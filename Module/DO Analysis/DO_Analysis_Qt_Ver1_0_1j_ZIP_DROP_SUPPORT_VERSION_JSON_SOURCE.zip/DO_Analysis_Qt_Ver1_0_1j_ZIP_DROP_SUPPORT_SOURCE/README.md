# DO Analysis Qt Ver1.0.1j — ZIP Drop Support

## Added

- Drag and drop `.zip`, `.txt`, `.log`, `.csv`, or folders anywhere on the application window.
- ZIP archives are extracted to a temporary folder and searched recursively.
- Only WaterSystem-compatible `.txt`, `.log`, and `.csv` files are loaded.
- Unsupported and unrelated files are skipped with a clear message.
- ZIP path traversal protection and automatic temporary-folder cleanup.
- Open Files now supports ZIP selection.
- Open Folder now searches all subfolders recursively.

## Run from source

Run `02_RUN_PYTHON_DEBUG.bat`.

## Build EXE locally or in GitHub Actions

Run `01_BUILD_EXE_NUITKA.bat` or `build_exe.bat`.

Output:

`dist\DO_Analysis_Qt_Ver1_0_1j.exe`

The BAT installs all requirements and builds a one-file Windows EXE with Nuitka.
