from __future__ import annotations

import csv
import math
import os
import re
import sys
import shutil
import tempfile
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from PySide6.QtCore import Qt, QRectF, Signal, QPoint, QRect, QTimer
from PySide6.QtGui import QColor, QBrush, QPen, QAction, QCursor, QDragEnterEvent, QDropEvent, QCloseEvent
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFileDialog, QGridLayout, QHBoxLayout,
    QLabel, QMainWindow, QMessageBox, QPushButton, QSplitter, QTableWidget,
    QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget, QGroupBox, QHeaderView,
    QRubberBand, QToolTip,
)

import pyqtgraph as pg

MIN_VALID_DO = 0.0
MAX_VALID_DO = 10.0
MIN_EVENT_DURATION_MIN = 3.0
EVENT_MERGE_GAP_MIN = 3.0
VACUUM_MIN_DO_CHANGE = 0.7
VACUUM_FLAT_TOL = 0.10
SECONDARY_FLOW_VALID_MIN = 2.0
SECONDARY_FLOW_VALID_MAX = 6.5

SENSOR_KEYS = [
    ("do", "DO"),
    ("vacuum", "Vacuum"),
    ("primary_flow", "Primary Flow"),
    ("secondary_flow", "Secondary Flow"),
    ("chiller_temp", "Chiller Temp"),
    ("xd_temp", "XD Temp"),
    ("absolute_pressure", "Absolute Pressure"),
    ("dynamic_pressure", "Dynamic Pressure"),
]

DEFAULT_VISIBLE = {
    "do": True,
    "vacuum": True,
    "primary_flow": False,
    "secondary_flow": True,
    "chiller_temp": False,
    "xd_temp": False,
    "absolute_pressure": False,
    "dynamic_pressure": False,
}

STATE_COLORS = {
    "DEGAS": (80, 180, 80, 55),
    "TREAT": (80, 140, 255, 55),
    "CLEAN_TANK": (255, 160, 40, 55),
    "CLEAN_XD": (170, 90, 220, 55),
    "INITIALIZATION": (150, 150, 150, 45),
    "WAIT": (180, 180, 180, 45),
    "PAUSE": (255, 220, 60, 55),
    "DRAIN": (155, 100, 55, 55),
    "FILL": (80, 200, 220, 55),
    "ERROR": (255, 70, 70, 70),
}

@dataclass
class Sample:
    time_text: str
    t_min: float
    state: str
    do: Optional[float]
    vacuum: Optional[float]
    primary_flow: Optional[float]
    secondary_flow: Optional[float]
    chiller_temp: Optional[float]
    xd_temp: Optional[float]
    absolute_pressure: Optional[float]
    dynamic_pressure: Optional[float]

@dataclass
class Segment:
    kind: str
    label: str
    start_idx: int
    end_idx: int
    start_min: float
    end_min: float
    duration_min: float
    metrics: Dict[str, object] = field(default_factory=dict)

@dataclass
class LogData:
    path: Path
    samples: List[Sample]
    events: List[Segment]
    non_events: List[Segment]


def norm_header(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


def parse_time_to_minutes(text: str) -> float:
    parts = text.split(":")
    if len(parts) < 3:
        return 0.0
    h = int(parts[0]); m = int(parts[1]); sec = float(parts[2])
    if len(parts) > 3:
        sec += float("0." + re.sub(r"\D", "", parts[3]))
    return h * 60.0 + m + sec / 60.0


def to_float(v: str) -> Optional[float]:
    try:
        if v is None or str(v).strip() == "":
            return None
        return float(v)
    except Exception:
        return None


def is_valid_do(v: Optional[float]) -> bool:
    return v is not None and MIN_VALID_DO <= v <= MAX_VALID_DO


def classify_event_state(state: str) -> Optional[str]:
    u = state.upper()
    if "DEGAS" in u and "CIRCULATE" in u:
        return "DEGAS"
    if "TREAT" in u and "CIRCULATE" in u:
        return "TREAT"
    if "CLEAN" in u and "TANK" in u and "CIRCULATE" in u:
        return "CLEAN_TANK"
    if "CLEAN" in u and "XD" in u and "CIRCULATE" in u:
        return "CLEAN_XD"
    return None


def classify_non_event_state(state: str) -> str:
    u = state.upper()
    if "ERROR" in u:
        return "ERROR"
    if "DRAIN" in u:
        return "DRAIN"
    if "FILL" in u:
        return "FILL"
    if "PAUSE" in u:
        return "PAUSE"
    if "WAIT" in u or "IDLE" in u or "STANDBY" in u:
        return "WAIT"
    if "INITIAL" in u:
        return "INITIALIZATION"
    return u.strip()[:24] if u.strip() else "UNKNOWN"


def split_log_line(line: str) -> List[str]:
    """Split both whitespace WaterSystem logs and simple CSV-like logs."""
    text = line.strip()
    if not text:
        return []
    if "," in text and text.count(",") >= text.count(" "):
        return [p.strip() for p in text.split(",")]
    return re.split(r"\s+", text)


def find_header_row(lines: List[str]) -> Tuple[int, List[str]]:
    """Find the real WaterSystem header row, even if log text exists before it."""
    max_scan = min(len(lines), 3000)
    for row in range(max_scan):
        tokens = split_log_line(lines[row])
        normalized = [norm_header(t) for t in tokens]
        if "mainstate" in normalized and "dolevel" in normalized:
            return row, tokens
    raise ValueError("Header row not found: MainState / DOLevel")


def parse_log_file(path: Path) -> LogData:
    lines = path.read_text(errors="ignore", encoding="utf-8-sig").splitlines()
    if not lines:
        raise ValueError("Empty file")

    header_row, header_tokens = find_header_row(lines)
    cols = {norm_header(h): i for i, h in enumerate(header_tokens)}
    aliases = {
        "state": ["mainstate"],
        "chiller_temp": ["chillertemp", "chillertemperature"],
        "primary_flow": ["primaryflowmeter", "primaryflow"],
        "absolute_pressure": ["absolutepressure"],
        "dynamic_pressure": ["dynamicpressure"],
        "xd_temp": ["xdtemperature", "xdtemp", "xdtemparature"],
        "vacuum": ["vacuumlevel", "vacuum"],
        "do": ["dolevel", "do"],
        "secondary_flow": ["secondaryflowmeter", "secondaryflow", "2ndflow"],
    }
    idx: Dict[str, int] = {}
    for key, names in aliases.items():
        for n in names:
            if n in cols:
                idx[key] = cols[n]
                break
    if "state" not in idx or "do" not in idx:
        raise ValueError("Required columns not found: MainState / DOLevel")

    samples: List[Sample] = []
    prev_t = None
    day_offset = 0.0
    for line in lines[header_row + 1:]:
        parts = split_log_line(line)
        if len(parts) < 3:
            continue
        raw_t = parts[0]
        # Data rows must start with a WaterSystem timestamp such as 15:24:54:161.
        if not re.match(r"^\d{1,2}:\d{2}:\d{2}", raw_t):
            continue
        t = parse_time_to_minutes(raw_t) + day_offset
        if prev_t is not None and t < prev_t - 720:
            day_offset += 1440.0
            t += 1440.0
        prev_t = t
        def getnum(k: str) -> Optional[float]:
            i = idx.get(k)
            return to_float(parts[i]) if i is not None and i < len(parts) else None
        state_i = idx["state"]
        state = parts[state_i] if state_i < len(parts) else ""
        samples.append(Sample(
            time_text=raw_t, t_min=t, state=state,
            do=getnum("do"), vacuum=getnum("vacuum"),
            primary_flow=getnum("primary_flow"), secondary_flow=getnum("secondary_flow"),
            chiller_temp=getnum("chiller_temp"), xd_temp=getnum("xd_temp"),
            absolute_pressure=getnum("absolute_pressure"), dynamic_pressure=getnum("dynamic_pressure"),
        ))
    if not samples:
        raise ValueError("No valid WaterSystem data rows found after header")
    events = detect_events(samples)
    non_events = detect_non_events(samples, events)
    return LogData(path=path, samples=samples, events=events, non_events=non_events)


def detect_events(samples: List[Sample]) -> List[Segment]:
    raw: List[Tuple[str, int, int]] = []
    in_kind = None; start = 0
    for i, s in enumerate(samples):
        kind = classify_event_state(s.state) if is_valid_do(s.do) else None
        if kind:
            if in_kind is None:
                in_kind = kind; start = i
            elif kind != in_kind:
                raw.append((in_kind, start, i - 1)); in_kind = kind; start = i
        else:
            if in_kind is not None:
                raw.append((in_kind, start, i - 1)); in_kind = None
    if in_kind is not None:
        raw.append((in_kind, start, len(samples) - 1))

    merged: List[Tuple[str, int, int]] = []
    for kind, s, e in raw:
        if merged and merged[-1][0] == kind:
            gap = samples[s].t_min - samples[merged[-1][2]].t_min
            if gap <= EVENT_MERGE_GAP_MIN:
                merged[-1] = (kind, merged[-1][1], e)
                continue
        merged.append((kind, s, e))

    counts = {"DEGAS": 0, "TREAT": 0, "CLEAN_TANK": 0, "CLEAN_XD": 0}
    events: List[Segment] = []
    for kind, s, e in merged:
        dur = samples[e].t_min - samples[s].t_min
        if dur < MIN_EVENT_DURATION_MIN:
            continue
        counts[kind] += 1
        if kind == "DEGAS": label = f"D{counts[kind]}"
        elif kind == "TREAT": label = f"T{counts[kind]}"
        elif kind == "CLEAN_TANK": label = "CT" if counts[kind] == 1 else f"CT{counts[kind]}"
        else: label = "CXD" if counts[kind] == 1 else f"CXD{counts[kind]}"
        seg = Segment(kind=kind, label=label, start_idx=s, end_idx=e,
                      start_min=samples[s].t_min, end_min=samples[e].t_min, duration_min=dur)
        seg.metrics = compute_event_metrics(samples, seg)
        events.append(seg)
    return events


def detect_non_events(samples: List[Sample], events: List[Segment]) -> List[Segment]:
    event_mask = [False] * len(samples)
    for ev in events:
        for i in range(ev.start_idx, ev.end_idx + 1):
            if 0 <= i < len(event_mask): event_mask[i] = True
    segs: List[Segment] = []
    cur_kind = None; start = 0
    for i, s in enumerate(samples):
        kind = None if event_mask[i] else classify_non_event_state(s.state)
        if kind:
            if cur_kind is None:
                cur_kind = kind; start = i
            elif kind != cur_kind:
                add_non_event_segment(segs, samples, cur_kind, start, i - 1)
                cur_kind = kind; start = i
        else:
            if cur_kind is not None:
                add_non_event_segment(segs, samples, cur_kind, start, i - 1)
                cur_kind = None
    if cur_kind is not None:
        add_non_event_segment(segs, samples, cur_kind, start, len(samples) - 1)
    return segs


def add_non_event_segment(segs: List[Segment], samples: List[Sample], kind: str, s: int, e: int) -> None:
    dur = samples[e].t_min - samples[s].t_min
    if dur < 0.05:
        return
    label_map = {"INITIALIZATION": "Initialization", "WAIT": "Wait", "PAUSE": "Pause", "DRAIN": "Drain", "FILL": "Fill", "ERROR": "Error"}
    label = label_map.get(kind, kind.title())
    segs.append(Segment(kind=kind, label=label, start_idx=s, end_idx=e,
                        start_min=samples[s].t_min, end_min=samples[e].t_min, duration_min=dur))


def avg(vals: List[float]) -> Optional[float]:
    return sum(vals) / len(vals) if vals else None


def compute_event_metrics(samples: List[Sample], seg: Segment) -> Dict[str, object]:
    block = samples[seg.start_idx:seg.end_idx + 1]
    do_pairs = [(i + seg.start_idx, s.do) for i, s in enumerate(block) if is_valid_do(s.do)]
    metrics: Dict[str, object] = {"min_do": None, "to_min": None, "to_15": None, "to_10": None,
                                  "second_flow_avg": None, "vacuum_trend": "N/A"}
    if do_pairs:
        min_idx, min_do = min(do_pairs, key=lambda x: x[1])
        metrics["min_do"] = min_do
        metrics["to_min"] = samples[min_idx].t_min - seg.start_min
        for threshold, key in [(1.5, "to_15"), (1.0, "to_10")]:
            hit = next((idx for idx, val in do_pairs if val <= threshold), None)
            metrics[key] = (samples[hit].t_min - seg.start_min) if hit is not None else None
    sf_vals = [s.secondary_flow for s in block if s.secondary_flow is not None and SECONDARY_FLOW_VALID_MIN <= s.secondary_flow <= SECONDARY_FLOW_VALID_MAX]
    metrics["second_flow_avg"] = avg(sf_vals)
    metrics["vacuum_trend"] = compute_vacuum_trend(block)
    return metrics


def compute_vacuum_trend(block: List[Sample]) -> str:
    pairs = [(s.do, s.vacuum) for s in block if is_valid_do(s.do) and s.vacuum is not None]
    if not pairs:
        return "N/A"
    do_vals = [p[0] for p in pairs]
    max_do = max(do_vals); min_do = min(do_vals)
    if max_do - min_do < VACUUM_MIN_DO_CHANGE:
        return "N/A"
    high_v = [v for d, v in pairs if d >= max_do - 0.2]
    low_v = [v for d, v in pairs if d <= min_do + 0.2]
    if not high_v or not low_v:
        return "N/A"
    diff = avg(low_v) - avg(high_v)
    if diff > VACUUM_FLAT_TOL:
        return "UP"
    if diff < -VACUUM_FLAT_TOL:
        return "DOWN"
    return "FLAT"


def fmt_min(v: Optional[float]) -> str:
    return "N/A" if v is None else f"{v:.1f} min"


def fmt_val(v: Optional[float], digits: int = 2) -> str:
    return "N/A" if v is None else f"{v:.{digits}f}"



class TimeAxisItem(pg.AxisItem):
    """X axis that can display WaterSystem log time instead of sample index."""
    def __init__(self, orientation='bottom'):
        super().__init__(orientation=orientation)
        self.mode = "actual"
        self.base_min = 0.0

    def set_mode(self, mode: str, base_min: float = 0.0) -> None:
        self.mode = mode
        self.base_min = base_min
        self.picture = None
        self.update()

    def tickStrings(self, values, scale, spacing):
        labels = []
        for v in values:
            try:
                if self.mode == "relative":
                    rel = float(v) - float(self.base_min)
                    if abs(rel) < 0.01:
                        labels.append("0 min")
                    elif abs(rel) < 60:
                        labels.append(f"{rel:.1f} min")
                    else:
                        h = int(rel // 60)
                        m = rel - h * 60
                        labels.append(f"{h}h{m:.0f}m")
                else:
                    total_sec = int(round((float(v) % 1440.0) * 60.0))
                    hh = (total_sec // 3600) % 24
                    mm = (total_sec % 3600) // 60
                    ss = total_sec % 60
                    # Show seconds only when zoomed in tightly.
                    if spacing < 1.0:
                        labels.append(f"{hh:02d}:{mm:02d}:{ss:02d}")
                    else:
                        labels.append(f"{hh:02d}:{mm:02d}")
            except Exception:
                labels.append("")
        return labels

class ChartWidget(pg.PlotWidget):
    eventClicked = Signal(object)

    def __init__(self):
        self.time_axis = TimeAxisItem(orientation="bottom")
        super().__init__(axisItems={"bottom": self.time_axis})
        self.setBackground("w")
        self.showGrid(x=True, y=True, alpha=0.25)
        self.addLegend(offset=(10, 10))
        self.log: Optional[LogData] = None
        self.visible: Dict[str, bool] = DEFAULT_VISIBLE.copy()
        self.x_axis_mode = "actual"
        self.show_event_band = True
        self.show_event_label = True
        self.show_non_event_band = True
        self.show_non_event_label = True
        self.items_to_clear: List[object] = []
        self.overlay_items: List[object] = []
        self.drag_start: Optional[float] = None
        self.vb = self.getViewBox()
        self._redrawing = False
        self._range_update_guard = False
        self.setMouseTracking(True)
        self.scene().sigMouseClicked.connect(self._on_scene_clicked)
        self.scene().sigMouseMoved.connect(self._on_scene_mouse_moved)
        self.vb.sigRangeChanged.connect(self._on_view_range_changed)

        # Ver1.0.1: rectangular click-and-drag zoom.
        # Left button drag draws a rubber-band rectangle on the chart, and
        # releasing the mouse zooms both X and Y axes to the selected area.
        # This is intentionally handled here instead of relying on the default
        # PyQtGraph mouse mode so it works consistently after file switching
        # and with the custom time axis.
        self._rubber_band = QRubberBand(QRubberBand.Rectangle, self)
        self._rubber_origin: Optional[QPoint] = None
        self._rubber_active = False
        self._rubber_min_px = 8

        # Hover value popup.  The popup intentionally does not show a series
        # name; it shows the full sensor snapshot at the nearest timestamp.
        self._hover_text: Optional[pg.TextItem] = None
        self._hover_vline: Optional[pg.InfiniteLine] = None
        # Range changes in PyQtGraph can arrive in multiple steps
        # (X change first, then Y auto-scale). Overlay labels and the Y axis
        # are updated by a deferred controller so the final ViewBox range is
        # used, not the old pre-zoom range.
        self._overlay_refresh_pending = False
        self._view_update_pending = False

    def set_log(self, log: Optional[LogData]) -> None:
        self.log = log
        if log and log.samples:
            self.time_axis.set_mode(self.x_axis_mode, log.samples[0].t_min)
        # File changes must reset the X-axis to the new file's real time range.
        # Without this, PyQtGraph can keep the previous file's ViewBox range,
        # so Next/Previous or the file combo appears to load data but the
        # horizontal axis remains stuck on the old file.
        self.redraw(reset_view=True)

    def set_x_axis_mode(self, mode: str) -> None:
        self.x_axis_mode = "relative" if mode.lower().startswith("relative") else "actual"
        base = self.log.samples[0].t_min if self.log and self.log.samples else 0.0
        self.time_axis.set_mode(self.x_axis_mode, base)
        # Keep the current zoom when only changing label mode.
        self.redraw(reset_view=False)

    def _format_x_time(self, x_value: float) -> str:
        if not self.log or not self.log.samples:
            return "N/A"
        if self.x_axis_mode == "relative":
            rel = float(x_value) - self.log.samples[0].t_min
            return f"{rel:.2f} min"
        total_sec = int(round((float(x_value) % 1440.0) * 60.0))
        hh = (total_sec // 3600) % 24
        mm = (total_sec % 3600) // 60
        ss = total_sec % 60
        return f"{hh:02d}:{mm:02d}:{ss:02d}"

    def _find_nearest_sample_index(self, x_value: float) -> Optional[int]:
        if not self.log or not self.log.samples:
            return None
        samples = self.log.samples
        # Binary search is unnecessary for correctness, but keeps hover smooth
        # with long WaterSystem logs.
        lo, hi = 0, len(samples) - 1
        while lo < hi:
            mid = (lo + hi) // 2
            if samples[mid].t_min < x_value:
                lo = mid + 1
            else:
                hi = mid
        candidates = [lo]
        if lo > 0:
            candidates.append(lo - 1)
        if lo + 1 < len(samples):
            candidates.append(lo + 1)
        return min(candidates, key=lambda i: abs(samples[i].t_min - x_value))

    def _segment_at_x(self, x_value: float) -> Optional[Segment]:
        if not self.log:
            return None
        for seg in self.log.events:
            if seg.start_min <= x_value <= seg.end_min:
                return seg
        return None

    def _non_event_at_x(self, x_value: float) -> Optional[Segment]:
        if not self.log:
            return None
        for seg in self.log.non_events:
            if seg.start_min <= x_value <= seg.end_min:
                return seg
        return None

    def _ensure_hover_items(self) -> None:
        # Hover items are recreated after PlotWidget.clear().  Use the
        # TextItem constructor for fill/border because some pyqtgraph versions
        # do not provide setFill()/setBorder(); when those methods are missing,
        # mouse-move silently fails and no popup appears.
        if self._hover_vline is None:
            self._hover_vline = pg.InfiniteLine(
                angle=90,
                movable=False,
                pen=pg.mkPen((60, 60, 60), width=1, style=Qt.DashLine),
            )
            self._hover_vline.setZValue(900)
            self.addItem(self._hover_vline, ignoreBounds=True)
        if self._hover_text is None:
            self._hover_text = pg.TextItem(
                "",
                color=(20, 20, 20),
                anchor=(0, 1),
                fill=QColor(255, 255, 235, 235),
                border=pg.mkPen((120, 120, 120), width=1),
            )
            self._hover_text.setZValue(1000)
            self.addItem(self._hover_text, ignoreBounds=True)
        self._hover_vline.hide()
        self._hover_text.hide()

    def _sensor_line(self, label: str, value: Optional[float], digits: int = 2) -> str:
        return f"{label} : {'N/A' if value is None else f'{value:.{digits}f}'}"

    def _build_sample_hover_text(self, x_value: float, sample: Sample) -> str:
        lines = [
            f"Time : {self._format_x_time(sample.t_min)}",
            f"State : {sample.state}",
        ]
        ev = self._segment_at_x(x_value)
        if ev is not None:
            lines.append(f"Event : {ev.label}")
        else:
            nev = self._non_event_at_x(x_value)
            if nev is not None:
                lines.append(f"Non-event : {nev.label}")
        lines.extend([
            self._sensor_line("DO", sample.do),
            self._sensor_line("Vacuum", sample.vacuum),
            self._sensor_line("Primary Flow", sample.primary_flow),
            self._sensor_line("2nd Flow", sample.secondary_flow),
            self._sensor_line("Chiller Temp", sample.chiller_temp),
            self._sensor_line("XD Temp", sample.xd_temp),
            self._sensor_line("Absolute Pressure", sample.absolute_pressure),
            self._sensor_line("Dynamic Pressure", sample.dynamic_pressure),
        ])
        return "\n".join(lines)

    def _build_event_hover_text(self, seg: Segment) -> str:
        m = seg.metrics
        return "\n".join([
            f"{seg.label}  {seg.kind}",
            f"Start : {self._format_x_time(seg.start_min)}",
            f"End   : {self._format_x_time(seg.end_min)}",
            f"Duration : {seg.duration_min:.1f} min",
            f"Min DO : {fmt_val(m.get('min_do'))}",
            f"To 1.5 : {fmt_min(m.get('to_15'))}",
            f"To 1.0 : {fmt_min(m.get('to_10'))}",
            f"2nd Flow Avg : {fmt_val(m.get('second_flow_avg'))}",
            f"Vacuum Trend : {m.get('vacuum_trend', 'N/A')}",
        ])

    def _update_hover_popup(self, widget_pos: QPoint) -> None:
        scene_pos = self.mapToScene(widget_pos)
        self._update_hover_popup_scene(scene_pos)

    def _on_scene_mouse_moved(self, scene_pos) -> None:
        if self._rubber_active:
            return
        self._update_hover_popup_scene(scene_pos)

    def _update_hover_popup_scene(self, scene_pos) -> None:
        if not self.log or not self.log.samples:
            return
        if not self.plotItem.vb.sceneBoundingRect().contains(scene_pos):
            if self._hover_text: self._hover_text.hide()
            if self._hover_vline: self._hover_vline.hide()
            try:
                QToolTip.hideText()
            except Exception:
                pass
            return
        p = self.plotItem.vb.mapSceneToView(scene_pos)
        x_value = float(p.x())
        y_value = float(p.y())
        idx = self._find_nearest_sample_index(x_value)
        if idx is None:
            return
        sample = self.log.samples[idx]
        yr = self.vb.viewRange()[1]
        y0, y1 = yr[0], yr[1]
        # When the pointer is in the upper overlay lanes and inside an event,
        # show the event-specific popup.  Otherwise show the nearest timestamp
        # sensor snapshot.
        event_seg = self._segment_at_x(x_value)
        if event_seg is not None and y_value > y0 + (y1 - y0) * 0.72:
            popup = self._build_event_hover_text(event_seg)
        else:
            popup = self._build_sample_hover_text(x_value, sample)

        self._ensure_hover_items()
        assert self._hover_text is not None and self._hover_vline is not None
        self._hover_vline.setPos(sample.t_min)
        self._hover_vline.show()
        # Place popup near the cursor but keep it inside the current Y range.
        y_popup = min(max(y_value, y0 + (y1 - y0) * 0.15), y1 - (y1 - y0) * 0.05)
        self._hover_text.setText(popup)
        self._hover_text.setPos(sample.t_min, y_popup)
        self._hover_text.show()
        # Also show a native Qt tooltip. This makes the value popup visible even
        # if graphics overlay items are hidden behind a ViewBox state on some
        # Windows/PyQtGraph combinations.
        try:
            QToolTip.showText(QCursor.pos(), popup, self)
        except Exception:
            pass

    def set_visible(self, key: str, value: bool) -> None:
        self.visible[key] = value
        self.redraw()

    def set_overlay(self, event_band: bool, event_label: bool, non_event_band: bool, non_event_label: bool) -> None:
        self.show_event_band = event_band
        self.show_event_label = event_label
        self.show_non_event_band = non_event_band
        self.show_non_event_label = non_event_label
        self.redraw()

    def redraw(self, reset_view: bool = False) -> None:
        self._redrawing = True
        self.clear()
        self.overlay_items = []
        self.addLegend(offset=(10, 10))
        if not self.log or not self.log.samples:
            self._redrawing = False
            return
        self.setLabel('bottom', 'Time' if self.x_axis_mode == 'actual' else 'Relative time')
        x = [s.t_min for s in self.log.samples]
        pens = {
            "do": pg.mkPen((20, 80, 220), width=2),
            "vacuum": pg.mkPen((200, 0, 0), width=1.5),
            "primary_flow": pg.mkPen((140, 80, 180), width=1.2),
            "secondary_flow": pg.mkPen((0, 130, 180), width=1.6, style=Qt.DashLine),
            "chiller_temp": pg.mkPen((0, 160, 70), width=1.2),
            "xd_temp": pg.mkPen((255, 120, 0), width=1.2),
            "absolute_pressure": pg.mkPen((150, 150, 0), width=1.2),
            "dynamic_pressure": pg.mkPen((90, 90, 90), width=1.2),
        }
        for key, label in SENSOR_KEYS:
            if not self.visible.get(key, False):
                continue
            y = [getattr(s, key) if getattr(s, key) is not None else math.nan for s in self.log.samples]
            self.plot(x, y, pen=pens[key], name=label)

        if reset_view and x:
            xmin = min(x)
            xmax = max(x)
            if xmax > xmin:
                self.setXRange(xmin, xmax, padding=0)
            else:
                self.setXRange(xmin - 0.5, xmax + 0.5, padding=0)

        self._autoscale_y()
        self._draw_overlays()
        self._hover_text = None
        self._hover_vline = None
        self._ensure_hover_items()
        self._redrawing = False
        self._schedule_view_update()

    def _autoscale_y(self) -> None:
        if not self.log:
            return
        xmin, xmax = self.vb.viewRange()[0]
        vals: List[float] = []
        for s in self.log.samples:
            if s.t_min < xmin or s.t_min > xmax:
                continue
            for key, _ in SENSOR_KEYS:
                if self.visible.get(key, False):
                    v = getattr(s, key)
                    if v is not None and math.isfinite(v):
                        vals.append(v)
        if vals:
            lo, hi = min(vals), max(vals)
            pad = max((hi - lo) * 0.08, 0.5)
            self.setYRange(lo - pad, hi + pad, padding=0)

    def _clear_overlays(self) -> None:
        # Remove overlay items from both PlotWidget and ViewBox/scene.
        # LinearRegionItem/TextItem can be owned by the ViewBox internally, so
        # using only PlotWidget.removeItem() was not always enough after zoom/reset.
        for item in list(self.overlay_items):
            try:
                self.removeItem(item)
            except Exception:
                pass
            try:
                self.plotItem.vb.removeItem(item)
            except Exception:
                pass
            try:
                self.scene().removeItem(item)
            except Exception:
                pass
        self.overlay_items = []

    def _refresh_overlays(self) -> None:
        if self._redrawing:
            return
        self._overlay_refresh_pending = False
        self._clear_overlays()
        self._draw_overlays()

    def _schedule_overlay_refresh(self) -> None:
        """Redraw labels/bands after the final visible range has settled.

        The same method is called after zoom, reset, wheel zoom, pan, file
        switching, and Y-axis auto-scale. Multiple delayed refreshes are
        intentional: PyQtGraph may emit range changes in several steps.
        """
        if self._redrawing:
            return
        self._overlay_refresh_pending = True
        QTimer.singleShot(0, self._refresh_overlays)
        QTimer.singleShot(60, self._refresh_overlays)
        QTimer.singleShot(160, self._refresh_overlays)

    def _force_overlay_refresh(self) -> None:
        """Synchronously rebuild overlay items using the current ViewBox range."""
        if self._redrawing:
            return
        self._overlay_refresh_pending = False
        self._clear_overlays()
        self._draw_overlays()

    def _apply_y_autoscale_and_refresh(self) -> None:
        """Hard refresh after every ViewBox range change.

        This is the single authoritative refresh path for zoom, reset, pan,
        wheel zoom, file switching, and event jumps.

        Important fixes in Ver1.0.1h:
        - Read the current X range after the ViewBox has changed.
        - Auto-scale Y from visible sensor data only.
        - Force-remove old overlay objects from PlotWidget/ViewBox/scene.
        - Rebuild Event/Non-event bands and labels clipped to the new X range.
        - Run immediately and also via delayed timers so PyQtGraph's internal
          range updates cannot leave labels at the old location.
        """
        if self._redrawing or not self.log or not self.log.samples:
            self._view_update_pending = False
            return
        if self._range_update_guard:
            return

        self._view_update_pending = False
        self._range_update_guard = True
        try:
            self._autoscale_y()
            self._clear_overlays()
            self._draw_overlays()
            try:
                self.plotItem.vb.update()
                self.plotItem.update()
                self.update()
                self.scene().update()
            except Exception:
                pass
        finally:
            self._range_update_guard = False

    def _refresh_view_now(self) -> None:
        """Synchronous refresh used directly after setXRange/setRange calls."""
        self._apply_y_autoscale_and_refresh()

    def _schedule_view_update(self) -> None:
        if self._redrawing or not self.log or not self.log.samples:
            return
        # First refresh synchronously so labels/bands update immediately after
        # Reset Zoom / rectangle zoom.  Then run delayed passes to catch the
        # final ViewBox range after PyQtGraph finishes wheel/pan processing.
        self._refresh_view_now()
        for delay in (0, 20, 60, 120, 240, 500):
            QTimer.singleShot(delay, self._apply_y_autoscale_and_refresh)

    def _on_view_range_changed(self, *args) -> None:
        if self._redrawing or self._range_update_guard:
            return
        self._schedule_view_update()

    def _assign_label_lane(self, segments: List[Segment], lane_count: int, view_span: float, min_gap_ratio: float = 0.045) -> Dict[int, int]:
        """Assign overlay labels to lanes without changing the working 1.0.1a band/hover behavior.
        This only changes label Y positions, so Event Band, Non-event Band, and popup behavior stay stable.
        """
        lane_end = [-1e18] * max(1, lane_count)
        result: Dict[int, int] = {}
        min_gap = max(view_span * min_gap_ratio, 0.12)
        for seg in sorted(segments, key=lambda z: z.start_min):
            center = (seg.start_min + seg.end_min) / 2.0
            label_width = max(min_gap, view_span * (0.010 + 0.0035 * len(seg.label)))
            start = center - label_width / 2.0
            end = center + label_width / 2.0
            placed = False
            for lane in range(len(lane_end)):
                if start >= lane_end[lane]:
                    result[id(seg)] = lane
                    lane_end[lane] = end
                    placed = True
                    break
            if not placed:
                lane = min(range(len(lane_end)), key=lambda i: lane_end[i])
                result[id(seg)] = lane
                lane_end[lane] = end
        return result

    def _draw_overlays(self) -> None:
        if not self.log:
            return
        xr = self.vb.viewRange()[0]
        xmin, xmax = xr[0], xr[1]
        view_span = max(xmax - xmin, 0.01)
        yr = self.vb.viewRange()[1]
        y0, y1 = yr[0], yr[1]
        lane_h = (y1 - y0) * 0.045
        ev_label_y = y1 - lane_h * 0.8
        non_label_y = y1 - lane_h * 1.9

        visible_events = [seg for seg in self.log.events if seg.end_min >= xmin and seg.start_min <= xmax]
        visible_non_events = [seg for seg in self.log.non_events if seg.end_min >= xmin and seg.start_min <= xmax]

        # Use clipped segments for label placement.  This is the key fix for
        # zoom/reset: when a long Drain/Fill/Treat segment is only partly visible,
        # the label must be centered in the visible portion, not at the original
        # full-segment center outside the screen.
        def clipped_bounds(seg: Segment) -> Tuple[float, float, float]:
            a = max(seg.start_min, xmin)
            b = min(seg.end_min, xmax)
            c = (a + b) / 2.0
            return a, b, c

        def clipped_proxy(seg: Segment) -> Segment:
            a, b, _ = clipped_bounds(seg)
            # Only the label/start/end are used by _assign_label_lane.
            return Segment(kind=seg.kind, label=seg.label, start_idx=seg.start_idx, end_idx=seg.end_idx,
                           start_min=a, end_min=b, duration_min=max(b-a, 0.0), metrics=seg.metrics)

        ev_proxy = [clipped_proxy(seg) for seg in visible_events]
        non_proxy = [clipped_proxy(seg) for seg in visible_non_events]
        ev_lanes_proxy = self._assign_label_lane(ev_proxy, 3, view_span, 0.050)
        non_lanes_proxy = self._assign_label_lane(non_proxy, 5, view_span, 0.055)
        ev_lanes = {id(seg): ev_lanes_proxy.get(id(proxy), 0) for seg, proxy in zip(visible_events, ev_proxy)}
        non_lanes = {id(seg): non_lanes_proxy.get(id(proxy), 0) for seg, proxy in zip(visible_non_events, non_proxy)}

        # Bands are clipped to the visible range and labels are centered on the
        # visible part of each segment.  Overlay items are ignoreBounds=True so
        # they never affect Y-axis autoscale.
        if self.show_event_band or self.show_event_label:
            for ev in visible_events:
                a, b, c = clipped_bounds(ev)
                if b <= a:
                    continue
                color = QColor(*STATE_COLORS.get(ev.kind, (100, 100, 100, 55)))
                if self.show_event_band:
                    item = pg.LinearRegionItem(values=[a, b], orientation='vertical', brush=QBrush(color), movable=False)
                    item.setZValue(-10)
                    self.addItem(item, ignoreBounds=True)
                    self.overlay_items.append(item)
                if self.show_event_label:
                    lane = ev_lanes.get(id(ev), 0)
                    text = pg.TextItem(ev.label, color=(20, 20, 20), anchor=(0.5, 0.5))
                    text.setZValue(100)
                    text.setPos(c, ev_label_y - lane * lane_h * 0.58)
                    self.addItem(text, ignoreBounds=True)
                    self.overlay_items.append(text)
        if self.show_non_event_band or self.show_non_event_label:
            for seg in visible_non_events:
                a, b, c = clipped_bounds(seg)
                if b <= a:
                    continue
                color = QColor(*STATE_COLORS.get(seg.kind, (160, 160, 160, 40)))
                if self.show_non_event_band:
                    item = pg.LinearRegionItem(values=[a, b], orientation='vertical', brush=QBrush(color), movable=False)
                    item.setZValue(-20)
                    self.addItem(item, ignoreBounds=True)
                    self.overlay_items.append(item)
                if self.show_non_event_label:
                    lane = non_lanes.get(id(seg), 0)
                    text = pg.TextItem(seg.label, color=(60, 60, 60), anchor=(0.5, 0.5))
                    text.setZValue(110)
                    text.setPos(c, non_label_y - lane * lane_h * 0.48)
                    self.addItem(text, ignoreBounds=True)
                    self.overlay_items.append(text)

    def mouseDoubleClickEvent(self, ev):
        self.reset_zoom_to_current_file()
        ev.accept()

    def mousePressEvent(self, ev):
        if ev.button() == Qt.LeftButton and self.log and self.log.samples:
            self._rubber_origin = ev.pos()
            self._rubber_active = True
            self._rubber_band.setGeometry(QRect(self._rubber_origin, self._rubber_origin).normalized())
            self._rubber_band.show()
            ev.accept()
            return
        super().mousePressEvent(ev)

    def mouseMoveEvent(self, ev):
        if self._rubber_active and self._rubber_origin is not None:
            self._rubber_band.setGeometry(QRect(self._rubber_origin, ev.pos()).normalized())
            ev.accept()
            return
        self._update_hover_popup(ev.pos())
        super().mouseMoveEvent(ev)

    def mouseReleaseEvent(self, ev):
        if self._rubber_active and ev.button() == Qt.LeftButton:
            rect = self._rubber_band.geometry().normalized()
            self._rubber_band.hide()
            self._rubber_active = False
            self._rubber_origin = None

            if rect.width() >= self._rubber_min_px and rect.height() >= self._rubber_min_px:
                self._apply_rect_zoom(rect)
            else:
                # Small click: keep event selection behavior.
                super().mouseReleaseEvent(ev)
            ev.accept()
            return
        super().mouseReleaseEvent(ev)
        self._schedule_view_update()

    def wheelEvent(self, ev):
        super().wheelEvent(ev)
        self._schedule_view_update()

    def _apply_rect_zoom(self, rect: QRect) -> None:
        if not self.log:
            return
        # Convert widget coordinates -> scene coordinates -> data coordinates.
        top_left_scene = self.mapToScene(rect.topLeft())
        bottom_right_scene = self.mapToScene(rect.bottomRight())
        p1 = self.plotItem.vb.mapSceneToView(top_left_scene)
        p2 = self.plotItem.vb.mapSceneToView(bottom_right_scene)

        x1, x2 = sorted([float(p1.x()), float(p2.x())])
        y1, y2 = sorted([float(p1.y()), float(p2.y())])
        if x2 <= x1 or y2 <= y1:
            return
        # Rectangle selection uses the drawn X range and then recalculates Y
        # automatically from the visible sensor data. This keeps the vertical
        # axis meaningful after zoom and avoids labels being positioned with an
        # old or arbitrary Y range.
        self.setXRange(x1, x2, padding=0)
        self._schedule_view_update()

    def _on_scene_clicked(self, ev) -> None:
        if not self.log or ev.button() != Qt.LeftButton:
            return
        pos = ev.scenePos()
        if not self.plotItem.vb.sceneBoundingRect().contains(pos):
            return
        mouse_point = self.plotItem.vb.mapSceneToView(pos)
        x = mouse_point.x()
        nearest = None; best = 1e9
        for seg in self.log.events:
            if seg.start_min <= x <= seg.end_min:
                nearest = seg; break
            d = min(abs(x - seg.start_min), abs(x - seg.end_min))
            if d < best:
                best = d; nearest = seg
        if nearest and best < 5 or (nearest and nearest.start_min <= x <= nearest.end_min):
            self.eventClicked.emit(nearest)

    def zoom_to_segment(self, seg: Segment) -> None:
        pad = max(seg.duration_min * 0.15, 0.5)
        self.setXRange(seg.start_min - pad, seg.end_min + pad, padding=0)
        self._schedule_view_update()

    def reset_zoom_to_current_file(self) -> None:
        if not self.log or not self.log.samples:
            return
        xs = [s.t_min for s in self.log.samples]
        xmin, xmax = min(xs), max(xs)
        if xmax > xmin:
            self.setXRange(xmin, xmax, padding=0)
        else:
            self.setXRange(xmin - 0.5, xmax + 0.5, padding=0)
        self._schedule_view_update()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("DO Analysis Qt Ver1.0.1j ZIP Drop Support")
        self.setAcceptDrops(True)
        self.resize(1500, 900)
        self.logs: List[LogData] = []
        self._temp_dirs: List[Path] = []
        self.current_index = -1
        self.chart = ChartWidget()
        self.chart.eventClicked.connect(self.select_event)
        self.file_combo = QComboBox()
        self.file_combo.setMinimumWidth(520)
        self.file_combo.setMinimumContentsLength(55)
        try:
            self.file_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        except Exception:
            pass
        self.file_combo.currentIndexChanged.connect(self.change_file)
        self.x_axis_combo = QComboBox()
        self.x_axis_combo.addItems(["Actual Time", "Relative Time"])
        self.x_axis_combo.currentTextChanged.connect(self.change_x_axis_mode)
        self.current_file_label = QLabel("No file loaded")
        self.current_file_label.setStyleSheet("font-weight: bold; color: #333;")
        self.event_table = QTableWidget(0, 8)
        self.event_table.setHorizontalHeaderLabels(["Event", "Duration", "Min DO", "To Min", "To 1.5", "To 1.0", "2nd Flow Avg", "Vacuum"])
        self.event_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.event_table.cellClicked.connect(self.event_row_clicked)
        self.summary = QTextEdit(); self.summary.setReadOnly(True); self.summary.setMaximumHeight(70)
        self.checks: Dict[str, QCheckBox] = {}
        self.cb_event_band = QCheckBox("Event Band"); self.cb_event_band.setChecked(True)
        self.cb_event_label = QCheckBox("Event Label"); self.cb_event_label.setChecked(True)
        self.cb_non_event_band = QCheckBox("Non-event Band"); self.cb_non_event_band.setChecked(True)
        self.cb_non_event_label = QCheckBox("Non-event Label"); self.cb_non_event_label.setChecked(True)
        self.cb_all = QCheckBox("ALL"); self.cb_all.setChecked(False)
        self.cb_all.stateChanged.connect(self.toggle_all)
        for cb in [self.cb_event_band, self.cb_event_label, self.cb_non_event_band, self.cb_non_event_label]:
            cb.stateChanged.connect(self.update_overlay)
        self._build_ui()

    def _build_ui(self):
        open_files = QPushButton("Open Files / ZIP")
        open_files.clicked.connect(self.open_files)
        open_folder = QPushButton("Open Folder")
        open_folder.clicked.connect(self.open_folder)
        prev_btn = QPushButton("Previous")
        prev_btn.clicked.connect(lambda: self.step_file(-1))
        next_btn = QPushButton("Next")
        next_btn.clicked.connect(lambda: self.step_file(1))
        reset_btn = QPushButton("Reset Zoom")
        reset_btn.clicked.connect(self.chart.reset_zoom_to_current_file)

        top = QHBoxLayout()
        for w in [open_files, open_folder, QLabel("File:"), self.file_combo, prev_btn, next_btn, QLabel("X Axis:"), self.x_axis_combo, reset_btn]:
            top.addWidget(w)

        sensor_box = QGroupBox("Display")
        display_layout = QVBoxLayout(sensor_box)
        display_layout.setContentsMargins(8, 8, 8, 8)
        display_layout.setSpacing(3)
        display_layout.addWidget(self.cb_all)
        for key, label in SENSOR_KEYS:
            cb = QCheckBox(label)
            cb.setChecked(DEFAULT_VISIBLE[key])
            cb.stateChanged.connect(lambda _, k=key: self.update_sensor(k))
            self.checks[key] = cb
            display_layout.addWidget(cb)
        display_layout.addSpacing(8)
        display_layout.addWidget(QLabel("Overlay"))
        display_layout.addWidget(self.cb_event_band)
        display_layout.addWidget(self.cb_event_label)
        display_layout.addWidget(self.cb_non_event_band)
        display_layout.addWidget(self.cb_non_event_label)
        display_layout.addStretch(1)

        left = QVBoxLayout()
        left.addWidget(sensor_box)
        left_widget = QWidget(); left_widget.setLayout(left); left_widget.setMinimumWidth(170); left_widget.setMaximumWidth(200)

        right = QVBoxLayout()
        right.addLayout(top)
        drop_hint = QLabel("Drop WaterSystem log files, folders, or ZIP archives anywhere on this window")
        drop_hint.setStyleSheet("color: #555; padding: 3px 0;")
        right.addWidget(drop_hint)
        right.addWidget(self.current_file_label)
        right.addWidget(self.chart, stretch=8)
        right.addWidget(QLabel("Event Results"))
        self.event_table.setMaximumHeight(145)
        right.addWidget(self.event_table, stretch=1)
        right.addWidget(QLabel("Selected Event Summary"))
        right.addWidget(self.summary)
        right_widget = QWidget(); right_widget.setLayout(right)

        splitter = QSplitter()
        splitter.addWidget(left_widget)
        splitter.addWidget(right_widget)
        splitter.setStretchFactor(1, 1)
        self.setCentralWidget(splitter)

    def open_files(self):
        files, _ = QFileDialog.getOpenFileNames(
            self,
            "Select WaterSystem logs or ZIP files",
            "",
            "Supported files (*.zip *.txt *.log *.csv);;ZIP files (*.zip);;Log files (*.txt *.log *.csv);;All files (*.*)",
        )
        self.load_inputs([Path(f) for f in files])

    def open_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select folder")
        if not folder:
            return
        self.load_inputs([Path(folder)])

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        urls = event.mimeData().urls() if event.mimeData().hasUrls() else []
        if any(url.isLocalFile() for url in urls):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event: QDropEvent) -> None:
        paths = [Path(url.toLocalFile()) for url in event.mimeData().urls() if url.isLocalFile()]
        if paths:
            self.load_inputs(paths)
            event.acceptProposedAction()
        else:
            event.ignore()

    def _safe_extract_zip(self, zip_path: Path) -> Path:
        temp_root = Path(tempfile.mkdtemp(prefix="do_analysis_zip_"))
        self._temp_dirs.append(temp_root)
        root_resolved = temp_root.resolve()
        with zipfile.ZipFile(zip_path, "r") as zf:
            for member in zf.infolist():
                target = (temp_root / member.filename).resolve()
                if target != root_resolved and root_resolved not in target.parents:
                    raise ValueError(f"Unsafe ZIP entry: {member.filename}")
            zf.extractall(temp_root)
        return temp_root

    def _collect_supported_files(self, inputs: List[Path]) -> Tuple[List[Path], List[str]]:
        candidates: List[Path] = []
        errors: List[str] = []
        for source in inputs:
            try:
                if not source.exists():
                    errors.append(f"{source.name}: file or folder not found")
                elif source.is_dir():
                    candidates.extend(
                        p for p in source.rglob("*")
                        if p.is_file() and p.suffix.lower() in (".txt", ".log", ".csv")
                    )
                elif source.suffix.lower() == ".zip":
                    extracted = self._safe_extract_zip(source)
                    candidates.extend(
                        p for p in extracted.rglob("*")
                        if p.is_file() and p.suffix.lower() in (".txt", ".log", ".csv")
                    )
                elif source.suffix.lower() in (".txt", ".log", ".csv"):
                    candidates.append(source)
                else:
                    errors.append(f"{source.name}: unsupported file type")
            except (zipfile.BadZipFile, OSError, ValueError) as exc:
                errors.append(f"{source.name}: {exc}")
        unique = sorted({p.resolve(): p for p in candidates}.values(), key=lambda p: str(p).lower())
        return unique, errors

    def load_inputs(self, inputs: List[Path]) -> None:
        for temp_dir in self._temp_dirs:
            shutil.rmtree(temp_dir, ignore_errors=True)
        self._temp_dirs.clear()
        paths, input_errors = self._collect_supported_files(inputs)
        self.load_paths(paths, input_errors)

    def load_paths(self, paths: List[Path], initial_errors: Optional[List[str]] = None):
        self.logs = []
        errors = list(initial_errors or [])
        for p in paths:
            try:
                self.logs.append(parse_log_file(p))
            except Exception as e:
                errors.append(f"{p.name}: {e}")
        self.file_combo.blockSignals(True)
        self.file_combo.clear()
        for log in self.logs:
            self.file_combo.addItem(log.path.name)
            row = self.file_combo.count() - 1
            self.file_combo.setItemData(row, str(log.path), Qt.ToolTipRole)
        self.file_combo.blockSignals(False)
        if self.logs:
            self.file_combo.setCurrentIndex(0)
            self.change_file(0)
        if errors:
            detail = "\n".join(errors[:12])
            more = "" if len(errors) <= 12 else f"\n... and {len(errors) - 12} more"
            self.statusBar().showMessage(f"Loaded {len(self.logs)} file(s). Skipped {len(errors)} non-WaterSystem/unsupported file(s).")
            if not self.logs:
                QMessageBox.warning(self, "No WaterSystem logs loaded", detail + more)
            elif len(errors) <= 5:
                QMessageBox.information(self, "Some files skipped", detail + more)

    def closeEvent(self, event: QCloseEvent) -> None:
        for temp_dir in self._temp_dirs:
            shutil.rmtree(temp_dir, ignore_errors=True)
        self._temp_dirs.clear()
        super().closeEvent(event)

    def change_file(self, idx: int):
        if idx < 0 or idx >= len(self.logs): return
        self.current_index = idx
        self.current_file_label.setText(self.logs[idx].path.name)
        self.current_file_label.setToolTip(str(self.logs[idx].path))
        self.chart.set_log(self.logs[idx])
        self.fill_event_table()

    def step_file(self, delta: int):
        if not self.logs: return
        idx = max(0, min(len(self.logs)-1, self.current_index + delta))
        self.file_combo.setCurrentIndex(idx)

    def change_x_axis_mode(self, text: str):
        self.chart.set_x_axis_mode(text)

    def update_sensor(self, key: str):
        self.chart.set_visible(key, self.checks[key].isChecked())

    def update_overlay(self):
        self.chart.set_overlay(self.cb_event_band.isChecked(), self.cb_event_label.isChecked(), self.cb_non_event_band.isChecked(), self.cb_non_event_label.isChecked())

    def toggle_all(self):
        on = self.cb_all.isChecked()
        for cb in self.checks.values(): cb.setChecked(on)
        for cb in [self.cb_event_band, self.cb_event_label, self.cb_non_event_band, self.cb_non_event_label]: cb.setChecked(on)

    def fill_event_table(self):
        log = self.logs[self.current_index]
        self.event_table.setRowCount(len(log.events))
        for r, ev in enumerate(log.events):
            m = ev.metrics
            vals = [ev.label, f"{ev.duration_min:.1f}", fmt_val(m.get("min_do")), fmt_min(m.get("to_min")), fmt_min(m.get("to_15")), fmt_min(m.get("to_10")), fmt_val(m.get("second_flow_avg")), str(m.get("vacuum_trend", "N/A"))]
            for c, val in enumerate(vals):
                item = QTableWidgetItem(val)
                if c == 6 and m.get("second_flow_avg") is not None and m.get("second_flow_avg") <= 2.5:
                    item.setForeground(QColor(200, 0, 0))
                self.event_table.setItem(r, c, item)
        if len(log.events) == 0:
            self.summary.setPlainText("No event results for this file.")
        else:
            self.summary.clear()

    def event_row_clicked(self, row: int, col: int):
        if self.current_index < 0: return
        events = self.logs[self.current_index].events
        if 0 <= row < len(events):
            self.select_event(events[row])

    def select_event(self, ev: Segment):
        if self.current_index < 0: return
        events = self.logs[self.current_index].events
        if ev in events:
            row = events.index(ev)
            self.event_table.selectRow(row)
        self.chart.zoom_to_segment(ev)
        m = ev.metrics
        self.summary.setPlainText(
            f"{ev.label}  {ev.kind}\n"
            f"Duration: {ev.duration_min:.1f} min | Min DO: {fmt_val(m.get('min_do'))} | To 1.5: {fmt_min(m.get('to_15'))} | To 1.0: {fmt_min(m.get('to_10'))}\n"
            f"2nd Flow Avg: {fmt_val(m.get('second_flow_avg'))} | Vacuum Trend: {m.get('vacuum_trend', 'N/A')}"
        )


def main():
    app = QApplication(sys.argv)
    pg.setConfigOptions(antialias=True)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
