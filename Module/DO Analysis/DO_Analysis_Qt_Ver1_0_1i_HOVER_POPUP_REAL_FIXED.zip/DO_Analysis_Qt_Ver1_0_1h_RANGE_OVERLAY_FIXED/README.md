DO Analysis Qt Ver1.0.1e Label Refresh Real Fix

Fixes:
- Event / Non-event labels are rebuilt after zoom, pan, Reset Zoom, and event jump.
- Labels are centered in the currently visible portion of each segment, not the original full segment.
- Overlay bands and labels are clipped to the visible X range.
- Overlay items are excluded from ViewBox bounds so Y-axis autoscale is not affected.
- Delayed overlay refresh runs after PyQtGraph finishes X/Y range updates.

Run:
  run_debug.bat

Build:
  build_exe.bat
