@echo off
setlocal
cd /d %~dp0

echo [1/4] Installing requirements...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo [2/4] Cleaning old build...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist main.build rmdir /s /q main.build
if exist main.dist rmdir /s /q main.dist
if exist main.onefile-build rmdir /s /q main.onefile-build

echo [3/4] Building EXE with Nuitka...
python -m nuitka ^
  --standalone ^
  --onefile ^
  --enable-plugin=pyside6 ^
  --windows-console-mode=disable ^
  --assume-yes-for-downloads ^
  --output-dir=dist ^
  --output-filename="DO Analysis Qt Ver1.0.1.exe" ^
  main.py

echo [4/4] Done.
echo EXE: dist\DO Analysis Qt Ver1.0.1.exe
pause
