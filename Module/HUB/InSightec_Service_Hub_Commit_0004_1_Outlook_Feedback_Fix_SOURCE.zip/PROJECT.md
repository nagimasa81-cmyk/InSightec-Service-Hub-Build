# Commit 0004.1

Focus: Outlook feedback draft reliability.

Validation:
1. Select Send Mode = outlook.
2. Click Create Feedback.
3. Confirm an editable Outlook mail draft opens.
4. Confirm recipient, subject, body and attachments are populated.
5. If Outlook is unavailable, confirm an error dialog offers the mail template.

# InSightec Service Hub

## Current Build
Commit 0003.7d - Python Build Launcher

## Build Flow

```text
01_BUILD_EXE.bat
    -> Build_Hub_EXE.py
        -> python -m PyInstaller (subprocess argument list)
```

The BAT is now only a thin Windows launcher. PyInstaller arguments are passed as a Python list, avoiding CMD quoting, delayed expansion, caret continuation, and GitHub Actions shell parsing problems.


## Commit 0003.7e
- Fixed persistent PyInstaller `scriptname required` failure by using the PyInstaller Python API directly.
- Removed command-line `--specpath` handling from the launcher.
- Uses the source filename from the detected source root and logs the exact argument list.
