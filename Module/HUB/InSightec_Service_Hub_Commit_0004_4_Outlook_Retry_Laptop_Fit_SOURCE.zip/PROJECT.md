# PROJECT

Current build: Commit 0004.4 Outlook Retry & Laptop Fit

Validation focus:
- Initial window fits laptop screen and Feedback action button remains accessible.
- Outlook mode prompts the user to start Outlook.
- OK rechecks Outlook up to three times.
- A running Outlook opens an editable draft.
- Three failed checks open the mail template.
