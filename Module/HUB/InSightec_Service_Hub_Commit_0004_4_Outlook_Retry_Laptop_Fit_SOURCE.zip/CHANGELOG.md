# CHANGELOG

## Commit 0004.4
- Added Outlook running check before COM draft creation.
- Added three user-confirmed retries when Outlook is not running.
- Falls back to the copyable mail template after the third failed check.
- Hides raw COM errors from the user and records details in logs.
- Adjusted initial window geometry and Feedback layout for laptop displays.
