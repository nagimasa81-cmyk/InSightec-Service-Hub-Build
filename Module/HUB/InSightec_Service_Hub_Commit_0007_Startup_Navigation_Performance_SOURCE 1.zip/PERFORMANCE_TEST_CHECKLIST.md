# Commit 0007 Performance Test Checklist

- [ ] Double-click EXE: first window appears faster than Commit 0006.
- [ ] Dashboard -> Tools -> Dashboard switching is responsive.
- [ ] Tools -> Feedback -> Settings switching is responsive.
- [ ] English -> Japanese -> English switching is faster and does not freeze.
- [ ] Tool cards and readiness status remain correct after background refresh.
- [ ] Validate Tools performs a fresh validation and creates a report.
- [ ] Refresh on Tools page performs a fresh module metadata scan.
- [ ] MRI Raw FFT Explore card remains visible.
- [ ] Feedback screen capture behavior is unchanged.
- [ ] No regression in updates, help, settings, or module launching.
