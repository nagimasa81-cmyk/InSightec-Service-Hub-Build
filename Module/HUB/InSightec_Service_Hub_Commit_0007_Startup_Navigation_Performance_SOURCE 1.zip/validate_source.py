from __future__ import annotations

import json
import py_compile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQUIRED_FILES = (
    "InSightecServiceHub.py",
    "config.json",
    "hub_manifest.json",
    "Build_Hub_EXE.py",
    "01_BUILD_EXE.bat",
)
REQUIRED_DIRS = ("language", "help", "tools", "plugins", "database", "updates")


def fail(message: str) -> None:
    print(f"[FAIL] {message}")
    raise SystemExit(1)


def main() -> int:
    print("=" * 68)
    print("InSightec Service Hub - Source Validation")
    print("=" * 68)

    for name in REQUIRED_FILES:
        path = ROOT / name
        if not path.is_file():
            fail(f"Required file missing: {name}")
        print(f"[PASS] {name}")

    for name in REQUIRED_DIRS:
        path = ROOT / name
        if not path.is_dir():
            fail(f"Required directory missing: {name}/")
        print(f"[PASS] {name}/")

    for json_path in (ROOT / "config.json", ROOT / "hub_manifest.json", ROOT / "language" / "version.json"):
        try:
            json.loads(json_path.read_text(encoding="utf-8"))
        except Exception as exc:
            fail(f"Invalid JSON: {json_path.name}: {exc}")
        print(f"[PASS] JSON: {json_path.relative_to(ROOT)}")

    language_files = sorted((ROOT / "language").glob("*.json"))
    if not language_files:
        fail("No language JSON files found.")
    for path in language_files:
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            fail(f"Invalid language JSON {path.name}: {exc}")
    print(f"[PASS] Language files: {len(language_files)}")

    try:
        py_compile.compile(str(ROOT / "InSightecServiceHub.py"), doraise=True)
        py_compile.compile(str(ROOT / "Build_Hub_EXE.py"), doraise=True)
    except py_compile.PyCompileError as exc:
        fail(f"Python syntax validation failed: {exc}")
    print("[PASS] Python syntax")

    manifests = list((ROOT / "tools").glob("*/manifest.json")) + list((ROOT / "plugins").glob("*/manifest.json"))
    for path in manifests:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            fail(f"Invalid module manifest {path}: {exc}")
        if not data.get("id"):
            fail(f"Module manifest has no id: {path}")
    print(f"[PASS] Module manifests: {len(manifests)}")

    print("=" * 68)
    print("Source validation SUCCESS")
    print("=" * 68)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
