@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PYTHON_EXE="
where python >nul 2>&1 && set "PYTHON_EXE=python"
if not defined PYTHON_EXE (
    where py >nul 2>&1 && set "PYTHON_EXE=py -3.13"
)
if not defined PYTHON_EXE (
    echo [FAIL] Python was not found.
    exit /b 1
)

%PYTHON_EXE% "%~dp0validate_source.py"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
    echo [FAIL] Source validation failed.
    if not defined CI pause
    exit /b %RC%
)

if not defined CI pause
exit /b 0
