# InSightec Service Hub

Build: Commit 0004.4b Consolidated Language and Stability Fix

Enabled languages: English, 日本語, 繁體中文, 한국어, Español.
All language changes are applied at runtime without restarting the Hub.
