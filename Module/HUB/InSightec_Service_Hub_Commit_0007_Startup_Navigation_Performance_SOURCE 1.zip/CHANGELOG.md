# Commit 0007 - Startup and Navigation Performance

## Improved
- The main window is displayed before expensive tool manifest and EXE version scanning.
- Tool metadata is cached and reused during Dashboard, Tools, Modules, and Feedback navigation.
- Tool validation results are cached; explicit Validate/Refresh actions force a rescan.
- Language JSON files are loaded once per language and reused.
- Language switching shows a busy cursor and avoids repeated disk reads.
- Existing MRI Raw FFT Explore integration and CI build stability changes are retained.

## Validation
- Python syntax check passed.
- JSON validation passed.
- Source validator passed.
- ZIP integrity check passed.

# Commit 0005 - CI Build Stability

- Added `validate_source.py` and `02_VALIDATE_SOURCE.bat`.
- Added `requirements-build.txt` for GitHub Actions and local builds.
- Improved build metadata and release packaging.
- Updated application version to 0.5.0.
- Removed cached Python bytecode from the source package.

# Changelog

## Commit 0004.4b — Consolidated Language and Stability Fix
- Enabled Korean as a selectable runtime language.
- Expanded English, Japanese, Traditional Chinese, Korean, and Spanish to the same UI key coverage.
- Added Korean quick-start help and Korean module metadata.
- Set Outlook as the initial feedback mode.
- Removed the duplicate capitalization variant of the main Python source.
- Synchronized config, language version, and hub manifest metadata.

## Commit 0006 - MRI Raw FFT Explore Integration (2026-07-13)

- Added MRI Raw FFT Explore to the Service Hub tool launcher.
- Added `tools/MRIRawFFTExplore/manifest.json`.
- Added multilingual tool name and description metadata.
- Added expected executable mapping: `MRI_Raw_FFT_Explorer.exe`.
- Updated Hub version to 0.6.0.
