# Commit 0004.2

Outlook integration packaging fix for PyInstaller.

## Build behavior
- `pythoncom` and `pywintypes` are verified in the build environment but are not passed as hidden imports.
- `win32com` and `win32com.client` remain included.
- `win32com` submodules are collected.
