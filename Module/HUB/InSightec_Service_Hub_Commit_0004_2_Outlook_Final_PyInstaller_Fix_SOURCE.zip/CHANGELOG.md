# Changelog

## Commit 0004.2 - Outlook PyInstaller Final Fix

### Fixed
- Removed `pythoncom` and `pywintypes` from PyInstaller hidden-import arguments.
- Avoided PyInstaller `Failed to retrieve attribute __file__ from module pythoncom` error.
- Kept `win32com` submodule collection for Classic Outlook draft integration.
- Retained build-time pywin32 import verification.

### Validation
- Build should complete without the `pythoncom.__file__` AttributeError.
- Outlook mode should open an editable Classic Outlook draft.
