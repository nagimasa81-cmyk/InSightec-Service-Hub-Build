# InSightec Service Hub

Build: Commit 0005 Pack 1 Feedback Foreground Fix

RC1 scope:
- Outlook feedback draft foreground activation
- Mail template foreground activation
- Five-language feedback messages
- Laptop-safe template sizing
- Existing Source ZIP → GitHub Actions → EXE workflow preserved
