# Changelog

## Commit 0005 Pack 1 Fix 1 — Tcl/Tk Runtime Packaging
- Fixed startup failure in Python 3.13 PyInstaller standalone builds.
- Explicitly packages `tcl8.6` and `tk8.6` runtime data.
- Added post-build validation that fails the build if Tcl/Tk data is missing.
- Preserved all Commit 0005 Pack 1 feedback foreground and five-language changes.

## Commit 0005 Pack 1 — Feedback Foreground Fix
- Brought newly-created Classic Outlook feedback drafts to the foreground.
- Brought the fallback mail template to the foreground and centered it on laptop displays.
- Added Escape/Close handling to the mail template.
- Added Korean Outlook startup and fallback prompts.
- Added five-language feedback status and mail-template text.
- Preserved the existing RC1 folder structure and GitHub/BAT build flow.

## Commit 0004.4b — Consolidated Language and Stability Fix
- Enabled Korean as a selectable runtime language.
- Expanded English, Japanese, Traditional Chinese, Korean, and Spanish to the same UI key coverage.
- Added Korean quick-start help and Korean module metadata.
- Set Outlook as the initial feedback mode.
- Removed the duplicate capitalization variant of the main Python source.
- Synchronized config, language version, and hub manifest metadata.
