# RC1 Test Checklist

## Core
- [ ] Hub starts
- [ ] Hub closes without error
- [ ] All configured tools still launch
- [ ] Tool versions remain visible

## Feedback
- [ ] Outlook draft opens in front
- [ ] Template opens in front
- [ ] Outlook startup prompt retries up to three times
- [ ] Korean Outlook prompt is displayed correctly
- [ ] Golden attachment is included

## Languages
- [ ] English
- [ ] 日本語
- [ ] 繁體中文
- [ ] 한국어
- [ ] Español

## Update
- [ ] Install Golden Update ZIP
- [ ] Backup created
- [ ] Staging created
- [ ] Restart completed
- [ ] Rollback completed
