# RC1 Expected Results

## Feedback - Outlook
- When Outlook is already open, Create Feedback opens an editable Outlook draft.
- The new draft is brought to the foreground.
- Recipient, subject, body, selected attachment, and recent logs are populated.

## Feedback - Outlook not running
- The Hub prompts the user up to three times to start Outlook.
- If Outlook starts before the third confirmation, the draft opens.
- If Outlook is still unavailable after the third confirmation, the mail template opens.

## Feedback - Template
- The mail template opens centered and in front of the Hub.
- Copy Template copies the complete body.
- Escape or Close dismisses the template.

## Golden Update ZIP
- A backup folder is created.
- A staged upgrade folder is created.
- The Hub restarts.
- hub_manifest.json reports version 0.5.0-rc1-pack1-eval.
- Rollback restores the previous hub_manifest.json.
