# InSightec Service Hub

## Current Build
Commit 0003.7d - Python Build Launcher

## Build Flow

```text
01_BUILD_EXE.bat
    -> Build_Hub_EXE.py
        -> python -m PyInstaller (subprocess argument list)
```

The BAT is now only a thin Windows launcher. PyInstaller arguments are passed as a Python list, avoiding CMD quoting, delayed expansion, caret continuation, and GitHub Actions shell parsing problems.
