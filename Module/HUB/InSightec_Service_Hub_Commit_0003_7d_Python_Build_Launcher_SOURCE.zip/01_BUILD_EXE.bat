@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ============================================================
echo InSightec Service Hub - Python Build Launcher
echo ============================================================

set "PYTHON_EXE="
where python >nul 2>&1 && set "PYTHON_EXE=python"
if not defined PYTHON_EXE (
    where py >nul 2>&1 && set "PYTHON_EXE=py -3.13"
)
if not defined PYTHON_EXE (
    echo [FAIL] Python was not found.
    exit /b 1
)

%PYTHON_EXE% "%~dp0Build_Hub_EXE.py"
set "BUILD_RC=%ERRORLEVEL%"

if not "%BUILD_RC%"=="0" (
    echo [FAIL] Build launcher returned exit code %BUILD_RC%.
    if not defined CI pause
    exit /b %BUILD_RC%
)

if not defined CI pause
exit /b 0
