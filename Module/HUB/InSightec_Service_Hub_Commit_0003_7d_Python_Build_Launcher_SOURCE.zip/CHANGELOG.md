# Changelog

## Commit 0003.7d - Python Build Launcher

### Fixed
- Replaced the multiline PyInstaller command in BAT with a Python subprocess launcher.
- Eliminated the recurring `PyInstaller: scriptname required` failure in GitHub Actions.
- Ensured the main script is always passed as the final subprocess argument.

### Added
- `Build_Hub_EXE.py` for local and GitHub Actions builds.
- Automatic source-root and main-script detection.
- Automatic PyInstaller dependency installation when needed.
- Runtime content copy with PASS/SKIP reporting.
- EXE SHA-256 and elapsed-time reporting.
