@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem ============================================================
rem InSightec Service Hub - Fast PyInstaller Build
rem Works locally and in GitHub Actions even when BAT is in work\
rem ============================================================

set "BAT_DIR=%~dp0"
cd /d "%BAT_DIR%"

set "APP_NAME=InSightecServiceHub"
set "SOURCE_DIR="
set "MAIN_SCRIPT="

rem ---- Find source root and main script ----
for %%D in ("%BAT_DIR%" "%BAT_DIR%.." "%BAT_DIR%..\.." "%BAT_DIR%..\..\..") do (
    if not defined MAIN_SCRIPT (
        if exist "%%~fD\InSightecServiceHub.py" (
            set "SOURCE_DIR=%%~fD"
            set "MAIN_SCRIPT=%%~fD\InSightecServiceHub.py"
        )
    )
    if not defined MAIN_SCRIPT (
        if exist "%%~fD\InSighTecServiceHub.py" (
            set "SOURCE_DIR=%%~fD"
            set "MAIN_SCRIPT=%%~fD\InSighTecServiceHub.py"
        )
    )
    if not defined MAIN_SCRIPT (
        if exist "%%~fD\main.py" (
            set "SOURCE_DIR=%%~fD"
            set "MAIN_SCRIPT=%%~fD\main.py"
        )
    )
)

if not defined MAIN_SCRIPT (
    echo [FAIL] Main Python file not found.
    echo Checked:
    echo   %BAT_DIR%
    echo   %BAT_DIR%..
    echo   %BAT_DIR%..\..
    echo   %BAT_DIR%..\..\..
    exit /b 1
)

cd /d "%SOURCE_DIR%"

set "DIST_ROOT=%SOURCE_DIR%\dist"
set "DIST_DIR=%DIST_ROOT%\%APP_NAME%"
set "BUILD_ROOT=%SOURCE_DIR%\build"
set "SPEC_ROOT=%SOURCE_DIR%"
set "BUILD_LOG_DIR=%SOURCE_DIR%\build_logs"

if not exist "%BUILD_LOG_DIR%" mkdir "%BUILD_LOG_DIR%" >nul 2>&1
if not exist "%DIST_ROOT%" mkdir "%DIST_ROOT%" >nul 2>&1
if not exist "%BUILD_ROOT%" mkdir "%BUILD_ROOT%" >nul 2>&1

for /f "tokens=1-4 delims=/ " %%a in ("%date%") do set "DATESTAMP=%%a%%b%%c"
set "TIMESTAMP=%TIME::=%"
set "TIMESTAMP=%TIMESTAMP:.=%"
set "TIMESTAMP=%TIMESTAMP: =0%"
set "BUILD_LOG=%BUILD_LOG_DIR%\build_%DATESTAMP%_%TIMESTAMP%.log"

set /a COPIED_COUNT=0
set /a SKIPPED_COUNT=0
set /a FAILED_COUNT=0

call :log "============================================================"
call :log "InSightec Service Hub - PyInstaller Build"
call :log "BAT_DIR=%BAT_DIR%"
call :log "SOURCE_DIR=%SOURCE_DIR%"
call :log "MAIN_SCRIPT=%MAIN_SCRIPT%"
call :log "============================================================"

echo ============================================================
echo InSightec Service Hub Build
echo ============================================================
echo Source : %SOURCE_DIR%
echo Main   : %MAIN_SCRIPT%
echo Output : %DIST_DIR%
echo.

rem ---- Resolve Python ----
set "PYTHON_CMD="
where py >nul 2>&1
if not errorlevel 1 (
    py -3.13 --version >nul 2>&1 && set "PYTHON_CMD=py -3.13"
)
if not defined PYTHON_CMD (
    where python >nul 2>&1 && set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD (
    echo [FAIL] Python not found.
    exit /b 1
)

echo [1/4] Python
%PYTHON_CMD% --version
if errorlevel 1 goto :build_failed

echo.
echo [2/4] PyInstaller
%PYTHON_CMD% -m pip install --disable-pip-version-check pyinstaller pywin32 >>"%BUILD_LOG%" 2>&1
if errorlevel 1 (
    call :fail "Failed to install PyInstaller or pywin32."
    goto :build_failed
)

rem ---- Build EXE ----
echo.
echo [3/4] Building EXE
call :log "Command: %PYTHON_CMD% -m PyInstaller --noconfirm --clean --windowed --name %APP_NAME% %MAIN_SCRIPT%"

rem Runtime folders are copied after the EXE build.
rem Keeping --add-data out of this command avoids CMD quoting issues in GitHub Actions.
%PYTHON_CMD% -m PyInstaller --noconfirm --clean --windowed ^
  --name "%APP_NAME%" ^
  --distpath "%DIST_ROOT%" ^
  --workpath "%BUILD_ROOT%" ^
  --specpath "%SPEC_ROOT%" ^
  "%MAIN_SCRIPT%" >>"%BUILD_LOG%" 2>&1

if errorlevel 1 (
    call :fail "PyInstaller build failed. See %BUILD_LOG%."
    goto :build_failed
)

if not exist "%DIST_DIR%\%APP_NAME%.exe" (
    call :fail "Built EXE was not found: %DIST_DIR%\%APP_NAME%.exe"
    goto :build_failed
)

echo.
echo [4/4] Copying runtime content
call :copy_file "config.json" "%DIST_DIR%\config.json" "config.json"
call :copy_file "hub_manifest.json" "%DIST_DIR%\hub_manifest.json" "hub_manifest.json"
call :copy_file "README.txt" "%DIST_DIR%\README.txt" "README.txt"
call :copy_file "VERSION_HISTORY.txt" "%DIST_DIR%\VERSION_HISTORY.txt" "VERSION_HISTORY.txt"
call :copy_file "TOOLS_INSTALL_README.txt" "%DIST_DIR%\TOOLS_INSTALL_README.txt" "TOOLS_INSTALL_README.txt"
call :copy_file "MODULE_MANAGER_README.txt" "%DIST_DIR%\MODULE_MANAGER_README.txt" "MODULE_MANAGER_README.txt"

call :copy_dir "tools" "%DIST_DIR%\tools" "tools"
call :copy_dir "plugins" "%DIST_DIR%\plugins" "plugins"
call :copy_dir "database" "%DIST_DIR%\database" "database"
call :copy_dir "language" "%DIST_DIR%\language" "language"
call :copy_dir "help" "%DIST_DIR%\help" "help"
call :copy_dir "updates" "%DIST_DIR%\updates" "updates"
call :copy_dir "resources" "%DIST_DIR%\resources" "resources"
call :copy_dir "icons" "%DIST_DIR%\icons" "icons"

if %FAILED_COUNT% GTR 0 goto :build_failed

echo.
echo ============================================================
echo Build SUCCESS
echo ============================================================
echo EXE     : %DIST_DIR%\%APP_NAME%.exe
echo Copied  : %COPIED_COUNT%
echo Skipped : %SKIPPED_COUNT%
echo Log     : %BUILD_LOG%
echo ============================================================
call :log "Build SUCCESS. Copied=%COPIED_COUNT%, Skipped=%SKIPPED_COUNT%"
if not defined CI pause
exit /b 0

:copy_dir
set "SRC=%SOURCE_DIR%\%~1"
set "DST=%~2"
set "LABEL=%~3"
if not exist "%SRC%\" (
    echo [SKIP] %LABEL%
    call :log "[SKIP] %LABEL%"
    set /a SKIPPED_COUNT+=1
    exit /b 0
)
if not exist "%DST%" mkdir "%DST%" >nul 2>&1
robocopy "%SRC%" "%DST%" /E /NFL /NDL /NJH /NJS /NP >>"%BUILD_LOG%" 2>&1
set "RC=!ERRORLEVEL!"
if !RC! GEQ 8 (
    echo [FAIL] %LABEL% - ROBOCOPY exit code !RC!
    call :log "[FAIL] %LABEL% - ROBOCOPY exit code !RC!"
    set /a FAILED_COUNT+=1
) else (
    echo [PASS] %LABEL%
    call :log "[PASS] %LABEL%"
    set /a COPIED_COUNT+=1
)
exit /b 0

:copy_file
set "SRC=%SOURCE_DIR%\%~1"
set "DST=%~2"
set "LABEL=%~3"
if not exist "%SRC%" (
    echo [SKIP] %LABEL%
    call :log "[SKIP] %LABEL%"
    set /a SKIPPED_COUNT+=1
    exit /b 0
)
copy /Y "%SRC%" "%DST%" >>"%BUILD_LOG%" 2>&1
if errorlevel 1 (
    echo [FAIL] %LABEL%
    call :log "[FAIL] %LABEL%"
    set /a FAILED_COUNT+=1
) else (
    echo [PASS] %LABEL%
    call :log "[PASS] %LABEL%"
    set /a COPIED_COUNT+=1
)
exit /b 0

:log
>>"%BUILD_LOG%" echo [%DATE% %TIME%] %~1
exit /b 0

:fail
set /a FAILED_COUNT+=1
echo [FAIL] %~1
call :log "[FAIL] %~1"
exit /b 0

:build_failed
echo.
echo ============================================================
echo Build FAILED
echo ============================================================
echo Source : %SOURCE_DIR%
echo Main   : %MAIN_SCRIPT%
echo Log    : %BUILD_LOG%
echo ============================================================
if exist "%BUILD_LOG%" type "%BUILD_LOG%"
if not defined CI pause
exit /b 1
