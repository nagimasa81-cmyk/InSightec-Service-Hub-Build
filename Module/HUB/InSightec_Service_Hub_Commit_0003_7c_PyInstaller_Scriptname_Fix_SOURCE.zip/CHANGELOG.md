# CHANGELOG

## Commit 0003.7 - Module Lifecycle Management
- Added Modules page in Developer Mode.
- Added Version Manager for module manifest.json.
- Added Package Builder to generate module update ZIP files.
- Added module channel metadata: stable / beta / feu / internal.
- Added version history display.
- Expanded language strings for English, Japanese, Traditional Chinese and Spanish.

## Commit 0003.7a - Build BAT Resilience Fix
- Optional runtime folders are now checked before copy.
- Missing `resources`, `icons`, `help`, `language`, or `updates` no longer fail the build.
- `build_logs` is created automatically.
- Added explicit PyInstaller error handling and EXE existence verification.
- Added readable PASS / SKIP / FAIL output and final Build Summary.
- CI builds now return an explicit success or failure exit code and do not pause.

## Commit 0003.7b
- Replaced Hub PyInstaller BAT with a GitHub Actions-safe relative-path build script.
- Added preferred `01_BUILD_EXE.bat` entry point for the selected-module workflow.
- Added automatic source detection, build/dist/log directory creation, and optional runtime-folder copy handling.


## Commit 0003.7c
- Fixed GitHub Actions PyInstaller invocation where dynamic `--add-data` quoting removed the script name.
- Runtime folders are copied after the EXE build instead of being embedded.
