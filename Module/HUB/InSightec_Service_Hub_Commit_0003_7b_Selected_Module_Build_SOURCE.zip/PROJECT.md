# PROJECT

Current Build: Commit 0003.7 Module Lifecycle

Status: FEU validation build

Focus:
- Module Manager
- Version Manager
- Package Builder
- Update Channels

### Commit 0003.7a
Build pipeline hotfix: optional runtime directories are skipped safely, build logs are created automatically, and GitHub Actions receives reliable exit codes.

## Build integration (Commit 0003.7b)
The Hub source package includes `01_BUILD_EXE.bat` as the preferred GitHub Actions build entry point. It resolves the source directory from its own location, builds `InSightecServiceHub.py`, and creates `dist/InSightecServiceHub/` for standalone packaging.
