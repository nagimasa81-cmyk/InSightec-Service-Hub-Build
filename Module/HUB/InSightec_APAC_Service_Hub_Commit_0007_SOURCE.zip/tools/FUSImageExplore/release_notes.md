# FUS Image Explore 1.0.0

- Added to InSightec APAC Service Hub tool launcher.
- Expected executable: `MRI_Raw_FFT_Explorer.exe`.
- Supports DICOM/raw FFT visualization and MRI image reconstruction workflows.
