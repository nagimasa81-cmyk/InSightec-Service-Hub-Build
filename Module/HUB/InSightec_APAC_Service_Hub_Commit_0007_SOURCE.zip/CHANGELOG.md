# Changelog

## Commit 0007 - APAC Naming and Tool Consolidation (2026-07-25)

- Renamed the application to InSightec APAC Service Hub.
- Removed the obsolete duplicate DO analysis module and standardized the remaining module as DO Analysis.
- Standardized the tool folder as `tools/DOanalysis`.
- Renamed the MRI image analysis module and folder to FUS Image Explore / `tools/FUSImageExplore`.
- Updated English, Japanese, Spanish, Traditional Chinese, and Korean tool metadata.
- Retained GitHub/PyInstaller build BAT files and source validation.

# Commit 0005 - CI Build Stability

- Added `validate_source.py` and `02_VALIDATE_SOURCE.bat`.
- Added `requirements-build.txt` for GitHub Actions and local builds.
- Improved build metadata and release packaging.
- Updated application version to 0.5.0.
- Removed cached Python bytecode from the source package.

# Changelog

## Commit 0004.4b — Consolidated Language and Stability Fix
- Enabled Korean as a selectable runtime language.
- Expanded English, Japanese, Traditional Chinese, Korean, and Spanish to the same UI key coverage.
- Added Korean quick-start help and Korean module metadata.
- Set Outlook as the initial feedback mode.
- Removed the duplicate capitalization variant of the main Python source.
- Synchronized config, language version, and hub manifest metadata.

## Commit 0006 - FUS Image Explore Integration (2026-07-13)

- Added FUS Image Explore to the Service Hub tool launcher.
- Added `tools/FUSImageExplore/manifest.json`.
- Added multilingual tool name and description metadata.
- Added expected executable mapping: `MRI_Raw_FFT_Explorer.exe`.
- Updated Hub version to 0.6.0.
