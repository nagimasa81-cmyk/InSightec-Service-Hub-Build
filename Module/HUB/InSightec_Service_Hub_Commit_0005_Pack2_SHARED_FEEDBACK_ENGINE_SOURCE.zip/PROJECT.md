# InSightec Service Hub

Current release: Commit 0005 Pack 1 FIX2 Performance

Baseline: Commit 0004.4b

RC1 focus:
- Startup performance
- Runtime language switching performance
- Feedback foreground behavior
- Tcl/Tk runtime packaging stability
- Foundation and existing build flow preservation
