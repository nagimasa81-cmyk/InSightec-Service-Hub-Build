Tool installation locations

- tools\DOAnalysis\DO Analysis Qt Ver1.0.1.exe
- tools\FUSImageExplore\FUS Image Explore.exe
- tools\LogExplorer\LogMergeTool_NoExcel.exe
- tools\TrackerSNR\TrackerSNR_CLEAN_EXE.exe
- tools\VIMeasure\VIMeasureAnalyzer.exe

Use only the consolidated tools\DOAnalysis location for DO analysis.
