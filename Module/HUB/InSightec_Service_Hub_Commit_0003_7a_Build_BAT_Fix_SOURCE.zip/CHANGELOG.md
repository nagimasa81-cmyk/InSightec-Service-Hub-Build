# CHANGELOG

## Commit 0003.7 - Module Lifecycle Management
- Added Modules page in Developer Mode.
- Added Version Manager for module manifest.json.
- Added Package Builder to generate module update ZIP files.
- Added module channel metadata: stable / beta / feu / internal.
- Added version history display.
- Expanded language strings for English, Japanese, Traditional Chinese and Spanish.

## Commit 0003.7a - Build BAT Resilience Fix
- Optional runtime folders are now checked before copy.
- Missing `resources`, `icons`, `help`, `language`, or `updates` no longer fail the build.
- `build_logs` is created automatically.
- Added explicit PyInstaller error handling and EXE existence verification.
- Added readable PASS / SKIP / FAIL output and final Build Summary.
- CI builds now return an explicit success or failure exit code and do not pause.
