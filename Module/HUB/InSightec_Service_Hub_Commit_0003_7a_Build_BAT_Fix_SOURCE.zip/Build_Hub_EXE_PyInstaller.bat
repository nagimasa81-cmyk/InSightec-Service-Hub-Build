@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "APP_NAME=InSightecServiceHub"
set "DIST_DIR=dist\%APP_NAME%"
set "BUILD_LOG_DIR=build_logs"
set "BUILD_LOG=%BUILD_LOG_DIR%\build_%DATE:~0,4%%DATE:~5,2%%DATE:~8,2%_%TIME:~0,2%%TIME:~3,2%%TIME:~6,2%.log"
set "BUILD_LOG=%BUILD_LOG: =0%"
set /a COPIED_COUNT=0
set /a SKIPPED_COUNT=0
set /a FAILED_COUNT=0

if not exist "%BUILD_LOG_DIR%" mkdir "%BUILD_LOG_DIR%" >nul 2>&1

call :log "============================================================"
call :log "InSightec Service Hub - PyInstaller Build"
call :log "Source: %CD%"
call :log "============================================================"

echo.
echo [1/4] Checking Python...
where python >nul 2>&1
if errorlevel 1 (
    call :fail "Python was not found in PATH."
    goto :build_failed
)
for /f "delims=" %%V in ('python --version 2^>^&1') do call :log "%%V"

echo.
echo [2/4] Installing build dependencies...
python -m pip install --disable-pip-version-check pyinstaller pywin32 >>"%BUILD_LOG%" 2>&1
if errorlevel 1 (
    call :fail "Failed to install PyInstaller or pywin32."
    goto :build_failed
)

echo.
echo [3/4] Building EXE...
set "PYI_DATA_ARGS=--add-data config.json;."
if exist "language\" set "PYI_DATA_ARGS=!PYI_DATA_ARGS! --add-data language;language"
if exist "help\" set "PYI_DATA_ARGS=!PYI_DATA_ARGS! --add-data help;help"
if exist "resources\" set "PYI_DATA_ARGS=!PYI_DATA_ARGS! --add-data resources;resources"

pyinstaller --noconfirm --clean --windowed --name "%APP_NAME%" !PYI_DATA_ARGS! InSightecServiceHub.py >>"%BUILD_LOG%" 2>&1
if errorlevel 1 (
    call :fail "PyInstaller build failed. See %BUILD_LOG%."
    goto :build_failed
)

if not exist "%DIST_DIR%\%APP_NAME%.exe" (
    call :fail "Built EXE was not found: %DIST_DIR%\%APP_NAME%.exe"
    goto :build_failed
)

echo.
echo [4/4] Copying runtime content...
call :copy_file "config.json" "%DIST_DIR%\config.json" "config.json"
call :copy_file "hub_manifest.json" "%DIST_DIR%\hub_manifest.json" "hub_manifest.json"
call :copy_file "README.txt" "%DIST_DIR%\README.txt" "README.txt"
call :copy_file "VERSION_HISTORY.txt" "%DIST_DIR%\VERSION_HISTORY.txt" "VERSION_HISTORY.txt"
call :copy_file "TOOLS_INSTALL_README.txt" "%DIST_DIR%\TOOLS_INSTALL_README.txt" "TOOLS_INSTALL_README.txt"
call :copy_file "MODULE_MANAGER_README.txt" "%DIST_DIR%\MODULE_MANAGER_README.txt" "MODULE_MANAGER_README.txt"

call :copy_dir "tools" "%DIST_DIR%\tools" "tools"
call :copy_dir "plugins" "%DIST_DIR%\plugins" "plugins"
call :copy_dir "database" "%DIST_DIR%\database" "database"
call :copy_dir "language" "%DIST_DIR%\language" "language"
call :copy_dir "help" "%DIST_DIR%\help" "help"
call :copy_dir "updates" "%DIST_DIR%\updates" "updates"
call :copy_dir "resources" "%DIST_DIR%\resources" "resources"
call :copy_dir "icons" "%DIST_DIR%\icons" "icons"

if %FAILED_COUNT% GTR 0 goto :build_failed

echo.
echo ============================================================
echo Build Summary
echo ============================================================
echo EXE      : PASS
if %COPIED_COUNT% GTR 0 echo Copied   : %COPIED_COUNT%
if %SKIPPED_COUNT% GTR 0 echo Skipped  : %SKIPPED_COUNT% optional item(s)
echo Failed   : %FAILED_COUNT%
echo Output   : %CD%\%DIST_DIR%
echo Log      : %CD%\%BUILD_LOG%
echo ============================================================
echo Build SUCCESS
call :log "Build SUCCESS. Copied=%COPIED_COUNT%, Skipped=%SKIPPED_COUNT%, Failed=%FAILED_COUNT%"

if not defined CI pause
exit /b 0

:copy_dir
set "SRC=%~1"
set "DST=%~2"
set "LABEL=%~3"
if not exist "%SRC%\" (
    echo [SKIP] %LABEL% - folder not found
    call :log "[SKIP] %LABEL% - folder not found"
    set /a SKIPPED_COUNT+=1
    exit /b 0
)
if not exist "%DST%" mkdir "%DST%" >nul 2>&1
rem XCOPY exit code 0 or 1 is acceptable; 2 or higher is a real failure.
xcopy "%SRC%\*" "%DST%\" /E /I /Y /Q >>"%BUILD_LOG%" 2>&1
set "RC=!ERRORLEVEL!"
if !RC! GEQ 2 (
    echo [FAIL] %LABEL% - XCOPY exit code !RC!
    call :log "[FAIL] %LABEL% - XCOPY exit code !RC!"
    set /a FAILED_COUNT+=1
    exit /b 0
)
echo [PASS] %LABEL% copied
call :log "[PASS] %LABEL% copied"
set /a COPIED_COUNT+=1
exit /b 0

:copy_file
set "SRC=%~1"
set "DST=%~2"
set "LABEL=%~3"
if not exist "%SRC%" (
    echo [SKIP] %LABEL% - file not found
    call :log "[SKIP] %LABEL% - file not found"
    set /a SKIPPED_COUNT+=1
    exit /b 0
)
copy /Y "%SRC%" "%DST%" >>"%BUILD_LOG%" 2>&1
if errorlevel 1 (
    echo [FAIL] %LABEL% - copy failed
    call :log "[FAIL] %LABEL% - copy failed"
    set /a FAILED_COUNT+=1
    exit /b 0
)
echo [PASS] %LABEL% copied
call :log "[PASS] %LABEL% copied"
set /a COPIED_COUNT+=1
exit /b 0

:log
>>"%BUILD_LOG%" echo [%DATE% %TIME%] %~1
exit /b 0

:fail
set /a FAILED_COUNT+=1
echo [FAIL] %~1
call :log "[FAIL] %~1"
exit /b 0

:build_failed
echo.
echo ============================================================
echo Build Summary
echo ============================================================
echo EXE      : FAIL
if %COPIED_COUNT% GTR 0 echo Copied   : %COPIED_COUNT%
if %SKIPPED_COUNT% GTR 0 echo Skipped  : %SKIPPED_COUNT% optional item(s)
echo Failed   : %FAILED_COUNT%
echo Log      : %CD%\%BUILD_LOG%
echo ============================================================
echo Build FAILED
call :log "Build FAILED. Copied=%COPIED_COUNT%, Skipped=%SKIPPED_COUNT%, Failed=%FAILED_COUNT%"
if not defined CI pause
exit /b 1
