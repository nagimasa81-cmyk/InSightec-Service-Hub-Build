# InSightec Service Hub

Current build: Commit 0004.3 Outlook COM Fix

Validation targets:
- GitHub Actions build succeeds on Python 3.13
- Outlook mode opens an editable Classic Outlook draft
- Recipient, subject, body, and attachments are populated
- Template fallback remains available
