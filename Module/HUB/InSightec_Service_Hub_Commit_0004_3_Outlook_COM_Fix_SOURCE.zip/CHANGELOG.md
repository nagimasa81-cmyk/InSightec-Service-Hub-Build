# Changelog

## Commit 0004.3
- Replaced pywin32 Outlook automation with comtypes.
- Removed pythoncom/pywintypes PyInstaller hook dependency.
- Added reliable Classic Outlook draft creation with attachments.
- Added Outlook failure fallback to the copyable mail template.
- Updated build dependency checks for Python 3.13.
