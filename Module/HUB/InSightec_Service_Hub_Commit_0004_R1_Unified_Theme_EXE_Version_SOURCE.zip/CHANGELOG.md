# Commit 0004 R1

- Unified Hub colors, header, navigation, spacing, and base control sizing with the other service tools.
- Module version is now read from the Windows EXE ProductVersion/FileVersion when available.
- manifest.json remains the fallback and retains display name, description, build, and compatibility metadata.
- Tool cards and Information show the version source and manifest version for validation.

# Changelog

## Commit 0003.7d - Python Build Launcher

### Fixed
- Replaced the multiline PyInstaller command in BAT with a Python subprocess launcher.
- Eliminated the recurring `PyInstaller: scriptname required` failure in GitHub Actions.
- Ensured the main script is always passed as the final subprocess argument.

### Added
- `Build_Hub_EXE.py` for local and GitHub Actions builds.
- Automatic source-root and main-script detection.
- Automatic PyInstaller dependency installation when needed.
- Runtime content copy with PASS/SKIP reporting.
- EXE SHA-256 and elapsed-time reporting.


## Commit 0003.7e
- Fixed persistent PyInstaller `scriptname required` failure by using the PyInstaller Python API directly.
- Removed command-line `--specpath` handling from the launcher.
- Uses the source filename from the detected source root and logs the exact argument list.
