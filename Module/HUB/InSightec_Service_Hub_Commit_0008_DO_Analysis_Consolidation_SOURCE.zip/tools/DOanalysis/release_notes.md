# DO Analysis 1.0.1

- The Service Hub now contains one standardized **DO Analysis** tool entry.
- Tool ID: `do_analysis`
- Tool folder: `tools/DOanalysis`
- Display names are unified in English, Japanese, Spanish, Traditional Chinese, and Korean.
