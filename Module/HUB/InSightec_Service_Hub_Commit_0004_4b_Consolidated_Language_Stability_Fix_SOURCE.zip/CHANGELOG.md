# Changelog

## Commit 0004.4b — Consolidated Language and Stability Fix
- Enabled Korean as a selectable runtime language.
- Expanded English, Japanese, Traditional Chinese, Korean, and Spanish to the same UI key coverage.
- Added Korean quick-start help and Korean module metadata.
- Set Outlook as the initial feedback mode.
- Removed the duplicate capitalization variant of the main Python source.
- Synchronized config, language version, and hub manifest metadata.
