# builder/builder_gui.py
# InSightec Service Hub - Dedicated Builder GUI v0.2

from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from builder.build_core import BuildCore


class BuildWorker(QThread):
    log_signal = Signal(str)
    done_signal = Signal(bool, str)

    def __init__(self, action: str, project_root: Path, selected_modules: list[dict], debug: bool, create_zip: bool) -> None:
        super().__init__()
        self.action = action
        self.project_root = project_root
        self.selected_modules = selected_modules
        self.debug = debug
        self.create_zip = create_zip

    def run(self) -> None:
        core = BuildCore(self.project_root, log_callback=self.log_signal.emit)
        try:
            if self.action == "platform":
                result = core.build_platform(debug=self.debug, create_zip=self.create_zip)
                self.done_signal.emit(result.ok, result.message)
                return

            if self.action == "selected":
                if not self.selected_modules:
                    self.done_signal.emit(False, "No module selected.")
                    return
                ok = True
                for manifest in self.selected_modules:
                    result = core.build_module(manifest, debug=self.debug, create_zip=self.create_zip)
                    ok = ok and result.ok
                self.done_signal.emit(ok, "Selected module build completed." if ok else "Selected module build failed.")
                return

            if self.action == "all":
                results = core.build_all_modules(debug=self.debug, create_zip=self.create_zip)
                ok = all(item.ok for item in results)
                self.done_signal.emit(ok, "All module build completed." if ok else "All module build failed.")
                return

            if self.action == "clean":
                core.clean()
                self.done_signal.emit(True, "Clean completed.")
                return

            if self.action == "validate":
                result = core.validate()
                self.done_signal.emit(bool(result.get("ok")), "Validation OK." if result.get("ok") else "Validation failed.")
                return

        except Exception as exc:
            self.done_signal.emit(False, str(exc))


class ServiceHubBuilderGui(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.project_root = Path(__file__).resolve().parents[1]
        self.core = BuildCore(self.project_root, log_callback=self.append_log)
        self.modules: list[dict] = []
        self.worker: BuildWorker | None = None

        self.setWindowTitle("InSightec Service Hub Builder v0.2")
        self.resize(980, 720)

        self._build_ui()
        self.scan_modules()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)

        title = QLabel("InSightec Service Hub Builder v0.2")
        title.setObjectName("BuilderTitle")
        layout.addWidget(title)

        self.project_label = QLabel(f"Project: {self.project_root}")
        layout.addWidget(self.project_label)

        body = QHBoxLayout()

        module_box = QGroupBox("Modules")
        module_layout = QVBoxLayout(module_box)
        self.module_list = QListWidget()
        module_layout.addWidget(self.module_list)

        option_box = QGroupBox("Options")
        option_layout = QVBoxLayout(option_box)
        self.debug_check = QCheckBox("Debug build / console visible")
        self.zip_check = QCheckBox("Create release ZIP")
        self.zip_check.setChecked(True)
        option_layout.addWidget(self.debug_check)
        option_layout.addWidget(self.zip_check)
        option_layout.addStretch()

        body.addWidget(module_box, 3)
        body.addWidget(option_box, 2)
        layout.addLayout(body)

        button_row = QHBoxLayout()

        scan_btn = QPushButton("Scan Modules")
        scan_btn.clicked.connect(self.scan_modules)
        validate_btn = QPushButton("Validate")
        validate_btn.clicked.connect(lambda: self.start_action("validate"))
        build_platform_btn = QPushButton("Build Platform")
        build_platform_btn.clicked.connect(lambda: self.start_action("platform"))
        build_selected_btn = QPushButton("Build Selected")
        build_selected_btn.clicked.connect(lambda: self.start_action("selected"))
        build_all_btn = QPushButton("Build All Modules")
        build_all_btn.clicked.connect(lambda: self.start_action("all"))
        clean_btn = QPushButton("Clean")
        clean_btn.clicked.connect(lambda: self.start_action("clean"))

        for button in [scan_btn, validate_btn, build_platform_btn, build_selected_btn, build_all_btn, clean_btn]:
            button_row.addWidget(button)

        layout.addLayout(button_row)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(QLabel("Build Log"))
        layout.addWidget(self.log)

    def append_log(self, message: str) -> None:
        self.log.append(message)

    def scan_modules(self) -> None:
        self.module_list.clear()
        self.modules = self.core.discover_modules()
        for manifest in self.modules:
            label = (
                f"{manifest.get('module_name', manifest.get('module_id'))} "
                f"v{manifest.get('version', '-')} "
                f"({'enabled' if manifest.get('enabled', True) else 'disabled'})"
            )
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, manifest)
            item.setCheckState(Qt.Checked if manifest.get("enabled", True) and not manifest.get("error") else Qt.Unchecked)
            if manifest.get("error"):
                item.setToolTip(manifest["error"])
            self.module_list.addItem(item)
        self.append_log("Module scan completed.")

    def selected_modules(self) -> list[dict]:
        selected: list[dict] = []
        for index in range(self.module_list.count()):
            item = self.module_list.item(index)
            if item.checkState() == Qt.Checked:
                selected.append(item.data(Qt.UserRole))
        return selected

    def start_action(self, action: str) -> None:
        if self.worker and self.worker.isRunning():
            QMessageBox.warning(self, "Busy", "Build is already running.")
            return

        self.append_log(f"Starting action: {action}")
        self.worker = BuildWorker(
            action=action,
            project_root=self.project_root,
            selected_modules=self.selected_modules(),
            debug=self.debug_check.isChecked(),
            create_zip=self.zip_check.isChecked(),
        )
        self.worker.log_signal.connect(self.append_log)
        self.worker.done_signal.connect(self.on_done)
        self.worker.start()

    def on_done(self, ok: bool, message: str) -> None:
        self.append_log(message)
        QMessageBox.information(self, "Completed" if ok else "Failed", message)


def main() -> None:
    app = QApplication(sys.argv)
    window = ServiceHubBuilderGui()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
