# builder/build_core.py
# InSightec Service Hub - Dedicated Builder Core v0.1

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import textwrap
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

from builder.manifest_manager import ManifestManager
from builder.package_manager import PackageManager
from builder.validator import BuilderValidator
from builder.environment_manager import BuildEnvironmentManager

LogCallback = Callable[[str], None]


@dataclass
class BuildResult:
    ok: bool
    target: str
    mode: str
    output_path: Optional[Path]
    log_path: Path
    elapsed_seconds: float
    message: str


class BuildCore:
    def __init__(self, project_root: str | Path | None = None, log_callback: LogCallback | None = None) -> None:
        self.project_root = Path(project_root or Path.cwd()).resolve()
        self.log_callback = log_callback
        self.manifests = ManifestManager(self.project_root)
        self.packages = PackageManager(self.project_root)
        self.validator = BuilderValidator(self.project_root)
        self.build_root = self.project_root / "build"
        self.temp_root = self.project_root / "temp_build"
        self.log_root = self.project_root / "build_logs"
        self.release_root = self.project_root / "release"
        for path in [self.build_root, self.temp_root, self.log_root, self.release_root]:
            path.mkdir(parents=True, exist_ok=True)

    def log(self, message: str) -> None:
        line = f"[{datetime.now().strftime('%H:%M:%S')}] {message}"
        if self.log_callback:
            self.log_callback(line)
        else:
            print(line)

    def discover_modules(self) -> list[dict[str, Any]]:
        modules = self.manifests.discover_modules()
        self.log(f"Discovered {len(modules)} module(s).")
        return modules

    def validate(self) -> dict[str, Any]:
        modules = self.discover_modules()
        result = self.validator.validate_project(modules)
        self.log("Validation OK." if result["ok"] else "Validation failed.")
        return result

    def clean(self) -> list[Path]:
        removed = self.packages.clean_paths(["build", "build_debug", "temp_build", "release"])
        for path in [self.build_root, self.temp_root, self.log_root, self.release_root]:
            path.mkdir(parents=True, exist_ok=True)
        for path in removed:
            self.log(f"Removed: {path}")
        return removed

    def build_platform(self, debug: bool = False, create_zip: bool = True) -> BuildResult:
        return self._build_entry(
            target_name="ServiceHubPlatform",
            entry_script=self.project_root / "run_service_hub.py",
            debug=debug,
            create_zip=create_zip,
            include_project_dirs=True,
        )

    def build_module(self, manifest: dict[str, Any], debug: bool = False, create_zip: bool = True) -> BuildResult:
        module_id = manifest.get("module_id") or manifest.get("module_name") or "module"
        module_name = manifest.get("module_name") or module_id
        runner_path = self._create_module_runner(manifest)
        safe_target = self._safe_name(f"{module_id}_{manifest.get('version', '0.0.0')}")
        self.log(f"Building module: {module_name}")
        return self._build_entry(
            target_name=safe_target,
            entry_script=runner_path,
            debug=debug,
            create_zip=create_zip,
            include_project_dirs=True,
        )

    def build_all_modules(self, debug: bool = False, create_zip: bool = True) -> list[BuildResult]:
        results: list[BuildResult] = []
        for manifest in self.discover_modules():
            if manifest.get("enabled", True) and not manifest.get("error"):
                results.append(self.build_module(manifest, debug=debug, create_zip=create_zip))
        return results

    def _build_entry(
        self,
        target_name: str,
        entry_script: Path,
        debug: bool,
        create_zip: bool,
        include_project_dirs: bool,
    ) -> BuildResult:
        start = time.time()
        mode = "debug" if debug else "release"
        safe_target = self._safe_name(target_name)
        log_path = self.log_root / f"{safe_target}_{mode}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        output_dir = self.project_root / ("build_debug" if debug else "build")
        output_dir.mkdir(parents=True, exist_ok=True)

        environment = BuildEnvironmentManager(self.log).prepare()

        cmd = [
            str(environment.python_executable),
            "-m",
            "nuitka",
            "--assume-yes-for-downloads",
            "--standalone",
            "--onefile",
            "--enable-plugin=pyside6",
            f"--output-dir={output_dir}",
            f"--output-filename={safe_target}.exe",
            "--windows-console-mode=force" if debug else "--windows-console-mode=disable",
        ]

        if include_project_dirs:
            # Python packages are included as packages, not as data folders.
            # This is required for modules loaded dynamically from manifest.json.
            for package in ["app", "core", "modules"]:
                package_path = self.project_root / package
                if package_path.exists():
                    cmd.append(f"--include-package={package}")
                    cmd.append(f"--include-package-data={package}")

            # Runtime content folders remain normal data directories.
            for folder in ["config", "data"]:
                folder_path = self.project_root / folder
                if folder_path.exists() and any(folder_path.rglob("*")):
                    cmd.append(f"--include-data-dir={folder_path}={folder}")

        icon_path = self.project_root / "resources" / "icon.ico"
        if icon_path.exists():
            cmd.append(f"--windows-icon-from-ico={icon_path}")

        cmd.append(str(entry_script))

        self.log(f"Nuitka command: {' '.join(cmd)}")

        with log_path.open("w", encoding="utf-8") as log_file:
            log_file.write(" ".join(cmd) + "\n\n")
            try:
                process_env = os.environ.copy()
                process_env["NUITKA_ASSUME_YES_FOR_DOWNLOADS"] = "yes"
                process = subprocess.run(
                    cmd,
                    cwd=self.project_root,
                    env=process_env,
                    text=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    check=False,
                )
                log_file.write(process.stdout or "")
                ok = process.returncode == 0
            except Exception as exc:
                log_file.write(str(exc))
                ok = False

        elapsed = round(time.time() - start, 2)
        exe_path = output_dir / f"{safe_target}.exe"
        if ok and exe_path.exists():
            self.log(f"Build OK: {exe_path}")
            if create_zip:
                zip_path = self.packages.create_release_zip(
                    package_name=safe_target,
                    sources=[exe_path, "modules", "core/database/service_hub_schema_v2.sql", "README_MVP.txt"],
                )
                self.log(f"Release ZIP: {zip_path}")
            return BuildResult(True, safe_target, mode, exe_path, log_path, elapsed, "Build completed.")

        self.log(f"Build failed. See log: {log_path}")
        try:
            tail = log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-80:]
            if tail:
                self.log("===== LAST BUILD LOG LINES =====")
                for line in tail:
                    self.log(line)
        except OSError as exc:
            self.log(f"Unable to read build log: {exc}")
        return BuildResult(False, safe_target, mode, exe_path if exe_path.exists() else None, log_path, elapsed, "Build failed.")

    def _create_module_runner(self, manifest: dict[str, Any]) -> Path:
        module_id = manifest.get("module_id", "module")
        entry = manifest.get("entry")
        if not entry:
            raise ValueError("Module entry is missing.")

        runner_path = self.temp_root / f"run_{self._safe_name(module_id)}.py"
        runner_code = f'''
from __future__ import annotations
import importlib
import sys
from PySide6.QtWidgets import QApplication, QMainWindow

ENTRY = {entry!r}
TITLE = {manifest.get('module_name', module_id)!r}


def main() -> None:
    app = QApplication(sys.argv)
    module_path, class_name = ENTRY.rsplit('.', 1)
    module = importlib.import_module(module_path)
    widget_class = getattr(module, class_name)
    window = QMainWindow()
    window.setWindowTitle(TITLE)
    window.resize(1280, 820)
    window.setCentralWidget(widget_class())
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
'''
        runner_path.write_text(textwrap.dedent(runner_code), encoding="utf-8")
        return runner_path

    @staticmethod
    def _safe_name(value: str) -> str:
        keep = []
        for char in value:
            if char.isalnum() or char in ["_", "-", "."]:
                keep.append(char)
            else:
                keep.append("_")
        return "".join(keep).strip("_") or "build_target"
