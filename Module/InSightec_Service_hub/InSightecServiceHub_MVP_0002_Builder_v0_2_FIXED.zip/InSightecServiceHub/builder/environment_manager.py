# builder/environment_manager.py
# InSightec Service Hub - Build Environment Manager v0.2

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

LogCallback = Callable[[str], None]


@dataclass(frozen=True)
class BuildEnvironment:
    python_executable: Path
    python_version: str
    nuitka_version: str
    pyside6_version: str


class BuildEnvironmentManager:
    """Selects Python 3.13 and prepares the Nuitka/PySide6 build environment.

    Priority:
      1. SERVICE_HUB_PYTHON environment variable
      2. Current interpreter when it is Python 3.13
      3. Windows py launcher (py -3.13)
      4. GitHub hosted tool cache / common Python 3.13 locations
      5. Current interpreter as a last-resort fallback

    On GitHub Actions, missing/outdated build dependencies are installed into the
    selected Python automatically. Local auto-install can be enabled with:
      SERVICE_HUB_AUTO_INSTALL_BUILD_DEPS=1
    """

    REQUIRED_PACKAGES = (
        "PySide6",
        "Nuitka",
        "ordered-set",
        "zstandard",
        "pywin32",
    )

    def __init__(self, log_callback: Optional[LogCallback] = None) -> None:
        self.log_callback = log_callback

    def log(self, message: str) -> None:
        if self.log_callback:
            self.log_callback(message)
        else:
            print(message)

    def prepare(self) -> BuildEnvironment:
        python_exe = self.select_python()
        version = self._python_version(python_exe)
        self.log(f"Selected build Python: {python_exe}")
        self.log(f"Selected Python version: {version}")

        auto_install = self._auto_install_enabled()
        if auto_install:
            self.log("Preparing/updating build dependencies...")
            self._install_or_upgrade_dependencies(python_exe)
        else:
            self.log("Local dependency auto-install is disabled.")

        self._verify_imports(python_exe)
        nuitka_version = self._module_version(python_exe, "nuitka", "__version__")
        pyside6_version = self._module_version(python_exe, "PySide6", "__version__")

        self.log(f"Nuitka version: {nuitka_version}")
        self.log(f"PySide6 version: {pyside6_version}")
        self.log("Dependency Walker download approval: enabled")

        return BuildEnvironment(
            python_executable=python_exe,
            python_version=version,
            nuitka_version=nuitka_version,
            pyside6_version=pyside6_version,
        )

    def select_python(self) -> Path:
        override = os.environ.get("SERVICE_HUB_PYTHON", "").strip().strip('"')
        if override:
            candidate = Path(override)
            if candidate.is_file():
                return candidate.resolve()
            raise FileNotFoundError(f"SERVICE_HUB_PYTHON does not exist: {candidate}")

        current = Path(sys.executable).resolve()
        if sys.version_info[:2] == (3, 13):
            return current

        py_launcher = shutil.which("py")
        if py_launcher:
            try:
                result = subprocess.run(
                    [py_launcher, "-3.13", "-c", "import sys; print(sys.executable)"],
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=20,
                )
                if result.returncode == 0 and result.stdout.strip():
                    candidate = Path(result.stdout.strip())
                    if candidate.is_file():
                        return candidate.resolve()
            except (OSError, subprocess.SubprocessError):
                pass

        candidates: list[Path] = []
        runner_tool_cache = os.environ.get("RUNNER_TOOL_CACHE")
        if runner_tool_cache:
            candidates.extend(Path(runner_tool_cache).glob("Python/3.13*/x64/python.exe"))

        candidates.extend(Path("C:/hostedtoolcache/windows/Python").glob("3.13*/x64/python.exe"))

        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            candidates.extend([
                Path(local_app_data) / "Programs/Python/Python313/python.exe",
                Path(local_app_data) / "Programs/Python/Python313-32/python.exe",
            ])

        candidates.extend([
            Path("C:/Python313/python.exe"),
            Path("C:/Program Files/Python313/python.exe"),
            Path("C:/Program Files (x86)/Python313/python.exe"),
        ])

        valid = [path.resolve() for path in candidates if path.is_file()]
        if valid:
            valid.sort(key=lambda item: str(item), reverse=True)
            return valid[0]

        self.log(
            "WARNING: Python 3.13 was not found. Falling back to the current "
            f"interpreter ({current})."
        )
        return current

    def _auto_install_enabled(self) -> bool:
        explicit = os.environ.get("SERVICE_HUB_AUTO_INSTALL_BUILD_DEPS")
        if explicit is not None:
            return explicit.strip().lower() in {"1", "true", "yes", "on"}
        return os.environ.get("GITHUB_ACTIONS", "").lower() == "true"

    def _install_or_upgrade_dependencies(self, python_exe: Path) -> None:
        commands = [
            [str(python_exe), "-m", "pip", "install", "--upgrade", "pip"],
            [
                str(python_exe),
                "-m",
                "pip",
                "install",
                "--upgrade",
                *self.REQUIRED_PACKAGES,
            ],
        ]
        for command in commands:
            self.log("Running: " + " ".join(command))
            process = subprocess.run(command, text=True, check=False)
            if process.returncode != 0:
                raise RuntimeError(
                    "Build dependency installation failed with exit code "
                    f"{process.returncode}."
                )

    def _verify_imports(self, python_exe: Path) -> None:
        code = (
            "import PySide6, nuitka, ordered_set, zstandard; "
            "print('Build dependency import check: OK')"
        )
        process = subprocess.run(
            [str(python_exe), "-c", code],
            capture_output=True,
            text=True,
            check=False,
        )
        if process.returncode != 0:
            detail = (process.stderr or process.stdout or "Unknown import error").strip()
            raise RuntimeError(
                "Required build dependencies are missing from the selected Python. "
                "Run 05_PREPARE_BUILD_ENVIRONMENT.bat or set "
                "SERVICE_HUB_AUTO_INSTALL_BUILD_DEPS=1.\n" + detail
            )
        self.log(process.stdout.strip())

    @staticmethod
    def _python_version(python_exe: Path) -> str:
        process = subprocess.run(
            [str(python_exe), "-c", "import platform; print(platform.python_version())"],
            capture_output=True,
            text=True,
            check=False,
        )
        if process.returncode != 0:
            raise RuntimeError(f"Unable to query Python version: {python_exe}")
        return process.stdout.strip()

    @staticmethod
    def _module_version(python_exe: Path, module: str, attr: str) -> str:
        code = (
            f"import {module}; "
            f"print(getattr({module}, {attr!r}, 'unknown'))"
        )
        process = subprocess.run(
            [str(python_exe), "-c", code],
            capture_output=True,
            text=True,
            check=False,
        )
        if process.returncode != 0:
            return "unknown"
        return process.stdout.strip() or "unknown"
