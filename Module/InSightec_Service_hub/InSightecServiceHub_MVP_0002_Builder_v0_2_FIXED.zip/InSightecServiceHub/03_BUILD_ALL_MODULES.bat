@echo off
cd /d %~dp0
set NUITKA_ASSUME_YES_FOR_DOWNLOADS=yes
python -m builder.build_cli --target all
pause
