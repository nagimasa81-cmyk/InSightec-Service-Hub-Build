InSightec Service Hub Builder v0.2

Purpose:
- Dedicated builder for InSightec Service Hub.
- Prefers Python 3.13 automatically.
- On GitHub Actions, installs/upgrades PySide6, Nuitka, ordered-set,
  zstandard, and pywin32 into the selected Python 3.13 environment.
- Enables Nuitka non-interactive downloads for Dependency Walker.
- Scans modules/*/manifest.json automatically.
- Builds platform or selected modules using Nuitka.
- Creates release ZIP packages.
- Saves build logs under build_logs/ and prints the last 80 lines on failure.

Recommended first run on Windows:
  05_PREPARE_BUILD_ENVIRONMENT.bat
  00_RUN_BUILDER_GUI.bat

GUI:
  00_RUN_BUILDER_GUI.bat

CLI examples:
  python -m builder.build_cli --target environment
  python -m builder.build_cli --target validate
  python -m builder.build_cli --target platform
  python -m builder.build_cli --target platform --debug
  python -m builder.build_cli --target module --module-id ib_console
  python -m builder.build_cli --target all
  python -m builder.build_cli --target clean

Python selection order:
  1. SERVICE_HUB_PYTHON environment variable
  2. Current interpreter when Python 3.13
  3. Windows py launcher: py -3.13
  4. GitHub hosted tool cache / common Python 3.13 locations
  5. Current interpreter fallback with a warning

GitHub Actions:
- No requirements.txt change is required.
- The Builder detects GitHub Actions and prepares the selected Python 3.13
  environment automatically before Nuitka starts.
- The generated Nuitka command includes --assume-yes-for-downloads.
