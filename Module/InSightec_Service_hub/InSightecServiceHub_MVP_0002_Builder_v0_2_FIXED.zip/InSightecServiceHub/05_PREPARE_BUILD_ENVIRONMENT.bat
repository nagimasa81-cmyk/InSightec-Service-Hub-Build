@echo off
setlocal
cd /d %~dp0
set SERVICE_HUB_AUTO_INSTALL_BUILD_DEPS=1
python -m builder.build_cli --target environment
set ERR=%ERRORLEVEL%
if not "%ERR%"=="0" (
    echo.
    echo Build environment preparation failed. ERRORLEVEL=%ERR%
    exit /b %ERR%
)
echo.
echo Build environment is ready.
pause
