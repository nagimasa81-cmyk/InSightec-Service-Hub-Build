# Commit 0009 — RC9 Unified Build

- Added `version.json` RC9 metadata and `hub_variant=card_launcher`.
- Added canonical `scripts/build.py`.
- Replaced workflows with `.github/workflows/build_selected.yml`.
- Added independent Hub Guide and Module Guide build options.
- Added unified cache key and short artifact naming.
- Added Card Launcher / ZIP Drop validation.
- Added RC9 manifest fields and final Triple Check.
