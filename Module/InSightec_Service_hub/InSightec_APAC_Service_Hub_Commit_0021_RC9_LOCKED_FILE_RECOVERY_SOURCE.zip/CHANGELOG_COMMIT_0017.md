# Commit 0017 — RC9 Artifact ZIP Policy Fix

- PyInstallerの`_internal/base_library.zip`など必須ランタイムZIPを許可。
- 製品配布ZIPやSOURCE ZIPがArtifact payloadへ混入する場合はFAIL。
- `version.json`の`allowed_payload_zips`で意図的なZIPリソースを明示許可可能。
- `payload_zip_inventory.json`をArtifactへ追加し、各ZIPの許可理由を記録。
- GitHub Actionsの外側Artifact ZIPと製品配布ZIPの二重構造は引き続き禁止。
