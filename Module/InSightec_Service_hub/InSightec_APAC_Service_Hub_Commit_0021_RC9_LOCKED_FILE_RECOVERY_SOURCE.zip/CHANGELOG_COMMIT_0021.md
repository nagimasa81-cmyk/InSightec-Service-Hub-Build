# Commit 0021 — Locked-file recovery and resilient packaging

- Recover a completed Module distribution when a legacy child builder exits only because Windows denies post-build cleanup.
- Validate that the generated EXE exists, is stable, non-empty, and readable before recovery.
- Add bounded retry/backoff for transient WinError 5/32/33 file locks.
- Use resilient copy/remove operations for artifacts, cache and diagnostics.
- Preserve genuine compile, dependency and packaging failures as fatal errors.
- Keep BAT/Python/SPEC/PowerShell launcher dispatch from Commit0020.
