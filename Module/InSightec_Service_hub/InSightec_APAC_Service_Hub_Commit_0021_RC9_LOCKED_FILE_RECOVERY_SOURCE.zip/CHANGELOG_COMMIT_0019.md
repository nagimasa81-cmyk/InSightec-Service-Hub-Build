# Commit 0019 - Integrated Module Build and Guide-aware Cache

- Service Hub build now builds or restores every bundled Module through the same RC9 build.py.
- Module Guide ON/OFF is part of each Module cache key.
- Hub Guide, Module Guide, Hub Variant, Python version, Hub SOURCE, build.py, and all Module payload hashes are part of the Hub cache key.
- A changed Module invalidates only its own cache and the final Hub cache; unchanged Modules reuse cache.
- Module artifacts are integrated into the Hub tools directory before Hub packaging.
- Hub Artifact suffix G is used when either Hub Guide or bundled Module Guide is enabled.
- module_bundle_inventory.json records integrated Module payload hashes and executable paths.
