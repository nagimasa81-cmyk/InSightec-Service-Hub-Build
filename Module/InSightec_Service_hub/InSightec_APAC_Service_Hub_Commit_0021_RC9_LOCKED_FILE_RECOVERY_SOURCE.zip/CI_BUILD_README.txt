InSightec APAC Service Hub - Commit 0005 CI Build Stability

GitHub repository layout:

Repository
  Module
    InSightec_Service_hub
      <latest source ZIP>
  .github/workflows
    build_selected.yml
    build_all.yml

Recommended build flow:
1. Place this source ZIP in Module/InSightec_Service_hub.
2. Run build_selected.yml and select InSightec_Service_hub.
3. The workflow detects 01_BUILD_EXE.bat automatically.
4. The BAT launches Build_Hub_EXE.py.
5. PyInstaller creates dist/InSightecServiceHub.
6. GitHub Actions packages the standalone output as an artifact.

Optional local checks:
- 02_VALIDATE_SOURCE.bat
- 01_BUILD_EXE.bat

Commit 0005 changes:
- Added source validation.
- Added explicit build requirements.
- Added build metadata and release ZIP generation.
- Updated version/build metadata to 0.5.0 / Commit 0005.
