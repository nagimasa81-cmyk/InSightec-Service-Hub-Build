# FUS Image Explore 1.0.0

- Added to InSightec APAC Service Hub tool launcher.
- Expected executable: `MR_Image_Explorer_RC1.exe`.
- Supports DICOM/raw FFT visualization and MRI image reconstruction workflows.
