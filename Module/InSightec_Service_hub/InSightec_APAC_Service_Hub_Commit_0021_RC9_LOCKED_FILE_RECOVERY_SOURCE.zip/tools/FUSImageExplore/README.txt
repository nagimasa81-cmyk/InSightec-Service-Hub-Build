FUS Image Explore - Service Hub Integration

Place the built executable in this folder using this exact filename:

    MR_Image_Explorer_RC1.exe

The Service Hub reads tool metadata from manifest.json.
Until the EXE is placed here, the tool card remains visible but shows Missing/Warning and Launch is disabled.
