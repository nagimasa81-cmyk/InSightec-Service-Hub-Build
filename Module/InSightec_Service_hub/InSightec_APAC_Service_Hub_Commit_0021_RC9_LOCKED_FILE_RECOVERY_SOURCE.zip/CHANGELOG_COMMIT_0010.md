# Commit0010 - RC9 Final Build System Candidate

- Python 3.14 fixed in Workflow.
- pip-only dependency installation.
- requirements-build.txt and requirements.txt are both installed when present.
- pyproject.toml project installation and entry detection added.
- Module name input changed to free text for automatic folder recognition.
- Guide settings embedded in build_options.json and config.json.
- Hub Guide controls Guided Tour visibility; Module Guide is propagated to launched modules.
- Strict manifest/version, dist/EXE, artifact and cache validation.
- Repository scripts directory contains build.py only.
