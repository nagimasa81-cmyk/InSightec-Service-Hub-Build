# Commit 0016 — RC9 Build Diagnostics

- PyInstaller/Nuitka command output is preserved in `rc9_diagnostics`.
- Failed builds generate `build_failure.json` with classified causes.
- Missing modules, DLLs, hidden imports and Qt platform plugin problems are summarized.
- Qt runtime payload is checked before Artifact publication.
- GitHub Actions uploads diagnostics when a build fails.
- Successful Artifact remains a single outer GitHub ZIP with no nested product ZIP.
