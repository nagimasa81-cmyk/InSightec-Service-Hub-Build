# Commit 0015 — RC9 Scoped Audit and Legacy Metadata Migration

- Module build audits only the selected module.
- Service Hub build audits the Hub and all module SOURCE ZIPs currently present.
- Legacy SOURCE ZIPs without version.json can be migrated using the RC9 module version map.
- Full repository-relative paths and a correction summary are printed for failures.
- Fixed the undefined z_no_double variable in Triple Check.
- No-double-ZIP validation now uses the actual artifact payload only.
