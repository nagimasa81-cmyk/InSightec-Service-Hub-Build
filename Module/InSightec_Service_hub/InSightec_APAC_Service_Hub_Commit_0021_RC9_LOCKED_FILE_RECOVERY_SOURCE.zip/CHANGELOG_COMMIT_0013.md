# Commit 0013 — RC9 Artifact/Startup Validation Fix

- GitHub Artifactへ配布ディレクトリを直接アップロードし、ZIPの中のZIPを解消。
- build.pyが作るZIPはTriple Check用の一時ファイルのみとし、公開しない。
- EXE起動スモークテストを追加し、即時クラッシュするFFT等のArtifact公開を停止。
- CacheもZIPではなく検証済み配布ディレクトリを保存・復元。
- Artifact名をbuild.pyからWorkflowへ出力し、短いRC9名称を維持。
