# Commit 0012 — RC9 Hub Variant compatibility

- Workflow Hub Variant now has priority over SOURCE `version.json`.
- Legacy Hub SOURCE without `hub_variant` is accepted.
- Invalid or conflicting SOURCE variant is replaced by the selected workflow variant.
- Module builds do not require or validate `hub_variant`.
- RC9 manifest and `build_options.json` receive the resolved variant.
- Duplicate pip bootstrap execution removed.
