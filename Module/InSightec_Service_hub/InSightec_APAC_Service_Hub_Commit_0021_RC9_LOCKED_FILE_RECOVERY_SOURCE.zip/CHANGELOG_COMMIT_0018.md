# Commit 0018 - Balanced Audit and Module Dropdown

- Restored Module selection to a fixed GitHub Actions choice list.
- Module additions are intentionally maintained in build_selected.yml.
- Removed repository work folders such as hubsrc.
- Split audit findings into blocking errors and advisory warnings.
- Only the selected target can stop a build.
- Legacy missing version.json is migrated when a version can be inferred.
- BAT is optional when a valid SPEC, builder, pyproject, or entry point exists.
- Multiple legacy SPEC files use deterministic production selection where possible.
- Embedded SOURCE ZIP resources are advisory; final Artifact ZIP policy remains authoritative.
- Python syntax checks exclude tests, examples, samples, and vendored code from release blocking.
