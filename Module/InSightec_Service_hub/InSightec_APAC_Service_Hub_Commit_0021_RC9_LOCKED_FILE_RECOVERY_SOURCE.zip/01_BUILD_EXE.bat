@echo off
setlocal
cd /d "%~dp0"
python Build_Hub_EXE.py
set RC=%ERRORLEVEL%
if not "%RC%"=="0" echo [FAIL] Hub build failed with exit code %RC%.
if not defined CI pause
exit /b %RC%
