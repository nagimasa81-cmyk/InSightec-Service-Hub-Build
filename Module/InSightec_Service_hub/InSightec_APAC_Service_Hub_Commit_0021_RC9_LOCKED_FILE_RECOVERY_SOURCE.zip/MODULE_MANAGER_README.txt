InSightec APAC Service Hub - Module Manager

Commit 0003.7 adds Developer Mode module lifecycle tools.

How to use:
1. Open Modules from the left menu.
2. Enter Developer Mode password when prompted. Initial password: 5963.
3. Select a module.
4. Use Edit to change Version, Build, Channel and Release Notes.
5. Use Create Package to create a module update ZIP under updates/packages/.

Version source:
Hub reads version/build/channel from each module manifest.json.

Channels:
- stable: normal released module
- beta: beta validation
- feu: FEU validation
- internal: developer/internal validation
