Tool installation locations

- tools\DOanalysis\DO Analysis Qt Ver1.0.1.exe
- tools\LogExplorer\LogMergeTool_NoExcel.exe
- tools\TrackerSNR\TrackerSNR_CLEAN_EXE.exe
- tools\VIMeasure\VIMeasureAnalyzer.exe
- tools\FUSImageExplore\MR_Image_Explorer_RC1.exe

Place each tool executable in the listed folder before building or packaging the Hub.
