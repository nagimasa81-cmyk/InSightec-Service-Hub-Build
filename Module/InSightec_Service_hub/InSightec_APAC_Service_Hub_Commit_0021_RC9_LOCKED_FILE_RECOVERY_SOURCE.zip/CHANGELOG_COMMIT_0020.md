# Commit 0020 - Build Launcher Dispatch Fix

- Fixed RC9 build.py so version.json `build_script` is dispatched by file type.
- `.bat` and `.cmd` build definitions run through `cmd.exe`, never Python.
- `.py` build definitions run through the selected Python interpreter.
- `.spec` build definitions run through `python -m PyInstaller`.
- `.ps1` build definitions run through PowerShell with a non-interactive policy.
- Added explicit build launcher and target logging before execution.
- Added recursion protection for RC9 wrapper BAT files.
- Added support for the legacy lowercase `build_exe.bat` filename.
