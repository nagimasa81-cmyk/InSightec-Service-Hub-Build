# Commit 0017af — FUS Standalone Runtime Packaging Fix

Observed V9S result:
- FUS Image Explore compiled for ~23 minutes.
- EXE discovery succeeded.
- Packaging then failed because the Hub still required the historical folder
  `MRI_Raw_FFT_Explorer_Nuitka_Windows`.

Fix:
- When a tool has `copy_directory` but that historical directory is absent,
  use the already-validated built EXE's parent directory as the standalone
  runtime payload.
- This supports current Nuitka layouts such as `dist_nuitka/app.dist`.
- The entire runtime folder is copied, preserving DLLs/plugins/data next to EXE.
- Cache schema stays at v5 intentionally so V9S-successful tools can be reused.
