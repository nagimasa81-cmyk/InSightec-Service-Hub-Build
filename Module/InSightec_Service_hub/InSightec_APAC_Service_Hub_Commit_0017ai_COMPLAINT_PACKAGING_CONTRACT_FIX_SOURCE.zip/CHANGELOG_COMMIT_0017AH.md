# Commit 0017ah — Deep Runtime Contract Fix

- Sonication Analysis is packaged as the full Nuitka standalone `.dist` runtime,
  not as a single EXE.
- Only Sonication's cache signature changes, preserving successful caches of the
  other existing tools.
- Complaint Direct Launch card is shown before ZIP-drop tools when included.
- Complaint remains outside AUTO_TOOL_ORDER and cannot receive ZIP/folder Drop.
- Final Hub build validates Sonication sidecars, all required EXEs, and optional
  Complaint card/runtime consistency before creating the release artifact.
- Launch now detects immediate non-zero process exit instead of falsely reporting success.
