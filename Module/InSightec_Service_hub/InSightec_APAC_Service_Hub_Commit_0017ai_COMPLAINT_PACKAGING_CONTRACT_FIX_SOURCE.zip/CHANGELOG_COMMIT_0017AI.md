# Commit 0017ai — Complaint Folder-Onefile Packaging Contract

Observed V9V:
- Complaint compilation/package creation completed.
- Hub packaging then rejected the result because the distribution folder
  contained only the launcher EXE.

Fix:
- `copy_directory` means "copy the complete distribution directory"; it does
  not by itself imply DLL/plugin sidecars are mandatory.
- Sidecars are mandatory only when the effective build contract explicitly
  declares non-onefile standalone distribution.
- Complaint may therefore be a one-EXE distribution folder while Sonication
  remains strictly validated as a full standalone runtime.
- Complaint's cache signature receives a tool-specific packaging-policy bump.
