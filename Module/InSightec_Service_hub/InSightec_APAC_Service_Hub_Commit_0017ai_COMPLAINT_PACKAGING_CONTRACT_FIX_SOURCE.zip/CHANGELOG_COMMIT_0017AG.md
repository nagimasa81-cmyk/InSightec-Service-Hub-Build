# Commit 0017ag — Optional Complaint Integration

- Complaint is optionally built when include_complaint=include.
- Supports BUILD_EXE.bat and legacy 01_BUILD_EXE_NUITKA.bat.
- Complaint is Direct Launch only and remains outside ZIP/folder Drop routing.
- Excluded Complaint is not required by source validation/preflight.
