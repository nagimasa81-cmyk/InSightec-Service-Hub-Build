from pathlib import Path
from types import SimpleNamespace
from src.services.standalone_cavitation_service import StandaloneCavitationService
from src.services.cpc_vendor_reproduction_service import VendorBand

ROOT=Path(__file__).parents[1]
PANEL=(ROOT/'src/ui/image_panel.py').read_text(encoding='utf-8')
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')

def test_fft_band0_is_exact_0311_to_0411_mhz():
    svc=StandaloneCavitationService()
    profile=SimpleNamespace(bands=[VendorBand(0,.5,0,310000,411000)])
    replay=SimpleNamespace(vendor_profile=profile)
    low,high,source,_=svc.resolved_band_ranges(replay)[0]
    assert (low,high)==(311000.0,411000.0)
    assert 'R0130' in source

def test_selected_raw_fft_uses_same_band0_contract_and_reports_metric():
    assert 'band0_low_hz, band0_high_hz = 311000.0, 411000.0' in HYDRO
    assert 'FFT-derived Band0 (0.311–0.411 MHz)' in HYDRO
    assert 'Band0 FFT RMS' in HYDRO

def test_main_image_payload_carries_frequency_axis():
    assert '"frequency_axis"' in MAIN
    assert 'summary.get("Frequency Dir"' in MAIN

def test_workstation_hat_is_cyan_lower_right_and_direction_aware():
    assert 'workstation-style frequency-encoding "hat" marker' in PANEL
    assert 'cx, cy = w - 18.0, h - 18.0' in PANEL
    assert 'QColor(80, 235, 240)' in PANEL
    assert "freq_axis == lr_axis" in PANEL
    assert "freq_axis == tb_axis" in PANEL
