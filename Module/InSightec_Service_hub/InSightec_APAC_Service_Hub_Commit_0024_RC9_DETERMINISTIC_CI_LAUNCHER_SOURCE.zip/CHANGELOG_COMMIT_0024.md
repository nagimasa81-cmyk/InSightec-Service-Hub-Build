# Commit 0024 — Deterministic CI Launcher Ranking

- GitHub CI BAT files receive the highest unique priority.
- Canonical Nuitka BAT files receive the next priority.
- Local Windows/Python-version-specific BAT files remain usable but are deprioritized.
- Genuine unresolved ties now include scores and selection reasons in diagnostics.
- No change to Hub/Module cache or Guide cache conditions.
