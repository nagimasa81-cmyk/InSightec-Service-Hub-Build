# Commit 0046

- Forces installation of `PySide6-Addons` matching the active PySide6 version.
- Logs PySide6, Essentials and Addons versions and QtOpenGL module paths.
- Explicitly bundles QtOpenGL and QtOpenGLWidgets with PyInstaller.
- Verifies the generated distribution contains both Qt extension modules before smoke testing.
- Preserves Log Explorer CSA Err default / LOAD LOGS fixes.
- Preserves complete Sonication hiding when excluded.
