# Commit 0044

- Detects pyqtgraph/QtOpenGL usage before compilation.
- Installs the exact PySide6-Addons version matching the installed PySide6.
- Adds PySide6.QtOpenGL and QtOpenGLWidgets as explicit PyInstaller hidden imports.
- Fails before compilation with an actionable error when Qt dependency repair is impossible.
- Preserves complete Sonication Analysis removal for exclude builds.
