# Commit 0017aj — Hybrid Sonication Fast-Preflight Policy Ordering Fix

Observed with R0190v / Hybrid build:
- `Fast_Preflight_All_Tools.py` failed with `sonication_analysis: pytest is not declared after Hub build policy`.
- The checker asserted a *post-policy* invariant but never called `apply_hub_build_policy()` before checking it.
- The embedded Sonication snapshot therefore failed before the repository R0190v overlay job could run.

Fix:
- Fast preflight now applies the existing idempotent Soni Hub build policy before validating post-policy pytest/guard invariants.
- This keeps fast preflight and integrated build semantics aligned.
- No DQA/clinical calculation code is changed.
- Generated `__pycache__` files are removed from the Hub SOURCE package.
