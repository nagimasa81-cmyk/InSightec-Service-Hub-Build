\
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) != 2:
        print('Usage: 05_SMOKE_TEST_PACKAGED_EXE.py <exe>', file=sys.stderr)
        return 2

    exe = Path(sys.argv[1]).resolve()
    if not exe.is_file():
        print(f'[FAIL] packaged EXE missing: {exe}', file=sys.stderr)
        return 3
    if exe.stat().st_size < 100_000:
        print(f'[FAIL] packaged EXE unexpectedly small: {exe.stat().st_size}', file=sys.stderr)
        return 4

    env = os.environ.copy()
    env['MRIE_STARTUP_SMOKE_TEST'] = '1'
    env['QT_QPA_PLATFORM'] = 'offscreen'
    env['PYTHONNOUSERSITE'] = '1'

    print(f'[SMOKE] starting packaged EXE: {exe}')
    print('[SMOKE] MRIE_STARTUP_SMOKE_TEST=1; first-run guide disabled; timeout=90s')
    try:
        proc = subprocess.Popen([str(exe)], cwd=str(exe.parent), env=env)
        rc = proc.wait(timeout=90)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)
        print('[FAIL] packaged EXE did not exit within 90 seconds', file=sys.stderr)
        return 5
    except Exception as exc:
        print(f'[FAIL] packaged EXE could not start: {type(exc).__name__}: {exc}', file=sys.stderr)
        return 6

    if rc != 0:
        print(f'[FAIL] packaged EXE returned exit code {rc}', file=sys.stderr)
        local = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'MR_Image_Explorer' / 'startup_error.log'
        if local.is_file():
            print('----- startup_error.log -----', file=sys.stderr)
            try:
                print(local.read_text(encoding='utf-8', errors='replace'), file=sys.stderr)
            except Exception:
                pass
        return 7

    print('[PASS] packaged EXE created the Qt application/window and exited cleanly')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
