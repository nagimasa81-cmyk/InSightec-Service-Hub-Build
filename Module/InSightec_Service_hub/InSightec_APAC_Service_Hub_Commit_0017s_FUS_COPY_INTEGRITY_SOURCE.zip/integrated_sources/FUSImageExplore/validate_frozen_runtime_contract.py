from pathlib import Path

root = Path(__file__).resolve().parent
app = (root / 'app.py').read_text(encoding='utf-8')
bat = (root / '03_BUILD_NUITKA_STANDALONE.bat').read_text(encoding='utf-8', errors='ignore')
smoke = root / '05_SMOKE_TEST_PACKAGED_EXE.py'

checks = {
    'PySide6 imported before pyqtgraph': app.find('from PySide6.QtCore') < app.find('import pyqtgraph as pg'),
    'QtOpenGL import': 'QtOpenGLWidgets' in app,
    'Nuitka pyqtgraph include': '--include-package=pyqtgraph' in bat,
    'Nuitka QtOpenGL include': '--include-module=PySide6.QtOpenGLWidgets' in bat,
    'packaged smoke invoked': '05_SMOKE_TEST_PACKAGED_EXE.py' in bat,
    'smoke helper exists': smoke.is_file(),
    'validated runtime copier exists': (root / '05_PREPARE_PACKAGED_RUNTIME.py').is_file(),
    'xcopy removed': 'xcopy ' not in bat.lower(),
    'validated copy invoked': '05_PREPARE_PACKAGED_RUNTIME.py' in bat,
    'smoke guide disabled': 'MRIE_STARTUP_SMOKE_TEST' in app and '!= "1"' in app,
}
for name, ok in checks.items():
    print(f"[{'PASS' if ok else 'FAIL'}] {name}")
if not all(checks.values()):
    raise SystemExit(1)
