import json
import os
import sys
from pathlib import Path

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication
from src.common.constants import APP_NAME
from src.common.logger import configure_logging
from src.common.theme import DARK_STYLESHEET
from src.ui.main_window import MainWindow


def _handoff_source(argv):
    try:
        index = argv.index("--handoff")
        handoff = Path(argv[index + 1])
        payload = json.loads(handoff.read_text(encoding="utf-8"))
        workspace = Path(str(payload.get("workspace_path", "")))
        if workspace.exists():
            return workspace
        for item in payload.get("source_paths", []):
            source = Path(str(item))
            if source.exists():
                return source
    except Exception:
        return None
    return None


def run():
    configure_logging()
    source = _handoff_source(sys.argv)
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setStyleSheet(DARK_STYLESHEET)
    window = MainWindow()
    window.show()
    if source is not None:
        QTimer.singleShot(0, lambda: window.load(source))
    return app.exec()
