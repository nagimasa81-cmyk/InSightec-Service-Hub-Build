from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


@dataclass(frozen=True)
class ToolBuild:
    tool_id: str
    source_dir: str
    target_dir: str
    build_script: str
    output_candidates: tuple[str, ...]
    target_exe: str
    copy_directory: str | None = None
    prefer_existing_runtime: bool = False


TOOLS: tuple[ToolBuild, ...] = (
    ToolBuild(
        "do_analysis", "DOAnalysis", "DOanalysis", "build_exe.bat",
        ("dist/DO Analysis Qt.exe", "dist/DO Analysis Qt Ver1.0.1.exe"),
        "DO Analysis Qt Ver1.0.1.exe",
    ),
    ToolBuild(
        "tracker_snr", "TrackerSNR", "TrackerSNR", "00_BUILD_EXE_RECOMMENDED_PYINSTALLER.bat",
        ("dist/TrackerSNR_CLEAN_EXE.exe",), "TrackerSNR_CLEAN_EXE.exe",
    ),
    ToolBuild(
        "log_explorer", "LogExplorer", "LogExplorer", "01_BUILD_EXE_GITHUB.bat",
        ("dist/LogMergeTool_NoExcel.exe",),
        "LogMergeTool_NoExcel.exe",
    ),
    ToolBuild(
        "sonication_analysis", "SonicationAnalysis", "SonicationAnalysis", "01_BUILD_EXE_NUITKA.bat",
        ("dist/Sonication_Replay_Engine.exe",), "Sonication_Replay_Engine.exe", prefer_existing_runtime=True,
    ),
    ToolBuild(
        "fus_image_explore", "FUSImageExplore", "FUSImageExplore", "02_BUILD_EXE_NUITKA.bat",
        ("MRI_Raw_FFT_Explorer_Nuitka_Windows/MRI_Raw_FFT_Explorer.exe",),
        "MR_Image_Explorer_RC1.exe", copy_directory="MRI_Raw_FFT_Explorer_Nuitka_Windows",
    ),
    ToolBuild(
        "vimeasure", "VIMeasure", "VIMeasure", "01_BUILD_EXE_NUITKA.bat",
        ("dist/VIMeasureAnalyzer.exe",), "VIMeasureAnalyzer.exe",
    ),
)


def stream_command(command: list[str], cwd: Path, log_path: Path) -> int:
    env = os.environ.copy()
    env["CI"] = "true"
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    printable = subprocess.list2cmdline(command)
    print(f"[RUN] {printable}")
    with log_path.open("a", encoding="utf-8", errors="replace") as log:
        log.write(f"\n[RUN] {printable}\n")
        process = subprocess.Popen(
            command,
            cwd=str(cwd),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="")
            log.write(line)
        return process.wait()


def metadata_output_candidates(source_dir: Path) -> tuple[str, ...]:
    path = source_dir / "version.json"
    if not path.is_file():
        return ()
    try:
        meta = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return ()
    names: list[str] = []
    for key in ("exe_name", "executable"):
        value = str(meta.get(key) or "").strip()
        if value:
            names.append(value if value.lower().endswith(".exe") else value + ".exe")
    artifact = str(meta.get("artifact_base_name") or "").strip()
    if artifact:
        names.append(artifact if artifact.lower().endswith(".exe") else artifact + ".exe")
    out: list[str] = []
    for name in names:
        for prefix in ("dist", "."):
            rel = f"{prefix}/{name}" if prefix != "." else name
            if rel not in out:
                out.append(rel)
    return tuple(out)


def validate_tool_source_contract(spec: ToolBuild, source_dir: Path) -> dict:
    report = {"tool_id": spec.tool_id, "version_json": None, "warnings": []}
    meta_path = source_dir / "version.json"
    if meta_path.is_file():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8-sig"))
            report["version_json"] = meta
            entry = str(meta.get("entry_point") or "").strip()
            if entry and not (source_dir / entry).is_file():
                raise FileNotFoundError(f"{spec.tool_id}: version.json entry_point not found: {entry}")
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"{spec.tool_id}: invalid version.json: {exc}") from exc
    if not (source_dir / spec.build_script).is_file():
        raise FileNotFoundError(f"{spec.tool_id}: build script not found: {spec.build_script}")
    return report



MODULE_CACHE_SCHEMA = "insightec.integrated-tool-cache.v1"
CACHE_EXCLUDED_DIRS = {
    "__pycache__", ".git", ".github", ".pytest_cache",
    "dist", "build", "output", "release", "build_logs",
}


def _hash_file(path: Path, digest) -> None:
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)


def tool_source_signature(spec: ToolBuild, source_dir: Path) -> str:
    """Hash only build-relevant source state for one integrated tool."""
    digest = hashlib.sha256()
    digest.update(MODULE_CACHE_SCHEMA.encode("utf-8"))
    digest.update(spec.tool_id.encode("utf-8"))
    digest.update(spec.build_script.encode("utf-8"))
    digest.update(spec.target_exe.encode("utf-8"))
    digest.update(f"py{sys.version_info.major}.{sys.version_info.minor}".encode("ascii"))
    digest.update(platform.machine().lower().encode("utf-8"))

    generated_dir = (spec.copy_directory or "").lower()
    for path in sorted(source_dir.rglob("*"), key=lambda p: p.as_posix().lower()):
        if not path.is_file():
            continue
        rel = path.relative_to(source_dir)
        parts_lower = [part.lower() for part in rel.parts]
        if any(part in CACHE_EXCLUDED_DIRS for part in parts_lower):
            continue
        if generated_dir and parts_lower and parts_lower[0] == generated_dir:
            continue
        if path.suffix.lower() in {".pyc", ".pyo"}:
            continue
        digest.update(rel.as_posix().encode("utf-8"))
        _hash_file(path, digest)
    return digest.hexdigest()


def integrated_module_cache_root(source_root: Path) -> Path:
    explicit = os.environ.get("INSIGHTEC_MODULE_CACHE", "").strip()
    if explicit:
        return Path(explicit).resolve()
    workspace = os.environ.get("GITHUB_WORKSPACE", "").strip()
    if workspace:
        return (Path(workspace) / ".module-cache" / "integrated-tools").resolve()
    return (source_root / ".module-cache" / "integrated-tools").resolve()


def restore_tool_cache(
    spec: ToolBuild,
    source_root: Path,
    source_dir: Path,
    tools_root: Path,
) -> tuple[Path | None, str]:
    signature = tool_source_signature(spec, source_dir)
    cache_dir = integrated_module_cache_root(source_root) / spec.tool_id / signature / "payload"
    cached_exe = cache_dir / spec.target_exe
    if not cached_exe.is_file() or cached_exe.stat().st_size < 100_000:
        return None, signature

    destination = tools_root / spec.target_dir
    destination.mkdir(parents=True, exist_ok=True)
    for child in list(destination.iterdir()):
        if child.name.lower() in {"manifest.json", "readme.txt", "release_notes.md"}:
            continue
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()

    for item in cache_dir.iterdir():
        target = destination / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        else:
            shutil.copy2(item, target)

    target_exe = destination / spec.target_exe
    if not target_exe.is_file() or target_exe.stat().st_size < 100_000:
        return None, signature
    return target_exe, signature


def save_tool_cache(
    spec: ToolBuild,
    source_root: Path,
    source_dir: Path,
    tools_root: Path,
    signature: str,
) -> Path:
    source_runtime = tools_root / spec.target_dir
    if not source_runtime.is_dir():
        raise FileNotFoundError(f"{spec.tool_id}: packaged runtime missing before cache save: {source_runtime}")
    cache_base = integrated_module_cache_root(source_root) / spec.tool_id / signature
    payload = cache_base / "payload"
    if payload.exists():
        shutil.rmtree(payload)
    payload.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source_runtime, payload)
    metadata = {
        "schema": MODULE_CACHE_SCHEMA,
        "tool_id": spec.tool_id,
        "signature": signature,
        "target_exe": spec.target_exe,
        "python": f"{sys.version_info.major}.{sys.version_info.minor}",
        "created_at": datetime.now().isoformat(timespec="seconds"),
    }
    (cache_base / "cache_metadata.json").write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return payload


def existing_runtime_ready(spec: ToolBuild, tools_root: Path) -> Path | None:
    if not spec.prefer_existing_runtime:
        return None
    target = tools_root / spec.target_dir / spec.target_exe
    if target.is_file() and target.stat().st_size >= 100_000:
        return target
    return None

def first_existing(root: Path, candidates: tuple[str, ...]) -> Path | None:
    for relative in candidates:
        candidate = root / Path(relative)
        if candidate.is_file():
            return candidate
    return None


def copy_tool_result(spec: ToolBuild, source_root: Path, tools_root: Path) -> Path:
    destination = tools_root / spec.target_dir
    destination.mkdir(parents=True, exist_ok=True)

    # Preserve the manifest and documentation copied by the Hub packager, while
    # replacing stale binaries/runtime folders from previous builds.
    for child in list(destination.iterdir()):
        if child.name.lower() in {"manifest.json", "readme.txt", "release_notes.md"}:
            continue
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()

    source_dir = source_root / "integrated_sources" / spec.source_dir
    candidates = metadata_output_candidates(source_dir) + spec.output_candidates
    built_exe = first_existing(source_dir, candidates)
    if built_exe is None:
        raise FileNotFoundError(
            f"{spec.tool_id}: build completed but no expected EXE was found. "
            f"Checked: {', '.join(candidates)}"
        )

    if spec.copy_directory:
        runtime_dir = source_dir / spec.copy_directory
        if not runtime_dir.is_dir():
            raise FileNotFoundError(f"{spec.tool_id}: runtime directory not found: {runtime_dir}")
        for item in runtime_dir.iterdir():
            target = destination / item.name
            if item.is_dir():
                shutil.copytree(item, target, dirs_exist_ok=True)
            else:
                shutil.copy2(item, target)
        copied_exe = destination / built_exe.name
        target_exe = destination / spec.target_exe
        if copied_exe.resolve() != target_exe.resolve():
            if target_exe.exists():
                target_exe.unlink()
            copied_exe.rename(target_exe)
    else:
        target_exe = destination / spec.target_exe
        shutil.copy2(built_exe, target_exe)

    if not target_exe.is_file() or target_exe.stat().st_size < 100_000:
        raise RuntimeError(f"{spec.tool_id}: packaged EXE is missing or unexpectedly small: {target_exe}")
    return target_exe


def build_integrated_tools(source_root: Path, dist_dir: Path, fail_on_error: bool = True) -> dict:
    tools_root = dist_dir / "tools"
    tools_root.mkdir(parents=True, exist_ok=True)
    log_root = source_root / "build_logs" / "integrated_tools"
    log_root.mkdir(parents=True, exist_ok=True)

    results: list[dict] = []
    for index, spec in enumerate(TOOLS, start=1):
        started = time.monotonic()
        source_dir = source_root / "integrated_sources" / spec.source_dir
        build_script = source_dir / spec.build_script
        result = {
            "tool_id": spec.tool_id,
            "source_dir": str(source_dir),
            "build_script": spec.build_script,
            "status": "failed",
        }
        print("\n" + "=" * 72)
        print(f"Integrated tool {index}/{len(TOOLS)}: {spec.tool_id}")
        print("=" * 72)
        try:
            if os.name != "nt":
                raise RuntimeError("Integrated EXE builds require a Windows runner")
            contract = validate_tool_source_contract(spec, source_dir)
            result["contract"] = contract
            existing = existing_runtime_ready(spec, tools_root)
            if existing is not None:
                result.update({
                    "status": "ready",
                    "target_exe": str(existing.relative_to(dist_dir)),
                    "size_bytes": existing.stat().st_size,
                    "elapsed_seconds": round(time.monotonic() - started, 1),
                    "build_skipped": "existing externally integrated runtime preserved",
                })
                print(f"[PASS] {spec.tool_id}: preserved externally integrated runtime {existing}")
                results.append(result)
                continue

            cached, module_signature = restore_tool_cache(spec, source_root, source_dir, tools_root)
            result["module_cache_signature"] = module_signature
            if cached is not None:
                result.update({
                    "status": "ready",
                    "target_exe": str(cached.relative_to(dist_dir)),
                    "size_bytes": cached.stat().st_size,
                    "elapsed_seconds": round(time.monotonic() - started, 1),
                    "build_skipped": "exact per-module cache hit",
                })
                print(f"[CACHE HIT] {spec.tool_id}: restored {cached}")
                results.append(result)
                continue

            print(f"[CACHE MISS] {spec.tool_id}: {module_signature[:16]}...; building only this tool")
            log_path = log_root / f"{spec.tool_id}_{datetime.now():%Y%m%d_%H%M%S}.log"
            # Pass CALL and the BAT path as separate argv items; avoid /s + nested quoted command strings.
            rc = stream_command(["cmd.exe", "/d", "/c", "call", str(build_script)], source_dir, log_path)
            if rc != 0:
                raise RuntimeError(f"Build script exited with code {rc}. See {log_path}")
            target_exe = copy_tool_result(spec, source_root, tools_root)
            cache_payload = save_tool_cache(
                spec, source_root, source_dir, tools_root, module_signature
            )
            result.update({
                "status": "ready",
                "module_cache_saved": str(cache_payload),
                "target_exe": str(target_exe.relative_to(dist_dir)),
                "size_bytes": target_exe.stat().st_size,
                "elapsed_seconds": round(time.monotonic() - started, 1),
                "log": str(log_path),
            })
            print(f"[PASS] {spec.tool_id}: {target_exe}")
        except Exception as exc:
            result.update({
                "error": f"{type(exc).__name__}: {exc}",
                "elapsed_seconds": round(time.monotonic() - started, 1),
            })
            print(f"[FAIL] {spec.tool_id}: {result['error']}")
            results.append(result)
            if fail_on_error:
                status_path = dist_dir / "tool_build_status.json"
                status_path.write_text(json.dumps({"tools": results}, indent=2), encoding="utf-8")
                raise
            continue
        results.append(result)

    report = {
        "schema": "insightec.hub.integrated-tool-build.v1",
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "all_ready": all(item["status"] == "ready" for item in results) and len(results) == len(TOOLS),
        "tools": results,
    }
    status_path = dist_dir / "tool_build_status.json"
    status_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    if not report["all_ready"] and fail_on_error:
        raise RuntimeError("One or more integrated tools failed to build")
    return report


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: Build_Integrated_Tools.py SOURCE_ROOT DIST_DIR")
    build_integrated_tools(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
