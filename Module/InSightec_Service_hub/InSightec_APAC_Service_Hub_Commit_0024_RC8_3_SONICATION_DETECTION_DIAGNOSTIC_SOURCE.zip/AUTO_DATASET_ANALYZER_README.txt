InSightec APAC Auto Dataset Analyzer - Commit 0011

1. Select the tools to launch using the checkboxes.
2. The selection is saved and is not changed by dataset detection.
3. Drop a ZIP, folder, or files. Inspection starts automatically.
4. With Auto launch after drop enabled, only selected tools with compatible data are launched.
5. Disable Auto launch to review results first, then use Open Selected Tools.
6. Each tool receives a handoff JSON through --handoff and INSIGHTEC_HANDOFF.
7. Guide and guided-tour functions are not included.
