InSightec APAC Service Hub Help Resources

The guided tour system is intentionally disabled in Release Mode.
This directory is retained because the Hub runtime and source validator expect a help resource root.
Operational help is provided through the standard Help menu and packaged documentation.
