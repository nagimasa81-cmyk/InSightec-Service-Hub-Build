from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


@dataclass(frozen=True)
class ToolBuild:
    tool_id: str
    source_dir: str
    target_dir: str
    build_script: str
    output_candidates: tuple[str, ...]
    target_exe: str
    copy_directory: str | None = None


TOOLS: tuple[ToolBuild, ...] = (
    ToolBuild(
        "do_analysis", "DOAnalysis", "DOanalysis", "build_exe.bat",
        ("dist/DO Analysis Qt.exe", "dist/DO Analysis Qt Ver1.0.1.exe"),
        "DO Analysis Qt Ver1.0.1.exe",
    ),
    ToolBuild(
        "tracker_snr", "TrackerSNR", "TrackerSNR", "00_BUILD_EXE_RECOMMENDED_PYINSTALLER.bat",
        ("dist/TrackerSNR_CLEAN_EXE.exe",), "TrackerSNR_CLEAN_EXE.exe",
    ),
    ToolBuild(
        "log_explorer", "LogExplorer", "LogExplorer", "01_BUILD_EXE_GITHUB.bat",
        ("dist/LogMergeTool_RC1_Commit0067.exe", "dist/LogMergeTool_NoExcel.exe"),
        "LogMergeTool_NoExcel.exe",
    ),
    ToolBuild(
        "sonication_analysis", "SonicationAnalysis", "SonicationAnalysis", "01_BUILD_EXE_NUITKA.bat",
        ("dist/Sonication_Replay_Engine.exe",), "Sonication_Replay_Engine.exe",
    ),
    ToolBuild(
        "fus_image_explore", "FUSImageExplore", "FUSImageExplore", "02_BUILD_EXE_NUITKA.bat",
        ("MRI_Raw_FFT_Explorer_Nuitka_Windows/MRI_Raw_FFT_Explorer.exe",),
        "MR_Image_Explorer_RC1.exe", copy_directory="MRI_Raw_FFT_Explorer_Nuitka_Windows",
    ),
    ToolBuild(
        "vimeasure", "VIMeasure", "VIMeasure", "01_BUILD_EXE_NUITKA.bat",
        ("dist/VIMeasureAnalyzer.exe",), "VIMeasureAnalyzer.exe",
    ),
)


def stream_command(command: list[str], cwd: Path, log_path: Path) -> int:
    env = os.environ.copy()
    env["CI"] = "true"
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    printable = subprocess.list2cmdline(command)
    print(f"[RUN] {printable}")
    with log_path.open("a", encoding="utf-8", errors="replace") as log:
        log.write(f"\n[RUN] {printable}\n")
        process = subprocess.Popen(
            command,
            cwd=str(cwd),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="")
            log.write(line)
        return process.wait()


def first_existing(root: Path, candidates: tuple[str, ...]) -> Path | None:
    for relative in candidates:
        candidate = root / Path(relative)
        if candidate.is_file():
            return candidate
    return None


def copy_tool_result(spec: ToolBuild, source_root: Path, tools_root: Path) -> Path:
    destination = tools_root / spec.target_dir
    destination.mkdir(parents=True, exist_ok=True)

    # Preserve the manifest and documentation copied by the Hub packager, while
    # replacing stale binaries/runtime folders from previous builds.
    for child in list(destination.iterdir()):
        if child.name.lower() in {"manifest.json", "readme.txt", "release_notes.md"}:
            continue
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()

    source_dir = source_root / "integrated_sources" / spec.source_dir
    built_exe = first_existing(source_dir, spec.output_candidates)
    if built_exe is None:
        raise FileNotFoundError(
            f"{spec.tool_id}: build completed but no expected EXE was found. "
            f"Checked: {', '.join(spec.output_candidates)}"
        )

    if spec.copy_directory:
        runtime_dir = source_dir / spec.copy_directory
        if not runtime_dir.is_dir():
            raise FileNotFoundError(f"{spec.tool_id}: runtime directory not found: {runtime_dir}")
        for item in runtime_dir.iterdir():
            target = destination / item.name
            if item.is_dir():
                shutil.copytree(item, target, dirs_exist_ok=True)
            else:
                shutil.copy2(item, target)
        copied_exe = destination / built_exe.name
        target_exe = destination / spec.target_exe
        if copied_exe.resolve() != target_exe.resolve():
            if target_exe.exists():
                target_exe.unlink()
            copied_exe.rename(target_exe)
    else:
        target_exe = destination / spec.target_exe
        shutil.copy2(built_exe, target_exe)

    if not target_exe.is_file() or target_exe.stat().st_size < 100_000:
        raise RuntimeError(f"{spec.tool_id}: packaged EXE is missing or unexpectedly small: {target_exe}")
    return target_exe


def build_integrated_tools(source_root: Path, dist_dir: Path, fail_on_error: bool = True) -> dict:
    tools_root = dist_dir / "tools"
    tools_root.mkdir(parents=True, exist_ok=True)
    log_root = source_root / "build_logs" / "integrated_tools"
    log_root.mkdir(parents=True, exist_ok=True)

    results: list[dict] = []
    for index, spec in enumerate(TOOLS, start=1):
        started = time.monotonic()
        source_dir = source_root / "integrated_sources" / spec.source_dir
        build_script = source_dir / spec.build_script
        result = {
            "tool_id": spec.tool_id,
            "source_dir": str(source_dir),
            "build_script": spec.build_script,
            "status": "failed",
        }
        print("\n" + "=" * 72)
        print(f"Integrated tool {index}/{len(TOOLS)}: {spec.tool_id}")
        print("=" * 72)
        try:
            if os.name != "nt":
                raise RuntimeError("Integrated EXE builds require a Windows runner")
            if not build_script.is_file():
                raise FileNotFoundError(f"Build script not found: {build_script}")
            log_path = log_root / f"{spec.tool_id}_{datetime.now():%Y%m%d_%H%M%S}.log"
            rc = stream_command(["cmd.exe", "/d", "/s", "/c", "call", str(build_script)], source_dir, log_path)
            if rc != 0:
                raise RuntimeError(f"Build script exited with code {rc}. See {log_path}")
            target_exe = copy_tool_result(spec, source_root, tools_root)
            result.update({
                "status": "ready",
                "target_exe": str(target_exe.relative_to(dist_dir)),
                "size_bytes": target_exe.stat().st_size,
                "elapsed_seconds": round(time.monotonic() - started, 1),
                "log": str(log_path),
            })
            print(f"[PASS] {spec.tool_id}: {target_exe}")
        except Exception as exc:
            result.update({
                "error": f"{type(exc).__name__}: {exc}",
                "elapsed_seconds": round(time.monotonic() - started, 1),
            })
            print(f"[FAIL] {spec.tool_id}: {result['error']}")
            results.append(result)
            if fail_on_error:
                status_path = dist_dir / "tool_build_status.json"
                status_path.write_text(json.dumps({"tools": results}, indent=2), encoding="utf-8")
                raise
            continue
        results.append(result)

    report = {
        "schema": "insightec.hub.integrated-tool-build.v1",
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "all_ready": all(item["status"] == "ready" for item in results) and len(results) == len(TOOLS),
        "tools": results,
    }
    status_path = dist_dir / "tool_build_status.json"
    status_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    if not report["all_ready"] and fail_on_error:
        raise RuntimeError("One or more integrated tools failed to build")
    return report


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: Build_Integrated_Tools.py SOURCE_ROOT DIST_DIR")
    build_integrated_tools(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
