# Commit 0023 — RC8.1 Sonication EXE Alias Compatibility

- Added `acceptable_executables` support to tool manifests.
- Sonication Analysis accepts `Sonication_Replay_Engine.exe`, `SonicationAnalysis.exe`, `Sonication_Analysis.exe`, and the legacy spaced filename.
- Executable discovery is case-insensitive and searches subfolders recursively.
- Auto Dataset Analyzer and normal tool launch use the same resolver.
