# Commit 0024 — Sonication EXE Detection Diagnostics

- Does not change executable selection behavior.
- Records Hub RUN_DIR and the exact resolved SonicationAnalysis folder.
- Records manifest path, configured EXE, aliases and every discovered EXE.
- Records each candidate score and the final selected path.
- Writes JSON report to `logs/tool_detection_sonication_analysis.json`.
- Adds the same diagnostic location to Auto Dataset Analyzer details.

This commit is intended to identify why an existing `Sonication_Replay_Engine.exe` is shown as Missing EXE before applying another behavioral fix.
