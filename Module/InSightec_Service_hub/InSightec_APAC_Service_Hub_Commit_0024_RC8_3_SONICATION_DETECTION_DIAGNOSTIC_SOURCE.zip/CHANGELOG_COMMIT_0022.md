# Commit 0022 - RC7.4 Deterministic Source Validation

- Restored the required `help/` runtime resource root without reintroducing Guide/Tour.
- Added `help/README_HELP.txt` as a packaged non-interactive help resource.
- Updated build contract to version 10 and release sequence 22.
- Declared required runtime directories and `validate_source.py` in the build contract.
- RC7.4 runs source validators during global preflight before compilation.
