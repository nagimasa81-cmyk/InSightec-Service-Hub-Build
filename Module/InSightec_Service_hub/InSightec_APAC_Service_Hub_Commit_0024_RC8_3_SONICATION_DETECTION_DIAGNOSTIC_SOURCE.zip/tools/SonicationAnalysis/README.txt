Place SonicationAnalysis.exe in this folder. The Hub passes --handoff <json path> when compatible data is detected.
