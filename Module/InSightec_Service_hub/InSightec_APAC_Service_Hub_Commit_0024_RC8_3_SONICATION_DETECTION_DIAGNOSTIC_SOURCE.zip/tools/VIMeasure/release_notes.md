# VIMeasure 7.1.0

- Native `--handoff` and `INSIGHTEC_HANDOFF` receiver.
- Automatically loads compatible files supplied by the Hub.
- Dataset recognition uses file content instead of requiring `VIMeasure` in the filename.
- Accepts files, folders, and shared extracted workspaces.
- Guide and tour features are not included.
