VIMeasure runtime package. Keep VIMeasureAnalyzer.exe and manifest.json in this folder.
