@echo off
cd /d %~dp0
python -m builder.build_cli --target platform
if errorlevel 1 (
	echo.
	echo ============================================
	echo BUILD FAILED
	echo ============================================
	type "%LOGFILE%"
	exit /b 1
pause
