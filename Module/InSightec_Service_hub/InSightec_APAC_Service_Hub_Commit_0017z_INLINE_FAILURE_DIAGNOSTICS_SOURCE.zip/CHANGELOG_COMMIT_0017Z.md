# Commit 0017z — Transparent Tool Failure Diagnostics

Module BAT/bootstrap failures now print diagnostic contexts and the final 220 log lines directly to GitHub Actions before raising.
