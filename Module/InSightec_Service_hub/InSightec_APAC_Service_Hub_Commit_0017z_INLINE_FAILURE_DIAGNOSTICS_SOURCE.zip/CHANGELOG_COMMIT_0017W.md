# Commit 0017w — Contract-driven latest module integration
- Removes dependency on hard-coded build script names for overlaid modules.
- `Overlay_Latest_Modules.py` discovers the newest valid SOURCE from each Module folder.
- The SOURCE root is derived from `insightec_build_contract.json`.
- Nested package roots such as Soni/VIMeasure are normalized into Hub integrated_sources.
- Build_Integrated_Tools uses the contract-declared build script when available.
- Smart signature reuse / true force rebuild from 0017v is retained.
