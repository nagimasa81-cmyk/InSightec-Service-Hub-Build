# Commit 0017v — Smart Incremental Build Policy

- A module runtime cache is reusable only when:
  - the source/build signature is an exact match,
  - cache metadata says `build_status=success`,
  - the expected EXE exists and is at least 100 KB.
- `INSIGHTEC_FORCE_TOOL_REBUILD=1` bypasses the internal module cache.
- This makes a newly added/changed SOURCE build automatically when no successful
  build exists for that exact signature.
