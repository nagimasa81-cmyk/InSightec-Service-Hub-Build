# Commit 0017y — VIMeasure Dependency Bootstrap

Observed GitHub failure:
`ModuleNotFoundError: No module named 'PySide6'`

The latest VIMeasure SOURCE was selected correctly and its module BAT was executed,
but that BAT assumed PySide6 was already installed.

Fix:
- Hub common integrated-tool builder bootstraps VIMeasure build dependencies before
  executing the module-owned BAT.
- On Windows it uses `py -3.13` when available, matching current/legacy VIMeasure BATs.
- Installs/upgrades PySide6, Nuitka, ordered-set and zstandard.
- Probes PySide6 QtCore/QtGui/QtWidgets/QtCharts and Nuitka before the heavy build.
- Bootstrap failure is fail-fast and logged separately.
