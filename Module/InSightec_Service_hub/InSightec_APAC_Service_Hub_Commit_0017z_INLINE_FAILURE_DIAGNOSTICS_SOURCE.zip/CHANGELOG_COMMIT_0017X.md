# Commit 0017x — Flexible Contract Compatibility

- Accept heterogeneous/nested `insightec_build_contract.json` schemas.
- Recursively resolve build script and entry point declarations.
- If a valid contract exists but script keys differ, discover the actual build BAT/CMD
  under the contract source root using deterministic build-script precedence.
- Apply the same resolver to latest-module overlay and actual integrated-tool build.
- Remove historical FUS/Soni/Log BAT-name checks from Fast_Preflight_All_Tools.py.
