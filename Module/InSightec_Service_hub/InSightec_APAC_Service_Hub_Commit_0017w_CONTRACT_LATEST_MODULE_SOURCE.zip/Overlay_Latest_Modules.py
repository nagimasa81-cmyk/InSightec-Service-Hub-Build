\
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


MAPPING = {
    "DO_Analysis": "DOAnalysis",
    "trackerSNR": "TrackerSNR",
    "Log_explorer": "LogExplorer",
    "Soni": "SonicationAnalysis",
    "FFT": "FUSImageExplore",
    "VIMeasure": "VIMeasure",
}


def natural_key(name: str):
    parts = re.split(r"(\d+)", name.lower())
    return tuple((1, int(p)) if p.isdigit() else (0, p) for p in parts)


def git_last_change(repo: Path, path: Path) -> int:
    try:
        rel = path.relative_to(repo).as_posix()
        cp = subprocess.run(
            ["git", "log", "-1", "--format=%ct", "--", rel],
            cwd=repo, text=True, capture_output=True, check=False,
        )
        raw = cp.stdout.strip()
        return int(raw) if raw.isdigit() else 0
    except Exception:
        return 0


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def contract_candidates_in_zip(path: Path):
    try:
        with zipfile.ZipFile(path, "r") as z:
            if z.testzip():
                return []
            names = [n.replace("\\", "/") for n in z.namelist()]
            out = []
            for name in names:
                if not name.lower().endswith("insightec_build_contract.json"):
                    continue
                try:
                    data = json.loads(z.read(name).decode("utf-8-sig"))
                except Exception:
                    continue
                root = name[:-len("insightec_build_contract.json")]
                out.append((root, data))
            return out
    except Exception:
        return []


def _declared_values(contract: dict):
    build = str(
        contract.get("build_script")
        or contract.get("builder")
        or contract.get("build_bat")
        or ""
    ).strip().replace("\\", "/")
    entry = str(contract.get("entry_point") or contract.get("entry") or "").strip().replace("\\", "/")
    return build, entry


def _exists_under(names: set[str], root: str, declared: str) -> bool:
    if not declared:
        return True
    basename = Path(declared).name
    probes = {
        root + declared,
        root + basename,
        declared,
    }
    if probes & names:
        return True
    return any(n.startswith(root) and n.endswith("/" + basename) for n in names)


def choose_contract_root(path: Path):
    """Choose a contract root whose declared build script/entry point exist."""
    try:
        with zipfile.ZipFile(path, "r") as z:
            if z.testzip():
                return None
            names = {n.replace("\\", "/") for n in z.namelist()}
            viable = []
            for root, contract in contract_candidates_in_zip(path):
                build, entry = _declared_values(contract)
                if not build:
                    continue
                if not _exists_under(names, root, build):
                    continue
                if entry and not _exists_under(names, root, entry):
                    continue
                viable.append((root, contract))
            if not viable:
                return None
            viable.sort(key=lambda x: (len(x[0].split("/")) if x[0] else 0, len(x[0]), x[0]))
            return viable[0]
    except Exception:
        return None


def extract_contract_root(zip_path: Path, root: str, destination: Path):
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as z:
        plen = len(root)
        for info in z.infolist():
            name = info.filename.replace("\\", "/")
            if root and not name.startswith(root):
                continue
            relative = name[plen:] if root else name
            if not relative:
                continue
            dest = destination / relative
            if info.is_dir():
                dest.mkdir(parents=True, exist_ok=True)
            else:
                dest.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as src, dest.open("wb") as dst:
                    shutil.copyfileobj(src, dst)


def reconstruct(parts: list[Path], output: Path) -> bool:
    numbered = []
    for p in parts:
        marker = p.name.lower().rfind(".zip.part")
        if marker < 0:
            continue
        suffix = p.name[marker + len(".zip.part"):]
        if suffix.isdigit():
            numbered.append((int(suffix), p))
    numbered.sort()
    if not numbered or [n for n, _ in numbered] != list(range(1, len(numbered)+1)):
        return False
    with output.open("wb") as out:
        for _, p in numbered:
            with p.open("rb") as inp:
                shutil.copyfileobj(inp, out)
    return True


def candidates(repo: Path, module_dir: Path, scratch: Path):
    found = []
    # Normal SOURCE ZIPs.
    for p in module_dir.glob("*.zip"):
        if "SOURCE" not in p.name.upper():
            continue
        chosen = choose_contract_root(p)
        if chosen is not None:
            root, contract = chosen
            found.append({
                "path": p, "root": root, "contract": contract,
                "display": p.name, "git_change": git_last_change(repo, p),
                "kind": "normal",
            })

    # Loose split.
    groups = {}
    for p in module_dir.glob("*.zip.part*"):
        idx = p.name.lower().rfind(".zip.part")
        if idx < 0:
            continue
        source_name = p.name[:idx+4]
        groups.setdefault(source_name, []).append(p)
    for source_name, parts in groups.items():
        rebuilt = scratch / ("loose_" + re.sub(r"[^A-Za-z0-9_.-]", "_", source_name))
        if reconstruct(parts, rebuilt):
            chosen = choose_contract_root(rebuilt)
            if chosen is not None:
                root, contract = chosen
                # Git timestamp = newest committed part.
                g = max((git_last_change(repo, p) for p in parts), default=0)
                found.append({
                    "path": rebuilt, "root": root, "contract": contract,
                    "display": source_name, "git_change": g, "kind": "loose",
                })

    # Packaged split ZIP.
    for outer in module_dir.glob("*.zip"):
        try:
            with zipfile.ZipFile(outer, "r") as z:
                names = [n.replace("\\", "/") for n in z.namelist()]
                if not any(".zip.part" in n.lower() for n in names):
                    continue
                pkg = scratch / ("pkg_" + re.sub(r"[^A-Za-z0-9_.-]", "_", outer.stem))
                pkg.mkdir(parents=True, exist_ok=True)
                z.extractall(pkg)
        except Exception:
            continue
        groups2 = {}
        for p in pkg.rglob("*.zip.part*"):
            idx = p.name.lower().rfind(".zip.part")
            if idx < 0:
                continue
            source_name = p.name[:idx+4]
            groups2.setdefault(source_name, []).append(p)
        for source_name, parts in groups2.items():
            rebuilt = scratch / ("packaged_" + re.sub(r"[^A-Za-z0-9_.-]", "_", outer.stem+"_"+source_name))
            if reconstruct(parts, rebuilt):
                chosen = choose_contract_root(rebuilt)
                if chosen is not None:
                    root, contract = chosen
                    found.append({
                        "path": rebuilt, "root": root, "contract": contract,
                        "display": source_name, "git_change": git_last_change(repo, outer),
                        "kind": f"packaged:{outer.name}",
                    })
    return found


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo-root", default=".")
    ap.add_argument("--hub-root", required=True)
    ap.add_argument("--include-sonication", default="true")
    ap.add_argument("--report", default="")
    ns = ap.parse_args()

    repo = Path(ns.repo_root).resolve()
    hub = Path(ns.hub_root).resolve()
    include_soni = str(ns.include_sonication).lower() == "true"
    report = {"schema": "insightec.latest-module-overlay.v2", "modules": []}

    with tempfile.TemporaryDirectory() as td:
        scratch = Path(td)
        for module_name, integrated_name in MAPPING.items():
            if module_name == "Soni" and not include_soni:
                print("[OVERLAY SKIP] Soni excluded")
                report["modules"].append({"module": module_name, "status": "skipped"})
                continue

            module_dir = repo / "Module" / module_name
            if not module_dir.is_dir():
                raise SystemExit(f"Module folder missing: {module_dir}")

            found = candidates(repo, module_dir, scratch)
            if not found:
                raise SystemExit(
                    f"No valid contract-based SOURCE for {module_name}. "
                    "A valid SOURCE must contain insightec_build_contract.json and its declared build script."
                )

            found.sort(
                key=lambda x: (x["git_change"], natural_key(x["display"])),
                reverse=True,
            )
            chosen = found[0]
            destination = hub / "integrated_sources" / integrated_name
            extract_contract_root(chosen["path"], chosen["root"], destination)

            # Contract must now be present at/under normalized destination.
            contract_files = list(destination.rglob("insightec_build_contract.json"))
            if not contract_files:
                raise SystemExit(f"Overlay contract missing after extraction: {module_name}")

            build, entry = _declared_values(chosen["contract"])
            print("="*72)
            print(f"[LATEST MODULE] {module_name}")
            print(f"  selected        : {chosen['display']}")
            print(f"  kind            : {chosen['kind']}")
            print(f"  git change      : {chosen['git_change']}")
            print(f"  contract root   : {chosen['root'] or '<zip-root>'}")
            print(f"  contract build  : {build}")
            print(f"  contract entry  : {entry}")
            print(f"  overlay target  : {destination}")
            print(f"  candidates      : {len(found)}")
            print("="*72)

            report["modules"].append({
                "module": module_name,
                "integrated_source": integrated_name,
                "status": "overlaid",
                "selected": chosen["display"],
                "kind": chosen["kind"],
                "git_change": chosen["git_change"],
                "contract_root": chosen["root"],
                "contract_build_script": build,
                "contract_entry_point": entry,
                "sha256": sha256_file(chosen["path"]),
                "candidate_count": len(found),
            })

    report_path = Path(ns.report) if ns.report else hub / "latest_module_overlay.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[PASS] Contract-driven latest module overlay complete: {report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
