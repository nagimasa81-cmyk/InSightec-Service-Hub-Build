# Commit 0025 — RC8.5 All-Tool Detection Trace

- Adds ENTER/EXIT executable detection tracing for every tool in Auto Dataset Analyzer.
- Writes `logs/tool_detection_all_tools.json`.
- Logs resolved folder, manifest, candidates, selected EXE, validation result and failure detail.
- Fixes the stale `tool` loop variable that caused the Sonication details section to output VIMeasure diagnostics.
- Does not change executable selection priority.
