"""Repository preflight compatibility shim.

The canonical Service Hub build entry remains InSightecServiceHub.py.
Build_Hub_EXE.py does not use this file.
"""

from InSightecServiceHub import main

if __name__ == "__main__":
    main()
