# Commit 0017t — Tool ZIP Install Uses Shared Password-Aware Extractor

Change request: apply the same ZIP Drop password behavior (introduced in
commit 0017s) to the manual "Select ZIP for <tool>" install dialog.

Changes:
- `install_tool_zip` no longer calls `zipfile.ZipFile(...).extractall()`
  directly. It now calls `self._safe_extract_zip(zip_path, folder)`, the
  same helper used by the Tools dataset drop zone.
- Effect: installing a tool from an encrypted ZIP now automatically tries
  the configured ZIP Drop password (ZipCrypto via stdlib `zipfile`, AES via
  `pyzipper` if available and if `zipfile` reports `NotImplementedError`).
  If the password does not match, or the encryption is unsupported, the
  install stops with an error dialog and nothing is extracted into the
  tool's folder.
- No UI change: the file picker and success/warning/error dialogs behave as
  before; only the extraction step underneath changed.

Not changed in this commit:
- The Upgrade ZIP installer (`upgrade_manifest.json` flow) still uses plain
  `zipfile.ZipFile(...).extractall()` without password handling.
