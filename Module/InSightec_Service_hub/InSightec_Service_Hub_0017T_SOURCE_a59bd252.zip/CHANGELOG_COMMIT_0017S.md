# Commit 0017s — ZIP Drop Auto-Unlock Password

Change request: dataset ZIPs dropped or selected in the Tools drop zone may
be password-protected. Attempt the configured ZIP Drop password automatically;
if it does not open the archive, stop without extracting.

Changes:
- `_safe_extract_zip` now detects encrypted entries (`flag_bits & 0x1`) before
  extracting.
- Standard ZipCrypto-encrypted ZIPs are opened via the stdlib `zipfile` using
  the configured password.
- WinZip/7-Zip AES-encrypted ZIPs (`NotImplementedError` from `zipfile`) fall
  back to `pyzipper.AESZipFile` with the same configured password, when the
  `pyzipper` package is available in the build.
- If the password is wrong, or the archive uses an encryption scheme neither
  library can read, extraction stops immediately with a clear error; no
  partial extraction is written.
- The password is **not hardcoded**. `ensure_zip_drop_password()` seeds
  `cfg['zip_drop_password']` with a default (`clinicalopt`) only on first run.
  From then on the effective password always comes from `config.json`, and it
  is editable any time from Settings > "ZIP Drop Password" (masked entry).
- Added `pyzipper>=0.3.6` to `requirements-build.txt` so PyInstaller bundles
  it into the frozen EXE automatically (same pattern as `tkinterdnd2`).
- Added `zip_drop_password` / `zip_drop_password_note` translations for
  en / ja / es / ko / zh_TW.

Not changed in this commit:
- `install_tool_zip` (manual tool-ZIP install dialog) and the Upgrade ZIP
  installer still use plain `zipfile.ZipFile(...).extractall()` without
  password handling. Can be aligned to the same behavior on request.
