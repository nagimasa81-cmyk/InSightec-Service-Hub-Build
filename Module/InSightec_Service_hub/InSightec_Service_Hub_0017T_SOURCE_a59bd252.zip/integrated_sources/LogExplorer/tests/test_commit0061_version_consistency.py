from pathlib import Path
import json, re
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'LogMergeTool_NoExcel_Main.py').read_text(encoding='utf-8-sig')
meta=json.loads((ROOT/'version.json').read_text(encoding='utf-8-sig'))
versions=set(re.findall(r'^APP_VERSION\s*=\s*"([^"]+)"', source, flags=re.MULTILINE))
assert versions == {meta['version']}, versions
assert 'def _c60_set_quick_filter' in source
assert 'MultiPaneLogViewer.build_ui = _c60_build_ui' in source
print('Commit0061 retained-feature/current-version contract: PASS')
