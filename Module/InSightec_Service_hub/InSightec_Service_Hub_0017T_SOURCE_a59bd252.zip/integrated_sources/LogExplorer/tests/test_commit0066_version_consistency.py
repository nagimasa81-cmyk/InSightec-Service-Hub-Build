from pathlib import Path
import json, re
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'LogMergeTool_NoExcel_Main.py').read_text(encoding='utf-8-sig')
meta=json.loads((ROOT/'version.json').read_text(encoding='utf-8-sig'))
versions=set(re.findall(r'^APP_VERSION\s*=\s*"([^"]+)"', source, flags=re.MULTILINE))
assert versions == {meta['version']}, versions
assert 'def _c66_start_import_clicked' in source
assert 'MainWindow.start_import_clicked = _c66_start_import_clicked' in source
assert 'Configure the Viewer and press LOAD LOGS' in source
print('Commit0066 retained-feature/current-version contract: PASS')
