from __future__ import annotations
import json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
meta=json.loads((ROOT/'version.json').read_text(encoding='utf-8-sig'))
source=(ROOT/'LogMergeTool_NoExcel_Main.py').read_text(encoding='utf-8-sig')
versions=set(re.findall(r'^APP_VERSION\s*=\s*"([^"]+)"',source,flags=re.MULTILINE))
assert versions == {meta['version']}, (versions, meta['version'])
assert meta['commit'].lower() in meta['version'].lower(), (meta['commit'],meta['version'])
assert meta['artifact_base_name'].startswith('LogMergeTool_RC1_'), meta['artifact_base_name']
for name in ('01_BUILD_EXE_GITHUB.bat','01_BUILD_EXE_NUITKA.bat'):
    bat=(ROOT/name).read_text(encoding='utf-8-sig')
    assert 'build_metadata.py --write-bat' in bat, name
    assert 'test_current_version_contract.py' in bat or name=='01_BUILD_EXE_NUITKA.bat', name
print('Current Log Explorer version contract: PASS')
