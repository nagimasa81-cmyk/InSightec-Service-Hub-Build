from pathlib import Path
import json, re
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'LogMergeTool_NoExcel_Main.py').read_text(encoding='utf-8-sig')
meta=json.loads((ROOT/'version.json').read_text(encoding='utf-8-sig'))
versions=set(re.findall(r'^APP_VERSION\s*=\s*"([^"]+)"', source, flags=re.MULTILINE))
assert versions == {meta['version']}, versions
assert '_C65UnifiedProgressProxy' in source
assert '_c65_shared_progress' in source
print('Commit0065 retained-feature/current-version contract: PASS')
