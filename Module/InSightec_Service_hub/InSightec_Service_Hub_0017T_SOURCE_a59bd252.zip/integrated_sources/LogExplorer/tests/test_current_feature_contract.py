from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'LogMergeTool_NoExcel_Main.py').read_text(encoding='utf-8-sig')
required=[
    '# Commit0069: current workflow guide and daily source/output reset',
    '_C69_LAST_LAUNCH_DATE_KEY',
    'QTimer.singleShot(150, lambda: _apply_insightec_handoff(self))',
    'self.source_edit.clear()',
    'self.output_edit.clear()',
    'def _insightec_handoff_payload',
    'def _apply_insightec_handoff',
    'MainWindow.__init__ = _c69_main_init',
    'MainWindow.start_import_clicked = _c67_start_import_clicked',
]
for token in required:
    assert token in source, token
assert source.count('if __name__ == "__main__":') == 1
print('Current Log Explorer feature contract: PASS')
