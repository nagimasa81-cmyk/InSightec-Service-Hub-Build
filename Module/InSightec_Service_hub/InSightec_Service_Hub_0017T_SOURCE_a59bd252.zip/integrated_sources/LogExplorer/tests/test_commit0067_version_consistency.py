from pathlib import Path
import json, re
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'LogMergeTool_NoExcel_Main.py').read_text(encoding='utf-8-sig')
meta=json.loads((ROOT/'version.json').read_text(encoding='utf-8-sig'))
versions=set(re.findall(r'^APP_VERSION\s*=\s*"([^"]+)"', source, flags=re.MULTILINE))
assert versions == {meta['version']}, versions
assert 'def _c67_prepare_discovery_options' in source
assert '_safe_extract_zip_for_discovery(source)' in source
assert 'MainWindow.start_import_clicked = _c67_start_import_clicked' in source
assert 'opt.source_folder = str(extract_root)' in source
print('Commit0067 retained-feature/current-version contract: PASS')
