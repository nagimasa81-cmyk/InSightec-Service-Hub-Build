InSightec Service Hub MVP

Run standalone IB Console:
  python run_ib_console.py

Run Service Hub Launcher:
  python run_service_hub.py

Create sample data:
  python tools/seed_sample_data.py

Main features included:
- SQLite DB schema v2
- Launcher + manifest module loader
- IB Database Console
- System/Asset search
- System detail
- Inspection schedule input
- Part replacement input
- Inspection record input
- Documents tab
- Attachments tab
- Timeline tab
- Update Center zip import

Notes:
- Requires Python with PySide6 installed.
- Run commands from the project root folder.
