# Commit 0017ae — Contract / Result Resolution

- `build.file` in `insightec_build_contract.json` is authoritative.
- `build.expected_exe_patterns` and `build.output_directories` are consumed.
- Successful TrackerSNR/Log Explorer outputs are discovered recursively when
  module packages nest their `dist` directory.
- Cache schema advanced to v5.
