\
from __future__ import annotations

import ast
import json
import os
import sys
from pathlib import Path

from Build_Integrated_Tools import TOOLS, tool_is_enabled, validate_tool_source_contract


def parse_python_tree(root: Path) -> int:
    count = 0
    for path in root.rglob("*.py"):
        parts = {p.lower() for p in path.parts}
        if "__pycache__" in parts or ".venv" in parts or "build" in parts or "dist" in parts:
            continue
        ast.parse(path.read_text(encoding="utf-8-sig", errors="replace"), filename=str(path))
        count += 1
    return count


def require_text(path: Path, required: list[str], label: str) -> None:
    text = path.read_text(encoding="utf-8", errors="ignore")
    missing = [item for item in required if item not in text]
    if missing:
        raise RuntimeError(f"{label}: missing required contract markers: {missing}")


def main() -> int:
    root = Path(__file__).resolve().parent
    results = []

    parsed = parse_python_tree(root)
    print(f"[PASS] Python AST parse: {parsed} files")

    for spec in TOOLS:
        if not tool_is_enabled(spec):
            print(f"[SKIP] {spec.tool_id}: disabled by build selection")
            continue
        source = root / "integrated_sources" / spec.source_dir
        contract = validate_tool_source_contract(spec, source)

        # Contract-driven validation is authoritative for overlaid latest modules.
        # Do not require historical build-script filenames from older embedded snapshots.
        if spec.tool_id == "sonication_analysis":
            req_candidates = [
                p for p in source.rglob("requirements.txt")
                if not any(part.lower() in {".venv", "venv", "site-packages"} for part in p.parts)
            ]
            declared = "\n".join(
                p.read_text(encoding="utf-8-sig", errors="replace")
                for p in req_candidates
            ).lower()
            if "pytest" not in declared:
                raise RuntimeError("sonication_analysis: pytest is not declared after Hub build policy")
            print("[PASS] sonication_analysis: pytest build dependency declared")
            pytest_bats = []
            unguarded = []
            for bat in source.rglob("*.bat"):
                if any(part.lower() in {".venv", "venv", "site-packages"} for part in bat.parts):
                    continue
                bat_text = bat.read_text(encoding="utf-8-sig", errors="replace")
                if "-m pytest" in bat_text.lower():
                    pytest_bats.append(bat)
                    if "INSIGHTEC_HUB_PYTEST_GUARD_V2" not in bat_text:
                        unguarded.append(bat)
            if unguarded:
                raise RuntimeError("sonication_analysis: pytest BAT invocation lacks Hub interpreter guard: " + ", ".join(str(x.relative_to(source)) for x in unguarded))
            if pytest_bats:
                print(f"[PASS] sonication_analysis: pytest BAT guard present in {len(pytest_bats)} BAT(s)")

        print(f"[PASS] {spec.tool_id}: build contract + fast static preflight")
        results.append({"tool_id": spec.tool_id, "status": "pass", "contract": contract})

    report = {
        "schema": "insightec.fast-preflight.v1",
        "python_files_parsed": parsed,
        "enabled_tools": len(results),
        "tools": results,
    }
    out = root / "fast_preflight_report.json"
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[PASS] Fast preflight complete: {len(results)} enabled tool(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
