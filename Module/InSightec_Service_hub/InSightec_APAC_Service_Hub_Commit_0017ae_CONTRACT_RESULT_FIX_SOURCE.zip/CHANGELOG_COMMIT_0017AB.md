# Commit 0017ab — Cache Hardening

- Module cache schema bumped to v2.
- `.venv`, `venv`, `site-packages`, `.mypy_cache`, `.ruff_cache` are excluded from tool source signatures.
- Prevents stale v1 caches and environment-local files from causing false reuse/rebuild behavior.
