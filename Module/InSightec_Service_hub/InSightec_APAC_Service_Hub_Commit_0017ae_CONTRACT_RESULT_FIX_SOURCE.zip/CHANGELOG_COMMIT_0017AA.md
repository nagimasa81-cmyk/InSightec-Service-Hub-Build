# Commit 0017aa — Sonication Pytest Bootstrap

Creates/repairs Sonication's source-local .venv and installs pytest before the module BAT runs.
