# Commit 0017ac — Sonication Requirements Policy

The Hub overlay copy of Soni now ensures pytest>=8,<9 is present in requirements.txt before signatures and builds.
