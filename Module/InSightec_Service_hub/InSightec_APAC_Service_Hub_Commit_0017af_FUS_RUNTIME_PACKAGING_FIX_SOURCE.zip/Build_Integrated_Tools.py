from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


@dataclass(frozen=True)
class ToolBuild:
    tool_id: str
    source_dir: str
    target_dir: str
    build_script: str
    output_candidates: tuple[str, ...]
    target_exe: str
    copy_directory: str | None = None
    prefer_existing_runtime: bool = False


TOOLS: tuple[ToolBuild, ...] = (
    ToolBuild(
        "do_analysis", "DOAnalysis", "DOanalysis", "build_exe.bat",
        ("dist/DO Analysis Qt.exe", "dist/DO Analysis Qt Ver1.0.1.exe"),
        "DO Analysis Qt Ver1.0.1.exe",
    ),
    ToolBuild(
        "tracker_snr", "TrackerSNR", "TrackerSNR", "00_BUILD_EXE_RECOMMENDED_PYINSTALLER.bat",
        ("dist/TrackerSNR_CLEAN_EXE.exe",), "TrackerSNR_CLEAN_EXE.exe",
    ),
    ToolBuild(
        "log_explorer", "LogExplorer", "LogExplorer", "01_BUILD_EXE_GITHUB.bat",
        ("dist/LogMergeTool_NoExcel.exe",),
        "LogMergeTool_NoExcel.exe",
    ),
    ToolBuild(
        "sonication_analysis", "SonicationAnalysis", "SonicationAnalysis", "01_BUILD_EXE_NUITKA.bat",
        ("dist/Sonication_Replay_Engine.exe",), "Sonication_Replay_Engine.exe", prefer_existing_runtime=True,
    ),
    ToolBuild(
        "fus_image_explore", "FUSImageExplore", "FUSImageExplore", "02_BUILD_EXE_NUITKA.bat",
        ("MRI_Raw_FFT_Explorer_Nuitka_Windows/MRI_Raw_FFT_Explorer.exe",),
        "MR_Image_Explorer_RC1.exe", copy_directory="MRI_Raw_FFT_Explorer_Nuitka_Windows",
    ),
    ToolBuild(
        "vimeasure", "VIMeasure", "VIMeasure", "01_BUILD_EXE_NUITKA.bat",
        ("dist/VIMeasureAnalyzer.exe",), "VIMeasureAnalyzer.exe",
    ),
)


def stream_command(command: list[str], cwd: Path, log_path: Path) -> int:
    env = os.environ.copy()
    env["CI"] = "true"
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    printable = subprocess.list2cmdline(command)
    print(f"[RUN] {printable}")
    with log_path.open("a", encoding="utf-8", errors="replace") as log:
        log.write(f"\n[RUN] {printable}\n")
        process = subprocess.Popen(
            command,
            cwd=str(cwd),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="")
            log.write(line)
        return process.wait()


def print_failure_log_summary(log_path: Path, *, tail_lines: int = 220) -> None:
    """Print the real module failure directly into GitHub Actions output."""
    print("\n" + "!" * 78)
    print(f"[BUILD FAILURE LOG] {log_path}")
    print("!" * 78)
    if not log_path.is_file():
        print("[WARN] Failure log file does not exist.")
        print("!" * 78 + "\n")
        return
    try:
        lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception as exc:
        print(f"[WARN] Could not read failure log: {type(exc).__name__}: {exc}")
        print("!" * 78 + "\n")
        return
    keywords = (
        "traceback", "error", "fatal", "failed", "failure",
        "modulenotfounderror", "importerror", "assertionerror",
        "exception", "nuitka", "pytest", "no module named",
    )
    hits = [i for i, line in enumerate(lines) if any(k in line.lower() for k in keywords)]
    if hits:
        print("[DIAGNOSTIC CONTEXT]")
        selected = set()
        for idx in hits[-12:]:
            selected.update(range(max(0, idx-2), min(len(lines), idx+4)))
        for idx in sorted(selected):
            print(f"{idx+1:05d}: {lines[idx]}")
    tail = min(tail_lines, len(lines))
    print(f"\n[LAST {tail} LOG LINES]")
    start = max(0, len(lines)-tail_lines)
    for idx in range(start, len(lines)):
        print(f"{idx+1:05d}: {lines[idx]}")
    print("!" * 78 + "\n")


def metadata_output_candidates(source_dir: Path) -> tuple[str, ...]:
    path = source_dir / "version.json"
    if not path.is_file():
        return ()
    try:
        meta = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return ()
    names: list[str] = []
    for key in ("exe_name", "executable"):
        value = str(meta.get(key) or "").strip()
        if value:
            names.append(value if value.lower().endswith(".exe") else value + ".exe")
    artifact = str(meta.get("artifact_base_name") or "").strip()
    if artifact:
        names.append(artifact if artifact.lower().endswith(".exe") else artifact + ".exe")
    out: list[str] = []
    for name in names:
        for prefix in ("dist", "."):
            rel = f"{prefix}/{name}" if prefix != "." else name
            if rel not in out:
                out.append(rel)
    return tuple(out)



def load_effective_build_contract(source_dir: Path) -> tuple[Path | None, dict]:
    """Load the nearest build contract from an overlaid module source."""
    candidates = sorted(
        source_dir.rglob("insightec_build_contract.json"),
        key=lambda p: (len(p.relative_to(source_dir).parts), p.as_posix().lower()),
    )
    for path in candidates:
        try:
            data = json.loads(path.read_text(encoding="utf-8-sig"))
        except Exception:
            continue
        if isinstance(data, dict):
            return path, data
    return None, {}


def _recursive_contract_value(obj, preferred_keys: tuple[str, ...]) -> str:
    if isinstance(obj, dict):
        lowered = {str(k).lower(): v for k, v in obj.items()}
        for key in preferred_keys:
            value = lowered.get(key.lower())
            if isinstance(value, str) and value.strip():
                return value.strip().replace("\\", "/")
        for value in obj.values():
            found = _recursive_contract_value(value, preferred_keys)
            if found:
                return found
    elif isinstance(obj, list):
        for value in obj:
            found = _recursive_contract_value(value, preferred_keys)
            if found:
                return found
    return ""


def _discover_build_script(source_dir: Path, contract_path: Path | None) -> Path | None:
    root = contract_path.parent if contract_path is not None else source_dir
    candidates = [p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in {".bat", ".cmd"}]

    def rank(path: Path):
        base = path.name.lower()
        score = 100
        if base == "build_exe.bat":
            score = 0
        elif base.startswith("00_build_exe"):
            score = 1
        elif base.startswith("01_build_exe"):
            score = 2
        elif base.startswith("02_build_exe"):
            score = 3
        elif "build_exe" in base:
            score = 4
        elif "build" in base:
            score = 10
        return (score, len(path.relative_to(root).parts), path.as_posix().lower())

    if not candidates:
        return None
    candidates.sort(key=rank)
    return candidates[0]


def _discover_entry_point(source_dir: Path, contract_path: Path | None) -> Path | None:
    root = contract_path.parent if contract_path is not None else source_dir
    preferred = (
        "main.py", "launcher.py", "app.py", "do_analysis_qt_app.py",
        "TrackerSNR_CLEAN_EXE.py", "LogMergeTool_NoExcel_Main.py",
        "VIMeasureAnalyzer.py",
    )
    files = [p for p in root.rglob("*.py") if p.is_file()]
    by_base = {p.name.lower(): p for p in files}
    for name in preferred:
        if name.lower() in by_base:
            return by_base[name.lower()]
    return None


def _resolve_contract_path(source_dir: Path, contract_path: Path | None, declared: str) -> Path | None:
    declared = str(declared or "").strip().replace("\\", "/")
    if not declared:
        return None
    probes: list[Path] = []
    probes.append(source_dir / declared)
    if contract_path is not None:
        probes.append(contract_path.parent / declared)
        probes.append(contract_path.parent / Path(declared).name)
    probes.append(source_dir / Path(declared).name)
    for probe in probes:
        if probe.is_file():
            return probe
    matches = [
        p for p in source_dir.rglob(Path(declared).name)
        if p.is_file()
    ]
    if len(matches) == 1:
        return matches[0]
    return None


def _contract_build_section(contract: dict) -> dict:
    build = contract.get("build")
    return build if isinstance(build, dict) else {}


def _contract_declared_build_script(contract: dict) -> str:
    build = _contract_build_section(contract)
    for key in ("file", "build_script", "build_bat", "script", "builder"):
        value = build.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip().replace("\\", "/")
    return _recursive_contract_value(
        contract,
        ("build_script", "build_bat", "build_script_path"),
    )


def _contract_expected_exe_patterns(contract: dict) -> tuple[str, ...]:
    values = _contract_build_section(contract).get("expected_exe_patterns")
    if isinstance(values, list):
        return tuple(str(v).strip() for v in values if str(v).strip())
    return ()


def _contract_output_directories(contract: dict) -> tuple[str, ...]:
    values = _contract_build_section(contract).get("output_directories")
    if isinstance(values, list):
        return tuple(str(v).strip().replace("\\", "/") for v in values if str(v).strip())
    return ()


def effective_build_script(spec: ToolBuild, source_dir: Path) -> Path:
    contract_path, contract = load_effective_build_contract(source_dir)
    declared = _contract_declared_build_script(contract)
    resolved = _resolve_contract_path(source_dir, contract_path, declared)
    if resolved is None and contract_path is not None:
        resolved = _discover_build_script(source_dir, contract_path)
    if resolved is not None:
        print(f"[CONTRACT] {spec.tool_id}: build_script={resolved.relative_to(source_dir)}")
        return resolved

    fallback = source_dir / spec.build_script
    if fallback.is_file():
        print(f"[CONTRACT FALLBACK] {spec.tool_id}: build_script={spec.build_script}")
        return fallback

    # Last-resort compatibility: find the old configured basename recursively.
    matches = [p for p in source_dir.rglob(Path(spec.build_script).name) if p.is_file()]
    if len(matches) == 1:
        print(f"[CONTRACT FALLBACK] {spec.tool_id}: build_script={matches[0].relative_to(source_dir)}")
        return matches[0]

    raise FileNotFoundError(
        f"{spec.tool_id}: no usable build script found. "
        f"contract={contract_path}, declared={declared!r}, fallback={spec.build_script!r}"
    )


def validate_tool_source_contract(spec: ToolBuild, source_dir: Path) -> dict:
    report = {"tool_id": spec.tool_id, "version_json": None, "warnings": []}
    meta_path = source_dir / "version.json"
    if meta_path.is_file():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8-sig"))
            report["version_json"] = meta
            entry = str(meta.get("entry_point") or "").strip()
            if entry and not (source_dir / entry).is_file():
                raise FileNotFoundError(f"{spec.tool_id}: version.json entry_point not found: {entry}")
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"{spec.tool_id}: invalid version.json: {exc}") from exc
    contract_path, contract = load_effective_build_contract(source_dir)
    if contract_path is not None:
        report["build_contract"] = str(contract_path.relative_to(source_dir))
        report["contract_data"] = contract
    build_script = effective_build_script(spec, source_dir)
    report["effective_build_script"] = str(build_script.relative_to(source_dir))
    if contract_path is not None:
        declared_entry = _recursive_contract_value(
            contract,
            ("entry_point", "entry", "entrypoint", "main", "main_py"),
        )
        entry_path = _resolve_contract_path(source_dir, contract_path, declared_entry) if declared_entry else None
        if entry_path is None:
            entry_path = _discover_entry_point(source_dir, contract_path)
        if declared_entry and entry_path is None:
            raise FileNotFoundError(
                f"{spec.tool_id}: contract entry_point not found: {declared_entry}"
            )
        if entry_path is not None:
            report["effective_entry_point"] = str(entry_path.relative_to(source_dir))
    return report



MODULE_CACHE_SCHEMA = "insightec.integrated-tool-cache.v5"
CACHE_EXCLUDED_DIRS = {
    "__pycache__", ".git", ".github", ".pytest_cache",
    ".venv", "venv", "site-packages",
    ".mypy_cache", ".ruff_cache",
    "dist", "build", "output", "release", "build_logs",
}


def _hash_file(path: Path, digest) -> None:
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)


def tool_source_signature(spec: ToolBuild, source_dir: Path) -> str:
    """Hash only build-relevant source state for one integrated tool."""
    digest = hashlib.sha256()
    digest.update(MODULE_CACHE_SCHEMA.encode("utf-8"))
    digest.update(b"insightec.hub-build-policy.v3")
    digest.update(spec.tool_id.encode("utf-8"))
    digest.update(str(effective_build_script(spec, source_dir).relative_to(source_dir)).encode("utf-8"))
    digest.update(spec.target_exe.encode("utf-8"))
    digest.update(f"py{sys.version_info.major}.{sys.version_info.minor}".encode("ascii"))
    digest.update(platform.machine().lower().encode("utf-8"))

    generated_dir = (spec.copy_directory or "").lower()
    for path in sorted(source_dir.rglob("*"), key=lambda p: p.as_posix().lower()):
        if not path.is_file():
            continue
        rel = path.relative_to(source_dir)
        parts_lower = [part.lower() for part in rel.parts]
        if any(part in CACHE_EXCLUDED_DIRS for part in parts_lower):
            continue
        if generated_dir and parts_lower and parts_lower[0] == generated_dir:
            continue
        if path.suffix.lower() in {".pyc", ".pyo"}:
            continue
        digest.update(rel.as_posix().encode("utf-8"))
        _hash_file(path, digest)
    return digest.hexdigest()


def integrated_module_cache_root(source_root: Path) -> Path:
    explicit = os.environ.get("INSIGHTEC_MODULE_CACHE", "").strip()
    if explicit:
        return Path(explicit).resolve()
    workspace = os.environ.get("GITHUB_WORKSPACE", "").strip()
    if workspace:
        return (Path(workspace) / ".module-cache" / "integrated-tools").resolve()
    return (source_root / ".module-cache" / "integrated-tools").resolve()


def force_tool_rebuild_enabled() -> bool:
    value = os.environ.get("INSIGHTEC_FORCE_TOOL_REBUILD", "").strip().lower()
    return value in {"1", "true", "yes", "on"}


def restore_tool_cache(
    spec: ToolBuild,
    source_root: Path,
    source_dir: Path,
    tools_root: Path,
) -> tuple[Path | None, str]:
    signature = tool_source_signature(spec, source_dir)
    if force_tool_rebuild_enabled():
        print(f"[FORCE REBUILD] {spec.tool_id}: internal module cache bypassed")
        return None, signature
    cache_dir = integrated_module_cache_root(source_root) / spec.tool_id / signature / "payload"
    cached_exe = cache_dir / spec.target_exe
    metadata_path = cache_dir.parent / "cache_metadata.json"
    try:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8")) if metadata_path.is_file() else {}
    except Exception:
        metadata = {}
    if metadata.get("build_status") != "success":
        return None, signature
    if metadata.get("signature") != signature:
        return None, signature
    if not cached_exe.is_file() or cached_exe.stat().st_size < 100_000:
        return None, signature

    destination = tools_root / spec.target_dir
    destination.mkdir(parents=True, exist_ok=True)
    for child in list(destination.iterdir()):
        if child.name.lower() in {"manifest.json", "readme.txt", "release_notes.md"}:
            continue
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()

    for item in cache_dir.iterdir():
        target = destination / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        else:
            shutil.copy2(item, target)

    target_exe = destination / spec.target_exe
    if not target_exe.is_file() or target_exe.stat().st_size < 100_000:
        return None, signature
    return target_exe, signature


def save_tool_cache(
    spec: ToolBuild,
    source_root: Path,
    source_dir: Path,
    tools_root: Path,
    signature: str,
) -> Path:
    source_runtime = tools_root / spec.target_dir
    if not source_runtime.is_dir():
        raise FileNotFoundError(f"{spec.tool_id}: packaged runtime missing before cache save: {source_runtime}")
    cache_base = integrated_module_cache_root(source_root) / spec.tool_id / signature
    payload = cache_base / "payload"
    if payload.exists():
        shutil.rmtree(payload)
    payload.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source_runtime, payload)
    metadata = {
        "schema": MODULE_CACHE_SCHEMA,
        "tool_id": spec.tool_id,
        "signature": signature,
        "target_exe": spec.target_exe,
        "python": f"{sys.version_info.major}.{sys.version_info.minor}",
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "build_status": "success",
        "validated_exe_size": (payload / spec.target_exe).stat().st_size
            if (payload / spec.target_exe).is_file() else None,
    }
    (cache_base / "cache_metadata.json").write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return payload


def existing_runtime_ready(spec: ToolBuild, tools_root: Path) -> Path | None:
    external_assembly = _env_flag("INSIGHTEC_EXTERNAL_TOOL_ASSEMBLY", default=False)
    if not spec.prefer_existing_runtime and not external_assembly:
        return None
    target = tools_root / spec.target_dir / spec.target_exe
    if target.is_file() and target.stat().st_size >= 100_000:
        return target
    return None

def first_existing(root: Path, candidates: tuple[str, ...]) -> Path | None:
    for relative in candidates:
        candidate = root / Path(relative)
        if candidate.is_file():
            return candidate
    return None


def discover_built_exe(spec: ToolBuild, source_dir: Path) -> Path | None:
    """Find the actual validated product even when a module nests its dist folder."""
    _contract_path, contract = load_effective_build_contract(source_dir)
    patterns = list(_contract_expected_exe_patterns(contract))
    patterns.extend(Path(x).name for x in spec.output_candidates)
    patterns.append(spec.target_exe)

    roots = []
    for rel in _contract_output_directories(contract):
        direct = source_dir / rel
        if direct.exists():
            roots.append(direct)
        # Some module sources have an extra contract/source root layer.
        roots.extend(p for p in source_dir.rglob(Path(rel).name) if p.is_dir())
    if not roots:
        roots = [source_dir]

    import fnmatch
    excluded = {".venv", "venv", "site-packages", "__pycache__", "build_logs"}
    found = []
    seen = set()
    for root in roots:
        for exe in root.rglob("*.exe"):
            if exe in seen:
                continue
            seen.add(exe)
            rel = exe.relative_to(source_dir)
            if any(part.lower() in excluded or part.lower().endswith(".build") for part in rel.parts):
                continue
            if not exe.is_file() or exe.stat().st_size < 100_000:
                continue
            found.append(exe)
    if not found:
        return None

    def rank(path: Path):
        rel = path.relative_to(source_dir)
        name = path.name.lower()
        exact = 0 if name == spec.target_exe.lower() else 1
        match_rank = 999
        for idx, pattern in enumerate(patterns):
            if fnmatch.fnmatch(name, Path(pattern).name.lower()):
                match_rank = min(match_rank, idx)
        output_rank = 0 if any(
            part.lower() in {"dist", "release", "output"} or part.lower().endswith(".dist")
            for part in rel.parts
        ) else 1
        return (exact, match_rank, output_rank, len(rel.parts), -path.stat().st_size, rel.as_posix().lower())

    found.sort(key=rank)
    chosen = found[0]
    print(f"[BUILD OUTPUT] {spec.tool_id}: discovered {chosen.relative_to(source_dir)}")
    return chosen


def copy_tool_result(spec: ToolBuild, source_root: Path, tools_root: Path) -> Path:
    destination = tools_root / spec.target_dir
    destination.mkdir(parents=True, exist_ok=True)

    # Preserve the manifest and documentation copied by the Hub packager, while
    # replacing stale binaries/runtime folders from previous builds.
    for child in list(destination.iterdir()):
        if child.name.lower() in {"manifest.json", "readme.txt", "release_notes.md"}:
            continue
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()

    source_dir = source_root / "integrated_sources" / spec.source_dir
    candidates = metadata_output_candidates(source_dir) + spec.output_candidates
    built_exe = first_existing(source_dir, candidates)
    if built_exe is None:
        built_exe = discover_built_exe(spec, source_dir)
    if built_exe is None:
        raise FileNotFoundError(
            f"{spec.tool_id}: build completed but no usable EXE was found. "
            f"Checked fixed candidates: {', '.join(candidates)}; "
            "recursive contract-driven discovery also found nothing."
        )

    if spec.copy_directory:
        runtime_dir = source_dir / spec.copy_directory

        # Historical FUS builds used a fixed runtime folder
        # `MRI_Raw_FFT_Explorer_Nuitka_Windows`, while current Nuitka builds
        # emit a standalone folder such as `dist_nuitka/app.dist`.
        # The successfully detected EXE is authoritative: when the historical
        # fixed folder does not exist, package the EXE's actual parent runtime.
        if not runtime_dir.is_dir():
            discovered_runtime = built_exe.parent
            try:
                discovered_runtime.relative_to(source_dir)
            except ValueError:
                discovered_runtime = Path()

            if (
                not discovered_runtime
                or not discovered_runtime.is_dir()
                or discovered_runtime.resolve() == source_dir.resolve()
            ):
                raise FileNotFoundError(
                    f"{spec.tool_id}: runtime directory not found: {runtime_dir}; "
                    f"detected EXE parent is not a usable standalone runtime: {built_exe.parent}"
                )

            runtime_dir = discovered_runtime
            print(
                f"[RUNTIME OUTPUT] {spec.tool_id}: fixed runtime folder missing; "
                f"using detected EXE parent {runtime_dir.relative_to(source_dir)}"
            )

        # A standalone runtime must contain the detected EXE before copying.
        try:
            built_exe.relative_to(runtime_dir)
        except ValueError:
            raise RuntimeError(
                f"{spec.tool_id}: detected EXE {built_exe} is outside runtime directory {runtime_dir}"
            )

        for item in runtime_dir.iterdir():
            target = destination / item.name
            if item.is_dir():
                shutil.copytree(item, target, dirs_exist_ok=True)
            else:
                shutil.copy2(item, target)

        copied_exe = destination / built_exe.name
        target_exe = destination / spec.target_exe
        if copied_exe.resolve() != target_exe.resolve():
            if target_exe.exists():
                target_exe.unlink()
            copied_exe.rename(target_exe)
    else:
        target_exe = destination / spec.target_exe
        shutil.copy2(built_exe, target_exe)

    if not target_exe.is_file() or target_exe.stat().st_size < 100_000:
        raise RuntimeError(f"{spec.tool_id}: packaged EXE is missing or unexpectedly small: {target_exe}")
    return target_exe



def _env_flag(*names: str, default: bool = True) -> bool:
    for name in names:
        raw = os.environ.get(name)
        if raw is None:
            continue
        value = str(raw).strip().lower()
        if value in {"1", "true", "yes", "on", "include", "included"}:
            return True
        if value in {"0", "false", "no", "off", "exclude", "excluded"}:
            return False
    return default


def tool_is_enabled(spec: ToolBuild) -> bool:
    """Honor matrix single-tool selection and top-level Hub build selection."""
    only_tool = os.environ.get("INSIGHTEC_ONLY_TOOL", "").strip().lower()
    if only_tool and spec.tool_id.lower() != only_tool:
        return False
    if spec.tool_id == "sonication_analysis":
        if _env_flag("INSIGHTEC_EXCLUDE_SONICATION", default=False):
            return False
        return _env_flag(
            "INSIGHTEC_INCLUDE_SONICATION",
            "INPUT_INCLUDE_SONICATION",
            default=True,
        )
    return True



def _windows_python_for_tool(spec: ToolBuild) -> list[str]:
    """Return the interpreter command most likely to match the module BAT."""
    if os.name != "nt":
        return [sys.executable]
    if spec.tool_id == "vimeasure":
        # Current/legacy VIMeasure BATs use `py -3.13` explicitly.
        probe = subprocess.run(
            ["py", "-3.13", "-c", "import sys; print(sys.executable)"],
            text=True,
            capture_output=True,
            check=False,
        )
        if probe.returncode == 0:
            return ["py", "-3.13"]
    return [sys.executable]


def ensure_sonication_local_venv(source_dir: Path, log_root: Path) -> None:
    if os.name != "nt":
        return

    venv_python = source_dir / ".venv" / "Scripts" / "python.exe"
    log_path = log_root / f"sonication_venv_bootstrap_{datetime.now():%Y%m%d_%H%M%S}.log"

    if not venv_python.is_file():
        print("[BOOTSTRAP] sonication_analysis: creating source-local .venv")
        rc = stream_command(
            [sys.executable, "-m", "venv", str(source_dir / ".venv")],
            source_dir,
            log_path,
        )
        if rc != 0:
            print_failure_log_summary(log_path)
            raise RuntimeError(f"sonication_analysis: failed to create .venv. Full log: {log_path}")

    probe = [str(venv_python), "-c", "import pytest; print(pytest.__version__)"]
    rc = stream_command(probe, source_dir, log_path)
    if rc == 0:
        print("[PASS] sonication_analysis: local .venv already has pytest")
        return

    print("[BOOTSTRAP] sonication_analysis: installing pytest into local .venv")
    rc = stream_command(
        [str(venv_python), "-m", "pip", "install", "--disable-pip-version-check",
         "--upgrade", "pytest>=8,<9"],
        source_dir,
        log_path,
    )
    if rc != 0:
        print_failure_log_summary(log_path)
        raise RuntimeError(f"sonication_analysis: pytest install failed. Full log: {log_path}")

    rc = stream_command(probe, source_dir, log_path)
    if rc != 0:
        print_failure_log_summary(log_path)
        raise RuntimeError(f"sonication_analysis: pytest import failed after install. Full log: {log_path}")

    print("[PASS] sonication_analysis: local .venv pytest bootstrap")


def ensure_tool_build_environment(spec: ToolBuild, source_dir: Path, log_root: Path) -> None:
    """Bootstrap missing build dependencies before a module-owned BAT is executed.

    Repository module SOURCES are allowed to evolve independently.  A module BAT
    should ideally be self-contained, but the Hub build must not fail late merely
    because a historical/current BAT assumes its build environment is preinstalled.
    """
    requirements: list[str] = []
    import_probe = ""

    if spec.tool_id == "vimeasure":
        requirements = [
            "PySide6>=6.8,<7",
            "Nuitka>=2.7,<5",
            "ordered-set",
            "zstandard",
        ]
        import_probe = (
            "import PySide6; "
            "from PySide6 import QtCore, QtGui, QtWidgets, QtCharts; "
            "import nuitka; "
            "print('VIMeasure build environment: PASS', PySide6.__version__)"
        )
    elif spec.tool_id == "sonication_analysis":
        requirements = [
            "pytest>=8,<9",
            "Nuitka>=2.7,<5",
            "ordered-set",
            "zstandard",
        ]
        import_probe = (
            "import pytest, nuitka; "
            "print('Sonication outer build environment: PASS', pytest.__version__)"
        )

    if not requirements:
        return

    python_cmd = _windows_python_for_tool(spec)
    bootstrap_log = log_root / f"{spec.tool_id}_bootstrap_{datetime.now():%Y%m%d_%H%M%S}.log"

    print(f"[BOOTSTRAP] {spec.tool_id}: ensuring build dependencies with {' '.join(python_cmd)}")
    install_cmd = python_cmd + [
        "-m", "pip", "install",
        "--disable-pip-version-check",
        "--upgrade",
        *requirements,
    ]
    rc = stream_command(install_cmd, source_dir, bootstrap_log)
    if rc != 0:
        print_failure_log_summary(bootstrap_log)
        raise RuntimeError(
            f"{spec.tool_id}: dependency bootstrap failed with code {rc}. "
            f"Failure details were printed above. Full log: {bootstrap_log}"
        )

    probe_cmd = python_cmd + ["-c", import_probe]
    rc = stream_command(probe_cmd, source_dir, bootstrap_log)
    if rc != 0:
        print_failure_log_summary(bootstrap_log)
        raise RuntimeError(
            f"{spec.tool_id}: dependency import probe failed with code {rc}. "
            f"Failure details were printed above. Full log: {bootstrap_log}"
        )

    print(f"[PASS] {spec.tool_id}: build dependency bootstrap/import probe")



def build_integrated_tools(source_root: Path, dist_dir: Path, fail_on_error: bool = True) -> dict:
    tools_root = dist_dir / "tools"
    tools_root.mkdir(parents=True, exist_ok=True)
    log_root = source_root / "build_logs" / "integrated_tools"
    log_root.mkdir(parents=True, exist_ok=True)

    results: list[dict] = []
    enabled_tools = [spec for spec in TOOLS if tool_is_enabled(spec)]
    disabled_tools = [spec for spec in TOOLS if not tool_is_enabled(spec)]

    for spec in disabled_tools:
        print(f"[SKIP] {spec.tool_id}: disabled by top-level Hub build selection")

    for index, spec in enumerate(enabled_tools, start=1):
        started = time.monotonic()
        source_dir = source_root / "integrated_sources" / spec.source_dir
        build_script = effective_build_script(spec, source_dir)
        result = {
            "tool_id": spec.tool_id,
            "source_dir": str(source_dir),
            "build_script": spec.build_script,
            "status": "failed",
        }
        print("\n" + "=" * 72)
        print(f"Integrated tool {index}/{len(enabled_tools)}: {spec.tool_id}")
        print("=" * 72)
        try:
            if os.name != "nt":
                raise RuntimeError("Integrated EXE builds require a Windows runner")
            contract = validate_tool_source_contract(spec, source_dir)
            result["contract"] = contract
            existing = existing_runtime_ready(spec, tools_root)
            if existing is not None:
                result.update({
                    "status": "ready",
                    "target_exe": str(existing.relative_to(dist_dir)),
                    "size_bytes": existing.stat().st_size,
                    "elapsed_seconds": round(time.monotonic() - started, 1),
                    "build_skipped": "existing externally integrated runtime preserved",
                })
                print(f"[PASS] {spec.tool_id}: preserved externally integrated runtime {existing}")
                results.append(result)
                continue

            cached, module_signature = restore_tool_cache(spec, source_root, source_dir, tools_root)
            result["module_cache_signature"] = module_signature
            if cached is not None:
                result.update({
                    "status": "ready",
                    "target_exe": str(cached.relative_to(dist_dir)),
                    "size_bytes": cached.stat().st_size,
                    "elapsed_seconds": round(time.monotonic() - started, 1),
                    "build_skipped": "exact per-module cache hit",
                })
                print(f"[CACHE HIT] {spec.tool_id}: restored {cached}")
                results.append(result)
                continue

            print(f"[CACHE MISS] {spec.tool_id}: {module_signature[:16]}...; building only this tool")
            ensure_tool_build_environment(spec, source_dir, log_root)
            if spec.tool_id == "sonication_analysis":
                ensure_sonication_local_venv(source_dir, log_root)
            log_path = log_root / f"{spec.tool_id}_{datetime.now():%Y%m%d_%H%M%S}.log"
            # Pass CALL and the BAT path as separate argv items; avoid /s + nested quoted command strings.
            rc = stream_command(["cmd.exe", "/d", "/c", "call", str(build_script)], source_dir, log_path)
            if rc != 0:
                print_failure_log_summary(log_path)
                raise RuntimeError(
                    f"Build script exited with code {rc}. "
                    f"Failure details were printed above. Full log: {log_path}"
                )
            target_exe = copy_tool_result(spec, source_root, tools_root)
            cache_payload = save_tool_cache(
                spec, source_root, source_dir, tools_root, module_signature
            )
            result.update({
                "status": "ready",
                "module_cache_saved": str(cache_payload),
                "target_exe": str(target_exe.relative_to(dist_dir)),
                "size_bytes": target_exe.stat().st_size,
                "elapsed_seconds": round(time.monotonic() - started, 1),
                "log": str(log_path),
            })
            print(f"[PASS] {spec.tool_id}: {target_exe}")
        except Exception as exc:
            result.update({
                "error": f"{type(exc).__name__}: {exc}",
                "elapsed_seconds": round(time.monotonic() - started, 1),
            })
            print(f"[FAIL] {spec.tool_id}: {result['error']}")
            results.append(result)
            if fail_on_error:
                status_path = dist_dir / "tool_build_status.json"
                status_path.write_text(json.dumps({"tools": results}, indent=2), encoding="utf-8")
                raise
            continue
        results.append(result)

    skipped = [
        {
            "tool_id": spec.tool_id,
            "status": "skipped",
            "reason": "disabled by top-level Hub build selection",
        }
        for spec in disabled_tools
    ]
    report = {
        "schema": "insightec.hub.integrated-tool-build.v2",
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "all_ready": all(item["status"] == "ready" for item in results) and len(results) == len(enabled_tools),
        "enabled_tool_count": len(enabled_tools),
        "skipped_tool_count": len(disabled_tools),
        "tools": results + skipped,
    }
    status_path = dist_dir / "tool_build_status.json"
    status_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    if not report["all_ready"] and fail_on_error:
        raise RuntimeError("One or more integrated tools failed to build")
    return report


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: Build_Integrated_Tools.py SOURCE_ROOT DIST_DIR")
    build_integrated_tools(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve())
