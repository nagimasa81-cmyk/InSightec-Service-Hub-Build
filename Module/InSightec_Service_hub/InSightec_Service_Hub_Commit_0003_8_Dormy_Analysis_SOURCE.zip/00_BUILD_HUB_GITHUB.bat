@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo [1/5] Checking Python...
where python >nul 2>nul || (
  echo ERROR: Python was not found in PATH.
  exit /b 1
)

echo [2/5] Installing build dependencies...
python -m pip install --upgrade pip || exit /b 1
python -m pip install pyinstaller pywin32 || exit /b 1

echo [3/5] Cleaning previous build...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist InSightecServiceHub.spec del /q InSightecServiceHub.spec

echo [4/5] Building InSightec Service Hub...
python -m PyInstaller --noconfirm --clean --windowed ^
  --name InSightecServiceHub ^
  --add-data "config.json;." ^
  --add-data "language;language" ^
  --add-data "help;help" ^
  InSightecServiceHub.py || exit /b 1

echo [5/5] Copying runtime content...
set "OUT=dist\InSightecServiceHub"
if not exist "%OUT%\InSightecServiceHub.exe" (
  echo ERROR: Expected EXE was not created.
  exit /b 1
)
copy /Y config.json "%OUT%\config.json" >nul || exit /b 1
for %%D in (tools plugins database language help updates resources) do (
  if exist "%%D" xcopy /E /I /Y "%%D" "%OUT%\%%D" >nul || exit /b 1
)
if exist hub_manifest.json copy /Y hub_manifest.json "%OUT%\hub_manifest.json" >nul

echo BUILD SUCCESS: %CD%\%OUT%\InSightecServiceHub.exe
exit /b 0
