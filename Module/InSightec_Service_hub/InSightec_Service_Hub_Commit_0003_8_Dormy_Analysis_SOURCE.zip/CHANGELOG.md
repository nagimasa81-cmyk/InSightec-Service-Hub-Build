# CHANGELOG

## Commit 0003.7 - Module Lifecycle Management
- Added Modules page in Developer Mode.
- Added Version Manager for module manifest.json.
- Added Package Builder to generate module update ZIP files.
- Added module channel metadata: stable / beta / feu / internal.
- Added version history display.
- Expanded language strings for English, Japanese, Traditional Chinese and Spanish.


## Commit 0003.8 - 2026-07-25
- Removed DO Analysis A from all Hub-facing cards, lists, health status, and favorites while retaining its module files.
- Renamed DO Analysis B to Dormy Analysis across English, Japanese, Spanish, Traditional Chinese, and Korean metadata.
- Added `show_in_hub` manifest support for safely hiding installed modules.
