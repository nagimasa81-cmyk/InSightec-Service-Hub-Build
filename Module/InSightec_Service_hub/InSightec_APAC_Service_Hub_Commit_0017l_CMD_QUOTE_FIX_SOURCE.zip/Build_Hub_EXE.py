from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import zipfile
from datetime import datetime
from pathlib import Path

APP_NAME = "InSightecServiceHub"
MAIN_CANDIDATES = ("InSightecServiceHub.py",)
RUNTIME_FILES = (
    "config.json",
    "hub_manifest.json",
    "README.txt",
    "VERSION_HISTORY.txt",
    "TOOLS_INSTALL_README.txt",
    "MODULE_MANAGER_README.txt",
)
RUNTIME_DIRS = (
    "tools",
    "plugins",
    "database",
    "language",
    "help",
    "updates",
    "resources",
    "icons",
)


def find_source_root(start: Path) -> tuple[Path, Path]:
    checked: list[Path] = []
    current = start.resolve()
    for candidate_root in (current, *current.parents[:4]):
        checked.append(candidate_root)
        for filename in MAIN_CANDIDATES:
            script = candidate_root / filename
            if script.is_file():
                return candidate_root, script
    checked_text = "\n".join(f"  - {p}" for p in checked)
    raise FileNotFoundError(
        "Main Python file was not found. Checked:\n" + checked_text
    )


def run(command: list[str], log_file: Path, cwd: Path) -> None:
    printable = subprocess.list2cmdline(command)
    print(f"[RUN] {printable}")
    with log_file.open("a", encoding="utf-8", errors="replace") as log:
        log.write(f"\n[RUN] {printable}\n")
        process = subprocess.Popen(
            command,
            cwd=str(cwd),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="")
            log.write(line)
        return_code = process.wait()
    if return_code != 0:
        raise RuntimeError(f"Command failed with exit code {return_code}: {printable}")


def ensure_build_dependencies(log_file: Path, source_root: Path) -> None:
    required_imports = ("PyInstaller", "comtypes", "comtypes.client")
    missing: list[str] = []
    for module_name in required_imports:
        check = subprocess.run(
            [sys.executable, "-c", f"import {module_name}"],
            cwd=str(source_root),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        if check.returncode != 0:
            missing.append(module_name)

    if not missing:
        print("[PASS] PyInstaller and comtypes build dependencies are available.")
        return

    print("[INFO] Missing build imports: " + ", ".join(missing))
    print("[INFO] Installing/upgrading PyInstaller, hooks, and comtypes...")
    run(
        [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--disable-pip-version-check",
            "--upgrade",
            "pyinstaller",
            "pyinstaller-hooks-contrib",
            "comtypes",
        ],
        log_file,
        source_root,
    )
    run(
        [
            sys.executable,
            "-c",
            "import PyInstaller, comtypes, comtypes.client; "
            "print('PyInstaller/comtypes dependency check: PASS')",
        ],
        log_file,
        source_root,
    )



def load_build_metadata(source_root: Path) -> dict:
    metadata = {
        "app_name": APP_NAME,
        "version": "0.0.0",
        "build": "Unknown",
    }
    for filename in ("hub_manifest.json", "config.json"):
        path = source_root / filename
        if not path.is_file():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        metadata["version"] = str(data.get("version") or data.get("console_version") or metadata["version"])
        metadata["build"] = str(data.get("build") or data.get("build_name") or metadata["build"])
        metadata["app_name"] = str(data.get("name") or data.get("console_name") or metadata["app_name"])
        if filename == "hub_manifest.json":
            break
    return metadata


def write_build_info(dist_dir: Path, metadata: dict, exe_path: Path, elapsed: float) -> Path:
    info = {
        "application": metadata.get("app_name", APP_NAME),
        "version": metadata.get("version", "0.0.0"),
        "build": metadata.get("build", "Unknown"),
        "built_at": datetime.now().isoformat(timespec="seconds"),
        "python": sys.version,
        "executable": exe_path.name,
        "sha256": file_sha256(exe_path),
        "elapsed_seconds": round(elapsed, 1),
    }
    path = dist_dir / "build_info.json"
    path.write_text(json.dumps(info, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def create_release_zip(source_root: Path, dist_dir: Path, metadata: dict) -> Path:
    release_dir = source_root / "release"
    release_dir.mkdir(parents=True, exist_ok=True)
    safe_version = str(metadata.get("version", "0.0.0")).replace(" ", "_")
    zip_path = release_dir / f"{APP_NAME}_{safe_version}_Standalone.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(dist_dir.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(dist_dir.parent))
    return zip_path


def copy_runtime_content(source_root: Path, dist_dir: Path) -> tuple[int, int]:
    copied = 0
    skipped = 0

    for filename in RUNTIME_FILES:
        source = source_root / filename
        destination = dist_dir / filename
        if not source.is_file():
            print(f"[SKIP] {filename}")
            skipped += 1
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        print(f"[PASS] {filename}")
        copied += 1

    for dirname in RUNTIME_DIRS:
        source = source_root / dirname
        destination = dist_dir / dirname
        if not source.is_dir():
            print(f"[SKIP] {dirname}/")
            skipped += 1
            continue
        if destination.exists():
            shutil.rmtree(destination)
        shutil.copytree(source, destination)
        print(f"[PASS] {dirname}/")
        copied += 1

    return copied, skipped


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    started = time.monotonic()
    launcher_dir = Path(__file__).resolve().parent

    try:
        source_root, main_script = find_source_root(launcher_dir)
        metadata = load_build_metadata(source_root)
        dist_root = source_root / "dist"
        dist_dir = dist_root / APP_NAME
        build_root = source_root / "build"
        spec_root = source_root
        log_root = source_root / "build_logs"
        log_root.mkdir(parents=True, exist_ok=True)
        if dist_root.exists():
            shutil.rmtree(dist_root)
        if build_root.exists():
            shutil.rmtree(build_root)
        dist_root.mkdir(parents=True, exist_ok=True)
        build_root.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = log_root / f"build_{timestamp}.log"

        print("=" * 68)
        print("InSightec APAC Service Hub - Python Build Launcher")
        print("=" * 68)
        print(f"Application : {metadata.get('app_name')}")
        print(f"Version     : {metadata.get('version')}")
        print(f"Build       : {metadata.get('build')}")
        print(f"Python      : {sys.executable}")
        print(f"Source root : {source_root}")
        print(f"Main script : {main_script}")
        print(f"Output      : {dist_dir}")
        print(f"Log         : {log_file}")
        print()

        validator = source_root / "validate_source.py"
        if validator.is_file():
            run([sys.executable, str(validator)], log_file, source_root)

        ensure_build_dependencies(log_file, source_root)

        # Call PyInstaller through its Python API instead of rebuilding a long
        # Windows command line. This avoids CMD/PowerShell quoting issues that
        # can make PyInstaller report "scriptname required" even when the
        # source file exists.
        from PyInstaller.__main__ import run as pyinstaller_run

        pyinstaller_args = [
            "--noconfirm",
            "--clean",
            "--windowed",
            "--name",
            APP_NAME,
            "--distpath",
            str(dist_root),
            "--workpath",
            str(build_root),
            "--collect-submodules",
            "comtypes",
            "--collect-submodules",
            "comtypes.client",
            # Use only the filename while running from source_root. This keeps
            # paths short and avoids trailing-backslash quoting edge cases.
            main_script.name,
        ]

        printable_args = " ".join(repr(arg) for arg in pyinstaller_args)
        print(f"[RUN] PyInstaller API args: {printable_args}")
        with log_file.open("a", encoding="utf-8", errors="replace") as log:
            log.write(f"\n[RUN] PyInstaller API args: {printable_args}\n")

        previous_cwd = Path.cwd()
        try:
            os.chdir(source_root)
            pyinstaller_run(pyinstaller_args)
        finally:
            os.chdir(previous_cwd)

        exe_path = dist_dir / f"{APP_NAME}.exe"
        if not exe_path.is_file():
            raise FileNotFoundError(f"Built EXE was not found: {exe_path}")

        copied, skipped = copy_runtime_content(source_root, dist_dir)

        # Build and package every integrated analysis tool into the Hub runtime.
        # A Hub build is considered incomplete when any configured tool EXE is missing.
        from Build_Integrated_Tools import build_integrated_tools
        tool_report = build_integrated_tools(source_root, dist_dir, fail_on_error=True)
        print(f"[PASS] Integrated tools ready: {sum(1 for x in tool_report['tools'] if x['status'] == 'ready')}/{len(tool_report['tools'])}")

        elapsed = time.monotonic() - started
        build_info = write_build_info(dist_dir, metadata, exe_path, elapsed)
        release_zip = create_release_zip(source_root, dist_dir, metadata)

        print()
        print("=" * 68)
        print("Build SUCCESS")
        print("=" * 68)
        print(f"EXE        : {exe_path}")
        print(f"SHA256     : {file_sha256(exe_path)}")
        print(f"Build info : {build_info}")
        print(f"Release ZIP: {release_zip}")
        print(f"Copied     : {copied}")
        print(f"Skipped    : {skipped}")
        print(f"Elapsed    : {elapsed:.1f} sec")
        print(f"Build log  : {log_file}")
        print("=" * 68)
        return 0

    except Exception as exc:
        print()
        print("=" * 68)
        print("Build FAILED")
        print("=" * 68)
        print(f"{type(exc).__name__}: {exc}")
        print("=" * 68)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
