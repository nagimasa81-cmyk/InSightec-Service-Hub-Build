@echo off
cd /d %~dp0
python -m builder.build_cli --target all
pause
