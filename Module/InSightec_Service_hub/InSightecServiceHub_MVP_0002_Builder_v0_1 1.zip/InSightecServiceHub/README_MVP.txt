InSightec Service Hub MVP

Run standalone IB Console:
  python run_ib_console.py

Run Service Hub Launcher:
  python run_service_hub.py

Create sample data:
  python tools/seed_sample_data.py

Main features included:
- SQLite DB schema v2
- Launcher + manifest module loader
- IB Database Console
- System/Asset search
- System detail
- Inspection schedule input
- Part replacement input
- Inspection record input
- Documents tab
- Attachments tab
- Timeline tab
- Update Center zip import

Notes:
- Requires Python with PySide6 installed.
- Run commands from the project root folder.

Builder v0.1 added:
- 00_RUN_BUILDER_GUI.bat : launch GUI Builder
- 01_BUILD_PLATFORM_RELEASE.bat : build Service Hub EXE
- 02_BUILD_PLATFORM_DEBUG.bat : build debug EXE with console
- 03_BUILD_ALL_MODULES.bat : build all discovered modules
- 04_CLEAN_BUILD.bat : clean build/release/temp folders
- builder/build_cli.py : GitHub Actions compatible CLI entry
