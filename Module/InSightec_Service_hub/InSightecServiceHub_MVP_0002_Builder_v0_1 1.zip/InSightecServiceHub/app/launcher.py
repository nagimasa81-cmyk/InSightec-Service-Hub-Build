from PySide6.QtWidgets import QMainWindow,QWidget,QHBoxLayout,QVBoxLayout,QLabel,QListWidget,QListWidgetItem,QStackedWidget
from app.module_loader import ModuleLoader
from app.update_center import UpdateCenter
class ServiceHubLauncher(QMainWindow):
    def __init__(self): super().__init__(); self.setWindowTitle('InSightec Service Hub'); self.resize(1360,820); self.loader=ModuleLoader(); self.modules=[]; self._build_ui(); self.load_modules()
    def _build_ui(self):
        root=QWidget(); self.setCentralWidget(root); layout=QHBoxLayout(root); left=QVBoxLayout(); title=QLabel('InSightec Service Hub'); title.setObjectName('LauncherTitle'); self.module_list=QListWidget(); self.module_list.currentRowChanged.connect(self.change_module); left.addWidget(title); left.addWidget(self.module_list); self.stack=QStackedWidget(); layout.addLayout(left,1); layout.addWidget(self.stack,5)
    def load_modules(self):
        self.modules=self.loader.discover_modules(); self.module_list.clear()
        for m in self.modules:
            self.module_list.addItem(QListWidgetItem(f"{m.get('module_name',m.get('module_id'))} v{m.get('version','-')}"))
            try: self.stack.addWidget(self.loader.load_module_widget(m))
            except Exception as e: self.stack.addWidget(QLabel(f"Failed to load module:\n{m.get('module_name')}\n\n{e}"))
        self.module_list.addItem(QListWidgetItem('Update Center')); self.stack.addWidget(UpdateCenter())
        if self.stack.count(): self.module_list.setCurrentRow(0)
    def change_module(self,index:int):
        if index>=0: self.stack.setCurrentIndex(index)
