from __future__ import annotations
import json, zipfile
from pathlib import Path
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTextEdit,QFileDialog,QMessageBox,QTableWidget,QTableWidgetItem,QHeaderView
from modules.ib_console.services.update_package_service import UpdatePackageService
from core.database.db_manager import DBManager
class UpdateCenter(QWidget):
    def __init__(self)->None: super().__init__(); self.db=DBManager(); self.service=UpdatePackageService(self.db); self.selected_zip=None; self._build_ui(); self.load_history()
    def _build_ui(self):
        l=QVBoxLayout(self); title=QLabel('Update Center'); title.setObjectName('ModuleTitle'); l.addWidget(title); row=QHBoxLayout(); s=QPushButton('Select Update Zip'); s.clicked.connect(self.select_zip); i=QPushButton('Import Update'); i.clicked.connect(self.import_update); r=QPushButton('Refresh History'); r.clicked.connect(self.load_history); row.addWidget(s); row.addWidget(i); row.addWidget(r); row.addStretch(); l.addLayout(row)
        self.manifest=QTextEdit(); self.manifest.setReadOnly(True); self.manifest.setMaximumHeight(220); l.addWidget(QLabel('Manifest Preview')); l.addWidget(self.manifest)
        self.table=QTableWidget(); self.table.setColumnCount(6); self.table.setHorizontalHeaderLabels(['Module','Version','Type','Status','Imported At','Notes']); self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); self.table.setEditTriggers(QTableWidget.NoEditTriggers); l.addWidget(QLabel('Update History')); l.addWidget(self.table)
    def select_zip(self):
        p,_=QFileDialog.getOpenFileName(self,'Select Update Zip','','Zip Files (*.zip);;All Files (*.*)')
        if p: self.selected_zip=Path(p); self.preview_manifest(self.selected_zip)
    def preview_manifest(self,p:Path):
        try:
            with zipfile.ZipFile(p,'r') as z: data=json.loads(z.read('manifest.json').decode('utf-8'))
            self.manifest.setPlainText(json.dumps(data,ensure_ascii=False,indent=2))
        except Exception as e: QMessageBox.critical(self,'Manifest Preview Failed',str(e))
    def import_update(self):
        if not self.selected_zip: QMessageBox.warning(self,'No Zip','Select update zip first.'); return
        try: res=self.service.import_update_package(self.selected_zip); QMessageBox.information(self,'Imported',f"Update imported.\n{res['package_id']}"); self.load_history()
        except Exception as e: QMessageBox.critical(self,'Import Failed',str(e))
    def load_history(self):
        rows=self.db.fetch_all('SELECT * FROM update_packages WHERE deleted_at IS NULL ORDER BY imported_at DESC'); self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,v in enumerate([r.get('module_name'),r.get('package_version'),r.get('package_type'),r.get('status'),r.get('imported_at'),r.get('notes')]):
                it=QTableWidgetItem(str(v or '')); it.setFlags(it.flags() ^ Qt.ItemIsEditable); self.table.setItem(i,j,it)
