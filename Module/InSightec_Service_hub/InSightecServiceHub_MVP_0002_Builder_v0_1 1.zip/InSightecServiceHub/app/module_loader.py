from __future__ import annotations
import importlib, json
from pathlib import Path
from typing import Any
from PySide6.QtWidgets import QWidget
class ModuleLoader:
    def __init__(self, modules_root:str|Path='modules')->None: self.modules_root=Path(modules_root)
    def discover_modules(self)->list[dict[str,Any]]:
        mods=[]
        if not self.modules_root.exists(): return mods
        for p in self.modules_root.glob('*/manifest.json'):
            try:
                m=json.loads(p.read_text(encoding='utf-8')); m['_manifest_path']=str(p)
                if m.get('enabled',True): mods.append(m)
            except Exception as e: mods.append({'module_id':p.parent.name,'module_name':p.parent.name,'enabled':False,'error':str(e),'_manifest_path':str(p)})
        return sorted(mods,key=lambda x:x.get('module_name',''))
    def load_module_widget(self, manifest:dict[str,Any])->QWidget:
        entry=manifest.get('entry'); mod_path, cls_name=entry.rsplit('.',1); mod=importlib.import_module(mod_path); cls=getattr(mod,cls_name); w=cls()
        if not isinstance(w,QWidget): raise TypeError(f'{entry} is not QWidget')
        return w
