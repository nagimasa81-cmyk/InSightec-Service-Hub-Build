from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.database.db_manager import DBManager
from core.services.asset_service import AssetService
from core.services.service_event_service import ServiceEventService
def main():
    db=DBManager('data/service_hub.db','core/database/service_hub_schema_v2.sql'); db.initialize_database(); a=AssetService(db); e=ServiceEventService(db)
    existing=db.fetch_one("SELECT asset_id FROM assets WHERE system_serial='SN-SAMPLE-001'")
    if existing: print('Sample already exists:', existing['asset_id']); return
    hid=a.create_hospital('Sample Hospital','company_insightec','Japan','Tokyo','Sample hospital')
    aid=a.create_asset(hid,'SN-SAMPLE-001','Prime','Sample Prime System','FUS System','1.0.0','2025-01-15','Sample asset','user_masaki')
    db.insert('inspection_schedules',{'schedule_id':db.new_id('schedule'),'asset_id':aid,'inspection_due_date':'2026-07-20','inspection_deadline':'2026-08-05','next_inspection_status':'未定','notes':'Sample schedule'})
    a.add_asset_component(aid,'component_watersystem','WS-SAMPLE-001','V2','2025-01-15 10:00:00','Initial WaterSystem')
    a.add_asset_component(aid,'component_pump','PUMP-SAMPLE-001','A','2025-01-15 10:00:00','Initial Pump')
    e.create_inspection_event(aid,'CASE-SAMPLE-001','2026-06-20 09:00:00','Masaki','2026-06-20 12:00:00','No major issue found.','Annual inspection completed.','None','未入力','user_masaki')
    e.create_part_replacement_event(aid,'FlowMeter','2026-06-21 14:00:00','CASE-SAMPLE-002','Masaki','Sample replacement','component_flowmeter',None,'FM-OLD-001','FM-NEW-001','Sample FlowMeter replacement','user_masaki')
    print('Sample data created. Asset ID:', aid)
if __name__=='__main__': main()
