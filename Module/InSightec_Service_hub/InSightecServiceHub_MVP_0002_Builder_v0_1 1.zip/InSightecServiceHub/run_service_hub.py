from __future__ import annotations
import sys
from PySide6.QtWidgets import QApplication,QMessageBox
from core.database.db_manager import DBManager
from app.launcher import ServiceHubLauncher
def initialize_db(): DBManager('data/service_hub.db','core/database/service_hub_schema_v2.sql','data/backups').initialize_database()
def main():
    app=QApplication(sys.argv)
    try: initialize_db()
    except Exception as e: QMessageBox.critical(None,'Database Initialization Failed',str(e)); sys.exit(1)
    w=ServiceHubLauncher(); w.show(); sys.exit(app.exec())
if __name__=='__main__': main()
