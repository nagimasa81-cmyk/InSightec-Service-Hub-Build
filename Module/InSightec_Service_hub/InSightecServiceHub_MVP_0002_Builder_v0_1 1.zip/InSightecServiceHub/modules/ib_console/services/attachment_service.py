from __future__ import annotations
import shutil
from pathlib import Path
from typing import Any, Optional
from core.database.db_manager import DBManager
class AttachmentService:
    def __init__(self, db:Optional[DBManager]=None, attachment_root:str|Path='data/attachments')->None: self.db=db or DBManager(); self.attachment_root=Path(attachment_root); self.attachment_root.mkdir(parents=True,exist_ok=True)
    def add_attachment(self,related_table:str,related_id:str,source_file_path:str|Path,asset_id:Optional[str]=None,attachment_type:Optional[str]=None,notes:Optional[str]=None,copy_file:bool=True)->str:
        src=Path(source_file_path); aid=self.db.new_id('attachment'); target_dir=self.attachment_root/related_table/related_id; target_dir.mkdir(parents=True,exist_ok=True); dst=target_dir/src.name
        if copy_file:
            i=1; base=dst
            while dst.exists(): dst=base.with_name(f'{base.stem}_{i}{base.suffix}'); i+=1
            shutil.copy2(src,dst)
        else: dst=src
        self.db.insert('universal_attachments',{'attachment_id':aid,'asset_id':asset_id,'related_table':related_table,'related_id':related_id,'file_name':src.name,'file_path':str(dst),'file_type':src.suffix.lower().replace('.',''),'attachment_type':attachment_type,'notes':notes}); return aid
    def list_asset_attachments(self,asset_id:str)->list[dict[str,Any]]: return self.db.fetch_all('SELECT * FROM universal_attachments WHERE asset_id=? AND deleted_at IS NULL ORDER BY uploaded_at DESC',[asset_id])
