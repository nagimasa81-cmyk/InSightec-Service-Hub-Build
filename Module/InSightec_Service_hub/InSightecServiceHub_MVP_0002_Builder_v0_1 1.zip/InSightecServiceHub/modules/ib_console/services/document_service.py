from __future__ import annotations
from typing import Any, Optional
from core.database.db_manager import DBManager
class DocumentService:
    def __init__(self, db: Optional[DBManager]=None)->None: self.db=db or DBManager()
    def list_documents(self,document_type:Optional[str]=None,target_system_type:Optional[str]=None,latest_only:bool=False)->list[dict[str,Any]]:
        sql='SELECT * FROM documents WHERE deleted_at IS NULL'; p=[]
        if document_type: sql+=' AND document_type=?'; p.append(document_type)
        if target_system_type: sql+=' AND (target_system_type=? OR target_system_type IS NULL)'; p.append(target_system_type)
        if latest_only: sql+=' AND is_latest=1'
        sql+=' ORDER BY document_type,title,version DESC'; return self.db.fetch_all(sql,p)
