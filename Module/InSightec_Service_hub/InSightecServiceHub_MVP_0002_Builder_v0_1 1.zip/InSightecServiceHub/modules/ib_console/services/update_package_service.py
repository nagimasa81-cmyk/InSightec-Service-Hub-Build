from __future__ import annotations
import json, zipfile, shutil
from pathlib import Path
from typing import Any, Optional
from core.database.db_manager import DBManager
class UpdatePackageService:
    def __init__(self, db:Optional[DBManager]=None, import_root:str|Path='data/imports/update_packages', document_root:str|Path='data/documents')->None:
        self.db=db or DBManager(); self.import_root=Path(import_root); self.document_root=Path(document_root); self.import_root.mkdir(parents=True,exist_ok=True); self.document_root.mkdir(parents=True,exist_ok=True)
    def import_update_package(self, zip_path:str|Path, imported_by_user_id:Optional[str]=None)->dict[str,Any]:
        z=Path(zip_path); pid=self.db.new_id('package'); ex=self.import_root/pid; ex.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(z,'r') as f: f.extractall(ex)
        manifest=json.loads((ex/'manifest.json').read_text(encoding='utf-8'))
        imported=[]
        for d in manifest.get('documents',[]):
            src=ex/d.get('source','')
            if src.exists():
                tgt=self.document_root/d.get('document_type','Other')/(d.get('target_system_type') or 'Common')/d.get('version',manifest.get('version','0.0.0')); tgt.mkdir(parents=True,exist_ok=True); out=tgt/src.name; shutil.copy2(src,out)
                did=self.db.new_id('document'); self.db.insert('documents',{'document_id':did,'document_type':d.get('document_type','Other'),'title':d.get('title',src.stem),'version':d.get('version',manifest.get('version','0.0.0')),'target_system_type':d.get('target_system_type'),'file_path':str(out),'effective_date':d.get('effective_date'),'is_latest':1,'notes':d.get('notes')}); imported.append(did)
        self.db.insert('update_packages',{'package_id':pid,'module_name':manifest.get('module','Unknown'),'package_version':manifest.get('version','0.0.0'),'package_type':manifest.get('update_type','Unknown'),'manifest_json':json.dumps(manifest,ensure_ascii=False),'imported_by_user_id':imported_by_user_id,'status':'Imported','notes':manifest.get('notes')})
        return {'package_id':pid,'manifest':manifest,'imported_documents':imported,'status':'Imported'}
