from __future__ import annotations
from typing import Any, Optional
from core.database.db_manager import DBManager
from core.services.asset_service import AssetService
from core.services.service_event_service import ServiceEventService
class IBService:
    def __init__(self, db: Optional[DBManager]=None)->None: self.db=db or DBManager(); self.asset_service=AssetService(self.db); self.event_service=ServiceEventService(self.db)
    def search_systems(self, keyword:str='')->list[dict[str,Any]]:
        rows=self.asset_service.search_assets(keyword)
        for r in rows: r['system_id']=r['asset_id']
        return rows
    def get_system_detail(self, system_id:str)->Optional[dict[str,Any]]:
        r=self.asset_service.get_asset_detail(system_id)
        if r: r['system_id']=r['asset_id']
        return r
    def create_or_update_inspection_schedule(self,system_id:str,inspection_due_date:Optional[str],inspection_deadline:Optional[str],planned_start_datetime:Optional[str]=None,planned_end_datetime:Optional[str]=None,next_inspection_status:str='未定',notes:Optional[str]=None)->str:
        ex=self.db.fetch_one('SELECT schedule_id FROM inspection_schedules WHERE asset_id=? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 1',[system_id])
        data={'inspection_due_date':inspection_due_date,'inspection_deadline':inspection_deadline,'planned_start_datetime':planned_start_datetime,'planned_end_datetime':planned_end_datetime,'next_inspection_status':next_inspection_status,'notes':notes}
        if ex:
            sid=ex['schedule_id']; self.db.update_by_id('inspection_schedules','schedule_id',sid,data)
        else:
            sid=self.db.new_id('schedule'); data.update({'schedule_id':sid,'asset_id':system_id}); self.db.insert('inspection_schedules',data)
        self.asset_service.add_timeline_event(system_id,'InspectionScheduleUpdated',self.db.now_text(),'Inspection schedule updated',f'Status: {next_inspection_status}','inspection_schedules',sid)
        return sid
    def get_inspection_schedule(self, system_id:str)->Optional[dict[str,Any]]:
        return self.db.fetch_one('SELECT * FROM inspection_schedules WHERE asset_id=? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 1',[system_id])
    def add_part_replacement(self,system_id:str,replaced_part:str,replacement_datetime:str,case_no:Optional[str],replaced_by:Optional[str],replacement_reason:Optional[str],notes:Optional[str]=None)->str:
        return self.event_service.create_part_replacement_event(system_id,replaced_part,replacement_datetime,case_no,replaced_by,replacement_reason,notes=notes)[1]
    def list_part_replacements(self, system_id:str)->list[dict[str,Any]]:
        return self.db.fetch_all('SELECT * FROM part_replacements WHERE asset_id=? AND deleted_at IS NULL ORDER BY replacement_datetime DESC',[system_id])
    def add_inspection_record(self,system_id:str,inspection_datetime:Optional[str],work_start_datetime:Optional[str],work_end_datetime:Optional[str],case_no:Optional[str],inspector_name:Optional[str],findings:Optional[str],actions:Optional[str],remaining_items:Optional[str],salesforce_update_status:str='未入力',notes:Optional[str]=None)->str:
        dt=inspection_datetime or self.db.now_text(); eid,iid=self.event_service.create_inspection_event(system_id,case_no,dt,inspector_name,work_end_datetime,findings,actions,remaining_items,salesforce_update_status)
        self.db.update_by_id('service_events','service_event_id',eid,{'event_start_datetime':work_start_datetime or dt,'event_end_datetime':work_end_datetime,'findings':findings,'actions':actions,'remaining_items':remaining_items,'salesforce_update_status':salesforce_update_status})
        if notes: self.db.update_by_id('inspection_records','inspection_id',iid,{'notes':notes})
        return iid
    def list_inspection_records(self, system_id:str)->list[dict[str,Any]]:
        return self.db.fetch_all('''SELECT ir.*,se.case_no,se.event_start_datetime AS work_start_datetime,se.event_end_datetime AS work_end_datetime,se.primary_engineer,se.findings,se.actions,se.remaining_items,se.salesforce_update_status FROM inspection_records ir JOIN service_events se ON ir.service_event_id=se.service_event_id WHERE ir.asset_id=? AND ir.deleted_at IS NULL AND se.deleted_at IS NULL ORDER BY ir.inspection_datetime DESC,ir.created_at DESC''',[system_id])
    def get_timeline(self, system_id:str)->list[dict[str,Any]]: return self.asset_service.get_timeline(system_id)
