from __future__ import annotations
from pathlib import Path
from PySide6.QtCore import Qt,QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QTabWidget,QTextEdit,QDialog,QMessageBox,QTableWidget,QTableWidgetItem,QHeaderView
from modules.ib_console.services.ib_service import IBService
from modules.ib_console.services.document_service import DocumentService
from modules.ib_console.services.attachment_service import AttachmentService
class SystemDetailDialog(QDialog):
    def __init__(self, system_id:str, parent:QWidget|None=None)->None:
        super().__init__(parent); self.asset_id=system_id; self.service=IBService(); self.document_rows=[]; self.attachment_rows=[]; self.inspection_rows=[]; self.setWindowTitle('System Detail'); self.resize(1100,760); self._build_ui(); self.load_data()
    def _build_ui(self):
        layout=QVBoxLayout(self); hr=QHBoxLayout(); self.title_label=QLabel('System Detail'); rb=QPushButton('Refresh'); rb.clicked.connect(self.load_data); cb=QPushButton('Close'); cb.clicked.connect(self.close); hr.addWidget(self.title_label); hr.addStretch(); hr.addWidget(rb); hr.addWidget(cb); layout.addLayout(hr)
        self.basic_info=QTextEdit(); self.basic_info.setReadOnly(True); self.basic_info.setMaximumHeight(145); layout.addWidget(self.basic_info); self.tabs=QTabWidget(); layout.addWidget(self.tabs)
        self.schedule_text=QTextEdit(); self.schedule_text.setReadOnly(True); sw=QWidget(); sl=QVBoxLayout(sw); eb=QPushButton('Edit Inspection Schedule'); eb.clicked.connect(self.open_schedule_dialog); sl.addWidget(eb); sl.addWidget(self.schedule_text); self.tabs.addTab(sw,'Schedule')
        self.parts_table=self._table(['Replacement Date','Part','Case No.','Replaced By','Reason','Notes']); pw=QWidget(); pl=QVBoxLayout(pw); ab=QPushButton('Add Part Replacement'); ab.clicked.connect(self.open_part_dialog); pl.addWidget(ab); pl.addWidget(self.parts_table); self.tabs.addTab(pw,'Parts')
        self.inspection_table=self._table(['Inspection Date','Case No.','Inspector','Work Start','Work End','Salesforce','Findings']); self.inspection_table.cellDoubleClicked.connect(self.open_inspection_detail); iw=QWidget(); il=QVBoxLayout(iw); ib=QPushButton('Add Inspection Record'); ib.clicked.connect(self.open_inspection_dialog); il.addWidget(ib); il.addWidget(self.inspection_table); self.tabs.addTab(iw,'Inspections')
        self.timeline_table=self._table(['Date/Time','Event Type','Title','Severity','Summary','Source']); self.tabs.addTab(self.timeline_table,'Timeline')
        self.document_table=self._table(['Type','Title','Version','Target','Effective Date','File']); self.document_table.cellDoubleClicked.connect(self.open_document); self.tabs.addTab(self.document_table,'Documents')
        self.attachment_table=self._table(['File Name','Type','Related','File Type','Uploaded At','Notes']); self.attachment_table.cellDoubleClicked.connect(self.open_attachment); aw=QWidget(); al=QVBoxLayout(aw); add=QPushButton('Add Attachment'); add.clicked.connect(self.add_attachment); al.addWidget(add); al.addWidget(self.attachment_table); self.tabs.addTab(aw,'Attachments')
    def _table(self, headers):
        t=QTableWidget(); t.setColumnCount(len(headers)); t.setHorizontalHeaderLabels(headers); t.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); t.setSelectionBehavior(QTableWidget.SelectRows); t.setEditTriggers(QTableWidget.NoEditTriggers); return t
    def _setrow(self,t,i,vals):
        for j,v in enumerate(vals):
            it=QTableWidgetItem(str(v or '')); it.setFlags(it.flags() ^ Qt.ItemIsEditable); t.setItem(i,j,it)
    def load_data(self):
        a=self.service.get_system_detail(self.asset_id)
        if not a: QMessageBox.warning(self,'Not Found','System was not found.'); self.close(); return
        self.title_label.setText(f"{a.get('hospital_name')} / {a.get('system_serial')}"); self.basic_info.setText(f"Hospital: {a.get('hospital_name') or '-'}\nSerial: {a.get('system_serial') or '-'}\nSystem Type: {a.get('system_type') or '-'}\nVersion: {a.get('current_version') or '-'}\nStatus: {a.get('current_status') or '-'}\nInstall Date: {a.get('install_date') or '-'}\nCountry: {a.get('country') or '-'}\nDistributor: {a.get('distributor_name') or '-'}")
        self.load_schedule(); self.load_parts(); self.load_inspections(); self.load_timeline(); self.load_documents(a.get('system_type')); self.load_attachments()
    def load_schedule(self):
        s=self.service.get_inspection_schedule(self.asset_id); self.schedule_text.setText('No inspection schedule.' if not s else f"Due Date: {s.get('inspection_due_date') or '-'}\nDeadline: {s.get('inspection_deadline') or '-'}\nPlanned Start: {s.get('planned_start_datetime') or '-'}\nPlanned End: {s.get('planned_end_datetime') or '-'}\nStatus: {s.get('next_inspection_status') or '-'}\nNotes:\n{s.get('notes') or '-'}")
    def load_parts(self):
        rows=self.service.list_part_replacements(self.asset_id); self.parts_table.setRowCount(len(rows))
        for i,r in enumerate(rows): self._setrow(self.parts_table,i,[r.get('replacement_datetime'),r.get('replaced_part'),r.get('case_no'),r.get('replaced_by'),r.get('replacement_reason'),r.get('notes')])
    def load_inspections(self):
        self.inspection_rows=self.service.list_inspection_records(self.asset_id); self.inspection_table.setRowCount(len(self.inspection_rows))
        for i,r in enumerate(self.inspection_rows): self._setrow(self.inspection_table,i,[r.get('inspection_datetime'),r.get('case_no'),r.get('inspector_name') or r.get('primary_engineer'),r.get('work_start_datetime'),r.get('work_end_datetime'),r.get('salesforce_update_status'),r.get('findings')])
    def load_timeline(self):
        rows=self.service.get_timeline(self.asset_id); self.timeline_table.setRowCount(len(rows))
        for i,r in enumerate(rows): self._setrow(self.timeline_table,i,[r.get('event_datetime'),r.get('event_type'),r.get('title'),r.get('severity'),r.get('summary'),f"{r.get('source_table') or '-'} / {r.get('source_id') or '-'}"])
    def load_documents(self, system_type):
        self.document_rows=DocumentService().list_documents(target_system_type=system_type,latest_only=True); self.document_table.setRowCount(len(self.document_rows))
        for i,r in enumerate(self.document_rows): self._setrow(self.document_table,i,[r.get('document_type'),r.get('title'),r.get('version'),r.get('target_system_type') or 'Common',r.get('effective_date'),'Open' if Path(r.get('file_path') or '').exists() else 'Missing'])
    def load_attachments(self):
        self.attachment_rows=AttachmentService().list_asset_attachments(self.asset_id); self.attachment_table.setRowCount(len(self.attachment_rows))
        for i,r in enumerate(self.attachment_rows): self._setrow(self.attachment_table,i,[r.get('file_name'),r.get('attachment_type'),r.get('related_table'),r.get('file_type'),r.get('uploaded_at'),r.get('notes')])
    def open_schedule_dialog(self):
        from modules.ib_console.ui.inspection_schedule_dialog import InspectionScheduleDialog
        if InspectionScheduleDialog(self.asset_id,self).exec(): self.load_schedule(); self.load_timeline()
    def open_part_dialog(self):
        from modules.ib_console.ui.part_replacement_dialog import PartReplacementDialog
        if PartReplacementDialog(self.asset_id,self).exec(): self.load_parts(); self.load_timeline()
    def open_inspection_dialog(self):
        from modules.ib_console.ui.inspection_record_dialog import InspectionRecordDialog
        if InspectionRecordDialog(self.asset_id,self).exec(): self.load_inspections(); self.load_timeline()
    def open_inspection_detail(self,row:int,col:int):
        if 0 <= row < len(self.inspection_rows): QMessageBox.information(self,'Inspection',f"Inspection ID:\n{self.inspection_rows[row]['inspection_id']}")
    def open_document(self,row:int,col:int):
        p=Path(self.document_rows[row].get('file_path') or '') if 0 <= row < len(self.document_rows) else None
        if p and p.exists(): QDesktopServices.openUrl(QUrl.fromLocalFile(str(p.resolve())))
    def add_attachment(self):
        from PySide6.QtWidgets import QFileDialog
        path,_=QFileDialog.getOpenFileName(self,'Select Attachment','','All Files (*.*)')
        if path: AttachmentService().add_attachment('assets',self.asset_id,path,asset_id=self.asset_id,attachment_type='General',notes='Asset attachment'); self.load_attachments()
    def open_attachment(self,row:int,col:int):
        p=Path(self.attachment_rows[row].get('file_path') or '') if 0 <= row < len(self.attachment_rows) else None
        if p and p.exists(): QDesktopServices.openUrl(QUrl.fromLocalFile(str(p.resolve())))
