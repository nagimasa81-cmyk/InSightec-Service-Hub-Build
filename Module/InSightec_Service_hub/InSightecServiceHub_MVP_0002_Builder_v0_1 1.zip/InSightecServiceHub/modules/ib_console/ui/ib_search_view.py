from __future__ import annotations
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLineEdit,QPushButton,QTableWidget,QTableWidgetItem,QHeaderView,QLabel
from modules.ib_console.services.ib_service import IBService
class IBSearchView(QWidget):
    def __init__(self)->None:
        super().__init__(); self.service=IBService(); self.current_rows=[]; self._build_ui(); self.load_data()
    def _build_ui(self)->None:
        layout=QVBoxLayout(self); row=QHBoxLayout(); self.search_edit=QLineEdit(); self.search_edit.setPlaceholderText('Search hospital, serial, type, distributor...'); self.search_edit.returnPressed.connect(self.load_data)
        b=QPushButton('Search'); b.clicked.connect(self.load_data); r=QPushButton('Refresh'); r.clicked.connect(self.refresh)
        row.addWidget(QLabel('Keyword')); row.addWidget(self.search_edit); row.addWidget(b); row.addWidget(r); layout.addLayout(row)
        self.table=QTableWidget(); self.table.setColumnCount(8); self.table.setHorizontalHeaderLabels(['Hospital','Serial','Type','Version','Status','Country','Distributor','Install Date']); self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); self.table.setSelectionBehavior(QTableWidget.SelectRows); self.table.setEditTriggers(QTableWidget.NoEditTriggers); self.table.cellDoubleClicked.connect(self.open_detail); layout.addWidget(self.table)
    def refresh(self): self.search_edit.clear(); self.load_data()
    def load_data(self):
        self.current_rows=self.service.search_systems(self.search_edit.text().strip()); self.table.setRowCount(len(self.current_rows))
        for i,row in enumerate(self.current_rows):
            vals=[row.get('hospital_name'),row.get('system_serial'),row.get('system_type'),row.get('current_version'),row.get('current_status'),row.get('country'),row.get('distributor_name'),row.get('install_date')]
            for j,v in enumerate(vals):
                it=QTableWidgetItem(str(v or '')); it.setFlags(it.flags() ^ Qt.ItemIsEditable); self.table.setItem(i,j,it)
    def open_detail(self,row:int,column:int):
        from modules.ib_console.ui.system_detail_view import SystemDetailDialog
        if 0 <= row < len(self.current_rows): SystemDetailDialog(self.current_rows[row]['system_id'], self).exec(); self.load_data()
