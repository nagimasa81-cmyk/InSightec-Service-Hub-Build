from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QTextEdit,QPushButton,QComboBox,QMessageBox,QWidget
from modules.ib_console.services.ib_service import IBService
class InspectionScheduleDialog(QDialog):
    def __init__(self, system_id:str, parent:QWidget|None=None): super().__init__(parent); self.system_id=system_id; self.service=IBService(); self.setWindowTitle('Inspection Schedule'); self.resize(620,420); self._build_ui(); self.load_data()
    def _build_ui(self):
        l=QVBoxLayout(self); self.due=QLineEdit(); self.due.setPlaceholderText('YYYY-MM-DD'); self.dead=QLineEdit(); self.dead.setPlaceholderText('YYYY-MM-DD'); self.ps=QLineEdit(); self.ps.setPlaceholderText('YYYY-MM-DD HH:MM:SS'); self.pe=QLineEdit(); self.pe.setPlaceholderText('YYYY-MM-DD HH:MM:SS'); self.status=QComboBox(); self.status.addItems(['未定','スケジュール済み','予定日入力済み','完了']); self.notes=QTextEdit()
        for label,w in [('Inspection Due Date',self.due),('Inspection Deadline',self.dead),('Planned Start',self.ps),('Planned End',self.pe),('Status',self.status),('Notes',self.notes)]: l.addWidget(QLabel(label)); l.addWidget(w)
        row=QHBoxLayout(); s=QPushButton('Save'); s.clicked.connect(self.save); c=QPushButton('Cancel'); c.clicked.connect(self.reject); row.addStretch(); row.addWidget(s); row.addWidget(c); l.addLayout(row)
    def load_data(self):
        r=self.service.get_inspection_schedule(self.system_id)
        if r: self.due.setText(r.get('inspection_due_date') or ''); self.dead.setText(r.get('inspection_deadline') or ''); self.ps.setText(r.get('planned_start_datetime') or ''); self.pe.setText(r.get('planned_end_datetime') or ''); self.notes.setText(r.get('notes') or ''); idx=self.status.findText(r.get('next_inspection_status') or '未定'); self.status.setCurrentIndex(max(idx,0))
    def save(self):
        try: self.service.create_or_update_inspection_schedule(self.system_id,self.due.text().strip() or None,self.dead.text().strip() or None,self.ps.text().strip() or None,self.pe.text().strip() or None,self.status.currentText(),self.notes.toPlainText().strip() or None); self.accept()
        except Exception as e: QMessageBox.critical(self,'Save Failed',str(e))
