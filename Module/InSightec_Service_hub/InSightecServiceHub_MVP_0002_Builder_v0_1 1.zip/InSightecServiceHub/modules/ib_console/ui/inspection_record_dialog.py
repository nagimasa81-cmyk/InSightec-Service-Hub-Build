from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QTextEdit,QPushButton,QComboBox,QMessageBox,QWidget
from modules.ib_console.services.ib_service import IBService
class InspectionRecordDialog(QDialog):
    def __init__(self, system_id:str, parent:QWidget|None=None): super().__init__(parent); self.system_id=system_id; self.service=IBService(); self.setWindowTitle('Inspection Record'); self.resize(680,620); self._build_ui()
    def _build_ui(self):
        l=QVBoxLayout(self); self.dt=QLineEdit(); self.dt.setPlaceholderText('YYYY-MM-DD HH:MM:SS'); self.ws=QLineEdit(); self.we=QLineEdit(); self.case=QLineEdit(); self.insp=QLineEdit(); self.find=QTextEdit(); self.act=QTextEdit(); self.rem=QTextEdit(); self.sf=QComboBox(); self.sf.addItems(['未入力','入力済み','要確認']); self.notes=QTextEdit()
        for label,w in [('Inspection Datetime',self.dt),('Work Start',self.ws),('Work End',self.we),('Case No.',self.case),('Inspector',self.insp),('Findings',self.find),('Actions',self.act),('Remaining Items',self.rem),('Salesforce Status',self.sf),('Notes',self.notes)]: l.addWidget(QLabel(label)); l.addWidget(w)
        row=QHBoxLayout(); s=QPushButton('Save'); s.clicked.connect(self.save); c=QPushButton('Cancel'); c.clicked.connect(self.reject); row.addStretch(); row.addWidget(s); row.addWidget(c); l.addLayout(row)
    def save(self):
        if not self.dt.text().strip(): QMessageBox.warning(self,'Missing','Inspection datetime is required.'); return
        try: self.service.add_inspection_record(self.system_id,self.dt.text().strip(),self.ws.text().strip() or None,self.we.text().strip() or None,self.case.text().strip() or None,self.insp.text().strip() or None,self.find.toPlainText().strip() or None,self.act.toPlainText().strip() or None,self.rem.toPlainText().strip() or None,self.sf.currentText(),self.notes.toPlainText().strip() or None); self.accept()
        except Exception as e: QMessageBox.critical(self,'Save Failed',str(e))
