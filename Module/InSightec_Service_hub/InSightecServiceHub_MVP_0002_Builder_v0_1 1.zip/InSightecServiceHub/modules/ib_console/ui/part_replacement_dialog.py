from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QTextEdit,QPushButton,QMessageBox,QWidget
from modules.ib_console.services.ib_service import IBService
class PartReplacementDialog(QDialog):
    def __init__(self, system_id:str, parent:QWidget|None=None): super().__init__(parent); self.system_id=system_id; self.service=IBService(); self.setWindowTitle('Part Replacement'); self.resize(620,460); self._build_ui()
    def _build_ui(self):
        l=QVBoxLayout(self); self.part=QLineEdit(); self.dt=QLineEdit(); self.dt.setPlaceholderText('YYYY-MM-DD HH:MM:SS'); self.case=QLineEdit(); self.by=QLineEdit(); self.reason=QTextEdit(); self.notes=QTextEdit()
        for label,w in [('Replaced Part',self.part),('Replacement Datetime',self.dt),('Case No.',self.case),('Replaced By',self.by),('Reason',self.reason),('Notes',self.notes)]: l.addWidget(QLabel(label)); l.addWidget(w)
        row=QHBoxLayout(); s=QPushButton('Save'); s.clicked.connect(self.save); c=QPushButton('Cancel'); c.clicked.connect(self.reject); row.addStretch(); row.addWidget(s); row.addWidget(c); l.addLayout(row)
    def save(self):
        if not self.part.text().strip() or not self.dt.text().strip(): QMessageBox.warning(self,'Missing','Part and datetime are required.'); return
        try: self.service.add_part_replacement(self.system_id,self.part.text().strip(),self.dt.text().strip(),self.case.text().strip() or None,self.by.text().strip() or None,self.reason.toPlainText().strip() or None,self.notes.toPlainText().strip() or None); self.accept()
        except Exception as e: QMessageBox.critical(self,'Save Failed',str(e))
