from PySide6.QtWidgets import QWidget,QVBoxLayout,QLabel
from modules.ib_console.ui.ib_search_view import IBSearchView
class IBConsoleModule(QWidget):
    def __init__(self): super().__init__(); self.setObjectName('IBConsoleModule'); l=QVBoxLayout(self); title=QLabel('IB Database Console'); title.setObjectName('ModuleTitle'); l.addWidget(title); l.addWidget(IBSearchView())
