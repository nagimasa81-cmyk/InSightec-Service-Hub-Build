from __future__ import annotations
from typing import Any, Optional
from core.database.db_manager import DBManager

class AssetService:
    def __init__(self, db: Optional[DBManager]=None)->None: self.db=db or DBManager()
    def search_assets(self, keyword:str='')->list[dict[str,Any]]:
        k=keyword.strip(); like=f'%{k}%'
        return self.db.fetch_all('''SELECT a.*, h.hospital_name,h.country,h.city,c.company_name AS distributor_name FROM assets a JOIN hospitals h ON a.hospital_id=h.hospital_id LEFT JOIN companies c ON h.company_id=c.company_id WHERE a.deleted_at IS NULL AND h.deleted_at IS NULL AND (?='' OR a.system_serial LIKE ? OR a.asset_name LIKE ? OR a.system_type LIKE ? OR h.hospital_name LIKE ? OR c.company_name LIKE ?) ORDER BY h.hospital_name,a.system_serial''',[k,like,like,like,like,like])
    def get_asset_detail(self, asset_id:str)->Optional[dict[str,Any]]:
        return self.db.fetch_one('''SELECT a.*,h.hospital_name,h.country,h.city,h.address,h.contact_name,h.contact_email,h.contact_phone,c.company_name AS distributor_name FROM assets a JOIN hospitals h ON a.hospital_id=h.hospital_id LEFT JOIN companies c ON h.company_id=c.company_id WHERE a.asset_id=? AND a.deleted_at IS NULL''',[asset_id])
    def create_hospital(self,hospital_name:str,company_id:Optional[str]=None,country:Optional[str]=None,city:Optional[str]=None,notes:Optional[str]=None)->str:
        hid=self.db.new_id('hospital'); self.db.insert('hospitals',{'hospital_id':hid,'company_id':company_id,'hospital_name':hospital_name,'country':country,'city':city,'notes':notes}); return hid
    def create_asset(self,hospital_id:str,system_serial:str,system_type:str,asset_name:Optional[str]=None,asset_type:str='FUS System',current_version:Optional[str]=None,install_date:Optional[str]=None,notes:Optional[str]=None,created_by_user_id:Optional[str]=None)->str:
        aid=self.db.new_id('asset'); self.db.insert('assets',{'asset_id':aid,'hospital_id':hospital_id,'asset_name':asset_name,'system_serial':system_serial,'asset_type':asset_type,'system_type':system_type,'current_version':current_version,'install_date':install_date,'notes':notes}); self.add_timeline_event(aid,'AssetCreated',self.db.now_text(),'Asset registered',f'Asset {system_serial} was registered.','assets',aid,'Info',created_by_user_id); return aid
    def list_components(self,asset_id:str)->list[dict[str,Any]]:
        return self.db.fetch_all('''SELECT ac.*,cm.component_name,cm.component_category FROM asset_components ac JOIN component_master cm ON ac.component_master_id=cm.component_master_id WHERE ac.asset_id=? AND ac.deleted_at IS NULL ORDER BY cm.component_category,cm.component_name''',[asset_id])
    def add_asset_component(self,asset_id:str,component_master_id:str,component_serial:Optional[str]=None,component_version:Optional[str]=None,installed_at:Optional[str]=None,notes:Optional[str]=None)->str:
        acid=self.db.new_id('assetcomp'); self.db.insert('asset_components',{'asset_component_id':acid,'asset_id':asset_id,'component_master_id':component_master_id,'component_serial':component_serial,'component_version':component_version,'installed_at':installed_at,'notes':notes}); self.add_component_history(asset_id,'Installed',installed_at or self.db.now_text(),acid,component_master_id,None,None,None,component_serial,notes); return acid
    def add_component_history(self,asset_id:str,history_type:str,history_datetime:str,asset_component_id:Optional[str]=None,component_master_id:Optional[str]=None,service_event_id:Optional[str]=None,replacement_id:Optional[str]=None,old_value:Optional[str]=None,new_value:Optional[str]=None,notes:Optional[str]=None)->str:
        cid=self.db.new_id('comphist'); self.db.insert('component_history',{'component_history_id':cid,'asset_id':asset_id,'asset_component_id':asset_component_id,'component_master_id':component_master_id,'service_event_id':service_event_id,'replacement_id':replacement_id,'history_type':history_type,'history_datetime':history_datetime,'old_value':old_value,'new_value':new_value,'notes':notes}); return cid
    def get_timeline(self,asset_id:str)->list[dict[str,Any]]:
        return self.db.fetch_all('SELECT * FROM timeline_events WHERE asset_id=? AND deleted_at IS NULL ORDER BY event_datetime DESC, created_at DESC',[asset_id])
    def add_timeline_event(self,asset_id:str,event_type:str,event_datetime:str,title:str,summary:Optional[str]=None,source_table:Optional[str]=None,source_id:Optional[str]=None,severity:str='Info',created_by_user_id:Optional[str]=None)->str:
        tid=self.db.new_id('timeline'); self.db.insert('timeline_events',{'timeline_id':tid,'asset_id':asset_id,'event_type':event_type,'event_datetime':event_datetime,'title':title,'summary':summary,'source_table':source_table,'source_id':source_id,'severity':severity,'created_by_user_id':created_by_user_id}); return tid
