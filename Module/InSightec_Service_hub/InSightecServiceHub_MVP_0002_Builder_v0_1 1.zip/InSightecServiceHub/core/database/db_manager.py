from __future__ import annotations
import sqlite3, shutil, uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Optional

class DBManager:
    def __init__(self, db_path: str|Path='data/service_hub.db', schema_path: str|Path='core/database/service_hub_schema_v2.sql', backup_dir: str|Path='data/backups') -> None:
        self.db_path=Path(db_path); self.schema_path=Path(schema_path); self.backup_dir=Path(backup_dir)
        self.db_path.parent.mkdir(parents=True, exist_ok=True); self.backup_dir.mkdir(parents=True, exist_ok=True)
    @staticmethod
    def new_id(prefix: Optional[str]=None)->str:
        v=str(uuid.uuid4()); return f'{prefix}_{v}' if prefix else v
    @staticmethod
    def now_text()->str: return datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    def connect(self)->sqlite3.Connection:
        conn=sqlite3.connect(self.db_path); conn.row_factory=sqlite3.Row; conn.execute('PRAGMA foreign_keys=ON;'); return conn
    def initialize_database(self)->None:
        if not self.schema_path.exists(): raise FileNotFoundError(f'Schema not found: {self.schema_path}')
        with self.connect() as conn:
            conn.executescript(self.schema_path.read_text(encoding='utf-8')); conn.commit()
    def backup_database(self)->Path:
        if not self.db_path.exists(): raise FileNotFoundError(f'Database not found: {self.db_path}')
        p=self.backup_dir/f"service_hub_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"; shutil.copy2(self.db_path,p); return p
    def execute(self, sql:str, params:Optional[Iterable[Any]]=None)->int:
        with self.connect() as conn:
            cur=conn.execute(sql, tuple(params or [])); conn.commit(); return cur.rowcount
    def fetch_one(self, sql:str, params:Optional[Iterable[Any]]=None)->Optional[dict[str,Any]]:
        with self.connect() as conn:
            row=conn.execute(sql, tuple(params or [])).fetchone(); return dict(row) if row else None
    def fetch_all(self, sql:str, params:Optional[Iterable[Any]]=None)->list[dict[str,Any]]:
        with self.connect() as conn:
            return [dict(r) for r in conn.execute(sql, tuple(params or [])).fetchall()]
    def insert(self, table:str, data:dict[str,Any])->str:
        cols=list(data.keys()); vals=[data[c] for c in cols]
        self.execute(f"INSERT INTO {table} ({','.join(cols)}) VALUES ({','.join(['?']*len(cols))})", vals)
        return str(vals[0]) if vals else ''
    def update_by_id(self, table:str, id_column:str, id_value:str, data:dict[str,Any])->int:
        if not data: return 0
        data=dict(data); data['updated_at']=self.now_text(); cols=list(data.keys())
        return self.execute(f"UPDATE {table} SET {','.join([c+'=?' for c in cols])} WHERE {id_column}=? AND deleted_at IS NULL", [data[c] for c in cols]+[id_value])
    def soft_delete(self, table:str, id_column:str, id_value:str)->int:
        now=self.now_text(); return self.execute(f"UPDATE {table} SET deleted_at=?, updated_at=? WHERE {id_column}=? AND deleted_at IS NULL", [now, now, id_value])
