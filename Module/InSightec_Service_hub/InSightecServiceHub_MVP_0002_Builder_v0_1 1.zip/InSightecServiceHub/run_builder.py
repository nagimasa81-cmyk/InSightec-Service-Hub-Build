# run_builder.py
from builder.builder_gui import main

if __name__ == "__main__":
    main()
