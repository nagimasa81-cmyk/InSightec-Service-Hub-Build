InSightec Service Hub Builder v0.1

Purpose:
- Dedicated builder for InSightec Service Hub.
- Scans modules/*/manifest.json automatically.
- Builds platform or selected modules using Nuitka.
- Creates release ZIP packages.
- Saves build logs under build_logs/.

GUI:
  00_RUN_BUILDER_GUI.bat

CLI examples:
  python -m builder.build_cli --target validate
  python -m builder.build_cli --target platform
  python -m builder.build_cli --target platform --debug
  python -m builder.build_cli --target module --module-id ib_console
  python -m builder.build_cli --target all
  python -m builder.build_cli --target clean

Requirements:
  pip install nuitka ordered-set zstandard PySide6

Notes:
- Platform build target is run_service_hub.py.
- Module build creates a temporary runner under temp_build/.
- If Nuitka is not installed, validation still works but build will fail with a clear log.
