# builder/build_cli.py
# InSightec Service Hub - Builder CLI v0.1

from __future__ import annotations

import argparse
from pathlib import Path

from builder.build_core import BuildCore


def main() -> None:
    parser = argparse.ArgumentParser(description="InSightec Service Hub Builder CLI")
    parser.add_argument("--target", choices=["platform", "all", "module", "validate", "clean"], default="platform")
    parser.add_argument("--module-id", default="")
    parser.add_argument("--debug", action="store_true")
    parser.add_argument("--no-zip", action="store_true")
    parser.add_argument("--project-root", default=".")
    args = parser.parse_args()

    core = BuildCore(project_root=Path(args.project_root))

    if args.target == "validate":
        result = core.validate()
        raise SystemExit(0 if result["ok"] else 1)

    if args.target == "clean":
        core.clean()
        raise SystemExit(0)

    if args.target == "platform":
        result = core.build_platform(debug=args.debug, create_zip=not args.no_zip)
        raise SystemExit(0 if result.ok else 1)

    if args.target == "all":
        results = core.build_all_modules(debug=args.debug, create_zip=not args.no_zip)
        raise SystemExit(0 if all(item.ok for item in results) else 1)

    if args.target == "module":
        modules = core.discover_modules()
        selected = None
        for manifest in modules:
            if manifest.get("module_id") == args.module_id:
                selected = manifest
                break
        if not selected:
            print(f"Module not found: {args.module_id}")
            raise SystemExit(2)
        result = core.build_module(selected, debug=args.debug, create_zip=not args.no_zip)
        raise SystemExit(0 if result.ok else 1)


if __name__ == "__main__":
    main()
