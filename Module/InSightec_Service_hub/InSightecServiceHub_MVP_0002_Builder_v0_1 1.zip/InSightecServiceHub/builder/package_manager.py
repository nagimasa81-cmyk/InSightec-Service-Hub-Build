# builder/package_manager.py
# InSightec Service Hub - Builder Package Manager

from __future__ import annotations

import shutil
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Iterable


class PackageManager:
    def __init__(self, project_root: str | Path) -> None:
        self.project_root = Path(project_root).resolve()
        self.release_root = self.project_root / "release"
        self.release_root.mkdir(parents=True, exist_ok=True)

    def create_release_zip(
        self,
        package_name: str,
        sources: Iterable[str | Path],
        output_dir: str | Path | None = None,
    ) -> Path:
        output_dir_path = Path(output_dir) if output_dir else self.release_root
        output_dir_path.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        zip_path = output_dir_path / f"{package_name}_{timestamp}.zip"

        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for source in sources:
                source_path = Path(source)
                if not source_path.is_absolute():
                    source_path = self.project_root / source_path
                if not source_path.exists():
                    continue

                if source_path.is_file():
                    zf.write(source_path, source_path.relative_to(self.project_root))
                else:
                    for file_path in source_path.rglob("*"):
                        if file_path.is_file():
                            if any(part == "__pycache__" for part in file_path.parts):
                                continue
                            zf.write(file_path, file_path.relative_to(self.project_root))

        return zip_path

    def clean_paths(self, paths: Iterable[str | Path]) -> list[Path]:
        removed: list[Path] = []
        for path in paths:
            target = Path(path)
            if not target.is_absolute():
                target = self.project_root / target
            if target.exists():
                if target.is_dir():
                    shutil.rmtree(target)
                else:
                    target.unlink()
                removed.append(target)
        return removed
