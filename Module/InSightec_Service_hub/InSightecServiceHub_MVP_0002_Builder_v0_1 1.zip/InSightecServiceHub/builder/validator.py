# builder/validator.py
# InSightec Service Hub - Builder Validator

from __future__ import annotations

from pathlib import Path
from typing import Any


class ValidationResult(dict):
    pass


class BuilderValidator:
    def __init__(self, project_root: str | Path) -> None:
        self.project_root = Path(project_root).resolve()

    def validate_manifest(self, manifest: dict[str, Any]) -> ValidationResult:
        errors: list[str] = []
        warnings: list[str] = []

        required = ["module_id", "module_name", "version", "entry"]
        for key in required:
            if not manifest.get(key):
                errors.append(f"Missing required key: {key}")

        entry = manifest.get("entry")
        if entry:
            try:
                module_path, class_name = entry.rsplit(".", 1)
                module_file = self.project_root / (module_path.replace(".", "/") + ".py")
                module_dir_init = self.project_root / module_path.replace(".", "/") / "__init__.py"
                if not module_file.exists() and not module_dir_init.exists():
                    errors.append(f"Entry module file was not found: {module_path}")
                if not class_name:
                    errors.append(f"Entry class name is empty: {entry}")
            except Exception as exc:
                errors.append(f"Entry format is invalid: {entry} ({exc})")

        if not manifest.get("enabled", True):
            warnings.append("Module is disabled.")

        return ValidationResult(ok=not errors, errors=errors, warnings=warnings)

    def validate_project(self, manifests: list[dict[str, Any]]) -> dict[str, Any]:
        results = []
        for manifest in manifests:
            result = self.validate_manifest(manifest)
            results.append({"module_id": manifest.get("module_id"), "result": result})
        return {"ok": all(item["result"].get("ok") for item in results), "modules": results}
