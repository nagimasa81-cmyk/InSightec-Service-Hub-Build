# builder/manifest_manager.py
# InSightec Service Hub - Builder Manifest Manager

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class ManifestManager:
    def __init__(self, project_root: str | Path) -> None:
        self.project_root = Path(project_root).resolve()
        self.modules_root = self.project_root / "modules"

    def load_manifest(self, manifest_path: str | Path) -> dict[str, Any]:
        path = Path(manifest_path)
        data = json.loads(path.read_text(encoding="utf-8"))
        data["_manifest_path"] = str(path)
        data["_module_dir"] = str(path.parent)
        return data

    def discover_modules(self) -> list[dict[str, Any]]:
        modules: list[dict[str, Any]] = []

        if not self.modules_root.exists():
            return modules

        for manifest_path in sorted(self.modules_root.glob("*/manifest.json")):
            try:
                manifest = self.load_manifest(manifest_path)
                manifest.setdefault("enabled", True)
                modules.append(manifest)
            except Exception as exc:
                modules.append(
                    {
                        "module_id": manifest_path.parent.name,
                        "module_name": manifest_path.parent.name,
                        "version": "unknown",
                        "enabled": False,
                        "error": str(exc),
                        "_manifest_path": str(manifest_path),
                        "_module_dir": str(manifest_path.parent),
                    }
                )

        return modules

    def get_platform_version(self) -> str:
        candidates = [
            self.project_root / "platform_manifest.json",
            self.project_root / "manifest.json",
        ]
        for path in candidates:
            if path.exists():
                try:
                    return json.loads(path.read_text(encoding="utf-8")).get("version", "1.0.0")
                except Exception:
                    pass
        return "1.0.0"

    def update_module_version(self, module_id: str, version: str) -> None:
        manifest_path = self.modules_root / module_id / "manifest.json"
        if not manifest_path.exists():
            raise FileNotFoundError(f"Manifest not found: {manifest_path}")

        data = json.loads(manifest_path.read_text(encoding="utf-8"))
        data["version"] = version
        manifest_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
