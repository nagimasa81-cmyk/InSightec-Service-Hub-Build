from __future__ import annotations
import sys
from PySide6.QtWidgets import QApplication,QMainWindow,QMessageBox
from core.database.db_manager import DBManager
from modules.ib_console.ib_console_module import IBConsoleModule
class IBConsoleStandalone(QMainWindow):
    def __init__(self): super().__init__(); self.setWindowTitle('InSightec Service Hub - IB Database Console'); self.resize(1280,820); self.setCentralWidget(IBConsoleModule())
def main():
    app=QApplication(sys.argv)
    try: DBManager('data/service_hub.db','core/database/service_hub_schema_v2.sql','data/backups').initialize_database()
    except Exception as e: QMessageBox.critical(None,'Database Initialization Failed',str(e)); sys.exit(1)
    w=IBConsoleStandalone(); w.show(); sys.exit(app.exec())
if __name__=='__main__': main()
