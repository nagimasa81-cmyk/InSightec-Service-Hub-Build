@echo off
cd /d %~dp0
python run_builder.py
pause
