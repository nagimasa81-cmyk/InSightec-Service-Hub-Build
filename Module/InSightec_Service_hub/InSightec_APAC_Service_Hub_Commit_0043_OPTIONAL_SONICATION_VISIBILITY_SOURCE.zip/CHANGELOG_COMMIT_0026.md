# Commit 0026 — RC8.6 Sonication Tool Registration Fix

## Root cause
`tools/SonicationAnalysis/manifest.json` existed in the source package, but `sonication_analysis` was missing from `config.json`. In the assembled Hub distribution the Sonication manifest was therefore not guaranteed to be copied/discovered, and the runtime tool list contained only five active analysis tools.

## Fix
- Added `sonication_analysis` to the canonical `config.json` tool registry.
- Fixed folder to `tools/SonicationAnalysis`.
- Fixed primary executable to `Sonication_Replay_Engine.exe`.
- Added all accepted executable aliases.
- Enabled the tool as an active module.
- Preserved manifest-based override when `manifest.json` is available.

## Expected result
The all-tool trace must include `tool_id: sonication_analysis`, and executable validation must select `Sonication_Replay_Engine.exe` or one of its accepted aliases.
