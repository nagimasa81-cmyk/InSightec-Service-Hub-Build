# Commit 0043 — Optional Sonication Visibility Enforcement

- Excluded builds remove `sonication_analysis` from `config.json`.
- Excluded builds remove `tools/SonicationAnalysis`, preventing manifest rediscovery.
- Excluded builds remove Sonication from version tool lists.
- Included builds retain the existing Sonication card and runtime integration.
