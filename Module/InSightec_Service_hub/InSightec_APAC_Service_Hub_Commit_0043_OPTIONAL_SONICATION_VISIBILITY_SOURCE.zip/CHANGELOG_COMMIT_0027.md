# Commit0027 — Complete Dataset Handoff

- Added `primary_input` to every native handoff payload.
- Preserves the original dropped ZIP/folder ahead of matched member files.
- Enables Sonication Replay to auto-load a complete dataset after Hub launch.
