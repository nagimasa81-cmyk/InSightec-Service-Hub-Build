# Roadmap

- Commit0001: Foundation
- Commit0002: Binary Explorer and structure detection
- Commit0003: Spectrum frame parser
- Commit0004: FFT viewer
- Commit0005: Peak and cavitation analysis
- Commit0006: Replay API
- Commit0007: Temperature analyzer
- Commit0008: Replay Studio
