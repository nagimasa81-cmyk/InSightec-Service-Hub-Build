# SpectrumMsg Analyzer RC1 Commit0002

## Main features

- ZIP / folder import
- Drag and drop
- Sonication-centered explorer
- Extended file classification
- Binary Explorer
  - HEX
  - ASCII
  - UInt16 / UInt32 / UInt64
  - Int16 / Int32
  - Float32 / Float64
  - Little / Big endian
  - Offset jump
  - HEX / ASCII search
  - Auto detector
  - Header candidate list
  - Bookmarks
  - Structure markers
  - JSON template save/load

## Run

`build\03_RUN_DEBUG.bat`

## Build

`build\01_BUILD_EXE.bat`

Commit0002 is a reverse-engineering aid. It does not yet claim that detected
header fields or frame boundaries are definitive SpectrumMsg structures.
