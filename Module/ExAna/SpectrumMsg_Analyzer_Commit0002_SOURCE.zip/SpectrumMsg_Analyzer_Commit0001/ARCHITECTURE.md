# Architecture

Import -> Discovery -> Domain Model -> Binary Analysis -> Capability -> UI

## Commit0002 additions

- `binary_analysis_service.py`
  - Byte loading
  - Numeric decoding
  - Search
  - Heuristic type scoring
  - Candidate header field detection
- `binary_explorer.py`
  - Offset navigation
  - HEX/ASCII/numeric synchronized inspection
  - Endian/type controls
  - Bookmarks
  - Structure markers
  - JSON template save/load
