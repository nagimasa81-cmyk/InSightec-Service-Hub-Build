# Changelog

## RC1 Commit0002

- Added advanced Binary Explorer.
- Added synchronized HEX, ASCII and numeric interpretation views.
- Added little/big endian switching.
- Added UInt16, UInt32, UInt64, Int16, Int32, Float32 and Float64 decoding.
- Added offset jump.
- Added HEX and ASCII search.
- Added bookmark support.
- Added basic structure markers.
- Added automatic binary type scoring.
- Added template export/import as JSON.
- Improved discovery classification for FFT, text, hydrophone, calibration and replay files.
- Added candidate header field analysis.
