from __future__ import annotations

import logging
from collections import defaultdict
from pathlib import Path

from PySide6.QtCore import QByteArray, Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QFileDialog,
    QGroupBox,
    QHeaderView,
    QLabel,
    QMainWindow,
    QMessageBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from src.common.constants import APP_NAME
from src.common.settings import create_settings
from src.domain.models import DiscoveredFile, TreatmentPackage
from src.services.capability_service import CapabilityService
from src.services.discovery_service import DiscoveryService
from src.services.import_service import ImportErrorUser, ImportService
from src.ui.binary_explorer import BinaryExplorer

LOG = logging.getLogger(__name__)
APP_VERSION = "RC1 Commit0002"


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} - {APP_VERSION}")
        self.resize(1500, 950)
        self.setAcceptDrops(True)

        self.settings = create_settings()
        self.import_service = ImportService()
        self.discovery_service = DiscoveryService()
        self.capability_service = CapabilityService()
        self.package: TreatmentPackage | None = None

        self._build_actions()
        self._build_ui()
        self._restore_layout()
        self.statusBar().showMessage("Ready")

    def _build_actions(self) -> None:
        menu = self.menuBar().addMenu("&File")

        self.open_zip_action = QAction("Open ZIP...", self)
        self.open_zip_action.triggered.connect(self.open_zip)
        menu.addAction(self.open_zip_action)

        self.open_folder_action = QAction("Open Folder...", self)
        self.open_folder_action.triggered.connect(self.open_folder)
        menu.addAction(self.open_folder_action)

        reload_action = QAction("Reload", self)
        reload_action.triggered.connect(self.reload_source)
        menu.addAction(reload_action)

        menu.addSeparator()
        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        menu.addAction(exit_action)

        toolbar = self.addToolBar("Main")
        toolbar.setMovable(False)
        toolbar.addAction(self.open_zip_action)
        toolbar.addAction(self.open_folder_action)
        toolbar.addAction(reload_action)

    def _build_ui(self) -> None:
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Item", "Type", "Size"])
        self.tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.tree.itemSelectionChanged.connect(self._selection_changed)

        explorer_box = QGroupBox("Treatment Explorer")
        explorer_layout = QVBoxLayout(explorer_box)
        explorer_layout.addWidget(self.tree)

        self.info_label = QLabel("Open a ZIP file or folder.")
        self.info_label.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.info_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        self.capability_table = QTableWidget(0, 3)
        self.capability_table.setHorizontalHeaderLabels(["Capability", "Status", "Detail"])
        self.capability_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.capability_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)

        info_box = QGroupBox("Package Information")
        info_layout = QVBoxLayout(info_box)
        info_layout.addWidget(self.info_label)
        info_layout.addWidget(self.capability_table, 1)

        top_splitter = QSplitter(Qt.Orientation.Horizontal)
        top_splitter.addWidget(explorer_box)
        top_splitter.addWidget(info_box)
        top_splitter.setSizes([520, 900])

        self.binary_explorer = BinaryExplorer()
        self.binary_explorer.status_message.connect(self.statusBar().showMessage)

        self.main_splitter = QSplitter(Qt.Orientation.Vertical)
        self.main_splitter.addWidget(top_splitter)
        self.main_splitter.addWidget(self.binary_explorer)
        self.main_splitter.setSizes([360, 560])

        central = QWidget()
        layout = QVBoxLayout(central)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.addWidget(self.main_splitter)
        self.setCentralWidget(central)

    def open_zip(self) -> None:
        filename, _ = QFileDialog.getOpenFileName(
            self, "Open Treatment ZIP", "", "ZIP files (*.zip)"
        )
        if filename:
            self.load_source(Path(filename))

    def open_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Open Treatment Folder")
        if folder:
            self.load_source(Path(folder))

    def reload_source(self) -> None:
        if self.package:
            self.load_source(self.package.source)

    def load_source(self, source: Path) -> None:
        self.statusBar().showMessage(f"Loading {source.name}...")
        try:
            workspace = self.import_service.import_path(source)
            package = self.discovery_service.discover(source, workspace)
        except ImportErrorUser as exc:
            QMessageBox.warning(self, APP_NAME, str(exc))
            self.statusBar().showMessage("Import failed")
            return
        except Exception as exc:
            LOG.exception("Unexpected import error")
            QMessageBox.critical(self, APP_NAME, f"Unexpected error:\n{exc}")
            self.statusBar().showMessage("Import failed")
            return

        self.package = package
        self._populate_tree(package)
        self._populate_information(package)
        self.settings.setValue("recent_source", str(source))
        self.statusBar().showMessage(
            f"Loaded {len(package.files)} files / {len(package.sonications)} sonications"
        )

    def _populate_tree(self, package: TreatmentPackage) -> None:
        self.tree.clear()
        root = QTreeWidgetItem(
            [package.source.name, "Treatment", f"{len(package.files)} files"]
        )
        root.setData(0, Qt.ItemDataRole.UserRole, None)
        self.tree.addTopLevelItem(root)

        grouped: dict[str, list[DiscoveredFile]] = defaultdict(list)
        for item in package.files:
            grouped[item.sonication or "Package"].append(item)

        def sort_key(name: str):
            if name.startswith("Sonication"):
                try:
                    return (0, int(name.replace("Sonication", "")))
                except ValueError:
                    pass
            return (1, name.lower())

        for group_name in sorted(grouped, key=sort_key):
            group_item = QTreeWidgetItem([group_name, "Group", ""])
            root.addChild(group_item)

            by_category: dict[str, list[DiscoveredFile]] = defaultdict(list)
            for item in grouped[group_name]:
                by_category[item.category].append(item)

            for category in sorted(by_category):
                category_item = QTreeWidgetItem(
                    [category, "Category", f"{len(by_category[category])} files"]
                )
                group_item.addChild(category_item)

                for discovered in by_category[category]:
                    file_item = QTreeWidgetItem(
                        [
                            discovered.path.name,
                            discovered.category,
                            self._format_size(discovered.size),
                        ]
                    )
                    file_item.setToolTip(0, str(discovered.path))
                    file_item.setData(0, Qt.ItemDataRole.UserRole, str(discovered.path))
                    category_item.addChild(file_item)

            group_item.setExpanded(True)

        root.setExpanded(True)

    def _populate_information(self, package: TreatmentPackage) -> None:
        total_size = sum(item.size for item in package.files)
        self.info_label.setText(
            f"<b>Source:</b> {package.source}<br>"
            f"<b>Workspace:</b> {package.workspace}<br>"
            f"<b>Files:</b> {len(package.files):,}<br>"
            f"<b>Sonications:</b> {len(package.sonications):,}<br>"
            f"<b>Total size:</b> {self._format_size(total_size)}"
        )

        capabilities = self.capability_service.analyze(package)
        self.capability_table.setRowCount(len(capabilities))
        for row, (name, (status, detail)) in enumerate(capabilities.items()):
            self.capability_table.setItem(row, 0, QTableWidgetItem(name))
            self.capability_table.setItem(row, 1, QTableWidgetItem(status))
            self.capability_table.setItem(row, 2, QTableWidgetItem(detail))

    def _selection_changed(self) -> None:
        items = self.tree.selectedItems()
        if not items:
            return
        raw_path = items[0].data(0, Qt.ItemDataRole.UserRole)
        if raw_path:
            path = Path(raw_path)
            if path.is_file():
                self.binary_explorer.show_file(path)

    @staticmethod
    def _format_size(size: int) -> str:
        value = float(size)
        for unit in ("B", "KB", "MB", "GB"):
            if value < 1024 or unit == "GB":
                return f"{value:.1f} {unit}"
            value /= 1024
        return f"{size} B"

    def dragEnterEvent(self, event) -> None:
        urls = event.mimeData().urls()
        if urls and any(url.isLocalFile() for url in urls):
            event.acceptProposedAction()

    def dropEvent(self, event) -> None:
        for url in event.mimeData().urls():
            if not url.isLocalFile():
                continue
            path = Path(url.toLocalFile())
            if path.is_dir() or path.suffix.lower() == ".zip":
                self.load_source(path)
                event.acceptProposedAction()
                return
        QMessageBox.information(self, APP_NAME, "Drop a treatment ZIP file or folder.")

    def _restore_layout(self) -> None:
        geometry = self.settings.value("geometry")
        state = self.settings.value("window_state")
        splitter = self.settings.value("main_splitter")

        if isinstance(geometry, QByteArray):
            self.restoreGeometry(geometry)
        if isinstance(state, QByteArray):
            self.restoreState(state)
        if isinstance(splitter, QByteArray):
            self.main_splitter.restoreState(splitter)

    def closeEvent(self, event) -> None:
        self.settings.setValue("geometry", self.saveGeometry())
        self.settings.setValue("window_state", self.saveState())
        self.settings.setValue("main_splitter", self.main_splitter.saveState())
        self.import_service.cleanup()
        super().closeEvent(event)
