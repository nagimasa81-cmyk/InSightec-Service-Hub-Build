from __future__ import annotations

import math
import struct
import tempfile
from pathlib import Path

from PySide6.QtWidgets import QApplication

from src.services.discovery_service import DiscoveryService
from src.services.signal_visualization_service import SignalVisualizationService
from src.services.structure_detection_service import StructureDetectionService
from src.ui.main_window import MainWindow


def make_sample(root: Path) -> Path:
    sonication = root / "Sonication1"
    sonication.mkdir(parents=True)

    header = b"SPECTRUMMSG" + b"\x00" * (32 - len("SPECTRUMMSG"))
    values = []
    for index in range(6516):
        value = (
            math.exp(-((index - 900) / 80) ** 2) * 100.0
            + math.exp(-((index - 1800) / 120) ** 2) * 40.0
        )
        values.append(struct.pack("<f", value))

    (sonication / "SpectrumMsg-1.dmp").write_bytes(
        header + b"".join(values) * 3
    )
    (sonication / "Sonication1.act").write_text(
        "Power=100\n",
        encoding="utf-8",
    )
    (sonication / "5-0.raw").write_bytes(b"\x00" * 1024)
    (root / "ProtocolData.xml").write_text("<root/>", encoding="utf-8")
    return sonication / "SpectrumMsg-1.dmp"


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="SpectrumMsgVerify_") as temp:
        root = Path(temp)
        spectrum_path = make_sample(root)
        data = spectrum_path.read_bytes()

        package = DiscoveryService().discover(root, root)
        assert len(package.files) == 4
        assert any(item.category == "SpectrumMsg" for item in package.files)

        signal = SignalVisualizationService().analyze(
            data=data,
            offset=32,
            sample_count=2048,
            numeric_type="Float32",
            endian="Little",
            stride=1,
        )
        assert len(signal.values) == 2048
        assert signal.stats.finite_ratio == 1.0

        structure = StructureDetectionService().analyze(data)
        assert structure.frame_count >= 2
        assert structure.frame_size > 0

        app = QApplication.instance() or QApplication([])
        window = MainWindow()
        assert window.analysis_tabs.count() == 3
        window.close()
        app.processEvents()

    print("VERIFY_SOURCE_OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
