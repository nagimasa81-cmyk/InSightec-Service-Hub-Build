# Changelog

## RC1 Commit0004b Triple Checked

- Revalidated all Python source files with `compileall` and `py_compile`.
- Performed a real PySide6 offscreen startup test.
- Performed an end-to-end synthetic treatment-folder test.
- Verified ZIP/folder discovery, SpectrumMsg selection, Binary Explorer,
  Signal Visualization and Structure Analysis.
- Added a stable `objectName` to the main toolbar so window-state persistence
  does not produce a Qt warning.
- Added `verify_source.py` and `build/00_VERIFY_SOURCE.bat`.
- Renamed the package root to match Commit0004b.

## RC1 Commit0004a Hot Fix

- Fixed `Qt.TextInteractionFlag.TextSelectableByMouse`.
