# Changelog

## RC1 Commit0004a Hot Fix

- Fixed startup failure in Signal Visualizer.
- Replaced invalid `QLabel.TextSelectableByMouse` access with
  `Qt.TextInteractionFlag.TextSelectableByMouse`.
- Added the required `Qt` import.
- Re-ran syntax validation for all Python files.

## RC1 Commit0004

- Added Signal Visualization Engine.
