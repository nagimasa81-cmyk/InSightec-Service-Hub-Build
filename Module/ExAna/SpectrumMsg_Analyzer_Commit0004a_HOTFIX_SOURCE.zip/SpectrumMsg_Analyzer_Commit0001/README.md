# SpectrumMsg Analyzer RC1 Commit0004a Hot Fix

This package fixes the Commit0004 startup error:

`QLabel object has no attribute TextSelectableByMouse`

## Run

`build\03_RUN_DEBUG.bat`

## Verification

1. Start the application.
2. Open a treatment ZIP.
3. Select a SpectrumMsg file.
4. Confirm that Signal Visualization opens.
5. Confirm that the Current Region values can be selected with the mouse.
