# Architecture

Import -> Sonication Discovery -> Series Resolution -> Replay Model -> UI

## Integration boundary

`src/integration/spectrum_provider.py` defines the stable contract:

- `SpectrumFrame`
- `SpectrumProvider`
- `NullSpectrumProvider`

A future adapter can import SpectrumMsg Analyzer's decoder package or consume its
JSON/CSV output without changing the Replay UI or domain model.

The intended shared package name is `fus_spectrum_contracts` once both projects
are consolidated.
