# Sonication Replay Engine RC1 Prototype

A standalone viewer that reconstructs each Sonication using only files found
inside Sonication folders.

## Current prototype capabilities

- Open a treatment ZIP, a Sonication-only ZIP, or an extracted folder.
- Discover `SonicationN` folders recursively.
- Detect temperature RAW series (`5-*.raw`, float32, 256x256).
- Detect magnitude RAW series (`6-*.raw`, uint16, 256x256).
- Display magnitude, temperature and transparent overlay.
- Play, pause, step, jump and change replay speed.
- Show hotspot coordinates, maximum/mean temperature and frame counts.
- Detect ACT and SpectrumMsg files per Sonication.
- Expose a stable Spectrum Provider interface for future integration with
  SpectrumMsg Analyzer.

## Important limitations

- RAW prefix mappings are based on the sample Sonication exports inspected so far.
- Temperature and magnitude series may have different frame counts. RC1 maps them
  on a normalized timeline.
- Exact MR/Spectrum timestamps are not yet decoded.
- Spectrum display is a placeholder summary until the SpectrumMsg Analyzer bridge
  is connected.

## Run

`build\03_RUN_DEBUG.bat`

## Verify

`build\00_VERIFY_SOURCE.bat`

## Build EXE

`build\01_BUILD_EXE.bat`
