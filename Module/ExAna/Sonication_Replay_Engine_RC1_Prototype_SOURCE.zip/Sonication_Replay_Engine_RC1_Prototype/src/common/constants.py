APP_NAME = "Sonication Replay Engine"
APP_VERSION = "RC1 Prototype Commit0001"
ORGANIZATION = "InSightec Service Tools"
IMAGE_SHAPE = (256, 256)
TEMPERATURE_PREFIX = "5"
MAGNITUDE_PREFIX = "6"
