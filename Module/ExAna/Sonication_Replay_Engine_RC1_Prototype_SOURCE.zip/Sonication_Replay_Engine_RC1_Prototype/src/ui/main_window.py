from __future__ import annotations
import logging
from pathlib import Path
import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import Qt,QTimer,QSettings,QByteArray
from PySide6.QtGui import QAction
from PySide6.QtWidgets import QMainWindow,QFileDialog,QMessageBox,QTreeWidget,QTreeWidgetItem,QSplitter,QWidget,QVBoxLayout,QHBoxLayout,QPushButton,QSlider,QLabel,QSpinBox,QGroupBox,QTableWidget,QTableWidgetItem,QHeaderView
from src.common.constants import APP_NAME,APP_VERSION,ORGANIZATION
from src.domain.models import ReplayPackage,SonicationModel
from src.services.import_service import ImportService
from src.services.discovery_service import DiscoveryService
from src.services.replay_service import ReplayService
from src.integration.spectrum_provider import NullSpectrumProvider,SpectrumMsgAnalyzerAdapter
from src.ui.image_panel import ImagePanel

LOG=logging.getLogger(__name__)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle(f'{APP_NAME} - {APP_VERSION}'); self.resize(1600,950); self.setAcceptDrops(True)
        self.settings=QSettings(ORGANIZATION,APP_NAME); self.importer=ImportService(); self.discovery=DiscoveryService(); self.replay=ReplayService(); self.spectrum_provider=NullSpectrumProvider()
        self.package=None; self.current=None; self.frame_index=0; self.timer=QTimer(self); self.timer.timeout.connect(self.next_frame)
        self._actions(); self._ui(); self._restore()
    def _actions(self):
        menu=self.menuBar().addMenu('&File'); oz=QAction('Open ZIP...',self); oz.triggered.connect(self.open_zip); menu.addAction(oz); of=QAction('Open Folder...',self); of.triggered.connect(self.open_folder); menu.addAction(of); menu.addSeparator(); ex=QAction('Exit',self); ex.triggered.connect(self.close); menu.addAction(ex)
        tb=self.addToolBar('Main'); tb.setObjectName('MainToolbar'); tb.setMovable(False); tb.addAction(oz); tb.addAction(of)
    def _ui(self):
        self.tree=QTreeWidget(); self.tree.setHeaderLabels(['Sonication / Data','Count']); self.tree.itemSelectionChanged.connect(self.select_sonication)
        left=QGroupBox('Sonications'); ll=QVBoxLayout(left); ll.addWidget(self.tree)
        self.mag=ImagePanel('Magnitude'); self.temp=ImagePanel('Temperature'); self.overlay=ImagePanel('Overlay')
        images=QSplitter(Qt.Orientation.Horizontal); images.addWidget(self.mag); images.addWidget(self.temp); images.addWidget(self.overlay); images.setSizes([1,1,1])
        self.slider=QSlider(Qt.Orientation.Horizontal); self.slider.valueChanged.connect(self.slider_changed)
        first=QPushButton('|<'); prev=QPushButton('<'); self.play=QPushButton('Play'); nxt=QPushButton('>'); last=QPushButton('>|')
        first.clicked.connect(lambda:self.set_frame(0)); prev.clicked.connect(self.previous_frame); self.play.clicked.connect(self.toggle_play); nxt.clicked.connect(self.next_frame); last.clicked.connect(lambda:self.set_frame(max(0,self.current.replay_frame_count-1) if self.current else 0))
        self.speed=QSpinBox(); self.speed.setRange(1,20); self.speed.setValue(5); self.speed.setSuffix(' fps'); self.speed.valueChanged.connect(self.speed_changed)
        self.frame_label=QLabel('Frame -/-'); controls=QHBoxLayout();
        for x in [first,prev,self.play,nxt,last,self.frame_label,self.slider,QLabel('Speed'),self.speed]: controls.addWidget(x)
        self.metrics=QTableWidget(0,2); self.metrics.setHorizontalHeaderLabels(['Metric','Value']); self.metrics.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch); self.metrics.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        metrics_box=QGroupBox('Replay / Integration Status'); ml=QVBoxLayout(metrics_box); ml.addWidget(self.metrics)
        center=QWidget(); cl=QVBoxLayout(center); cl.addWidget(images,1); cl.addLayout(controls); cl.addWidget(metrics_box)
        self.main_split=QSplitter(Qt.Orientation.Horizontal); self.main_split.addWidget(left); self.main_split.addWidget(center); self.main_split.setSizes([320,1250]); self.setCentralWidget(self.main_split); self.statusBar().showMessage('Ready')
    def open_zip(self):
        f,_=QFileDialog.getOpenFileName(self,'Open treatment or Sonication ZIP','','ZIP files (*.zip)');
        if f:self.load(Path(f))
    def open_folder(self):
        f=QFileDialog.getExistingDirectory(self,'Open treatment or Sonication folder');
        if f:self.load(Path(f))
    def load(self,source):
        try: ws=self.importer.open(source); pkg=self.discovery.discover(source,ws)
        except Exception as e: QMessageBox.critical(self,APP_NAME,str(e)); return
        self.package=pkg; self.tree.clear()
        if not pkg.sonications: QMessageBox.information(self,APP_NAME,'No Sonication folder or compatible Sonication files were found.'); return
        for son in pkg.sonications:
            item=QTreeWidgetItem([son.name,f'{son.replay_frame_count} replay frames']); item.setData(0,Qt.ItemDataRole.UserRole,son.name); self.tree.addTopLevelItem(item)
            for name,count in [('Temperature RAW',len(son.temperature_frames)),('Magnitude RAW',len(son.magnitude_frames)),('SpectrumMsg',len(son.spectrum_files)),('ACT',len(son.act_files)),('Other',len(son.other_files))]: item.addChild(QTreeWidgetItem([name,str(count)]))
            item.setExpanded(True)
        self.tree.setCurrentItem(self.tree.topLevelItem(0)); self.statusBar().showMessage(f'Loaded {len(pkg.sonications)} sonication(s)')
    def select_sonication(self):
        items=self.tree.selectedItems();
        if not items or items[0].parent() is not None:return
        name=items[0].data(0,Qt.ItemDataRole.UserRole); self.current=next((s for s in self.package.sonications if s.name==name),None); self.set_frame(0)
    def set_frame(self,index):
        if not self.current:return
        try:data=self.replay.frame(self.current,index)
        except Exception as e: QMessageBox.warning(self,APP_NAME,f'Unable to decode frame\n{e}'); return
        self.frame_index=data.replay_index; self.slider.blockSignals(True); self.slider.setRange(0,max(0,self.current.replay_frame_count-1)); self.slider.setValue(self.frame_index); self.slider.blockSignals(False)
        self.frame_label.setText(f'Frame {self.frame_index+1}/{self.current.replay_frame_count}')
        mag=data.magnitude
        if mag is not None: self.mag.set_image(mag,levels=(float(np.percentile(mag,1)),float(np.percentile(mag,99))))
        else:self.mag.set_image(None)
        temp=data.temperature; lut=pg.colormap.get('CET-L4').getLookupTable(0,1,256)
        if temp is not None:
            finite=temp[np.isfinite(temp)]; levels=(float(np.percentile(finite,2)),float(np.percentile(finite,98))) if finite.size else None
            self.temp.set_image(temp,levels=levels,lut=lut,hotspot=(data.hotspot_x,data.hotspot_y) if data.hotspot_x is not None else None)
        else:self.temp.set_image(None)
        if mag is not None:
            self.overlay.set_image(mag,levels=(float(np.percentile(mag,1)),float(np.percentile(mag,99))))
            if temp is not None:
                # For RC1, overlay is temperature-dominant with hotspot on aligned geometry.
                self.overlay.set_image(temp,levels=levels,lut=lut,hotspot=(data.hotspot_x,data.hotspot_y) if data.hotspot_x is not None else None)
        else:self.overlay.set_image(temp,levels=levels if temp is not None else None,lut=lut if temp is not None else None)
        provider=SpectrumMsgAnalyzerAdapter(); spectrum_status='Bridge ready; decoder not connected' if provider.supports(self.current.spectrum_files) else 'No SpectrumMsg'
        rows=[('Sonication',self.current.name),('Replay frame',f'{self.frame_index+1}/{self.current.replay_frame_count}'),('Magnitude frame',str(data.magnitude_index) if data.magnitude_index is not None else 'Missing'),('Temperature frame',str(data.temperature_index) if data.temperature_index is not None else 'Missing'),('Maximum temperature',f'{data.maximum_temperature:.2f} °C' if data.maximum_temperature is not None else 'Unavailable'),('Mean temperature',f'{data.mean_temperature:.2f} °C' if data.mean_temperature is not None else 'Unavailable'),('Hotspot',f'X={data.hotspot_x}, Y={data.hotspot_y}' if data.hotspot_x is not None else 'Unavailable'),('ACT',f'{len(self.current.act_files)} file(s)'),('Spectrum',spectrum_status),('Sync mode','Normalized frame mapping (RC1)')]
        self.metrics.setRowCount(len(rows));
        for r,(k,v) in enumerate(rows): self.metrics.setItem(r,0,QTableWidgetItem(k)); self.metrics.setItem(r,1,QTableWidgetItem(v))
    def slider_changed(self,v): self.set_frame(v)
    def previous_frame(self): self.set_frame(max(0,self.frame_index-1))
    def next_frame(self):
        if not self.current:return
        n=self.frame_index+1
        if n>=self.current.replay_frame_count:n=0 if self.timer.isActive() else self.current.replay_frame_count-1
        self.set_frame(n)
    def toggle_play(self):
        if self.timer.isActive(): self.timer.stop(); self.play.setText('Play')
        else:self.timer.start(max(20,int(1000/self.speed.value()))); self.play.setText('Pause')
    def speed_changed(self,v):
        if self.timer.isActive():self.timer.start(max(20,int(1000/v)))
    def dragEnterEvent(self,e):
        if any(u.isLocalFile() for u in e.mimeData().urls()):e.acceptProposedAction()
    def dropEvent(self,e):
        for u in e.mimeData().urls():
            if u.isLocalFile():
                p=Path(u.toLocalFile())
                if p.is_dir() or p.suffix.lower()=='.zip':self.load(p);e.acceptProposedAction();return
    def _restore(self):
        g=self.settings.value('geometry'); s=self.settings.value('state'); sp=self.settings.value('splitter')
        if isinstance(g,QByteArray):self.restoreGeometry(g)
        if isinstance(s,QByteArray):self.restoreState(s)
        if isinstance(sp,QByteArray):self.main_split.restoreState(sp)
    def closeEvent(self,e):
        self.timer.stop(); self.settings.setValue('geometry',self.saveGeometry()); self.settings.setValue('state',self.saveState()); self.settings.setValue('splitter',self.main_split.saveState()); self.importer.cleanup(); super().closeEvent(e)
