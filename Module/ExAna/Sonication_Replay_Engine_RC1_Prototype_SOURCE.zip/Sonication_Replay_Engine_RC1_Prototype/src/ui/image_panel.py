from __future__ import annotations
import numpy as np
import pyqtgraph as pg
from PySide6.QtWidgets import QGroupBox,QVBoxLayout,QWidget

class ImagePanel(QGroupBox):
    def __init__(self,title,parent=None):
        super().__init__(title,parent)
        self.view=pg.PlotWidget(); self.view.setAspectLocked(True); self.view.hideAxis('left'); self.view.hideAxis('bottom')
        self.image=pg.ImageItem(); self.view.addItem(self.image)
        self.hotspot=pg.ScatterPlotItem(size=14,symbol='+'); self.view.addItem(self.hotspot)
        layout=QVBoxLayout(self); layout.addWidget(self.view)
    def set_image(self,array:np.ndarray|None,levels=None,lut=None,hotspot=None):
        if array is None:
            self.image.clear(); self.hotspot.setData([]); return
        self.image.setImage(array.T,autoLevels=levels is None,levels=levels)
        if lut is not None: self.image.setLookupTable(lut)
        if hotspot is not None: self.hotspot.setData([hotspot[0]],[hotspot[1]])
        else: self.hotspot.setData([])
