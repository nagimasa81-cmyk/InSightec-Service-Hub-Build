# Roadmap

- Commit0001: Sonication folder replay prototype
- Commit0002: RAW profile resolver and manual mapping UI
- Commit0003: SpectrumMsg Analyzer adapter and spectrum panel
- Commit0004: ACT metadata and accurate timeline synchronization
- Commit0005: Export, bookmarks and investigation notes
- Later: merge into Replay Studio / FUS Investigation Platform
