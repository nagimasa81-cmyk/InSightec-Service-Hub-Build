# Changelog

## RC1 Prototype Commit0001

- Added ZIP/folder import and recursive Sonication discovery.
- Added Sonication-only ZIP support.
- Added temperature and magnitude RAW resolvers.
- Added synchronized replay timeline.
- Added magnitude, temperature and overlay viewers.
- Added hotspot and temperature metrics.
- Added ACT/SpectrumMsg capability status.
- Added Spectrum Provider integration contract for future Analyzer integration.
- Added source verification and Nuitka build BAT files.
