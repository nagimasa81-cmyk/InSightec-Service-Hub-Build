from pathlib import Path
import tempfile, numpy as np
from src.services.discovery_service import DiscoveryService
from src.services.raw_service import RawService
from src.services.replay_service import ReplayService

def main():
    with tempfile.TemporaryDirectory(prefix='SonReplayVerify_') as t:
        root=Path(t); son=root/'Sonication1'; son.mkdir()
        temp=np.full((256,256),37.0,dtype='<f4'); temp[100,120]=52.5; temp.tofile(son/'5-1-3-0.raw')
        mag=np.arange(256*256,dtype='<u2').reshape(256,256); mag.tofile(son/'6-1-0-0.raw')
        (son/'SpectrumMsg-1.dmp').write_bytes(b'example'); (son/'Sonication1.act').write_text('Power=100',encoding='utf-8')
        pkg=DiscoveryService().discover(root,root); assert len(pkg.sonications)==1
        model=pkg.sonications[0]; assert len(model.temperature_frames)==1 and len(model.magnitude_frames)==1
        frame=ReplayService().frame(model,0); assert frame.maximum_temperature==52.5 and frame.hotspot_x==120 and frame.hotspot_y==100
    print('VERIFY_SOURCE_OK'); return 0
if __name__=='__main__':raise SystemExit(main())
