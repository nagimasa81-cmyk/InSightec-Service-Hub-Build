# SpectrumMsg Analyzer RC1 Commit0005

Spectrum Decoder Engine with candidate scanning, frequency axis, peak and harmonic labels, replay, compare, TXT correlation and CSV export.

Run `build\00_VERIFY_SOURCE.bat`, then `build\03_RUN_DEBUG.bat`.
