from __future__ import annotations
import math,struct,tempfile
from pathlib import Path
from PySide6.QtWidgets import QApplication
from src.services.spectrum_decoder_service import SpectrumDecoderService
from src.ui.main_window import MainWindow
def main():
 with tempfile.TemporaryDirectory() as td:
  root=Path(td); vals=[]; ref=[]
  for i in range(2048):
   v=math.exp(-((i-400)/18)**2)*100+math.exp(-((i-800)/24)**2)*45+math.exp(-((i-200)/14)**2)*30;ref.append(v);vals.append(struct.pack('<f',v))
  data=b'SPECTRUMMSG'+b'\0'*21+b''.join(vals)*4
  d=SpectrumDecoderService();c=d.decode_candidate(data,32,2048,'Float32','Little',1,1_300_000,ref)
  assert c.correlation and c.correlation>.99 and len(c.peaks)>=3
  cs=d.scan_candidates(data,2048,'Float32','Little',1,1_300_000,32,20,ref);assert cs and cs[0].correlation>.99
  app=QApplication.instance() or QApplication([]);w=MainWindow();assert w.analysis_tabs.count()==4;w.close();app.processEvents()
 print('VERIFY_SOURCE_OK');return 0
if __name__=='__main__':raise SystemExit(main())
