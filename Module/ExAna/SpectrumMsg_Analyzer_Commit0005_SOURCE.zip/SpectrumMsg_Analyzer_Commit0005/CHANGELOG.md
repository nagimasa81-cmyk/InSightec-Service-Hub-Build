# Changelog

## RC1 Commit0005
- Added Spectrum Decoder Engine.
- Added candidate scanning, frequency axis, peak detection and harmonic labels.
- Added replay navigation, compare overlay, TXT reference correlation and CSV export.
- Added synthetic verification for candidate scanning and correlation.
