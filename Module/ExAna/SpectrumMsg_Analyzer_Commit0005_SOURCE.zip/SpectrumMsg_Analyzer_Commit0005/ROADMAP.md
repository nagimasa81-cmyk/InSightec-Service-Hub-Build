# Roadmap
- Commit0005: Spectrum Decoder Engine
- Commit0006: Cavitation Analysis and Timeline
- Commit0007: Replay API
- Commit0008: Temperature Analyzer
- Commit0009: Replay Studio
