from __future__ import annotations
import csv
from pathlib import Path
import numpy as np
from src.domain.spectrum_models import SpectrumCandidate,SpectrumPeak
from src.services.signal_visualization_service import SignalVisualizationService
class SpectrumDecoderService:
 def __init__(self): self.signal_service=SignalVisualizationService()
 def decode_candidate(self,data,offset,sample_count,numeric_type,endian,stride=1,max_frequency=1.0,reference=None):
  a=self.signal_service.analyze(data,offset,sample_count,numeric_type,endian,stride)
  amp=np.abs(np.nan_to_num(np.asarray(a.values,dtype=np.float64)))
  freq=np.linspace(0.0,float(max_frequency),num=len(amp),endpoint=False) if len(amp) else np.asarray([])
  peaks=self.detect_peaks(amp,freq); self.label_harmonics(peaks)
  corr=self.correlation(amp,reference) if reference else None
  score=a.fft_candidate_score+(8 if len(peaks)>=2 else 0)
  if corr is not None: score=score*.65+max(0,corr)*35
  return SpectrumCandidate(offset,numeric_type,endian,len(amp),stride,round(min(100,float(score)),1),[float(v) for v in amp],[float(v) for v in freq],peaks,self.broadband_energy(amp,peaks),corr,list(a.fft_candidate_reasons))
 def scan_candidates(self,data,sample_count,numeric_type,endian,stride=1,max_frequency=1.0,step_bytes=None,max_candidates=50,reference=None):
  sizes={'UInt16':2,'UInt32':4,'Int16':2,'Int32':4,'Float32':4,'Float64':8}; span=sizes[numeric_type]*stride*sample_count; step=step_bytes or max(sizes[numeric_type],span//4)
  out=[]
  for off in range(0,max(1,len(data)-sizes[numeric_type]+1),step):
   c=self.decode_candidate(data,off,sample_count,numeric_type,endian,stride,max_frequency,reference)
   if c.sample_count>=max(16,sample_count//4) and c.score>=25: out.append(c)
  out.sort(key=lambda c:(c.correlation if c.correlation is not None else -2,c.score),reverse=True)
  return out[:max_candidates]
 def detect_peaks(self,amp,freq,max_peaks=12):
  if amp.size<3:return []
  med=float(np.median(amp));std=float(np.std(amp));thr=med+max(std*1.5,float(np.max(amp))*.03)
  idx=[i for i in range(1,len(amp)-1) if amp[i]>=amp[i-1] and amp[i]>amp[i+1] and amp[i]>=thr]
  idx.sort(key=lambda i:float(amp[i]),reverse=True); sel=[]; dist=max(2,len(amp)//200)
  for i in idx:
   if all(abs(i-j)>=dist for j in sel):sel.append(i)
   if len(sel)>=max_peaks:break
  sel.sort();return [SpectrumPeak(i,float(freq[i]),float(amp[i])) for i in sel]
 def label_harmonics(self,peaks):
  if not peaks:return
  f=max(peaks,key=lambda p:p.amplitude);f.label='Main'
  if f.frequency<=0:return
  for p in peaks:
   if p is f:continue
   r=p.frequency/f.frequency
   if abs(r-.5)<=.08:p.label='Subharmonic'
   elif abs(r-2)<=.12:p.label='2nd Harmonic'
   elif abs(r-3)<=.18:p.label='3rd Harmonic'
 def broadband_energy(self,amp,peaks):
  if not amp.size:return 0.0
  mask=np.ones(amp.size,dtype=bool);rad=max(2,amp.size//100)
  for p in peaks:mask[max(0,p.index-rad):min(amp.size,p.index+rad+1)]=False
  x=amp[mask];return float(np.mean(x**2)) if x.size else 0.0
 def load_reference_txt(self,path):
  vals=[]
  for line in path.read_text(encoding='utf-8',errors='ignore').splitlines():
   nums=[]
   for part in line.replace(',',' ').replace(';',' ').split():
    try:nums.append(float(part))
    except ValueError:pass
   if nums:vals.append(nums[-1])
  return vals
 def correlation(self,amp,reference):
  if reference is None or len(reference)<4 or amp.size<4:return None
  ref=np.nan_to_num(np.asarray(reference,dtype=float));x=np.linspace(0,1,len(ref));y=np.linspace(0,1,len(amp));ref=np.interp(y,x,ref)
  a=amp-np.mean(amp);b=ref-np.mean(ref);d=float(np.linalg.norm(a)*np.linalg.norm(b));return 0.0 if d<=1e-12 else float(np.dot(a,b)/d)
 def export_csv(self,path,c):
  labels={p.index:p.label for p in c.peaks}
  with path.open('w',newline='',encoding='utf-8-sig') as h:
   wr=csv.writer(h);wr.writerow(['Index','Frequency','Amplitude','PeakLabel'])
   for i,v in enumerate(c.values):wr.writerow([i,c.frequencies[i],v,labels.get(i,'')])
