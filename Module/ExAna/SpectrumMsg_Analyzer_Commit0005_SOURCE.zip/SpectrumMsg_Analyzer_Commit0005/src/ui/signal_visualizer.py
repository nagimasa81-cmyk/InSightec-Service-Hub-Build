from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QComboBox,
    QFileDialog,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from src.domain.signal_models import SignalAnalysis
from src.services.signal_visualization_service import SignalVisualizationService

LOG = logging.getLogger(__name__)


class SignalVisualizer(QWidget):
    status_message = Signal(str)
    jump_requested = Signal(int)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.service = SignalVisualizationService()
        self.path: Path | None = None
        self.data = b""
        self.analysis: SignalAnalysis | None = None
        self._build_ui()

    def _build_ui(self) -> None:
        controls = QHBoxLayout()

        self.offset_edit = QLineEdit("0")
        self.offset_edit.setPlaceholderText("Offset: decimal or 0x...")
        jump_button = QPushButton("Jump")
        jump_button.clicked.connect(self.jump)

        prev_button = QPushButton("Previous Block")
        prev_button.clicked.connect(self.previous_block)

        next_button = QPushButton("Next Block")
        next_button.clicked.connect(self.next_block)

        self.type_combo = QComboBox()
        self.type_combo.addItems(
            ["UInt16", "UInt32", "Int16", "Int32", "Float32", "Float64"]
        )
        self.type_combo.setCurrentText("Float32")

        self.endian_combo = QComboBox()
        self.endian_combo.addItems(["Little", "Big"])

        self.count_spin = QSpinBox()
        self.count_spin.setRange(16, 1_000_000)
        self.count_spin.setValue(2048)
        self.count_spin.setSingleStep(256)

        self.stride_spin = QSpinBox()
        self.stride_spin.setRange(1, 1024)
        self.stride_spin.setValue(1)

        analyze_button = QPushButton("Visualize")
        analyze_button.clicked.connect(self.visualize)

        export_button = QPushButton("Export CSV")
        export_button.clicked.connect(self.export_csv)

        for widget in (
            QLabel("Offset"),
            self.offset_edit,
            jump_button,
            prev_button,
            next_button,
            QLabel("Type"),
            self.type_combo,
            QLabel("Endian"),
            self.endian_combo,
            QLabel("Samples"),
            self.count_spin,
            QLabel("Stride"),
            self.stride_spin,
            analyze_button,
            export_button,
        ):
            controls.addWidget(widget)

        self.waveform_plot = pg.PlotWidget()
        self.waveform_plot.setLabel("left", "Decoded Value")
        self.waveform_plot.setLabel("bottom", "Sample Index")
        self.waveform_plot.showGrid(x=True, y=True, alpha=0.25)

        self.histogram_plot = pg.PlotWidget()
        self.histogram_plot.setLabel("left", "Count")
        self.histogram_plot.setLabel("bottom", "Value")
        self.histogram_plot.showGrid(x=True, y=True, alpha=0.25)

        self.derivative_plot = pg.PlotWidget()
        self.derivative_plot.setLabel("left", "First Derivative")
        self.derivative_plot.setLabel("bottom", "Sample Index")
        self.derivative_plot.showGrid(x=True, y=True, alpha=0.25)

        self.spectrum_plot = pg.PlotWidget()
        self.spectrum_plot.setLabel("left", "Amplitude Candidate")
        self.spectrum_plot.setLabel("bottom", "Bin Index")
        self.spectrum_plot.showGrid(x=True, y=True, alpha=0.25)

        plots = QTabWidget()
        plots.addTab(self.waveform_plot, "Waveform")
        plots.addTab(self.histogram_plot, "Histogram")
        plots.addTab(self.derivative_plot, "Derivative")
        plots.addTab(self.spectrum_plot, "FFT Candidate")

        self.stats_labels: dict[str, QLabel] = {}
        stats_grid = QGridLayout()
        for row, key in enumerate(
            ["File", "Offset", "Count", "Min", "Max", "Mean", "StdDev", "Finite", "FFT Candidate"]
        ):
            stats_grid.addWidget(QLabel(f"{key}:"), row, 0)
            value = QLabel("-")
            value.setTextInteractionFlags(
                value.textInteractionFlags()
                | Qt.TextInteractionFlag.TextSelectableByMouse
            )
            stats_grid.addWidget(value, row, 1)
            self.stats_labels[key] = value

        self.reasons = QTextEdit()
        self.reasons.setReadOnly(True)
        self.reasons.setPlaceholderText("FFT-candidate evidence will appear here.")

        stats_box = QGroupBox("Current Region")
        stats_layout = QVBoxLayout(stats_box)
        stats_layout.addLayout(stats_grid)
        stats_layout.addWidget(self.reasons, 1)

        body = QHBoxLayout()
        body.addWidget(plots, 4)
        body.addWidget(stats_box, 1)

        outer = QVBoxLayout(self)
        outer.addLayout(controls)
        outer.addLayout(body, 1)

    def set_file(self, path: Path, data: bytes) -> None:
        self.path = path
        self.data = data
        self.analysis = None
        self.offset_edit.setText("0")
        self._clear_plots()
        self.stats_labels["File"].setText(path.name)
        self.status_message.emit(f"Signal source selected: {path.name}")

    def jump_to(self, offset: int) -> None:
        self.offset_edit.setText(hex(max(0, offset)))
        self.visualize()
        self.jump_requested.emit(max(0, offset))

    def jump(self) -> None:
        try:
            offset = int(self.offset_edit.text().strip(), 0)
        except ValueError:
            QMessageBox.warning(self, "Signal Visualization", "Use decimal or 0x-prefixed offset.")
            return
        self.jump_to(offset)

    def previous_block(self) -> None:
        current = self._current_offset()
        step = self._byte_span()
        self.jump_to(max(0, current - step))

    def next_block(self) -> None:
        current = self._current_offset()
        self.jump_to(min(max(0, len(self.data) - 1), current + self._byte_span()))

    def visualize(self) -> None:
        if not self.data:
            self.status_message.emit("No binary file selected.")
            return
        try:
            offset = self._current_offset()
            self.analysis = self.service.analyze(
                data=self.data,
                offset=offset,
                sample_count=self.count_spin.value(),
                numeric_type=self.type_combo.currentText(),
                endian=self.endian_combo.currentText(),
                stride=self.stride_spin.value(),
            )
            self._show_analysis(self.analysis)
            self.jump_requested.emit(offset)
            self.status_message.emit(
                f"Visualized {len(self.analysis.values):,} values from 0x{offset:08X}"
            )
        except Exception as exc:
            LOG.exception("Signal visualization failed")
            QMessageBox.critical(
                self,
                "Signal Visualization",
                f"Unable to visualize this region:\n{exc}",
            )

    def export_csv(self) -> None:
        if self.analysis is None:
            self.visualize()
        if self.analysis is None:
            return

        default_name = (
            f"{self.path.stem}_offset_{self.analysis.offset:08X}.csv"
            if self.path
            else "signal.csv"
        )
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Export Signal CSV",
            default_name,
            "CSV files (*.csv)",
        )
        if not filename:
            return
        try:
            self.service.export_csv(Path(filename), self.analysis)
            self.status_message.emit(f"Signal CSV exported: {filename}")
        except Exception as exc:
            QMessageBox.warning(self, "Signal Export", f"Unable to export CSV:\n{exc}")

    def _show_analysis(self, analysis: SignalAnalysis) -> None:
        self._clear_plots()
        values = np.asarray(analysis.values, dtype=np.float64)
        derivative = np.asarray(analysis.derivative, dtype=np.float64)

        if values.size:
            x = np.arange(values.size)
            self.waveform_plot.plot(x, values, clear=True)
            self.derivative_plot.plot(x, derivative, clear=True)
            self.spectrum_plot.plot(x, np.abs(values), clear=True)

        if analysis.histogram_counts and len(analysis.histogram_edges) > 1:
            counts = np.asarray(analysis.histogram_counts)
            edges = np.asarray(analysis.histogram_edges)
            centers = (edges[:-1] + edges[1:]) / 2.0
            width = float(np.mean(np.diff(edges))) if len(edges) > 1 else 1.0
            bars = pg.BarGraphItem(x=centers, height=counts, width=width)
            self.histogram_plot.addItem(bars)

        stats = analysis.stats
        self.stats_labels["File"].setText(self.path.name if self.path else "-")
        self.stats_labels["Offset"].setText(f"0x{analysis.offset:08X}")
        self.stats_labels["Count"].setText(f"{stats.count:,}")
        self.stats_labels["Min"].setText(f"{stats.minimum:.8g}")
        self.stats_labels["Max"].setText(f"{stats.maximum:.8g}")
        self.stats_labels["Mean"].setText(f"{stats.mean:.8g}")
        self.stats_labels["StdDev"].setText(f"{stats.stddev:.8g}")
        self.stats_labels["Finite"].setText(f"{stats.finite_ratio * 100:.2f}%")
        self.stats_labels["FFT Candidate"].setText(f"{analysis.fft_candidate_score:.1f}%")
        self.reasons.setPlainText(
            "\n".join(f"- {reason}" for reason in analysis.fft_candidate_reasons)
            or "- No positive FFT-candidate evidence."
        )

    def _clear_plots(self) -> None:
        for plot in (
            self.waveform_plot,
            self.histogram_plot,
            self.derivative_plot,
            self.spectrum_plot,
        ):
            plot.clear()

    def _current_offset(self) -> int:
        try:
            return max(0, min(int(self.offset_edit.text().strip(), 0), max(0, len(self.data) - 1)))
        except ValueError:
            return 0

    def _byte_span(self) -> int:
        sizes = {
            "UInt16": 2,
            "UInt32": 4,
            "Int16": 2,
            "Int32": 4,
            "Float32": 4,
            "Float64": 8,
        }
        return (
            sizes[self.type_combo.currentText()]
            * self.count_spin.value()
            * self.stride_spin.value()
        )
