from __future__ import annotations
from pathlib import Path
import numpy as np, pyqtgraph as pg
from PySide6.QtCore import QTimer,Qt,Signal
from PySide6.QtWidgets import *
from src.services.spectrum_decoder_service import SpectrumDecoderService
class SpectrumDecoderWidget(QWidget):
 status_message=Signal(str);jump_requested=Signal(int)
 def __init__(self,parent=None):
  super().__init__(parent);self.service=SpectrumDecoderService();self.path=None;self.data=b'';self.reference=None;self.reference_path=None;self.candidates=[];self.current_index=-1;self.compare_indices=[];self.timer=QTimer(self);self.timer.timeout.connect(self.next_candidate);self._build()
 def _build(self):
  c=QHBoxLayout();self.offset=QLineEdit('0');self.typ=QComboBox();self.typ.addItems(['UInt16','UInt32','Int16','Int32','Float32','Float64']);self.typ.setCurrentText('Float32');self.endian=QComboBox();self.endian.addItems(['Little','Big']);self.samples=QSpinBox();self.samples.setRange(32,262144);self.samples.setValue(2048);self.stride=QSpinBox();self.stride.setRange(1,1024);self.stride.setValue(1);self.maxf=QDoubleSpinBox();self.maxf.setRange(.001,1e9);self.maxf.setValue(1300000);self.step=QSpinBox();self.step.setRange(0,1_000_000_000);self.step.setSpecialValueText('Auto')
  b1=QPushButton('Decode Offset');b1.clicked.connect(self.decode_offset);b2=QPushButton('Search Candidates');b2.clicked.connect(self.scan);b3=QPushButton('Load TXT Reference');b3.clicked.connect(self.load_ref);b4=QPushButton('Export CSV');b4.clicked.connect(self.export)
  for w in [QLabel('Offset'),self.offset,QLabel('Type'),self.typ,QLabel('Endian'),self.endian,QLabel('Samples'),self.samples,QLabel('Stride'),self.stride,QLabel('Max Freq'),self.maxf,QLabel('Step'),self.step,b1,b2,b3,b4]:c.addWidget(w)
  r=QHBoxLayout();
  for text,fn in [('<<',self.first),('<',self.prev),('Play',lambda:self.timer.start(400)),('Stop',self.timer.stop),('>',self.next_candidate),('>>',self.last),('Add Compare',self.add_compare),('Clear Compare',self.clear_compare)]:
   b=QPushButton(text);b.clicked.connect(fn);r.addWidget(b)
  self.plot=pg.PlotWidget();self.plot.showGrid(x=True,y=True,alpha=.25);self.plot.setLabel('left','Amplitude');self.plot.setLabel('bottom','Frequency')
  self.table=QTableWidget(0,7);self.table.setHorizontalHeaderLabels(['#','Offset','Score','Correlation','Peaks','Broadband','Type']);self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch);self.table.itemDoubleClicked.connect(lambda i:self.select(i.row()))
  self.peaks=QTableWidget(0,4);self.peaks.setHorizontalHeaderLabels(['Label','Index','Frequency','Amplitude']);self.peaks.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch);self.summary=QTextEdit();self.summary.setReadOnly(True)
  rs=QSplitter(Qt.Orientation.Vertical);rs.addWidget(self.table);rs.addWidget(self.peaks);rs.addWidget(self.summary);body=QSplitter(Qt.Orientation.Horizontal);body.addWidget(self.plot);body.addWidget(rs);body.setSizes([1050,500])
  o=QVBoxLayout(self);o.addLayout(c);o.addLayout(r);o.addWidget(body)
 def set_file(self,path,data):self.path=path;self.data=data;self.reference=None;self.candidates=[];self.current_index=-1;self.plot.clear();self.table.setRowCount(0);self.peaks.setRowCount(0);self.summary.setText(f'Selected: {path.name}')
 def params(self,off):return dict(data=self.data,offset=off,sample_count=self.samples.value(),numeric_type=self.typ.currentText(),endian=self.endian.currentText(),stride=self.stride.value(),max_frequency=self.maxf.value(),reference=self.reference)
 def decode_offset(self):
  if not self.data:return
  c=self.service.decode_candidate(**self.params(int(self.offset.text(),0)));self.candidates=[c];self.current_index=0;self.refresh_table();self.show(c)
 def scan(self):
  if not self.data:return
  self.status_message.emit('Scanning candidates...');p=self.params(0);p.pop('offset');self.candidates=self.service.scan_candidates(**p,step_bytes=self.step.value() or None);self.current_index=0 if self.candidates else -1;self.refresh_table();
  if self.candidates:self.show(self.candidates[0])
  self.status_message.emit(f'Candidate scan: {len(self.candidates)}')
 def load_ref(self):
  f,_=QFileDialog.getOpenFileName(self,'Load TXT','','Text (*.txt *.csv);;All (*.*)')
  if f:self.reference_path=Path(f);self.reference=self.service.load_reference_txt(self.reference_path);self.status_message.emit(f'Reference: {len(self.reference)} values')
 def export(self):
  c=self.current();
  if not c:return
  f,_=QFileDialog.getSaveFileName(self,'Export CSV','spectrum.csv','CSV (*.csv)')
  if f:self.service.export_csv(Path(f),c)
 def current(self):return self.candidates[self.current_index] if 0<=self.current_index<len(self.candidates) else None
 def first(self):
  if self.candidates:self.select(0)
 def last(self):
  if self.candidates:self.select(len(self.candidates)-1)
 def prev(self):
  if self.candidates:self.select(max(0,self.current_index-1))
 def next_candidate(self):
  if not self.candidates:self.timer.stop();return
  self.select((self.current_index+1)%len(self.candidates))
 def select(self,i):self.current_index=i;self.show(self.candidates[i])
 def add_compare(self):
  if self.current_index>=0 and self.current_index not in self.compare_indices:self.compare_indices.append(self.current_index);self.show(self.current())
 def clear_compare(self):self.compare_indices=[];self.show(self.current()) if self.current() else None
 def show(self,c):
  self.plot.clear();self.plot.addLegend();self.plot.plot(np.asarray(c.frequencies),np.asarray(c.values),name=f'Current 0x{c.offset:08X}')
  for i in self.compare_indices:
   o=self.candidates[i];self.plot.plot(np.asarray(o.frequencies),np.asarray(o.values),name=f'Compare {i}')
  for p in c.peaks:self.plot.addItem(pg.InfiniteLine(pos=p.frequency,angle=90,label=p.label))
  self.offset.setText(hex(c.offset));self.jump_requested.emit(c.offset);self.peaks.setRowCount(len(c.peaks))
  for r,p in enumerate(c.peaks):
   for col,v in enumerate([p.label,p.index,p.frequency,p.amplitude]):self.peaks.setItem(r,col,QTableWidgetItem(str(v)))
  corr='-' if c.correlation is None else f'{c.correlation:.4f}';self.summary.setText(f'Offset: 0x{c.offset:08X}\nScore: {c.score:.1f}%\nCorrelation: {corr}\nBroadband: {c.broadband_energy:.8g}\nPeaks: {len(c.peaks)}')
  if self.current_index>=0:self.table.selectRow(self.current_index)
 def refresh_table(self):
  self.table.setRowCount(len(self.candidates))
  for r,c in enumerate(self.candidates):
   vals=[r,f'0x{c.offset:08X}',f'{c.score:.1f}%',('-' if c.correlation is None else f'{c.correlation:.4f}'),len(c.peaks),f'{c.broadband_energy:.6g}',f'{c.numeric_type}/{c.endian}']
   for col,v in enumerate(vals):self.table.setItem(r,col,QTableWidgetItem(str(v)))
