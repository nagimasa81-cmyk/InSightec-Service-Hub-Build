from __future__ import annotations
from dataclasses import dataclass, field
@dataclass(slots=True)
class SpectrumPeak:
    index:int; frequency:float; amplitude:float; label:str='Peak'
@dataclass(slots=True)
class SpectrumCandidate:
    offset:int; numeric_type:str; endian:str; sample_count:int; stride:int; score:float
    values:list[float]=field(default_factory=list); frequencies:list[float]=field(default_factory=list)
    peaks:list[SpectrumPeak]=field(default_factory=list); broadband_energy:float=0.0
    correlation:float|None=None; reasons:list[str]=field(default_factory=list)
