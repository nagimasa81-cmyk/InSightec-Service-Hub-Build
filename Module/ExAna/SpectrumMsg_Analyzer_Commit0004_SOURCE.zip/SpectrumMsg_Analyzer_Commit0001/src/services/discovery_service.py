from __future__ import annotations

import re
from pathlib import Path

from src.domain.models import DiscoveredFile, TreatmentPackage


SONICATION_RE = re.compile(r"(sonication\s*[_-]?\s*\d+)", re.IGNORECASE)


class DiscoveryService:
    def discover(self, source: Path, workspace: Path) -> TreatmentPackage:
        discovered: list[DiscoveredFile] = []
        for path in workspace.rglob("*"):
            if not path.is_file():
                continue
            discovered.append(
                DiscoveredFile(
                    path=path,
                    category=self.classify(path),
                    sonication=self.find_sonication(path.relative_to(workspace)),
                )
            )
        discovered.sort(key=lambda item: str(item.path).lower())
        return TreatmentPackage(source=source, workspace=workspace, files=discovered)

    @staticmethod
    def find_sonication(relative_path: Path) -> str | None:
        for part in relative_path.parts:
            match = SONICATION_RE.search(part)
            if match:
                digits = re.findall(r"\d+", match.group(1))
                return f"Sonication{int(digits[0])}" if digits else match.group(1)
        return None

    @staticmethod
    def classify(path: Path) -> str:
        name = path.name.lower()
        suffix = path.suffix.lower()
        parts = {part.lower() for part in path.parts}

        if "spectrummsg" in name:
            return "SpectrumMsg"
        if suffix == ".raw":
            return "RAW"
        if suffix == ".act":
            return "ACT"
        if suffix == ".xml":
            return "XML"
        if "mrfiles" in parts or "mrfiles" in name:
            return "MRFILES"
        if "cpcfiles" in parts or "cpcfiles" in name:
            return "CPCFiles"
        if "hydrophone" in name or "hydrophone" in parts:
            return "Hydrophone"
        if "calibration" in name or suffix in {".ini", ".cal"}:
            return "Calibration"
        if "replay" in name:
            return "Replay"
        if suffix in {".fft"} or "_fft" in name:
            return "Spectrum FFT"
        if suffix in {".txt", ".csv"} and "spectrum" in name:
            return "Spectrum TXT"
        if suffix == ".dmp" or "spectrum" in name:
            return "Spectrum"
        return "Unknown"
