from collections import Counter
from src.domain.models import TreatmentPackage

class CapabilityService:
    def analyze(self,p:TreatmentPackage):
        c=Counter(x.category for x in p.files); spectrum=c['SpectrumMsg']+c['Spectrum']; temp=c['RAW']; act=c['ACT']; xml=c['XML']; mr=c['MRFILES']
        score=sum(bool(v) for v in (spectrum,temp,act,xml))
        return {
            'Spectrum':('Available' if spectrum else 'Missing',f'{spectrum} file(s)'),
            'Temperature':('Available' if temp else 'Missing',f'{temp} RAW file(s)'),
            'ACT':('Available' if act else 'Missing',f'{act} file(s)'),
            'Metadata XML':('Available' if xml else 'Missing',f'{xml} file(s)'),
            'MR':('Available' if mr else 'Missing',f'{mr} file(s)'),
            'Replay Capability':(f'Level {score}','Capability-based result'),
        }
