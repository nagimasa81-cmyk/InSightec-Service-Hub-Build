from __future__ import annotations
import shutil, tempfile, zipfile
from pathlib import Path

class ImportErrorUser(RuntimeError): pass

class ImportService:
    def __init__(self): self._temp_dirs=[]
    def import_path(self, source: Path) -> Path:
        source=source.expanduser().resolve()
        if not source.exists(): raise ImportErrorUser(f"Path does not exist: {source}")
        if source.is_dir(): return source
        if source.suffix.lower()=='.zip':
            temp=Path(tempfile.mkdtemp(prefix='SpectrumMsgAnalyzer_')); self._temp_dirs.append(temp)
            try:
                with zipfile.ZipFile(source,'r') as z: z.extractall(temp)
            except (zipfile.BadZipFile,OSError) as e:
                shutil.rmtree(temp,ignore_errors=True); raise ImportErrorUser(f"Unable to extract ZIP: {e}") from e
            return temp
        raise ImportErrorUser('Only ZIP files and folders are supported.')
    def cleanup(self):
        for p in self._temp_dirs: shutil.rmtree(p,ignore_errors=True)
        self._temp_dirs.clear()
