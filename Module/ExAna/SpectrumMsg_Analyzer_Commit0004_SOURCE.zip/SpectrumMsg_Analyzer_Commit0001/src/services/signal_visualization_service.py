from __future__ import annotations

import csv
import math
import struct
from pathlib import Path

import numpy as np

from src.domain.signal_models import SignalAnalysis, SignalStatistics


class SignalVisualizationService:
    FORMATS = {
        "UInt16": "H",
        "UInt32": "I",
        "Int16": "h",
        "Int32": "i",
        "Float32": "f",
        "Float64": "d",
    }

    def analyze(
        self,
        data: bytes,
        offset: int,
        sample_count: int,
        numeric_type: str,
        endian: str,
        stride: int = 1,
    ) -> SignalAnalysis:
        values = self.decode(
            data=data,
            offset=offset,
            sample_count=sample_count,
            numeric_type=numeric_type,
            endian=endian,
            stride=stride,
        )

        arr = np.asarray(values, dtype=np.float64)
        finite = arr[np.isfinite(arr)]

        if finite.size:
            stats = SignalStatistics(
                count=int(arr.size),
                minimum=float(np.min(finite)),
                maximum=float(np.max(finite)),
                mean=float(np.mean(finite)),
                stddev=float(np.std(finite)),
                finite_ratio=float(finite.size / max(1, arr.size)),
            )
            derivative = np.diff(arr, prepend=arr[0])
            hist_counts, hist_edges = np.histogram(finite, bins=min(64, max(8, int(np.sqrt(finite.size)))))
            score, reasons = self.fft_candidate_score(finite)
        else:
            stats = SignalStatistics(count=int(arr.size))
            derivative = np.zeros_like(arr)
            hist_counts = np.asarray([], dtype=np.float64)
            hist_edges = np.asarray([], dtype=np.float64)
            score = 0.0
            reasons = ["No finite values were decoded."]

        return SignalAnalysis(
            offset=offset,
            numeric_type=numeric_type,
            endian=endian,
            stride=stride,
            values=[float(v) for v in arr],
            derivative=[float(v) for v in derivative],
            histogram_counts=[float(v) for v in hist_counts],
            histogram_edges=[float(v) for v in hist_edges],
            stats=stats,
            fft_candidate_score=round(score, 1),
            fft_candidate_reasons=reasons,
        )

    def decode(
        self,
        data: bytes,
        offset: int,
        sample_count: int,
        numeric_type: str,
        endian: str,
        stride: int,
    ) -> list[float]:
        if numeric_type not in self.FORMATS:
            raise ValueError(f"Unsupported numeric type: {numeric_type}")
        if stride < 1:
            raise ValueError("Stride must be at least 1.")

        fmt = self.FORMATS[numeric_type]
        size = struct.calcsize(fmt)
        prefix = "<" if endian == "Little" else ">"
        step = size * stride
        offset = max(0, min(offset, len(data)))

        values: list[float] = []
        pos = offset
        while pos + size <= len(data) and len(values) < sample_count:
            value = struct.unpack_from(prefix + fmt, data, pos)[0]
            values.append(float(value))
            pos += step
        return values

    def fft_candidate_score(self, finite: np.ndarray) -> tuple[float, list[str]]:
        reasons: list[str] = []
        if finite.size < 16:
            return 5.0, ["Too few values for reliable spectrum scoring."]

        abs_values = np.abs(finite)
        maximum = float(np.max(abs_values))
        minimum = float(np.min(abs_values))
        mean = float(np.mean(abs_values))
        std = float(np.std(abs_values))

        non_negative_ratio = float(np.mean(finite >= 0))
        positive_dynamic = maximum / max(1e-12, mean)
        sparse_peak_ratio = float(np.mean(abs_values > (mean + 3.0 * std))) if std > 0 else 0.0

        diff = np.diff(abs_values)
        smoothness = 1.0 - min(1.0, float(np.std(diff)) / max(1e-12, std * 2.0))
        finite_ratio = float(np.mean(np.isfinite(finite)))

        score = 0.0
        score += non_negative_ratio * 25.0
        score += min(1.0, positive_dynamic / 20.0) * 25.0
        score += min(1.0, sparse_peak_ratio / 0.08) * 20.0
        score += smoothness * 20.0
        score += finite_ratio * 10.0

        if non_negative_ratio >= 0.95:
            reasons.append("Values are predominantly non-negative.")
        if positive_dynamic >= 8.0:
            reasons.append("Dynamic range is consistent with sparse spectral peaks.")
        if sparse_peak_ratio > 0.0:
            reasons.append("A small number of strong peak candidates is present.")
        if smoothness >= 0.5:
            reasons.append("Adjacent values have moderate continuity.")
        if maximum == minimum:
            reasons.append("Signal is constant; spectrum likelihood is low.")
            score *= 0.2

        return max(0.0, min(100.0, score)), reasons

    def export_csv(self, path: Path, analysis: SignalAnalysis) -> None:
        with path.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.writer(handle)
            writer.writerow(
                [
                    "Index",
                    "Value",
                    "Derivative",
                    "SourceOffset",
                    "NumericType",
                    "Endian",
                    "Stride",
                ]
            )
            for index, value in enumerate(analysis.values):
                writer.writerow(
                    [
                        index,
                        value,
                        analysis.derivative[index] if index < len(analysis.derivative) else "",
                        analysis.offset,
                        analysis.numeric_type,
                        analysis.endian,
                        analysis.stride,
                    ]
                )
