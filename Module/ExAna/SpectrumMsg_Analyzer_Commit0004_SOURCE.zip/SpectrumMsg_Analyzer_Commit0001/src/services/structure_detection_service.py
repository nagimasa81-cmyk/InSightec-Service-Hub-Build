from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass

from src.domain.structure_models import (
    EntropyBlock,
    FrameCandidate,
    SimilarityBlock,
    StructureCandidate,
)


@dataclass(slots=True)
class _ScoredPeriod:
    header_size: int
    frame_size: int
    frame_count: int
    remainder: int
    similarity_score: float
    count_score: float
    entropy_score: float
    remainder_score: float
    total_score: float


class StructureDetectionService:
    """
    Heuristic binary structure detector.

    It is intentionally conservative. Results are candidates, not confirmed
    SpectrumMsg format definitions.
    """

    def analyze(self, data: bytes) -> StructureCandidate:
        if len(data) < 128:
            return StructureCandidate(
                header_size=0,
                frame_size=max(1, len(data)),
                frame_count=1 if data else 0,
                remainder=0,
                confidence=5.0 if data else 0.0,
                evidence=["File is too small for reliable repeated-frame detection."],
            )

        entropy_profile = self.entropy_profile(data)
        similarity_profile = self.similarity_profile(data)

        candidate = self._search_best_period(data, entropy_profile)
        frames = [
            FrameCandidate(
                index=index,
                offset=candidate.header_size + index * candidate.frame_size,
                length=min(
                    candidate.frame_size,
                    len(data) - (candidate.header_size + index * candidate.frame_size),
                ),
            )
            for index in range(candidate.frame_count)
            if candidate.header_size + index * candidate.frame_size < len(data)
        ]

        evidence = [
            f"Candidate header size: {candidate.header_size} bytes.",
            f"Candidate frame size: {candidate.frame_size} bytes.",
            f"Candidate frame count: {candidate.frame_count}.",
            f"Trailing remainder: {candidate.remainder} bytes.",
            f"Repeated-block similarity score: {candidate.similarity_score:.1f}%.",
            f"Header/body entropy contrast score: {candidate.entropy_score:.1f}%.",
        ]

        if candidate.frame_count < 2:
            evidence.append("No reliable repeated frame pattern was detected.")
        elif candidate.similarity_score < 40:
            evidence.append("Repeated-block similarity is weak; manual review is required.")
        else:
            evidence.append("Repeated-block evidence is present, but field meanings remain unconfirmed.")

        return StructureCandidate(
            header_size=candidate.header_size,
            frame_size=candidate.frame_size,
            frame_count=candidate.frame_count,
            remainder=candidate.remainder,
            confidence=round(candidate.total_score, 1),
            score_components={
                "similarity": round(candidate.similarity_score, 1),
                "frame_count": round(candidate.count_score, 1),
                "entropy_contrast": round(candidate.entropy_score, 1),
                "remainder": round(candidate.remainder_score, 1),
            },
            evidence=evidence,
            frames=frames,
            entropy_profile=entropy_profile,
            similarity_profile=similarity_profile,
        )

    def entropy_profile(self, data: bytes, block_size: int = 256) -> list[EntropyBlock]:
        profile: list[EntropyBlock] = []
        for offset in range(0, len(data), block_size):
            chunk = data[offset: offset + block_size]
            profile.append(
                EntropyBlock(
                    offset=offset,
                    length=len(chunk),
                    entropy=round(self._entropy(chunk), 4),
                )
            )
        return profile

    def similarity_profile(self, data: bytes, block_size: int = 256) -> list[SimilarityBlock]:
        profile: list[SimilarityBlock] = []
        previous = None
        for offset in range(0, len(data), block_size):
            chunk = data[offset: offset + block_size]
            similarity = 0.0 if previous is None else self._byte_similarity(previous, chunk)
            profile.append(
                SimilarityBlock(
                    offset=offset,
                    length=len(chunk),
                    similarity=round(similarity * 100, 2),
                )
            )
            previous = chunk
        return profile

    def _search_best_period(
        self, data: bytes, entropy_profile: list[EntropyBlock]
    ) -> _ScoredPeriod:
        file_size = len(data)
        header_candidates = self._header_candidates(file_size)
        frame_candidates = self._frame_size_candidates(file_size)

        best = _ScoredPeriod(
            header_size=0,
            frame_size=file_size,
            frame_count=1,
            remainder=0,
            similarity_score=0.0,
            count_score=5.0,
            entropy_score=0.0,
            remainder_score=100.0,
            total_score=5.0,
        )

        for header_size in header_candidates:
            body_size = file_size - header_size
            if body_size < 64:
                continue

            for frame_size in frame_candidates:
                if frame_size > body_size:
                    continue

                frame_count = body_size // frame_size
                if frame_count < 2:
                    continue

                remainder = body_size % frame_size
                sample_count = min(frame_count, 12)
                frames = [
                    data[
                        header_size + index * frame_size:
                        header_size + (index + 1) * frame_size
                    ]
                    for index in range(sample_count)
                ]

                pair_scores = [
                    self._sampled_similarity(frames[index], frames[index + 1])
                    for index in range(len(frames) - 1)
                ]
                similarity = (sum(pair_scores) / len(pair_scores)) if pair_scores else 0.0
                similarity_score = similarity * 100

                count_score = min(100.0, 30.0 + frame_count * 6.0)
                remainder_ratio = remainder / max(1, frame_size)
                remainder_score = max(0.0, 100.0 - remainder_ratio * 140.0)
                entropy_score = self._entropy_contrast_score(
                    data, header_size, frame_size
                )

                total = (
                    similarity_score * 0.50
                    + count_score * 0.15
                    + entropy_score * 0.20
                    + remainder_score * 0.15
                )

                if total > best.total_score:
                    best = _ScoredPeriod(
                        header_size=header_size,
                        frame_size=frame_size,
                        frame_count=frame_count,
                        remainder=remainder,
                        similarity_score=similarity_score,
                        count_score=count_score,
                        entropy_score=entropy_score,
                        remainder_score=remainder_score,
                        total_score=total,
                    )

        return best

    @staticmethod
    def _header_candidates(file_size: int) -> list[int]:
        base = {
            0, 16, 32, 48, 64, 96, 128, 160, 192, 224, 256,
            320, 384, 448, 512, 640, 768, 896, 1024, 1280,
            1536, 1792, 2048, 3072, 4096,
        }
        return sorted(value for value in base if value < file_size)

    @staticmethod
    def _frame_size_candidates(file_size: int) -> list[int]:
        candidates = set()

        for power in range(6, 21):
            value = 2 ** power
            candidates.update({value, value * 2, value * 3, value * 4})

        for divisor in range(2, 129):
            approx = file_size // divisor
            rounded = max(16, (approx // 16) * 16)
            for delta in (-64, -32, -16, 0, 16, 32, 64):
                value = rounded + delta
                if 64 <= value <= file_size:
                    candidates.add(value)

        return sorted(candidates)

    def _entropy_contrast_score(
        self, data: bytes, header_size: int, frame_size: int
    ) -> float:
        if header_size <= 0:
            return 20.0

        header = data[:header_size]
        body = data[header_size: header_size + min(frame_size, 4096)]
        if not header or not body:
            return 0.0

        header_entropy = self._entropy(header)
        body_entropy = self._entropy(body)
        contrast = abs(body_entropy - header_entropy)
        return min(100.0, contrast / 3.0 * 100.0)

    @staticmethod
    def _entropy(chunk: bytes) -> float:
        if not chunk:
            return 0.0
        counts = Counter(chunk)
        length = len(chunk)
        return -sum(
            (count / length) * math.log2(count / length)
            for count in counts.values()
        )

    @staticmethod
    def _byte_similarity(left: bytes, right: bytes) -> float:
        limit = min(len(left), len(right))
        if limit <= 0:
            return 0.0
        equal = sum(1 for index in range(limit) if left[index] == right[index])
        return equal / limit

    @staticmethod
    def _sampled_similarity(left: bytes, right: bytes) -> float:
        limit = min(len(left), len(right))
        if limit <= 0:
            return 0.0

        sample_points = min(1024, limit)
        if sample_points == limit:
            return StructureDetectionService._byte_similarity(left, right)

        step = max(1, limit // sample_points)
        equal = 0
        count = 0
        for index in range(0, limit, step):
            equal += left[index] == right[index]
            count += 1
            if count >= sample_points:
                break
        return equal / max(1, count)
