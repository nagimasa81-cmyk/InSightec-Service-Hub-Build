from __future__ import annotations

import math
import struct
from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class DecodedRow:
    offset: int
    hex_text: str
    ascii_text: str
    numeric_text: str


class BinaryAnalysisService:
    MAX_BYTES = 8 * 1024 * 1024

    def read(self, path: Path) -> bytes:
        with path.open("rb") as handle:
            return handle.read(self.MAX_BYTES)

    def rows(
        self,
        data: bytes,
        start: int,
        row_count: int,
        numeric_type: str,
        endian: str,
    ) -> list[DecodedRow]:
        rows: list[DecodedRow] = []
        start = max(0, min(start, max(0, len(data) - 1)))
        start -= start % 16
        for offset in range(start, min(len(data), start + row_count * 16), 16):
            chunk = data[offset: offset + 16]
            rows.append(
                DecodedRow(
                    offset=offset,
                    hex_text=" ".join(f"{b:02X}" for b in chunk),
                    ascii_text="".join(chr(b) if 32 <= b <= 126 else "." for b in chunk),
                    numeric_text=self.decode_chunk(chunk, numeric_type, endian),
                )
            )
        return rows

    def decode_chunk(self, chunk: bytes, numeric_type: str, endian: str) -> str:
        formats = {
            "UInt16": "H",
            "UInt32": "I",
            "UInt64": "Q",
            "Int16": "h",
            "Int32": "i",
            "Float32": "f",
            "Float64": "d",
        }
        fmt = formats[numeric_type]
        size = struct.calcsize(fmt)
        prefix = "<" if endian == "Little" else ">"
        values = []
        for pos in range(0, len(chunk) - size + 1, size):
            value = struct.unpack_from(prefix + fmt, chunk, pos)[0]
            if isinstance(value, float):
                if math.isfinite(value):
                    values.append(f"{value:.6g}")
                else:
                    values.append(str(value))
            else:
                values.append(str(value))
        return " | ".join(values)

    @staticmethod
    def search_hex(data: bytes, query: str, start: int = 0) -> int:
        cleaned = "".join(query.split())
        if len(cleaned) % 2:
            raise ValueError("HEX search requires complete byte pairs.")
        needle = bytes.fromhex(cleaned)
        return data.find(needle, start)

    @staticmethod
    def search_ascii(data: bytes, query: str, start: int = 0) -> int:
        return data.find(query.encode("utf-8", errors="ignore"), start)

    def type_scores(self, data: bytes, endian: str) -> dict[str, float]:
        sample = data[: min(len(data), 4096)]
        scores: dict[str, float] = {}
        for typ in ("UInt16", "UInt32", "Int16", "Int32", "Float32", "Float64"):
            try:
                values = self._decode_values(sample, typ, endian, 256)
            except Exception:
                scores[typ] = 0.0
                continue
            if not values:
                scores[typ] = 0.0
                continue

            finite = sum(
                1 for v in values if not isinstance(v, float) or math.isfinite(v)
            ) / len(values)
            nonzero = sum(v != 0 for v in values) / len(values)
            moderate = sum(
                abs(float(v)) < 1e9 for v in values
                if not isinstance(v, float) or math.isfinite(v)
            ) / len(values)

            score = (finite * 0.5) + (nonzero * 0.2) + (moderate * 0.3)
            scores[typ] = round(score * 100, 1)
        return scores

    def candidate_header_fields(self, data: bytes, endian: str) -> list[tuple[int, str, str]]:
        candidates: list[tuple[int, str, str]] = []
        prefix = "<" if endian == "Little" else ">"
        limit = min(len(data), 256)

        for offset in range(0, limit - 4, 4):
            u32 = struct.unpack_from(prefix + "I", data, offset)[0]
            f32 = struct.unpack_from(prefix + "f", data, offset)[0]

            if 1 <= u32 <= 1_000_000:
                label = "Possible count/size/version"
                candidates.append((offset, "UInt32", f"{u32} ({label})"))
            if math.isfinite(f32) and 1e-6 <= abs(f32) <= 1e7:
                candidates.append((offset, "Float32", f"{f32:.6g}"))

        return candidates[:100]

    def _decode_values(
        self, data: bytes, numeric_type: str, endian: str, limit: int
    ) -> list[int | float]:
        formats = {
            "UInt16": "H",
            "UInt32": "I",
            "Int16": "h",
            "Int32": "i",
            "Float32": "f",
            "Float64": "d",
        }
        fmt = formats[numeric_type]
        size = struct.calcsize(fmt)
        prefix = "<" if endian == "Little" else ">"
        values = []
        for pos in range(0, min(len(data) - size + 1, limit * size), size):
            values.append(struct.unpack_from(prefix + fmt, data, pos)[0])
        return values
