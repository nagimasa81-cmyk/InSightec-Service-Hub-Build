from pathlib import Path
from PySide6.QtWidgets import QPlainTextEdit
from src.common.constants import BINARY_PREVIEW_BYTES

class BinaryView(QPlainTextEdit):
    def __init__(self,parent=None):
        super().__init__(parent); self.setReadOnly(True); self.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap); self.setPlaceholderText('Select a file to preview HEX and ASCII.')
    def show_file(self,path:Path):
        try:
            data=path.read_bytes()[:BINARY_PREVIEW_BYTES]
        except OSError as e:
            self.setPlainText(f'Unable to read file:\n{e}'); return
        lines=[]
        for off in range(0,len(data),16):
            chunk=data[off:off+16]; hx=' '.join(f'{b:02X}' for b in chunk); asc=''.join(chr(b) if 32<=b<=126 else '.' for b in chunk); lines.append(f'{off:08X}  {hx:<47}  {asc}')
        self.setPlainText(f'File: {path}\nSize: {path.stat().st_size:,} bytes\nPreview: {len(data):,} bytes\n\n'+'\n'.join(lines))
