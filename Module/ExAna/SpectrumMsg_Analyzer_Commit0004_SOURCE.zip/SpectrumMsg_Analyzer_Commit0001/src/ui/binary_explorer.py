from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QFileDialog,
    QGroupBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from src.services.binary_analysis_service import BinaryAnalysisService


class BinaryExplorer(QWidget):
    status_message = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.service = BinaryAnalysisService()
        self.path: Path | None = None
        self.data = b""
        self.current_offset = 0
        self.bookmarks: list[dict] = []
        self.markers: list[dict] = []

        self._build_ui()

    def _build_ui(self) -> None:
        controls = QHBoxLayout()

        self.offset_edit = QLineEdit("0")
        self.offset_edit.setPlaceholderText("Offset (decimal or 0x...)")
        jump_button = QPushButton("Jump")
        jump_button.clicked.connect(self.jump_to_offset)

        self.type_combo = QComboBox()
        self.type_combo.addItems(
            ["UInt16", "UInt32", "UInt64", "Int16", "Int32", "Float32", "Float64"]
        )
        self.type_combo.setCurrentText("Float32")
        self.type_combo.currentTextChanged.connect(self.refresh)

        self.endian_combo = QComboBox()
        self.endian_combo.addItems(["Little", "Big"])
        self.endian_combo.currentTextChanged.connect(self.refresh)

        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("HEX bytes or ASCII text")
        self.search_mode = QComboBox()
        self.search_mode.addItems(["HEX", "ASCII"])
        search_button = QPushButton("Search Next")
        search_button.clicked.connect(self.search_next)

        bookmark_button = QPushButton("Add Bookmark")
        bookmark_button.clicked.connect(self.add_bookmark)

        marker_button = QPushButton("Add Marker")
        marker_button.clicked.connect(self.add_marker)

        save_template = QPushButton("Save Template")
        save_template.clicked.connect(self.save_template)

        load_template = QPushButton("Load Template")
        load_template.clicked.connect(self.load_template)

        for widget in (
            QLabel("Offset"), self.offset_edit, jump_button,
            QLabel("Type"), self.type_combo,
            QLabel("Endian"), self.endian_combo,
            self.search_edit, self.search_mode, search_button,
            bookmark_button, marker_button, save_template, load_template,
        ):
            controls.addWidget(widget)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Offset", "HEX", "ASCII", "Numeric"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setStretchLastSection(True)

        self.analysis_tabs = QTabWidget()

        self.type_table = QTableWidget(0, 2)
        self.type_table.setHorizontalHeaderLabels(["Candidate Type", "Score"])
        self.type_table.horizontalHeader().setStretchLastSection(True)
        self.type_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)

        self.header_table = QTableWidget(0, 3)
        self.header_table.setHorizontalHeaderLabels(["Offset", "Type", "Candidate Value"])
        self.header_table.horizontalHeader().setStretchLastSection(True)
        self.header_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.header_table.itemDoubleClicked.connect(self._jump_from_header)

        self.bookmark_table = QTableWidget(0, 3)
        self.bookmark_table.setHorizontalHeaderLabels(["Offset", "Name", "Kind"])
        self.bookmark_table.horizontalHeader().setStretchLastSection(True)
        self.bookmark_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.bookmark_table.itemDoubleClicked.connect(self._jump_from_bookmark)

        self.analysis_tabs.addTab(self.type_table, "Auto Detector")
        self.analysis_tabs.addTab(self.header_table, "Header Candidates")
        self.analysis_tabs.addTab(self.bookmark_table, "Bookmarks / Markers")

        box = QGroupBox("Binary Explorer")
        layout = QVBoxLayout(box)
        layout.addLayout(controls)
        layout.addWidget(self.table, 3)
        layout.addWidget(self.analysis_tabs, 2)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(box)

    def show_file(self, path: Path) -> None:
        self.path = path
        try:
            self.data = self.service.read(path)
        except OSError as exc:
            QMessageBox.critical(self, "Binary Explorer", str(exc))
            return
        self.current_offset = 0
        self.offset_edit.setText("0")
        self.refresh()
        self._refresh_analysis()
        self.status_message.emit(
            f"Binary loaded: {path.name} / {len(self.data):,} preview bytes"
        )

    def jump_to(self, offset: int) -> None:
        self._jump(offset)

    def set_auto_markers(self, markers: list[dict]) -> None:
        self.markers = [
            marker for marker in self.markers
            if marker.get("kind") != "Auto Marker"
        ]
        self.markers.extend(markers)
        self._refresh_bookmarks()
        self.refresh()

    def refresh(self) -> None:
        if not self.data:
            self.table.setRowCount(0)
            return
        rows = self.service.rows(
            self.data,
            self.current_offset,
            256,
            self.type_combo.currentText(),
            self.endian_combo.currentText(),
        )
        self.table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            values = [
                f"0x{row.offset:08X}",
                row.hex_text,
                row.ascii_text,
                row.numeric_text,
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(value)
                if self._offset_is_marked(row.offset):
                    item.setBackground(Qt.GlobalColor.darkCyan)
                self.table.setItem(row_index, column, item)
        self.table.resizeColumnToContents(0)
        self.table.resizeColumnToContents(2)

    def jump_to_offset(self) -> None:
        if not self.data:
            return
        text = self.offset_edit.text().strip()
        try:
            value = int(text, 0)
        except ValueError:
            QMessageBox.warning(self, "Offset", "Use decimal or 0x-prefixed HEX.")
            return
        self._jump(value)

    def _jump(self, offset: int) -> None:
        if not self.data:
            return
        self.current_offset = max(0, min(offset, len(self.data) - 1))
        self.offset_edit.setText(hex(self.current_offset))
        self.refresh()
        self.status_message.emit(f"Offset 0x{self.current_offset:08X}")

    def search_next(self) -> None:
        if not self.data:
            return
        query = self.search_edit.text()
        if not query:
            return
        try:
            if self.search_mode.currentText() == "HEX":
                found = self.service.search_hex(self.data, query, self.current_offset + 1)
            else:
                found = self.service.search_ascii(self.data, query, self.current_offset + 1)
        except ValueError as exc:
            QMessageBox.warning(self, "Search", str(exc))
            return

        if found < 0:
            QMessageBox.information(self, "Search", "No further match found.")
            return
        self._jump(found)

    def add_bookmark(self) -> None:
        if not self.data:
            return
        name, ok = QInputDialog.getText(self, "Bookmark", "Bookmark name:")
        if ok and name:
            self.bookmarks.append(
                {"offset": self.current_offset, "name": name, "kind": "Bookmark"}
            )
            self._refresh_bookmarks()

    def add_marker(self) -> None:
        if not self.data:
            return
        name, ok = QInputDialog.getText(self, "Structure Marker", "Marker name:")
        if not ok or not name:
            return
        length, ok = QInputDialog.getInt(
            self, "Structure Marker", "Length (bytes):", 16, 1, 100_000_000
        )
        if ok:
            marker = {
                "offset": self.current_offset,
                "length": length,
                "name": name,
                "kind": "Marker",
            }
            self.markers.append(marker)
            self._refresh_bookmarks()
            self.refresh()

    def save_template(self) -> None:
        filename, _ = QFileDialog.getSaveFileName(
            self, "Save Binary Template", "", "JSON files (*.json)"
        )
        if not filename:
            return
        payload = {
            "version": 1,
            "endian": self.endian_combo.currentText(),
            "numeric_type": self.type_combo.currentText(),
            "bookmarks": self.bookmarks,
            "markers": self.markers,
        }
        Path(filename).write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def load_template(self) -> None:
        filename, _ = QFileDialog.getOpenFileName(
            self, "Load Binary Template", "", "JSON files (*.json)"
        )
        if not filename:
            return
        try:
            payload = json.loads(Path(filename).read_text(encoding="utf-8"))
            self.bookmarks = list(payload.get("bookmarks", []))
            self.markers = list(payload.get("markers", []))
            self.endian_combo.setCurrentText(payload.get("endian", "Little"))
            self.type_combo.setCurrentText(payload.get("numeric_type", "Float32"))
            self._refresh_bookmarks()
            self.refresh()
        except Exception as exc:
            QMessageBox.warning(self, "Template", f"Unable to load template:\n{exc}")

    def _refresh_analysis(self) -> None:
        scores = self.service.type_scores(self.data, self.endian_combo.currentText())
        ordered = sorted(scores.items(), key=lambda item: item[1], reverse=True)
        self.type_table.setRowCount(len(ordered))
        for row, (name, score) in enumerate(ordered):
            self.type_table.setItem(row, 0, QTableWidgetItem(name))
            self.type_table.setItem(row, 1, QTableWidgetItem(f"{score:.1f}%"))

        candidates = self.service.candidate_header_fields(
            self.data, self.endian_combo.currentText()
        )
        self.header_table.setRowCount(len(candidates))
        for row, (offset, typ, value) in enumerate(candidates):
            self.header_table.setItem(row, 0, QTableWidgetItem(f"0x{offset:08X}"))
            self.header_table.setItem(row, 1, QTableWidgetItem(typ))
            self.header_table.setItem(row, 2, QTableWidgetItem(value))

        self._refresh_bookmarks()

    def _refresh_bookmarks(self) -> None:
        entries = self.bookmarks + self.markers
        self.bookmark_table.setRowCount(len(entries))
        for row, entry in enumerate(entries):
            self.bookmark_table.setItem(
                row, 0, QTableWidgetItem(f"0x{int(entry['offset']):08X}")
            )
            self.bookmark_table.setItem(row, 1, QTableWidgetItem(str(entry["name"])))
            self.bookmark_table.setItem(row, 2, QTableWidgetItem(str(entry["kind"])))

    def _jump_from_header(self, item: QTableWidgetItem) -> None:
        offset_text = self.header_table.item(item.row(), 0).text()
        self._jump(int(offset_text, 16))

    def _jump_from_bookmark(self, item: QTableWidgetItem) -> None:
        offset_text = self.bookmark_table.item(item.row(), 0).text()
        self._jump(int(offset_text, 16))

    def _offset_is_marked(self, offset: int) -> bool:
        for marker in self.markers:
            start = int(marker["offset"])
            end = start + int(marker["length"])
            if start <= offset < end:
                return True
        return False
