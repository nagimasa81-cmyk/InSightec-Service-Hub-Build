from __future__ import annotations

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import QWidget

from src.domain.structure_models import StructureCandidate


class StructureHeatmap(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.candidate: StructureCandidate | None = None
        self.total_size = 0
        self.setMinimumHeight(110)

    def set_structure(self, candidate: StructureCandidate, total_size: int) -> None:
        self.candidate = candidate
        self.total_size = total_size
        self.update()

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        rect = self.rect().adjusted(10, 22, -10, -26)
        painter.fillRect(rect, QColor("#15191f"))
        painter.setPen(QPen(QColor("#6b7480")))
        painter.drawRect(rect)

        candidate = self.candidate
        if not candidate or self.total_size <= 0:
            painter.setPen(QColor("#cfd6de"))
            painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, "No structure analysis")
            return

        def x_for(offset: int) -> float:
            return rect.left() + rect.width() * (offset / self.total_size)

        if candidate.header_size > 0:
            x0 = x_for(0)
            x1 = x_for(candidate.header_size)
            painter.fillRect(
                QRectF(x0, rect.top(), max(2.0, x1 - x0), rect.height()),
                QColor("#3b82b4"),
            )
            painter.setPen(QColor("#dceaf5"))
            painter.drawText(
                QRectF(x0 + 3, rect.top(), max(30.0, x1 - x0 - 6), 20),
                "HEADER",
            )

        frame_colors = [QColor("#4f9f73"), QColor("#417f61")]
        for frame in candidate.frames:
            x0 = x_for(frame.offset)
            x1 = x_for(frame.offset + frame.length)
            painter.fillRect(
                QRectF(x0, rect.top(), max(1.0, x1 - x0), rect.height()),
                frame_colors[frame.index % 2],
            )
            if frame.index < 8 and x1 - x0 > 24:
                painter.setPen(QColor("#edf7f1"))
                painter.drawText(
                    QRectF(x0 + 2, rect.bottom() - 20, x1 - x0 - 4, 18),
                    f"F{frame.index}",
                )

        if candidate.remainder > 0:
            start = candidate.header_size + candidate.frame_count * candidate.frame_size
            x0 = x_for(start)
            painter.fillRect(
                QRectF(x0, rect.top(), rect.right() - x0, rect.height()),
                QColor("#8f6f3f"),
            )

        painter.setPen(QColor("#d5dbe2"))
        painter.drawText(
            10,
            16,
            (
                f"Confidence {candidate.confidence:.1f}% | "
                f"Header {candidate.header_size} | "
                f"Frame {candidate.frame_size} | "
                f"Count {candidate.frame_count}"
            ),
        )
