import sys
from PySide6.QtWidgets import QApplication
from src.common.constants import APP_NAME
from src.common.logger import configure_logging
from src.common.theme import DARK_STYLESHEET
from src.ui.main_window import MainWindow

def run()->int:
    configure_logging(); app=QApplication(sys.argv); app.setApplicationName(APP_NAME); app.setStyleSheet(DARK_STYLESHEET); w=MainWindow(); w.show(); return app.exec()
