from __future__ import annotations

from dataclasses import asdict, dataclass, field


@dataclass(slots=True)
class EntropyBlock:
    offset: int
    length: int
    entropy: float


@dataclass(slots=True)
class SimilarityBlock:
    offset: int
    length: int
    similarity: float


@dataclass(slots=True)
class FrameCandidate:
    index: int
    offset: int
    length: int


@dataclass(slots=True)
class StructureCandidate:
    header_size: int
    frame_size: int
    frame_count: int
    remainder: int
    confidence: float
    score_components: dict[str, float] = field(default_factory=dict)
    evidence: list[str] = field(default_factory=list)
    frames: list[FrameCandidate] = field(default_factory=list)
    entropy_profile: list[EntropyBlock] = field(default_factory=list)
    similarity_profile: list[SimilarityBlock] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)
