from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path

@dataclass(slots=True)
class DiscoveredFile:
    path: Path
    category: str
    sonication: str | None = None
    @property
    def size(self) -> int:
        try: return self.path.stat().st_size
        except OSError: return 0

@dataclass(slots=True)
class TreatmentPackage:
    source: Path
    workspace: Path
    files: list[DiscoveredFile] = field(default_factory=list)
    @property
    def sonications(self) -> list[str]:
        return sorted({f.sonication for f in self.files if f.sonication})
