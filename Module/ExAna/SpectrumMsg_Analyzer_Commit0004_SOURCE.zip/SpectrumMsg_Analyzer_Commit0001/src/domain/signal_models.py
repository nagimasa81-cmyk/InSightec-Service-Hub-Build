from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class SignalStatistics:
    count: int = 0
    minimum: float = 0.0
    maximum: float = 0.0
    mean: float = 0.0
    stddev: float = 0.0
    finite_ratio: float = 0.0


@dataclass(slots=True)
class SignalAnalysis:
    offset: int
    numeric_type: str
    endian: str
    stride: int
    values: list[float] = field(default_factory=list)
    derivative: list[float] = field(default_factory=list)
    histogram_counts: list[float] = field(default_factory=list)
    histogram_edges: list[float] = field(default_factory=list)
    stats: SignalStatistics = field(default_factory=SignalStatistics)
    fft_candidate_score: float = 0.0
    fft_candidate_reasons: list[str] = field(default_factory=list)
