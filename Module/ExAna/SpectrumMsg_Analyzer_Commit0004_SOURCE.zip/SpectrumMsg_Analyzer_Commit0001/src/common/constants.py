APP_NAME = "SpectrumMsg Analyzer"
APP_VERSION = "RC1 Commit0001"
ORGANIZATION = "InSightec Service Tools"
BINARY_PREVIEW_BYTES = 4096
