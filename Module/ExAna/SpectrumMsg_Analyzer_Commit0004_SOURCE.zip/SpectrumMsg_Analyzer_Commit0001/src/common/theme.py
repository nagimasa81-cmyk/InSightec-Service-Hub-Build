DARK_STYLESHEET = r"""
QWidget { background: #20242b; color: #e9edf2; font-family: 'Segoe UI'; font-size: 10pt; }
QMenuBar, QMenu, QToolBar, QStatusBar { background: #252a32; }
QPushButton, QToolButton { background: #2f6fab; border: 1px solid #4e86ba; border-radius: 4px; padding: 5px 10px; }
QTreeWidget, QTableWidget, QPlainTextEdit { background: #171a1f; alternate-background-color: #1d2127; border: 1px solid #3b414b; selection-background-color: #315f87; }
QHeaderView::section { background: #2a3038; border: 0; border-right: 1px solid #3b414b; padding: 5px; }
QGroupBox { border: 1px solid #3b414b; border-radius: 4px; margin-top: 8px; padding-top: 8px; }
QGroupBox::title { subcontrol-origin: margin; left: 8px; padding: 0 4px; }
QSplitter::handle { background: #3a404a; }
"""
