from PySide6.QtCore import QSettings
from .constants import APP_NAME, ORGANIZATION

def create_settings() -> QSettings:
    return QSettings(ORGANIZATION, APP_NAME)
