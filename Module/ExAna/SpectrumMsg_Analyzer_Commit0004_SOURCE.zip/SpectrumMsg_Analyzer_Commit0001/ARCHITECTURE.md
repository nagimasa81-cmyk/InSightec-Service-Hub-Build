# Architecture

Import -> Discovery -> Binary Analysis -> Structure Detection -> Signal Visualization -> UI

## Commit0004 additions

`signal_visualization_service.py`

- Decodes numeric samples from arbitrary offsets.
- Computes signal statistics.
- Computes histogram and first derivative.
- Calculates a heuristic FFT-candidate score.
- Exports decoded values to CSV.

`signal_visualizer.py`

- Offset navigation.
- Data type and endian selection.
- Sample count and stride selection.
- Waveform, histogram, derivative and candidate spectrum plots.
- Statistics panel.
- Synchronization with Binary Explorer.

The FFT-candidate score is heuristic only. It indicates that a decoded region
resembles a non-negative sparse spectrum, but does not confirm the SpectrumMsg
format.
