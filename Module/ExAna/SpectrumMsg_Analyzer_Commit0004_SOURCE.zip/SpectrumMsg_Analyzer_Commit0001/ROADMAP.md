# Roadmap

- Commit0001: Foundation
- Commit0002: Binary Explorer
- Commit0003: Reverse Engineering Engine
- Commit0004: Signal Visualization Engine
- Commit0005: Spectrum frame decoder
- Commit0006: Peak and cavitation analysis
- Commit0007: Replay API
- Commit0008: Temperature analyzer
- Commit0009: Replay Studio
