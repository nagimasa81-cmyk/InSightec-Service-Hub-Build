# SpectrumMsg Analyzer RC1 Commit0004

## Signal Visualization Engine

Commit0004 changes the reverse-engineering workflow from structure-only analysis
to direct signal investigation.

### Features

- Decode from any binary offset
- UInt16 / UInt32 / Int16 / Int32 / Float32 / Float64
- Little / Big endian
- Configurable sample count
- Configurable stride
- Previous / next block navigation
- Waveform plot
- Histogram
- First derivative
- FFT-candidate amplitude plot
- Statistics panel
- Heuristic FFT-candidate score
- CSV export
- Offset synchronization with Binary Explorer

## Suggested test

1. Open a treatment ZIP.
2. Select a `SpectrumMsg-*.dmp` file.
3. Open `Signal Visualization`.
4. Try Float32 and UInt16.
5. Change endian.
6. Move with Previous/Next Block.
7. Look for regions with:
   - finite values
   - non-negative values
   - strong sparse peaks
   - meaningful dynamic range
8. Export interesting regions to CSV.

## Important

The FFT-candidate score is heuristic and does not confirm that a region is an
actual FFT frame.
