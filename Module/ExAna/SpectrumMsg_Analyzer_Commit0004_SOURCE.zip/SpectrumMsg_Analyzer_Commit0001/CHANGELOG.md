# Changelog

## RC1 Commit0004

- Added Signal Visualization Engine.
- Added waveform plotting from arbitrary binary offsets.
- Added UInt16, UInt32, Int16, Int32, Float32 and Float64 visualization.
- Added little/big endian switching.
- Added configurable sample count and byte stride.
- Added automatic statistics: count, minimum, maximum, mean and standard deviation.
- Added histogram visualization.
- Added first-derivative visualization.
- Added FFT-candidate score based on monotonicity, non-negativity, peak sparsity and dynamic range.
- Added candidate spectrum plot using decoded amplitude values.
- Added offset synchronization with Binary Explorer.
- Added quick previous/next block navigation.
- Added CSV export of the current decoded signal.
- Added safer decoding and plotting for invalid or non-finite values.

## RC1 Commit0003a

- Fixed Structure Explorer startup issue.
