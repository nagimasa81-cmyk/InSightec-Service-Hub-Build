# SpectrumMsg Analyzer RC1 Commit0003

## Reverse Engineering Engine

Commit0003 adds automatic binary-structure analysis.

### Features

- Candidate header-size detection
- Candidate frame-size detection
- Repeated-block similarity analysis
- Entropy profile
- Header/body entropy contrast
- Frame count and trailing remainder analysis
- Structure confidence score
- Tentative frame table
- Structure heatmap
- Automatic header/frame markers
- JSON structure export
- Double-click frame or entropy rows to jump in Binary Explorer

## Important limitation

The generated structure is heuristic. It is not yet a confirmed SpectrumMsg
format specification. Commit0004 will use actual sample correlations and FFT
validation to confirm or reject candidates.

## Run

`build\03_RUN_DEBUG.bat`

## Build

`build\01_BUILD_EXE.bat`
