# Roadmap

- Commit0001: Foundation
- Commit0002: Binary Explorer
- Commit0003: Reverse Engineering Engine
- Commit0004: Spectrum frame decoder and FFT viewer
- Commit0005: Peak and cavitation analysis
- Commit0006: Replay API
- Commit0007: Temperature analyzer
- Commit0008: Replay Studio
