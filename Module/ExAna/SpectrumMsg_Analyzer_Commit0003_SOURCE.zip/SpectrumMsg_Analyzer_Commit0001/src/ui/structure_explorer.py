from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QFileDialog,
    QGroupBox,
    QHeaderView,
    QLabel,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from src.domain.structure_models import StructureCandidate
from src.services.structure_detection_service import StructureDetectionService
from src.ui.structure_heatmap import StructureHeatmap


class StructureExplorer(QWidget):
    jump_requested = Signal(int)
    markers_generated = Signal(list)
    status_message = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.service = StructureDetectionService()
        self.path: Path | None = None
        self.data = b""
        self.candidate: StructureCandidate | None = None

        self._build_ui()

    def _build_ui(self) -> None:
        self.summary = QLabel("Select a binary file, then run structure analysis.")
        self.summary.setWordWrap(True)

        analyze_button = QPushButton("Analyze Structure")
        analyze_button.clicked.connect(self.analyze)

        export_button = QPushButton("Export Structure JSON")
        export_button.clicked.connect(self.export_json)

        self.heatmap = StructureHeatmap()

        self.frame_table = QTableWidget(0, 4)
        self.frame_table.setHorizontalHeaderLabels(
            ["Index", "Offset", "Length", "End Offset"]
        )
        self.frame_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.frame_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.frame_table.itemDoubleClicked.connect(self._jump_from_frame)

        self.entropy_table = QTableWidget(0, 3)
        self.entropy_table.setHorizontalHeaderLabels(
            ["Offset", "Entropy", "Adjacent Similarity"]
        )
        self.entropy_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.entropy_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.entropy_table.itemDoubleClicked.connect(self._jump_from_entropy)

        self.evidence = QTextEdit()
        self.evidence.setReadOnly(True)

        vertical = QSplitter()
        vertical.setOrientation(vertical.Orientation.Vertical)
        vertical.addWidget(self.frame_table)
        vertical.addWidget(self.entropy_table)
        vertical.addWidget(self.evidence)
        vertical.setSizes([260, 220, 160])

        box = QGroupBox("Reverse Engineering Engine")
        layout = QVBoxLayout(box)
        layout.addWidget(self.summary)
        layout.addWidget(analyze_button)
        layout.addWidget(export_button)
        layout.addWidget(self.heatmap)
        layout.addWidget(vertical, 1)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(box)

    def set_file(self, path: Path, data: bytes) -> None:
        self.path = path
        self.data = data
        self.candidate = None
        self.summary.setText(
            f"Selected: {path.name} | Preview bytes: {len(data):,}"
        )
        self.frame_table.setRowCount(0)
        self.entropy_table.setRowCount(0)
        self.evidence.clear()

    def analyze(self) -> None:
        if not self.data:
            self.status_message.emit("No binary data loaded.")
            return

        self.status_message.emit("Analyzing repeated structure...")
        self.candidate = self.service.analyze(self.data)
        self._populate(self.candidate)
        self.status_message.emit(
            (
                f"Structure candidate: header={self.candidate.header_size}, "
                f"frame={self.candidate.frame_size}, "
                f"count={self.candidate.frame_count}, "
                f"confidence={self.candidate.confidence:.1f}%"
            )
        )

    def export_json(self) -> None:
        if not self.candidate:
            self.analyze()
        if not self.candidate:
            return

        default_name = (
            f"{self.path.stem}_structure.json" if self.path else "structure.json"
        )
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Export Structure JSON",
            default_name,
            "JSON files (*.json)",
        )
        if not filename:
            return

        payload = {
            "source_file": str(self.path) if self.path else None,
            "analysis_status": "tentative",
            "structure": self.candidate.to_dict(),
        }
        Path(filename).write_text(
            json.dumps(payload, indent=2),
            encoding="utf-8",
        )
        self.status_message.emit(f"Structure JSON exported: {filename}")

    def _populate(self, candidate: StructureCandidate) -> None:
        self.summary.setText(
            (
                f"<b>Candidate Header:</b> {candidate.header_size:,} bytes &nbsp; "
                f"<b>Frame Size:</b> {candidate.frame_size:,} bytes &nbsp; "
                f"<b>Frames:</b> {candidate.frame_count:,} &nbsp; "
                f"<b>Remainder:</b> {candidate.remainder:,} bytes &nbsp; "
                f"<b>Confidence:</b> {candidate.confidence:.1f}%"
            )
        )

        self.heatmap.set_structure(candidate, len(self.data))

        self.frame_table.setRowCount(len(candidate.frames))
        for row, frame in enumerate(candidate.frames):
            values = [
                str(frame.index),
                f"0x{frame.offset:08X}",
                f"{frame.length:,}",
                f"0x{frame.offset + frame.length:08X}",
            ]
            for column, value in enumerate(values):
                self.frame_table.setItem(row, column, QTableWidgetItem(value))

        similarity_by_offset = {
            item.offset: item.similarity for item in candidate.similarity_profile
        }
        self.entropy_table.setRowCount(len(candidate.entropy_profile))
        for row, block in enumerate(candidate.entropy_profile):
            self.entropy_table.setItem(
                row, 0, QTableWidgetItem(f"0x{block.offset:08X}")
            )
            self.entropy_table.setItem(
                row, 1, QTableWidgetItem(f"{block.entropy:.4f}")
            )
            self.entropy_table.setItem(
                row,
                2,
                QTableWidgetItem(
                    f"{similarity_by_offset.get(block.offset, 0.0):.2f}%"
                ),
            )

        component_lines = [
            "Score Components:",
            *[
                f"- {name}: {value:.1f}%"
                for name, value in candidate.score_components.items()
            ],
            "",
            "Evidence:",
            *[f"- {line}" for line in candidate.evidence],
            "",
            "Important:",
            "- This result is heuristic and tentative.",
            "- It does not yet prove field meanings or FFT layout.",
        ]
        self.evidence.setPlainText("\n".join(component_lines))

        markers = []
        if candidate.header_size > 0:
            markers.append(
                {
                    "offset": 0,
                    "length": candidate.header_size,
                    "name": "Detected Header",
                    "kind": "Auto Marker",
                }
            )
        for frame in candidate.frames[:200]:
            markers.append(
                {
                    "offset": frame.offset,
                    "length": frame.length,
                    "name": f"Frame {frame.index}",
                    "kind": "Auto Marker",
                }
            )
        self.markers_generated.emit(markers)

    def _jump_from_frame(self, item: QTableWidgetItem) -> None:
        offset = int(self.frame_table.item(item.row(), 1).text(), 16)
        self.jump_requested.emit(offset)

    def _jump_from_entropy(self, item: QTableWidgetItem) -> None:
        offset = int(self.entropy_table.item(item.row(), 0).text(), 16)
        self.jump_requested.emit(offset)
