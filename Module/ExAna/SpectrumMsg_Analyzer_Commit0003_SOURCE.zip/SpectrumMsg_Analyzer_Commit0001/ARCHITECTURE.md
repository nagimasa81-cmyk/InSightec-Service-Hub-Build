# Architecture

Import -> Discovery -> Domain Model -> Binary Analysis -> Structure Detection -> UI

## Commit0003 engine

`structure_detection_service.py` performs heuristic reverse engineering:

1. Calculates block entropy.
2. Calculates adjacent-block similarity.
3. Searches candidate header sizes.
4. Searches repeated frame periods.
5. Scores candidates using:
   - repeated-byte similarity
   - frame count plausibility
   - header-to-body entropy contrast
   - trailing remainder penalty
6. Produces a tentative structure model.
7. Exports the result as JSON.

The result is deliberately marked as tentative. Commit0003 does not claim that
SpectrumMsg format fields are fully decoded.
