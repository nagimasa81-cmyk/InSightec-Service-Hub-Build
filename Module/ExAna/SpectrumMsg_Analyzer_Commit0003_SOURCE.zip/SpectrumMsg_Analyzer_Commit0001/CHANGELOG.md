# Changelog

## RC1 Commit0003

- Added Reverse Engineering Engine.
- Added automatic candidate header-size detection.
- Added repeated-block and frame-period detection.
- Added entropy profile calculation.
- Added byte-similarity profile calculation.
- Added candidate frame boundary generation.
- Added tentative frame table with offset and length.
- Added structure confidence scoring.
- Added binary structure heatmap.
- Added structure JSON export.
- Added Structure Explorer tab.
- Added automatic markers for detected header and frames.
- Added analysis summary and evidence output.

## RC1 Commit0002

- Added advanced Binary Explorer and candidate header analysis.
