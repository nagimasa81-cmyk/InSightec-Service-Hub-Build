from PySide6.QtWidgets import QApplication, QMainWindow

from common_guide import GuideConfig, GuideManager, GuidePage


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Example Analyzer")

        self.guide_manager = GuideManager(
            self,
            GuideConfig(
                app_name="Example Analyzer",
                settings_product="ExampleAnalyzer",
            ),
            pages=[
                GuidePage("1. Import data", "Explain how the user imports files, folders, or ZIPs."),
                GuidePage("2. Review results", "Explain the main chart, table, and filters."),
                GuidePage("3. Export", "Explain saving results and projects."),
            ],
        )

    def showEvent(self, event):
        super().showEvent(event)
        if not getattr(self, "_guide_checked", False):
            self._guide_checked = True
            self.guide_manager.schedule_startup_check()

    def closeEvent(self, event):
        self.guide_manager.handle_close_event(event, cleanup_callback=self.cleanup)

    def cleanup(self):
        pass


if __name__ == "__main__":
    app = QApplication([])
    window = MainWindow()
    window.resize(1000, 700)
    window.show()
    app.exec()
