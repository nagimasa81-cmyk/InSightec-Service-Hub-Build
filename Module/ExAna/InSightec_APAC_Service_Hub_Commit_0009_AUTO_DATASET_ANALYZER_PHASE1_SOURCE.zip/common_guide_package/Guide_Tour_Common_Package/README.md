# InSightec Common Guide & Exit Confirmation Package

Reusable PySide6 package for InSightec desktop tools.

## Included

- `common_guide/guide_manager.py`: reusable manager
- `example/integration_example.py`: minimal integration example
- `IMPLEMENTATION_REQUEST_JA.txt`: copy-ready implementation request
- `UI_TEXT_EN.txt`: approved common English UI wording

## Integration

1. Copy `common_guide` into the target source tree.
2. Create `GuideManager` after the main window is created.
3. Provide the application-specific `GuidePage` list.
4. Call `schedule_startup_check()` once after the window becomes visible.
5. Delegate `closeEvent` to `handle_close_event()`.
6. Keep app-specific cleanup in the optional cleanup callback.

## Required customization

- `app_name`
- `settings_product`
- guide pages
- optional dialog titles

Do not reuse guide text from another application.
