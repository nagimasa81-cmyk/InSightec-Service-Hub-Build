InSightec APAC Service Hub - Auto Dataset Analyzer Phase 1

1. Build with 01_BUILD_EXE.bat or Build_Hub_EXE_PyInstaller.bat.
2. Place each tool EXE in its existing tools/<ToolName> folder.
3. Place SonicationAnalysis.exe in tools/SonicationAnalysis when available.
4. Start the Hub and drop a ZIP, folder, or files on Auto Dataset Analyzer.
5. The Hub extracts ZIP files once into a shared temporary workspace, scans contents,
   selects compatible tools, writes handoff JSON files, and starts installed selected tools.

Handoff compatibility:
  <tool.exe> --handoff <path-to-json>
Existing tools that do not yet parse --handoff may still start, but automatic data loading
requires adding handoff argument support to each tool source.
