from pathlib import Path

import numpy as np

from energy_scan import SAMPLE_SPLIT, _horizontal_levels, analyze_image


def test_fixed_270_split() -> None:
    xs = np.arange(0, 500, dtype=float)
    values = np.where(xs <= SAMPLE_SPLIT, 0.20, 1.20)
    # Add sparse spikes that must not dominate the robust average.
    values[40] = 2.8
    values[410] = 2.9
    low, high, confidence = _horizontal_levels(xs, values, 3.0)
    assert abs(low - 0.20) < 0.03, (low, high)
    assert abs(high - 1.20) < 0.03, (low, high)
    assert confidence > 0.5, confidence


def test_reference_images_if_available() -> None:
    """Run legacy camera references when the optional upload folder is present."""
    samples = Path(__file__).resolve().parent.parent / "upload"
    expected = {
        "Gain_verification_ch0.JPG": [0],
        "Gain_verification_ch1.JPG": [1],
        "Gain_verification_all.JPG": list(range(8)),
        "Noise_verification_ch0.JPG": [0],
        "Noise_verification_ch1.JPG": [1],
    }
    available = [name for name in expected if (samples / name).exists()]
    if not available:
        print("Reference camera images not packaged; synthetic core test only.")
        return
    for filename in available:
        result = analyze_image(samples / filename)
        assert result.channels == expected[filename], (filename, result.channels)
        # v1.7.0 must continue instead of Excluded for unknown/multiple channels.
        assert result.mode in {"Gain", "Noise"}, result
        assert result.low is not None and result.high is not None, result
    print(f"{len(available)} reference image(s) passed.")


def main() -> None:
    test_fixed_270_split()
    test_reference_images_if_available()
    print("Energy Graph Scan v1.7.0 core tests passed.")


if __name__ == "__main__":
    main()
