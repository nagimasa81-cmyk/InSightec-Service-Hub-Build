from pathlib import Path
import numpy as np
from energy_scan import (
    _gain_auto_ranges,
    _noise_fixed_ranges,
    _pixel_y_to_value,
    _detect_y_axis_calibration,
    analyze_image,
)


def test_gain_auto_ranges() -> None:
    xs=np.arange(0,500,dtype=float)
    # Pixel Y: low level is lower on graph (y=240), high level is higher (y=180).
    py=np.where(xs<315,240.0,180.0)
    py[300:330]=np.linspace(240,180,30)
    py[40]=210; py[430]=205
    lm,hm,lr,hr,conf=_gain_auto_ranges(xs,py,500)
    assert np.median(py[lm]) > np.median(py[hm]), (lr,hr)
    assert lr[1] < hr[0], (lr,hr)
    assert conf > .4, conf


def test_noise_fixed_ranges() -> None:
    xs=np.arange(0,500,dtype=float)
    lm,hm,lr,hr=_noise_fixed_ranges(xs,500)
    assert xs[lm].max() < xs[hm].min()
    assert lr[1] < hr[0]


def test_pixel_calibration_one_way() -> None:
    plot=(10,10,510,310)
    cal=(310.0,50.0,1.0)
    vals=_pixel_y_to_value(np.array([270.,250.]),plot,3.0,cal)
    assert np.allclose(vals,[.8,1.2],atol=.03), vals


def test_plot_grid_calibration() -> None:
    # Synthetic plot: only 1.0/2.0/3.0 labels are visible; zero is NOT printed.
    from PIL import Image, ImageDraw, ImageFont
    a=np.zeros((280,600,3),dtype=np.uint8)
    x0,y0,x1,y1=120,60,560,210
    for y in (60,110,160,210):
        a[y, x0:x1+1]=[15,150,25]
    im=Image.fromarray(a); d=ImageDraw.Draw(im); font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',20)
    for y,t in ((60,'3.0'),(110,'2.0'),(160,'1.0')):
        d.text((78,y-10),t,font=font,fill=(20,190,35))
    a=np.asarray(im)
    cal=_detect_y_axis_calibration(a,(x0,y0,x1,y1),'Gain')
    assert cal is not None, cal
    zero,step,val,anchors=cal
    assert abs(zero-210)<5.0, cal
    assert abs(step-50)<4.0, cal
    assert val==1.0 and len(anchors)>=2, cal


def test_reference_images_if_available() -> None:
    samples = Path(__file__).resolve().parent.parent / 'upload'
    expected = {
        'Gain_verification_ch0.JPG':[0],
        'Gain_verification_ch1.JPG':[1],
        'Gain_verification_all.JPG':list(range(8)),
        'Noise_verification_ch0.JPG':[0],
        'Noise_verification_ch1.JPG':[1],
    }
    available=[n for n in expected if (samples/n).exists()]
    if not available:
        print('Reference camera images not packaged; synthetic core test only.')
        return
    for fn in available:
        r=analyze_image(samples/fn)
        assert r.channels==expected[fn],(fn,r.channels)
        assert r.low is not None and r.high is not None
    print(f'{len(available)} reference image(s) passed.')


def main():
    test_gain_auto_ranges()
    test_noise_fixed_ranges()
    test_pixel_calibration_one_way()
    test_plot_grid_calibration()
    test_reference_images_if_available()
    print('Energy Graph Scan v2.0.0 axis-label unified-core tests passed.')

if __name__=='__main__':
    main()
