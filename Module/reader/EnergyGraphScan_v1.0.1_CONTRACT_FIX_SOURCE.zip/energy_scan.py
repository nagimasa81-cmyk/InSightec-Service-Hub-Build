from __future__ import annotations

import csv
import os
import re
import statistics
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
from PIL import Image, ImageDraw, ImageTk
from scipy import ndimage


APP_VERSION = "1.0.1"
IMAGE_TYPES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


@dataclass
class ScanResult:
    file: str
    mode: str
    channels: list[int]
    low: float | None
    high: float | None
    noise: float | None
    confidence: float
    graph_box: tuple[int, int, int, int]
    message: str = ""


def _robust(values: Iterable[float], z: float = 3.5) -> np.ndarray:
    a = np.asarray(list(values), dtype=float)
    a = a[np.isfinite(a)]
    if not len(a):
        return a
    med = np.median(a)
    mad = np.median(np.abs(a - med))
    if mad < 1e-9:
        return a[np.abs(a - med) <= max(0.02, abs(med) * .15)]
    return a[np.abs(a - med) / (1.4826 * mad) <= z]


def _dark_component(a: np.ndarray) -> tuple[int, int, int, int]:
    dark = np.all(a < 38, axis=2)
    labels, _ = ndimage.label(dark)
    candidates = []
    for index, sl in enumerate(ndimage.find_objects(labels), 1):
        if sl is None:
            continue
        ys, xs = sl
        w, h = xs.stop - xs.start, ys.stop - ys.start
        if 180 <= w <= 420 and 75 <= h <= 210 and xs.start > a.shape[1] * .48 and ys.start < a.shape[0] * .45:
            area = int(np.count_nonzero(labels[sl] == index))
            candidates.append((area, xs.start, ys.start, w, h))
    if not candidates:
        raise ValueError("Energy per Band graph was not found")
    _, x, y, w, h = max(candidates)
    return x, y, w, h


def _checked_channels(a: np.ndarray, box: tuple[int, int, int, int]) -> list[int]:
    x, y, _, _ = box
    # The channel row is tied to the Energy graph in both known UI layouts.
    start_x = x - 320
    check_y = y + 120
    found = []
    for ch in range(8):
        cx = int(round(start_x + ch * 36.3))
        patch = a[max(0, check_y):check_y + 14, max(0, cx):cx + 14]
        if patch.shape[:2] == (14, 14) and np.count_nonzero(np.all(patch < 80, axis=2)) >= 8:
            found.append(ch)
    return found


def _trace_series(a: np.ndarray, box: tuple[int, int, int, int], top_value: float) -> tuple[np.ndarray, np.ndarray]:
    x, y, w, h = box
    x0, x1 = x + int(w * .145), x + w - 4
    y0, y1 = y + int(h * .08), y + int(h * .73)
    crop = a[y0:y1 + 1, x0:x1 + 1].astype(int)
    r, g, b = crop[..., 0], crop[..., 1], crop[..., 2]
    green_grid = (g > 55) & (g > r * 1.35) & (g > b * 1.25)
    bright = (r + g + b > 410) & (np.maximum.reduce([r, g, b]) > 145)
    trace = bright & ~green_grid
    # Remove long, thin UI/text runs while retaining point clouds.
    trace = ndimage.binary_opening(trace, structure=np.ones((1, 2))) | trace
    xs, vals = [], []
    height = max(1, y1 - y0)
    for col in range(trace.shape[1]):
        yy = np.flatnonzero(trace[:, col])
        if len(yy):
            # Median is deliberately insensitive to isolated vertical spikes.
            py = float(np.median(yy))
            xs.append(col)
            vals.append((1.0 - py / height) * top_value)
    if len(vals) < 25:
        raise ValueError("Not enough signal pixels were found")
    return np.asarray(xs, float), np.asarray(vals, float)


def _gain_levels(xs: np.ndarray, values: np.ndarray) -> tuple[float, float, float]:
    # Smooth by horizontal bins; text and spikes have poor horizontal continuity.
    bins = np.linspace(xs.min(), xs.max() + 1, 31)
    centers = []
    for lo, hi in zip(bins[:-1], bins[1:]):
        part = values[(xs >= lo) & (xs < hi)]
        if len(part) >= 2:
            centers.append(float(np.median(part)))
    # Do not reject globally here: in a true two-level capture the high plateau
    # is intentionally far from the (often longer) low plateau.
    c = np.asarray(centers, dtype=float)
    if len(c) < 6:
        raise ValueError("Gain plateaus could not be separated")
    # Deterministic two-cluster 1-D k-means.
    means = np.percentile(c, [20, 80]).astype(float)
    for _ in range(30):
        label = np.argmin(np.abs(c[:, None] - means[None, :]), axis=1)
        new = np.array([np.median(c[label == k]) if np.any(label == k) else means[k] for k in range(2)])
        if np.allclose(new, means):
            break
        means = new
    low, high = sorted(float(v) for v in means)
    # Explicitly remove low-base contamination from the high signal population.
    high_group = c[c > (low + high) / 2]
    low_group = c[c <= (low + high) / 2]
    low_clean, high_clean = _robust(low_group), _robust(high_group)
    low = float(np.mean(low_clean)) if len(low_clean) else low
    high = float(np.mean(high_clean)) if len(high_clean) else high
    separation = min(1.0, max(0.0, (high - low) / max(.001, top_value_for(high) * .25)))
    return low, high, separation


def top_value_for(value: float) -> float:
    return 3.0 if value > .1 else .04


def analyze_image(path: str | Path, requested_mode: str = "Auto") -> ScanResult:
    path = Path(path)
    a = np.asarray(Image.open(path).convert("RGB"))
    box = _dark_component(a)
    channels = _checked_channels(a, box)
    mode = requested_mode
    if mode == "Auto":
        mode = "Noise" if re.search(r"noise", path.name, re.I) else "Gain"
    if len(channels) > 1:
        return ScanResult(
            path.name, "Excluded", channels, None, None, None, 1.0, box,
            "Multiple checked channels",
        )
    if not channels:
        return ScanResult(
            path.name, "Excluded", channels, None, None, None, 0.0, box,
            "No checked channel detected",
        )
    top = .04 if mode == "Noise" else 3.0
    xs, values = _trace_series(a, box, top)
    if mode == "Noise":
        clean = _robust(values, 3.0)
        value = float(np.mean(clean)) if len(clean) else float(np.median(values))
        confidence = min(1.0, len(clean) / 120)
        return ScanResult(path.name, mode, channels, None, None, round(value, 1), confidence, box)
    low, high, separation = _gain_levels(xs, values)
    return ScanResult(path.name, mode, channels, round(low, 1), round(high, 1), None, separation, box)


def annotate(path: str | Path, result: ScanResult) -> Image.Image:
    im = Image.open(path).convert("RGB")
    d = ImageDraw.Draw(im)
    x, y, w, h = result.graph_box
    d.rectangle((x, y, x + w, y + h), outline=(255, 60, 60), width=3)
    label = f"{result.mode}  CH: {','.join(map(str, result.channels)) or 'none'}"
    if result.mode == "Gain":
        label += f"  Low={result.low:.1f} High={result.high:.1f}"
    elif result.mode == "Noise":
        label += f"  Mean={result.noise:.1f}"
    else:
        label += f"  {result.message}"
    d.rectangle((x, max(0, y - 24), min(im.width - 1, x + 430), y), fill=(20, 20, 20))
    d.text((x + 4, max(0, y - 20)), label, fill=(255, 255, 0))
    return im


def export_csv(results: list[ScanResult], path: str | Path) -> None:
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        wr = csv.writer(f)
        wr.writerow(["File", "Mode", "Checked Channels", "Low Mean", "High Mean", "Noise Mean", "Confidence", "Message"])
        for r in results:
            wr.writerow([r.file, r.mode, ",".join(map(str, r.channels)), r.low, r.high, r.noise, f"{r.confidence:.2f}", r.message])


def run_gui() -> None:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    root = tk.Tk()
    root.title(f"Energy Graph Scan {APP_VERSION}")
    root.geometry("1120x720")
    root.minsize(900, 600)
    results: list[ScanResult] = []
    paths: dict[str, str] = {}
    photo = None
    mode_var = tk.StringVar(value="Auto")
    status = tk.StringVar(value="Select one or more JPEG/PNG screenshots.")

    bar = ttk.Frame(root, padding=8); bar.pack(fill="x")
    ttk.Button(bar, text="Open Images", command=lambda: open_images()).pack(side="left")
    ttk.Label(bar, text="Analysis:").pack(side="left", padx=(16, 4))
    ttk.Combobox(bar, textvariable=mode_var, values=["Auto", "Gain", "Noise"], width=9, state="readonly").pack(side="left")
    ttk.Button(bar, text="Export CSV", command=lambda: save_csv()).pack(side="left", padx=8)
    ttk.Label(bar, textvariable=status).pack(side="left", padx=14)

    pane = ttk.Panedwindow(root, orient="horizontal"); pane.pack(fill="both", expand=True, padx=8, pady=(0, 8))
    left = ttk.Frame(pane); right = ttk.Frame(pane); pane.add(left, weight=2); pane.add(right, weight=3)
    cols = ("file", "mode", "channels", "low", "high", "noise", "conf")
    tree = ttk.Treeview(left, columns=cols, show="headings")
    labels = ["File", "Mode", "Channels", "Low", "High", "Noise", "Conf."]
    widths = [190, 60, 80, 55, 55, 60, 55]
    for c, label, width in zip(cols, labels, widths):
        tree.heading(c, text=label); tree.column(c, width=width, anchor="center")
    tree.column("file", anchor="w")
    tree.pack(fill="both", expand=True)
    preview = ttk.Label(right, anchor="center"); preview.pack(fill="both", expand=True)

    def show_selected(_event=None):
        nonlocal photo
        sel = tree.selection()
        if not sel: return
        idx = int(sel[0]); r = results[idx]
        im = annotate(paths[r.file], r)
        maxw, maxh = max(300, right.winfo_width() - 12), max(300, right.winfo_height() - 12)
        im.thumbnail((maxw, maxh), Image.Resampling.LANCZOS)
        photo = ImageTk.PhotoImage(im); preview.configure(image=photo)

    def open_images():
        names = filedialog.askopenfilenames(filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.tif *.tiff")])
        if not names: return
        failures = []
        for name in names:
            try:
                r = analyze_image(name, mode_var.get())
                paths[r.file] = name; results.append(r)
                tree.insert("", "end", iid=str(len(results)-1), values=(r.file, r.mode, ",".join(map(str,r.channels)), r.low if r.low is not None else "", r.high if r.high is not None else "", r.noise if r.noise is not None else "", f"{r.confidence:.0%}"))
            except Exception as exc:
                failures.append(f"{os.path.basename(name)}: {exc}")
        status.set(f"Analyzed {len(names)-len(failures)} of {len(names)} image(s).")
        if results:
            tree.selection_set(str(len(results)-1)); show_selected()
        if failures: messagebox.showwarning("Some images could not be scanned", "\n".join(failures))

    def save_csv():
        if not results:
            messagebox.showinfo("No results", "Open and analyze images first."); return
        name = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="energy_scan_results.csv", filetypes=[("CSV", "*.csv")])
        if name:
            export_csv(results, name); status.set(f"Saved: {name}")

    tree.bind("<<TreeviewSelect>>", show_selected)
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        for name in sys.argv[1:]:
            print(analyze_image(name))
    else:
        run_gui()
