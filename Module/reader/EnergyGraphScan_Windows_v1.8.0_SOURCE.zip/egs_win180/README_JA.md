# Energy Graph Scan v1.8.0 — Windows

Windows版の解析コアを、Gain自動範囲認識とpixel-first計測へ更新した版です。UIは従来のWindows操作を維持します。

## v1.8.0 の主な変更

- GainのLow/High横範囲からSample#270固定を廃止。
- 前面トレースの持続的なレベル変化から、Low安定区間・遷移区間・High安定区間を自動認識。
- Noiseのみ従来どおりSample#270境界を維持。
- トレースの実pixel Yを一次計測値として保持。
- Low/Highラインは数値から逆算せず、測定した実pixel Yへ直接描画。
- 数値は同じpixel YをY軸校正で実値へ変換。
- Y軸校正は外側ROIではなく、Energy per Bandの実plot内部だけを使用。
- Y=0はplot最下端、1目盛りは実際の主要横グリッド間隔から算出。
- グリッド本数はGain/Noise判定には使用しない。
- 単一Channelでも連続した色トレースを優先し、CH2などで別の色線/グリッドへ流れるケースを低減。
- 診断メッセージにGain自動範囲、Y校正値、Low/Highの実pixel Yを表示。

## なぜ以前は「ラインは合うのに数値だけズレる」ことがあったか

旧版は、Y軸校正が誤っていても、その誤った校正で数値化し、同じ校正を逆算してラインを描いていました。そのためラインだけ元pixel位置へ戻り、見かけ上正しくても数値が間違うケースがありました。v1.8.0ではライン描画と数値校正を分離しています。

## Gain範囲

Gainでは固定Sample#を使いません。前面トレースを横方向に走査し、2つの安定plateauとその間の遷移帯を検出します。Low/Highは実際のYレベルで決定します。

## Channel

- checkboxが1個: そのChannelを優先。
- checkboxが複数: checkbox群を候補集合として保持し、foreground trace 1本だけを計算。
- checkboxなし: Unknownのまま解析継続。

## Build

GitHub Actionsの `Build Windows EXE` または `01_BUILD_EXE_GITHUB.bat` を使用してください。
