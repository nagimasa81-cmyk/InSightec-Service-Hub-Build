from pathlib import Path

from energy_scan import analyze_image


def main() -> None:
    samples = Path(__file__).resolve().parent.parent / "upload"
    expected = {
        "Gain_verification_ch0.JPG": [0],
        "Gain_verification_ch1.JPG": [1],
        "Gain_verification_all.JPG": list(range(8)),
        "Noise_verification_ch0.JPG": [0],
        "Noise_verification_ch1.JPG": [1],
    }
    for filename, channels in expected.items():
        result = analyze_image(samples / filename)
        assert result.channels == channels, (filename, result.channels)
        if len(channels) > 1:
            assert result.mode == "Excluded" and result.message == "Multiple checked channels"
            continue
        if result.mode == "Gain":
            assert result.low is not None and result.high is not None
            assert result.high - result.low >= .5, result
    print("All five reference images passed.")


if __name__ == "__main__":
    main()
