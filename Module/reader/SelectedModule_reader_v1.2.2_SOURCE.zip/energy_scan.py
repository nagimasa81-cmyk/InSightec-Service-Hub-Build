from __future__ import annotations

import csv
import os
import re
import statistics
import sys
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
from PIL import Image, ImageDraw, ImageTk
from scipy import ndimage


APP_VERSION = "1.2.2"
IMAGE_TYPES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


@dataclass
class ScanResult:
    file: str
    mode: str
    channels: list[int]
    low: float | None
    high: float | None
    noise: float | None
    confidence: float
    graph_box: tuple[int, int, int, int]
    message: str = ""


def _robust(values: Iterable[float], z: float = 3.5, absolute_floor: float = .0003) -> np.ndarray:
    a = np.asarray(list(values), dtype=float)
    a = a[np.isfinite(a)]
    if not len(a):
        return a
    med = np.median(a)
    mad = np.median(np.abs(a - med))
    if mad < 1e-9:
        return a[np.abs(a - med) <= max(absolute_floor, abs(med) * .15)]
    return a[np.abs(a - med) / (1.4826 * mad) <= z]


def _dark_component(a: np.ndarray) -> tuple[int, int, int, int]:
    dark = np.all(a < 38, axis=2)
    labels, _ = ndimage.label(dark)
    candidates = []
    for index, sl in enumerate(ndimage.find_objects(labels), 1):
        if sl is None:
            continue
        ys, xs = sl
        w, h = xs.stop - xs.start, ys.stop - ys.start
        if 180 <= w <= 420 and 75 <= h <= 210 and xs.start > a.shape[1] * .48 and ys.start < a.shape[0] * .45:
            area = int(np.count_nonzero(labels[sl] == index))
            candidates.append((area, xs.start, ys.start, w, h))
    if not candidates:
        raise ValueError("Energy per Band graph was not found")
    _, x, y, w, h = max(candidates)
    return x, y, w, h


def _checked_channels(a: np.ndarray, box: tuple[int, int, int, int]) -> list[int]:
    x, y, _, _ = box
    # The channel row is tied to the Energy graph in both known UI layouts.
    start_x = x - 320
    check_y = y + 120
    found = []
    for ch in range(8):
        cx = int(round(start_x + ch * 36.3))
        patch = a[max(0, check_y):check_y + 14, max(0, cx):cx + 14]
        if patch.shape[:2] == (14, 14) and np.count_nonzero(np.all(patch < 80, axis=2)) >= 8:
            found.append(ch)
    return found


def _trace_series(a: np.ndarray, box: tuple[int, int, int, int], top_value: float) -> tuple[np.ndarray, np.ndarray]:
    x, y, w, h = box
    x0, x1 = x + int(w * .145), x + w - 4
    y0, y1 = y + int(h * .08), y + int(h * .73)
    crop = a[y0:y1 + 1, x0:x1 + 1].astype(int)
    r, g, b = crop[..., 0], crop[..., 1], crop[..., 2]
    green_grid = (g > 55) & (g > r * 1.35) & (g > b * 1.25)
    maximum = np.maximum.reduce([r, g, b])
    minimum = np.minimum.reduce([r, g, b])
    bright = (r + g + b > 360) & (maximum > 130)
    colored = (maximum > 105) & ((maximum - minimum) > 45)
    trace = bright | colored
    # Remove only long horizontal grid rows. Do not discard the thick green/yellow
    # signal band; otherwise isolated upper dots can be mistaken for High signal.
    grid_rows = np.flatnonzero(np.count_nonzero(green_grid, axis=1) > crop.shape[1] * .18)
    for row in grid_rows:
        trace[max(0, row - 2):min(trace.shape[0], row + 3), :] = False
    # Remove long, thin UI/text runs while retaining point clouds.
    trace = ndimage.binary_opening(trace, structure=np.ones((1, 2))) | trace
    xs, vals = [], []
    height = max(1, y1 - y0)
    for col in range(trace.shape[1]):
        yy = np.flatnonzero(trace[:, col])
        if len(yy):
            # Median is deliberately insensitive to isolated vertical spikes.
            py = float(np.median(yy))
            xs.append(col)
            vals.append((1.0 - py / height) * top_value)
    if len(vals) < 25:
        raise ValueError("Not enough signal pixels were found")
    return np.asarray(xs, float), np.asarray(vals, float)


def _noise_axis_top(a: np.ndarray, box: tuple[int, int, int, int]) -> float:
    """Use 0.03 when the cropped graph exposes only the 0.03..0 grid; otherwise 0.04."""
    x, y, w, h = box
    crop = a[y:y + h, x:x + w].astype(int)
    r, g, b = crop[..., 0], crop[..., 1], crop[..., 2]
    green = (g > 38) & (g > r * 1.28) & (g > b * 1.16)
    candidates = np.flatnonzero(np.count_nonzero(green, axis=1) > w * .18)
    groups = []
    for row in candidates:
        if not groups or row - groups[-1][-1] > 2:
            groups.append([int(row)])
        else:
            groups[-1].append(int(row))
    zero_baseline_visible = bool(groups) and np.mean(groups[-1]) > h * .63
    return (len(groups) - 1) * .01 if len(groups) >= 4 and zero_baseline_visible else .04


def _horizontal_levels(xs: np.ndarray, values: np.ndarray, top: float, fixed_sample: float | None = None) -> tuple[float, float, float]:
    """Split Noise at Sample# 270; otherwise use the strongest positive step."""
    bins = np.linspace(xs.min(), xs.max() + 1, 31)
    centers = []
    for lo, hi in zip(bins[:-1], bins[1:]):
        part = values[(xs >= lo) & (xs < hi)]
        if len(part) >= 2:
            centers.append(float(np.median(part)))
    c = np.asarray(centers, dtype=float)
    if len(c) < 6:
        raise ValueError("Left/right signal ranges could not be separated")
    window = max(3, int(len(c) * .10))
    split, best_jump = int(len(c) * .55), 0.0
    if fixed_sample is not None:
        split = int(np.clip(round(len(c) * fixed_sample / 520.0), 2, len(c) - 2))
    else:
        best_jump = -np.inf
        for index in range(max(window, int(len(c) * .25)), min(len(c) - window, int(len(c) * .82))):
            jump = float(np.median(c[index:index + window]) - np.median(c[index - window:index]))
            if jump > best_jump:
                split, best_jump = index, jump
        if best_jump < top * .08:
            raise ValueError("Low-to-high transition was not found")
    margin = max(1, window // 4)
    floor = max(.0002, top * .01)
    low_clean = _robust(c[:max(1, split - margin)], absolute_floor=floor)
    high_clean = _robust(c[min(len(c) - 1, split + margin):], absolute_floor=floor)
    low = float(np.mean(low_clean))
    high = float(np.mean(high_clean))
    separation = min(1.0, max(0.0, best_jump / max(.00001, top * .20)))
    return low, high, separation


def analyze_image(path: str | Path, requested_mode: str = "Auto") -> ScanResult:
    path = Path(path)
    a = np.asarray(Image.open(path).convert("RGB"))
    box = _dark_component(a)
    channels = _checked_channels(a, box)
    mode = requested_mode
    if mode == "Auto":
        mode = "Noise" if re.search(r"noise", path.name, re.I) else "Gain"
    if len(channels) > 1:
        return ScanResult(
            path.name, "Excluded", channels, None, None, None, 1.0, box,
            "Multiple checked channels",
        )
    if not channels:
        return ScanResult(
            path.name, "Excluded", channels, None, None, None, 0.0, box,
            "No checked channel detected",
        )
    top = _noise_axis_top(a, box) if mode == "Noise" else 3.0
    xs, values = _trace_series(a, box, top)
    low, high, separation = _horizontal_levels(xs, values, top, 270.0 if mode == "Noise" else None)
    digits = 4 if mode == "Noise" else 2
    return ScanResult(path.name, mode, channels, round(low, digits), round(high, digits), None, separation, box)


def _spec_in(result: ScanResult) -> bool:
    if result.low is None or result.high is None:
        return False
    if result.mode == "Noise":
        return 0 <= result.low <= .015 and .001 <= result.high <= .02
    if result.mode == "Gain":
        return 1 <= result.high <= 1.5
    return False


def annotate(path: str | Path, result: ScanResult) -> Image.Image:
    im = Image.open(path).convert("RGB")
    d = ImageDraw.Draw(im)
    x, y, w, h = result.graph_box
    d.rectangle((x, y, x + w, y + h), outline=(255, 60, 60), width=3)
    label = f"{result.mode}  CH: {','.join(map(str, result.channels)) or 'none'}"
    if result.mode == "Gain":
        label += f"  Low={result.low:.2f} High={result.high:.2f}  {'SPEC IN' if _spec_in(result) else 'SPEC OUT'}"
    elif result.mode == "Noise":
        label += f"  Low={result.low:.4f} High={result.high:.4f}  {'SPEC IN' if _spec_in(result) else 'SPEC OUT'}"
    else:
        label += f"  {result.message}"
    d.rectangle((x, max(0, y - 24), min(im.width - 1, x + 430), y), fill=(20, 20, 20))
    d.text((x + 4, max(0, y - 20)), label, fill=(30, 144, 255) if _spec_in(result) else (255, 55, 55))
    return im


def export_csv(results: list[ScanResult], path: str | Path) -> None:
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        wr = csv.writer(f)
        wr.writerow(["File", "Mode", "Checked Channels", "Low Mean", "High Mean", "Noise Mean", "Confidence", "Message"])
        for r in results:
            wr.writerow([r.file, r.mode, ",".join(map(str, r.channels)), r.low, r.high, r.noise, f"{r.confidence:.2f}", r.message])


def run_gui() -> None:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    try:
        from tkinterdnd2 import DND_FILES, TkinterDnD
        root = TkinterDnD.Tk(); dnd_available = True
    except Exception:
        root = tk.Tk(); DND_FILES = None; dnd_available = False
    root.title(f"Energy Graph Scan {APP_VERSION}")
    root.geometry("1120x720")
    root.minsize(900, 600)
    results: list[ScanResult] = []
    paths: dict[int, str] = {}
    temporary_dirs: list[tempfile.TemporaryDirectory] = []
    photo = None
    mode_var = tk.StringVar(value="Auto")
    status = tk.StringVar(value="Drop ZIP, folders, or image files below.")

    bar = ttk.Frame(root, padding=8); bar.pack(fill="x")
    ttk.Button(bar, text="Open Files", command=lambda: open_images()).pack(side="left")
    ttk.Button(bar, text="Open Folder", command=lambda: open_folder()).pack(side="left", padx=(6, 0))
    ttk.Label(bar, text="Analysis:").pack(side="left", padx=(16, 4))
    ttk.Combobox(bar, textvariable=mode_var, values=["Auto", "Gain", "Noise"], width=9, state="readonly").pack(side="left")
    ttk.Button(bar, text="Export CSV", command=lambda: save_csv()).pack(side="left", padx=8)
    ttk.Label(bar, textvariable=status).pack(side="left", padx=14)

    pane = ttk.Panedwindow(root, orient="horizontal"); pane.pack(fill="both", expand=True, padx=8, pady=(0, 8))
    left = ttk.Frame(pane); right = ttk.Frame(pane); pane.add(left, weight=2); pane.add(right, weight=3)
    cols = ("file", "mode", "channels", "low", "high", "spec", "conf")
    drop = ttk.Label(left, text="DROP ZIP / FOLDER / JPEG / PNG HERE", anchor="center", padding=14, relief="ridge")
    drop.pack(fill="x", pady=(0, 8))
    tree = ttk.Treeview(left, columns=cols, show="headings")
    labels = ["File", "Mode", "Channels", "Low", "High", "Spec", "Conf."]
    widths = [190, 60, 80, 55, 55, 60, 55]
    for c, label, width in zip(cols, labels, widths):
        tree.heading(c, text=label); tree.column(c, width=width, anchor="center")
    tree.column("file", anchor="w")
    tree.tag_configure("spec_in", foreground="#0070C0")
    tree.tag_configure("spec_out", foreground="#D02020")
    tree.pack(fill="both", expand=True)
    preview = ttk.Label(right, anchor="center"); preview.pack(fill="both", expand=True)

    def show_selected(_event=None):
        nonlocal photo
        sel = tree.selection()
        if not sel: return
        idx = int(sel[0]); r = results[idx]
        im = annotate(paths[idx], r)
        maxw, maxh = max(300, right.winfo_width() - 12), max(300, right.winfo_height() - 12)
        im.thumbnail((maxw, maxh), Image.Resampling.LANCZOS)
        photo = ImageTk.PhotoImage(im); preview.configure(image=photo, cursor="hand2")

    def collect_images(entries: Iterable[str]) -> tuple[list[str], list[str]]:
        found, warnings = [], []
        for raw in entries:
            p = Path(raw)
            if p.is_dir():
                found.extend(str(q) for q in p.rglob("*") if q.is_file() and q.suffix.lower() in IMAGE_TYPES)
            elif p.is_file() and p.suffix.lower() in IMAGE_TYPES:
                found.append(str(p))
            elif p.is_file() and p.suffix.lower() == ".zip":
                try:
                    holder = tempfile.TemporaryDirectory(prefix="EnergyGraphScan_"); temporary_dirs.append(holder)
                    target = Path(holder.name).resolve()
                    with zipfile.ZipFile(p) as zf:
                        for member in zf.infolist():
                            out = (target / member.filename).resolve()
                            if member.is_dir() or Path(member.filename).suffix.lower() not in IMAGE_TYPES or (target not in out.parents): continue
                            out.parent.mkdir(parents=True, exist_ok=True)
                            with zf.open(member) as src, open(out, "wb") as dst: dst.write(src.read())
                            found.append(str(out))
                except Exception as exc: warnings.append(f"{p.name}: {exc}")
            else: warnings.append(f"{p.name or raw}: unsupported")
        return list(dict.fromkeys(found)), warnings

    def analyze_entries(entries: Iterable[str]):
        names, failures = collect_images(entries)
        if not names:
            status.set("No supported images were found.")
            if failures: messagebox.showwarning("Could not import", "\n".join(failures)); return
        added = 0
        for name in names:
            try:
                r = analyze_image(name, mode_var.get()); idx = len(results); paths[idx] = name; results.append(r)
                digits = 4 if r.mode == "Noise" else 2
                low_text = f"{r.low:.{digits}f}" if r.low is not None else ""; high_text = f"{r.high:.{digits}f}" if r.high is not None else ""
                passed = _spec_in(r)
                tree.insert("", "end", iid=str(idx), values=(r.file, r.mode, ",".join(map(str,r.channels)), low_text, high_text, "IN" if passed else "OUT", f"{r.confidence:.0%}"), tags=("spec_in" if passed else "spec_out",)); added += 1
            except Exception as exc: failures.append(f"{os.path.basename(name)}: {exc}")
        status.set(f"Analyzed {added} of {len(names)} image(s).")
        if added: tree.selection_set(str(len(results)-1)); show_selected()
        if failures: messagebox.showwarning("Some items could not be scanned", "\n".join(failures[:30]))

    def open_images():
        names = filedialog.askopenfilenames(filetypes=[("Supported", "*.zip *.jpg *.jpeg *.png *.bmp *.tif *.tiff"), ("All", "*.*")])
        if names: analyze_entries(names)

    def open_folder():
        name = filedialog.askdirectory()
        if name: analyze_entries([name])

    def on_drop(event): analyze_entries(root.tk.splitlist(event.data))

    def enlarge_preview(_event=None):
        sel = tree.selection()
        if not sel: return
        idx = int(sel[0]); r = results[idx]; original = annotate(paths[idx], r)
        win = tk.Toplevel(root); win.title(f"Image inspection — {r.file}"); win.geometry("1000x760")
        tools = ttk.Frame(win, padding=6); tools.pack(fill="x"); canvas_large = tk.Canvas(win, background="#202020", highlightthickness=0)
        sx = ttk.Scrollbar(win, orient="horizontal", command=canvas_large.xview); sy = ttk.Scrollbar(win, orient="vertical", command=canvas_large.yview)
        canvas_large.configure(xscrollcommand=sx.set, yscrollcommand=sy.set); sy.pack(side="right", fill="y"); sx.pack(side="bottom", fill="x"); canvas_large.pack(fill="both", expand=True)
        state = {"photo": None}
        def redraw(factor):
            size=(max(1,int(original.width*factor)),max(1,int(original.height*factor))); shown=original.resize(size,Image.Resampling.LANCZOS)
            state["photo"]=ImageTk.PhotoImage(shown); canvas_large.delete("all"); canvas_large.create_image(0,0,image=state["photo"],anchor="nw"); canvas_large.configure(scrollregion=(0,0,*size))
        ttk.Label(tools,text="Zoom:").pack(side="left")
        for text, factor in [("50%",.5),("100%",1.0),("200%",2.0)]: ttk.Button(tools,text=text,command=lambda f=factor:redraw(f)).pack(side="left",padx=3)
        ttk.Button(tools,text="Fit",command=lambda:redraw(min((win.winfo_width()-40)/original.width,(win.winfo_height()-100)/original.height))).pack(side="left",padx=3)
        canvas_large.bind("<MouseWheel>",lambda e:canvas_large.yview_scroll(-1 if e.delta>0 else 1,"units")); redraw(1.0)

    def save_csv():
        if not results:
            messagebox.showinfo("No results", "Open and analyze images first."); return
        name = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="energy_scan_results.csv", filetypes=[("CSV", "*.csv")])
        if name:
            export_csv(results, name); status.set(f"Saved: {name}")

    tree.bind("<<TreeviewSelect>>", show_selected)
    preview.bind("<Button-1>", enlarge_preview)
    if dnd_available:
        for widget in (root, drop, tree, preview): widget.drop_target_register(DND_FILES); widget.dnd_bind("<<Drop>>", on_drop)
    else: drop.configure(text="Use Open Files / Open Folder (drag & drop unavailable)")
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        for name in sys.argv[1:]:
            print(analyze_image(name))
    else:
        run_gui()
