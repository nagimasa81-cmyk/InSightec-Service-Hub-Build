@echo off
setlocal
cd /d "%~dp0"
py -3 -m pip install --upgrade pip
if errorlevel 1 exit /b 1
py -3 -m pip install -r requirements.txt pyinstaller
if errorlevel 1 exit /b 1
py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --icon app.ico --name EnergyGraphScan energy_scan.py
if errorlevel 1 exit /b 1
echo.
echo Build complete: dist\EnergyGraphScan.exe
pause
