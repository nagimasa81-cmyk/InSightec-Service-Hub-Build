@echo off
setlocal
cd /d "%~dp0"
echo === Energy Graph Scan build interpreter ===
python -c "import sys; print(sys.executable); print(sys.version)"
if errorlevel 1 exit /b 1
python -m pip install --upgrade pip
if errorlevel 1 exit /b 1
python -m pip install -r requirements.txt pyinstaller
if errorlevel 1 exit /b 1
python -c "import numpy, PIL, scipy, tkinterdnd2; import energy_scan; print('dependency/import smoke PASS')"
if errorlevel 1 exit /b 1
python test_samples.py
if errorlevel 1 exit /b 1
python -m PyInstaller --noconfirm --clean --onefile --windowed --collect-all tkinterdnd2 --icon app.ico --name EnergyGraphScan energy_scan.py
if errorlevel 1 exit /b 1
echo.
echo Build complete: dist\EnergyGraphScan.exe
exit /b 0
