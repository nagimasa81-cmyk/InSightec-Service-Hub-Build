# Energy Graph Scan v1.7.1 — Windows

Windows版をiPhone v1.7.1の解析仕様へ合わせた版です。UIは従来のWindows操作を維持し、解析コアを更新しています。

## v1.7.1 の主な変更

- Channel checkboxが1個だけの場合は、そのChannelを優先して解析。
- 複数Channelがチェックされている場合、複数トレースを平均しない。
- グラフ内の色をクラスタ化し、色ごとに独立して横方向へトレース追跡。
- 可視率と連続性から前面に見えているトレース候補を選び、その1本だけでLow/Highを計算。
- 完全重複や検出失敗時のみ従来抽出へフォールバックし、結果メッセージに明示。
- Low/High分割はGain/NoiseともSample#270を共通基準として維持。
- Channelが不明でも解析は停止しない。
- 数値と表示ラインは同じ座標モデルを使用。

## Channel判定の考え方

1. checkboxが1個: そのChannelを優先。
2. checkboxが複数: checkbox群を候補集合として保持し、計算にはforeground traceだけを使用。
3. checkboxなし: Channel Unknownのままforeground traceで数値解析を継続。

現在は画像内の前面色トレース分離を優先しています。複数checkbox時の「foreground色 → CH番号」の完全な対応付けは、実画像による色テーブル検証を追加してさらに強化します。

## Build

GitHub Actionsの `Build Windows EXE` または `01_BUILD_EXE_GITHUB.bat` を使用してください。


## 2.0.0 Y軸数値ラベル校正
- 最下段major gridline=0 の仮定を廃止。
- Energy per Band左Y軸で実際に見えている数値ラベルだけをアンカーとして使用。
- 2個以上のラベル: pixel Y ↔ 実値を回帰して傾き/切片を決定。
- 1個だけのラベル: 読み取った実値をアンカーにし、major grid spacingから傾きだけ補完。
- 0個: 数値とSPECを出さない。
- ラベルが一部隠れていても、見えているアンカーだけで処理。
- グリッド本数をGain/Noise判定には使用しない。
- Gain Low/High横範囲は自動認識、NoiseのみSample#270。
- デバッグ情報にY-axis anchorsを表示。

## v2.2.0 Vision-style Axis Reasoning
- Manual Gain/Noiseを絶対優先。反対family OCRを使用しない。
- Autoはtrace-modeを初期仮説にし、Gain/NoiseのY軸系列を別々に評価。
- 複数ラベルの上下順・major-grid stepとの整合・数値scaleを統合スコア化。
- 弱いOCRでtrace-modeを上書きしない。決定的な差がある場合のみAuto modeを補正。
- 1-anchor校正はconfidenceが十分高い場合だけ数値化。
- Overlay pixelは従来どおり一次測定として維持。数値校正失敗時はLow/High/SPEC保留。

## Windows v2.2.1 Pixel-primary Measurement
- foreground traceの実pixelを一次測定値として保存。
- Low/High代表高さはrobust median。平均値による下振れを抑制。
- Gainの表示X範囲はstable subsetのmin/maxではなく、transition前後のplateau全体。
- 数値は同じ代表pixelをY軸校正へ入力して算出。
- overlayも同じ代表pixelとplateau範囲を直接使用。
- 値からpixelへ逆変換してoverlayを作らない。
