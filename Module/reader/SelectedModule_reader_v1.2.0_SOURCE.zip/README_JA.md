# Energy Graph Scan v1.2.0

CGA/CSA画面を保存したJPEG/PNG画像から、Channelsのチェック状態と「Energy per Band」を数値化します。

## 使い方

1. `EnergyGraphScan.exe`を起動します。
2. ZIP・フォルダ・JPEG/PNGファイルをドロップします。複数同時ドロップ、`Open Files`、`Open Folder`にも対応します。
3. ファイル名に`Noise`が含まれる画像はNoise、それ以外はGainとして自動判定します。必要ならAnalysis欄で固定指定できます。
4. 結果表で画像を選ぶと、検出領域と値をプレビューできます。
5. `Export CSV`で全結果を保存します。
6. 右側プレビューをクリックすると拡大画面が開き、50%／100%／200%／Fitとスクロールで画像状態を確認できます。

## 計算仕様

- Gain：横方向の切替点で左側Low／右側Highを分離し、小数第2位で表示します。Highの1.00〜1.50がスペック内です（Lowはベース値のため判定対象外）。
- Noise：横方向の切替点で左側Low／右側Highを分離し、小数第4位で表示します。Lowは0〜0.015、Highは0.001〜0.02がスペック内です。
- スペック内は青、スペック外は赤で表示します。
- 縦方向の孤立スパイクは中央値・MAD外れ値除去で無視します。
- Gainの高信号区間に混在する低ベースは2群分離後、高信号群から除外します。
- 添付基準画面に従い、Gain縦軸上限は3.0、Noise縦軸上限は0.04として換算します。
- チェック対象はChannel 0～7です。
- 複数チャンネルが同時にチェックされた画像は解析対象外とし、`Excluded: Multiple checked channels`と表示します。
- チャンネルが1つだけチェックされた画像のみGain／Noiseを数値化します。

## ソースから起動

```text
python -m pip install -r requirements.txt
python energy_scan.py
```

## Windows EXEビルド

`01_BUILD_EXE_GITHUB.bat`をダブルクリックするか、GitHub Actionsの`Build Windows EXE`を実行します。
