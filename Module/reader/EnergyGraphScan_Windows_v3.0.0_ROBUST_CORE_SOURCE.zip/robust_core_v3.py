
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Iterable
import math

@dataclass(frozen=True)
class Hypothesis:
    kind: str
    value: Any
    score: float
    source: str
    evidence: dict[str, Any] = field(default_factory=dict)

def _clip(v: float) -> float:
    return max(0.0, min(1.0, float(v)))

def H(kind, value, score, source, **evidence):
    return Hypothesis(kind, value, _clip(score), source, evidence)

def choose(hypotheses: Iterable[Hypothesis], margin=.10, minimum=.45, allow_unknown=True):
    h=sorted([x for x in hypotheses if x is not None and math.isfinite(x.score)],key=lambda x:x.score,reverse=True)
    if not h:
        return H("result","Unknown" if allow_unknown else None,0.0,"no-hypothesis")
    a=h[0]
    if a.score<minimum:
        return H(a.kind,"Unknown" if allow_unknown else None,a.score,"below-minimum",ranked=[x.source for x in h])
    if len(h)>1 and a.value!=h[1].value and a.score-h[1].score<margin:
        return H(a.kind,"Unknown" if allow_unknown else None,a.score,"ambiguous-margin",ranked=[x.source for x in h])
    return a

def resolve_mode(requested, trace_mode, axis_scores):
    if requested in {"Gain","Noise"}:
        return H("mode",requested,1.0,"manual")
    hs=[]
    if trace_mode in {"Gain","Noise"}:
        hs.append(H("mode",trace_mode,.52,"trace-morphology"))
    gs=float(axis_scores.get("Gain",float("nan")))
    ns=float(axis_scores.get("Noise",float("nan")))
    if math.isfinite(gs): hs.append(H("mode","Gain",.50+.40*max(0,min(1,gs)),"axis-family"))
    if math.isfinite(ns): hs.append(H("mode","Noise",.50+.40*max(0,min(1,ns)),"axis-family"))
    return choose(hs,margin=.12,minimum=.48)

def resolve_channel(checked, foreground_channel):
    checked=list(checked or [])
    if len(checked)==1:
        return H("channel",checked[0],1.0,"single-checked")
    if len(checked)>1:
        if foreground_channel is not None and foreground_channel in checked:
            return H("channel",foreground_channel,.92,"foreground-color-matched")
        return H("channel",None,.60,"multiple-checked-no-color-match",checked=checked,foreground=foreground_channel)
    return H("channel",None,.50,"no-checked-channel")

def numeric_guard(mode, low, high, displayed_max=None):
    if low is None or high is None or not (math.isfinite(low) and math.isfinite(high)):
        return False,"non-finite"
    if mode=="Noise":
        if not (-.003<=low<=.06 and -.003<=high<=.06): return False,"Noise outside plausible display scale"
    elif mode=="Gain":
        lim=3.6 if displayed_max is None else max(3.2,float(displayed_max)*1.20)
        if high+.04<low: return False,"Gain High<Low"
        if not (0<=low<=lim and 0<=high<=lim): return False,"Gain outside displayed scale"
    else:
        return False,"unknown mode"
    return True,"PASS"
