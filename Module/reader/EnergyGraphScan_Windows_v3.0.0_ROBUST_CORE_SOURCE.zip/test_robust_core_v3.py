
from robust_core_v3 import *
m=resolve_mode("Auto","Gain",{"Gain":.15,"Noise":.88})
assert m.value=="Noise"
assert resolve_channel([1,2,3],2).value==2
assert resolve_channel([1,2,3],7).value is None
assert numeric_guard("Noise",.006,.014)[0]
assert not numeric_guard("Gain",2.0,1.0)[0]
print("Robust Core v3 Windows policy PASS")
