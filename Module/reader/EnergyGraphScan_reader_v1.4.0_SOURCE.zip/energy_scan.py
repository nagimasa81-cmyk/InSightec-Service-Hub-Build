from __future__ import annotations

import csv
import os
import re
import sys
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
from PIL import Image, ImageDraw, ImageTk
from scipy import ndimage


APP_VERSION = "1.4.0"
IMAGE_TYPES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
SAMPLE_SPLIT = 270.0
SAMPLE_AXIS_MAX = 500.0


@dataclass
class ScanResult:
    file: str
    mode: str
    channels: list[int]
    low: float | None
    high: float | None
    noise: float | None
    confidence: float
    graph_box: tuple[int, int, int, int]
    message: str = ""
    analysis_channel: int | None = None
    split_sample: float = SAMPLE_SPLIT
    axis_top: float = 3.0


def _robust(values: Iterable[float], z: float = 3.5, absolute_floor: float = .0003) -> np.ndarray:
    a = np.asarray(list(values), dtype=float)
    a = a[np.isfinite(a)]
    if not len(a):
        return a
    med = np.median(a)
    mad = np.median(np.abs(a - med))
    if mad < 1e-9:
        return a[np.abs(a - med) <= max(absolute_floor, abs(med) * .15)]
    return a[np.abs(a - med) / (1.4826 * mad) <= z]


def _dark_component(a: np.ndarray) -> tuple[int, int, int, int]:
    """Find the Energy per Band graph using scale-tolerant geometry.

    The old detector hard-coded 180..420 x 75..210 pixels. That was fragile when
    iPhone crop/zoom changed by only a few pixels. The new detector scores dark
    rectangular components relative to image size, while retaining conservative
    limits to avoid menus and headers.
    """
    dark = np.all(a < 42, axis=2)
    labels, _ = ndimage.label(dark)
    ih, iw = a.shape[:2]
    candidates: list[tuple[float, int, int, int, int]] = []
    for index, sl in enumerate(ndimage.find_objects(labels), 1):
        if sl is None:
            continue
        ys, xs = sl
        w, h = xs.stop - xs.start, ys.stop - ys.start
        if w < max(120, iw * .12) or h < max(55, ih * .055):
            continue
        if w > iw * .55 or h > ih * .38:
            continue
        if xs.start < iw * .38 or ys.start > ih * .58:
            continue
        area = int(np.count_nonzero(labels[sl] == index))
        fill = area / max(1, w * h)
        aspect = w / max(1, h)
        if not (1.45 <= aspect <= 6.5):
            continue
        # Prefer right-side, upper-half components with graph-like aspect/fill.
        score = area * (0.75 + min(aspect, 4.0) / 8.0) * (0.7 + min(fill, .9))
        score *= 1.0 + max(0.0, xs.start / iw - .45)
        candidates.append((score, xs.start, ys.start, w, h))
    if not candidates:
        raise ValueError("Energy per Band graph was not found")
    _, x, y, w, h = max(candidates)
    return int(x), int(y), int(w), int(h)


def _checked_channels(a: np.ndarray, box: tuple[int, int, int, int]) -> list[int]:
    """Detect checked CH0..CH7 using graph-relative coordinates.

    We retain the known UI relationship but scale the offsets from the graph width
    so small iPhone crop/zoom changes do not shift every channel checkbox.
    """
    x, y, w, h = box
    scale = w / 300.0
    start_x = x - 320.0 * scale
    check_y = y + 120.0 * (h / 135.0)
    step = 36.3 * scale
    patch_size = int(np.clip(round(14 * scale), 9, 22))
    found: list[int] = []
    for ch in range(8):
        cx = int(round(start_x + ch * step))
        cy = int(round(check_y))
        patch = a[max(0, cy):min(a.shape[0], cy + patch_size), max(0, cx):min(a.shape[1], cx + patch_size)]
        if patch.size == 0:
            continue
        dark_count = np.count_nonzero(np.all(patch < 85, axis=2))
        threshold = max(5, int(patch.shape[0] * patch.shape[1] * .04))
        if dark_count >= threshold:
            found.append(ch)
    return found


def _graph_trace_geometry(box: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    x, y, w, h = box
    return x + int(w * .145), y + int(h * .08), x + w - 4, y + int(h * .73)


def _split_x(box: tuple[int, int, int, int], split_sample: float = SAMPLE_SPLIT) -> float:
    x0, _, x1, _ = _graph_trace_geometry(box)
    return x0 + (x1 - x0) * np.clip(split_sample / SAMPLE_AXIS_MAX, 0.0, 1.0)


def _value_to_y(box: tuple[int, int, int, int], value: float, top_value: float) -> float:
    _, y0, _, y1 = _graph_trace_geometry(box)
    return y1 - np.clip(value / max(top_value, 1e-12), 0.0, 1.0) * (y1 - y0)


def _trace_series(a: np.ndarray, box: tuple[int, int, int, int], top_value: float, mode: str, channel: int | None) -> tuple[np.ndarray, np.ndarray]:
    x0, y0, x1, y1 = _graph_trace_geometry(box)
    crop = a[y0:y1 + 1, x0:x1 + 1].astype(int)
    r, g, b = crop[..., 0], crop[..., 1], crop[..., 2]
    green_grid = (g > 55) & (g > r * 1.35) & (g > b * 1.25)
    maximum = np.maximum.reduce([r, g, b])
    minimum = np.minimum.reduce([r, g, b])
    bright = (r + g + b > 360) & (maximum > 130)
    colored = (maximum > 105) & ((maximum - minimum) > 45)

    # CH0 is white. CH1..7 are colored. Unknown/multiple use the union so that
    # channel detection failure no longer blocks signal quantification.
    if channel == 0:
        trace = bright.copy()
    elif channel is not None:
        trace = colored.copy()
    else:
        trace = bright | colored

    if channel != 0:
        trace &= ~ndimage.binary_dilation(green_grid, structure=np.ones((3, 3)))

    if mode == "Noise" and channel != 0:
        achromatic = bright & ((maximum - minimum) < 38)
        popup_cols = np.flatnonzero(
            np.count_nonzero(achromatic[int(trace.shape[0] * .45):], axis=0)
            >= max(3, int(trace.shape[0] * .055))
        )
        for col in popup_cols:
            trace[:, max(0, col - 4):min(trace.shape[1], col + 5)] = False

    trace = ndimage.binary_opening(trace, structure=np.ones((1, 2))) | trace
    xs, vals = [], []
    height = max(1, y1 - y0)
    split_ratio = SAMPLE_SPLIT / SAMPLE_AXIS_MAX
    for col in range(trace.shape[1]):
        yy = np.flatnonzero(trace[:, col])
        if len(yy):
            if mode == "Noise":
                quantile = .90 if col < trace.shape[1] * split_ratio else .60
            else:
                quantile = .50
            py = float(np.quantile(yy, quantile))
            xs.append(col)
            vals.append((1.0 - py / height) * top_value)
    if len(vals) < 25:
        raise ValueError("Not enough signal pixels were found")
    return np.asarray(xs, float), np.asarray(vals, float)


def _noise_axis_top(a: np.ndarray, box: tuple[int, int, int, int]) -> float:
    """Use 0.03 when the cropped graph exposes only the 0.03..0 grid; otherwise 0.04."""
    x, y, w, h = box
    crop = a[y:y + h, x:x + w].astype(int)
    r, g, b = crop[..., 0], crop[..., 1], crop[..., 2]
    green = (g > 38) & (g > r * 1.28) & (g > b * 1.16)
    candidates = np.flatnonzero(np.count_nonzero(green, axis=1) > w * .18)
    groups: list[list[int]] = []
    for row in candidates:
        if not groups or row - groups[-1][-1] > 2:
            groups.append([int(row)])
        else:
            groups[-1].append(int(row))
    zero_baseline_visible = bool(groups) and np.mean(groups[-1]) > h * .63
    return (len(groups) - 1) * .01 if len(groups) >= 4 and zero_baseline_visible else .04


def _detect_mode(a: np.ndarray, box: tuple[int, int, int, int], filename: str) -> tuple[str, str]:
    """Auto mode with explicit filename evidence plus conservative visual fallback.

    Filename remains authoritative when it states Gain/Noise. For generic camera
    filenames we estimate from the graph grid density. Ambiguous cases fall back
    to Gain but are marked in the result message rather than silently pretending
    the mode was certain.
    """
    if re.search(r"noise", filename, re.I):
        return "Noise", ""
    if re.search(r"gain", filename, re.I):
        return "Gain", ""

    x, y, w, h = box
    crop = a[y:y + h, x:x + w].astype(int)
    r, g, b = crop[..., 0], crop[..., 1], crop[..., 2]
    green = (g > 45) & (g > r * 1.28) & (g > b * 1.16)
    rows = np.flatnonzero(np.count_nonzero(green, axis=1) > w * .18)
    groups = 0
    last = -99
    for row in rows:
        if row - last > 2:
            groups += 1
        last = int(row)
    if 4 <= groups <= 5:
        return "Noise", "Auto mode inferred from graph scale"
    return "Gain", "Auto mode uncertain; Gain fallback used"


def _horizontal_levels(xs: np.ndarray, values: np.ndarray, top: float, split_sample: float = SAMPLE_SPLIT, axis_width: float | None = None) -> tuple[float, float, float]:
    """Split every graph at Sample#270 and robustly average Low and High regions."""
    if len(xs) < 6:
        raise ValueError("Left/right signal ranges could not be separated")
    x_min, x_max = float(xs.min()), float(xs.max())
    full_width = float(axis_width if axis_width is not None else max(1.0, x_max + 1.0))
    split_x = (full_width - 1.0) * np.clip(split_sample / SAMPLE_AXIS_MAX, 0.0, 1.0)
    margin = max(2.0, full_width * .018)
    left = values[xs <= split_x - margin]
    right = values[xs >= split_x + margin]
    if len(left) < 4 or len(right) < 4:
        raise ValueError("Low/High regions do not contain enough signal samples")

    floor = max(.0002, top * .01)
    low_clean = _robust(left, absolute_floor=floor)
    high_clean = _robust(right, absolute_floor=floor)
    if not len(low_clean) or not len(high_clean):
        raise ValueError("Signal samples were removed as outliers")

    low = float(np.mean(low_clean))
    high = float(np.mean(high_clean))
    delta = abs(float(np.median(high_clean)) - float(np.median(low_clean)))
    separation = min(1.0, max(0.0, delta / max(.00001, top * .20)))
    return low, high, separation


def analyze_array(
    a: np.ndarray,
    filename: str = "image",
    requested_mode: str = "Auto",
    graph_box_override: tuple[int, int, int, int] | None = None,
) -> ScanResult:
    """Single analysis pipeline used by both automatic and future manual ROI paths."""
    if a.ndim != 3 or a.shape[2] < 3:
        raise ValueError("RGB image data is required")
    a = np.asarray(a[..., :3], dtype=np.uint8)
    box = graph_box_override or _dark_component(a)
    channels = _checked_channels(a, box)

    message_parts: list[str] = []
    mode = requested_mode
    if mode == "Auto":
        mode, mode_note = _detect_mode(a, box, filename)
        if mode_note:
            message_parts.append(mode_note)
    if mode not in {"Gain", "Noise"}:
        raise ValueError(f"Unsupported analysis mode: {mode}")

    # Continue analysis even if channel detection failed or found multiple boxes.
    # One exact channel gets channel-specific color extraction; otherwise union trace.
    analysis_channel = channels[0] if len(channels) == 1 else None
    if not channels:
        message_parts.append("Channel unknown; signal analysis continued")
    elif len(channels) > 1:
        message_parts.append("Multiple channel candidates; combined signal analysis used")

    top = _noise_axis_top(a, box) if mode == "Noise" else 3.0
    xs, values = _trace_series(a, box, top, mode, analysis_channel)
    x0, _, x1, _ = _graph_trace_geometry(box)
    low, high, separation = _horizontal_levels(xs, values, top, SAMPLE_SPLIT, axis_width=max(1, x1 - x0 + 1))
    digits = 4 if mode == "Noise" else 2
    return ScanResult(
        filename,
        mode,
        channels,
        round(low, digits),
        round(high, digits),
        None,
        separation,
        box,
        "; ".join(message_parts),
        analysis_channel=analysis_channel,
        split_sample=SAMPLE_SPLIT,
        axis_top=top,
    )


def analyze_image(
    path: str | Path,
    requested_mode: str = "Auto",
    graph_box_override: tuple[int, int, int, int] | None = None,
) -> ScanResult:
    path = Path(path)
    a = np.asarray(Image.open(path).convert("RGB"))
    return analyze_array(a, path.name, requested_mode, graph_box_override)


def _spec_in(result: ScanResult) -> bool:
    if result.low is None or result.high is None:
        return False
    if result.mode == "Noise":
        return 0 <= result.low <= .015 and .001 <= result.high <= .02
    if result.mode == "Gain":
        return 1 <= result.high <= 1.5
    return False


def annotate(path: str | Path, result: ScanResult) -> Image.Image:
    """Draw analysis overlays from the exact same coordinate model used for values."""
    im = Image.open(path).convert("RGB")
    d = ImageDraw.Draw(im)
    x, y, w, h = result.graph_box
    d.rectangle((x, y, x + w, y + h), outline=(255, 60, 60), width=3)

    top = result.axis_top
    split_x = _split_x(result.graph_box, result.split_sample)
    _, y0, _, y1 = _graph_trace_geometry(result.graph_box)
    d.line((split_x, y0, split_x, y1), fill=(255, 210, 40), width=2)

    if result.low is not None:
        ly = _value_to_y(result.graph_box, result.low, top)
        x0, _, _, _ = _graph_trace_geometry(result.graph_box)
        d.line((x0, ly, split_x, ly), fill=(0, 190, 255), width=3)
    if result.high is not None:
        hy = _value_to_y(result.graph_box, result.high, top)
        _, _, x1, _ = _graph_trace_geometry(result.graph_box)
        d.line((split_x, hy, x1, hy), fill=(255, 120, 0), width=3)

    channel_text = ",".join(map(str, result.channels)) if result.channels else "Unknown"
    label = f"{result.mode}  CH: {channel_text}"
    if result.low is not None and result.high is not None:
        if result.mode == "Gain":
            label += f"  Low={result.low:.2f} High={result.high:.2f}  {'SPEC IN' if _spec_in(result) else 'SPEC OUT'}"
        else:
            label += f"  Low={result.low:.4f} High={result.high:.4f}  {'SPEC IN' if _spec_in(result) else 'SPEC OUT'}"
    if result.message:
        label += f"  [{result.message}]"
    label_width = min(im.width - 1, x + max(430, int(w * 1.55)))
    d.rectangle((x, max(0, y - 28), label_width, y), fill=(20, 20, 20))
    d.text((x + 4, max(0, y - 22)), label, fill=(30, 144, 255) if _spec_in(result) else (255, 55, 55))
    return im


def export_csv(results: list[ScanResult], path: str | Path) -> None:
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        wr = csv.writer(f)
        wr.writerow(["File", "Mode", "Checked Channels", "Analysis Channel", "Low Mean", "High Mean", "Noise Mean", "Confidence", "Message"])
        for r in results:
            wr.writerow([
                r.file,
                r.mode,
                ",".join(map(str, r.channels)) if r.channels else "Unknown",
                "" if r.analysis_channel is None else r.analysis_channel,
                r.low,
                r.high,
                r.noise,
                f"{r.confidence:.2f}",
                r.message,
            ])


def run_gui() -> None:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    try:
        from tkinterdnd2 import DND_FILES, TkinterDnD
        root = TkinterDnD.Tk(); dnd_available = True
    except Exception:
        root = tk.Tk(); DND_FILES = None; dnd_available = False
    root.title(f"Energy Graph Scan {APP_VERSION}")
    root.geometry("1120x720")
    root.minsize(900, 600)
    results: list[ScanResult] = []
    paths: dict[int, str] = {}
    temporary_dirs: list[tempfile.TemporaryDirectory] = []
    photo = None
    mode_var = tk.StringVar(value="Auto")
    status = tk.StringVar(value="Drop ZIP, folders, or image files below.")

    bar = ttk.Frame(root, padding=8); bar.pack(fill="x")
    ttk.Button(bar, text="Open Files", command=lambda: open_images()).pack(side="left")
    ttk.Button(bar, text="Open Folder", command=lambda: open_folder()).pack(side="left", padx=(6, 0))
    ttk.Label(bar, text="Analysis:").pack(side="left", padx=(16, 4))
    ttk.Combobox(bar, textvariable=mode_var, values=["Auto", "Gain", "Noise"], width=9, state="readonly").pack(side="left")
    ttk.Button(bar, text="Export CSV", command=lambda: save_csv()).pack(side="left", padx=8)
    ttk.Label(bar, textvariable=status).pack(side="left", padx=14)

    pane = ttk.Panedwindow(root, orient="horizontal"); pane.pack(fill="both", expand=True, padx=8, pady=(0, 8))
    left = ttk.Frame(pane); right = ttk.Frame(pane); pane.add(left, weight=2); pane.add(right, weight=3)
    cols = ("file", "mode", "channels", "low", "high", "spec", "conf")
    drop = ttk.Label(left, text="DROP ZIP / FOLDER / JPEG / PNG HERE", anchor="center", padding=14, relief="ridge")
    drop.pack(fill="x", pady=(0, 8))
    tree = ttk.Treeview(left, columns=cols, show="headings")
    labels = ["File", "Mode", "Channels", "Low", "High", "Spec", "Conf."]
    widths = [190, 60, 95, 55, 55, 60, 55]
    for c, label, width in zip(cols, labels, widths):
        tree.heading(c, text=label); tree.column(c, width=width, anchor="center")
    tree.column("file", anchor="w")
    tree.tag_configure("spec_in", foreground="#0070C0")
    tree.tag_configure("spec_out", foreground="#D02020")
    tree.pack(fill="both", expand=True)
    preview = ttk.Label(right, anchor="center"); preview.pack(fill="both", expand=True)

    def show_selected(_event=None):
        nonlocal photo
        sel = tree.selection()
        if not sel: return
        idx = int(sel[0]); r = results[idx]
        im = annotate(paths[idx], r)
        maxw, maxh = max(300, right.winfo_width() - 12), max(300, right.winfo_height() - 12)
        im.thumbnail((maxw, maxh), Image.Resampling.LANCZOS)
        photo = ImageTk.PhotoImage(im); preview.configure(image=photo, cursor="hand2")
        if r.message:
            status.set(r.message)

    def collect_images(entries: Iterable[str]) -> tuple[list[str], list[str]]:
        found, warnings = [], []
        for raw in entries:
            p = Path(raw)
            if p.is_dir():
                found.extend(str(q) for q in p.rglob("*") if q.is_file() and q.suffix.lower() in IMAGE_TYPES)
            elif p.is_file() and p.suffix.lower() in IMAGE_TYPES:
                found.append(str(p))
            elif p.is_file() and p.suffix.lower() == ".zip":
                try:
                    holder = tempfile.TemporaryDirectory(prefix="EnergyGraphScan_"); temporary_dirs.append(holder)
                    target = Path(holder.name).resolve()
                    with zipfile.ZipFile(p) as zf:
                        for member in zf.infolist():
                            out = (target / member.filename).resolve()
                            if member.is_dir() or Path(member.filename).suffix.lower() not in IMAGE_TYPES or (target not in out.parents): continue
                            out.parent.mkdir(parents=True, exist_ok=True)
                            with zf.open(member) as src, open(out, "wb") as dst: dst.write(src.read())
                            found.append(str(out))
                except Exception as exc: warnings.append(f"{p.name}: {exc}")
            else: warnings.append(f"{p.name or raw}: unsupported")
        return list(dict.fromkeys(found)), warnings

    def analyze_entries(entries: Iterable[str]):
        names, failures = collect_images(entries)
        if not names:
            status.set("No supported images were found.")
            if failures: messagebox.showwarning("Could not import", "\n".join(failures))
            return
        added = 0
        for name in names:
            try:
                r = analyze_image(name, mode_var.get()); idx = len(results); paths[idx] = name; results.append(r)
                digits = 4 if r.mode == "Noise" else 2
                low_text = f"{r.low:.{digits}f}" if r.low is not None else ""; high_text = f"{r.high:.{digits}f}" if r.high is not None else ""
                passed = _spec_in(r)
                ch_text = ",".join(map(str, r.channels)) if r.channels else "Unknown"
                tree.insert("", "end", iid=str(idx), values=(r.file, r.mode, ch_text, low_text, high_text, "IN" if passed else "OUT", f"{r.confidence:.0%}"), tags=("spec_in" if passed else "spec_out",)); added += 1
            except Exception as exc: failures.append(f"{os.path.basename(name)}: {exc}")
        status.set(f"Analyzed {added} of {len(names)} image(s).")
        if added: tree.selection_set(str(len(results)-1)); show_selected()
        if failures: messagebox.showwarning("Some items could not be scanned", "\n".join(failures[:30]))

    def open_images():
        names = filedialog.askopenfilenames(filetypes=[("Supported", "*.zip *.jpg *.jpeg *.png *.bmp *.tif *.tiff"), ("All", "*.*")])
        if names: analyze_entries(names)

    def open_folder():
        name = filedialog.askdirectory()
        if name: analyze_entries([name])

    def on_drop(event): analyze_entries(root.tk.splitlist(event.data))

    def enlarge_preview(_event=None):
        sel = tree.selection()
        if not sel: return
        idx = int(sel[0]); r = results[idx]; original = annotate(paths[idx], r)
        win = tk.Toplevel(root); win.title(f"Image inspection — {r.file}"); win.geometry("1000x760")
        tools = ttk.Frame(win, padding=6); tools.pack(fill="x"); canvas_large = tk.Canvas(win, background="#202020", highlightthickness=0)
        sx = ttk.Scrollbar(win, orient="horizontal", command=canvas_large.xview); sy = ttk.Scrollbar(win, orient="vertical", command=canvas_large.yview)
        canvas_large.configure(xscrollcommand=sx.set, yscrollcommand=sy.set); sy.pack(side="right", fill="y"); sx.pack(side="bottom", fill="x"); canvas_large.pack(fill="both", expand=True)
        state = {"photo": None}
        def redraw(factor):
            size=(max(1,int(original.width*factor)),max(1,int(original.height*factor))); shown=original.resize(size,Image.Resampling.LANCZOS)
            state["photo"]=ImageTk.PhotoImage(shown); canvas_large.delete("all"); canvas_large.create_image(0,0,image=state["photo"],anchor="nw"); canvas_large.configure(scrollregion=(0,0,*size))
        ttk.Label(tools,text="Zoom:").pack(side="left")
        for text, factor in [("50%",.5),("100%",1.0),("200%",2.0)]: ttk.Button(tools,text=text,command=lambda f=factor:redraw(f)).pack(side="left",padx=3)
        ttk.Button(tools,text="Fit",command=lambda:redraw(min((win.winfo_width()-40)/original.width,(win.winfo_height()-100)/original.height))).pack(side="left",padx=3)
        canvas_large.bind("<MouseWheel>",lambda e:canvas_large.yview_scroll(-1 if e.delta>0 else 1,"units")); redraw(1.0)

    def save_csv():
        if not results:
            messagebox.showinfo("No results", "Open and analyze images first."); return
        name = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="energy_scan_results.csv", filetypes=[("CSV", "*.csv")])
        if name:
            export_csv(results, name); status.set(f"Saved: {name}")

    tree.bind("<<TreeviewSelect>>", show_selected)
    preview.bind("<Button-1>", enlarge_preview)
    if dnd_available:
        for widget in (root, drop, tree, preview): widget.drop_target_register(DND_FILES); widget.dnd_bind("<<Drop>>", on_drop)
    else: drop.configure(text="Use Open Files / Open Folder (drag & drop unavailable)")
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        for name in sys.argv[1:]:
            print(analyze_image(name))
    else:
        run_gui()
