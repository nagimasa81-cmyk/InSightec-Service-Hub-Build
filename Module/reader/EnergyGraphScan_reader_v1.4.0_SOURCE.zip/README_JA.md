# Energy Graph Scan v1.4.0

CGA/CSA画面を保存したJPEG/PNG画像から、Channelsのチェック状態と「Energy per Band」を数値化します。

## v1.4.0 の主な変更

- Gain / NoiseともにLow/High境界を **Sample#270** に統一しました。
- Channelを検出できなくても `Unknown` として解析を継続します。
- 複数Channelを検出しても除外せず、候補Channelを表示したまま複合信号として解析を継続します。
- 自動ROIと将来の手動ROIが同じ `analyze_array()` パイプラインを使用できる構造へ整理しました。
- 数値計算とプレビューの検出ラインが同じ座標変換を使用するように統一しました。
- Energy per Bandグラフ検出を固定px条件から画像サイズ相対の判定へ変更し、iPhone撮影時の軽微なクロップ差に強くしました。
- Autoモードはファイル名にGain/Noiseがあれば優先し、一般的なカメラ名の場合はグラフスケールから補助判定します。曖昧な場合は結果メッセージに表示します。

## 使い方

1. `EnergyGraphScan.exe`を起動します。
2. ZIP・フォルダ・JPEG/PNGファイルをドロップします。複数同時ドロップ、`Open Files`、`Open Folder`にも対応します。
3. Analysisは通常`Auto`を使います。必要なら`Gain`または`Noise`を固定指定できます。
4. 結果表で画像を選ぶと、検出領域、Sample#270境界、Low/High検出ラインをプレビューできます。
5. 右側プレビューをクリックすると拡大表示できます。
6. `Export CSV`で全結果を保存できます。

## 計算仕様

- 横軸は **Low = Sample#0〜270、High = Sample#270以降** として扱います。
- Gain：小数第2位。Highの1.00〜1.50がスペック内です。
- Noise：小数第4位。Lowは0〜0.015、Highは0.001〜0.02がスペック内です。
- スペック内は青、スペック外は赤で表示します。
- 孤立スパイクは中央値・MADベースの外れ値除去で平均から外します。
- CH0は白色信号、CH1〜7は色付き信号として抽出します。
- Channelが1つだけ確定した場合はChannel別抽出を使います。
- Channel不明または複数候補の場合は白色＋色付き信号を統合して解析を継続します。
- プレビューの縦境界線とLow/High水平線は、値計算と同じグラフ座標から生成します。

## 検証について

SOURCE ZIPには基準スクリーンショット画像そのものは含まれていません。そのため同梱テストではSample#270分割・外れ値除去を合成データで必ず確認し、基準画像が`../upload`に存在する環境では追加の実画像テストも自動実行します。

## ソースから起動

```text
python -m pip install -r requirements.txt
python energy_scan.py
```

## テスト

```text
python test_samples.py
```

## Windows EXEビルド

`01_BUILD_EXE_GITHUB.bat`をダブルクリックするか、GitHub Actionsの`Build Windows EXE`を実行します。
