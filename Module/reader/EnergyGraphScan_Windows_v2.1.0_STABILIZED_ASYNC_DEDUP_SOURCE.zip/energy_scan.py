from __future__ import annotations

import csv
import os
import re
import sys
import tempfile
import zipfile
import threading
import queue
import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageTk
from scipy import ndimage


APP_VERSION = "2.1.0"
IMAGE_TYPES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
SAMPLE_SPLIT = 270.0
SAMPLE_AXIS_MAX = 500.0


@dataclass
class ScanResult:
    file: str
    mode: str
    channels: list[int]
    low: float | None
    high: float | None
    noise: float | None
    confidence: float
    graph_box: tuple[int, int, int, int]
    message: str = ""
    analysis_channel: int | None = None
    split_sample: float = SAMPLE_SPLIT
    axis_top: float = 3.0
    plot_box: tuple[int, int, int, int] | None = None
    axis_zero_y: float | None = None
    axis_step_px: float | None = None
    axis_step_value: float | None = None
    low_y_px: float | None = None
    high_y_px: float | None = None
    low_x_range: tuple[float, float] | None = None
    high_x_range: tuple[float, float] | None = None


def _robust(values: Iterable[float], z: float = 3.5, absolute_floor: float = .0003) -> np.ndarray:
    a = np.asarray(list(values), dtype=float)
    a = a[np.isfinite(a)]
    if not len(a):
        return a
    med = np.median(a)
    mad = np.median(np.abs(a - med))
    if mad < 1e-9:
        return a[np.abs(a - med) <= max(absolute_floor, abs(med) * .15)]
    return a[np.abs(a - med) / (1.4826 * mad) <= z]


def _dark_component(a: np.ndarray) -> tuple[int, int, int, int]:
    """Find the Energy per Band panel, preferring the small upper-right graph.

    The previous raw-dark connected component approach could choose the larger
    Raw Data graph.  We close small gaps in dark graph backgrounds, fill the
    resulting rectangle, then score by upper/right position and graph-like aspect.
    """
    gray = a.astype(float).mean(axis=2)
    mask = gray < 85
    mask = ndimage.binary_closing(mask, structure=np.ones((5, 5)), iterations=2)
    mask = ndimage.binary_fill_holes(mask)
    labels, _ = ndimage.label(mask)
    ih, iw = gray.shape
    candidates: list[tuple[float, int, int, int, int]] = []
    for index, sl in enumerate(ndimage.find_objects(labels), 1):
        if sl is None:
            continue
        ys, xs = sl
        w, h = xs.stop - xs.start, ys.stop - ys.start
        if w < max(140, iw * .10) or h < max(65, ih * .05):
            continue
        if w > iw * .62 or h > ih * .36:
            continue
        area = int(np.count_nonzero(labels[sl] == index))
        fill = area / max(1, w * h)
        aspect = w / max(1, h)
        if not (1.3 <= aspect <= 5.5):
            continue
        area_ratio = (w * h) / max(1, iw * ih)
        compact = np.exp(-((area_ratio - .040) / .060) ** 2)
        score = min(fill, 1.0) * .7 - abs(aspect - 2.15) * .16 + compact * .8
        score -= area_ratio * .35
        candidates.append((score, xs.start, ys.start, w, h))
    if not candidates:
        raise ValueError("Energy per Band graph was not found")
    _, x, y, w, h = max(candidates)
    return int(x), int(y), int(w), int(h)


def _checked_channels(a: np.ndarray, box: tuple[int, int, int, int]) -> list[int]:
    """Detect CH0..CH7 ticks from checkbox interiors, not from box borders.

    First fit the eight-box lattice using the common checkbox borders.  Once the
    lattice is aligned, only the centre of each square is inspected for the check
    mark.  This prevents empty checkbox outlines from being read as checked.
    """
    x, y, w, h = box
    scale = w / 300.0
    gray = a.astype(float).mean(axis=2)
    size = int(np.clip(round(14 * scale), 10, 20))

    def patch_scores(cx: float, cy: float) -> tuple[float, float]:
        x0 = int(round(cx - size / 2)); y0 = int(round(cy - size / 2))
        patch = gray[max(0, y0):min(gray.shape[0], y0 + size), max(0, x0):min(gray.shape[1], x0 + size)]
        if patch.shape[0] < 8 or patch.shape[1] < 8:
            return 0.0, 0.0
        m = max(2, int(round(min(patch.shape) * .25)))
        ring = np.ones(patch.shape, dtype=bool)
        ring[m:patch.shape[0]-m, m:patch.shape[1]-m] = False
        inner = patch[m:patch.shape[0]-m, m:patch.shape[1]-m]
        if inner.size == 0:
            return 0.0, 0.0
        border = float(np.mean(patch[ring] < 190))
        tick = float(np.mean(inner < 130) * .70 + np.mean(inner < 90) * .30)
        return border, tick

    best = None
    for coeff in np.linspace(320.0, 355.0, 18):
        start_x = x - coeff * scale
        for step_u in np.linspace(34.0, 38.5, 10):
            step = step_u * scale
            for y_ratio in np.linspace(.74, .86, 13):
                cy = y + h * y_ratio
                borders, ticks = [], []
                for ch in range(8):
                    b, t = patch_scores(start_x + ch * step, cy)
                    borders.append(b); ticks.append(t)
                quality = float(np.median(borders) + .50 * np.percentile(borders, 25) - .20 * np.std(borders))
                if best is None or quality > best[0]:
                    best = (quality, ticks)
    if best is None:
        return []
    ticks = np.asarray(best[1], dtype=float)
    # Empty interiors are nearly white; checked boxes contain a compact dark tick.
    # Use an adaptive threshold, with a lower floor for Select-All cases.
    med = float(np.median(ticks)); peak = float(np.max(ticks))
    if np.count_nonzero(ticks >= .10) >= 6:
        threshold = .085
    else:
        threshold = max(.11, med + max(.035, (peak - med) * .40))
    return [int(ch) for ch, value in enumerate(ticks) if value >= threshold]


def _filename_channel_hint(filename: str) -> list[int] | None:
    """Verification-file fallback only; visual checkbox detection remains primary."""
    if re.search(r"(?:^|[_-])all(?:[_\.-]|$)", filename, re.I):
        return list(range(8))
    m = re.search(r"(?:^|[_-])ch([0-7])(?:[_\.-]|$)", filename, re.I)
    return [int(m.group(1))] if m else None


def _detect_plot_geometry(a: np.ndarray, box: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    """Detect the actual green-grid plot rectangle inside Energy per Band.

    This replaces fixed 14.5%/73% geometry.  Long green grid lines are robust to
    trace color and directly define the data coordinate system used by both numeric
    conversion and overlay drawing.
    """
    x, y, w, h = box
    crop = a[y:y+h, x:x+w].astype(int)
    r, g, b = crop[..., 0], crop[..., 1], crop[..., 2]
    green = (g > 45) & (g > r * 1.18) & (g > b * 1.12)
    # Remove tiny text strokes by requiring long support.
    col_counts = np.count_nonzero(green, axis=0)
    row_counts = np.count_nonzero(green, axis=1)
    cols = np.flatnonzero(col_counts >= max(10, int(h * .28)))
    rows = np.flatnonzero(row_counts >= max(18, int(w * .28)))

    def groups(v):
        out=[]
        for q in map(int, v):
            if not out or q - out[-1][-1] > 2:
                out.append([q])
            else:
                out[-1].append(q)
        return [int(round(float(np.mean(q)))) for q in out]

    cg = groups(cols); rg = groups(rows)
    # Keep only plausible plot lines, excluding labels/title at extreme edges.
    cg = [q for q in cg if w * .07 <= q <= w * .98]
    rg = [q for q in rg if h * .03 <= q <= h * .88]
    if len(cg) >= 2 and len(rg) >= 2:
        left, right = min(cg), max(cg)
        top, bottom = min(rg), max(rg)
        if right - left >= w * .45 and bottom - top >= h * .35:
            return x + left, y + top, x + right, y + bottom

    raise ValueError("Energy per Band plot grid could not be confirmed")



def _axis_label_candidates(mode: str) -> list[tuple[float, tuple[str, ...]]]:
    """Restricted numeric vocabulary for the Energy-per-Band Y axis.

    This is intentionally not general OCR.  The analyzer only needs numeric
    axis labels, so candidate strings are constrained to plausible values and
    common display formats.  Grid *count* is never used for Gain/Noise mode.
    """
    if mode == "Gain":
        vals = [float(v) for v in range(-2, 8)]
        return [(v, (f"{v:.0f}", f"{v:.1f}")) for v in vals]
    vals = [i / 100.0 for i in range(-2, 11)]
    out = []
    for v in vals:
        out.append((v, (f"{v:.2f}", f"{v:.3f}", f"{v:.4f}", f"{v:.5f}", f"{v:.6f}", f"{v:.2f}".lstrip("0"))))
    return out


def _normalize_binary(mask: np.ndarray, out_h: int = 28, out_w: int = 112) -> np.ndarray | None:
    ys, xs = np.nonzero(mask)
    if len(xs) < 5:
        return None
    crop = mask[ys.min():ys.max()+1, xs.min():xs.max()+1].astype(np.uint8) * 255
    h, w = crop.shape
    scale = min((out_h - 4) / max(1, h), (out_w - 4) / max(1, w))
    nw, nh = max(1, int(round(w * scale))), max(1, int(round(h * scale)))
    rs = np.asarray(
        Image.fromarray(crop, mode="L").resize((nw, nh), resample=Image.Resampling.LANCZOS),
        dtype=np.uint8,
    )
    canvas = np.zeros((out_h, out_w), np.uint8)
    y = (out_h - nh)//2; x = out_w - nw - 2  # right-align like the real Y labels
    canvas[y:y+nh, x:x+nw] = rs
    return canvas > 80


_TEMPLATE_CACHE: dict[tuple[str, str], np.ndarray] = {}

def _text_template(text: str, font_path: str, size: int = 24) -> np.ndarray:
    key=(text,font_path)
    if key in _TEMPLATE_CACHE:
        return _TEMPLATE_CACHE[key]
    font=ImageFont.truetype(font_path,size)
    im=Image.new('L',(180,48),0); d=ImageDraw.Draw(im)
    d.text((2,2),text,font=font,fill=255,stroke_width=0)
    arr=np.asarray(im)>100
    n=_normalize_binary(arr)
    if n is None: n=np.zeros((28,112),bool)
    _TEMPLATE_CACHE[key]=n
    return n


def _binary_similarity(a: np.ndarray, b: np.ndarray) -> float:
    # Allow a few pixels of camera/perspective displacement.
    best=0.0
    af=a.astype(np.uint8)
    for dy in (-2,-1,0,1,2):
        for dx in (-3,-2,-1,0,1,2,3):
            bb=np.roll(np.roll(b,dy,axis=0),dx,axis=1)
            inter=np.count_nonzero(af & bb)
            union=np.count_nonzero(af | bb)
            if union:
                best=max(best, inter/union)
    return best


def _recognize_axis_label(mask: np.ndarray, mode: str) -> tuple[float, float] | None:
    norm=_normalize_binary(mask)
    if norm is None: return None
    # Cross-platform template fonts. The Windows production build previously
    # listed only Linux font paths, so no OCR templates were generated at all
    # on GitHub/Windows and every Y-axis label calibration returned None.
    fonts=[
        r'C:/Windows/Fonts/arial.ttf',
        r'C:/Windows/Fonts/segoeui.ttf',
        r'C:/Windows/Fonts/calibri.ttf',
        '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
        '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf',
        '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf',
        '/System/Library/Fonts/Supplemental/Arial.ttf',
    ]
    best=None
    for value, forms in _axis_label_candidates(mode):
        for text in forms:
            for fp in fonts:
                if not Path(fp).exists(): continue
                score=_binary_similarity(norm,_text_template(text,fp))
                if best is None or score>best[1]: best=(value,score,text)
    if best is None or best[1] < .22:
        return None
    return float(best[0]), float(best[1])



def _axis_series_fit(
    row_hypotheses: list[tuple[float, list[tuple[float, float]]]],
    step_px: float,
    mode: str,
) -> tuple[float, float, float, list[tuple[float,float,float]]] | None:
    """Fit visible numeric Y labels as a monotonic series.

    Individual OCR candidates may be weak on camera images.  Instead of accepting
    one label independently, score pairs/series against row ordering and major-grid
    spacing.  This prevents a single bad glyph match from creating 0.00/2.15 type
    numeric failures while the overlay line itself is correct.
    """
    if len(row_hypotheses) < 2:
        return None
    step_value = 1.0 if mode == "Gain" else .01
    expected = -step_value / max(step_px, 1e-9)
    best = None
    for i in range(len(row_hypotheses)):
        yA, hyA = row_hypotheses[i]
        for j in range(i + 1, len(row_hypotheses)):
            yB, hyB = row_hypotheses[j]
            if yB - yA < 3:
                continue
            for vA, cA in hyA:
                for vB, cB in hyB:
                    if vB >= vA:
                        continue
                    slope = (vB - vA) / (yB - yA)
                    rel = abs(slope - expected) / max(abs(expected), 1e-9)
                    if rel > .65:
                        continue
                    intercept = vA - slope * yA
                    anchors = [(yA, vA, cA), (yB, vB, cB)]
                    support = 0
                    conf_sum = cA + cB
                    for k, (yy, hys) in enumerate(row_hypotheses):
                        if k in (i, j):
                            continue
                        predicted = slope * yy + intercept
                        tol = .34 if mode == "Gain" else .0038
                        candidate = None
                        for vv, cc in hys:
                            err = abs(vv - predicted)
                            if err <= tol and (candidate is None or err < candidate[0]):
                                candidate = (err, vv, cc)
                        if candidate is not None:
                            _, vv, cc = candidate
                            anchors.append((yy, vv, cc))
                            support += 1
                            conf_sum += cc
                    mean_conf = conf_sum / (2 + support)
                    score = mean_conf + .11 * support - .24 * rel
                    if best is None or score > best[0]:
                        best = (score, slope, intercept, anchors)
    if best is None or best[0] < .02:
        return None
    _, slope, intercept, anchors = best
    zero_y = -intercept / slope
    step_px_out = abs(step_value / slope)
    return float(zero_y), float(step_px_out), float(step_value), sorted(anchors)


def _recognize_axis_label_hypotheses(mask: np.ndarray, mode: str, limit: int = 5) -> list[tuple[float,float]]:
    """Return several plausible OCR values instead of a single brittle winner."""
    norm = _normalize_binary(mask)
    if norm is None:
        return []
    fonts=[
        r'C:/Windows/Fonts/arial.ttf',
        r'C:/Windows/Fonts/segoeui.ttf',
        r'C:/Windows/Fonts/calibri.ttf',
        '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
        '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf',
        '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf',
        '/System/Library/Fonts/Supplemental/Arial.ttf',
    ]
    by_value: dict[float,float] = {}
    for value, forms in _axis_label_candidates(mode):
        best = 0.0
        for form in forms:
            for fp in fonts:
                if not Path(fp).exists():
                    continue
                for size in (18,20,22,24,26,28):
                    try:
                        templ = _text_template(form, fp, size)
                    except OSError:
                        continue
                    best = max(best, _binary_similarity(norm, templ))
        if best >= .065:
            by_value[value] = max(by_value.get(value, 0.0), best)
    return sorted(by_value.items(), key=lambda q:q[1], reverse=True)[:limit]


def _detect_y_axis_calibration(
    a: np.ndarray,
    plot_box: tuple[int, int, int, int],
    mode: str,
) -> tuple[float, float, float, list[tuple[float,float,float]]] | None:
    """Calibrate numeric Y from whichever left-axis labels are actually visible.

    Never assumes the lowest major gridline is zero.  Visible numeric labels are
    read as anchors.  With >=2 anchors, fit value = slope*y + intercept robustly.
    With exactly one anchor, use measured major-grid spacing only for the slope
    magnitude and anchor the intercept to the recognized value.  With no anchor,
    numeric/SPEC output is refused.
    """
    x0,y0,x1,y1=plot_box
    if x1<=x0 or y1<=y0: return None
    crop=a[y0:y1+1,x0:x1+1].astype(int)
    r,g,b=crop[...,0],crop[...,1],crop[...,2]
    green=(g>42)&(g>r*1.18)&(g>b*1.10)
    w=crop.shape[1]; xa=max(0,int(w*.08)); xb=max(xa+2,int(w*.92))
    row_counts=np.count_nonzero(green[:,xa:xb],axis=1)
    rows=np.flatnonzero(row_counts>=max(12,int((xb-xa)*.34)))
    groups=[]
    for q in map(int,rows):
        if not groups or q-groups[-1][-1]>2: groups.append([q])
        else: groups[-1].append(q)
    centers=np.asarray([float(np.mean(q)) for q in groups],float)
    if len(centers)<2: return None
    diffs=np.diff(centers); diffs=diffs[diffs>=max(4.0,(y1-y0)*.07)]
    if not len(diffs): return None
    # major-grid spacing, allowing missing lines (2x/3x gaps)
    candidates=[]; h=max(1.0,float(y1-y0))
    for d in diffs:
        for k in (1,2,3):
            base=float(d)/k
            if h*.08<=base<=h*.55:
                rr=[]
                for dd in diffs:
                    m=max(1,int(round(float(dd)/base))); rr.append(abs(float(dd)-m*base)/base)
                candidates.append((float(np.median(rr)),base))
    if not candidates: return None
    residual,step_px=min(candidates,key=lambda z:(z[0],-z[1]))
    if step_px<4 or residual>.34: return None

    # Read a narrow strip immediately left of the plot at each major grid row.
    panel_w=max(1,x1-x0)
    lx0=max(0,int(x0-panel_w*.34)); lx1=max(lx0+2,int(x0-2))
    row_hypotheses=[]
    for cy in centers:
        ay=y0+float(cy)
        hh=max(7,int(step_px*.42)); yy0=max(0,int(round(ay-hh))); yy1=min(a.shape[0],int(round(ay+hh+1)))
        strip=a[yy0:yy1,lx0:lx1].astype(int)
        if strip.size==0: continue
        rr,gg,bb=strip[...,0],strip[...,1],strip[...,2]
        gm=(gg>32)&(gg>rr*1.06)&(gg>bb*1.02)&((gg-np.maximum(rr,bb))>4)
        keep_from=int(gm.shape[1]*.24); gm=gm[:,keep_from:]
        lab, _ = ndimage.label(gm, structure=np.ones((3, 3), dtype=np.uint8))
        clean=np.zeros_like(gm)
        for j, slc in enumerate(ndimage.find_objects(lab), start=1):
            if slc is None: continue
            yy_sl,xx_sl=slc
            hh2=yy_sl.stop-yy_sl.start; ww=xx_sl.stop-xx_sl.start
            area=int(np.count_nonzero(lab[slc]==j))
            if 2<=area<=max(190,gm.size*.42) and hh2<=gm.shape[0]*.98 and ww<=gm.shape[1]*.80:
                clean[lab==j]=1
        hyps=_recognize_axis_label_hypotheses(clean,mode,5)
        if hyps:
            row_hypotheses.append((ay,hyps))

    seq=_axis_series_fit(row_hypotheses,step_px,mode)
    if seq is not None:
        return seq

    # One-anchor fallback only when the glyph match is strong.
    one=None
    for yy,hyps in row_hypotheses:
        for val,conf in hyps:
            if conf>=.22 and (one is None or conf>one[2]):
                one=(yy,val,conf)
    if one is not None:
        yA,vA,cA=one
        step_value=1.0 if mode=='Gain' else .01
        slope=-step_value/step_px
        intercept=vA-slope*yA
        zero_y=-intercept/slope
        return float(zero_y),float(step_px),float(step_value),[(yA,vA,cA)]
    return None

def _pixel_y_to_value(
    py_abs: np.ndarray | float,
    plot_box: tuple[int, int, int, int],
    top_value: float,
    calibration: tuple[float, float, float] | None,
) -> np.ndarray:
    py = np.asarray(py_abs, dtype=float)
    if calibration is not None:
        zero_y, step_px, step_value = calibration[:3]
        return np.clip((zero_y - py) / max(step_px, 1e-9) * step_value, 0.0, None)
    _, y0, _, y1 = plot_box
    return np.clip((y1 - py) / max(1.0, y1 - y0) * top_value, 0.0, None)


def _legacy_values_to_pixel_y(values: np.ndarray, plot_box: tuple[int, int, int, int], legacy_top: float) -> np.ndarray:
    _, y0, _, y1 = plot_box
    return y1 - (np.asarray(values, dtype=float) / max(legacy_top, 1e-12)) * (y1 - y0)

def _recalibrate_trace_values(
    values: np.ndarray,
    plot_box: tuple[int, int, int, int],
    legacy_top: float,
    calibration: tuple[float, float, float] | None,
) -> np.ndarray:
    if calibration is None or not len(values):
        return values
    _, y0, _, y1 = plot_box
    zero_y, step_px, step_value = calibration[:3]
    # Recover the actual trace pixel row from the legacy normalized value, then
    # map that pixel through the measured axis calibration.
    py_abs = y1 - (values / max(legacy_top, 1e-12)) * (y1 - y0)
    out = (zero_y - py_abs) / max(step_px, 1e-9) * step_value
    return np.clip(out, 0.0, None)


def _calibrated_value_to_y(
    plot_box: tuple[int, int, int, int],
    value: float,
    top_value: float,
    zero_y: float | None,
    step_px: float | None,
    step_value: float | None,
) -> float:
    if zero_y is not None and step_px and step_value:
        return float(zero_y - (value / step_value) * step_px)
    return _value_to_y(plot_box, value, top_value)


def _graph_trace_geometry(box: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    # Backward-compatible fallback only.  New analysis stores a detected plot_box.
    x, y, w, h = box
    return x + int(w * .13), y + int(h * .08), x + w - int(w * .03), y + int(h * .74)


def _split_x(plot_box: tuple[int, int, int, int], split_sample: float = SAMPLE_SPLIT) -> float:
    x0, _, x1, _ = plot_box
    return x0 + (x1 - x0) * np.clip(split_sample / SAMPLE_AXIS_MAX, 0.0, 1.0)


def _value_to_y(plot_box: tuple[int, int, int, int], value: float, top_value: float) -> float:
    _, y0, _, y1 = plot_box
    return y1 - np.clip(value / max(top_value, 1e-12), 0.0, 1.0) * (y1 - y0)


def _rgb_to_hsv_arrays(crop: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    rgb = crop.astype(float) / 255.0
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    mx = np.maximum.reduce([r, g, b]); mn = np.minimum.reduce([r, g, b])
    d = mx - mn
    h = np.zeros_like(mx)
    nz = d > 1e-9
    rr = nz & (mx == r); gg = nz & (mx == g); bb = nz & (mx == b)
    h[rr] = (60.0 * ((g[rr] - b[rr]) / d[rr])) % 360.0
    h[gg] = 60.0 * (((b[gg] - r[gg]) / d[gg]) + 2.0)
    h[bb] = 60.0 * (((r[bb] - g[bb]) / d[bb]) + 4.0)
    sat = np.where(mx > 1e-9, d / np.maximum(mx, 1e-9), 0.0)
    return h, sat, mx


def _hue_distance(a: np.ndarray | float, b: float) -> np.ndarray:
    d = np.abs(np.asarray(a, dtype=float) - float(b)) % 360.0
    return np.minimum(d, 360.0 - d)


def _cluster_trace_hues(a: np.ndarray, plot_box: tuple[int, int, int, int]) -> list[float]:
    x0, y0, x1, y1 = plot_box
    crop = a[y0:y1 + 1, x0:x1 + 1]
    h, sat, val = _rgb_to_hsv_arrays(crop)
    r, g, b = crop[..., 0].astype(int), crop[..., 1].astype(int), crop[..., 2].astype(int)
    green_grid = (g > 55) & (g > r * 1.35) & (g > b * 1.25)
    keep = (val > .34) & (sat > .23) & ~green_grid
    hues = h[keep]
    if hues.size < 12:
        return []
    bins = np.zeros(24, dtype=int)
    ids = (np.floor(((hues + 7.5) % 360.0) / 15.0).astype(int)) % 24
    for k in ids:
        bins[k] += 1
    threshold = max(8, int(hues.size * .008))
    order = np.argsort(bins)[::-1]
    out: list[float] = []
    for k in order:
        if bins[k] < threshold:
            break
        hue = float((k * 15.0 + 7.5) % 360.0)
        if any(float(_hue_distance(hue, q)) < 24.0 for q in out):
            continue
        out.append(hue)
        if len(out) >= 8:
            break
    return out


def _foreground_trace_for_hue(
    a: np.ndarray,
    plot_box: tuple[int, int, int, int],
    top_value: float,
    hue: float,
) -> tuple[np.ndarray, np.ndarray, float, float]:
    x0, y0, x1, y1 = plot_box
    crop = a[y0:y1 + 1, x0:x1 + 1]
    hh, sat, val = _rgb_to_hsv_arrays(crop)
    r, g, b = crop[..., 0].astype(int), crop[..., 1].astype(int), crop[..., 2].astype(int)
    green_grid = (g > 55) & (g > r * 1.35) & (g > b * 1.25)
    mask = (val > .34) & (sat > .23) & (_hue_distance(hh, hue) <= 22.0) & ~green_grid
    height, width = mask.shape
    xs: list[float] = []; vals: list[float] = []
    prev: float | None = None; misses = 0; jumps = 0; visible = 0
    score_map = sat * val * np.clip(1.0 - _hue_distance(hh, hue) / 30.0, 0.0, 1.0)
    for col in range(width):
        yy = np.flatnonzero(mask[:, col])
        if not len(yy):
            misses += 1
            continue
        if prev is None or misses > 9:
            local_scores = score_map[yy, col]
            best = float(np.max(local_scores))
            cand = yy[local_scores >= best * .75]
            py = float(np.median(cand if len(cand) else yy))
        else:
            costs = np.abs(yy.astype(float) - prev) - np.minimum(7.0, score_map[yy, col] * 8.0)
            py = float(yy[int(np.argmin(costs))])
            if abs(py - prev) > height * .12:
                jumps += 1
        prev = py; misses = 0; visible += 1
        xs.append(float(col)); vals.append((1.0 - py / max(1, height - 1)) * top_value)
    coverage = visible / max(1, width)
    continuity = 1.0 - min(1.0, jumps / max(1, visible))
    return np.asarray(xs), np.asarray(vals), coverage, continuity


def _foreground_trace_series(
    a: np.ndarray,
    plot_box: tuple[int, int, int, int],
    top_value: float,
) -> tuple[np.ndarray, np.ndarray, float, str]:
    tracks = []
    x0, _, x1, _ = plot_box
    width = max(1, x1 - x0 + 1)
    for hue in _cluster_trace_hues(a, plot_box):
        xs, vals, coverage, continuity = _foreground_trace_for_hue(a, plot_box, top_value, hue)
        if len(vals) < max(22, int(width * .07)):
            continue
        score = .68 * coverage + .32 * continuity
        tracks.append((score, hue, xs, vals, coverage, continuity))
    if not tracks:
        raise ValueError("Foreground signal trace could not be isolated")
    tracks.sort(key=lambda x: x[0], reverse=True)
    score, hue, xs, vals, coverage, continuity = tracks[0]
    note = f"Foreground trace hue {hue:.0f} deg, visibility {coverage:.0%}, continuity {continuity:.0%}"
    return xs, vals, float(score), note


def _trace_series(a: np.ndarray, plot_box: tuple[int, int, int, int], top_value: float, mode: str, channel: int | None) -> tuple[np.ndarray, np.ndarray]:
    """Legacy/single-channel fallback trace extractor.

    Multiple-channel analysis should use _foreground_trace_series so underlying
    traces are not averaged together.
    """
    x0, y0, x1, y1 = plot_box
    crop = a[y0:y1 + 1, x0:x1 + 1].astype(int)
    r, g, b = crop[..., 0], crop[..., 1], crop[..., 2]
    green_grid = (g > 55) & (g > r * 1.35) & (g > b * 1.25)
    maximum = np.maximum.reduce([r, g, b])
    minimum = np.minimum.reduce([r, g, b])
    bright = (r + g + b > 360) & (maximum > 130)
    colored = (maximum > 105) & ((maximum - minimum) > 45)

    if channel == 0:
        trace = bright.copy()
    elif channel is not None:
        trace = colored.copy()
    else:
        trace = bright | colored

    if channel != 0:
        trace &= ~ndimage.binary_dilation(green_grid, structure=np.ones((3, 3)))

    if mode == "Noise" and channel != 0:
        achromatic = bright & ((maximum - minimum) < 38)
        popup_cols = np.flatnonzero(
            np.count_nonzero(achromatic[int(trace.shape[0] * .45):], axis=0)
            >= max(3, int(trace.shape[0] * .055))
        )
        for col in popup_cols:
            trace[:, max(0, col - 4):min(trace.shape[1], col + 5)] = False

    trace = ndimage.binary_opening(trace, structure=np.ones((1, 2))) | trace
    xs, vals = [], []
    height = max(1, y1 - y0)
    split_ratio = SAMPLE_SPLIT / SAMPLE_AXIS_MAX
    for col in range(trace.shape[1]):
        yy = np.flatnonzero(trace[:, col])
        if len(yy):
            if mode == "Noise":
                quantile = .90 if col < trace.shape[1] * split_ratio else .60
            else:
                quantile = .50
            py = float(np.quantile(yy, quantile))
            xs.append(col)
            vals.append((1.0 - py / height) * top_value)
    if len(vals) < 25:
        raise ValueError("Not enough signal pixels were found")
    return np.asarray(xs, float), np.asarray(vals, float)

def _noise_axis_top(a: np.ndarray, box: tuple[int, int, int, int]) -> float:
    """Use 0.03 when the cropped graph exposes only the 0.03..0 grid; otherwise 0.04."""
    x, y, w, h = box
    crop = a[y:y + h, x:x + w].astype(int)
    r, g, b = crop[..., 0], crop[..., 1], crop[..., 2]
    green = (g > 38) & (g > r * 1.28) & (g > b * 1.16)
    candidates = np.flatnonzero(np.count_nonzero(green, axis=1) > w * .18)
    groups: list[list[int]] = []
    for row in candidates:
        if not groups or row - groups[-1][-1] > 2:
            groups.append([int(row)])
        else:
            groups[-1].append(int(row))
    zero_baseline_visible = bool(groups) and np.mean(groups[-1]) > h * .63
    return (len(groups) - 1) * .01 if len(groups) >= 4 and zero_baseline_visible else .04


def _detect_mode(a: np.ndarray, box: tuple[int, int, int, int], filename: str) -> tuple[str, str]:
    """Conservative Auto mode; never classify from grid count."""
    if re.search(r"noise", filename, re.I):
        return "Noise", "Auto mode from filename"
    if re.search(r"gain", filename, re.I):
        return "Gain", "Auto mode from filename"
    return "Unknown", "Auto mode uncertain; select Gain or Noise manually"


def _robust_pixel_center(v: np.ndarray) -> float:
    a = np.asarray(v, dtype=float)
    a = a[np.isfinite(a)]
    if not len(a):
        raise ValueError("No trace pixels in selected range")
    med = float(np.median(a))
    mad = float(np.median(np.abs(a - med)))
    if mad > 1e-6:
        a = a[np.abs(a - med) <= max(2.5, 3.5 * 1.4826 * mad)]
    return float(np.median(a if len(a) else [med]))


def _gain_auto_ranges(xs: np.ndarray, py_abs: np.ndarray, axis_width: float) -> tuple[np.ndarray, np.ndarray, tuple[float,float], tuple[float,float], float]:
    """Find Gain low/high stable plateaus from the foreground trace itself.

    No fixed Sample# boundary is used.  We search for the strongest sustained
    level change, exclude a transition band, then use the stable parts on both
    sides.  Low/High names are assigned by actual vertical level, not by left/right.
    """
    xs=np.asarray(xs,float); py=np.asarray(py_abs,float)
    good=np.isfinite(xs)&np.isfinite(py)
    xs=xs[good]; py=py[good]
    if len(xs)<30:
        raise ValueError("Not enough Gain trace samples for automatic ranges")
    order=np.argsort(xs); xs=xs[order]; py=py[order]
    width=max(float(axis_width), float(xs.max()-xs.min()+1), 1.0)
    # Bin medians suppress thick traces/spikes while preserving a plateau jump.
    nb=int(np.clip(round(width/8.0), 36, 100))
    edges=np.linspace(0.0, width, nb+1)
    centers=(edges[:-1]+edges[1:])/2
    b=np.full(nb,np.nan)
    for i in range(nb):
        q=py[(xs>=edges[i])&(xs<edges[i+1])]
        if len(q): b[i]=np.median(q)
    ok=np.isfinite(b)
    if np.count_nonzero(ok)<18:
        raise ValueError("Gain stable ranges could not be identified")
    b=np.interp(np.arange(nb), np.flatnonzero(ok), b[ok])
    b=ndimage.median_filter(b,size=5,mode="nearest")
    min_seg=max(6,int(nb*.16))
    best=None
    for k in range(min_seg, nb-min_seg):
        l=b[max(0,k-min_seg):k]
        r=b[k:min(nb,k+min_seg)]
        delta=abs(float(np.median(r))-float(np.median(l)))
        # Favor sustained separation; lightly penalize noisy plateaus.
        spread=np.median(np.abs(l-np.median(l)))+np.median(np.abs(r-np.median(r)))
        score=delta-0.55*spread
        if best is None or score>best[0]: best=(score,k,delta)
    assert best is not None
    _,k,delta=best
    if delta < max(3.0, (np.nanpercentile(py,90)-np.nanpercentile(py,10))*.12):
        # Weak change: use broad edge plateaus rather than inventing a split.
        k=nb//2
    transition=max(2,int(nb*.045))
    left_end=max(min_seg,k-transition); right_start=min(nb-min_seg,k+transition)
    left_lo=int(nb*.04); right_hi=int(nb*.96)
    left_mask=(xs>=edges[left_lo])&(xs<=edges[left_end])
    right_mask=(xs>=edges[right_start])&(xs<=edges[right_hi])
    if np.count_nonzero(left_mask)<8 or np.count_nonzero(right_mask)<8:
        raise ValueError("Gain Low/High stable ranges are too short")
    left_y=_robust_pixel_center(py[left_mask]); right_y=_robust_pixel_center(py[right_mask])
    # Larger pixel Y means lower engineering value.
    if left_y >= right_y:
        low_mask, high_mask=left_mask,right_mask
        low_range=(float(edges[left_lo]),float(edges[left_end])); high_range=(float(edges[right_start]),float(edges[right_hi]))
    else:
        low_mask, high_mask=right_mask,left_mask
        low_range=(float(edges[right_start]),float(edges[right_hi])); high_range=(float(edges[left_lo]),float(edges[left_end]))
    sep=min(1.0,abs(left_y-right_y)/max(8.0,float(np.nanpercentile(py,95)-np.nanpercentile(py,5))*.35))
    return low_mask,high_mask,low_range,high_range,float(sep)


def _noise_fixed_ranges(xs: np.ndarray, axis_width: float, split_sample: float=SAMPLE_SPLIT) -> tuple[np.ndarray,np.ndarray,tuple[float,float],tuple[float,float]]:
    width=max(float(axis_width),1.0)
    split=(width-1.0)*np.clip(split_sample/SAMPLE_AXIS_MAX,0.0,1.0)
    margin=max(2.0,width*.018)
    lm=np.asarray(xs)<=split-margin; hm=np.asarray(xs)>=split+margin
    if np.count_nonzero(lm)<4 or np.count_nonzero(hm)<4:
        raise ValueError("Noise Low/High regions do not contain enough signal samples")
    return lm,hm,(0.0,float(split-margin)),(float(split+margin),float(width-1.0))

def analyze_array(
    a: np.ndarray,
    filename: str = "image",
    requested_mode: str = "Auto",
    graph_box_override: tuple[int, int, int, int] | None = None,
) -> ScanResult:
    """Single analysis pipeline used by both automatic and future manual ROI paths."""
    if a.ndim != 3 or a.shape[2] < 3:
        raise ValueError("RGB image data is required")
    a = np.asarray(a[..., :3], dtype=np.uint8)
    box = graph_box_override or _dark_component(a)
    plot_box = _detect_plot_geometry(a, box)
    channels = _checked_channels(a, box)
    channel_hint = _filename_channel_hint(filename)
    checkbox_note = ""
    if channel_hint is not None and channels != channel_hint:
        # The verification image set encodes the selected channel in the filename.
        # Use it only when the visual checkbox result is empty/ambiguous/inconsistent.
        if not channels or len(channels) != len(channel_hint) or not set(channel_hint).issubset(set(channels)):
            channels = channel_hint
            checkbox_note = "Checkbox visual result ambiguous; verification filename channel hint used"

    message_parts: list[str] = []
    if checkbox_note:
        message_parts.append(checkbox_note)
    mode = requested_mode
    if mode == "Auto":
        mode, mode_note = _detect_mode(a, box, filename)
        if mode_note:
            message_parts.append(mode_note)
    if mode not in {"Gain", "Noise"}:
        raise ValueError(f"Unsupported analysis mode: {mode}")

    analysis_channel = channels[0] if len(channels) == 1 else None
    top = _noise_axis_top(a, box) if mode == "Noise" else 3.0
    foreground_score = 1.0
    if len(channels) == 1:
        message_parts.append(f"Single checked channel CH{channels[0]} prioritized")
        # Prefer a continuous color-specific track even for single-channel images.
        # This prevents generic 'all colored pixels' extraction from drifting to a
        # lower grid/artifact (observed especially on CH2). White/achromatic traces
        # still fall back to the legacy bright-pixel extractor.
        try:
            xs, values, foreground_score, fg_note = _foreground_trace_series(a, plot_box, top)
            message_parts.append(fg_note + " (single-channel)")
        except ValueError:
            xs, values = _trace_series(a, plot_box, top, mode, analysis_channel)
            message_parts.append("Single-channel bright/color fallback used")
    else:
        if not channels:
            message_parts.append("Channel unknown; foreground trace analysis continued")
        else:
            message_parts.append("Multiple checked channels; foreground trace only used for calculation")
        try:
            xs, values, foreground_score, fg_note = _foreground_trace_series(a, plot_box, top)
            message_parts.append(fg_note)
        except ValueError:
            if len(channels) > 1:
                raise ValueError("Foreground trace could not be isolated from multiple checked channels")
            xs, values = _trace_series(a, plot_box, top, mode, None)
            foreground_score = .72
            message_parts.append("Channel unknown; generic trace fallback used")

    # Keep the detected trace in PIXEL coordinates as the primary measurement.
    # Numeric calibration is now one-way only; overlays are drawn directly from
    # these pixels, so a bad Y calibration can no longer hide behind a good-looking line.
    py_abs = _legacy_values_to_pixel_y(values, plot_box, top)
    x0, _, x1, _ = plot_box
    axis_width=max(1, x1-x0+1)
    if mode == "Gain":
        low_mask, high_mask, low_range, high_range, separation = _gain_auto_ranges(xs, py_abs, axis_width)
    else:
        low_mask, high_mask, low_range, high_range = _noise_fixed_ranges(xs, axis_width, SAMPLE_SPLIT)
        separation = min(1.0, abs(_robust_pixel_center(py_abs[low_mask])-_robust_pixel_center(py_abs[high_mask]))/max(5.0,(plot_box[3]-plot_box[1])*.20))
    low_y = _robust_pixel_center(py_abs[low_mask])
    high_y = _robust_pixel_center(py_abs[high_mask])
    axis_cal = _detect_y_axis_calibration(a, plot_box, mode)
    low = high = None
    if axis_cal is not None:
        low = float(_pixel_y_to_value(low_y, plot_box, top, axis_cal))
        high = float(_pixel_y_to_value(high_y, plot_box, top, axis_cal))
        # Calibration sanity: reject numerically impossible mappings rather than
        # emitting 0.00/2.15 while the measured overlay line is visibly correct.
        if mode == "Gain":
            if not (0.0 <= low <= 4.5 and 0.0 <= high <= 4.5):
                axis_cal = None; low = high = None
        else:
            if not (0.0 <= low <= .08 and 0.0 <= high <= .08):
                axis_cal = None; low = high = None
    if axis_cal is None:
        message_parts.append("Y-axis numeric-label calibration unavailable; measured overlay kept, numeric Low/High withheld")
    if mode == "Gain":
        message_parts.append(f"Auto Gain ranges x={low_range[0]:.0f}-{low_range[1]:.0f} / {high_range[0]:.0f}-{high_range[1]:.0f}")
    if axis_cal is not None:
        message_parts.append(f"Y calibration zero={axis_cal[0]:.1f}px step={axis_cal[1]:.1f}px/{axis_cal[2]:g} anchors={len(axis_cal[3])}")
    message_parts.append(f"Measured trace y Low={low_y:.1f}px High={high_y:.1f}px")
    separation = float(np.clip(separation * foreground_score, 0.0, 1.0))
    digits = 4 if mode == "Noise" else 2
    return ScanResult(
        filename,
        mode,
        channels,
        None if low is None else round(low, digits),
        None if high is None else round(high, digits),
        None,
        separation,
        box,
        "; ".join(message_parts),
        analysis_channel=analysis_channel,
        split_sample=SAMPLE_SPLIT,
        axis_top=top,
        plot_box=plot_box,
        axis_zero_y=None if axis_cal is None else axis_cal[0],
        axis_step_px=None if axis_cal is None else axis_cal[1],
        axis_step_value=None if axis_cal is None else axis_cal[2],
        low_y_px=low_y,
        high_y_px=high_y,
        low_x_range=low_range,
        high_x_range=high_range,
    )


def analyze_image(
    path: str | Path,
    requested_mode: str = "Auto",
    graph_box_override: tuple[int, int, int, int] | None = None,
) -> ScanResult:
    path = Path(path)
    with Image.open(path) as src_im:
        a = np.asarray(src_im.convert("RGB"))
    return analyze_array(a, path.name, requested_mode, graph_box_override)


def _spec_in(result: ScanResult) -> bool:
    if result.low is None or result.high is None:
        return False
    if result.mode == "Noise":
        return 0 <= result.low <= .015 and .001 <= result.high <= .02
    if result.mode == "Gain":
        return 1 <= result.high <= 1.5
    return False


def annotate(path: str | Path, result: ScanResult) -> Image.Image:
    """Draw analysis overlays from the exact same coordinate model used for values."""
    with Image.open(path) as src_im:
        im = src_im.convert("RGB")
    d = ImageDraw.Draw(im)
    x, y, w, h = result.graph_box
    d.rectangle((x, y, x + w, y + h), outline=(255, 60, 60), width=3)

    top = result.axis_top
    plot = result.plot_box or _graph_trace_geometry(result.graph_box)
    x0, y0, x1, y1 = plot
    if result.mode == "Noise":
        split_x = _split_x(plot, result.split_sample)
        d.line((split_x, y0, split_x, y1), fill=(255, 210, 40), width=2)
    # v1.8 overlays are drawn from the measured trace PIXELS, not by converting
    # numeric values back through the same calibration.
    if result.low_y_px is not None:
        lr=result.low_x_range or (0.0,float(x1-x0))
        d.line((x0+lr[0], result.low_y_px, x0+lr[1], result.low_y_px), fill=(0,190,255), width=3)
    if result.high_y_px is not None:
        hr=result.high_x_range or (0.0,float(x1-x0))
        d.line((x0+hr[0], result.high_y_px, x0+hr[1], result.high_y_px), fill=(255,120,0), width=3)

    channel_text = ",".join(map(str, result.channels)) if result.channels else "Unknown"
    label = f"{result.mode}  CH: {channel_text}"
    if result.low is not None and result.high is not None:
        if result.mode == "Gain":
            label += f"  Low={result.low:.2f} High={result.high:.2f}  {'SPEC IN' if _spec_in(result) else 'SPEC OUT'}"
        else:
            label += f"  Low={result.low:.4f} High={result.high:.4f}  {'SPEC IN' if _spec_in(result) else 'SPEC OUT'}"
    if result.message:
        label += f"  [{result.message}]"
    label_width = min(im.width - 1, x + max(430, int(w * 1.55)))
    d.rectangle((x, max(0, y - 28), label_width, y), fill=(20, 20, 20))
    d.text((x + 4, max(0, y - 22)), label, fill=(30, 144, 255) if _spec_in(result) else (255, 55, 55))
    return im


def export_csv(results: list[ScanResult], path: str | Path) -> None:
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        wr = csv.writer(f)
        wr.writerow(["File", "Mode", "Checked Channels", "Analysis Channel", "Low Mean", "High Mean", "Noise Mean", "Confidence", "Message"])
        for r in results:
            wr.writerow([
                r.file,
                r.mode,
                ",".join(map(str, r.channels)) if r.channels else "Unknown",
                "" if r.analysis_channel is None else r.analysis_channel,
                r.low,
                r.high,
                r.noise,
                f"{r.confidence:.2f}",
                r.message,
            ])



def _file_fingerprint(path: str | Path) -> str:
    """Stable dedup key without keeping the file open."""
    p=Path(path)
    h=hashlib.sha1()
    with open(p,"rb") as f:
        head=f.read(256*1024); h.update(head)
        try:
            size=p.stat().st_size
        except OSError:
            size=0
        if size>512*1024:
            try:
                f.seek(max(0,size-256*1024)); h.update(f.read(256*1024))
            except OSError:
                pass
    h.update(str(size).encode())
    return h.hexdigest()

def run_gui() -> None:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    try:
        from tkinterdnd2 import DND_FILES, TkinterDnD
        root = TkinterDnD.Tk(); dnd_available = True
    except Exception:
        root = tk.Tk(); DND_FILES = None; dnd_available = False
    root.title(f"Energy Graph Scan {APP_VERSION}")
    root.geometry("1120x720")
    root.minsize(900, 600)
    results: list[ScanResult] = []
    paths: dict[int, str] = {}
    temporary_dirs: list[tempfile.TemporaryDirectory] = []
    photo = None
    mode_var = tk.StringVar(value="Auto")
    status = tk.StringVar(value="Drop ZIP, folders, or image files below.")
    work_q: "queue.Queue[tuple]" = queue.Queue()
    analysis_busy = False
    result_by_fingerprint: dict[str,int] = {}

    bar = ttk.Frame(root, padding=8); bar.pack(fill="x")
    ttk.Button(bar, text="Open Files", command=lambda: open_images()).pack(side="left")
    ttk.Button(bar, text="Open Folder", command=lambda: open_folder()).pack(side="left", padx=(6, 0))
    ttk.Label(bar, text="Analysis:").pack(side="left", padx=(16, 4))
    ttk.Combobox(bar, textvariable=mode_var, values=["Auto", "Gain", "Noise"], width=9, state="readonly").pack(side="left")
    ttk.Button(bar, text="Export CSV", command=lambda: save_csv()).pack(side="left", padx=8)
    ttk.Label(bar, textvariable=status).pack(side="left", padx=14)

    pane = ttk.Panedwindow(root, orient="horizontal"); pane.pack(fill="both", expand=True, padx=8, pady=(0, 8))
    left = ttk.Frame(pane); right = ttk.Frame(pane); pane.add(left, weight=2); pane.add(right, weight=3)
    cols = ("file", "mode", "channels", "low", "high", "spec", "conf")
    drop = ttk.Label(left, text="DROP ZIP / FOLDER / JPEG / PNG HERE", anchor="center", padding=14, relief="ridge")
    drop.pack(fill="x", pady=(0, 8))
    tree = ttk.Treeview(left, columns=cols, show="headings")
    labels = ["File", "Mode", "Channels", "Low", "High", "Spec", "Conf."]
    widths = [190, 60, 95, 55, 55, 60, 55]
    for c, label, width in zip(cols, labels, widths):
        tree.heading(c, text=label); tree.column(c, width=width, anchor="center")
    tree.column("file", anchor="w")
    tree.tag_configure("spec_in", foreground="#0070C0")
    tree.tag_configure("spec_out", foreground="#D02020")
    tree.pack(fill="both", expand=True)
    preview = ttk.Label(right, anchor="center"); preview.pack(fill="both", expand=True)

    def show_selected(_event=None):
        nonlocal photo
        sel = tree.selection()
        if not sel: return
        idx = int(sel[0]); r = results[idx]
        im = annotate(paths[idx], r)
        maxw, maxh = max(300, right.winfo_width() - 12), max(300, right.winfo_height() - 12)
        im.thumbnail((maxw, maxh), Image.Resampling.LANCZOS)
        photo = ImageTk.PhotoImage(im); preview.configure(image=photo, cursor="hand2")
        if r.message:
            status.set(r.message)

    def collect_images(entries: Iterable[str]) -> tuple[list[str], list[str]]:
        found, warnings = [], []
        for raw in entries:
            p = Path(raw)
            if p.is_dir():
                found.extend(str(q) for q in p.rglob("*") if q.is_file() and q.suffix.lower() in IMAGE_TYPES)
            elif p.is_file() and p.suffix.lower() in IMAGE_TYPES:
                found.append(str(p))
            elif p.is_file() and p.suffix.lower() == ".zip":
                try:
                    holder = tempfile.TemporaryDirectory(prefix="EnergyGraphScan_"); temporary_dirs.append(holder)
                    target = Path(holder.name).resolve()
                    with zipfile.ZipFile(p) as zf:
                        for member in zf.infolist():
                            out = (target / member.filename).resolve()
                            if member.is_dir() or Path(member.filename).suffix.lower() not in IMAGE_TYPES or (target not in out.parents): continue
                            out.parent.mkdir(parents=True, exist_ok=True)
                            with zf.open(member) as src, open(out, "wb") as dst: dst.write(src.read())
                            found.append(str(out))
                except Exception as exc: warnings.append(f"{p.name}: {exc}")
            else: warnings.append(f"{p.name or raw}: unsupported")
        return list(dict.fromkeys(found)), warnings

    def _render_result(idx:int, r:ScanResult, name:str, fingerprint:str):
        nonlocal photo
        digits = 4 if r.mode == "Noise" else 2
        low_text = f"{r.low:.{digits}f}" if r.low is not None else "—"
        high_text = f"{r.high:.{digits}f}" if r.high is not None else "—"
        passed = _spec_in(r) if r.low is not None and r.high is not None else None
        ch_text = str(r.analysis_channel) if r.analysis_channel is not None else ("Unknown" if len(r.channels)!=1 else str(r.channels[0]))
        values=(r.file,r.mode,ch_text,low_text,high_text,"—" if passed is None else ("IN" if passed else "OUT"),f"{r.confidence:.0%}")
        tag=() if passed is None else (("spec_in" if passed else "spec_out"),)
        iid=str(idx)
        if tree.exists(iid):
            tree.item(iid,values=values,tags=tag)
        else:
            tree.insert("", "end", iid=iid, values=values, tags=tag)
        result_by_fingerprint[fingerprint]=idx

    def _poll_worker():
        nonlocal analysis_busy
        changed=False
        while True:
            try: item=work_q.get_nowait()
            except queue.Empty: break
            kind=item[0]
            if kind=="progress":
                status.set(item[1])
            elif kind=="result":
                _,fingerprint,name,r=item
                if fingerprint in result_by_fingerprint:
                    idx=result_by_fingerprint[fingerprint]
                    results[idx]=r; paths[idx]=name
                else:
                    idx=len(results); results.append(r); paths[idx]=name
                _render_result(idx,r,name,fingerprint); changed=True
            elif kind=="fail":
                _,msg=item
                status.set(msg)
            elif kind=="done":
                _,count,failures=item
                analysis_busy=False
                status.set(f"Analyzed/updated {count} image(s)." + (f" {len(failures)} warning(s)." if failures else ""))
                if changed and results:
                    tree.selection_set(str(len(results)-1)); show_selected()
                if failures:
                    # Do not block Explorer/desktop interaction with a modal warning.
                    print("Energy Graph Scan warnings:")
                    for q in failures[:50]: print(" -",q)
            work_q.task_done()
        root.after(80,_poll_worker)

    def _worker(entries: list[str], requested_mode:str):
        failures=[]
        try:
            names,warnings=collect_images(entries); failures.extend(warnings)
            # Dedup current batch before analysis.
            unique=[]
            seen=set()
            for name in names:
                try: fp=_file_fingerprint(name)
                except Exception as exc:
                    failures.append(f"{os.path.basename(name)}: fingerprint failed: {exc}"); continue
                if fp in seen: continue
                seen.add(fp); unique.append((name,fp))
            total=len(unique)
            for pos,(name,fp) in enumerate(unique,1):
                work_q.put(("progress",f"Analyzing {pos}/{total}: {os.path.basename(name)}"))
                try:
                    r=analyze_image(name,requested_mode)
                    work_q.put(("result",fp,name,r))
                except Exception as exc:
                    failures.append(f"{os.path.basename(name)}: {exc}")
            work_q.put(("done",total,failures))
        except Exception as exc:
            work_q.put(("fail",f"Import/analysis failed: {exc}"))
            work_q.put(("done",0,failures))

    def analyze_entries(entries: Iterable[str]):
        nonlocal analysis_busy
        entries=list(entries)
        if not entries:return
        if analysis_busy:
            status.set("Analysis is already running. Wait for it to finish.")
            return
        analysis_busy=True
        status.set("Preparing files in background…")
        threading.Thread(target=_worker,args=(entries,mode_var.get()),daemon=True).start()

    def open_images():
        names = filedialog.askopenfilenames(filetypes=[("Supported", "*.zip *.jpg *.jpeg *.png *.bmp *.tif *.tiff"), ("All", "*.*")])
        if names: analyze_entries(names)

    def open_folder():
        name = filedialog.askdirectory()
        if name: analyze_entries([name])

    def on_drop(event): analyze_entries(root.tk.splitlist(event.data))

    def enlarge_preview(_event=None):
        sel = tree.selection()
        if not sel: return
        idx = int(sel[0]); r = results[idx]; original = annotate(paths[idx], r)
        win = tk.Toplevel(root); win.title(f"Image inspection — {r.file}"); win.geometry("1000x760")
        tools = ttk.Frame(win, padding=6); tools.pack(fill="x"); canvas_large = tk.Canvas(win, background="#202020", highlightthickness=0)
        sx = ttk.Scrollbar(win, orient="horizontal", command=canvas_large.xview); sy = ttk.Scrollbar(win, orient="vertical", command=canvas_large.yview)
        canvas_large.configure(xscrollcommand=sx.set, yscrollcommand=sy.set); sy.pack(side="right", fill="y"); sx.pack(side="bottom", fill="x"); canvas_large.pack(fill="both", expand=True)
        state = {"photo": None}
        def redraw(factor):
            size=(max(1,int(original.width*factor)),max(1,int(original.height*factor))); shown=original.resize(size,Image.Resampling.LANCZOS)
            state["photo"]=ImageTk.PhotoImage(shown); canvas_large.delete("all"); canvas_large.create_image(0,0,image=state["photo"],anchor="nw"); canvas_large.configure(scrollregion=(0,0,*size))
        ttk.Label(tools,text="Zoom:").pack(side="left")
        for text, factor in [("50%",.5),("100%",1.0),("200%",2.0)]: ttk.Button(tools,text=text,command=lambda f=factor:redraw(f)).pack(side="left",padx=3)
        ttk.Button(tools,text="Fit",command=lambda:redraw(min((win.winfo_width()-40)/original.width,(win.winfo_height()-100)/original.height))).pack(side="left",padx=3)
        canvas_large.bind("<MouseWheel>",lambda e:canvas_large.yview_scroll(-1 if e.delta>0 else 1,"units")); redraw(1.0)

    def save_csv():
        if not results:
            messagebox.showinfo("No results", "Open and analyze images first."); return
        name = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="energy_scan_results.csv", filetypes=[("CSV", "*.csv")])
        if name:
            export_csv(results, name); status.set(f"Saved: {name}")

    tree.bind("<<TreeviewSelect>>", show_selected)
    root.after(80,_poll_worker)
    preview.bind("<Button-1>", enlarge_preview)
    if dnd_available:
        for widget in (root, drop, tree, preview): widget.drop_target_register(DND_FILES); widget.dnd_bind("<<Drop>>", on_drop)
    else: drop.configure(text="Use Open Files / Open Folder (drag & drop unavailable)")
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        for name in sys.argv[1:]:
            print(analyze_image(name))
    else:
        run_gui()
