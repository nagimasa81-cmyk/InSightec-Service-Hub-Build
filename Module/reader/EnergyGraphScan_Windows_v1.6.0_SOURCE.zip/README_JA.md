# Energy Graph Scan v1.6.0 — Windows

Windows版をiPhone v1.6.0の解析仕様へ合わせた版です。UIは従来のWindows操作を維持し、解析コアを更新しています。

## v1.6.0 の主な変更

- Channel checkboxが1個だけの場合は、そのChannelを優先して解析。
- 複数Channelがチェックされている場合、複数トレースを平均しない。
- グラフ内の色をクラスタ化し、色ごとに独立して横方向へトレース追跡。
- 可視率と連続性から前面に見えているトレース候補を選び、その1本だけでLow/Highを計算。
- 完全重複や検出失敗時のみ従来抽出へフォールバックし、結果メッセージに明示。
- Low/High分割はGain/NoiseともSample#270を共通基準として維持。
- Channelが不明でも解析は停止しない。
- 数値と表示ラインは同じ座標モデルを使用。

## Channel判定の考え方

1. checkboxが1個: そのChannelを優先。
2. checkboxが複数: checkbox群を候補集合として保持し、計算にはforeground traceだけを使用。
3. checkboxなし: Channel Unknownのままforeground traceで数値解析を継続。

現在は画像内の前面色トレース分離を優先しています。複数checkbox時の「foreground色 → CH番号」の完全な対応付けは、実画像による色テーブル検証を追加してさらに強化します。

## Build

GitHub Actionsの `Build Windows EXE` または `01_BUILD_EXE_GITHUB.bat` を使用してください。
