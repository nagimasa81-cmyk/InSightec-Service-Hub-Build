import json
import os
import sys
import subprocess
import shutil
import hashlib
import platform
import traceback
import sqlite3
import webbrowser
import zipfile
import tempfile
import time
import ctypes
import threading
import re
import uuid
import queue
from ctypes import wintypes
from datetime import datetime, timedelta
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
    HUB_TK_BASE = TkinterDnD.Tk
    DND_AVAILABLE = True
except Exception:
    HUB_TK_BASE = tk.Tk
    DND_FILES = None
    DND_AVAILABLE = False

RUN_DIR = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
CONFIG_PATH = RUN_DIR / 'config.json'
LOG_DIR = RUN_DIR / 'logs'
SESSION_LOG_PATH = LOG_DIR / f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
FEEDBACK_DIR = RUN_DIR / 'feedback'
UPDATES_DIR = RUN_DIR / 'updates'
BACKUP_DIR = RUN_DIR / 'backups'
DB_DIR = RUN_DIR / 'database'
LANG_DIR = RUN_DIR / 'language'
HELP_DIR = RUN_DIR / 'help'
for p in (LOG_DIR, FEEDBACK_DIR, UPDATES_DIR, BACKUP_DIR, DB_DIR, LANG_DIR, HELP_DIR):
    p.mkdir(exist_ok=True)

THEMES = {
    'insightec_light': {
        'bg': '#eef3f7', 'panel': '#ffffff', 'panel2': '#e6eef5', 'text': '#243746',
        'muted': '#617487', 'primary': '#005b96', 'accent': '#00a0c6', 'ok': '#148a5b',
        'warn': '#c78400', 'bad': '#b3261e', 'entry': '#ffffff', 'border': '#c8d6e2',
        'header': '#004f7c', 'nav': '#dfe9f1', 'nav_active': '#c8ddeb'
    },
    'insightec_dark': {
        'bg': '#07111f', 'panel': '#101c2d', 'panel2': '#0b1728', 'text': '#eaf6ff',
        'muted': '#9fb6c9', 'primary': '#55c7ff', 'accent': '#00a3d9', 'ok': '#31c48d',
        'warn': '#f4b740', 'bad': '#ff6b6b', 'entry': '#02091a', 'border': '#17324d'
    }
}

LANGUAGE_METADATA = {
    'en': {'name': 'English', 'native': 'English', 'flag': '🇺🇸', 'enabled': True, 'completion': 100},
    'ja': {'name': 'Japanese', 'native': '日本語', 'flag': '🇯🇵', 'enabled': True, 'completion': 100},
    'zh_TW': {'name': 'Traditional Chinese', 'native': '繁體中文', 'flag': '🇹🇼', 'enabled': True, 'completion': 100},
    'ko': {'name': 'Korean', 'native': '한국어', 'flag': '🇰🇷', 'enabled': True, 'completion': 100},
    'es': {'name': 'Spanish', 'native': 'Español', 'flag': '🇪🇸', 'enabled': True, 'completion': 100},
}

SUPPORTED_LANGUAGES = {code: meta['native'] for code, meta in LANGUAGE_METADATA.items()}

LANGUAGE_FONT = {
    'en': ('Segoe UI', 10),
    'ja': ('Yu Gothic UI', 10),
    'zh_TW': ('Microsoft JhengHei UI', 10),
    'ko': ('Malgun Gothic', 10),
    'es': ('Segoe UI', 10),
}

_MANIFEST_CACHE = {'signature': None, 'items': []}




def normalize_tool_manifest(manifest, folder_path):
    """Normalize a module manifest into the internal tool dictionary format."""
    data = dict(manifest or {})
    data.setdefault('folder', str(folder_path.relative_to(RUN_DIR)) if folder_path.is_relative_to(RUN_DIR) else str(folder_path))
    data.setdefault('enabled', data.get('status', 'active') != 'future')
    data.setdefault('status', 'active' if data.get('enabled', True) else 'future')
    if 'display_name' in data and 'name' not in data:
        data['name'] = data.get('display_name')
    if 'entry' in data and 'exe' not in data:
        data['exe'] = data.get('entry')
    return data

def discover_tool_manifests(force=False):
    """Read module manifests once and reuse them until a manifest changes."""
    paths = []
    for base_name in ('tools', 'plugins'):
        base = RUN_DIR / base_name
        if base.exists():
            paths.extend(sorted(base.glob('*/manifest.json')))
    signature = tuple((str(p), p.stat().st_mtime_ns, p.stat().st_size) for p in paths)
    if not force and _MANIFEST_CACHE.get('signature') == signature:
        return [dict(x) for x in _MANIFEST_CACHE.get('items', [])]
    discovered = []
    for manifest_path in paths:
        manifest = load_json(manifest_path, {})
        if manifest:
            tool = normalize_tool_manifest(manifest, manifest_path.parent)
            tool['_manifest_path'] = str(manifest_path)
            discovered.append(tool)
    _MANIFEST_CACHE['signature'] = signature
    _MANIFEST_CACHE['items'] = [dict(x) for x in discovered]
    return discovered

def localized_value(value, language_code='en'):
    """Return localized text from either a plain string or a language dictionary."""
    if isinstance(value, dict):
        return value.get(language_code) or value.get('en') or next(iter(value.values()), '')
    return value or ''

class AppLogger:
    def __init__(self):
        self.path = LOG_DIR / f"hub_{datetime.now().strftime('%Y%m%d')}.log"
    def write(self, msg):
        line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
        try:
            with open(self.path, 'a', encoding='utf-8') as f:
                f.write(line + '\n')
        except Exception:
            pass
        return line
logger = AppLogger()

def load_json(path, default):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return default


def save_json(path, data):
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        logger.write(f'Failed to save JSON {path}: {e}')
        return False

def load_config():
    return load_json(CONFIG_PATH, {})

def save_config(cfg):
    with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)

def sha256_short(path):
    try:
        h = hashlib.sha256()
        with open(path, 'rb') as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b''):
                h.update(chunk)
        return h.hexdigest()[:12]
    except Exception:
        return 'N/A'

def get_windows_exe_version(path):
    """Read ProductVersion/FileVersion from a Windows EXE. Returns an empty string when unavailable."""
    if os.name != 'nt':
        return ''
    try:
        exe_path = str(Path(path).resolve())
        size = ctypes.windll.version.GetFileVersionInfoSizeW(exe_path, None)
        if not size:
            return ''
        buf = ctypes.create_string_buffer(size)
        if not ctypes.windll.version.GetFileVersionInfoW(exe_path, 0, size, buf):
            return ''
        value_ptr = ctypes.c_void_p()
        value_len = wintypes.UINT()
        if not ctypes.windll.version.VerQueryValueW(buf, '\\', ctypes.byref(value_ptr), ctypes.byref(value_len)):
            return ''
        class VS_FIXEDFILEINFO(ctypes.Structure):
            _fields_ = [
                ('dwSignature', wintypes.DWORD), ('dwStrucVersion', wintypes.DWORD),
                ('dwFileVersionMS', wintypes.DWORD), ('dwFileVersionLS', wintypes.DWORD),
                ('dwProductVersionMS', wintypes.DWORD), ('dwProductVersionLS', wintypes.DWORD),
                ('dwFileFlagsMask', wintypes.DWORD), ('dwFileFlags', wintypes.DWORD),
                ('dwFileOS', wintypes.DWORD), ('dwFileType', wintypes.DWORD),
                ('dwFileSubtype', wintypes.DWORD), ('dwFileDateMS', wintypes.DWORD),
                ('dwFileDateLS', wintypes.DWORD),
            ]
        info = ctypes.cast(value_ptr, ctypes.POINTER(VS_FIXEDFILEINFO)).contents
        ms = info.dwProductVersionMS or info.dwFileVersionMS
        ls = info.dwProductVersionLS or info.dwFileVersionLS
        parts = [(ms >> 16) & 0xFFFF, ms & 0xFFFF, (ls >> 16) & 0xFFFF, ls & 0xFFFF]
        while len(parts) > 3 and parts[-1] == 0:
            parts.pop()
        return '.'.join(str(x) for x in parts)
    except Exception:
        return ''

def tool_folder_path(tool):
    return RUN_DIR / tool.get('folder', '')

def _tool_executable_score(path, tool):
    """Score an executable by role instead of depending on one fixed filename."""
    name = path.name.lower()
    rel = str(path.relative_to(tool_folder_path(tool))).replace('\\', '/').lower()
    exclude = [str(x).lower() for x in tool.get('executable_exclude', [])]
    if any(token and token in name for token in exclude):
        return -100000
    if any(token in name for token in ('uninstall', 'updater', 'update_helper', 'crash', 'reporter')):
        return -100000
    score = 0
    configured = str(tool.get('exe', '') or '').lower()
    if configured and name == configured:
        score += 1200
    candidates = tool.get('executable_candidates', []) or []
    for index, candidate in enumerate(candidates):
        candidate = str(candidate).lower().strip()
        if not candidate:
            continue
        if name == candidate:
            score += 1100 - index * 10
        elif candidate.replace('.exe', '') in name:
            score += 500 - index * 5
    patterns = tool.get('executable_patterns', []) or []
    for pattern in patterns:
        try:
            if re.search(str(pattern), path.name, re.IGNORECASE):
                score += 650
        except re.error:
            pass
    if 'debug' in name or 'console' in name or 'test' in name:
        score -= 500
    if '/dist/' in f'/{rel}/' or '.dist/' in rel or '/release/' in f'/{rel}/':
        score += 120
    depth = len(path.relative_to(tool_folder_path(tool)).parts)
    score -= depth * 3
    try:
        score += min(int(path.stat().st_size / (1024 * 1024)), 100)
    except OSError:
        pass
    return score


def resolve_tool_executable(tool):
    """Resolve the most likely startup EXE using manifest hints and executable inspection."""
    folder = tool_folder_path(tool)
    configured = str(tool.get('exe', '') or '').strip()
    fallback = folder / configured if configured else folder / '__tool_executable_not_found__.exe'
    if not folder.exists():
        return fallback, 'tool folder does not exist'

    exact_names = []
    if configured:
        exact_names.append(configured)
    exact_names.extend(str(x) for x in (tool.get('executable_candidates', []) or []) if x)
    for name in exact_names:
        direct = folder / name
        if direct.is_file():
            return direct, f'exact manifest candidate: {name}'
    for name in exact_names:
        matches = [x for x in folder.rglob(name) if x.is_file()]
        if matches:
            best = max(matches, key=lambda x: _tool_executable_score(x, tool))
            return best, f'recursive manifest candidate: {name}'

    executables = [x for x in folder.rglob('*.exe') if x.is_file()]
    ranked = sorted(((_tool_executable_score(x, tool), x) for x in executables), reverse=True, key=lambda item: item[0])
    if ranked and ranked[0][0] > -100000:
        return ranked[0][1], f'auto-resolved executable (score {ranked[0][0]})'
    return fallback, 'no usable executable candidate found'


def tool_abs_path(tool):
    return resolve_tool_executable(tool)[0]

def tool_validation(tool, detailed=False):
    if tool.get('status') == 'future':
        return {'ready': False, 'status': 'Coming Soon', 'detail': 'Reserved future plug-in'}
    if not tool.get('enabled'):
        return {'ready': False, 'status': 'Disabled', 'detail': 'Tool is disabled in config'}
    folder = tool_folder_path(tool)
    p, resolution_detail = resolve_tool_executable(tool)
    if not folder.exists():
        return {'ready': False, 'status': 'Missing', 'detail': f'Folder not found: {folder}'}
    if not p.exists() or not p.is_file():
        return {'ready': False, 'status': 'Missing', 'detail': f'No startup EXE could be resolved under {folder}. Manifest candidates: {tool.get("executable_candidates", [])}'}
    try:
        st = p.stat()
        return {
            'ready': True,
            'status': 'Ready',
            'detail': f'{st.st_size/1024/1024:.1f} MB | {datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M")} | {resolution_detail}' + (f' | hash {sha256_short(p)}' if detailed else ''),
            'path': str(p)
        }
    except Exception as e:
        return {'ready': False, 'status': 'Error', 'detail': str(e)}

def tool_is_ready(tool):
    return bool(tool_validation(tool).get('ready'))

def tool_runtime_info(tool):
    v = tool_validation(tool, detailed=True)
    if v.get('ready'):
        return f"{tool.get('version', '')} | {v.get('detail')}"
    return f"{tool.get('version', '')} | {v.get('status')}: {v.get('detail')}"

class HubApp(HUB_TK_BASE):
    def __init__(self):
        super().__init__()
        self.ui_scale = 1.0
        self.developer_mode = False
        self.developer_mode_until = None
        self._resize_after = None
        self._tools_cache = None
        self._tools_cache_signature = None
        self.cfg = load_config()
        self.ensure_developer_password()
        self.lang_en = load_json(LANG_DIR / 'en.json', {})
        self.lang = self.load_language(self.cfg.get('language', 'en'))
        self.theme_name = self.cfg.get('theme', 'insightec_light')
        self.theme = THEMES.get(self.theme_name, THEMES['insightec_light'])
        self.current_page = 'tools'
        self.selected_tool_id = None
        self.auto_analysis_session = None
        self._auto_analysis_generation = 0
        self._auto_result_queue = queue.Queue()
        self.auto_tool_vars = {}
        self.auto_result_widgets = {}
        self.auto_launch_var = None
        self.title(f"{self.cfg.get('console_name', 'InSightec APAC Service Hub')} v{self.cfg.get('console_version', '')}")
        # Fit the initial window inside the current laptop/workstation display.
        # This avoids hiding bottom action buttons on 1366x768-class screens.
        screen_w = max(1024, self.winfo_screenwidth())
        screen_h = max(640, self.winfo_screenheight())
        initial_w = min(1280, max(980, screen_w - 80))
        initial_h = min(720, max(620, screen_h - 110))
        pos_x = max(0, (screen_w - initial_w) // 2)
        pos_y = max(0, (screen_h - initial_h) // 2 - 10)
        self.geometry(f'{initial_w}x{initial_h}+{pos_x}+{pos_y}')
        self.minsize(960, 600)
        self.bind('<Configure>', self.on_window_configure)
        self._apply_style()
        self._build_shell()
        self.after_idle(self._audit_geometry_managers)
        self.after_idle(self.init_parts_db)
        self.after(80, self._poll_auto_analysis_queue)
        self.cfg['session_log'] = str(SESSION_LOG_PATH)
        save_config(self.cfg)
        logger.write('InSightec APAC Service Hub started')
        self.write_session('Hub started')
        # Unified UI: Tools is the only launcher/dataset-routing home page.
        # Legacy startup_page values are intentionally redirected here.
        startup_page = self.cfg.get('startup_page', 'tools')
        self.show_tools()


    def _audit_geometry_managers(self):
        """Log any parent that has children managed by both pack and grid."""
        mixed = []

        def walk(widget):
            try:
                managers = {}
                for child in widget.winfo_children():
                    manager = child.winfo_manager()
                    if manager:
                        managers.setdefault(manager, []).append(str(child))
                    walk(child)
                if 'pack' in managers and 'grid' in managers:
                    mixed.append((str(widget), managers['pack'], managers['grid']))
            except tk.TclError:
                return

        walk(self)
        if mixed:
            for parent, packed, gridded in mixed:
                logger.write(
                    'Geometry manager conflict detected: '
                    f'parent={parent}; pack={packed}; grid={gridded}'
                )
        else:
            logger.write('Geometry manager audit passed')

    def t(self, key):
        return self.lang.get(key, self.lang_en.get(key, key))

    def tr_tool(self, tool, field):
        return localized_value(tool.get(field, ''), self.cfg.get('language', 'en'))

    def load_language(self, code):
        if not getattr(self, 'lang_en', None):
            self.lang_en = load_json(LANG_DIR / 'en.json', {})
        data = self.lang_en.copy() if code == 'en' else load_json(LANG_DIR / f'{code}.json', {})
        if not data:
            data = self.lang_en.copy()
        else:
            merged = self.lang_en.copy()
            merged.update(data)
            data = merged
        return data

    def language_label(self, code):
        meta = LANGUAGE_METADATA.get(code, {'native': code, 'flag': '', 'completion': 0, 'enabled': False})
        state = 'Ready' if meta.get('enabled') else 'Coming Soon'
        return f"{code} - {meta.get('flag','')} {meta.get('native', code)} ({state})"

    def language_values(self):
        return [self.language_label(code) for code in SUPPORTED_LANGUAGES]

    def parse_language_value(self, value):
        return str(value).split(' - ', 1)[0].strip()

    def language_enabled(self, code):
        return bool(LANGUAGE_METADATA.get(code, {}).get('enabled'))

    def language_completion(self, code):
        return int(LANGUAGE_METADATA.get(code, {}).get('completion', 0))

    def language_menu_button(self, parent, variable, command, width=28):
        """Create a language selector where incomplete languages are visible but disabled."""
        mb = ttk.Menubutton(parent, textvariable=variable, width=width)
        menu = tk.Menu(mb, tearoff=0)
        for code in SUPPORTED_LANGUAGES:
            meta = LANGUAGE_METADATA.get(code, {})
            label = self.language_label(code)
            state = 'normal' if meta.get('enabled') else 'disabled'
            menu.add_command(
                label=label,
                state=state,
                command=lambda c=code: (variable.set(self.language_label(c)), command(c))
            )
        mb.configure(menu=menu)
        return mb

    def language_status_lines(self):
        lines = []
        for code in SUPPORTED_LANGUAGES:
            meta = LANGUAGE_METADATA.get(code, {})
            status = self.t('ready') if meta.get('enabled') else self.t('coming_soon')
            lines.append(f"{meta.get('flag','')} {meta.get('native', code)}: {meta.get('completion', 0)}% - {status}")
        return lines


    def ensure_developer_password(self):
        """Initialize developer password hash. Default password is 5963."""
        if not self.cfg.get('developer_password_hash'):
            self.cfg['developer_password_hash'] = hashlib.sha256('5963'.encode('utf-8')).hexdigest()
            save_config(self.cfg)

    def verify_developer_password(self, password):
        return hashlib.sha256(str(password).encode('utf-8')).hexdigest() == self.cfg.get('developer_password_hash', '')

    def developer_mode_valid(self):
        if not self.developer_mode or not self.developer_mode_until:
            return False
        if datetime.now() > self.developer_mode_until:
            self.developer_mode = False
            self.developer_mode_until = None
            self.set_status(self.t('developer_mode_expired'))
            return False
        return True

    def enable_developer_mode(self):
        self.developer_mode = True
        self.developer_mode_until = datetime.now() + timedelta(minutes=30)
        self.set_status(self.t('developer_mode_enabled'))

    def prompt_developer_mode(self):
        win = tk.Toplevel(self)
        win.title(self.t('developer_password'))
        win.transient(self)
        win.grab_set()
        win.configure(bg=self.theme['bg'])
        win.geometry('360x170')
        ttk.Label(win, text=self.t('developer_password'), font=('Segoe UI Semibold', 12)).pack(anchor='w', padx=18, pady=(18, 6))
        pwd = tk.StringVar()
        entry = ttk.Entry(win, textvariable=pwd, show='*', width=28)
        entry.pack(anchor='w', padx=18, pady=6)
        msg = tk.StringVar(value='')
        ttk.Label(win, textvariable=msg, foreground=self.theme['bad'], background=self.theme['bg']).pack(anchor='w', padx=18, pady=(0, 4))
        def ok():
            if self.verify_developer_password(pwd.get()):
                self.enable_developer_mode()
                win.destroy()
                self.show_update()
            else:
                msg.set(self.t('invalid_password'))
                entry.selection_range(0, 'end')
        row = ttk.Frame(win)
        row.pack(fill='x', padx=18, pady=8)
        ttk.Button(row, text='OK', style='Accent.TButton', command=ok).pack(side='right')
        ttk.Button(row, text=self.t('cancel'), command=win.destroy).pack(side='right', padx=8)
        entry.bind('<Return>', lambda e: ok())
        entry.focus_set()
        self.wait_window(win)

    def on_window_configure(self, event):
        if event.widget is not self:
            return
        if self._resize_after:
            self.after_cancel(self._resize_after)
        self._resize_after = self.after(160, self.apply_responsive_scale)

    def apply_responsive_scale(self):
        width = max(1, self.winfo_width())
        if width < 1050:
            new_scale = 0.88
        elif width < 1250:
            new_scale = 0.94
        else:
            new_scale = 1.0
        if abs(new_scale - self.ui_scale) > 0.01:
            self.ui_scale = new_scale
            self._apply_style()

    def _apply_style(self):
        c = self.theme
        self.configure(bg=c['bg'])
        s = ttk.Style(self)
        try:
            s.theme_use('clam')
        except Exception:
            pass
        base_family = LANGUAGE_FONT.get(self.cfg.get('language', 'en'), ('Segoe UI', 10))[0]
        s.configure('.', font=(base_family, max(8, int(self.ui_scale * 10))))
        s.configure('TFrame', background=c['bg'])
        s.configure('Panel.TFrame', background=c['panel'], relief='flat')
        s.configure('Header.TFrame', background=c.get('header', c['primary']))
        s.configure('NavPanel.TFrame', background=c.get('nav', c['panel2']))
        s.configure('Panel2.TFrame', background=c['panel2'], relief='flat')
        s.configure('TLabel', background=c['bg'], foreground=c['text'])
        s.configure('Panel.TLabel', background=c['panel'], foreground=c['text'])
        s.configure('Muted.TLabel', background=c['panel'], foreground=c['muted'])
        s.configure('Title.TLabel', background=c.get('header', c['primary']), foreground='#ffffff', font=('Segoe UI Semibold', max(18, int(self.ui_scale * 24))))
        s.configure('PageTitle.TLabel', background=c['panel'], foreground=c['primary'], font=('Segoe UI Semibold', max(14, int(self.ui_scale * 18))))
        s.configure('Metric.TLabel', background=c['panel'], foreground=c['text'], font=('Segoe UI Semibold', max(18, int(self.ui_scale * 24))))
        s.configure('Section.TLabel', background=c['panel'], foreground=c['primary'], font=('Segoe UI Semibold', max(10, int(self.ui_scale * 12))))
        s.configure('Card.TFrame', background=c['panel'])
        s.configure('Nav.TButton', font=('Segoe UI Semibold', max(9, int(self.ui_scale * 10))), padding=(14, 10), anchor='w', background=c.get('nav', c['panel2']), foreground=c['text'])
        s.map('Nav.TButton', background=[('active', c.get('nav_active', c['border']))])
        s.configure('TButton', font=('Segoe UI', max(8, int(self.ui_scale * 10))), padding=8)
        s.configure('Accent.TButton', font=('Segoe UI Semibold', max(9, int(self.ui_scale * 10))), padding=8)
        s.configure('Tool.TButton', font=('Segoe UI Semibold', max(9, int(self.ui_scale * 11))), padding=10)
        s.configure('TEntry', fieldbackground=c['entry'], foreground=c['text'])
        s.configure('TCombobox', fieldbackground=c['entry'], foreground=c['text'])
        s.configure('Treeview', background=c['panel'], fieldbackground=c['panel'], foreground=c['text'], rowheight=30)
        s.configure('Treeview.Heading', background=c['panel2'], foreground=c['text'], font=('Segoe UI Semibold', max(9, int(self.ui_scale * 10))))
        s.map('Treeview', background=[('selected', c['primary'])], foreground=[('selected', '#ffffff')])

    def _build_shell(self):
        c = self.theme
        header = ttk.Frame(self, style='Header.TFrame')
        header.pack(fill='x', padx=0, pady=0)
        ttk.Label(header, text='InSightec APAC Service Hub', style='Title.TLabel').pack(side='left', padx=(22, 8), pady=12)
        ttk.Label(header, text=f"v{self.cfg.get('console_version', '')}  |  One Hub for Every Service Engineer", foreground='#d9edf7', background=c.get('header', c['primary'])).pack(side='left', padx=8, pady=(18,0))
        self.lang_var = tk.StringVar(value=self.language_label(self.cfg.get('language', 'en')))
        lang = self.language_menu_button(header, self.lang_var, self.change_language, width=28)
        lang.pack(side='right', padx=(0,18), pady=10)
        ttk.Label(header, text='🌐', background=c.get('header', c['primary']), foreground='#ffffff').pack(side='right', padx=(0,6), pady=14)
        self.search_var = tk.StringVar()
        search = ttk.Entry(self, textvariable=self.search_var, font=('Segoe UI', max(9, int(self.ui_scale * 11))))
        search.pack(fill='x', padx=18, pady=(12, 10))
        search.insert(0, self.t('search'))
        search.bind('<FocusIn>', lambda e: self._clear_search_placeholder())
        search.bind('<Return>', lambda e: self.search())
        shell = ttk.Frame(self)
        shell.pack(fill='both', expand=True, padx=18, pady=(0, 10))
        self.nav = ttk.Frame(shell, style='NavPanel.TFrame', width=190)
        self.nav.pack(side='left', fill='y', padx=(0, 12))
        self.nav.pack_propagate(False)
        self.content = ttk.Frame(shell, style='Panel.TFrame')
        self.content.pack(side='left', fill='both', expand=True)
        self.status_var = tk.StringVar(value=self.t('status_ready'))
        status = ttk.Frame(self)
        status.pack(fill='x', padx=18, pady=(0, 12))
        ttk.Label(status, textvariable=self.status_var, background=c['bg'], foreground=c['muted']).pack(side='left')
        ttk.Label(status, text=f"Log: {logger.path.name}", background=c['bg'], foreground=c['muted']).pack(side='right')
        self._build_nav()

    def _build_nav(self):
        for w in self.nav.winfo_children():
            w.destroy()
        items = [
            ('tools', '🛠', self.t('tools'), self.show_tools),
            ('modules', '🧩', self.t('modules') if 'modules' in self.lang else 'Modules', self.show_modules),
            ('parts', '📦', self.t('parts'), lambda: self.show_coming_soon('Part Search')),
            ('documents', '📚', self.t('documents'), lambda: self.show_coming_soon('Document Search')),
            ('feedback', '💬', self.t('feedback'), self.show_feedback),
            ('update', '⬆', self.t('update'), self.show_update),
            ('help', '❓', self.t('help'), self.show_help),
            ('settings', '⚙', self.t('settings'), self.show_settings),
            ('about', 'ℹ', self.t('about'), self.show_about),
        ]
        tk.Label(self.nav, text='  MENU', bg=self.theme.get('nav', self.theme['panel2']), fg=self.theme['muted'], font=('Segoe UI Semibold', max(8, int(self.ui_scale*9)))).pack(anchor='w', padx=10, pady=(16,8))
        for key, icon, text, cmd in items:
            ttk.Button(self.nav, text=f'{icon}  {text}', style='Nav.TButton', command=cmd).pack(fill='x', padx=10, pady=4)

    def clear_content(self):
        try:
            canvas = getattr(self, '_tools_canvas', None)
            if canvas is not None:
                canvas.unbind_all('<MouseWheel>')
                canvas.unbind_all('<Button-4>')
                canvas.unbind_all('<Button-5>')
        except Exception:
            pass
        for w in self.content.winfo_children():
            w.destroy()
    def write_session(self, event, detail=''):
        try:
            line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {event}"
            if detail:
                line += f" | {detail}"
            with open(SESSION_LOG_PATH, 'a', encoding='utf-8') as f:
                f.write(line + '\n')
        except Exception:
            pass

    def set_status(self, msg):
        line = logger.write(msg)
        self.write_session('Status', msg)
        self.status_var.set(msg)
        return line

    def page_title(self, title, subtitle=''):
        top = ttk.Frame(self.content, style='Panel.TFrame')
        top.pack(fill='x', padx=18, pady=(18, 8))
        ttk.Label(top, text=title, style='PageTitle.TLabel').pack(side='left')
        if subtitle:
            ttk.Label(top, text=subtitle, style='Muted.TLabel').pack(side='left', padx=14, pady=(4,0))

    def card(self, parent, title='', width=None):
        frame = ttk.Frame(parent, style='Panel.TFrame')
        frame.configure(padding=16)
        if title:
            ttk.Label(frame, text=title, style='Panel.TLabel', font=('Segoe UI Semibold', 13)).pack(anchor='w', pady=(0, 10))
        return frame

    def metric_card(self, parent, title, value, subtitle=''):
        f = self.card(parent, title)
        ttk.Label(f, text=str(value), style='Metric.TLabel').pack(anchor='w')
        if subtitle:
            ttk.Label(f, text=subtitle, style='Muted.TLabel').pack(anchor='w', pady=(2,0))
        return f

    def get_tools(self, force=False):
        """Return installed tools using a lightweight manifest cache.

        EXE version-resource inspection is intentionally deferred to explicit
        validation/information actions because scanning every EXE blocks startup.
        """
        manifest_tools = discover_tool_manifests(force=force)
        signature = tuple((t.get('id'), t.get('version'), t.get('exe'), t.get('_manifest_path')) for t in manifest_tools)
        if not force and self._tools_cache is not None and self._tools_cache_signature == signature:
            return self._tools_cache
        if not manifest_tools:
            tools = [dict(t) for t in self.cfg.get('tools', [])]
        else:
            by_id = {t.get('id'): dict(t) for t in self.cfg.get('tools', []) if t.get('id')}
            for mt in manifest_tools:
                tid = mt.get('id')
                if tid:
                    base = by_id.get(tid, {})
                    base.update(mt)
                    by_id[tid] = base
            tools, seen = [], set()
            for t in self.cfg.get('tools', []):
                tid = t.get('id')
                if tid in by_id:
                    tools.append(by_id[tid]); seen.add(tid)
            for mt in manifest_tools:
                tid = mt.get('id')
                if tid and tid not in seen:
                    tools.append(mt); seen.add(tid)
        for tool in tools:
            tool['_manifest_version'] = str(tool.get('version', '') or '')
            tool['_version_source'] = 'manifest.json' if tool.get('_manifest_path') else 'config.json'
        self._tools_cache = tools
        self._tools_cache_signature = signature
        return tools

    def invalidate_tool_cache(self):
        self._tools_cache = None
        self._tools_cache_signature = None
        _MANIFEST_CACHE['signature'] = None

    def get_tool_by_id(self, tool_id):
        return next((t for t in self.get_tools() if t.get('id') == tool_id), None)


    def validate_all_tools(self, save_report=True):
        rows = []
        for t in self.get_tools():
            v = tool_validation(t, detailed=True)
            folder = tool_folder_path(t)
            exe_path = Path(v.get('path', tool_abs_path(t)))
            checks = {
                'plugin_config': bool(t.get('id') and self.tr_tool(t, 'name')),
                'folder': folder.exists(),
                'exe': bool(v.get('ready')),
                'version': bool(t.get('version')),
                'help': (folder / 'help').exists() or (HELP_DIR.exists()),
                'log_folder': LOG_DIR.exists(),
                'feedback_ready': FEEDBACK_DIR.exists(),
            }
            if t.get('status') == 'future':
                result = 'SKIP'
            elif checks['exe'] and checks['plugin_config'] and checks['version']:
                result = 'PASS'
            elif checks['folder'] or checks['plugin_config']:
                result = 'WARNING'
            else:
                result = 'FAIL'
            rows.append({
                'id': t.get('id'),
                'name': self.tr_tool(t, 'name'),
                'version': t.get('version'),
                'status': v.get('status'),
                'result': result,
                'ready': bool(v.get('ready')),
                'path': v.get('path', str(tool_abs_path(t))),
                'detail': v.get('detail', ''),
                'checks': checks,
            })
        if save_report:
            stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            txt_report = LOG_DIR / f'tool_validation_{stamp}.txt'
            html_report = LOG_DIR / f'tool_validation_{stamp}.html'
            lines = [f'InSightec APAC Service Hub Tool Validation - {stamp}', '']
            for r in rows:
                lines.append(f"[{r['result']}] {r['name']}  v{r['version']}  status={r['status']}")
                for k, ok in r['checks'].items():
                    lines.append(f"  {'OK' if ok else 'NG'} {k}")
                lines.append(f"  Path   : {r['path']}")
                lines.append(f"  Detail : {r['detail']}")
                lines.append('')
            txt_report.write_text('\n'.join(lines), encoding='utf-8')
            def color(result):
                return {'PASS':'#148a5b','WARNING':'#c78400','FAIL':'#b3261e','SKIP':'#64788d'}.get(result, '#64788d')
            html = ['<!doctype html><html><head><meta charset="utf-8"><title>Tool Validation</title>',
                    '<style>body{font-family:Segoe UI,Arial;margin:24px;color:#1f2d3a} table{border-collapse:collapse;width:100%} th,td{border:1px solid #d6e3ef;padding:8px;text-align:left} th{background:#eef5fb}.badge{font-weight:700}</style></head><body>',
                    f'<h1>InSightec APAC Service Hub - Tool Validation</h1><p>Build: {self.cfg.get("console_version","")} / {stamp}</p>',
                    '<table><tr><th>Tool</th><th>Version</th><th>Result</th><th>Checks</th><th>Path / Detail</th></tr>']
            for r in rows:
                checks = '<br>'.join(f"{'✓' if ok else '×'} {k}" for k, ok in r['checks'].items())
                detail = f"{r['path']}<br><small>{r['detail']}</small>"
                html.append(f"<tr><td>{r['name']}</td><td>{r['version']}</td><td><span class='badge' style='color:{color(r['result'])}'>{r['result']}</span></td><td>{checks}</td><td>{detail}</td></tr>")
            html.append('</table></body></html>')
            html_report.write_text('\n'.join(html), encoding='utf-8')
            self.cfg['last_validation_report'] = str(html_report)
            save_config(self.cfg)
            self.set_status(f'Tool validation completed: {html_report.name}')
        return rows

    def status_badge(self, parent, status):
        c = self.theme
        color = c['ok'] if status == 'Ready' else (c['warn'] if status in ('Coming Soon','Disabled') else c['bad'])
        return tk.Label(parent, text=f"● {status}", bg=c['panel'], fg=color, font=('Segoe UI Semibold', max(9, int(self.ui_scale * 10))))

    def install_tool_zip(self, tool):
        zip_path = filedialog.askopenfilename(title=f"Select ZIP for {tool.get('name')}", filetypes=[('ZIP file','*.zip'),('All files','*.*')])
        if not zip_path:
            return
        folder = tool_folder_path(tool)
        folder.mkdir(parents=True, exist_ok=True)
        try:
            with zipfile.ZipFile(zip_path, 'r') as z:
                z.extractall(folder)
            v = tool_validation(tool)
            if v.get('ready'):
                messagebox.showinfo('Install complete', f"{tool.get('name')} is ready.\n\n{v.get('path')}")
                self.set_status(f"Installed tool ZIP: {tool.get('name')}")
            else:
                messagebox.showwarning('Install checked', f"ZIP extracted, but EXE was not detected.\n\n{v.get('detail')}")
                self.set_status(f"Tool ZIP extracted but not ready: {tool.get('name')}")
            self.invalidate_tool_cache()
            self.show_tools()
        except Exception as e:
            self.set_status(f'Tool ZIP install failed: {e}')
            messagebox.showerror('Install failed', str(e))

    def _show_unified_tools_page(self):
        """Unified Tools UI: direct card launch + checked-tool ZIP/folder routing."""
        self.current_page = 'tools'
        self.clear_content()
        self.page_title(
            self.t('tools'),
            'Check tools and drop a ZIP, or launch one tool directly.'
        )

        # Full-page vertical scrolling for laptop-size displays.
        scroll_host = ttk.Frame(self.content, style='Panel.TFrame')
        scroll_host.pack(fill='both', expand=True, padx=14, pady=(0, 12))

        tools_canvas = tk.Canvas(scroll_host, highlightthickness=0, borderwidth=0)
        tools_vscroll = ttk.Scrollbar(scroll_host, orient='vertical', command=tools_canvas.yview)
        tools_canvas.configure(yscrollcommand=tools_vscroll.set)
        tools_vscroll.pack(side='right', fill='y')
        tools_canvas.pack(side='left', fill='both', expand=True)

        outer = ttk.Frame(tools_canvas, style='Panel.TFrame')
        canvas_window = tools_canvas.create_window((0, 0), window=outer, anchor='nw')

        def _sync_tools_scrollregion(_event=None):
            try:
                tools_canvas.configure(scrollregion=tools_canvas.bbox('all'))
            except tk.TclError:
                pass

        def _sync_tools_width(event):
            try:
                tools_canvas.itemconfigure(canvas_window, width=max(1, event.width))
            except tk.TclError:
                pass

        def _tools_mousewheel(event):
            try:
                if event.delta:
                    tools_canvas.yview_scroll(int(-1 * (event.delta / 120)), 'units')
            except tk.TclError:
                pass
            return 'break'

        def _tools_scroll_up(_event):
            try:
                tools_canvas.yview_scroll(-3, 'units')
            except tk.TclError:
                pass
            return 'break'

        def _tools_scroll_down(_event):
            try:
                tools_canvas.yview_scroll(3, 'units')
            except tk.TclError:
                pass
            return 'break'

        def _bind_tools_wheel(_event=None):
            tools_canvas.bind_all('<MouseWheel>', _tools_mousewheel)
            tools_canvas.bind_all('<Button-4>', _tools_scroll_up)
            tools_canvas.bind_all('<Button-5>', _tools_scroll_down)

        def _unbind_tools_wheel(_event=None):
            tools_canvas.unbind_all('<MouseWheel>')
            tools_canvas.unbind_all('<Button-4>')
            tools_canvas.unbind_all('<Button-5>')

        outer.bind('<Configure>', _sync_tools_scrollregion)
        tools_canvas.bind('<Configure>', _sync_tools_width)
        tools_canvas.bind('<Enter>', _bind_tools_wheel)
        tools_canvas.bind('<Leave>', _unbind_tools_wheel)
        outer.bind('<Enter>', _bind_tools_wheel)
        outer.bind('<Leave>', _unbind_tools_wheel)

        self._tools_canvas = tools_canvas
        self._tools_vscroll = tools_vscroll
        self._tools_scroll_inner = outer

        # --- Dataset drop zone: always visible at the top of Tools. ---
        drop = tk.Label(
            outer,
            text=self.t('hybrid_drop'),
            bg=self.theme['panel2'], fg=self.theme['primary'], relief='groove', bd=2,
            font=('Segoe UI Semibold', max(11, int(self.ui_scale * 14))), height=3,
            cursor='hand2'
        )
        drop.pack(fill='x', pady=(0, 7))
        drop.bind('<Button-1>', lambda e: self.choose_auto_dataset())
        if DND_AVAILABLE:
            try:
                drop.drop_target_register(DND_FILES)
                drop.dnd_bind('<<Drop>>', self.on_auto_dataset_drop)
            except Exception as exc:
                logger.write(f'Hybrid drop registration failed: {exc}')

        controls = ttk.Frame(outer, style='Panel.TFrame')
        controls.pack(fill='x', pady=(0, 8))
        ttk.Button(controls, text=self.t('hybrid_select_zip'), command=self.choose_auto_dataset).pack(side='left')
        ttk.Button(controls, text=self.t('hybrid_select_folder'), command=self.choose_auto_folder).pack(side='left', padx=5)
        # Hybrid contract: dropping/selecting a dataset always launches every
        # explicitly checked tool after the ZIP/folder has been prepared.
        # Dataset detection is advisory only and must never override the user's
        # checkbox selection.
        self.auto_launch_var = tk.BooleanVar(value=True)
        ttk.Label(
            controls,
            text='Checked tools open with ZIP',
            style='Muted.TLabel'
        ).pack(side='right', padx=(8, 4))
        self.auto_progress = ttk.Progressbar(controls, mode='indeterminate', length=130)
        self.auto_progress.pack(side='right', padx=6)

        # Shared state used by both the hybrid page and the detailed analyzer page.
        self.auto_tool_vars = {}
        self.auto_result_widgets = {}
        saved = self.cfg.get('auto_analyzer_selected_tools', {})

        # --- Direct launcher cards. ---
        section = ttk.Frame(outer, style='Panel.TFrame')
        section.pack(fill='x', pady=(1, 4))
        ttk.Label(
            section, text='TOOLS', style='Section.TLabel'
        ).pack(side='left')
        ttk.Label(
            section,
            text=self.t('hybrid_tools_hint'),
            style='Muted.TLabel'
        ).pack(side='left', padx=12)

        cards_host = ttk.Frame(outer, style='Panel.TFrame')
        cards_host.pack(fill='x', pady=(0, 8))
        tools_by_id = {t.get('id'): t for t in self.get_tools()}
        direct_only = [
            t for t in self.get_tools()
            if t.get('id') not in self.AUTO_TOOL_ORDER and t.get('status') != 'future'
        ]
        # Direct-only optional tools (Complaint) are intentionally shown first so
        # they are visible without scrolling, while remaining outside ZIP Drop routing.
        ordered = direct_only + [tools_by_id[tid] for tid in self.AUTO_TOOL_ORDER if tid in tools_by_id]
        cols = 3 if self.winfo_width() >= 1100 else 2
        for c in range(cols):
            cards_host.columnconfigure(c, weight=1, uniform='hybridcards')

        for idx, tool in enumerate(ordered):
            tid = tool.get('id')
            card = self.card(cards_host)
            card.grid(row=idx // cols, column=idx % cols, sticky='nsew', padx=5, pady=4)
            v = tool_validation(tool)
            top = ttk.Frame(card, style='Panel.TFrame')
            top.pack(fill='x')
            icon = '🟢' if v.get('ready') else ('🟡' if tool.get('status') == 'future' else '🔴')
            ttk.Label(top, text=f"{icon} {self.tr_tool(tool, 'name')}", style='Panel.TLabel',
                      font=('Segoe UI Semibold', max(10, int(self.ui_scale * 12)))).pack(side='left')
            ttk.Label(top, text=f"v{tool.get('version', '')}", style='Muted.TLabel').pack(side='right')
            ttk.Label(card, text=self.tr_tool(tool, 'description'), style='Muted.TLabel',
                      wraplength=360).pack(anchor='w', pady=(2, 5))

            status_row = ttk.Frame(card, style='Panel.TFrame')
            status_row.pack(fill='x')
            if tid in self.AUTO_TOOL_ORDER:
                var = tk.BooleanVar(value=bool(saved.get(tid, True)))
                self.auto_tool_vars[tid] = var
                ttk.Checkbutton(status_row, text=self.t('hybrid_use_drop'), variable=var,
                                command=self._save_auto_tool_selection).pack(side='left')
                status = ttk.Label(status_row, text=self.t('hybrid_ready_drop'), style='Muted.TLabel')
                status.pack(side='right')
                self.auto_result_widgets[tid] = status
            else:
                ttk.Label(status_row, text=self.t('hybrid_direct_only'), style='Muted.TLabel').pack(side='right')

            actions = ttk.Frame(card, style='Panel.TFrame')
            actions.pack(fill='x', pady=(5, 0))
            ttk.Button(
                actions, text='▶ ' + self.t('launch'), style='Accent.TButton',
                command=lambda t=tool: self.launch_tool(t),
                state='normal' if v.get('ready') else 'disabled'
            ).pack(side='left', ipadx=9, ipady=2)
            ttk.Button(actions, text=self.t('information'), command=lambda t=tool: self.show_tool_info(t)).pack(side='right')

        # --- Compact shared dataset result panel. ---
        summary = self.card(outer, self.t('hybrid_dataset_routing'))
        summary.pack(fill='both', expand=True, pady=(2, 0))
        self.auto_summary_var = tk.StringVar(value=self.t('hybrid_no_dataset'))
        ttk.Label(summary, textvariable=self.auto_summary_var, style='Panel.TLabel', justify='left',
                  wraplength=1000).pack(anchor='w', fill='x')
        result_actions = ttk.Frame(summary, style='Panel.TFrame')
        result_actions.pack(fill='x', pady=(5, 4))
        ttk.Button(result_actions, text=self.t('hybrid_open_detected'), style='Accent.TButton',
                   command=self._create_handoffs_and_launch).pack(side='left')
        ttk.Button(result_actions, text=self.t('hybrid_select_all'), command=lambda: self.set_auto_tool_checks(True)).pack(side='left', padx=5)
        ttk.Button(result_actions, text=self.t('hybrid_clear_all'), command=lambda: self.set_auto_tool_checks(False)).pack(side='left', padx=5)
        self.auto_details = scrolledtext.ScrolledText(summary, height=4, wrap='word', font=('Consolas', 8))
        self.auto_details.pack(fill='both', expand=True)
        self.auto_details.insert('1.0', self.t('hybrid_drop_details'))
        self.auto_details.configure(state='disabled')

        # Restore the last routing result when returning to Home without re-scanning.
        if self.auto_analysis_session:
            self.after_idle(lambda: self._render_auto_analysis_result(self.auto_analysis_session, allow_auto_launch=False))
        ttk.Frame(outer, height=10, style='Panel.TFrame').pack(fill='x')
        self.after_idle(_sync_tools_scrollregion)
        self.after_idle(lambda: tools_canvas.yview_moveto(0.0))

        self.set_status('Tools ready' + ('' if DND_AVAILABLE else ' - drag/drop unavailable; use Select ZIP / Folder'))


    def tool_row(self, parent, tool, compact=False):
        row = ttk.Frame(parent, style='Panel.TFrame')
        row.pack(fill='x', pady=4)
        mark = '✓' if tool_is_ready(tool) else ('…' if tool.get('status') == 'future' else '!')
        ttk.Label(row, text=f"{mark} {self.tr_tool(tool, 'name')}", style='Panel.TLabel', font=('Segoe UI Semibold', max(9, int(self.ui_scale * 10)))).pack(side='left')
        ttk.Label(row, text=tool.get('version', ''), style='Muted.TLabel').pack(side='left', padx=10)
        if not compact:
            ttk.Label(row, text=self.tr_tool(tool, 'description'), style='Muted.TLabel').pack(side='left', padx=10)
        ttk.Button(row, text=self.t('launch'), command=lambda t=tool: self.launch_tool(t)).pack(side='right')
        ttk.Button(row, text='★' if tool.get('id') in self.cfg.get('favorites', []) else '☆', command=lambda t=tool: self.toggle_favorite(t)).pack(side='right', padx=4)

    def tool_mini_card(self, parent, tool):
        f = self.card(parent)
        v = tool_validation(tool)
        icon = '🟢' if v.get('ready') else ('🟡' if tool.get('status') == 'future' else '🔴')
        ttk.Label(f, text=f"{icon} {self.tr_tool(tool, 'name')}", style='Panel.TLabel', font=('Segoe UI Semibold', 12)).pack(anchor='w')
        ttk.Label(f, text=f"v{tool.get('version', '')}  |  {v.get('status')}", style='Muted.TLabel').pack(anchor='w', pady=(2, 6))
        row = ttk.Frame(f, style='Panel.TFrame')
        row.pack(fill='x')
        ttk.Button(row, text='▶ ' + self.t('launch'), style='Accent.TButton', command=lambda t=tool: self.launch_tool(t), state='normal' if v.get('ready') else 'disabled').pack(side='left', ipadx=12, ipady=3)
        ttk.Button(row, text='★' if tool.get('id') in self.cfg.get('favorites', []) else '☆', command=lambda t=tool: self.toggle_favorite(t)).pack(side='right')
        return f

    def show_tools(self):
        return self._show_unified_tools_page()

    def tool_card(self, parent, tool, cols=2):
        v = tool_validation(tool)
        f = self.card(parent)
        f.columnconfigure(0, weight=1)

        header = ttk.Frame(f, style='Panel.TFrame')
        header.pack(fill='x')
        name = self.tr_tool(tool, 'name')
        icon = '🟢' if v.get('ready') else ('🟡' if tool.get('status') == 'future' else '🔴')
        ttk.Label(header, text=f"{icon} {name}", style='Panel.TLabel', font=('Segoe UI Semibold', max(11, int(self.ui_scale * 13)))).pack(side='left', anchor='w')
        ttk.Label(header, text=f"v{tool.get('version', '')}", style='Muted.TLabel').pack(side='right', anchor='e')

        meta = ttk.Frame(f, style='Panel.TFrame')
        meta.pack(fill='x', pady=(3, 2))
        status_text = self.t('future') if tool.get('status') == 'future' else (self.t('status_ready') if v.get('ready') else self.t('missing'))
        ttk.Label(meta, text=f"• {status_text}", foreground=self.theme['ok'] if v.get('ready') else self.theme['warn'], background=self.theme['panel'], font=('Segoe UI', max(9, int(self.ui_scale*10)))).pack(side='left')
        source = tool.get('_version_source', 'manifest.json' if tool.get('_manifest_path') else 'config.json')
        ttk.Label(meta, text=f"  {self.t('version_source') if 'version_source' in self.lang else 'Source'}: {source}", style='Muted.TLabel').pack(side='right')

        desc = self.tr_tool(tool, 'description')
        if desc:
            ttk.Label(f, text=desc, style='Muted.TLabel', wraplength=360 if cols >= 2 else 620).pack(anchor='w', pady=(2, 4))

        buttons = ttk.Frame(f, style='Panel.TFrame')
        buttons.pack(fill='x', pady=(2, 0))
        launch_state = 'normal' if v.get('ready') else 'disabled'
        ttk.Button(buttons, text='▶ ' + self.t('launch'), style='Accent.TButton', command=lambda x=tool: self.launch_tool(x), state=launch_state).pack(side='left', padx=(0, 4), ipadx=10, ipady=3)
        ttk.Button(buttons, text=self.t('details') if 'details' in self.lang else 'Details', command=lambda: toggle_details()).pack(side='left', padx=4)
        ttk.Button(buttons, text=self.t('information'), command=lambda x=tool: self.show_tool_info(x)).pack(side='left', padx=4)
        ttk.Button(buttons, text='★' if tool.get('id') in self.cfg.get('favorites', []) else '☆', command=lambda x=tool: self.toggle_favorite(x)).pack(side='right')

        detail_frame = ttk.Frame(f, style='Panel.TFrame')
        def toggle_details(df=detail_frame, t=tool, val=v):
            if df.winfo_ismapped():
                df.pack_forget()
                return
            for child in df.winfo_children():
                child.destroy()
            ttk.Separator(df).pack(fill='x', pady=5)
            detail_text = (
                f"{self.t('build') if 'build' in self.lang else 'Build'}: {t.get('build','N/A')}\n"
                f"{self.t('manifest') if 'manifest' in self.lang else 'Manifest'}: {t.get('_manifest_path', 'config.json')}\n"
                f"Version Source: {t.get('_version_source', 'manifest.json')}\n"
                f"Manifest Version: {t.get('_manifest_version', t.get('version',''))}\n"
                f"EXE: {tool_abs_path(t)}\n"
                f"{self.t('folder')}: {tool_folder_path(t)}\n"
                f"{self.t('details') if 'details' in self.lang else 'Details'}: {val.get('detail','')}"
            )
            ttk.Label(df, text=detail_text, style='Muted.TLabel', justify='left', wraplength=420 if cols >= 2 else 700).pack(anchor='w')
            extra = ttk.Frame(df, style='Panel.TFrame')
            extra.pack(fill='x', pady=(5, 0))
            ttk.Button(extra, text=self.t('folder'), command=lambda x=t: self.open_path(tool_folder_path(x))).pack(side='left', padx=(0,4))
            ttk.Button(extra, text=self.t('install_zip'), command=lambda x=t: self.install_tool_zip(x), state='disabled' if t.get('status') == 'future' else 'normal').pack(side='left', padx=4)
            df.pack(fill='x', pady=(4, 0))
        return f

    def launch_tool(self, tool, handoff_path=None):
        if tool.get('status') == 'future' or not tool.get('enabled'):
            self.show_coming_soon(tool.get('name', 'Tool'))
            return
        exe, resolution_detail = resolve_tool_executable(tool)
        if not exe.exists():
            messagebox.showerror('Not found', f'Executable not found:\n{exe}\n\nPlace the EXE under the configured tool folder.')
            self.set_status(f"Missing tool: {tool.get('name')}")
            return
        try:
            command = [str(exe)]
            launch_env = os.environ.copy()
            if handoff_path:
                handoff_text = str(Path(handoff_path).resolve())
                command.extend(['--handoff', handoff_text])
                # Dual handoff channel for tools that consume either argv or environment.
                launch_env['INSIGHTEC_HANDOFF'] = handoff_text
                launch_env['INSIGHTEC_AUTO_LOAD'] = '1'
                try:
                    payload = json.loads(Path(handoff_text).read_text(encoding='utf-8'))
                    matched = [str(Path(x)) for x in payload.get('matched_files', []) if x]
                    launch_env['INSIGHTEC_MATCHED_FILES_JSON'] = json.dumps(matched, ensure_ascii=False)
                    if matched:
                        launch_env['INSIGHTEC_PRIMARY_INPUT'] = matched[0]
                except Exception:
                    pass
            process = subprocess.Popen(command, cwd=str(exe.parent), shell=False, env=launch_env)
            # Windowed EXEs can fail immediately when a DLL/plugin is missing.
            # Report that as a launch failure instead of falsely saying "Launched".
            time.sleep(0.35)
            return_code = process.poll()
            if return_code is not None and return_code != 0:
                raise RuntimeError(
                    f"{self.tr_tool(tool, 'name')} exited immediately with code {return_code}. "
                    f"Runtime: {exe.parent}"
                )
            self.write_session('Launch Tool', f"{tool.get('name')} | {exe} | {resolution_detail}")
            recent = self.cfg.setdefault('recent_tools', [])
            recent.insert(0, {'id': tool.get('id'), 'name': tool.get('name'), 'time': datetime.now().strftime('%Y-%m-%d %H:%M')})
            self.cfg['recent_tools'] = recent[:10]
            save_config(self.cfg)
            self.set_status(f"Launched: {tool.get('name')}")
        except Exception as e:
            self.set_status(f"Launch failed: {e}")
            messagebox.showerror('Launch failed', str(e))

    def show_tool_info(self, tool):
        text = (
            f"{self.tr_tool(tool, 'name')}\n\n"
            f"{self.t('version')}: {tool.get('version','')}\n"
            f"Build: {tool.get('build','N/A')}\n"
            f"Status: {tool_validation(tool).get('status')}\n"
            f"Manifest: {tool.get('_manifest_path', 'config.json')}\n"
            f"Path: {tool_abs_path(tool)}\n"
            f"Runtime: {tool_runtime_info(tool)}\n\n"
            f"Description:\n{self.tr_tool(tool, 'description')}"
        )
        messagebox.showinfo(self.t('information'), text)

    def toggle_favorite(self, tool):
        fav = self.cfg.setdefault('favorites', [])
        tid = tool.get('id')
        if tid in fav:
            fav.remove(tid)
            self.set_status(f"Removed favorite: {tool.get('name')}")
        else:
            fav.append(tid)
            self.set_status(f"Added favorite: {tool.get('name')}")
        save_config(self.cfg)
        self.show_tools()

    def show_coming_soon(self, name):
        self.clear_content()
        self.page_title(name, self.t('future'))
        f = self.card(self.content, name)
        f.pack(fill='both', expand=True, padx=18, pady=12)
        ttk.Label(f, text=f'{name} is reserved for a future plug-in. It can be added later without changing Hub core code.', style='Panel.TLabel', font=('Segoe UI', 13), wraplength=800).pack(anchor='w', pady=10)
        ttk.Label(f, text=self.cfg.get('future_plugin_policy', ''), style='Muted.TLabel', wraplength=800).pack(anchor='w', pady=8)
        ttk.Button(f, text='Open Plugins Folder', command=lambda: self.open_path(RUN_DIR / 'plugins')).pack(anchor='w', pady=10)
        self.set_status(f'{name}: coming soon')


    # ------------------------------------------------------------------
    # Unified dataset router
    # ------------------------------------------------------------------
    AUTO_TOOL_ORDER = ['do_analysis', 'tracker_snr', 'log_explorer', 'sonication_analysis', 'fus_image_explore', 'vimeasure']
    AUTO_TOOL_LABELS = {
        'do_analysis': 'DO Analysis', 'tracker_snr': 'TrackerSNR', 'log_explorer': 'Log Explore',
        'sonication_analysis': 'Sonication Analysis', 'fus_image_explore': 'FUS Image Explore', 'vimeasure': 'VIMeasure'
    }

    def _save_auto_tool_selection(self):
        self.cfg['auto_analyzer_selected_tools'] = {tid: bool(var.get()) for tid, var in self.auto_tool_vars.items()}
        save_config(self.cfg)

    def _save_auto_analyzer_options(self):
        if self.auto_launch_var is not None:
            self.cfg['auto_analyzer_auto_launch'] = bool(self.auto_launch_var.get())
        self._save_auto_tool_selection()

    def set_auto_tool_checks(self, checked):
        for var in self.auto_tool_vars.values():
            var.set(bool(checked))
        self._save_auto_tool_selection()

    def select_recommended_tools(self):
        detections = (self.auto_analysis_session or {}).get('detections', {})
        for tid, var in self.auto_tool_vars.items():
            var.set(bool(detections.get(tid, {}).get('matched')))
        self._save_auto_tool_selection()


    def choose_auto_dataset(self):
        paths = filedialog.askopenfilenames(
            title='Select ZIP or data files',
            filetypes=[
                ('Supported data', '*.zip *.txt *.log *.dmp *.ini *.dat *.raw *.dcm *.*'),
                ('All files', '*.*'),
            ],
        )
        if paths:
            self.start_auto_analysis(list(paths))

    def choose_auto_folder(self):
        path = filedialog.askdirectory(title='Select dataset folder')
        if path:
            self.start_auto_analysis([path])

    def on_auto_dataset_drop(self, event):
        try:
            paths = list(self.tk.splitlist(event.data))
        except Exception:
            paths = [event.data.strip('{}')]
        if paths:
            self.start_auto_analysis(paths)

    def start_auto_analysis(self, paths):
        if not paths:
            return
        self._auto_analysis_generation += 1
        generation = self._auto_analysis_generation
        progress = getattr(self, 'auto_progress', None)
        if self._auto_widget_alive(progress):
            progress.start(10)
        if getattr(self, 'auto_summary_var', None) is not None:
            self.auto_summary_var.set('Inspecting dataset...')
        for status in self.auto_result_widgets.values():
            if self._auto_widget_alive(status):
                status.configure(text='Scanning')
        thread = threading.Thread(target=self._auto_analysis_worker, args=(paths, generation), daemon=True)
        thread.start()

    def _auto_analysis_worker(self, paths, generation):
        try:
            result = self._inspect_dataset(paths)
            self._auto_result_queue.put(('ok', generation, result))
        except Exception as exc:
            logger.write(traceback.format_exc())
            self._auto_result_queue.put(('error', generation, str(exc)))

    def _poll_auto_analysis_queue(self):
        """Publish background dataset-analysis results only from the Tk main thread."""
        try:
            while True:
                kind, generation, payload = self._auto_result_queue.get_nowait()
                if generation != self._auto_analysis_generation:
                    logger.write(f'Ignored stale auto-analysis result generation={generation}')
                    continue
                if kind == 'ok':
                    self._finish_auto_analysis(payload)
                else:
                    self._fail_auto_analysis(str(payload))
        except queue.Empty:
            pass
        except tk.TclError:
            return
        try:
            self.after(80, self._poll_auto_analysis_queue)
        except tk.TclError:
            return

    def _safe_extract_zip(self, zip_path, destination):
        destination = Path(destination).resolve()
        with zipfile.ZipFile(zip_path, 'r') as zf:
            for member in zf.infolist():
                target = (destination / member.filename).resolve()
                if destination not in target.parents and target != destination:
                    raise ValueError(f'Unsafe ZIP path: {member.filename}')
            zf.extractall(destination)

    def _inspect_dataset(self, source_paths):
        session_id = datetime.now().strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:6]
        workspace = Path(tempfile.gettempdir()) / 'InSightec_APAC_AutoAnalysis' / session_id
        workspace.mkdir(parents=True, exist_ok=True)
        roots, source_info = [], []
        for raw in source_paths:
            path = Path(raw)
            if not path.exists():
                continue
            source_info.append(str(path))
            if path.is_file() and path.suffix.lower() == '.zip':
                dest = workspace / ('zip_' + re.sub(r'[^A-Za-z0-9_.-]+', '_', path.stem))
                dest.mkdir(parents=True, exist_ok=True)
                self._safe_extract_zip(path, dest)
                roots.append(dest)
            else:
                roots.append(path)
        files = []
        for root in roots:
            if root.is_file():
                files.append(root)
            else:
                files.extend(p for p in root.rglob('*') if p.is_file())
        detections = {tid: {'matched': False, 'score': 0, 'files': [], 'reasons': []} for tid in self.AUTO_TOOL_ORDER}
        def hit(tid, path, reason, score=1):
            d=detections[tid]; d['matched']=True; d['score'] += score
            sp=str(path)
            if sp not in d['files'] and len(d['files']) < 500: d['files'].append(sp)
            if reason not in d['reasons']: d['reasons'].append(reason)
        for path in files:
            low_name=path.name.lower(); low_full=str(path).lower(); suffix=path.suffix.lower()
            sample=''
            if suffix in ('.txt','.log','.ini','.csv','.out','.act') and path.stat().st_size < 50*1024*1024:
                try:
                    sample=path.read_text(encoding='utf-8', errors='ignore')[:65536].lower()
                except Exception: pass
            if ('watersystem' in low_name or any(k in sample for k in ('do level','primaryflow','secondary flow','mainstate','degas_circulate'))):
                hit('do_analysis', path, 'WaterSystem / DO data', 3)
            if any(k in low_full for k in ('tracker', 'scan0', 'scan1', 'scan2', 'scan3')) or any(k in sample for k in ('tracker0','tracker1','signal','noise','snr')):
                hit('tracker_snr', path, 'Tracker / SNR data', 2)
            if any(k in low_name for k in ('psc','mrserver','gesys','review.out','csa','cga','lais')) or suffix == '.log':
                hit('log_explorer', path, 'Service log data', 2)
            if any(k in low_full for k in ('sonication','spectrummsg','cpcfiles','hydrophone','xdgeometry')) or suffix in ('.dmp','.act'):
                hit('sonication_analysis', path, 'Sonication / hydrophone data', 3)
            if suffix in ('.dcm','.ima') or any(k in low_full for k in ('mrfiles','planningct','planningmr','thermal','memp','tmap')):
                hit('fus_image_explore', path, 'DICOM / MR image data', 3)
            elif suffix in ('.raw','.dat') and any(k in low_full for k in ('mr','image','kspace','fft')):
                hit('fus_image_explore', path, 'MRI raw / FFT data', 2)
            if any(k in low_full for k in ('vimeasure','vi_measure','voltage','current')) or any(k in sample for k in ('voltage','current','iall','vall')):
                hit('vimeasure', path, 'Voltage / current measurement data', 3)
        return {'session_id': session_id, 'workspace': str(workspace), 'sources': source_info, 'roots': [str(x) for x in roots], 'file_count': len(files), 'detections': detections}

    def _auto_widget_alive(self, widget):
        try:
            return bool(widget is not None and int(widget.winfo_exists()))
        except Exception:
            return False

    def _render_auto_analysis_result(self, result, allow_auto_launch=True):
        self.auto_analysis_session = result
        matched=[]
        for tid in self.AUTO_TOOL_ORDER:
            d=result['detections'][tid]
            tool = self.get_tool_by_id(tid)
            installed = bool(tool and tool_validation(tool).get('ready'))
            if d['matched'] and installed:
                label = f"Detected | Ready ({len(d['files'])})"
            elif d['matched']:
                label = f"Detected | Missing EXE ({len(d['files'])})"
            elif installed:
                label = "Ready | No matching data"
            else:
                label = "Missing EXE | No data"
            status = self.auto_result_widgets.get(tid)
            if self._auto_widget_alive(status):
                status.configure(text=label)
            if d['matched']:
                matched.append(self.AUTO_TOOL_LABELS[tid])
        if getattr(self, 'auto_summary_var', None) is not None:
            self.auto_summary_var.set(f"{result['file_count']:,} files inspected | {len(matched)} compatible tools detected | Session {result['session_id']}")
        lines=[]
        for tid in self.AUTO_TOOL_ORDER:
            d=result['detections'][tid]
            lines.append(f"[{self.AUTO_TOOL_LABELS[tid]}] {'READY' if d['matched'] else 'NO DATA'}")
            if d['reasons']:
                lines.append('  ' + ', '.join(d['reasons']))
            for fp in d['files'][:8]:
                lines.append('  - ' + fp)
            if len(d['files']) > 8:
                lines.append(f"  ... and {len(d['files'])-8} more")
        details = getattr(self, 'auto_details', None)
        if self._auto_widget_alive(details):
            details.configure(state='normal')
            details.delete('1.0','end')
            details.insert('1.0','\n'.join(lines))
            details.configure(state='disabled')
        self._save_auto_tool_selection()
        if self.current_page == 'tools':
            # Unified Tools page: checkbox routing is authoritative. Detection
            # is advisory and never vetoes an explicitly selected tool.
            self._create_handoffs_and_launch()
        elif allow_auto_launch and self.auto_launch_var is not None and self.auto_launch_var.get():
            self._create_handoffs_and_launch()
        else:
            self.set_status('Automatic inspection complete. Open selected tools or use any card directly.')

    def _finish_auto_analysis(self, result):
        progress = getattr(self, 'auto_progress', None)
        if self._auto_widget_alive(progress):
            progress.stop()
        self._render_auto_analysis_result(result, allow_auto_launch=True)

    def _create_handoffs_and_launch(self):
        """Launch every explicitly checked tool with the same prepared dataset.

        Hybrid routing contract:
        - checkbox selection is authoritative;
        - Hub detection is advisory only;
        - each checked tool receives the complete extracted dataset roots;
        - card Launch remains a normal no-handoff launch.
        """
        result = self.auto_analysis_session or {}
        if not result or not result.get('workspace'):
            self.set_status('Drop or select a dataset before opening tools.')
            return

        self._save_auto_analyzer_options()

        selected_ids = [
            tid for tid in self.AUTO_TOOL_ORDER
            if self.auto_tool_vars.get(tid) is not None and self.auto_tool_vars[tid].get()
        ]
        if not selected_ids:
            self.set_status('Dataset prepared, but no tools are checked.')
            return

        handoff_dir = Path(result.get('workspace', '')) / 'handoff'
        handoff_dir.mkdir(parents=True, exist_ok=True)

        # All selected tools receive the same dataset roots. For a ZIP input these
        # are the safely extracted ZIP-content folders, not a Hub-filtered subset.
        dataset_roots = [str(Path(x)) for x in (result.get('roots') or []) if x]
        source_paths = [str(Path(x)) for x in (result.get('sources') or []) if x]
        launch_inputs = dataset_roots or source_paths

        launched = []
        unavailable = []
        for tid in selected_ids:
            tool = self.get_tool_by_id(tid)
            if not tool or not tool_validation(tool).get('ready'):
                unavailable.append(self.AUTO_TOOL_LABELS[tid])
                continue

            detection = result.get('detections', {}).get(tid, {})
            payload = {
                'schema': 'insightec.hybrid.handoff.v2',
                'session_id': result.get('session_id'),
                'tool_id': tid,
                'selection_policy': 'explicit_checkbox',
                'source_paths': source_paths,
                'dataset_roots': dataset_roots,
                'workspace_path': result.get('workspace'),
                # Existing tools already consume matched_files first. In Hybrid,
                # this field intentionally means the complete prepared dataset.
                'matched_files': launch_inputs,
                # Keep Hub detection separately for diagnostics/recommendations.
                'detected_files': detection.get('files', []),
                'detection_reasons': detection.get('reasons', []),
                'detection_matched': bool(detection.get('matched')),
                'auto_load': True,
                'auto_analyze': True,
                'created_at': datetime.now().isoformat(timespec='seconds'),
            }
            hp = handoff_dir / f'{tid}.json'
            hp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
            self.launch_tool(tool, hp)
            launched.append(self.AUTO_TOOL_LABELS[tid])

        msg = 'Hybrid dataset routing complete.'
        if launched:
            msg += ' Launched checked tools: ' + ', '.join(launched) + '.'
        if unavailable:
            msg += ' Missing packaged tool EXE: ' + ', '.join(unavailable) + '.'
        self.set_status(msg)

    def _fail_auto_analysis(self, message):
        progress = getattr(self, 'auto_progress', None)
        if self._auto_widget_alive(progress):
            progress.stop()
        if getattr(self, 'auto_summary_var', None) is not None:
            self.auto_summary_var.set('Analysis failed: ' + message)
        self.set_status('Auto Dataset Analyzer failed: ' + message)
        messagebox.showerror('Auto Dataset Analyzer', message)

    def show_feedback(self):
        self.current_page = 'feedback'
        self.clear_content()
        self.page_title(self.t('feedback'), 'FEU validation feedback package')
        f = self.card(self.content, self.t('feedback'))
        f.pack(fill='both', expand=True, padx=18, pady=12)

        top = ttk.Frame(f, style='Panel.TFrame')
        top.pack(fill='x')
        category_var = tk.StringVar(value='Bug Report')
        tool_var = tk.StringVar(value='InSightec APAC Service Hub')
        severity_var = tk.StringVar(value='Normal')
        reproducible_var = tk.StringVar(value='Unknown')
        mode_var = tk.StringVar(value=self.cfg.get('feedback_mode', 'template'))
        tools = ['InSightec APAC Service Hub'] + [self.tr_tool(t, 'name') for t in self.get_tools()]
        self.form_row(top, 'Category', ttk.Combobox(top, textvariable=category_var, values=['Bug Report','Feature Request','Question','Suggestion','Validation Result'], width=28, state='readonly'))
        self.form_row(top, 'Related Tool', ttk.Combobox(top, textvariable=tool_var, values=tools, width=32, state='readonly'))
        self.form_row(top, 'Severity', ttk.Combobox(top, textvariable=severity_var, values=['Low','Normal','High','Critical'], width=28, state='readonly'))
        self.form_row(top, 'Reproducible', ttk.Combobox(top, textvariable=reproducible_var, values=['Unknown','Yes','No','Sometimes'], width=28, state='readonly'))
        self.form_row(top, 'Send Mode', ttk.Combobox(top, textvariable=mode_var, values=['template','outlook'], width=28, state='readonly'))

        ttk.Label(f, text='Comment / Issue detail', style='Panel.TLabel').pack(anchor='w', pady=(12,0))
        txt = scrolledtext.ScrolledText(f, height=5, bg=self.theme['entry'], fg=self.theme['text'], insertbackground=self.theme['text'], relief='solid', borderwidth=1)
        txt.pack(fill='both', expand=True, pady=6)
        txt.insert('1.0', 'Observed behavior:\n\nSteps to reproduce:\n\nExpected behavior:\n')

        files = []
        flabel = tk.StringVar(value='No attachment selected')
        def refresh_file_label():
            flabel.set(f'{len(files)} attachment(s) selected')
        def add_files():
            selected = filedialog.askopenfilenames(title='Select screenshot/photo/log files')
            for s in selected:
                if s not in files:
                    files.append(s)
            refresh_file_label()
        def add_recent_logs():
            for log in sorted(LOG_DIR.glob('*.log'), key=lambda p: p.stat().st_mtime, reverse=True)[:5]:
                if str(log) not in files:
                    files.append(str(log))
            refresh_file_label()
        def capture_screenshot():
            try:
                from PIL import ImageGrab
                stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                path = FEEDBACK_DIR / f'screenshot_{stamp}.png'
                img = ImageGrab.grab()
                img.save(path)
                files.append(str(path))
                refresh_file_label()
                self.set_status(f'Screenshot captured: {path.name}')
            except Exception as e:
                messagebox.showwarning('Screenshot unavailable', f'Automatic screenshot capture failed. Please attach a photo or screenshot manually.\n\n{e}')
        btns = ttk.Frame(f, style='Panel.TFrame')
        btns.pack(fill='x', pady=(4,0))
        ttk.Button(btns, text='Capture Screenshot', command=capture_screenshot).pack(side='left')
        ttk.Button(btns, text='Add Screenshot / Photo / File', command=add_files).pack(side='left', padx=6)
        ttk.Button(btns, text='Attach Recent Logs', command=add_recent_logs).pack(side='left', padx=6)
        ttk.Label(f, textvariable=flabel, style='Muted.TLabel').pack(anchor='w', pady=(4,0))

        def submit():
            meta = {
                'category': category_var.get(),
                'tool': tool_var.get(),
                'severity': severity_var.get(),
                'reproducible': reproducible_var.get(),
                'mode': mode_var.get()
            }
            old_mode = self.cfg.get('feedback_mode', 'template')
            self.cfg['feedback_mode'] = mode_var.get()
            self.create_feedback(txt.get('1.0', 'end'), files, meta)
            self.cfg['feedback_mode'] = old_mode
        ttk.Button(f, text=self.t('create_feedback'), style='Accent.TButton', command=submit).pack(anchor='e', pady=(6, 2))

    def make_feedback_text(self, comment, attachments, meta=None):
        meta = meta or {}
        validation_rows = self.validate_all_tools(save_report=False)
        validation_text = '\n'.join(f"- {r['name']} v{r['version']}: {r['status']} ({r['detail']})" for r in validation_rows)
        recent = '\n'.join(str(p.name) for p in sorted(LOG_DIR.glob('*.log'), key=lambda p: p.stat().st_mtime, reverse=True)[:5])
        return f"""Service Tool Feedback / FEU Validation

To: {self.cfg.get('feedback_to', 'masakii@insightec.com')}
Subject: [{meta.get('category','Feedback')}] {meta.get('tool','InSightec APAC Service Hub')} - Hub v{self.cfg.get('console_version', '')}

Category: {meta.get('category','Feedback')}
Related tool: {meta.get('tool','InSightec APAC Service Hub')}
Severity: {meta.get('severity','Normal')}
Reproducible: {meta.get('reproducible','Unknown')}

Hub version: {self.cfg.get('console_version', '')}
Language: {self.cfg.get('language', 'en')}
Theme: {self.cfg.get('theme', '')}
PC: {platform.platform()}
Python: {platform.python_version()}
Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Normal permission update only: {self.cfg.get('normal_permission_update_only', True)}

Comment:
{comment.strip() or '(no comment)'}

Tool validation:
{validation_text or '(no tool configured)'}

Attachments to include:
{chr(10).join(attachments) if attachments else '(none selected)'}

Recent console logs:
{recent or '(no log found)'}
"""

    def _outlook_process_running(self):
        """Return True when Classic Outlook is already running."""
        if os.name != 'nt':
            return False
        try:
            flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
            result = subprocess.run(
                ['tasklist', '/FI', 'IMAGENAME eq OUTLOOK.EXE', '/NH'],
                capture_output=True,
                text=True,
                timeout=5,
                creationflags=flags,
                check=False,
            )
            return 'OUTLOOK.EXE' in (result.stdout or '').upper()
        except Exception as exc:
            logger.write(f'Outlook process check failed: {type(exc).__name__}: {exc}')
            return False

    def _outlook_prompt(self, attempt):
        code = self.cfg.get('language', 'en')
        messages = {
            'ja': (
                'Microsoft Outlook が起動していません',
                f'Outlookを使用する場合は、Microsoft Outlookを起動し、完全に開くまでお待ちください。\n\n'
                f'起動後に［OK］を押してください。\n\n確認 {attempt} / 3'
            ),
            'zh_TW': (
                'Microsoft Outlook 尚未啟動',
                f'若要使用 Outlook，請先啟動 Microsoft Outlook，並等待它完全開啟。\n\n'
                f'啟動後請按「確定」。\n\n確認 {attempt} / 3'
            ),
            'es': (
                'Microsoft Outlook no está abierto',
                f'Para usar Outlook, inicie Microsoft Outlook y espere hasta que se abra completamente.\n\n'
                f'Después, pulse Aceptar.\n\nIntento {attempt} / 3'
            ),
            'en': (
                'Microsoft Outlook is not running',
                f'To use Outlook, start Microsoft Outlook and wait until it is fully open.\n\n'
                f'Then click OK.\n\nAttempt {attempt} / 3'
            ),
        }
        title, message = messages.get(code, messages['en'])
        return messagebox.askokcancel(title, message, parent=self)

    def _outlook_fallback_notice(self):
        code = self.cfg.get('language', 'en')
        texts = {
            'ja': ('Outlookを確認できません', '3回確認しましたがOutlookを確認できませんでした。メールテンプレートを表示します。'),
            'zh_TW': ('無法偵測 Outlook', '已確認3次，但仍無法偵測 Outlook。將改為顯示郵件範本。'),
            'es': ('No se detectó Outlook', 'Outlook no se detectó después de 3 intentos. Se mostrará la plantilla de correo.'),
            'en': ('Outlook was not detected', 'Outlook was not detected after 3 attempts. The mail template will be shown instead.'),
        }
        return texts.get(code, texts['en'])

    def create_feedback(self, comment, files, meta=None):
        body = self.make_feedback_text(comment, files, meta)
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        out = FEEDBACK_DIR / f'feedback_template_{stamp}.txt'
        out.write_text(body, encoding='utf-8')
        manifest = FEEDBACK_DIR / f'feedback_manifest_{stamp}.json'
        manifest.write_text(json.dumps({'created': stamp, 'attachments': files, 'meta': meta or {}, 'template': str(out)}, indent=2, ensure_ascii=False), encoding='utf-8')

        mode = str((meta or {}).get('mode') or self.cfg.get('feedback_mode', 'template')).strip().lower()
        if mode == 'outlook':
            # Require Classic Outlook to be started by the user. Prompt up to three times.
            detected = self._outlook_process_running()
            if not detected:
                for attempt in range(1, 4):
                    if not self._outlook_prompt(attempt):
                        break
                    self.update_idletasks()
                    time.sleep(0.25)
                    if self._outlook_process_running():
                        detected = True
                        break

            if detected:
                # Outlook can take a few seconds before its COM object is ready.
                last_detail = ''
                for _ in range(6):
                    success, detail = self.try_outlook(body, files, meta)
                    if success:
                        self.set_status('Feedback draft opened in Outlook')
                        return
                    last_detail = detail
                    self.update_idletasks()
                    time.sleep(0.6)
                logger.write(f'Outlook draft creation failed after retries: {last_detail}')
            else:
                title, message = self._outlook_fallback_notice()
                messagebox.showinfo(title, message, parent=self)

        self.show_template(body)
        self.set_status(f'Feedback template created: {out.name}')

    def try_outlook(self, body, files, meta=None):
        """Open an editable Classic Outlook draft using comtypes.

        comtypes is used instead of pywin32 because it packages reliably with
        PyInstaller on Python 3.13 and does not require pythoncom hooks.
        """
        try:
            import comtypes.client

            try:
                outlook = comtypes.client.GetActiveObject('Outlook.Application')
            except Exception:
                outlook = comtypes.client.CreateObject('Outlook.Application')

            mail = outlook.CreateItem(0)
            mail.To = self.cfg.get('feedback_to', 'masakii@insightec.com')
            category = (meta or {}).get('category', 'Feedback')
            tool = (meta or {}).get('tool', 'InSightec APAC Service Hub')
            mail.Subject = f"[Hub {category}] {tool} - v{self.cfg.get('console_version', '')}"
            mail.Body = body

            attached = set()
            for item in files:
                path = Path(item)
                if path.is_file():
                    resolved = str(path.resolve())
                    key = resolved.lower()
                    if key not in attached:
                        mail.Attachments.Add(resolved)
                        attached.add(key)
            for log in sorted(LOG_DIR.glob('*.log'), key=lambda p: p.stat().st_mtime, reverse=True)[:3]:
                resolved = str(log.resolve())
                key = resolved.lower()
                if key not in attached:
                    mail.Attachments.Add(resolved)
                    attached.add(key)

            mail.Display(False)
            return True, ''
        except Exception as e:
            return False, f'{type(e).__name__}: {e}'

    def show_template(self, body):
        win = tk.Toplevel(self)
        win.title('Mail Template')
        win.geometry('820x680')
        win.configure(bg=self.theme['bg'])
        ttk.Label(win, text='Copy this template into email').pack(anchor='w', padx=14, pady=(14,4))
        box = scrolledtext.ScrolledText(win, bg=self.theme['entry'], fg=self.theme['text'], insertbackground=self.theme['text'], relief='solid', borderwidth=1)
        box.pack(fill='both', expand=True, padx=14, pady=4)
        box.insert('1.0', body)
        def copy():
            self.clipboard_clear(); self.clipboard_append(box.get('1.0', 'end'))
            self.set_status('Template copied to clipboard')
        ttk.Button(win, text=self.t('copy_template'), command=copy, style='Accent.TButton').pack(anchor='e', padx=14, pady=14)


    def release_notes_text(self):
        """Return localized release notes for the Update page."""
        return self.help_text('release_notes')

    def show_update(self):
        self.current_page = 'update'
        self.clear_content()
        self.page_title(self.t('update'), self.t('normal_permission'))

        f = self.card(self.content, self.t('update_center'))
        f.pack(fill='both', expand=True, padx=18, pady=12)

        top = ttk.Frame(f, style='Panel.TFrame')
        top.pack(fill='x')
        left = ttk.Frame(top, style='Panel.TFrame')
        left.pack(side='left', fill='both', expand=True)
        right = ttk.Frame(top, style='Panel.TFrame')
        right.pack(side='right', fill='y')

        ttk.Label(left, text=self.t('simple_update_title'), style='Section.TLabel').pack(anchor='w', pady=(0, 4))
        ttk.Label(left, text=self.t('simple_update_description'), style='Panel.TLabel', wraplength=760).pack(anchor='w', pady=(0, 12))
        ttk.Label(left, text=f"{self.t('current_version')}: {self.cfg.get('console_version','')}", style='Muted.TLabel').pack(anchor='w')
        ttk.Label(left, text=f"{self.t('latest_version')}: {self.t('manual_update_package')}", style='Muted.TLabel').pack(anchor='w', pady=(0, 8))

        ttk.Button(right, text=self.t('install_update'), style='Accent.TButton', command=self.install_upgrade_zip).pack(fill='x', pady=(0, 8), ipadx=12, ipady=5)
        ttk.Button(right, text=self.t('advanced'), command=self.prompt_developer_mode).pack(fill='x', pady=4)

        ttk.Separator(f).pack(fill='x', pady=12)
        ttk.Label(f, text=self.t('release_notes'), style='Section.TLabel').pack(anchor='w')
        notes = scrolledtext.ScrolledText(f, height=8, bg=self.theme['entry'], fg=self.theme['text'], insertbackground=self.theme['text'], relief='solid', borderwidth=1)
        notes.pack(fill='both', expand=True, pady=(6, 10))
        notes.insert('1.0', self.release_notes_text())
        notes.configure(state='disabled')

        if self.developer_mode_valid():
            ttk.Separator(f).pack(fill='x', pady=10)
            dev = self.card(f, self.t('advanced'))
            dev.pack(fill='x', pady=(0, 0))
            ttk.Label(dev, text='DEV MODE', foreground=self.theme['warn'], background=self.theme['panel'], font=('Segoe UI Semibold', 11)).pack(anchor='w', pady=(0, 6))
            row1 = ttk.Frame(dev, style='Panel.TFrame')
            row1.pack(fill='x', pady=3)
            ttk.Button(row1, text=self.t('rollback_last_upgrade'), command=self.rollback_last_upgrade).pack(side='left', padx=(0, 6))
            ttk.Button(row1, text=self.t('open_updates_folder'), command=lambda: self.open_path(UPDATES_DIR)).pack(side='left', padx=6)
            ttk.Button(row1, text=self.t('open_backups_folder'), command=lambda: self.open_path(BACKUP_DIR)).pack(side='left', padx=6)
            ttk.Button(row1, text=self.t('open_logs_folder'), command=lambda: self.open_path(LOG_DIR)).pack(side='left', padx=6)
            row2 = ttk.Frame(dev, style='Panel.TFrame')
            row2.pack(fill='x', pady=3)
            ttk.Button(row2, text=self.t('open_workspace_folder'), command=lambda: self.open_path(RUN_DIR / 'workspace')).pack(side='left', padx=(0, 6))
            ttk.Button(row2, text=self.t('run_update'), command=self.run_update_bat).pack(side='left', padx=6)
            ttk.Button(row2, text=self.t('validate_tools'), command=lambda: self.validate_all_tools(True)).pack(side='left', padx=6)
            ttk.Label(dev, text=self.t('developer_mode_timeout'), style='Muted.TLabel').pack(anchor='w', pady=(6,0))

        self.set_status(self.t('update_center_loaded'))

    def _resolve_upgrade_root(self, tmp_dir):
        root = tmp_dir
        nested = [p for p in tmp_dir.iterdir() if p.is_dir()]
        if len(nested) == 1 and not any(p.is_file() for p in tmp_dir.iterdir()):
            root = nested[0]
        return root

    def _backup_upgrade_targets(self, root, backup_dir):
        blocked = {'logs', 'workspace', 'backups', '__pycache__'}
        copied = []
        for item in root.iterdir():
            if item.name in blocked or item.name == 'upgrade_manifest.json':
                continue
            target = RUN_DIR / item.name
            if target.exists():
                try:
                    if target.is_dir():
                        shutil.copytree(target, backup_dir / item.name, dirs_exist_ok=True)
                    else:
                        shutil.copy2(target, backup_dir / item.name)
                except Exception as e:
                    logger.write(f'Backup warning for {target}: {e}')
            copied.append(item.name)
        (backup_dir / 'backup_manifest.json').write_text(json.dumps({
            'created': datetime.now().isoformat(timespec='seconds'),
            'run_dir': str(RUN_DIR),
            'items': copied
        }, indent=2, ensure_ascii=False), encoding='utf-8')
        return copied

    def _restart_command(self):
        if getattr(sys, 'frozen', False):
            return f'"{sys.executable}"'
        run_bat = RUN_DIR / 'Run_Hub.bat'
        if run_bat.exists():
            return f'"{run_bat}"'
        return f'"{sys.executable}" "{Path(__file__).resolve()}"'

    def _write_windows_apply_bat(self, source_dir, label):
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        bat_path = UPDATES_DIR / f'apply_{label}_{stamp}.bat'
        restart_cmd = self._restart_command()
        lines = [
            '@echo off',
            'setlocal',
            'title InSightec APAC Service Hub Updater',
            f'echo InSightec APAC Service Hub - applying {label}...',
            'echo Please do not close this window.',
            'timeout /t 2 /nobreak >nul',
            f'robocopy "{source_dir}" "{RUN_DIR}" /E /XD logs workspace backups __pycache__ /XF upgrade_manifest.json backup_manifest.json /NFL /NDL /NJH /NJS',
            'set RC=%ERRORLEVEL%',
            'if %RC% LEQ 7 (',
            '  echo Update applied successfully.',
            f'  start "" {restart_cmd}',
            '  exit /b 0',
            ') else (',
            '  echo Update failed. Robocopy error: %RC%',
            '  pause',
            '  exit /b %RC%',
            ')',
        ]
        bat_path.write_text('\n'.join(lines) + '\n', encoding='utf-8')
        return bat_path


    def show_update_progress(self):
        win = tk.Toplevel(self)
        win.title(self.t('updating_title'))
        win.transient(self)
        win.grab_set()
        win.configure(bg=self.theme['bg'])
        win.geometry('520x340')
        ttk.Label(win, text=self.t('updating_title'), font=('Segoe UI Semibold', 18)).pack(anchor='w', padx=24, pady=(24, 6))
        ttk.Label(win, text=self.t('updating_message'), background=self.theme['bg'], foreground=self.theme['muted']).pack(anchor='w', padx=24, pady=(0, 12))
        steps = [self.t('update_step_backup'), self.t('update_step_verify'), self.t('update_step_install'), self.t('update_step_restart')]
        vars_ = []
        for i, step in enumerate(steps):
            v = tk.StringVar(value=f"□ {step}")
            vars_.append(v)
            ttk.Label(win, textvariable=v, font=('Segoe UI', 11)).pack(anchor='w', padx=34, pady=6)
        ttk.Label(win, text=self.t('do_not_close'), background=self.theme['bg'], foreground=self.theme['warn']).pack(anchor='w', padx=24, pady=(14, 0))
        def set_step(idx, state='active'):
            prefix = '▶' if state == 'active' else ('✓' if state == 'done' else '□')
            vars_[idx].set(f"{prefix} {steps[idx]}")
            win.update_idletasks()
            win.update()
        win.set_step = set_step
        win.update()
        return win

    def install_upgrade_zip(self):
        zip_path = filedialog.askopenfilename(title=self.t('select_upgrade_zip'), filetypes=[('Upgrade ZIP', '*.zip'), ('All files', '*.*')])
        if not zip_path:
            return
        if not messagebox.askyesno(self.t('confirm_upgrade_title'), self.t('confirm_upgrade_message')):
            return
        progress = self.show_update_progress()
        progress_start = time.time()
        progress.set_step(0, 'active')
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_dir = BACKUP_DIR / f'upgrade_backup_{stamp}'
        stage_dir = UPDATES_DIR / f'staged_upgrade_{stamp}'
        backup_dir.mkdir(parents=True, exist_ok=True)
        stage_dir.mkdir(parents=True, exist_ok=True)
        tmp_dir = Path(tempfile.mkdtemp(prefix='ish_upgrade_'))
        try:
            progress.set_step(1, 'active')
            with zipfile.ZipFile(zip_path, 'r') as z:
                z.extractall(tmp_dir)
            root = self._resolve_upgrade_root(tmp_dir)
            manifest = load_json(root / 'upgrade_manifest.json', {})
            progress.set_step(1, 'done')
            self._backup_upgrade_targets(root, backup_dir)
            progress.set_step(0, 'done')
            progress.set_step(2, 'active')
            shutil.copytree(root, stage_dir, dirs_exist_ok=True)
            progress.set_step(2, 'done')
            (stage_dir / 'upgrade_applied_from.txt').write_text(str(zip_path), encoding='utf-8')
            if platform.system() == 'Windows':
                progress.set_step(3, 'active')
                bat_path = self._write_windows_apply_bat(stage_dir, 'upgrade')
                msg = self.t('upgrade_ready_restart') + f"\n\n{self.t('backup_folder')}: {backup_dir}\n{self.t('stage_folder')}: {stage_dir}"
                if manifest:
                    msg += f"\n{self.t('upgrade_version')}: {manifest.get('version', manifest.get('build', 'N/A'))}"
                elapsed = time.time() - progress_start
                if elapsed < 1.0:
                    time.sleep(1.0 - elapsed)
                progress.destroy()
                messagebox.showinfo(self.t('upgrade_ready_title'), msg)
                logger.write(f'Launching upgrade apply BAT: {bat_path}')
                os.startfile(str(bat_path))
                self.destroy()
                sys.exit(0)
            else:
                for item in root.iterdir():
                    if item.name in {'logs', 'workspace', 'backups', '__pycache__', 'upgrade_manifest.json'}:
                        continue
                    target = RUN_DIR / item.name
                    if item.is_dir():
                        shutil.copytree(item, target, dirs_exist_ok=True)
                    else:
                        shutil.copy2(item, target)
                progress.set_step(3, 'done')
                elapsed = time.time() - progress_start
                if elapsed < 1.0:
                    time.sleep(1.0 - elapsed)
                progress.destroy()
                messagebox.showinfo(self.t('upgrade_complete_title'), self.t('upgrade_complete'))
                self.set_status(self.t('upgrade_complete'))
        except Exception as e:
            try:
                progress.destroy()
            except Exception:
                pass
            logger.write(f'Upgrade failed: {e}\n{traceback.format_exc()}')
            messagebox.showerror(self.t('upgrade_failed_title'), f"{self.t('upgrade_failed')}\n\n{e}")
            self.set_status(self.t('upgrade_failed'))
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

    def rollback_last_upgrade(self):
        backups = sorted(BACKUP_DIR.glob('upgrade_backup_*'), key=lambda p: p.stat().st_mtime, reverse=True)
        if not backups:
            messagebox.showinfo(self.t('rollback_title'), self.t('rollback_no_backup'))
            return
        backup_dir = backups[0]
        if not messagebox.askyesno(self.t('rollback_title'), self.t('rollback_confirm') + f"\n\n{backup_dir}"):
            return
        try:
            if platform.system() == 'Windows':
                bat_path = self._write_windows_apply_bat(backup_dir, 'rollback')
                messagebox.showinfo(self.t('rollback_ready_title'), self.t('rollback_ready_message'))
                logger.write(f'Launching rollback apply BAT: {bat_path}')
                os.startfile(str(bat_path))
                self.destroy()
                sys.exit(0)
            else:
                for item in backup_dir.iterdir():
                    if item.name == 'backup_manifest.json':
                        continue
                    target = RUN_DIR / item.name
                    if item.is_dir():
                        shutil.copytree(item, target, dirs_exist_ok=True)
                    else:
                        shutil.copy2(item, target)
                messagebox.showinfo(self.t('rollback_title'), self.t('rollback_complete'))
                self.set_status(self.t('rollback_complete'))
        except Exception as e:
            logger.write(f'Rollback failed: {e}\n{traceback.format_exc()}')
            messagebox.showerror(self.t('rollback_title'), f"{self.t('rollback_failed')}\n\n{e}")

    def run_update_bat(self):
        bat = filedialog.askopenfilename(title='Select update BAT', filetypes=[('Batch file', '*.bat'), ('All files', '*.*')])
        if not bat:
            return
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup = BACKUP_DIR / f'config_backup_{stamp}.json'
        try:
            shutil.copy2(CONFIG_PATH, backup)
        except Exception:
            pass
        target = UPDATES_DIR / f"update_{stamp}_{Path(bat).name}"
        shutil.copy2(bat, target)
        self.set_status(f'Running update BAT with normal user permission: {target.name}')
        try:
            if platform.system() == 'Windows':
                subprocess.Popen(['cmd.exe', '/c', str(target)], cwd=str(RUN_DIR), shell=False)
            else:
                subprocess.Popen(['bash', str(target)], cwd=str(RUN_DIR))
            messagebox.showinfo('Update started', 'Update BAT started with normal user permission.\nA config backup was created before execution.')
        except Exception as e:
            self.set_status(f'Update failed: {e}')
            messagebox.showerror('Update failed', str(e))

    def show_help(self):
        self.current_page = 'help'
        self.clear_content()
        self.page_title(self.t('help'), self.t('help_subtitle'))
        outer = ttk.Frame(self.content, style='Panel.TFrame')
        outer.pack(fill='both', expand=True, padx=18, pady=12)
        tabs = ttk.Notebook(outer)
        tabs.pack(fill='both', expand=True)
        for key, title in [('release_notes', self.t('release_notes'))]:
            frame = ttk.Frame(tabs, style='Panel.TFrame')
            tabs.add(frame, text=title)
            text = scrolledtext.ScrolledText(frame, bg=self.theme['entry'], fg=self.theme['text'], insertbackground=self.theme['text'], relief='flat', font=('Segoe UI', max(9, int(self.ui_scale * 11))))
            text.pack(fill='both', expand=True, padx=8, pady=8)
            text.insert('1.0', self.help_text(key))
            text.configure(state='disabled')
        self.set_status('Help Center loaded')

    def help_text(self, key):
        lang = self.cfg.get('language', 'en')
        if key == 'quick_start':
            if lang == 'ja':
                return 'クイックスタート\n\n1. Dashboardでツール状態を確認します。\n2. Toolsで必要なEXEを起動します。\n3. Feedbackでコメントと添付をまとめます。\n4. Outlookが使えない場合はテンプレートをコピーします。\n5. Updateは通常権限のBATで実行します。'
            if lang == 'zh_TW':
                return '快速開始\n\n1. 在 Dashboard 確認工具狀態。\n2. 在 Tools 啟動需要的 EXE。\n3. 使用 Feedback 彙整註解與附件。\n4. 如果無法使用 Outlook，請複製郵件範本。\n5. Update 以一般使用者權限執行 BAT。'
            if lang == 'ko':
                return '빠른 시작\n\n1. Dashboard에서 도구 상태를 확인합니다.\n2. Tools에서 필요한 EXE를 실행합니다.\n3. Feedback에서 의견과 첨부 파일을 정리합니다.\n4. Outlook을 사용할 수 없으면 메일 템플릿을 복사합니다.\n5. Update는 일반 사용자 권한의 BAT로 실행합니다.'
            return 'Quick Start\n\n1. Check tool status in Tools.\n2. Launch an EXE from its card, or check tools and drop a ZIP.\n3. Use Feedback to collect comments and attachments.\n4. If Outlook is unavailable, copy the email template.\n5. Run updates using normal-permission BAT files.'
        if key == 'guided_tour':
            if lang == 'ja':
                return 'ガイドツアー\n\nM1ではHelp内ガイドとして実装。次の段階で画面上に吹き出しを重ねるInteractive Guideへ拡張します。\n\nTools → Feedback → Update → Settings の順で確認してください。'
            if lang == 'zh_TW':
                return '導覽\n\nM1 先以 Help 內的導覽實作。下一階段會加入畫面上的互動提示。\n\n建議順序：Tools → Feedback → Update → Settings。'
            if lang == 'ko':
                return '가이드 투어\n\nM1에서는 Help 기반 가이드로 제공합니다. 다음 단계에서 실제 UI 위에 안내 말풍선을 추가합니다.\n\n권장 순서: Tools → Feedback → Update → Settings.'
            return 'Guided Tour\n\nM1 provides this Help-based guide. The next step will add overlay callouts on the live UI.\n\nRecommended path: Tools → Feedback → Update → Settings.'
        if lang == 'ja':
            return 'リリースノート\n\nValidation Build 003.1\n- 4言語切替を追加。\n- UI、Help、Feedback、Validationの翻訳キーを追加。\n- 再起動不要のリアルタイム切替に対応。'
        if lang == 'zh_TW':
            return '版本資訊\n\nValidation Build 003.1\n- 新增四語言切換。\n- 新增 UI、Help、Feedback、Validation 翻譯鍵。\n- 支援不重新啟動的即時切換。'
        if lang == 'ko':
            return '릴리스 노트\n\nValidation Build 003.1\n- 4개 언어 전환을 추가했습니다.\n- UI, Help, Feedback, Validation 번역 키를 추가했습니다.\n- 재시작 없는 실시간 전환을 지원합니다.'
        return self.t('release_notes_text')


    def show_modules(self):
        self.current_page = 'modules'
        self.clear_content()
        self.page_title(self.t('modules') if 'modules' in self.lang else 'Modules', self.t('modules_subtitle') if 'modules_subtitle' in self.lang else 'Manage module versions, packages and channels')
        if not self.developer_mode_valid():
            wrap = self.card(self.content, self.t('developer_mode_required') if 'developer_mode_required' in self.lang else 'Developer Mode Required')
            wrap.pack(fill='both', expand=True, padx=18, pady=12)
            ttk.Label(wrap, text=self.t('developer_mode_modules_message') if 'developer_mode_modules_message' in self.lang else 'Module management is available in Developer Mode only.', style='Panel.TLabel').pack(anchor='w', pady=(0, 12))
            ttk.Button(wrap, text=self.t('advanced') if 'advanced' in self.lang else 'Advanced', style='Accent.TButton', command=lambda: (self.prompt_developer_mode(), self.show_modules())).pack(anchor='w')
            return

        outer = ttk.Frame(self.content, style='Panel.TFrame')
        outer.pack(fill='both', expand=True, padx=12, pady=10)
        left = ttk.Frame(outer, style='Panel.TFrame')
        left.pack(side='left', fill='both', expand=True, padx=(0, 10))
        right = ttk.Frame(outer, style='Panel.TFrame')
        right.pack(side='left', fill='both', expand=True)

        ttk.Label(left, text=self.t('version_manager') if 'version_manager' in self.lang else 'Version Manager', style='Section.TLabel').pack(anchor='w', padx=8, pady=(4, 8))
        columns = ('name', 'version', 'build', 'channel', 'source')
        tree = ttk.Treeview(left, columns=columns, show='headings', height=12)
        headings = {
            'name': self.t('module') if 'module' in self.lang else 'Module',
            'version': self.t('version') if 'version' in self.lang else 'Version',
            'build': self.t('build') if 'build' in self.lang else 'Build',
            'channel': self.t('channel') if 'channel' in self.lang else 'Channel',
            'source': self.t('source') if 'source' in self.lang else 'Source',
        }
        widths = {'name': 190, 'version': 90, 'build': 110, 'channel': 90, 'source': 120}
        for col in columns:
            tree.heading(col, text=headings[col])
            tree.column(col, width=widths[col], anchor='w')
        tools = self.get_tools()
        for tool in tools:
            tree.insert('', 'end', iid=tool.get('id'), values=(
                self.tr_tool(tool, 'name'),
                tool.get('version', ''),
                tool.get('build', ''),
                tool.get('channel', 'stable'),
                'manifest.json' if tool.get('_manifest_path') else 'config.json'
            ))
        tree.pack(fill='both', expand=True, padx=8, pady=(0, 8))

        btns = ttk.Frame(left, style='Panel.TFrame')
        btns.pack(fill='x', padx=8, pady=(0, 8))
        ttk.Button(btns, text=self.t('edit') if 'edit' in self.lang else 'Edit', style='Accent.TButton', command=lambda: self.edit_selected_module(tree)).pack(side='left')
        ttk.Button(btns, text=self.t('refresh') if 'refresh' in self.lang else 'Refresh', command=self.show_modules).pack(side='left', padx=6)
        ttk.Button(btns, text=self.t('open_modules_folder') if 'open_modules_folder' in self.lang else 'Open Modules Folder', command=lambda: self.open_path(RUN_DIR / 'tools')).pack(side='left', padx=6)

        ttk.Label(right, text=self.t('package_builder') if 'package_builder' in self.lang else 'Package Builder', style='Section.TLabel').pack(anchor='w', padx=8, pady=(4, 8))
        ttk.Label(right, text=self.t('package_builder_desc') if 'package_builder_desc' in self.lang else 'Create an update ZIP from a module folder. Manifest, EXE, help, language and icon files are included when present.', style='Panel.TLabel', wraplength=430).pack(anchor='w', padx=8, pady=(0, 12))
        ttk.Button(right, text=self.t('create_package') if 'create_package' in self.lang else 'Create Package', style='Accent.TButton', command=lambda: self.create_package_dialog(tree)).pack(anchor='w', padx=8, pady=(0, 8))
        ttk.Button(right, text=self.t('open_updates_folder') if 'open_updates_folder' in self.lang else 'Open Updates Folder', command=lambda: self.open_path(UPDATES_DIR)).pack(anchor='w', padx=8, pady=(0, 14))

        ttk.Label(right, text=self.t('version_history') if 'version_history' in self.lang else 'Version History', style='Section.TLabel').pack(anchor='w', padx=8, pady=(10, 8))
        self.module_history_box = scrolledtext.ScrolledText(right, height=10, bg=self.theme['entry'], fg=self.theme['text'], relief='flat', font=('Consolas', 9))
        self.module_history_box.pack(fill='both', expand=True, padx=8, pady=(0, 8))
        self.module_history_box.insert('1.0', self.t('select_module_history') if 'select_module_history' in self.lang else 'Select a module to view version history.')
        self.module_history_box.configure(state='disabled')
        tree.bind('<<TreeviewSelect>>', lambda e: self.update_module_history(tree))
        self.set_status(self.t('modules_loaded') if 'modules_loaded' in self.lang else 'Modules loaded')

    def selected_module_from_tree(self, tree):
        sel = tree.selection()
        if not sel:
            messagebox.showinfo(self.t('module_select_title') if 'module_select_title' in self.lang else 'Select Module', self.t('module_select_message') if 'module_select_message' in self.lang else 'Please select a module first.')
            return None
        return self.get_tool_by_id(sel[0])

    def update_module_history(self, tree):
        tool = self.selected_module_from_tree_no_message(tree)
        if not tool or not hasattr(self, 'module_history_box'):
            return
        lines = []
        lines.append(f"{self.tr_tool(tool, 'name')}  v{tool.get('version', '')}")
        lines.append(f"Build: {tool.get('build', '')}")
        lines.append(f"Channel: {tool.get('channel', 'stable')}")
        lines.append(f"Manifest: {tool.get('_manifest_path', 'config.json')}")
        lines.append('')
        history = tool.get('history') or []
        if not history:
            lines.append(self.t('no_version_history') if 'no_version_history' in self.lang else 'No version history recorded yet.')
        else:
            for item in history:
                if isinstance(item, dict):
                    lines.append(f"- {item.get('version','')} | {item.get('build','')} | {item.get('date','')} | {item.get('note','')}")
                else:
                    lines.append(f"- {item}")
        self.module_history_box.configure(state='normal')
        self.module_history_box.delete('1.0', 'end')
        self.module_history_box.insert('1.0', '\n'.join(lines))
        self.module_history_box.configure(state='disabled')

    def selected_module_from_tree_no_message(self, tree):
        sel = tree.selection()
        if not sel:
            return None
        return self.get_tool_by_id(sel[0])

    def edit_selected_module(self, tree):
        tool = self.selected_module_from_tree(tree)
        if not tool:
            return
        manifest_path = Path(tool.get('_manifest_path', ''))
        if not manifest_path.exists():
            messagebox.showwarning(self.t('manifest_required') if 'manifest_required' in self.lang else 'Manifest Required', self.t('manifest_required_message') if 'manifest_required_message' in self.lang else 'This module does not have a manifest.json file.')
            return
        manifest = load_json(manifest_path, {})
        win = tk.Toplevel(self)
        win.title(self.t('edit_module') if 'edit_module' in self.lang else 'Edit Module')
        win.transient(self)
        win.grab_set()
        win.configure(bg=self.theme['bg'])
        win.geometry('560x520')
        ttk.Label(win, text=self.tr_tool(tool, 'name'), font=('Segoe UI Semibold', 14)).pack(anchor='w', padx=18, pady=(18, 10))
        form = ttk.Frame(win)
        form.pack(fill='x', padx=18)
        version_var = tk.StringVar(value=str(manifest.get('version', tool.get('version', ''))))
        build_var = tk.StringVar(value=str(manifest.get('build', tool.get('build', datetime.now().strftime('%Y-%m-%d')))))
        channel_var = tk.StringVar(value=str(manifest.get('channel', tool.get('channel', 'stable'))))
        notes = tk.Text(win, height=8, bg=self.theme['entry'], fg=self.theme['text'], relief='flat')
        def row(label, widget):
            r = ttk.Frame(form)
            r.pack(fill='x', pady=6)
            ttk.Label(r, text=label, width=18).pack(side='left')
            widget.pack(side='left', fill='x', expand=True)
        row(self.t('version') if 'version' in self.lang else 'Version', ttk.Entry(form, textvariable=version_var, width=20))
        row(self.t('build') if 'build' in self.lang else 'Build', ttk.Entry(form, textvariable=build_var, width=20))
        row(self.t('channel') if 'channel' in self.lang else 'Channel', ttk.Combobox(form, textvariable=channel_var, values=['stable','beta','feu','internal'], width=18, state='readonly'))
        ttk.Label(win, text=self.t('release_notes') if 'release_notes' in self.lang else 'Release Notes').pack(anchor='w', padx=18, pady=(12, 4))
        current_note = manifest.get('release_note_text', '')
        notes.pack(fill='both', expand=True, padx=18, pady=(0, 10))
        notes.insert('1.0', current_note)
        def save_module():
            old = dict(manifest)
            manifest['version'] = version_var.get().strip() or manifest.get('version', '1.0.0')
            manifest['build'] = build_var.get().strip() or datetime.now().strftime('%Y-%m-%d')
            manifest['channel'] = channel_var.get().strip() or 'stable'
            manifest['release_note_text'] = notes.get('1.0', 'end').strip()
            history = manifest.get('history')
            if not isinstance(history, list):
                history = []
            history.append({'version': manifest['version'], 'build': manifest['build'], 'date': datetime.now().strftime('%Y-%m-%d %H:%M'), 'note': manifest.get('release_note_text','')[:120]})
            manifest['history'] = history[-20:]
            manifest['updated_at'] = datetime.now().isoformat(timespec='seconds')
            manifest['metadata_managed_by'] = 'InSightec APAC Service Hub Version Manager'
            if save_json(manifest_path, manifest):
                logger.write(f'Module manifest updated: {manifest_path} {old.get("version")} -> {manifest.get("version")}')
                messagebox.showinfo(self.t('saved') if 'saved' in self.lang else 'Saved', self.t('module_saved') if 'module_saved' in self.lang else 'Module manifest saved.')
                win.destroy()
                self.show_modules()
            else:
                messagebox.showerror(self.t('error') if 'error' in self.lang else 'Error', self.t('module_save_failed') if 'module_save_failed' in self.lang else 'Failed to save module manifest.')
        btns = ttk.Frame(win)
        btns.pack(fill='x', padx=18, pady=(0, 18))
        ttk.Button(btns, text=self.t('save') if 'save' in self.lang else 'Save', style='Accent.TButton', command=save_module).pack(side='right')
        ttk.Button(btns, text=self.t('cancel') if 'cancel' in self.lang else 'Cancel', command=win.destroy).pack(side='right', padx=8)

    def create_package_dialog(self, tree):
        tool = self.selected_module_from_tree(tree)
        if not tool:
            return
        out = self.create_module_package(tool)
        if out:
            messagebox.showinfo(self.t('package_created') if 'package_created' in self.lang else 'Package Created', f"{self.t('package_created_message') if 'package_created_message' in self.lang else 'Package created:'}\n\n{out}")
            self.open_path(out.parent)

    def create_module_package(self, tool):
        folder = tool_folder_path(tool)
        manifest_path = Path(tool.get('_manifest_path', folder / 'manifest.json'))
        if not folder.exists() or not manifest_path.exists():
            messagebox.showerror(self.t('error') if 'error' in self.lang else 'Error', self.t('manifest_required_message') if 'manifest_required_message' in self.lang else 'Module folder or manifest.json was not found.')
            return None
        manifest = load_json(manifest_path, {})
        version = str(manifest.get('version', tool.get('version', '0.0.0'))).replace(' ', '_')
        module_id = str(manifest.get('id', tool.get('id', folder.name))).replace(' ', '_')
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        package_dir = UPDATES_DIR / 'packages'
        package_dir.mkdir(parents=True, exist_ok=True)
        out = package_dir / f"{module_id}_Update_{version}_{stamp}.zip"
        manifest['package_created_at'] = datetime.now().isoformat(timespec='seconds')
        manifest['package_channel'] = manifest.get('channel', 'stable')
        with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED) as z:
            # package under tools/<foldername>/ so Install Upgrade can copy to the right place
            root_name = f"tools/{folder.name}"
            for item in folder.rglob('*'):
                if item.is_dir() or '__pycache__' in item.parts:
                    continue
                arc = f"{root_name}/{item.relative_to(folder).as_posix()}"
                z.write(item, arc)
            z.writestr('upgrade_manifest.json', json.dumps({
                'type': 'module_update',
                'module_id': module_id,
                'version': version,
                'channel': manifest.get('channel', 'stable'),
                'created_at': datetime.now().isoformat(timespec='seconds'),
                'min_hub_version': manifest.get('min_hub_version', '1.0.0')
            }, indent=2, ensure_ascii=False))
        size = out.stat().st_size
        sha = hashlib.sha256(out.read_bytes()).hexdigest()
        manifest['last_package'] = {'path': str(out), 'size': size, 'sha256': sha, 'created_at': datetime.now().isoformat(timespec='seconds')}
        save_json(manifest_path, manifest)
        logger.write(f'Module package created: {out} ({size} bytes)')
        return out

    def show_settings(self):
        self.current_page = 'settings'
        self.clear_content()
        self.page_title(self.t('settings'), self.t('settings_subtitle'))
        f = self.card(self.content, self.t('settings'))
        f.pack(fill='both', expand=True, padx=18, pady=12)
        lang_var = tk.StringVar(value=self.language_label(self.cfg.get('language', 'en')))
        theme_var = tk.StringVar(value=self.cfg.get('theme', 'insightec_light'))
        mode_var = tk.StringVar(value=self.cfg.get('feedback_mode', 'template'))
        to_var = tk.StringVar(value=self.cfg.get('feedback_to', 'masakii@insightec.com'))
        user_var = tk.StringVar(value=self.cfg.get('user_name', 'Masaki'))
        fields = ttk.Frame(f, style='Panel.TFrame')
        fields.pack(anchor='nw', fill='x')
        self.form_row(fields, self.t('language'), self.language_menu_button(fields, lang_var, lambda c: lang_var.set(self.language_label(c)), width=34))
        lang_note = ttk.Label(fields, text=self.t('language_note'), style='Muted.TLabel')
        lang_note.pack(anchor='w', padx=160, pady=(0, 8))
        self.form_row(fields, self.t('theme'), ttk.Combobox(fields, textvariable=theme_var, values=list(THEMES.keys()), width=28, state='readonly'))
        self.form_row(fields, self.t('user_name'), ttk.Entry(fields, textvariable=user_var, width=32))
        self.form_row(fields, self.t('feedback_mode'), ttk.Combobox(fields, textvariable=mode_var, values=['template', 'outlook'], width=28, state='readonly'))
        self.form_row(fields, self.t('feedback_to'), ttk.Entry(fields, textvariable=to_var, width=50))
        def save():
            requested_language = self.parse_language_value(lang_var.get())
            if not self.language_enabled(requested_language):
                messagebox.showinfo(self.t('language_not_available_title'), self.t('language_not_available_message'))
                lang_var.set(self.language_label(self.cfg.get('language', 'en')))
                return
            old_page = self.current_page
            self.cfg['startup_page'] = 'tools'
            self.cfg['language'] = requested_language
            self.cfg['theme'] = theme_var.get()
            self.cfg['feedback_mode'] = mode_var.get()
            self.cfg['feedback_to'] = to_var.get().strip()
            self.cfg['user_name'] = user_var.get().strip() or 'Service Engineer'
            save_config(self.cfg)
            self.lang = self.load_language(requested_language)
            self.theme_name = self.cfg.get('theme', 'insightec_light')
            self.theme = THEMES.get(self.theme_name, THEMES['insightec_light'])
            self.rebuild_ui(old_page)
            self.set_status(self.t('settings_saved'))
        ttk.Button(f, text=self.t('save'), command=save, style='Accent.TButton').pack(anchor='e', pady=18)
        self.translation_progress_widget(f)

    def form_row(self, parent, label, widget):
        row = ttk.Frame(parent, style='Panel.TFrame')
        row.pack(fill='x', pady=6)
        ttk.Label(row, text=label, style='Panel.TLabel', width=18).pack(side='left')
        widget.pack(side='left')

    def show_about(self):
        self.current_page = 'about'
        self.clear_content()
        self.page_title(self.t('about_system_information'), self.t('about_copy_instruction'))
        rows = self.validate_all_tools(save_report=False)
        info = [
            f"Hub: {self.cfg.get('console_name', 'InSightec APAC Service Hub')}",
            f"Build: {self.cfg.get('console_version', '')}",
            f"Build Date: {self.cfg.get('build_date', '')}",
            f"Python: {platform.python_version()}",
            f"OS: {platform.platform()}",
            f"Run Folder: {RUN_DIR}",
            '',
            'Language Status:',
            *self.language_status_lines(),
            '',
            f"Hub Log: {logger.path}",
            f"Session Log: {SESSION_LOG_PATH}",
            '',
            'Installed Tools:',
        ]
        for r in rows:
            info.append(f"- {r['name']} {r['version']}: {r['result']} / {r['status']}")
        text = '\n'.join(info)
        f = self.card(self.content, self.t('system_information'))
        f.pack(fill='both', expand=True, padx=18, pady=12)
        box = scrolledtext.ScrolledText(f, height=22, font=('Consolas', 10))
        box.pack(fill='both', expand=True)
        box.insert('1.0', text)
        box.configure(state='disabled')
        def copy_info():
            self.clipboard_clear()
            self.clipboard_append(text)
            self.set_status('System information copied')
        ttk.Button(f, text=self.t('copy_system_information'), style='Accent.TButton', command=copy_info).pack(anchor='e', pady=10)
        self.set_status(self.t('about_loaded'))

    def search(self):
        q = self.search_var.get().strip()
        if not q or q == self.t('search'):
            return
        matches = []
        low = q.lower()
        for t in self.get_tools():
            name = self.tr_tool(t, 'name')
            desc = self.tr_tool(t, 'description')
            if low in name.lower() or low in desc.lower() or low in t.get('id', '').lower():
                matches.append(t)
        self.clear_content()
        self.page_title(self.t('search_title'), q)
        f = self.card(self.content, f"{len(matches)} {self.t('tool_result_count')}")
        f.pack(fill='both', expand=True, padx=18, pady=12)
        if matches:
            for t in matches:
                self.tool_row(f, t)
        else:
            ttk.Label(f, text=self.t('no_result'), style='Panel.TLabel').pack(anchor='w')
        self.set_status(f'Search: {q}')

    def _clear_search_placeholder(self):
        if self.search_var.get() == self.t('search'):
            self.search_var.set('')

    def rebuild_ui(self, page=None):
        current = page or self.current_page
        for w in self.winfo_children():
            w.destroy()
        self._apply_style()
        self._build_shell()
        page_map = {
            'tools': self.show_tools,
            'modules': self.show_modules,
            'feedback': self.show_feedback,
            'update': self.show_update,
            'help': self.show_help,
            'settings': self.show_settings,
            'about': self.show_about,
        }
        page_map.get(current, self.show_tools)()

    def change_language(self, code):
        if code not in SUPPORTED_LANGUAGES:
            code = 'en'
        if not self.language_enabled(code):
            messagebox.showinfo(self.t('language_not_available_title'), self.t('language_not_available_message'))
            self.lang_var.set(self.language_label(self.cfg.get('language', 'en')))
            return
        self.cfg['language'] = code
        save_config(self.cfg)
        self.lang = self.load_language(code)
        self.rebuild_ui(self.current_page)
        self.set_status(f"{self.t('language_changed')}: {SUPPORTED_LANGUAGES.get(code, code)}")

    def translation_progress_widget(self, parent):
        f = ttk.Frame(parent, style='Panel.TFrame')
        f.pack(fill='x', pady=(18, 4))
        ttk.Label(f, text=self.t('translation_status'), style='Panel.TLabel', font=('Segoe UI Semibold', max(9, int(self.ui_scale * 11)))).pack(anchor='w', pady=(0, 6))
        for code in SUPPORTED_LANGUAGES:
            meta = LANGUAGE_METADATA.get(code, {})
            status = self.t('ready') if meta.get('enabled') else self.t('coming_soon')
            ttk.Label(f, text=f"{meta.get('flag','')} {meta.get('native', code):<12}  {meta.get('completion', 0)}%  -  {status}", style='Muted.TLabel').pack(anchor='w', padx=8)

    def init_parts_db(self):
        db = DB_DIR / 'parts.db'
        con = sqlite3.connect(db)
        cur = con.cursor()
        cur.execute('create table if not exists parts(part_number text, description text, system text, notes text, photo_path text)')
        con.commit()
        con.close()

    def open_path(self, path):
        try:
            if platform.system() == 'Windows':
                os.startfile(str(path))
            elif platform.system() == 'Darwin':
                subprocess.Popen(['open', str(path)])
            else:
                subprocess.Popen(['xdg-open', str(path)])
        except Exception as e:
            messagebox.showerror('Open failed', str(e))

if __name__ == '__main__':
    try:
        HubApp().mainloop()
    except Exception:
        logger.write(traceback.format_exc())
        raise
