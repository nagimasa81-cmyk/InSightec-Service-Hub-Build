# Changelog

## Commit 0008 - APAC Naming and Tool Consolidation (2026-07-25)

- Renamed the application to InSightec APAC Service Hub.
- Removed the obsolete duplicate DO analysis module and standardized the remaining module as DO Analysis.
- Standardized the tool folder as `tools/DOanalysis`.
- Renamed the MRI image analysis module and folder to FUS Image Explore / `tools/FUSImageExplore`.
- Updated English, Japanese, Spanish, Traditional Chinese, and Korean tool metadata.
- Retained GitHub/PyInstaller build BAT files and source validation.

# Commit 0005 - CI Build Stability

- Added `validate_source.py` and `02_VALIDATE_SOURCE.bat`.
- Added `requirements-build.txt` for GitHub Actions and local builds.
- Improved build metadata and release packaging.
- Updated application version to 0.5.0.
- Removed cached Python bytecode from the source package.

# Changelog

## Commit 0004.4b — Consolidated Language and Stability Fix
- Enabled Korean as a selectable runtime language.
- Expanded English, Japanese, Traditional Chinese, Korean, and Spanish to the same UI key coverage.
- Added Korean quick-start help and Korean module metadata.
- Set Outlook as the initial feedback mode.
- Removed the duplicate capitalization variant of the main Python source.
- Synchronized config, language version, and hub manifest metadata.

## Commit 0006 - FUS Image Explore Integration (2026-07-13)

- Added FUS Image Explore to the Service Hub tool launcher.
- Added `tools/FUSImageExplore/manifest.json`.
- Added multilingual tool name and description metadata.
- Added expected executable mapping: `MR_Image_Explorer_RC1.exe`.
- Updated Hub version to 0.6.0.

## Commit 0008 - Naming and Startup Performance
- Unified the DO tool display name as DO Analysis and removed legacy A/B naming references.
- Kept the display name FUS Image Explore while changing its expected executable to MR_Image_Explorer_RC1.exe.
- Added manifest/tool caching and deferred EXE version/hash inspection to explicit validation actions.
- Deferred parts database initialization until the UI is visible.
- Reduced repeated language and tool metadata disk reads during startup.

## Commit 0009 - Auto Dataset Analyzer Phase 1 (2026-07-28)
- Added ZIP/folder/multi-file drag-and-drop intake using tkinterdnd2.
- Added automatic recursive dataset inspection and safe shared ZIP extraction.
- Added checkbox selection for DO Analysis, TrackerSNR, Log Explore, Sonication Analysis, FUS Image Explore, and VIMeasure.
- Added recommended-only automatic selection and immediate multi-tool launch.
- Added per-tool handoff JSON (`--handoff`) with matched file lists.
- Added Sonication Analysis manifest placeholder.
- Added common Guide/Tour package and root version.json.


## Commit 0010 - Resilient Executable Resolution
- Integrated Sonication Replay Engine RC2-R0014 source.
- Added Hub handoff auto-load support to Sonication Analysis.
- Replaced fixed EXE-name dependency with candidate/pattern/scoring resolution.
- Added generic CI metadata and updated R4 workflow.

## Commit 0013 — VIMeasure native handoff
- Integrated VIMeasure Ver7 source and native automatic Hub loading.
- Added content-based V/I dataset recognition independent of filenames.
- Triple validation included.
