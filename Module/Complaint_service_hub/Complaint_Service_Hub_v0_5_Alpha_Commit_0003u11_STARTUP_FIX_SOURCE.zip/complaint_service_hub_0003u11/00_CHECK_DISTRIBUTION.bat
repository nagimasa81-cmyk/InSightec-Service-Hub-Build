@echo off
setlocal
cd /d "%~dp0"
echo Checking Complaint Service Hub distribution...
set ERR=0
if not exist "Complaint_Service_Hub_Launcher.exe" echo MISSING: Complaint_Service_Hub_Launcher.exe&set ERR=1
if not exist "Complaint_Service_Hub.exe" echo MISSING: Complaint_Service_Hub.exe&set ERR=1
if not exist "Complaint_Service_Hub_Updater.exe" echo MISSING: Complaint_Service_Hub_Updater.exe&set ERR=1
if not exist "config\settings.json" echo MISSING: config\settings.json&set ERR=1
if not exist "masters\translations.json" echo MISSING: masters\translations.json&set ERR=1
if "%ERR%"=="0" echo Distribution check: OK
if not "%ERR%"=="0" echo Distribution check: FAILED
pause
exit /b %ERR%
