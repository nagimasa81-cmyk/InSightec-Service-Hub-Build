@echo off
cd /d "%~dp0"
python hub_app.py
set RC=%ERRORLEVEL%
echo.
echo Exit code: %RC%
pause
exit /b %RC%
