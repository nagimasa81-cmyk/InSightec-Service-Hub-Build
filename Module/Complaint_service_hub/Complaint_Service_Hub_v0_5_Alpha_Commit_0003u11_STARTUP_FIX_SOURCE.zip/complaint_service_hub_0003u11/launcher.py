"""Stable launcher for InSightec Complaint Service Hub.

Applies a pending program update, then starts the main Hub executable.
Works both from Python source and from a Nuitka standalone distribution.
"""
from __future__ import annotations

import ctypes
import datetime
import os
import subprocess
import sys
import traceback
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
PENDING = APP_DIR / "updates" / "pending_program_update.zip"
LOG = APP_DIR / "logs" / "launcher.log"

HUB_EXE_NAMES = (
    "Complaint_Service_Hub.exe",
    "hub_app.exe",  # compatibility with older packages
)
UPDATER_EXE_NAMES = (
    "Complaint_Service_Hub_Updater.exe",
    "updater.exe",  # compatibility with older packages
)


def log(message: str) -> None:
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open("a", encoding="utf-8") as handle:
        handle.write(f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S} {message}\n")


def show_error(title: str, message: str) -> None:
    log(f"ERROR DIALOG: {title}: {message}")
    if os.name == "nt":
        try:
            ctypes.windll.user32.MessageBoxW(None, message, title, 0x10)
            return
        except Exception:
            pass
    print(f"{title}: {message}", file=sys.stderr)


def find_executable(candidates: tuple[str, ...]) -> Path | None:
    for name in candidates:
        path = APP_DIR / name
        if path.is_file():
            return path
    return None


def source_command(script_name: str, *arguments: str) -> list[str]:
    script = APP_DIR / script_name
    if not script.is_file():
        raise FileNotFoundError(f"Required file was not found: {script}")
    return [sys.executable, str(script), *arguments]


def updater_command(update_zip: Path) -> list[str]:
    executable = find_executable(UPDATER_EXE_NAMES)
    if executable is not None:
        return [str(executable), str(update_zip)]
    return source_command("updater.py", str(update_zip))


def hub_command() -> list[str]:
    executable = find_executable(HUB_EXE_NAMES)
    if executable is not None:
        return [str(executable)]
    return source_command("hub_app.py")


def main() -> int:
    try:
        os.chdir(APP_DIR)
        log(f"Launcher started. executable={sys.executable!r}, app_dir={str(APP_DIR)!r}")

        if PENDING.is_file():
            command = updater_command(PENDING)
            log("Pending update command: " + " | ".join(command))
            result = subprocess.run(command, cwd=str(APP_DIR), check=False)
            log(f"Updater returned {result.returncode}")

        command = hub_command()
        log("Hub command: " + " | ".join(command))
        process = subprocess.Popen(command, cwd=str(APP_DIR))
        log(f"Hub process started. pid={process.pid}")

        # Detect an immediate startup crash instead of silently disappearing.
        try:
            return_code = process.wait(timeout=2.0)
        except subprocess.TimeoutExpired:
            log("Hub remained active after startup grace period.")
            return 0

        if return_code != 0:
            raise RuntimeError(
                f"The Hub closed during startup with exit code {return_code}. "
                f"See {LOG} and logs\\hub_startup_error.log."
            )
        log("Hub exited normally during startup grace period.")
        return 0

    except Exception as exc:
        detail = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        log(detail.rstrip())
        show_error(
            "Complaint Service Hub - Startup Error",
            "The application could not start.\n\n"
            f"{exc}\n\n"
            f"Diagnostic log:\n{LOG}",
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
