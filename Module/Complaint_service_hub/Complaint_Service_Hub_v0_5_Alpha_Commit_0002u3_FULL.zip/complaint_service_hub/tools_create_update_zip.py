from __future__ import annotations
import sys, zipfile, datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent
kind=(sys.argv[1] if len(sys.argv)>1 else 'master').lower()
ts=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
if kind=='program':
    out=ROOT/f'Complaint_Service_Hub_Program_Update_0002u3_{ts}.zip'
    include=['hub_app.py','launcher.py','updater.py','main.py','app_version.json','manifest.json','docs/UPDATE_MODEL.txt']
else:
    out=ROOT/f'Complaint_Service_Hub_Master_Update_{ts}.zip'
    include=[]
    for folder in ['config','masters','templates','profiles']:
        include += [str(p.relative_to(ROOT)) for p in (ROOT/folder).rglob('*') if p.is_file()]
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for rel in include:
        p=ROOT/rel
        if p.exists(): z.write(p, 'complaint_service_hub/'+rel)
print(out)
