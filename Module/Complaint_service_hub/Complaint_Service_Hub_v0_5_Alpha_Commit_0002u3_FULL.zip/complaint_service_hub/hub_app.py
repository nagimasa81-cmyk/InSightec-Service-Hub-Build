from __future__ import annotations
import sys, os, json, zipfile, shutil, datetime, re
from pathlib import Path

try:
    from PySide6.QtCore import Qt, QSize
    from PySide6.QtGui import QFont
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QLabel, QPushButton, QComboBox,
        QVBoxLayout, QHBoxLayout, QGridLayout, QFrame, QMessageBox, QFileDialog,
        QDialog, QLineEdit, QFormLayout, QDialogButtonBox, QScrollArea, QTextEdit,
        QTableWidget, QTableWidgetItem, QTabWidget, QCheckBox
    )
except Exception as e:
    print('PySide6 is required. Install with: pip install PySide6')
    raise

APP_DIR = Path(__file__).resolve().parent

LANG_NAMES = {
    'en':'English', 'ja':'日本語', 'ko':'한국어', 'th':'ไทย',
    'zh-TW':'繁體中文', 'zh-CN':'简体中文'
}
COUNTRY_DEFAULT_LANG = {
    'Japan':'ja', 'Korea':'ko', 'Thailand':'th', 'Philippines':'en',
    'Taiwan':'zh-TW', 'China':'zh-CN', 'India':'en', 'Australia':'en',
    'Vietnam':'en'
}

PRIMARY = '#005DAA'
DARK = '#052A4F'
ACCENT = '#0099E5'
BG = '#F5F8FC'
CARD_BORDER = '#D7E3F1'


def read_json(path: Path, default):
    try:
        if path.exists():
            return json.load(open(path, encoding='utf-8'))
    except Exception:
        pass
    return default

def write_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    json.dump(data, open(path, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

def log(msg: str):
    p = APP_DIR / 'logs' / 'hub.log'
    p.parent.mkdir(exist_ok=True)
    with p.open('a', encoding='utf-8') as f:
        f.write(f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S} {msg}\n")

class StartupDialog(QDialog):
    def __init__(self, settings, people):
        super().__init__()
        self.setWindowTitle('Startup Selection')
        self.setModal(True)
        self.settings = settings
        self.people = people
        self.setMinimumWidth(430)
        self.setWindowFlag(Qt.WindowStaysOnTopHint, True)
        layout = QVBoxLayout(self)
        title = QLabel('InSightec Complaint Service Hub')
        title.setFont(QFont('Arial', 18, QFont.Bold))
        title.setStyleSheet(f'color:{PRIMARY};')
        layout.addWidget(title)
        form = QFormLayout()
        self.company = QComboBox()
        companies = sorted(set([p.get('company','') for p in people if p.get('company')]))
        for c in companies: self.company.addItem(c)
        self.password = QLineEdit(); self.password.setEchoMode(QLineEdit.Password); self.password.setPlaceholderText('Required for InSightec')
        self.user = QComboBox()
        self.actual_user = QComboBox(); self.actual_user.setEnabled(False)
        form.addRow('Company', self.company)
        form.addRow('Password', self.password)
        form.addRow('User', self.user)
        form.addRow('Actual User (for shared)', self.actual_user)
        layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept_checked)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.company.currentTextChanged.connect(self.refresh_users)
        if settings.get('company'):
            i=self.company.findText(settings.get('company'))
            if i>=0: self.company.setCurrentIndex(i)
        self.refresh_users()
        if settings.get('user'):
            i=self.user.findText(settings.get('user'))
            if i>=0: self.user.setCurrentIndex(i)
        self.user.currentTextChanged.connect(self.refresh_actual)
        self.refresh_actual()

    def refresh_users(self):
        comp = self.company.currentText()
        self.password.setEnabled(comp == 'InSightec')
        self.user.clear()
        users = [p.get('name','') for p in self.people if p.get('company') == comp and p.get('active', True)]
        if not users:
            users = ['Shared User']
        self.user.addItems(users)
        self.refresh_actual()

    def refresh_actual(self):
        name = self.user.currentText()
        shared = 'shared' in name.lower() or '共用' in name
        self.actual_user.setEnabled(shared)
        self.actual_user.clear()
        if shared:
            comp = self.company.currentText()
            names = [p.get('name','') for p in self.people if p.get('company') == comp and 'shared' not in p.get('name','').lower()]
            self.actual_user.addItems(names or [''])

    def accept_checked(self):
        if self.company.currentText() == 'InSightec' and self.password.text() != '5963':
            QMessageBox.warning(self, 'Password', 'Password is required for InSightec.')
            return
        if self.actual_user.isEnabled() and not self.actual_user.currentText().strip():
            QMessageBox.warning(self, 'Actual User', 'Please select actual user for shared account.')
            return
        self.settings['company'] = self.company.currentText()
        self.settings['user'] = self.user.currentText()
        self.settings['actual_user'] = self.actual_user.currentText() if self.actual_user.isEnabled() else ''
        if not self.settings.get('language') or self.settings.get('language') == 'auto':
            country = self.selected_person().get('country','')
            self.settings['language'] = COUNTRY_DEFAULT_LANG.get(country, 'en')
        self.accept()

    def selected_person(self):
        name = self.user.currentText()
        return next((p for p in self.people if p.get('name') == name and p.get('company') == self.company.currentText()), {})

class ToolCard(QFrame):
    def __init__(self, title, desc, icon, color, tag, callback):
        super().__init__()
        self.setFrameShape(QFrame.StyledPanel)
        self.setMinimumHeight(170)
        self.setStyleSheet(f'''
            QFrame {{ background:white; border:1px solid {CARD_BORDER}; border-radius:14px; }}
            QLabel {{ border:0; background:transparent; }}
            QPushButton {{ background:{color}; color:white; border:0; border-radius:7px; padding:8px 16px; font-weight:bold; }}
            QPushButton:hover {{ background:{PRIMARY}; }}
        ''')
        lay = QVBoxLayout(self); lay.setContentsMargins(20,16,20,16); lay.setSpacing(8)
        header=QHBoxLayout()
        icon_l=QLabel(icon); icon_l.setFont(QFont('Arial',22)); icon_l.setStyleSheet(f'color:{color};')
        title_l=QLabel(title); title_l.setFont(QFont('Arial',16,QFont.Bold)); title_l.setStyleSheet(f'color:{color};')
        header.addWidget(icon_l); header.addWidget(title_l); header.addStretch()
        lay.addLayout(header)
        d=QLabel(desc); d.setWordWrap(True); d.setMinimumHeight(44); d.setStyleSheet('color:#27313D;')
        lay.addWidget(d)
        tag_l=QLabel(tag); tag_l.setStyleSheet('background:#EDF3FA; color:#123B66; border-radius:6px; padding:4px 8px; font-weight:bold;')
        lay.addWidget(tag_l, alignment=Qt.AlignLeft)
        lay.addStretch()
        btn=QPushButton('Start  ›'); btn.setMinimumHeight(34); btn.clicked.connect(callback)
        lay.addWidget(btn)

class ComplaintDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Complaint Tool')
        self.resize(780, 720)
        self.hospital_master = read_json(APP_DIR/'masters/hospital_master.json', [])
        layout=QVBoxLayout(self)
        form=QFormLayout()
        self.country=QComboBox(); self.country.addItems(sorted(set([h.get('country','') for h in self.hospital_master if h.get('country')]) or ['India','Japan']))
        self.hospital=QComboBox(); self.serial=QComboBox(); self.sw=QComboBox()
        self.subject=QLineEdit(); self.desc=QTextEdit(); self.desc.setMinimumHeight(150)
        self.output=QComboBox(); self.output.addItems(['Outlook','Template'])
        self.input_source=QComboBox(); self.input_source.addItems(['Direct Input','From Email / Template'])
        form.addRow('Input Source', self.input_source)
        form.addRow('Country', self.country)
        form.addRow('Hospital Name', self.hospital)
        form.addRow('Serial Number', self.serial)
        form.addRow('Software Version', self.sw)
        form.addRow('Complaint Subject', self.subject)
        form.addRow('Complaint Description', self.desc)
        form.addRow('Output Mode', self.output)
        layout.addLayout(form)
        btns=QHBoxLayout()
        for text, fn in [('Check English', self.check_english),('Generate', self.generate),('Save Record', self.save_record),('Close', self.accept)]:
            b=QPushButton(text); b.clicked.connect(fn); btns.addWidget(b)
        layout.addLayout(btns)
        self.country.currentTextChanged.connect(self.refresh_hospital)
        self.hospital.currentTextChanged.connect(self.refresh_serial)
        self.serial.currentTextChanged.connect(self.refresh_from_serial)
        self.refresh_hospital()

    def refresh_hospital(self):
        country=self.country.currentText(); self.hospital.blockSignals(True); self.hospital.clear()
        self.hospital.addItems([h['hospital_name'] for h in self.hospital_master if h.get('country')==country])
        self.hospital.blockSignals(False); self.refresh_serial()
    def refresh_serial(self):
        hname=self.hospital.currentText(); self.serial.blockSignals(True); self.serial.clear(); self.sw.clear()
        matches=[h for h in self.hospital_master if h.get('hospital_name')==hname]
        self.serial.addItems([m.get('serial','') for m in matches])
        if len(matches)==1:
            self.sw.addItems(matches[0].get('software_versions',[]))
        self.serial.blockSignals(False)
    def refresh_from_serial(self):
        serial=self.serial.currentText(); matches=[h for h in self.hospital_master if h.get('serial')==serial]
        if len(matches)==1:
            self.country.setCurrentText(matches[0].get('country',''))
            self.hospital.setCurrentText(matches[0].get('hospital_name',''))
    def text_has_non_english(self):
        text=self.subject.text()+'\n'+self.desc.toPlainText()
        return bool(re.search(r'[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af\u0e00-\u0e7f]', text))
    def check_english(self):
        if self.text_has_non_english(): QMessageBox.warning(self,'English Check','Non-English characters were detected. Please write in English.')
        else: QMessageBox.information(self,'English Check','OK. No obvious non-English characters detected.')
    def payload(self):
        return {'country':self.country.currentText(),'hospital_name':self.hospital.currentText(),'serial':self.serial.currentText(),'software_version':self.sw.currentText(),'complaint_subject':self.subject.text(),'complaint_description':self.desc.toPlainText()}
    def generate(self):
        if self.text_has_non_english():
            QMessageBox.warning(self,'English Check','Please correct non-English text before generating.'); return
        t=read_json(APP_DIR/'templates/email_template.json',{})
        p=self.payload(); subject=t.get('subject','[Complaint] {complaint_subject}').format(**p); body=t.get('body','').format(**p)
        if self.output.currentText()=='Template':
            dlg=QDialog(self); dlg.setWindowTitle('Template Preview'); dlg.resize(700,500); lay=QVBoxLayout(dlg); box=QTextEdit(); box.setPlainText('Subject: '+subject+'\n\n'+body); lay.addWidget(box); b=QPushButton('Copy to Clipboard'); b.clicked.connect(lambda: QApplication.clipboard().setText(box.toPlainText())); lay.addWidget(b); dlg.exec()
        else:
            QMessageBox.information(self,'Outlook','Outlook draft creation is placeholder in this Alpha. Template was generated in logs.')
        log('Generated complaint template: '+subject)
    def save_record(self):
        p=APP_DIR/'data'; p.mkdir(exist_ok=True); fn=p/(f"complaint_{datetime.datetime.now():%Y%m%d_%H%M%S}.json"); write_json(fn,self.payload()); QMessageBox.information(self,'Saved',f'Saved:\n{fn}')

class MasterManagerDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent); self.setWindowTitle('Master Manager'); self.resize(900,650)
        layout=QVBoxLayout(self); tabs=QTabWidget(); layout.addWidget(tabs)
        for title, path in [('People','masters/people_master.json'),('Hospital','masters/hospital_master.json'),('Recipient','masters/recipients.json'),('Salesforce Mapping','profiles/salesforce_profile_default.json')]:
            w=QWidget(); wl=QVBoxLayout(w); text=QTextEdit(); text.setPlainText(json.dumps(read_json(APP_DIR/path,{}), ensure_ascii=False, indent=2)); wl.addWidget(text)
            row=QHBoxLayout(); imp=QPushButton('Import JSON/Excel'); save=QPushButton('Save JSON'); row.addWidget(imp); row.addWidget(save); wl.addLayout(row)
            save.clicked.connect(lambda checked=False, t=text, p=path: self.save_text(t,p))
            imp.clicked.connect(lambda checked=False, t=text, title=title: self.import_file(t,title))
            tabs.addTab(w,title)
        close=QPushButton('Close'); close.clicked.connect(self.accept); layout.addWidget(close)
    def save_text(self, text, path):
        try:
            data=json.loads(text.toPlainText()); write_json(APP_DIR/path, data); QMessageBox.information(self,'Saved','Saved.')
        except Exception as e: QMessageBox.warning(self,'Error',str(e))
    def import_file(self, text, title):
        fn,_=QFileDialog.getOpenFileName(self,'Import',str(APP_DIR),'Data (*.json *.xlsx *.csv);;All (*.*)')
        if not fn: return
        if fn.lower().endswith('.json'):
            text.setPlainText(open(fn,encoding='utf-8').read())
        else:
            QMessageBox.information(self,'Import','Excel/CSV import UI is prepared. Detailed mapping will be implemented in next commit.')

class SettingsDialog(QDialog):
    def __init__(self, settings, parent=None):
        super().__init__(parent); self.settings=settings; self.setWindowTitle('Settings'); self.resize(480,320)
        lay=QVBoxLayout(self); form=QFormLayout(); self.lang=QComboBox(); [self.lang.addItem(v,k) for k,v in LANG_NAMES.items()]; self.out=QComboBox(); self.out.addItems(['Outlook','Template']); self.auto=QCheckBox('Auto Login')
        self.lang.setCurrentIndex(max(0,self.lang.findData(settings.get('language','en')))); self.out.setCurrentText(settings.get('output_mode','Outlook')); self.auto.setChecked(settings.get('auto_login',False))
        form.addRow('Language',self.lang); form.addRow('Output Mode',self.out); form.addRow('',self.auto); lay.addLayout(form)
        btn=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel); btn.accepted.connect(self.save); btn.rejected.connect(self.reject); lay.addWidget(btn)
    def save(self):
        self.settings['language']=self.lang.currentData(); self.settings['output_mode']=self.out.currentText(); self.settings['auto_login']=self.auto.isChecked(); write_json(APP_DIR/'config/settings.json', self.settings); self.accept()

class MainWindow(QMainWindow):
    def __init__(self, settings, people):
        super().__init__()
        self.settings=settings; self.people=people; self.trans=read_json(APP_DIR/'masters/translations.json', {})
        self.version=read_json(APP_DIR/'app_version.json', {})
        self.admin_mode=False
        self.setWindowTitle('InSightec Complaint Service Hub')
        self.resize(1250,780)
        self.setStyleSheet(f'QMainWindow{{background:{BG};}} QLabel{{color:#1E2937;}} QPushButton{{cursor:pointer;}}')
        self.build_ui()
        self.retranslate()
    def t(self,k):
        lang=self.settings.get('language','en')
        return self.trans.get(lang,self.trans.get('en',{})).get(k,k)
    def current_person(self):
        return next((p for p in self.people if p.get('name')==self.settings.get('user') and p.get('company')==self.settings.get('company')), {})
    def is_masaki(self):
        return 'masaki' in self.settings.get('user','').lower()
    def is_insightec(self): return self.settings.get('company')=='InSightec'
    def build_ui(self):
        central=QWidget(); self.setCentralWidget(central); root=QHBoxLayout(central); root.setContentsMargins(0,0,0,0); root.setSpacing(0)
        self.nav=QFrame(); self.nav.setFixedWidth(230); self.nav.setStyleSheet(f'QFrame{{background:{DARK};}} QLabel{{color:white;}} QPushButton{{color:white; background:transparent; border:0; text-align:left; padding:10px 16px; font-size:14px;}} QPushButton:hover{{background:#0B5D9A;}}')
        navlay=QVBoxLayout(self.nav); navlay.setContentsMargins(18,22,18,18)
        logo=QLabel('InSightec'); logo.setFont(QFont('Arial',26,QFont.Bold)); logo.setStyleSheet('color:white; font-style:italic;')
        navlay.addWidget(logo); sub=QLabel('Bringing therapy into focus'); sub.setStyleSheet('color:#DCEBFF;'); navlay.addWidget(sub)
        badge=QLabel(f"Complaint Service Hub\n{self.version.get('program','0.5 Alpha')} · Build {self.version.get('build','')}"); badge.setStyleSheet(f'background:#073B70; border:1px solid {ACCENT}; border-radius:8px; padding:12px; color:white; font-weight:bold;'); badge.setMinimumHeight(70); navlay.addWidget(badge); navlay.addSpacing(10)
        self.nav_buttons=[]
        for key, icon in [('home','🏠'),('complaint','📝'),('salesforce','☁'),('update_zip','📦'),('settings','⚙'),('template','📄'),('improvement','💡'),('system_no','➕'),('master_manager','🛠'),('log_viewer','📋'),('about','ⓘ')]:
            b=QPushButton(f'{icon}  {key}'); b.clicked.connect(lambda checked=False,k=key: self.open_tool(k)); self.nav_buttons.append((key,b)); navlay.addWidget(b)
        navlay.addStretch(); self.footer=QLabel('© InSightec'); self.footer.setStyleSheet('color:#DCEBFF;'); navlay.addWidget(self.footer)
        root.addWidget(self.nav)
        self.main=QWidget(); mainlay=QVBoxLayout(self.main); mainlay.setContentsMargins(28,24,28,10); mainlay.setSpacing(12)
        head=QHBoxLayout(); self.title=QLabel(); self.title.setFont(QFont('Arial',25,QFont.Bold)); self.title.setStyleSheet(f'color:{PRIMARY};')
        self.subtitle=QLabel(); self.subtitle.setFont(QFont('Arial',25,QFont.Bold));
        head.addWidget(self.title); head.addWidget(self.subtitle); head.addSpacing(10); self.version_label=QLabel(); head.addWidget(self.version_label); head.addStretch()
        self.output_cb=QComboBox(); self.output_cb.addItems(['Outlook','Template']); self.output_cb.setCurrentText(self.settings.get('output_mode','Outlook')); self.output_cb.currentTextChanged.connect(self.change_output)
        self.lang_cb=QComboBox(); [self.lang_cb.addItem(name,code) for code,name in LANG_NAMES.items()]; self.lang_cb.setCurrentIndex(max(0,self.lang_cb.findData(self.settings.get('language','en')))); self.lang_cb.currentIndexChanged.connect(self.change_lang)
        self.user_label=QLabel(); self.admin_btn=QPushButton('Admin Mode: OFF'); self.admin_btn.clicked.connect(self.toggle_admin); self.admin_btn.setVisible(self.is_masaki())
        for w in [QLabel('Output'), self.output_cb, QLabel('Language'), self.lang_cb, self.user_label, self.admin_btn]: head.addWidget(w)
        mainlay.addLayout(head)
        self.info=QLabel(); mainlay.addWidget(self.info)
        line=QFrame(); line.setFrameShape(QFrame.HLine); line.setStyleSheet(f'color:{CARD_BORDER};'); mainlay.addWidget(line)
        self.scroll=QScrollArea(); self.scroll.setWidgetResizable(True); self.scroll.setFrameShape(QFrame.NoFrame)
        self.content=QWidget(); self.grid=QGridLayout(self.content); self.grid.setContentsMargins(4,4,4,20); self.grid.setHorizontalSpacing(22); self.grid.setVerticalSpacing(22)
        self.scroll.setWidget(self.content); mainlay.addWidget(self.scroll,1)
        self.status=QLabel(); self.status.setStyleSheet(f'background:{DARK}; color:white; padding:8px; border-radius:4px;'); mainlay.addWidget(self.status)
        root.addWidget(self.main,1)
        self.refresh_cards()
    def allowed_tools(self):
        base=['complaint','update_zip','settings','template','improvement','system_no']
        if self.is_insightec(): base.insert(1,'salesforce')
        if self.is_masaki() and self.admin_mode: base += ['master_manager','log_viewer','about']
        return base
    def refresh_cards(self):
        while self.grid.count():
            item=self.grid.takeAt(0); w=item.widget();
            if w: w.deleteLater()
        allowed=self.allowed_tools()
        defs={
            'complaint':('Complaint','Create complaint, check English, generate Outlook mail or copy template.','📝',PRIMARY,'User tool'),
            'salesforce':('Salesforce','Auto input mapped complaint fields to Salesforce on Microsoft Edge.','☁','#10883E','InSightec user'),
            'update_zip':('Update ZIP','Load Master Update or Program Update ZIP. Backup is created automatically.','📦','#D26900','User tool'),
            'settings':('Settings','Default country, output mode, language and paths.','⚙','#008B8B','Available to all users'),
            'template':('Template','Preview the generated mail/template content.','📄','#226B8A','User tool'),
            'improvement':('Improvement','Create an improvement request mail/template.','💡','#2B9AD6','User tool'),
            'system_no':('System No.','Create a system-number addition request.','➕','#198754','User tool'),
            'master_manager':('Master Manager','Edit masters and create update ZIP package.','🛠','#5B4AA0','Admin only'),
            'log_viewer':('Log Viewer','View application logs and operation history.','📋','#1E88E5','Admin only'),
            'about':('About','Application information and version.','ⓘ','#333333','Admin only')}
        row=0; col=0
        title=QLabel(self.t('launch_pad')); title.setFont(QFont('Arial',18,QFont.Bold)); self.grid.addWidget(title,row,0,1,3); row+=1
        for k in allowed:
            title,desc,icon,color,tag=defs[k]
            c=ToolCard(self.t(k) if k in self.trans.get(self.settings.get('language','en'),{}) else title, desc, icon, color, tag, lambda key=k: self.open_tool(key))
            self.grid.addWidget(c,row,col)
            col+=1
            if col>=3: col=0; row+=1
        if self.is_masaki() and self.admin_mode:
            admin=QLabel(self.t('admin_only')); admin.setFont(QFont('Arial',15,QFont.Bold)); admin.setStyleSheet('color:#5B4AA0;'); self.grid.addWidget(admin,row,0,1,3)
    def retranslate(self):
        self.title.setText('InSightec')
        self.subtitle.setText('Complaint Service Hub')
        self.version_label.setText(f"{self.version.get('program','0.5 Alpha')} · Build {self.version.get('build','')}")
        self.info.setText(f"{self.t('company')}: {self.settings.get('company')}  |  {self.t('language')}: {LANG_NAMES.get(self.settings.get('language'),'English')}  |  {self.t('output')}: {self.settings.get('output_mode')}")
        self.user_label.setText(self.settings.get('user',''))
        self.status.setText(f"{self.t('ready')}  |  Program {self.version.get('program')} Build {self.version.get('build')}  |  Master {self.version.get('master')}  |  User {self.settings.get('user')}  |  Output {self.settings.get('output_mode')}")
        for key,b in self.nav_buttons:
            b.setVisible(key in ['home']+self.allowed_tools())
            b.setText(f"{b.text().split('  ')[0]}  {self.t(key)}")
        self.refresh_cards()
    def change_output(self, text):
        self.settings['output_mode']=text; write_json(APP_DIR/'config/settings.json', self.settings); self.retranslate()
    def change_lang(self):
        self.settings['language']=self.lang_cb.currentData(); write_json(APP_DIR/'config/settings.json', self.settings); self.retranslate()
    def toggle_admin(self):
        if not self.is_masaki(): return
        self.admin_mode=not self.admin_mode; self.admin_btn.setText('Admin Mode: ON' if self.admin_mode else 'Admin Mode: OFF'); self.admin_btn.setStyleSheet('background:#E6A700; padding:8px;' if self.admin_mode else ''); self.retranslate()
    def open_tool(self, key):
        if key=='complaint': ComplaintDialog(self).exec()
        elif key=='settings':
            if SettingsDialog(self.settings,self).exec():
                self.output_cb.setCurrentText(self.settings.get('output_mode','Outlook')); self.lang_cb.setCurrentIndex(max(0,self.lang_cb.findData(self.settings.get('language','en')))); self.retranslate()
        elif key=='update_zip': self.apply_update_zip()
        elif key=='master_manager': MasterManagerDialog(self).exec()
        elif key=='salesforce': QMessageBox.information(self,'Salesforce','Salesforce Auto Input UI is ready. Engine will be implemented after mapping validation.')
        elif key=='log_viewer': self.show_logs()
        elif key=='about': QMessageBox.information(self,'About',f"InSightec Complaint Service Hub\nProgram {self.version.get('program')}\nBuild {self.version.get('build')}\nNo Tkinter / Launcher-Hub-Updater separated")
        elif key in ('template','improvement','system_no'): QMessageBox.information(self,key, f'{key} flow is prepared. Detailed form will be added in next commits.')
    def apply_update_zip(self):
        fn,_=QFileDialog.getOpenFileName(self,'Select Update ZIP',str(APP_DIR),'ZIP Files (*.zip)')
        if not fn: return
        # detect manifest type
        try:
            with zipfile.ZipFile(fn) as z:
                names=z.namelist(); text='\n'.join(names).lower()
                is_program=('hub_app.py' in text) or ('launcher.py' in text) or ('updater.py' in text) or ('program_update' in text)
        except Exception as e:
            QMessageBox.warning(self,'Update',str(e)); return
        if is_program:
            dst=APP_DIR/'updates'/'pending_program_update.zip'; dst.parent.mkdir(exist_ok=True); shutil.copy2(fn,dst)
            QMessageBox.information(self,'Program Update','Program Update was staged. Please close Hub and start Launcher again. The Launcher will apply it before opening Hub.')
        else:
            self.apply_master_update(Path(fn))
    def apply_master_update(self, path):
        bdir=APP_DIR/'backups'/f"master_backup_{datetime.datetime.now():%Y%m%d_%H%M%S}"; bdir.mkdir(parents=True,exist_ok=True)
        try:
            with zipfile.ZipFile(path) as z:
                for n in z.namelist():
                    if n.endswith('/'): continue
                    rel=n
                    if rel.startswith('complaint_service_hub/'): rel=rel[len('complaint_service_hub/'):]
                    if not (rel.startswith('masters/') or rel.startswith('templates/') or rel.startswith('profiles/') or rel.startswith('config/')): continue
                    dst=APP_DIR/rel
                    if dst.exists():
                        (bdir/rel).parent.mkdir(parents=True,exist_ok=True); shutil.copy2(dst,bdir/rel)
                    dst.parent.mkdir(parents=True,exist_ok=True)
                    with z.open(n) as src, open(dst,'wb') as out: shutil.copyfileobj(src,out)
            QMessageBox.information(self,'Master Update','Master Update completed.')
        except Exception as e: QMessageBox.warning(self,'Master Update failed',str(e))
    def show_logs(self):
        dlg=QDialog(self); dlg.setWindowTitle('Log Viewer'); dlg.resize(800,550); lay=QVBoxLayout(dlg); box=QTextEdit(); box.setReadOnly(True); content=''
        for p in sorted((APP_DIR/'logs').glob('*.log')):
            content += f'===== {p.name} =====\n' + p.read_text(encoding='utf-8', errors='ignore')[-4000:] + '\n\n'
        box.setPlainText(content or 'No logs yet.'); lay.addWidget(box); b=QPushButton('Close'); b.clicked.connect(dlg.accept); lay.addWidget(b); dlg.exec()

def main():
    app=QApplication(sys.argv)
    app.setStyle('Fusion')
    settings=read_json(APP_DIR/'config/settings.json', {})
    people=read_json(APP_DIR/'masters/people_master.json', [])
    if not settings.get('auto_login'):
        dlg=StartupDialog(settings, people)
        if dlg.exec() != QDialog.Accepted:
            return 0
        # auto language by selected user's country when language not manually changed
        person=dlg.selected_person(); country=person.get('country','')
        if country and settings.get('language') not in LANG_NAMES:
            settings['language']=COUNTRY_DEFAULT_LANG.get(country,'en')
        write_json(APP_DIR/'config/settings.json', settings)
    win=MainWindow(settings, people); win.show()
    return app.exec()

if __name__ == '__main__':
    raise SystemExit(main())
