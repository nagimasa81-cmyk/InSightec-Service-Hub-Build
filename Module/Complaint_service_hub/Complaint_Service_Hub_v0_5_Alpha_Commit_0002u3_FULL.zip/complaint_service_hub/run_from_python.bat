@echo off
cd /d "%~dp0"
py -m pip install PySide6
py launcher.py
pause
