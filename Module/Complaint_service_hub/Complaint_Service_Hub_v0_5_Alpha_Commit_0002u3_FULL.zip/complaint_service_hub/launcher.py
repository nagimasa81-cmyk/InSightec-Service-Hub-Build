"""Launcher for InSightec Complaint Service Hub.
No tkinter / no GUI dependency. Applies pending program updates before launching Hub.
"""
from __future__ import annotations
import os, sys, subprocess, zipfile, shutil, json, datetime
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
PENDING = APP_DIR / 'updates' / 'pending_program_update.zip'
LOG = APP_DIR / 'logs' / 'launcher.log'

def log(msg: str):
    LOG.parent.mkdir(exist_ok=True)
    with LOG.open('a', encoding='utf-8') as f:
        f.write(f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S} {msg}\n")

def exe_or_py(name: str):
    exe = APP_DIR / f'{name}.exe'
    py = APP_DIR / f'{name}.py'
    if exe.exists():
        return [str(exe)]
    return [sys.executable, str(py)]

def main():
    os.chdir(APP_DIR)
    if PENDING.exists():
        log(f'Pending program update found: {PENDING}')
        rc = subprocess.call(exe_or_py('updater') + [str(PENDING)])
        log(f'Updater returned {rc}')
        if rc != 0:
            # keep going with current app; user can inspect logs
            pass
    hub_cmd = exe_or_py('hub_app')
    log('Launching Hub: ' + ' '.join(hub_cmd))
    subprocess.Popen(hub_cmd, cwd=str(APP_DIR))

if __name__ == '__main__':
    main()
