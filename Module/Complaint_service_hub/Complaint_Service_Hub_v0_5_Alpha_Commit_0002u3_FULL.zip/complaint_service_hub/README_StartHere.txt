InSightec Complaint Service Hub v0.5 Alpha - Build 0002u3

Recommended build:
1. Extract this ZIP.
2. Run 01_BUILD_EXE_NUITKA.bat on Windows.
3. Start dist\Complaint_Service_Hub\Complaint_Service_Hub_Launcher.exe.

Python test run:
- Run run_from_python.bat.

Important:
- This version does not use tkinter.
- Launcher, Hub, and Updater are separated.
- Program Update is staged and applied by Launcher on the next start.
- Master Update is applied from Hub > Update ZIP.

InSightec password: 5963
