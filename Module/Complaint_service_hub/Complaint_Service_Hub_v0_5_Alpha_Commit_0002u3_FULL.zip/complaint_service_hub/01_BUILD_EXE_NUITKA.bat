@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo InSightec Complaint Service Hub - Nuitka Build
echo Launcher + Hub + Updater separated / No Tkinter

echo ============================================================
py -m pip install --upgrade pip
py -m pip install nuitka ordered-set zstandard PySide6
if errorlevel 1 pause & exit /b 1

rmdir /s /q build 2>nul
rmdir /s /q dist 2>nul
mkdir dist

echo [1/3] Build Hub...
py -m nuitka --standalone --enable-plugin=pyside6 --windows-console-mode=disable --output-dir=build --output-filename=Complaint_Service_Hub.exe hub_app.py
if errorlevel 1 pause & exit /b 1

echo [2/3] Build Launcher...
py -m nuitka --standalone --windows-console-mode=disable --output-dir=build --output-filename=Complaint_Service_Hub_Launcher.exe launcher.py
if errorlevel 1 pause & exit /b 1

echo [3/3] Build Updater...
py -m nuitka --standalone --windows-console-mode=disable --output-dir=build --output-filename=Complaint_Service_Hub_Updater.exe updater.py
if errorlevel 1 pause & exit /b 1

mkdir dist\Complaint_Service_Hub
xcopy /E /I /Y build\hub_app.dist\* dist\Complaint_Service_Hub\ >nul
copy /Y build\launcher.dist\Complaint_Service_Hub_Launcher.exe dist\Complaint_Service_Hub\Complaint_Service_Hub_Launcher.exe >nul
copy /Y build\updater.dist\Complaint_Service_Hub_Updater.exe dist\Complaint_Service_Hub\Complaint_Service_Hub_Updater.exe >nul
copy /Y build\hub_app.dist\Complaint_Service_Hub.exe dist\Complaint_Service_Hub\Complaint_Service_Hub.exe >nul
xcopy /E /I /Y config dist\Complaint_Service_Hub\config\ >nul
xcopy /E /I /Y masters dist\Complaint_Service_Hub\masters\ >nul
xcopy /E /I /Y templates dist\Complaint_Service_Hub\templates\ >nul
xcopy /E /I /Y profiles dist\Complaint_Service_Hub\profiles\ >nul
xcopy /E /I /Y docs dist\Complaint_Service_Hub\docs\ >nul
mkdir dist\Complaint_Service_Hub\updates 2>nul
mkdir dist\Complaint_Service_Hub\backups 2>nul
mkdir dist\Complaint_Service_Hub\logs 2>nul
copy /Y app_version.json dist\Complaint_Service_Hub\app_version.json >nul
copy /Y manifest.json dist\Complaint_Service_Hub\manifest.json >nul
copy /Y README_StartHere.txt dist\Complaint_Service_Hub\README_StartHere.txt >nul

echo.
echo Build complete.
echo Run: dist\Complaint_Service_Hub\Complaint_Service_Hub_Launcher.exe
echo.
pause
