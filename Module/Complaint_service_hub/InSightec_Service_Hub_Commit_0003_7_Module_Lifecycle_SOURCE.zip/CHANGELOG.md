# CHANGELOG

## Commit 0003.7 - Module Lifecycle Management
- Added Modules page in Developer Mode.
- Added Version Manager for module manifest.json.
- Added Package Builder to generate module update ZIP files.
- Added module channel metadata: stable / beta / feu / internal.
- Added version history display.
- Expanded language strings for English, Japanese, Traditional Chinese and Spanish.
