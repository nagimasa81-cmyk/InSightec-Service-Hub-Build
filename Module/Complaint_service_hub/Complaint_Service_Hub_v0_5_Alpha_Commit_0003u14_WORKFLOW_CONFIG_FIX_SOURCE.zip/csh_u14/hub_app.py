from __future__ import annotations
import sys, os, json, zipfile, shutil, datetime, re, platform, subprocess, time
from pathlib import Path
from feedback_engine import FeedbackEngine, FeedbackRequest, build_runtime_context

try:
    from PySide6.QtCore import Qt, QSize
    from PySide6.QtGui import QFont
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QLabel, QPushButton, QComboBox,
        QVBoxLayout, QHBoxLayout, QGridLayout, QFrame, QMessageBox, QFileDialog,
        QDialog, QLineEdit, QFormLayout, QDialogButtonBox, QScrollArea, QTextEdit,
        QTableWidget, QTableWidgetItem, QTabWidget, QCheckBox, QListWidget,
        QListWidgetItem, QGroupBox
    )
except Exception as e:
    print('PySide6 is required. Install with: pip install PySide6')
    raise

APP_DIR = Path(__file__).resolve().parent

LANG_NAMES = {
    'en':'English', 'ja':'日本語', 'ko':'한국어', 'th':'ไทย',
    'zh-TW':'繁體中文', 'zh-CN':'简体中文', 'hi':'हिन्दी'
}
COUNTRY_DEFAULT_LANG = {
    'Japan':'ja', 'Korea':'ko', 'Thailand':'th', 'Philippines':'en',
    'Taiwan':'zh-TW', 'China':'zh-CN', 'India':'hi', 'Australia':'en',
    'Vietnam':'en'
}

PRIMARY = '#005DAA'
DARK = '#052A4F'
ACCENT = '#0099E5'
BG = '#F5F8FC'
CARD_BORDER = '#D7E3F1'


def read_json(path: Path, default):
    try:
        if path.exists():
            return json.load(open(path, encoding='utf-8'))
    except Exception:
        pass
    return default

def write_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    json.dump(data, open(path, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

def log(msg: str):
    p = APP_DIR / 'logs' / 'hub.log'
    p.parent.mkdir(exist_ok=True)
    with p.open('a', encoding='utf-8') as f:
        f.write(f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S} {msg}\n")

_TRANSLATIONS_CACHE = None

def ui_text(widget, key):
    """Return translated UI text using the nearest settings owner."""
    global _TRANSLATIONS_CACHE
    if _TRANSLATIONS_CACHE is None:
        _TRANSLATIONS_CACHE = read_json(APP_DIR/'masters/translations.json', {})
    current = widget
    settings = None
    while current is not None:
        settings = getattr(current, 'settings', None)
        if isinstance(settings, dict):
            break
        try:
            current = current.parent()
        except Exception:
            current = None
    if not isinstance(settings, dict):
        settings = read_json(APP_DIR/'config/settings.json', {})
    lang = settings.get('language', 'en')
    table = _TRANSLATIONS_CACHE.get(lang, _TRANSLATIONS_CACHE.get('en', {}))
    return table.get(key, _TRANSLATIONS_CACHE.get('en', {}).get(key, key))

def contains_non_english_text(text: str) -> bool:
    """Return True when alphabetic characters outside ASCII English are present."""
    for ch in text or "":
        if ch.isalpha() and not ("A" <= ch <= "Z" or "a" <= ch <= "z"):
            return True
    return False

class StartupDialog(QDialog):
    def __init__(self, settings, people):
        super().__init__()
        self.setWindowTitle(ui_text(self, 'startup_selection'))
        self.setModal(True)
        self.settings = settings
        self.people = people
        self.setMinimumWidth(430)
        self.setWindowFlag(Qt.WindowStaysOnTopHint, True)
        layout = QVBoxLayout(self)
        title = QLabel('InSightec Complaint Service Hub')
        title.setFont(QFont('Arial', 18, QFont.Bold))
        title.setStyleSheet(f'color:{PRIMARY};')
        layout.addWidget(title)
        form = QFormLayout()
        self.company = QComboBox()
        companies = sorted(set([p.get('company','') for p in people if p.get('company')]))
        for c in companies: self.company.addItem(c)
        self.password = QLineEdit(); self.password.setEchoMode(QLineEdit.Password); self.password.setPlaceholderText(ui_text(self, 'required_insightec'))
        self.user = QComboBox()
        self.actual_user = QComboBox(); self.actual_user.setEnabled(False)
        form.addRow(ui_text(self, 'company'), self.company)
        form.addRow(ui_text(self, 'password'), self.password)
        form.addRow(ui_text(self, 'user'), self.user)
        form.addRow(ui_text(self, 'actual_user_shared'), self.actual_user)
        layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept_checked)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.company.currentTextChanged.connect(self.refresh_users)
        if settings.get('company'):
            i=self.company.findText(settings.get('company'))
            if i>=0: self.company.setCurrentIndex(i)
        self.refresh_users()
        if settings.get('user'):
            i=self.user.findText(settings.get('user'))
            if i>=0: self.user.setCurrentIndex(i)
        self.user.currentTextChanged.connect(self.refresh_actual)
        self.refresh_actual()

    def refresh_users(self):
        comp = self.company.currentText()
        self.password.setEnabled(comp == 'InSightec')
        self.user.clear()
        users = [p.get('name','') for p in self.people if p.get('company') == comp and p.get('active', True)]
        if not users:
            users = ['Shared User']
        self.user.addItems(users)
        self.refresh_actual()

    def refresh_actual(self):
        name = self.user.currentText()
        shared = 'shared' in name.lower() or '共用' in name
        self.actual_user.setEnabled(shared)
        self.actual_user.clear()
        if shared:
            comp = self.company.currentText()
            names = [p.get('name','') for p in self.people if p.get('company') == comp and 'shared' not in p.get('name','').lower()]
            self.actual_user.addItems(names or [''])

    def accept_checked(self):
        if self.company.currentText() == 'InSightec' and self.password.text() != '5963':
            QMessageBox.warning(self, ui_text(self,'password'), ui_text(self,'password_required'))
            return
        if self.actual_user.isEnabled() and not self.actual_user.currentText().strip():
            QMessageBox.warning(self, ui_text(self,'actual_user'), ui_text(self,'select_actual_user'))
            return
        self.settings['company'] = self.company.currentText()
        self.settings['user'] = self.user.currentText()
        self.settings['actual_user'] = self.actual_user.currentText() if self.actual_user.isEnabled() else ''
        if not self.settings.get('language') or self.settings.get('language') == 'auto':
            country = self.selected_person().get('country','')
            self.settings['language'] = COUNTRY_DEFAULT_LANG.get(country, 'en')
        self.accept()

    def selected_person(self):
        name = self.user.currentText()
        return next((p for p in self.people if p.get('name') == name and p.get('company') == self.company.currentText()), {})

class ToolCard(QFrame):
    def __init__(self, title, desc, icon, color, tag, callback, start_text='Start'):
        super().__init__()
        self.setFrameShape(QFrame.StyledPanel)
        self.setMinimumHeight(170)
        self.setCursor(Qt.PointingHandCursor)
        self._callback = callback
        self.setStyleSheet(f'''
            QFrame {{ background:white; border:1px solid {CARD_BORDER}; border-radius:14px; }}
            QLabel {{ border:0; background:transparent; }}
            QPushButton {{ background:{color}; color:white; border:0; border-radius:7px; padding:8px 16px; font-weight:bold; }}
            QPushButton:hover {{ background:{PRIMARY}; }}
        ''')
        lay = QVBoxLayout(self); lay.setContentsMargins(20,16,20,16); lay.setSpacing(8)
        header=QHBoxLayout()
        icon_l=QLabel(icon); icon_l.setFont(QFont('Arial',22)); icon_l.setStyleSheet(f'color:{color};')
        title_l=QLabel(title); title_l.setFont(QFont('Arial',16,QFont.Bold)); title_l.setStyleSheet(f'color:{color};')
        header.addWidget(icon_l); header.addWidget(title_l); header.addStretch()
        lay.addLayout(header)
        d=QLabel(desc); d.setWordWrap(True); d.setMinimumHeight(44); d.setStyleSheet('color:#27313D;')
        lay.addWidget(d)
        tag_l=QLabel(tag); tag_l.setStyleSheet('background:#EDF3FA; color:#123B66; border-radius:6px; padding:4px 8px; font-weight:bold;')
        lay.addWidget(tag_l, alignment=Qt.AlignLeft)
        lay.addStretch()
        btn=QPushButton(start_text + '  ›'); btn.setMinimumHeight(34)
        # QPushButton.clicked emits a boolean. Do not pass it to the tool callback,
        # otherwise it replaces the captured tool key and open_tool(False) is called.
        btn.clicked.connect(lambda checked=False: self.activate())
        lay.addWidget(btn)

    def activate(self):
        try:
            self._callback()
        except Exception as exc:
            log(f'Tool card activation failed: {exc!r}')
            QMessageBox.critical(self, ui_text(self,'launch_error'), ui_text(self,'function_start_failed') + f'\n\n{exc}')

    def mousePressEvent(self, event):
        # Make the entire card clickable, not only the Start button.
        if event.button() == Qt.LeftButton:
            self.activate()
            event.accept()
            return
        super().mousePressEvent(event)

class ComplaintDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(ui_text(self, 'complaint_tool'))
        self.resize(780, 720)
        self.hospital_master = read_json(APP_DIR/'masters/hospital_master.json', [])
        layout=QVBoxLayout(self)
        form=QFormLayout()
        self.country=QComboBox(); self.country.addItems(sorted(set([h.get('country','') for h in self.hospital_master if h.get('country')]) or ['India','Japan']))
        self.hospital=QComboBox(); self.serial=QComboBox(); self.sw=QComboBox()
        self.subject=QLineEdit(); self.desc=QTextEdit(); self.desc.setMinimumHeight(150)
        self.output=QComboBox(); self.output.addItems(['Outlook','Template'])
        self.input_source=QComboBox(); self.input_source.addItems([ui_text(self,'direct_input'),ui_text(self,'from_email_template')])
        form.addRow(ui_text(self,'input_source'), self.input_source)
        form.addRow(ui_text(self,'country'), self.country)
        form.addRow(ui_text(self,'hospital_name'), self.hospital)
        form.addRow(ui_text(self,'serial_number'), self.serial)
        form.addRow(ui_text(self,'software_version'), self.sw)
        form.addRow(ui_text(self,'complaint_subject'), self.subject)
        form.addRow(ui_text(self,'complaint_description'), self.desc)
        form.addRow(ui_text(self,'output_mode'), self.output)
        layout.addLayout(form)
        btns=QHBoxLayout()
        for text, fn in [(ui_text(self,'check_english'), self.check_english),(ui_text(self,'generate'), self.generate),(ui_text(self,'feedback'), self.open_feedback),(ui_text(self,'save_record'), self.save_record),(ui_text(self,'close'), self.accept)]:
            b=QPushButton(text); b.clicked.connect(fn); btns.addWidget(b)
        layout.addLayout(btns)
        self.country.currentTextChanged.connect(self.refresh_hospital)
        self.hospital.currentTextChanged.connect(self.refresh_serial)
        self.serial.currentTextChanged.connect(self.refresh_from_serial)
        self.refresh_hospital()

    def refresh_hospital(self):
        country=self.country.currentText(); self.hospital.blockSignals(True); self.hospital.clear()
        self.hospital.addItems([h['hospital_name'] for h in self.hospital_master if h.get('country')==country])
        self.hospital.blockSignals(False); self.refresh_serial()
    def refresh_serial(self):
        hname=self.hospital.currentText(); self.serial.blockSignals(True); self.serial.clear(); self.sw.clear()
        matches=[h for h in self.hospital_master if h.get('hospital_name')==hname]
        self.serial.addItems([m.get('serial','') for m in matches])
        if len(matches)==1:
            self.sw.addItems(matches[0].get('software_versions',[]))
        self.serial.blockSignals(False)
    def refresh_from_serial(self):
        serial=self.serial.currentText(); matches=[h for h in self.hospital_master if h.get('serial')==serial]
        if len(matches)==1:
            self.country.setCurrentText(matches[0].get('country',''))
            self.hospital.setCurrentText(matches[0].get('hospital_name',''))
    def text_has_non_english(self):
        text=self.subject.text()+'\n'+self.desc.toPlainText()
        return contains_non_english_text(text)
    def check_english(self):
        if self.text_has_non_english(): QMessageBox.warning(self,ui_text(self,'english_check'),ui_text(self,'non_english_detected'))
        else: QMessageBox.information(self,ui_text(self,'english_check'),ui_text(self,'english_check_ok'))
    def payload(self):
        return {'country':self.country.currentText(),'hospital_name':self.hospital.currentText(),'serial':self.serial.currentText(),'software_version':self.sw.currentText(),'complaint_subject':self.subject.text(),'complaint_description':self.desc.toPlainText()}
    def open_feedback(self):
        FeedbackDialog(self.parent(), complaint_context=self.payload()).exec()
    def generate(self):
        if self.text_has_non_english():
            QMessageBox.warning(self,ui_text(self,'english_check'),ui_text(self,'correct_non_english')); return
        t=read_json(APP_DIR/'templates/email_template.json',{})
        p=self.payload(); subject=t.get('subject','[Complaint] {complaint_subject}').format(**p); body=t.get('body','').format(**p)
        if self.output.currentText()=='Template':
            dlg=QDialog(self); dlg.setWindowTitle(ui_text(self,'template_preview')); dlg.resize(700,500); lay=QVBoxLayout(dlg); box=QTextEdit(); box.setPlainText('Subject: '+subject+'\n\n'+body); lay.addWidget(box); b=QPushButton(ui_text(self,'copy_clipboard')); b.clicked.connect(lambda: QApplication.clipboard().setText(box.toPlainText())); lay.addWidget(b); dlg.exec()
        else:
            QMessageBox.information(self,ui_text(self,'outlook'),ui_text(self,'outlook_placeholder'))
        log('Generated complaint template: '+subject)
    def save_record(self):
        p=APP_DIR/'data'; p.mkdir(exist_ok=True); fn=p/(f"complaint_{datetime.datetime.now():%Y%m%d_%H%M%S}.json"); write_json(fn,self.payload()); QMessageBox.information(self,ui_text(self,'saved'),ui_text(self,'saved_path')+f'\n{fn}')


class FeedbackAttachmentList(QListWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setDragDropMode(QListWidget.DropOnly)
        self.setSelectionMode(QListWidget.ExtendedSelection)
        self.setMinimumHeight(105)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event):
        if event.mimeData().hasUrls():
            for url in event.mimeData().urls():
                path = url.toLocalFile()
                if path:
                    self.add_path(path)
            event.acceptProposedAction()
        else:
            super().dropEvent(event)

    def add_path(self, path):
        path = str(Path(path))
        existing = {self.item(i).data(Qt.UserRole) for i in range(self.count())}
        if path not in existing and Path(path).is_file():
            item = QListWidgetItem(Path(path).name)
            item.setToolTip(path)
            item.setData(Qt.UserRole, path)
            self.addItem(item)

    def paths(self):
        return [self.item(i).data(Qt.UserRole) for i in range(self.count())]


class FeedbackDialog(QDialog):
    def __init__(self, parent=None, complaint_context=None):
        super().__init__(parent)
        self.parent_window = parent
        self.settings = getattr(parent, 'settings', read_json(APP_DIR/'config/settings.json', {}))
        self.version = getattr(parent, 'version', read_json(APP_DIR/'app_version.json', {}))
        self.complaint_context = complaint_context or self.load_latest_complaint()
        self.feedback_dir = APP_DIR/'feedback'
        self.feedback_dir.mkdir(parents=True, exist_ok=True)
        self.engine = FeedbackEngine(APP_DIR, self.settings.get('feedback_to','masakii@insightec.com'), APP_DIR/'logs', self.feedback_dir)
        self.setWindowTitle(ui_text(self,'feedback_title'))
        self.resize(900, 790)
        self.setAcceptDrops(True)
        layout = QVBoxLayout(self)

        intro = QLabel(ui_text(self,'feedback_intro'))
        intro.setWordWrap(True)
        intro.setStyleSheet(f'color:{PRIMARY}; font-weight:bold;')
        layout.addWidget(intro)

        form = QFormLayout()
        self.category = QComboBox(); [self.category.addItem(ui_text(self,k),v) for k,v in [('bug_report','Bug Report'),('improvement_request','Improvement Request'),('new_feature','New Feature'),('question','Question'),('validation_result','Validation Result')]]
        self.priority = QComboBox(); [self.priority.addItem(ui_text(self,k),v) for k,v in [('low','Low'),('normal','Normal'),('high','High'),('critical','Critical')]]
        self.reproducible = QComboBox(); [self.reproducible.addItem(ui_text(self,k),v) for k,v in [('unknown','Unknown'),('yes','Yes'),('no','No'),('sometimes','Sometimes')]]
        self.related_tool = QComboBox(); self.related_tool.addItems(['Complaint Service Hub','Complaint Input','Salesforce','Update ZIP','Settings','System No. Request'])
        self.mode = QComboBox(); self.mode.addItems(['Outlook','Template']); self.mode.setCurrentText(self.settings.get('feedback_mode', self.settings.get('output_mode','Outlook')).title())
        form.addRow(ui_text(self,'category'), self.category)
        form.addRow(ui_text(self,'priority'), self.priority)
        form.addRow(ui_text(self,'reproducible'), self.reproducible)
        form.addRow(ui_text(self,'related_tool'), self.related_tool)
        form.addRow(ui_text(self,'send_mode'), self.mode)
        layout.addLayout(form)

        self.context_group = QGroupBox(ui_text(self,'complaint_context_auto'))
        context_form = QFormLayout(self.context_group)
        self.context_preview = QTextEdit(); self.context_preview.setReadOnly(True); self.context_preview.setMaximumHeight(130)
        self.context_preview.setPlainText(self.context_text())
        context_form.addRow(self.context_preview)
        layout.addWidget(self.context_group)

        layout.addWidget(QLabel(ui_text(self,'comment_issue_detail')))
        self.comment = QTextEdit(); self.comment.setMinimumHeight(180)
        self.comment.setPlainText(ui_text(self,'feedback_comment_template'))
        layout.addWidget(self.comment)

        attach_row = QHBoxLayout()
        for text, fn in [(ui_text(self,'capture_screenshot'), self.capture_screenshot),(ui_text(self,'add_files'), self.add_files),(ui_text(self,'attach_recent_logs'), self.add_recent_logs),(ui_text(self,'create_validation_report'), self.create_validation_report),(ui_text(self,'remove_selected'), self.remove_selected)]:
            b=QPushButton(text); b.clicked.connect(fn); attach_row.addWidget(b)
        attach_row.addStretch()
        layout.addLayout(attach_row)
        self.attachments = FeedbackAttachmentList()
        self.attachments.setToolTip(ui_text(self,'attachment_drop_tip'))
        layout.addWidget(self.attachments)

        buttons = QDialogButtonBox(QDialogButtonBox.Cancel)
        create = QPushButton(ui_text(self,'create_feedback'))
        create.setStyleSheet(f'background:{PRIMARY}; color:white; padding:8px 18px; font-weight:bold;')
        create.clicked.connect(self.submit)
        buttons.addButton(create, QDialogButtonBox.AcceptRole)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def load_latest_complaint(self):
        files = sorted((APP_DIR/'data').glob('complaint_*.json'), key=lambda x: x.stat().st_mtime, reverse=True) if (APP_DIR/'data').exists() else []
        return read_json(files[0], {}) if files else {}

    def context_text(self):
        c=self.complaint_context or {}
        if not c:
            return ui_text(self,'no_complaint_context')
        labels=[(ui_text(self,'country'),'country'),(ui_text(self,'hospital_name'),'hospital_name'),(ui_text(self,'serial_number'),'serial'),(ui_text(self,'software_version'),'software_version'),(ui_text(self,'complaint_subject'),'complaint_subject'),(ui_text(self,'complaint'),'complaint_description')]
        return '\n'.join(f'{label}: {c.get(key, "")}' for label,key in labels)

    def add_files(self):
        files,_=QFileDialog.getOpenFileNames(self,ui_text(self,'select_attachment_files'),str(APP_DIR),'All Files (*.*)')
        for f in files: self.attachments.add_path(f)

    def capture_screenshot(self):
        try:
            screen=QApplication.primaryScreen()
            if screen is None: raise RuntimeError('No screen was detected.')
            stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            path=self.feedback_dir/f'screenshot_{stamp}.png'
            pix=screen.grabWindow(0)
            if not pix.save(str(path), 'PNG'): raise RuntimeError('Screenshot could not be saved.')
            self.attachments.add_path(path)
            QMessageBox.information(self,ui_text(self,'screenshot'),ui_text(self,'screenshot_saved')+f'\n{path.name}')
        except Exception as exc:
            QMessageBox.warning(self,ui_text(self,'screenshot_unavailable'),str(exc))

    def add_recent_logs(self):
        logs=sorted((APP_DIR/'logs').glob('*.log'), key=lambda p:p.stat().st_mtime, reverse=True)[:5]
        for item in logs: self.attachments.add_path(item)
        if not logs: QMessageBox.information(self,ui_text(self,'logs'),ui_text(self,'no_logs_found'))

    def feedback_context(self):
        return build_runtime_context(
            application='InSightec Complaint Service Hub',
            application_version=self.version.get('program',''),
            build=self.version.get('build',''),
            company=self.settings.get('company',''),
            user=self.settings.get('actual_user') or self.settings.get('user',''),
            language=self.settings.get('language',''),
            current_page='Complaint Input' if self.complaint_context else 'Feedback',
            related_tool=self.related_tool.currentText(),
            extra=self.complaint_context or {},
        )

    def create_validation_report(self):
        path = self.engine.create_validation_report(self.feedback_context())
        self.attachments.add_path(path)

    def remove_selected(self):
        for item in self.attachments.selectedItems():
            self.attachments.takeItem(self.attachments.row(item))

    def feedback_request(self):
        return FeedbackRequest(
            category=self.category.currentData() or self.category.currentText(),
            priority=self.priority.currentData() or self.priority.currentText(),
            reproducible=self.reproducible.currentData() or self.reproducible.currentText(),
            comment=self.comment.toPlainText(),
            mode=self.mode.currentText().lower(),
            attachments=self.attachments.paths(),
            context=self.feedback_context(),
        )

    def make_body(self):
        return self.engine.build_body(self.feedback_request())

    def submit(self):
        if contains_non_english_text(self.comment.toPlainText()):
            QMessageBox.warning(self, ui_text(self,'english_check'), ui_text(self,'feedback_body_must_be_english'))
            return
        request = self.feedback_request()
        body, outputs = self.engine.prepare(request)
        if contains_non_english_text(body):
            QMessageBox.warning(self, ui_text(self,'english_check'), ui_text(self,'generated_body_not_english'))
            return
        template = outputs['template']
        manifest = outputs['manifest']
        files = request.attachments
        self.settings['feedback_mode']=self.mode.currentText()
        write_json(APP_DIR/'config/settings.json', self.settings)
        if self.mode.currentText()=='Outlook':
            result, detail = self.open_outlook_with_recovery(body, files)
            if result == 'success':
                log(f'Feedback Outlook draft opened: {manifest.name}')
                QMessageBox.information(self,ui_text(self,'feedback'),ui_text(self,'feedback_opened_outlook'))
                self.accept(); return
            if result == 'cancel':
                return
            log(f'Feedback Outlook fallback to template: {detail}')
        self.show_template(body, template)

    def create_outlook_draft_once(self, body, files):
        try:
            import comtypes
            import comtypes.stream
            import comtypes.client
            try:
                outlook = comtypes.client.GetActiveObject('Outlook.Application')
            except Exception:
                return False, 'Outlook is not running or COM is not ready.'
            mail=outlook.CreateItem(0)
            mail.To=self.settings.get('feedback_to','masakii@insightec.com')
            mail.Subject=self.engine.build_subject(self.feedback_request())
            mail.Body=body
            attached=set()
            for item in files:
                path=Path(item)
                if path.is_file():
                    resolved=str(path.resolve()); key=resolved.lower()
                    if key not in attached:
                        mail.Attachments.Add(resolved); attached.add(key)
            for item in sorted((APP_DIR/'logs').glob('*.log'), key=lambda p:p.stat().st_mtime, reverse=True)[:3]:
                resolved=str(item.resolve()); key=resolved.lower()
                if key not in attached:
                    mail.Attachments.Add(resolved); attached.add(key)
            mail.Display(False)
            return True,''
        except ModuleNotFoundError as exc:
            return False, f'Internal module error: {exc}'
        except Exception as exc:
            return False,f'{type(exc).__name__}: {exc}'

    def start_outlook(self):
        try:
            if sys.platform.startswith('win'):
                try:
                    os.startfile('outlook.exe')
                except Exception:
                    subprocess.Popen(['outlook.exe'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return True, ''
            return False, 'Automatic Outlook start is only supported on Windows.'
        except Exception as exc:
            return False, f'{type(exc).__name__}: {exc}'

    def open_outlook_with_recovery(self, body, files):
        last_detail = ''
        for attempt in range(1, 4):
            ok, detail = self.create_outlook_draft_once(body, files)
            if ok:
                return 'success', ''
            last_detail = detail
            log(f'Outlook feedback attempt {attempt}/3 failed: {detail}')

            # Packaging or internal module failures cannot be fixed by retrying.
            if 'Internal module error:' in detail or 'ModuleNotFoundError' in detail:
                answer = QMessageBox.question(
                    self,
                    ui_text(self,'outlook_component_unavailable'),
                    ui_text(self,'outlook_component_message') + f'\n\n{detail}',
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.Yes,
                )
                return ('template', detail) if answer == QMessageBox.Yes else ('cancel', detail)

            box = QMessageBox(self)
            box.setIcon(QMessageBox.Question)
            box.setWindowTitle(ui_text(self,'outlook_not_ready'))
            box.setText(ui_text(self,'outlook_connect_failed') + f'\n\n{ui_text(self,"attempt")} {attempt}/3')
            box.setInformativeText(
                ui_text(self,'outlook_recovery_help')
            )
            retry_button = box.addButton(ui_text(self,'retry'), QMessageBox.AcceptRole)
            open_button = box.addButton(ui_text(self,'open_outlook'), QMessageBox.ActionRole)
            template_button = box.addButton(ui_text(self,'open_template'), QMessageBox.DestructiveRole)
            cancel_button = box.addButton(QMessageBox.Cancel)
            box.exec()
            clicked = box.clickedButton()

            if clicked == template_button:
                return 'template', detail
            if clicked == cancel_button:
                return 'cancel', detail
            if clicked == open_button:
                started, start_detail = self.start_outlook()
                if not started:
                    QMessageBox.warning(self, ui_text(self,'outlook_start_failed'), start_detail)
                else:
                    # Give Outlook time to register its COM server before the next attempt.
                    QApplication.setOverrideCursor(Qt.WaitCursor)
                    try:
                        for _ in range(8):
                            QApplication.processEvents()
                            time.sleep(0.5)
                    finally:
                        QApplication.restoreOverrideCursor()
            # Retry button proceeds immediately to the next loop iteration.

        answer = QMessageBox.question(
            self,
            ui_text(self,'outlook_connection_failed'),
            ui_text(self,'outlook_failed_three') + f'\n\n{last_detail}',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes,
        )
        return ('template', last_detail) if answer == QMessageBox.Yes else ('cancel', last_detail)

    def show_template(self, body, path):
        dlg=QDialog(self); dlg.setWindowTitle(ui_text(self,'feedback_mail_template')); dlg.resize(820,650)
        lay=QVBoxLayout(dlg); info=QLabel(ui_text(self,'template_saved') + f': {path}'); info.setWordWrap(True); lay.addWidget(info)
        box=QTextEdit(); box.setPlainText(body); lay.addWidget(box)
        row=QHBoxLayout(); copy=QPushButton(ui_text(self,'copy_clipboard')); close=QPushButton(ui_text(self,'close'))
        copy.clicked.connect(lambda: QApplication.clipboard().setText(box.toPlainText()))
        close.clicked.connect(dlg.accept); row.addStretch(); row.addWidget(copy); row.addWidget(close); lay.addLayout(row)
        dlg.exec(); self.accept()


class MasterManagerDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent); self.setWindowTitle(ui_text(self,'master_manager')); self.resize(900,650)
        layout=QVBoxLayout(self); tabs=QTabWidget(); layout.addWidget(tabs)
        for title_key, path in [('people','masters/people_master.json'),('hospital','masters/hospital_master.json'),('recipient','masters/recipients.json'),('salesforce_mapping','profiles/salesforce_profile_default.json')]:
            title = ui_text(self,title_key)
            w=QWidget(); wl=QVBoxLayout(w); text=QTextEdit(); text.setPlainText(json.dumps(read_json(APP_DIR/path,{}), ensure_ascii=False, indent=2)); wl.addWidget(text)
            row=QHBoxLayout(); imp=QPushButton(ui_text(self,'import_json_excel')); save=QPushButton(ui_text(self,'save_json')); row.addWidget(imp); row.addWidget(save); wl.addLayout(row)
            save.clicked.connect(lambda checked=False, t=text, p=path: self.save_text(t,p))
            imp.clicked.connect(lambda checked=False, t=text, title=title: self.import_file(t,title))
            tabs.addTab(w,title)
        close=QPushButton(ui_text(self,'close')); close.clicked.connect(self.accept); layout.addWidget(close)
    def save_text(self, text, path):
        try:
            data=json.loads(text.toPlainText()); write_json(APP_DIR/path, data); QMessageBox.information(self,ui_text(self,'saved'),ui_text(self,'saved'))
        except Exception as e: QMessageBox.warning(self,ui_text(self,'error'),str(e))
    def import_file(self, text, title):
        fn,_=QFileDialog.getOpenFileName(self,'Import',str(APP_DIR),'Data (*.json *.xlsx *.csv);;All (*.*)')
        if not fn: return
        if fn.lower().endswith('.json'):
            text.setPlainText(open(fn,encoding='utf-8').read())
        else:
            QMessageBox.information(self,ui_text(self,'import_title'),ui_text(self,'import_prepared'))

class SettingsDialog(QDialog):
    def __init__(self, settings, parent=None):
        super().__init__(parent); self.settings=settings; self.setWindowTitle(ui_text(self,'settings')); self.resize(480,320)
        lay=QVBoxLayout(self); form=QFormLayout(); self.lang=QComboBox(); [self.lang.addItem(v,k) for k,v in LANG_NAMES.items()]; self.out=QComboBox(); self.out.addItems(['Outlook','Template']); self.auto=QCheckBox(ui_text(self,'auto_login'))
        self.lang.setCurrentIndex(max(0,self.lang.findData(settings.get('language','en')))); self.out.setCurrentText(settings.get('output_mode','Outlook')); self.auto.setChecked(settings.get('auto_login',False))
        form.addRow(ui_text(self,'language'),self.lang); form.addRow(ui_text(self,'output_mode'),self.out); form.addRow('',self.auto); lay.addLayout(form)
        btn=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel); btn.accepted.connect(self.save); btn.rejected.connect(self.reject); lay.addWidget(btn)
    def save(self):
        self.settings['language']=self.lang.currentData(); self.settings['output_mode']=self.out.currentText(); self.settings['auto_login']=self.auto.isChecked(); write_json(APP_DIR/'config/settings.json', self.settings); self.accept()

class MainWindow(QMainWindow):
    def __init__(self, settings, people):
        super().__init__()
        self.settings=settings; self.people=people; self.trans=read_json(APP_DIR/'masters/translations.json', {})
        self.version=read_json(APP_DIR/'app_version.json', {})
        self.admin_mode=False
        self.setWindowTitle('InSightec Complaint Service Hub')
        self.resize(1250,780)
        self.setStyleSheet(f'QMainWindow{{background:{BG};}} QLabel{{color:#1E2937;}} QPushButton{{cursor:pointer;}}')
        self.build_ui()
        self.retranslate()
    def t(self,k):
        lang=self.settings.get('language','en')
        return self.trans.get(lang,self.trans.get('en',{})).get(k,k)
    def current_person(self):
        return next((p for p in self.people if p.get('name')==self.settings.get('user') and p.get('company')==self.settings.get('company')), {})
    def is_masaki(self):
        return 'masaki' in self.settings.get('user','').lower()
    def is_insightec(self): return self.settings.get('company')=='InSightec'
    def build_ui(self):
        central=QWidget(); self.setCentralWidget(central); root=QHBoxLayout(central); root.setContentsMargins(0,0,0,0); root.setSpacing(0)
        self.nav=QFrame(); self.nav.setFixedWidth(230); self.nav.setStyleSheet(f'QFrame{{background:{DARK};}} QLabel{{color:white;}} QPushButton{{color:white; background:transparent; border:0; text-align:left; padding:10px 16px; font-size:14px;}} QPushButton:hover{{background:#0B5D9A;}}')
        navlay=QVBoxLayout(self.nav); navlay.setContentsMargins(18,22,18,18)
        logo=QLabel('InSightec'); logo.setFont(QFont('Arial',26,QFont.Bold)); logo.setStyleSheet('color:white; font-style:italic;')
        navlay.addWidget(logo); sub=QLabel('Bringing therapy into focus'); sub.setStyleSheet('color:#DCEBFF;'); navlay.addWidget(sub)
        badge=QLabel(f"Complaint Service Hub\n{self.version.get('program','0.5 Alpha')} · Build {self.version.get('build','')}"); badge.setStyleSheet(f'background:#073B70; border:1px solid {ACCENT}; border-radius:8px; padding:12px; color:white; font-weight:bold;'); badge.setMinimumHeight(70); navlay.addWidget(badge); navlay.addSpacing(10)
        self.nav_buttons=[]
        for key, icon in [('home','🏠'),('complaint','📝'),('salesforce','☁'),('update_zip','📦'),('settings','⚙'),('feedback','💬'),('system_no','➕'),('master_manager','🛠'),('log_viewer','📋'),('about','ⓘ')]:
            b=QPushButton(f'{icon}  {key}'); b.clicked.connect(lambda checked=False,k=key: self.open_tool(k)); self.nav_buttons.append((key,b)); navlay.addWidget(b)
        navlay.addStretch(); self.footer=QLabel('© InSightec'); self.footer.setStyleSheet('color:#DCEBFF;'); navlay.addWidget(self.footer)
        root.addWidget(self.nav)
        self.main=QWidget(); mainlay=QVBoxLayout(self.main); mainlay.setContentsMargins(28,24,28,10); mainlay.setSpacing(12)
        head=QHBoxLayout(); self.title=QLabel(); self.title.setFont(QFont('Arial',25,QFont.Bold)); self.title.setStyleSheet(f'color:{PRIMARY};')
        self.subtitle=QLabel(); self.subtitle.setFont(QFont('Arial',25,QFont.Bold));
        head.addWidget(self.title); head.addWidget(self.subtitle); head.addSpacing(10); self.version_label=QLabel(); head.addWidget(self.version_label); head.addStretch()
        self.lang_cb=QComboBox(); [self.lang_cb.addItem(name,code) for code,name in LANG_NAMES.items()]; self.lang_cb.setCurrentIndex(max(0,self.lang_cb.findData(self.settings.get('language','en')))); self.lang_cb.currentIndexChanged.connect(self.change_lang)
        self.user_label=QLabel(); self.admin_btn=QPushButton(ui_text(self,'admin_mode_off')); self.admin_btn.clicked.connect(self.toggle_admin); self.admin_btn.setVisible(self.is_masaki())
        self.language_label=QLabel(self.t('language'))
        for w in [self.language_label, self.lang_cb, self.user_label, self.admin_btn]: head.addWidget(w)
        mainlay.addLayout(head)
        self.info=QLabel(); mainlay.addWidget(self.info)
        line=QFrame(); line.setFrameShape(QFrame.HLine); line.setStyleSheet(f'color:{CARD_BORDER};'); mainlay.addWidget(line)
        self.scroll=QScrollArea(); self.scroll.setWidgetResizable(True); self.scroll.setFrameShape(QFrame.NoFrame)
        self.content=QWidget(); self.grid=QGridLayout(self.content); self.grid.setContentsMargins(4,4,4,20); self.grid.setHorizontalSpacing(22); self.grid.setVerticalSpacing(22)
        self.scroll.setWidget(self.content); mainlay.addWidget(self.scroll,1)
        self.status=QLabel(); self.status.setStyleSheet(f'background:{DARK}; color:white; padding:8px; border-radius:4px;'); mainlay.addWidget(self.status)
        root.addWidget(self.main,1)
        self.refresh_cards()
    def allowed_tools(self):
        base=['complaint','update_zip','settings','feedback','system_no']
        if self.is_insightec(): base.insert(1,'salesforce')
        if self.is_masaki() and self.admin_mode: base += ['master_manager','log_viewer','about']
        return base
    def refresh_cards(self):
        while self.grid.count():
            item=self.grid.takeAt(0); w=item.widget();
            if w: w.deleteLater()
        allowed=self.allowed_tools()
        defs={
            'complaint':('Complaint','Create complaint, check English, generate Outlook mail or copy template.','📝',PRIMARY,'User tool'),
            'salesforce':('Salesforce','Auto input mapped complaint fields to Salesforce on Microsoft Edge.','☁','#10883E','InSightec user'),
            'update_zip':('Update ZIP','Load Master Update or Program Update ZIP. Backup is created automatically.','📦','#D26900','User tool'),
            'settings':('Settings','Default country, output mode, language and paths.','⚙','#008B8B','Available to all users'),
            'feedback':('Feedback','Send bug reports, improvement requests, questions, screenshots, logs, and validation reports.','💬','#1E88E5','User tool'),
            'system_no':('System No.','Create a system-number addition request.','➕','#198754','User tool'),
            'master_manager':('Master Manager','Edit masters and create update ZIP package.','🛠','#5B4AA0','Admin only'),
            'log_viewer':('Log Viewer','View application logs and operation history.','📋','#1E88E5','Admin only'),
            'about':('About','Application information and version.','ⓘ','#333333','Admin only')}
        row=0; col=0
        title=QLabel(self.t('launch_pad')); title.setFont(QFont('Arial',18,QFont.Bold)); self.grid.addWidget(title,row,0,1,3); row+=1
        for k in allowed:
            title,desc,icon,color,tag=defs[k]
            c=ToolCard(self.t(k) if k in self.trans.get(self.settings.get('language','en'),{}) else title, self.t(k+'_desc'), icon, color, self.t(k+'_tag'), lambda key=k: self.open_tool(key), self.t('start'))
            self.grid.addWidget(c,row,col)
            col+=1
            if col>=3: col=0; row+=1
        if self.is_masaki() and self.admin_mode:
            admin=QLabel(self.t('admin_only')); admin.setFont(QFont('Arial',15,QFont.Bold)); admin.setStyleSheet('color:#5B4AA0;'); self.grid.addWidget(admin,row,0,1,3)
    def retranslate(self):
        self.title.setText('InSightec')
        self.subtitle.setText('Complaint Service Hub')
        self.version_label.setText(f"{self.version.get('program','0.5 Alpha')} · Build {self.version.get('build','')}")
        self.info.setText(f"{self.t('company')}: {self.settings.get('company')}  |  {self.t('language')}: {LANG_NAMES.get(self.settings.get('language'),'English')}")
        self.user_label.setText(self.settings.get('user',''))
        self.language_label.setText(self.t('language'))
        self.admin_btn.setText(self.t('admin_mode_on') if self.admin_mode else self.t('admin_mode_off'))
        self.status.setText(f"{self.t('ready')}  |  Program {self.version.get('program')} Build {self.version.get('build')}  |  Master {self.version.get('master')}  |  User {self.settings.get('user')}")
        for key,b in self.nav_buttons:
            b.setVisible(key in ['home']+self.allowed_tools())
            b.setText(f"{b.text().split('  ')[0]}  {self.t(key)}")
        self.refresh_cards()
    def change_output(self, text):
        self.settings['output_mode']=text; write_json(APP_DIR/'config/settings.json', self.settings); self.retranslate()
    def change_lang(self):
        self.settings['language']=self.lang_cb.currentData(); write_json(APP_DIR/'config/settings.json', self.settings); self.retranslate()
    def toggle_admin(self):
        if not self.is_masaki(): return
        self.admin_mode=not self.admin_mode; self.admin_btn.setText(self.t('admin_mode_on') if self.admin_mode else self.t('admin_mode_off')); self.admin_btn.setStyleSheet('background:#E6A700; padding:8px;' if self.admin_mode else ''); self.retranslate()
    def open_tool(self, key):
        log(f'Open tool requested: {key!r}')
        try:
            if key=='home':
                self.refresh_cards()
                self.scroll.verticalScrollBar().setValue(0)
            elif key=='complaint': ComplaintDialog(self).exec()
            elif key=='settings':
                if SettingsDialog(self.settings,self).exec():
                    self.lang_cb.setCurrentIndex(max(0,self.lang_cb.findData(self.settings.get('language','en')))); self.retranslate()
            elif key=='update_zip': self.apply_update_zip()
            elif key=='feedback': FeedbackDialog(self).exec()
            elif key=='master_manager': MasterManagerDialog(self).exec()
            elif key=='salesforce': QMessageBox.information(self,self.t('salesforce'),self.t('salesforce_ready_message'))
            elif key=='log_viewer': self.show_logs()
            elif key=='about': QMessageBox.information(self,self.t('about'),f"InSightec Complaint Service Hub\n{self.t('program')}: {self.version.get('program')}\n{self.t('build')}: {self.version.get('build')}\n{self.t('architecture_note')}")
            elif key=='system_no': QMessageBox.information(self,self.t('system_no'), self.t('system_no_prepared'))
            else:
                raise ValueError(f'Unknown tool key: {key!r}')
            log(f'Open tool completed: {key!r}')
        except Exception as exc:
            log(f'Open tool failed: key={key!r}, error={exc!r}')
            QMessageBox.critical(self, self.t('launch_error'), self.t('function_start_failed') + f'\n\nTool: {key}\nError: {exc}')
    def apply_update_zip(self):
        fn,_=QFileDialog.getOpenFileName(self,self.t('select_update_zip'),str(APP_DIR),self.t('zip_files_filter'))
        if not fn: return
        # detect manifest type
        try:
            with zipfile.ZipFile(fn) as z:
                names=z.namelist(); text='\n'.join(names).lower()
                is_program=('hub_app.py' in text) or ('launcher.py' in text) or ('updater.py' in text) or ('program_update' in text)
        except Exception as e:
            QMessageBox.warning(self,self.t('update'),str(e)); return
        if is_program:
            dst=APP_DIR/'updates'/'pending_program_update.zip'; dst.parent.mkdir(exist_ok=True); shutil.copy2(fn,dst)
            QMessageBox.information(self,self.t('program_update'),self.t('program_update_staged'))
        else:
            self.apply_master_update(Path(fn))
    def apply_master_update(self, path):
        bdir=APP_DIR/'backups'/f"master_backup_{datetime.datetime.now():%Y%m%d_%H%M%S}"; bdir.mkdir(parents=True,exist_ok=True)
        try:
            with zipfile.ZipFile(path) as z:
                for n in z.namelist():
                    if n.endswith('/'): continue
                    rel=n
                    if rel.startswith('complaint_service_hub/'): rel=rel[len('complaint_service_hub/'):]
                    if not (rel.startswith('masters/') or rel.startswith('templates/') or rel.startswith('profiles/') or rel.startswith('config/')): continue
                    dst=APP_DIR/rel
                    if dst.exists():
                        (bdir/rel).parent.mkdir(parents=True,exist_ok=True); shutil.copy2(dst,bdir/rel)
                    dst.parent.mkdir(parents=True,exist_ok=True)
                    with z.open(n) as src, open(dst,'wb') as out: shutil.copyfileobj(src,out)
            QMessageBox.information(self,self.t('master_update'),self.t('master_update_completed'))
        except Exception as e: QMessageBox.warning(self,self.t('master_update_failed'),str(e))
    def show_logs(self):
        dlg=QDialog(self); dlg.setWindowTitle(self.t('log_viewer')); dlg.resize(800,550); lay=QVBoxLayout(dlg); box=QTextEdit(); box.setReadOnly(True); content=''
        for p in sorted((APP_DIR/'logs').glob('*.log')):
            content += f'===== {p.name} =====\n' + p.read_text(encoding='utf-8', errors='ignore')[-4000:] + '\n\n'
        box.setPlainText(content or self.t('no_logs_yet')); lay.addWidget(box); b=QPushButton(self.t('close')); b.clicked.connect(dlg.accept); lay.addWidget(b); dlg.exec()

def main():
    app=QApplication(sys.argv)
    app.setStyle('Fusion')
    settings=read_json(APP_DIR/'config/settings.json', {})
    people=read_json(APP_DIR/'masters/people_master.json', [])
    if not settings.get('auto_login'):
        dlg=StartupDialog(settings, people)
        if dlg.exec() != QDialog.Accepted:
            return 0
        # auto language by selected user's country when language not manually changed
        person=dlg.selected_person(); country=person.get('country','')
        if country and settings.get('language') not in LANG_NAMES:
            settings['language']=COUNTRY_DEFAULT_LANG.get(country,'en')
        write_json(APP_DIR/'config/settings.json', settings)
    win=MainWindow(settings, people); win.show()
    return app.exec()

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as exc:
        import traceback
        error_log = APP_DIR / 'logs' / 'hub_startup_error.log'
        error_log.parent.mkdir(parents=True, exist_ok=True)
        error_log.write_text(traceback.format_exc(), encoding='utf-8')
        try:
            app = QApplication.instance() or QApplication(sys.argv)
            QMessageBox.critical(
                None,
                'Complaint Service Hub - Startup Error',
                f'The application could not start.\n\n{exc}\n\nDiagnostic log:\n{error_log}',
            )
        except Exception:
            pass
        raise
