from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from PySide6.QtCore import Qt, QTimer, QRect
from PySide6.QtGui import QFont, QPainter, QColor, QPen
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QDialog, QDialogButtonBox, QFrame, QHBoxLayout,
    QLabel, QPushButton, QScrollArea, QSizePolicy, QVBoxLayout, QWidget,
)

DEFAULT_SETTINGS = {
    "schema_version": "1.0",
    "show_startup_prompt": True,
    "show_guide_next_startup": False,
    "do_not_ask_again": False,
    "guide_version": "1.0",
    "last_completed_guide_version": "",
}

DEFAULT_STEPS = [
    {"id": "welcome", "title": "Welcome", "body": "Welcome to Complaint Service Hub. This guide introduces the main complaint workflow."},
    {"id": "language", "title": "Language selection", "body": "Choose the display language from the language selector in the upper-right area.", "target": "lang_cb"},
    {"id": "complaint", "title": "Create Complaint", "body": "Open Complaint from the navigation panel or launch pad to start a new complaint.", "target": "nav_complaint"},
    {"id": "basic", "title": "Basic information", "body": "Complete all required fields in the Basic tab. Missing required fields are highlighted in red."},
    {"id": "medical", "title": "Medical information", "body": "Review and complete the required Medical tab fields before creating feedback."},
    {"id": "additional", "title": "Additional information", "body": "Complete the Additional tab and verify that no required field remains red."},
    {"id": "feedback", "title": "Create Feedback", "body": "Create Feedback prepares the English email. Outlook is used when available; otherwise use the copyable template."},
    {"id": "finish", "title": "Ready", "body": "The basic guide is complete. You can restart it later from the Guide menu."},
]

TRANSLATIONS = {
    "en": {
        "welcome_title": "Welcome to Complaint Service Hub",
        "welcome_body": "Would you like to view the quick guide and guided tour?",
        "start_guide": "Start Guide",
        "not_now": "Not Now",
        "dont_ask": "Don't ask again",
        "previous": "Previous",
        "next": "Next",
        "skip": "Skip",
        "finish": "Finish",
        "guide": "Guide",
        "exit_title": "Exit Complaint Service Hub?",
        "exit_body": "Are you sure you want to close the application?",
        "show_next": "Show the guide and guided tour at the next startup",
        "cancel": "Cancel",
        "exit": "Exit",
    },
    "ja": {
        "welcome_title": "Complaint Service Hubへようこそ",
        "welcome_body": "クイックガイドとガイドツアーを表示しますか？",
        "start_guide": "ガイドを開始",
        "not_now": "今回は表示しない",
        "dont_ask": "次回から確認しない",
        "previous": "戻る",
        "next": "次へ",
        "skip": "スキップ",
        "finish": "完了",
        "guide": "ガイド",
        "exit_title": "Complaint Service Hubを終了しますか？",
        "exit_body": "アプリケーションを閉じてもよろしいですか？",
        "show_next": "次回起動時にガイドとツアーを表示する",
        "cancel": "キャンセル",
        "exit": "終了",
    },
}


def _read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


class WelcomeDialog(QDialog):
    def __init__(self, text: dict[str, str], parent: QWidget | None = None):
        super().__init__(parent)
        self.setWindowTitle(text["welcome_title"])
        self.setModal(True)
        self.setMinimumWidth(520)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 26, 28, 24)
        title = QLabel(text["welcome_title"])
        title.setFont(QFont("Arial", 18, QFont.Bold))
        title.setWordWrap(True)
        body = QLabel(text["welcome_body"])
        body.setWordWrap(True)
        body.setStyleSheet("color:#334155; padding:8px 0 16px 0;")
        self.do_not_ask = QCheckBox(text["dont_ask"])
        layout.addWidget(title)
        layout.addWidget(body)
        layout.addWidget(self.do_not_ask)
        buttons = QDialogButtonBox()
        start = buttons.addButton(text["start_guide"], QDialogButtonBox.AcceptRole)
        skip = buttons.addButton(text["not_now"], QDialogButtonBox.RejectRole)
        start.setDefault(True)
        start.clicked.connect(self.accept)
        skip.clicked.connect(self.reject)
        layout.addWidget(buttons)


class GuideOverlay(QWidget):
    """Phase-1 overlay foundation: dims the parent and exposes a target rectangle."""
    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self._target = QRect()
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.hide()

    def set_target(self, widget: QWidget | None) -> None:
        if widget is None or not widget.isVisible():
            self._target = QRect()
        else:
            top_left = widget.mapTo(self.parentWidget(), widget.rect().topLeft())
            self._target = QRect(top_left, widget.size()).adjusted(-6, -6, 6, 6)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(0, 20, 45, 110))
        if not self._target.isNull():
            painter.setCompositionMode(QPainter.CompositionMode_Clear)
            painter.fillRect(self._target, Qt.transparent)
            painter.setCompositionMode(QPainter.CompositionMode_SourceOver)
            painter.setPen(QPen(QColor("#0099E5"), 3))
            painter.drawRoundedRect(self._target, 8, 8)


class GuideViewer(QDialog):
    def __init__(self, manager: "GuideManager", steps: list[dict[str, Any]], parent: QWidget | None = None):
        super().__init__(parent)
        self.manager = manager
        self.steps = steps or DEFAULT_STEPS
        self.index = 0
        self.setWindowTitle(manager.text("guide"))
        self.setMinimumSize(680, 480)
        self.setModal(False)

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        self.progress = QLabel()
        self.progress.setStyleSheet("color:#64748B; font-weight:bold;")
        self.title = QLabel()
        self.title.setFont(QFont("Arial", 20, QFont.Bold))
        self.title.setWordWrap(True)
        self.image = QLabel()
        self.image.setAlignment(Qt.AlignCenter)
        self.image.setMinimumHeight(150)
        self.image.setStyleSheet("background:#F1F5F9; border:1px solid #CBD5E1; border-radius:8px;")
        self.image.setText("Guide image area")
        self.never_again = QCheckBox("Do not show this guide again")
        self.body = QLabel()
        self.body.setWordWrap(True)
        self.body.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.body.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.body.setStyleSheet("font-size:15px; color:#1E293B; padding:12px 2px;")
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        body_host = QWidget()
        body_layout = QVBoxLayout(body_host)
        body_layout.addWidget(self.body)
        body_layout.addStretch()
        scroll.setWidget(body_host)

        root.addWidget(self.progress)
        root.addWidget(self.title)
        root.addWidget(self.image)
        root.addWidget(scroll, 1)
        root.addWidget(self.never_again)

        nav = QHBoxLayout()
        self.previous = QPushButton(manager.text("previous"))
        self.jump = QPushButton("Go to this section")
        self.skip = QPushButton(manager.text("skip"))
        self.next = QPushButton(manager.text("next"))
        self.previous.clicked.connect(self.go_previous)
        self.jump.clicked.connect(self.jump_to_target)
        self.skip.clicked.connect(self.reject)
        self.next.clicked.connect(self.go_next)
        nav.addWidget(self.previous)
        nav.addWidget(self.jump)
        nav.addStretch()
        nav.addWidget(self.skip)
        nav.addWidget(self.next)
        root.addLayout(nav)
        self.render_step()

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Right, Qt.Key_Return, Qt.Key_Enter):
            self.go_next()
            return
        if event.key() == Qt.Key_Left:
            self.go_previous()
            return
        super().keyPressEvent(event)

    def render_step(self):
        step = self.steps[self.index]
        self.progress.setText(f"Step {self.index + 1} / {len(self.steps)}")
        self.title.setText(str(step.get("title", "")))
        self.body.setText(str(step.get("body", "")))
        self.previous.setEnabled(self.index > 0)
        self.next.setText(self.manager.text("finish") if self.index == len(self.steps) - 1 else self.manager.text("next"))
        image_name = str(step.get("image", "")).strip()
        image_path = self.manager.assets_dir / "images" / image_name if image_name else None
        if image_path and image_path.is_file():
            from PySide6.QtGui import QPixmap
            pixmap = QPixmap(str(image_path))
            self.image.setPixmap(pixmap.scaled(self.image.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
            self.image.show()
        else:
            self.image.hide()
        self.manager.highlight_target(str(step.get("target", "")))

    def jump_to_target(self):
        step = self.steps[self.index]
        self.manager.navigate_to_target(str(step.get("target", "")))

    def go_previous(self):
        if self.index > 0:
            self.index -= 1
            self.render_step()

    def go_next(self):
        if self.index >= len(self.steps) - 1:
            self.manager.mark_completed(self.never_again.isChecked())
            answer = QMessageBox.question(self, "Guide complete", "Create a complaint now?", QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            self.accept()
            if answer == QMessageBox.Yes:
                self.manager.navigate_to_target("nav_complaint")
            return
        self.index += 1
        self.render_step()

    def done(self, result):
        self.manager.clear_highlight()
        super().done(result)


class ExitDialog(QDialog):
    def __init__(self, text: dict[str, str], parent: QWidget | None = None):
        super().__init__(parent)
        self.setWindowTitle(text["exit_title"])
        self.setModal(True)
        self.setMinimumWidth(520)
        layout = QVBoxLayout(self)
        title = QLabel(text["exit_title"])
        title.setFont(QFont("Arial", 17, QFont.Bold))
        body = QLabel(text["exit_body"])
        self.show_next = QCheckBox(text["show_next"])
        self.show_next.setChecked(False)
        layout.addWidget(title)
        layout.addWidget(body)
        layout.addSpacing(8)
        layout.addWidget(self.show_next)
        buttons = QDialogButtonBox()
        cancel = buttons.addButton(text["cancel"], QDialogButtonBox.RejectRole)
        exit_button = buttons.addButton(text["exit"], QDialogButtonBox.AcceptRole)
        cancel.clicked.connect(self.reject)
        exit_button.clicked.connect(self.accept)
        layout.addWidget(buttons)


class GuideManager:
    def __init__(self, main_window: QWidget, app_dir: Path, language: str = "en"):
        self.main_window = main_window
        self.app_dir = Path(app_dir)
        self.language = language if language in TRANSLATIONS else "en"
        self.settings_path = self.app_dir / "config" / "guide_settings.json"
        self.guides_dir = self.app_dir / "common_guide" / "guides"
        self.assets_dir = self.app_dir / "common_guide" / "assets"
        self.settings = dict(DEFAULT_SETTINGS)
        self.settings.update(_read_json(self.settings_path, {}))
        self.steps = self._load_steps()
        self.overlay = GuideOverlay(main_window)
        self.viewer: GuideViewer | None = None

    def text(self, key: str) -> str:
        return TRANSLATIONS.get(self.language, TRANSLATIONS["en"]).get(key, TRANSLATIONS["en"].get(key, key))

    def set_language(self, language: str) -> None:
        self.language = language if language in TRANSLATIONS else "en"

    def _load_steps(self) -> list[dict[str, Any]]:
        payload = _read_json(self.guides_dir / "complaint_steps.json", {})
        steps = payload.get("steps") if isinstance(payload, dict) else None
        return steps if isinstance(steps, list) and steps else list(DEFAULT_STEPS)

    def save(self) -> None:
        _write_json(self.settings_path, self.settings)

    def should_prompt(self) -> bool:
        return bool(self.settings.get("show_guide_next_startup")) or (
            bool(self.settings.get("show_startup_prompt", True)) and not bool(self.settings.get("do_not_ask_again", False))
        )

    def show_startup_prompt(self) -> None:
        if not self.should_prompt():
            return
        dialog = WelcomeDialog(TRANSLATIONS.get(self.language, TRANSLATIONS["en"]), self.main_window)
        accepted = dialog.exec() == QDialog.Accepted
        if dialog.do_not_ask.isChecked():
            self.settings["do_not_ask_again"] = True
            self.settings["show_startup_prompt"] = False
        self.settings["show_guide_next_startup"] = False
        self.save()
        if accepted:
            self.show_guide()

    def show_guide(self) -> None:
        if self.viewer and self.viewer.isVisible():
            self.viewer.raise_()
            self.viewer.activateWindow()
            return
        self.viewer = GuideViewer(self, self.steps, self.main_window)
        self.viewer.show()
        self.viewer.raise_()

    def highlight_target(self, name: str) -> None:
        target = None
        if name:
            target = getattr(self.main_window, name, None)
            if target is None and name == "nav_complaint":
                for key, button in getattr(self.main_window, "nav_buttons", []):
                    if key == "complaint":
                        target = button
                        break
        self.overlay.setGeometry(self.main_window.rect())
        self.overlay.set_target(target)
        if target is not None:
            self.overlay.show()
            self.overlay.raise_()
            if self.viewer:
                self.viewer.raise_()
        else:
            self.overlay.hide()

    def clear_highlight(self) -> None:
        self.overlay.hide()

    def navigate_to_target(self, name: str) -> None:
        if name == "nav_complaint" and hasattr(self.main_window, "open_tool"):
            self.clear_highlight(); self.main_window.open_tool("complaint")
            return
        target = getattr(self.main_window, name, None)
        if target is not None:
            target.setFocus()

    def mark_completed(self, never_again: bool = False) -> None:
        self.settings["last_completed_guide_version"] = self.settings.get("guide_version", "1.0")
        self.settings["show_guide_next_startup"] = False
        if never_again:
            self.settings["do_not_ask_again"] = True
            self.settings["show_startup_prompt"] = False
        self.save()

    def reset_for_next_startup(self) -> None:
        self.settings["show_guide_next_startup"] = True
        self.save()

    def confirm_exit(self) -> tuple[bool, bool]:
        dialog = ExitDialog(TRANSLATIONS.get(self.language, TRANSLATIONS["en"]), self.main_window)
        accepted = dialog.exec() == QDialog.Accepted
        return accepted, dialog.show_next.isChecked()
