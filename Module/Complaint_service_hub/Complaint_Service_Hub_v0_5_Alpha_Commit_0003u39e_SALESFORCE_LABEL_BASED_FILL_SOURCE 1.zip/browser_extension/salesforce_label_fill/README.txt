InSightec Salesforce Label Fill

Microsoft Edge:
1. Open edge://extensions
2. Turn on Developer mode
3. Select Load unpacked
4. Select this folder

Google Chrome:
1. Open chrome://extensions
2. Turn on Developer mode
3. Select Load unpacked
4. Select this folder

Use:
1. Prepare reviewed values in Complaint Service Hub.
2. Open the Salesforce New Complaint page.
3. Click Prepare label-based fill in the app.
4. Click the extension icon and Fill This Page.
5. Review every field. Lookup/dropdown fields may require manual selection. The extension never presses Save.
