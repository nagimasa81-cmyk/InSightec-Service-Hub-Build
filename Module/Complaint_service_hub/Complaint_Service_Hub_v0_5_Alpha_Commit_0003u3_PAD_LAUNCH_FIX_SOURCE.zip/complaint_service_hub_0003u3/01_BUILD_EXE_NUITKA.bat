@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================================
echo InSightec Complaint Service Hub - Stable Nuitka Build
echo Launcher + Hub + Updater separated / No Tkinter
echo Build 0003u2: Windows CMD compatible Python 3.13/3.14 check
echo ============================================================

python --version
python -c "import sys; major, minor = sys.version_info[:2]; print(f'Python {major}.{minor} detected.'); sys.exit(0 if (major, minor) in [(3,13),(3,14)] else 1)"
if errorlevel 1 (
    echo ERROR: Please use Python 3.13 or 3.14.
    pause
    exit /b 1
)
echo Python version accepted.

echo.
echo Installing build dependencies...
python -m pip install --upgrade pip
REM Python 3.14 support requires newer Nuitka and newer PySide6.
REM These versions also work for Python 3.13, so the same dependency set is used.
python -m pip install "nuitka>=4.1.3,<4.2" ordered-set zstandard "PySide6>=6.11.1,<6.12"
if errorlevel 1 pause & exit /b 1

echo.
echo Cleaning old build outputs...
rmdir /s /q build 2>nul
rmdir /s /q dist 2>nul
mkdir dist

set NUITKA_COMMON=--standalone --assume-yes-for-downloads --windows-console-mode=disable --output-dir=build

echo [1/3] Build Hub...
python -m nuitka %NUITKA_COMMON% --enable-plugin=pyside6 --output-filename=Complaint_Service_Hub.exe hub_app.py
if errorlevel 1 pause & exit /b 1

echo [2/3] Build Launcher...
python -m nuitka %NUITKA_COMMON% --output-filename=Complaint_Service_Hub_Launcher.exe launcher.py
if errorlevel 1 pause & exit /b 1

echo [3/3] Build Updater...
python -m nuitka %NUITKA_COMMON% --output-filename=Complaint_Service_Hub_Updater.exe updater.py
if errorlevel 1 pause & exit /b 1

echo.
echo Packaging distribution folder...
mkdir dist\Complaint_Service_Hub
xcopy /E /I /Y build\hub_app.dist\* dist\Complaint_Service_Hub\ >nul
copy /Y build\launcher.dist\Complaint_Service_Hub_Launcher.exe dist\Complaint_Service_Hub\Complaint_Service_Hub_Launcher.exe >nul
copy /Y build\updater.dist\Complaint_Service_Hub_Updater.exe dist\Complaint_Service_Hub\Complaint_Service_Hub_Updater.exe >nul
copy /Y build\hub_app.dist\Complaint_Service_Hub.exe dist\Complaint_Service_Hub\Complaint_Service_Hub.exe >nul
xcopy /E /I /Y config dist\Complaint_Service_Hub\config\ >nul
xcopy /E /I /Y masters dist\Complaint_Service_Hub\masters\ >nul
xcopy /E /I /Y templates dist\Complaint_Service_Hub\templates\ >nul
xcopy /E /I /Y profiles dist\Complaint_Service_Hub\profiles\ >nul
xcopy /E /I /Y docs dist\Complaint_Service_Hub\docs\ >nul
mkdir dist\Complaint_Service_Hub\updates 2>nul
mkdir dist\Complaint_Service_Hub\backups 2>nul
mkdir dist\Complaint_Service_Hub\logs 2>nul
copy /Y app_version.json dist\Complaint_Service_Hub\app_version.json >nul
copy /Y manifest.json dist\Complaint_Service_Hub\manifest.json >nul
copy /Y README_StartHere.txt dist\Complaint_Service_Hub\README_StartHere.txt >nul

echo.
echo Build complete.
echo Run: dist\Complaint_Service_Hub\Complaint_Service_Hub_Launcher.exe
echo.
pause
