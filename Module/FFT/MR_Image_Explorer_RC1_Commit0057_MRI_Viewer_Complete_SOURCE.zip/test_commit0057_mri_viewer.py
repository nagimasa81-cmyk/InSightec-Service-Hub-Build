from pathlib import Path
import ast

source = Path(__file__).with_name("app.py").read_text(encoding="utf-8")
ast.parse(source)

required = [
    'APP_VERSION = "5.7.0 RC1 MRI Viewer Complete Commit0057"',
    "self.display_reset_button",
    "def reset_viewer_display",
    "def _save_viewer_layout",
    "def _restore_viewer_layout",
    "QSettings",
    "MRI Exams",
    "def _exam_identity",
    "def _series_search_blob",
    '"Series Number"',
    '"Acquisition Time"',
    '"Description"',
    "Patient:",
    "Institution:",
    "self.current_kspace = fft2c(self.current_image)",
    'self.view_mode = "Both"',
]
for token in required:
    assert token in source, token

for forbidden in [
    "Thermometry MEMP",
    "Temperature Map",
    "Clinical Order",
    "self.explorer_type_combo",
    "InteractiveRenderPanel",
    "def open_3d_workspace",
]:
    assert forbidden not in source, forbidden

print("Commit0057 MRI Viewer regression: PASS")
