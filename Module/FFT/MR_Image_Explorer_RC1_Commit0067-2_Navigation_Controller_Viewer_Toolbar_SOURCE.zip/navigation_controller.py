from __future__ import annotations

"""Navigation coordination for MR Image Explorer.

The controller deliberately owns no widgets.  It coordinates the existing
MainWindow data model and explorer tree through the small public surface used by
app.py.  This keeps navigation testable and prevents Previous/Next behaviour
from being duplicated across toolbar, mouse wheel, and keyboard handlers.
"""

from typing import Any


class NavigationController:
    """Coordinate DICOM and explorer-order navigation for a MainWindow."""

    def __init__(self, window: Any):
        self.window = window

    def navigate_series(self, delta: int) -> bool:
        """Move within the current DICOM series only.

        Returns True when a different image was opened.
        """
        w = self.window
        if not getattr(w, "dicom_entries", None):
            self.update_ui()
            return False
        indices = w._current_series_indices()
        current = int(getattr(w, "slice_index", 0))
        try:
            position = indices.index(current)
        except ValueError:
            position = 0
        target_position = max(0, min(position + int(delta), len(indices) - 1))
        target_index = indices[target_position]
        if target_index == current:
            self.update_ui()
            return False
        w.show_dicom(target_index)
        return True

    def navigate_continuous(self, delta: int) -> bool:
        """Move in display order and cross a series/folder boundary."""
        w = self.window
        if getattr(w, "source_kind", None) != "dicom" or not getattr(w, "dicom_entries", None):
            return bool(w._navigate_tree_source_continuous(delta))

        groups = w._ordered_series_groups()
        current = int(getattr(w, "slice_index", 0))
        group_pos = item_pos = None
        for gi, (_key, indices) in enumerate(groups):
            if current in indices:
                group_pos = gi
                item_pos = indices.index(current)
                break
        if group_pos is None or item_pos is None:
            self.update_ui()
            return False

        step = -1 if int(delta) < 0 else 1
        indices = groups[group_pos][1]
        target = None
        next_pos = item_pos + step
        if 0 <= next_pos < len(indices):
            target = indices[next_pos]
        elif step > 0 and group_pos + 1 < len(groups):
            target = groups[group_pos + 1][1][0]
        elif step < 0 and group_pos - 1 >= 0:
            target = groups[group_pos - 1][1][-1]

        if target is None or target == current:
            self.update_ui()
            return False

        display_mode = getattr(w, "view_mode", "Both")
        w.show_dicom(target)
        w._set_tree_series_expansion_for_index(target)
        # show_dicom should preserve this already; re-apply only when required.
        if getattr(w, "view_mode", display_mode) != display_mode:
            w.set_view_mode(display_mode)
        return True

    def update_ui(self) -> None:
        """Refresh slice text and enablement for continuous navigation."""
        w = self.window
        entries = getattr(w, "dicom_entries", None) or []
        if getattr(w, "source_kind", None) == "dicom" and entries:
            groups = w._ordered_series_groups()
            current = int(getattr(w, "slice_index", 0))
            group_pos = item_pos = 0
            current_indices = [current]
            for gi, (_key, indices) in enumerate(groups):
                if current in indices:
                    group_pos = gi
                    item_pos = indices.index(current)
                    current_indices = indices
                    break
            label = f"Slice: {item_pos + 1}/{max(len(current_indices), 1)}"
            has_previous = item_pos > 0 or group_pos > 0
            has_next = item_pos < len(current_indices) - 1 or group_pos < len(groups) - 1
        else:
            label = "Slice: -"
            # Explorer-backed RAW/bitmap navigation may be available; leave the
            # buttons enabled when a source is selected and let the controller
            # reject a boundary cleanly.
            has_source = getattr(w, "tree", None) is not None and w.tree.currentItem() is not None
            has_previous = has_source
            has_next = has_source

        if hasattr(w, "slice_label"):
            w.slice_label.setText(label)
        if hasattr(w, "prev_btn"):
            w.prev_btn.setEnabled(bool(has_previous))
        if hasattr(w, "next_btn"):
            w.next_btn.setEnabled(bool(has_next))
