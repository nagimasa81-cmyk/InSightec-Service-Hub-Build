from core.dicom_provider import DicomNavigationProvider
from core.display_state import DisplayState


def test_dicom_provider_crosses_group_boundary():
    current = {"value": 1}
    provider = DicomNavigationProvider(
        groups_factory=lambda: [("A", [0, 1]), ("B", [4, 5])],
        current_index=lambda: current["value"],
    )
    target = provider.next()
    assert target is not None
    assert target.item == 4
    assert target.group_index == 1
    assert target.index_in_group == 0


def test_dicom_provider_previous_crosses_group_boundary():
    provider = DicomNavigationProvider(
        groups_factory=lambda: [("A", [0, 1]), ("B", [4, 5])],
        current_index=lambda: 4,
    )
    target = provider.previous()
    assert target is not None
    assert target.item == 1
    assert target.group_index == 0
    assert target.index_in_group == 1


def test_dicom_provider_clamps_at_ends():
    provider = DicomNavigationProvider(
        groups_factory=lambda: [("A", [2, 3])],
        current_index=lambda: 2,
    )
    assert provider.previous().item == 2
    assert provider.jump(999).item == 3


def test_display_state_normalizes_invalid_values():
    state = DisplayState(mode="invalid", zoom=0, rotation=-90).normalized()
    assert state.mode == "Both"
    assert state.zoom == 0.01
    assert state.rotation == 270
