from __future__ import annotations

"""Central navigation coordination for MR Image Explorer."""

from typing import Any

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QTreeWidgetItemIterator

from core.dicom_provider import DicomNavigationProvider
from core.raw_provider import ExplorerNavigationProvider
from core.tree_sync import TreeSyncEngine


class NavigationController:
    """Coordinate DICOM and Explorer navigation without duplicating order logic."""

    EXPLORER_LEAF_TYPES = {
        "raw_file",
        "bitmap_pending",
        "tracker_file",
        "tracker_pending",
    }

    def __init__(self, window: Any):
        self.window = window
        self.tree_sync = TreeSyncEngine(getattr(window, "tree", None))

    def _dicom_provider(self) -> DicomNavigationProvider:
        w = self.window
        return DicomNavigationProvider(
            groups_factory=w._ordered_series_groups,
            current_index=lambda: int(getattr(w, "slice_index", 0)),
        )

    def _explorer_items(self) -> list[Any]:
        w = self.window
        tree = getattr(w, "tree", None)
        if tree is None:
            return []
        items: list[Any] = []
        iterator = QTreeWidgetItemIterator(tree)
        while iterator.value():
            item = iterator.value()
            data = item.data(0, Qt.UserRole)
            if data and data[0] in self.EXPLORER_LEAF_TYPES:
                items.append(item)
            iterator += 1
        return items

    def _explorer_provider(self) -> ExplorerNavigationProvider:
        tree = getattr(self.window, "tree", None)
        return ExplorerNavigationProvider(
            items_factory=self._explorer_items,
            current_item=(lambda: tree.currentItem() if tree is not None else None),
        )

    def navigate_series(self, delta: int) -> bool:
        """Move within the current DICOM series without crossing a boundary."""
        w = self.window
        if not getattr(w, "dicom_entries", None):
            self.update_ui()
            return False
        indices = w._current_series_indices()
        current = int(getattr(w, "slice_index", 0))
        if not indices:
            self.update_ui()
            return False
        try:
            position = indices.index(current)
        except ValueError:
            position = 0
        target_position = max(0, min(position + (-1 if int(delta) < 0 else 1), len(indices) - 1))
        target_index = indices[target_position]
        if target_index == current:
            self.update_ui()
            return False
        mode = getattr(w, "view_mode", "Both")
        w.show_dicom(target_index)
        if getattr(w, "view_mode", mode) != mode:
            w.set_view_mode(mode)
        return True

    def navigate_continuous(self, delta: int) -> bool:
        """Move in display order across DICOM series or Explorer groups."""
        w = self.window
        step = -1 if int(delta) < 0 else 1

        if getattr(w, "source_kind", None) == "dicom" and getattr(w, "dicom_entries", None):
            provider = self._dicom_provider()
            current = provider.current()
            target = provider.move(step)
            if current is None or target is None or target.item == current.item:
                self.update_ui()
                return False
            mode = getattr(w, "view_mode", "Both")
            w.show_dicom(target.item)
            w._set_tree_series_expansion_for_index(target.item)
            if getattr(w, "view_mode", mode) != mode:
                w.set_view_mode(mode)
            self.update_ui()
            return True

        provider = self._explorer_provider()
        current = provider.current()
        target = provider.move(step)
        if current is None or target is None or target.item is current.item:
            self.update_ui()
            return False
        self.tree_sync.sync_item(target.item, collapse_previous=True)
        w._open_tree_item(target.item, force=True)
        self.update_ui()
        return True

    def update_ui(self) -> None:
        """Refresh slice text and continuous-navigation button availability."""
        w = self.window
        entries = getattr(w, "dicom_entries", None) or []
        if getattr(w, "source_kind", None) == "dicom" and entries:
            location = self._dicom_provider().current()
            if location is None:
                label, has_previous, has_next = "Slice: -", False, False
            else:
                label = f"Slice: {location.index_in_group + 1}/{max(location.group_size, 1)}"
                has_previous = location.has_previous
                has_next = location.has_next
        else:
            location = self._explorer_provider().current()
            label = "Slice: -"
            has_previous = bool(location and location.has_previous)
            has_next = bool(location and location.has_next)

        toolbar = getattr(w, "viewer_toolbar", None)
        if toolbar is not None and hasattr(toolbar, "set_navigation_state"):
            toolbar.set_navigation_state(
                label=label,
                has_previous=has_previous,
                has_next=has_next,
            )
            return
        if hasattr(w, "slice_label"):
            w.slice_label.setText(label)
        if hasattr(w, "prev_btn"):
            w.prev_btn.setEnabled(bool(has_previous))
        if hasattr(w, "next_btn"):
            w.next_btn.setEnabled(bool(has_next))
