from __future__ import annotations

"""DICOM navigation provider with stable series-aware display ordering."""

from typing import Any, Callable, Iterable, Optional, Sequence

from .navigation_provider import NavigationLocation, NavigationProvider


class DicomNavigationProvider(NavigationProvider[int]):
    """Flatten ordered DICOM series while preserving group metadata.

    ``groups_factory`` returns ``[(series_key, [entry_index, ...]), ...]`` and
    ``current_index`` returns the currently displayed global entry index.
    Factories are used so the provider always sees the latest imported data.
    """

    def __init__(
        self,
        groups_factory: Callable[[], Sequence[tuple[Any, Sequence[int]]]],
        current_index: Callable[[], int],
    ) -> None:
        self._groups_factory = groups_factory
        self._current_index = current_index

    def _snapshot(self) -> tuple[list[list[int]], list[int]]:
        groups = [list(indices) for _key, indices in self._groups_factory() if indices]
        flattened = [item for group in groups for item in group]
        return groups, flattened

    @staticmethod
    def _location(
        target: int,
        groups: list[list[int]],
        flattened: list[int],
    ) -> Optional[NavigationLocation[int]]:
        if target not in flattened:
            return None
        flat_index = flattened.index(target)
        for group_index, group in enumerate(groups):
            if target in group:
                index_in_group = group.index(target)
                return NavigationLocation(
                    item=target,
                    index=flat_index,
                    count=len(flattened),
                    group_index=group_index,
                    index_in_group=index_in_group,
                    group_count=len(groups),
                    group_size=len(group),
                )
        return None

    def current(self) -> Optional[NavigationLocation[int]]:
        groups, flattened = self._snapshot()
        if not flattened:
            return None
        current = int(self._current_index())
        if current not in flattened:
            current = flattened[0]
        return self._location(current, groups, flattened)

    def move(self, delta: int) -> Optional[NavigationLocation[int]]:
        location = self.current()
        if location is None or int(delta) == 0:
            return location
        groups, flattened = self._snapshot()
        target_index = max(0, min(location.index + (-1 if delta < 0 else 1), len(flattened) - 1))
        return self._location(flattened[target_index], groups, flattened)

    def jump(self, index: int) -> Optional[NavigationLocation[int]]:
        groups, flattened = self._snapshot()
        if not flattened:
            return None
        target_index = max(0, min(int(index), len(flattened) - 1))
        return self._location(flattened[target_index], groups, flattened)
