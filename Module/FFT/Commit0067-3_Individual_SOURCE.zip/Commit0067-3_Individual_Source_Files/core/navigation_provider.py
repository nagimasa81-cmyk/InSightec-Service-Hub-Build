from __future__ import annotations

"""Provider abstractions used by MR Image Explorer navigation.

The controller depends on this small API instead of knowing how DICOM series or
Explorer items are stored. Providers are intentionally Qt-light so their order
and boundary behaviour can be unit-tested without opening the GUI.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Generic, Optional, TypeVar

T = TypeVar("T")


@dataclass(frozen=True)
class NavigationLocation(Generic[T]):
    """A resolved navigation target and its position in a flattened order."""

    item: T
    index: int
    count: int
    group_index: int = 0
    index_in_group: int = 0
    group_count: int = 1
    group_size: int = 1

    @property
    def has_previous(self) -> bool:
        return self.index > 0

    @property
    def has_next(self) -> bool:
        return self.index + 1 < self.count


class NavigationProvider(ABC, Generic[T]):
    """Resolve current, previous, next, and arbitrary navigation locations."""

    @abstractmethod
    def current(self) -> Optional[NavigationLocation[T]]:
        raise NotImplementedError

    @abstractmethod
    def move(self, delta: int) -> Optional[NavigationLocation[T]]:
        raise NotImplementedError

    @abstractmethod
    def jump(self, index: int) -> Optional[NavigationLocation[T]]:
        raise NotImplementedError

    def previous(self) -> Optional[NavigationLocation[T]]:
        return self.move(-1)

    def next(self) -> Optional[NavigationLocation[T]]:
        return self.move(1)
