from __future__ import annotations

"""Explorer-order provider for RAW, bitmap, and tracker sources."""

from typing import Any, Callable, Iterable, Optional, Sequence

from .navigation_provider import NavigationLocation, NavigationProvider


class ExplorerNavigationProvider(NavigationProvider[Any]):
    """Navigate selectable Explorer leaves in their current visual order."""

    def __init__(
        self,
        items_factory: Callable[[], Sequence[Any]],
        current_item: Callable[[], Any],
    ) -> None:
        self._items_factory = items_factory
        self._current_item = current_item

    def _items(self) -> list[Any]:
        return [item for item in self._items_factory() if item is not None]

    def _location(self, item: Any, items: list[Any]) -> Optional[NavigationLocation[Any]]:
        if item not in items:
            return None
        index = items.index(item)
        parent = item.parent() if hasattr(item, "parent") else None
        group_items = [candidate for candidate in items if (candidate.parent() if hasattr(candidate, "parent") else None) is parent]
        return NavigationLocation(
            item=item,
            index=index,
            count=len(items),
            group_index=0,
            index_in_group=group_items.index(item) if item in group_items else index,
            group_count=1,
            group_size=len(group_items) or len(items),
        )

    def current(self) -> Optional[NavigationLocation[Any]]:
        items = self._items()
        if not items:
            return None
        current = self._current_item()
        if current not in items:
            current = items[0]
        return self._location(current, items)

    def move(self, delta: int) -> Optional[NavigationLocation[Any]]:
        location = self.current()
        if location is None or int(delta) == 0:
            return location
        items = self._items()
        target_index = max(0, min(location.index + (-1 if delta < 0 else 1), len(items) - 1))
        return self._location(items[target_index], items)

    def jump(self, index: int) -> Optional[NavigationLocation[Any]]:
        items = self._items()
        if not items:
            return None
        target_index = max(0, min(int(index), len(items) - 1))
        return self._location(items[target_index], items)
