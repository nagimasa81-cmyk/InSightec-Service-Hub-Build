from pathlib import Path
import json

ROOT = Path(__file__).parent
SOURCE = (ROOT / 'app.py').read_text(encoding='utf-8')
VERSION = json.loads((ROOT / 'version.json').read_text(encoding='utf-8'))

def test_version_identity():
    assert VERSION['version'] == '5.15.0'
    assert VERSION['commit'] == 'Commit0065_Navigation_Accordion_Orientation_Fix'

def test_raw_orientation_is_suppressed():
    assert 'if getattr(self, "source_kind", None) != "dicom" or self.current_ds is None:' in SOURCE
    assert 'self.primary_panel.set_orientation_labels(orientation_values)' in SOURCE
    assert 'self.secondary_panel.set_orientation_labels(empty_values)' in SOURCE

def test_continuous_navigation_is_wired():
    assert 'self.prev_btn.clicked.connect(lambda: self.change_slice_continuous(-1))' in SOURCE
    assert 'self.next_btn.clicked.connect(lambda: self.change_slice_continuous(1))' in SOURCE
    assert 'self.primary_panel.pageRequested.connect(self.change_slice_continuous)' in SOURCE

def test_raw_explorer_navigation_and_group_follow():
    assert 'active_path = str(getattr(self, "current_source", "") or "")' in SOURCE
    assert 'old_parent.setExpanded(False)' in SOURCE
    assert 'parent.setExpanded(True)' in SOURCE
    assert 'self._active_tree_source_key = None' in SOURCE

def test_profile_and_right_accordions_start_closed():
    assert 'self.profile_accordion = AccordionSection("Crosshair Profiles", lower, False)' in SOURCE
    assert 'QTimer.singleShot(0, self._collapse_all_viewer_accordions)' in SOURCE
    assert 'section.set_expanded(False, False)' in SOURCE

def test_top_toolbar_is_page_level():
    assert 'layout.insertWidget(0, self.mode_toolbar_widget)' in SOURCE
