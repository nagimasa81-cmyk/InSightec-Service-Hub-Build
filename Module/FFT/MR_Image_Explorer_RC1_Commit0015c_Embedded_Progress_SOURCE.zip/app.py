from __future__ import annotations

import csv
import json
import os
import copy
import shutil
import sys
import tempfile
import zipfile
import threading
import queue
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import pydicom
import pyqtgraph as pg
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from PySide6.QtCore import Qt, Signal, QMimeData, QUrl, QTimer, QObject, QThread, Slot
from PySide6.QtGui import QAction, QKeySequence, QImage, QDrag
from pydicom.uid import generate_uid
from tracker_position import DirectionMeasurement, signal_peak_coordinate, solve_position
from artifact_learning_db import ArtifactDatabase, image_features
from artifact_detection import classify_feature_vector, features_to_vector
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout, QFrame,
    QGridLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QPushButton,
    QDoubleSpinBox, QProgressDialog, QScrollArea, QSlider, QSpinBox, QSplitter, QStatusBar, QTabWidget, QTableWidget,
    QTableWidgetItem, QTextEdit, QTreeWidget, QTreeWidgetItem, QTreeWidgetItemIterator, QVBoxLayout, QWidget, QMenu,
)

APP_NAME = "MR Image Explorer"
APP_VERSION = "1.5.3 RC1 Import Engine Commit0015c Embedded Progress"

pg.setConfigOptions(imageAxisOrder="row-major", antialias=True)


def fft2c(image: np.ndarray) -> np.ndarray:
    return np.fft.fftshift(np.fft.fft2(np.fft.ifftshift(image)))


def ifft2c(kspace: np.ndarray) -> np.ndarray:
    return np.fft.fftshift(np.fft.ifft2(np.fft.ifftshift(kspace)))


def display_array(arr: np.ndarray, mode: str) -> np.ndarray:
    if mode == "FFT":
        return np.log1p(np.abs(arr))
    return np.abs(arr)


@dataclass
class DicomEntry:
    path: Path
    ds: pydicom.dataset.FileDataset
    image: Optional[np.ndarray]
    sort_key: tuple


class ImportWorker(QObject):
    progress = Signal(str, int, int)
    completed = Signal(object)
    failed = Signal(str)
    canceled = Signal()

    def __init__(self, paths: list[Path]):
        super().__init__()
        self.paths = [Path(path) for path in paths]
        self._cancel_requested = False
        self.temp_dirs: list[Path] = []

    @Slot()
    def cancel(self):
        self._cancel_requested = True

    def _check_cancel(self):
        if self._cancel_requested:
            raise InterruptedError("Import canceled")

    @staticmethod
    def _looks_tracker(path: Path) -> bool:
        name = path.name.lower()
        if "trackerimg" in name or "pfile" in name:
            return True
        if path.suffix == "" and path.stat().st_size > 4096:
            try:
                with path.open("rb") as handle:
                    first = handle.read(4)
                rev = np.frombuffer(first, dtype="<f4")[0]
                return bool(np.isfinite(rev) and 1 < rev < 100)
            except Exception:
                return False
        return False

    @staticmethod
    def _read_dicom_metadata(path: Path) -> DicomEntry:
        ds = pydicom.dcmread(
            str(path),
            stop_before_pixels=True,
            defer_size="1 KB",
            force=False,
        )
        rows = int(getattr(ds, "Rows", 0) or 0)
        cols = int(getattr(ds, "Columns", 0) or 0)
        if rows <= 0 or cols <= 0:
            raise ValueError("Not an image DICOM")

        instance = int(getattr(ds, "InstanceNumber", 0) or 0)
        position = getattr(ds, "ImagePositionPatient", None)
        z_value = (
            float(position[2])
            if position is not None and len(position) >= 3
            else float(instance)
        )
        series = str(getattr(ds, "SeriesInstanceUID", "") or "")
        sort_key = (series, z_value, instance, path.name.lower())
        return DicomEntry(path=path, ds=ds, image=None, sort_key=sort_key)

    def _extract_zip(self, path: Path) -> list[Path]:
        root = Path(tempfile.mkdtemp(prefix="mr_image_explorer_"))
        self.temp_dirs.append(root)

        extracted: list[Path] = []
        with zipfile.ZipFile(path) as archive:
            members = archive.infolist()
            total = max(len(members), 1)

            for index, member in enumerate(members, start=1):
                self._check_cancel()
                self.progress.emit(
                    f"Extracting ZIP {index:,}/{total:,}\n{member.filename}",
                    index,
                    total,
                )

                destination = (root / member.filename).resolve()
                if not str(destination).startswith(str(root.resolve())):
                    raise ValueError("Unsafe ZIP member path")

                if member.is_dir():
                    destination.mkdir(parents=True, exist_ok=True)
                    continue

                destination.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(member, "r") as source, destination.open("wb") as target:
                    while True:
                        self._check_cancel()
                        chunk = source.read(1024 * 1024)
                        if not chunk:
                            break
                        target.write(chunk)
                extracted.append(destination)

        return extracted

    @Slot()
    def run(self):
        try:
            supported_extensions = {
                ".dcm", ".ima", ".dicom", "",
                ".raw", ".bin", ".dat", ".7", ".pfile", ".img",
                ".csv", ".npy", ".npz",
                ".jpg", ".jpeg", ".png", ".bmp",
            }

            files: list[Path] = []
            checked = 0

            self.progress.emit("Collecting files...", 0, 0)

            for source in self.paths:
                self._check_cancel()

                if source.is_dir():
                    for candidate in source.rglob("*"):
                        self._check_cancel()
                        checked += 1
                        if candidate.is_file() and candidate.suffix.lower() in supported_extensions:
                            files.append(candidate)
                        if checked % 100 == 0:
                            self.progress.emit(
                                f"Scanning folder...\n"
                                f"Checked: {checked:,}\n"
                                f"Candidates: {len(files):,}",
                                0,
                                0,
                            )

                elif source.is_file() and source.suffix.lower() == ".zip":
                    files.extend(self._extract_zip(source))

                elif source.is_file():
                    files.append(source)

            unique_files: list[Path] = []
            seen = set()
            for path in files:
                self._check_cancel()
                try:
                    key = str(path.resolve()).lower()
                except Exception:
                    key = str(path).lower()
                if key not in seen:
                    seen.add(key)
                    unique_files.append(path)

            files = unique_files
            total = len(files)

            dicoms: list[DicomEntry] = []
            trackers: list[Path] = []
            raw_files: list[Path] = []
            bitmaps: list[Path] = []
            signals: list[Path] = []
            skipped = 0

            for index, path in enumerate(files, start=1):
                self._check_cancel()
                self.progress.emit(
                    f"Indexing {index:,}/{total:,}\n{path.name}",
                    index,
                    max(total, 1),
                )

                suffix = path.suffix.lower()

                if suffix == ".txt":
                    continue
                if suffix in {".jpg", ".jpeg", ".png", ".bmp"}:
                    bitmaps.append(path)
                    continue
                if suffix in {".csv", ".npy", ".npz"}:
                    signals.append(path)
                    continue

                try:
                    dicoms.append(self._read_dicom_metadata(path))
                    continue
                except Exception:
                    pass

                try:
                    if self._looks_tracker(path):
                        trackers.append(path)
                    elif suffix in {".raw", ".bin", ".dat", ".7", ".pfile", ".img"}:
                        raw_files.append(path)
                    else:
                        skipped += 1
                except Exception:
                    skipped += 1

            dicoms.sort(key=lambda entry: entry.sort_key)

            self.completed.emit({
                "all_files": files,
                "dicoms": dicoms,
                "trackers": trackers,
                "raw_files": raw_files,
                "bitmaps": bitmaps,
                "signals": signals,
                "skipped": skipped,
                "temp_dirs": self.temp_dirs,
            })

        except InterruptedError:
            self.canceled.emit()
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class DropBanner(QFrame):
    pathsDropped = Signal(list)
    clicked = Signal()

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.setObjectName("DropBanner")
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip(
            "Click to select files or a folder.\n"
            "You can also drag and drop files, folders, or ZIP archives here."
        )
        layout = QVBoxLayout(self)
        self.title = QLabel("Click or Drop DICOM / Raw / P File / 1D Data / Folder / ZIP Here")
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setStyleSheet("font-size: 17px; font-weight: 600;")
        subtitle = QLabel("DICOM, RAW, GE TrackerImg/PFile, Siemens .dat, CSV/TXT/NPY/NPZ, images")
        subtitle.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.title)
        layout.addWidget(subtitle)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit()
            event.accept()
            return
        super().mousePressEvent(event)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self.setProperty("dragActive", True)
            self.style().unpolish(self); self.style().polish(self)

    def dragLeaveEvent(self, event):
        self.setProperty("dragActive", False)
        self.style().unpolish(self); self.style().polish(self)

    def dropEvent(self, event):
        self.setProperty("dragActive", False)
        self.style().unpolish(self)
        self.style().polish(self)
        paths = [
            Path(url.toLocalFile())
            for url in event.mimeData().urls()
            if url.isLocalFile()
        ]
        if paths:
            event.setDropAction(Qt.CopyAction)
            event.accept()
            self.pathsDropped.emit(paths)


class ImagePanel(QWidget):
    lineChanged = Signal(int, int)
    pageRequested = Signal(int)
    mouseActionChanged = Signal(str)
    viewRequested = Signal(str)
    levelWheel = Signal(float, bool)

    def __init__(self, title: str):
        super().__init__()
        layout = QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        self.label = QLabel(title)
        self.label.setStyleSheet("font-weight: 600; padding: 3px;")
        layout.addWidget(self.label)
        self.plot = pg.PlotWidget()
        self.plot.setMenuEnabled(False)
        self.plot.getViewBox().setMenuEnabled(False)
        self.plot.scene().sigMouseClicked.connect(self._scene_mouse_clicked)
        self.mouse_action = "Window/Level"
        self.plot.setAspectLocked(True)
        self.plot.hideAxis("left"); self.plot.hideAxis("bottom")
        self.image_item = pg.ImageItem()
        self.plot.addItem(self.image_item)
        self.hline = pg.InfiniteLine(angle=0, movable=True, pen=pg.mkPen('#ff4949', width=1.5, style=Qt.DashLine))
        self.vline = pg.InfiniteLine(angle=90, movable=True, pen=pg.mkPen('#ff4949', width=1.5, style=Qt.DashLine))
        self.plot.addItem(self.hline); self.plot.addItem(self.vline)
        self.hline.sigPositionChanged.connect(self._emit_position)
        self.vline.sigPositionChanged.connect(self._emit_position)
        self.comp_roi = pg.RectROI([10, 10], [40, 40], pen=pg.mkPen("#35a7ff", width=2))
        self.comp_roi.addScaleHandle([1, 1], [0, 0])
        self.comp_roi.addScaleHandle([0, 0], [1, 1])
        self.comp_roi.addScaleHandle([1, 0], [0, 1])
        self.comp_roi.addScaleHandle([0, 1], [1, 0])
        self.comp_roi.hide()
        self.plot.addItem(self.comp_roi)
        layout.addWidget(self.plot, 1)
        self.shape = (1, 1)
        self.current_levels = None

    def _scene_mouse_clicked(self, event):
        if event.button() == Qt.RightButton:
            event.accept()
            self._show_mouse_action_menu(event.screenPos().toPoint())

    def _show_mouse_action_menu(self, global_pos):
        menu = QMenu(self)
        menu.setToolTipsVisible(True)

        action_group = {}
        descriptions = {
            "Window/Level": "Wheel changes Level; Ctrl+Wheel changes Width",
            "Pan": "Left-drag moves the image",
            "Zoom": "Drag a rectangle to zoom",
            "Paging": "Mouse wheel moves Previous/Next image",
            "ROI": "Show and resize the compensation ROI",
        }
        for label in ["Window/Level", "Pan", "Zoom", "Paging", "ROI"]:
            action = menu.addAction(label)
            action.setCheckable(True)
            action.setChecked(self.mouse_action == label)
            action.setToolTip(descriptions[label])
            action_group[action] = label

        menu.addSeparator()
        fft_action = menu.addAction("FFT Current Image")
        back_fft_action = None
        if getattr(self.window(), "fft_view_active", False):
            back_fft_action = menu.addAction("Back from FFT")
        original_action = menu.addAction("Original View")
        both_action = menu.addAction("Both View")
        menu.addSeparator()
        auto_action = menu.addAction("Auto Window/Level")
        default_action = menu.addAction("Back to Default")

        selected = menu.exec(global_pos)
        if selected in action_group:
            self.mouse_action = action_group[selected]
            view_box = self.plot.getViewBox()
            if self.mouse_action == "Pan":
                view_box.setMouseMode(pg.ViewBox.PanMode)
                self.comp_roi.hide()
            elif self.mouse_action == "Zoom":
                view_box.setMouseMode(pg.ViewBox.RectMode)
                self.comp_roi.hide()
            elif self.mouse_action == "ROI":
                self.comp_roi.show()
            else:
                self.comp_roi.hide()
            self.mouseActionChanged.emit(self.mouse_action)
        elif selected == fft_action:
            self.viewRequested.emit("FFT_CURRENT")
        elif back_fft_action is not None and selected == back_fft_action:
            self.viewRequested.emit("BACK_FFT")
        elif selected == original_action:
            self.viewRequested.emit("Original")
        elif selected == both_action:
            self.viewRequested.emit("Both")
        elif selected == auto_action:
            self.mouseActionChanged.emit("Auto Window/Level")
        elif selected == default_action:
            self.viewRequested.emit("Default")


    def wheelEvent(self, event):
        delta = event.angleDelta().y()
        if self.mouse_action == "Paging":
            self.pageRequested.emit(1 if delta < 0 else -1)
            event.accept()
            return
        if self.mouse_action == "Window/Level":
            self.levelWheel.emit(1.0 if delta > 0 else -1.0, bool(event.modifiers() & Qt.ControlModifier))
            event.accept()
            return
        super().wheelEvent(event)


    def set_image(self, image: np.ndarray, auto_levels=True, levels=None):
        image = np.asarray(image, dtype=float)
        self.shape = image.shape[:2]
        self.current_levels = levels
        self.image_item.setImage(image, autoLevels=auto_levels if levels is None else False, levels=levels)
        self.plot.setRange(xRange=(0, self.shape[1]), yRange=(0, self.shape[0]), padding=0)
        self.set_line_position(self.shape[0] // 2, self.shape[1] // 2)

    def set_levels(self, low: float, high: float):
        if high <= low:
            high = low + 1.0
        self.current_levels = (float(low), float(high))
        self.image_item.setLevels(self.current_levels)

    def show_comp_roi(self):
        rows, cols = self.shape
        width = max(8, cols // 5)
        height = max(8, rows // 5)
        self.comp_roi.setPos((cols - width) / 2, (rows - height) / 2)
        self.comp_roi.setSize((width, height))
        self.comp_roi.show()

    def hide_comp_roi(self):
        self.comp_roi.hide()

    def comp_roi_bounds(self):
        pos = self.comp_roi.pos()
        size = self.comp_roi.size()
        x0 = max(0, min(int(round(pos.x())), self.shape[1] - 1))
        y0 = max(0, min(int(round(pos.y())), self.shape[0] - 1))
        x1 = max(x0 + 1, min(int(round(pos.x() + size.x())), self.shape[1]))
        y1 = max(y0 + 1, min(int(round(pos.y() + size.y())), self.shape[0]))
        return y0, y1, x0, x1

    def set_line_position(self, row: int, col: int):
        row = max(0, min(int(row), self.shape[0] - 1))
        col = max(0, min(int(col), self.shape[1] - 1))
        self.hline.blockSignals(True); self.vline.blockSignals(True)
        self.hline.setPos(row); self.vline.setPos(col)
        self.hline.blockSignals(False); self.vline.blockSignals(False)

    def _emit_position(self):
        row = max(0, min(int(round(self.hline.value())), self.shape[0] - 1))
        col = max(0, min(int(round(self.vline.value())), self.shape[1] - 1))
        self.lineChanged.emit(row, col)




class ServiceProgressDialog(QFrame):
    canceled = Signal()

    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setObjectName("ServiceProgressOverlay")
        self.setFrameShape(QFrame.StyledPanel)
        self.setFixedSize(620, 220)
        self.setStyleSheet("""
            QFrame#ServiceProgressOverlay {
                background: #18212b;
                color: #f2f6fa;
                border: 2px solid #2faee5;
                border-radius: 12px;
            }
            QLabel {
                color: #f2f6fa;
                font-size: 18px;
                font-weight: 600;
                border: none;
                background: transparent;
            }
            QProgressBar {
                min-height: 30px;
                border: 1px solid #55758e;
                border-radius: 7px;
                text-align: center;
                background: #0e151c;
                color: white;
                font-size: 16px;
                font-weight: 700;
            }
            QProgressBar::chunk {
                background: #1ea7e8;
                border-radius: 6px;
            }
            QPushButton {
                min-height: 40px;
                min-width: 130px;
                font-size: 16px;
                font-weight: 700;
                background: #2e4355;
                color: white;
                border: 1px solid #6c8da6;
                border-radius: 6px;
            }
            QPushButton:hover {
                background: #3b5770;
            }
            QPushButton:disabled {
                color: #8293a1;
                background: #25333f;
            }
        """)

        root = QVBoxLayout(self)
        root.setContentsMargins(26, 24, 26, 22)
        root.setSpacing(18)

        self.title_label = QLabel(title)
        self.title_label.setStyleSheet(
            "font-size: 20px; font-weight: 800; color: #ffffff;"
        )
        root.addWidget(self.title_label)

        self.message = QLabel(title)
        self.message.setWordWrap(True)
        root.addWidget(self.message)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        root.addWidget(self.progress)

        row = QHBoxLayout()
        row.addStretch(1)
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self._cancel)
        row.addWidget(self.cancel_button)
        root.addLayout(row)

        self._canceled = False
        self.hide()

    def _cancel(self):
        self._canceled = True
        self.canceled.emit()

    def wasCanceled(self):
        return self._canceled

    def setMaximum(self, maximum: int):
        self.progress.setMaximum(max(1, int(maximum)))

    def setValue(self, value: int):
        self.progress.setValue(int(value))

    def setLabelText(self, text: str):
        self.message.setText(text)

    def raise_(self):
        super().raise_()

    def activateWindow(self):
        # Compatibility with the former dialog API.
        window = self.window()
        if window is not None:
            window.raise_()
            window.activateWindow()



class AccordionSection(QWidget):
    opened = Signal(object)
    def __init__(self, title, content, expanded=False, parent=None):
        super().__init__(parent); self.title=title; self.content=content
        lay=QVBoxLayout(self); lay.setContentsMargins(0,0,0,0); lay.setSpacing(3)
        self.button=QPushButton(); self.button.setCheckable(True); self.button.clicked.connect(self._toggle)
        self.button.setStyleSheet("QPushButton{text-align:left;min-height:30px;font-weight:700;background:#1e4b72;border:1px solid #37698f;border-radius:4px;padding:4px 8px} QPushButton:hover{background:#265f8e}")
        lay.addWidget(self.button); lay.addWidget(content); self.set_expanded(expanded,False)
    def _label(self): self.button.setText(("▼" if self.button.isChecked() else "▶")+"  "+self.title)
    def _toggle(self): self.set_expanded(self.button.isChecked(),True)
    def set_expanded(self, expanded, notify=False):
        self.button.blockSignals(True); self.button.setChecked(bool(expanded)); self.button.blockSignals(False)
        self.content.setVisible(bool(expanded)); self._label()
        if expanded and notify: self.opened.emit(self)

class DicomHeaderDialog(QDialog):
    def __init__(self, ds, source_path, parent=None):
        super().__init__(parent); self.ds=copy.deepcopy(ds) if ds is not None else None; self.source_path=Path(source_path) if source_path else None; self._editable=False
        self.setWindowTitle('DICOM Header'); self.resize(1120,720)
        root=QVBoxLayout(self); row=QHBoxLayout(); self.filter_edit=QLineEdit(); self.filter_edit.setPlaceholderText('Filter DICOM header...'); self.filter_edit.textChanged.connect(self._filter); row.addWidget(self.filter_edit,1)
        for label,cb in [('Edit',self.enable_edit),('Save',self.save_edited),('Close',self.close)]: b=QPushButton(label); b.clicked.connect(cb); row.addWidget(b)
        root.addLayout(row); self.table=QTableWidget(0,6); self.table.setHorizontalHeaderLabels(['Tag','Keyword','Name','VR','VM','Value']); self.table.horizontalHeader().setStretchLastSection(True); self.table.setSelectionMode(QTableWidget.ExtendedSelection); self.table.setContextMenuPolicy(Qt.CustomContextMenu); self.table.customContextMenuRequested.connect(self._menu); root.addWidget(self.table,1); self.status=QLabel('Read-only. Press Edit to change values.'); root.addWidget(self.status); self._populate()
    def _populate(self):
        rows=[]
        if self.ds:
            for e in self.ds.iterall():
                if e.tag.group!=0x7FE0: rows.append((str(e.tag),e.keyword,e.name,e.VR,str(e.VM),str(e.value)))
        self.table.setRowCount(len(rows))
        for r,vals in enumerate(rows):
            for c,v in enumerate(vals):
                it=QTableWidgetItem(v); it.setFlags(it.flags() & ~Qt.ItemIsEditable); self.table.setItem(r,c,it)
        self.table.resizeColumnsToContents()
    def enable_edit(self):
        self._editable=True
        for r in range(self.table.rowCount()):
            it=self.table.item(r,5)
            if it: it.setFlags(it.flags()|Qt.ItemIsEditable)
        self.status.setText('Edit mode enabled. Value column is editable.')
    def _menu(self,pos):
        m=QMenu(self); a1=m.addAction('Copy Selection'); a2=m.addAction('Copy Value'); a3=m.addAction('Copy Row'); a4=m.addAction('Select All'); a=m.exec(self.table.viewport().mapToGlobal(pos))
        if a==a4: self.table.selectAll(); return
        cur=self.table.currentItem()
        if a==a1: QApplication.clipboard().setText('\n'.join(i.text() for i in self.table.selectedItems()))
        elif a==a2 and cur: QApplication.clipboard().setText(self.table.item(cur.row(),5).text())
        elif a==a3 and cur: QApplication.clipboard().setText('\t'.join(self.table.item(cur.row(),c).text() if self.table.item(cur.row(),c) else '' for c in range(6)))
    def _filter(self,q):
        q=q.lower()
        for r in range(self.table.rowCount()): self.table.setRowHidden(r, not any(q in (self.table.item(r,c).text().lower() if self.table.item(r,c) else '') for c in range(6)))
    def _next_path(self):
        folder=(self.source_path.parent if self.source_path else Path.cwd())/'Edited'; folder.mkdir(parents=True,exist_ok=True); base=self.source_path.stem if self.source_path else 'DICOM'; out=folder/f'{base}_Edit.dcm'; n=1
        while out.exists(): out=folder/f'{base}_Edit{n}.dcm'; n+=1
        return out
    def save_edited(self):
        if not self.ds or not self._editable: QMessageBox.information(self,'DICOM Header','Press Edit before saving.'); return
        changed=0
        for r in range(self.table.rowCount()):
            try:
                g,e=self.table.item(r,0).text().strip('()').split(','); tag=(int(g,16),int(e,16)); val=self.table.item(r,5).text()
                if tag in self.ds and str(self.ds[tag].value)!=val: self.ds[tag].value=val; changed+=1
            except Exception: pass
        out=self._next_path()
        try: self.ds.save_as(str(out))
        except Exception as exc: QMessageBox.critical(self,'Save Error',str(exc)); return
        self.status.setText(f'Saved {changed} changed value(s): {out}'); QMessageBox.information(self,'DICOM Header',f'Saved:\n{out}')

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} {APP_VERSION}")
        self.resize(1550, 950)
        self.setAcceptDrops(True)
        self.temp_dirs: list[Path] = []
        self.dicom_entries: list[DicomEntry] = []
        self.current_image: Optional[np.ndarray] = None
        self.current_kspace: Optional[np.ndarray] = None
        self.current_recon: Optional[np.ndarray] = None
        self.current_ds = None
        self.current_source = ""
        self.view_mode = "Both"
        self.line_orientation = "Row"
        self.line_row = 0
        self.line_col = 0
        self.signals: list[dict] = []
        self.imported_paths: list[Path] = []
        self.spike_results: list[dict] = []
        self.active_spike_indices = np.array([], dtype=int)
        self.tracker_matrix: Optional[np.ndarray] = None
        self.tracker_source_path: Optional[Path] = None
        self.tracker_files: list[dict] = []
        self.tracker_file_index: int = -1
        self.tracker_line_metrics: list[dict] = []
        self.tracker_selected_lines: list[int] = []
        self.tracker_position_measurements: list[DirectionMeasurement] = []
        self.tracker_reconstructed_image: Optional[np.ndarray] = None
        self.tracker_strongest_line: Optional[np.ndarray] = None
        self.tracker_strongest_line_index: int = -1
        self.tracker_shared_name: str = ""
        self.artifact_db: Optional[ArtifactDatabase] = None
        self.artifact_db_path: Optional[Path] = None
        self.artifact_selected_indices: list[int] = []
        self.normal_reference_image: Optional[np.ndarray] = None
        self.normal_reference_path: Optional[Path] = None
        self.compensation_preview: Optional[np.ndarray] = None
        self.compensation_original: Optional[np.ndarray] = None
        self.compensation_original_kspace: Optional[np.ndarray] = None
        self.compensation_history: list[dict] = []
        self.compensation_history_index: int = -1
        self.compensation_base_kspace: Optional[np.ndarray] = None
        self.compensation_base_image: Optional[np.ndarray] = None
        self.compensation_roi_panel: Optional[ImagePanel] = None
        self.addsub_preview_result: Optional[np.ndarray] = None
        self.addsub_preview_operation: str = ""
        self.addsub_a: Optional[dict] = None
        self.addsub_b: Optional[dict] = None
        self.processed_images: dict[str, np.ndarray] = {}
        self.processed_sources: dict[str, Path] = {}
        self.window_level: Optional[float] = None
        self.dynamic_range: Optional[float] = None
        self.original_window_level: Optional[float] = None
        self.original_dynamic_range: Optional[float] = None
        self.raw_window_level: Optional[float] = None
        self.raw_dynamic_range: Optional[float] = None
        self.level_preset = "Auto"
        self.source_kind = "none"
        self.output_root_override: Optional[Path] = None
        self.current_mouse_action = "Window/Level"
        self.fft_view_active = False
        self.fft_back_image: Optional[np.ndarray] = None
        self.quick_spike_threshold = 0.0
        self.tracker_analysis_text: dict[str, str] = {}
        self.import_in_progress = False
        self.lazy_dicom_cache_limit = 24
        self.lazy_dicom_cache_order: list[int] = []
        self.pending_tracker_paths: list[Path] = []
        self.pending_first_dicom_index: Optional[int] = None
        self.import_thread: Optional[QThread] = None
        self.import_worker: Optional[ImportWorker] = None
        self.import_python_thread: Optional[threading.Thread] = None
        self.import_event_queue: queue.Queue = queue.Queue()
        self.import_cancel_event = threading.Event()
        self.import_poll_timer = QTimer(self)
        self.import_poll_timer.setInterval(50)
        self.import_poll_timer.timeout.connect(self._poll_import_queue)
        self.import_last_event_time = 0.0
        self.import_thread_started = False
        self.import_start_time = 0.0

        self._build_ui()
        self._build_menu()
        self._apply_style()
        self.statusBar().showMessage("Ready — drop files or folders above")

    def _build_ui(self):
        root = QWidget(); root_l = QVBoxLayout(root); root_l.setContentsMargins(8, 8, 8, 8)
        self.drop_banner = DropBanner()
        self.drop_banner.pathsDropped.connect(self.request_import)
        self.drop_banner.clicked.connect(self.open_import_selection)
        root_l.addWidget(self.drop_banner)

        self.tabs = QTabWidget()
        self.tabs.setMovable(False)
        self.tabs.setDocumentMode(False)
        self.tabs.setTabPosition(QTabWidget.North)
        self.tabs.addTab(self._build_workspace(), "Image Workspace")
        self.tabs.addTab(self._build_spike_results(), "Spike Diag")
        self.tabs.addTab(self._build_artifact_diag(), "Artifact Diag")
        self.tabs.addTab(self._build_tracker_signal_combined(), "Tracker Signal")
        self.tabs.addTab(self._build_signal_studio(), "1D Signal Studio")
        root_l.addWidget(self.tabs, 1)
        self.setCentralWidget(root)
        self.setStatusBar(QStatusBar())

    def _build_artifact_diag(self):
        page=QWidget(); lay=QVBoxLayout(page); inner=QTabWidget(); inner.addTab(self._build_artifact_detection(),'Detection'); inner.addTab(self._build_artifact_learning(),'Learning'); lay.addWidget(inner); return page

    def _build_tracker_signal_combined(self):
        page=QWidget(); lay=QVBoxLayout(page); inner=QTabWidget(); inner.addTab(self._build_tracker_explorer(),'Signal Explorer'); inner.addTab(self._build_tracker_position(),'Position'); lay.addWidget(inner); return page

    def _build_workspace(self):
        page = QWidget(); layout = QHBoxLayout(page); layout.setContentsMargins(0, 6, 0, 0)
        main_split = QSplitter(Qt.Horizontal)

        left = QWidget()
        left.setMinimumWidth(90)
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabel("Explorer")
        self.tree.setSelectionMode(QTreeWidget.ExtendedSelection)
        self.tree.setDragEnabled(True)
        self.tree.setAcceptDrops(False)
        self.tree.setDragDropMode(QTreeWidget.DragOnly)
        self.tree.setDefaultDropAction(Qt.CopyAction)
        self.tree.setMinimumWidth(90)
        self.tree.setTextElideMode(Qt.ElideMiddle)
        self.tree.setUniformRowHeights(False)
        self.tree.setStyleSheet("""
            QTreeWidget::item:selected {
                background: rgba(55, 165, 255, 110);
                color: white;
            }
            QTreeWidget::item:selected:active {
                background: rgba(55, 165, 255, 145);
            }
        """)
        self.tree.itemClicked.connect(self._tree_clicked)
        self.tree.startDrag = self._start_tree_file_drag
        self.tree.itemSelectionChanged.connect(self._tree_selection_changed)
        self.tree.currentItemChanged.connect(self._tree_current_changed)
        ll.addWidget(self.tree, 1)
        self.info = QLabel("No file loaded")
        self.info.setWordWrap(True); self.info.setMinimumHeight(150)
        self.info.setObjectName("InfoCard")
        ll.addWidget(self.info)
        main_split.addWidget(left)

        center = QWidget(); cl = QVBoxLayout(center); cl.setContentsMargins(0, 0, 0, 0)
        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel("Display"))
        self.workspace_source_combo = QComboBox()
        self.workspace_source_combo.addItems(["Current Image"])
        self.workspace_source_combo.hide()
        self.btn_fft = QPushButton("FFT")
        self.btn_original = QPushButton("Original")
        self.btn_both = QPushButton("Both")
        for b, mode in [(self.btn_fft, "FFT"), (self.btn_original, "Original"), (self.btn_both, "Both")]:
            b.setCheckable(True); b.clicked.connect(lambda checked=False, m=mode: self.set_view_mode(m)); mode_row.addWidget(b)
        mode_row.addStretch(1)
        self.slice_label = QLabel("Slice: -")
        self.prev_btn = QPushButton("Previous"); self.next_btn = QPushButton("Next")
        self.prev_btn.clicked.connect(lambda: self.change_slice(-1)); self.next_btn.clicked.connect(lambda: self.change_slice(1))
        self.clear_selected_images_button = QPushButton("Clear Selected")
        self.clear_all_images_button = QPushButton("Clear All Images")
        self.clear_selected_images_button.clicked.connect(self.clear_selected_images)
        self.clear_all_images_button.clicked.connect(self.clear_all_images)
        mode_row.addWidget(self.prev_btn); mode_row.addWidget(self.next_btn); mode_row.addWidget(self.slice_label)
        mode_row.addWidget(self.clear_selected_images_button); mode_row.addWidget(self.clear_all_images_button)
        self.header_popup_button=QPushButton("DICOM Header"); self.header_popup_button.clicked.connect(self.show_dicom_header_popup); mode_row.addWidget(self.header_popup_button)
        self.quick_spike_button=QPushButton("Quick Spike Detect"); self.quick_spike_button.clicked.connect(self.quick_spike_detect_prototype); mode_row.addWidget(self.quick_spike_button)
        cl.addLayout(mode_row)

        self.vertical_splitter = QSplitter(Qt.Vertical)
        image_container = QWidget(); il = QVBoxLayout(image_container); il.setContentsMargins(0, 0, 0, 0)
        self.image_splitter = QSplitter(Qt.Horizontal)
        self.primary_panel = ImagePanel("FFT (k-space)")
        self.secondary_panel = ImagePanel("Original")
        self.primary_panel.lineChanged.connect(self._line_moved)
        self.secondary_panel.lineChanged.connect(self._line_moved)
        self.primary_panel.pageRequested.connect(self.change_slice)
        self.secondary_panel.pageRequested.connect(self.change_slice)
        self.primary_panel.mouseActionChanged.connect(self._image_mouse_action_changed)
        self.secondary_panel.mouseActionChanged.connect(self._image_mouse_action_changed)
        self.primary_panel.viewRequested.connect(self._image_view_requested)
        self.secondary_panel.viewRequested.connect(self._image_view_requested)
        self.primary_panel.levelWheel.connect(
            lambda step, width: self._image_level_wheel(self.primary_panel, step, width)
        )
        self.secondary_panel.levelWheel.connect(
            lambda step, width: self._image_level_wheel(self.secondary_panel, step, width)
        )
        self.image_splitter.addWidget(self.primary_panel); self.image_splitter.addWidget(self.secondary_panel)
        il.addWidget(self.image_splitter, 1)

        line_bar = QHBoxLayout()
        line_bar.addWidget(QLabel("Line"))
        self.orientation_combo = QComboBox(); self.orientation_combo.addItems(["Row", "Column"])
        self.orientation_combo.currentTextChanged.connect(self._orientation_changed)
        line_bar.addWidget(self.orientation_combo)
        self.line_spin = QSpinBox(); self.line_spin.valueChanged.connect(self._spin_line_changed)
        line_bar.addWidget(self.line_spin)
        self.line_slider = QSlider(Qt.Horizontal); self.line_slider.valueChanged.connect(self._slider_line_changed)
        line_bar.addWidget(self.line_slider, 1)
        self.line_value_label = QLabel("-")
        line_bar.addWidget(self.line_value_label)
        il.addLayout(line_bar)
        self.vertical_splitter.addWidget(image_container)

        lower = QWidget(); low = QHBoxLayout(lower); low.setContentsMargins(0, 0, 0, 0)
        self.profile_plot = pg.PlotWidget(title="Selected Line Profile")
        self.profile_plot.showGrid(x=True, y=True, alpha=.2)
        self.profile_plot.setLabel("bottom", "Sample")
        low.addWidget(self.profile_plot, 2)
        self.tracker_plot = pg.PlotWidget(title="Tracker / Active 1D Signal")
        self.tracker_plot.showGrid(x=True, y=True, alpha=.2)
        low.addWidget(self.tracker_plot, 1)
        self.vertical_splitter.addWidget(lower)
        self.vertical_splitter.setSizes([620, 260])
        cl.addWidget(self.vertical_splitter, 1)
        main_split.addWidget(center)

        right = QWidget()
        right.setMinimumWidth(330)
        right.setMaximumWidth(520)
        rl = QVBoxLayout(right)
        rl.setContentsMargins(4, 0, 4, 0)
        rl.setSpacing(6)
        right.setStyleSheet("""
            QComboBox, QDoubleSpinBox, QSpinBox, QPushButton {
                min-height: 28px;
            }
            QGroupBox {
                margin-top: 8px;
            }
        """)
        profile_group = QGroupBox("Profile")
        form = QFormLayout(profile_group)
        self.profile_mode = QComboBox(); self.profile_mode.addItems(["Magnitude", "Real", "Imaginary", "Phase"])
        self.profile_mode.currentTextChanged.connect(self.on_display_type_changed)
        form.addRow("Type", self.profile_mode)
        self.log_profile = QCheckBox("Log scale"); self.log_profile.toggled.connect(self.update_line_profile)
        form.addRow(self.log_profile)
        rl.addWidget(profile_group)
        self.btn_send_signal = QPushButton("Send selected line to 1D Studio")
        self.btn_send_signal.clicked.connect(self.send_line_to_signal_studio)
        rl.addWidget(self.btn_send_signal)
        self.btn_auto = QPushButton("Auto Levels"); self.btn_auto.clicked.connect(self.auto_levels)
        rl.addWidget(self.btn_auto)
        spike_content=QFrame(); spike_layout=QFormLayout(spike_content)
        self.spike_range_combo=QComboBox(); self.spike_range_combo.addItems(["Large","Mid","Small","Scale"]); self.spike_range_combo.currentTextChanged.connect(self._spike_range_changed); spike_layout.addRow("Range",self.spike_range_combo)
        self.spike_scale_slider=QSlider(Qt.Horizontal); self.spike_scale_slider.setRange(10,100); self.spike_scale_slider.setValue(70); self.spike_scale_slider.setVisible(False); self.spike_scale_label=QLabel("70%"); self.spike_scale_label.setVisible(False); self.spike_scale_slider.valueChanged.connect(lambda v:self.spike_scale_label.setText(f"{v}%")); sr=QHBoxLayout(); sr.addWidget(self.spike_scale_slider,1); sr.addWidget(self.spike_scale_label); spike_layout.addRow("Scale",sr)
        self.spike_level_combo=QComboBox(); self.spike_level_combo.addItems(["Wide","Mid","Fine"]); spike_layout.addRow("Level",self.spike_level_combo)
        self.btn_spike=QPushButton("Apply Spike Processing"); self.btn_spike.clicked.connect(self.apply_spike_processing); self.btn_spike.setStyleSheet("QPushButton{background:#7a2430;font-weight:700;min-height:30px} QPushButton:hover{background:#a23242}"); spike_layout.addRow(self.btn_spike)

        display_group = QGroupBox("Dynamic Range / Window Level")
        display_form = QFormLayout(display_group)
        self.level_target_combo = QComboBox()
        self.level_target_combo.addItems(["Original Image", "Raw Data"])
        self.level_target_combo.currentTextChanged.connect(self._level_target_changed)
        display_form.addRow("Adjust", self.level_target_combo)

        self.level_preset_combo = QComboBox()
        self.level_preset_combo.addItems(["Auto", "Manual", "Wide", "Soft Tissue", "High Contrast", "Narrow"])
        self.level_preset_combo.currentTextChanged.connect(self.apply_level_preset)
        display_form.addRow("Preset", self.level_preset_combo)

        self.window_level_spin = QDoubleSpinBox()
        self.window_level_spin.setRange(-1e12, 1e12)
        self.window_level_spin.setDecimals(3)
        self.window_level_spin.valueChanged.connect(self._manual_levels_changed)
        display_form.addRow("Window level", self.window_level_spin)

        self.dynamic_range_spin = QDoubleSpinBox()
        self.dynamic_range_spin.setRange(1e-9, 1e12)
        self.dynamic_range_spin.setDecimals(3)
        self.dynamic_range_spin.valueChanged.connect(self._manual_levels_changed)
        display_form.addRow("Dynamic range", self.dynamic_range_spin)
        rl.addWidget(display_group)

        addsub_group = QGroupBox("Image Add / Subtract")
        addsub_layout = QVBoxLayout(addsub_group)
        addsub_row1 = QHBoxLayout()
        self.set_a_button = QPushButton("Set Current as A")
        self.set_b_button = QPushButton("Set Current as B")
        self.set_a_button.clicked.connect(lambda: self.set_addsub_source("A"))
        self.set_b_button.clicked.connect(lambda: self.set_addsub_source("B"))
        addsub_row1.addWidget(self.set_a_button)
        addsub_row1.addWidget(self.set_b_button)
        addsub_layout.addLayout(addsub_row1)
        self.addsub_status = QLabel("A: -\nB: -")
        self.addsub_status.setWordWrap(True)
        addsub_layout.addWidget(self.addsub_status)
        addsub_row2 = QHBoxLayout()
        self.add_button = QPushButton("Preview A + B")
        self.subtract_button = QPushButton("Preview A - B")
        self.add_button.clicked.connect(lambda: self.preview_addsub("add"))
        self.subtract_button.clicked.connect(lambda: self.preview_addsub("subtract"))
        addsub_row2.addWidget(self.add_button)
        addsub_row2.addWidget(self.subtract_button)
        addsub_layout.addLayout(addsub_row2)
        self.save_addsub_button = QPushButton("Save Preview Result")
        self.save_addsub_button.clicked.connect(self.save_addsub_preview)
        self.save_addsub_button.setEnabled(False)
        addsub_layout.addWidget(self.save_addsub_button)
        addsub_clear_row = QHBoxLayout()
        for label, callback in [
            ("Clear A", lambda: self.clear_addsub_slot("A")),
            ("Clear B", lambda: self.clear_addsub_slot("B")),
            ("Clear Result", self.clear_addsub_result),
        ]:
            button = QPushButton(label); button.clicked.connect(callback); addsub_clear_row.addWidget(button)
        addsub_layout.addLayout(addsub_clear_row)

        comp_group = QGroupBox("Raw Data Compensation")
        comp_layout = QVBoxLayout(comp_group)
        self.select_comp_button = QPushButton("Select Compensation ROI on Raw Data")
        self.preview_comp_button = QPushButton("Preview Reconstructed Image")
        self.apply_comp_button = QPushButton("Commit Compensation")
        self.save_comp_button = QPushButton("Save Displayed Compensation")
        self.cancel_comp_button = QPushButton("Cancel Current ROI")
        self.select_comp_button.clicked.connect(self.start_compensation_roi)
        self.preview_comp_button.clicked.connect(self.preview_compensation)
        self.apply_comp_button.clicked.connect(self.apply_compensation)
        self.save_comp_button.clicked.connect(self.save_compensation_history_state)
        self.cancel_comp_button.clicked.connect(self.clear_compensation_roi)
        comp_layout.addWidget(self.select_comp_button)

        level_row = QHBoxLayout()
        level_row.addWidget(QLabel("Level"))
        self.comp_level_combo = QComboBox()
        self.comp_level_combo.addItems(["Low", "Mid", "High"])
        self.comp_level_combo.setCurrentText("Mid")
        level_row.addWidget(self.comp_level_combo)
        comp_layout.addLayout(level_row)

        self.comp_status_label = QLabel("No RAW ROI selected")
        self.comp_status_label.setWordWrap(True)
        comp_layout.addWidget(self.comp_status_label)

        comp_preview_row = QHBoxLayout()
        comp_preview_row.addWidget(self.preview_comp_button)
        comp_preview_row.addWidget(self.apply_comp_button)
        comp_layout.addLayout(comp_preview_row)

        history_row = QHBoxLayout()
        self.comp_prev_button = QPushButton("Previous")
        self.comp_next_button = QPushButton("Next")
        self.comp_prev_button.clicked.connect(lambda: self.navigate_compensation_history(-1))
        self.comp_next_button.clicked.connect(lambda: self.navigate_compensation_history(1))
        history_row.addWidget(self.comp_prev_button)
        history_row.addWidget(self.comp_next_button)
        comp_layout.addLayout(history_row)
        comp_layout.addWidget(self.save_comp_button)
        self.clear_comp_history_button = QPushButton("Clear Compensation History")
        self.clear_comp_history_button.clicked.connect(self.clear_compensation_history)
        comp_layout.addWidget(self.clear_comp_history_button)
        comp_layout.addWidget(self.cancel_comp_button)

        self.preview_comp_button.setEnabled(False)
        self.apply_comp_button.setEnabled(False)
        self.save_comp_button.setEnabled(False)
        self.comp_prev_button.setEnabled(False)
        self.comp_next_button.setEnabled(False)

        self.accordion_sections=[]
        self.spike_accordion=AccordionSection("Spike",spike_content,True); self.comp_accordion=AccordionSection("Raw Data Compensation",comp_group,False); self.addsub_accordion=AccordionSection("Image Add/Sub",addsub_group,False)
        self.accordion_sections=[self.spike_accordion,self.comp_accordion,self.addsub_accordion]
        for section in self.accordion_sections: section.opened.connect(self._accordion_opened); rl.addWidget(section)
        rl.addStretch(1)

        output_group = QGroupBox("Output Folder")
        output_layout = QVBoxLayout(output_group)
        self.output_root_label = QLabel("Output: follows opened image folder")
        self.output_root_label.setWordWrap(True)
        output_layout.addWidget(self.output_root_label)
        self.output_root_button = QPushButton("Change Output Folder")
        self.output_root_button.clicked.connect(self.change_output_root)
        output_layout.addWidget(self.output_root_button)
        rl.addWidget(output_group)

        right_scroll = QScrollArea()
        right_scroll.setWidgetResizable(True)
        right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        right_scroll.setFrameShape(QFrame.NoFrame)
        right_scroll.setMinimumWidth(330)
        right_scroll.setWidget(right)
        main_split.addWidget(right_scroll)
        main_split.setCollapsible(0, True)
        main_split.setCollapsible(1, False)
        main_split.setCollapsible(2, True)
        main_split.setSizes([220, 1120, 350])
        layout.addWidget(main_split)
        self.set_view_mode("FFT")
        return page

    def _build_signal_studio(self):
        page = QWidget(); layout = QVBoxLayout(page)
        top = QHBoxLayout()
        self.back_to_workspace = QPushButton("← Back to Image Workspace")
        self.back_to_workspace.clicked.connect(lambda: self.tabs.setCurrentIndex(0))
        top.addWidget(self.back_to_workspace)
        self.signal_combo = QComboBox(); self.signal_combo.currentIndexChanged.connect(self.update_signal_plot)
        self.signal_component = QComboBox(); self.signal_component.addItems(["Magnitude", "Real", "Imaginary", "Phase"])
        self.signal_component.currentTextChanged.connect(self.update_signal_plot)
        self.signal_fft = QCheckBox("Frequency display (FFT)"); self.signal_fft.setChecked(False); self.signal_fft.toggled.connect(self.update_signal_plot)
        remove_signal = QPushButton("Remove Selected"); remove_signal.clicked.connect(self.remove_selected_signal)
        clear = QPushButton("Clear All Signals"); clear.clicked.connect(self.clear_signals)
        top.addWidget(QLabel("Signal")); top.addWidget(self.signal_combo, 1); top.addWidget(self.signal_component); top.addWidget(self.signal_fft); top.addWidget(remove_signal); top.addWidget(clear)
        layout.addLayout(top)
        self.signal_plot = pg.PlotWidget(); self.signal_plot.showGrid(x=True, y=True, alpha=.2)
        layout.addWidget(self.signal_plot, 1)
        note = QLabel("Tracker PFile/TrackerImg drops are automatically registered here as complex 1D raw signals.")
        note.setWordWrap(True); layout.addWidget(note)
        return page

    def _build_metadata(self):
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout()
        self.header_filter = QComboBox(); self.header_filter.setEditable(True); self.header_filter.setInsertPolicy(QComboBox.NoInsert)
        self.header_filter.lineEdit().setPlaceholderText("Filter header tags...")
        self.header_filter.lineEdit().textChanged.connect(self.filter_header)
        export = QPushButton("Export Current Header to Excel"); export.clicked.connect(self.export_header_excel)
        row.addWidget(self.header_filter, 1); row.addWidget(export)
        layout.addLayout(row)
        self.header_table = QTableWidget(0, 6)
        self.header_table.setHorizontalHeaderLabels(["Tag", "Keyword", "Name", "VR", "VM", "Value"])
        self.header_table.horizontalHeader().setStretchLastSection(True)
        self.header_table.setSortingEnabled(True)
        layout.addWidget(self.header_table)
        return page

    def _build_tracker_explorer(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        controls = QHBoxLayout()
        self.tracker_prev_file_button = QPushButton("◀ Previous File")
        self.tracker_next_file_button = QPushButton("Next File ▶")
        self.tracker_prev_file_button.clicked.connect(lambda: self.navigate_tracker_file(-1))
        self.tracker_next_file_button.clicked.connect(lambda: self.navigate_tracker_file(1))
        controls.addWidget(self.tracker_prev_file_button)
        self.tracker_file_combo = QComboBox()
        self.tracker_file_combo.currentIndexChanged.connect(self.select_tracker_file_index)
        controls.addWidget(self.tracker_file_combo)
        controls.addWidget(self.tracker_next_file_button)
        self.tracker_clear_current_button = QPushButton("Clear Current Tracker")
        self.tracker_clear_all_button = QPushButton("Clear All Trackers")
        self.tracker_clear_current_button.clicked.connect(self.clear_current_tracker)
        self.tracker_clear_all_button.clicked.connect(self.clear_all_trackers)
        controls.addWidget(self.tracker_clear_current_button)
        controls.addWidget(self.tracker_clear_all_button)
        self.tracker_drop_text = QLabel(
            "Drop a Tracker PFile / TrackerImg anywhere in the window. "
            "This tab reads and ranks raw lines directly without FFT."
        )
        self.tracker_drop_text.setWordWrap(True)
        controls.addWidget(self.tracker_drop_text, 1)

        controls.addWidget(QLabel("Top lines"))
        self.tracker_top_count = QSpinBox()
        self.tracker_top_count.setRange(1, 100)
        self.tracker_top_count.setValue(1)
        self.tracker_top_count.valueChanged.connect(self._refresh_tracker_ranking)
        controls.addWidget(self.tracker_top_count)

        controls.addWidget(QLabel("Rank by"))
        self.tracker_metric_combo = QComboBox()
        self.tracker_metric_combo.addItems(["Peak", "RMS", "Energy", "Mean magnitude", "Variance"])
        self.tracker_metric_combo.currentTextChanged.connect(self._refresh_tracker_ranking)
        controls.addWidget(self.tracker_metric_combo)

        self.tracker_export_button = QPushButton("Export CSV")
        self.tracker_export_button.clicked.connect(self.export_tracker_lines_csv)
        controls.addWidget(self.tracker_export_button)
        self.tracker_to_workspace_button = QPushButton("Show in Image Workspace")
        self.tracker_to_workspace_button.clicked.connect(self.show_tracker_in_workspace)
        controls.addWidget(self.tracker_to_workspace_button)
        self.tracker_to_1d_button = QPushButton("Show Strongest Line in 1D Studio")
        self.tracker_to_1d_button.clicked.connect(self.send_tracker_to_signal_studio)
        controls.addWidget(self.tracker_to_1d_button)
        layout.addLayout(controls)

        self.tracker_summary = QLabel("No Tracker file loaded.")
        self.tracker_summary.setWordWrap(True)
        layout.addWidget(self.tracker_summary)

        splitter = QSplitter(Qt.Horizontal)

        ranking_box = QGroupBox("Strongest Tracker Line")
        ranking_layout = QVBoxLayout(ranking_box)
        self.tracker_table = QTableWidget(0, 8)
        self.tracker_table.setHorizontalHeaderLabels(
            ["Rank", "Line", "Peak", "RMS", "Energy", "Mean", "Variance", "Relative strength"]
        )
        self.tracker_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.tracker_table.setSelectionMode(QTableWidget.ExtendedSelection)
        self.tracker_table.itemSelectionChanged.connect(self._tracker_selection_changed)
        self.tracker_table.horizontalHeader().setStretchLastSection(True)
        ranking_layout.addWidget(self.tracker_table)

        viewer_box = QGroupBox("Strongest Tracker Raw Line Magnitude — FFT Disabled")
        viewer_layout = QVBoxLayout(viewer_box)
        self.tracker_raw_plot = pg.PlotWidget()
        self.tracker_raw_plot.showGrid(x=True, y=True, alpha=0.25)
        self.tracker_raw_plot.setLabel("bottom", "Sample")
        self.tracker_raw_plot.setLabel("left", "Signal")
        viewer_layout.addWidget(self.tracker_raw_plot, 1)

        viewer_controls = QHBoxLayout()
        viewer_controls.addWidget(QLabel("Component"))
        self.tracker_component_combo = QComboBox()
        self.tracker_component_combo.addItems(["Magnitude", "Real", "Imaginary", "Phase"])
        self.tracker_component_combo.currentTextChanged.connect(self._plot_tracker_selected_lines)
        viewer_controls.addWidget(self.tracker_component_combo)

        self.tracker_previous_button = QPushButton("Previous Strong Line")
        self.tracker_previous_button.clicked.connect(self._select_previous_tracker_line)
        viewer_controls.addWidget(self.tracker_previous_button)

        self.tracker_next_button = QPushButton("Next Strong Line")
        self.tracker_next_button.clicked.connect(self._select_next_tracker_line)
        viewer_controls.addWidget(self.tracker_next_button)
        viewer_controls.addStretch(1)
        viewer_layout.addLayout(viewer_controls)

        self.tracker_metrics_label = QLabel("-")
        self.tracker_metrics_label.setWordWrap(True)
        viewer_layout.addWidget(self.tracker_metrics_label)

        splitter.addWidget(ranking_box)
        splitter.addWidget(viewer_box)
        splitter.setSizes([520, 900])
        layout.addWidget(splitter, 1)

        explanation = QLabel(
            "Tracker Signal Explorer and Spike Detection are separate. "
            "This tab automatically picks high-signal raw lines and displays their original samples without FFT."
        )
        explanation.setWordWrap(True)
        layout.addWidget(explanation)
        return page

    def _build_tracker_position(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        top = QHBoxLayout()
        top.addWidget(QLabel("FFT length"))
        self.position_fft_length = QSpinBox()
        self.position_fft_length.setRange(64, 65536)
        self.position_fft_length.setSingleStep(64)
        self.position_fft_length.setValue(1024)
        top.addWidget(self.position_fft_length)

        top.addWidget(QLabel("FOV (mm)"))
        self.position_fov = QDoubleSpinBox()
        self.position_fov.setRange(1.0, 5000.0)
        self.position_fov.setDecimals(3)
        self.position_fov.setValue(500.0)
        top.addWidget(self.position_fov)

        self.position_use_top = QPushButton("Use Top 3 Tracker Lines")
        self.position_use_top.clicked.connect(self.populate_position_top_lines)
        top.addWidget(self.position_use_top)

        self.position_calculate = QPushButton("Calculate Position")
        self.position_calculate.clicked.connect(self.calculate_tracker_position)
        top.addWidget(self.position_calculate)
        top.addStretch(1)
        layout.addLayout(top)

        offset_group = QGroupBox("Center Offset and Coordinate Convention")
        offset_form = QFormLayout(offset_group)
        offset_row = QHBoxLayout()
        self.position_offset_x = QDoubleSpinBox()
        self.position_offset_y = QDoubleSpinBox()
        self.position_offset_z = QDoubleSpinBox()
        for spin in (self.position_offset_x, self.position_offset_y, self.position_offset_z):
            spin.setRange(-5000.0, 5000.0)
            spin.setDecimals(4)
            spin.setValue(0.0)
        offset_row.addWidget(QLabel("X"))
        offset_row.addWidget(self.position_offset_x)
        offset_row.addWidget(QLabel("Y"))
        offset_row.addWidget(self.position_offset_y)
        offset_row.addWidget(QLabel("Z"))
        offset_row.addWidget(self.position_offset_z)
        offset_form.addRow("CenterOffset (mm)", offset_row)

        self.position_oppose_ap = QCheckBox("Oppose AP coordinate")
        self.position_oppose_ap.setChecked(True)
        offset_form.addRow(self.position_oppose_ap)
        layout.addWidget(offset_group)

        self.position_table = QTableWidget(3, 7)
        self.position_table.setHorizontalHeaderLabels([
            "Line", "Plane", "Rotation (deg)", "Peak bin",
            "Coordinate (mm)", "Peak/Background", "Use"
        ])
        plane_names = ["Axial", "Coronal", "Sagittal"]
        for row in range(3):
            self.position_table.setItem(row, 0, QTableWidgetItem(str(row)))
            plane_combo = QComboBox()
            plane_combo.addItems(plane_names)
            plane_combo.setCurrentIndex(row)
            self.position_table.setCellWidget(row, 1, plane_combo)

            rotation = QDoubleSpinBox()
            rotation.setRange(-360.0, 360.0)
            rotation.setDecimals(4)
            rotation.setValue(0.0)
            self.position_table.setCellWidget(row, 2, rotation)

            self.position_table.setItem(row, 3, QTableWidgetItem("-"))
            self.position_table.setItem(row, 4, QTableWidgetItem("-"))
            self.position_table.setItem(row, 5, QTableWidgetItem("-"))

            use_box = QCheckBox()
            use_box.setChecked(True)
            self.position_table.setCellWidget(row, 6, use_box)

        self.position_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.position_table)

        result_group = QGroupBox("Converted Tracker Position")
        result_layout = QVBoxLayout(result_group)
        self.position_result = QLabel(
            "Load a Tracker file, choose three directional lines, set Plane / Rotation / CenterOffset, "
            "then calculate the position."
        )
        self.position_result.setWordWrap(True)
        self.position_result.setTextInteractionFlags(Qt.TextSelectableByMouse)
        result_layout.addWidget(self.position_result)
        layout.addWidget(result_group)

        note = QLabel(
            "The basic conversion matches the attached TrackerApp structure: FFT peak bin → FOV coordinate → "
            "multi-direction geometric solve → CenterOffset → optional AP sign inversion. "
            "Gradient-map non-linearity correction is not applied unless a vendor gradient adapter is added."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        layout.addStretch(1)
        return page

    def _build_spike_results(self):
        page = QWidget()
        root = QHBoxLayout(page)
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.addWidget(QLabel("Processed Images"))
        self.spike_result_list = QTreeWidget()
        self.spike_result_list.setHeaderHidden(True)
        self.spike_result_list.itemClicked.connect(self._spike_result_selected)
        left_layout.addWidget(self.spike_result_list, 1)
        self.spike_result_summary = QLabel("Processed: 0 | Corrected: 0")
        left_layout.addWidget(self.spike_result_summary)
        self.save_spike_result_button = QPushButton("Save Corrected Image")
        self.save_spike_result_button.clicked.connect(self.save_current_spike_result)
        left_layout.addWidget(self.save_spike_result_button)

        grid = QWidget()
        grid_layout = QGridLayout(grid)
        self.spike_original_panel = ImagePanel("Original Image")
        self.spike_corrected_panel = ImagePanel("Corrected Image")
        self.spike_raw_before_panel = ImagePanel("Raw Before")
        self.spike_raw_after_panel = ImagePanel("Raw After")
        grid_layout.addWidget(self.spike_original_panel, 0, 0)
        grid_layout.addWidget(self.spike_corrected_panel, 0, 1)
        grid_layout.addWidget(self.spike_raw_before_panel, 1, 0)
        grid_layout.addWidget(self.spike_raw_after_panel, 1, 1)

        split = QSplitter(Qt.Horizontal)
        split.addWidget(left)
        split.addWidget(grid)
        split.setSizes([250, 1100])
        root.addWidget(split)
        return page


    def _build_artifact_detection(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        controls = QHBoxLayout()
        self.detect_artifact_button = QPushButton("Detect Artifact on Selected Images")
        self.detect_artifact_button.clicked.connect(self.detect_artifacts_from_db)
        controls.addWidget(self.detect_artifact_button)
        self.detect_tracker_button = QPushButton("Detect Current Tracker File")
        self.detect_tracker_button.clicked.connect(self.detect_tracker_artifact_from_db)
        controls.addWidget(self.detect_tracker_button)

        self.detect_selected_only = QCheckBox("Selected images only")
        self.detect_selected_only.setChecked(True)
        controls.addWidget(self.detect_selected_only)

        controls.addWidget(QLabel("Minimum samples / class"))
        self.detect_min_samples = QSpinBox()
        self.detect_min_samples.setRange(1, 100)
        self.detect_min_samples.setValue(2)
        controls.addWidget(self.detect_min_samples)
        controls.addStretch(1)
        layout.addLayout(controls)

        self.artifact_detection_summary = QLabel(
            "Open an Artifact DB and run detection. Classes without enough labeled samples are not predicted."
        )
        self.artifact_detection_summary.setWordWrap(True)
        layout.addWidget(self.artifact_detection_summary)

        self.artifact_detection_table = QTableWidget(0, 9)
        self.artifact_detection_table.setHorizontalHeaderLabels([
            "File", "Series", "Predicted Artifact", "Confidence",
            "Distance", "Training Support", "Status", "Alternatives", "Source Path"
        ])
        self.artifact_detection_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.artifact_detection_table.setSelectionMode(QTableWidget.ExtendedSelection)
        self.artifact_detection_table.horizontalHeader().setStretchLastSection(True)
        self.artifact_detection_table.cellDoubleClicked.connect(
            self.open_detected_artifact_image
        )
        layout.addWidget(self.artifact_detection_table, 1)

        classify_row = QHBoxLayout()
        self.send_detection_to_learning_button = QPushButton(
            "Send Selected Detection Rows to Artifact Learning"
        )
        self.send_detection_to_learning_button.clicked.connect(
            self.send_detected_rows_to_learning
        )
        classify_row.addWidget(self.send_detection_to_learning_button)
        classify_row.addStretch(1)
        layout.addLayout(classify_row)

        note = QLabel(
            "Spike is no longer a hard-coded threshold classification. "
            "Spike, Frequency, and other Artifact classes are predicted from the labeled Artifact DB. "
            "The separate Spike Diagnostic tab remains available for raw waveform review."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        return page

    def _build_artifact_learning(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        db_row = QHBoxLayout()
        self.artifact_db_label = QLabel("Artifact DB: Not opened")
        db_row.addWidget(self.artifact_db_label, 1)
        for label, callback in [
            ("Open / Create DB", self.open_artifact_database),
            ("Import DB JSON", self.import_artifact_database),
            ("Export DB JSON", self.export_artifact_database),
        ]:
            button = QPushButton(label)
            button.clicked.connect(callback)
            db_row.addWidget(button)
        layout.addLayout(db_row)

        selection = QGroupBox("Training Image Selection")
        selection_layout = QVBoxLayout(selection)
        self.artifact_selection_label = QLabel(
            "Select one or more DICOM images in Explorer, then add them as training images."
        )
        self.artifact_selection_label.setWordWrap(True)
        selection_layout.addWidget(self.artifact_selection_label)
        selection_buttons = QHBoxLayout()
        self.artifact_add_selected_button = QPushButton("Add Selected Images")
        self.artifact_add_selected_button.clicked.connect(self.collect_selected_artifact_images)
        selection_buttons.addWidget(self.artifact_add_selected_button)
        self.artifact_set_normal_button = QPushButton("Set Current as Normal Reference")
        self.artifact_set_normal_button.clicked.connect(self.set_current_normal_reference)
        selection_buttons.addWidget(self.artifact_set_normal_button)
        self.artifact_load_normal_button = QPushButton("Load Normal Reference")
        self.artifact_load_normal_button.clicked.connect(self.load_normal_reference)
        selection_buttons.addWidget(self.artifact_load_normal_button)
        self.artifact_preview_tracker_button = QPushButton("Preview Tracker Data")
        self.artifact_preview_tracker_button.clicked.connect(self.preview_tracker_in_artifact_learning)
        selection_buttons.addWidget(self.artifact_preview_tracker_button)
        self.artifact_save_tracker_button = QPushButton("Save Tracker Training Sample")
        self.artifact_save_tracker_button.clicked.connect(self.save_tracker_training_sample)
        selection_buttons.addWidget(self.artifact_save_tracker_button)
        selection_buttons.addStretch(1)
        selection_layout.addLayout(selection_buttons)
        preview_row = QHBoxLayout()
        self.artifact_preview_button = QPushButton("Preview Selected Image")
        self.artifact_preview_button.clicked.connect(self.preview_artifact_learning_image)
        preview_row.addWidget(self.artifact_preview_button)
        self.artifact_preview_prev = QPushButton("Previous Selected")
        self.artifact_preview_next = QPushButton("Next Selected")
        self.artifact_preview_prev.clicked.connect(lambda: self.navigate_artifact_preview(-1))
        self.artifact_preview_next.clicked.connect(lambda: self.navigate_artifact_preview(1))
        preview_row.addWidget(self.artifact_preview_prev)
        preview_row.addWidget(self.artifact_preview_next)
        self.artifact_clear_selected_button = QPushButton("Clear Training Selection")
        self.artifact_clear_all_button = QPushButton("Clear Training + Normal")
        self.artifact_clear_selected_button.clicked.connect(self.clear_selected_artifact_training)
        self.artifact_clear_all_button.clicked.connect(self.clear_all_artifact_training)
        preview_row.addWidget(self.artifact_clear_selected_button)
        preview_row.addWidget(self.artifact_clear_all_button)
        preview_row.addStretch(1)
        selection_layout.addLayout(preview_row)
        self.artifact_preview_panel = ImagePanel("Artifact Learning Preview")
        self.artifact_preview_panel.setMinimumHeight(260)
        selection_layout.addWidget(self.artifact_preview_panel)
        self.artifact_preview_position = 0
        self.artifact_normal_label = QLabel("Normal reference: None")
        selection_layout.addWidget(self.artifact_normal_label)
        layout.addWidget(selection)

        classify = QGroupBox("Classification")
        classify_form = QFormLayout(classify)
        type_row = QHBoxLayout()
        self.artifact_type_combo = QComboBox()
        type_row.addWidget(self.artifact_type_combo, 1)
        self.artifact_new_type = QLineEdit()
        self.artifact_new_type.setPlaceholderText("Manual new Artifact type")
        type_row.addWidget(self.artifact_new_type, 1)
        add_type = QPushButton("Add Type")
        add_type.clicked.connect(self.add_artifact_type_manual)
        type_row.addWidget(add_type)
        classify_form.addRow("Artifact", type_row)

        resolution_row = QHBoxLayout()
        self.artifact_resolution_combo = QComboBox()
        resolution_row.addWidget(self.artifact_resolution_combo, 1)
        self.artifact_new_resolution = QLineEdit()
        self.artifact_new_resolution.setPlaceholderText("Manual How to Resolved")
        resolution_row.addWidget(self.artifact_new_resolution, 1)
        add_resolution = QPushButton("Add Resolution")
        add_resolution.clicked.connect(self.add_resolution_manual)
        resolution_row.addWidget(add_resolution)
        classify_form.addRow("How to Resolved", resolution_row)

        self.artifact_notes = QTextEdit()
        self.artifact_notes.setMaximumHeight(90)
        self.artifact_notes.setPlaceholderText("Notes, conditions, service action, reproducibility...")
        classify_form.addRow("Notes", self.artifact_notes)

        save_button = QPushButton("Save Training Samples to Artifact DB")
        save_button.clicked.connect(self.save_artifact_training_samples)
        classify_form.addRow(save_button)
        layout.addWidget(classify)

        self.artifact_training_table = QTableWidget(0, 8)
        self.artifact_training_table.setHorizontalHeaderLabels([
            "ID", "File", "Series", "Instance", "Artifact",
            "How to Resolved", "Normal Compared", "Source Path"
        ])
        self.artifact_training_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.artifact_training_table.setSelectionMode(QTableWidget.ExtendedSelection)
        self.artifact_training_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.artifact_training_table, 1)

        reclassify = QPushButton("Apply Current Classification to Selected DB Rows")
        reclassify.clicked.connect(self.reclassify_selected_db_rows)
        layout.addWidget(reclassify)

        self.artifact_summary = QLabel(
            "Current detector: Spike. Artifact DB supports Frequency and future Artifact detectors."
        )
        self.artifact_summary.setWordWrap(True)
        layout.addWidget(self.artifact_summary)
        return page

    def _build_menu(self):
        file_menu = self.menuBar().addMenu("File")
        import_files = QAction("Import Files...", self)
        import_files.triggered.connect(self.open_import_selection)
        file_menu.addAction(import_files)
        import_folder = QAction("Import Folder...", self)
        import_folder.triggered.connect(self._open_folder_direct)
        file_menu.addAction(import_folder)
        file_menu.addSeparator()
        export_npz = QAction("Export Image/k-space NPZ", self); export_npz.triggered.connect(self.export_npz); file_menu.addAction(export_npz)
        export_header = QAction("Export DICOM Header Excel", self); export_header.triggered.connect(self.export_header_excel); file_menu.addAction(export_header)
        file_menu.addSeparator(); quit_action = QAction("Exit", self); quit_action.triggered.connect(self.close); file_menu.addAction(quit_action)

    def _apply_style(self):
        self.setStyleSheet("""
        QMainWindow, QWidget { background: #171a1f; color: #e6e9ee; }
        QMenuBar, QMenu { background: #20242b; }
        QTabWidget::pane { border: 1px solid #303946; }
        QTabBar::tab { background: #20242b; padding: 9px 18px; border: 1px solid #303946; }
        QTabBar::tab:selected { background: #1464cc; color: white; font-weight: 600; }
        QTabBar::tab:hover { background: #2b3440; }
        QPushButton, QComboBox, QSpinBox { background: #252b33; border: 1px solid #3b4654; padding: 6px; border-radius: 3px; }
        QPushButton:checked { background: #1464cc; border-color: #2c8cff; }
        QPushButton:hover { border-color: #6594c5; }
        QTreeWidget, QTableWidget { background: #111419; alternate-background-color: #191e25; border: 1px solid #303946; }
        QGroupBox { border: 1px solid #303946; border-radius: 4px; margin-top: 8px; padding-top: 8px; }
        QGroupBox::title { subcontrol-origin: margin; left: 8px; }
        #DropBanner { border: 1px dashed #5c7189; border-radius: 5px; background: #1d232b; }
        #DropBanner[dragActive="true"] { border: 2px solid #2f8cff; background: #20354f; }
        #InfoCard { border: 1px solid #303946; padding: 8px; background: #111419; }
        QSplitter::handle { background: #2f8cff; }
        QSplitter::handle:vertical { height: 4px; }
        QSplitter::handle:horizontal { width: 4px; }
        """)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls(): event.acceptProposedAction()

    def dropEvent(self, event):
        paths = [
            Path(url.toLocalFile())
            for url in event.mimeData().urls()
            if url.isLocalFile()
        ]
        if paths:
            event.setDropAction(Qt.CopyAction)
            event.accept()
            self.request_import(paths)

    def _position_progress_overlay(self, overlay=None):
        progress = overlay or getattr(self, "_active_import_progress", None)
        if progress is None:
            return

        parent = progress.parentWidget()
        if parent is None:
            return

        rect = parent.rect()
        x = max(12, (rect.width() - progress.width()) // 2)
        y = max(12, (rect.height() - progress.height()) // 2)
        progress.move(x, y)
        progress.raise_()

    def _make_progress(self, title: str, maximum: int):
        host = self.centralWidget() if self.centralWidget() is not None else self
        overlay = ServiceProgressDialog(title, host)
        overlay.setMaximum(maximum)
        self._position_progress_overlay(overlay)
        overlay.show()
        overlay.raise_()
        QApplication.processEvents()
        return overlay


    def _progress_step(self, progress: QProgressDialog, value: int, text: str) -> bool:
        progress.setLabelText(text)
        if progress.maximum() > 0:
            progress.setValue(min(value, progress.maximum()))
        QApplication.processEvents()
        return not progress.wasCanceled()

    def load_bitmap_image(self, path: Path):
        qimage = QImage(str(path))
        if qimage.isNull():
            raise ValueError(f"Unable to read image: {path}")
        gray = qimage.convertToFormat(QImage.Format_Grayscale8)
        width = gray.width()
        height = gray.height()
        ptr = gray.bits()
        array = np.frombuffer(ptr, dtype=np.uint8, count=gray.sizeInBytes())
        array = array.reshape((height, gray.bytesPerLine()))[:, :width].copy()

        self.current_image = array.astype(float)
        self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)
        self.current_ds = None
        self.current_source = str(path)
        self.source_kind = "bitmap"
        self.view_mode = "Original"
        self.original_window_level = None
        self.original_dynamic_range = None
        self.btn_original.setChecked(True)
        self.btn_fft.setChecked(False)
        self.btn_both.setChecked(False)

        self.processed_images[str(path)] = self.current_image.copy()
        self.processed_sources[str(path)] = path
        self._add_external_image_tree_item(path)
        self._update_output_root_label()
        self.refresh_images()
        self.info.setText(
            f"File: {path.name}\nType: Bitmap image\n"
            f"Size: {width} × {height}\nOriginal Image only"
        )

    def _add_external_image_tree_item(self, path: Path):
        root = None
        for index in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(index)
            if item.text(0) == "Image Files":
                root = item
                break
        if root is None:
            root = QTreeWidgetItem(["Image Files"])
            self.tree.addTopLevelItem(root)
        child = QTreeWidgetItem([path.name])
        child.setData(0, Qt.UserRole, ("processed", str(path)))
        root.addChild(child)
        root.setExpanded(True)
        self.tree.setCurrentItem(child)

    def _open_folder_direct(self):
        if self.import_in_progress:
            self.open_import_selection()
            return
        folder = QFileDialog.getExistingDirectory(
            self,
            "Select MRI Data Folder",
            "",
            QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks,
        )
        if folder:
            self.request_import([Path(folder)])

    def open_import_selection(self):
        if self.import_in_progress:
            QMessageBox.information(
                self,
                "Import in progress",
                "An import is already running.\n"
                "Wait for it to finish or press Cancel in the progress window.",
            )
            if hasattr(self, "_active_import_progress") and self._active_import_progress:
                self._active_import_progress.show()
                self._active_import_progress.raise_()
                self._active_import_progress.activateWindow()
            return

        dialog = QMessageBox(self)
        dialog.setWindowTitle("Import MRI Data")
        dialog.setText("Select how to import data.")
        files_button = dialog.addButton("Files", QMessageBox.AcceptRole)
        folder_button = dialog.addButton("Folder", QMessageBox.ActionRole)
        dialog.addButton("Cancel", QMessageBox.RejectRole)
        dialog.exec()

        selected_paths = []
        if dialog.clickedButton() == files_button:
            filenames, _ = QFileDialog.getOpenFileNames(
                self,
                "Select MRI Files",
                "",
                (
                    "Supported files "
                    "(*.dcm *.ima *.dicom *.zip *.raw *.bin *.dat *.7 *.pfile "
                    "*.img *.csv *.txt *.npy *.npz *.jpg *.jpeg *.png *.bmp);;"
                    "All files (*)"
                ),
            )
            selected_paths = [Path(name) for name in filenames]

        elif dialog.clickedButton() == folder_button:
            folder = QFileDialog.getExistingDirectory(
                self,
                "Select MRI Data Folder",
                "",
                QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks,
            )
            if folder:
                selected_paths = [Path(folder)]

        if selected_paths:
            self.request_import(selected_paths)

    def request_import(self, paths: list[Path]):
        clean_paths = [Path(path) for path in paths if Path(path).exists()]
        if not clean_paths:
            return

        if self.import_in_progress:
            self.statusBar().showMessage("Import request ignored: import is already running")
            if hasattr(self, "_active_import_progress") and self._active_import_progress:
                self._active_import_progress.show()
                self._active_import_progress.raise_()
                self._active_import_progress.activateWindow()
            return

        # Defer execution until the current drag/click event is fully completed.
        QTimer.singleShot(0, lambda p=clean_paths: self.import_paths(p))

    @Slot(str, int, int)
    def _on_import_progress(self, message: str, value: int, maximum: int):
        progress = getattr(self, "_active_import_progress", None)
        if progress is None:
            return

        progress.setLabelText(message)

        if maximum <= 0:
            progress.progress.setRange(0, 0)
        else:
            if (
                progress.progress.minimum() != 0
                or progress.progress.maximum() != maximum
            ):
                progress.progress.setRange(0, maximum)
            progress.setValue(value)

        self._position_progress_overlay(progress)
        if not progress.isVisible():
            progress.show()
        progress.raise_()
        QApplication.processEvents()


    def _on_import_completed(self, result: dict):
        try:
            for temp_dir in result.get("temp_dirs", []):
                if temp_dir not in self.temp_dirs:
                    self.temp_dirs.append(temp_dir)

            files = result.get("all_files", [])
            dicoms = result.get("dicoms", [])
            trackers = result.get("trackers", [])
            raw_files = result.get("raw_files", [])
            bitmaps = result.get("bitmaps", [])
            signals = result.get("signals", [])
            skipped = int(result.get("skipped", 0))

            known = set()
            for path in self.imported_paths:
                try:
                    known.add(str(path.resolve()).lower())
                except Exception:
                    pass

            for path in files:
                try:
                    key = str(path.resolve()).lower()
                except Exception:
                    key = str(path).lower()
                if key not in known:
                    self.imported_paths.append(path)
                    known.add(key)

            self.tree.blockSignals(True)
            try:
                self.tree.clear()

                if dicoms:
                    self.dicom_entries = list(dicoms)
                    self.lazy_dicom_cache_order.clear()
                    self.populate_dicom_tree()

                self.pending_tracker_paths = list(trackers)
                if trackers:
                    root = QTreeWidgetItem([f"Tracker P Files ({len(trackers)})"])
                    self.tree.addTopLevelItem(root)
                    for index, path in enumerate(trackers):
                        item = QTreeWidgetItem([path.name])
                        item.setData(0, Qt.UserRole, ("tracker_pending", index))
                        item.setToolTip(0, str(path))
                        root.addChild(item)
                    root.setExpanded(True)

                if raw_files:
                    root = QTreeWidgetItem([f"Raw / P Files ({len(raw_files)})"])
                    self.tree.addTopLevelItem(root)
                    for path in raw_files:
                        item = QTreeWidgetItem([path.name])
                        item.setData(0, Qt.UserRole, ("raw_file", str(path)))
                        item.setToolTip(0, str(path))
                        root.addChild(item)
                    root.setExpanded(True)

                if bitmaps:
                    root = QTreeWidgetItem([f"Image Files ({len(bitmaps)})"])
                    self.tree.addTopLevelItem(root)
                    for path in bitmaps:
                        item = QTreeWidgetItem([path.name])
                        item.setData(0, Qt.UserRole, ("bitmap_pending", str(path)))
                        item.setToolTip(0, str(path))
                        root.addChild(item)
                    root.setExpanded(True)

                if signals:
                    root = QTreeWidgetItem([f"1D / Array Data ({len(signals)})"])
                    self.tree.addTopLevelItem(root)
                    for path in signals:
                        item = QTreeWidgetItem([path.name])
                        item.setData(0, Qt.UserRole, ("signal_pending", str(path)))
                        item.setToolTip(0, str(path))
                        root.addChild(item)
                    root.setExpanded(True)
            finally:
                self.tree.blockSignals(False)

            total_recognized = (
                len(dicoms) + len(trackers) + len(raw_files)
                + len(bitmaps) + len(signals)
            )

            self.tabs.setCurrentIndex(0)
            self.statusBar().showMessage(
                f"Import completed: {len(dicoms):,} DICOM, "
                f"{len(trackers):,} Tracker, {len(raw_files):,} Raw/P, "
                f"{len(bitmaps) + len(signals):,} other"
            )

            if total_recognized == 0:
                QMessageBox.information(
                    self,
                    "Import completed",
                    f"No supported MRI data was recognized.\n"
                    f"Checked: {len(files):,}\nSkipped: {skipped:,}",
                )

            # Close progress first; decode the first image afterward.
            self._close_import_progress()
            if dicoms:
                QTimer.singleShot(100, lambda: self.show_dicom(0))

        except Exception as exc:
            self._on_import_failed(f"{type(exc).__name__}: {exc}")

    @Slot(str)
    def _on_import_failed(self, message: str):
        self._close_import_progress()
        QMessageBox.critical(self, "Import error", message)
        self.statusBar().showMessage(f"Import failed: {message}")

    @Slot()
    def _on_import_canceled(self):
        self._close_import_progress()
        self.statusBar().showMessage("Import canceled")

    @Slot()
    def _on_import_thread_finished(self):
        self.import_thread = None
        self.import_worker = None


    def _close_import_progress(self):
        self.import_poll_timer.stop()
        self.import_in_progress = False
        self.import_thread_started = False
        self.import_python_thread = None
        self.import_cancel_event.clear()

        self.drop_banner.setEnabled(True)
        self.drop_banner.title.setText(
            "Click or Drop DICOM / Raw / P File / 1D Data / Folder / ZIP Here"
        )

        progress = getattr(self, "_active_import_progress", None)
        self._active_import_progress = None
        if progress is not None:
            progress.hide()
            progress.deleteLater()

        QApplication.processEvents()


    def _queue_import_event(self, kind: str, payload=None):
        self.import_event_queue.put((kind, payload, time.monotonic()))

    def _import_thread_main(self, paths: list[Path]):
        temp_dirs = []
        try:
            supported = {
                ".dcm", ".ima", ".dicom", "",
                ".raw", ".bin", ".dat", ".7", ".pfile", ".img",
                ".csv", ".npy", ".npz",
                ".jpg", ".jpeg", ".png", ".bmp",
            }
            files = []
            checked = 0
            self._queue_import_event("progress", ("Collecting files...", 0, 0))

            for source in paths:
                if self.import_cancel_event.is_set():
                    self._queue_import_event("canceled")
                    return
                source = Path(source)
                if source.is_dir():
                    for candidate in source.rglob("*"):
                        if self.import_cancel_event.is_set():
                            self._queue_import_event("canceled")
                            return
                        checked += 1
                        if candidate.is_file() and candidate.suffix.lower() in supported:
                            files.append(candidate)
                        if checked % 100 == 0:
                            self._queue_import_event(
                                "progress",
                                (f"Scanning folder...\nChecked: {checked:,}\nCandidates: {len(files):,}", 0, 0),
                            )
                elif source.is_file() and source.suffix.lower() == ".zip":
                    root = Path(tempfile.mkdtemp(prefix="mr_image_explorer_"))
                    temp_dirs.append(root)
                    with zipfile.ZipFile(source) as archive:
                        members = archive.infolist()
                        total_members = max(len(members), 1)
                        for member_index, member in enumerate(members, start=1):
                            if self.import_cancel_event.is_set():
                                self._queue_import_event("canceled")
                                return
                            self._queue_import_event(
                                "progress",
                                (f"Extracting ZIP {member_index:,}/{total_members:,}\n{member.filename}", member_index, total_members),
                            )
                            target = (root / member.filename).resolve()
                            if not str(target).startswith(str(root.resolve())):
                                raise ValueError("Unsafe ZIP member path")
                            if member.is_dir():
                                target.mkdir(parents=True, exist_ok=True)
                                continue
                            target.parent.mkdir(parents=True, exist_ok=True)
                            with archive.open(member) as src, target.open("wb") as dst:
                                while True:
                                    if self.import_cancel_event.is_set():
                                        self._queue_import_event("canceled")
                                        return
                                    chunk = src.read(1024 * 1024)
                                    if not chunk:
                                        break
                                    dst.write(chunk)
                                    self._queue_import_event(
                                        "progress",
                                        (
                                            f"Extracting ZIP {member_index:,}/{total_members:,}\n"
                                            f"{member.filename}",
                                            member_index,
                                            total_members,
                                        ),
                                    )
                            if target.suffix.lower() in supported:
                                files.append(target)
                elif source.is_file():
                    files.append(source)

            unique=[]; seen=set()
            for path in files:
                try: key=str(path.resolve()).lower()
                except Exception: key=str(path).lower()
                if key not in seen:
                    seen.add(key); unique.append(path)
            files=unique
            total=max(len(files),1)
            dicoms=[]; trackers=[]; raws=[]; bitmaps=[]; signals=[]; skipped=0

            for idx,path in enumerate(files, start=1):
                if self.import_cancel_event.is_set():
                    self._queue_import_event("canceled"); return
                self._queue_import_event("progress", (f"Indexing {idx:,}/{len(files):,}\n{path.name}", idx, total))
                suffix=path.suffix.lower()
                if suffix==".txt":
                    continue
                if suffix in {".jpg",".jpeg",".png",".bmp"}:
                    bitmaps.append(path); continue
                if suffix in {".csv",".npy",".npz"}:
                    signals.append(path); continue
                try:
                    ds=pydicom.dcmread(str(path), stop_before_pixels=True, defer_size="1 KB", force=False)
                    rows=int(getattr(ds,"Rows",0) or 0); cols=int(getattr(ds,"Columns",0) or 0)
                    if rows<=0 or cols<=0: raise ValueError("not image")
                    instance=int(getattr(ds,"InstanceNumber",0) or 0)
                    pos=getattr(ds,"ImagePositionPatient",None)
                    z=float(pos[2]) if pos is not None and len(pos)>=3 else float(instance)
                    series=str(getattr(ds,"SeriesInstanceUID","") or "")
                    dicoms.append(DicomEntry(path=path, ds=ds, image=None, sort_key=(series,z,instance,path.name.lower())))
                    continue
                except Exception:
                    pass
                try:
                    name=path.name.lower(); is_tracker=("trackerimg" in name or "pfile" in name)
                    if not is_tracker and path.suffix=="" and path.stat().st_size>4096:
                        with path.open("rb") as fh: first=fh.read(4)
                        if len(first)==4:
                            rev=np.frombuffer(first,dtype="<f4")[0]
                            is_tracker=bool(np.isfinite(rev) and 1<rev<100)
                    if is_tracker: trackers.append(path)
                    elif suffix in {".raw",".bin",".dat",".7",".pfile",".img"}: raws.append(path)
                    else: skipped+=1
                except Exception:
                    skipped+=1

            dicoms.sort(key=lambda entry: entry.sort_key)
            self._queue_import_event("completed", {
                "all_files": files, "dicoms": dicoms, "trackers": trackers,
                "raw_files": raws, "bitmaps": bitmaps, "signals": signals,
                "skipped": skipped, "temp_dirs": temp_dirs,
            })
        except Exception as exc:
            self._queue_import_event("failed", f"{type(exc).__name__}: {exc}")

    def _poll_import_queue(self):
        handled = False

        while True:
            try:
                kind, payload, event_time = self.import_event_queue.get_nowait()
            except queue.Empty:
                break

            handled = True
            self.import_last_event_time = event_time

            if kind == "progress":
                message, value, maximum = payload
                self._on_import_progress(message, value, maximum)

            elif kind == "completed":
                self.import_poll_timer.stop()
                self._on_import_completed(payload)
                return

            elif kind == "failed":
                self.import_poll_timer.stop()
                self._on_import_failed(payload)
                return

            elif kind == "canceled":
                self.import_poll_timer.stop()
                self._on_import_canceled()
                return

        thread = self.import_python_thread
        if not self.import_in_progress or thread is None:
            return

        # Never treat a worker as stopped before thread.start() has completed.
        if not self.import_thread_started:
            return

        # Give the worker a startup grace period before declaring abnormal exit.
        elapsed = time.monotonic() - self.import_start_time
        if elapsed < 1.5:
            return

        if not thread.is_alive() and not handled:
            self.import_poll_timer.stop()

            # Drain once more in case the worker exited immediately after
            # placing its final event in the queue.
            try:
                kind, payload, event_time = self.import_event_queue.get_nowait()
            except queue.Empty:
                self._on_import_failed(
                    "Import worker stopped without returning a result."
                )
                return

            self.import_last_event_time = event_time
            if kind == "completed":
                self._on_import_completed(payload)
            elif kind == "failed":
                self._on_import_failed(payload)
            elif kind == "canceled":
                self._on_import_canceled()
            elif kind == "progress":
                message, value, maximum = payload
                self._on_import_progress(message, value, maximum)
                self._on_import_failed(
                    "Import worker ended after its final progress update "
                    "without returning a completion result."
                )


    def _cancel_python_import(self):
        self.import_cancel_event.set()
        progress = getattr(self, "_active_import_progress", None)
        if progress is not None:
            progress.setLabelText("Canceling import...")
            progress.cancel_button.setEnabled(False)

    def import_paths(self, paths: list[Path]):
        if self.import_in_progress:
            progress = getattr(self, "_active_import_progress", None)
            if progress is not None:
                progress.show()
                progress.raise_()
            return

        clean_paths = [Path(path) for path in paths if Path(path).exists()]
        if not clean_paths:
            QMessageBox.information(
                self,
                "Import MRI Data",
                "The selected path no longer exists.",
            )
            return

        self.import_in_progress = True
        self.import_thread_started = False
        self.import_start_time = time.monotonic()
        self.import_cancel_event.clear()

        while True:
            try:
                self.import_event_queue.get_nowait()
            except queue.Empty:
                break

        self.drop_banner.setEnabled(False)
        self.drop_banner.title.setText("Importing MRI Data...")
        self.drop_banner.repaint()
        QApplication.processEvents()

        progress = self._make_progress("Importing MRI Data", 1)
        progress.progress.setRange(0, 0)
        progress.setLabelText("Preparing import...")
        self._active_import_progress = progress
        progress.canceled.connect(self._cancel_python_import)

        progress.show()
        progress.raise_()
        QApplication.processEvents()

        thread = threading.Thread(
            target=self._import_thread_main,
            args=(clean_paths,),
            daemon=True,
            name="MRImageExplorerImport",
        )
        self.import_python_thread = thread

        # Start the worker first. Only then start the watchdog/poll timer.
        try:
            thread.start()
            self.import_thread_started = True
        except Exception as exc:
            self._on_import_failed(
                f"Unable to start Import worker: {type(exc).__name__}: {exc}"
            )
            return

        self.import_last_event_time = time.monotonic()
        self.import_poll_timer.start()




    def extract_zip(self, path: Path, parent_progress: Optional[QProgressDialog] = None) -> list[Path]:
        root = Path(tempfile.mkdtemp(prefix='mri_fft_'))
        self.temp_dirs.append(root)
        with zipfile.ZipFile(path) as z:
            members = z.infolist()
            for index, m in enumerate(members, start=1):
                if parent_progress is not None:
                    parent_progress.setLabelText(f"Extracting {path.name}: {index}/{len(members)}")
                    QApplication.processEvents()
                    if parent_progress.wasCanceled():
                        return []
                target = (root / m.filename).resolve()
                if not str(target).startswith(str(root.resolve())):
                    raise ValueError("Unsafe ZIP member")
                z.extract(m, root)
        return [p for p in root.rglob('*') if p.is_file()]

    def read_dicom_metadata(self, path: Path) -> DicomEntry:
        # Header-only read. Pixel Data is not decompressed during initial import.
        ds = pydicom.dcmread(
            str(path),
            stop_before_pixels=True,
            defer_size="1 KB",
            force=False,
        )
        rows = int(getattr(ds, "Rows", 0) or 0)
        cols = int(getattr(ds, "Columns", 0) or 0)
        if rows <= 0 or cols <= 0:
            raise ValueError("Not an image DICOM")

        instance = int(getattr(ds, "InstanceNumber", 0) or 0)
        pos = getattr(ds, "ImagePositionPatient", None)
        z = float(pos[2]) if pos is not None and len(pos) >= 3 else float(instance)
        series = str(getattr(ds, "SeriesInstanceUID", "") or "")
        sort_key = (series, z, instance, path.name.lower())
        return DicomEntry(path=path, ds=ds, image=None, sort_key=sort_key)

    def _ensure_dicom_image(self, index: int) -> DicomEntry:
        if not (0 <= index < len(self.dicom_entries)):
            raise IndexError(index)
        entry = self.dicom_entries[index]
        if entry.image is None:
            full_entry = self.read_dicom(entry.path)
            entry.ds = full_entry.ds
            entry.image = full_entry.image
            entry.sort_key = full_entry.sort_key

            self.lazy_dicom_cache_order = [
                value for value in self.lazy_dicom_cache_order if value != index
            ]
            self.lazy_dicom_cache_order.append(index)

            # Keep a small working set. Header metadata always remains available.
            while len(self.lazy_dicom_cache_order) > self.lazy_dicom_cache_limit:
                remove_index = self.lazy_dicom_cache_order.pop(0)
                if remove_index != index and 0 <= remove_index < len(self.dicom_entries):
                    self.dicom_entries[remove_index].image = None
        return entry

    def read_dicom(self, path: Path) -> DicomEntry:
        ds = pydicom.dcmread(str(path), force=False)
        if not hasattr(ds, 'PixelData'): raise ValueError('No pixel data')
        arr = ds.pixel_array
        if arr.ndim == 3: arr = arr[0]
        if arr.ndim != 2: raise ValueError('Not 2D')
        arr = arr.astype(float) * float(getattr(ds, 'RescaleSlope', 1)) + float(getattr(ds, 'RescaleIntercept', 0))
        instance = int(getattr(ds, 'InstanceNumber', 0) or 0)
        pos = getattr(ds, 'ImagePositionPatient', None)
        z = float(pos[2]) if pos is not None and len(pos) >= 3 else float(instance)
        return DicomEntry(path, ds, arr, (z, instance, path.name.lower()))

    def populate_dicom_tree(self):
        self.tree.clear()
        root = QTreeWidgetItem([f"DICOM Images ({len(self.dicom_entries)})"])
        self.tree.addTopLevelItem(root)

        grouped = {}
        for index, entry in enumerate(self.dicom_entries):
            series_uid = str(getattr(entry.ds, "SeriesInstanceUID", "") or "UnknownSeries")
            description = str(
                getattr(entry.ds, "SeriesDescription", "")
                or getattr(entry.ds, "ProtocolName", "")
                or "Unnamed Series"
            )
            series_number = str(getattr(entry.ds, "SeriesNumber", "") or "")
            grouped.setdefault((series_uid, description, series_number), []).append((index, entry))

        for (series_uid, description, series_number), entries in grouped.items():
            prefix = f"Series {series_number} — " if series_number else ""
            series_item = QTreeWidgetItem([f"{prefix}{description} ({len(entries)})"])
            series_item.setData(0, Qt.UserRole, ("series", series_uid))
            series_item.setToolTip(0, f"Series UID: {series_uid}")
            root.addChild(series_item)

            for index, entry in entries:
                instance = str(getattr(entry.ds, "InstanceNumber", index + 1) or index + 1)
                rows = str(getattr(entry.ds, "Rows", "") or "")
                cols = str(getattr(entry.ds, "Columns", "") or "")
                bits = str(getattr(entry.ds, "BitsStored", "") or "")
                detail = f"Inst {instance}"
                if rows and cols:
                    detail += f"  {rows}×{cols}"
                if bits:
                    detail += f"  {bits}bit"

                item = QTreeWidgetItem([f"{entry.path.name}  |  {detail}"])
                item.setData(0, Qt.UserRole, ("dicom", index))
                item.setToolTip(0, f"{entry.path}\nSeries: {description}\nInstance: {instance}")
                series_item.addChild(item)

            series_item.setExpanded(False)

        root.setExpanded(True)


    def show_dicom(self, index: int):
        if not self.dicom_entries:
            return

        index = max(0, min(int(index), len(self.dicom_entries) - 1))

        try:
            entry = self._ensure_dicom_image(index)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "DICOM Load Error",
                f"Unable to load image:\n{self.dicom_entries[index].path}\n\n{exc}",
            )
            return

        self.current_image = np.asarray(entry.image).copy()
        self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)
        self.current_ds = entry.ds
        self.current_source = str(entry.path)
        self.source_kind = "dicom"
        self.slice_index = index

        self.compensation_base_image = np.asarray(self.current_image).copy()
        self.compensation_base_kspace = np.asarray(self.current_kspace).copy()
        self.compensation_history = []
        self.compensation_history_index = -1
        self.compensation_preview = None
        self._update_compensation_history_buttons()

        self.original_window_level = None
        self.original_dynamic_range = None
        if self.raw_window_level is None or self.raw_dynamic_range is None:
            self._set_levels_for_target("Raw Data", np.log1p(np.abs(self.current_kspace)))

        self.view_mode = "Both"
        self.btn_both.setChecked(True)
        self.btn_fft.setChecked(False)
        self.btn_original.setChecked(False)

        self.slice_label.setText(f"Slice: {index + 1}/{len(self.dicom_entries)}")
        self.info.setText(self.dicom_info(entry.ds, entry.path, index))
        self._select_tree_dicom_index(index)
        self._update_output_root_label()
        self.refresh_images()
        QApplication.processEvents()


    def dicom_info(self, ds, path, index):
        spacing = getattr(ds, 'PixelSpacing', ['-', '-'])
        return (f"File: {path.name}\nType: DICOM\nSize: {getattr(ds,'Columns','-')} × {getattr(ds,'Rows','-')}\n"
                f"Bit Depth: {getattr(ds,'BitsAllocated','-')} bit\nPixel Spacing: {spacing}\n"
                f"Series: {getattr(ds,'SeriesDescription','-')}\nInstance: {index+1}/{len(self.dicom_entries)}\n"
                f"TE / TR: {getattr(ds,'EchoTime','-')} / {getattr(ds,'RepetitionTime','-')} ms")

    def change_slice(self, delta):
        if self.dicom_entries: self.show_dicom(getattr(self, 'slice_index', 0) + delta)

    def looks_tracker(self, p: Path) -> bool:
        n = p.name.lower()
        if 'trackerimg' in n or 'pfile' in n: return True
        if p.suffix == '' and p.stat().st_size > 4096:
            try:
                rev = np.frombuffer(p.read_bytes()[:4], dtype='<f4')[0]
                return np.isfinite(rev) and 1 < rev < 100
            except Exception: return False
        return False

    def show_tracker_in_workspace(self):
        if self.tracker_matrix is None:
            QMessageBox.information(self, "Tracker", "Load a Tracker file first.")
            return
        self.workspace_source_combo.setCurrentText("Tracker Raw Magnitude")
        self.current_kspace = np.asarray(self.tracker_matrix).copy()
        self.current_recon = ifft2c(self.current_kspace)
        self.current_image = np.abs(self.current_recon)
        self.current_source = str(self.tracker_source_path or "Tracker")
        self.tabs.setCurrentIndex(0)
        self.refresh_images()

    def _capture_tracker_state(self, path: Path, matrix: np.ndarray, matrix_size: int, offset: int):
        magnitude = np.abs(matrix).astype(np.float64)
        metrics=[]
        for i,line in enumerate(magnitude):
            metrics.append({"line":i,"peak":float(np.max(line)),"rms":float(np.sqrt(np.mean(line**2))),"energy":float(np.sum(line**2)),"mean":float(np.mean(line)),"variance":float(np.var(line)),"relative":0.0})
        rms=np.array([m["rms"] for m in metrics],float); lo=float(np.min(rms)); hi=float(np.max(rms)); span=max(hi-lo,np.finfo(float).eps)
        for m in metrics: m["relative"]=100.0*(m["rms"]-lo)/span
        strongest=max(metrics,key=lambda m:m["rms"]); idx=int(strongest["line"])
        return {"path":path,"matrix":np.asarray(matrix).copy(),"matrix_size":matrix_size,"offset":offset,"line_metrics":metrics,"strongest_line_index":idx,"strongest_line":np.asarray(matrix[idx]).copy(),"reconstructed_image":np.abs(ifft2c(matrix))}

    def _apply_tracker_state(self, index: int):
        if not (0 <= index < len(self.tracker_files)): return
        self.tracker_file_index=index; s=self.tracker_files[index]
        self.tracker_source_path=s["path"]; self.tracker_matrix=np.asarray(s["matrix"]).copy(); self.tracker_line_metrics=list(s["line_metrics"])
        self.tracker_strongest_line_index=int(s["strongest_line_index"]); self.tracker_strongest_line=np.asarray(s["strongest_line"]).copy(); self.tracker_reconstructed_image=np.asarray(s["reconstructed_image"]).copy(); self.tracker_shared_name=s["path"].name; self.tracker_selected_lines=[self.tracker_strongest_line_index]
        self.tracker_file_combo.blockSignals(True); self.tracker_file_combo.clear(); self.tracker_file_combo.addItems([x["path"].name for x in self.tracker_files]); self.tracker_file_combo.setCurrentIndex(index); self.tracker_file_combo.blockSignals(False)
        self._refresh_tracker_ranking(); self._plot_tracker_selected_lines(); self._update_tracker_navigation_buttons()
        self.tracker_summary.setText(f"{s['path'].name} | {index+1}/{len(self.tracker_files)} | Matrix {s['matrix_size']} × {s['matrix_size']} | Strongest line {self.tracker_strongest_line_index}")
        signal_name=f"{s['path'].name} | Strongest line {self.tracker_strongest_line_index}"
        self.signals=[x for x in self.signals if not str(x.get('name','')).startswith(f"{s['path'].name} | Strongest line")]
        self.signals.append({"name":signal_name,"data":self.tracker_strongest_line.copy()}); self.signal_combo.clear(); self.signal_combo.addItems([x["name"] for x in self.signals])
        if self.workspace_source_combo.currentText().startswith("Tracker"): self.change_workspace_source(self.workspace_source_combo.currentText())

    def _update_tracker_navigation_buttons(self):
        has=bool(self.tracker_files)
        self.tracker_prev_file_button.setEnabled(has and self.tracker_file_index>0); self.tracker_next_file_button.setEnabled(has and self.tracker_file_index<len(self.tracker_files)-1); self.tracker_clear_current_button.setEnabled(has); self.tracker_clear_all_button.setEnabled(has)

    def select_tracker_file_index(self, index:int):
        if 0 <= index < len(self.tracker_files): self._apply_tracker_state(index)

    def navigate_tracker_file(self, step:int):
        target=self.tracker_file_index+int(step)
        if 0 <= target < len(self.tracker_files): self._apply_tracker_state(target)

    def clear_current_tracker(self):
        if not self.tracker_files: return
        if QMessageBox.question(self,"Clear Tracker",f"Remove current Tracker file?\n{self.tracker_files[self.tracker_file_index]['path'].name}") != QMessageBox.Yes: return
        self.tracker_files.pop(self.tracker_file_index)
        if self.tracker_files: self._apply_tracker_state(min(self.tracker_file_index,len(self.tracker_files)-1))
        else: self._reset_tracker_state()

    def clear_all_trackers(self):
        if not self.tracker_files: return
        if QMessageBox.question(self,"Clear All Trackers","Clear all imported Tracker files?") != QMessageBox.Yes: return
        self.tracker_files.clear(); self._reset_tracker_state()

    def _reset_tracker_state(self):
        self.tracker_file_index=-1; self.tracker_matrix=None; self.tracker_source_path=None; self.tracker_line_metrics=[]; self.tracker_selected_lines=[]; self.tracker_strongest_line=None; self.tracker_strongest_line_index=-1; self.tracker_reconstructed_image=None; self.tracker_shared_name=""
        self.tracker_file_combo.clear(); self.tracker_table.setRowCount(0); self.tracker_raw_plot.clear(); self.tracker_summary.setText("No Tracker file loaded."); self.tracker_metrics_label.setText("-"); self._update_tracker_navigation_buttons()

    def keyPressEvent(self, event):
        if self.tabs.currentIndex() in (3,4,5,6,7):
            if event.key()==Qt.Key_Left: self.navigate_tracker_file(-1); event.accept(); return
            if event.key()==Qt.Key_Right: self.navigate_tracker_file(1); event.accept(); return
        super().keyPressEvent(event)

    def load_tracker(self, path: Path):
        raw = path.read_bytes()
        best = None

        for matrix in (512, 384, 320, 256, 192, 160, 128, 96, 64):
            need = matrix * matrix * 4
            if len(raw) < need:
                continue

            offset = len(raw) - need
            vals = np.frombuffer(
                raw,
                dtype="<i2",
                count=matrix * matrix * 2,
                offset=offset,
            )
            complex_data = (
                vals[0::2].astype(float)
                + 1j * vals[1::2].astype(float)
            )
            raw_matrix = complex_data.reshape(matrix, matrix)

            line_rms = np.sqrt(np.mean(np.abs(raw_matrix) ** 2, axis=1))
            score = float(
                np.percentile(line_rms, 99)
                / (np.median(line_rms) + 1e-9)
            )
            if best is None or score > best[0]:
                best = (score, matrix, offset, raw_matrix)

        if best is None:
            raise ValueError("No Tracker matrix candidate found")

        _, matrix, offset, raw_matrix = best
        state = self._capture_tracker_state(
            path, raw_matrix, matrix, offset
        )

        txt_path = path.with_suffix(".txt")
        if txt_path.exists():
            state["analysis_text"] = txt_path.read_text(
                encoding="utf-8", errors="replace"
            )
        else:
            state["analysis_text"] = ""

        existing = next(
            (
                i for i, item in enumerate(self.tracker_files)
                if item["path"] == path
            ),
            None,
        )
        if existing is None:
            self.tracker_files.append(state)
            index = len(self.tracker_files) - 1
        else:
            self.tracker_files[existing] = state
            index = existing

        self._apply_tracker_state(index)
        self.statusBar().showMessage(
            f"Loaded Tracker {index + 1}/{len(self.tracker_files)}: {path.name}"
        )


    def load_signal_file(self, path: Path):
        if path.suffix.lower() == '.npy': arr = np.load(path, allow_pickle=False)
        elif path.suffix.lower() == '.npz':
            z = np.load(path, allow_pickle=False); arr = z[list(z.keys())[0]]
        else:
            rows=[]
            with open(path, encoding='utf-8-sig', errors='replace') as f:
                for line in f:
                    nums=[]
                    for token in line.strip().replace(';', ',').split(','):
                        try: nums.append(float(token.strip()))
                        except ValueError: pass
                    if nums: rows.append(nums)
            if not rows: return
            arr = np.array([r[0]+1j*r[1] if len(r)>1 else r[0] for r in rows])
        arr=np.asarray(arr).squeeze()
        if arr.ndim == 1: self.add_signal(arr, path.name)
        elif arr.ndim == 2:
            self.current_image = np.abs(arr); self.current_kspace = fft2c(arr); self.current_recon = ifft2c(self.current_kspace); self.refresh_images()

    def add_signal(self, signal, name):
        signal=np.asarray(signal).squeeze()
        if signal.ndim != 1 or signal.size < 2: return
        self.signals.append({'name': name, 'data': signal})
        self.active_spike_indices = np.array([], dtype=int)
        self.signal_combo.addItem(name)
        self.signal_combo.setCurrentIndex(len(self.signals)-1)
        self.update_signal_plot(); self.update_tracker_preview(signal)

    def clear_signals(self):
        self.signals.clear(); self.signal_combo.clear(); self.signal_plot.clear(); self.tracker_plot.clear()

    def update_signal_plot(self):
        self.signal_plot.clear(); idx=self.signal_combo.currentIndex()
        if idx < 0 or idx >= len(self.signals): return
        data=np.asarray(self.signals[idx]['data']); component=self.signal_component.currentText()
        if self.signal_fft.isChecked(): data=np.fft.fftshift(np.fft.fft(data)); self.signal_plot.setLabel('bottom','Frequency bin')
        else: self.signal_plot.setLabel('bottom','Sample')
        y=self.component(data, component)
        self.signal_plot.plot(y)
        if self.active_spike_indices.size:
            valid = self.active_spike_indices[self.active_spike_indices < len(y)]
            if valid.size:
                scatter = pg.ScatterPlotItem(
                    x=valid,
                    y=np.asarray(y)[valid],
                    pen=pg.mkPen("#ff3b3b"),
                    brush=pg.mkBrush("#ff3b3b"),
                    size=9,
                    symbol="x",
                )
                self.signal_plot.addItem(scatter)

    def update_tracker_preview(self, signal):
        self.tracker_plot.clear(); self.tracker_plot.plot(np.abs(np.asarray(signal)))

    def _analyze_tracker_lines(self):
        self.tracker_line_metrics = []
        if self.tracker_matrix is None:
            return

        magnitude = np.abs(self.tracker_matrix).astype(np.float64)
        for line_index, line in enumerate(magnitude):
            self.tracker_line_metrics.append({
                "line": line_index,
                "peak": float(np.max(line)),
                "rms": float(np.sqrt(np.mean(line ** 2))),
                "energy": float(np.sum(line ** 2)),
                "mean": float(np.mean(line)),
                "variance": float(np.var(line)),
                "relative": 0.0,
            })

        rms_values = np.array([item["rms"] for item in self.tracker_line_metrics], dtype=float)
        low = float(np.min(rms_values))
        high = float(np.max(rms_values))
        span = max(high - low, np.finfo(float).eps)
        for item in self.tracker_line_metrics:
            item["relative"] = 100.0 * (item["rms"] - low) / span

    def _tracker_metric_key(self) -> str:
        return {
            "Peak": "peak",
            "RMS": "rms",
            "Energy": "energy",
            "Mean magnitude": "mean",
            "Variance": "variance",
        }.get(self.tracker_metric_combo.currentText(), "peak")

    def _refresh_tracker_ranking(self):
        if not hasattr(self, "tracker_table"):
            return
        if not self.tracker_line_metrics:
            self.tracker_table.setRowCount(0)
            return

        key = self._tracker_metric_key()
        ranked = sorted(self.tracker_line_metrics, key=lambda item: item[key], reverse=True)
        ranked = ranked[: self.tracker_top_count.value()]

        self.tracker_table.blockSignals(True)
        self.tracker_table.setRowCount(len(ranked))
        for row, item in enumerate(ranked):
            values = [
                row + 1,
                item["line"],
                f'{item["peak"]:.6g}',
                f'{item["rms"]:.6g}',
                f'{item["energy"]:.6g}',
                f'{item["mean"]:.6g}',
                f'{item["variance"]:.6g}',
                f'{item["relative"]:.1f}%',
            ]
            for col, value in enumerate(values):
                table_item = QTableWidgetItem(str(value))
                table_item.setData(Qt.UserRole, item["line"])
                self.tracker_table.setItem(row, col, table_item)
        self.tracker_table.resizeColumnsToContents()
        self.tracker_table.blockSignals(False)

        if ranked:
            self.tracker_table.selectRow(0)
            self._tracker_selection_changed()

    def _tracker_selection_changed(self):
        rows = sorted({item.row() for item in self.tracker_table.selectedItems()})
        selected = []
        for row in rows:
            item = self.tracker_table.item(row, 1)
            if item is not None:
                selected.append(int(item.data(Qt.UserRole)))
        self.tracker_selected_lines = selected[:8]
        self._plot_tracker_selected_lines()

    def _tracker_component(self, line: np.ndarray) -> np.ndarray:
        mode = self.tracker_component_combo.currentText()
        if mode == "Real":
            return np.real(line)
        if mode == "Imaginary":
            return np.imag(line)
        if mode == "Phase":
            return np.angle(line)
        return np.abs(line)

    def _plot_tracker_selected_lines(self):
        if not hasattr(self, "tracker_raw_plot"):
            return
        self.tracker_raw_plot.clear()
        if self.tracker_matrix is None or not self.tracker_selected_lines:
            self.tracker_metrics_label.setText("-")
            return

        summaries = []
        for line_index in self.tracker_selected_lines:
            raw_line = self.tracker_matrix[line_index]
            values = np.asarray(self._tracker_component(raw_line), dtype=float)
            self.tracker_raw_plot.plot(values)

            metric = next(
                (item for item in self.tracker_line_metrics if item["line"] == line_index),
                None,
            )
            if metric:
                summaries.append(
                    f'Line {line_index}: Peak {metric["peak"]:.6g}, '
                    f'RMS {metric["rms"]:.6g}, Energy {metric["energy"]:.6g}'
                )
        self.tracker_metrics_label.setText(" | ".join(summaries))

    def _select_next_tracker_line(self):
        row = self.tracker_table.currentRow()
        if 0 <= row < self.tracker_table.rowCount() - 1:
            self.tracker_table.clearSelection()
            self.tracker_table.selectRow(row + 1)

    def _select_previous_tracker_line(self):
        row = self.tracker_table.currentRow()
        if row > 0:
            self.tracker_table.clearSelection()
            self.tracker_table.selectRow(row - 1)

    def export_tracker_lines_csv(self):
        if not self.tracker_line_metrics:
            QMessageBox.information(self, "Tracker Export", "Load a Tracker file first.")
            return
        filename, _ = QFileDialog.getSaveFileName(
            self, "Export Tracker Line Metrics", "tracker_line_metrics.csv", "CSV files (*.csv)"
        )
        if not filename:
            return
        if not filename.lower().endswith(".csv"):
            filename += ".csv"

        import csv
        with open(filename, "w", newline="", encoding="utf-8-sig") as stream:
            writer = csv.writer(stream)
            writer.writerow(["Line", "Peak", "RMS", "Energy", "MeanMagnitude", "Variance", "RelativeStrength"])
            for item in sorted(self.tracker_line_metrics, key=lambda value: value["line"]):
                writer.writerow([
                    item["line"], item["peak"], item["rms"], item["energy"],
                    item["mean"], item["variance"], item["relative"]
                ])
        self.statusBar().showMessage(f"Tracker metrics exported: {filename}")

    def _raw_candidate_paths(self) -> list[Path]:
        candidates = []
        seen = set()
        for path in self.imported_paths:
            if not path.exists() or not path.is_file():
                continue
            suffix = path.suffix.lower()
            if self.looks_tracker(path) or suffix in {".raw", ".bin", ".dat", ".pfile"}:
                key = str(path.resolve())
                if key not in seen:
                    candidates.append(path)
                    seen.add(key)
        return candidates

    @staticmethod
    def _robust_z(values: np.ndarray) -> np.ndarray:
        values = np.asarray(values, dtype=np.float64)
        if values.size == 0:
            return values
        median = np.nanmedian(values)
        mad = np.nanmedian(np.abs(values - median))
        scale = max(1.4826 * mad, np.finfo(float).eps)
        return np.abs(values - median) / scale

    @staticmethod
    def _group_spike_indices(indices: np.ndarray) -> list[np.ndarray]:
        indices = np.asarray(indices, dtype=int)
        if indices.size == 0:
            return []
        cuts = np.where(np.diff(indices) > 1)[0] + 1
        return [group for group in np.split(indices, cuts) if group.size]

    def _extract_tracker_signal(self, path: Path) -> tuple[np.ndarray, str]:
        raw = path.read_bytes()
        best = None
        for matrix in (512, 384, 320, 256, 192, 160, 128, 96, 64):
            need = matrix * matrix * 4
            if len(raw) < need:
                continue
            offset = len(raw) - need
            vals = np.frombuffer(raw, dtype="<i2", count=matrix * matrix * 2, offset=offset)
            signal = vals[0::2].astype(np.float64) + 1j * vals[1::2].astype(np.float64)
            image = ifft2c(signal.reshape(matrix, matrix))
            contrast = np.percentile(np.abs(image), 99) / (np.median(np.abs(image)) + 1e-9)
            if best is None or contrast > best[0]:
                best = (contrast, signal, f"Tracker complex int16 {matrix}x{matrix}, offset {offset}")
        if best is None:
            raise ValueError("No valid Tracker complex matrix candidate")
        return best[1], best[2]

    def _extract_generic_raw_signal(self, path: Path) -> tuple[np.ndarray, str]:
        # Limit analysis memory while retaining enough data for spike screening.
        max_bytes = 32 * 1024 * 1024
        size = path.stat().st_size
        offset = max(0, size - max_bytes)
        if offset % 2:
            offset += 1
        with open(path, "rb") as stream:
            stream.seek(offset)
            raw = np.fromfile(stream, dtype="<i2")
        if raw.size < 8:
            raise ValueError("Not enough int16 samples")
        # Treat even/odd pairs as complex when possible. Magnitude analysis is
        # resistant to phase rotation and works for many MRI raw layouts.
        if raw.size >= 16 and raw.size % 2 == 0:
            signal = raw[0::2].astype(np.float64) + 1j * raw[1::2].astype(np.float64)
            description = f"Generic complex int16 tail, byte offset {offset}"
        else:
            signal = raw.astype(np.float64)
            description = f"Generic real int16 tail, byte offset {offset}"
        return signal, description

    def _analyze_spike_signal(self, signal: np.ndarray, threshold: float) -> dict:
        signal = np.asarray(signal).squeeze()
        magnitude = np.abs(signal).astype(np.float64)
        finite = np.isfinite(magnitude)
        if magnitude.size < 8 or not np.any(finite):
            raise ValueError("Signal has insufficient valid samples")
        replacement = np.nanmedian(magnitude[finite])
        magnitude = np.where(finite, magnitude, replacement)

        amplitude_z = self._robust_z(magnitude)
        first_difference = np.abs(np.diff(magnitude, prepend=magnitude[0]))
        difference_z = self._robust_z(first_difference)

        combined = np.maximum(amplitude_z, difference_z)
        raw_indices = np.flatnonzero(combined >= threshold)
        groups = self._group_spike_indices(raw_indices)

        # Represent each consecutive group by its strongest sample.
        representatives = []
        for group in groups:
            representatives.append(int(group[np.argmax(combined[group])]))
        representatives = np.asarray(representatives, dtype=int)

        strongest = int(np.argmax(combined))
        score = float(combined[strongest])
        return {
            "score": score,
            "flagged": bool(representatives.size and score >= threshold),
            "indices": representatives,
            "groups": len(groups),
            "strongest": strongest,
            "samples": int(magnitude.size),
        }

    def _selected_dicom_indices(self):
        indices = []
        for item in self.tree.selectedItems():
            data = item.data(0, Qt.UserRole)
            if data and data[0] == "dicom":
                indices.append(int(data[1]))
        if not indices and self.dicom_entries:
            indices = [getattr(self, "slice_index", 0)]
        return sorted(set(indices))

    def _spike_range_percent(self):
        mapping = {"Large": 100, "Mid": 70, "Small": 40}
        if self.spike_range_combo.currentText() == "Scale":
            return int(self.spike_scale_slider.value())
        return mapping.get(self.spike_range_combo.currentText(), 100)

    def _suppress_image_spikes(self, image: np.ndarray):
        source = np.asarray(image, dtype=float)
        kspace = fft2c(source)
        magnitude = np.abs(kspace)
        rows, cols = magnitude.shape
        cy, cx = rows // 2, cols // 2

        area_fraction = max(min(self._spike_range_percent() / 100.0, 1.0), 0.1)
        side_fraction = np.sqrt(area_fraction)
        half_h = max(4, int(rows * side_fraction / 2.0))
        half_w = max(4, int(cols * side_fraction / 2.0))
        y0, y1 = max(1, cy - half_h), min(rows - 1, cy + half_h)
        x0, x1 = max(1, cx - half_w), min(cols - 1, cx + half_w)

        # Robust local background from eight adjacent pixels.
        neighbor_stack = np.stack([
            np.roll(magnitude, (dy, dx), axis=(0, 1))
            for dy, dx in [
                (-1, -1), (-1, 0), (-1, 1),
                (0, -1),           (0, 1),
                (1, -1),  (1, 0),  (1, 1),
            ]
        ], axis=0)
        local_median = np.median(neighbor_stack, axis=0)
        local_mad = np.median(np.abs(neighbor_stack - local_median[None, ...]), axis=0)
        local_scale = np.maximum(1.4826 * local_mad, np.finfo(float).eps)

        region = magnitude[y0:y1, x0:x1]
        region_log = np.log1p(region)
        global_median = float(np.median(region_log))
        global_mad = float(np.median(np.abs(region_log - global_median)))
        global_scale = max(1.4826 * global_mad, np.finfo(float).eps)

        settings = {
            "Wide": (8.0, 7.0),
            "Mid": (5.0, 5.0),
            "Fine": (3.0, 3.5),
        }
        ratio_limit, global_z_limit = settings.get(
            self.spike_level_combo.currentText(), (5.0, 5.0)
        )

        ratio = magnitude / np.maximum(local_median, np.finfo(float).eps)
        global_z = (np.log1p(magnitude) - global_median) / global_scale

        mask = np.zeros_like(magnitude, dtype=bool)
        mask[y0:y1, x0:x1] = True
        # Protect the central low-frequency region.
        dc_radius = max(3, int(min(rows, cols) * 0.025))
        yy, xx = np.ogrid[:rows, :cols]
        mask &= ((yy - cy) ** 2 + (xx - cx) ** 2) > dc_radius ** 2

        candidate_mask = mask & (ratio > ratio_limit) & (global_z > global_z_limit)
        candidate_points = np.argwhere(candidate_mask)

        # Rank strongest candidates and cap correction to avoid over-processing.
        if candidate_points.size:
            scores = np.array([
                ratio[y, x] * max(global_z[y, x], 0.0)
                for y, x in candidate_points
            ])
            order = np.argsort(scores)[::-1]
            maximum_candidates = {
                "Wide": 40,
                "Mid": 120,
                "Fine": 300,
            }.get(self.spike_level_combo.currentText(), 120)
            candidate_points = candidate_points[order[:maximum_candidates]]

        corrected = kspace.copy()
        candidates = []

        def replace_point(y: int, x: int):
            ya, yb = max(0, y - 2), min(rows, y + 3)
            xa, xb = max(0, x - 2), min(cols, x + 3)
            patch = corrected[ya:yb, xa:xb].copy()
            patch_mag = magnitude[ya:yb, xa:xb]
            keep = patch_mag < np.percentile(patch_mag, 75)
            values = patch[keep]
            if values.size < 3:
                values = patch.reshape(-1)
            return np.median(np.real(values)) + 1j * np.median(np.imag(values))

        for y, x in candidate_points:
            y, x = int(y), int(x)
            corrected[y, x] = replace_point(y, x)
            candidates.append((y, x))

            # MRI image data has conjugate symmetry; compensate the paired point.
            sy = (2 * cy - y) % rows
            sx = (2 * cx - x) % cols
            if (sy, sx) != (y, x) and mask[sy, sx]:
                corrected[sy, sx] = replace_point(sy, sx)
                candidates.append((int(sy), int(sx)))

        result = np.abs(ifft2c(corrected))

        # Confirm that the candidate correction changes stripe energy.
        before_dx = np.mean(np.abs(np.diff(source, axis=1)))
        before_dy = np.mean(np.abs(np.diff(source, axis=0)))
        after_dx = np.mean(np.abs(np.diff(result, axis=1)))
        after_dy = np.mean(np.abs(np.diff(result, axis=0)))
        stripe_improvement = max(
            (before_dx - after_dx) / max(before_dx, 1e-9),
            (before_dy - after_dy) / max(before_dy, 1e-9),
        )

        # Multiple obvious k-space outliers are accepted even when the image-domain
        # improvement is modest, which is common in heavy multi-spike examples.
        detected = len(candidates) >= 2 and (
            stripe_improvement > 0.002 or len(candidates) >= 8
        )
        if not detected:
            return source.copy(), kspace, kspace.copy(), []

        return result, kspace, corrected, candidates


    def apply_spike_processing(self):
        dicom_indices = self._selected_dicom_indices()
        if not dicom_indices:
            # No original image selection: use existing RAW/PFile diagnostic.
            self.detect_spikes()
            return

        progress = self._make_progress("Spike Processing", len(dicom_indices))
        processed = []
        try:
            for number, index in enumerate(dicom_indices, start=1):
                if progress.wasCanceled():
                    return
                entry = self._ensure_dicom_image(index)
                progress.setLabelText(
                    f"Detecting repeated stripes and k-space spikes {number}/{len(dicom_indices)}: {entry.path.name}"
                )
                QApplication.processEvents()

                corrected, raw_before, raw_after, candidates = self._suppress_image_spikes(entry.image)
                if candidates:
                    self.current_ds = entry.ds
                    self.current_source = str(entry.path)
                    output = self._save_processed_image(
                        corrected,
                        f"{entry.path.stem}_NS",
                        "_NS",
                    )
                    processed.append({
                        "index": index,
                        "path": entry.path,
                        "output": output,
                        "original": np.asarray(entry.image).copy(),
                        "corrected": corrected,
                        "raw_before": raw_before,
                        "raw_after": raw_after,
                        "candidates": candidates,
                    })
                progress.setValue(number)
        finally:
            progress.close()

        if not processed:
            QMessageBox.information(self, "Spike Processing", "No Spike")
            return

        self.spike_image_results = processed
        last = processed[-1]
        self._display_processed_result(last["corrected"], last["output"])
        self._refresh_spike_diag()
        self.tabs.setCurrentIndex(1)
        QMessageBox.information(
            self,
            "Spike Processing",
            f"Processed {len(dicom_indices)} image(s).\n"
            f"Spike corrected: {len(processed)} image(s).",
        )

    def _refresh_spike_diag(self):
        self.spike_result_list.clear()
        results = getattr(self, "spike_image_results", [])
        for index, result in enumerate(results):
            item = QTreeWidgetItem([result["path"].name])
            item.setData(0, Qt.UserRole, index)
            self.spike_result_list.addTopLevelItem(item)
        self.spike_result_summary.setText(
            f"Processed: {len(results)} | Corrected: {len(results)}"
        )
        if results:
            item = self.spike_result_list.topLevelItem(len(results)-1)
            self.spike_result_list.setCurrentItem(item)
            self._show_spike_result(len(results)-1)

    def _spike_result_selected(self, item, column):
        index = item.data(0, Qt.UserRole)
        if index is not None:
            self._show_spike_result(int(index))

    def _show_spike_result(self, index: int):
        results = getattr(self, "spike_image_results", [])
        if not (0 <= index < len(results)):
            return
        result = results[index]
        self.current_spike_result_index = index
        self.spike_original_panel.set_image(result["original"])
        self.spike_corrected_panel.set_image(result["corrected"])
        self.spike_raw_before_panel.set_image(np.log1p(np.abs(result["raw_before"])))
        self.spike_raw_after_panel.set_image(np.log1p(np.abs(result["raw_after"])))
        for y, x in result["candidates"]:
            circle = pg.ScatterPlotItem(
                [x], [y], symbol="o", size=16,
                pen=pg.mkPen("r", width=2),
                brush=pg.mkBrush(255, 0, 0, 20)
            )
            self.spike_raw_before_panel.plot.addItem(circle)

    def save_current_spike_result(self):
        results = getattr(self, "spike_image_results", [])
        index = getattr(self, "current_spike_result_index", -1)
        if not (0 <= index < len(results)):
            return
        result = results[index]
        self.current_ds = self.dicom_entries[result["index"]].ds
        self.current_source = str(result["path"])
        output = self._save_processed_image(
            result["corrected"], f"{result['path'].stem}_NS", "_NS"
        )
        QMessageBox.information(self, "Spike Diag", f"Saved:\n{output}")

    def detect_spikes(self):
        candidates = self._raw_candidate_paths()
        if not candidates:
            QMessageBox.information(
                self,
                "Spike Detection",
                "No RAW, BIN, DAT, PFile, or TrackerImg files are currently imported. "
                "Drop a file or folder first.",
            )
            return

        threshold = float(self.spike_threshold.value())
        progress = self._make_progress("Detecting Spike Noise", len(candidates))
        results = []
        try:
            for index, path in enumerate(candidates, start=1):
                if not self._progress_step(
                    progress,
                    index - 1,
                    f"Analyzing {index}/{len(candidates)}: {path.name}",
                ):
                    self.statusBar().showMessage("Spike detection canceled")
                    return
                try:
                    if self.looks_tracker(path):
                        signal, source_type = self._extract_tracker_signal(path)
                    else:
                        signal, source_type = self._extract_generic_raw_signal(path)
                    analysis = self._analyze_spike_signal(signal, threshold)
                    analysis.update({
                        "path": path,
                        "name": path.name,
                        "type": source_type,
                        "signal": signal,
                        "error": "",
                    })
                except Exception as exc:
                    analysis = {
                        "path": path,
                        "name": path.name,
                        "type": "Unreadable",
                        "signal": np.array([], dtype=float),
                        "score": 0.0,
                        "flagged": False,
                        "indices": np.array([], dtype=int),
                        "groups": 0,
                        "strongest": -1,
                        "samples": 0,
                        "error": str(exc),
                    }
                results.append(analysis)
                progress.setValue(index)
        finally:
            progress.close()

        self.spike_results = sorted(results, key=lambda item: item["score"], reverse=True)
        self._refresh_spike_table()
        flagged = sum(1 for item in results if item["flagged"])
        errors = sum(1 for item in results if item["error"])
        self.spike_summary.setText(
            f"Scanned {len(results)} raw file(s) at robust threshold {threshold:.1f}. "
            f"Spike candidates: {flagged}. Read errors: {errors}."
        )
        self.tabs.setCurrentIndex(1)
        self.statusBar().showMessage(f"Spike detection complete: {flagged}/{len(results)} flagged")

    def _refresh_spike_table(self):
        if not hasattr(self, "spike_table"):
            return
        show_flagged = self.spike_only_flagged.isChecked()
        rows = [
            result for result in self.spike_results
            if (result["flagged"] or not show_flagged)
        ]
        self.spike_table.setSortingEnabled(False)
        self.spike_table.setRowCount(len(rows))
        for row, result in enumerate(rows):
            status = "SPIKE" if result["flagged"] else ("ERROR" if result["error"] else "OK")
            values = [
                status,
                result["name"],
                result["type"],
                f'{result["score"]:.2f}',
                str(result["groups"]),
                str(result["strongest"]) if result["strongest"] >= 0 else "-",
                str(result["samples"]),
                str(result["path"]),
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                item.setData(Qt.UserRole, result)
                if status == "SPIKE":
                    item.setBackground(pg.mkColor("#7a2430"))
                elif status == "ERROR":
                    item.setBackground(pg.mkColor("#6a5520"))
                self.spike_table.setItem(row, col, item)
        self.spike_table.setSortingEnabled(True)
        self.spike_table.resizeColumnsToContents()

    def _open_spike_result(self, row: int, column: int):
        item = self.spike_table.item(row, 0)
        if item is None:
            return
        result = item.data(Qt.UserRole)
        if not result or result["signal"].size < 2:
            if result and result["error"]:
                QMessageBox.warning(self, "Spike Result", result["error"])
            return

        name = f'Spike scan: {result["name"]}'
        self.signals.append({"name": name, "data": result["signal"]})
        self.signal_combo.addItem(name)
        self.signal_combo.setCurrentIndex(len(self.signals) - 1)
        self.active_spike_indices = np.asarray(result["indices"], dtype=int)
        self.signal_fft.setChecked(False)
        self.signal_component.setCurrentText("Magnitude")
        self.update_signal_plot()
        self.update_tracker_preview(result["signal"])
        self.tabs.setCurrentIndex(1)
        self.statusBar().showMessage(
            f'Opened {result["name"]}: {len(self.active_spike_indices)} spike group(s)'
        )

    @staticmethod
    def _position_plane_index(name: str) -> int:
        return {"Axial": 0, "Coronal": 1, "Sagittal": 2}.get(name, 0)

    def populate_position_top_lines(self):
        if self.tracker_matrix is None or not self.tracker_line_metrics:
            QMessageBox.information(self, "Tracker Position", "Load a Tracker PFile / TrackerImg first.")
            return

        ranked = sorted(self.tracker_line_metrics, key=lambda item: item["rms"], reverse=True)[:3]
        for row, metric in enumerate(ranked):
            self.position_table.setItem(row, 0, QTableWidgetItem(str(metric["line"])))
        self.tabs.setCurrentIndex(4)
        self.statusBar().showMessage("Top three Tracker lines assigned to position conversion.")

    def calculate_tracker_position(self):
        if self.tracker_matrix is None:
            QMessageBox.information(self, "Tracker Position", "Load a Tracker file first.")
            return

        fft_length = int(self.position_fft_length.value())
        fov = float(self.position_fov.value())
        measurements = []

        try:
            for row in range(self.position_table.rowCount()):
                use_widget = self.position_table.cellWidget(row, 6)
                if use_widget is not None and not use_widget.isChecked():
                    continue

                line_item = self.position_table.item(row, 0)
                if line_item is None:
                    continue
                line_index = int(line_item.text())
                if line_index < 0 or line_index >= self.tracker_matrix.shape[0]:
                    raise ValueError(f"Line {line_index} is outside the available range.")

                plane_widget = self.position_table.cellWidget(row, 1)
                rotation_widget = self.position_table.cellWidget(row, 2)
                plane = self._position_plane_index(plane_widget.currentText())
                rotation_deg = float(rotation_widget.value())

                peak_bin, coordinate_mm, snr_like, spectrum = signal_peak_coordinate(
                    self.tracker_matrix[line_index],
                    fft_length=fft_length,
                    fov_mm=fov,
                )
                measurement = DirectionMeasurement(
                    line_index=line_index,
                    plane=plane,
                    rotation_deg=rotation_deg,
                    peak_bin=peak_bin,
                    coordinate_mm=coordinate_mm,
                    snr_like=snr_like,
                )
                measurements.append(measurement)

                self.position_table.setItem(row, 3, QTableWidgetItem(f"{peak_bin:.4f}"))
                self.position_table.setItem(row, 4, QTableWidgetItem(f"{coordinate_mm:.4f}"))
                self.position_table.setItem(row, 5, QTableWidgetItem(f"{snr_like:.3f}"))

            offset = np.array([
                self.position_offset_x.value(),
                self.position_offset_y.value(),
                self.position_offset_z.value(),
            ], dtype=float)

            scanner_xyz, pqr, rms_error = solve_position(
                measurements,
                center_offset=offset,
                oppose_ap=self.position_oppose_ap.isChecked(),
            )
            self.tracker_position_measurements = measurements
            self.position_result.setText(
                f"Coordinates MR / Scanner (mm):\n"
                f"  X = {scanner_xyz[0]:.4f}\n"
                f"  Y = {scanner_xyz[1]:.4f}\n"
                f"  Z = {scanner_xyz[2]:.4f}\n\n"
                f"Coordinates PQR (mm):\n"
                f"  P = {pqr[0]:.4f}\n"
                f"  Q = {pqr[1]:.4f}\n"
                f"  R = {pqr[2]:.4f}\n\n"
                f"Projection RMS residual = {rms_error:.5f} mm\n"
                f"Gradient-map correction = Not applied"
            )
            self.statusBar().showMessage("Tracker position conversion completed.")
        except Exception as exc:
            QMessageBox.critical(self, "Tracker Position Error", str(exc))

    def component(self, arr, mode):
        if mode == 'Real': return np.real(arr)
        if mode == 'Imaginary': return np.imag(arr)
        if mode == 'Phase': return np.angle(arr)
        return np.abs(arr)

    def change_workspace_source(self, source_name: str):
        if source_name == "Tracker Raw Magnitude":
            if self.tracker_matrix is None:
                return
            self.current_kspace = np.asarray(self.tracker_matrix).copy()
            self.current_recon = ifft2c(self.current_kspace)
            self.current_image = np.abs(self.current_recon)
            self.current_source = str(self.tracker_source_path or "Tracker")
        elif source_name == "Tracker Reconstructed":
            if self.tracker_reconstructed_image is None:
                return
            self.current_image = np.asarray(self.tracker_reconstructed_image).copy()
            self.current_kspace = fft2c(self.current_image)
            self.current_recon = ifft2c(self.current_kspace)
            self.current_source = str(self.tracker_source_path or "Tracker")
        self.refresh_images()

    def send_tracker_to_signal_studio(self):
        if self.tracker_strongest_line is None:
            QMessageBox.information(self, "Tracker", "Load a Tracker file first.")
            return
        name = f"{self.tracker_shared_name} | Strongest line {self.tracker_strongest_line_index}"
        existing = next((i for i, item in enumerate(self.signals) if item.get("name") == name), None)
        if existing is None:
            self.add_signal(np.asarray(self.tracker_strongest_line).copy(), name)
            existing = len(self.signals) - 1
        self.signal_combo.setCurrentIndex(existing)
        self.signal_component.setCurrentText("Magnitude")
        self.signal_fft.setChecked(False)
        self.tabs.setCurrentIndex(1)
        self.update_signal_plot()

    def preview_tracker_in_artifact_learning(self):
        if self.tracker_matrix is None:
            QMessageBox.information(self, "Artifact Learning", "Load a Tracker file first.")
            return
        image = np.log1p(np.abs(self.tracker_matrix))
        self.artifact_preview_panel.label.setText(
            f"Tracker Raw Magnitude: {self.tracker_shared_name}"
        )
        self.artifact_preview_panel.set_image(image)
        self.artifact_selection_label.setText(
            f"Tracker data ready for learning: {self.tracker_shared_name}"
        )

    def save_tracker_training_sample(self):
        if self.tracker_matrix is None or self.tracker_source_path is None:
            QMessageBox.information(self, "Artifact Learning", "Load a Tracker file first.")
            return
        if not self._ensure_artifact_database():
            return
        artifact_type = self.artifact_type_combo.currentText().strip() or "Not Artifact"
        resolution = self.artifact_resolution_combo.currentText().strip()
        notes = self.artifact_notes.toPlainText().strip()
        tracker_image = np.log1p(np.abs(self.tracker_matrix))
        features = image_features(tracker_image, self.normal_reference_image)
        features.update({
            "data_type": "Tracker Raw",
            "strongest_line": self.tracker_strongest_line_index,
            "line_peak": float(np.max(np.abs(self.tracker_strongest_line))) if self.tracker_strongest_line is not None else 0.0,
            "line_rms": float(np.sqrt(np.mean(np.abs(self.tracker_strongest_line) ** 2))) if self.tracker_strongest_line is not None else 0.0,
        })
        self.artifact_db.add_sample(
            source_path=str(self.tracker_source_path),
            source_name=self.tracker_source_path.name,
            series_uid="TRACKER",
            series_description="Tracker Raw Data",
            instance_number=self.tracker_strongest_line_index,
            artifact_type=artifact_type,
            resolution=resolution,
            is_normal_reference=False,
            normal_reference_path=str(self.normal_reference_path or ""),
            features=features,
            notes=notes,
        )
        self.refresh_artifact_training_table()
        self.artifact_summary.setText(
            f"Saved Tracker training sample as '{artifact_type}'."
        )

    def detect_tracker_artifact_from_db(self):
        if self.tracker_matrix is None:
            QMessageBox.information(self, "Artifact Detection", "Load a Tracker file first.")
            return
        if not self._ensure_artifact_database():
            return
        keys, training, labels, metadata = self.artifact_db.training_feature_vectors()
        tracker_image = np.log1p(np.abs(self.tracker_matrix))
        features = image_features(tracker_image, self.normal_reference_image)
        features.update({
            "data_type": "Tracker Raw",
            "strongest_line": self.tracker_strongest_line_index,
        })
        vector = features_to_vector(features, keys)
        result = classify_feature_vector(
            vector, training, labels,
            minimum_samples_per_class=self.detect_min_samples.value(),
        )
        self.artifact_detection_table.setRowCount(1)
        alternatives = ", ".join(
            f"{label} {confidence * 100:.1f}%"
            for label, confidence, distance, support in result.alternatives[1:4]
        )
        values = [
            self.tracker_source_path.name if self.tracker_source_path else "Tracker",
            "Tracker Raw Data",
            result.label,
            f"{result.confidence * 100:.1f}%",
            f"{result.distance:.4f}" if np.isfinite(result.distance) else "-",
            result.support,
            result.status,
            alternatives,
            str(self.tracker_source_path or ""),
        ]
        for column, value in enumerate(values):
            self.artifact_detection_table.setItem(0, column, QTableWidgetItem(str(value)))
        self.artifact_detection_summary.setText(
            f"Tracker prediction: {result.label} | Confidence {result.confidence * 100:.1f}%"
        )
        self.tabs.setCurrentIndex(2)

    def _image_mouse_action_changed(self, action: str):
        if action == "Auto Window/Level":
            self.auto_levels()
            self.statusBar().showMessage("Window/Level recalculated automatically")
            return
        self.current_mouse_action = action
        self.primary_panel.mouse_action = action
        self.secondary_panel.mouse_action = action
        self.mouse_action_label.setText(f"Mouse: {action}")
        tooltips = {
            "Window/Level": "Wheel: Level\nCtrl+Wheel: Width",
            "Pan": "Left-drag: Pan",
            "Zoom": "Drag a rectangle: Zoom",
            "Paging": "Mouse wheel: Previous / Next image",
            "ROI": "Drag corners: resize ROI",
        }
        self.mouse_action_label.setToolTip(tooltips.get(action, action))
        if action == "ROI":
            if self.current_kspace is not None and self.source_kind != "bitmap":
                self.primary_panel.show_comp_roi()
            else:
                self.statusBar().showMessage("ROI requires raw/k-space data")
        self.statusBar().showMessage(f"Mouse action selected: {action}")


    def _image_view_requested(self, mode: str):
        if mode == "FFT_CURRENT":
            if self.current_image is None:
                return
            self.fft_back_image = np.asarray(self.current_image).copy()
            self.current_kspace = fft2c(np.asarray(self.current_image, dtype=float))
            self.current_recon = ifft2c(self.current_kspace)
            self.raw_window_level = None
            self.raw_dynamic_range = None
            self.fft_view_active = True
            fft_image = np.log1p(np.abs(self.current_kspace))
            self.primary_panel.label.setText("FFT Current Image")
            self.primary_panel.set_image(
                fft_image,
                levels=self._levels_for_target("Raw Data", fft_image, auto_original=False),
            )
            self.secondary_panel.hide()
            self.view_mode = "FFT"
            self.statusBar().showMessage("FFT calculated and displayed in the current panel")
            return
        if mode == "BACK_FFT":
            if self.fft_back_image is not None:
                self.current_image = np.asarray(self.fft_back_image).copy()
                self.current_kspace = fft2c(self.current_image)
                self.current_recon = ifft2c(self.current_kspace)
            self.fft_view_active = False
            self.fft_back_image = None
            self.set_view_mode("Original")
            self.statusBar().showMessage("Returned to the image before FFT")
            return
        if mode == "Default":
            self.profile_mode.setCurrentText("Magnitude")
            self.level_target_combo.setCurrentText("Original Image")
            self.original_window_level = None
            self.original_dynamic_range = None
            self.raw_window_level = None
            self.raw_dynamic_range = None
            self.fft_view_active = False
            self.fft_back_image = None
            self.primary_panel.plot.getViewBox().autoRange()
            self.secondary_panel.plot.getViewBox().autoRange()
            self.set_view_mode("Both" if self.source_kind != "bitmap" else "Original")
            return
        self.fft_view_active = False
        self.fft_back_image = None
        self.set_view_mode(mode)


    def _image_level_wheel(self, panel, step: float, adjust_width: bool):
        target = "Raw Data" if panel is self.primary_panel and self.view_mode in {"FFT", "Both"} else "Original Image"
        self.level_target_combo.setCurrentText(target)

        if target == "Raw Data":
            center = float(self.raw_window_level or 0.0)
            width = max(float(self.raw_dynamic_range or 1.0), 1e-9)
        else:
            center = float(self.original_window_level or 0.0)
            width = max(float(self.original_dynamic_range or 1.0), 1e-9)

        increment = max(width * 0.04, 1e-6)
        if adjust_width:
            width = max(width + step * increment, 1e-9)
        else:
            center += step * increment

        if target == "Raw Data":
            self.raw_window_level = center
            self.raw_dynamic_range = width
        else:
            self.original_window_level = center
            self.original_dynamic_range = width

        self._sync_level_controls()
        self.refresh_images()

    def _accordion_opened(self, opened):
        for section in self.accordion_sections:
            if section is not opened: section.set_expanded(False,False)

    def _spike_range_changed(self,value):
        visible=value=="Scale"; self.spike_scale_slider.setVisible(visible); self.spike_scale_label.setVisible(visible)

    def show_dicom_header_popup(self):
        if self.current_ds is None: QMessageBox.information(self,"DICOM Header","Load a DICOM image first."); return
        DicomHeaderDialog(self.current_ds,self.current_source,self).exec()

    def quick_spike_detect_prototype(self):
        if not self.dicom_entries:
            QMessageBox.information(self, "Quick Spike Detect", "Load DICOM images first.")
            return
        progress=self._make_progress("Quick Spike Detect",len(self.dicom_entries))
        records=[]
        def rz(values):
            a=np.asarray(values,dtype=float); med=float(np.median(a)); mad=float(np.median(np.abs(a-med))); s=max(1.4826*mad,1e-9); return (a-med)/s
        try:
            for n,entry in enumerate(self.dicom_entries,1):
                if progress.wasCanceled(): break
                progress.setLabelText(f"Screening {n}/{len(self.dicom_entries)}: {entry.path.name}")
                img=np.asarray(entry.image,dtype=float); c=img-np.median(img); rows,cols=c.shape
                def pscore(p):
                    sp=np.abs(np.fft.rfft(p))
                    if sp.size<12:return 0.0
                    z=rz(sp[2:]); return float(np.mean(np.sort(z)[-6:])+min(int(np.sum(z>6)),8)*0.7)
                sr,sc=pscore(np.mean(c,axis=1)),pscore(np.mean(c,axis=0)); stripe=max(sr,sc); axis='row' if sr>=sc else 'column'
                mag=np.abs(fft2c(c)); cy,cx=rows//2,cols//2
                yy,xx=np.ogrid[:rows,:cols]; cw=max(2,int(min(rows,cols)*0.02)); cr=max(4,int(min(rows,cols)*0.035))
                valid=np.ones_like(mag,dtype=bool)
                valid[np.abs(np.arange(rows)[:,None]-cy)<=cw]=False
                valid[:,np.abs(np.arange(cols)[None,:]-cx)<=cw]=False
                valid &= ((yy-cy)**2+(xx-cx)**2)>cr**2
                vals=np.log1p(mag[valid]); kz=rz(vals); ks=float(np.percentile(kz,99.95)+min(int(np.sum(kz>8)),12)*0.35+min(int(np.sum(kz>12)),6)*0.8)
                field=np.zeros_like(mag,dtype=float); field[valid]=kz; coords=np.argwhere(field>8); pairs=0
                for y,x in coords[:200]:
                    sy=(2*cy-int(y))%rows; sx=(2*cx-int(x))%cols
                    if field[sy,sx]>6:pairs+=1
                consist=0.0
                if coords.size:
                    dy=np.abs(coords[:,0]-cy); dx=np.abs(coords[:,1]-cx); consist=float(np.mean(dx>dy) if axis=='row' else np.mean(dy>dx))*3.0
                score=0.52*stripe+0.32*ks+0.10*min(pairs,12)*0.6+0.06*consist
                series=str(getattr(entry.ds,'SeriesInstanceUID','') or getattr(entry.ds,'SeriesNumber','') or 'UnknownSeries')
                records.append(dict(index=n-1,series=series,raw_score=float(score),stripe_score=float(stripe),kspace_score=float(ks),pair_hits=int(pairs)))
                progress.setValue(n)
        finally: progress.close()
        by={}
        for r in records: by.setdefault(r['series'],[]).append(r)
        high=[]; review=[]
        for group in by.values():
            z=rz([r['raw_score'] for r in group])
            for r,zz in zip(group,z):
                if zz>=5 and r['stripe_score']>=8 and r['kspace_score']>=8 and r['pair_hits']>=1: high.append(r['index'])
                elif zz>=3.2 and r['stripe_score']>=6 and r['kspace_score']>=6: review.append(r['index'])
        self.quick_spike_indices=sorted(set(high)); self.quick_spike_review_indices=sorted(set(review))
        self._highlight_quick_spike_candidates(self.quick_spike_indices,self.quick_spike_review_indices)
        dlg=QMessageBox(self)
        dlg.setWindowTitle("Quick Spike Detect")
        dlg.setText(
            f"High Confidence: {len(high)}\n"
            f"Review: {len(review)}\n"
            f"Total Images: {len(self.dicom_entries)}"
        )
        dlg.addButton('Close',QMessageBox.RejectRole); apply=dlg.addButton('Apply High Confidence',QMessageBox.AcceptRole); dlg.exec()
        if dlg.clickedButton()==apply: self._select_quick_spike_candidates(self.quick_spike_indices)


    def _highlight_quick_spike_candidates(self, high_indices, review_indices=None):
        high={int(v) for v in high_indices}; review={int(v) for v in (review_indices or [])}
        it=QTreeWidgetItemIterator(self.tree)
        while it.value():
            item=it.value(); data=item.data(0,Qt.UserRole)
            if data and data[0]=="dicom":
                i=int(data[1])
                if i in high: item.setForeground(0,pg.mkBrush("#ff4f4f")); item.setToolTip(0,"Quick Spike: High Confidence")
                elif i in review: item.setForeground(0,pg.mkBrush("#ffb347")); item.setToolTip(0,"Quick Spike: Review")
                else: item.setForeground(0,pg.mkBrush("#d8e5ef")); item.setToolTip(0,"")
            it+=1


    def _select_quick_spike_candidates(self, indices):
        target = {int(value) for value in indices}
        self.tree.blockSignals(True)
        try:
            self.tree.clearSelection()
            iterator = QTreeWidgetItemIterator(self.tree)
            first_item = None
            while iterator.value():
                item = iterator.value()
                data = item.data(0, Qt.UserRole)
                if data and data[0] == "dicom" and int(data[1]) in target:
                    item.setSelected(True)
                    if first_item is None:
                        first_item = item
                iterator += 1
            if first_item is not None:
                self.tree.setCurrentItem(first_item)
        finally:
            self.tree.blockSignals(False)

        if target:
            self.show_dicom(min(target))


    def on_display_type_changed(self, value: str):
        self.refresh_images()
        self.update_line_profile()

    @staticmethod
    def _display_component(array: np.ndarray, mode: str) -> np.ndarray:
        data = np.asarray(array)
        if mode == "Real":
            return np.real(data)
        if mode == "Imaginary":
            return np.imag(data)
        if mode == "Phase":
            return np.angle(data)
        return np.abs(data)

    def set_view_mode(self, mode):
        if self.source_kind == "bitmap" and mode != "Original":
            mode = "Original"
        self.view_mode = mode
        for button, value in [
            (self.btn_fft, "FFT"),
            (self.btn_original, "Original"),
            (self.btn_both, "Both"),
        ]:
            button.setChecked(value == mode)
        self.refresh_images()


    def refresh_images(self):
        if self.current_image is None:
            return
        mode = self.profile_mode.currentText() if hasattr(self, "profile_mode") else "Magnitude"
        orig = self._display_component(self.current_image, mode)

        if self.source_kind == "bitmap":
            self.view_mode = "Original"
            auto_original = self.level_preset_combo.currentText() == "Auto"
            original_levels = self._levels_for_target("Original Image", orig, auto_original=auto_original)
            self.primary_panel.show()
            self.secondary_panel.hide()
            self.primary_panel.label.setText(f"Original Image — {mode}")
            self.primary_panel.set_image(orig, levels=original_levels)
            self._sync_level_controls()
            rows, cols = orig.shape
            self._configure_line_control(rows, cols)
            self._sync_lines()
            self.update_line_profile()
            return

        if self.current_kspace is None:
            return
        raw_component = self._display_component(self.current_kspace, mode)
        fft_img = np.log1p(np.abs(raw_component)) if mode == "Magnitude" else raw_component
        auto_original = self.level_preset_combo.currentText() == "Auto"
        original_levels = self._levels_for_target("Original Image", orig, auto_original=auto_original)
        raw_levels = self._levels_for_target("Raw Data", fft_img, auto_original=False)

        if self.view_mode == "FFT":
            self.primary_panel.show()
            self.secondary_panel.hide()
            self.primary_panel.label.setText(f"FFT (k-space) — {mode}")
            self.primary_panel.set_image(fft_img, levels=raw_levels)
        elif self.view_mode == "Original":
            self.primary_panel.show()
            self.secondary_panel.hide()
            self.primary_panel.label.setText(f"Original Image — {mode}")
            self.primary_panel.set_image(orig, levels=original_levels)
        else:
            self.primary_panel.show()
            self.secondary_panel.show()
            self.primary_panel.label.setText(f"FFT (k-space) — {mode}")
            self.secondary_panel.label.setText(f"Original Image — {mode}")
            self.primary_panel.set_image(fft_img, levels=raw_levels)
            self.secondary_panel.set_image(orig, levels=original_levels)

        rows, cols = orig.shape
        self.line_row = min(max(int(self.line_row_ratio * max(rows - 1, 1)), 0), rows - 1)
        self.line_col = min(max(int(self.line_col_ratio * max(cols - 1, 1)), 0), cols - 1)
        self._configure_line_control(rows, cols)
        self._sync_lines()
        self._sync_level_controls()
        self.update_line_profile()


    def _configure_line_control(self, rows, cols):
        maximum = rows-1 if self.line_orientation=='Row' else cols-1
        self.line_spin.blockSignals(True); self.line_slider.blockSignals(True)
        self.line_spin.setRange(0, maximum); self.line_slider.setRange(0, maximum)
        value=self.line_row if self.line_orientation=='Row' else self.line_col
        self.line_spin.setValue(value); self.line_slider.setValue(value)
        self.line_spin.blockSignals(False); self.line_slider.blockSignals(False)

    def _orientation_changed(self, text):
        self.line_orientation=text
        if self.current_image is not None: self._configure_line_control(*self.current_image.shape); self.update_line_profile()

    def _spin_line_changed(self, value):
        self._set_selected_line(value)

    def _slider_line_changed(self, value):
        self._set_selected_line(value)

    def _set_selected_line(self, value):
        if self.current_image is None: return
        if self.line_orientation=='Row': self.line_row=value
        else: self.line_col=value
        self.line_spin.blockSignals(True); self.line_slider.blockSignals(True); self.line_spin.setValue(value); self.line_slider.setValue(value); self.line_spin.blockSignals(False); self.line_slider.blockSignals(False)
        self._sync_lines(); self.update_line_profile()

    def _line_moved(self, row: int, col: int):
        self.line_row = int(row)
        self.line_col = int(col)
        if self.current_image is not None:
            rows, cols = np.asarray(self.current_image).shape
            self.line_row_ratio = self.line_row / max(rows - 1, 1)
            self.line_col_ratio = self.line_col / max(cols - 1, 1)
        self._sync_lines()
        self.update_line_profile()


    def _sync_lines(self):
        self.primary_panel.set_line_position(self.line_row, self.line_col); self.secondary_panel.set_line_position(self.line_row, self.line_col)

    def active_display_array(self):
        if self.view_mode == 'Original': return np.asarray(self.current_image)
        return np.asarray(self.current_kspace)

    def update_line_profile(self):
        if self.current_image is None or self.current_kspace is None: return
        arr=self.active_display_array(); line=arr[self.line_row,:] if self.line_orientation=='Row' else arr[:,self.line_col]
        y=self.component(line, self.profile_mode.currentText())
        if self.log_profile.isChecked(): y=np.log10(np.maximum(np.abs(y), 1e-12))
        self.profile_plot.clear(); self.profile_plot.plot(y)
        pos=self.line_row if self.line_orientation=='Row' else self.line_col
        self.line_value_label.setText(f"{pos} / {len(y)-1}")

    def send_line_to_signal_studio(self):
        if self.current_image is None: return
        arr=self.active_display_array(); line=arr[self.line_row,:] if self.line_orientation=='Row' else arr[:,self.line_col]
        self.add_signal(line, f"{self.line_orientation} {self.line_row if self.line_orientation=='Row' else self.line_col} — {self.view_mode}")
        self.tabs.setCurrentIndex(1)

    def auto_levels(self):
        if self.current_image is None:
            return
        target = self.level_target_combo.currentText() if hasattr(self, "level_target_combo") else "Original Image"
        if target == "Raw Data" and self.current_kspace is not None:
            self._set_levels_for_target("Raw Data", np.log1p(np.abs(self.current_kspace)))
        else:
            self._set_levels_for_target("Original Image", np.asarray(self.current_image))
        self.level_preset_combo.blockSignals(True)
        self.level_preset_combo.setCurrentText("Auto")
        self.level_preset_combo.blockSignals(False)
        self._sync_level_controls()
        self.refresh_images()


    def _tree_current_changed(self, current, previous):
        if current is None:
            return
        data = current.data(0, Qt.UserRole)
        if data and data[0] == "dicom":
            self.show_dicom(int(data[1]))


    def _tree_original_paths(self):
        paths, seen = [], set()
        def add_path(value):
            try: path = Path(value)
            except Exception: return
            if path.exists() and path.is_file():
                key = str(path.resolve()).lower()
                if key not in seen:
                    seen.add(key); paths.append(path)
                if path.suffix.lower() in {".dat", ".pfile", ".7", ".img"}:
                    txt = path.with_suffix(".txt")
                    if txt.exists():
                        k = str(txt.resolve()).lower()
                        if k not in seen: seen.add(k); paths.append(txt)
        for item in self.tree.selectedItems():
            data=item.data(0,Qt.UserRole)
            if not data: continue
            kind=data[0]
            if kind=="dicom":
                i=int(data[1])
                if 0<=i<len(self.dicom_entries): add_path(self.dicom_entries[i].path)
            elif kind=="tracker_file":
                i=int(data[1])
                if 0<=i<len(self.tracker_files): add_path(self.tracker_files[i]["path"])
            elif kind in {"processed","tracker_workspace"}: add_path(data[1])
            elif kind=="series":
                for j in range(item.childCount()):
                    d=item.child(j).data(0,Qt.UserRole)
                    if d and d[0]=="dicom":
                        i=int(d[1])
                        if 0<=i<len(self.dicom_entries): add_path(self.dicom_entries[i].path)
        return paths



    def _start_tree_file_drag(self, supported_actions):
        paths=self._tree_original_paths()
        if not paths:
            self.statusBar().showMessage("No original files are available for drag and drop")
            return
        mime=QMimeData(); mime.setUrls([QUrl.fromLocalFile(str(p)) for p in paths])
        drag=QDrag(self.tree); drag.setMimeData(mime)
        self.statusBar().showMessage(f"Dragging {len(paths)} original file(s)")
        drag.exec(Qt.CopyAction)

    def _tree_clicked(self, item, column):
        data = item.data(0, Qt.UserRole)
        if not data:
            return
        if data[0] == "dicom":
            self.show_dicom(int(data[1]))
        elif data[0] == "signal":
            self.tabs.setCurrentIndex(4)
            self.signal_combo.setCurrentIndex(int(data[1]))
            self.update_signal_plot()
        elif data[0] == "processed":
            self.load_processed_image(data[1])
            self.refresh_images()
        elif data[0] == "tracker_workspace":
            self.show_tracker_in_workspace()
        elif data[0] == "tracker_signal":
            self.send_tracker_to_signal_studio()
        elif data[0] == "tracker_file":
            self._apply_tracker_state(int(data[1]))
            self.show_tracker_in_workspace()
            self.tabs.setCurrentIndex(0)
        elif data[0] == "tracker_pending":
            index = int(data[1])
            if 0 <= index < len(self.pending_tracker_paths):
                path = self.pending_tracker_paths[index]
                self.statusBar().showMessage(f"Loading Tracker: {path.name}")
                QApplication.processEvents()
                try:
                    self.load_tracker(path)
                    self.show_tracker_in_workspace()
                    self.tabs.setCurrentIndex(0)
                except Exception as exc:
                    QMessageBox.critical(
                        self, "Tracker Load Error", f"{path.name}\n\n{exc}"
                    )

        elif data[0] == "bitmap_pending":
            path = Path(data[1])
            self.load_bitmap_image(path)
            self.tabs.setCurrentIndex(0)

        elif data[0] == "signal_pending":
            path = Path(data[1])
            self.load_signal_file(path)
            self.tabs.setCurrentIndex(4)

        elif data[0] == "raw_file":
            path = Path(data[1])
            self.current_source = str(path)
            self.source_kind = "raw_file"
            self.info.setText(
                f"File: {path.name}\n"
                f"Type: Raw / P File\n"
                f"Path: {path}\n"
                "Use Raw Data Compensation, Spike Processing, or Tracker Signal "
                "after format/dimension detection."
            )
            self.statusBar().showMessage(f"Selected raw file: {path.name}")






    def _select_tree_dicom_index(self, index: int):
        iterator = QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            item = iterator.value()
            data = item.data(0, Qt.UserRole)
            if data and data[0] == "dicom" and int(data[1]) == int(index):
                self.tree.blockSignals(True)
                self.tree.setCurrentItem(item)
                self.tree.blockSignals(False)
                return
            iterator += 1

    def _level_target_changed(self, target: str):
        self._sync_level_controls()
        self.refresh_images()

    def _set_levels_for_target(self, target: str, array: np.ndarray):
        finite = np.asarray(array, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            center, width = 0.5, 1.0
        else:
            low, high = np.percentile(finite, [1.0, 99.5])
            if high <= low:
                high = low + 1.0
            center = float((low + high) / 2.0)
            width = float(high - low)

        if target == "Raw Data":
            self.raw_window_level = center
            self.raw_dynamic_range = width
        else:
            self.original_window_level = center
            self.original_dynamic_range = width

    def _levels_for_target(self, target: str, array: np.ndarray, auto_original: bool = False):
        if target == "Original Image":
            if auto_original or self.original_window_level is None or self.original_dynamic_range is None:
                self._set_levels_for_target(target, array)
            center = float(self.original_window_level)
            width = max(float(self.original_dynamic_range), 1e-9)
        else:
            if self.raw_window_level is None or self.raw_dynamic_range is None:
                self._set_levels_for_target(target, array)
            center = float(self.raw_window_level)
            width = max(float(self.raw_dynamic_range), 1e-9)
        return center - width / 2.0, center + width / 2.0

    def _active_level_array(self) -> np.ndarray:
        if self.current_image is None or self.current_kspace is None:
            return np.array([0.0, 1.0])
        if self.view_mode == "Original":
            return np.abs(self.current_image)
        return np.log1p(np.abs(self.current_kspace))

    def _set_auto_levels_from_array(self, array: np.ndarray):
        finite = np.asarray(array, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            center, width = 0.5, 1.0
        else:
            low, high = np.percentile(finite, [1.0, 99.5])
            if high <= low:
                high = low + 1.0
            center = (low + high) / 2.0
            width = high - low
        self.window_level = float(center)
        self.dynamic_range = float(width)
        self._sync_level_controls()

    def _levels_for_array(self, array: np.ndarray):
        finite = np.asarray(array, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            return (0.0, 1.0)
        low, high = np.percentile(finite, [1.0, 99.5])
        if high <= low:
            high = low + 1.0
        return (float(low), float(high))

    def _current_levels(self):
        if self.window_level is None or self.dynamic_range is None:
            self._set_auto_levels_from_array(self._active_level_array())
        half = max(float(self.dynamic_range) / 2.0, 1e-9)
        return (float(self.window_level) - half, float(self.window_level) + half)

    def _sync_level_controls(self):
        if not hasattr(self, "window_level_spin"):
            return
        target = self.level_target_combo.currentText() if hasattr(self, "level_target_combo") else "Original Image"
        if target == "Raw Data":
            center = self.raw_window_level
            width = self.raw_dynamic_range
        else:
            center = self.original_window_level
            width = self.original_dynamic_range

        self.window_level_spin.blockSignals(True)
        self.dynamic_range_spin.blockSignals(True)
        self.window_level_spin.setValue(float(center or 0.0))
        self.dynamic_range_spin.setValue(max(float(width or 1.0), 1e-9))
        self.window_level_spin.blockSignals(False)
        self.dynamic_range_spin.blockSignals(False)


    def _manual_levels_changed(self):
        target = self.level_target_combo.currentText() if hasattr(self, "level_target_combo") else "Original Image"
        center = float(self.window_level_spin.value())
        width = max(float(self.dynamic_range_spin.value()), 1e-9)
        if target == "Raw Data":
            self.raw_window_level = center
            self.raw_dynamic_range = width
        else:
            self.original_window_level = center
            self.original_dynamic_range = width
        self.level_preset_combo.blockSignals(True)
        self.level_preset_combo.setCurrentText("Manual")
        self.level_preset_combo.blockSignals(False)
        self.refresh_images()


    def apply_level_preset(self, preset: str):
        if self.current_image is None:
            return
        array = self._active_level_array()
        finite = np.asarray(array, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            return

        percentiles = {
            "Auto": (1.0, 99.5),
            "Wide": (0.0, 100.0),
            "Soft Tissue": (5.0, 95.0),
            "High Contrast": (10.0, 90.0),
            "Narrow": (25.0, 75.0),
        }
        low_p, high_p = percentiles.get(preset, (1.0, 99.5))
        low, high = np.percentile(finite, [low_p, high_p])
        if high <= low:
            high = low + 1.0
        self.level_preset = preset
        self.window_level = float((low + high) / 2.0)
        self.dynamic_range = float(high - low)
        self._sync_level_controls()
        levels = self._current_levels()
        self.primary_panel.set_levels(*levels)
        if self.secondary_panel.isVisible():
            self.secondary_panel.set_levels(*levels)

    def _current_image_record(self):
        if self.current_image is None:
            return None
        name = Path(self.current_source).name if self.current_source else "current_image"
        return {
            "name": name,
            "path": Path(self.current_source) if self.current_source else None,
            "image": np.asarray(self.current_image, dtype=float).copy(),
            "ds": copy.deepcopy(self.current_ds) if self.current_ds is not None else None,
        }

    def set_addsub_source(self, slot: str):
        record = self._current_image_record()
        if record is None:
            QMessageBox.information(self, "Add/Subtract", "Load an image first.")
            return
        if slot == "A":
            self.addsub_a = record
        else:
            self.addsub_b = record
        self.addsub_status.setText(
            f"A: {self.addsub_a['name'] if self.addsub_a else '-'}\\n"
            f"B: {self.addsub_b['name'] if self.addsub_b else '-'}"
        )

    def run_addsub(self, operation: str):
        # Backward-compatible alias.
        self.preview_addsub(operation)

    def preview_addsub(self, operation: str):
        if self.addsub_a is None or self.addsub_b is None:
            QMessageBox.information(self, "Add/Subtract", "Set both image A and image B first.")
            return
        a = np.asarray(self.addsub_a["image"], dtype=float)
        b = np.asarray(self.addsub_b["image"], dtype=float)
        if a.shape != b.shape:
            QMessageBox.warning(self, "Add/Subtract", f"Image sizes do not match: {a.shape} and {b.shape}")
            return

        result = a + b if operation == "add" else a - b
        self.addsub_preview_result = result
        self.addsub_preview_operation = operation
        self.save_addsub_button.setEnabled(True)

        dialog = QDialog(self)
        dialog.setWindowTitle("Add / Subtract Preview")
        dialog.resize(1450, 620)
        layout = QVBoxLayout(dialog)
        panels = QSplitter(Qt.Horizontal)
        panel_a = ImagePanel("Image A")
        panel_b = ImagePanel("Image B")
        panel_result = ImagePanel("Result: A + B" if operation == "add" else "Result: A - B")
        panels.addWidget(panel_a)
        panels.addWidget(panel_b)
        panels.addWidget(panel_result)
        panel_a.set_image(a)
        panel_b.set_image(b)
        panel_result.set_image(result)
        layout.addWidget(panels, 1)

        buttons = QHBoxLayout()
        save_button = QPushButton("Save Result")
        close_button = QPushButton("Close Preview")
        save_button.clicked.connect(lambda: (self.save_addsub_preview(), dialog.accept()))
        close_button.clicked.connect(dialog.reject)
        buttons.addStretch(1)
        buttons.addWidget(save_button)
        buttons.addWidget(close_button)
        layout.addLayout(buttons)
        dialog.exec()

    def save_addsub_preview(self):
        if self.addsub_preview_result is None or not self.addsub_preview_operation:
            QMessageBox.information(self, "Add/Subtract", "Preview an Add/Subtract result first.")
            return
        operation = self.addsub_preview_operation
        tag = "add" if operation == "add" else "sub"
        base = Path(self.addsub_a["name"]).stem if self.addsub_a else "image"
        output_path = self._save_processed_image(
            self.addsub_preview_result,
            f"{base}_{tag}_addsub",
            "_addsub",
        )
        self._display_processed_result(self.addsub_preview_result, output_path)
        self.addsub_status.setText(
            f"A: {self.addsub_a['name'] if self.addsub_a else '-'}\n"
            f"B: {self.addsub_b['name'] if self.addsub_b else '-'}\n"
            f"Saved: {output_path.name}"
        )
        self.save_addsub_button.setEnabled(False)
        self.statusBar().showMessage(f"Add/Subtract saved: {output_path}")

    def _raw_compensation_panel(self):
        # ROI coordinates always refer to raw/k-space dimensions. When FFT or Both
        # is visible, use its panel. In Original-only mode, keep the display unchanged
        # and place the ROI on the visible panel using the same matrix coordinates.
        return self.primary_panel

    def start_compensation_roi(self):
        if self.current_kspace is None:
            QMessageBox.information(self, "Compensation", "Load raw/k-space data first.")
            return

        if not self.compensation_history:
            self.compensation_history = [{
                "kspace": np.asarray(self.current_kspace).copy(),
                "image": np.asarray(self.current_image).copy(),
                "label": "Original",
                "roi": None,
                "level": None,
            }]
            self.compensation_history_index = 0

        self.compensation_original_kspace = np.asarray(self.current_kspace).copy()
        self.compensation_original = np.asarray(self.current_image).copy()
        self.compensation_preview = None
        self.compensation_roi_panel = self._raw_compensation_panel()
        self.compensation_roi_panel.show_comp_roi()
        self.preview_comp_button.setEnabled(True)
        self.apply_comp_button.setEnabled(False)
        self.comp_status_label.setText(
            "RAW ROI active. The current view mode and Window/Level are unchanged."
        )
        self.statusBar().showMessage("Move and resize the RAW compensation ROI.")

    def clear_compensation_roi(self):
        if self.compensation_roi_panel is not None:
            self.compensation_roi_panel.hide_comp_roi()
        if self.compensation_original_kspace is not None:
            self.current_kspace = self.compensation_original_kspace.copy()
            self.current_recon = ifft2c(self.current_kspace)
            self.current_image = np.abs(self.current_recon)
        self.compensation_preview = None
        self.compensation_original = None
        self.compensation_original_kspace = None
        self.compensation_roi_panel = None
        self.preview_comp_button.setEnabled(False)
        self.apply_comp_button.setEnabled(False)
        self.comp_status_label.setText("No RAW ROI selected")
        self.refresh_images()

    @staticmethod
    @staticmethod
    def _interpolate_rectangle(raw_data: np.ndarray, y0: int, y1: int, x0: int, x1: int, strength: float = 1.0) -> np.ndarray:
        source = np.asarray(raw_data)
        result = source.copy()
        rows, cols = source.shape
        y0 = max(1, min(int(y0), rows - 2))
        y1 = max(y0 + 1, min(int(y1), rows - 1))
        x0 = max(1, min(int(x0), cols - 2))
        x1 = max(x0 + 1, min(int(x1), cols - 1))
        cy, cx = rows // 2, cols // 2
        roi = source[y0:y1, x0:x1].copy()
        margin = max(3, int(min(rows, cols) * 0.01))
        ya, yb = max(0, y0-margin), min(rows, y1+margin)
        xa, xb = max(0, x0-margin), min(cols, x1+margin)
        neighborhood = source[ya:yb, xa:xb].copy()
        mask = np.ones(neighborhood.shape, dtype=bool)
        mask[y0-ya:y1-ya, x0-xa:x1-xa] = False
        local_yy, local_xx = np.indices(neighborhood.shape)
        global_y = local_yy + ya
        global_x = local_xx + xa
        cross_width = max(2, int(min(rows, cols) * 0.015))
        cross_mask = (np.abs(global_y-cy) <= cross_width) | (np.abs(global_x-cx) <= cross_width)
        valid = mask & ~cross_mask
        background_values = neighborhood[valid]
        if background_values.size < 8:
            background_values = neighborhood[mask]
        if background_values.size == 0:
            return result
        background_mag = np.abs(background_values)
        median_mag = float(np.median(background_mag))
        mad_mag = float(np.median(np.abs(background_mag - median_mag)))
        noise_level = median_mag + 2.5 * max(1.4826 * mad_mag, 1e-9)
        roi_mag = np.abs(roi)
        outlier_mask = roi_mag > max(noise_level * 2.5, median_mag * 4.0)
        roi_yy, roi_xx = np.indices(roi.shape)
        global_roi_y = roi_yy + y0
        global_roi_x = roi_xx + x0
        roi_cross = ((np.abs(global_roi_y-cy) <= cross_width) | (np.abs(global_roi_x-cx) <= cross_width))
        outlier_mask &= ~roi_cross
        if not np.any(outlier_mask):
            return result
        phase_reference = np.angle(np.median(background_values))
        replacement = median_mag * np.exp(1j * phase_reference)
        blend = float(np.clip(strength, 0.0, 1.0))
        corrected_roi = roi.copy()
        corrected_roi[outlier_mask] = roi[outlier_mask] * (1.0-blend) + replacement * blend
        result[y0:y1, x0:x1] = corrected_roi
        return result


    def _compensation_strength(self):
        return {"Low": 0.40, "Mid": 0.70, "High": 1.00}.get(
            self.comp_level_combo.currentText(), 0.70
        )

    def _compensation_bounds(self):
        panel = self.compensation_roi_panel or self._raw_compensation_panel()
        if not panel.comp_roi.isVisible():
            raise ValueError("RAW compensation ROI is not active.")
        y0, y1, x0, x1 = panel.comp_roi_bounds()
        if (y1 - y0) < 2 or (x1 - x0) < 2:
            raise ValueError("Compensation ROI is too small.")
        return y0, y1, x0, x1

    def preview_compensation(self):
        if self.current_kspace is None:
            QMessageBox.information(self, "Compensation", "Load raw/k-space data first.")
            return
        try:
            y0, y1, x0, x1 = self._compensation_bounds()
            source_kspace = (
                self.compensation_original_kspace
                if self.compensation_original_kspace is not None
                else np.asarray(self.current_kspace)
            )
            strength = self._compensation_strength()
            compensated_kspace = self._interpolate_rectangle(
                source_kspace, y0, y1, x0, x1, strength
            )
            reconstructed = ifft2c(compensated_kspace)

            self.compensation_preview = compensated_kspace
            self.current_kspace = compensated_kspace
            self.current_recon = reconstructed
            self.current_image = np.abs(reconstructed)

            # Preserve view mode, preset, Window Level, and Dynamic Range.
            self.refresh_images()
            self.apply_comp_button.setEnabled(True)

            original_roi = np.abs(source_kspace[y0:y1, x0:x1])
            new_roi = np.abs(compensated_kspace[y0:y1, x0:x1])
            change = np.abs(new_roi - original_roi)
            self.comp_status_label.setText(
                f"Preview: {self.comp_level_combo.currentText()} | "
                f"RAW ROI x={x0}:{x1}, y={y0}:{y1} | "
                f"Mean change={float(np.mean(change)):.4g}"
            )
        except Exception as exc:
            QMessageBox.critical(self, "Compensation Preview Error", str(exc))

    def apply_compensation(self):
        try:
            y0, y1, x0, x1 = self._compensation_bounds()
            if self.compensation_preview is None:
                self.preview_compensation()
            if self.compensation_preview is None:
                return

            state = {
                "kspace": np.asarray(self.current_kspace).copy(),
                "image": np.asarray(self.current_image).copy(),
                "label": f"{self.comp_level_combo.currentText()} ROI {x0}:{x1},{y0}:{y1}",
                "roi": (y0, y1, x0, x1),
                "level": self.comp_level_combo.currentText(),
            }

            if self.compensation_history_index < len(self.compensation_history) - 1:
                self.compensation_history = self.compensation_history[
                    : self.compensation_history_index + 1
                ]
            self.compensation_history.append(state)
            self.compensation_history_index = len(self.compensation_history) - 1

            if self.compensation_roi_panel is not None:
                self.compensation_roi_panel.hide_comp_roi()
            self.compensation_roi_panel = None
            self.compensation_preview = None
            self.compensation_original_kspace = None
            self.compensation_original = None
            self.preview_comp_button.setEnabled(False)
            self.apply_comp_button.setEnabled(False)
            self.save_comp_button.setEnabled(True)
            self._update_compensation_history_buttons()
            self.comp_status_label.setText(
                f"Committed {self.compensation_history_index}/"
                f"{len(self.compensation_history)-1}: {state['label']}. "
                f"Select another ROI to continue."
            )
            self.refresh_images()
        except Exception as exc:
            QMessageBox.critical(self, "Compensation Error", str(exc))

    def _update_compensation_history_buttons(self):
        self.comp_prev_button.setEnabled(self.compensation_history_index > 0)
        self.comp_next_button.setEnabled(
            0 <= self.compensation_history_index < len(self.compensation_history) - 1
        )
        self.save_comp_button.setEnabled(self.compensation_history_index >= 0)

    def navigate_compensation_history(self, step: int):
        target = self.compensation_history_index + int(step)
        if target < 0 or target >= len(self.compensation_history):
            return
        self.compensation_history_index = target
        state = self.compensation_history[target]
        self.current_kspace = np.asarray(state["kspace"]).copy()
        self.current_recon = ifft2c(self.current_kspace)
        self.current_image = np.abs(self.current_recon)
        self.compensation_preview = None
        self.compensation_original_kspace = None
        if self.compensation_roi_panel is not None:
            self.compensation_roi_panel.hide_comp_roi()
        self.compensation_roi_panel = None
        self.refresh_images()
        self._update_compensation_history_buttons()
        self.comp_status_label.setText(
            f"History {target}/{len(self.compensation_history)-1}: {state['label']}"
        )

    def save_compensation_history_state(self):
        if not self.compensation_history or self.compensation_history_index < 0:
            QMessageBox.information(self, "Compensation", "No compensation state is available.")
            return
        state = self.compensation_history[self.compensation_history_index]
        base = Path(self.current_source).stem if self.current_source else "raw"
        output_path = self._save_processed_image(
            np.asarray(state["image"]),
            f"{base}_comp_h{self.compensation_history_index}",
            "_comp",
        )
        # Save raw/k-space separately for exact restoration.
        np.save(
            output_path.parent / f"{Path(output_path).stem}_raw.npy",
            np.asarray(state["kspace"]),
        )
        self.comp_status_label.setText(
            f"Saved displayed state {self.compensation_history_index}: {output_path.name}"
        )
        self.statusBar().showMessage(f"Compensation state saved: {output_path}")

    def change_output_root(self):
        initial = str(self._output_root())
        selected = QFileDialog.getExistingDirectory(self, "Select Output Top Folder", initial)
        if not selected:
            return
        self.output_root_override = Path(selected)
        self._update_output_root_label()

    def _output_root(self) -> Path:
        if self.output_root_override is not None:
            return self.output_root_override
        source = Path(self.current_source) if self.current_source else Path.cwd() / "image"
        parent = source.parent if source.parent.exists() else Path.cwd()
        return parent / "MR_Image_Explorer_Output"

    def _update_output_root_label(self):
        if hasattr(self, "output_root_label"):
            self.output_root_label.setText(f"Output: {self._output_root()}")

    def _work_folder(self, category: str = "Processed") -> Path:
        folder = self._output_root() / category
        folder.mkdir(parents=True, exist_ok=True)
        self._update_output_root_label()
        return folder


    def _save_processed_image(self, image: np.ndarray, stem: str, suffix: str) -> Path:
        suffix_lower = suffix.lower()
        if "addsub" in suffix_lower:
            category = "AddSub"
        elif "comp" in suffix_lower:
            category = "Compensated"
        elif "ns" in suffix_lower or "spike" in suffix_lower:
            category = "NoSpike"
        else:
            category = "Processed"

        folder = self._work_folder(category)
        safe_stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", stem)
        npy_path = folder / f"{safe_stem}.npy"
        np.save(npy_path, np.asarray(image, dtype=np.float32))

        if self.current_ds is not None:
            ds = copy.deepcopy(self.current_ds)
            arr = np.asarray(image, dtype=float)
            finite = arr[np.isfinite(arr)]
            low = float(np.min(finite)) if finite.size else 0.0
            high = float(np.max(finite)) if finite.size else 1.0
            if high <= low:
                high = low + 1.0
            scaled = np.clip((arr - low) / (high - low) * 65535.0, 0, 65535).astype(np.uint16)
            ds.PixelData = scaled.tobytes()
            ds.Rows, ds.Columns = scaled.shape
            ds.BitsAllocated = 16
            ds.BitsStored = 16
            ds.HighBit = 15
            ds.PixelRepresentation = 0
            ds.RescaleSlope = (high - low) / 65535.0
            ds.RescaleIntercept = low
            ds.SOPInstanceUID = generate_uid()
            ds.SeriesInstanceUID = generate_uid()
            ds.ImageType = ["DERIVED", "SECONDARY"]
            original_description = str(getattr(ds, "SeriesDescription", "MR"))
            ds.SeriesDescription = f"{original_description} {suffix}"
            dcm_path = folder / f"{safe_stem}.dcm"
            ds.save_as(str(dcm_path), write_like_original=False)
            primary_path = dcm_path
        else:
            primary_path = npy_path

        self.processed_images[str(primary_path)] = np.asarray(image, dtype=float).copy()
        self.processed_sources[str(primary_path)] = primary_path
        self._add_processed_tree_item(primary_path)
        self._update_output_root_label()
        return primary_path


    def _add_processed_tree_item(self, path: Path):
        root = None
        for i in range(self.tree.topLevelItemCount()):
            candidate = self.tree.topLevelItem(i)
            if candidate.text(0) == "Processed Files":
                root = candidate
                break
        if root is None:
            root = QTreeWidgetItem(["Processed Files"])
            self.tree.addTopLevelItem(root)
        item = QTreeWidgetItem([path.name])
        item.setData(0, Qt.UserRole, ("processed", str(path)))
        root.addChild(item)
        root.setExpanded(True)
        self.tree.setCurrentItem(item)

    def _display_processed_result(self, image: np.ndarray, path: Path):
        self.current_image = np.asarray(image, dtype=float)
        self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)
        self.current_source = str(path)
        self.current_ds = None
        self.source_kind = "processed"
        self.original_window_level = None
        self.original_dynamic_range = None
        self.raw_window_level = None
        self.raw_dynamic_range = None
        self.view_mode = "Both"
        self._update_output_root_label()
        self.refresh_images()


    def load_processed_image(self, path_value: str):
        path = Path(path_value)
        if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp"}:
            self.load_bitmap_image(path)
            return

        if str(path) in self.processed_images:
            image = self.processed_images[str(path)]
        elif path.suffix.lower() == ".npy":
            image = np.load(path, allow_pickle=False)
        elif path.suffix.lower() == ".dcm":
            entry = self.read_dicom(path)
            image = entry.image
            self.current_ds = entry.ds
        else:
            return

        self.current_image = np.asarray(image, dtype=float)
        self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)
        self.current_source = str(path)
        self.source_kind = "processed"
        self.original_window_level = None
        self.original_dynamic_range = None
        self.raw_window_level = None
        self.raw_dynamic_range = None
        self.view_mode = "Both"
        self._update_output_root_label()
        self.refresh_images()


    def _artifact_detection_indices(self):
        self._tree_selection_changed()
        if self.detect_selected_only.isChecked() and self.artifact_selected_indices:
            return list(self.artifact_selected_indices)
        return list(range(len(self.dicom_entries)))

    def detect_artifacts_from_db(self):
        if not self._ensure_artifact_database():
            return

        keys, training, labels, metadata = self.artifact_db.training_feature_vectors()
        indices = self._artifact_detection_indices()
        if not indices:
            QMessageBox.information(self, "Artifact Detection", "No DICOM images are available.")
            return

        progress = self._make_progress("Artifact Detection", len(indices))
        results = []
        try:
            for count, index in enumerate(indices, start=1):
                if progress.wasCanceled():
                    break
                entry = self.dicom_entries[index]
                progress.setLabelText(f"Classifying image: {entry.path.name}")
                features = image_features(entry.image, self.normal_reference_image)
                vector = features_to_vector(features, keys)
                result = classify_feature_vector(
                    vector,
                    training,
                    labels,
                    minimum_samples_per_class=self.detect_min_samples.value(),
                )
                results.append({
                    "index": index,
                    "entry": entry,
                    "features": features,
                    "result": result,
                })
                progress.setValue(count)
        finally:
            progress.close()

        self._artifact_detection_results = results
        self.artifact_detection_table.setRowCount(len(results))
        predicted_counts = {}
        for row, item in enumerate(results):
            entry = item["entry"]
            result = item["result"]
            predicted_counts[result.label] = predicted_counts.get(result.label, 0) + 1
            alternatives = ", ".join(
                f"{label} {confidence * 100:.1f}%"
                for label, confidence, distance, support in result.alternatives[1:4]
            )
            values = [
                entry.path.name,
                str(getattr(entry.ds, "SeriesDescription", "") or getattr(entry.ds, "ProtocolName", "")),
                result.label,
                f"{result.confidence * 100:.1f}%",
                f"{result.distance:.4f}" if np.isfinite(result.distance) else "-",
                result.support,
                result.status,
                alternatives,
                str(entry.path),
            ]
            for column, value in enumerate(values):
                table_item = QTableWidgetItem(str(value))
                table_item.setData(Qt.UserRole, row)
                self.artifact_detection_table.setItem(row, column, table_item)

        self.artifact_detection_table.resizeColumnsToContents()
        summary = ", ".join(f"{label}: {count}" for label, count in sorted(predicted_counts.items()))
        self.artifact_detection_summary.setText(
            f"Detected {len(results)} image(s). {summary or 'No prediction results.'}"
        )

    def open_detected_artifact_image(self, row: int, column: int):
        if not hasattr(self, "_artifact_detection_results"):
            return
        if row < 0 or row >= len(self._artifact_detection_results):
            return
        result = self._artifact_detection_results[row]
        self.show_dicom(int(result["index"]))
        self.tabs.setCurrentIndex(0)

    def send_detected_rows_to_learning(self):
        if not hasattr(self, "_artifact_detection_results"):
            return
        selected_rows = sorted(
            {item.row() for item in self.artifact_detection_table.selectedItems()}
        )
        if not selected_rows:
            return
        indices = []
        predicted_labels = []
        for row in selected_rows:
            result = self._artifact_detection_results[row]
            indices.append(int(result["index"]))
            predicted_labels.append(result["result"].label)
        self.artifact_selected_indices = sorted(set(indices))
        if predicted_labels and len(set(predicted_labels)) == 1:
            self.artifact_type_combo.setCurrentText(predicted_labels[0])
        self.artifact_selection_label.setText(
            f"Training images ready from detection: {len(self.artifact_selected_indices)}"
        )
        self.tabs.setCurrentIndex(2)

    def clear_selected_images(self):
        selected=[]
        for item in self.tree.selectedItems():
            data=item.data(0,Qt.UserRole)
            if data and data[0]=="dicom": selected.append(int(data[1]))
        selected=sorted(set(selected),reverse=True)
        if not selected: return
        if QMessageBox.question(self,"Clear Selected Images",f"Remove {len(selected)} selected image(s)?") != QMessageBox.Yes: return
        for i in selected:
            if 0 <= i < len(self.dicom_entries): self.dicom_entries.pop(i)
        if self.dicom_entries: self.populate_dicom_tree(); self.show_dicom(min(getattr(self,"slice_index",0),len(self.dicom_entries)-1))
        else: self._reset_image_state()

    def clear_all_images(self):
        if QMessageBox.question(self,"Clear All Images","Clear all imported images and image editing state?") != QMessageBox.Yes: return
        self.dicom_entries.clear(); self._reset_image_state()

    def _reset_image_state(self):
        self.current_image=None; self.current_kspace=None; self.current_recon=None; self.current_ds=None; self.current_source=""; self.tree.clear(); self.primary_panel.image_item.clear(); self.secondary_panel.image_item.clear(); self.profile_plot.clear(); self.slice_label.setText("Slice: -"); self.info.setText("No file loaded")
        self.compensation_history=[]; self.compensation_history_index=-1; self.addsub_a=None; self.addsub_b=None; self.addsub_preview_result=None; self.addsub_status.setText("A: -\nB: -")

    def remove_selected_signal(self):
        i=self.signal_combo.currentIndex()
        if 0 <= i < len(self.signals): self.signals.pop(i); self.signal_combo.clear(); self.signal_combo.addItems([x["name"] for x in self.signals]); self.update_signal_plot()

    def clear_addsub_slot(self,slot:str):
        if slot=="A": self.addsub_a=None
        else: self.addsub_b=None
        self.addsub_status.setText(f"A: {self.addsub_a['name'] if self.addsub_a else '-'}\nB: {self.addsub_b['name'] if self.addsub_b else '-'}")

    def clear_addsub_result(self):
        self.addsub_preview_result=None; self.addsub_preview_operation=""; self.save_addsub_button.setEnabled(False)

    def clear_compensation_history(self):
        if self.compensation_base_kspace is not None:
            self.current_kspace = np.asarray(self.compensation_base_kspace).copy()
            self.current_recon = ifft2c(self.current_kspace)
            if self.compensation_base_image is not None:
                self.current_image = np.asarray(self.compensation_base_image).copy()
            else:
                self.current_image = np.abs(self.current_recon)

        self.compensation_history = []
        self.compensation_history_index = -1
        self.compensation_preview = None
        self.compensation_original = None
        self.compensation_original_kspace = None
        if self.compensation_roi_panel is not None:
            self.compensation_roi_panel.hide_comp_roi()
        self.compensation_roi_panel = None
        self._update_compensation_history_buttons()
        self.comp_status_label.setText("Compensation history cleared — original restored")
        self.refresh_images()


    def clear_selected_artifact_training(self):
        self.artifact_selected_indices=[]; self.artifact_preview_position=0; self.artifact_selection_label.setText("No training images selected."); self.artifact_preview_panel.image_item.clear()

    def clear_all_artifact_training(self):
        self.clear_selected_artifact_training(); self.normal_reference_image=None; self.normal_reference_path=None; self.artifact_normal_label.setText("Normal reference: None")

    def _tree_selection_changed(self):
        indices = []
        for item in self.tree.selectedItems():
            data = item.data(0, Qt.UserRole)
            if data and data[0] == "dicom":
                indices.append(int(data[1]))
        self.artifact_selected_indices = sorted(set(indices))
        if hasattr(self, "artifact_selection_label"):
            self.artifact_selection_label.setText(
                f"Selected DICOM images in Explorer: {len(self.artifact_selected_indices)}"
            )

    def _ensure_artifact_database(self):
        if self.artifact_db is None:
            self.open_artifact_database()
        return self.artifact_db is not None

    def open_artifact_database(self):
        choice = QMessageBox(self)
        choice.setWindowTitle("Artifact Database")
        choice.setText("Open an existing database or create a new database.")
        open_button = choice.addButton("Open Existing", QMessageBox.AcceptRole)
        create_button = choice.addButton("Create New", QMessageBox.ActionRole)
        choice.addButton("Cancel", QMessageBox.RejectRole)
        choice.exec()

        clicked = choice.clickedButton()
        if clicked == open_button:
            filename, _ = QFileDialog.getOpenFileName(
                self, "Open Artifact Database", "",
                "SQLite database (*.sqlite *.db);;All files (*)"
            )
        elif clicked == create_button:
            filename, _ = QFileDialog.getSaveFileName(
                self, "Create Artifact Database", "MR_Artifact_Learning.sqlite",
                "SQLite database (*.sqlite *.db)"
            )
        else:
            return

        if not filename:
            return
        path = Path(filename)
        if path.suffix.lower() not in {".sqlite", ".db"}:
            path = path.with_suffix(".sqlite")
        if self.artifact_db is not None:
            self.artifact_db.close()
        self.artifact_db = ArtifactDatabase(path)
        self.artifact_db_path = path
        self.artifact_db_label.setText(f"Artifact DB: {path}")
        self.refresh_artifact_lists()
        self.refresh_artifact_training_table()


    def refresh_artifact_lists(self):
        if self.artifact_db is None:
            return
        self.artifact_type_combo.clear()
        self.artifact_type_combo.addItems(self.artifact_db.artifact_types())
        self.artifact_resolution_combo.clear()
        self.artifact_resolution_combo.addItems(self.artifact_db.resolutions())

    def add_artifact_type_manual(self):
        if not self._ensure_artifact_database():
            return
        value = self.artifact_new_type.text().strip()
        if value:
            self.artifact_db.add_artifact_type(value)
            self.refresh_artifact_lists()
            self.artifact_type_combo.setCurrentText(value)
            self.artifact_new_type.clear()

    def add_resolution_manual(self):
        if not self._ensure_artifact_database():
            return
        value = self.artifact_new_resolution.text().strip()
        if value:
            self.artifact_db.add_resolution(value)
            self.refresh_artifact_lists()
            self.artifact_resolution_combo.setCurrentText(value)
            self.artifact_new_resolution.clear()

    def collect_selected_artifact_images(self):
        self._tree_selection_changed()
        if not self.artifact_selected_indices and self.dicom_entries:
            self.artifact_selected_indices = [getattr(self, "slice_index", 0)]
        self.artifact_selection_label.setText(
            f"Training images ready: {len(self.artifact_selected_indices)}"
        )
        self.tabs.setCurrentIndex(2)

    def preview_artifact_learning_image(self):
        self._tree_selection_changed()
        if not self.artifact_selected_indices:
            QMessageBox.information(
                self, "Artifact Learning Preview", "Select one or more DICOM images in Explorer."
            )
            return
        self.artifact_preview_position = max(
            0, min(self.artifact_preview_position, len(self.artifact_selected_indices) - 1)
        )
        index = self.artifact_selected_indices[self.artifact_preview_position]
        if not (0 <= index < len(self.dicom_entries)):
            return
        entry = self.dicom_entries[index]
        self.artifact_preview_panel.label.setText(
            f"Artifact Learning Preview: {entry.path.name} "
            f"({self.artifact_preview_position + 1}/{len(self.artifact_selected_indices)})"
        )
        self.artifact_preview_panel.set_image(np.asarray(entry.image, dtype=float))
        self.artifact_selection_label.setText(
            f"Training images ready: {len(self.artifact_selected_indices)} | "
            f"Previewing {entry.path.name}"
        )

    def navigate_artifact_preview(self, step: int):
        if not self.artifact_selected_indices:
            self._tree_selection_changed()
        if not self.artifact_selected_indices:
            return
        self.artifact_preview_position = (
            self.artifact_preview_position + int(step)
        ) % len(self.artifact_selected_indices)
        self.preview_artifact_learning_image()

    def set_current_normal_reference(self):
        if self.current_image is None:
            QMessageBox.information(self, "Normal Reference", "Load an image first.")
            return
        self.normal_reference_image = np.asarray(self.current_image, dtype=float).copy()
        self.normal_reference_path = Path(self.current_source) if self.current_source else None
        self.artifact_normal_label.setText(
            f"Normal reference: {self.normal_reference_path or 'Current image'}"
        )

    def load_normal_reference(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Load Normal Reference", "",
            "DICOM or NumPy (*.dcm *.ima *.npy *.npz);;All files (*)"
        )
        if not filename:
            return
        path = Path(filename)
        try:
            if path.suffix.lower() == ".npy":
                image = np.load(path, allow_pickle=False)
            elif path.suffix.lower() == ".npz":
                archive = np.load(path, allow_pickle=False)
                image = archive[list(archive.keys())[0]]
            else:
                image = self.read_dicom(path).image
            image = np.asarray(image).squeeze()
            if image.ndim != 2:
                raise ValueError(f"Normal reference must be 2D: {image.shape}")
            self.normal_reference_image = image.astype(float)
            self.normal_reference_path = path
            self.artifact_normal_label.setText(f"Normal reference: {path}")
        except Exception as exc:
            QMessageBox.critical(self, "Normal Reference Error", str(exc))

    def save_artifact_training_samples(self):
        if not self._ensure_artifact_database():
            return
        indices = [
            i for i in self.artifact_selected_indices
            if 0 <= i < len(self.dicom_entries)
        ]
        if not indices:
            QMessageBox.information(self, "Artifact Learning", "Select DICOM images first.")
            return
        artifact_type = self.artifact_type_combo.currentText().strip() or "Not Artifact"
        resolution = self.artifact_resolution_combo.currentText().strip()
        notes = self.artifact_notes.toPlainText().strip()
        progress = self._make_progress("Saving Artifact Training Samples", len(indices))
        saved = 0
        try:
            for count, index in enumerate(indices, start=1):
                if progress.wasCanceled():
                    break
                entry = self.dicom_entries[index]
                progress.setLabelText(f"Analyzing image: {entry.path.name}")
                features = image_features(entry.image, self.normal_reference_image)
                ds = entry.ds
                self.artifact_db.add_sample(
                    source_path=str(entry.path),
                    source_name=entry.path.name,
                    series_uid=str(getattr(ds, "SeriesInstanceUID", "")),
                    series_description=str(
                        getattr(ds, "SeriesDescription", "")
                        or getattr(ds, "ProtocolName", "")
                    ),
                    instance_number=int(getattr(ds, "InstanceNumber", index) or index),
                    artifact_type=artifact_type,
                    resolution=resolution,
                    is_normal_reference=False,
                    normal_reference_path=str(self.normal_reference_path or ""),
                    features=features,
                    notes=notes,
                )
                saved += 1
                progress.setValue(count)
        finally:
            progress.close()
        self.refresh_artifact_training_table()
        self.artifact_summary.setText(
            f"Saved {saved} sample(s) as {artifact_type}. "
            f"Normal comparison: {'Yes' if self.normal_reference_image is not None else 'No'}"
        )

    def refresh_artifact_training_table(self):
        if self.artifact_db is None:
            self.artifact_training_table.setRowCount(0)
            return
        rows = self.artifact_db.samples()
        self.artifact_training_table.setRowCount(len(rows))
        for r, sample in enumerate(rows):
            try:
                features = json.loads(sample.get("features_json", "{}"))
            except Exception:
                features = {}
            values = [
                sample["id"], sample["source_name"], sample["series_description"],
                sample["instance_number"], sample["artifact_type"],
                sample["resolution"] or "",
                "Yes" if features.get("normal_comparison") else "No",
                sample["source_path"] or "",
            ]
            for c, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.UserRole, int(sample["id"]))
                self.artifact_training_table.setItem(r, c, item)
        self.artifact_training_table.resizeColumnsToContents()

    def reclassify_selected_db_rows(self):
        if self.artifact_db is None:
            return
        rows = sorted({i.row() for i in self.artifact_training_table.selectedItems()})
        artifact_type = self.artifact_type_combo.currentText().strip() or "Not Artifact"
        resolution = self.artifact_resolution_combo.currentText().strip()
        notes = self.artifact_notes.toPlainText().strip()
        for row in rows:
            item = self.artifact_training_table.item(row, 0)
            if item is not None:
                self.artifact_db.update_sample_classification(
                    int(item.data(Qt.UserRole)), artifact_type, resolution, notes
                )
        self.refresh_artifact_training_table()

    def import_artifact_database(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Import Artifact DB JSON", "",
            "Artifact DB JSON (*.json);;All files (*)"
        )
        if not filename:
            return
        if self.artifact_db is None:
            self.open_artifact_database()
        if self.artifact_db is None:
            return
        self.artifact_db.import_json(Path(filename))
        self.refresh_artifact_lists()
        self.refresh_artifact_training_table()


    def export_artifact_database(self):
        if self.artifact_db is None:
            QMessageBox.information(self, "Artifact DB", "Open an Artifact DB first.")
            return
        filename, _ = QFileDialog.getSaveFileName(
            self, "Export Artifact DB JSON", "MRI_Artifact_DB.json",
            "Artifact DB JSON (*.json)"
        )
        if filename:
            if not filename.lower().endswith(".json"):
                filename += ".json"
            self.artifact_db.export_json(Path(filename))

    def fill_header(self, ds):
        return


    def filter_header(self, value):
        return


    def export_header_excel(self):
        if self.current_ds is None: QMessageBox.information(self,'No DICOM','Load a DICOM file first.'); return
        filename,_=QFileDialog.getSaveFileName(self,'Export DICOM Header','DICOM_Header.xlsx','Excel (*.xlsx)')
        if not filename: return
        if not filename.lower().endswith('.xlsx'): filename += '.xlsx'
        wb=Workbook(); ws=wb.active; ws.title='DICOM Header'; headers=['Tag','Keyword','Name','VR','VM','Value']; ws.append(headers)
        for cell in ws[1]: cell.font=Font(bold=True); cell.fill=PatternFill('solid', fgColor='D9EAF7')
        for elem in self.current_ds.iterall():
            if elem.tag.group != 0x7FE0: ws.append([str(elem.tag),elem.keyword,elem.name,elem.VR,str(elem.VM),str(elem.value)])
        ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
        for col,width in {'A':16,'B':28,'C':38,'D':8,'E':8,'F':80}.items(): ws.column_dimensions[col].width=width
        for row in ws.iter_rows():
            for cell in row: cell.alignment=Alignment(vertical='top', wrap_text=True)
        wb.save(filename); self.statusBar().showMessage(f'Exported {filename}')

    def export_npz(self):
        if self.current_image is None: return
        filename,_=QFileDialog.getSaveFileName(self,'Export NPZ','MRI_FFT_Data.npz','NPZ (*.npz)')
        if filename:
            if not filename.lower().endswith('.npz'): filename += '.npz'
            np.savez_compressed(filename,image=self.current_image,kspace=self.current_kspace,reconstruction=self.current_recon,source=self.current_source)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._position_progress_overlay()

    def closeEvent(self, event):
        self.import_cancel_event.set()
        if self.import_worker is not None:
            try: self.import_worker.cancel()
            except Exception: pass
        for directory in self.temp_dirs:
            try: shutil.rmtree(directory, ignore_errors=True)
            except Exception: pass
        event.accept()

def validate_startup_dependencies():
    required_names = [
        "QApplication",
        "QMainWindow",
        "QGridLayout",
        "QTreeWidget",
        "QMimeData",
        "QUrl",
        "QDrag",
        "MainWindow",
    ]
    missing = [name for name in required_names if name not in globals()]
    if missing:
        raise RuntimeError(
            "Missing startup dependency/import: " + ", ".join(missing)
        )


def write_startup_error(error: BaseException) -> Path:
    log_dir = Path.home() / "AppData" / "Local" / "MR_Image_Explorer"
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        log_dir = Path.cwd()

    log_path = log_dir / "startup_error.log"
    try:
        import traceback
        log_path.write_text(
            "MR Image Explorer startup failed.\n\n"
            + "".join(
                traceback.format_exception(
                    type(error),
                    error,
                    error.__traceback__,
                )
            ),
            encoding="utf-8",
        )
    except Exception:
        pass
    return log_path


def main():
    try:
        validate_startup_dependencies()

        app = QApplication(sys.argv)
        app.setApplicationName(APP_NAME)
        app.setOrganizationName("InSightec")

        window = MainWindow()
        window.show()
        window.raise_()
        window.activateWindow()

        # Used by GitHub Actions to verify that both Python and packaged EXE
        # actually create the application window and enter the Qt event loop.
        if os.environ.get("MRIE_STARTUP_SMOKE_TEST") == "1":
            QTimer.singleShot(1200, app.quit)

        return app.exec()

    except BaseException as error:
        log_path = write_startup_error(error)

        try:
            app = QApplication.instance()
            if app is None:
                app = QApplication(sys.argv)
            QMessageBox.critical(
                None,
                "MR Image Explorer - Startup Error",
                f"{type(error).__name__}: {error}\n\n"
                f"Log:\n{log_path}",
            )
        except Exception:
            pass

        return 1


if __name__ == "__main__":
    raise SystemExit(main())
