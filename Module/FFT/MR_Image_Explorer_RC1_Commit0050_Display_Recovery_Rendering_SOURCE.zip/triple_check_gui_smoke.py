from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import Qt
from PySide6.QtGui import QImage
from PySide6.QtWidgets import QApplication, QTreeWidgetItem

from app import MainWindow


def main() -> int:
    app = QApplication.instance() or QApplication([])
    window = MainWindow()
    window.resize(1200, 760)
    window.show()
    app.processEvents()

    test_image = Path(__file__).with_name("_commit0048_smoke.png")
    image = QImage(48, 32, QImage.Format_Grayscale8)
    image.fill(96)
    if not image.save(str(test_image)):
        raise RuntimeError("Could not create smoke-test image.")

    item = QTreeWidgetItem(["Commit0048 Smoke Bitmap"])
    item.setData(
        0,
        Qt.UserRole,
        ("bitmap_pending", str(test_image)),
    )
    window.tree.addTopLevelItem(item)
    window.tree.setCurrentItem(item)
    item.setSelected(True)
    window._open_tree_item(item, force=True)
    app.processEvents()

    assert window.current_image is not None
    assert tuple(window.current_image.shape[:2]) == (32, 48)
    assert window.source_kind == "bitmap"
    assert window.view_mode == "Original"
    assert window.tabs.currentIndex() == 0
    assert window._last_verified_display_source == (
        "bitmap_pending",
        str(test_image),
    )

    tracker = Path(__file__).with_name("tracking_test.dat")
    tracker.write_bytes(b"tracking")
    raw_file = Path(__file__).with_name("image_test.raw")
    raw_file.write_bytes(b"\0" * 8192)

    original_detector = window.looks_tracker
    window.looks_tracker = (
        lambda path: Path(path).name == tracker.name
    )
    window.imported_paths = [tracker, raw_file]
    candidates = window._raw_candidate_paths()
    window.looks_tracker = original_detector

    assert tracker not in candidates
    assert raw_file in candidates

    window.close()
    app.processEvents()
    print(
        "Commit0048 GUI smoke test PASS: "
        "list selection displayed bitmap and Tracking PFile was excluded."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
