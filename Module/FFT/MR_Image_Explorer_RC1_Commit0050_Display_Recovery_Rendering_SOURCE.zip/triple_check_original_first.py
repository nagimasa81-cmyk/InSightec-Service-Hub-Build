from __future__ import annotations

import ast
from pathlib import Path

SOURCE = Path(__file__).with_name("app.py")
text = SOURCE.read_text(encoding="utf-8")
tree = ast.parse(text)

required = {
    "show_dicom",
    "set_view_mode",
    "_finalize_image_selection",
    "_classify_series_purpose",
    "populate_dicom_tree",
}
methods = {
    node.name
    for node in ast.walk(tree)
    if isinstance(node, ast.FunctionDef)
}
missing = required - methods
assert not missing, f"Missing methods: {sorted(missing)}"

show_start = text.index("    def show_dicom")
show_end = text.index("\n    def ", show_start + 5)
show_block = text[show_start:show_end]
assert 'self.view_mode = "Original"' in show_block
assert "self.current_kspace = None" in show_block
assert "fft2c(self.current_image)" not in show_block

mode_start = text.index("    def set_view_mode")
mode_end = text.index("\n    def ", mode_start + 5)
mode_block = text[mode_start:mode_end]
assert 'requested_mode in {"FFT", "Both"}' in mode_block
assert "self.current_kspace = fft2c" in mode_block

final_start = text.index("    def _finalize_image_selection")
final_end = text.index("\n    def ", final_start + 5)
final_block = text[final_start:final_end]
assert 'self.view_mode = "Original"' in final_block
assert "self.primary_panel.set_image" in final_block

assert "Thermometry MEMP" in text
assert "Temperature Map" in text
assert "Acquisition Order: Series" in text

print(
    "PASS: DICOM list selection is Original-first, "
    "FFT is lazy, and Series classification is present."
)
