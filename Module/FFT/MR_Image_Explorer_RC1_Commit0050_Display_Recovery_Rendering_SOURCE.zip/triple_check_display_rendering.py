from pathlib import Path
import ast
text=Path(__file__).with_name("app.py").read_text(encoding="utf-8")
ast.parse(text)
for token in ["def _paint_original_now", "self.primary_panel.image_item.setImage", "def _schedule_original_repaint", "Rotate X +90", "Rotate Y +90", "Rotate Z +90", "Auto WW/WL", "def _window_image"]:
    assert token in text, token
show=text[text.index("    def show_dicom"):text.index("\n    def ",text.index("    def show_dicom")+5)]
assert "self._paint_original_now" in show
assert "self._schedule_original_repaint" in show
print("PASS: direct image repaint and rendering rotation/WW/WL controls present")
