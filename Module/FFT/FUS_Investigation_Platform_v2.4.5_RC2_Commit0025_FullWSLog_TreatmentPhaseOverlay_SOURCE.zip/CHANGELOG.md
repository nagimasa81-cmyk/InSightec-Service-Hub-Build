# Changelog

## v2.4.5-RC2 — Commit0025_FullWSLog_TreatmentPhaseOverlay

- Operation now includes the complete WS log file when that file contains the resolved Treatment session.
- Events outside the immediate Treatment interval remain visible.
- Added detailed Treatment Phase tags:
  - Pre-treatment
  - Sonication N — Pre
  - Sonication N — During
  - Sonication N — Post / Cooling
  - Between Sonications
  - Post-treatment
  - Outside Treatment phase
- During/Pre/Post events inherit the corresponding Sonication Number.
- Operation chart adds lightly colored background bands for each Treatment phase.
- Phase labels are drawn inside sufficiently wide chart regions.
- Operation table Phase column is renamed Treatment Phase.
- Preserved click stability, chart zoom/reset, RAW Series navigation and MR Series fixes.
