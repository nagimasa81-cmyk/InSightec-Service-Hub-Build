# RC2.4.5 test checklist

- Open Operation and confirm the complete WS log is displayed.
- Confirm events before and after Treatment remain in the table.
- Verify every Treatment-overlapping event has a detailed Treatment Phase tag.
- Verify During/Pre/Post events show the matching Sonication Number.
- Confirm chart background changes lightly by phase.
- Confirm phase labels align with the Treatment timeline.
- Test filters using Treatment Phase.
- Confirm click jump, drag zoom and double-click reset remain responsive.
- Confirm RAW Series navigation and MR Series image display remain functional.
