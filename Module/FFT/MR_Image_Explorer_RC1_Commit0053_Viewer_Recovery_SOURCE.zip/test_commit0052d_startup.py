from pathlib import Path
import ast

source_path = Path(__file__).with_name("app.py")
source = source_path.read_text(encoding="utf-8")
tree = ast.parse(source)

functions = {
    node.name
    for node in ast.walk(tree)
    if isinstance(node, ast.FunctionDef)
}

required = {
    "validate_startup_dependencies",
    "write_startup_error",
    "main",
}
missing = required - functions
assert not missing, f"Missing startup functions: {sorted(missing)}"

assert 'if __name__ == "__main__":' in source
assert "raise SystemExit(main())" in source
assert "window = MainWindow()" in source
assert "return app.exec()" in source
assert "MRIE_STARTUP_SMOKE_TEST" in source
assert "startup_error.log" in source
assert "APPLICATION_EVENT_LOOP_START" in source

print("Commit0052d startup bootstrap regression: PASS")
