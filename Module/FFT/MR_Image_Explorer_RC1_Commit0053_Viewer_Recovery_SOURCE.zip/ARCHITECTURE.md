# MR Image Explorer Engine Architecture — Commit0052

## Isolation rules

- `DisplayEngine` is the only public gateway for DICOM, RAW, bitmap and processed-image display.
- `ExplorerEngine` owns metadata tree construction, series filtering and text search. It never owns pixel arrays.
- `RenderingEngine` receives volume data but cannot replace the current 2D display path.
- `SpikeEngine` performs DICOM/RAW analysis without changing list-selection callbacks.
- Stable Commit0051 implementation bodies remain private (`_display_impl_*`, `_rendering_impl_*`, `_spike_impl_*`) during the migration.

This staged separation avoids a risky all-at-once rewrite while enforcing clear boundaries for all future changes.
