from __future__ import annotations

from typing import Any


class ExplorerEngine:
    """Metadata-only Series tree, filter and selection controller."""

    def __init__(self, host: Any):
        self.host = host
        self.series_filter = "All Series"
        self.search_text = ""


    @staticmethod
    def series_purpose_label(description: str, metadata: str = "") -> str:
        value = f"{description or ''} {metadata or ''}".upper()

        if "TMAP" in value or "TEMP MAP" in value or "TEMPERATURE MAP" in value:
            return "Temperature Map"
        if "MEMP" in value:
            return "Thermometry MEMP"
        if any(token in value for token in ("LOCALIZER", "SCOUT", "3-PLANE", "3 PLANE")):
            return "Localizer"
        if any(token in value for token in ("PLAN", "PLANNING", "TARGET")):
            return "Planning"
        if any(token in value for token in ("DWI", "DIFFUSION", "ADC")):
            return "Diffusion"
        if "T2" in value:
            return "T2"
        if "T1" in value:
            return "T1"
        return "Other MRI"

    @staticmethod
    def safe_series_number(dataset: Any) -> int:
        try:
            return int(getattr(dataset, "SeriesNumber", 0) or 0)
        except Exception:
            return 0

    @staticmethod
    def safe_series_description(dataset: Any) -> str:
        for attribute in (
            "SeriesDescription",
            "ProtocolName",
            "SequenceName",
        ):
            try:
                value = str(getattr(dataset, attribute, "") or "").strip()
            except Exception:
                value = ""
            if value:
                return value
        return "Unnamed Series"

    def rebuild(self) -> None:
        self.host._explorer_impl_populate_dicom_tree()
        self.apply_filter(self.series_filter, self.search_text)

    def apply_filter(self, series: str = "All Series", search: str = "") -> None:
        self.series_filter = str(series or "All Series")
        self.search_text = str(search or "").strip().lower()
        tree = self.host.tree
        root = tree.topLevelItem(0) if tree.topLevelItemCount() else None
        if root is None:
            return
        for i in range(root.childCount()):
            series_item = root.child(i)
            series_text = series_item.text(0)
            series_match = (
                self.series_filter == "All Series"
                or self.series_filter in series_text
            )
            visible_children = 0
            for j in range(series_item.childCount()):
                image_item = series_item.child(j)
                text = image_item.text(0).lower()
                visible = series_match and (
                    not self.search_text
                    or self.search_text in text
                    or self.search_text in series_text.lower()
                )
                image_item.setHidden(not visible)
                visible_children += int(visible)
            series_item.setHidden(not series_match or visible_children == 0)

    def series_labels(self) -> list[str]:
        labels = ["All Series"]
        tree = self.host.tree
        root = tree.topLevelItem(0) if tree.topLevelItemCount() else None
        if root is not None:
            labels.extend(root.child(i).text(0) for i in range(root.childCount()))
        return labels
