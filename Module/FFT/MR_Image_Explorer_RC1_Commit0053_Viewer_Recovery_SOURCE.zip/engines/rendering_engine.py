from __future__ import annotations

from typing import Any


class RenderingEngine:
    """Independent rendering workspace gateway.

    It can read DICOM volume data from the host, but it never changes the
    DisplayEngine's current image or list-selection callbacks.
    """

    def __init__(self, host: Any):
        self.host = host

    def open_workspace(self) -> None:
        self.host._rendering_impl_open_3d_workspace()

    def rotate_volume(self, volume, axis: str, direction: int = 1):
        return self.host._rotate_volume_90(volume, axis, direction)
