from __future__ import annotations

from typing import Any


class SpikeEngine:
    """Independent DICOM/RAW spike-analysis gateway."""

    def __init__(self, host: Any):
        self.host = host

    def apply(self) -> None:
        self.host._spike_impl_apply_spike_processing()

    def quick_detect(self) -> None:
        self.host._spike_impl_quick_spike_detect_prototype()
