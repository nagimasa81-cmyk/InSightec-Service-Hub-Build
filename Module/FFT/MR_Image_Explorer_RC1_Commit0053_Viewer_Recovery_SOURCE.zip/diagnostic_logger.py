from __future__ import annotations

import json
import logging
import os
import platform
import sys
import traceback
import zipfile
from datetime import datetime
from pathlib import Path
from threading import RLock
from typing import Any

import numpy as np


def _local_app_data() -> Path:
    base = os.environ.get("LOCALAPPDATA")
    if base:
        return Path(base)
    return Path.home() / "AppData" / "Local"


class DiagnosticLogger:
    def __init__(self, app_name: str, version: str):
        self.app_name = app_name
        self.version = version
        self.enabled = True
        self._lock = RLock()
        self.root = _local_app_data() / "MR_Image_Explorer"
        self.log_dir = self.root / "logs"
        self.export_dir = self.root / "diagnostics"
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.export_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_path = self.log_dir / f"MR_Image_Explorer_Debug_{timestamp}.log"
        self.state_path = self.log_dir / f"Display_State_{timestamp}.json"

        self.logger = logging.getLogger(f"MRImageExplorer.{timestamp}")
        self.logger.setLevel(logging.DEBUG)
        self.logger.propagate = False
        handler = logging.FileHandler(
            self.log_path,
            encoding="utf-8",
        )
        handler.setFormatter(
            logging.Formatter(
                "%(asctime)s.%(msecs)03d | %(levelname)s | %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
        )
        self.logger.addHandler(handler)

        self.info(
            "APPLICATION_START",
            app_name=app_name,
            version=version,
            python=sys.version,
            platform=platform.platform(),
        )

    def _write(self, level: int, event: str, **fields: Any) -> None:
        if not self.enabled:
            return
        payload = {"event": event, **fields}
        with self._lock:
            self.logger.log(
                level,
                json.dumps(
                    payload,
                    ensure_ascii=False,
                    default=str,
                    sort_keys=True,
                ),
            )

    def debug(self, event: str, **fields: Any) -> None:
        self._write(logging.DEBUG, event, **fields)

    def info(self, event: str, **fields: Any) -> None:
        self._write(logging.INFO, event, **fields)

    def warning(self, event: str, **fields: Any) -> None:
        self._write(logging.WARNING, event, **fields)

    def exception(self, event: str, error: BaseException, **fields: Any) -> None:
        self._write(
            logging.ERROR,
            event,
            error_type=type(error).__name__,
            error=str(error),
            traceback="".join(
                traceback.format_exception(
                    type(error),
                    error,
                    error.__traceback__,
                )
            ),
            **fields,
        )

    @staticmethod
    def array_summary(value: Any) -> dict[str, Any]:
        if value is None:
            return {
                "present": False,
                "shape": None,
                "dtype": None,
                "size": 0,
            }
        try:
            array = np.asarray(value)
            finite = array[np.isfinite(array)]
            return {
                "present": True,
                "shape": list(array.shape),
                "dtype": str(array.dtype),
                "size": int(array.size),
                "minimum": float(finite.min()) if finite.size else None,
                "maximum": float(finite.max()) if finite.size else None,
                "mean": float(finite.mean()) if finite.size else None,
                "nonzero": int(np.count_nonzero(array)),
                "finite_count": int(finite.size),
            }
        except Exception as exc:
            return {
                "present": True,
                "summary_error": f"{type(exc).__name__}: {exc}",
            }

    def save_state(self, state: dict[str, Any]) -> Path:
        with self._lock:
            self.state_path.write_text(
                json.dumps(
                    state,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                ),
                encoding="utf-8",
            )
        return self.state_path

    def clear(self) -> None:
        with self._lock:
            for handler in self.logger.handlers:
                handler.flush()
            self.log_path.write_text("", encoding="utf-8")
            self.info("LOG_CLEARED")

    def export_zip(
        self,
        destination: Path,
        extra_files: list[Path] | None = None,
        state: dict[str, Any] | None = None,
    ) -> Path:
        destination = Path(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if state is not None:
            self.save_state(state)

        with self._lock:
            for handler in self.logger.handlers:
                handler.flush()

            with zipfile.ZipFile(
                destination,
                "w",
                zipfile.ZIP_DEFLATED,
            ) as archive:
                if self.log_path.exists():
                    archive.write(self.log_path, f"logs/{self.log_path.name}")
                if self.state_path.exists():
                    archive.write(self.state_path, f"state/{self.state_path.name}")
                for file_path in extra_files or []:
                    path = Path(file_path)
                    if path.exists() and path.is_file():
                        archive.write(path, f"support/{path.name}")
        return destination


_INSTANCE: DiagnosticLogger | None = None


def initialize(app_name: str, version: str) -> DiagnosticLogger:
    global _INSTANCE
    if _INSTANCE is None:
        _INSTANCE = DiagnosticLogger(app_name, version)
    return _INSTANCE


def get_logger() -> DiagnosticLogger | None:
    return _INSTANCE
