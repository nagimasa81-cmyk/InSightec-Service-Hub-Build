from pathlib import Path
import ast

source = Path(__file__).with_name("app.py").read_text(encoding="utf-8")
tree = ast.parse(source)

blocks = {}
for node in ast.walk(tree):
    if isinstance(node, ast.FunctionDef):
        blocks[node.name] = ast.get_source_segment(source, node) or ""

required = {
    "read_dicom",
    "_visible_image_levels",
    "_paint_selected_dicom_original",
    "_display_impl_show_dicom",
    "set_view_mode",
}
missing = required - set(blocks)
assert not missing, f"Missing methods: {sorted(missing)}"

paint = blocks["_paint_selected_dicom_original"]
assert "auto_levels=True" in paint
assert "levels=levels" in paint
assert 'self.view_mode = "Original"' in paint
assert "self.primary_panel.set_image" in paint

show = blocks["_display_impl_show_dicom"]
assert "self.current_kspace = None" in show
assert "self.original_window_level = None" in show
assert "self.original_dynamic_range = None" in show
assert "self._paint_selected_dicom_original()" in show

read_block = blocks["read_dicom"]
assert "MONOCHROME1" in read_block
assert "np.nan_to_num" in read_block
assert "RescaleSlope" in read_block
assert "RescaleIntercept" in read_block

mode = blocks["set_view_mode"]
assert 'requested in {"FFT", "Both"}' in mode
assert "self.current_kspace = fft2c" in mode

print("Commit0052b visible DICOM regression: PASS")
