from pathlib import Path
import ast

root = Path(__file__).parent
app_source = (root / "app.py").read_text(encoding="utf-8")
logger_source = (root / "diagnostic_logger.py").read_text(encoding="utf-8")

ast.parse(app_source)
ast.parse(logger_source)

required_app_tokens = [
    "initialize_diagnostics",
    "IMAGE_PANEL_SET_IMAGE_BEGIN",
    "IMAGE_PANEL_SET_IMAGE_END",
    "DICOM_PIXEL_ARRAY_READY",
    "DISPLAY_DICOM_BEGIN",
    "TREE_ITEM_OPEN_REQUEST",
    "REFRESH_IMAGES_BEGIN",
    "Export Diagnostic ZIP",
    "_diagnostic_display_state",
]
for token in required_app_tokens:
    assert token in app_source, token

required_logger_tokens = [
    "MR_Image_Explorer_Debug_",
    "array_summary",
    "export_zip",
    "traceback",
]
for token in required_logger_tokens:
    assert token in logger_source, token

print("Commit0052c diagnostic logging regression: PASS")
