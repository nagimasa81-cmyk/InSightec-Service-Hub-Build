from pathlib import Path
import ast

root = Path(__file__).parent
source = (root / "app.py").read_text(encoding="utf-8")
stable = (
    root
    / "_stable_reference_not_packaged"
).read_text(encoding="utf-8") if (
    root / "_stable_reference_not_packaged"
).exists() else ""

tree = ast.parse(source)
methods = {
    node.name
    for node in ast.walk(tree)
    if isinstance(node, ast.FunctionDef)
}

required = {
    "_display_impl_show_dicom",
    "set_view_mode",
    "refresh_images",
    "_apply_image_orientation",
    "_open_tree_item",
    "_rendering_impl_open_3d_workspace",
}
assert not (required - methods)

assert 'self.view_mode = "Both"' in source
assert "self.current_kspace = fft2c(self.current_image)" in source
assert "self.secondary_panel.set_image" in source
assert "TREE_ITEM_OPEN_STABLE" in source
assert "class InteractiveRenderPanel" in source
assert "panRequested" in source
assert "windowLevelDragged" in source
assert "rotateRequested" in source
assert "DiagnosticLogger" in (
    root / "diagnostic_logger.py"
).read_text(encoding="utf-8")
assert 'if __name__ == "__main__":' in source

print("Commit0053 viewer recovery regression: PASS")
