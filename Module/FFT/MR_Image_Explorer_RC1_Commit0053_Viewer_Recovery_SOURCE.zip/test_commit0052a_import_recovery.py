from types import SimpleNamespace

from engines.explorer_engine import ExplorerEngine


def check(dataset, expected_number, expected_description, expected_purpose):
    number = ExplorerEngine.safe_series_number(dataset)
    description = ExplorerEngine.safe_series_description(dataset)
    purpose = ExplorerEngine.series_purpose_label(description)
    assert number == expected_number
    assert description == expected_description
    assert purpose == expected_purpose


check(
    SimpleNamespace(SeriesNumber=29, SeriesDescription="MEMP"),
    29,
    "MEMP",
    "Thermometry MEMP",
)
check(
    SimpleNamespace(SeriesNumber="bad", ProtocolName="TMAP"),
    0,
    "TMAP",
    "Temperature Map",
)
check(
    SimpleNamespace(),
    0,
    "Unnamed Series",
    "Other MRI",
)
check(
    SimpleNamespace(SeriesNumber=None, SeriesDescription="Localizer"),
    0,
    "Localizer",
    "Localizer",
)

print("Commit0052a import recovery regression: PASS")
