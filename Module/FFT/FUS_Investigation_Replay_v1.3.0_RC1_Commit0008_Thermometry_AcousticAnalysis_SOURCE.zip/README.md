# FUS Investigation & Treatment Replay Workstation RC1.3

## Main additions

- Sonication thermometry workflow:
  - baseline phase/magnitude RAW candidate
  - repeated sonication RAW frames
  - baseline/current/difference display
  - phase-difference and temperature-rise spatial candidates
- Real treatment RAW data are used when a consistent frame sequence can be reconstructed.
- Temperature values are not labeled in degrees Celsius until phase identity, unwrap, TE, field strength, PRF coefficient and timing are validated.
- Multi-hydrophone acoustic analysis:
  - 4–8 candidate channels
  - single, overlay, separate, average and maximum-envelope spectrum
  - spectrogram
  - all-channel heatmap
  - relative spectral-band comparison
  - time-resolved activity
  - RMS, crest-factor and impulsive-fraction channel comparison
- No simulated Hydrophone/Cavitation trace is displayed.
- Selected Sonication details remain fixed while the upper list scrolls.
- Previous/Next updates all review panels.

## Build

The source ZIP is compatible with the supplied RC1 GitHub Actions workflow.

- Entry point: app.py
- Python: 3.13
- Default build engine: fast_pyinstaller
