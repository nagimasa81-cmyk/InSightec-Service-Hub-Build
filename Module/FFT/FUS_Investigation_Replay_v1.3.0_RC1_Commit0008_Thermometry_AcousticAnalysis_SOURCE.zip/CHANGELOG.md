# Changelog

## v1.3.0-RC1 — Commit0008_Thermometry_AcousticAnalysis

- Added Thermometry Replay tab.
- Reconstructs a consistent RAW frame sequence per Sonication.
- Uses the first decodable consistent frame as the baseline candidate.
- Displays baseline, current frame and frame-minus-baseline.
- Added phase-difference and temperature-rise spatial candidate views.
- Explicitly separates real RAW reconstruction from unvalidated Celsius conversion.
- Added Channel Heatmap spectrum mode.
- Added Relative Cavitation Bands exploratory spectrum mode.
- Expanded Hydrophone Cavitation into time-resolved activity and per-channel acoustic metrics.
- Added RMS activity, crest factor and impulsive-fraction comparisons.
- Retained fixed lower Sonication details and synchronized Previous/Next navigation.
