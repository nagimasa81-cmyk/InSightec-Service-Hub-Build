from __future__ import annotations

import csv
import json
import os
import copy
import shutil
import sys
import tempfile
import zipfile
import threading
import queue
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import pydicom
import pyqtgraph as pg
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from PySide6.QtCore import Qt, Signal, QMimeData, QUrl, QTimer, QObject, QThread, Slot, QEvent, QSettings
from PySide6.QtGui import QAction, QKeySequence, QImage, QDrag
from pydicom.uid import generate_uid
from tracker_position import DirectionMeasurement, signal_peak_coordinate, solve_position
from stable_diagnostic_logger import StableDiagnosticLogger
from artifact_learning_db import ArtifactDatabase, image_features
from artifact_detection import classify_feature_vector, features_to_vector
from raw_import_engine import (
    RawImportError,
    RawImportResult,
    load_raw_file_auto,
    try_render_fus_raw_exact,
)
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout, QFrame,
    QGridLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QPushButton,
    QDoubleSpinBox, QProgressBar, QProgressDialog, QScrollArea, QSizePolicy, QSlider, QSpinBox, QSplitter, QStatusBar, QTabWidget, QTableWidget,
    QTableWidgetItem, QTextEdit, QTreeWidget, QTreeWidgetItem, QTreeWidgetItemIterator, QVBoxLayout, QWidget, QMenu,
)

APP_NAME = "MR Image Explorer"
APP_VERSION = "5.7.1 RC1 Minimal MRI Viewer Commit0057a"

pg.setConfigOptions(imageAxisOrder="row-major", antialias=True)


def median_filter_3x3_numpy(array: np.ndarray) -> np.ndarray:
    """NumPy-only 3x3 median filter used for RAW display scoring."""
    source = np.asarray(array, dtype=float)
    if source.ndim != 2 or source.size == 0:
        return source.copy()

    padded = np.pad(source, 1, mode="edge")
    try:
        windows = np.lib.stride_tricks.sliding_window_view(
            padded, (3, 3)
        )
        return np.median(windows, axis=(-2, -1))
    except Exception:
        output = np.empty_like(source, dtype=float)
        for row in range(source.shape[0]):
            for col in range(source.shape[1]):
                output[row, col] = np.median(
                    padded[row:row + 3, col:col + 3]
                )
        return output


def fft2c(image: np.ndarray) -> np.ndarray:
    return np.fft.fftshift(np.fft.fft2(np.fft.ifftshift(image)))


def ifft2c(kspace: np.ndarray) -> np.ndarray:
    return np.fft.fftshift(np.fft.ifft2(np.fft.ifftshift(kspace)))


def display_array(arr: np.ndarray, mode: str) -> np.ndarray:
    if mode == "FFT":
        return np.log1p(np.abs(arr))
    return np.abs(arr)


@dataclass
class DicomEntry:
    path: Path
    ds: pydicom.dataset.FileDataset
    image: Optional[np.ndarray]
    sort_key: tuple


class ImportWorker(QObject):
    progress = Signal(str, int, int)
    completed = Signal(object)
    failed = Signal(str)
    canceled = Signal()

    def __init__(self, paths: list[Path]):
        super().__init__()
        self.paths = [Path(path) for path in paths]
        self._cancel_requested = False
        self.temp_dirs: list[Path] = []
        self.raw_preview_cache: dict[str, RawImportResult] = {}
        self.origin_info: dict[str, dict] = {}

    @Slot()
    def cancel(self):
        self._cancel_requested = True

    def _check_cancel(self):
        if self._cancel_requested:
            raise InterruptedError("Import canceled")

    @staticmethod
    def _looks_tracker(path: Path) -> bool:
        name = path.name.lower()
        if "trackerimg" in name or "pfile" in name:
            return True
        if path.suffix == "" and path.stat().st_size > 4096:
            try:
                with path.open("rb") as handle:
                    first = handle.read(4)
                rev = np.frombuffer(first, dtype="<f4")[0]
                return bool(np.isfinite(rev) and 1 < rev < 100)
            except Exception:
                return False
        return False

    @staticmethod
    def _read_dicom_metadata(path: Path) -> DicomEntry:
        ds = pydicom.dcmread(
            str(path),
            stop_before_pixels=True,
            defer_size="1 KB",
            force=False,
        )
        rows = int(getattr(ds, "Rows", 0) or 0)
        cols = int(getattr(ds, "Columns", 0) or 0)
        if rows <= 0 or cols <= 0:
            raise ValueError("Not an image DICOM")

        instance = int(getattr(ds, "InstanceNumber", 0) or 0)
        position = getattr(ds, "ImagePositionPatient", None)
        z_value = (
            float(position[2])
            if position is not None and len(position) >= 3
            else float(instance)
        )
        series = str(getattr(ds, "SeriesInstanceUID", "") or "")
        sort_key = (series, z_value, instance, path.name.lower())
        return DicomEntry(path=path, ds=ds, image=None, sort_key=sort_key)

    def _extract_zip(self, path: Path) -> list[Path]:
        root = Path(tempfile.mkdtemp(prefix="mr_image_explorer_"))
        self.temp_dirs.append(root)

        extracted: list[Path] = []
        with zipfile.ZipFile(path) as archive:
            members = archive.infolist()
            total = max(len(members), 1)

            for index, member in enumerate(members, start=1):
                self._check_cancel()
                self.progress.emit(
                    f"Extracting ZIP {index:,}/{total:,}\n{member.filename}",
                    index,
                    total,
                )

                destination = (root / member.filename).resolve()
                if not str(destination).startswith(str(root.resolve())):
                    raise ValueError("Unsafe ZIP member path")

                if member.is_dir():
                    destination.mkdir(parents=True, exist_ok=True)
                    continue

                destination.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(member, "r") as source, destination.open("wb") as target:
                    while True:
                        self._check_cancel()
                        chunk = source.read(1024 * 1024)
                        if not chunk:
                            break
                        target.write(chunk)
                extracted.append(destination)
                member_path = Path(member.filename)
                self.origin_info[str(destination)] = {
                    "container": path.name,
                    "container_type": "ZIP",
                    "relative_path": member.filename,
                    "group_path": str(member_path.parent)
                    if str(member_path.parent) != "."
                    else "(ZIP root)",
                }

        return extracted

    @Slot()
    def run(self):
        try:
            supported_extensions = {
                ".dcm", ".ima", ".dicom", "",
                ".raw", ".bin", ".dat", ".7", ".pfile", ".img", ".kspace", ".cfl", ".rawdata", ".complex",
                ".csv", ".npy", ".npz",
                ".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff",
            }

            files: list[Path] = []
            checked = 0

            self.progress.emit("Collecting files...", 0, 0)

            for source in self.paths:
                self._check_cancel()

                if source.is_dir():
                    for candidate in source.rglob("*"):
                        self._check_cancel()
                        checked += 1
                        if candidate.is_file():
                            files.append(candidate)
                            try:
                                relative = candidate.relative_to(source)
                            except Exception:
                                relative = Path(candidate.name)
                            self.origin_info[str(candidate)] = {
                                "container": source.name,
                                "container_type": "Folder",
                                "relative_path": str(relative),
                                "group_path": str(relative.parent)
                                if str(relative.parent) != "."
                                else "(Folder root)",
                            }
                        if checked % 100 == 0:
                            self.progress.emit(
                                f"Scanning folder...\n"
                                f"Checked: {checked:,}\n"
                                f"Candidates: {len(files):,}",
                                0,
                                0,
                            )

                elif source.is_file() and source.suffix.lower() == ".zip":
                    files.extend(self._extract_zip(source))

                elif source.is_file():
                    files.append(source)
                    self.origin_info[str(source)] = {
                        "container": source.parent.name,
                        "container_type": "File",
                        "relative_path": source.name,
                        "group_path": "(Selected files)",
                    }

            unique_files: list[Path] = []
            seen = set()
            for path in files:
                self._check_cancel()
                try:
                    key = str(path.resolve()).lower()
                except Exception:
                    key = str(path).lower()
                if key not in seen:
                    seen.add(key)
                    unique_files.append(path)

            files = unique_files
            total = len(files)

            dicoms: list[DicomEntry] = []
            trackers: list[Path] = []
            raw_files: list[Path] = []
            bitmaps: list[Path] = []
            signals: list[Path] = []
            skipped = 0

            for index, path in enumerate(files, start=1):
                self._check_cancel()
                self.progress.emit(
                    f"Indexing {index:,}/{total:,}\n{path.name}",
                    index,
                    max(total, 1),
                )

                suffix = path.suffix.lower()

                # First test every file as DICOM. This includes extensionless
                # and vendor-named image files in deep ZIP/folder structures.
                try:
                    dicoms.append(self._read_dicom_metadata(path))
                    continue
                except Exception:
                    pass

                if suffix in {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}:
                    bitmaps.append(path)
                    continue
                if suffix in {".csv", ".npy", ".npz"}:
                    signals.append(path)
                    continue
                if suffix in {".txt", ".json", ".xml", ".ini", ".log", ".md"}:
                    continue

                try:
                    if self._looks_tracker(path):
                        trackers.append(path)
                    elif suffix in {".raw", ".bin", ".dat", ".7", ".pfile", ".img", ".kspace", ".cfl", ".rawdata", ".complex"}:
                        raw_files.append(path)

                        # Build the exact FUS preview while the import worker is
                        # already indexing files. Tree selection will therefore
                        # display immediately without another decoding pass.
                        try:
                            exact_preview = try_render_fus_raw_exact(path)
                            if exact_preview is not None:
                                self.raw_preview_cache[str(path)] = exact_preview
                        except Exception:
                            pass
                    else:
                        skipped += 1
                except Exception:
                    skipped += 1

            dicoms.sort(key=lambda entry: entry.sort_key)

            self.completed.emit({
                "all_files": files,
                "dicoms": dicoms,
                "trackers": trackers,
                "raw_files": raw_files,
                "raw_preview_cache": self.raw_preview_cache,
                "origin_info": self.origin_info,
                "bitmaps": bitmaps,
                "signals": signals,
                "skipped": skipped,
                "temp_dirs": self.temp_dirs,
            })

        except InterruptedError:
            self.canceled.emit()
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class DropBanner(QFrame):
    pathsDropped = Signal(list)
    clicked = Signal()

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.setObjectName("DropBanner")
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip(
            "Click to select files or a folder.\n"
            "You can also drag and drop files, folders, or ZIP archives here."
        )
        layout = QVBoxLayout(self)
        self.title = QLabel("Click or Drop DICOM / Raw / P File / 1D Data / Folder / ZIP Here")
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setStyleSheet("font-size: 17px; font-weight: 600;")
        subtitle = QLabel("DICOM, RAW, GE TrackerImg/PFile, Siemens .dat, CSV/TXT/NPY/NPZ, images")
        subtitle.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.title)
        layout.addWidget(subtitle)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit()
            event.accept()
            return
        super().mousePressEvent(event)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self.setProperty("dragActive", True)
            self.style().unpolish(self); self.style().polish(self)

    def dragLeaveEvent(self, event):
        self.setProperty("dragActive", False)
        self.style().unpolish(self); self.style().polish(self)

    def dropEvent(self, event):
        self.setProperty("dragActive", False)
        self.style().unpolish(self)
        self.style().polish(self)
        paths = [
            Path(url.toLocalFile())
            for url in event.mimeData().urls()
            if url.isLocalFile()
        ]
        if paths:
            event.setDropAction(Qt.CopyAction)
            event.accept()
            self.pathsDropped.emit(paths)


class ImagePanel(QWidget):
    lineChanged = Signal(int, int)
    pageRequested = Signal(int)
    mouseActionChanged = Signal(str)
    viewRequested = Signal(str)
    levelWheel = Signal(float, bool)

    def __init__(self, title: str):
        super().__init__()
        layout = QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        self.label = QLabel(title)
        self.label.setStyleSheet("font-weight: 600; padding: 3px;")
        layout.addWidget(self.label)
        self.plot = pg.PlotWidget()
        self.plot.setMenuEnabled(False)
        self.plot.getViewBox().setMenuEnabled(False)
        self.plot.scene().sigMouseClicked.connect(self._scene_mouse_clicked)
        self.plot.viewport().installEventFilter(self)
        self.mouse_action = "Window/Level"
        self._wl_drag_origin = None
        self._wl_drag_start = None
        self.plot.setAspectLocked(True)
        self.plot.hideAxis("left"); self.plot.hideAxis("bottom")
        self.image_item = pg.ImageItem()
        self.plot.addItem(self.image_item)
        self.hline = pg.InfiniteLine(angle=0, movable=True, pen=pg.mkPen('#ff4949', width=1.5, style=Qt.DashLine))
        self.vline = pg.InfiniteLine(angle=90, movable=True, pen=pg.mkPen('#ff4949', width=1.5, style=Qt.DashLine))
        self.plot.addItem(self.hline); self.plot.addItem(self.vline)
        self.hline.sigPositionChanged.connect(self._emit_position)
        self.vline.sigPositionChanged.connect(self._emit_position)
        self.comp_roi = pg.RectROI([10, 10], [40, 40], pen=pg.mkPen("#35a7ff", width=2))
        self.comp_roi.addScaleHandle([1, 1], [0, 0])
        self.comp_roi.addScaleHandle([0, 0], [1, 1])
        self.comp_roi.addScaleHandle([1, 0], [0, 1])
        self.comp_roi.addScaleHandle([0, 1], [1, 0])
        self.comp_roi.hide()
        self.plot.addItem(self.comp_roi)
        layout.addWidget(self.plot, 1)
        self.shape = (1, 1)
        self.current_levels = None

        self.orientation_labels = {}
        for key in ("top", "bottom", "left", "right"):
            orientation_label = QLabel("", self)
            orientation_label.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            orientation_label.setStyleSheet(
                "color:#fff4a6; font-size:17px; font-weight:900;"
                "background:rgba(0,0,0,105); padding:2px 5px; border-radius:3px;"
            )
            orientation_label.hide()
            self.orientation_labels[key] = orientation_label

        self.annotation_label = QLabel("", self)
        self.annotation_label.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.annotation_label.setWordWrap(True)
        self.annotation_label.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.annotation_label.setStyleSheet(
            "color:#f2f7fb; font-size:12px; font-weight:700;"
            "background:rgba(0,0,0,120);"
            "border:1px solid rgba(80,200,255,150);"
            "padding:5px 7px; border-radius:4px;"
        )
        self.annotation_label.hide()

    def set_orientation_labels(self, values):
        for key, label in self.orientation_labels.items():
            value = str(values.get(key, "") or "").strip()
            label.setText(value)
            label.setVisible(bool(value))
        self._position_orientation_labels()

    def clear_orientation_labels(self):
        self.set_orientation_labels({})

    def set_annotation(self, text, mode="Minimum"):
        value = str(text or "").strip()
        self.annotation_label.setText(value)
        self.annotation_label.setVisible(bool(value))
        self.annotation_label.setMaximumWidth(360 if mode == "Full" else 260)
        self._position_annotation()

    def clear_annotation(self):
        self.annotation_label.clear()
        self.annotation_label.hide()

    def _position_annotation(self):
        if not self.annotation_label.isVisible():
            return
        self.annotation_label.adjustSize()
        width = min(self.annotation_label.width(), max(180, self.width() // 2))
        self.annotation_label.resize(width, self.annotation_label.sizeHint().height())
        self.annotation_label.move(12, 38)
        self.annotation_label.raise_()

    def _position_orientation_labels(self):
        margin = 12
        rect = self.rect()
        for key, label in self.orientation_labels.items():
            if not label.isVisible():
                continue
            label.adjustSize()
            if key == "top":
                label.move((rect.width() - label.width()) // 2, 34)
            elif key == "bottom":
                label.move(
                    (rect.width() - label.width()) // 2,
                    rect.height() - label.height() - margin,
                )
            elif key == "left":
                label.move(margin, (rect.height() - label.height()) // 2)
            else:
                label.move(
                    rect.width() - label.width() - margin,
                    (rect.height() - label.height()) // 2,
                )
            label.raise_()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._position_orientation_labels()
        self._position_annotation()

    def eventFilter(self, watched, event):
        if watched is self.plot.viewport():
            if event.type() == QEvent.MouseButtonPress and event.button() == Qt.RightButton and self.mouse_action == "Window/Level":
                self._wl_drag_origin = event.position()
                window = self.window()
                self._wl_drag_start = (
                    float(window.window_level_spin.value()),
                    float(window.dynamic_range_spin.value()),
                )
                return True
            if event.type() == QEvent.MouseMove and self._wl_drag_origin is not None and event.buttons() & Qt.RightButton:
                delta = event.position() - self._wl_drag_origin
                level, width = self._wl_drag_start
                scale = max(width, 1.0)
                window = self.window()
                window.window_level_spin.setValue(level - float(delta.y()) * scale / 240.0)
                window.dynamic_range_spin.setValue(max(1e-6, width + float(delta.x()) * scale / 170.0))
                window._manual_levels_changed()
                return True
            if event.type() == QEvent.MouseButtonRelease and event.button() == Qt.RightButton and self._wl_drag_origin is not None:
                self._wl_drag_origin = None
                self._wl_drag_start = None
                return True
            if event.type() == QEvent.Wheel:
                if event.modifiers() & Qt.ControlModifier:
                    self.pageRequested.emit(1 if event.angleDelta().y() < 0 else -1)
                else:
                    factor = 0.90 if event.angleDelta().y() < 0 else 1.10
                    self.plot.getViewBox().scaleBy((factor, factor))
                return True
        return super().eventFilter(watched, event)

    def _scene_mouse_clicked(self, event):
        if event.button() == Qt.RightButton:
            event.accept()
            self._show_mouse_action_menu(event.screenPos().toPoint())

    def _show_mouse_action_menu(self, global_pos):
        menu = QMenu(self)

        wl_action = menu.addAction("Window / Level mode")
        pan_action = menu.addAction("Pan mode")
        zoom_action = menu.addAction("Zoom rectangle mode")
        paging_action = menu.addAction("Mouse wheel paging")
        roi_action = menu.addAction("Show Compensation ROI")

        menu.addSeparator()
        fft_action = menu.addAction("FFT Current Image")
        back_fft_action = None
        if getattr(self.window(), "fft_view_active", False):
            back_fft_action = menu.addAction("Back from FFT")
        previous_action = menu.addAction("Previous Image")
        next_action = menu.addAction("Next Image")

        menu.addSeparator()
        auto_action = menu.addAction("Auto Window / Level")
        reset_action = menu.addAction("Reset View")

        selected = menu.exec(global_pos)
        if selected is None:
            return

        view_box = self.plot.getViewBox()

        if selected == wl_action:
            self.mouse_action = "Window/Level"
            self.comp_roi.hide()
            self.mouseActionChanged.emit(self.mouse_action)
        elif selected == pan_action:
            self.mouse_action = "Pan"
            self.comp_roi.hide()
            view_box.setMouseMode(pg.ViewBox.PanMode)
            self.mouseActionChanged.emit(self.mouse_action)
        elif selected == zoom_action:
            self.mouse_action = "Zoom"
            self.comp_roi.hide()
            view_box.setMouseMode(pg.ViewBox.RectMode)
            self.mouseActionChanged.emit(self.mouse_action)
        elif selected == paging_action:
            self.mouse_action = "Paging"
            self.comp_roi.hide()
            self.mouseActionChanged.emit(self.mouse_action)
        elif selected == roi_action:
            self.mouse_action = "ROI"
            self.comp_roi.show()
            self.mouseActionChanged.emit(self.mouse_action)
        elif selected == fft_action:
            self.viewRequested.emit("FFT_CURRENT")
        elif back_fft_action is not None and selected == back_fft_action:
            self.viewRequested.emit("BACK_FFT")
        elif selected == previous_action:
            self.pageRequested.emit(-1)
        elif selected == next_action:
            self.pageRequested.emit(1)
        elif selected == auto_action:
            self.mouseActionChanged.emit("Auto Window/Level")
        elif selected == reset_action:
            view_box.autoRange()
            self.viewRequested.emit("Default")


    def wheelEvent(self, event):
        if event.modifiers() & Qt.ControlModifier:
            self.pageRequested.emit(1 if event.angleDelta().y() < 0 else -1)
        else:
            factor = 0.90 if event.angleDelta().y() < 0 else 1.10
            self.plot.getViewBox().scaleBy((factor, factor))
        event.accept()


    def set_image(self, image: np.ndarray, auto_levels=True, levels=None):
        image = np.asarray(image, dtype=float)
        self.shape = image.shape[:2]
        self.current_levels = levels
        self.image_item.setImage(image, autoLevels=auto_levels if levels is None else False, levels=levels)
        self.plot.setRange(xRange=(0, self.shape[1]), yRange=(0, self.shape[0]), padding=0)
        self.set_line_position(self.shape[0] // 2, self.shape[1] // 2)

    def set_levels(self, low: float, high: float):
        if high <= low:
            high = low + 1.0
        self.current_levels = (float(low), float(high))
        self.image_item.setLevels(self.current_levels)

    def show_comp_roi(self):
        rows, cols = self.shape
        width = max(8, cols // 5)
        height = max(8, rows // 5)
        self.comp_roi.setPos((cols - width) / 2, (rows - height) / 2)
        self.comp_roi.setSize((width, height))
        self.comp_roi.show()

    def hide_comp_roi(self):
        self.comp_roi.hide()

    def comp_roi_bounds(self):
        pos = self.comp_roi.pos()
        size = self.comp_roi.size()
        x0 = max(0, min(int(round(pos.x())), self.shape[1] - 1))
        y0 = max(0, min(int(round(pos.y())), self.shape[0] - 1))
        x1 = max(x0 + 1, min(int(round(pos.x() + size.x())), self.shape[1]))
        y1 = max(y0 + 1, min(int(round(pos.y() + size.y())), self.shape[0]))
        return y0, y1, x0, x1

    def set_line_position(self, row: int, col: int):
        row = max(0, min(int(row), self.shape[0] - 1))
        col = max(0, min(int(col), self.shape[1] - 1))
        self.hline.blockSignals(True); self.vline.blockSignals(True)
        self.hline.setPos(row); self.vline.setPos(col)
        self.hline.blockSignals(False); self.vline.blockSignals(False)

    def _emit_position(self):
        row = max(0, min(int(round(self.hline.value())), self.shape[0] - 1))
        col = max(0, min(int(round(self.vline.value())), self.shape[1] - 1))
        self.lineChanged.emit(row, col)




class ServiceProgressDialog(QFrame):
    canceled = Signal()

    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setObjectName("ServiceProgressOverlay")
        self.setFrameShape(QFrame.StyledPanel)
        self.setMinimumHeight(118)
        self.setMaximumHeight(142)
        self.setStyleSheet("""
            QFrame#ServiceProgressOverlay {
                background: #18212b;
                color: #f2f6fa;
                border: 2px solid #2faee5;
                border-radius: 10px;
            }
            QLabel {
                color: #f2f6fa;
                border: none;
                background: transparent;
            }
            QProgressBar {
                min-height: 28px;
                max-height: 32px;
                border: 1px solid #55758e;
                border-radius: 6px;
                text-align: center;
                background: #0e151c;
                color: white;
                font-size: 15px;
                font-weight: 700;
            }
            QProgressBar::chunk {
                background: #1ea7e8;
                border-radius: 5px;
            }
            QPushButton {
                min-height: 34px;
                max-height: 38px;
                min-width: 104px;
                font-size: 14px;
                font-weight: 700;
                background: #2e4355;
                color: white;
                border: 1px solid #6c8da6;
                border-radius: 6px;
            }
            QPushButton:hover {
                background: #3b5770;
            }
            QPushButton:disabled {
                color: #8293a1;
                background: #25333f;
            }
        """)

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 10, 18, 10)
        root.setSpacing(7)

        # Top-aligned controls remain accessible even on a short screen.
        top_row = QHBoxLayout()
        top_row.setSpacing(12)

        self.title_label = QLabel(title)
        self.title_label.setStyleSheet(
            "font-size: 18px; font-weight: 800; color: #ffffff;"
        )
        top_row.addWidget(self.title_label, 1)

        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self._cancel)
        top_row.addWidget(self.cancel_button, 0, Qt.AlignTop)

        root.addLayout(top_row)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        root.addWidget(self.progress)

        # Only one information line is displayed. There is no second stage line.
        self.message = QLabel("")
        self.message.setWordWrap(False)
        self.message.setTextInteractionFlags(Qt.NoTextInteraction)
        self.message.setStyleSheet(
            "font-size: 13px; font-weight: 600; color: #dce8f1;"
        )
        self.message.setMinimumHeight(20)
        root.addWidget(self.message)

        self._canceled = False
        self.hide()

    def _cancel(self):
        self._canceled = True
        self.cancel_button.setEnabled(False)
        self.cancel_button.setText("Canceling...")
        self.canceled.emit()

    def wasCanceled(self):
        return self._canceled

    def setMaximum(self, maximum: int):
        self.progress.setMaximum(max(1, int(maximum)))

    def setValue(self, value: int):
        self.progress.setValue(int(value))

    def setLabelText(self, text: str):
        lines = [line.strip() for line in str(text).splitlines() if line.strip()]
        detail = lines[-1] if lines else ""
        if len(detail) > 104:
            detail = "..." + detail[-101:]
        self.message.setText(detail)

    def reset_for_use(self, title: str):
        self._canceled = False
        self.title_label.setText(title)
        self.cancel_button.setText("Cancel")
        self.cancel_button.setEnabled(True)
        self.message.clear()

    def raise_(self):
        super().raise_()

    def activateWindow(self):
        window = self.window()
        if window is not None:
            window.raise_()
            window.activateWindow()



class AccordionSection(QWidget):
    opened = Signal(object)
    def __init__(self, title, content, expanded=False, parent=None):
        super().__init__(parent); self.title=title; self.content=content
        lay=QVBoxLayout(self); lay.setContentsMargins(0,0,0,0); lay.setSpacing(3)
        self.button=QPushButton(); self.button.setCheckable(True); self.button.clicked.connect(self._toggle)
        self.button.setStyleSheet("QPushButton{text-align:left;min-height:30px;font-weight:700;background:#1e4b72;border:1px solid #37698f;border-radius:4px;padding:4px 8px} QPushButton:hover{background:#265f8e}")
        lay.addWidget(self.button); lay.addWidget(content); self.set_expanded(expanded,False)
    def _label(self): self.button.setText(("▼" if self.button.isChecked() else "▶")+"  "+self.title)
    def _toggle(self): self.set_expanded(self.button.isChecked(),True)
    def set_expanded(self, expanded, notify=False):
        self.button.blockSignals(True); self.button.setChecked(bool(expanded)); self.button.blockSignals(False)
        self.content.setVisible(bool(expanded)); self._label()
        if expanded and notify: self.opened.emit(self)

class DicomHeaderDialog(QDialog):
    def __init__(self, ds, source_path, parent=None):
        super().__init__(parent); self.ds=copy.deepcopy(ds) if ds is not None else None; self.source_path=Path(source_path) if source_path else None; self._editable=False
        self.setWindowTitle('DICOM Header'); self.resize(1120,720)
        root=QVBoxLayout(self); row=QHBoxLayout(); self.filter_edit=QLineEdit(); self.filter_edit.setPlaceholderText('Filter DICOM header...'); self.filter_edit.textChanged.connect(self._filter); row.addWidget(self.filter_edit,1)
        for label,cb in [('Edit',self.enable_edit),('Save',self.save_edited),('Close',self.close)]: b=QPushButton(label); b.clicked.connect(cb); row.addWidget(b)
        root.addLayout(row); self.table=QTableWidget(0,6); self.table.setHorizontalHeaderLabels(['Tag','Keyword','Name','VR','VM','Value']); self.table.horizontalHeader().setStretchLastSection(True); self.table.setSelectionMode(QTableWidget.ExtendedSelection); self.table.setContextMenuPolicy(Qt.CustomContextMenu); self.table.customContextMenuRequested.connect(self._menu); root.addWidget(self.table,1); self.status=QLabel('Read-only. Press Edit to change values.'); root.addWidget(self.status); self._populate()
    def _populate(self):
        rows=[]
        if self.ds:
            for e in self.ds.iterall():
                if e.tag.group!=0x7FE0: rows.append((str(e.tag),e.keyword,e.name,e.VR,str(e.VM),str(e.value)))
        self.table.setRowCount(len(rows))
        for r,vals in enumerate(rows):
            for c,v in enumerate(vals):
                it=QTableWidgetItem(v); it.setFlags(it.flags() & ~Qt.ItemIsEditable); self.table.setItem(r,c,it)
        self.table.resizeColumnsToContents()
    def enable_edit(self):
        self._editable=True
        for r in range(self.table.rowCount()):
            it=self.table.item(r,5)
            if it: it.setFlags(it.flags()|Qt.ItemIsEditable)
        self.status.setText('Edit mode enabled. Value column is editable.')
    def _menu(self,pos):
        m=QMenu(self); a1=m.addAction('Copy Selection'); a2=m.addAction('Copy Value'); a3=m.addAction('Copy Row'); a4=m.addAction('Select All'); a=m.exec(self.table.viewport().mapToGlobal(pos))
        if a==a4: self.table.selectAll(); return
        cur=self.table.currentItem()
        if a==a1: QApplication.clipboard().setText('\n'.join(i.text() for i in self.table.selectedItems()))
        elif a==a2 and cur: QApplication.clipboard().setText(self.table.item(cur.row(),5).text())
        elif a==a3 and cur: QApplication.clipboard().setText('\t'.join(self.table.item(cur.row(),c).text() if self.table.item(cur.row(),c) else '' for c in range(6)))
    def _filter(self,q):
        q=q.lower()
        for r in range(self.table.rowCount()): self.table.setRowHidden(r, not any(q in (self.table.item(r,c).text().lower() if self.table.item(r,c) else '') for c in range(6)))
    def _next_path(self):
        folder=(self.source_path.parent if self.source_path else Path.cwd())/'Edited'; folder.mkdir(parents=True,exist_ok=True); base=self.source_path.stem if self.source_path else 'DICOM'; out=folder/f'{base}_Edit.dcm'; n=1
        while out.exists(): out=folder/f'{base}_Edit{n}.dcm'; n+=1
        return out
    def save_edited(self):
        if not self.ds or not self._editable: QMessageBox.information(self,'DICOM Header','Press Edit before saving.'); return
        changed=0
        for r in range(self.table.rowCount()):
            try:
                g,e=self.table.item(r,0).text().strip('()').split(','); tag=(int(g,16),int(e,16)); val=self.table.item(r,5).text()
                if tag in self.ds and str(self.ds[tag].value)!=val: self.ds[tag].value=val; changed+=1
            except Exception: pass
        out=self._next_path()
        try: self.ds.save_as(str(out))
        except Exception as exc: QMessageBox.critical(self,'Save Error',str(exc)); return
        self.status.setText(f'Saved {changed} changed value(s): {out}'); QMessageBox.information(self,'DICOM Header',f'Saved:\n{out}')

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} {APP_VERSION}")
        self.stable_diagnostics = StableDiagnosticLogger(APP_VERSION)
        self.stable_diagnostics.info("MAIN_WINDOW_INIT")
        self.resize(980, 700)
        self.setMinimumSize(820, 560)
        self.setAcceptDrops(True)
        self.temp_dirs: list[Path] = []
        self.dicom_entries: list[DicomEntry] = []
        self.current_image: Optional[np.ndarray] = None
        self.current_kspace: Optional[np.ndarray] = None
        self.current_recon: Optional[np.ndarray] = None
        self.current_ds = None
        self.current_source = ""
        self.current_raw_result: Optional[RawImportResult] = None
        self.raw_preview_cache: dict[str, RawImportResult] = {}
        self.import_origin_info: dict[str, dict] = {}
        self._active_tree_source_key = None
        self._tree_open_in_progress = False
        self.orientation_override = {
            "top": None, "bottom": None, "left": None, "right": None
        }
        self.orientation_plane_override = "Auto"
        self.annotation_visible = False
        self.annotation_mode = "Minimum"
        self.raw_display_mode = "Auto"
        self.view_mode = "Both"
        self.line_orientation = "Row"
        self.line_row = 0
        self.line_col = 0
        self.line_row_ratio = 0.5
        self.line_col_ratio = 0.5
        self.signals: list[dict] = []
        self.imported_paths: list[Path] = []
        self.spike_results: list[dict] = []
        self.active_spike_indices = np.array([], dtype=int)
        self.tracker_matrix: Optional[np.ndarray] = None
        self.tracker_source_path: Optional[Path] = None
        self.tracker_files: list[dict] = []
        self.tracker_file_index: int = -1
        self.tracker_line_metrics: list[dict] = []
        self.tracker_selected_lines: list[int] = []
        self.tracker_position_measurements: list[DirectionMeasurement] = []
        self.tracker_reconstructed_image: Optional[np.ndarray] = None
        self.tracker_strongest_line: Optional[np.ndarray] = None
        self.tracker_strongest_line_index: int = -1
        self.tracker_shared_name: str = ""
        self.artifact_db: Optional[ArtifactDatabase] = None
        self.artifact_db_path: Optional[Path] = None
        self.artifact_selected_indices: list[int] = []
        self.normal_reference_image: Optional[np.ndarray] = None
        self.normal_reference_path: Optional[Path] = None
        self.compensation_preview: Optional[np.ndarray] = None
        self.compensation_original: Optional[np.ndarray] = None
        self.compensation_original_kspace: Optional[np.ndarray] = None
        self.compensation_history: list[dict] = []
        self.compensation_history_index: int = -1
        self.compensation_base_kspace: Optional[np.ndarray] = None
        self.compensation_base_image: Optional[np.ndarray] = None
        self.compensation_roi_panel: Optional[ImagePanel] = None
        self.addsub_preview_result: Optional[np.ndarray] = None
        self.addsub_preview_operation: str = ""
        self.addsub_a: Optional[dict] = None
        self.addsub_b: Optional[dict] = None
        self.processed_images: dict[str, np.ndarray] = {}
        self.processed_sources: dict[str, Path] = {}
        self.window_level: Optional[float] = None
        self.dynamic_range: Optional[float] = None
        self.original_window_level: Optional[float] = None
        self.original_dynamic_range: Optional[float] = None
        self.raw_window_level: Optional[float] = None
        self.raw_dynamic_range: Optional[float] = None
        self.level_preset = "Auto"
        self.source_kind = "none"
        self.output_root_override: Optional[Path] = None
        self.last_import_output_root: Optional[Path] = None
        self.current_mouse_action = "Window/Level"
        self.fft_view_active = False
        self.fft_back_image: Optional[np.ndarray] = None
        self.quick_spike_threshold = 0.0
        self.tracker_analysis_text: dict[str, str] = {}
        self.import_in_progress = False
        self.lazy_dicom_cache_limit = 24
        self.lazy_dicom_cache_order: list[int] = []
        self.pending_tracker_paths: list[Path] = []
        self.pending_first_dicom_index: Optional[int] = None
        self.import_thread: Optional[QThread] = None
        self.import_worker: Optional[ImportWorker] = None
        self.import_python_thread: Optional[threading.Thread] = None
        self.import_event_queue: queue.Queue = queue.Queue()
        self.import_cancel_event = threading.Event()
        self.import_poll_timer = QTimer(self)
        self.import_poll_timer.setInterval(50)
        self.import_poll_timer.timeout.connect(self._poll_import_queue)
        self.import_last_event_time = 0.0
        self.import_thread_started = False
        self.import_start_time = 0.0
        self.import_history: list[dict] = []
        self._responsive_pending = False
        self._initial_fit_done = False
        self._user_main_split_sizes: list[int] = []
        self._user_left_split_sizes: list[int] = []
        self._user_vertical_split_sizes: list[int] = []
        self._user_image_split_sizes: list[int] = []
        self.developer_mode = False
        self.spike_diagnostic_records: dict[int, dict] = {}
        self._screen_fit_completed = False
        self.viewer_settings = QSettings("InSightec", "MR_Image_Explorer")

        self._build_ui()
        self._build_menu()
        self._apply_style()
        self.tabs.currentChanged.connect(
            lambda _index: self._schedule_responsive_layout()
        )
        self.statusBar().showMessage("Ready — drop files or folders above")
        QTimer.singleShot(0, self._restore_viewer_layout)
        QTimer.singleShot(0, self._initial_screen_fit)
        QTimer.singleShot(180, self._initial_screen_fit)
        QTimer.singleShot(420, self._initial_screen_fit)

    def _build_ui(self):
        root = QWidget()
        root_l = QVBoxLayout(root)
        root_l.setContentsMargins(8, 8, 8, 8)
        root_l.setSpacing(6)
        self.root_layout = root_l

        self.drop_banner = DropBanner()
        self.drop_banner.pathsDropped.connect(self.request_import)
        self.drop_banner.clicked.connect(self.open_import_selection)
        root_l.addWidget(self.drop_banner)

        # This panel is a normal layout widget, not an overlay.
        # It cannot be hidden behind pyqtgraph/OpenGL/native child windows.
        self.import_progress_panel = ServiceProgressDialog(
            "Importing MRI Data",
            root,
        )
        self.import_progress_panel.hide()
        self.import_progress_panel.setSizePolicy(
            QSizePolicy.Expanding,
            QSizePolicy.Fixed,
        )
        root_l.addWidget(self.import_progress_panel)

        self.tabs = QTabWidget()
        self.tabs.setMovable(False)
        self.tabs.setDocumentMode(False)
        self.tabs.setTabPosition(QTabWidget.North)
        self.tabs.addTab(self._build_workspace(), "Image Workspace")
        self.tabs.addTab(self._build_spike_results(), "Spike Diag")
        self.tabs.addTab(self._build_artifact_diag(), "Artifact Diag")
        self.tabs.addTab(self._build_tracker_signal_combined(), "Tracker Signal")
        self.tabs.addTab(self._build_signal_studio(), "1D Signal Studio")

        self.global_toolbar = QWidget()
        global_toolbar_layout = QHBoxLayout(self.global_toolbar)
        global_toolbar_layout.setContentsMargins(0, 2, 0, 2)
        global_toolbar_layout.setSpacing(5)

        self.global_import_button = QPushButton("Import")
        self.global_import_button.clicked.connect(
            self.open_import_selection
        )
        global_toolbar_layout.addWidget(self.global_import_button)

        self.display_reset_button = QPushButton("Display Reset")
        self.display_reset_button.clicked.connect(self.reset_viewer_display)
        global_toolbar_layout.addWidget(self.display_reset_button)

        # These operations affect the complete workspace, so they are kept
        # outside the image-only toolbar.
        for button in (
            self.previous_import_button,
            self.clear_selected_images_button,
            self.clear_all_images_button,
            self.header_popup_button,
            self.image_orientation_button,
            self.quick_spike_button,
        ):
            global_toolbar_layout.addWidget(button)

        global_toolbar_layout.addStretch(1)
        root_l.addWidget(self.global_toolbar)
        root_l.addWidget(self.tabs, 1)

        self.setCentralWidget(root)
        self.setStatusBar(QStatusBar())



    def _build_artifact_diag(self):
        page=QWidget(); lay=QVBoxLayout(page); inner=QTabWidget(); inner.addTab(self._build_artifact_detection(),'Detection'); inner.addTab(self._build_artifact_learning(),'Learning'); lay.addWidget(inner); return page

    def _build_tracker_signal_combined(self):
        page=QWidget(); lay=QVBoxLayout(page); inner=QTabWidget(); inner.addTab(self._build_tracker_explorer(),'Signal Explorer'); inner.addTab(self._build_tracker_position(),'Position'); lay.addWidget(inner); return page

    def _build_workspace(self):
        page = QWidget(); layout = QHBoxLayout(page); layout.setContentsMargins(0, 6, 0, 0)
        self.main_split = QSplitter(Qt.Horizontal)
        main_split = self.main_split

        left = QWidget()
        left.setMinimumWidth(90)
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabel("Explorer")
        self.tree.setSelectionMode(QTreeWidget.ExtendedSelection)
        self.tree.setDragEnabled(True)
        self.tree.setAcceptDrops(False)
        self.tree.setDragDropMode(QTreeWidget.DragOnly)
        self.tree.setDefaultDropAction(Qt.CopyAction)
        self.tree.setMinimumWidth(180)
        self.tree.setTextElideMode(Qt.ElideRight)
        self.tree.setUniformRowHeights(True)
        self.tree.setIndentation(12)
        self.tree.setAnimated(False)
        self.tree.setMouseTracking(False)
        self.tree.setStyleSheet("""
            QTreeWidget::item:selected {
                background: rgba(55, 165, 255, 110);
                color: white;
            }
            QTreeWidget::item:selected:active {
                background: rgba(55, 165, 255, 145);
            }
        """)
        self.tree.itemClicked.connect(self._tree_clicked)
        self.tree.startDrag = self._start_tree_file_drag
        self.tree.itemSelectionChanged.connect(self._tree_selection_changed)
        self.tree.currentItemChanged.connect(self._tree_current_changed)
        self.left_content_splitter = QSplitter(Qt.Vertical)
        self.left_content_splitter.setChildrenCollapsible(False)
        self.explorer_container = QWidget()
        explorer_container_layout = QVBoxLayout(self.explorer_container)
        explorer_container_layout.setContentsMargins(0, 0, 0, 0)
        explorer_container_layout.setSpacing(4)

        explorer_filter = QWidget()
        explorer_filter_layout = QGridLayout(explorer_filter)
        explorer_filter_layout.setContentsMargins(0, 0, 0, 2)
        explorer_filter_layout.setHorizontalSpacing(5)
        explorer_filter_layout.setVerticalSpacing(3)

        self.series_filter_combo = QComboBox()
        self.series_filter_combo.addItem("All Series")
        self.series_filter_combo.currentTextChanged.connect(
            self._apply_explorer_filters
        )

        self.explorer_search_edit = QLineEdit()
        self.explorer_search_edit.setPlaceholderText(
            "Search file / series / protocol / instance"
        )
        self.explorer_search_edit.setClearButtonEnabled(True)
        self.explorer_search_edit.textChanged.connect(
            self._apply_explorer_filters
        )

        self.explorer_type_combo = QComboBox()
        self.explorer_type_combo.addItems(
            ["All", "DICOM", "RAW", "Bitmap", "Tracking"]
        )
        self.explorer_type_combo.currentTextChanged.connect(
            self._apply_explorer_filters
        )

        self.explorer_sort_combo = QComboBox()
        self.explorer_sort_combo.addItems(
            ["Series / Instance", "Series / Filename"]
        )
        self.explorer_sort_combo.currentTextChanged.connect(
            self._rebuild_explorer_preserving_state
        )

        clear_filter_button = QPushButton("Clear Filter")
        clear_filter_button.clicked.connect(
            self._clear_explorer_filters
        )

        explorer_filter_layout.addWidget(QLabel("Series"), 0, 0)
        explorer_filter_layout.addWidget(self.series_filter_combo, 0, 1)
        explorer_filter_layout.addWidget(QLabel("Search"), 1, 0)
        explorer_filter_layout.addWidget(self.explorer_search_edit, 1, 1)
        explorer_filter_layout.addWidget(QLabel("Type"), 2, 0)
        explorer_filter_layout.addWidget(self.explorer_type_combo, 2, 1)
        explorer_filter_layout.addWidget(QLabel("Sort"), 3, 0)
        explorer_filter_layout.addWidget(self.explorer_sort_combo, 3, 1)
        explorer_filter_layout.addWidget(clear_filter_button, 4, 0, 1, 2)

        explorer_container_layout.addWidget(explorer_filter)
        explorer_container_layout.addWidget(self.tree, 1)
        self.left_content_splitter.addWidget(self.explorer_container)

        self.annotation_panel = QGroupBox("Annotation")
        annotation_layout = QVBoxLayout(self.annotation_panel)
        annotation_layout.setContentsMargins(6, 6, 6, 6)
        annotation_controls = QHBoxLayout()
        self.annotation_toggle = QCheckBox("Show")
        self.annotation_toggle.toggled.connect(self._annotation_visibility_changed)
        self.annotation_mode_combo = QComboBox()
        self.annotation_mode_combo.addItems(["Minimum", "Full"])
        self.annotation_mode_combo.currentTextChanged.connect(self._annotation_mode_changed)
        annotation_controls.addWidget(self.annotation_toggle)
        annotation_controls.addWidget(self.annotation_mode_combo)
        annotation_layout.addLayout(annotation_controls)

        self.annotation_text = QLabel("No annotation")
        self.annotation_text.setWordWrap(True)
        self.annotation_text.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.annotation_text.setObjectName("InfoCard")
        annotation_layout.addWidget(self.annotation_text, 1)
        self.annotation_panel.hide()
        self.left_content_splitter.addWidget(self.annotation_panel)
        self.left_content_splitter.setSizes([500, 0])

        self.message_panel = QGroupBox("Message / File Info")
        message_layout = QVBoxLayout(self.message_panel)
        message_layout.setContentsMargins(4, 4, 4, 4)

        self.info = QLabel("No file loaded")
        self.info.setWordWrap(True)
        self.info.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.info.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.info.setObjectName("InfoCard")

        self.info_scroll = QScrollArea()
        self.info_scroll.setWidgetResizable(True)
        self.info_scroll.setFrameShape(QFrame.NoFrame)
        self.info_scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarAsNeeded
        )
        self.info_scroll.setVerticalScrollBarPolicy(
            Qt.ScrollBarAsNeeded
        )
        self.info_scroll.setWidget(self.info)
        message_layout.addWidget(self.info_scroll)

        self.left_content_splitter.addWidget(self.message_panel)
        self.left_content_splitter.setCollapsible(0, False)
        self.left_content_splitter.setCollapsible(1, True)
        self.left_content_splitter.setCollapsible(2, False)
        self.left_content_splitter.setSizes([500, 0, 130])
        self.left_content_splitter.splitterMoved.connect(
            lambda _pos, _idx: self._remember_left_splitter_sizes()
        )

        ll.addWidget(self.left_content_splitter, 1)
        main_split.addWidget(left)

        center = QWidget(); cl = QVBoxLayout(center); cl.setContentsMargins(0, 0, 0, 0)
        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel("Display"))
        self.workspace_source_combo = QComboBox()
        self.workspace_source_combo.addItems(["Current Image"])
        self.workspace_source_combo.hide()
        self.btn_fft = QPushButton("FFT")
        self.btn_original = QPushButton("Original")
        self.btn_both = QPushButton("Both")
        for b, mode in [(self.btn_fft, "FFT"), (self.btn_original, "Original"), (self.btn_both, "Both")]:
            b.setCheckable(True); b.clicked.connect(lambda checked=False, m=mode: self.set_view_mode(m)); mode_row.addWidget(b)
        mode_row.addStretch(1)
        self.slice_label = QLabel("Slice: -")
        self.prev_btn = QPushButton("Previous"); self.next_btn = QPushButton("Next")
        self.prev_btn.clicked.connect(lambda: self.change_slice(-1)); self.next_btn.clicked.connect(lambda: self.change_slice(1))
        mode_row.addWidget(self.prev_btn)
        mode_row.addWidget(self.next_btn)
        mode_row.addWidget(self.slice_label)
        mode_row.addStretch(1)

        self.clear_selected_images_button = QPushButton("Clear Selected")
        self.clear_all_images_button = QPushButton("Clear All Images")
        self.clear_selected_images_button.clicked.connect(
            self.clear_selected_images
        )
        self.clear_all_images_button.clicked.connect(
            self.clear_all_images
        )

        self.previous_import_button = QPushButton("Previous Import")
        self.previous_import_button.setEnabled(False)
        self.previous_import_button.setToolTip(
            "Restore the image list that existed before the latest import."
        )
        self.previous_import_button.clicked.connect(
            self.restore_previous_import
        )

        self.header_popup_button = QPushButton("DICOM Header")
        self.header_popup_button.clicked.connect(
            self.show_dicom_header_popup
        )

        self.image_orientation_button = QPushButton("Orientation")
        self.image_orientation_button.setToolTip(
            "Display DICOM orientation by default or manually edit "
            "R/L/A/P/H/F."
        )
        self.image_orientation_button.clicked.connect(
            self.edit_image_orientation
        )

        self.quick_spike_button = QPushButton("Quick Spike Detect")
        self.quick_spike_button.clicked.connect(
            self.quick_spike_detect_prototype
        )

        self.mode_toolbar_widget = QWidget()
        self.mode_toolbar_widget.setLayout(mode_row)
        self.mode_toolbar_widget.setSizePolicy(
            QSizePolicy.Expanding,
            QSizePolicy.Fixed,
        )
        cl.addWidget(self.mode_toolbar_widget)

        self.vertical_splitter = QSplitter(Qt.Vertical)
        image_container = QWidget(); il = QVBoxLayout(image_container); il.setContentsMargins(0, 0, 0, 0)
        self.image_splitter = QSplitter(Qt.Horizontal)
        self.primary_panel = ImagePanel("FFT (k-space)")
        self.secondary_panel = ImagePanel("Original")
        self.primary_panel.lineChanged.connect(self._line_moved)
        self.secondary_panel.lineChanged.connect(self._line_moved)
        self.primary_panel.pageRequested.connect(self.change_slice)
        self.secondary_panel.pageRequested.connect(self.change_slice)
        self.primary_panel.mouseActionChanged.connect(self._image_mouse_action_changed)
        self.secondary_panel.mouseActionChanged.connect(self._image_mouse_action_changed)
        self.primary_panel.viewRequested.connect(self._image_view_requested)
        self.secondary_panel.viewRequested.connect(self._image_view_requested)
        self.primary_panel.levelWheel.connect(
            lambda step, width: self._image_level_wheel(self.primary_panel, step, width)
        )
        self.secondary_panel.levelWheel.connect(
            lambda step, width: self._image_level_wheel(self.secondary_panel, step, width)
        )
        self.image_splitter.addWidget(self.primary_panel)
        self.image_splitter.addWidget(self.secondary_panel)
        self.image_splitter.setChildrenCollapsible(False)
        self.image_splitter.splitterMoved.connect(
            lambda _pos, _idx: self._remember_splitter_sizes()
        )
        il.addWidget(self.image_splitter, 1)

        line_bar = QHBoxLayout()
        line_bar.addWidget(QLabel("Line"))
        self.orientation_combo = QComboBox(); self.orientation_combo.addItems(["Row", "Column"])
        self.orientation_combo.currentTextChanged.connect(self._orientation_changed)
        line_bar.addWidget(self.orientation_combo)
        self.line_spin = QSpinBox(); self.line_spin.valueChanged.connect(self._spin_line_changed)
        line_bar.addWidget(self.line_spin)
        self.line_slider = QSlider(Qt.Horizontal); self.line_slider.valueChanged.connect(self._slider_line_changed)
        line_bar.addWidget(self.line_slider, 1)
        self.line_value_label = QLabel("-")
        line_bar.addWidget(self.line_value_label)
        il.addLayout(line_bar)
        self.vertical_splitter.addWidget(image_container)

        lower = QWidget(); low = QHBoxLayout(lower); low.setContentsMargins(0, 0, 0, 0)
        self.profile_plot = pg.PlotWidget(title="Selected Line Profile")
        self.profile_plot.showGrid(x=True, y=True, alpha=.2)
        self.profile_plot.setLabel("bottom", "Sample")
        low.addWidget(self.profile_plot, 2)
        self.tracker_plot = pg.PlotWidget(title="Tracker / Active 1D Signal")
        self.tracker_plot.showGrid(x=True, y=True, alpha=.2)
        low.addWidget(self.tracker_plot, 1)
        self.vertical_splitter.addWidget(lower)
        self.vertical_splitter.setCollapsible(0, False)
        self.vertical_splitter.setCollapsible(1, True)
        self.vertical_splitter.setSizes([620, 220])
        self.vertical_splitter.splitterMoved.connect(
            lambda _pos, _idx: self._remember_splitter_sizes()
        )
        cl.addWidget(self.vertical_splitter, 1)
        main_split.addWidget(center)

        right = QWidget()
        right.setMinimumWidth(250)
        right.setMaximumWidth(520)
        rl = QVBoxLayout(right)
        rl.setContentsMargins(4, 0, 4, 0)
        rl.setSpacing(6)
        right.setStyleSheet("""
            QComboBox, QDoubleSpinBox, QSpinBox, QPushButton {
                min-height: 28px;
            }
            QGroupBox {
                margin-top: 8px;
            }
        """)
        profile_group = QGroupBox("Profile")
        form = QFormLayout(profile_group)
        self.profile_mode = QComboBox(); self.profile_mode.addItems(["Magnitude", "Real", "Imaginary", "Phase"])
        self.profile_mode.currentTextChanged.connect(self.on_display_type_changed)
        form.addRow("Type", self.profile_mode)
        self.raw_display_combo = QComboBox()
        self.raw_display_combo.addItems(
            ["Auto", "Reconstructed Image", "Direct Array", "k-space Magnitude"]
        )
        self.raw_display_combo.setToolTip(
            "RAW Auto compares direct-array and reconstructed-image views."
        )
        self.raw_display_combo.currentTextChanged.connect(
            self._change_raw_display_mode
        )
        self.raw_display_combo.setEnabled(False)
        form.addRow("RAW Display", self.raw_display_combo)
        self.log_profile = QCheckBox("Log scale"); self.log_profile.toggled.connect(self.update_line_profile)
        form.addRow(self.log_profile)
        rl.addWidget(profile_group)
        self.btn_send_signal = QPushButton("Send selected line to 1D Studio")
        self.btn_send_signal.clicked.connect(self.send_line_to_signal_studio)
        rl.addWidget(self.btn_send_signal)
        self.btn_auto = QPushButton("Auto Levels"); self.btn_auto.clicked.connect(self.auto_levels)
        rl.addWidget(self.btn_auto)
        spike_content=QFrame(); spike_layout=QFormLayout(spike_content)
        self.spike_range_combo=QComboBox(); self.spike_range_combo.addItems(["Large","Mid","Small","Scale"]); self.spike_range_combo.currentTextChanged.connect(self._spike_range_changed); spike_layout.addRow("Range",self.spike_range_combo)
        self.spike_scale_slider=QSlider(Qt.Horizontal); self.spike_scale_slider.setRange(10,100); self.spike_scale_slider.setValue(70); self.spike_scale_slider.setVisible(False); self.spike_scale_label=QLabel("70%"); self.spike_scale_label.setVisible(False); self.spike_scale_slider.valueChanged.connect(lambda v:self.spike_scale_label.setText(f"{v}%")); sr=QHBoxLayout(); sr.addWidget(self.spike_scale_slider,1); sr.addWidget(self.spike_scale_label); spike_layout.addRow("Scale",sr)
        self.spike_level_combo=QComboBox(); self.spike_level_combo.addItems(["Wide","Mid","Fine"]); spike_layout.addRow("Level",self.spike_level_combo)
        self.btn_spike=QPushButton("Apply Spike Processing"); self.btn_spike.clicked.connect(self.apply_spike_processing); self.btn_spike.setStyleSheet("QPushButton{background:#7a2430;font-weight:700;min-height:30px} QPushButton:hover{background:#a23242}"); spike_layout.addRow(self.btn_spike)

        display_group = QGroupBox("Dynamic Range / Window Level")
        display_form = QFormLayout(display_group)
        self.level_target_combo = QComboBox()
        self.level_target_combo.addItems(["Original Image", "Raw Data"])
        self.level_target_combo.currentTextChanged.connect(self._level_target_changed)
        display_form.addRow("Adjust", self.level_target_combo)

        self.level_preset_combo = QComboBox()
        self.level_preset_combo.addItems(["Auto", "Manual", "Wide", "Soft Tissue", "High Contrast", "Narrow"])
        self.level_preset_combo.currentTextChanged.connect(self.apply_level_preset)
        display_form.addRow("Preset", self.level_preset_combo)

        self.window_level_spin = QDoubleSpinBox()
        self.window_level_spin.setRange(-1e12, 1e12)
        self.window_level_spin.setDecimals(3)
        self.window_level_spin.valueChanged.connect(self._manual_levels_changed)
        display_form.addRow("Window level", self.window_level_spin)

        self.dynamic_range_spin = QDoubleSpinBox()
        self.dynamic_range_spin.setRange(1e-9, 1e12)
        self.dynamic_range_spin.setDecimals(3)
        self.dynamic_range_spin.valueChanged.connect(self._manual_levels_changed)
        display_form.addRow("Dynamic range", self.dynamic_range_spin)
        rl.addWidget(display_group)

        addsub_group = QGroupBox("Image Add / Subtract")
        addsub_layout = QVBoxLayout(addsub_group)
        addsub_row1 = QHBoxLayout()
        self.set_a_button = QPushButton("Set Current as A")
        self.set_b_button = QPushButton("Set Current as B")
        self.set_a_button.clicked.connect(lambda: self.set_addsub_source("A"))
        self.set_b_button.clicked.connect(lambda: self.set_addsub_source("B"))
        addsub_row1.addWidget(self.set_a_button)
        addsub_row1.addWidget(self.set_b_button)
        addsub_layout.addLayout(addsub_row1)
        self.addsub_status = QLabel("A: -\nB: -")
        self.addsub_status.setWordWrap(True)
        addsub_layout.addWidget(self.addsub_status)
        addsub_row2 = QHBoxLayout()
        self.add_button = QPushButton("Preview A + B")
        self.subtract_button = QPushButton("Preview A - B")
        self.add_button.clicked.connect(lambda: self.preview_addsub("add"))
        self.subtract_button.clicked.connect(lambda: self.preview_addsub("subtract"))
        addsub_row2.addWidget(self.add_button)
        addsub_row2.addWidget(self.subtract_button)
        addsub_layout.addLayout(addsub_row2)
        self.save_addsub_button = QPushButton("Save Preview Result")
        self.save_addsub_button.clicked.connect(self.save_addsub_preview)
        self.save_addsub_button.setEnabled(False)
        addsub_layout.addWidget(self.save_addsub_button)
        addsub_clear_row = QHBoxLayout()
        for label, callback in [
            ("Clear A", lambda: self.clear_addsub_slot("A")),
            ("Clear B", lambda: self.clear_addsub_slot("B")),
            ("Clear Result", self.clear_addsub_result),
        ]:
            button = QPushButton(label); button.clicked.connect(callback); addsub_clear_row.addWidget(button)
        addsub_layout.addLayout(addsub_clear_row)

        comp_group = QGroupBox("Raw Data Compensation")
        comp_layout = QVBoxLayout(comp_group)
        self.select_comp_button = QPushButton("Select Compensation ROI on Raw Data")
        self.preview_comp_button = QPushButton("Preview Reconstructed Image")
        self.apply_comp_button = QPushButton("Commit Compensation")
        self.save_comp_button = QPushButton("Save Displayed Compensation")
        self.cancel_comp_button = QPushButton("Cancel Current ROI")
        self.select_comp_button.clicked.connect(self.start_compensation_roi)
        self.preview_comp_button.clicked.connect(self.preview_compensation)
        self.apply_comp_button.clicked.connect(self.apply_compensation)
        self.save_comp_button.clicked.connect(self.save_compensation_history_state)
        self.cancel_comp_button.clicked.connect(self.clear_compensation_roi)
        comp_layout.addWidget(self.select_comp_button)

        level_row = QHBoxLayout()
        level_row.addWidget(QLabel("Level"))
        self.comp_level_combo = QComboBox()
        self.comp_level_combo.addItems(["Low", "Mid", "High"])
        self.comp_level_combo.setCurrentText("Mid")
        level_row.addWidget(self.comp_level_combo)
        comp_layout.addLayout(level_row)

        self.comp_status_label = QLabel("No RAW ROI selected")
        self.comp_status_label.setWordWrap(True)
        comp_layout.addWidget(self.comp_status_label)

        comp_preview_row = QHBoxLayout()
        comp_preview_row.addWidget(self.preview_comp_button)
        comp_preview_row.addWidget(self.apply_comp_button)
        comp_layout.addLayout(comp_preview_row)

        history_row = QHBoxLayout()
        self.comp_prev_button = QPushButton("Previous")
        self.comp_next_button = QPushButton("Next")
        self.comp_prev_button.clicked.connect(lambda: self.navigate_compensation_history(-1))
        self.comp_next_button.clicked.connect(lambda: self.navigate_compensation_history(1))
        history_row.addWidget(self.comp_prev_button)
        history_row.addWidget(self.comp_next_button)
        comp_layout.addLayout(history_row)
        comp_layout.addWidget(self.save_comp_button)
        self.clear_comp_history_button = QPushButton("Clear Compensation History")
        self.clear_comp_history_button.clicked.connect(self.clear_compensation_history)
        comp_layout.addWidget(self.clear_comp_history_button)
        comp_layout.addWidget(self.cancel_comp_button)

        self.preview_comp_button.setEnabled(False)
        self.apply_comp_button.setEnabled(False)
        self.save_comp_button.setEnabled(False)
        self.comp_prev_button.setEnabled(False)
        self.comp_next_button.setEnabled(False)

        self.accordion_sections=[]
        self.spike_accordion=AccordionSection("Spike",spike_content,True); self.comp_accordion=AccordionSection("Raw Data Compensation",comp_group,False); self.addsub_accordion=AccordionSection("Image Add/Sub",addsub_group,False)
        self.accordion_sections=[self.spike_accordion,self.comp_accordion,self.addsub_accordion]
        for section in self.accordion_sections: section.opened.connect(self._accordion_opened); rl.addWidget(section)
        rl.addStretch(1)

        output_group = QGroupBox("Output Folder")
        output_layout = QVBoxLayout(output_group)
        self.output_root_label = QLabel("Output: follows opened image folder")
        self.output_root_label.setWordWrap(True)
        output_layout.addWidget(self.output_root_label)
        self.output_root_button = QPushButton("Change Output Folder")
        self.output_root_button.clicked.connect(self.change_output_root)
        output_layout.addWidget(self.output_root_button)
        rl.addWidget(output_group)

        right_scroll = QScrollArea()
        right_scroll.setWidgetResizable(True)
        right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        right_scroll.setFrameShape(QFrame.NoFrame)
        right_scroll.setMinimumWidth(250)
        right_scroll.setWidget(right)
        main_split.addWidget(right_scroll)
        main_split.setCollapsible(0, True)
        main_split.setCollapsible(1, False)
        main_split.setCollapsible(2, True)
        main_split.setSizes([210, 760, 300])
        main_split.splitterMoved.connect(
            lambda _pos, _idx: self._remember_splitter_sizes()
        )
        layout.addWidget(main_split)
        self.set_view_mode("Both")
        return page

    def _build_signal_studio(self):
        page = QWidget(); layout = QVBoxLayout(page)
        top = QHBoxLayout()
        self.back_to_workspace = QPushButton("← Back to Image Workspace")
        self.back_to_workspace.clicked.connect(lambda: self.tabs.setCurrentIndex(0))
        top.addWidget(self.back_to_workspace)
        self.signal_combo = QComboBox(); self.signal_combo.currentIndexChanged.connect(self.update_signal_plot)
        self.signal_component = QComboBox(); self.signal_component.addItems(["Magnitude", "Real", "Imaginary", "Phase"])
        self.signal_component.currentTextChanged.connect(self.update_signal_plot)
        self.signal_fft = QCheckBox("Frequency display (FFT)"); self.signal_fft.setChecked(False); self.signal_fft.toggled.connect(self.update_signal_plot)
        remove_signal = QPushButton("Remove Selected"); remove_signal.clicked.connect(self.remove_selected_signal)
        clear = QPushButton("Clear All Signals"); clear.clicked.connect(self.clear_signals)
        top.addWidget(QLabel("Signal")); top.addWidget(self.signal_combo, 1); top.addWidget(self.signal_component); top.addWidget(self.signal_fft); top.addWidget(remove_signal); top.addWidget(clear)
        layout.addLayout(top)
        self.signal_plot = pg.PlotWidget(); self.signal_plot.showGrid(x=True, y=True, alpha=.2)
        layout.addWidget(self.signal_plot, 1)
        note = QLabel("Tracker PFile/TrackerImg drops are automatically registered here as complex 1D raw signals.")
        note.setWordWrap(True); layout.addWidget(note)
        return page

    def _build_metadata(self):
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout()
        self.header_filter = QComboBox(); self.header_filter.setEditable(True); self.header_filter.setInsertPolicy(QComboBox.NoInsert)
        self.header_filter.lineEdit().setPlaceholderText("Filter header tags...")
        self.header_filter.lineEdit().textChanged.connect(self.filter_header)
        export = QPushButton("Export Current Header to Excel"); export.clicked.connect(self.export_header_excel)
        row.addWidget(self.header_filter, 1); row.addWidget(export)
        layout.addLayout(row)
        self.header_table = QTableWidget(0, 6)
        self.header_table.setHorizontalHeaderLabels(["Tag", "Keyword", "Name", "VR", "VM", "Value"])
        self.header_table.horizontalHeader().setStretchLastSection(True)
        self.header_table.setSortingEnabled(True)
        layout.addWidget(self.header_table)
        return page

    def _build_tracker_explorer(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        controls = QHBoxLayout()
        self.tracker_prev_file_button = QPushButton("◀ Previous File")
        self.tracker_next_file_button = QPushButton("Next File ▶")
        self.tracker_prev_file_button.clicked.connect(lambda: self.navigate_tracker_file(-1))
        self.tracker_next_file_button.clicked.connect(lambda: self.navigate_tracker_file(1))
        controls.addWidget(self.tracker_prev_file_button)
        self.tracker_file_combo = QComboBox()
        self.tracker_file_combo.currentIndexChanged.connect(self.select_tracker_file_index)
        controls.addWidget(self.tracker_file_combo)
        controls.addWidget(self.tracker_next_file_button)
        self.tracker_clear_current_button = QPushButton("Clear Current Tracker")
        self.tracker_clear_all_button = QPushButton("Clear All Trackers")
        self.tracker_clear_current_button.clicked.connect(self.clear_current_tracker)
        self.tracker_clear_all_button.clicked.connect(self.clear_all_trackers)
        controls.addWidget(self.tracker_clear_current_button)
        controls.addWidget(self.tracker_clear_all_button)
        self.tracker_drop_text = QLabel(
            "Drop a Tracker PFile / TrackerImg anywhere in the window. "
            "This tab reads and ranks raw lines directly without FFT."
        )
        self.tracker_drop_text.setWordWrap(True)
        controls.addWidget(self.tracker_drop_text, 1)

        controls.addWidget(QLabel("Top lines"))
        self.tracker_top_count = QSpinBox()
        self.tracker_top_count.setRange(1, 100)
        self.tracker_top_count.setValue(1)
        self.tracker_top_count.valueChanged.connect(self._refresh_tracker_ranking)
        controls.addWidget(self.tracker_top_count)

        controls.addWidget(QLabel("Rank by"))
        self.tracker_metric_combo = QComboBox()
        self.tracker_metric_combo.addItems(["Peak", "RMS", "Energy", "Mean magnitude", "Variance"])
        self.tracker_metric_combo.currentTextChanged.connect(self._refresh_tracker_ranking)
        controls.addWidget(self.tracker_metric_combo)

        self.tracker_export_button = QPushButton("Export CSV")
        self.tracker_export_button.clicked.connect(self.export_tracker_lines_csv)
        controls.addWidget(self.tracker_export_button)
        self.tracker_to_workspace_button = QPushButton("Show in Image Workspace")
        self.tracker_to_workspace_button.clicked.connect(self.show_tracker_in_workspace)
        controls.addWidget(self.tracker_to_workspace_button)
        self.tracker_to_1d_button = QPushButton("Show Strongest Line in 1D Studio")
        self.tracker_to_1d_button.clicked.connect(self.send_tracker_to_signal_studio)
        controls.addWidget(self.tracker_to_1d_button)
        layout.addLayout(controls)

        self.tracker_summary = QLabel("No Tracker file loaded.")
        self.tracker_summary.setWordWrap(True)
        layout.addWidget(self.tracker_summary)

        splitter = QSplitter(Qt.Horizontal)

        ranking_box = QGroupBox("Strongest Tracker Line")
        ranking_layout = QVBoxLayout(ranking_box)
        self.tracker_table = QTableWidget(0, 8)
        self.tracker_table.setHorizontalHeaderLabels(
            ["Rank", "Line", "Peak", "RMS", "Energy", "Mean", "Variance", "Relative strength"]
        )
        self.tracker_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.tracker_table.setSelectionMode(QTableWidget.ExtendedSelection)
        self.tracker_table.itemSelectionChanged.connect(self._tracker_selection_changed)
        self.tracker_table.horizontalHeader().setStretchLastSection(True)
        ranking_layout.addWidget(self.tracker_table)

        viewer_box = QGroupBox("Strongest Tracker Raw Line Magnitude — FFT Disabled")
        viewer_layout = QVBoxLayout(viewer_box)
        self.tracker_raw_plot = pg.PlotWidget()
        self.tracker_raw_plot.showGrid(x=True, y=True, alpha=0.25)
        self.tracker_raw_plot.setLabel("bottom", "Sample")
        self.tracker_raw_plot.setLabel("left", "Signal")
        viewer_layout.addWidget(self.tracker_raw_plot, 1)

        viewer_controls = QHBoxLayout()
        viewer_controls.addWidget(QLabel("Component"))
        self.tracker_component_combo = QComboBox()
        self.tracker_component_combo.addItems(["Magnitude", "Real", "Imaginary", "Phase"])
        self.tracker_component_combo.currentTextChanged.connect(self._plot_tracker_selected_lines)
        viewer_controls.addWidget(self.tracker_component_combo)

        self.tracker_previous_button = QPushButton("Previous Strong Line")
        self.tracker_previous_button.clicked.connect(self._select_previous_tracker_line)
        viewer_controls.addWidget(self.tracker_previous_button)

        self.tracker_next_button = QPushButton("Next Strong Line")
        self.tracker_next_button.clicked.connect(self._select_next_tracker_line)
        viewer_controls.addWidget(self.tracker_next_button)
        viewer_controls.addStretch(1)
        viewer_layout.addLayout(viewer_controls)

        self.tracker_metrics_label = QLabel("-")
        self.tracker_metrics_label.setWordWrap(True)
        viewer_layout.addWidget(self.tracker_metrics_label)

        splitter.addWidget(ranking_box)
        splitter.addWidget(viewer_box)
        splitter.setSizes([520, 900])
        layout.addWidget(splitter, 1)

        explanation = QLabel(
            "Tracker Signal Explorer and Spike Detection are separate. "
            "This tab automatically picks high-signal raw lines and displays their original samples without FFT."
        )
        explanation.setWordWrap(True)
        layout.addWidget(explanation)
        return page

    def _build_tracker_position(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        top = QHBoxLayout()
        top.addWidget(QLabel("FFT length"))
        self.position_fft_length = QSpinBox()
        self.position_fft_length.setRange(64, 65536)
        self.position_fft_length.setSingleStep(64)
        self.position_fft_length.setValue(1024)
        top.addWidget(self.position_fft_length)

        top.addWidget(QLabel("FOV (mm)"))
        self.position_fov = QDoubleSpinBox()
        self.position_fov.setRange(1.0, 5000.0)
        self.position_fov.setDecimals(3)
        self.position_fov.setValue(500.0)
        top.addWidget(self.position_fov)

        self.position_use_top = QPushButton("Use Top 3 Tracker Lines")
        self.position_use_top.clicked.connect(self.populate_position_top_lines)
        top.addWidget(self.position_use_top)

        self.position_calculate = QPushButton("Calculate Position")
        self.position_calculate.clicked.connect(self.calculate_tracker_position)
        top.addWidget(self.position_calculate)
        top.addStretch(1)
        layout.addLayout(top)

        offset_group = QGroupBox("Center Offset and Coordinate Convention")
        offset_form = QFormLayout(offset_group)
        offset_row = QHBoxLayout()
        self.position_offset_x = QDoubleSpinBox()
        self.position_offset_y = QDoubleSpinBox()
        self.position_offset_z = QDoubleSpinBox()
        for spin in (self.position_offset_x, self.position_offset_y, self.position_offset_z):
            spin.setRange(-5000.0, 5000.0)
            spin.setDecimals(4)
            spin.setValue(0.0)
        offset_row.addWidget(QLabel("X"))
        offset_row.addWidget(self.position_offset_x)
        offset_row.addWidget(QLabel("Y"))
        offset_row.addWidget(self.position_offset_y)
        offset_row.addWidget(QLabel("Z"))
        offset_row.addWidget(self.position_offset_z)
        offset_form.addRow("CenterOffset (mm)", offset_row)

        self.position_oppose_ap = QCheckBox("Oppose AP coordinate")
        self.position_oppose_ap.setChecked(True)
        offset_form.addRow(self.position_oppose_ap)
        layout.addWidget(offset_group)

        self.position_table = QTableWidget(3, 7)
        self.position_table.setHorizontalHeaderLabels([
            "Line", "Plane", "Rotation (deg)", "Peak bin",
            "Coordinate (mm)", "Peak/Background", "Use"
        ])
        plane_names = ["Axial", "Coronal", "Sagittal"]
        for row in range(3):
            self.position_table.setItem(row, 0, QTableWidgetItem(str(row)))
            plane_combo = QComboBox()
            plane_combo.addItems(plane_names)
            plane_combo.setCurrentIndex(row)
            self.position_table.setCellWidget(row, 1, plane_combo)

            rotation = QDoubleSpinBox()
            rotation.setRange(-360.0, 360.0)
            rotation.setDecimals(4)
            rotation.setValue(0.0)
            self.position_table.setCellWidget(row, 2, rotation)

            self.position_table.setItem(row, 3, QTableWidgetItem("-"))
            self.position_table.setItem(row, 4, QTableWidgetItem("-"))
            self.position_table.setItem(row, 5, QTableWidgetItem("-"))

            use_box = QCheckBox()
            use_box.setChecked(True)
            self.position_table.setCellWidget(row, 6, use_box)

        self.position_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.position_table)

        result_group = QGroupBox("Converted Tracker Position")
        result_layout = QVBoxLayout(result_group)
        self.position_result = QLabel(
            "Load a Tracker file, choose three directional lines, set Plane / Rotation / CenterOffset, "
            "then calculate the position."
        )
        self.position_result.setWordWrap(True)
        self.position_result.setTextInteractionFlags(Qt.TextSelectableByMouse)
        result_layout.addWidget(self.position_result)
        layout.addWidget(result_group)

        note = QLabel(
            "The basic conversion matches the attached TrackerApp structure: FFT peak bin → FOV coordinate → "
            "multi-direction geometric solve → CenterOffset → optional AP sign inversion. "
            "Gradient-map non-linearity correction is not applied unless a vendor gradient adapter is added."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        layout.addStretch(1)
        return page

    def _build_spike_results(self):
        page = QWidget()
        root = QHBoxLayout(page)
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.addWidget(QLabel("Processed Images"))
        self.spike_result_list = QTreeWidget()
        self.spike_result_list.setHeaderHidden(True)
        self.spike_result_list.itemClicked.connect(self._spike_result_selected)
        left_layout.addWidget(self.spike_result_list, 1)
        self.spike_result_summary = QLabel("Processed: 0 | Corrected: 0")
        self.spike_result_summary.setWordWrap(True)
        left_layout.addWidget(self.spike_result_summary)
        self.developer_mode_check = QCheckBox("Developer Mode")
        self.developer_mode_check.setToolTip("Show stripe groups, raw candidate mapping, confidence and exclusion reasons.")
        self.developer_mode_check.toggled.connect(self._toggle_developer_mode)
        left_layout.addWidget(self.developer_mode_check)
        self.spike_developer_text = QTextEdit()
        self.spike_developer_text.setReadOnly(True)
        self.spike_developer_text.setMaximumHeight(180)
        self.spike_developer_text.hide()
        left_layout.addWidget(self.spike_developer_text)
        self.save_spike_result_button = QPushButton("Save Corrected Image")
        self.save_spike_result_button.clicked.connect(self.save_current_spike_result)
        left_layout.addWidget(self.save_spike_result_button)

        grid = QWidget()
        grid_layout = QGridLayout(grid)
        self.spike_original_panel = ImagePanel("Original Image")
        self.spike_stripe_panel = ImagePanel("Stripe Only")
        self.spike_raw_candidate_panel = ImagePanel("Mapped Raw Candidate")
        self.spike_corrected_panel = ImagePanel("Corrected Image")
        self.spike_raw_before_panel = ImagePanel("Actual Raw / k-space")
        self.spike_raw_after_panel = ImagePanel("Processed Raw")
        grid_layout.addWidget(self.spike_original_panel, 0, 0)
        grid_layout.addWidget(self.spike_stripe_panel, 0, 1)
        grid_layout.addWidget(self.spike_corrected_panel, 0, 2)
        grid_layout.addWidget(self.spike_raw_candidate_panel, 1, 0)
        grid_layout.addWidget(self.spike_raw_before_panel, 1, 1)
        grid_layout.addWidget(self.spike_raw_after_panel, 1, 2)

        split = QSplitter(Qt.Horizontal)
        split.addWidget(left)
        split.addWidget(grid)
        split.setCollapsible(0, True)
        split.setSizes([250, 1100])
        root.addWidget(split)
        return page


    def _build_artifact_detection(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        controls = QHBoxLayout()
        self.detect_artifact_button = QPushButton("Detect Artifact on Selected Images")
        self.detect_artifact_button.clicked.connect(self.detect_artifacts_from_db)
        controls.addWidget(self.detect_artifact_button)
        self.detect_tracker_button = QPushButton("Detect Current Tracker File")
        self.detect_tracker_button.clicked.connect(self.detect_tracker_artifact_from_db)
        controls.addWidget(self.detect_tracker_button)

        self.detect_selected_only = QCheckBox("Selected images only")
        self.detect_selected_only.setChecked(True)
        controls.addWidget(self.detect_selected_only)

        controls.addWidget(QLabel("Minimum samples / class"))
        self.detect_min_samples = QSpinBox()
        self.detect_min_samples.setRange(1, 100)
        self.detect_min_samples.setValue(2)
        controls.addWidget(self.detect_min_samples)
        controls.addStretch(1)
        layout.addLayout(controls)

        self.artifact_detection_summary = QLabel(
            "Open an Artifact DB and run detection. Classes without enough labeled samples are not predicted."
        )
        self.artifact_detection_summary.setWordWrap(True)
        layout.addWidget(self.artifact_detection_summary)

        self.artifact_detection_table = QTableWidget(0, 9)
        self.artifact_detection_table.setHorizontalHeaderLabels([
            "File", "Series", "Predicted Artifact", "Confidence",
            "Distance", "Training Support", "Status", "Alternatives", "Source Path"
        ])
        self.artifact_detection_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.artifact_detection_table.setSelectionMode(QTableWidget.ExtendedSelection)
        self.artifact_detection_table.horizontalHeader().setStretchLastSection(True)
        self.artifact_detection_table.cellDoubleClicked.connect(
            self.open_detected_artifact_image
        )
        layout.addWidget(self.artifact_detection_table, 1)

        classify_row = QHBoxLayout()
        self.send_detection_to_learning_button = QPushButton(
            "Send Selected Detection Rows to Artifact Learning"
        )
        self.send_detection_to_learning_button.clicked.connect(
            self.send_detected_rows_to_learning
        )
        classify_row.addWidget(self.send_detection_to_learning_button)
        classify_row.addStretch(1)
        layout.addLayout(classify_row)

        note = QLabel(
            "Spike is no longer a hard-coded threshold classification. "
            "Spike, Frequency, and other Artifact classes are predicted from the labeled Artifact DB. "
            "The separate Spike Diagnostic tab remains available for raw waveform review."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        return page

    def _build_artifact_learning(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        db_row = QHBoxLayout()
        self.artifact_db_label = QLabel("Artifact DB: Not opened")
        db_row.addWidget(self.artifact_db_label, 1)
        for label, callback in [
            ("Open / Create DB", self.open_artifact_database),
            ("Import DB JSON", self.import_artifact_database),
            ("Export DB JSON", self.export_artifact_database),
        ]:
            button = QPushButton(label)
            button.clicked.connect(callback)
            db_row.addWidget(button)
        layout.addLayout(db_row)

        selection = QGroupBox("Training Image Selection")
        selection_layout = QVBoxLayout(selection)
        self.artifact_selection_label = QLabel(
            "Select one or more DICOM images in Explorer, then add them as training images."
        )
        self.artifact_selection_label.setWordWrap(True)
        selection_layout.addWidget(self.artifact_selection_label)
        selection_buttons = QHBoxLayout()
        self.artifact_add_selected_button = QPushButton("Add Selected Images")
        self.artifact_add_selected_button.clicked.connect(self.collect_selected_artifact_images)
        selection_buttons.addWidget(self.artifact_add_selected_button)
        self.artifact_mark_spike_button = QPushButton("Mark Selected: Spike")
        self.artifact_mark_spike_button.clicked.connect(lambda: self._set_learning_class_quick("Spike"))
        selection_buttons.addWidget(self.artifact_mark_spike_button)
        self.artifact_mark_not_spike_button = QPushButton("Mark Selected: Not Spike")
        self.artifact_mark_not_spike_button.clicked.connect(lambda: self._set_learning_class_quick("Not Spike"))
        selection_buttons.addWidget(self.artifact_mark_not_spike_button)
        self.artifact_set_normal_button = QPushButton("Set Current as Normal Reference")
        self.artifact_set_normal_button.clicked.connect(self.set_current_normal_reference)
        selection_buttons.addWidget(self.artifact_set_normal_button)
        self.artifact_load_normal_button = QPushButton("Load Normal Reference")
        self.artifact_load_normal_button.clicked.connect(self.load_normal_reference)
        selection_buttons.addWidget(self.artifact_load_normal_button)
        self.artifact_preview_tracker_button = QPushButton("Preview Tracker Data")
        self.artifact_preview_tracker_button.clicked.connect(self.preview_tracker_in_artifact_learning)
        selection_buttons.addWidget(self.artifact_preview_tracker_button)
        self.artifact_save_tracker_button = QPushButton("Save Tracker Training Sample")
        self.artifact_save_tracker_button.clicked.connect(self.save_tracker_training_sample)
        selection_buttons.addWidget(self.artifact_save_tracker_button)
        selection_buttons.addStretch(1)
        selection_layout.addLayout(selection_buttons)
        preview_row = QHBoxLayout()
        self.artifact_preview_button = QPushButton("Preview Selected Image")
        self.artifact_preview_button.clicked.connect(self.preview_artifact_learning_image)
        preview_row.addWidget(self.artifact_preview_button)
        self.artifact_preview_prev = QPushButton("Previous Selected")
        self.artifact_preview_next = QPushButton("Next Selected")
        self.artifact_preview_prev.clicked.connect(lambda: self.navigate_artifact_preview(-1))
        self.artifact_preview_next.clicked.connect(lambda: self.navigate_artifact_preview(1))
        preview_row.addWidget(self.artifact_preview_prev)
        preview_row.addWidget(self.artifact_preview_next)
        self.artifact_clear_selected_button = QPushButton("Clear Training Selection")
        self.artifact_clear_all_button = QPushButton("Clear Training + Normal")
        self.artifact_clear_selected_button.clicked.connect(self.clear_selected_artifact_training)
        self.artifact_clear_all_button.clicked.connect(self.clear_all_artifact_training)
        preview_row.addWidget(self.artifact_clear_selected_button)
        preview_row.addWidget(self.artifact_clear_all_button)
        preview_row.addStretch(1)
        selection_layout.addLayout(preview_row)
        self.artifact_preview_panel = ImagePanel("Artifact Learning Preview")
        self.artifact_preview_panel.setMinimumHeight(260)
        selection_layout.addWidget(self.artifact_preview_panel)
        self.artifact_preview_position = 0
        self.artifact_normal_label = QLabel("Normal reference: None")
        selection_layout.addWidget(self.artifact_normal_label)
        layout.addWidget(selection)

        classify = QGroupBox("Classification")
        classify_form = QFormLayout(classify)
        type_row = QHBoxLayout()
        self.artifact_type_combo = QComboBox()
        type_row.addWidget(self.artifact_type_combo, 1)
        self.artifact_new_type = QLineEdit()
        self.artifact_new_type.setPlaceholderText("Manual new Artifact type")
        type_row.addWidget(self.artifact_new_type, 1)
        add_type = QPushButton("Add Type")
        add_type.clicked.connect(self.add_artifact_type_manual)
        type_row.addWidget(add_type)
        classify_form.addRow("Artifact", type_row)

        resolution_row = QHBoxLayout()
        self.artifact_resolution_combo = QComboBox()
        resolution_row.addWidget(self.artifact_resolution_combo, 1)
        self.artifact_new_resolution = QLineEdit()
        self.artifact_new_resolution.setPlaceholderText("Manual How to Resolved")
        resolution_row.addWidget(self.artifact_new_resolution, 1)
        add_resolution = QPushButton("Add Resolution")
        add_resolution.clicked.connect(self.add_resolution_manual)
        resolution_row.addWidget(add_resolution)
        classify_form.addRow("How to Resolved", resolution_row)

        self.artifact_notes = QTextEdit()
        self.artifact_notes.setMaximumHeight(90)
        self.artifact_notes.setPlaceholderText("Notes, conditions, service action, reproducibility...")
        classify_form.addRow("Notes", self.artifact_notes)

        save_button = QPushButton("Save Training Samples to Artifact DB")
        save_button.clicked.connect(self.save_artifact_training_samples)
        classify_form.addRow(save_button)
        layout.addWidget(classify)

        self.artifact_training_table = QTableWidget(0, 8)
        self.artifact_training_table.setHorizontalHeaderLabels([
            "ID", "File", "Series", "Instance", "Artifact",
            "How to Resolved", "Normal Compared", "Source Path"
        ])
        self.artifact_training_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.artifact_training_table.setSelectionMode(QTableWidget.ExtendedSelection)
        self.artifact_training_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.artifact_training_table, 1)

        reclassify = QPushButton("Apply Current Classification to Selected DB Rows")
        reclassify.clicked.connect(self.reclassify_selected_db_rows)
        layout.addWidget(reclassify)

        self.artifact_summary = QLabel(
            "Current detector: Spike. Artifact DB supports Frequency and future Artifact detectors."
        )
        self.artifact_summary.setWordWrap(True)
        layout.addWidget(self.artifact_summary)
        return page

    def _build_menu(self):
        file_menu = self.menuBar().addMenu("File")
        import_files = QAction("Import Files...", self)
        import_files.triggered.connect(self.open_import_selection)
        file_menu.addAction(import_files)
        import_folder = QAction("Import Folder...", self)
        import_folder.triggered.connect(self._open_folder_direct)
        file_menu.addAction(import_folder)
        file_menu.addSeparator()
        export_npz = QAction("Export Image/k-space NPZ", self); export_npz.triggered.connect(self.export_npz); file_menu.addAction(export_npz)
        export_header = QAction("Export DICOM Header Excel", self); export_header.triggered.connect(self.export_header_excel); file_menu.addAction(export_header)
        file_menu.addSeparator(); quit_action = QAction("Exit", self); quit_action.triggered.connect(self.close); file_menu.addAction(quit_action)

        diagnostic_menu = self.menuBar().addMenu("Diagnostics")
        open_logs = QAction("Open Log Folder", self)
        open_logs.triggered.connect(self.open_stable_log_folder)
        diagnostic_menu.addAction(open_logs)

        export_logs = QAction("Export Stable Diagnostic ZIP...", self)
        export_logs.triggered.connect(self.export_stable_diagnostic_zip)
        diagnostic_menu.addAction(export_logs)



    def _stable_diagnostic_state(self):
        image_item = None
        try:
            image_item = getattr(
                self.primary_panel.image_item,
                "image",
                None,
            )
        except Exception:
            pass

        return {
            "version": APP_VERSION,
            "current_source": self.current_source,
            "source_kind": self.source_kind,
            "view_mode": self.view_mode,
            "slice_index": self.slice_index,
            "current_image": self.stable_diagnostics.array_summary(
                self.current_image
            ),
            "current_kspace": self.stable_diagnostics.array_summary(
                self.current_kspace
            ),
            "image_item": self.stable_diagnostics.array_summary(
                image_item
            ),
            "primary_visible": self.primary_panel.isVisible(),
            "secondary_visible": self.secondary_panel.isVisible(),
            "window_level": self.original_window_level,
            "dynamic_range": self.original_dynamic_range,
        }

    def open_stable_log_folder(self):
        self.stable_diagnostics.info("OPEN_LOG_FOLDER")
        try:
            os.startfile(str(self.stable_diagnostics.log_dir))
        except Exception:
            self.statusBar().showMessage(
                f"Log folder: {self.stable_diagnostics.log_dir}",
                10000,
            )

    def export_stable_diagnostic_zip(self):
        default_path = (
            self.stable_diagnostics.export_dir
            / "MR_Image_Explorer_Stable_Diagnostic.zip"
        )
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Export Stable Diagnostic ZIP",
            str(default_path),
            "ZIP (*.zip)",
        )
        if not filename:
            return

        output = Path(filename)
        if output.suffix.lower() != ".zip":
            output = output.with_suffix(".zip")

        try:
            self.stable_diagnostics.export_zip(
                output,
                self._stable_diagnostic_state(),
            )
            self.statusBar().showMessage(
                f"Diagnostic ZIP exported: {output}",
                10000,
            )
        except Exception as exc:
            self.stable_diagnostics.exception(
                "DIAGNOSTIC_EXPORT_FAILED",
                exc,
            )
            QMessageBox.warning(
                self,
                "Diagnostic Export",
                f"{type(exc).__name__}: {exc}",
            )

    def _apply_style(self):
        self.setStyleSheet("""
        QMainWindow, QWidget { background: #171a1f; color: #e6e9ee; }
        QMenuBar, QMenu { background: #20242b; }
        QTabWidget::pane { border: 1px solid #303946; }
        QTabBar::tab { background: #20242b; padding: 9px 18px; border: 1px solid #303946; }
        QTabBar::tab:selected { background: #1464cc; color: white; font-weight: 600; }
        QTabBar::tab:hover { background: #2b3440; }
        QPushButton, QComboBox, QSpinBox { background: #252b33; border: 1px solid #3b4654; padding: 6px; border-radius: 3px; }
        QPushButton:checked { background: #1464cc; border-color: #2c8cff; }
        QPushButton:hover { border-color: #6594c5; }
        QTreeWidget, QTableWidget { background: #111419; alternate-background-color: #191e25; border: 1px solid #303946; }
        QGroupBox { border: 1px solid #303946; border-radius: 4px; margin-top: 8px; padding-top: 8px; }
        QGroupBox::title { subcontrol-origin: margin; left: 8px; }
        #DropBanner { border: 1px dashed #5c7189; border-radius: 5px; background: #1d232b; }
        #DropBanner[dragActive="true"] { border: 2px solid #2f8cff; background: #20354f; }
        #InfoCard { border: 1px solid #303946; padding: 8px; background: #111419; }
        QSplitter::handle { background: #2f8cff; }
        QSplitter::handle:vertical { height: 4px; }
        QSplitter::handle:horizontal { width: 4px; }
        """)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls(): event.acceptProposedAction()

    def dropEvent(self, event):
        paths = [
            Path(url.toLocalFile())
            for url in event.mimeData().urls()
            if url.isLocalFile()
        ]
        if paths:
            event.setDropAction(Qt.CopyAction)
            event.accept()
            self.request_import(paths)

    def _position_progress_overlay(self, overlay=None):
        # Progress is a regular layout widget in Commit0015d.
        return


    def _make_progress(self, title: str, maximum: int):
        panel = self.import_progress_panel
        panel.reset_for_use(title)

        if maximum <= 0:
            panel.progress.setRange(0, 0)
        else:
            panel.progress.setRange(0, max(1, int(maximum)))
            panel.progress.setValue(0)

        panel.show()
        self.root_layout.invalidate()
        self.root_layout.activate()
        self.centralWidget().updateGeometry()
        self.centralWidget().repaint()
        QApplication.processEvents()
        return panel


    def _progress_step(self, progress: QProgressDialog, value: int, text: str) -> bool:
        progress.setLabelText(text)
        if progress.maximum() > 0:
            progress.setValue(min(value, progress.maximum()))
        QApplication.processEvents()
        return not progress.wasCanceled()

    @staticmethod
    def _patient_axis_label(vector):
        components = [
            (float(vector[0]), "L", "R"),
            (float(vector[1]), "P", "A"),
            (float(vector[2]), "S", "I"),
        ]
        output = []
        for value, positive, negative in sorted(
            components, key=lambda item: abs(item[0]), reverse=True
        ):
            if abs(value) >= 1e-4:
                output.append(positive if value > 0 else negative)
        return "".join(output[:2])

    def _detect_image_plane(self):
        if self.orientation_plane_override != "Auto":
            return self.orientation_plane_override

        if self.current_ds is not None:
            try:
                orientation = [float(v) for v in self.current_ds.ImageOrientationPatient]
                row = np.asarray(orientation[:3], dtype=float)
                column = np.asarray(orientation[3:6], dtype=float)
                normal = np.cross(row, column)
                axis = int(np.argmax(np.abs(normal)))
                return ("Sagittal", "Coronal", "Axial")[axis]
            except Exception:
                pass

            metadata = " ".join(
                str(getattr(self.current_ds, name, "") or "")
                for name in (
                    "SeriesDescription", "ProtocolName",
                    "StudyDescription", "ImageComments",
                )
            ).lower()
            if "cor" in metadata:
                return "Coronal"
            if "sag" in metadata:
                return "Sagittal"
            if "axi" in metadata or "tra" in metadata:
                return "Axial"

        source_text = str(self.current_source or "").lower()
        if "cor" in source_text:
            return "Coronal"
        if "sag" in source_text:
            return "Sagittal"
        if "axi" in source_text or "tra" in source_text:
            return "Axial"
        if self.source_kind == "raw_file":
            return "Coronal"
        return "Axial"

    @staticmethod
    def _plane_default_labels(plane):
        presets = {
            "Axial": {"top": "A", "bottom": "P", "left": "R", "right": "L"},
            "Coronal": {"top": "S", "bottom": "I", "left": "R", "right": "L"},
            "Sagittal": {"top": "S", "bottom": "I", "left": "A", "right": "P"},
        }
        return dict(presets.get(plane, presets["Axial"]))

    def _dicom_orientation_labels(self):
        if self.current_ds is None:
            return self._plane_default_labels(self._detect_image_plane())
        try:
            orientation = [float(v) for v in self.current_ds.ImageOrientationPatient]
            row = np.asarray(orientation[:3], dtype=float)
            column = np.asarray(orientation[3:6], dtype=float)
            labels = {
                "top": self._patient_axis_label(-column),
                "bottom": self._patient_axis_label(column),
                "left": self._patient_axis_label(-row),
                "right": self._patient_axis_label(row),
            }
            if all(labels.values()):
                return labels
        except Exception:
            pass
        return self._plane_default_labels(self._detect_image_plane())

    def _effective_orientation_labels(self):
        defaults = self._dicom_orientation_labels()
        return {
            key: self.orientation_override.get(key) or defaults[key]
            for key in defaults
        }

    def _apply_image_orientation(self):
        labels = self._effective_orientation_labels()
        if self.view_mode == "FFT":
            self.primary_panel.clear_orientation_labels()
            self.secondary_panel.clear_orientation_labels()
        elif self.view_mode == "Original":
            self.primary_panel.set_orientation_labels(labels)
            self.secondary_panel.clear_orientation_labels()
        else:
            self.primary_panel.clear_orientation_labels()
            self.secondary_panel.set_orientation_labels(labels)
        self._update_annotation_display()

    def _transform_current_image(self, operation):
        if self.current_image is None:
            return

        def transform(array):
            if array is None:
                return None
            if operation == "Rotate Left":
                return np.rot90(array, 1)
            if operation == "Rotate Right":
                return np.rot90(array, -1)
            if operation == "Flip Horizontal":
                return np.fliplr(array)
            if operation == "Flip Vertical":
                return np.flipud(array)
            return array

        for name in (
            "current_image", "current_kspace", "current_recon",
            "compensation_base_image", "compensation_original",
            "compensation_base_kspace", "compensation_original_kspace",
            "addsub_preview_result",
        ):
            value = getattr(self, name, None)
            if value is not None and np.asarray(value).ndim >= 2:
                setattr(self, name, transform(np.asarray(value)))

        labels = self._effective_orientation_labels()
        if operation == "Rotate Left":
            new_labels = {
                "top": labels["right"], "bottom": labels["left"],
                "left": labels["top"], "right": labels["bottom"],
            }
        elif operation == "Rotate Right":
            new_labels = {
                "top": labels["left"], "bottom": labels["right"],
                "left": labels["bottom"], "right": labels["top"],
            }
        elif operation == "Flip Horizontal":
            new_labels = {
                **labels, "left": labels["right"], "right": labels["left"]
            }
        elif operation == "Flip Vertical":
            new_labels = {
                **labels, "top": labels["bottom"], "bottom": labels["top"]
            }
        else:
            new_labels = labels

        self.orientation_override = dict(new_labels)
        self.refresh_images()
        self._configure_line_control(*self.current_image.shape)
        self.update_line_profile()
        self._apply_image_orientation()

    def edit_image_orientation(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Image Orientation")
        dialog.resize(430, 320)
        form = QFormLayout(dialog)

        plane_combo = QComboBox()
        plane_combo.addItems(["Auto", "Axial", "Coronal", "Sagittal"])
        plane_combo.setCurrentText(self.orientation_plane_override)
        form.addRow("Scan plane", plane_combo)

        current = self._effective_orientation_labels()
        edits = {}
        for key, title in (
            ("top", "Top"), ("bottom", "Bottom"),
            ("left", "Left"), ("right", "Right"),
        ):
            edit = QLineEdit(current[key])
            edit.setMaxLength(3)
            edits[key] = edit
            form.addRow(title, edit)

        preset_row = QHBoxLayout()
        for plane in ("Axial", "Coronal", "Sagittal"):
            button = QPushButton(plane)
            def apply_preset(_checked=False, selected=plane):
                plane_combo.setCurrentText(selected)
                for key, value in self._plane_default_labels(selected).items():
                    edits[key].setText(value)
            button.clicked.connect(apply_preset)
            preset_row.addWidget(button)
        form.addRow("Preset", preset_row)

        transform_grid = QGridLayout()
        for title, row, column in (
            ("Rotate Left", 0, 0), ("Rotate Right", 0, 1),
            ("Flip Horizontal", 1, 0), ("Flip Vertical", 1, 1),
        ):
            button = QPushButton(title)
            def apply_transform(_checked=False, operation=title):
                self._transform_current_image(operation)
                dialog.accept()
            button.clicked.connect(apply_transform)
            transform_grid.addWidget(button, row, column)
        form.addRow("Image transform", transform_grid)

        buttons = QHBoxLayout()
        reset_button = QPushButton("Use detected default")
        apply_button = QPushButton("Apply labels")
        cancel_button = QPushButton("Cancel")
        buttons.addWidget(reset_button)
        buttons.addStretch(1)
        buttons.addWidget(apply_button)
        buttons.addWidget(cancel_button)
        form.addRow(buttons)

        def restore_defaults():
            selected = plane_combo.currentText()
            plane = self._detect_image_plane() if selected == "Auto" else selected
            for key, value in self._plane_default_labels(plane).items():
                edits[key].setText(value)

        reset_button.clicked.connect(restore_defaults)
        apply_button.clicked.connect(dialog.accept)
        cancel_button.clicked.connect(dialog.reject)

        if dialog.exec() == QDialog.Accepted:
            self.orientation_plane_override = plane_combo.currentText()
            plane = self._detect_image_plane()
            defaults = self._plane_default_labels(plane)
            self.orientation_override = {
                key: (
                    None
                    if edit.text().strip().upper() == defaults.get(key, "")
                    else edit.text().strip().upper()
                )
                for key, edit in edits.items()
            }
            self._apply_image_orientation()

    def _annotation_lines(self, mode=None):
        mode = mode or self.annotation_mode
        plane = self._detect_image_plane()
        labels = self._effective_orientation_labels()
        lines = [
            Path(self.current_source).name if self.current_source else "No file",
            f"{plane} | {labels['top']}/{labels['bottom']} "
            f"{labels['left']}/{labels['right']}",
        ]
        if self.current_image is not None:
            lines.append(f"{self.current_image.shape[0]}×{self.current_image.shape[1]}")
        if mode == "Minimum":
            return lines

        if self.current_ds is not None:
            ds = self.current_ds
            fields = [
                ("Patient", getattr(ds, "PatientName", "")),
                ("Study", getattr(ds, "StudyDescription", "")),
                ("Series", getattr(ds, "SeriesDescription", "")),
                ("Protocol", getattr(ds, "ProtocolName", "")),
                ("Modality", getattr(ds, "Modality", "")),
                ("Series No.", getattr(ds, "SeriesNumber", "")),
                ("Instance", getattr(ds, "InstanceNumber", "")),
                ("TE/TR", f"{getattr(ds, 'EchoTime', '')}/{getattr(ds, 'RepetitionTime', '')}"),
                ("Pixel spacing", getattr(ds, "PixelSpacing", "")),
            ]
            for label, value in fields:
                if str(value).strip() and str(value) != "/":
                    lines.append(f"{label}: {value}")
        elif self.current_raw_result is not None:
            result = self.current_raw_result
            lines.extend([
                f"RAW: {result.dtype_name}, {result.endian_name}",
                f"Confidence: {result.confidence:.0%}",
                f"Image-likeness: {getattr(result, 'fus_image_likeness', 0.0):.3f}",
                f"Offset: {result.offset_bytes} bytes",
            ])
        return lines

    def _update_annotation_display(self):
        value = "\n".join(self._annotation_lines())
        self.annotation_text.setText(value or "No annotation")
        if not self.annotation_visible:
            self.primary_panel.clear_annotation()
            self.secondary_panel.clear_annotation()
            return
        if self.view_mode == "FFT":
            self.primary_panel.clear_annotation()
            self.secondary_panel.clear_annotation()
        elif self.view_mode == "Original":
            self.primary_panel.set_annotation(value, self.annotation_mode)
            self.secondary_panel.clear_annotation()
        else:
            self.primary_panel.clear_annotation()
            self.secondary_panel.set_annotation(value, self.annotation_mode)

    def _annotation_visibility_changed(self, checked):
        self.annotation_visible = bool(checked)
        self.annotation_panel.setVisible(self.annotation_visible)
        self._resize_left_annotation_area()
        self._update_annotation_display()
        self._schedule_responsive_layout()

    def _annotation_mode_changed(self, mode):
        self.annotation_mode = str(mode)
        self._resize_left_annotation_area()
        self._update_annotation_display()

    def _resize_left_annotation_area(self):
        if not hasattr(self, "left_content_splitter"):
            return

        total = max(
            sum(self.left_content_splitter.sizes()),
            self.left_content_splitter.height(),
            360,
        )

        current = self.left_content_splitter.sizes()
        remembered = self._user_left_split_sizes

        if len(remembered) == 3 and sum(remembered) > 0:
            message_height = max(80, remembered[2])
        elif len(current) == 3 and sum(current) > 0:
            message_height = max(80, current[2])
        else:
            message_height = 120

        upper_available = max(220, total - message_height)

        if not self.annotation_visible:
            target = [upper_available, 0, message_height]
        elif self.annotation_mode == "Minimum":
            target = [
                int(upper_available * 0.67),
                int(upper_available * 0.33),
                message_height,
            ]
        else:
            target = [
                int(upper_available * 0.50),
                int(upper_available * 0.50),
                message_height,
            ]

        self.left_content_splitter.setSizes(target)


    @staticmethod
    def _raw_image_quality(image):
        array = np.abs(np.asarray(image, dtype=float))
        finite = array[np.isfinite(array)]
        if finite.size < 256:
            return -1e9
        low, high = np.percentile(finite, [1.0, 99.0])
        if high <= low:
            return -1e9
        normalized = np.clip((array - low) / (high - low), 0.0, 1.0)
        gy, gx = np.gradient(normalized)
        gradient = np.hypot(gx, gy)
        smooth_difference = np.abs(
            normalized - median_filter_3x3_numpy(normalized)
        )
        center = normalized[
            normalized.shape[0] // 4: normalized.shape[0] * 3 // 4,
            normalized.shape[1] // 4: normalized.shape[1] * 3 // 4,
        ]
        return (
            float(np.var(center)) * 7.0
            + float(np.mean(gradient > np.percentile(gradient, 85))) * 2.0
            - float(np.mean(smooth_difference)) * 4.0
            - float(np.mean((normalized < 0.01) | (normalized > 0.99))) * 2.0
        )

    @staticmethod
    def _fus_preview_normalize(image):
        array = np.asarray(image)
        if np.iscomplexobj(array):
            array = np.abs(array)
        array = np.asarray(array, dtype=float)
        finite = array[np.isfinite(array)]
        if finite.size == 0:
            return np.zeros_like(array, dtype=float)
        low, high = np.percentile(finite, [1.0, 99.0])
        if not np.isfinite(low) or not np.isfinite(high) or high <= low:
            low = float(np.min(finite)); high = float(np.max(finite))
        if high <= low:
            return np.zeros_like(array, dtype=float)
        return np.clip((array-low)/(high-low), 0.0, 1.0)

    def _raw_display_candidates(self, result):
        raw = np.asarray(result.data)
        direct = np.abs(raw) if np.iscomplexobj(raw) else np.asarray(raw, dtype=float)
        reconstructed = np.abs(ifft2c(raw))
        return {
            "Direct Array": self._fus_preview_normalize(direct),
            "Reconstructed Image": self._fus_preview_normalize(reconstructed),
            "k-space Magnitude": self._fus_preview_normalize(np.log1p(np.abs(raw))),
        }

    def _auto_raw_display(self, result):
        candidates = self._raw_display_candidates(result)
        scores = {
            key: self._raw_image_quality(value)
            for key, value in candidates.items()
        }
        recommended = getattr(result, "recommended_display", "Auto")
        fus_likeness = float(getattr(result, "fus_image_likeness", 0.0))

        if recommended == "Direct Array" and fus_likeness >= 0.45:
            selected = "Direct Array"
            scores["Direct Array"] += 100.0
            return selected, candidates[selected], scores
        elif recommended == "Reconstructed Image":
            scores["Reconstructed Image"] += 1.2
        elif result.is_kspace:
            scores["Reconstructed Image"] += 0.75
        else:
            scores["Direct Array"] += 0.20

        selected = max(scores, key=scores.get)
        return selected, candidates[selected], scores

    def _change_raw_display_mode(self, mode):
        if self.current_raw_result is None:
            return
        candidates = self._raw_display_candidates(self.current_raw_result)
        if mode == "Auto":
            selected, image, _scores = self._auto_raw_display(
                self.current_raw_result
            )
        else:
            selected = mode
            image = candidates.get(mode, candidates["Direct Array"])

        self.raw_display_mode = mode
        self.current_image = np.asarray(image, dtype=float)
        if selected == "Reconstructed Image":
            self.current_kspace = np.asarray(self.current_raw_result.data)
        else:
            self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)

        self.original_window_level = None
        self.original_dynamic_range = None
        self.raw_window_level = None
        self.raw_dynamic_range = None
        self.refresh_images()
        self._configure_line_control(*self.current_image.shape)
        self.update_line_profile()
        self._apply_image_orientation()
        self.statusBar().showMessage(f"RAW display: {selected}")

    def _display_loaded_raw_result(
        self,
        path: Path,
        result: RawImportResult,
        *,
        cached: bool = False,
    ):
        self.current_raw_result = result
        self.current_ds = None
        self.current_source = str(path)
        self.source_kind = "raw_file"
        self.slice_label.setText(
            f"RAW: {result.rows}×{result.cols}"
        )

        selected_mode, selected_image, raw_scores = self._auto_raw_display(result)
        image = np.asarray(selected_image, dtype=float)

        if image.ndim != 2 or image.size == 0:
            raise RawImportError(
                f"Decoded RAW preview has invalid shape: {image.shape}"
            )

        # FUS previews are normally normalized to 0–1. Ensure a finite visible
        # image even when cached data contains NaN/Inf or a flat range.
        image = np.nan_to_num(image, nan=0.0, posinf=1.0, neginf=0.0)
        finite = image[np.isfinite(image)]
        if finite.size:
            low, high = np.percentile(finite, [1.0, 99.0])
            if high > low:
                image = np.clip((image - low) / (high - low), 0.0, 1.0)
            elif float(np.max(finite)) > float(np.min(finite)):
                minimum = float(np.min(finite))
                maximum = float(np.max(finite))
                image = np.clip(
                    (image - minimum) / (maximum - minimum),
                    0.0,
                    1.0,
                )

        self.current_image = image
        if selected_mode == "Reconstructed Image":
            self.current_kspace = np.asarray(result.data)
        else:
            self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)

        self.compensation_base_kspace = np.asarray(self.current_kspace).copy()
        self.compensation_base_image = np.asarray(self.current_image).copy()
        self.compensation_original = np.asarray(self.current_image).copy()
        self.compensation_original_kspace = np.asarray(
            self.current_kspace
        ).copy()
        self.compensation_history.clear()
        self.compensation_history_index = -1

        # Clear all previous-image display state. Without this reset, a DICOM
        # manual WW/WL can make a normalized RAW image appear completely black.
        self.original_window_level = 0.5
        self.original_dynamic_range = 1.0
        self.raw_window_level = None
        self.raw_dynamic_range = None

        self.level_target_combo.blockSignals(True)
        self.level_preset_combo.blockSignals(True)
        try:
            self.level_target_combo.setCurrentText("Original Image")
            self.level_preset_combo.setCurrentText("Manual")
            self.window_level_spin.setValue(0.5)
            self.dynamic_range_spin.setValue(1.0)
        finally:
            self.level_target_combo.blockSignals(False)
            self.level_preset_combo.blockSignals(False)

        self.raw_display_mode = "Auto"
        self.raw_display_combo.blockSignals(True)
        try:
            self.raw_display_combo.setCurrentText("Auto")
            self.raw_display_combo.setEnabled(True)
        finally:
            self.raw_display_combo.blockSignals(False)

        interpretation = (
            "Complex k-space"
            if result.is_kspace
            else "FUS direct image candidate"
        )
        cache_text = (
            "Predecoded during import"
            if cached
            else "Decoded on selection"
        )
        self.info.setText(
            f"File: {path.name}\n"
            f"Type: RAW ({interpretation})\n"
            f"Display: Auto → {selected_mode}\n"
            f"Preview: Exact FUS Commit0013 compatible\n"
            f"Load mode: {cache_text}\n"
            f"Matrix: {result.rows} × {result.cols}\n"
            f"Data type: {result.dtype_name}\n"
            f"Endian: {result.endian_name}\n"
            f"Confidence: {result.confidence:.0%}\n"
            f"Status: "
            f"{'Experimental Preview' if getattr(result, 'experimental', False) else 'Recognized RAW'}\n"
            f"FUS image-likeness: "
            f"{getattr(result, 'fus_image_likeness', 0.0):.3f}\n"
            f"Candidates: "
            f"{getattr(result, 'candidate_summary', '') or 'Primary decoder match'}\n"
            f"Reason: {result.reason}"
        )

        self._update_output_root_label()

        # First paint Original directly. This avoids an empty Both layout when
        # the secondary panel has not yet completed its geometry update.
        self.view_mode = "Original"
        self.btn_original.setChecked(True)
        self.btn_fft.setChecked(False)
        self.btn_both.setChecked(False)

        self.primary_panel.show()
        self.secondary_panel.hide()
        self.primary_panel.label.setText("Original Image — Magnitude")
        self.primary_panel.set_image(
            self.current_image,
            levels=(0.0, 1.0),
        )
        self.primary_panel.set_orientation_labels(
            self._effective_orientation_labels()
        )
        self.primary_panel.repaint()
        QApplication.processEvents()

        self._configure_line_control(*self.current_image.shape)
        self._sync_lines()
        self.update_line_profile()

        # Then restore the user's normal RAW workspace as Both. Deferred redraw
        # lets splitter geometry settle before the FFT panel is added.
        def finish_both_display():
            if self.current_source != str(path):
                return
            self.view_mode = "Both"
            self.btn_original.setChecked(False)
            self.btn_fft.setChecked(False)
            self.btn_both.setChecked(True)
            self.refresh_images()
            self._apply_image_orientation()
            self._schedule_responsive_layout()

        QTimer.singleShot(0, finish_both_display)
        QTimer.singleShot(80, finish_both_display)

        self.statusBar().showMessage(
            f"RAW displayed: {path.name} — "
            f"{result.rows}×{result.cols}, "
            f"image-likeness "
            f"{getattr(result, 'fus_image_likeness', 0.0):.3f}"
        )


    def load_raw_file(self, path: Path):
        path = Path(path)
        cache_key = str(path)

        cached_result = self.raw_preview_cache.get(cache_key)
        if cached_result is not None:
            try:
                self._display_loaded_raw_result(
                    path,
                    cached_result,
                    cached=True,
                )
                return
            except Exception:
                # A stale or incompatible cached object must not block a fresh
                # exact decode.
                self.raw_preview_cache.pop(cache_key, None)

        # The exact FUS decoder is intentionally attempted synchronously first.
        # It is bounded to three dtypes and ten matrix widths and normally
        # completes fast enough for direct list selection.
        exact_result = try_render_fus_raw_exact(path)
        if exact_result is not None:
            self.raw_preview_cache[cache_key] = exact_result
            self._display_loaded_raw_result(path, exact_result, cached=False)
            return

        # Unsupported/proprietary layouts use the extended fallback. Keep the
        # progress UI only for this uncommon path.
        progress = self._make_progress("Analyzing RAW Data", 0)
        progress.setLabelText(path.name)
        QApplication.processEvents()

        try:
            result = load_raw_file_auto(
                path,
                cache_path=self._output_root() / "raw_import_profiles.json",
            )
        except RawImportError as exc:
            QMessageBox.warning(
                self,
                "RAW Import",
                f"{path.name}\n\n{exc}",
            )
            self.statusBar().showMessage(f"RAW not recognized: {path.name}")
            return
        except Exception as exc:
            QMessageBox.critical(
                self,
                "RAW Import Error",
                f"{path.name}\n\n{type(exc).__name__}: {exc}",
            )
            return
        finally:
            progress.hide()
            self._stabilize_layout()

        self.raw_preview_cache[cache_key] = result
        self._display_loaded_raw_result(path, result, cached=False)


    def load_bitmap_image(self, path: Path):
        qimage = QImage(str(path))
        if qimage.isNull():
            raise ValueError(f"Unable to read image: {path}")
        gray = qimage.convertToFormat(QImage.Format_Grayscale8)
        width = gray.width()
        height = gray.height()
        ptr = gray.bits()
        array = np.frombuffer(ptr, dtype=np.uint8, count=gray.sizeInBytes())
        array = array.reshape((height, gray.bytesPerLine()))[:, :width].copy()

        self.current_image = array.astype(float)
        self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)
        self.current_ds = None
        self.current_source = str(path)
        self.source_kind = "bitmap"
        self.view_mode = "Original"
        self.original_window_level = None
        self.original_dynamic_range = None
        self.btn_original.setChecked(True)
        self.btn_fft.setChecked(False)
        self.btn_both.setChecked(False)

        self.processed_images[str(path)] = self.current_image.copy()
        self.processed_sources[str(path)] = path
        self._add_external_image_tree_item(path)
        self._update_output_root_label()
        self.refresh_images()
        self.info.setText(
            f"File: {path.name}\nType: Bitmap image\n"
            f"Size: {width} × {height}\nOriginal Image only"
        )

    def _add_external_image_tree_item(self, path: Path):
        root = None
        for index in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(index)
            if item.text(0) == "Image Files":
                root = item
                break
        if root is None:
            root = QTreeWidgetItem(["Image Files"])
            self.tree.addTopLevelItem(root)
        child = QTreeWidgetItem([path.name])
        child.setData(0, Qt.UserRole, ("processed", str(path)))
        root.addChild(child)
        root.setExpanded(True)
        self.tree.setCurrentItem(child)

    def _open_folder_direct(self):
        if self.import_in_progress:
            self.open_import_selection()
            return
        folder = QFileDialog.getExistingDirectory(
            self,
            "Select MRI Data Folder",
            "",
            QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks,
        )
        if folder:
            self.request_import([Path(folder)])

    def open_import_selection(self):
        if self.import_in_progress:
            QMessageBox.information(
                self,
                "Import in progress",
                "An import is already running.\n"
                "Wait for it to finish or press Cancel in the progress window.",
            )
            if hasattr(self, "_active_import_progress") and self._active_import_progress:
                self._active_import_progress.show()
                self._active_import_progress.raise_()
                self._active_import_progress.activateWindow()
            return

        dialog = QMessageBox(self)
        dialog.setWindowTitle("Import MRI Data")
        dialog.setText("Select how to import data.")
        files_button = dialog.addButton("Files", QMessageBox.AcceptRole)
        folder_button = dialog.addButton("Folder", QMessageBox.ActionRole)
        dialog.addButton("Cancel", QMessageBox.RejectRole)
        dialog.exec()

        selected_paths = []
        if dialog.clickedButton() == files_button:
            filenames, _ = QFileDialog.getOpenFileNames(
                self,
                "Select MRI Files",
                "",
                (
                    "Supported files "
                    "(*.dcm *.ima *.dicom *.zip *.raw *.bin *.dat *.7 *.pfile "
                    "*.img *.csv *.txt *.npy *.npz *.jpg *.jpeg *.png *.bmp);;"
                    "All files (*)"
                ),
            )
            selected_paths = [Path(name) for name in filenames]

        elif dialog.clickedButton() == folder_button:
            folder = QFileDialog.getExistingDirectory(
                self,
                "Select MRI Data Folder",
                "",
                QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks,
            )
            if folder:
                selected_paths = [Path(folder)]

        if selected_paths:
            self.request_import(selected_paths)

    def request_import(self, paths: list[Path]):
        clean_paths = [Path(path) for path in paths if Path(path).exists()]
        if not clean_paths:
            return

        first_source = clean_paths[0]
        if first_source.is_dir():
            base_parent = first_source
        else:
            base_parent = first_source.parent
        self.last_import_output_root = base_parent / "MR_Image_Explorer_Output"
        self._update_output_root_label()

        if self.import_in_progress:
            self.statusBar().showMessage("Import request ignored: import is already running")
            if hasattr(self, "_active_import_progress") and self._active_import_progress:
                self._active_import_progress.show()
                self._active_import_progress.raise_()
                self._active_import_progress.activateWindow()
            return

        # Defer execution until the current drag/click event is fully completed.
        QTimer.singleShot(0, lambda p=clean_paths: self.import_paths(p))

    @Slot(str, int, int)
    def _on_import_progress(self, message: str, value: int, maximum: int):
        progress = getattr(self, "_active_import_progress", None)
        if progress is None:
            return

        lines = []
        for line in str(message).splitlines():
            if len(line) > 96:
                line = "..." + line[-93:]
            lines.append(line)
        progress.setLabelText("\n".join(lines[:3]))

        if maximum <= 0:
            progress.progress.setRange(0, 0)
        else:
            if (
                progress.progress.minimum() != 0
                or progress.progress.maximum() != maximum
            ):
                progress.progress.setRange(0, maximum)
            progress.setValue(value)

        if not progress.isVisible():
            progress.show()

        self.root_layout.invalidate()
        self.centralWidget().updateGeometry()
        progress.repaint()
        self.centralWidget().repaint()
        QApplication.processEvents()


    def _save_current_import_history(self):
        if not self.dicom_entries and not self.pending_tracker_paths:
            return
        self.import_history.append({
            "dicom_entries": list(self.dicom_entries),
            "pending_tracker_paths": list(self.pending_tracker_paths),
            "imported_paths": list(self.imported_paths),
            "slice_index": int(getattr(self, "slice_index", 0)),
        })
        self.import_history = self.import_history[-5:]
        self.previous_import_button.setEnabled(bool(self.import_history))

    def restore_previous_import(self):
        if not self.import_history:
            return
        state = self.import_history.pop()
        self.dicom_entries = list(state["dicom_entries"])
        self.pending_tracker_paths = list(state["pending_tracker_paths"])
        self.imported_paths = list(state["imported_paths"])
        self.lazy_dicom_cache_order.clear()
        self.populate_dicom_tree()
        self.previous_import_button.setEnabled(bool(self.import_history))
        if self.dicom_entries:
            index = min(state["slice_index"], len(self.dicom_entries) - 1)
            QTimer.singleShot(0, lambda i=index: self.show_dicom(i))
        self.statusBar().showMessage("Previous import list restored")
        self._stabilize_layout()

    def _origin_for_path(self, path):
        return self.import_origin_info.get(
            str(path),
            {
                "container": Path(path).parent.name,
                "container_type": "File",
                "relative_path": Path(path).name,
                "group_path": "(Other)",
            },
        )

    def _ensure_group_item(self, parent, cache, key, title):
        if key not in cache:
            item = QTreeWidgetItem([title])
            parent.addChild(item)
            cache[key] = item
        return cache[key]

    def _add_grouped_path_items(
        self,
        root_title,
        paths,
        data_kind,
        text_builder,
    ):
        if not paths:
            return

        root = QTreeWidgetItem([f"{root_title} ({len(paths)})"])
        self.tree.addTopLevelItem(root)
        group_cache = {}

        for index, path in enumerate(paths):
            origin = self._origin_for_path(path)
            container = origin.get("container", "Other")
            group_path = origin.get("group_path", "(Root)")
            container_type = origin.get("container_type", "File")
            key = (container_type, container, group_path)
            title = f"{container_type}: {container} / {group_path}"
            group = self._ensure_group_item(
                root,
                group_cache,
                key,
                title,
            )

            item = QTreeWidgetItem([text_builder(path, index)])
            if data_kind == "tracker_pending":
                item.setData(0, Qt.UserRole, (data_kind, index))
            else:
                item.setData(0, Qt.UserRole, (data_kind, str(path)))
            item.setToolTip(
                0,
                f"{path}\n"
                f"Source: {container_type} {container}\n"
                f"Relative: {origin.get('relative_path', path.name)}",
            )
            group.addChild(item)

        for item in group_cache.values():
            item.setExpanded(False)
        root.setExpanded(True)

    def _on_import_completed(self, result: dict):
        try:
            self._save_current_import_history()
            for temp_dir in result.get("temp_dirs", []):
                if temp_dir not in self.temp_dirs:
                    self.temp_dirs.append(temp_dir)

            files = result.get("all_files", [])
            dicoms = result.get("dicoms", [])
            trackers = result.get("trackers", [])
            raw_files = result.get("raw_files", [])
            self.raw_preview_cache.update(
                result.get("raw_preview_cache", {}) or {}
            )
            self.import_origin_info = dict(
                result.get("origin_info", {}) or {}
            )
            self._active_tree_source_key = None
            bitmaps = result.get("bitmaps", [])
            signals = result.get("signals", [])
            skipped = int(result.get("skipped", 0))

            known = set()
            for path in self.imported_paths:
                try:
                    known.add(str(path.resolve()).lower())
                except Exception:
                    pass

            for path in files:
                try:
                    key = str(path.resolve()).lower()
                except Exception:
                    key = str(path).lower()
                if key not in known:
                    self.imported_paths.append(path)
                    known.add(key)

            self.tree.blockSignals(True)
            try:
                self.tree.clear()

                if dicoms:
                    self.dicom_entries = list(dicoms)
                    self.lazy_dicom_cache_order.clear()
                    self.populate_dicom_tree()

                self.pending_tracker_paths = list(trackers)

                self._add_grouped_path_items(
                    "Tracker P Files",
                    trackers,
                    "tracker_pending",
                    lambda path, index: path.name,
                )

                def raw_text(path, index):
                    preview = self.raw_preview_cache.get(str(path))
                    if preview is None:
                        return path.name
                    status = (
                        "Experimental"
                        if getattr(preview, "experimental", False)
                        else "Recognized"
                    )
                    return (
                        f"{path.name}  |  {preview.rows}×{preview.cols} "
                        f"{preview.dtype_name}  "
                        f"score {preview.fus_image_likeness:.3f}  "
                        f"{status}"
                    )

                self._add_grouped_path_items(
                    "RAW / P / k-space Images",
                    raw_files,
                    "raw_file",
                    raw_text,
                )

                self._add_grouped_path_items(
                    "Bitmap Images",
                    bitmaps,
                    "bitmap_pending",
                    lambda path, index: (
                        f"{path.name}  |  {path.suffix.lower().lstrip('.').upper()}"
                    ),
                )

                if signals:
                    root = QTreeWidgetItem([f"1D / Array Data ({len(signals)})"])
                    self.tree.addTopLevelItem(root)
                    for path in signals:
                        item = QTreeWidgetItem([path.name])
                        item.setData(0, Qt.UserRole, ("signal_pending", str(path)))
                        item.setToolTip(0, str(path))
                        root.addChild(item)
                    root.setExpanded(True)
            finally:
                self.tree.blockSignals(False)

            total_recognized = (
                len(dicoms) + len(trackers) + len(raw_files)
                + len(bitmaps) + len(signals)
            )

            self.tabs.setCurrentIndex(0)
            self.statusBar().showMessage(
                f"Inventory completed: {len(dicoms):,} DICOM images, "
                f"{len(raw_files):,} RAW images, "
                f"{len(bitmaps):,} bitmap images, "
                f"{len(trackers):,} Tracker, {len(signals):,} signal files"
            )

            if total_recognized == 0:
                QMessageBox.information(
                    self,
                    "Import completed",
                    f"No supported MRI data was recognized.\n"
                    f"Checked: {len(files):,}\nSkipped: {skipped:,}",
                )

            # Close progress first; decode the first image afterward.
            self._close_import_progress()
            if dicoms:
                QTimer.singleShot(100, lambda: self.show_dicom(0))
            elif raw_files:
                first_raw = Path(raw_files[0])
                QTimer.singleShot(
                    100,
                    lambda path=first_raw: self.load_raw_file(path),
                )

        except Exception as exc:
            self._on_import_failed(f"{type(exc).__name__}: {exc}")


    @Slot(str)
    def _on_import_failed(self, message: str):
        self._close_import_progress()
        QMessageBox.critical(self, "Import error", message)
        self.statusBar().showMessage(f"Import failed: {message}")

    @Slot()
    def _on_import_canceled(self):
        self._close_import_progress()
        self.statusBar().showMessage("Import canceled")

    @Slot()
    def _on_import_thread_finished(self):
        self.import_thread = None
        self.import_worker = None


    def _available_screen_geometry(self):
        screen = self.screen() or QApplication.primaryScreen()
        if screen is None:
            return None
        return screen.availableGeometry()

    def _initial_screen_fit(self):
        if self._screen_fit_completed:
            self._ensure_window_inside_screen()
            return
        geometry = self._available_screen_geometry()
        if geometry is None:
            return
        self.centralWidget().ensurePolished()
        self.centralWidget().layout().activate()
        QApplication.processEvents()
        max_width = max(820, int(geometry.width() * 0.94))
        max_height = max(560, int(geometry.height() * 0.92))
        target_width = min(max_width, 1280)
        target_height = min(max_height, 820)
        self.resize(target_width, target_height)
        frame = self.frameGeometry()
        frame.moveCenter(geometry.center())
        if frame.left() < geometry.left(): frame.moveLeft(geometry.left())
        if frame.top() < geometry.top(): frame.moveTop(geometry.top())
        if frame.right() > geometry.right(): frame.moveRight(geometry.right())
        if frame.bottom() > geometry.bottom(): frame.moveBottom(geometry.bottom())
        self.move(frame.topLeft())
        self._screen_fit_completed = True
        self._initial_fit_done = True
        self._apply_responsive_layout()


    def _save_viewer_layout(self):
        try:
            self.viewer_settings.setValue(
                "window_geometry",
                self.saveGeometry(),
            )
            self.viewer_settings.setValue(
                "main_split",
                self.main_split.sizes(),
            )
            self.viewer_settings.setValue(
                "left_split",
                self.left_content_splitter.sizes(),
            )
            self.viewer_settings.setValue(
                "vertical_split",
                self.vertical_splitter.sizes(),
            )
            self.viewer_settings.setValue(
                "image_split",
                self.image_splitter.sizes(),
            )
        except Exception:
            pass

    def _restore_viewer_layout(self):
        try:
            geometry = self.viewer_settings.value("window_geometry")
            if geometry is not None:
                self.restoreGeometry(geometry)

            for key, splitter in (
                ("main_split", self.main_split),
                ("left_split", self.left_content_splitter),
                ("vertical_split", self.vertical_splitter),
                ("image_split", self.image_splitter),
            ):
                sizes = self.viewer_settings.value(key)
                if isinstance(sizes, list) and sizes:
                    splitter.setSizes(
                        [int(value) for value in sizes]
                    )

            if len(self.main_split.sizes()) == 3:
                self._user_main_split_sizes = self.main_split.sizes()
            if len(self.left_content_splitter.sizes()) == 3:
                self._user_left_split_sizes = (
                    self.left_content_splitter.sizes()
                )
            if len(self.vertical_splitter.sizes()) == 2:
                self._user_vertical_split_sizes = (
                    self.vertical_splitter.sizes()
                )
            if len(self.image_splitter.sizes()) == 2:
                self._user_image_split_sizes = (
                    self.image_splitter.sizes()
                )
        except Exception:
            pass

    def reset_viewer_display(self):
        self._user_main_split_sizes = []
        self._user_left_split_sizes = []
        self._user_vertical_split_sizes = []
        self._user_image_split_sizes = []

        self.main_split.setSizes([360, 820, 260])
        self.left_content_splitter.setSizes([500, 0, 130])
        self.vertical_splitter.setSizes([620, 220])
        self.image_splitter.setSizes([1, 1])

        self.annotation_toggle.setChecked(False)
        self.annotation_mode_combo.setCurrentText("Minimum")

        self.orientation_plane_override = "Auto"
        self.orientation_override = {
            "top": None,
            "bottom": None,
            "left": None,
            "right": None,
        }

        self.original_window_level = None
        self.original_dynamic_range = None
        self.raw_window_level = None
        self.raw_dynamic_range = None

        for panel in (
            self.primary_panel,
            self.secondary_panel,
        ):
            try:
                panel.plot.getViewBox().autoRange()
            except Exception:
                pass

        if self.current_image is not None:
            self.refresh_images()
            self._apply_image_orientation()

        self.statusBar().showMessage(
            "Display and layout reset.",
            6000,
        )

    def _remember_left_splitter_sizes(self):
        if hasattr(self, "left_content_splitter"):
            sizes = self.left_content_splitter.sizes()
            if len(sizes) == 3 and sum(sizes) > 0:
                self._user_left_split_sizes = sizes

    def _remember_splitter_sizes(self):
        if hasattr(self, "main_split"):
            self._user_main_split_sizes = self.main_split.sizes()
        if hasattr(self, "vertical_splitter"):
            self._user_vertical_split_sizes = self.vertical_splitter.sizes()
        if hasattr(self, "image_splitter"):
            self._user_image_split_sizes = self.image_splitter.sizes()

    def _schedule_responsive_layout(self):
        if self._responsive_pending:
            return
        self._responsive_pending = True
        def apply():
            self._responsive_pending = False
            self._apply_responsive_layout()
        QTimer.singleShot(0, apply)
        QTimer.singleShot(100, self._apply_responsive_layout)
        QTimer.singleShot(260, self._apply_responsive_layout)


    def _apply_responsive_layout(self):
        if not hasattr(self, "main_split"):
            return

        width = max(self.centralWidget().width(), 900)
        height = max(self.centralWidget().height(), 600)

        # Keep the complete workspace reachable. The center image has priority.
        if width < 1180:
            left_width = 120
            right_width = 255
        elif width < 1450:
            left_width = 170
            right_width = 285
        else:
            left_width = 220
            right_width = 330

        center_width = max(420, width - left_width - right_width - 45)

        remembered = self._user_main_split_sizes
        if len(remembered) == 3 and sum(remembered) > 0:
            available = max(width - 45, 700)
            remembered_total = sum(remembered)
            scaled = [
                max(90, int(value * available / remembered_total))
                for value in remembered
            ]
            # Keep the center panel usable while honoring the user's left width.
            scaled[1] = max(360, scaled[1])
            self.main_split.setSizes(scaled)
        else:
            self.main_split.setSizes(
                [left_width, center_width, right_width]
            )

        self._resize_left_annotation_area()

        # Preserve usable image height and collapse the lower plots first.
        available_tab_height = max(self.tabs.height(), height - 140)
        if available_tab_height < 680:
            lower_height = 90
        elif available_tab_height < 820:
            lower_height = 150
        else:
            lower_height = 220
        upper_height = max(340, available_tab_height - lower_height - 80)
        self.vertical_splitter.setSizes([upper_height, lower_height])

        if self.view_mode == "Both" and self.secondary_panel.isVisible():
            half = max(240, center_width // 2)
            self.image_splitter.setSizes([half, half])
        else:
            self.image_splitter.setSizes([max(480, center_width), 0])

        self.root_layout.invalidate()
        self.root_layout.activate()
        self.centralWidget().updateGeometry()
        self.centralWidget().repaint()

    def _ensure_window_inside_screen(self):
        geometry = self._available_screen_geometry()
        if geometry is None:
            return
        frame = self.frameGeometry()
        if frame.width() > geometry.width():
            self.resize(int(geometry.width() * 0.96), self.height())
            frame = self.frameGeometry()
        if frame.height() > geometry.height():
            self.resize(self.width(), int(geometry.height() * 0.94))
            frame = self.frameGeometry()
        if not geometry.intersects(frame) or not geometry.contains(frame.center()):
            frame.moveCenter(geometry.center())
            self.move(frame.topLeft())

    def _stabilize_layout(self):
        try:
            self._ensure_window_inside_screen()
            self._apply_responsive_layout()
            self.root_layout.invalidate()
            self.root_layout.activate()
            self.centralWidget().updateGeometry()
            self.tabs.updateGeometry()
            self.image_splitter.updateGeometry()
            self.centralWidget().repaint()
            self.repaint()
        except Exception:
            pass


    def _close_import_progress(self):
        self.import_poll_timer.stop()
        self.import_in_progress = False
        self.import_thread_started = False
        self.import_python_thread = None
        self.import_cancel_event.clear()

        self.drop_banner.setEnabled(True)
        self.drop_banner.title.setText(
            "Click or Drop DICOM / Raw / P File / 1D Data / Folder / ZIP Here"
        )

        progress = getattr(self, "_active_import_progress", None)
        self._active_import_progress = None
        if progress is not None:
            progress.cancel_button.setEnabled(True)
            progress.hide()

        self._stabilize_layout()
        QTimer.singleShot(0, self._stabilize_layout)
        QTimer.singleShot(120, self._stabilize_layout)
        QTimer.singleShot(300, self._schedule_responsive_layout)
        QApplication.processEvents()


    def _queue_import_event(self, kind: str, payload=None):
        self.import_event_queue.put((kind, payload, time.monotonic()))

    def _import_thread_main(self, paths: list[Path]):
        temp_dirs = []
        try:
            supported = {
                ".dcm", ".ima", ".dicom", "",
                ".raw", ".bin", ".dat", ".7", ".pfile", ".img", ".kspace", ".cfl", ".rawdata", ".complex",
                ".csv", ".npy", ".npz",
                ".jpg", ".jpeg", ".png", ".bmp",
            }
            files = []
            checked = 0
            self._queue_import_event("progress", ("Collecting files...", 0, 0))

            for source in paths:
                if self.import_cancel_event.is_set():
                    self._queue_import_event("canceled")
                    return
                source = Path(source)
                if source.is_dir():
                    for candidate in source.rglob("*"):
                        if self.import_cancel_event.is_set():
                            self._queue_import_event("canceled")
                            return
                        checked += 1
                        if candidate.is_file() and candidate.suffix.lower() in supported:
                            files.append(candidate)
                        if checked % 100 == 0:
                            self._queue_import_event(
                                "progress",
                                (f"Scanning folder...\nChecked: {checked:,}\nCandidates: {len(files):,}", 0, 0),
                            )
                elif source.is_file() and source.suffix.lower() == ".zip":
                    root = Path(tempfile.mkdtemp(prefix="mr_image_explorer_"))
                    temp_dirs.append(root)
                    with zipfile.ZipFile(source) as archive:
                        members = archive.infolist()
                        total_members = max(len(members), 1)
                        for member_index, member in enumerate(members, start=1):
                            if self.import_cancel_event.is_set():
                                self._queue_import_event("canceled")
                                return
                            self._queue_import_event(
                                "progress",
                                (f"Extracting ZIP {member_index:,}/{total_members:,}\n{member.filename}", member_index, total_members),
                            )
                            target = (root / member.filename).resolve()
                            if not str(target).startswith(str(root.resolve())):
                                raise ValueError("Unsafe ZIP member path")
                            if member.is_dir():
                                target.mkdir(parents=True, exist_ok=True)
                                continue
                            target.parent.mkdir(parents=True, exist_ok=True)
                            with archive.open(member) as src, target.open("wb") as dst:
                                while True:
                                    if self.import_cancel_event.is_set():
                                        self._queue_import_event("canceled")
                                        return
                                    chunk = src.read(1024 * 1024)
                                    if not chunk:
                                        break
                                    dst.write(chunk)
                                    self._queue_import_event(
                                        "progress",
                                        (
                                            f"Extracting ZIP {member_index:,}/{total_members:,}\n"
                                            f"{member.filename}",
                                            member_index,
                                            total_members,
                                        ),
                                    )
                            if target.suffix.lower() in supported:
                                files.append(target)
                elif source.is_file():
                    files.append(source)

            unique=[]; seen=set()
            for path in files:
                try: key=str(path.resolve()).lower()
                except Exception: key=str(path).lower()
                if key not in seen:
                    seen.add(key); unique.append(path)
            files=unique
            total=max(len(files),1)
            dicoms=[]; trackers=[]; raws=[]; bitmaps=[]; signals=[]; skipped=0

            for idx,path in enumerate(files, start=1):
                if self.import_cancel_event.is_set():
                    self._queue_import_event("canceled"); return
                self._queue_import_event("progress", (f"Indexing {idx:,}/{len(files):,}\n{path.name}", idx, total))
                suffix=path.suffix.lower()
                if suffix==".txt":
                    continue
                if suffix in {".jpg",".jpeg",".png",".bmp"}:
                    bitmaps.append(path); continue
                if suffix in {".csv",".npy",".npz"}:
                    signals.append(path); continue
                try:
                    ds=pydicom.dcmread(str(path), stop_before_pixels=True, defer_size="1 KB", force=False)
                    rows=int(getattr(ds,"Rows",0) or 0); cols=int(getattr(ds,"Columns",0) or 0)
                    if rows<=0 or cols<=0: raise ValueError("not image")
                    instance=int(getattr(ds,"InstanceNumber",0) or 0)
                    pos=getattr(ds,"ImagePositionPatient",None)
                    z=float(pos[2]) if pos is not None and len(pos)>=3 else float(instance)
                    series=str(getattr(ds,"SeriesInstanceUID","") or "")
                    dicoms.append(DicomEntry(path=path, ds=ds, image=None, sort_key=(series,z,instance,path.name.lower())))
                    continue
                except Exception:
                    pass
                try:
                    name=path.name.lower(); is_tracker=("trackerimg" in name or "pfile" in name)
                    if not is_tracker and path.suffix=="" and path.stat().st_size>4096:
                        with path.open("rb") as fh: first=fh.read(4)
                        if len(first)==4:
                            rev=np.frombuffer(first,dtype="<f4")[0]
                            is_tracker=bool(np.isfinite(rev) and 1<rev<100)
                    if is_tracker: trackers.append(path)
                    elif suffix in {".raw",".bin",".dat",".7",".pfile",".img",".kspace",".cfl",".rawdata",".complex"}: raws.append(path)
                    else: skipped+=1
                except Exception:
                    skipped+=1

            dicoms.sort(key=lambda entry: entry.sort_key)
            self._queue_import_event("completed", {
                "all_files": files, "dicoms": dicoms, "trackers": trackers,
                "raw_files": raws, "bitmaps": bitmaps, "signals": signals,
                "skipped": skipped, "temp_dirs": temp_dirs,
            })
        except Exception as exc:
            self._queue_import_event("failed", f"{type(exc).__name__}: {exc}")

    def _poll_import_queue(self):
        handled = False

        while True:
            try:
                kind, payload, event_time = self.import_event_queue.get_nowait()
            except queue.Empty:
                break

            handled = True
            self.import_last_event_time = event_time

            if kind == "progress":
                message, value, maximum = payload
                self._on_import_progress(message, value, maximum)

            elif kind == "completed":
                self.import_poll_timer.stop()
                self._on_import_completed(payload)
                return

            elif kind == "failed":
                self.import_poll_timer.stop()
                self._on_import_failed(payload)
                return

            elif kind == "canceled":
                self.import_poll_timer.stop()
                self._on_import_canceled()
                return

        thread = self.import_python_thread
        if not self.import_in_progress or thread is None:
            return

        # Never treat a worker as stopped before thread.start() has completed.
        if not self.import_thread_started:
            return

        # Give the worker a startup grace period before declaring abnormal exit.
        elapsed = time.monotonic() - self.import_start_time
        if elapsed < 1.5:
            return

        if not thread.is_alive() and not handled:
            self.import_poll_timer.stop()

            # Drain once more in case the worker exited immediately after
            # placing its final event in the queue.
            try:
                kind, payload, event_time = self.import_event_queue.get_nowait()
            except queue.Empty:
                self._on_import_failed(
                    "Import worker stopped without returning a result."
                )
                return

            self.import_last_event_time = event_time
            if kind == "completed":
                self._on_import_completed(payload)
            elif kind == "failed":
                self._on_import_failed(payload)
            elif kind == "canceled":
                self._on_import_canceled()
            elif kind == "progress":
                message, value, maximum = payload
                self._on_import_progress(message, value, maximum)
                self._on_import_failed(
                    "Import worker ended after its final progress update "
                    "without returning a completion result."
                )


    def _cancel_python_import(self):
        self.import_cancel_event.set()
        progress = getattr(self, "_active_import_progress", None)
        if progress is not None:
            progress.setLabelText("Canceling import...")
            progress.cancel_button.setEnabled(False)

    def import_paths(self, paths: list[Path]):
        if self.import_in_progress:
            progress = getattr(self, "_active_import_progress", None)
            if progress is not None:
                progress.show()
                self.root_layout.invalidate()
                self.centralWidget().repaint()
                QApplication.processEvents()
            return

        clean_paths = [Path(path) for path in paths if Path(path).exists()]
        if not clean_paths:
            QMessageBox.information(
                self,
                "Import MRI Data",
                "The selected path no longer exists.",
            )
            return

        self.import_in_progress = True
        self.import_thread_started = False
        self.import_start_time = time.monotonic()
        self.import_cancel_event.clear()

        while True:
            try:
                self.import_event_queue.get_nowait()
            except queue.Empty:
                break

        self.drop_banner.setEnabled(False)
        self.drop_banner.title.setText("Importing MRI Data...")
        self.drop_banner.repaint()
        QApplication.processEvents()

        progress = self._make_progress("Importing MRI Data", 1)
        progress.progress.setRange(0, 0)
        progress.setLabelText("Preparing import...")
        self._active_import_progress = progress
        progress.canceled.connect(self._cancel_python_import)

        progress.show()
        progress.raise_()
        QApplication.processEvents()

        thread = threading.Thread(
            target=self._import_thread_main,
            args=(clean_paths,),
            daemon=True,
            name="MRImageExplorerImport",
        )
        self.import_python_thread = thread

        # Start the worker first. Only then start the watchdog/poll timer.
        try:
            thread.start()
            self.import_thread_started = True
        except Exception as exc:
            self._on_import_failed(
                f"Unable to start Import worker: {type(exc).__name__}: {exc}"
            )
            return

        self.import_last_event_time = time.monotonic()
        self.import_poll_timer.start()






    def extract_zip(self, path: Path, parent_progress: Optional[QProgressDialog] = None) -> list[Path]:
        root = Path(tempfile.mkdtemp(prefix='mri_fft_'))
        self.temp_dirs.append(root)
        with zipfile.ZipFile(path) as z:
            members = z.infolist()
            for index, m in enumerate(members, start=1):
                if parent_progress is not None:
                    parent_progress.setLabelText(f"Extracting {path.name}: {index}/{len(members)}")
                    QApplication.processEvents()
                    if parent_progress.wasCanceled():
                        return []
                target = (root / m.filename).resolve()
                if not str(target).startswith(str(root.resolve())):
                    raise ValueError("Unsafe ZIP member")
                z.extract(m, root)
        return [p for p in root.rglob('*') if p.is_file()]

    def read_dicom_metadata(self, path: Path) -> DicomEntry:
        # Header-only read. Pixel Data is not decompressed during initial import.
        ds = pydicom.dcmread(
            str(path),
            stop_before_pixels=True,
            defer_size="1 KB",
            force=False,
        )
        rows = int(getattr(ds, "Rows", 0) or 0)
        cols = int(getattr(ds, "Columns", 0) or 0)
        if rows <= 0 or cols <= 0:
            raise ValueError("Not an image DICOM")

        instance = int(getattr(ds, "InstanceNumber", 0) or 0)
        pos = getattr(ds, "ImagePositionPatient", None)
        z = float(pos[2]) if pos is not None and len(pos) >= 3 else float(instance)
        series = str(getattr(ds, "SeriesInstanceUID", "") or "")
        sort_key = (series, z, instance, path.name.lower())
        return DicomEntry(path=path, ds=ds, image=None, sort_key=sort_key)

    def _ensure_dicom_image(self, index: int) -> DicomEntry:
        if not (0 <= index < len(self.dicom_entries)):
            raise IndexError(index)
        entry = self.dicom_entries[index]
        if entry.image is None:
            full_entry = self.read_dicom(entry.path)
            entry.ds = full_entry.ds
            entry.image = full_entry.image
            entry.sort_key = full_entry.sort_key

            self.lazy_dicom_cache_order = [
                value for value in self.lazy_dicom_cache_order if value != index
            ]
            self.lazy_dicom_cache_order.append(index)

            # Keep a small working set. Header metadata always remains available.
            while len(self.lazy_dicom_cache_order) > self.lazy_dicom_cache_limit:
                remove_index = self.lazy_dicom_cache_order.pop(0)
                if remove_index != index and 0 <= remove_index < len(self.dicom_entries):
                    self.dicom_entries[remove_index].image = None
        return entry

    def read_dicom(self, path: Path) -> DicomEntry:
        ds = pydicom.dcmread(str(path), force=False)
        if not hasattr(ds, 'PixelData'): raise ValueError('No pixel data')
        arr = ds.pixel_array
        if arr.ndim == 3: arr = arr[0]
        if arr.ndim != 2: raise ValueError('Not 2D')
        arr = arr.astype(float) * float(getattr(ds, 'RescaleSlope', 1)) + float(getattr(ds, 'RescaleIntercept', 0))
        instance = int(getattr(ds, 'InstanceNumber', 0) or 0)
        pos = getattr(ds, 'ImagePositionPatient', None)
        z = float(pos[2]) if pos is not None and len(pos) >= 3 else float(instance)
        return DicomEntry(path, ds, arr, (z, instance, path.name.lower()))

    @staticmethod
    def _explorer_series_purpose(ds):
        value = " ".join(
            str(getattr(ds, name, "") or "")
            for name in (
                "SeriesDescription",
                "ProtocolName",
                "SequenceName",
                "ImageType",
            )
        ).upper()
        if "TMAP" in value or "TEMP MAP" in value:
            return "Temperature Map"
        if "MEMP" in value:
            return "Thermometry MEMP"
        if any(token in value for token in ("LOCALIZER", "SCOUT", "3-PLANE")):
            return "Localizer"
        if any(token in value for token in ("PLAN", "PLANNING", "TARGET")):
            return "Planning"
        if any(token in value for token in ("DWI", "DIFFUSION", "ADC")):
            return "Diffusion"
        if "T2" in value:
            return "T2"
        if "T1" in value:
            return "T1"
        return "Other MRI"

    @staticmethod
    def _safe_series_number(ds):
        try:
            return int(getattr(ds, "SeriesNumber", 0) or 0)
        except Exception:
            return 0

    @staticmethod
    def _safe_instance_number(ds, fallback):
        try:
            return int(getattr(ds, "InstanceNumber", fallback) or fallback)
        except Exception:
            return int(fallback)

    def _capture_explorer_state(self):
        expanded = set()
        selected = []
        iterator = QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            item = iterator.value()
            data = item.data(0, Qt.UserRole)
            if data:
                key = tuple(data)
                if item.isExpanded():
                    expanded.add(key)
                if item.isSelected():
                    selected.append(key)
            iterator += 1
        return {
            "expanded": expanded,
            "selected": selected,
            "scroll": self.tree.verticalScrollBar().value(),
        }

    def _restore_explorer_state(self, state):
        selected = set(state.get("selected", []))
        first_selected = None
        iterator = QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            item = iterator.value()
            data = item.data(0, Qt.UserRole)
            key = tuple(data) if data else None
            if key in state.get("expanded", set()):
                item.setExpanded(True)
            if key in selected:
                item.setSelected(True)
                first_selected = first_selected or item
            iterator += 1

        if first_selected is not None:
            self.tree.setCurrentItem(first_selected)

        QTimer.singleShot(
            0,
            lambda: self.tree.verticalScrollBar().setValue(
                state.get("scroll", 0)
            ),
        )

    def _clear_explorer_filters(self):
        self.series_filter_combo.blockSignals(True)
        self.explorer_search_edit.blockSignals(True)
        self.explorer_type_combo.blockSignals(True)
        try:
            self.series_filter_combo.setCurrentText("All Series")
            self.explorer_search_edit.clear()
            self.explorer_type_combo.setCurrentText("All")
        finally:
            self.series_filter_combo.blockSignals(False)
            self.explorer_search_edit.blockSignals(False)
            self.explorer_type_combo.blockSignals(False)
        self._apply_explorer_filters()

    def _rebuild_explorer_preserving_state(self, *_):
        state = self._capture_explorer_state()
        self.populate_dicom_tree()
        self._restore_explorer_state(state)

    def _apply_explorer_filters(self, *_):
        series_filter = self.series_filter_combo.currentText()
        search_text = self.explorer_search_edit.text().strip().lower()
        type_filter = self.explorer_type_combo.currentText()

        def filter_item(item):
            children_visible = False
            for child_index in range(item.childCount()):
                if filter_item(item.child(child_index)):
                    children_visible = True

            data = item.data(0, Qt.UserRole)
            own_visible = True
            if data:
                kind = data[0]
                if kind == "series" and series_filter != "All Series":
                    own_visible = item.text(0) == series_filter
                elif kind == "dicom":
                    own_visible = type_filter in ("All", "DICOM")
                elif kind == "raw_file":
                    own_visible = type_filter in ("All", "RAW")
                elif kind == "bitmap_pending":
                    own_visible = type_filter in ("All", "Bitmap")
                elif str(kind).startswith("tracker"):
                    own_visible = type_filter in ("All", "Tracking")

            if search_text:
                own_visible = (
                    own_visible
                    and search_text in item.text(0).lower()
                )

            visible = own_visible or children_visible
            item.setHidden(not visible)
            return visible

        root = self.tree.invisibleRootItem()
        for index in range(root.childCount()):
            filter_item(root.child(index))

    def populate_dicom_tree(self):
        state = (
            self._capture_explorer_state()
            if self.tree.topLevelItemCount()
            else {"expanded": set(), "selected": [], "scroll": 0}
        )

        self.tree.blockSignals(True)
        try:
            self.tree.clear()
            root = QTreeWidgetItem(
                [f"DICOM Images ({len(self.dicom_entries)})"]
            )
            root.setData(0, Qt.UserRole, ("dicom_root", "all"))
            self.tree.addTopLevelItem(root)

            patients = {}
            for index, entry in enumerate(self.dicom_entries):
                ds = entry.ds
                patient_name = str(
                    getattr(ds, "PatientName", "")
                    or getattr(ds, "PatientID", "")
                    or "Unknown Patient"
                )
                patient_id = str(
                    getattr(ds, "PatientID", "") or patient_name
                )
                study_date = str(
                    getattr(ds, "StudyDate", "") or "Unknown Date"
                )
                study_description = str(
                    getattr(ds, "StudyDescription", "") or "MRI Exam"
                )
                study_uid = str(
                    getattr(ds, "StudyInstanceUID", "")
                    or f"{patient_id}:{study_date}:{study_description}"
                )
                series_number = self._safe_series_number(ds)
                series_description = str(
                    getattr(ds, "SeriesDescription", "")
                    or getattr(ds, "ProtocolName", "")
                    or "Unnamed Series"
                )
                series_uid = str(
                    getattr(ds, "SeriesInstanceUID", "")
                    or f"{study_uid}:{series_number}:{series_description}"
                )

                patients.setdefault(
                    (patient_name, patient_id), {}
                ).setdefault(
                    (study_date, study_description, study_uid), {}
                ).setdefault(
                    (series_number, series_description, series_uid), []
                ).append((index, entry))

            series_filter_labels = []

            for (patient_name, patient_id), exams in sorted(
                patients.items(),
                key=lambda item: (
                    item[0][0].lower(),
                    item[0][1].lower(),
                ),
            ):
                patient_item = QTreeWidgetItem(
                    [f"Patient: {patient_name}"]
                )
                patient_item.setData(
                    0, Qt.UserRole, ("patient", patient_id)
                )
                root.addChild(patient_item)

                for (
                    study_date,
                    study_description,
                    study_uid,
                ), series_map in sorted(
                    exams.items(),
                    key=lambda item: (
                        item[0][0],
                        item[0][1].lower(),
                    ),
                ):
                    exam_item = QTreeWidgetItem(
                        [f"Exam: {study_date} | {study_description}"]
                    )
                    exam_item.setData(
                        0, Qt.UserRole, ("exam", study_uid)
                    )
                    patient_item.addChild(exam_item)

                    for (
                        series_number,
                        series_description,
                        series_uid,
                    ), entries in sorted(
                        series_map.items(),
                        key=lambda item: (
                            item[0][0],
                            item[0][1].lower(),
                        ),
                    ):
                        prefix = (
                            f"Series {series_number:02d}"
                            if series_number
                            else "Series —"
                        )
                        label = (
                            f"{prefix} | {series_description} | "
                            f"{len(entries)} images"
                        )
                        series_filter_labels.append(label)

                        series_item = QTreeWidgetItem([label])
                        series_item.setData(
                            0, Qt.UserRole, ("series", series_uid)
                        )
                        exam_item.addChild(series_item)

                        entries.sort(
                            key=lambda pair: (
                                self._safe_instance_number(
                                    pair[1].ds,
                                    pair[0] + 1,
                                ),
                                pair[1].path.name.lower(),
                            )
                        )

                        for index, entry in entries:
                            instance = self._safe_instance_number(
                                entry.ds,
                                index + 1,
                            )
                            image_item = QTreeWidgetItem(
                                [f"{entry.path.name}    Inst {instance}"]
                            )
                            image_item.setData(
                                0, Qt.UserRole, ("dicom", index)
                            )
                            image_item.setFlags(
                                image_item.flags()
                                | Qt.ItemIsUserCheckable
                                | Qt.ItemIsSelectable
                                | Qt.ItemIsEnabled
                            )
                            image_item.setCheckState(0, Qt.Unchecked)
                            series_item.addChild(image_item)

                        series_item.setExpanded(False)

                    exam_item.setExpanded(True)

                patient_item.setExpanded(True)

            root.setExpanded(True)

            previous = self.series_filter_combo.currentText()
            self.series_filter_combo.blockSignals(True)
            self.series_filter_combo.clear()
            self.series_filter_combo.addItem("All Series")
            self.series_filter_combo.addItems(series_filter_labels)
            self.series_filter_combo.setCurrentText(
                previous
                if previous in series_filter_labels
                else "All Series"
            )
            self.series_filter_combo.blockSignals(False)

        finally:
            self.tree.blockSignals(False)

        self._restore_explorer_state(state)
        self._apply_explorer_filters()


    def show_dicom(self, index: int):
        self.stable_diagnostics.info(
            "SHOW_DICOM_BEGIN",
            index=int(index),
            entries=len(self.dicom_entries),
        )
        if not self.dicom_entries:
            return

        index = max(0, min(int(index), len(self.dicom_entries) - 1))

        try:
            entry = self._ensure_dicom_image(index)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "DICOM Load Error",
                f"Unable to load image:\n{self.dicom_entries[index].path}\n\n{exc}",
            )
            return

        self.current_image = np.asarray(entry.image).copy()
        self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)
        self.current_ds = entry.ds
        self.current_source = str(entry.path)
        self.source_kind = "dicom"
        self.raw_display_combo.setEnabled(False)
        self.slice_index = index

        self.compensation_base_image = np.asarray(self.current_image).copy()
        self.compensation_base_kspace = np.asarray(self.current_kspace).copy()
        self.compensation_history = []
        self.compensation_history_index = -1
        self.compensation_preview = None
        self._update_compensation_history_buttons()

        self.original_window_level = None
        self.original_dynamic_range = None
        if self.raw_window_level is None or self.raw_dynamic_range is None:
            self._set_levels_for_target("Raw Data", np.log1p(np.abs(self.current_kspace)))

        self.view_mode = "Both"
        self.btn_both.setChecked(True)
        self.btn_fft.setChecked(False)
        self.btn_original.setChecked(False)

        self.slice_label.setText(f"Slice: {index + 1}/{len(self.dicom_entries)}")
        self.info.setText(self.dicom_info(entry.ds, entry.path, index))
        self._select_tree_dicom_index(index)
        self._update_output_root_label()
        self.refresh_images()
        QApplication.processEvents()
        QTimer.singleShot(0, self._stabilize_layout)
        self._apply_image_orientation()
        self.stable_diagnostics.info(
            "SHOW_DICOM_END",
            state=self._stable_diagnostic_state(),
        )


    def dicom_info(self, ds, path, index):
        spacing = getattr(ds, 'PixelSpacing', ['-', '-'])
        return (f"File: {path.name}\nType: DICOM\nSize: {getattr(ds,'Columns','-')} × {getattr(ds,'Rows','-')}\n"
                f"Bit Depth: {getattr(ds,'BitsAllocated','-')} bit\nPixel Spacing: {spacing}\n"
                f"Series: {getattr(ds,'SeriesDescription','-')}\nInstance: {index+1}/{len(self.dicom_entries)}\n"
                f"TE / TR: {getattr(ds,'EchoTime','-')} / {getattr(ds,'RepetitionTime','-')} ms")

    def change_slice(self, delta):
        if self.dicom_entries: self.show_dicom(getattr(self, 'slice_index', 0) + delta)

    def looks_tracker(self, p: Path) -> bool:
        n = p.name.lower()
        if 'trackerimg' in n or 'pfile' in n: return True
        if p.suffix == '' and p.stat().st_size > 4096:
            try:
                rev = np.frombuffer(p.read_bytes()[:4], dtype='<f4')[0]
                return np.isfinite(rev) and 1 < rev < 100
            except Exception: return False
        return False

    def show_tracker_in_workspace(self):
        if self.tracker_matrix is None:
            QMessageBox.information(self, "Tracker", "Load a Tracker file first.")
            return
        self.workspace_source_combo.setCurrentText("Tracker Raw Magnitude")
        self.current_kspace = np.asarray(self.tracker_matrix).copy()
        self.current_recon = ifft2c(self.current_kspace)
        self.current_image = np.abs(self.current_recon)
        self.current_source = str(self.tracker_source_path or "Tracker")
        self.tabs.setCurrentIndex(0)
        self.refresh_images()

    def _capture_tracker_state(self, path: Path, matrix: np.ndarray, matrix_size: int, offset: int):
        magnitude = np.abs(matrix).astype(np.float64)
        metrics=[]
        for i,line in enumerate(magnitude):
            metrics.append({"line":i,"peak":float(np.max(line)),"rms":float(np.sqrt(np.mean(line**2))),"energy":float(np.sum(line**2)),"mean":float(np.mean(line)),"variance":float(np.var(line)),"relative":0.0})
        rms=np.array([m["rms"] for m in metrics],float); lo=float(np.min(rms)); hi=float(np.max(rms)); span=max(hi-lo,np.finfo(float).eps)
        for m in metrics: m["relative"]=100.0*(m["rms"]-lo)/span
        strongest=max(metrics,key=lambda m:m["rms"]); idx=int(strongest["line"])
        return {"path":path,"matrix":np.asarray(matrix).copy(),"matrix_size":matrix_size,"offset":offset,"line_metrics":metrics,"strongest_line_index":idx,"strongest_line":np.asarray(matrix[idx]).copy(),"reconstructed_image":np.abs(ifft2c(matrix))}

    def _apply_tracker_state(self, index: int):
        if not (0 <= index < len(self.tracker_files)): return
        self.tracker_file_index=index; s=self.tracker_files[index]
        self.tracker_source_path=s["path"]; self.tracker_matrix=np.asarray(s["matrix"]).copy(); self.tracker_line_metrics=list(s["line_metrics"])
        self.tracker_strongest_line_index=int(s["strongest_line_index"]); self.tracker_strongest_line=np.asarray(s["strongest_line"]).copy(); self.tracker_reconstructed_image=np.asarray(s["reconstructed_image"]).copy(); self.tracker_shared_name=s["path"].name; self.tracker_selected_lines=[self.tracker_strongest_line_index]
        self.tracker_file_combo.blockSignals(True); self.tracker_file_combo.clear(); self.tracker_file_combo.addItems([x["path"].name for x in self.tracker_files]); self.tracker_file_combo.setCurrentIndex(index); self.tracker_file_combo.blockSignals(False)
        self._refresh_tracker_ranking(); self._plot_tracker_selected_lines(); self._update_tracker_navigation_buttons()
        self.tracker_summary.setText(f"{s['path'].name} | {index+1}/{len(self.tracker_files)} | Matrix {s['matrix_size']} × {s['matrix_size']} | Strongest line {self.tracker_strongest_line_index}")
        signal_name=f"{s['path'].name} | Strongest line {self.tracker_strongest_line_index}"
        self.signals=[x for x in self.signals if not str(x.get('name','')).startswith(f"{s['path'].name} | Strongest line")]
        self.signals.append({"name":signal_name,"data":self.tracker_strongest_line.copy()}); self.signal_combo.clear(); self.signal_combo.addItems([x["name"] for x in self.signals])
        if self.workspace_source_combo.currentText().startswith("Tracker"): self.change_workspace_source(self.workspace_source_combo.currentText())

    def _update_tracker_navigation_buttons(self):
        has=bool(self.tracker_files)
        self.tracker_prev_file_button.setEnabled(has and self.tracker_file_index>0); self.tracker_next_file_button.setEnabled(has and self.tracker_file_index<len(self.tracker_files)-1); self.tracker_clear_current_button.setEnabled(has); self.tracker_clear_all_button.setEnabled(has)

    def select_tracker_file_index(self, index:int):
        if 0 <= index < len(self.tracker_files): self._apply_tracker_state(index)

    def navigate_tracker_file(self, step:int):
        target=self.tracker_file_index+int(step)
        if 0 <= target < len(self.tracker_files): self._apply_tracker_state(target)

    def clear_current_tracker(self):
        if not self.tracker_files: return
        if QMessageBox.question(self,"Clear Tracker",f"Remove current Tracker file?\n{self.tracker_files[self.tracker_file_index]['path'].name}") != QMessageBox.Yes: return
        self.tracker_files.pop(self.tracker_file_index)
        if self.tracker_files: self._apply_tracker_state(min(self.tracker_file_index,len(self.tracker_files)-1))
        else: self._reset_tracker_state()

    def clear_all_trackers(self):
        if not self.tracker_files: return
        if QMessageBox.question(self,"Clear All Trackers","Clear all imported Tracker files?") != QMessageBox.Yes: return
        self.tracker_files.clear(); self._reset_tracker_state()

    def _reset_tracker_state(self):
        self.tracker_file_index=-1; self.tracker_matrix=None; self.tracker_source_path=None; self.tracker_line_metrics=[]; self.tracker_selected_lines=[]; self.tracker_strongest_line=None; self.tracker_strongest_line_index=-1; self.tracker_reconstructed_image=None; self.tracker_shared_name=""
        self.tracker_file_combo.clear(); self.tracker_table.setRowCount(0); self.tracker_raw_plot.clear(); self.tracker_summary.setText("No Tracker file loaded."); self.tracker_metrics_label.setText("-"); self._update_tracker_navigation_buttons()

    def keyPressEvent(self, event):
        if self.tabs.currentIndex() in (3,4,5,6,7):
            if event.key()==Qt.Key_Left: self.navigate_tracker_file(-1); event.accept(); return
            if event.key()==Qt.Key_Right: self.navigate_tracker_file(1); event.accept(); return
        super().keyPressEvent(event)

    def load_tracker(self, path: Path):
        raw = path.read_bytes()
        best = None

        for matrix in (512, 384, 320, 256, 192, 160, 128, 96, 64):
            need = matrix * matrix * 4
            if len(raw) < need:
                continue

            offset = len(raw) - need
            vals = np.frombuffer(
                raw,
                dtype="<i2",
                count=matrix * matrix * 2,
                offset=offset,
            )
            complex_data = (
                vals[0::2].astype(float)
                + 1j * vals[1::2].astype(float)
            )
            raw_matrix = complex_data.reshape(matrix, matrix)

            line_rms = np.sqrt(np.mean(np.abs(raw_matrix) ** 2, axis=1))
            score = float(
                np.percentile(line_rms, 99)
                / (np.median(line_rms) + 1e-9)
            )
            if best is None or score > best[0]:
                best = (score, matrix, offset, raw_matrix)

        if best is None:
            raise ValueError("No Tracker matrix candidate found")

        _, matrix, offset, raw_matrix = best
        state = self._capture_tracker_state(
            path, raw_matrix, matrix, offset
        )

        txt_path = path.with_suffix(".txt")
        if txt_path.exists():
            state["analysis_text"] = txt_path.read_text(
                encoding="utf-8", errors="replace"
            )
        else:
            state["analysis_text"] = ""

        existing = next(
            (
                i for i, item in enumerate(self.tracker_files)
                if item["path"] == path
            ),
            None,
        )
        if existing is None:
            self.tracker_files.append(state)
            index = len(self.tracker_files) - 1
        else:
            self.tracker_files[existing] = state
            index = existing

        self._apply_tracker_state(index)
        self.statusBar().showMessage(
            f"Loaded Tracker {index + 1}/{len(self.tracker_files)}: {path.name}"
        )


    def load_signal_file(self, path: Path):
        if path.suffix.lower() == '.npy': arr = np.load(path, allow_pickle=False)
        elif path.suffix.lower() == '.npz':
            z = np.load(path, allow_pickle=False); arr = z[list(z.keys())[0]]
        else:
            rows=[]
            with open(path, encoding='utf-8-sig', errors='replace') as f:
                for line in f:
                    nums=[]
                    for token in line.strip().replace(';', ',').split(','):
                        try: nums.append(float(token.strip()))
                        except ValueError: pass
                    if nums: rows.append(nums)
            if not rows: return
            arr = np.array([r[0]+1j*r[1] if len(r)>1 else r[0] for r in rows])
        arr=np.asarray(arr).squeeze()
        if arr.ndim == 1: self.add_signal(arr, path.name)
        elif arr.ndim == 2:
            self.current_image = np.abs(arr); self.current_kspace = fft2c(arr); self.current_recon = ifft2c(self.current_kspace); self.refresh_images()

    def add_signal(self, signal, name):
        signal=np.asarray(signal).squeeze()
        if signal.ndim != 1 or signal.size < 2: return
        self.signals.append({'name': name, 'data': signal})
        self.active_spike_indices = np.array([], dtype=int)
        self.signal_combo.addItem(name)
        self.signal_combo.setCurrentIndex(len(self.signals)-1)
        self.update_signal_plot(); self.update_tracker_preview(signal)

    def clear_signals(self):
        self.signals.clear(); self.signal_combo.clear(); self.signal_plot.clear(); self.tracker_plot.clear()

    def update_signal_plot(self):
        self.signal_plot.clear(); idx=self.signal_combo.currentIndex()
        if idx < 0 or idx >= len(self.signals): return
        data=np.asarray(self.signals[idx]['data']); component=self.signal_component.currentText()
        if self.signal_fft.isChecked(): data=np.fft.fftshift(np.fft.fft(data)); self.signal_plot.setLabel('bottom','Frequency bin')
        else: self.signal_plot.setLabel('bottom','Sample')
        y=self.component(data, component)
        self.signal_plot.plot(y)
        if self.active_spike_indices.size:
            valid = self.active_spike_indices[self.active_spike_indices < len(y)]
            if valid.size:
                scatter = pg.ScatterPlotItem(
                    x=valid,
                    y=np.asarray(y)[valid],
                    pen=pg.mkPen("#ff3b3b"),
                    brush=pg.mkBrush("#ff3b3b"),
                    size=9,
                    symbol="x",
                )
                self.signal_plot.addItem(scatter)

    def update_tracker_preview(self, signal):
        self.tracker_plot.clear(); self.tracker_plot.plot(np.abs(np.asarray(signal)))

    def _analyze_tracker_lines(self):
        self.tracker_line_metrics = []
        if self.tracker_matrix is None:
            return

        magnitude = np.abs(self.tracker_matrix).astype(np.float64)
        for line_index, line in enumerate(magnitude):
            self.tracker_line_metrics.append({
                "line": line_index,
                "peak": float(np.max(line)),
                "rms": float(np.sqrt(np.mean(line ** 2))),
                "energy": float(np.sum(line ** 2)),
                "mean": float(np.mean(line)),
                "variance": float(np.var(line)),
                "relative": 0.0,
            })

        rms_values = np.array([item["rms"] for item in self.tracker_line_metrics], dtype=float)
        low = float(np.min(rms_values))
        high = float(np.max(rms_values))
        span = max(high - low, np.finfo(float).eps)
        for item in self.tracker_line_metrics:
            item["relative"] = 100.0 * (item["rms"] - low) / span

    def _tracker_metric_key(self) -> str:
        return {
            "Peak": "peak",
            "RMS": "rms",
            "Energy": "energy",
            "Mean magnitude": "mean",
            "Variance": "variance",
        }.get(self.tracker_metric_combo.currentText(), "peak")

    def _refresh_tracker_ranking(self):
        if not hasattr(self, "tracker_table"):
            return
        if not self.tracker_line_metrics:
            self.tracker_table.setRowCount(0)
            return

        key = self._tracker_metric_key()
        ranked = sorted(self.tracker_line_metrics, key=lambda item: item[key], reverse=True)
        ranked = ranked[: self.tracker_top_count.value()]

        self.tracker_table.blockSignals(True)
        self.tracker_table.setRowCount(len(ranked))
        for row, item in enumerate(ranked):
            values = [
                row + 1,
                item["line"],
                f'{item["peak"]:.6g}',
                f'{item["rms"]:.6g}',
                f'{item["energy"]:.6g}',
                f'{item["mean"]:.6g}',
                f'{item["variance"]:.6g}',
                f'{item["relative"]:.1f}%',
            ]
            for col, value in enumerate(values):
                table_item = QTableWidgetItem(str(value))
                table_item.setData(Qt.UserRole, item["line"])
                self.tracker_table.setItem(row, col, table_item)
        self.tracker_table.resizeColumnsToContents()
        self.tracker_table.blockSignals(False)

        if ranked:
            self.tracker_table.selectRow(0)
            self._tracker_selection_changed()

    def _tracker_selection_changed(self):
        rows = sorted({item.row() for item in self.tracker_table.selectedItems()})
        selected = []
        for row in rows:
            item = self.tracker_table.item(row, 1)
            if item is not None:
                selected.append(int(item.data(Qt.UserRole)))
        self.tracker_selected_lines = selected[:8]
        self._plot_tracker_selected_lines()

    def _tracker_component(self, line: np.ndarray) -> np.ndarray:
        mode = self.tracker_component_combo.currentText()
        if mode == "Real":
            return np.real(line)
        if mode == "Imaginary":
            return np.imag(line)
        if mode == "Phase":
            return np.angle(line)
        return np.abs(line)

    def _plot_tracker_selected_lines(self):
        if not hasattr(self, "tracker_raw_plot"):
            return
        self.tracker_raw_plot.clear()
        if self.tracker_matrix is None or not self.tracker_selected_lines:
            self.tracker_metrics_label.setText("-")
            return

        summaries = []
        for line_index in self.tracker_selected_lines:
            raw_line = self.tracker_matrix[line_index]
            values = np.asarray(self._tracker_component(raw_line), dtype=float)
            self.tracker_raw_plot.plot(values)

            metric = next(
                (item for item in self.tracker_line_metrics if item["line"] == line_index),
                None,
            )
            if metric:
                summaries.append(
                    f'Line {line_index}: Peak {metric["peak"]:.6g}, '
                    f'RMS {metric["rms"]:.6g}, Energy {metric["energy"]:.6g}'
                )
        self.tracker_metrics_label.setText(" | ".join(summaries))

    def _select_next_tracker_line(self):
        row = self.tracker_table.currentRow()
        if 0 <= row < self.tracker_table.rowCount() - 1:
            self.tracker_table.clearSelection()
            self.tracker_table.selectRow(row + 1)

    def _select_previous_tracker_line(self):
        row = self.tracker_table.currentRow()
        if row > 0:
            self.tracker_table.clearSelection()
            self.tracker_table.selectRow(row - 1)

    def export_tracker_lines_csv(self):
        if not self.tracker_line_metrics:
            QMessageBox.information(self, "Tracker Export", "Load a Tracker file first.")
            return
        filename, _ = QFileDialog.getSaveFileName(
            self, "Export Tracker Line Metrics", "tracker_line_metrics.csv", "CSV files (*.csv)"
        )
        if not filename:
            return
        if not filename.lower().endswith(".csv"):
            filename += ".csv"

        import csv
        with open(filename, "w", newline="", encoding="utf-8-sig") as stream:
            writer = csv.writer(stream)
            writer.writerow(["Line", "Peak", "RMS", "Energy", "MeanMagnitude", "Variance", "RelativeStrength"])
            for item in sorted(self.tracker_line_metrics, key=lambda value: value["line"]):
                writer.writerow([
                    item["line"], item["peak"], item["rms"], item["energy"],
                    item["mean"], item["variance"], item["relative"]
                ])
        self.statusBar().showMessage(f"Tracker metrics exported: {filename}")

    def _raw_candidate_paths(self) -> list[Path]:
        """RAW image/signal candidates; Tracking PFiles are excluded."""
        candidates = []
        seen = set()
        for path in self.imported_paths:
            if not path.exists() or not path.is_file():
                continue

            # Tracking PFile belongs only to Tracker analysis.
            if self.looks_tracker(path):
                continue

            suffix = path.suffix.lower()
            if suffix in {
                ".raw",
                ".bin",
                ".dat",
                ".pfile",
            }:
                key = str(path.resolve())
                if key not in seen:
                    candidates.append(path)
                    seen.add(key)
        return candidates


    def _robust_z(values: np.ndarray) -> np.ndarray:
        values = np.asarray(values, dtype=np.float64)
        if values.size == 0:
            return values
        median = np.nanmedian(values)
        mad = np.nanmedian(np.abs(values - median))
        scale = max(1.4826 * mad, np.finfo(float).eps)
        return np.abs(values - median) / scale

    @staticmethod
    def _group_spike_indices(indices: np.ndarray) -> list[np.ndarray]:
        indices = np.asarray(indices, dtype=int)
        if indices.size == 0:
            return []
        cuts = np.where(np.diff(indices) > 1)[0] + 1
        return [group for group in np.split(indices, cuts) if group.size]

    def _extract_tracker_signal(self, path: Path) -> tuple[np.ndarray, str]:
        raw = path.read_bytes()
        best = None
        for matrix in (512, 384, 320, 256, 192, 160, 128, 96, 64):
            need = matrix * matrix * 4
            if len(raw) < need:
                continue
            offset = len(raw) - need
            vals = np.frombuffer(raw, dtype="<i2", count=matrix * matrix * 2, offset=offset)
            signal = vals[0::2].astype(np.float64) + 1j * vals[1::2].astype(np.float64)
            image = ifft2c(signal.reshape(matrix, matrix))
            contrast = np.percentile(np.abs(image), 99) / (np.median(np.abs(image)) + 1e-9)
            if best is None or contrast > best[0]:
                best = (contrast, signal, f"Tracker complex int16 {matrix}x{matrix}, offset {offset}")
        if best is None:
            raise ValueError("No valid Tracker complex matrix candidate")
        return best[1], best[2]

    def _extract_generic_raw_signal(self, path: Path) -> tuple[np.ndarray, str]:
        # Limit analysis memory while retaining enough data for spike screening.
        max_bytes = 32 * 1024 * 1024
        size = path.stat().st_size
        offset = max(0, size - max_bytes)
        if offset % 2:
            offset += 1
        with open(path, "rb") as stream:
            stream.seek(offset)
            raw = np.fromfile(stream, dtype="<i2")
        if raw.size < 8:
            raise ValueError("Not enough int16 samples")
        # Treat even/odd pairs as complex when possible. Magnitude analysis is
        # resistant to phase rotation and works for many MRI raw layouts.
        if raw.size >= 16 and raw.size % 2 == 0:
            signal = raw[0::2].astype(np.float64) + 1j * raw[1::2].astype(np.float64)
            description = f"Generic complex int16 tail, byte offset {offset}"
        else:
            signal = raw.astype(np.float64)
            description = f"Generic real int16 tail, byte offset {offset}"
        return signal, description

    def _analyze_spike_signal(self, signal: np.ndarray, threshold: float) -> dict:
        signal = np.asarray(signal).squeeze()
        magnitude = np.abs(signal).astype(np.float64)
        finite = np.isfinite(magnitude)
        if magnitude.size < 8 or not np.any(finite):
            raise ValueError("Signal has insufficient valid samples")
        replacement = np.nanmedian(magnitude[finite])
        magnitude = np.where(finite, magnitude, replacement)

        amplitude_z = self._robust_z(magnitude)
        first_difference = np.abs(np.diff(magnitude, prepend=magnitude[0]))
        difference_z = self._robust_z(first_difference)

        combined = np.maximum(amplitude_z, difference_z)
        raw_indices = np.flatnonzero(combined >= threshold)
        groups = self._group_spike_indices(raw_indices)

        # Represent each consecutive group by its strongest sample.
        representatives = []
        for group in groups:
            representatives.append(int(group[np.argmax(combined[group])]))
        representatives = np.asarray(representatives, dtype=int)

        strongest = int(np.argmax(combined))
        score = float(combined[strongest])
        return {
            "score": score,
            "flagged": bool(representatives.size and score >= threshold),
            "indices": representatives,
            "groups": len(groups),
            "strongest": strongest,
            "samples": int(magnitude.size),
        }

    def _selected_dicom_indices(self):
        indices = set()
        iterator = QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            item = iterator.value()
            data = item.data(0, Qt.UserRole)
            if data and data[0] == "dicom":
                if item.isSelected() or item.checkState(0) == Qt.Checked:
                    indices.add(int(data[1]))
            iterator += 1
        if not indices and self.dicom_entries:
            indices.add(int(getattr(self, "slice_index", 0)))
        return sorted(indices)


    def _spike_range_percent(self):
        mapping = {"Large": 100, "Mid": 70, "Small": 40}
        if self.spike_range_combo.currentText() == "Scale":
            return int(self.spike_scale_slider.value())
        return mapping.get(self.spike_range_combo.currentText(), 100)

    def _suppress_image_spikes(self, image: np.ndarray):
        source = np.asarray(image, dtype=float)
        kspace = fft2c(source)
        magnitude = np.abs(kspace)
        rows, cols = magnitude.shape
        cy, cx = rows // 2, cols // 2

        area_fraction = max(
            min(self._spike_range_percent() / 100.0, 1.0),
            0.10,
        )
        side_fraction = np.sqrt(area_fraction)
        half_h = max(4, int(rows * side_fraction / 2.0))
        half_w = max(4, int(cols * side_fraction / 2.0))
        y0, y1 = max(1, cy - half_h), min(rows - 1, cy + half_h)
        x0, x1 = max(1, cx - half_w), min(cols - 1, cx + half_w)

        valid = np.zeros_like(magnitude, dtype=bool)
        valid[y0:y1, x0:x1] = True
        cross_width = max(2, int(min(rows, cols) * 0.018))
        center_radius = max(4, int(min(rows, cols) * 0.04))
        yy, xx = np.ogrid[:rows, :cols]
        valid &= np.abs(yy - cy) > cross_width
        valid &= np.abs(xx - cx) > cross_width
        valid &= ((yy - cy) ** 2 + (xx - cx) ** 2) > center_radius ** 2

        raw_features = self._raw_spike_features(magnitude, valid)
        coords = raw_features["candidate_coords"]

        level_limits = {
            "Wide": (10.0, 40),
            "Mid": (7.5, 140),
            "Fine": (5.5, 360),
        }
        minimum_z, maximum_candidates = level_limits.get(
            self.spike_level_combo.currentText(),
            (7.5, 140),
        )

        if coords.size:
            scores = np.array([
                raw_features["local_z"][y, x]
                + 0.5 * raw_features["global_z"][y, x]
                for y, x in coords
            ])
            keep = scores >= minimum_z
            coords = coords[keep]
            scores = scores[keep]
            order = np.argsort(scores)[::-1]
            coords = coords[order[:maximum_candidates]]

        corrected = kspace.copy()
        candidates = []
        corrected_set = set()

        def replacement_value(y: int, x: int):
            radius = 2
            ya, yb = max(0, y - radius), min(rows, y + radius + 1)
            xa, xb = max(0, x - radius), min(cols, x + radius + 1)
            patch = corrected[ya:yb, xa:xb]
            patch_mag = np.abs(patch)
            threshold = np.percentile(patch_mag, 65)
            values = patch[patch_mag <= threshold]
            if values.size < 4:
                values = patch.reshape(-1)
            return (
                np.median(np.real(values))
                + 1j * np.median(np.imag(values))
            )

        for y, x in coords:
            y, x = int(y), int(x)
            if (y, x) in corrected_set:
                continue
            corrected[y, x] = replacement_value(y, x)
            candidates.append((y, x))
            corrected_set.add((y, x))

            sy = (2 * cy - y) % rows
            sx = (2 * cx - x) % cols
            if valid[sy, sx] and (sy, sx) not in corrected_set:
                corrected[sy, sx] = replacement_value(sy, sx)
                candidates.append((int(sy), int(sx)))
                corrected_set.add((int(sy), int(sx)))

        result = np.abs(ifft2c(corrected))
        if not candidates:
            return source.copy(), kspace, kspace.copy(), []

        before_features = self._image_stripe_features(source)
        after_features = self._image_stripe_features(result)
        before_score = (
            before_features["stripe_strength"]
            + before_features["diagonal_strength"]
        )
        after_score = (
            after_features["stripe_strength"]
            + after_features["diagonal_strength"]
        )
        improvement = before_score - after_score

        # Heavy multi-spike images can show modest stripe-score improvement on a
        # single pass, so multiple strong isolated points are sufficient evidence.
        detected = (
            improvement > 0.35
            or len(candidates) >= 4
            or raw_features["max_local_z"] >= 12.0
        )
        if not detected:
            return source.copy(), kspace, kspace.copy(), []

        return result, kspace, corrected, candidates


    def apply_spike_processing(self):
        dicom_indices = self._selected_dicom_indices()
        if not dicom_indices:
            # No original image selection: use existing RAW/PFile diagnostic.
            self.detect_spikes()
            return

        progress = self._make_progress("Spike Processing", len(dicom_indices))
        processed = []
        try:
            for number, index in enumerate(dicom_indices, start=1):
                if progress.wasCanceled():
                    return
                entry = self._ensure_dicom_image(index)
                progress.setLabelText(
                    f"Detecting repeated stripes and k-space spikes {number}/{len(dicom_indices)}: {entry.path.name}"
                )
                QApplication.processEvents()

                stripe_info = self._extract_stripe_only(entry.image)
                actual_raw = fft2c(np.asarray(entry.image, dtype=float))
                raw_mapping = self._map_stripe_to_raw(stripe_info, actual_raw)
                corrected, raw_before, raw_after, candidates = self._suppress_image_spikes(entry.image)
                if candidates and raw_mapping["agreement"] > 0.0:
                    self.current_ds = entry.ds
                    self.current_source = str(entry.path)
                    output = self._save_processed_image(
                        corrected,
                        f"{entry.path.stem}_NS",
                        "_NS",
                    )
                    processed.append({
                        "index": index,
                        "path": entry.path,
                        "output": output,
                        "original": np.asarray(entry.image).copy(),
                        "corrected": corrected,
                        "raw_before": raw_before,
                        "raw_after": raw_after,
                        "candidates": candidates,
                        "stripe_only": stripe_info["stripe_only"],
                        "raw_candidate": raw_mapping["candidate_image"],
                        "stripe_groups": stripe_info["groups"],
                        "raw_agreement": float(raw_mapping["agreement"]),
                        "matched_raw_count": int(len(raw_mapping["matched_coords"])),
                    })
                progress.setValue(number)
        finally:
            progress.close()

        if not processed:
            QMessageBox.information(self, "Spike Processing", "No Spike")
            return

        self.spike_image_results = processed
        last = processed[-1]
        self._display_processed_result(last["corrected"], last["output"])
        self._refresh_spike_diag()
        self.tabs.setCurrentIndex(1)
        self._schedule_responsive_layout()
        QMessageBox.information(
            self,
            "Spike Processing",
            f"Processed {len(dicom_indices)} image(s).\n"
            f"Spike corrected: {len(processed)} image(s).",
        )

    def _refresh_spike_diag(self):
        self.spike_result_list.clear()
        results = getattr(self, "spike_image_results", [])
        for index, result in enumerate(results):
            item = QTreeWidgetItem([result["path"].name])
            item.setData(0, Qt.UserRole, index)
            self.spike_result_list.addTopLevelItem(item)
        self.spike_result_summary.setText(
            f"Processed: {len(results)} | Corrected: {len(results)}"
        )
        if results:
            item = self.spike_result_list.topLevelItem(len(results)-1)
            self.spike_result_list.setCurrentItem(item)
            self._show_spike_result(len(results)-1)

    def _spike_result_selected(self, item, column):
        index = item.data(0, Qt.UserRole)
        if index is not None:
            self._show_spike_result(int(index))

    def _show_spike_result(self, index: int):
        results=getattr(self,"spike_image_results",[])
        if not (0<=index<len(results)): return
        result=results[index]; self.current_spike_result_index=index
        self.spike_original_panel.set_image(result["original"])
        self.spike_stripe_panel.set_image(result.get("stripe_only",np.zeros_like(result["original"])))
        self.spike_raw_candidate_panel.set_image(result.get("raw_candidate",np.zeros_like(result["original"])))
        self.spike_corrected_panel.set_image(result["corrected"])
        self.spike_raw_before_panel.set_image(np.log1p(np.abs(result["raw_before"])))
        self.spike_raw_after_panel.set_image(np.log1p(np.abs(result["raw_after"])))
        for y,x in result["candidates"]:
            self.spike_raw_before_panel.plot.addItem(pg.ScatterPlotItem([x],[y],symbol="o",size=14,pen=pg.mkPen("r",width=2),brush=pg.mkBrush(255,0,0,20)))
        groups=result.get("stripe_groups",[])
        details=[f"Raw agreement: {result.get('raw_agreement',0.0):.3f}",f"Matched raw peaks: {result.get('matched_raw_count',0)}",f"Stripe groups: {len(groups)}"]
        for n,g in enumerate(groups[:12],1): details.append(f"G{n}: angle {g['angle']:.1f}°, {g['scale']}, peak z {g['peak_z']:.1f}, points {g['points']}")
        if len(groups)>12: details.append(f"... {len(groups)-12} additional groups")
        if hasattr(self,"spike_developer_text"): self.spike_developer_text.setPlainText("\n".join(details))


    def save_current_spike_result(self):
        results = getattr(self, "spike_image_results", [])
        index = getattr(self, "current_spike_result_index", -1)
        if not (0 <= index < len(results)):
            return
        result = results[index]
        self.current_ds = self.dicom_entries[result["index"]].ds
        self.current_source = str(result["path"])
        output = self._save_processed_image(
            result["corrected"], f"{result['path'].stem}_NS", "_NS"
        )
        QMessageBox.information(self, "Spike Diag", f"Saved:\n{output}")

    def detect_spikes(self):
        candidates = self._raw_candidate_paths()
        if not candidates:
            QMessageBox.information(
                self,
                "Spike Detection",
                "No supported RAW, BIN, DAT, or non-tracking PFile is imported. "
                "Drop a file or folder first.",
            )
            return

        threshold = float(self.spike_threshold.value())
        progress = self._make_progress("Detecting Spike Noise", len(candidates))
        results = []
        try:
            for index, path in enumerate(candidates, start=1):
                if not self._progress_step(
                    progress,
                    index - 1,
                    f"Analyzing {index}/{len(candidates)}: {path.name}",
                ):
                    self.statusBar().showMessage("Spike detection canceled")
                    return
                try:
                    if self.looks_tracker(path):
                        signal, source_type = self._extract_tracker_signal(path)
                    else:
                        signal, source_type = self._extract_generic_raw_signal(path)
                    analysis = self._analyze_spike_signal(signal, threshold)
                    analysis.update({
                        "path": path,
                        "name": path.name,
                        "type": source_type,
                        "signal": signal,
                        "error": "",
                    })
                except Exception as exc:
                    analysis = {
                        "path": path,
                        "name": path.name,
                        "type": "Unreadable",
                        "signal": np.array([], dtype=float),
                        "score": 0.0,
                        "flagged": False,
                        "indices": np.array([], dtype=int),
                        "groups": 0,
                        "strongest": -1,
                        "samples": 0,
                        "error": str(exc),
                    }
                results.append(analysis)
                progress.setValue(index)
        finally:
            progress.close()

        self.spike_results = sorted(results, key=lambda item: item["score"], reverse=True)
        self._refresh_spike_table()
        flagged = sum(1 for item in results if item["flagged"])
        errors = sum(1 for item in results if item["error"])
        self.spike_summary.setText(
            f"Scanned {len(results)} raw file(s) at robust threshold {threshold:.1f}. "
            f"Spike candidates: {flagged}. Read errors: {errors}."
        )
        self.tabs.setCurrentIndex(1)
        self.statusBar().showMessage(f"Spike detection complete: {flagged}/{len(results)} flagged")

    def _refresh_spike_table(self):
        if not hasattr(self, "spike_table"):
            return
        show_flagged = self.spike_only_flagged.isChecked()
        rows = [
            result for result in self.spike_results
            if (result["flagged"] or not show_flagged)
        ]
        self.spike_table.setSortingEnabled(False)
        self.spike_table.setRowCount(len(rows))
        for row, result in enumerate(rows):
            status = "SPIKE" if result["flagged"] else ("ERROR" if result["error"] else "OK")
            values = [
                status,
                result["name"],
                result["type"],
                f'{result["score"]:.2f}',
                str(result["groups"]),
                str(result["strongest"]) if result["strongest"] >= 0 else "-",
                str(result["samples"]),
                str(result["path"]),
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                item.setData(Qt.UserRole, result)
                if status == "SPIKE":
                    item.setBackground(pg.mkColor("#7a2430"))
                elif status == "ERROR":
                    item.setBackground(pg.mkColor("#6a5520"))
                self.spike_table.setItem(row, col, item)
        self.spike_table.setSortingEnabled(True)
        self.spike_table.resizeColumnsToContents()

    def _open_spike_result(self, row: int, column: int):
        item = self.spike_table.item(row, 0)
        if item is None:
            return
        result = item.data(Qt.UserRole)
        if not result or result["signal"].size < 2:
            if result and result["error"]:
                QMessageBox.warning(self, "Spike Result", result["error"])
            return

        name = f'Spike scan: {result["name"]}'
        self.signals.append({"name": name, "data": result["signal"]})
        self.signal_combo.addItem(name)
        self.signal_combo.setCurrentIndex(len(self.signals) - 1)
        self.active_spike_indices = np.asarray(result["indices"], dtype=int)
        self.signal_fft.setChecked(False)
        self.signal_component.setCurrentText("Magnitude")
        self.update_signal_plot()
        self.update_tracker_preview(result["signal"])
        self.tabs.setCurrentIndex(1)
        self.statusBar().showMessage(
            f'Opened {result["name"]}: {len(self.active_spike_indices)} spike group(s)'
        )

    @staticmethod
    def _position_plane_index(name: str) -> int:
        return {"Axial": 0, "Coronal": 1, "Sagittal": 2}.get(name, 0)

    def populate_position_top_lines(self):
        if self.tracker_matrix is None or not self.tracker_line_metrics:
            QMessageBox.information(self, "Tracker Position", "Load a Tracker PFile / TrackerImg first.")
            return

        ranked = sorted(self.tracker_line_metrics, key=lambda item: item["rms"], reverse=True)[:3]
        for row, metric in enumerate(ranked):
            self.position_table.setItem(row, 0, QTableWidgetItem(str(metric["line"])))
        self.tabs.setCurrentIndex(4)
        self.statusBar().showMessage("Top three Tracker lines assigned to position conversion.")

    def calculate_tracker_position(self):
        if self.tracker_matrix is None:
            QMessageBox.information(self, "Tracker Position", "Load a Tracker file first.")
            return

        fft_length = int(self.position_fft_length.value())
        fov = float(self.position_fov.value())
        measurements = []

        try:
            for row in range(self.position_table.rowCount()):
                use_widget = self.position_table.cellWidget(row, 6)
                if use_widget is not None and not use_widget.isChecked():
                    continue

                line_item = self.position_table.item(row, 0)
                if line_item is None:
                    continue
                line_index = int(line_item.text())
                if line_index < 0 or line_index >= self.tracker_matrix.shape[0]:
                    raise ValueError(f"Line {line_index} is outside the available range.")

                plane_widget = self.position_table.cellWidget(row, 1)
                rotation_widget = self.position_table.cellWidget(row, 2)
                plane = self._position_plane_index(plane_widget.currentText())
                rotation_deg = float(rotation_widget.value())

                peak_bin, coordinate_mm, snr_like, spectrum = signal_peak_coordinate(
                    self.tracker_matrix[line_index],
                    fft_length=fft_length,
                    fov_mm=fov,
                )
                measurement = DirectionMeasurement(
                    line_index=line_index,
                    plane=plane,
                    rotation_deg=rotation_deg,
                    peak_bin=peak_bin,
                    coordinate_mm=coordinate_mm,
                    snr_like=snr_like,
                )
                measurements.append(measurement)

                self.position_table.setItem(row, 3, QTableWidgetItem(f"{peak_bin:.4f}"))
                self.position_table.setItem(row, 4, QTableWidgetItem(f"{coordinate_mm:.4f}"))
                self.position_table.setItem(row, 5, QTableWidgetItem(f"{snr_like:.3f}"))

            offset = np.array([
                self.position_offset_x.value(),
                self.position_offset_y.value(),
                self.position_offset_z.value(),
            ], dtype=float)

            scanner_xyz, pqr, rms_error = solve_position(
                measurements,
                center_offset=offset,
                oppose_ap=self.position_oppose_ap.isChecked(),
            )
            self.tracker_position_measurements = measurements
            self.position_result.setText(
                f"Coordinates MR / Scanner (mm):\n"
                f"  X = {scanner_xyz[0]:.4f}\n"
                f"  Y = {scanner_xyz[1]:.4f}\n"
                f"  Z = {scanner_xyz[2]:.4f}\n\n"
                f"Coordinates PQR (mm):\n"
                f"  P = {pqr[0]:.4f}\n"
                f"  Q = {pqr[1]:.4f}\n"
                f"  R = {pqr[2]:.4f}\n\n"
                f"Projection RMS residual = {rms_error:.5f} mm\n"
                f"Gradient-map correction = Not applied"
            )
            self.statusBar().showMessage("Tracker position conversion completed.")
        except Exception as exc:
            QMessageBox.critical(self, "Tracker Position Error", str(exc))

    def component(self, arr, mode):
        if mode == 'Real': return np.real(arr)
        if mode == 'Imaginary': return np.imag(arr)
        if mode == 'Phase': return np.angle(arr)
        return np.abs(arr)

    def change_workspace_source(self, source_name: str):
        if source_name == "Tracker Raw Magnitude":
            if self.tracker_matrix is None:
                return
            self.current_kspace = np.asarray(self.tracker_matrix).copy()
            self.current_recon = ifft2c(self.current_kspace)
            self.current_image = np.abs(self.current_recon)
            self.current_source = str(self.tracker_source_path or "Tracker")
        elif source_name == "Tracker Reconstructed":
            if self.tracker_reconstructed_image is None:
                return
            self.current_image = np.asarray(self.tracker_reconstructed_image).copy()
            self.current_kspace = fft2c(self.current_image)
            self.current_recon = ifft2c(self.current_kspace)
            self.current_source = str(self.tracker_source_path or "Tracker")
        self.refresh_images()

    def send_tracker_to_signal_studio(self):
        if self.tracker_strongest_line is None:
            QMessageBox.information(self, "Tracker", "Load a Tracker file first.")
            return
        name = f"{self.tracker_shared_name} | Strongest line {self.tracker_strongest_line_index}"
        existing = next((i for i, item in enumerate(self.signals) if item.get("name") == name), None)
        if existing is None:
            self.add_signal(np.asarray(self.tracker_strongest_line).copy(), name)
            existing = len(self.signals) - 1
        self.signal_combo.setCurrentIndex(existing)
        self.signal_component.setCurrentText("Magnitude")
        self.signal_fft.setChecked(False)
        self.tabs.setCurrentIndex(1)
        self.update_signal_plot()

    def preview_tracker_in_artifact_learning(self):
        if self.tracker_matrix is None:
            QMessageBox.information(self, "Artifact Learning", "Load a Tracker file first.")
            return
        image = np.log1p(np.abs(self.tracker_matrix))
        self.artifact_preview_panel.label.setText(
            f"Tracker Raw Magnitude: {self.tracker_shared_name}"
        )
        self.artifact_preview_panel.set_image(image)
        self.artifact_selection_label.setText(
            f"Tracker data ready for learning: {self.tracker_shared_name}"
        )

    def save_tracker_training_sample(self):
        if self.tracker_matrix is None or self.tracker_source_path is None:
            QMessageBox.information(self, "Artifact Learning", "Load a Tracker file first.")
            return
        if not self._ensure_artifact_database():
            return
        artifact_type = self.artifact_type_combo.currentText().strip() or "Not Artifact"
        resolution = self.artifact_resolution_combo.currentText().strip()
        notes = self.artifact_notes.toPlainText().strip()
        tracker_image = np.log1p(np.abs(self.tracker_matrix))
        features = image_features(tracker_image, self.normal_reference_image)
        features.update({
            "data_type": "Tracker Raw",
            "strongest_line": self.tracker_strongest_line_index,
            "line_peak": float(np.max(np.abs(self.tracker_strongest_line))) if self.tracker_strongest_line is not None else 0.0,
            "line_rms": float(np.sqrt(np.mean(np.abs(self.tracker_strongest_line) ** 2))) if self.tracker_strongest_line is not None else 0.0,
        })
        self.artifact_db.add_sample(
            source_path=str(self.tracker_source_path),
            source_name=self.tracker_source_path.name,
            series_uid="TRACKER",
            series_description="Tracker Raw Data",
            instance_number=self.tracker_strongest_line_index,
            artifact_type=artifact_type,
            resolution=resolution,
            is_normal_reference=False,
            normal_reference_path=str(self.normal_reference_path or ""),
            features=features,
            notes=notes,
        )
        self.refresh_artifact_training_table()
        self.artifact_summary.setText(
            f"Saved Tracker training sample as '{artifact_type}'."
        )

    def detect_tracker_artifact_from_db(self):
        if self.tracker_matrix is None:
            QMessageBox.information(self, "Artifact Detection", "Load a Tracker file first.")
            return
        if not self._ensure_artifact_database():
            return
        keys, training, labels, metadata = self.artifact_db.training_feature_vectors()
        tracker_image = np.log1p(np.abs(self.tracker_matrix))
        features = image_features(tracker_image, self.normal_reference_image)
        features.update({
            "data_type": "Tracker Raw",
            "strongest_line": self.tracker_strongest_line_index,
        })
        vector = features_to_vector(features, keys)
        result = classify_feature_vector(
            vector, training, labels,
            minimum_samples_per_class=self.detect_min_samples.value(),
        )
        self.artifact_detection_table.setRowCount(1)
        alternatives = ", ".join(
            f"{label} {confidence * 100:.1f}%"
            for label, confidence, distance, support in result.alternatives[1:4]
        )
        values = [
            self.tracker_source_path.name if self.tracker_source_path else "Tracker",
            "Tracker Raw Data",
            result.label,
            f"{result.confidence * 100:.1f}%",
            f"{result.distance:.4f}" if np.isfinite(result.distance) else "-",
            result.support,
            result.status,
            alternatives,
            str(self.tracker_source_path or ""),
        ]
        for column, value in enumerate(values):
            self.artifact_detection_table.setItem(0, column, QTableWidgetItem(str(value)))
        self.artifact_detection_summary.setText(
            f"Tracker prediction: {result.label} | Confidence {result.confidence * 100:.1f}%"
        )
        self.tabs.setCurrentIndex(2)

    def _image_mouse_action_changed(self, action: str):
        if action == "Auto Window/Level":
            self.auto_levels()
            self.statusBar().showMessage("Window/Level recalculated automatically")
            return
        self.current_mouse_action = action
        self.primary_panel.mouse_action = action
        self.secondary_panel.mouse_action = action
        self.mouse_action_label.setText(f"Mouse: {action}")
        tooltips = {
            "Window/Level": "Wheel: Level\nCtrl+Wheel: Width",
            "Pan": "Left-drag: Pan",
            "Zoom": "Drag a rectangle: Zoom",
            "Paging": "Mouse wheel: Previous / Next image",
            "ROI": "Drag corners: resize ROI",
        }
        self.mouse_action_label.setToolTip(tooltips.get(action, action))
        if action == "ROI":
            if self.current_kspace is not None and self.source_kind != "bitmap":
                self.primary_panel.show_comp_roi()
            else:
                self.statusBar().showMessage("ROI requires raw/k-space data")
        self.statusBar().showMessage(f"Mouse action selected: {action}")


    def _image_view_requested(self, mode: str):
        if mode == "FFT_CURRENT":
            if self.current_image is None:
                return
            self.fft_back_image = np.asarray(self.current_image).copy()
            self.current_kspace = fft2c(np.asarray(self.current_image, dtype=float))
            self.current_recon = ifft2c(self.current_kspace)
            self.raw_window_level = None
            self.raw_dynamic_range = None
            self.fft_view_active = True
            fft_image = np.log1p(np.abs(self.current_kspace))
            self.primary_panel.label.setText("FFT Current Image")
            self.primary_panel.set_image(
                fft_image,
                levels=self._levels_for_target("Raw Data", fft_image, auto_original=False),
            )
            self.secondary_panel.hide()
            self.view_mode = "FFT"
            self.statusBar().showMessage("FFT calculated and displayed in the current panel")
            return
        if mode == "BACK_FFT":
            if self.fft_back_image is not None:
                self.current_image = np.asarray(self.fft_back_image).copy()
                self.current_kspace = fft2c(self.current_image)
                self.current_recon = ifft2c(self.current_kspace)
            self.fft_view_active = False
            self.fft_back_image = None
            self.set_view_mode("Original")
            self.statusBar().showMessage("Returned to the image before FFT")
            return
        if mode == "Default":
            self.profile_mode.setCurrentText("Magnitude")
            self.level_target_combo.setCurrentText("Original Image")
            self.original_window_level = None
            self.original_dynamic_range = None
            self.raw_window_level = None
            self.raw_dynamic_range = None
            self.fft_view_active = False
            self.fft_back_image = None
            self.primary_panel.plot.getViewBox().autoRange()
            self.secondary_panel.plot.getViewBox().autoRange()
            self.set_view_mode("Both" if self.source_kind != "bitmap" else "Original")
            return
        self.fft_view_active = False
        self.fft_back_image = None
        self.set_view_mode(mode)


    def _image_level_wheel(self, panel, step: float, adjust_width: bool):
        target = "Raw Data" if panel is self.primary_panel and self.view_mode in {"FFT", "Both"} else "Original Image"
        self.level_target_combo.setCurrentText(target)

        if target == "Raw Data":
            center = float(self.raw_window_level or 0.0)
            width = max(float(self.raw_dynamic_range or 1.0), 1e-9)
        else:
            center = float(self.original_window_level or 0.0)
            width = max(float(self.original_dynamic_range or 1.0), 1e-9)

        increment = max(width * 0.04, 1e-6)
        if adjust_width:
            width = max(width + step * increment, 1e-9)
        else:
            center += step * increment

        if target == "Raw Data":
            self.raw_window_level = center
            self.raw_dynamic_range = width
        else:
            self.original_window_level = center
            self.original_dynamic_range = width

        self._sync_level_controls()
        self.refresh_images()

    def _accordion_opened(self, opened):
        for section in self.accordion_sections:
            if section is not opened: section.set_expanded(False,False)

    def _spike_range_changed(self,value):
        visible=value=="Scale"; self.spike_scale_slider.setVisible(visible); self.spike_scale_label.setVisible(visible)

    def show_dicom_header_popup(self):
        if self.current_ds is None: QMessageBox.information(self,"DICOM Header","Load a DICOM image first."); return
        DicomHeaderDialog(self.current_ds,self.current_source,self).exec()

    def _toggle_developer_mode(self, enabled: bool):
        self.developer_mode = bool(enabled)
        if hasattr(self, "spike_developer_text"):
            self.spike_developer_text.setVisible(self.developer_mode)
        if self.developer_mode and hasattr(self, "current_spike_result_index"):
            self._show_spike_result(self.current_spike_result_index)

    @classmethod
    def _extract_stripe_only(cls, image: np.ndarray) -> dict:
        source = np.asarray(image, dtype=float)
        source = source - np.median(source)
        rows, cols = source.shape
        spectrum = fft2c(source)
        magnitude = np.abs(spectrum)
        cy, cx = rows // 2, cols // 2
        yy, xx = np.indices((rows, cols))
        dy = yy - cy
        dx = xx - cx
        radius = np.hypot(dy, dx)
        angle = np.arctan2(dy, dx)
        center_radius = max(5, int(min(rows, cols) * 0.04))
        cross_width = max(2, int(min(rows, cols) * 0.015))
        valid = (radius > center_radius) & (np.abs(dy) > cross_width) & (np.abs(dx) > cross_width)
        logmag = np.log1p(magnitude)
        zmap = np.zeros_like(logmag)
        zmap[valid] = cls._robust_zscore(logmag[valid])

        # Direction/scale groups. Multi-spike images may contain many groups.
        groups=[]
        candidate_mask=np.zeros_like(valid)
        angle_bins=np.linspace(-np.pi, np.pi, 37)
        radial_bins=[center_radius, max(center_radius+1,int(min(rows,cols)*0.12)), int(min(rows,cols)*0.25), int(min(rows,cols)*0.50)]
        for a0,a1 in zip(angle_bins[:-1],angle_bins[1:]):
            amask=valid & (angle>=a0) & (angle<a1)
            for ri,(r0,r1) in enumerate(zip(radial_bins[:-1],radial_bins[1:])):
                mask=amask & (radius>=r0) & (radius<r1)
                if not np.any(mask): continue
                peak=float(np.percentile(zmap[mask],99.7))
                count=int(np.sum(zmap[mask]>5.5))
                if peak>=6.0 and count>=1:
                    group_mask=mask & (zmap>=max(5.5,peak*0.62))
                    candidate_mask |= group_mask
                    groups.append({"angle":float(np.rad2deg((a0+a1)/2.0)),"scale":["Wide","Mid","Fine"][min(ri,2)],"peak_z":peak,"points":int(np.sum(group_mask))})
        # Symmetric completion and thin sparse support avoid ring/band inclusion.
        candidate_mask |= np.flip(np.flip(candidate_mask,axis=0),axis=1)
        candidate_spectrum=np.where(candidate_mask,spectrum,0)
        stripe_only=np.real(ifft2c(candidate_spectrum))
        return {"stripe_only":stripe_only,"candidate_spectrum":candidate_spectrum,"candidate_mask":candidate_mask,"groups":groups,"valid_mask":valid,"z_map":zmap}

    @classmethod
    def _map_stripe_to_raw(cls, stripe_info: dict, actual_kspace: np.ndarray) -> dict:
        predicted=np.abs(stripe_info["candidate_spectrum"])
        actual=np.abs(actual_kspace)
        mask=np.asarray(stripe_info["candidate_mask"],dtype=bool)
        if not np.any(mask):
            return {"agreement":0.0,"matched_mask":mask,"candidate_image":predicted,"matched_coords":np.empty((0,2),dtype=int)}
        local=np.stack([np.roll(actual,(dy,dx),axis=(0,1)) for dy,dx in ((-1,0),(1,0),(0,-1),(0,1),(-1,-1),(1,1))])
        med=np.median(local,axis=0)
        mad=np.median(np.abs(local-med[None,...]),axis=0)
        z=(actual-med)/np.maximum(1.4826*mad,1e-9)
        matched=mask & (z>6.0) & (actual>np.maximum(med*2.5,1e-9))
        predicted_points=max(int(np.sum(mask)),1)
        agreement=float(np.sum(matched)/predicted_points)
        return {"agreement":agreement,"matched_mask":matched,"candidate_image":np.log1p(predicted),"matched_coords":np.argwhere(matched),"raw_z":z}

    @staticmethod
    def _robust_zscore(values: np.ndarray) -> np.ndarray:
        array = np.asarray(values, dtype=float)
        if array.size == 0:
            return np.asarray([], dtype=float)
        median = float(np.median(array))
        mad = float(np.median(np.abs(array - median)))
        scale = max(1.4826 * mad, 1e-9)
        return (array - median) / scale

    @classmethod
    def _image_stripe_features(cls, image: np.ndarray) -> dict:
        source = np.asarray(image, dtype=float)
        source = source - np.median(source)
        rows, cols = source.shape

        def projection_score(projection):
            spectrum = np.abs(np.fft.rfft(projection))
            if spectrum.size < 12:
                return 0.0, 0
            z = cls._robust_zscore(spectrum[2:])
            return float(np.mean(np.sort(z)[-8:])), int(np.sum(z > 5.5))

        row_strength, row_count = projection_score(np.mean(source, axis=1))
        col_strength, col_count = projection_score(np.mean(source, axis=0))

        yy, xx = np.indices((rows, cols))
        angle_results = []
        for angle in (-75, -60, -45, -30, -15, 15, 30, 45, 60, 75):
            theta = np.deg2rad(angle)
            coordinate = xx * np.cos(theta) + yy * np.sin(theta)
            bins = np.floor(coordinate - coordinate.min()).astype(int)
            sums = np.bincount(bins.ravel(), weights=source.ravel())
            counts = np.bincount(bins.ravel())
            projection = sums / np.maximum(counts, 1)
            strength, count = projection_score(projection)
            angle_results.append((strength, count, angle))
        angle_strength, angle_count, best_angle = max(angle_results, key=lambda item: item[0])

        frequency = np.abs(fft2c(source))
        cy, cx = rows // 2, cols // 2
        radius = np.hypot(yy - cy, xx - cx)
        valid = (
            (radius > max(5, int(min(rows, cols) * 0.04)))
            & (np.abs(yy - cy) > max(2, int(min(rows, cols) * 0.018)))
            & (np.abs(xx - cx) > max(2, int(min(rows, cols) * 0.018)))
        )
        z_map = np.zeros_like(frequency)
        z_map[valid] = cls._robust_zscore(np.log1p(frequency[valid]))
        diagonal_strength = float(np.percentile(z_map[valid], 99.9)) if np.any(valid) else 0.0

        gx = np.diff(source, axis=1, prepend=source[:, :1])
        gy = np.diff(source, axis=0, prepend=source[:1, :])
        gradient = np.hypot(gx, gy)
        edge_mask = gradient >= np.percentile(gradient, 92)
        line_persistence = max(
            float(np.max(np.mean(edge_mask, axis=1))),
            float(np.max(np.mean(edge_mask, axis=0))),
        )

        return {
            "stripe_strength": max(row_strength, col_strength, angle_strength),
            "periodic_count": max(row_count, col_count, angle_count),
            "diagonal_strength": diagonal_strength,
            "direction_concentration": min(1.0, angle_strength / 12.0),
            "line_persistence": line_persistence,
            "best_stripe_angle": float(best_angle),
            "frequency": frequency,
            "z_map": z_map,
            "valid_mask": valid,
        }


    @classmethod
    def _raw_spike_features(cls, frequency: np.ndarray, valid_mask: np.ndarray) -> dict:
        magnitude = np.asarray(frequency, dtype=float)
        rows, cols = magnitude.shape
        cy, cx = rows // 2, cols // 2

        # Local background estimate. Random isolated high signals stand far above
        # the surrounding MRI raw-data noise.
        neighbor_stack = np.stack([
            np.roll(magnitude, (dy, dx), axis=(0, 1))
            for dy, dx in (
                (-2, 0), (-1, -1), (-1, 0), (-1, 1),
                (0, -2), (0, -1), (0, 1), (0, 2),
                (1, -1), (1, 0), (1, 1), (2, 0),
            )
        ])
        local_median = np.median(neighbor_stack, axis=0)
        local_mad = np.median(
            np.abs(neighbor_stack - local_median[None, ...]),
            axis=0,
        )
        local_scale = np.maximum(1.4826 * local_mad, 1e-9)
        local_z = (magnitude - local_median) / local_scale

        log_values = np.log1p(magnitude[valid_mask])
        global_z_values = cls._robust_zscore(log_values)
        global_z = np.zeros_like(magnitude)
        global_z[valid_mask] = global_z_values

        candidate_mask = (
            valid_mask
            & (local_z > 7.0)
            & (global_z > 6.0)
            & (magnitude > np.maximum(local_median * 3.0, 1e-9))
        )
        coords = np.argwhere(candidate_mask)

        # Conjugate-pair support is useful but not mandatory; the examples can
        # contain several random spikes.
        pair_hits = 0
        for y, x in coords[:500]:
            sy = (2 * cy - int(y)) % rows
            sx = (2 * cx - int(x)) % cols
            if candidate_mask[sy, sx] or (
                local_z[sy, sx] > 5.0 and global_z[sy, sx] > 4.5
            ):
                pair_hits += 1

        isolated_count = int(coords.shape[0])
        maximum_local_z = (
            float(np.max(local_z[candidate_mask]))
            if isolated_count
            else 0.0
        )
        random_spread = 0.0
        if isolated_count >= 2:
            normalized = coords.astype(float)
            normalized[:, 0] /= max(rows - 1, 1)
            normalized[:, 1] /= max(cols - 1, 1)
            random_spread = float(
                np.std(normalized[:, 0]) + np.std(normalized[:, 1])
            )

        return {
            "isolated_count": isolated_count,
            "max_local_z": maximum_local_z,
            "pair_hits": pair_hits,
            "random_spread": random_spread,
            "candidate_coords": coords,
            "local_z": local_z,
            "global_z": global_z,
        }

    def quick_spike_detect_prototype(self):
        if not self.dicom_entries:
            QMessageBox.information(self, "Quick Spike Detect", "Load DICOM images first.")
            return
        progress=self._make_progress("Quick Spike Detect",len(self.dicom_entries))
        records=[]; errors=0
        try:
            for index in range(len(self.dicom_entries)):
                if progress.wasCanceled(): break
                try:
                    entry=self._ensure_dicom_image(index)
                    progress.setLabelText(f"Stripe extraction {index+1}/{len(self.dicom_entries)}\n{entry.path.name}")
                    progress.setValue(index+1); QApplication.processEvents()
                    image=np.asarray(entry.image,dtype=float)
                    stripe=self._extract_stripe_only(image)
                    actual_raw=fft2c(image)
                    mapping=self._map_stripe_to_raw(stripe,actual_raw)
                    groups=stripe["groups"]
                    stripe_energy=float(np.std(stripe["stripe_only"])/(np.std(image)+1e-9))
                    group_score=sum(min(g["peak_z"],15.0) for g in groups)
                    multi_direction=len({round(g["angle"]/15)*15 for g in groups})
                    raw_agreement=float(mapping["agreement"])
                    # Raw agreement is mandatory. Strong curved/ring energy without sparse matched peaks is not Spike.
                    score=(min(group_score,60)*0.08 + min(len(groups),16)*0.35 + min(multi_direction,8)*0.4 + min(stripe_energy,1.0)*5.0 + raw_agreement*18.0)
                    series=str(getattr(entry.ds,"SeriesInstanceUID","") or getattr(entry.ds,"SeriesNumber","") or "UnknownSeries")
                    records.append({"index":index,"series":series,"score":score,"groups":groups,"group_count":len(groups),"directions":multi_direction,"stripe_energy":stripe_energy,"raw_agreement":raw_agreement,"matched_count":int(len(mapping["matched_coords"])),"stripe_only":stripe["stripe_only"],"raw_candidate":mapping["candidate_image"]})
                except Exception as exc:
                    errors+=1
        finally:
            progress.hide(); self._stabilize_layout()
        by_series={}
        for r in records: by_series.setdefault(r["series"],[]).append(r)
        high=[]; review=[]; self.quick_spike_details={}
        for group in by_series.values():
            vals=np.array([r["score"] for r in group],dtype=float)
            zvals=self._robust_zscore(vals) if len(vals)>=4 else np.zeros(len(vals))
            for r,z in zip(group,zvals):
                # Mandatory image stripe + actual raw match. Multiple directions/scales are allowed and rewarded.
                raw_ok=r["raw_agreement"]>=0.015 and r["matched_count"]>=1
                stripe_ok=r["group_count"]>=1 and r["stripe_energy"]>=0.006
                multi_ok=r["directions"]>=2 or r["group_count"]>=3
                confidence="No Spike"
                if raw_ok and stripe_ok and (multi_ok or z>=3.5) and r["score"]>=5.0:
                    high.append(r["index"]); confidence="High Confidence"
                elif raw_ok and stripe_ok and r["score"]>=3.0:
                    review.append(r["index"]); confidence="Review"
                r["series_z"]=float(z); r["confidence"]=confidence
                self.quick_spike_details[r["index"]]=r
        self.quick_spike_indices=sorted(set(high)); self.quick_spike_review_indices=sorted(set(review))
        self._highlight_quick_spike_candidates(self.quick_spike_indices,self.quick_spike_review_indices)
        dialog=QMessageBox(self); dialog.setWindowTitle("Quick Spike Detect")
        dialog.setText(f"High Confidence: {len(self.quick_spike_indices)}\nReview: {len(self.quick_spike_review_indices)}\nRead Errors: {errors}\nTotal Images: {len(self.dicom_entries)}\n\nLogic: Original stripe extraction → stripe-only frequency mapping → actual Raw/k-space agreement.")
        dialog.addButton("Close",QMessageBox.RejectRole); check=dialog.addButton("Check High Confidence",QMessageBox.AcceptRole); dialog.exec()
        if dialog.clickedButton()==check:
            hs=set(self.quick_spike_indices); it=QTreeWidgetItemIterator(self.tree)
            while it.value():
                item=it.value(); data=item.data(0,Qt.UserRole)
                if data and data[0]=="dicom": item.setCheckState(0,Qt.Checked if int(data[1]) in hs else Qt.Unchecked)
                it+=1
            if hs: self.show_dicom(min(hs))


    def _highlight_quick_spike_candidates(self, high_indices, review_indices=None):
        high={int(v) for v in high_indices}; review={int(v) for v in (review_indices or [])}
        it=QTreeWidgetItemIterator(self.tree)
        while it.value():
            item=it.value(); data=item.data(0,Qt.UserRole)
            if data and data[0]=="dicom":
                i=int(data[1])
                if i in high: item.setForeground(0,pg.mkBrush("#ff4f4f")); item.setToolTip(0,"Quick Spike: High Confidence")
                elif i in review: item.setForeground(0,pg.mkBrush("#ffb347")); item.setToolTip(0,"Quick Spike: Review")
                else: item.setForeground(0,pg.mkBrush("#d8e5ef")); item.setToolTip(0,"")
            it+=1


    def _select_quick_spike_candidates(self, indices):
        target = {int(value) for value in indices}
        self.tree.blockSignals(True)
        try:
            self.tree.clearSelection()
            iterator = QTreeWidgetItemIterator(self.tree)
            first_item = None
            while iterator.value():
                item = iterator.value()
                data = item.data(0, Qt.UserRole)
                if data and data[0] == "dicom" and int(data[1]) in target:
                    item.setSelected(True)
                    if first_item is None:
                        first_item = item
                iterator += 1
            if first_item is not None:
                self.tree.setCurrentItem(first_item)
        finally:
            self.tree.blockSignals(False)

        if target:
            self.show_dicom(min(target))


    def on_display_type_changed(self, value: str):
        self.refresh_images()
        self.update_line_profile()

    @staticmethod
    def _display_component(array: np.ndarray, mode: str) -> np.ndarray:
        data = np.asarray(array)
        if mode == "Real":
            return np.real(data)
        if mode == "Imaginary":
            return np.imag(data)
        if mode == "Phase":
            return np.angle(data)
        return np.abs(data)

    def set_view_mode(self, mode):
        if self.source_kind == "bitmap" and mode != "Original":
            mode = "Original"
        self.view_mode = mode
        for button, value in [
            (self.btn_fft, "FFT"),
            (self.btn_original, "Original"),
            (self.btn_both, "Both"),
        ]:
            button.setChecked(value == mode)
        self.refresh_images()
        self._schedule_responsive_layout()



    def refresh_images(self):
        self.stable_diagnostics.info(
            "REFRESH_IMAGES_BEGIN",
            view_mode=self.view_mode,
            current_image=self.stable_diagnostics.array_summary(
                self.current_image
            ),
            current_kspace=self.stable_diagnostics.array_summary(
                self.current_kspace
            ),
        )
        if self.current_image is None:
            return
        mode = self.profile_mode.currentText() if hasattr(self, "profile_mode") else "Magnitude"
        orig = self._display_component(self.current_image, mode)

        if self.source_kind == "bitmap":
            self.view_mode = "Original"
            auto_original = (self.level_target_combo.currentText() == "Original Image" and self.level_preset_combo.currentText() == "Auto")
            original_levels = self._levels_for_target("Original Image", orig, auto_original=auto_original)
            self.primary_panel.show()
            self.secondary_panel.hide()
            self.primary_panel.label.setText(f"Original Image — {mode}")
            self.primary_panel.set_image(orig, levels=original_levels)
            self._sync_level_controls()
            rows, cols = orig.shape
            self._configure_line_control(rows, cols)
            self._sync_lines()
            self.update_line_profile()
            return

        if self.current_kspace is None:
            return
        raw_component = self._display_component(self.current_kspace, mode)
        fft_img = np.log1p(np.abs(raw_component)) if mode == "Magnitude" else raw_component
        auto_original = (self.level_target_combo.currentText() == "Original Image" and self.level_preset_combo.currentText() == "Auto")
        original_levels = self._levels_for_target("Original Image", orig, auto_original=auto_original)
        raw_levels = self._levels_for_target("Raw Data", fft_img, auto_original=False)

        if self.view_mode == "FFT":
            self.primary_panel.show()
            self.secondary_panel.hide()
            self.primary_panel.label.setText(f"FFT (k-space) — {mode}")
            self.primary_panel.set_image(fft_img, levels=raw_levels)
        elif self.view_mode == "Original":
            self.primary_panel.show()
            self.secondary_panel.hide()
            self.primary_panel.label.setText(f"Original Image — {mode}")
            self.primary_panel.set_image(orig, levels=original_levels)
        else:
            self.primary_panel.show()
            self.secondary_panel.show()
            self.primary_panel.label.setText(f"FFT (k-space) — {mode}")
            self.secondary_panel.label.setText(f"Original Image — {mode}")
            self.primary_panel.set_image(fft_img, levels=raw_levels)
            self.secondary_panel.set_image(orig, levels=original_levels)

        rows, cols = orig.shape
        self.line_row = min(max(int(self.line_row_ratio * max(rows - 1, 1)), 0), rows - 1)
        self.line_col = min(max(int(self.line_col_ratio * max(cols - 1, 1)), 0), cols - 1)
        self._configure_line_control(rows, cols)
        self._sync_lines()
        self._sync_level_controls()
        self.update_line_profile()
        self._apply_image_orientation()
        self.stable_diagnostics.info(
            "REFRESH_IMAGES_END",
            state=self._stable_diagnostic_state(),
        )


    def _configure_line_control(self, rows, cols):
        maximum = rows-1 if self.line_orientation=='Row' else cols-1
        self.line_spin.blockSignals(True); self.line_slider.blockSignals(True)
        self.line_spin.setRange(0, maximum); self.line_slider.setRange(0, maximum)
        value=self.line_row if self.line_orientation=='Row' else self.line_col
        self.line_spin.setValue(value); self.line_slider.setValue(value)
        self.line_spin.blockSignals(False); self.line_slider.blockSignals(False)

    def _orientation_changed(self, text):
        self.line_orientation=text
        if self.current_image is not None: self._configure_line_control(*self.current_image.shape); self.update_line_profile()

    def _spin_line_changed(self, value):
        self._set_selected_line(value)

    def _slider_line_changed(self, value):
        self._set_selected_line(value)

    def _set_selected_line(self, value):
        if self.current_image is None: return
        if self.line_orientation=='Row': self.line_row=value
        else: self.line_col=value
        self.line_spin.blockSignals(True); self.line_slider.blockSignals(True); self.line_spin.setValue(value); self.line_slider.setValue(value); self.line_spin.blockSignals(False); self.line_slider.blockSignals(False)
        self._sync_lines(); self.update_line_profile()

    def _line_moved(self, row: int, col: int):
        self.line_row = int(row)
        self.line_col = int(col)
        if self.current_image is not None:
            rows, cols = np.asarray(self.current_image).shape
            self.line_row_ratio = self.line_row / max(rows - 1, 1)
            self.line_col_ratio = self.line_col / max(cols - 1, 1)
        self._sync_lines()
        self.update_line_profile()


    def _sync_lines(self):
        self.primary_panel.set_line_position(self.line_row, self.line_col); self.secondary_panel.set_line_position(self.line_row, self.line_col)

    def active_display_array(self):
        if self.view_mode == 'Original': return np.asarray(self.current_image)
        return np.asarray(self.current_kspace)

    def update_line_profile(self):
        if self.current_image is None or self.current_kspace is None: return
        arr=self.active_display_array(); line=arr[self.line_row,:] if self.line_orientation=='Row' else arr[:,self.line_col]
        y=self.component(line, self.profile_mode.currentText())
        if self.log_profile.isChecked(): y=np.log10(np.maximum(np.abs(y), 1e-12))
        self.profile_plot.clear(); self.profile_plot.plot(y)
        pos=self.line_row if self.line_orientation=='Row' else self.line_col
        self.line_value_label.setText(f"{pos} / {len(y)-1}")

    def send_line_to_signal_studio(self):
        if self.current_image is None: return
        arr=self.active_display_array(); line=arr[self.line_row,:] if self.line_orientation=='Row' else arr[:,self.line_col]
        self.add_signal(line, f"{self.line_orientation} {self.line_row if self.line_orientation=='Row' else self.line_col} — {self.view_mode}")
        self.tabs.setCurrentIndex(1)

    def auto_levels(self):
        if self.current_image is None:
            return
        target = self.level_target_combo.currentText() if hasattr(self, "level_target_combo") else "Original Image"
        if target == "Raw Data":
            if self.current_kspace is None:
                return
            self._set_levels_for_target("Raw Data", np.log1p(np.abs(self.current_kspace)))
        else:
            self._set_levels_for_target("Original Image", np.asarray(self.current_image))
        self.level_preset_combo.blockSignals(True)
        self.level_preset_combo.setCurrentText("Auto")
        self.level_preset_combo.blockSignals(False)
        self._sync_level_controls()
        self.refresh_images()


    def _tree_current_changed(self, current, previous):
        try:
            self._open_tree_item(current, force=False)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Explorer Selection Error",
                f"{type(exc).__name__}: {exc}",
            )


    def _tree_original_paths(self):
        paths, seen = [], set()
        def add_path(value):
            try: path = Path(value)
            except Exception: return
            if path.exists() and path.is_file():
                key = str(path.resolve()).lower()
                if key not in seen:
                    seen.add(key); paths.append(path)
                if path.suffix.lower() in {".dat", ".pfile", ".7", ".img"}:
                    txt = path.with_suffix(".txt")
                    if txt.exists():
                        k = str(txt.resolve()).lower()
                        if k not in seen: seen.add(k); paths.append(txt)
        for item in self.tree.selectedItems():
            data=item.data(0,Qt.UserRole)
            if not data: continue
            kind=data[0]
            if kind=="dicom":
                i=int(data[1])
                if 0<=i<len(self.dicom_entries): add_path(self.dicom_entries[i].path)
            elif kind=="tracker_file":
                i=int(data[1])
                if 0<=i<len(self.tracker_files): add_path(self.tracker_files[i]["path"])
            elif kind in {"processed","tracker_workspace","raw_file","bitmap_pending","signal_pending"}:
                add_path(data[1])
            elif kind=="series":
                for j in range(item.childCount()):
                    d=item.child(j).data(0,Qt.UserRole)
                    if d and d[0]=="dicom":
                        i=int(d[1])
                        if 0<=i<len(self.dicom_entries): add_path(self.dicom_entries[i].path)
        return paths



    def _start_tree_file_drag(self, supported_actions):
        paths=self._tree_original_paths()
        if not paths:
            self.statusBar().showMessage("No original files are available for drag and drop")
            return
        mime=QMimeData(); mime.setUrls([QUrl.fromLocalFile(str(p)) for p in paths])
        drag=QDrag(self.tree); drag.setMimeData(mime)
        self.statusBar().showMessage(f"Dragging {len(paths)} original file(s)")
        drag.exec(Qt.CopyAction)

    def _open_tree_item(self, item, *, force=False):
        # Defensive initialization for sessions restored from an older build.
        if not hasattr(self, "_tree_open_in_progress"):
            self._tree_open_in_progress = False
        if not hasattr(self, "_active_tree_source_key"):
            self._active_tree_source_key = None

        if item is None or self._tree_open_in_progress:
            return

        data = item.data(0, Qt.UserRole)
        if not data:
            return
        self.stable_diagnostics.info(
            "TREE_ITEM_OPEN",
            text=item.text(0),
            data=data,
            force=bool(force),
        )

        source_type = str(data[0])
        source_value = data[1] if len(data) > 1 else None
        source_key = (source_type, str(source_value))

        if not force and source_key == self._active_tree_source_key:
            return

        self._tree_open_in_progress = True
        try:
            if source_type == "dicom":
                self.show_dicom(int(source_value))
                self.tabs.setCurrentIndex(0)

            elif source_type == "signal":
                self.tabs.setCurrentIndex(4)
                self.signal_combo.setCurrentIndex(int(source_value))
                self.update_signal_plot()

            elif source_type == "processed":
                self.load_processed_image(source_value)
                self.refresh_images()
                self.tabs.setCurrentIndex(0)

            elif source_type == "tracker_workspace":
                self.show_tracker_in_workspace()
                self.tabs.setCurrentIndex(0)

            elif source_type == "tracker_signal":
                self.send_tracker_to_signal_studio()

            elif source_type == "tracker_file":
                self._apply_tracker_state(int(source_value))
                self.show_tracker_in_workspace()
                self.tabs.setCurrentIndex(0)

            elif source_type == "tracker_pending":
                index = int(source_value)
                if 0 <= index < len(self.pending_tracker_paths):
                    path = self.pending_tracker_paths[index]
                    self.statusBar().showMessage(
                        f"Loading Tracker: {path.name}"
                    )
                    QApplication.processEvents()
                    self.load_tracker(path)
                    self.show_tracker_in_workspace()
                    self.tabs.setCurrentIndex(0)

            elif source_type == "bitmap_pending":
                self.load_bitmap_image(Path(source_value))
                self.tabs.setCurrentIndex(0)

            elif source_type == "signal_pending":
                self.load_signal_file(Path(source_value))
                self.tabs.setCurrentIndex(4)

            elif source_type == "raw_file":
                path = Path(source_value)
                self.statusBar().showMessage(
                    f"Opening RAW: {path.name}"
                )
                QApplication.processEvents()
                self.load_raw_file(path)
                self.tabs.setCurrentIndex(0)

            self._active_tree_source_key = source_key

        except Exception as exc:
            self._active_tree_source_key = None
            QMessageBox.critical(
                self,
                "File Display Error",
                f"{source_type}: {source_value}\n\n"
                f"{type(exc).__name__}: {exc}",
            )
            self.statusBar().showMessage(
                f"Unable to display {source_type}: {exc}"
            )
        finally:
            self._tree_open_in_progress = False


    def _tree_clicked(self, item, column):
        try:
            self._open_tree_item(item, force=True)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Explorer Selection Error",
                f"{type(exc).__name__}: {exc}",
            )


    def _select_tree_dicom_index(self, index: int):
        iterator = QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            item = iterator.value()
            data = item.data(0, Qt.UserRole)
            if data and data[0] == "dicom" and int(data[1]) == int(index):
                self.tree.blockSignals(True)
                self.tree.setCurrentItem(item)
                self.tree.blockSignals(False)
                return
            iterator += 1

    def _level_target_changed(self, target: str):
        self._sync_level_controls()
        self.refresh_images()

    def _set_levels_for_target(self, target: str, array: np.ndarray):
        finite = np.asarray(array, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            center, width = 0.5, 1.0
        else:
            low, high = np.percentile(finite, [1.0, 99.5])
            if high <= low:
                high = low + 1.0
            center = float((low + high) / 2.0)
            width = float(high - low)

        if target == "Raw Data":
            self.raw_window_level = center
            self.raw_dynamic_range = width
        else:
            self.original_window_level = center
            self.original_dynamic_range = width

    def _levels_for_target(self, target: str, array: np.ndarray, auto_original: bool = False):
        if target == "Original Image":
            if auto_original or self.original_window_level is None or self.original_dynamic_range is None:
                self._set_levels_for_target(target, array)
            center = float(self.original_window_level)
            width = max(float(self.original_dynamic_range), 1e-9)
        else:
            if self.raw_window_level is None or self.raw_dynamic_range is None:
                self._set_levels_for_target(target, array)
            center = float(self.raw_window_level)
            width = max(float(self.raw_dynamic_range), 1e-9)
        return center - width / 2.0, center + width / 2.0

    def _active_level_array(self) -> np.ndarray:
        if self.current_image is None or self.current_kspace is None:
            return np.array([0.0, 1.0])
        if self.view_mode == "Original":
            return np.abs(self.current_image)
        return np.log1p(np.abs(self.current_kspace))

    def _set_auto_levels_from_array(self, array: np.ndarray):
        finite = np.asarray(array, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            center, width = 0.5, 1.0
        else:
            low, high = np.percentile(finite, [1.0, 99.5])
            if high <= low:
                high = low + 1.0
            center = (low + high) / 2.0
            width = high - low
        self.window_level = float(center)
        self.dynamic_range = float(width)
        self._sync_level_controls()

    def _levels_for_array(self, array: np.ndarray):
        finite = np.asarray(array, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            return (0.0, 1.0)
        low, high = np.percentile(finite, [1.0, 99.5])
        if high <= low:
            high = low + 1.0
        return (float(low), float(high))

    def _current_levels(self):
        if self.window_level is None or self.dynamic_range is None:
            self._set_auto_levels_from_array(self._active_level_array())
        half = max(float(self.dynamic_range) / 2.0, 1e-9)
        return (float(self.window_level) - half, float(self.window_level) + half)

    def _sync_level_controls(self):
        if not hasattr(self, "window_level_spin"):
            return
        target = self.level_target_combo.currentText() if hasattr(self, "level_target_combo") else "Original Image"
        if target == "Raw Data":
            center = self.raw_window_level
            width = self.raw_dynamic_range
        else:
            center = self.original_window_level
            width = self.original_dynamic_range

        self.window_level_spin.blockSignals(True)
        self.dynamic_range_spin.blockSignals(True)
        self.window_level_spin.setValue(float(center or 0.0))
        self.dynamic_range_spin.setValue(max(float(width or 1.0), 1e-9))
        self.window_level_spin.blockSignals(False)
        self.dynamic_range_spin.blockSignals(False)


    def _manual_levels_changed(self):
        target = self.level_target_combo.currentText() if hasattr(self, "level_target_combo") else "Original Image"
        center = float(self.window_level_spin.value())
        width = max(float(self.dynamic_range_spin.value()), 1e-9)
        if target == "Raw Data":
            self.raw_window_level = center
            self.raw_dynamic_range = width
        else:
            self.original_window_level = center
            self.original_dynamic_range = width
        self.level_preset_combo.blockSignals(True)
        self.level_preset_combo.setCurrentText("Manual")
        self.level_preset_combo.blockSignals(False)
        self.refresh_images()


    def apply_level_preset(self, preset: str):
        if self.current_image is None:
            return
        array = self._active_level_array()
        finite = np.asarray(array, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            return

        percentiles = {
            "Auto": (1.0, 99.5),
            "Wide": (0.0, 100.0),
            "Soft Tissue": (5.0, 95.0),
            "High Contrast": (10.0, 90.0),
            "Narrow": (25.0, 75.0),
        }
        low_p, high_p = percentiles.get(preset, (1.0, 99.5))
        low, high = np.percentile(finite, [low_p, high_p])
        if high <= low:
            high = low + 1.0
        self.level_preset = preset
        self.window_level = float((low + high) / 2.0)
        self.dynamic_range = float(high - low)
        self._sync_level_controls()
        levels = self._current_levels()
        self.primary_panel.set_levels(*levels)
        if self.secondary_panel.isVisible():
            self.secondary_panel.set_levels(*levels)

    def _current_image_record(self):
        if self.current_image is None:
            return None
        name = Path(self.current_source).name if self.current_source else "current_image"
        return {
            "name": name,
            "path": Path(self.current_source) if self.current_source else None,
            "image": np.asarray(self.current_image, dtype=float).copy(),
            "ds": copy.deepcopy(self.current_ds) if self.current_ds is not None else None,
        }

    def set_addsub_source(self, slot: str):
        record = self._current_image_record()
        if record is None:
            QMessageBox.information(self, "Add/Subtract", "Load an image first.")
            return
        if slot == "A":
            self.addsub_a = record
        else:
            self.addsub_b = record
        self.addsub_status.setText(
            f"A: {self.addsub_a['name'] if self.addsub_a else '-'}\\n"
            f"B: {self.addsub_b['name'] if self.addsub_b else '-'}"
        )

    def run_addsub(self, operation: str):
        # Backward-compatible alias.
        self.preview_addsub(operation)

    def preview_addsub(self, operation: str):
        if self.addsub_a is None or self.addsub_b is None:
            QMessageBox.information(self, "Add/Subtract", "Set both image A and image B first.")
            return
        a = np.asarray(self.addsub_a["image"], dtype=float)
        b = np.asarray(self.addsub_b["image"], dtype=float)
        if a.shape != b.shape:
            QMessageBox.warning(self, "Add/Subtract", f"Image sizes do not match: {a.shape} and {b.shape}")
            return

        result = a + b if operation == "add" else a - b
        self.addsub_preview_result = result
        self.addsub_preview_operation = operation
        self.save_addsub_button.setEnabled(True)

        dialog = QDialog(self)
        dialog.setWindowTitle("Add / Subtract Preview")
        dialog.resize(1450, 620)
        layout = QVBoxLayout(dialog)
        panels = QSplitter(Qt.Horizontal)
        panel_a = ImagePanel("Image A")
        panel_b = ImagePanel("Image B")
        panel_result = ImagePanel("Result: A + B" if operation == "add" else "Result: A - B")
        panels.addWidget(panel_a)
        panels.addWidget(panel_b)
        panels.addWidget(panel_result)
        panel_a.set_image(a)
        panel_b.set_image(b)
        panel_result.set_image(result)
        layout.addWidget(panels, 1)

        buttons = QHBoxLayout()
        save_button = QPushButton("Save Result")
        close_button = QPushButton("Close Preview")
        save_button.clicked.connect(lambda: (self.save_addsub_preview(), dialog.accept()))
        close_button.clicked.connect(dialog.reject)
        buttons.addStretch(1)
        buttons.addWidget(save_button)
        buttons.addWidget(close_button)
        layout.addLayout(buttons)
        dialog.exec()

    def save_addsub_preview(self):
        if self.addsub_preview_result is None or not self.addsub_preview_operation:
            QMessageBox.information(
                self,
                "Add/Subtract",
                "Preview an Add/Subtract result first.",
            )
            return

        operation = self.addsub_preview_operation
        tag = "add" if operation == "add" else "sub"
        base = Path(self.addsub_a["name"]).stem if self.addsub_a else "image"

        previous_ds = self.current_ds
        previous_source = self.current_source
        try:
            if self.addsub_a is not None:
                self.current_ds = copy.deepcopy(self.addsub_a.get("ds"))
                source_path = self.addsub_a.get("path")
                if source_path:
                    self.current_source = str(source_path)

            output_path = self._save_processed_image(
                self.addsub_preview_result,
                f"{base}_{tag}_addsub",
                "_addsub",
            )

            if not output_path.exists():
                raise IOError(f"Saved output file was not created: {output_path}")

            npy_path = output_path.with_suffix(".npy")
            if output_path.suffix.lower() == ".dcm" and not npy_path.exists():
                raise IOError(f"Add/Subtract array file was not created: {npy_path}")

            self._display_processed_result(
                self.addsub_preview_result,
                output_path,
            )
            self.addsub_status.setText(
                f"A: {self.addsub_a['name'] if self.addsub_a else '-'}\n"
                f"B: {self.addsub_b['name'] if self.addsub_b else '-'}\n"
                f"Saved: {output_path}"
            )
            self.save_addsub_button.setEnabled(False)
            self.statusBar().showMessage(
                f"Add/Subtract saved: {output_path}"
            )
            QMessageBox.information(
                self,
                "Add/Subtract Saved",
                f"Saved successfully:\n{output_path}",
            )
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Add/Subtract Save Error",
                str(exc),
            )
        finally:
            if self.current_ds is None:
                self.current_ds = previous_ds
            if not self.current_source:
                self.current_source = previous_source


    def _raw_compensation_panel(self):
        # ROI coordinates always refer to raw/k-space dimensions. When FFT or Both
        # is visible, use its panel. In Original-only mode, keep the display unchanged
        # and place the ROI on the visible panel using the same matrix coordinates.
        return self.primary_panel

    def start_compensation_roi(self):
        if self.current_kspace is None:
            QMessageBox.information(self, "Compensation", "Load raw/k-space data first.")
            return

        if not self.compensation_history:
            self.compensation_history = [{
                "kspace": np.asarray(self.current_kspace).copy(),
                "image": np.asarray(self.current_image).copy(),
                "label": "Original",
                "roi": None,
                "level": None,
            }]
            self.compensation_history_index = 0

        self.compensation_original_kspace = np.asarray(self.current_kspace).copy()
        self.compensation_original = np.asarray(self.current_image).copy()
        self.compensation_preview = None
        self.compensation_roi_panel = self._raw_compensation_panel()
        self.compensation_roi_panel.show_comp_roi()
        self.preview_comp_button.setEnabled(True)
        self.apply_comp_button.setEnabled(False)
        self.comp_status_label.setText(
            "RAW ROI active. The current view mode and Window/Level are unchanged."
        )
        self.statusBar().showMessage("Move and resize the RAW compensation ROI.")

    def clear_compensation_roi(self):
        if self.compensation_roi_panel is not None:
            self.compensation_roi_panel.hide_comp_roi()
        if self.compensation_original_kspace is not None:
            self.current_kspace = self.compensation_original_kspace.copy()
            self.current_recon = ifft2c(self.current_kspace)
            self.current_image = np.abs(self.current_recon)
        self.compensation_preview = None
        self.compensation_original = None
        self.compensation_original_kspace = None
        self.compensation_roi_panel = None
        self.preview_comp_button.setEnabled(False)
        self.apply_comp_button.setEnabled(False)
        self.comp_status_label.setText("No RAW ROI selected")
        self.refresh_images()

    @staticmethod
    def _interpolate_rectangle(raw_data: np.ndarray, y0: int, y1: int, x0: int, x1: int, strength: float = 1.0) -> np.ndarray:
        source = np.asarray(raw_data)
        result = source.copy()
        rows, cols = source.shape
        y0 = max(1, min(int(y0), rows - 2))
        y1 = max(y0 + 1, min(int(y1), rows - 1))
        x0 = max(1, min(int(x0), cols - 2))
        x1 = max(x0 + 1, min(int(x1), cols - 1))
        cy, cx = rows // 2, cols // 2
        roi = source[y0:y1, x0:x1].copy()
        margin = max(3, int(min(rows, cols) * 0.01))
        ya, yb = max(0, y0-margin), min(rows, y1+margin)
        xa, xb = max(0, x0-margin), min(cols, x1+margin)
        neighborhood = source[ya:yb, xa:xb].copy()
        mask = np.ones(neighborhood.shape, dtype=bool)
        mask[y0-ya:y1-ya, x0-xa:x1-xa] = False
        local_yy, local_xx = np.indices(neighborhood.shape)
        global_y = local_yy + ya
        global_x = local_xx + xa
        cross_width = max(2, int(min(rows, cols) * 0.015))
        cross_mask = (np.abs(global_y-cy) <= cross_width) | (np.abs(global_x-cx) <= cross_width)
        valid = mask & ~cross_mask
        background_values = neighborhood[valid]
        if background_values.size < 8:
            background_values = neighborhood[mask]
        if background_values.size == 0:
            return result
        background_mag = np.abs(background_values)
        median_mag = float(np.median(background_mag))
        mad_mag = float(np.median(np.abs(background_mag - median_mag)))
        noise_level = median_mag + 2.5 * max(1.4826 * mad_mag, 1e-9)
        roi_mag = np.abs(roi)
        outlier_mask = roi_mag > max(noise_level * 2.5, median_mag * 4.0)
        roi_yy, roi_xx = np.indices(roi.shape)
        global_roi_y = roi_yy + y0
        global_roi_x = roi_xx + x0
        roi_cross = ((np.abs(global_roi_y-cy) <= cross_width) | (np.abs(global_roi_x-cx) <= cross_width))
        outlier_mask &= ~roi_cross
        if not np.any(outlier_mask):
            return result
        phase_reference = np.angle(np.median(background_values))
        replacement = median_mag * np.exp(1j * phase_reference)
        blend = float(np.clip(strength, 0.0, 1.0))
        corrected_roi = roi.copy()
        corrected_roi[outlier_mask] = roi[outlier_mask] * (1.0-blend) + replacement * blend
        result[y0:y1, x0:x1] = corrected_roi
        return result


    def _compensation_strength(self):
        return {"Low": 0.40, "Mid": 0.70, "High": 1.00}.get(
            self.comp_level_combo.currentText(), 0.70
        )

    def _compensation_bounds(self):
        panel = self.compensation_roi_panel or self._raw_compensation_panel()
        if not panel.comp_roi.isVisible():
            raise ValueError("RAW compensation ROI is not active.")
        y0, y1, x0, x1 = panel.comp_roi_bounds()
        if (y1 - y0) < 2 or (x1 - x0) < 2:
            raise ValueError("Compensation ROI is too small.")
        return y0, y1, x0, x1

    def preview_compensation(self):
        if self.current_kspace is None:
            QMessageBox.information(self, "Compensation", "Load raw/k-space data first.")
            return
        try:
            y0, y1, x0, x1 = self._compensation_bounds()
            source_kspace = (
                self.compensation_original_kspace
                if self.compensation_original_kspace is not None
                else np.asarray(self.current_kspace)
            )
            strength = self._compensation_strength()
            compensated_kspace = self._interpolate_rectangle(
                source_kspace, y0, y1, x0, x1, strength
            )
            reconstructed = ifft2c(compensated_kspace)

            self.compensation_preview = compensated_kspace
            self.current_kspace = compensated_kspace
            self.current_recon = reconstructed
            self.current_image = np.abs(reconstructed)

            # Preserve view mode, preset, Window Level, and Dynamic Range.
            self.refresh_images()
            self.apply_comp_button.setEnabled(True)

            original_roi = np.abs(source_kspace[y0:y1, x0:x1])
            new_roi = np.abs(compensated_kspace[y0:y1, x0:x1])
            change = np.abs(new_roi - original_roi)
            self.comp_status_label.setText(
                f"Preview: {self.comp_level_combo.currentText()} | "
                f"RAW ROI x={x0}:{x1}, y={y0}:{y1} | "
                f"Mean change={float(np.mean(change)):.4g}"
            )
        except Exception as exc:
            QMessageBox.critical(self, "Compensation Preview Error", str(exc))

    def apply_compensation(self):
        try:
            y0, y1, x0, x1 = self._compensation_bounds()
            if self.compensation_preview is None:
                self.preview_compensation()
            if self.compensation_preview is None:
                return

            state = {
                "kspace": np.asarray(self.current_kspace).copy(),
                "image": np.asarray(self.current_image).copy(),
                "label": f"{self.comp_level_combo.currentText()} ROI {x0}:{x1},{y0}:{y1}",
                "roi": (y0, y1, x0, x1),
                "level": self.comp_level_combo.currentText(),
            }

            if self.compensation_history_index < len(self.compensation_history) - 1:
                self.compensation_history = self.compensation_history[
                    : self.compensation_history_index + 1
                ]
            self.compensation_history.append(state)
            self.compensation_history_index = len(self.compensation_history) - 1

            if self.compensation_roi_panel is not None:
                self.compensation_roi_panel.hide_comp_roi()
            self.compensation_roi_panel = None
            self.compensation_preview = None
            self.compensation_original_kspace = None
            self.compensation_original = None
            self.preview_comp_button.setEnabled(False)
            self.apply_comp_button.setEnabled(False)
            self.save_comp_button.setEnabled(True)
            self._update_compensation_history_buttons()
            self.comp_status_label.setText(
                f"Committed {self.compensation_history_index}/"
                f"{len(self.compensation_history)-1}: {state['label']}. "
                f"Select another ROI to continue."
            )
            self.refresh_images()
        except Exception as exc:
            QMessageBox.critical(self, "Compensation Error", str(exc))

    def _update_compensation_history_buttons(self):
        self.comp_prev_button.setEnabled(self.compensation_history_index > 0)
        self.comp_next_button.setEnabled(
            0 <= self.compensation_history_index < len(self.compensation_history) - 1
        )
        self.save_comp_button.setEnabled(self.compensation_history_index >= 0)

    def navigate_compensation_history(self, step: int):
        target = self.compensation_history_index + int(step)
        if target < 0 or target >= len(self.compensation_history):
            return
        self.compensation_history_index = target
        state = self.compensation_history[target]
        self.current_kspace = np.asarray(state["kspace"]).copy()
        self.current_recon = ifft2c(self.current_kspace)
        self.current_image = np.abs(self.current_recon)
        self.compensation_preview = None
        self.compensation_original_kspace = None
        if self.compensation_roi_panel is not None:
            self.compensation_roi_panel.hide_comp_roi()
        self.compensation_roi_panel = None
        self.refresh_images()
        self._update_compensation_history_buttons()
        self.comp_status_label.setText(
            f"History {target}/{len(self.compensation_history)-1}: {state['label']}"
        )

    def save_compensation_history_state(self):
        if not self.compensation_history or self.compensation_history_index < 0:
            QMessageBox.information(self, "Compensation", "No compensation state is available.")
            return
        state = self.compensation_history[self.compensation_history_index]
        base = Path(self.current_source).stem if self.current_source else "raw"
        output_path = self._save_processed_image(
            np.asarray(state["image"]),
            f"{base}_comp_h{self.compensation_history_index}",
            "_comp",
        )
        # Save raw/k-space separately for exact restoration.
        np.save(
            output_path.parent / f"{Path(output_path).stem}_raw.npy",
            np.asarray(state["kspace"]),
        )
        self.comp_status_label.setText(
            f"Saved displayed state {self.compensation_history_index}: {output_path.name}"
        )
        self.statusBar().showMessage(f"Compensation state saved: {output_path}")

    def change_output_root(self):
        initial = str(self._output_root())
        selected = QFileDialog.getExistingDirectory(self, "Select Output Top Folder", initial)
        if not selected:
            return
        self.output_root_override = Path(selected)
        self._update_output_root_label()

    def _output_root(self) -> Path:
        if self.output_root_override is not None:
            return self.output_root_override
        if self.last_import_output_root is not None:
            return self.last_import_output_root
        source = Path(self.current_source) if self.current_source else Path.cwd() / "image"
        parent = source.parent if source.parent.exists() else Path.cwd()
        return parent / "MR_Image_Explorer_Output"


    def _update_output_root_label(self):
        if hasattr(self, "output_root_label"):
            self.output_root_label.setText(f"Output: {self._output_root()}")

    def _work_folder(self, category: str = "Processed") -> Path:
        folder = self._output_root() / category
        folder.mkdir(parents=True, exist_ok=True)
        self._update_output_root_label()
        return folder


    def _save_processed_image(self, image: np.ndarray, stem: str, suffix: str) -> Path:
        suffix_lower = suffix.lower()
        if "addsub" in suffix_lower:
            category = "AddSub"
        elif "comp" in suffix_lower:
            category = "Compensated"
        elif "ns" in suffix_lower or "spike" in suffix_lower:
            category = "NoSpike"
        else:
            category = "Processed"

        folder = self._work_folder(category)
        safe_stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", stem)
        candidate_stem = safe_stem
        counter = 1
        while (
            (folder / f"{candidate_stem}.npy").exists()
            or (folder / f"{candidate_stem}.dcm").exists()
        ):
            candidate_stem = f"{safe_stem}_{counter}"
            counter += 1
        safe_stem = candidate_stem

        npy_path = folder / f"{safe_stem}.npy"
        np.save(npy_path, np.asarray(image, dtype=np.float32))

        if self.current_ds is not None:
            ds = copy.deepcopy(self.current_ds)
            arr = np.asarray(image, dtype=float)
            finite = arr[np.isfinite(arr)]
            low = float(np.min(finite)) if finite.size else 0.0
            high = float(np.max(finite)) if finite.size else 1.0
            if high <= low:
                high = low + 1.0
            scaled = np.clip((arr - low) / (high - low) * 65535.0, 0, 65535).astype(np.uint16)
            ds.PixelData = scaled.tobytes()
            ds.Rows, ds.Columns = scaled.shape
            ds.BitsAllocated = 16
            ds.BitsStored = 16
            ds.HighBit = 15
            ds.PixelRepresentation = 0
            ds.RescaleSlope = (high - low) / 65535.0
            ds.RescaleIntercept = low
            ds.SOPInstanceUID = generate_uid()
            ds.SeriesInstanceUID = generate_uid()
            ds.ImageType = ["DERIVED", "SECONDARY"]
            original_description = str(getattr(ds, "SeriesDescription", "MR"))
            ds.SeriesDescription = f"{original_description} {suffix}"
            dcm_path = folder / f"{safe_stem}.dcm"
            ds.save_as(str(dcm_path), write_like_original=False)
            primary_path = dcm_path
        else:
            primary_path = npy_path

        self.processed_images[str(primary_path)] = np.asarray(image, dtype=float).copy()
        self.processed_sources[str(primary_path)] = primary_path
        self._add_processed_tree_item(primary_path)
        self._update_output_root_label()
        return primary_path


    def _add_processed_tree_item(self, path: Path):
        root = None
        for i in range(self.tree.topLevelItemCount()):
            candidate = self.tree.topLevelItem(i)
            if candidate.text(0) == "Processed Files":
                root = candidate
                break
        if root is None:
            root = QTreeWidgetItem(["Processed Files"])
            self.tree.addTopLevelItem(root)
        item = QTreeWidgetItem([path.name])
        item.setData(0, Qt.UserRole, ("processed", str(path)))
        root.addChild(item)
        root.setExpanded(True)
        self.tree.setCurrentItem(item)

    def _display_processed_result(self, image: np.ndarray, path: Path):
        self.current_image = np.asarray(image, dtype=float)
        self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)
        self.current_source = str(path)
        self.current_ds = None
        self.source_kind = "processed"
        self.original_window_level = None
        self.original_dynamic_range = None
        self.raw_window_level = None
        self.raw_dynamic_range = None
        self.view_mode = "Both"
        self._update_output_root_label()
        self.refresh_images()


    def load_processed_image(self, path_value: str):
        path = Path(path_value)
        if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp"}:
            self.load_bitmap_image(path)
            return

        if str(path) in self.processed_images:
            image = self.processed_images[str(path)]
        elif path.suffix.lower() == ".npy":
            image = np.load(path, allow_pickle=False)
        elif path.suffix.lower() == ".dcm":
            entry = self.read_dicom(path)
            image = entry.image
            self.current_ds = entry.ds
        else:
            return

        self.current_image = np.asarray(image, dtype=float)
        self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)
        self.current_source = str(path)
        self.source_kind = "processed"
        self.original_window_level = None
        self.original_dynamic_range = None
        self.raw_window_level = None
        self.raw_dynamic_range = None
        self.view_mode = "Both"
        self._update_output_root_label()
        self.refresh_images()


    def _artifact_detection_indices(self):
        self._tree_selection_changed()
        if self.detect_selected_only.isChecked() and self.artifact_selected_indices:
            return list(self.artifact_selected_indices)
        return list(range(len(self.dicom_entries)))

    def detect_artifacts_from_db(self):
        if not self._ensure_artifact_database():
            return

        keys, training, labels, metadata = self.artifact_db.training_feature_vectors()
        indices = self._artifact_detection_indices()
        if not indices:
            QMessageBox.information(self, "Artifact Detection", "No DICOM images are available.")
            return

        progress = self._make_progress("Artifact Detection", len(indices))
        results = []
        try:
            for count, index in enumerate(indices, start=1):
                if progress.wasCanceled():
                    break
                entry = self.dicom_entries[index]
                progress.setLabelText(f"Classifying image: {entry.path.name}")
                features = image_features(entry.image, self.normal_reference_image)
                vector = features_to_vector(features, keys)
                result = classify_feature_vector(
                    vector,
                    training,
                    labels,
                    minimum_samples_per_class=self.detect_min_samples.value(),
                )
                results.append({
                    "index": index,
                    "entry": entry,
                    "features": features,
                    "result": result,
                })
                progress.setValue(count)
        finally:
            progress.close()

        self._artifact_detection_results = results
        self.artifact_detection_table.setRowCount(len(results))
        predicted_counts = {}
        for row, item in enumerate(results):
            entry = item["entry"]
            result = item["result"]
            predicted_counts[result.label] = predicted_counts.get(result.label, 0) + 1
            alternatives = ", ".join(
                f"{label} {confidence * 100:.1f}%"
                for label, confidence, distance, support in result.alternatives[1:4]
            )
            values = [
                entry.path.name,
                str(getattr(entry.ds, "SeriesDescription", "") or getattr(entry.ds, "ProtocolName", "")),
                result.label,
                f"{result.confidence * 100:.1f}%",
                f"{result.distance:.4f}" if np.isfinite(result.distance) else "-",
                result.support,
                result.status,
                alternatives,
                str(entry.path),
            ]
            for column, value in enumerate(values):
                table_item = QTableWidgetItem(str(value))
                table_item.setData(Qt.UserRole, row)
                self.artifact_detection_table.setItem(row, column, table_item)

        self.artifact_detection_table.resizeColumnsToContents()
        summary = ", ".join(f"{label}: {count}" for label, count in sorted(predicted_counts.items()))
        self.artifact_detection_summary.setText(
            f"Detected {len(results)} image(s). {summary or 'No prediction results.'}"
        )

    def open_detected_artifact_image(self, row: int, column: int):
        if not hasattr(self, "_artifact_detection_results"):
            return
        if row < 0 or row >= len(self._artifact_detection_results):
            return
        result = self._artifact_detection_results[row]
        self.show_dicom(int(result["index"]))
        self.tabs.setCurrentIndex(0)

    def send_detected_rows_to_learning(self):
        if not hasattr(self, "_artifact_detection_results"):
            return
        selected_rows = sorted(
            {item.row() for item in self.artifact_detection_table.selectedItems()}
        )
        if not selected_rows:
            return
        indices = []
        predicted_labels = []
        for row in selected_rows:
            result = self._artifact_detection_results[row]
            indices.append(int(result["index"]))
            predicted_labels.append(result["result"].label)
        self.artifact_selected_indices = sorted(set(indices))
        if predicted_labels and len(set(predicted_labels)) == 1:
            self.artifact_type_combo.setCurrentText(predicted_labels[0])
        self.artifact_selection_label.setText(
            f"Training images ready from detection: {len(self.artifact_selected_indices)}"
        )
        self.tabs.setCurrentIndex(2)

    def clear_selected_images(self):
        selected=[]
        for item in self.tree.selectedItems():
            data=item.data(0,Qt.UserRole)
            if data and data[0]=="dicom": selected.append(int(data[1]))
        selected=sorted(set(selected),reverse=True)
        if not selected: return
        if QMessageBox.question(self,"Clear Selected Images",f"Remove {len(selected)} selected image(s)?") != QMessageBox.Yes: return
        for i in selected:
            if 0 <= i < len(self.dicom_entries): self.dicom_entries.pop(i)
        if self.dicom_entries: self.populate_dicom_tree(); self.show_dicom(min(getattr(self,"slice_index",0),len(self.dicom_entries)-1))
        else: self._reset_image_state()

    def clear_all_images(self):
        if QMessageBox.question(self,"Clear All Images","Clear all imported images and image editing state?") != QMessageBox.Yes: return
        self.dicom_entries.clear(); self._reset_image_state()

    def _reset_image_state(self):
        self.current_image=None; self.current_kspace=None; self.current_recon=None; self.current_ds=None; self.current_source=""; self.tree.clear(); self.primary_panel.image_item.clear(); self.secondary_panel.image_item.clear(); self.profile_plot.clear(); self.slice_label.setText("Slice: -"); self.info.setText("No file loaded")
        self.compensation_history=[]; self.compensation_history_index=-1; self.addsub_a=None; self.addsub_b=None; self.addsub_preview_result=None; self.addsub_status.setText("A: -\nB: -")

    def remove_selected_signal(self):
        i=self.signal_combo.currentIndex()
        if 0 <= i < len(self.signals): self.signals.pop(i); self.signal_combo.clear(); self.signal_combo.addItems([x["name"] for x in self.signals]); self.update_signal_plot()

    def clear_addsub_slot(self,slot:str):
        if slot=="A": self.addsub_a=None
        else: self.addsub_b=None
        self.addsub_status.setText(f"A: {self.addsub_a['name'] if self.addsub_a else '-'}\nB: {self.addsub_b['name'] if self.addsub_b else '-'}")

    def clear_addsub_result(self):
        self.addsub_preview_result=None; self.addsub_preview_operation=""; self.save_addsub_button.setEnabled(False)

    def clear_compensation_history(self):
        if self.compensation_base_kspace is not None:
            self.current_kspace = np.asarray(self.compensation_base_kspace).copy()
            self.current_recon = ifft2c(self.current_kspace)
            if self.compensation_base_image is not None:
                self.current_image = np.asarray(self.compensation_base_image).copy()
            else:
                self.current_image = np.abs(self.current_recon)

        self.compensation_history = []
        self.compensation_history_index = -1
        self.compensation_preview = None
        self.compensation_original = None
        self.compensation_original_kspace = None
        if self.compensation_roi_panel is not None:
            self.compensation_roi_panel.hide_comp_roi()
        self.compensation_roi_panel = None
        self._update_compensation_history_buttons()
        self.comp_status_label.setText("Compensation history cleared — original restored")
        self.refresh_images()


    def clear_selected_artifact_training(self):
        self.artifact_selected_indices=[]; self.artifact_preview_position=0; self.artifact_selection_label.setText("No training images selected."); self.artifact_preview_panel.image_item.clear()

    def clear_all_artifact_training(self):
        self.clear_selected_artifact_training(); self.normal_reference_image=None; self.normal_reference_path=None; self.artifact_normal_label.setText("Normal reference: None")

    def _tree_selection_changed(self):
        selected_items = self.tree.selectedItems()

        indices = []
        for item in selected_items:
            data = item.data(0, Qt.UserRole)
            if data and data[0] == "dicom":
                indices.append(int(data[1]))

        self.artifact_selected_indices = sorted(set(indices))
        if hasattr(self, "artifact_selection_label"):
            self.artifact_selection_label.setText(
                f"Selected DICOM images in Explorer: "
                f"{len(self.artifact_selected_indices)}"
            )

        # For a single RAW/bitmap/tracker/signal selection, ensure the item is
        # opened even on Windows configurations where itemClicked is not
        # delivered after a drag or focus change.
        if len(selected_items) == 1:
            item = selected_items[0]
            data = item.data(0, Qt.UserRole)
            if data and data[0] != "dicom":
                QTimer.singleShot(
                    0,
                    lambda selected=item: self._open_tree_item(
                        selected,
                        force=False,
                    ),
                )



    def _ensure_artifact_database(self):
        if self.artifact_db is None:
            self.open_artifact_database()
        return self.artifact_db is not None

    def open_artifact_database(self):
        choice = QMessageBox(self)
        choice.setWindowTitle("Artifact Database")
        choice.setText("Open an existing database or create a new database.")
        open_button = choice.addButton("Open Existing", QMessageBox.AcceptRole)
        create_button = choice.addButton("Create New", QMessageBox.ActionRole)
        choice.addButton("Cancel", QMessageBox.RejectRole)
        choice.exec()

        clicked = choice.clickedButton()
        if clicked == open_button:
            filename, _ = QFileDialog.getOpenFileName(
                self, "Open Artifact Database", "",
                "SQLite database (*.sqlite *.db);;All files (*)"
            )
        elif clicked == create_button:
            filename, _ = QFileDialog.getSaveFileName(
                self, "Create Artifact Database", "MR_Artifact_Learning.sqlite",
                "SQLite database (*.sqlite *.db)"
            )
        else:
            return

        if not filename:
            return
        path = Path(filename)
        if path.suffix.lower() not in {".sqlite", ".db"}:
            path = path.with_suffix(".sqlite")
        if self.artifact_db is not None:
            self.artifact_db.close()
        self.artifact_db = ArtifactDatabase(path)
        self.artifact_db_path = path
        self.artifact_db_label.setText(f"Artifact DB: {path}")
        self.refresh_artifact_lists()
        self.refresh_artifact_training_table()


    def refresh_artifact_lists(self):
        if self.artifact_db is None:
            return
        self.artifact_type_combo.clear()
        self.artifact_type_combo.addItems(self.artifact_db.artifact_types())
        self.artifact_resolution_combo.clear()
        self.artifact_resolution_combo.addItems(self.artifact_db.resolutions())

    def _set_learning_class_quick(self, class_name: str):
        if hasattr(self, "artifact_type_combo"):
            index=self.artifact_type_combo.findText(class_name)
            if index<0:
                self.artifact_new_type.setText(class_name)
                self.add_artifact_type_manual()
                index=self.artifact_type_combo.findText(class_name)
            if index>=0: self.artifact_type_combo.setCurrentIndex(index)
        self.collect_selected_artifact_images()
        self.statusBar().showMessage(f"Learning class prepared: {class_name}")

    def add_artifact_type_manual(self):
        if not self._ensure_artifact_database():
            return
        value = self.artifact_new_type.text().strip()
        if value:
            self.artifact_db.add_artifact_type(value)
            self.refresh_artifact_lists()
            self.artifact_type_combo.setCurrentText(value)
            self.artifact_new_type.clear()

    def add_resolution_manual(self):
        if not self._ensure_artifact_database():
            return
        value = self.artifact_new_resolution.text().strip()
        if value:
            self.artifact_db.add_resolution(value)
            self.refresh_artifact_lists()
            self.artifact_resolution_combo.setCurrentText(value)
            self.artifact_new_resolution.clear()

    def collect_selected_artifact_images(self):
        self._tree_selection_changed()
        if not self.artifact_selected_indices and self.dicom_entries:
            self.artifact_selected_indices = [getattr(self, "slice_index", 0)]
        self.artifact_selection_label.setText(
            f"Training images ready: {len(self.artifact_selected_indices)}"
        )
        self.tabs.setCurrentIndex(2)

    def preview_artifact_learning_image(self):
        self._tree_selection_changed()
        if not self.artifact_selected_indices:
            QMessageBox.information(
                self, "Artifact Learning Preview", "Select one or more DICOM images in Explorer."
            )
            return
        self.artifact_preview_position = max(
            0, min(self.artifact_preview_position, len(self.artifact_selected_indices) - 1)
        )
        index = self.artifact_selected_indices[self.artifact_preview_position]
        if not (0 <= index < len(self.dicom_entries)):
            return
        entry = self.dicom_entries[index]
        self.artifact_preview_panel.label.setText(
            f"Artifact Learning Preview: {entry.path.name} "
            f"({self.artifact_preview_position + 1}/{len(self.artifact_selected_indices)})"
        )
        self.artifact_preview_panel.set_image(np.asarray(entry.image, dtype=float))
        self.artifact_selection_label.setText(
            f"Training images ready: {len(self.artifact_selected_indices)} | "
            f"Previewing {entry.path.name}"
        )

    def navigate_artifact_preview(self, step: int):
        if not self.artifact_selected_indices:
            self._tree_selection_changed()
        if not self.artifact_selected_indices:
            return
        self.artifact_preview_position = (
            self.artifact_preview_position + int(step)
        ) % len(self.artifact_selected_indices)
        self.preview_artifact_learning_image()

    def set_current_normal_reference(self):
        if self.current_image is None:
            QMessageBox.information(self, "Normal Reference", "Load an image first.")
            return
        self.normal_reference_image = np.asarray(self.current_image, dtype=float).copy()
        self.normal_reference_path = Path(self.current_source) if self.current_source else None
        self.artifact_normal_label.setText(
            f"Normal reference: {self.normal_reference_path or 'Current image'}"
        )

    def load_normal_reference(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Load Normal Reference", "",
            "DICOM or NumPy (*.dcm *.ima *.npy *.npz);;All files (*)"
        )
        if not filename:
            return
        path = Path(filename)
        try:
            if path.suffix.lower() == ".npy":
                image = np.load(path, allow_pickle=False)
            elif path.suffix.lower() == ".npz":
                archive = np.load(path, allow_pickle=False)
                image = archive[list(archive.keys())[0]]
            else:
                image = self.read_dicom(path).image
            image = np.asarray(image).squeeze()
            if image.ndim != 2:
                raise ValueError(f"Normal reference must be 2D: {image.shape}")
            self.normal_reference_image = image.astype(float)
            self.normal_reference_path = path
            self.artifact_normal_label.setText(f"Normal reference: {path}")
        except Exception as exc:
            QMessageBox.critical(self, "Normal Reference Error", str(exc))

    def save_artifact_training_samples(self):
        if not self._ensure_artifact_database():
            return
        indices = [
            i for i in self.artifact_selected_indices
            if 0 <= i < len(self.dicom_entries)
        ]
        if not indices:
            QMessageBox.information(self, "Artifact Learning", "Select DICOM images first.")
            return
        artifact_type = self.artifact_type_combo.currentText().strip() or "Not Artifact"
        resolution = self.artifact_resolution_combo.currentText().strip()
        notes = self.artifact_notes.toPlainText().strip()
        progress = self._make_progress("Saving Artifact Training Samples", len(indices))
        saved = 0
        try:
            for count, index in enumerate(indices, start=1):
                if progress.wasCanceled():
                    break
                entry = self.dicom_entries[index]
                progress.setLabelText(f"Analyzing image: {entry.path.name}")
                features = image_features(entry.image, self.normal_reference_image)
                ds = entry.ds
                self.artifact_db.add_sample(
                    source_path=str(entry.path),
                    source_name=entry.path.name,
                    series_uid=str(getattr(ds, "SeriesInstanceUID", "")),
                    series_description=str(
                        getattr(ds, "SeriesDescription", "")
                        or getattr(ds, "ProtocolName", "")
                    ),
                    instance_number=int(getattr(ds, "InstanceNumber", index) or index),
                    artifact_type=artifact_type,
                    resolution=resolution,
                    is_normal_reference=False,
                    normal_reference_path=str(self.normal_reference_path or ""),
                    features=features,
                    notes=notes,
                )
                saved += 1
                progress.setValue(count)
        finally:
            progress.close()
        self.refresh_artifact_training_table()
        self.artifact_summary.setText(
            f"Saved {saved} sample(s) as {artifact_type}. "
            f"Normal comparison: {'Yes' if self.normal_reference_image is not None else 'No'}"
        )

    def refresh_artifact_training_table(self):
        if self.artifact_db is None:
            self.artifact_training_table.setRowCount(0)
            return
        rows = self.artifact_db.samples()
        self.artifact_training_table.setRowCount(len(rows))
        for r, sample in enumerate(rows):
            try:
                features = json.loads(sample.get("features_json", "{}"))
            except Exception:
                features = {}
            values = [
                sample["id"], sample["source_name"], sample["series_description"],
                sample["instance_number"], sample["artifact_type"],
                sample["resolution"] or "",
                "Yes" if features.get("normal_comparison") else "No",
                sample["source_path"] or "",
            ]
            for c, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.UserRole, int(sample["id"]))
                self.artifact_training_table.setItem(r, c, item)
        self.artifact_training_table.resizeColumnsToContents()

    def reclassify_selected_db_rows(self):
        if self.artifact_db is None:
            return
        rows = sorted({i.row() for i in self.artifact_training_table.selectedItems()})
        artifact_type = self.artifact_type_combo.currentText().strip() or "Not Artifact"
        resolution = self.artifact_resolution_combo.currentText().strip()
        notes = self.artifact_notes.toPlainText().strip()
        for row in rows:
            item = self.artifact_training_table.item(row, 0)
            if item is not None:
                self.artifact_db.update_sample_classification(
                    int(item.data(Qt.UserRole)), artifact_type, resolution, notes
                )
        self.refresh_artifact_training_table()

    def import_artifact_database(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Import Artifact DB JSON", "",
            "Artifact DB JSON (*.json);;All files (*)"
        )
        if not filename:
            return
        if self.artifact_db is None:
            self.open_artifact_database()
        if self.artifact_db is None:
            return
        self.artifact_db.import_json(Path(filename))
        self.refresh_artifact_lists()
        self.refresh_artifact_training_table()


    def export_artifact_database(self):
        if self.artifact_db is None:
            QMessageBox.information(self, "Artifact DB", "Open an Artifact DB first.")
            return
        filename, _ = QFileDialog.getSaveFileName(
            self, "Export Artifact DB JSON", "MRI_Artifact_DB.json",
            "Artifact DB JSON (*.json)"
        )
        if filename:
            if not filename.lower().endswith(".json"):
                filename += ".json"
            self.artifact_db.export_json(Path(filename))

    def fill_header(self, ds):
        return


    def filter_header(self, value):
        return


    def export_header_excel(self):
        if self.current_ds is None: QMessageBox.information(self,'No DICOM','Load a DICOM file first.'); return
        filename,_=QFileDialog.getSaveFileName(self,'Export DICOM Header','DICOM_Header.xlsx','Excel (*.xlsx)')
        if not filename: return
        if not filename.lower().endswith('.xlsx'): filename += '.xlsx'
        wb=Workbook(); ws=wb.active; ws.title='DICOM Header'; headers=['Tag','Keyword','Name','VR','VM','Value']; ws.append(headers)
        for cell in ws[1]: cell.font=Font(bold=True); cell.fill=PatternFill('solid', fgColor='D9EAF7')
        for elem in self.current_ds.iterall():
            if elem.tag.group != 0x7FE0: ws.append([str(elem.tag),elem.keyword,elem.name,elem.VR,str(elem.VM),str(elem.value)])
        ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
        for col,width in {'A':16,'B':28,'C':38,'D':8,'E':8,'F':80}.items(): ws.column_dimensions[col].width=width
        for row in ws.iter_rows():
            for cell in row: cell.alignment=Alignment(vertical='top', wrap_text=True)
        wb.save(filename); self.statusBar().showMessage(f'Exported {filename}')

    def export_npz(self):
        if self.current_image is None: return
        filename,_=QFileDialog.getSaveFileName(self,'Export NPZ','MRI_FFT_Data.npz','NPZ (*.npz)')
        if filename:
            if not filename.lower().endswith('.npz'): filename += '.npz'
            np.savez_compressed(filename,image=self.current_image,kspace=self.current_kspace,reconstruction=self.current_recon,source=self.current_source)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._schedule_responsive_layout()


    def showEvent(self, event):
        super().showEvent(event)
        QTimer.singleShot(0, self._initial_screen_fit)
        QTimer.singleShot(180, self._initial_screen_fit)

    def closeEvent(self, event):
        self._save_viewer_layout()
        self.import_cancel_event.set()
        if self.import_worker is not None:
            try: self.import_worker.cancel()
            except Exception: pass
        for directory in self.temp_dirs:
            try: shutil.rmtree(directory, ignore_errors=True)
            except Exception: pass
        event.accept()

def validate_startup_dependencies():
    required_names = [
        "QApplication",
        "QMainWindow",
        "QGridLayout",
        "QProgressBar",
        "QSizePolicy",
        "QTreeWidget",
        "QMimeData",
        "QUrl",
        "QDrag",
        "MainWindow",
    ]
    missing = [name for name in required_names if name not in globals()]
    if missing:
        raise RuntimeError(
            "Missing startup dependency/import: " + ", ".join(missing)
        )


def write_startup_error(error: BaseException) -> Path:
    log_dir = Path.home() / "AppData" / "Local" / "MR_Image_Explorer"
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        log_dir = Path.cwd()

    log_path = log_dir / "startup_error.log"
    try:
        import traceback
        log_path.write_text(
            "MR Image Explorer startup failed.\n\n"
            + "".join(
                traceback.format_exception(
                    type(error),
                    error,
                    error.__traceback__,
                )
            ),
            encoding="utf-8",
        )
    except Exception:
        pass
    return log_path


def main():
    try:
        validate_startup_dependencies()

        app = QApplication(sys.argv)
        app.setApplicationName(APP_NAME)
        app.setOrganizationName("InSightec")

        window = MainWindow()
        window.show()
        window.raise_()
        window.activateWindow()

        # Used by GitHub Actions to verify that both Python and packaged EXE
        # actually create the application window and enter the Qt event loop.
        if os.environ.get("MRIE_STARTUP_SMOKE_TEST") == "1":
            QTimer.singleShot(1200, app.quit)

        return app.exec()

    except BaseException as error:
        log_path = write_startup_error(error)

        try:
            app = QApplication.instance()
            if app is None:
                app = QApplication(sys.argv)
            QMessageBox.critical(
                None,
                "MR Image Explorer - Startup Error",
                f"{type(error).__name__}: {error}\n\n"
                f"Log:\n{log_path}",
            )
        except Exception:
            pass

        return 1


if __name__ == "__main__":
    raise SystemExit(main())
