"""Commit0139 spike/noise detection accuracy regression test.

Runs entirely without PySide6/pydicom. Static markers confirm the fix is
present in app.py; functional checks extract the *actual* MainWindow methods
via AST and run them against synthetic data with known injected spikes, so
the test exercises the real algorithm rather than a re-typed copy.

Three things are covered:

1. A pre-existing latent bug: `_robust_z` was defined without @staticmethod
   yet called as `self._robust_z(magnitude)` inside `_analyze_spike_signal`
   (the Spike Diag 1D quick-scan path). That call raises TypeError at
   runtime ("_robust_z() takes 1 positional argument but 2 were given"),
   so the 1D screening could never have completed successfully before this
   fix. This test calls `_analyze_spike_signal` for real and asserts it
   does not raise.

2. 1D signal screening (Spike Diag): a sliding-window local robust z-score
   is added alongside the existing global one, so a subtle spike sitting in
   a naturally quiet stretch of a signal with a varying baseline amplitude
   is no longer diluted by louder stretches elsewhere in the same signal.

3. 2D RAW k-space point detection (Quick Spike / Auto Correct candidate
   screening): the flat whole-region global z-score is replaced with a
   radial-binned one, because k-space magnitude naturally falls off with
   radius. This improves recall for spikes near the outer edge and reduces
   false positives on normal bright structure just outside the excluded
   center.
"""
import ast
from pathlib import Path

import numpy as np

text = Path("app.py").read_text(encoding="utf-8")

# --- static markers -------------------------------------------------------
for marker in (
    "def _local_robust_z",
    "def _radial_robust_zscore",
    "local_amplitude_z = self._local_robust_z(magnitude)",
    "global_z = cls._radial_robust_zscore(safe, valid_mask, cy, cx)",
):
    assert marker in text, marker

tree = ast.parse(text)
main_window = next(
    node for node in ast.walk(tree)
    if isinstance(node, ast.ClassDef) and node.name == "MainWindow"
)
robust_z_node = next(
    item for item in main_window.body
    if isinstance(item, ast.FunctionDef) and item.name == "_robust_z"
)
assert any(
    isinstance(d, ast.Name) and d.id == "staticmethod"
    for d in robust_z_node.decorator_list
), "_robust_z must be @staticmethod (it is called as self._robust_z(...))"
print("Commit0139 static markers: PASS")

# --- extract the real methods from app.py via AST -------------------------
wanted = {
    "_robust_z", "_local_robust_z", "_group_spike_indices", "_analyze_spike_signal",
    "_robust_zscore", "_radial_robust_zscore", "_raw_spike_features",
}
found = {}
for item in main_window.body:
    if isinstance(item, ast.FunctionDef) and item.name in wanted:
        found[item.name] = ast.get_source_segment(text, item)
assert wanted <= found.keys(), wanted - found.keys()

namespace = {"np": np}
exec(compile("\n\n".join(found.values()), "<app.py extract>", "exec"), namespace)


class _Fake:
    _robust_z = staticmethod(namespace["_robust_z"])
    _local_robust_z = staticmethod(namespace["_local_robust_z"])
    _group_spike_indices = staticmethod(namespace["_group_spike_indices"])
    _analyze_spike_signal = namespace["_analyze_spike_signal"]
    _robust_zscore = staticmethod(namespace["_robust_zscore"])
    _radial_robust_zscore = classmethod(namespace["_radial_robust_zscore"])
    _raw_spike_features = classmethod(namespace["_raw_spike_features"])


fake = _Fake()

# --- 1) the latent self._robust_z(...) TypeError must be gone -------------
signal = np.abs(np.random.default_rng(0).normal(10, 1, 500))
result = fake._analyze_spike_signal(signal, threshold=6.0)
assert isinstance(result, dict) and "flagged" in result
print("Commit0139 _analyze_spike_signal no longer raises TypeError: PASS")

# --- 2) 1D: subtle spike hidden in a quiet stretch of a varying envelope --
n_trials = 150
hits_global_only = 0
hits_with_local = 0
for trial in range(n_trials):
    rng = np.random.default_rng(trial)
    n = 1500
    dyn_range = rng.uniform(5, 60)
    envelope = 3.0 + dyn_range * (0.5 + 0.5 * np.sin(np.linspace(0, rng.uniform(2, 4) * np.pi, n)))
    sig = envelope * (1.0 + rng.normal(0, 0.07, n))
    quiet_idx = int(np.clip(int(np.argmin(envelope[: n // 3])) + rng.integers(-5, 5), 30, n - 30))
    fold = rng.uniform(2.5, 4.5)
    sig[quiet_idx] = envelope[quiet_idx] * fold

    magnitude = np.abs(sig)
    global_z = fake._robust_z(magnitude)
    local_z = fake._local_robust_z(magnitude)
    threshold = 5.0
    hits_global_only += bool(global_z[quiet_idx] >= threshold)
    hits_with_local += bool(max(global_z[quiet_idx], local_z[quiet_idx]) >= threshold)

recall_before = hits_global_only / n_trials
recall_after = hits_with_local / n_trials
assert recall_after > recall_before + 0.5, (recall_before, recall_after)
assert recall_after >= 0.9, recall_after
print(f"Commit0139 1D recall on subtle hidden spikes: {recall_before:.0%} -> {recall_after:.0%}: PASS")

# False positives on clean (no injected spike) signals must stay low.
false_positive_samples = 0
total_samples = 0
for trial in range(20):
    rng = np.random.default_rng(9000 + trial)
    n = 1500
    dyn_range = rng.uniform(5, 60)
    envelope = 3.0 + dyn_range * (0.5 + 0.5 * np.sin(np.linspace(0, rng.uniform(2, 4) * np.pi, n)))
    sig = envelope * (1.0 + rng.normal(0, 0.07, n))
    magnitude = np.abs(sig)
    global_z = fake._robust_z(magnitude)
    local_z = fake._local_robust_z(magnitude)
    false_positive_samples += int(np.sum(np.maximum(global_z, local_z) >= 5.0))
    total_samples += n
assert false_positive_samples / total_samples < 0.01, false_positive_samples
print(f"Commit0139 1D false-positive rate on clean signals: {false_positive_samples}/{total_samples}: PASS")


# --- 3) 2D: radial-binned global_z for RAW k-space point detection --------
def make_synthetic_kspace(rows=128, cols=128, seed=0):
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:rows, 0:cols]
    cy, cx = rows // 2, cols // 2
    r = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2) + 1.0
    base = 5000.0 / (1.0 + (r / 6.0) ** 1.6)
    noise = np.exp(rng.normal(0, 0.35, size=base.shape))
    return base * noise, cy, cx, r


def inject_spike(mag, y, x, fold):
    local_baseline = mag[max(0, y - 3):y + 4, max(0, x - 3):x + 4]
    mag[y, x] = np.median(local_baseline) * fold
    return mag


rng = np.random.default_rng(42)
n_trials_2d = 120
hits_flat = 0
hits_radial = 0
for trial in range(n_trials_2d):
    magnitude, cy, cx, r = make_synthetic_kspace(seed=1000 + trial)
    rows, cols = magnitude.shape
    valid = np.ones_like(magnitude, dtype=bool)
    valid[cy - 3:cy + 4, cx - 3:cx + 4] = False

    radius = rng.uniform(8, 60)
    angle = rng.uniform(0, 2 * np.pi)
    y = int(np.clip(cy + radius * np.sin(angle), 4, rows - 5))
    x = int(np.clip(cx + radius * np.cos(angle), 4, cols - 5))
    fold = rng.uniform(5.0, 12.0)
    magnitude = inject_spike(magnitude, y, x, fold)
    safe = np.log1p(magnitude)

    neighbor_stack = np.stack([
        np.roll(safe, (dy, dx), axis=(0, 1))
        for dy, dx in ((-2, 0), (-1, -1), (-1, 0), (-1, 1), (0, -2), (0, -1), (0, 1), (0, 2), (1, -1), (1, 0), (1, 1), (2, 0))
    ])
    local_median = np.median(neighbor_stack, axis=0)
    local_mad = np.median(np.abs(neighbor_stack - local_median[None, ...]), axis=0)
    local_z = (safe - local_median) / np.maximum(1.4826 * local_mad, 1e-6)

    gz_flat = np.zeros_like(safe)
    gz_flat[valid] = fake._robust_zscore(safe[valid])
    gz_radial = fake._radial_robust_zscore(safe, valid, cy, cx)

    hits_flat += bool(valid[y, x] and local_z[y, x] > 6.0 and gz_flat[y, x] > 4.5)
    hits_radial += bool(valid[y, x] and local_z[y, x] > 6.0 and gz_radial[y, x] > 4.5)

recall_flat = hits_flat / n_trials_2d
recall_radial = hits_radial / n_trials_2d
assert recall_radial > recall_flat + 0.2, (recall_flat, recall_radial)
print(f"Commit0139 2D recall (local_z & global_z point_mask): flat {recall_flat:.0%} -> radial {recall_radial:.0%}: PASS")

# False positives on clean (no spike) k-space must not increase.
fp_flat = 0
fp_radial = 0
valid_px_total = 0
for seed in range(15):
    magnitude, cy, cx, r = make_synthetic_kspace(seed=seed)
    rows, cols = magnitude.shape
    valid = np.ones_like(magnitude, dtype=bool)
    valid[cy - 3:cy + 4, cx - 3:cx + 4] = False
    safe = np.log1p(magnitude)
    gz_flat = np.zeros_like(safe)
    gz_flat[valid] = fake._robust_zscore(safe[valid])
    gz_radial = fake._radial_robust_zscore(safe, valid, cy, cx)
    fp_flat += int(np.sum(valid & (gz_flat > 4.5)))
    fp_radial += int(np.sum(valid & (gz_radial > 4.5)))
    valid_px_total += int(np.sum(valid))

assert fp_radial <= fp_flat, (fp_flat, fp_radial)
print(f"Commit0139 2D false positives on clean k-space: flat {fp_flat} -> radial {fp_radial} (of {valid_px_total} px): PASS")

print("Commit0139 spike/noise accuracy functional checks: PASS")
