"""Commit0152 regression test: extend Commit0151's test-pattern/non-image
exclusion to paths 3/4 (Auto Correct, Manual Paint's Auto-detect assist),
both of which call core/hybrid_compensation.py's detect_artifacts().

core/ modules cannot import from app.py (would create a circular import),
so _fus_image_likeness, _looks_like_test_pattern, and a new
_spike_eligible_image were ported into core/hybrid_compensation.py in
exact numeric agreement with app.py's versions, and wired into
detect_artifacts() itself (the one function both Auto Correct and Manual
Paint's Auto-detect actually call for every artifact type), so gating it
there covers both call sites without a separate check in each caller.

While verifying this against the existing test suite, a real bug in the
original _looks_like_test_pattern heuristic (both the app.py version from
Commit0151 and this commit's ported core/ copy) was found and fixed:
comparing *every* row/column pair false-flagged a legitimate small-blob-
against-large-dark-background signal (exactly
test_commit0099_explicit_auto_precision_guard.py's own synthetic test
data) as a "repeating pattern", because background rows/columns are
trivially near-identical to their neighbors (both close to zero) without
that being evidence of a real repeating pattern. Fixed by only judging
near-duplication among rows/columns that have their own meaningful
internal variation ("active"); with too few active rows/columns to judge
either way, the function now returns "not a test pattern" rather than
guessing.

Runs entirely without PySide6/pydicom.
"""
import warnings
from pathlib import Path

import numpy as np

app_text = Path("app.py").read_text(encoding="utf-8")
hybrid_text = Path("core/hybrid_compensation.py").read_text(encoding="utf-8")

# --- static markers -------------------------------------------------------
for marker in (
    "def _fus_image_likeness(array: np.ndarray) -> float:",
    "def _looks_like_test_pattern(image: np.ndarray) -> bool:",
    "def _spike_eligible_image(image: np.ndarray) -> bool:",
    "reconstructed = np.abs(ifft2c(source))",
    "if not _spike_eligible_image(reconstructed):",
    '"excluded_reason": "calibration/test pattern or non-image data (not real anatomy)"',
):
    assert marker in hybrid_text, marker[:60]
for marker in (
    "active_rows = row_energy > row_thresh",
    "row_pair_active = active_rows[:-1] | active_rows[1:]",
):
    assert marker in app_text, marker[:60]
    assert marker in hybrid_text, marker[:60]
print("Commit0152 static markers: PASS")

# --- functional: import the real core module and exercise detect_artifacts
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    from core.hybrid_compensation import detect_artifacts, fft2c, ifft2c
    from core.hybrid_compensation import _looks_like_test_pattern as core_looks_like_test_pattern
    from core.hybrid_compensation import _fus_image_likeness as core_fus_image_likeness

    rng = np.random.default_rng(0)
    rows, cols = 256, 256
    yy, xx = np.mgrid[0:rows, 0:cols]

    # Case 1: realistic anatomy -- must NOT be excluded.
    anatomy = 150 * np.exp(-(((yy - 128) ** 2 + (xx - 128) ** 2) / (2 * 60 ** 2))) + rng.normal(0, 8, size=(rows, cols))
    anatomy += 40 * np.sin(yy / 15.0) * np.exp(-(((yy - 128) ** 2 + (xx - 128) ** 2) / (2 * 80 ** 2)))
    det = detect_artifacts(fft2c(anatomy), "Spike", 4.0, "Balanced")
    assert det.stats.get("excluded_reason") is None, det.stats
    print("Commit0152 detect_artifacts: realistic anatomy not excluded: PASS")

    # Case 2: horizontal-band calibration pattern (matches a Commit0151
    # reported screenshot) -- must be excluded, with an empty mask and no
    # candidate evaluation performed.
    bands = np.zeros((rows, cols))
    for i in range(0, rows, 40):
        bands[i:i + 20, :] = 200
    det2 = detect_artifacts(fft2c(bands), "Spike", 4.0, "Balanced")
    assert det2.stats.get("excluded_reason") is not None, det2.stats
    assert not det2.mask.any(), "excluded image must return an empty mask"
    print("Commit0152 detect_artifacts: calibration pattern excluded, empty mask: PASS")

    # Case 3 (regression guard): the exact synthetic signal
    # test_commit0099_explicit_auto_precision_guard.py uses -- a small
    # central blob against a huge, near-uniform dark background -- must
    # NOT be excluded. This is the case the original (Commit0151) version
    # of _looks_like_test_pattern incorrectly flagged.
    n = 128
    y, x = np.mgrid[:n, :n]
    cy = cx = (n - 1) / 2
    r = np.hypot(y - cy, x - cx)
    mag = np.exp(-(r / 18.0) ** 2) + 0.12 * np.exp(-(r / 44.0) ** 2)
    phase = 0.01 * (x - cx)
    k_blob = mag * np.exp(1j * phase)
    reconstructed_blob = np.abs(ifft2c(k_blob))
    assert core_fus_image_likeness(reconstructed_blob) >= 0.10
    assert not core_looks_like_test_pattern(reconstructed_blob), (
        "small-blob-against-dark-background signal must not be flagged as a test pattern"
    )
    det3 = detect_artifacts(k_blob, "Auto", 3.0, "Conservative")
    assert det3.stats.get("excluded_reason") is None, det3.stats
    assert det3.stats.get("detector_revision") == "mri_auto_detection_v8_stage2_artifact_validation", det3.stats
    print("Commit0152 regression guard: small-blob/dark-background signal "
          "(test_commit0099's own data) is not falsely excluded: PASS")

    # Case 4: recall on realistic point-spike k-space is not degraded by
    # the new gate (eligible images must pass straight through to the
    # normal detection logic).
    def make_kspace(seed=0, rows=256, cols=256):
        rng_local = np.random.default_rng(seed)
        yy_l, xx_l = np.mgrid[0:rows, 0:cols]
        cy_l, cx_l = rows / 2, cols / 2
        r_l = np.sqrt((yy_l - cy_l) ** 2 + (xx_l - cx_l) ** 2) + 1.0
        base = 5000.0 / (1.0 + (r_l / 6.0) ** 1.6)
        noise = np.exp(rng_local.normal(0, 0.35, size=base.shape))
        mag_l = base * noise
        phase_l = rng_local.uniform(0, 2 * np.pi, size=mag_l.shape)
        return mag_l * np.exp(1j * phase_l)

    def inject(kspace, y, x, fold):
        mag_l = np.abs(kspace)
        phase_l = np.angle(kspace)
        local = mag_l[max(0, y - 3):y + 4, max(0, x - 3):x + 4]
        mag_l[y, x] = np.median(local) * fold
        return mag_l * np.exp(1j * phase_l)

    rng2 = np.random.default_rng(555)
    n_trials = 30
    hits = 0
    for i in range(n_trials):
        ks = make_kspace(seed=3000 + i)
        radius = rng2.uniform(10, 70)
        angle = rng2.uniform(0, 2 * np.pi)
        y = int(np.clip(128 + radius * np.sin(angle), 4, 251))
        x = int(np.clip(128 + radius * np.cos(angle), 4, 251))
        fold = rng2.uniform(6, 14)
        ks2 = inject(ks, y, x, fold)
        det4 = detect_artifacts(ks2, "Spike", 4.0, "Balanced")
        assert det4.stats.get("excluded_reason") is None, "realistic k-space must not be excluded"
        hits += bool(det4.mask[y, x])
    recall = hits / n_trials
    assert recall >= 0.60, recall
    print(f"Commit0152 recall on realistic point-spike k-space unaffected by "
          f"the new gate: {hits}/{n_trials} ({recall:.0%}): PASS")

print("Commit0152 Auto Correct / Manual Paint test-pattern exclusion functional checks: PASS")
