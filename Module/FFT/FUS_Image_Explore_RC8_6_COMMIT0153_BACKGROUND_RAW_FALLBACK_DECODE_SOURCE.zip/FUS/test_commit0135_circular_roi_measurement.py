import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
import numpy as np
from PySide6.QtWidgets import QApplication
from app import ImagePanel

app = QApplication.instance() or QApplication([])
panel = ImagePanel("ROI Test")
image = np.arange(100, dtype=float).reshape(10, 10)
panel.set_image(image)
panel.show_measure_roi()
panel.measure_roi.setPos(2, 2)
panel.measure_roi.setSize((4, 4))
panel._update_measurement()
r = panel._last_measurement
assert r is not None
assert (r["x"], r["y"], r["width_px"], r["height_px"]) == (2, 2, 4, 4)
values = image[2:6, 2:6]
yy, xx = np.mgrid[2:6, 2:6]
center_x = 4.0
center_y = 4.0
radius = 2.0
mask = ((xx + 0.5 - center_x) / radius) ** 2 + ((yy + 0.5 - center_y) / radius) ** 2 <= 1.0
expected = values[mask]
assert expected.size == r["pixels"]
assert np.isclose(r["mean"], expected.mean())
assert np.isclose(r["std"], expected.std())
assert np.isclose(r["median"], np.median(expected))
assert np.isclose(r["min"], expected.min())
assert np.isclose(r["max"], expected.max())
panel.hide_measure_roi()
assert not panel.measure_roi.isVisible()
print("PASS: Commit0135 circular ROI measurement")
