"""Commit0142 regression test: detect_artifacts radial/flat blended z.

`detect_artifacts` (core/hybrid_compensation.py) is shared by Raw Data
Compensation's Auto Correct ("Spike"/"Line"/"Band"/"Block"/"Diagonal"
candidate types) and the Expert manual-mask suggestion tools in app.py. Its
Spike/Line/Band/Block detection all derived from one flat median/MAD z-score
over the whole k-space -- the same structural issue fixed for point
detection in Commit0139 (app.py), just not yet fixed here.

A pure per-radius-bin statistic (mirroring Commit0139's
_radial_robust_zscore exactly) measurably improved Spike recall on
synthetic edge spikes (64% -> 90% in interactive testing) but also
increased false positives on clean data (0 -> roughly 90-126 px across
20-40 clean trials), because a per-bin estimate is based on fewer samples
than the flat one and is therefore noisier. Blending flat and radial
z-scores (radial_weight=0.3) keeps most of the recall gain while cutting
the false-positive increase substantially.

Runs entirely without PySide6/pydicom.
"""
import warnings
from pathlib import Path

import numpy as np

text = Path("core/hybrid_compensation.py").read_text(encoding="utf-8")
for marker in (
    "def _radial_robust_z",
    "radial_weight: float = 0.3",
    "z = _radial_robust_z(logmag, cy, cx)",
):
    assert marker in text, marker
print("Commit0142 static markers: PASS")

import sys  # noqa: E402
sys.path.insert(0, ".")
from core.hybrid_compensation import detect_artifacts  # noqa: E402


def make_kspace(seed=0, rows=256, cols=256):
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:rows, 0:cols]
    cy, cx = rows / 2, cols / 2
    r = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2) + 1.0
    base = 5000.0 / (1.0 + (r / 6.0) ** 1.6)
    noise = np.exp(rng.normal(0, 0.35, size=base.shape))
    mag = base * noise
    phase = rng.uniform(0, 2 * np.pi, size=mag.shape)
    return mag * np.exp(1j * phase)


def inject_point(kspace, y, x, fold):
    mag = np.abs(kspace)
    phase = np.angle(kspace)
    local = mag[max(0, y - 3):y + 4, max(0, x - 3):x + 4]
    mag[y, x] = np.median(local) * fold
    return mag * np.exp(1j * phase)


with warnings.catch_warnings():
    warnings.simplefilter("ignore")

    # --- recall across random radii, moderate sample size for CI speed ---
    rng = np.random.default_rng(99)
    hits = 0
    n_trials = 40
    for i in range(n_trials):
        ks = make_kspace(seed=2000 + i)
        radius = rng.uniform(10, 60)
        angle = rng.uniform(0, 2 * np.pi)
        y = int(np.clip(128 + radius * np.sin(angle), 4, 251))
        x = int(np.clip(128 + radius * np.cos(angle), 4, 251))
        ks2 = inject_point(ks, y, x, rng.uniform(8, 15))
        det = detect_artifacts(ks2, "Spike", 4.0, "Balanced")
        hits += bool(det.mask[y, x])
    recall = hits / n_trials
    assert recall >= 0.75, recall
    print(f"Commit0142 Spike recall across random radii: {hits}/{n_trials} ({recall:.0%}): PASS")

    # --- false positives on clean data stay bounded (not necessarily zero,
    # documented trade-off; must not regress to the ~unbounded rate seen
    # with a pure, unblended per-bin statistic in interactive testing) ---
    fp_pixels = 0
    n_clean = 15
    for seed in range(n_clean):
        ks = make_kspace(seed=6000 + seed)
        det = detect_artifacts(ks, "Spike", 4.0, "Balanced")
        fp_pixels += int(det.mask.sum())
    fp_rate = fp_pixels / (n_clean * 256 * 256)
    assert fp_rate < 0.001, (fp_pixels, fp_rate)
    print(f"Commit0142 false-positive pixel rate on {n_clean} clean images: "
          f"{fp_pixels} px ({fp_rate:.5%}): PASS")

print("Commit0142 detect_artifacts radial/flat blended z functional checks: PASS")
