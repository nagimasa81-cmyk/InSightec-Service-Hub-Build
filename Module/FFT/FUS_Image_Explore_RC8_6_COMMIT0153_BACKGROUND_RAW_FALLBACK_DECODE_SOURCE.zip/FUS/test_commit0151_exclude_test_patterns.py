"""Commit0151 regression test: exclude calibration/test patterns and
non-image data from spike detection.

User-reported (with four screenshots): repeating stripe/band calibration
patterns (labeled "MEMP", an otherwise MRI-eligible category) and a tiny
synthetic/simulated file ("SimulatedPeak_41x41.raw", whose own
"image-likeness" score the app already computes and displays was 0.000)
were still being spike-detected and listed as results, even after
Commit0148/0149's MRI-only category/Modality filtering.

Two new module-level functions in app.py:
- `_looks_like_test_pattern(image)`: flags a repeating calibration pattern
  (e.g. horizontal bands or vertical stripes) that `_fus_image_likeness`
  alone cannot distinguish from real tissue, because such patterns are
  often locally very smooth (so adjacent-pixel correlation scores high,
  same as real anatomy).
- `_spike_eligible_image(image)`: combines a `_fus_image_likeness`
  threshold (catches non-image/noise-like data such as the reported
  SimulatedPeak file) with `_looks_like_test_pattern` (catches repeating
  calibration patterns) into one gate, used in addition to the existing
  MRI-only category/Modality gate (Commit0148/0149).

Applied at five spike-detection call sites: Spike Diag's DICOM loop
(`_activate_spike_diag_from_workspace_selection`), its current-workspace-
image branch, `apply_spike_processing`'s DICOM loop, and Quick Spike
Detect's DICOM and RAW loops.

Runs entirely without PySide6/pydicom.
"""
import ast
from pathlib import Path

import numpy as np

text = Path("app.py").read_text(encoding="utf-8")

# --- static markers -------------------------------------------------------
for marker in (
    "def _looks_like_test_pattern(image: np.ndarray) -> tuple[bool, str]:",
    "def _spike_eligible_image(image: np.ndarray) -> tuple[bool, str]:",
    "_fus_image_likeness,",  # imported from raw_import_engine
    "eligible_image, _reason = _spike_eligible_image(entry.image)",
    "eligible_image, pattern_reason = _spike_eligible_image(self.current_image)",
    "eligible_image, _reason = _spike_eligible_image(image)",
    'cached_likeness = getattr(result, "fus_image_likeness", None)',
):
    assert marker in text, marker[:70]
print("Commit0151 static markers: PASS")

call_sites = text.count("_spike_eligible_image(")
# 1 def + 1 internal call inside _spike_eligible_image's own body is not
# present (it calls _fus_image_likeness/_looks_like_test_pattern, not
# itself), so every occurrence besides the def is a real call site.
assert call_sites >= 5, call_sites
print(f"Commit0151 _spike_eligible_image wired at {call_sites - 1} call sites: PASS")

# --- functional: extract the real functions via AST and test them against
# synthetic data shaped like the four reported screenshots -----------------
tree = ast.parse(text)
found = {}
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name in ("_looks_like_test_pattern", "_spike_eligible_image"):
        found[node.name] = ast.get_source_segment(text, node)
assert {"_looks_like_test_pattern", "_spike_eligible_image"} <= found.keys()

from raw_import_engine import _fus_image_likeness  # noqa: E402

namespace = {"np": np, "_fus_image_likeness": _fus_image_likeness}
exec(compile("\n\n".join(found.values()), "<app.py extract>", "exec"), namespace)
spike_eligible_image = namespace["_spike_eligible_image"]

rng = np.random.default_rng(0)
rows, cols = 256, 256
yy, xx = np.mgrid[0:rows, 0:cols]

# Case 1: realistic anatomy-like image (smooth blob + texture + gradient).
anatomy = 150 * np.exp(-(((yy - 128) ** 2 + (xx - 128) ** 2) / (2 * 60 ** 2))) + rng.normal(0, 8, size=(rows, cols))
anatomy += 40 * np.sin(yy / 15.0) * np.exp(-(((yy - 128) ** 2 + (xx - 128) ** 2) / (2 * 80 ** 2)))
eligible, reason = spike_eligible_image(anatomy)
assert eligible, reason
print("Commit0151 realistic anatomy-like image: eligible: PASS")

# Case 2: horizontal bands (matches the first reported screenshot,
# "2-2-3-0.raw | MEMP" showing repeating horizontal stripes).
bands = np.zeros((rows, cols))
for i in range(0, rows, 40):
    bands[i:i + 20, :] = 200
eligible, reason = spike_eligible_image(bands)
assert not eligible and "pattern" in reason, reason
print(f"Commit0151 horizontal-band calibration pattern excluded ({reason}): PASS")

# Case 3: vertical stripes (matches the second reported screenshot,
# "28-1-0-0.raw | MEMP" showing repeating vertical stripes).
stripes = np.zeros((rows, cols))
for j in range(0, cols, 4):
    stripes[:, j:j + 2] = 200
eligible, reason = spike_eligible_image(stripes)
assert not eligible and "pattern" in reason, reason
print(f"Commit0151 vertical-stripe calibration pattern excluded ({reason}): PASS")

# Case 4: pure random noise standing in for the reported
# "SimulatedPeak_41x41.raw" file (whose own image-likeness score the app
# already showed as 0.000).
noise = rng.normal(0, 50, size=(64, 64))
eligible, reason = spike_eligible_image(noise)
assert not eligible and "not image-like" in reason, reason
print(f"Commit0151 non-image/noise-like data excluded ({reason}): PASS")

# Case 5: too-small data (mirrors a tiny synthetic array like the 41x41
# reported file, below the minimum sample size fus_image_likeness itself
# requires).
tiny = rng.normal(0, 50, size=(41, 41))
eligible, reason = spike_eligible_image(tiny)
assert not eligible, reason
print(f"Commit0151 too-small array excluded ({reason}): PASS")

print("Commit0151 test-pattern/non-image exclusion functional checks: PASS")
