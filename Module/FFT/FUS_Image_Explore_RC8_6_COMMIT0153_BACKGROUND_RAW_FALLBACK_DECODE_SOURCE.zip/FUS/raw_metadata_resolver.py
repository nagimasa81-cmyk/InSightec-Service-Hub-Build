from __future__ import annotations

import math
import os
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Any
from core.fus_export_core import virtual_raw_header


AXIS_NORMALIZE = {"IS": "SI", "SI": "SI", "PA": "AP", "AP": "AP", "LR": "RL", "RL": "RL"}
PLANE_AXES = {
    "AXIAL": {"ROW": "RL", "COL": "AP"},
    "CORONAL": {"ROW": "RL", "COL": "SI"},
    "SAGITTAL": {"ROW": "AP", "COL": "SI"},
}
TEXT_EXTENSIONS = {".txt", ".log", ".out", ".ini", ".cfg", ".xml", ".json", ".yaml", ".yml", ".par", ".hdr", ".asc", ".pro", ".dat"}


@dataclass(frozen=True)
class MetadataRecord:
    path: Path
    text: str
    lower: str
    sonication_number: int | None
    series_key: str
    vendor: str
    kind: str


class RawMetadataResolver:
    """Resolve a traceable virtual header for non-DICOM FUS RAW images.

    The resolver never requires review.out. GE can use it when present; Siemens
    instead prefers Phoenix/ASCCONV/SliceArray/MRFILES/protocol evidence.
    """

    @staticmethod
    def read_text(path: Path, limit: int = 8_000_000) -> str:
        try:
            if not path.is_file() or path.stat().st_size > limit:
                return ""
            data = path.read_bytes()
            for enc in ("utf-8", "utf-16-le", "utf-16-be", "latin-1"):
                try:
                    text = data.decode(enc, errors="ignore")
                    if text.strip():
                        return text
                except Exception:
                    continue
        except Exception:
            return ""
        return ""

    @staticmethod
    def normalize_identity(path: Path) -> dict:
        path = Path(path)
        nums = [int(v) for v in re.findall(r"\d+", path.stem)]
        son = None
        match = re.search(r"sonication[ _-]*(\d+)", str(path), re.I)
        if match:
            son = int(match.group(1))
        series_parts = nums[:-1] if len(nums) > 1 else nums
        return {
            "normalized_index": "-".join(map(str, nums)) if nums else path.stem,
            "series_key": "-".join(map(str, series_parts)) if series_parts else path.parent.name,
            "frame_number": nums[-1] if nums else None,
            "sonication_number": son,
        }

    @staticmethod
    def category(path: Path) -> str:
        combined = " ".join(part.lower() for part in Path(path).parts)
        if "tmap3" in combined or "tmap_3" in combined:
            return "TMAP3"
        if "memp" in combined:
            return "MEMP"
        if any(x in combined for x in ("planning mr", "planning_mr", "planningmr", "plan mr", "plan_mr")):
            return "Planning MR"
        if any(x in combined for x in ("anatomy mr", "anatomy_mr", "anatomymr", "anatomical mr", "anatomical_mr")):
            return "Anatomy MR"
        return "Excluded"

    @staticmethod
    def _record_kind(path: Path, low: str) -> str:
        name = path.name.lower()
        if "review.out" in name or name == "review.out":
            return "ge_review"
        if "mrserver" in name:
            return "ge_mrserver"
        if any(x in low for x in ("### asccconv begin", "ascconv", "phoenix", "sslicearray", "snormal.dsag", "snormal.dcor", "snormal.dtra")):
            return "siemens_protocol"
        if "mrfiles" in str(path).lower():
            return "mrfiles"
        if any(x in name for x in ("protocol", "prescription", "series", "scan")):
            return "protocol"
        return "sidecar"

    @staticmethod
    def _clean_attr(value: Any) -> str:
        return str(value or "").strip()

    @classmethod
    def _parse_mri_image_params(cls, path: Path) -> list[dict]:
        rows: list[dict] = []
        try:
            root = ET.parse(path).getroot()
            for elem in root.iter():
                if not elem.attrib:
                    continue
                attrs = {str(k).lower(): cls._clean_attr(v) for k, v in elem.attrib.items()}
                if "fieldindex" not in attrs:
                    continue
                try:
                    key = (int(attrs.get("fieldindex", "-1")), int(attrs.get("sonicationindex", "-1")), int(attrs.get("zoneindex", "-1")), int(attrs.get("arrayindex", "-1")))
                except Exception:
                    continue
                attrs["_key"] = key
                attrs["_source_path"] = str(path)
                rows.append(attrs)
        except Exception:
            return []
        return rows

    @classmethod
    def _mri_params_index(cls, all_files: Iterable[Path]) -> dict:
        exact: dict[tuple[int, int, int, int], dict] = {}
        by_field_son: dict[tuple[int, int], list[dict]] = {}
        sources: list[str] = []
        for value in all_files or []:
            path = Path(value)
            if path.name.lower() != "mriimageparams.xml" or not path.is_file():
                continue
            parsed = cls._parse_mri_image_params(path)
            if parsed:
                sources.append(str(path))
            for row in parsed:
                key = row["_key"]
                exact.setdefault(key, row)
                by_field_son.setdefault((key[0], key[1]), []).append(row)
        return {"exact": exact, "by_field_son": by_field_son, "sources": sources}

    @staticmethod
    def _vector_from_attrs(row: dict, prefix: str):
        try:
            vals = [float(row.get(prefix + "x", "")), float(row.get(prefix + "y", "")), float(row.get(prefix + "z", ""))]
            return vals if sum(v * v for v in vals) > 1e-12 else None
        except Exception:
            return None

    @classmethod
    def _geometry_from_mri_row(cls, row: dict) -> dict:
        row_vec = cls._vector_from_attrs(row, "rowdirectcosras")
        col_vec = cls._vector_from_attrs(row, "coldirectcosras")
        plane = "Unknown"; plane_angle = None
        freq_axis = "Unknown"; freq_angle = None; phase_axis = "Unknown"
        if row_vec is not None and col_vec is not None:
            normal = [row_vec[1]*col_vec[2]-row_vec[2]*col_vec[1], row_vec[2]*col_vec[0]-row_vec[0]*col_vec[2], row_vec[0]*col_vec[1]-row_vec[1]*col_vec[0]]
            normal_axis, plane_angle = cls._axis_from_vector(normal)
            plane = {"SI":"AXIAL", "AP":"CORONAL", "RL":"SAGITTAL"}.get(normal_axis, "Unknown")
            slot = str(row.get("freqdirection", "") or "").strip().upper()
            if slot == "ROW":
                freq_vec, phase_vec = row_vec, col_vec
            elif slot == "COL":
                freq_vec, phase_vec = col_vec, row_vec
            else:
                freq_vec = phase_vec = None
            if freq_vec is not None:
                axis, freq_angle = cls._axis_from_vector(freq_vec)
                if axis:
                    freq_axis = axis if (freq_angle or 0.0) <= 20.0 + 1e-9 else "Oblique >20°"
            if phase_vec is not None:
                axis, _ = cls._axis_from_vector(phase_vec)
                if axis:
                    phase_axis = axis
        return {"scan_plane":plane, "scan_plane_angle_deg":plane_angle, "row_direction_cosines":row_vec or [], "column_direction_cosines":col_vec or [], "frequency_direction":freq_axis, "frequency_angle_deg":freq_angle, "frequency_matrix_axis":str(row.get("freqdirection", "") or "").strip().upper(), "phase_encoding_axis":phase_axis}

    @staticmethod
    def _float_or_none(value: Any, scale: float = 1.0):
        try:
            v = float(str(value).strip()) * scale
            return v if math.isfinite(v) else None
        except Exception:
            return None

    @staticmethod
    def _mri_row_quality(row: dict) -> tuple[int, int, int, int]:
        """Score a candidate MriImageParams row for the field/sonication
        fallback (Commit0143). Mirrors Sonication Analysis's
        SonicationMetadataService._row_for_sonication.quality(): prefer a
        real treatment thermometry/MEMP row with real direction cosines
        over an empty placeholder row that happens to share the same
        (field, sonication) pair.
        """
        series = str(row.get("seriesdiscription") or row.get("seriesdescription") or "").upper()
        treatment = int(any(token in series for token in ("MEMP", "TMAP", "THERM")))
        freq = int(bool(str(row.get("freqdirection") or "").strip()))
        try:
            matrix = int(float(row.get("imgmatrixx") or -1) > 0)
        except (TypeError, ValueError):
            matrix = 0
        try:
            r = [float(row.get(k, 0.0) or 0.0) for k in ("rowdirectcosrasx", "rowdirectcosrasy", "rowdirectcosrasz")]
            c = [float(row.get(k, 0.0) or 0.0) for k in ("coldirectcosrasx", "coldirectcosrasy", "coldirectcosrasz")]
            r_norm = math.sqrt(sum(v * v for v in r))
            c_norm = math.sqrt(sum(v * v for v in c))
            cross_norm = math.sqrt(sum(v * v for v in (
                r[1]*c[2]-r[2]*c[1], r[2]*c[0]-r[0]*c[2], r[0]*c[1]-r[1]*c[0],
            )))
            cosines = int(r_norm > 0.5 and c_norm > 0.5 and cross_norm > 0.5)
        except (TypeError, ValueError):
            cosines = 0
        return (treatment, cosines, freq, matrix)

    @staticmethod
    def _mr_time_ms(value: Any) -> float | None:
        """Commit0143: auto-detect microseconds vs milliseconds by magnitude.

        GE MriImageParams exports store TR/TE in microseconds in most real
        exports seen so far (e.g. 28000 -> 28.0 ms, 3128 -> 3.128 ms), which
        is why this used a fixed x0.001 scale before. But not every export
        is guaranteed to use microseconds, and a fixed scale silently
        divides an already-in-ms value by 1000 if that assumption is ever
        wrong. Mirrors Sonication Analysis's
        SonicationMetadataService._format_mr_time_ms: only values with
        magnitude >= 1000 are treated as microseconds; smaller values are
        assumed to already be milliseconds.
        """
        try:
            v = float(str(value).strip())
        except (TypeError, ValueError):
            return None
        if not math.isfinite(v):
            return None
        return v / 1000.0 if abs(v) >= 1000.0 else v

    @classmethod
    def _mri_row_header(cls, row: dict) -> dict:
        g = cls._geometry_from_mri_row(row)
        sx=cls._float_or_none(row.get("pixsizex")); sy=cls._float_or_none(row.get("pixsizey")); mx=cls._float_or_none(row.get("imgmatrixx")); my=cls._float_or_none(row.get("imgmatrixy"))
        series=str(row.get("seriesdiscription", "") or "").strip(); up=series.upper()
        thermo="TMAP-ME (Multi Echo)" if "TMAP-ME" in up else ("TMAP (Single Echo)" if re.search(r"\bTMAP\b", up) else ("MEMP" if "MEMP" in up else ("TMAP3" if "TMAP3" in up else "Unknown")))
        return {**g, "series_description":series or "Unknown", "protocol_name":series or "Unknown", "thermometry_mode":thermo, "echo_mode":"Multi Echo" if "TMAP-ME" in up else ("Single Echo" if re.search(r"\bTMAP\b", up) else "Unknown"), "echo_number":cls._clean_attr(row.get("echonum")) or "Unknown", "tr_ms":cls._mr_time_ms(row.get("repetitiontimetr")), "te_ms":cls._mr_time_ms(row.get("echotimete")), "flip_angle_deg":cls._float_or_none(row.get("mrflipangle")), "bandwidth_raw":cls._float_or_none(row.get("varbandwidth")), "field_strength_t":cls._float_or_none(row.get("magstrength"),0.0001), "center_frequency_mhz":cls._float_or_none(row.get("centerfreq"),1e-7), "auto_center_frequency_mhz":cls._float_or_none(row.get("autocenterfreq"),1e-7), "matrix":[int(mx),int(my)] if mx is not None and my is not None else [], "pixel_spacing_mm":[sx,sy] if sx is not None and sy is not None else [], "fov_mm":[sx*mx,sy*my] if None not in (sx,sy,mx,my) else [], "slice_thickness_mm":cls._float_or_none(row.get("slicethick")), "image_location":cls._float_or_none(row.get("imgloc")), "image_location_axis":cls._clean_attr(row.get("raslocletter")) or "Unknown", "top_left_ras":[cls._float_or_none(row.get("topleftcoordr")),cls._float_or_none(row.get("topleftcoorda")),cls._float_or_none(row.get("topleftcoords"))], "actual_top_left_ras":[cls._float_or_none(row.get("acttopleftcoordr")),cls._float_or_none(row.get("acttopleftcoorda")),cls._float_or_none(row.get("acttopleftcoords"))], "acquisition_matrix":cls._clean_attr(row.get("acquisitionmatrix")), "series_number":cls._clean_attr(row.get("imgseriesnum")), "image_number":cls._clean_attr(row.get("imgnum")), "series_uid":cls._clean_attr(row.get("seriesuid")), "exam_uid":cls._clean_attr(row.get("imgexamuid")), "image_datetime":cls._clean_attr(row.get("imgdatetime")), "scan_time_raw":cls._clean_attr(row.get("scantime")), "manufacturer":cls._clean_attr(row.get("manufacturer")) or "Unknown", "is_mri_image":cls._clean_attr(row.get("ismriimage")), "image_type_code":cls._clean_attr(row.get("imagetype")), "actual_transmit_gain":cls._clean_attr(row.get("actualtransmitgain")), "auto_transmit_gain":cls._clean_attr(row.get("autotransmitgain")), "shim_xyz":[cls._float_or_none(row.get("shimx")),cls._float_or_none(row.get("shimy")),cls._float_or_none(row.get("shimz"))]}

    @classmethod
    def build_index(cls, all_files: Iterable[Path]) -> dict:
        records: list[MetadataRecord] = []
        votes = {"GE": 0, "Siemens": 0}
        for value in all_files or []:
            path = Path(value)
            if path.suffix.lower() not in TEXT_EXTENSIONS:
                continue
            text = cls.read_text(path)
            if not text:
                continue
            low = (path.name + "\n" + text[:400000]).lower()
            siemens = any(k in low for k in ("siemens", "syngo", "ascconv", "phoenix", "measuid", "twix", "slicearray", "snormal.dsag"))
            ge = any(k in low for k in ("general electric", "ge medical", "mrserver", "review.out", "gehc", "epic"))
            if siemens:
                votes["Siemens"] += 3 if "ascconv" in low or "phoenix" in low else 1
            if ge:
                votes["GE"] += 3 if "review.out" in low or "mrserver" in low else 1
            vendor = "Siemens" if siemens and not ge else ("GE" if ge and not siemens else "Unknown")
            ident = cls.normalize_identity(path)
            records.append(MetadataRecord(path, text, low, ident["sonication_number"], str(ident["series_key"]), vendor, cls._record_kind(path, low)))
        vendor = max(votes, key=votes.get) if max(votes.values(), default=0) else "Unknown"
        mri_params = cls._mri_params_index(all_files)
        return {"vendor": vendor, "vendor_votes": votes, "records": records, "series_cache": {}, "mri_params": mri_params}

    @staticmethod
    def _axis_from_vector(vector) -> tuple[str, float | None]:
        try:
            values = [float(v) for v in vector]
            if len(values) < 3:
                return "", None
            norm = math.sqrt(sum(v * v for v in values[:3]))
            if norm <= 1e-12:
                return "", None
            components = {
                "RL": abs(values[0]) / norm,
                "AP": abs(values[1]) / norm,
                "SI": abs(values[2]) / norm,
            }
            axis = max(components, key=components.get)
            angle = math.degrees(math.acos(max(0.0, min(1.0, components[axis]))))
            return axis, angle
        except Exception:
            return "", None

    @classmethod
    def build_dicom_series_index(cls, dicom_entries: Iterable[Any]) -> list[dict]:
        """Build authoritative series evidence from DICOM headers.

        Siemens (0018,1312) identifies the phase-encoding image axis (ROW/COL).
        ImageOrientationPatient (0020,0037) supplies the patient-space row and
        column direction cosines.  Frequency is the perpendicular in-plane
        vector: COL vector for ROW phase, ROW vector for COL phase.
        """
        grouped: dict[str, dict] = {}
        for entry in dicom_entries or []:
            ds = getattr(entry, "ds", None)
            if ds is None:
                continue
            uid = str(getattr(ds, "SeriesInstanceUID", "") or "").strip()
            series_number = str(getattr(ds, "SeriesNumber", "") or "").strip()
            description = str(getattr(ds, "SeriesDescription", "") or "").strip()
            protocol = str(getattr(ds, "ProtocolName", "") or "").strip()
            key = uid or f"{series_number}|{description}|{protocol}"
            if key in grouped:
                continue
            phase = str(getattr(ds, "InPlanePhaseEncodingDirection", "") or "").strip().upper()
            if not phase:
                try:
                    element = ds.get((0x0018, 0x1312))
                    phase = str(getattr(element, "value", element) or "").strip().upper()
                except Exception:
                    phase = ""
            orientation = getattr(ds, "ImageOrientationPatient", None)
            row = col = None
            if orientation is not None:
                try:
                    values = [float(v) for v in orientation]
                    if len(values) >= 6:
                        row, col = values[:3], values[3:6]
                except Exception:
                    row = col = None
            plane = ""
            plane_angle = None
            frequency = ""
            frequency_angle = None
            nearest_axis = ""
            if row is not None and col is not None:
                normal = [
                    row[1] * col[2] - row[2] * col[1],
                    row[2] * col[0] - row[0] * col[2],
                    row[0] * col[1] - row[1] * col[0],
                ]
                normal_axis, plane_angle = cls._axis_from_vector(normal)
                plane = {"SI": "AXIAL", "AP": "CORONAL", "RL": "SAGITTAL"}.get(normal_axis, "")
                freq_vector = col if phase == "ROW" else (row if phase == "COL" else None)
                if freq_vector is not None:
                    nearest_axis, frequency_angle = cls._axis_from_vector(freq_vector)
                    if nearest_axis:
                        frequency = nearest_axis if (frequency_angle or 0.0) <= 20.0 + 1e-9 else "Oblique >20°"
            manufacturer = str(getattr(ds, "Manufacturer", "") or "").strip()
            source_path = str(getattr(entry, "path", "") or "")
            grouped[key] = {
                "series_uid": uid,
                "series_number": series_number,
                "series_description": description,
                "protocol_name": protocol,
                "phase_direction": phase,
                "image_orientation_patient": list(row or []) + list(col or []),
                "scan_plane": plane,
                "plane_angle": plane_angle,
                "frequency_direction": frequency,
                "nearest_axis": nearest_axis or frequency,
                "frequency_angle": frequency_angle,
                "manufacturer": manufacturer,
                "source_path": source_path,
            }
        return list(grouped.values())

    @staticmethod
    def _raw_category_tokens(category: str) -> tuple[str, ...]:
        return {
            "TMAP3": ("tmap3", "tmap"),
            "MEMP": ("memp",),
            "Planning MR": ("planning", "plan"),
            "Anatomy MR": ("anatomy", "anatomical"),
        }.get(category, ())

    @classmethod
    def match_dicom_series(cls, path: Path, identity: dict, category: str, index: dict) -> tuple[dict | None, int, str]:
        series = list(index.get("dicom_series") or [])
        if not series:
            return None, 0, ""
        raw_numbers = [int(v) for v in re.findall(r"\d+", str(identity.get("series_key") or ""))]
        raw_series_number = str(raw_numbers[0]) if raw_numbers else ""
        tokens = cls._raw_category_tokens(category)
        scored: list[tuple[int, dict, list[str]]] = []
        for item in series:
            score = 0
            reasons: list[str] = []
            if raw_series_number and str(item.get("series_number") or "").lstrip("0") == raw_series_number.lstrip("0"):
                score += 120
                reasons.append("SeriesNumber")
            text = " ".join((str(item.get("series_description") or ""), str(item.get("protocol_name") or ""), str(item.get("source_path") or ""))).lower()
            if tokens and any(token in text for token in tokens):
                score += 80
                reasons.append("Protocol/category")
            son = identity.get("sonication_number")
            if son is not None and re.search(rf"(?:sonication|sonic|son)[ _-]*0*{int(son)}(?:\D|$)", text, re.I):
                score += 60
                reasons.append("Sonication")
            if item.get("phase_direction") in {"ROW", "COL"}:
                score += 15
            if item.get("frequency_direction"):
                score += 15
            scored.append((score, item, reasons))
        scored.sort(key=lambda row: row[0], reverse=True)
        best_score, best, reasons = scored[0]
        second_score = scored[1][0] if len(scored) > 1 else -1
        # Require a meaningful identity/category match and reject near-ties.
        if best_score < 95 or (second_score >= 0 and best_score - second_score < 25):
            return None, best_score, "Ambiguous DICOM series match"
        return best, best_score, "+".join(reasons)

    @staticmethod
    def rank_candidates(path: Path, identity: dict, index: dict) -> list[MetadataRecord]:
        path = Path(path)
        vendor = index.get("vendor", "Unknown")
        son = identity.get("sonication_number")
        series = str(identity.get("series_key") or "").lower()
        ranked: list[tuple[int, MetadataRecord]] = []
        for rec in index.get("records", []):
            score = 0
            try:
                if rec.path.parent == path.parent:
                    score += 140
                elif rec.path.parent in path.parents or path.parent in rec.path.parents:
                    score += 80
                else:
                    common = os.path.commonpath([str(path.parent), str(rec.path.parent)])
                    score += min(35, len(Path(common).parts) * 3)
            except Exception:
                pass
            if son is not None and (rec.sonication_number == son or f"sonication{son}" in rec.lower.replace(" ", "")):
                score += 100
            if series and (series in rec.lower or series in rec.path.stem.lower()):
                score += 65
            if rec.kind in {"protocol", "mrfiles"}:
                score += 35
            if vendor == "GE":
                if rec.kind == "ge_review": score += 55
                if rec.kind == "ge_mrserver": score += 45
            elif vendor == "Siemens":
                if rec.kind == "siemens_protocol": score += 80
                if rec.kind == "ge_review": score -= 200
            ranked.append((score, rec))
        ranked.sort(key=lambda x: (-x[0], len(str(x[1].path))))
        return [rec for score, rec in ranked[:120] if score > -100]

    @staticmethod
    def _capture(combined: str, patterns: list[str]) -> tuple[str, str]:
        for pattern in patterns:
            match = re.search(pattern, combined, re.I | re.M)
            if match:
                return match.group(1).strip(), pattern
        return "", ""

    @staticmethod
    def _normal_to_plane(combined: str) -> tuple[str, float | None, str]:
        def value(name: str):
            match = re.search(rf"{name}\s*=\s*([-+]?\d+(?:\.\d+)?)", combined, re.I)
            return float(match.group(1)) if match else None
        sag, cor, tra = value(r"sNormal\.dSag"), value(r"sNormal\.dCor"), value(r"sNormal\.dTra")
        if all(v is None for v in (sag, cor, tra)):
            return "", None, ""
        vector = [float(sag or 0), float(cor or 0), float(tra or 0)]
        norm = math.sqrt(sum(v * v for v in vector))
        if norm <= 1e-12:
            return "", None, ""
        values = {"SAGITTAL": abs(vector[0]), "CORONAL": abs(vector[1]), "AXIAL": abs(vector[2])}
        plane = max(values, key=values.get)
        angle = math.degrees(math.acos(max(0.0, min(1.0, values[plane] / norm))))
        return plane, angle, "Siemens Slice Normal"

    @classmethod
    def resolve(cls, path: Path, metadata_index: dict | None = None) -> dict:
        path = Path(path)
        identity = cls.normalize_identity(path)
        category = cls.category(path)
        index = metadata_index or cls.build_index([])
        candidates = cls.rank_candidates(path, identity, index)
        combined = "\n".join(rec.text for rec in candidates)
        path_text = " ".join(part.lower() for part in path.parts)
        evidence: list[dict] = []

        raw_match = re.match(r"^(\d+)-(\d+)-(\d+)-(\d+)\.raw$", path.name, re.I)
        raw_key = tuple(int(raw_match.group(i)) for i in range(1,5)) if raw_match else None
        exact_mri_row = (((index.get("mri_params") or {}).get("exact") or {}).get(raw_key) if raw_key else None)
        mri_row_match_method = "exact" if exact_mri_row is not None else ""
        if exact_mri_row is None and raw_key:
            # Commit0143: when there is no exact (field, sonication, zone,
            # array) row, fall back to other rows sharing the same
            # (field, sonication) instead of leaving the RAW file with no
            # MriImageParams enrichment at all. One sonication can contain
            # several rows (placeholder/setup rows plus the real treatment
            # thermometry/MEMP acquisition), so the candidate with the
            # strongest evidence is preferred rather than just the first
            # one found. Mirrors Sonication Analysis's
            # SonicationMetadataService._row_for_sonication/quality().
            candidates_by_son = (((index.get("mri_params") or {}).get("by_field_son") or {}).get((raw_key[0], raw_key[1])) or [])
            if candidates_by_son:
                exact_mri_row = max(candidates_by_son, key=cls._mri_row_quality)
                mri_row_match_method = "field_sonication_fallback"

        def add(field: str, value, source: str, method: str, priority: int):
            if value not in (None, ""):
                evidence.append({"field": field, "value": value, "source": source, "method": method, "priority": priority})

        if category == "Excluded":
            low = (combined + " " + path_text).lower()
            for token, label in (("tmap3", "TMAP3"), ("memp", "MEMP"), ("planning mr", "Planning MR"), ("anatomy mr", "Anatomy MR")):
                if token in low:
                    category = label
                    break

        dicom_series, dicom_match_score, dicom_match_reason = cls.match_dicom_series(path, identity, category, index)

        protocol, _ = cls._capture(combined, [r"protocol(?:\s*name)?\s*[:=]\s*([^\r\n,;]+)", r"scan\s*protocol\s*[:=]\s*([^\r\n,;]+)", r"tProtocolName\s*=\s*\"?([^\"\r\n]+)"])
        sequence, _ = cls._capture(combined, [r"sequence(?:\s*name)?\s*[:=]\s*([^\r\n,;]+)", r"pulse\s*sequence\s*[:=]\s*([^\r\n,;]+)", r"tSequenceFileName\s*=\s*\"?([^\"\r\n]+)"])
        direct, _ = cls._capture(combined, [r"frequency(?:\s+encoding)?(?:\s+direction)?\s*[:=]\s*(SI|IS|AP|PA|RL|LR)", r"readout(?:\s+direction)?\s*[:=]\s*(SI|IS|AP|PA|RL|LR)", r"freq(?:uency)?\s*dir(?:ection)?\s*[:=]\s*(SI|IS|AP|PA|RL|LR)"])
        phase, _ = cls._capture(combined, [r"phase(?:\s+encoding)?(?:\s+direction)?\s*[:=]\s*(SI|IS|AP|PA|RL|LR|ROW|COL)", r"phase\s*dir(?:ection)?\s*[:=]\s*(SI|IS|AP|PA|RL|LR|ROW|COL)", r"(?:inplane)?phaseencodingdirection\s*[:=]\s*(ROW|COL)", r"ucPhaseEncDir\s*[:=]\s*(ROW|COL|SI|IS|AP|PA|RL|LR)", r"iPhaseEncodingDirection\s*=\s*(ROW|COL|\d+)"])
        plane, _ = cls._capture(combined, [r"(?:scan\s*)?plane\s*[:=]\s*(AXIAL|TRANSVERSE|CORONAL|SAGITTAL|SAGITAL)", r"orientation\s*[:=]\s*(AXIAL|TRANSVERSE|CORONAL|SAGITTAL|SAGITAL)", r"sliceorientation\s*[:=]\s*(AXIAL|TRANSVERSE|CORONAL|SAGITTAL|SAGITAL)"])
        normal_plane, normal_angle, normal_source = cls._normal_to_plane(combined)
        plane = plane.upper() if plane else normal_plane
        if plane == "TRANSVERSE": plane = "AXIAL"
        if plane == "SAGITAL": plane = "SAGITTAL"
        phase = phase.upper()
        # Siemens numeric enum is not trusted unless mapped explicitly.
        if phase.isdigit():
            phase = ""
        direct = AXIS_NORMALIZE.get(direct.upper(), "")
        phase_axis = AXIS_NORMALIZE.get(phase, phase)

        # Authoritative DICOM-series evidence has priority over text inference.
        if dicom_series is not None:
            d_phase = str(dicom_series.get("phase_direction") or "").upper()
            d_plane = str(dicom_series.get("scan_plane") or "").upper()
            d_frequency = str(dicom_series.get("frequency_direction") or "")
            if d_phase in {"ROW", "COL"}:
                phase = d_phase
                phase_axis = d_phase
            if d_plane:
                plane = d_plane
            if d_frequency:
                direct = d_frequency if d_frequency != "Oblique >20°" else str(dicom_series.get("nearest_axis") or "")
            add("phase_direction", d_phase, str(dicom_series.get("source_path") or "DICOM series"), "DICOM (0018,1312) InPlanePhaseEncodingDirection", 150)
            add("scan_plane", d_plane, str(dicom_series.get("source_path") or "DICOM series"), "DICOM (0020,0037) ImageOrientationPatient", 150)
            add("frequency_direction", d_frequency, str(dicom_series.get("source_path") or "DICOM series"), "DICOM IOP vector perpendicular to phase axis", 160)

        if protocol: add("protocol_name", protocol, str(candidates[0].path) if candidates else "dataset", "Direct protocol metadata", 90)
        if sequence: add("sequence_name", sequence, str(candidates[0].path) if candidates else "dataset", "Direct sequence metadata", 90)
        if plane: add("scan_plane", plane, normal_source or (str(candidates[0].path) if candidates else "dataset"), "Slice normal" if normal_source else "Direct plane metadata", 95)
        if phase: add("phase_direction", phase, str(candidates[0].path) if candidates else "dataset", "Direct phase metadata", 95)
        if direct: add("frequency_direction", direct, str(candidates[0].path) if candidates else "dataset", "Direct frequency/readout metadata", 110)

        derived = ""
        if plane in PLANE_AXES and phase:
            axes = PLANE_AXES[plane]
            if phase in ("ROW", "COL"):
                derived = axes["COL" if phase == "ROW" else "ROW"]
            elif phase_axis in axes.values():
                derived = next((v for v in axes.values() if v != phase_axis), "")
            if derived:
                add("frequency_direction", derived, f"{plane}+{phase}", "Orthogonal plane/phase mapping", 100)

        # Direct metadata wins, but record inconsistency rather than silently hiding it.
        conflict = bool(direct and derived and direct != derived)
        frequency = direct or derived or "Unknown"
        angle = (dicom_series.get("frequency_angle") if dicom_series is not None else normal_angle)
        assignment = "Unknown"
        if frequency != "Unknown":
            if angle is not None and angle > 20.0 + 1e-9:
                frequency_out = "Oblique >20°"
                assignment = "Oblique plane >20°"
            else:
                frequency_out = frequency
                assignment = "Direct axis" if direct else "Derived from plane and phase direction"
        else:
            frequency_out = "Unknown"

        mri_exact_header = {}
        if exact_mri_row is not None:
            mri_exact_header = cls._mri_row_header(exact_mri_row)
            # Commit0144: "Unknown" is itself a truthy non-empty string, so
            # `mri_exact_header.get(...) or plane` previously let a row with
            # no valid direction cosines silently overwrite a perfectly good
            # DICOM- or text-derived value with the literal word "Unknown".
            # Mirrors Sonication Analysis's cascade, which only lets a
            # stronger source override a weaker one when the stronger
            # source actually has a value -- not when it merely exists but
            # could not resolve one.
            def _meaningful(value):
                text = str(value or "").strip()
                return text if text and text != "Unknown" else None
            plane = _meaningful(mri_exact_header.get("scan_plane")) or plane or "Unknown"
            frequency_out = _meaningful(mri_exact_header.get("frequency_direction")) or frequency_out or "Unknown"
            phase_axis = _meaningful(mri_exact_header.get("phase_encoding_axis")) or phase_axis or "Unknown"
            protocol = _meaningful(mri_exact_header.get("protocol_name")) or protocol or "Unknown"
            sequence = _meaningful(mri_exact_header.get("series_description")) or sequence or "Unknown"
            angle = mri_exact_header.get("frequency_angle_deg")
            assignment = "Exact MriImageParams row + direction cosines"
            add("scan_plane", plane, exact_mri_row.get("_source_path", "MriImageParams.xml"), "Exact RAW key + direction cosines", 250)
            add("frequency_direction", frequency_out, exact_mri_row.get("_source_path", "MriImageParams.xml"), "freqdirection ROW/COL projected through direction cosines", 260)
            add("phase_encoding_axis", phase_axis, exact_mri_row.get("_source_path", "MriImageParams.xml"), "Orthogonal in-plane encoding axis", 250)
            add("protocol_name", protocol, exact_mri_row.get("_source_path", "MriImageParams.xml"), "seriesdiscription exact RAW row", 250)

        sources = []
        for rec in candidates[:12]:
            value = str(rec.path)
            if value not in sources:
                sources.append(value)

        if exact_mri_row is not None:
            exact_source = str(exact_mri_row.get("_source_path") or "MriImageParams.xml")
            if exact_source not in sources:
                sources.insert(0, exact_source)

        son_state = "During" if category in {"TMAP3", "MEMP"} else ("Outside" if category in {"Planning MR", "Anatomy MR"} else "Unknown")
        export_header = virtual_raw_header(path)
        # Commit0144: mri_exact_header's own raw fields (scan_plane,
        # frequency_direction, protocol_name, ...) are spread into the
        # header dict below. Since some of its keys overlap with the ones
        # already carefully resolved above (with the "Unknown" sentinel
        # properly excluded from overriding a better value), spreading the
        # *unfiltered* dict would silently undo that fix by overwriting
        # them right back with a literal "Unknown" whenever the row itself
        # lacks valid direction cosines. Only keys the row actually
        # resolved are allowed through.
        mri_exact_header_safe = {
            k: v for k, v in mri_exact_header.items()
            if not (isinstance(v, str) and v.strip() == "Unknown")
        }
        # MriImageParams/sidecar evidence still has precedence for orientation
        # and protocol; the Export Core contributes Exablate field semantics,
        # payload/header facts and safe storage hints.
        header = {
            "metadata_type": "virtual_raw_header",
            "image_category": category,
            "protocol_name": protocol or "Unknown",
            "sequence_name": sequence or "Unknown",
            "frequency_direction": frequency_out,
            "nearest_axis": frequency if frequency != "Unknown" else "Unknown",
            "angle": angle,
            "assignment": assignment,
            "phase_direction": phase,
            "scan_plane": plane or "Unknown",
            "sonication_state": son_state,
            "sonication_number": identity.get("sonication_number"),
            "mr_vendor": (str(dicom_series.get("manufacturer") or "") if dicom_series is not None else "") or index.get("vendor", "Unknown"),
            "dicom_series_match": bool(dicom_series),
            "dicom_series_match_score": dicom_match_score,
            "dicom_series_match_reason": dicom_match_reason,
            "dicom_series_uid": str(dicom_series.get("series_uid") or "") if dicom_series is not None else "",
            "dicom_series_number": str(dicom_series.get("series_number") or "") if dicom_series is not None else "",
            "image_orientation_patient": dicom_series.get("image_orientation_patient", []) if dicom_series is not None else [],
            "sources": sources,
            "evidence": evidence,
            "metadata_conflict": conflict,
            "metadata_conflict_detail": f"Direct={direct}, Derived={derived}" if conflict else "",
            "mri_params_exact_match": mri_row_match_method == "exact",
            "mri_params_exact_key": list(raw_key) if raw_key is not None else [],
            "mri_params_match_method": mri_row_match_method,
            "mri_params_source": str(exact_mri_row.get("_source_path") or "") if exact_mri_row is not None else "",
            **identity,
            **export_header,
            **mri_exact_header_safe,
        }
        # Preserve the richer resolver identity when the generic export header
        # cannot infer it.
        header["metadata_type"] = "exablate_virtual_raw_header_v2"
        # Commit0144: combined "anatomical axis (ROW/COL)" display string,
        # e.g. "RL (ROW)", ported from Sonication Analysis's
        # SonicationMetadataService._frequency_direction_display. FUS
        # already tracked the anatomical axis (frequency_direction) and the
        # raw acquisition token (frequency_matrix_axis / phase_direction)
        # as separate fields; this combines them for display without
        # losing either piece, matching Sonication Analysis's traceability
        # convention for the same data.
        axis_value = str(header.get("frequency_direction") or "").strip()
        token = str(header.get("frequency_matrix_axis") or header.get("phase_direction") or "").strip().upper()
        if token in {"COLUMN"}:
            token = "COL"
        if axis_value and axis_value != "Unknown":
            header["frequency_direction_display"] = f"{axis_value} ({token})" if token in {"ROW", "COL"} else axis_value
        elif token in {"ROW", "COL"}:
            header["frequency_direction_display"] = token
        else:
            header["frequency_direction_display"] = "Unavailable"
        if "TMAP-ME" in combined.upper():
            header["thermometry_mode"] = "TMAP-ME (Multi Echo)"
        elif re.search(r"\\bTMAP\\b", combined.upper()):
            header["thermometry_mode"] = "TMAP (Single Echo)"
        field_id = raw_key[0] if raw_key is not None else header.get("field_id")
        relation_map={5:[6,28,33,23,2,34],6:[5,28,33,23],28:[5,6,33,23],33:[5,6,23,2,34],23:[5,6,33,2,34],2:[5,33,23,34],34:[5,33,23,2],16:[19,20,21,7,8,12,43,44],19:[20,21,16,44,7,8,12,43],20:[19,21,16,44,7,8,12,43],21:[19,20,16,44,7,8,12,43],7:[8,12,19,20,21,43],8:[7,12,19,20,21,43],12:[7,8,19,20,21,43],43:[7,8,12,44,19,20,21],44:[19,20,21,43,7,8,12],37:[38,39,40,41,42],38:[37,39,40,41,42],39:[37,38,40,41,42],40:[37,38,39,41,42],41:[37,38,39,40,42],42:[37,38,39,40,41]}
        if field_id in {16,19,20,21,44}: stage="Pre-Plan / Planning"
        elif field_id in {7,8,12,43}: stage="Treatment-day MR"
        elif field_id in {37,38,39,40,41,42}: stage="Motion / 3Plane"
        elif field_id in {5,6,23,28,33,2,34}: stage="MR Thermometry"
        else: stage="Other"
        header["workflow_stage"]=stage
        # Prefer semantic Export categories over path-only guesses when an exact RAW field is known.
        if exact_mri_row is not None:
            series_up=str(header.get("series_description") or "").upper()
            if "TMAP-ME" in series_up: header["image_category"]="TMAP-ME"
            elif re.search(r"\bTMAP\b", series_up): header["image_category"]="TMAP"
            elif "MEMP" in series_up: header["image_category"]="MEMP"
            elif "TMAP3" in series_up: header["image_category"]="TMAP3"
            elif field_id == 16: header["image_category"]="Planning CT"
            elif field_id in {19,20,21,44}: header["image_category"]="Planning MR"
            elif field_id in {7,8,12,43}: header["image_category"]="Treatment-day MR"
            elif field_id in {37,38,39,40,41,42}: header["image_category"]="3Plane Motion"
        header["related_field_ids"]=relation_map.get(field_id,[])
        if stage in {"MR Thermometry", "Motion / 3Plane"}: header["sonication_state"]="During"
        elif stage in {"Pre-Plan / Planning", "Treatment-day MR"}: header["sonication_state"]="Outside"
        header["dependency_chain"]=("Magnitude(6) -> masks/reference(23/28/33) -> Temperature(5) -> local derived maps(2/34)" if field_id in {2,5,6,23,28,33,34} else "Pre-Plan CT/MR -> Registration/Fusion -> Treatment-day MR -> Sonication" if field_id in {7,8,12,16,19,20,21,43,44} else "Reference 3Plane(37-39) -> Current 3Plane(40-42)" if field_id in {37,38,39,40,41,42} else "Unknown")
        peers=[]
        if exact_mri_row is not None:
            son=raw_key[1]; zone=raw_key[2]; uid=str(exact_mri_row.get("seriesuid") or "").strip()
            exact_rows=((index.get("mri_params") or {}).get("exact") or {}).values()
            peers=sorted({int(r["_key"][0]) for r in exact_rows if int(r["_key"][1])==son and (not uid or str(r.get("seriesuid") or "").strip()==uid)})
        header["correlated_field_ids_same_acquisition"]=peers
        header["correlation_basis"] = {
            "exact": "Exact MriImageParams key/SeriesUID/geometry",
            "field_sonication_fallback": "Same field/sonication MriImageParams row (best-quality match)",
        }.get(mri_row_match_method, "Field semantic and sidecar/DICOM evidence")
        header["header_confidence"] = {
            "exact": "High (exact MriImageParams row)",
            "field_sonication_fallback": "Medium (same-sonication MriImageParams row, not an exact key match)",
        }.get(mri_row_match_method, header.get("confidence", "Evidence-based"))
        return header
