"""Commit0138 import/drop reliability regression test.

Runs entirely without PySide6/pydicom (consistent with the Linux validation
environment used for 00_VALIDATE_SOURCE.bat). Static markers confirm the fix
is present in app.py; functional checks execute the *actual*
MainWindow._extract_zip_recursive / MainWindow._import_thread_main source
(extracted via AST, bound onto a minimal fake window) against real ZIP/folder
fixtures, so the test exercises the real algorithm rather than a re-typed copy.
"""
import ast
import shutil
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from raw_metadata_resolver import TEXT_EXTENSIONS as METADATA_SIDECAR_EXTENSIONS

# --- static markers -------------------------------------------------------
text = Path("app.py").read_text(encoding="utf-8")
for marker in (
    "def _extract_zip_recursive",
    "IMPORT_COLLECT_EXTENSIONS",
    "NON_IMAGE_SIDECAR_EXTENSIONS",
    "import_errors",
    "Extracting {zip_path.name}",
    "Unsafe ZIP member path in {zip_path.name}",
):
    assert marker in text, marker
print("Commit0138 static markers: PASS")

# --- module-level constants match the live app.py definitions ------------
BITMAP_EXTENSIONS = frozenset({".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"})
SIGNAL_EXTENSIONS = frozenset({".csv", ".npy", ".npz"})
RAW_EXTENSIONS = frozenset({".raw", ".bin", ".dat", ".7", ".pfile", ".img", ".kspace", ".cfl", ".rawdata", ".complex"})
NON_IMAGE_SIDECAR_EXTENSIONS = frozenset((set(METADATA_SIDECAR_EXTENSIONS) | {".txt"}) - {".dat"})
IMPORT_COLLECT_EXTENSIONS = frozenset(
    {".dcm", ".ima", ".dicom", "", ".7", ".pfile"}
    | RAW_EXTENSIONS | SIGNAL_EXTENSIONS | BITMAP_EXTENSIONS | NON_IMAGE_SIDECAR_EXTENSIONS
)
assert ".xml" in IMPORT_COLLECT_EXTENSIONS and ".tif" in IMPORT_COLLECT_EXTENSIONS
assert ".dat" not in NON_IMAGE_SIDECAR_EXTENSIONS  # .dat must still reach the RAW path

# --- extract the real methods from app.py via AST -------------------------
tree = ast.parse(text)
wanted = {"_extract_zip_recursive", "_import_thread_main"}
found = {}
for node in ast.walk(tree):
    if isinstance(node, ast.ClassDef) and node.name == "MainWindow":
        for item in node.body:
            if isinstance(item, ast.FunctionDef) and item.name in wanted:
                found[item.name] = ast.get_source_segment(text, item)
assert wanted <= found.keys(), wanted - found.keys()

@dataclass
class DicomEntry:
    path: Path
    ds: object
    image: object
    sort_key: tuple

class _FakePydicom:
    @staticmethod
    def dcmread(*_a, **_k):
        raise ValueError("not a real DICOM in this harness")

namespace = {
    "zipfile": zipfile, "tempfile": tempfile, "Path": Path, "np": np,
    "pydicom": _FakePydicom(), "DicomEntry": DicomEntry,
    "BITMAP_EXTENSIONS": BITMAP_EXTENSIONS, "SIGNAL_EXTENSIONS": SIGNAL_EXTENSIONS,
    "RAW_EXTENSIONS": RAW_EXTENSIONS, "NON_IMAGE_SIDECAR_EXTENSIONS": NON_IMAGE_SIDECAR_EXTENSIONS,
    "IMPORT_COLLECT_EXTENSIONS": IMPORT_COLLECT_EXTENSIONS,
}
exec(compile("\n\n".join(found.values()), "<app.py extract>", "exec"), namespace)

class _NoCancel:
    def is_set(self): return False

class _FakeMainWindow:
    _extract_zip_recursive = namespace["_extract_zip_recursive"]
    _import_thread_main = namespace["_import_thread_main"]
    def __init__(self):
        self.import_cancel_event = _NoCancel()
        self.events = []
    def _queue_import_event(self, kind, payload=None):
        self.events.append((kind, payload))

def _run(paths):
    win = _FakeMainWindow()
    win._import_thread_main(list(paths))
    completed = [p for k, p in win.events if k == "completed"]
    failed = [p for k, p in win.events if k == "failed"]
    return (completed[0] if completed else None), (failed[0] if failed else None)

work = Path(tempfile.mkdtemp(prefix="commit0138_test_"))

# Case A: folder drop containing MriImageParams.xml + a nested RAW file.
case_a = work / "caseA"
(case_a / "Sonication1").mkdir(parents=True)
(case_a / "MriImageParams.xml").write_text("<root/>")
(case_a / "Sonication1" / "5-1-3-0.raw").write_bytes(b"\x00" * 1000)
result, failure = _run([case_a])
assert failure is None, failure
names = {Path(p).name for p in result["all_files"]}
assert "MriImageParams.xml" in names, "MriImageParams.xml missing from all_files"
assert any(Path(p).name == "5-1-3-0.raw" for p in result["raw_files"])

# Case B: folder drop containing a TIFF image.
case_b = work / "caseB"
case_b.mkdir()
(case_b / "scan.tif").write_bytes(b"II*\x00" + b"0" * 50)
result, failure = _run([case_b])
assert failure is None, failure
assert any(Path(p).name == "scan.tif" for p in result["bitmaps"])

# Case C: ZIP containing a nested ZIP (zip-in-zip).
inner_zip = work / "inner.zip"
with zipfile.ZipFile(inner_zip, "w") as iz:
    iz.writestr("hidden/deep.raw", b"\x00" * 500)
outer_zip = work / "outer.zip"
with zipfile.ZipFile(outer_zip, "w") as z:
    z.write(inner_zip, "inner_archive.zip")
    z.writestr("top.raw", b"\x00" * 200)
result, failure = _run([outer_zip])
assert failure is None, failure
raw_names = {Path(p).name for p in result["raw_files"]}
assert {"deep.raw", "top.raw"} <= raw_names, raw_names

# Case D: a ZIP file sitting inside a dropped folder (not a top-level ZIP).
case_d = work / "caseD"
case_d.mkdir()
with zipfile.ZipFile(case_d / "bundle.zip", "w") as z:
    z.writestr("folder_nested.raw", b"\x00" * 300)
result, failure = _run([case_d])
assert failure is None, failure
assert any(Path(p).name == "folder_nested.raw" for p in result["raw_files"])

# Case E: one corrupt ZIP dropped together with one valid file -- the good
# file must still import, and the failure must be reported, not fatal.
bad_zip = work / "bad.zip"
bad_zip.write_bytes(b"not actually a zip file")
good_file = work / "good.raw"
good_file.write_bytes(b"\x00" * 100)
result, failure = _run([bad_zip, good_file])
assert failure is None, "a single bad ZIP must not abort the whole batch"
assert any(Path(p).name == "good.raw" for p in result["raw_files"])
assert result["import_errors"], "bad.zip failure should be reported"

# Case F: Zip Slip protection is still active for a standalone malicious ZIP.
mal_zip = work / "malicious.zip"
with zipfile.ZipFile(mal_zip, "w") as z:
    z.writestr("../../evil_escape.txt", "pwned")
result, failure = _run([mal_zip])
assert result is None and failure is not None and "Unsafe ZIP member path" in failure

shutil.rmtree(work, ignore_errors=True)
print("Commit0138 import/drop reliability functional checks: PASS")
