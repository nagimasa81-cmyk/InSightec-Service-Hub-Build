"""Commit0140 patch/region noise detection regression test.

Runs entirely without PySide6/pydicom. Static markers confirm the fix is
present in app.py; functional checks extract the *actual* MainWindow methods
via AST and run the full _suppress_image_spikes pipeline end to end against
synthetic data shaped like a real case a user reported, so the test
exercises the real algorithm rather than a re-typed copy.

Background: a real clinical image showed four broad, roughly rectangular
regions of elevated k-space energy near the left/right edges (RF/coil
interference confined to a block of many rows and columns at once, visible
in the FFT display and highlighted by the user). Point detection
(_raw_spike_features' local_z/global_z), row/column line detection, and the
existing compact-blob detector (_derived_kspace_cluster_candidates, which
explicitly rejects anything wider/taller than 35% of the matrix) all missed
every one of the four regions on the real data -- confirmed interactively
before this fix. Two more pre-existing, unrelated bugs were found and fixed
along the way:

- `ygrid`/`xgrid` were referenced inside _suppress_image_spikes but never
  defined anywhere in the file, so evaluating any real candidate raised
  NameError. Fixed by using the actual grids already established earlier
  in the function (`yy`, `xx`).
- The accept/reject gate only had `cluster_pass`/`point_pass` branches, so
  the new "patch" proposal type could never be accepted; a `patch_pass`
  branch was added, gated on the patch's own tile-level z-score rather than
  point-wise local_z (which is near zero inside a patch by construction).
"""
import ast
import warnings
from pathlib import Path

import numpy as np

text = Path("app.py").read_text(encoding="utf-8")

# --- static markers -------------------------------------------------------
for marker in (
    "def _patch_spike_features",
    "patch_mask, patch_tile_z = cls._patch_spike_features(safe, valid_mask, cy, cx)",
    'patch_pass = (proposal["type"] == "patch"',
    "ky = float(((yy-cy)*weights).sum()/total)",
    "kx = float(((xx-cx)*weights).sum()/total)",
):
    assert marker in text, marker
assert "ky = float(((ygrid" not in text and "kx = float(((xgrid" not in text, "stale ygrid/xgrid reference left behind"
print("Commit0140 static markers: PASS")

# --- extract the real methods from app.py via AST -------------------------
tree = ast.parse(text)
main_window = next(
    node for node in ast.walk(tree)
    if isinstance(node, ast.ClassDef) and node.name == "MainWindow"
)
wanted = {
    "_suppress_image_spikes", "_raw_spike_features", "_radial_robust_zscore",
    "_robust_zscore", "_group_spike_indices", "_patch_spike_features",
    "_derived_kspace_cluster_candidates", "_box_blur_2d",
}
found = {}
for item in main_window.body:
    if isinstance(item, ast.FunctionDef) and item.name in wanted:
        found[item.name] = ast.get_source_segment(text, item)
assert wanted <= found.keys(), wanted - found.keys()

module_level = {}
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name in {"fft2c", "ifft2c", "median_filter_3x3_numpy"}:
        module_level[node.name] = ast.get_source_segment(text, node)
assert len(module_level) == 3, module_level.keys()

namespace = {"np": np}
exec(compile("\n\n".join(module_level.values()), "<module_level>", "exec"), namespace)
exec(compile("\n\n".join(found.values()), "<app.py extract>", "exec"), namespace)


class _FakeCombo:
    def currentText(self):
        return "Wide"


class _Fake:
    spike_level_combo = _FakeCombo()

    def _spike_range_percent(self):
        return 100

    _box_blur_2d = staticmethod(namespace["_box_blur_2d"])
    _derived_kspace_cluster_candidates = classmethod(namespace["_derived_kspace_cluster_candidates"])
    _robust_zscore = staticmethod(namespace["_robust_zscore"])
    _radial_robust_zscore = classmethod(namespace["_radial_robust_zscore"])
    _patch_spike_features = classmethod(namespace["_patch_spike_features"])
    _group_spike_indices = staticmethod(namespace["_group_spike_indices"])
    _raw_spike_features = classmethod(namespace["_raw_spike_features"])
    _suppress_image_spikes = namespace["_suppress_image_spikes"]


fake = _Fake()


def make_synthetic_kspace(rows=256, cols=256, seed=0):
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:rows, 0:cols]
    cy, cx = rows // 2, cols // 2
    r = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2) + 1.0
    base = 5000.0 / (1.0 + (r / 6.0) ** 1.6)
    noise = np.exp(rng.normal(0, 0.35, size=base.shape))
    return base * noise, cy, cx


def kspace_to_image(magnitude, seed=0):
    rng = np.random.default_rng(seed)
    phase = rng.uniform(0, 2 * np.pi, size=magnitude.shape)
    kspace = magnitude * np.exp(1j * phase)
    image = np.real(np.fft.ifft2(np.fft.ifftshift(kspace)))
    image = image - image.mean()
    return image / (image.std() + 1e-9) * 300.0 + 1000.0


def inject_patch(magnitude, y0, y1, x0, x1, fold):
    local = magnitude[y0:y1, x0:x1]
    magnitude[y0:y1, x0:x1] = local * fold
    return magnitude


with warnings.catch_warnings():
    warnings.simplefilter("ignore")

    # --- 1) a real-shaped case: four broad patches near the k-space edges,
    # mirroring the reported clinical image (upper/lower bands on both the
    # left and right edges). ------------------------------------------------
    magnitude, cy, cx = make_synthetic_kspace(seed=7)
    boxes = [(56, 111, 240, 254), (64, 111, 1, 15), (144, 199, 1, 15), (144, 199, 240, 254)]
    for (y0, y1, x0, x1) in boxes:
        inject_patch(magnitude, y0, y1, x0, x1, fold=6.0)
    image = kspace_to_image(magnitude, seed=7)

    _, _, _, candidate_points, analysis = fake._suppress_image_spikes(image)
    assert analysis["proposal_count"] >= 4, analysis["proposal_count"]
    assert analysis["accepted_count"] >= 4, analysis["accepted_count"]
    accepted_types = {r["type"] for r in analysis["regions"]}
    assert "patch" in accepted_types, accepted_types
    print(f"Commit0140 four-patch case: {analysis['accepted_count']} accepted "
          f"(types: {sorted(accepted_types)}): PASS")

    # Each injected box must overlap at least one accepted patch region.
    def boxes_overlap(a, b):
        ay0, ay1, ax0, ax1 = a
        by0, by1, bx0, bx1 = b
        return ay0 <= by1 and ay1 >= by0 and ax0 <= bx1 and ax1 >= bx0

    accepted_boxes = [r["bbox"] for r in analysis["regions"] if r["type"] == "patch"]
    for box in boxes:
        assert any(boxes_overlap(box, ab) for ab in accepted_boxes), (box, accepted_boxes)
    print("Commit0140 all four injected patches recovered by bbox overlap: PASS")

    # --- 2) false positives on realistic clean (no injected patch) images ---
    false_accepts = 0
    n_trials = 20
    for seed in range(n_trials):
        clean_mag, cy2, cx2 = make_synthetic_kspace(seed=3000 + seed)
        clean_image = kspace_to_image(clean_mag, seed=3000 + seed)
        _, _, _, _, clean_analysis = fake._suppress_image_spikes(clean_image)
        false_accepts += clean_analysis["accepted_count"]
    assert false_accepts == 0, false_accepts
    print(f"Commit0140 false positives on {n_trials} clean realistic images: {false_accepts}: PASS")

print("Commit0140 patch/region noise detection functional checks: PASS")
