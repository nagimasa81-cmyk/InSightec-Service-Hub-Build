"""Commit0145 regression test: progressive virtual header availability.

User-reported (with screenshots of the running app): while a large import
(385 RAW files in the screenshots) is generating virtual headers, the
"Image / RAW Header", "Quick Spike Detect", and "Correlation" buttons
stayed disabled ("Preparing...") until the *entire* batch finished, and
the window title bar showed "(Not Responding)" during this time.

Two real causes were found and fixed:

1. `_start_virtual_header_background` built the metadata index
   (`RawMetadataResolver.build_index`) and the DICOM-series evidence index
   (`RawMetadataResolver.build_dicom_series_index`) *synchronously on the
   UI thread*, before the background `threading.Thread` even started. For
   a large import this is exactly the kind of unbounded-by-input-size work
   that can make a Qt window report "Not Responding" (Windows marks a
   window as such when its message loop hasn't processed a message in
   several seconds). Both now run inside the background thread instead.

2. Buttons were disabled for the whole batch and only re-enabled once via
   the "completed" signal, which only fired after every single file was
   processed. They are now enabled immediately (with a live
   "N/total indexed" progress label instead of a static "Preparing..."),
   and the background thread flushes each small batch of finished headers
   into the shared cache as it goes (via a new `partial` signal / handler)
   instead of holding everything until the very end.

This test runs the real `_start_virtual_header_background` background
thread (plain Python `threading`, no Qt event loop needed) with a fake
`virtual_header_signals` object whose `emit()` calls invoke the
corresponding handler directly, so the actual production logic --
including the real `_apply_virtual_header_partial` and
`_finish_virtual_header_background` methods -- is exercised, not a
re-typed copy.
"""
import ast
import os
import threading
import time
from pathlib import Path

import numpy as np

text = Path("app.py").read_text(encoding="utf-8")
for marker in (
    "partial = Signal(object, int, int)",
    "def _apply_virtual_header_partial",
    "metadata_index = self._build_raw_metadata_index(all_files_snapshot)",
    'self._set_virtual_header_actions_enabled(True, f"0/{len(raw_files)} indexed")',
):
    assert marker in text, marker
print("Commit0145 static markers: PASS")

tree = ast.parse(text)
main_window = next(
    n for n in ast.walk(tree) if isinstance(n, ast.ClassDef) and n.name == "MainWindow"
)
wanted = {
    "_set_virtual_header_actions_enabled", "_apply_virtual_header_partial",
    "_start_virtual_header_background", "_finish_virtual_header_background",
    "_quick_spike_raw_virtual_header", "_build_raw_metadata_index",
}
found = {}
for item in main_window.body:
    if isinstance(item, (ast.FunctionDef,)) and item.name in wanted:
        found[item.name] = ast.get_source_segment(text, item)
assert wanted <= found.keys(), wanted - found.keys()

namespace = {
    "np": np, "os": os, "Path": Path, "time": time, "threading": threading,
    "Slot": (lambda *a, **k: (lambda f: f)),  # no-op decorator stand-in
}
exec(compile("\n\n".join(found.values()), "<app.py extract>", "exec"), namespace)


class _FakeSignal:
    """Directly calls the bound handler instead of going through Qt, so
    this test can run without PySide6 while still exercising the real
    handler methods."""
    def __init__(self, handler_name, owner_getter):
        self._handler_name = handler_name
        self._owner_getter = owner_getter

    def emit(self, *args):
        getattr(self._owner_getter(), self._handler_name)(*args)


class _FakeSignals:
    def __init__(self, owner_getter):
        self.progress = _FakeSignal("_on_progress", owner_getter)
        self.partial = _FakeSignal("_apply_virtual_header_partial", owner_getter)
        self.completed = _FakeSignal("_finish_virtual_header_background", owner_getter)


class _FakeButton:
    def __init__(self):
        self.enabled = None
        self.text_value = ""

    def setEnabled(self, value):
        self.enabled = bool(value)

    def setText(self, value):
        self.text_value = value


class _FakeStatusBar:
    def __init__(self):
        self.last_message = ""

    def showMessage(self, message):
        self.last_message = message


class _FakeResolver:
    """Stands in for RawMetadataResolver: cheap, deterministic, and lets
    the test control how long "indexing" takes without real file I/O."""
    @staticmethod
    def build_index(all_files):
        return {"vendor": "GE", "records": []}

    @staticmethod
    def build_dicom_series_index(entries):
        return []

    @staticmethod
    def resolve(path, metadata_index):
        return {"source_path": str(path)}


class _Fake:
    header_popup_button = _FakeButton()
    quick_spike_button = _FakeButton()
    relation_button = _FakeButton()
    raw_virtual_header_cache = {}
    raw_preview_cache = {}
    dicom_entries = []
    imported_paths = []
    raw_metadata_index = {}
    virtual_headers_ready = True
    RawMetadataResolver = _FakeResolver

    def __init__(self):
        self._statusbar = _FakeStatusBar()
        self.virtual_header_signals = _FakeSignals(lambda: self)
        self.enabled_snapshots = []  # (button_enabled, button_text) recorded on every enable call

    def statusBar(self):
        return self._statusbar

    def _on_progress(self, current, total):
        self._statusbar.showMessage(f"Generating Virtual Headers: {current} / {total}")

    _set_virtual_header_actions_enabled = namespace["_set_virtual_header_actions_enabled"]
    _apply_virtual_header_partial = namespace["_apply_virtual_header_partial"]
    _start_virtual_header_background = namespace["_start_virtual_header_background"]
    _finish_virtual_header_background = namespace["_finish_virtual_header_background"]
    _quick_spike_raw_virtual_header = classmethod(namespace["_quick_spike_raw_virtual_header"])
    _build_raw_metadata_index = classmethod(namespace["_build_raw_metadata_index"])


# Patch the RawMetadataResolver name used inside the extracted method bodies.
namespace["RawMetadataResolver"] = _FakeResolver

fake = _Fake()

# --- buttons must be enabled immediately, never the old static
# "(Preparing...)" state, even before a single file has been processed ---
raw_files = [Path(f"{i}-1-0-0.raw") for i in range(1, 41)]  # 40 synthetic files
fake._start_virtual_header_background(raw_files, all_files=raw_files)
assert fake.header_popup_button.enabled is True, "button was disabled immediately after starting"
assert "Preparing" not in fake.header_popup_button.text_value, fake.header_popup_button.text_value
assert "0/40" in fake.header_popup_button.text_value, fake.header_popup_button.text_value
print("Commit0145 buttons enabled immediately with live progress label: PASS")

# Give the background thread time to finish (it's all synthetic/fast).
deadline = time.time() + 10
while time.time() < deadline:
    if len(fake.raw_virtual_header_cache) >= len(raw_files):
        break
    time.sleep(0.05)

assert len(fake.raw_virtual_header_cache) == len(raw_files), len(fake.raw_virtual_header_cache)
assert fake.header_popup_button.enabled is True
assert "Preparing" not in fake.header_popup_button.text_value
print("Commit0145 cache filled progressively and buttons stayed enabled throughout: PASS")

# --- the metadata index must not have been built synchronously on the
# calling thread before the background thread starts (Commit0145's fix
# for the "Not Responding" freeze) ------------------------------------------
slow_calls = {"count": 0}


class _SlowResolver(_FakeResolver):
    @staticmethod
    def build_index(all_files):
        slow_calls["count"] += 1
        time.sleep(0.2)
        return {"vendor": "GE", "records": []}


namespace["RawMetadataResolver"] = _SlowResolver
fake2 = _Fake()
fake2.RawMetadataResolver = _SlowResolver
start = time.time()
fake2._start_virtual_header_background(raw_files[:5], all_files=raw_files[:5])
elapsed_on_calling_thread = time.time() - start
assert elapsed_on_calling_thread < 0.15, (
    f"_start_virtual_header_background blocked the calling thread for "
    f"{elapsed_on_calling_thread:.2f}s -- metadata index build is not "
    f"backgrounded"
)
print(f"Commit0145 metadata index build does not block the calling thread "
      f"({elapsed_on_calling_thread*1000:.0f}ms): PASS")

print("Commit0145 progressive virtual header availability functional checks: PASS")
