from pathlib import Path
import tempfile
from raw_metadata_resolver import RawMetadataResolver

XML = """<?xml version=\"1.0\"?><root><row fieldindex=\"5\" sonicationindex=\"1\" zoneindex=\"3\" arrayindex=\"0\" magstrength=\"15000\" imgmatrixx=\"256\" imgmatrixy=\"256\" pixsizex=\"1.0938\" pixsizey=\"1.0938\" slicethick=\"3\" repetitiontimetr=\"28000\" echotimete=\"3128\" mrflipangle=\"30\" centerfreq=\"639080600\" autocenterfreq=\"639080600\" rowdirectcosrasx=\"0\" rowdirectcosrasy=\"-1\" rowdirectcosrasz=\"0\" coldirectcosrasx=\"-1\" coldirectcosrasy=\"0\" coldirectcosrasz=\"0\" freqdirection=\"ROW\" seriesdiscription=\"TMAP-ME\" manufacturer=\"GE MEDICAL SYSTEMS\" echonum=\"1\" seriesuid=\"SERIES-A\" imgseriesnum=\"20\" imgnum=\"52\" /></root>"""
with tempfile.TemporaryDirectory() as td:
    root=Path(td); (root/'Sonication1').mkdir()
    xml=root/'MriImageParams.xml'; xml.write_text(XML,encoding='utf-8')
    raw=root/'Sonication1'/'5-1-3-0.raw'; raw.write_bytes(b'\0'*(256*256*4))
    idx=RawMetadataResolver.build_index(list(root.rglob('*')))
    h=RawMetadataResolver.resolve(raw,idx)
    assert h['mri_params_exact_match'] is True
    assert h['thermometry_mode']=='TMAP-ME (Multi Echo)'
    assert h['echo_mode']=='Multi Echo'
    assert h['scan_plane']=='AXIAL'
    assert h['frequency_matrix_axis']=='ROW'
    assert h['frequency_direction']=='AP'
    assert h['phase_encoding_axis']=='RL'
    assert abs(h['tr_ms']-28.0)<1e-9 and abs(h['te_ms']-3.128)<1e-9
    assert abs(h['field_strength_t']-1.5)<1e-9
    assert abs(h['center_frequency_mhz']-63.90806)<1e-8
    assert h['workflow_stage']=='MR Thermometry'
    assert 6 in h['related_field_ids'] and 33 in h['related_field_ids']
print('Commit0137 exact Export RAW header: PASS')
