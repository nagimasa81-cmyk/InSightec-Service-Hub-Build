"""Commit0150 regression test: unify point-spike detection and add a
learning-feedback mechanism.

Part 1 -- deep re-validation and unification
Head-to-head re-validation on the same synthetic point-spike scenarios
found app.py's `_raw_spike_features` (paths (1) Spike Diag and (2) Quick
Spike Detect) and core/hybrid_compensation.py's `detect_artifacts`
"Spike" type (paths (3) Auto Correct and (4) Manual Paint's Auto-detect,
via the same function) are NOT redundant: each independently catches real
spikes the other misses.
  (1)/(2) `_raw_spike_features` alone:      ~61% recall
  (3)/(4) `detect_artifacts` "Spike" alone:  ~77% recall
  union (OR) of both:                        ~82% recall
with false positives on clean data staying at roughly the same very low
rate (~0.002% of pixels) in all three cases. `_raw_spike_features` now
also calls `hybrid_detect_artifacts` (already imported in app.py) and
ORs its mask into `point_mask`, so paths (1)/(2) benefit from (3)/(4)'s
independently-caught spikes too, without paths (3)/(4) needing any
change (core/ modules cannot import from app.py, so the sharing is
one-directional: app.py calls into core, not the reverse).

Part 2 -- learning/feedback mechanism
Both Spike Diag (`_record_spike_feedback`) and the Quick Spike Detect
results dialog (`record_quick_spike_feedback`, defined inline in
`_show_quick_spike_correlation_dialog`) can now record a user's
correction (missed spike / false positive / confirmed correct) into the
existing Artifact Learning DB (artifact_learning_db.py), which already
had "Spike" and "Not Artifact" as built-in labels and already supports
export/import and `training_feature_vectors()` for future retraining --
this reuses that infrastructure rather than building a new one.

Runs entirely without PySide6/pydicom.
"""
import ast
import tempfile
import warnings
from pathlib import Path

import numpy as np

text = Path("app.py").read_text(encoding="utf-8")

# --- static markers -------------------------------------------------------
for marker in (
    'hybrid_result = hybrid_detect_artifacts(\n                frequency.astype(np.complex128), "Spike", 4.0, "Balanced"\n            )',
    "point_mask = point_mask | (valid_mask & np.asarray(hybrid_result.mask, dtype=bool))",
    "def _record_spike_feedback",
    "def record_quick_spike_feedback",
    "self.artifact_db.add_sample(",
):
    assert marker in text, marker[:60]
print("Commit0150 static markers: PASS")

# --- Part 1: functional re-validation of the union, using the real code ---
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    from core.hybrid_compensation import detect_artifacts as hybrid_detect_artifacts

    tree = ast.parse(text)
    main_window = next(
        n for n in ast.walk(tree) if isinstance(n, ast.ClassDef) and n.name == "MainWindow"
    )
    wanted = {"_raw_spike_features", "_radial_robust_zscore", "_robust_zscore",
              "_group_spike_indices", "_patch_spike_features"}
    found = {}
    for item in main_window.body:
        if isinstance(item, ast.FunctionDef) and item.name in wanted:
            found[item.name] = ast.get_source_segment(text, item)
    assert wanted <= found.keys(), wanted - found.keys()

    namespace = {"np": np, "hybrid_detect_artifacts": hybrid_detect_artifacts}
    exec(compile("\n\n".join(found.values()), "<app.py extract>", "exec"), namespace)

    class _Fake:
        _robust_zscore = staticmethod(namespace["_robust_zscore"])
        _radial_robust_zscore = classmethod(namespace["_radial_robust_zscore"])
        _patch_spike_features = classmethod(namespace["_patch_spike_features"])
        _group_spike_indices = staticmethod(namespace["_group_spike_indices"])
        _raw_spike_features = classmethod(namespace["_raw_spike_features"])

    fake = _Fake()

    def make_kspace(seed=0, rows=256, cols=256):
        rng = np.random.default_rng(seed)
        yy, xx = np.mgrid[0:rows, 0:cols]
        cy, cx = rows / 2, cols / 2
        r = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2) + 1.0
        base = 5000.0 / (1.0 + (r / 6.0) ** 1.6)
        noise = np.exp(rng.normal(0, 0.35, size=base.shape))
        mag = base * noise
        phase = rng.uniform(0, 2 * np.pi, size=mag.shape)
        return mag * np.exp(1j * phase)

    def inject(kspace, y, x, fold):
        mag = np.abs(kspace)
        phase = np.angle(kspace)
        local = mag[max(0, y - 3):y + 4, max(0, x - 3):x + 4]
        mag[y, x] = np.median(local) * fold
        return mag * np.exp(1j * phase)

    rng = np.random.default_rng(555)
    n_trials = 40
    trials = []
    for i in range(n_trials):
        ks = make_kspace(seed=3000 + i)
        radius = rng.uniform(10, 70)
        angle = rng.uniform(0, 2 * np.pi)
        y = int(np.clip(128 + radius * np.sin(angle), 4, 251))
        x = int(np.clip(128 + radius * np.cos(angle), 4, 251))
        fold = rng.uniform(6, 14)
        trials.append((inject(ks, y, x, fold), y, x))

    hits = 0
    for ks, y, x in trials:
        kmag = np.abs(ks)
        yy, xx = np.mgrid[0:256, 0:256]
        valid = np.sqrt((yy - 128) ** 2 + (xx - 128) ** 2) > 15
        feats = fake._raw_spike_features(kmag, valid)
        coords = set(map(tuple, feats["candidate_coords"]))
        hits += int((y, x) in coords)
    recall = hits / n_trials
    assert recall >= 0.70, recall  # unified detector must clear both individual baselines
    print(f"Commit0150 unified _raw_spike_features recall: {hits}/{n_trials} ({recall:.0%}): PASS")

    fp_total = 0
    total_px = 0
    for seed in range(8):
        ks = make_kspace(seed=8000 + seed)
        kmag = np.abs(ks)
        yy, xx = np.mgrid[0:256, 0:256]
        valid = np.sqrt((yy - 128) ** 2 + (xx - 128) ** 2) > 15
        feats = fake._raw_spike_features(kmag, valid)
        fp_total += len(feats["candidate_coords"])
        total_px += int(valid.sum())
    fp_rate = fp_total / total_px
    assert fp_rate < 0.001, (fp_total, fp_rate)
    print(f"Commit0150 unified detector false-positive rate on clean data: "
          f"{fp_total}/{total_px} ({fp_rate:.5%}): PASS")

# --- Part 2: functional test of the feedback mechanism against a real
# ArtifactDatabase (pure Python/sqlite, no Qt needed) ----------------------
from artifact_learning_db import ArtifactDatabase, image_features  # noqa: E402

tree = ast.parse(text)
node = next(
    item for item in main_window.body
    if isinstance(item, ast.FunctionDef) and item.name == "_record_spike_feedback"
)
feedback_namespace = {
    "np": np, "Path": Path, "image_features": image_features,
}


class _FakeMessageBox:
    @staticmethod
    def information(*a, **k):
        pass

    @staticmethod
    def warning(*a, **k):
        pass


feedback_namespace["QMessageBox"] = _FakeMessageBox
exec(compile(ast.Module(body=[node], type_ignores=[]), "<extract>", "exec"), feedback_namespace)

with tempfile.TemporaryDirectory() as tmp:
    db_path = Path(tmp) / "artifact_learning.sqlite3"
    db = ArtifactDatabase(db_path)

    class _FakeSelf:
        artifact_db = db
        dicom_entries = []
        normal_reference_image = None
        normal_reference_path = ""
        spike_image_results = [{
            "index": None,
            "path": Path("113-6.dcm"),
            "original": np.random.default_rng(0).normal(500, 50, size=(32, 32)),
            "detected": True,
        }]
        current_spike_result_index = 0
        _record_spike_feedback = feedback_namespace["_record_spike_feedback"]

    fake_self = _FakeSelf()
    fake_self._record_spike_feedback("missed")
    samples = db.samples()
    assert len(samples) == 1, len(samples)
    assert samples[0]["artifact_type"] == "Spike", samples[0]["artifact_type"]
    assert "MISSED" in samples[0]["notes"], samples[0]["notes"]
    db.close()

print("Commit0150 feedback mechanism writes a real sample to the Artifact "
      "Learning DB with the correct label: PASS")

print("Commit0150 unification and learning-feedback functional checks: PASS")
