"""Commit0143 regression test: richer RAW header resolution.

Ported two techniques from the Sonication Analysis tool's
SonicationMetadataService (which resolves display metadata for RAW images
loaded from a ZIP-dropped Exablate export) into FUS's own
raw_metadata_resolver.py:

1. Field/sonication fallback with quality-based row selection. FUS's
   RawMetadataResolver already built a `by_field_son` index grouping
   MriImageParams.xml rows by (fieldindex, sonicationindex), but nothing
   ever read it -- a RAW file with no exact (field, sonication, zone,
   array) match got no MriImageParams enrichment at all, even when other
   rows for the same sonication existed. Sonication Analysis's
   SonicationMetadataService._row_for_sonication/quality() picks the
   best-evidenced row among several candidates (preferring a real
   treatment thermometry/MEMP row with real direction cosines over an
   empty placeholder row); the same technique is now used for this
   fallback.
2. Magnitude-based TR/TE microsecond-vs-millisecond detection
   (SonicationMetadataService._format_mr_time_ms), replacing a fixed
   x0.001 scale that silently assumed every export stores TR/TE in
   microseconds.

Runs entirely without PySide6/pydicom.
"""
import tempfile
from pathlib import Path

from raw_metadata_resolver import RawMetadataResolver

text = Path("raw_metadata_resolver.py").read_text(encoding="utf-8")
for marker in (
    "def _mri_row_quality",
    "def _mr_time_ms",
    "mri_row_match_method = \"field_sonication_fallback\"",
    "\"mri_params_match_method\": mri_row_match_method,",
):
    assert marker in text, marker
print("Commit0143 static markers: PASS")

# --- TR/TE magnitude-based unit detection ---------------------------------
assert RawMetadataResolver._mr_time_ms(28000) == 28.0   # microseconds
assert RawMetadataResolver._mr_time_ms(28.0) == 28.0    # already ms
assert RawMetadataResolver._mr_time_ms(3128) == 3.128
assert RawMetadataResolver._mr_time_ms(3.128) == 3.128
assert RawMetadataResolver._mr_time_ms(999) == 999.0    # just under the boundary
assert RawMetadataResolver._mr_time_ms(1000) == 1.0     # at the boundary
assert RawMetadataResolver._mr_time_ms(None) is None
assert RawMetadataResolver._mr_time_ms("not a number") is None
print("Commit0143 TR/TE magnitude-based unit detection: PASS")

# --- field/sonication fallback with quality-based row selection ----------
workdir = Path(tempfile.mkdtemp(prefix="commit0143_test_"))
xml_path = workdir / "MriImageParams.xml"
xml_path.write_text(
    """<?xml version="1.0"?>
<xml xmlns:rs="urn:schemas-microsoft-com:rowset" xmlns:z="#RowsetSchema">
<rs:data>
<z:row fieldindex="5" sonicationindex="2" zoneindex="0" arrayindex="0"
       seriesdiscription="" freqdirection="" imgmatrixx="0"
       rowdirectcosrasx="0" rowdirectcosrasy="0" rowdirectcosrasz="0"
       coldirectcosrasx="0" coldirectcosrasy="0" coldirectcosrasz="0"
       repetitiontimetr="0" echotimete="0"/>
<z:row fieldindex="5" sonicationindex="2" zoneindex="1" arrayindex="0"
       seriesdiscription="TMAP-ME" freqdirection="ROW" imgmatrixx="256"
       imgmatrixy="256" pixsizex="1.5" pixsizey="1.5"
       rowdirectcosrasx="1" rowdirectcosrasy="0" rowdirectcosrasz="0"
       coldirectcosrasx="0" coldirectcosrasy="1" coldirectcosrasz="0"
       repetitiontimetr="28000" echotimete="3128"
       manufacturer="GE MEDICAL SYSTEMS"/>
</rs:data>
</xml>""",
    encoding="utf-8",
)
# 5-2-9-3.raw matches neither exact row's (zone, array) key, only the
# (field=5, sonication=2) pair both rows share.
raw_path = workdir / "5-2-9-3.raw"
raw_path.write_bytes(b"\x00" * 1000)

index = RawMetadataResolver.build_index([xml_path, raw_path])
result = RawMetadataResolver.resolve(raw_path, index)

assert result["mri_params_exact_match"] is False, result["mri_params_exact_match"]
assert result["mri_params_match_method"] == "field_sonication_fallback", result["mri_params_match_method"]
assert result.get("series_description") == "TMAP-ME", result.get("series_description")
assert result.get("scan_plane") == "AXIAL", result.get("scan_plane")
assert result.get("tr_ms") is not None and abs(result["tr_ms"] - 28.0) < 1e-6
assert result.get("te_ms") is not None and abs(result["te_ms"] - 3.128) < 1e-6
assert "same-sonication" in result.get("header_confidence", "").lower()
print("Commit0143 field/sonication fallback picks the best-quality row "
      "(not the empty placeholder): PASS")

# --- exact match path must be unaffected by this change -------------------
workdir2 = Path(tempfile.mkdtemp(prefix="commit0143_test_exact_"))
xml_path2 = workdir2 / "MriImageParams.xml"
xml_path2.write_text(
    """<?xml version="1.0"?>
<xml xmlns:rs="urn:schemas-microsoft-com:rowset" xmlns:z="#RowsetSchema">
<rs:data>
<z:row fieldindex="5" sonicationindex="1" zoneindex="0" arrayindex="0"
       seriesdiscription="TMAP-ME" freqdirection="ROW" imgmatrixx="256"
       imgmatrixy="256" rowdirectcosrasx="1" rowdirectcosrasy="0" rowdirectcosrasz="0"
       coldirectcosrasx="0" coldirectcosrasy="1" coldirectcosrasz="0"
       repetitiontimetr="28000" echotimete="3128"/>
</rs:data>
</xml>""",
    encoding="utf-8",
)
raw_path2 = workdir2 / "5-1-0-0.raw"
raw_path2.write_bytes(b"\x00" * 1000)
index2 = RawMetadataResolver.build_index([xml_path2, raw_path2])
result2 = RawMetadataResolver.resolve(raw_path2, index2)
assert result2["mri_params_exact_match"] is True
assert result2["mri_params_match_method"] == "exact"
assert result2["header_confidence"] == "High (exact MriImageParams row)"
print("Commit0143 exact-match path unaffected: PASS")

print("Commit0143 richer RAW header resolution functional checks: PASS")
