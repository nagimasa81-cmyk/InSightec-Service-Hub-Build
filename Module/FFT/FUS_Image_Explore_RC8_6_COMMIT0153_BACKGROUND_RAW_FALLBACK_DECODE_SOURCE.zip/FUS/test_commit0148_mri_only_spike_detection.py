"""Commit0148 regression test: Quick Spike Detect is MRI-only.

User-reported (with a screenshot of the running Correlation dialog): an
image labeled "Planning CT" (a CT planning scan, Exablate field_id 16)
was visible mixed in with MRI images, and Quick Spike Detect's overall
results were unusable. Investigation confirmed a real bug:
`_quick_spike_detect_raw`'s eligibility loop initialized an `excluded`
list but never appended to it -- every RAW file was pushed into
`eligible` regardless of its `image_category`, including "Planning CT".
k-space/RF-spike analysis (FFT-based) has no meaning on a CT
reconstruction, so mixing CT images into the analyzed pool produces
meaningless per-image results and degrades the reported detection rate
overall. `_quick_spike_detect_dicom` had the analogous gap: it never
checked a DICOM entry's Modality tag, so a non-MR DICOM series (e.g. CT)
imported alongside MR series would also be analyzed.

Fix: an explicit MRI-only allow-list (`MRI_SPIKE_ELIGIBLE_CATEGORIES`)
for the RAW path (deny-by-default, not just excluding the literal string
"Excluded"), and an explicit Modality check for the DICOM path (skip any
entry whose Modality is confirmed to be something other than MR; a
missing/empty Modality tag is not excluded, so a well-formed MR file
that merely lacks this optional tag is not penalized).

Runs entirely without PySide6/pydicom.
"""
import ast
from pathlib import Path

text = Path("app.py").read_text(encoding="utf-8")

# --- static markers -------------------------------------------------------
for marker in (
    "MRI_SPIKE_ELIGIBLE_CATEGORIES = frozenset({",
    "if category not in MRI_SPIKE_ELIGIBLE_CATEGORIES:",
    'modality = str(getattr(entry.ds, "Modality", "") or "").strip().upper()',
    'if modality and modality != "MR":',
    "excluded_modality",
):
    assert marker in text, marker
print("Commit0148 static markers: PASS")

# --- the allow-list itself: extract and check contents --------------------
tree = ast.parse(text)
allow_list_node = next(
    node for node in ast.walk(tree)
    if isinstance(node, ast.Assign)
    and len(node.targets) == 1
    and isinstance(node.targets[0], ast.Name)
    and node.targets[0].id == "MRI_SPIKE_ELIGIBLE_CATEGORIES"
)
namespace = {}
exec(compile(ast.Module(body=[allow_list_node], type_ignores=[]), "<extract>", "exec"), namespace)
allow_list = namespace["MRI_SPIKE_ELIGIBLE_CATEGORIES"]

assert "Planning CT" not in allow_list, "CT must never be spike-eligible"
assert "Unclassified RAW" not in allow_list, "unclassified RAW is not confirmed MRI"
assert "Excluded" not in allow_list
for confirmed_mri in ("Planning MR", "Anatomy MR", "TMAP3", "MEMP", "TMAP-ME", "TMAP",
                      "Treatment-day MR", "3Plane Motion"):
    assert confirmed_mri in allow_list, confirmed_mri
print("Commit0148 MRI-only allow-list excludes Planning CT / unclassified RAW, "
      "includes all 8 confirmed-MRI categories: PASS")

# --- functional: reproduce the exact filtering logic from
# _quick_spike_detect_raw against a mix of categories, including the
# "Planning CT" case from the reported screenshot -------------------------
categories = [
    ("Planning MR", True), ("Anatomy MR", True), ("TMAP3", True), ("MEMP", True),
    ("TMAP-ME", True), ("TMAP", True), ("Treatment-day MR", True), ("3Plane Motion", True),
    ("Planning CT", False), ("Excluded", False), ("Unclassified RAW", False),
    ("SomethingUnexpected", False),
]
eligible, excluded = [], []
for category, _expected in categories:
    raw_category = "Unclassified RAW" if category == "Excluded" else category
    if raw_category not in allow_list:
        excluded.append(raw_category)
        continue
    eligible.append(raw_category)

expected_eligible = {c for c, ok in categories if ok}
expected_excluded_count = len(categories) - len(expected_eligible)
assert set(eligible) == expected_eligible, (set(eligible), expected_eligible)
assert len(excluded) == expected_excluded_count, (len(excluded), expected_excluded_count)
assert "Planning CT" in excluded, "the exact category from the reported screenshot must be excluded"
print(f"Commit0148 filtering reproduces the reported case: 'Planning CT' excluded, "
      f"{len(eligible)}/{len(categories)} categories remain eligible: PASS")

print("Commit0148 MRI-only spike detection functional checks: PASS")
