from pathlib import Path
text=Path("app.py").read_text(encoding="utf-8")
for marker in (
    "def _normalize_raw_identity",
    "def _build_raw_metadata_index",
    "def _rank_raw_metadata_candidates",
    'vendor == "Siemens"',
    '"ascconv", "phoenix", "slicearray"',
    "Siemens slice normal",
    "Derived from plane and phase direction",
    "self.tabs.setCurrentIndex(0)",
    # Commit0145: buttons stay enabled with a live progress label instead
    # of being disabled with a static "(Preparing...)" for the whole
    # import; see test_commit0145_progressive_virtual_headers.py.
    "_apply_virtual_header_partial",
):
    assert marker in text, marker
assert 'review.out" in name: score -= 100' in text
assert '_start_virtual_header_background(raw_files, files)' in text
print("Commit0130 static checks: PASS")
