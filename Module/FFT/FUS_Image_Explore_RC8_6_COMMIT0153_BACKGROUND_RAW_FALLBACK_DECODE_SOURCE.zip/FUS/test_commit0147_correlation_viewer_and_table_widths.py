"""Commit0147 regression test.

Two user requests:
1. The Correlation Summary tab's first column was too narrow to read
   comfortably, and a manual column-width adjustment did not stick after
   some other UI interaction ("moving the slide bar"). A shared
   `_harden_table_column_widths()` helper (resize once, then lock every
   column to Interactive resize mode, with an optional minimum width for
   column 0) was applied to the Correlation dialog's three tables, to the
   analogous Quick Spike Detect results dialog, and to every other
   QTableWidget in the app found to call `resizeColumnsToContents()`
   (DicomHeaderDialog, Tracker Signal Explorer, Spike Diag candidate/
   results tables, Artifact Diag detection/training tables).
2. Correlation Analysis feature addition: an Original/FFT image viewer on
   the right, and clicking a table cell expands a list of matching images
   below the table; clicking a list item loads that image into the
   viewer, using the same ImagePanel widget/API as Image Workspace.

Runs entirely without PySide6/pydicom, except for the pure-data record
matching logic, which is extracted from the real app.py via AST and
executed directly.
"""
import ast
from pathlib import Path

text = Path("app.py").read_text(encoding="utf-8")

# --- static markers: column-width hardening applied everywhere ------------
for marker in (
    "def _harden_table_column_widths(table:",
    "header.setSectionResizeMode(col, QHeaderView.Interactive)",
):
    assert marker in text, marker
hardening_call_sites = text.count("_harden_table_column_widths(")
# 1 definition + at least: DicomHeaderDialog x2, tracker_table, spike candidate
# table, spike_table, relation summary/cross/detail, quick-spike summary/
# cross/detail, artifact_detection_table, artifact_training_table, and the
# generic candidate-preview table = at least 14 call sites total.
assert hardening_call_sites >= 14, hardening_call_sites
print(f"Commit0147 column-width hardening applied at {hardening_call_sites - 1} call sites: PASS")

# --- static markers: Correlation viewer feature ---------------------------
for marker in (
    "def _relation_records_matching_summary_row",
    "def _relation_load_record_image",
    'original_panel = ImagePanel("Original Image"); fft_panel = ImagePanel("FFT (k-space)")',
    "image_list.itemClicked.connect(on_image_item_clicked)",
    "summary_table.cellClicked.connect(on_summary_cell_clicked)",
    "cross.cellClicked.connect(on_cross_cell_clicked)",
    "detail.cellClicked.connect(on_detail_cell_clicked)",
):
    assert marker in text, marker
print("Commit0147 Correlation viewer static markers: PASS")

# --- functional: record matching for each Summary row group ---------------
tree = ast.parse(text)
main_window = next(
    n for n in ast.walk(tree) if isinstance(n, ast.ClassDef) and n.name == "MainWindow"
)
node = next(
    item for item in main_window.body
    if isinstance(item, ast.FunctionDef) and item.name == "_relation_records_matching_summary_row"
)
namespace = {}
exec(compile(ast.get_source_segment(text, node), "<extract>", "exec"), namespace)
match_fn = namespace["_relation_records_matching_summary_row"]

records = [
    {"frequency": {"category": "RL"}, "sonication_state": "During", "image_category": "TMAP3",
     "virtual_header": {"protocol_name": "TMAP-ME", "scan_plane": "AXIAL", "field_id": 5, "mri_params_exact_match": True}},
    {"frequency": {"category": "AP"}, "sonication_state": "Outside", "image_category": "MEMP",
     "virtual_header": {"protocol_name": "MEMP", "scan_plane": "SAGITTAL", "field_id": 6, "mri_params_exact_match": False}},
    {"frequency": {"category": "RL"}, "sonication_state": "Outside", "image_category": "TMAP3",
     "virtual_header": {"protocol_name": "TMAP-ME", "scan_plane": "AXIAL", "field_id": 5, "mri_params_exact_match": True}},
]

assert len(match_fn(records, "Frequency Distribution", "RL")) == 2
assert len(match_fn(records, "Frequency Distribution", "AP")) == 1
assert len(match_fn(records, "Sonication Distribution", "During")) == 1
assert len(match_fn(records, "Sonication Distribution", "Outside")) == 2
assert len(match_fn(records, "RAW Image Category", "TMAP3")) == 2
assert len(match_fn(records, "Protocol / Series", "MEMP")) == 1
assert len(match_fn(records, "Scan Plane", "AXIAL")) == 2
assert len(match_fn(records, "Exablate Field", "5")) == 2
assert len(match_fn(records, "Exact MriImageParams", "Yes")) == 2
assert len(match_fn(records, "Exact MriImageParams", "No")) == 1
assert match_fn(records, "Nonexistent Group", "x") == []
print("Commit0147 Summary-row -> matching-records filtering (all 7 groups): PASS")

print("Commit0147 functional checks: PASS")
