"""Commit0144 regression test.

Follow-up to Commit0143's two deferred items, both from Sonication
Analysis's SonicationMetadataService (used when it resolves RAW image
metadata from a ZIP-dropped Exablate export):

1. "RL (ROW)"-style combined anatomical-axis + ROW/COL display string
   (SonicationMetadataService._frequency_direction_display), added as a
   new `frequency_direction_display` field. FUS already tracked the
   anatomical axis (frequency_direction) and the raw acquisition token
   (frequency_matrix_axis / phase_direction) as separate fields; this adds
   the combined string without removing either underlying field.

2. Cascade review found (and fixed) a real, previously-unrelated bug: the
   literal string "Unknown" is itself truthy, so
   `mri_exact_header.get(field) or <fallback>` let a MriImageParams row
   with no valid direction cosines silently overwrite a perfectly good
   DICOM- or text-derived value with the literal word "Unknown" -- both in
   the local-variable cascade AND (the actual root cause) in the final
   `**mri_exact_header` dict spread, which happened *after* the
   carefully-resolved local variables were already placed into the same
   dict literal, silently reverting them. Mirrors Sonication Analysis's
   cascade, which only lets a stronger source override a weaker one when
   the stronger source actually resolved a value.

Runs entirely without PySide6/pydicom.
"""
import tempfile
from pathlib import Path

from raw_metadata_resolver import RawMetadataResolver

text = Path("raw_metadata_resolver.py").read_text(encoding="utf-8")
for marker in (
    "frequency_direction_display",
    "mri_exact_header_safe",
    "def _meaningful(value):",
):
    assert marker in text, marker
print("Commit0144 static markers: PASS")

# --- bug fix: a row with no valid cosines must not overwrite a good
# text-derived value with the literal string "Unknown" -----------------
workdir = Path(tempfile.mkdtemp(prefix="commit0144_test_"))
xml_path = workdir / "MriImageParams.xml"
xml_path.write_text(
    """<?xml version="1.0"?>
<xml xmlns:rs="urn:schemas-microsoft-com:rowset" xmlns:z="#RowsetSchema">
<rs:data>
<z:row fieldindex="5" sonicationindex="1" zoneindex="0" arrayindex="0"
       seriesdiscription="TMAP-ME" freqdirection="ROW"
       rowdirectcosrasx="0" rowdirectcosrasy="0" rowdirectcosrasz="0"
       coldirectcosrasx="0" coldirectcosrasy="0" coldirectcosrasz="0"/>
</rs:data>
</xml>""",
    encoding="utf-8",
)
sidecar = workdir / "protocol.txt"
sidecar.write_text("Frequency Direction: RL\n", encoding="utf-8")
raw_path = workdir / "5-1-0-0.raw"
raw_path.write_bytes(b"\x00" * 1000)
index = RawMetadataResolver.build_index([xml_path, sidecar, raw_path])
result = RawMetadataResolver.resolve(raw_path, index)
assert result.get("frequency_direction") == "RL", result.get("frequency_direction")
print("Commit0144 'Unknown' no longer overwrites a good text-derived value: PASS")

# --- combined display string: normal axis + ROW/COL token --------------
workdir2 = Path(tempfile.mkdtemp(prefix="commit0144_test_axis_"))
xml_path2 = workdir2 / "MriImageParams.xml"
xml_path2.write_text(
    """<?xml version="1.0"?>
<xml xmlns:rs="urn:schemas-microsoft-com:rowset" xmlns:z="#RowsetSchema">
<rs:data>
<z:row fieldindex="5" sonicationindex="1" zoneindex="0" arrayindex="0"
       seriesdiscription="TMAP-ME" freqdirection="ROW"
       rowdirectcosrasx="1" rowdirectcosrasy="0" rowdirectcosrasz="0"
       coldirectcosrasx="0" coldirectcosrasy="1" coldirectcosrasz="0"/>
</rs:data>
</xml>""",
    encoding="utf-8",
)
raw_path2 = workdir2 / "5-1-0-0.raw"
raw_path2.write_bytes(b"\x00" * 1000)
index2 = RawMetadataResolver.build_index([xml_path2, raw_path2])
result2 = RawMetadataResolver.resolve(raw_path2, index2)
assert result2.get("frequency_direction") == "RL", result2.get("frequency_direction")
assert result2.get("frequency_matrix_axis") == "ROW", result2.get("frequency_matrix_axis")
assert result2.get("frequency_direction_display") == "RL (ROW)", result2.get("frequency_direction_display")
print("Commit0144 combined display 'RL (ROW)': PASS")

# --- combined display string: oblique + COL token -----------------------
workdir3 = Path(tempfile.mkdtemp(prefix="commit0144_test_oblique_"))
xml_path3 = workdir3 / "MriImageParams.xml"
xml_path3.write_text(
    """<?xml version="1.0"?>
<xml xmlns:rs="urn:schemas-microsoft-com:rowset" xmlns:z="#RowsetSchema">
<rs:data>
<z:row fieldindex="5" sonicationindex="1" zoneindex="0" arrayindex="0"
       seriesdiscription="TMAP-ME" freqdirection="COL"
       rowdirectcosrasx="0.9" rowdirectcosrasy="0.436" rowdirectcosrasz="0"
       coldirectcosrasx="-0.436" coldirectcosrasy="0.9" coldirectcosrasz="0"/>
</rs:data>
</xml>""",
    encoding="utf-8",
)
raw_path3 = workdir3 / "5-1-0-0.raw"
raw_path3.write_bytes(b"\x00" * 1000)
index3 = RawMetadataResolver.build_index([xml_path3, raw_path3])
result3 = RawMetadataResolver.resolve(raw_path3, index3)
assert result3.get("frequency_direction") == "Oblique >20°", result3.get("frequency_direction")
assert result3.get("frequency_direction_display") == "Oblique >20° (COL)", result3.get("frequency_direction_display")
print("Commit0144 combined display 'Oblique >20° (COL)': PASS")

# --- combined display string: no evidence at all -> Unavailable ---------
workdir4 = Path(tempfile.mkdtemp(prefix="commit0144_test_none_"))
raw_path4 = workdir4 / "unrelated.raw"
raw_path4.write_bytes(b"\x00" * 1000)
index4 = RawMetadataResolver.build_index([raw_path4])
result4 = RawMetadataResolver.resolve(raw_path4, index4)
assert result4.get("frequency_direction_display") == "Unavailable", result4.get("frequency_direction_display")
print("Commit0144 combined display falls back to 'Unavailable' with no evidence: PASS")

# --- app.py UI wiring -----------------------------------------------------
app_text = Path("app.py").read_text(encoding="utf-8")
assert '"frequency_direction_display"' in app_text
assert "'frequency_direction_display':'Frequency Direction (Anatomical + ROW/COL)'" in app_text
print("Commit0144 DicomHeaderDialog Geometry tab wiring present: PASS")

print("Commit0144 functional checks: PASS")
