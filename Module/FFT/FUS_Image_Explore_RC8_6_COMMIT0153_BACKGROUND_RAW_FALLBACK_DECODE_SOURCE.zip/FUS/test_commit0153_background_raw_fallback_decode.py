"""Commit0153 regression test: load_raw_file's extended-fallback decode
(load_raw_file_auto) runs on a background thread, so it no longer blocks
the whole app.

User-reported (with a screenshot): the window title bar showed
"(Not Responding)" while a progress panel labeled "Analyzing RAW Data"
sat on a specific file ("geofile.out.7") with an indeterminate progress
bar. That panel is shown by `load_raw_file`'s extended-fallback path
(`load_raw_file_auto`, used when a RAW file does not match the fast
"exact" decoder -- e.g. an unusual tracker/geometry file). The call ran
synchronously on the UI thread with only a single `processEvents()` call
*before* the blocking decode started, not during it -- the same class of
bug already fixed for virtual header generation (Commit0145) and Quick
Spike Detect/Correlation (Commit0146), just in a third place.

Fix: the same background-thread pattern (a plain `threading.Thread` plus
the existing `AnalysisSignals` class from Commit0146) is now used here
too. A request-id counter lets a stale background result (from a file
the user has since navigated away from, by clicking a different file
while the first one's fallback decode was still running) be discarded
safely instead of overwriting the currently-displayed file.

Runs entirely without PySide6/pydicom.
"""
import threading
import time
from pathlib import Path

text = Path("app.py").read_text(encoding="utf-8")

for marker in (
    "self._raw_load_request_id = 0",
    "self._raw_load_request_id = getattr(self, \"_raw_load_request_id\", 0) + 1",
    "if request_id != self._raw_load_request_id:",
    "threading.Thread(target=run, daemon=True).start()",
):
    assert text.count(marker) >= 1, marker[:60]
print("Commit0153 static markers: PASS")

# The fix must live inside load_raw_file, and load_raw_file_auto must no
# longer be called directly on the calling thread inside that function
# (only from within the new run() closure).
start = text.index("    def load_raw_file(self, path: Path):")
end = text.index("\n    def load_bitmap_image", start)
body = text[start:end]
assert "threading.Thread(target=run, daemon=True).start()" in body
assert body.count("load_raw_file_auto(") == 1  # only inside run()
# Confirm the blocking call is textually inside the run() closure, not at
# the same indentation as the rest of the method body.
run_start = body.index("def run():")
call_pos = body.index("load_raw_file_auto(")
assert call_pos > run_start, "load_raw_file_auto must be called from inside run(), not before it"
print("Commit0153 load_raw_file_auto is only ever called from the background closure: PASS")


# --- functional: simulate the threading/stale-result-discard behavior
# using a minimal stand-in, since the real function needs many other
# MainWindow attributes (raw_preview_cache, progress panel, etc.) that
# would require a much larger stub than the logic under test needs -----
class _FakeSignal:
    def __init__(self, handler):
        self._handler = handler

    def emit(self, payload):
        self._handler(payload)


class _FakeAnalysisSignals:
    def __init__(self, handler):
        self.finished = _FakeSignal(handler)


results = []


def make_finish_handler(expected_request_id, current_request_id_holder):
    def finish(payload):
        if expected_request_id != current_request_id_holder["value"]:
            results.append(("discarded", expected_request_id))
            return
        results.append(("applied", expected_request_id, payload))
    return finish


current_request_id_holder = {"value": 0}


def slow_decode(delay):
    time.sleep(delay)
    return {"decoded": True}


def start_request(delay, request_id, current_request_id_holder):
    signals = _FakeAnalysisSignals(make_finish_handler(request_id, current_request_id_holder))

    def run():
        result = slow_decode(delay)
        signals.finished.emit({"result": result, "error": None})

    threading.Thread(target=run, daemon=True).start()


# Request 1 (slow) starts, then the user "navigates away" (request 2,
# fast) before request 1 finishes. Request 1's result must be discarded.
current_request_id_holder["value"] = 1
start_request(delay=0.3, request_id=1, current_request_id_holder=current_request_id_holder)
current_request_id_holder["value"] = 2
start_request(delay=0.02, request_id=2, current_request_id_holder=current_request_id_holder)

deadline = time.time() + 5
while time.time() < deadline and len(results) < 2:
    time.sleep(0.02)

assert len(results) == 2, results
outcomes = {r[1]: r[0] for r in results}
assert outcomes[1] == "discarded", results
assert outcomes[2] == "applied", results
print("Commit0153 stale background result is discarded; the latest request's "
      "result is applied: PASS")

print("Commit0153 background RAW fallback decode functional checks: PASS")
