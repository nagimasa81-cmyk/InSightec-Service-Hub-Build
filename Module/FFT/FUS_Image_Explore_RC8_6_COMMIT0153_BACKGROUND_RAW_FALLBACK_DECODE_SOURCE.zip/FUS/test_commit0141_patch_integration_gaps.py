"""Commit0141 regression test: patch-noise integration gaps closed.

Commit0140 added broad patch/region detection to _suppress_image_spikes
(used by Spike Diag's "Apply Spike Processing"). Two other consumers were
found to still miss it entirely:

1. `_quick_spike_fast_raw_support` (the "Quick Spike Detect" screening used
   to flag High Confidence / Review / No Spike across many images) called
   `_raw_spike_features` but its own accept/quality scoring only looked at
   isolated_count and abnormal_line_count, never patch_tile_z. Fixed by
   adding a `patch_tile_count` term.
2. Raw Data Compensation's "Auto Correct" (`core/auto_correct.py`) uses a
   completely separate detector, `_bright_blob_mask`, whose coverage of a
   real reported four-region case varied a lot (roughly 3%-70% pixel
   coverage per region) across the Artifact Removal / Protection slider
   range, and even where a combined "Patch" mask covering all four regions
   was tried, it was rejected at every slider setting on
   `outside_image_change` alone. Fixed by adding an independent
   `_patch_region_mask`/`_patch_region_components` detector (not driven by
   the sliders) and trying each connected region as its own candidate
   (matching Commit0140's per-component approach in Spike Diag) instead of
   one combined mask.

Runs entirely without PySide6/pydicom.
"""
import ast
import warnings
from pathlib import Path

import numpy as np

app_text = Path("app.py").read_text(encoding="utf-8")
auto_correct_text = Path("core/auto_correct.py").read_text(encoding="utf-8")

# --- static markers -------------------------------------------------------
for marker in (
    "patch_tile_z = features.get(\"patch_tile_z\"",
    "patch_tile_count = int(np.sum(np.asarray(patch_tile_z) > 4.0))",
    "or patch_tile_count >= 2",
):
    assert marker in app_text, marker
for marker in (
    "def _patch_region_mask",
    "def _patch_region_components",
    '"Patch"',
    "for comp_mask in _patch_region_components(source):",
):
    assert marker in auto_correct_text, marker
print("Commit0141 static markers: PASS")

# --- part 1: Quick Spike Detect screening now patch-aware -----------------
tree = ast.parse(app_text)
main_window = next(n for n in ast.walk(tree) if isinstance(n, ast.ClassDef) and n.name == "MainWindow")
wanted = {
    "_quick_spike_fast_raw_support", "_raw_spike_features", "_radial_robust_zscore",
    "_robust_zscore", "_group_spike_indices", "_patch_spike_features",
}
found = {}
for item in main_window.body:
    if isinstance(item, ast.FunctionDef) and item.name in wanted:
        found[item.name] = ast.get_source_segment(app_text, item)
assert wanted <= found.keys(), wanted - found.keys()
namespace = {"np": np}
exec(compile("\n\n".join(found.values()), "<app.py extract>", "exec"), namespace)


class _Fake:
    _robust_zscore = staticmethod(namespace["_robust_zscore"])
    _radial_robust_zscore = classmethod(namespace["_radial_robust_zscore"])
    _patch_spike_features = classmethod(namespace["_patch_spike_features"])
    _group_spike_indices = staticmethod(namespace["_group_spike_indices"])
    _raw_spike_features = classmethod(namespace["_raw_spike_features"])
    _quick_spike_fast_raw_support = classmethod(namespace["_quick_spike_fast_raw_support"])


fake = _Fake()


def make_synthetic_kspace(rows=256, cols=256, seed=0):
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:rows, 0:cols]
    cy, cx = rows // 2, cols // 2
    r = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2) + 1.0
    base = 5000.0 / (1.0 + (r / 6.0) ** 1.6)
    noise = np.exp(rng.normal(0, 0.35, size=base.shape))
    return base * noise


def to_complex_kspace(magnitude, seed=0):
    rng = np.random.default_rng(seed)
    phase = rng.uniform(0, 2 * np.pi, size=magnitude.shape)
    return magnitude * np.exp(1j * phase)


with warnings.catch_warnings():
    warnings.simplefilter("ignore")

    magnitude = make_synthetic_kspace(seed=7)
    boxes = [(56, 111, 240, 254), (64, 111, 1, 15), (144, 199, 1, 15), (144, 199, 240, 254)]
    for (y0, y1, x0, x1) in boxes:
        magnitude[y0:y1, x0:x1] *= 6.0
    kspace = to_complex_kspace(magnitude, seed=7)

    screen = fake._quick_spike_fast_raw_support(kspace)
    assert screen["accepted_count"] >= 1, screen
    assert screen["patch_tile_count"] >= 2, screen
    print(f"Commit0141 Quick Spike Detect screening now flags the four-patch case "
          f"(patch_tile_count={screen['patch_tile_count']}): PASS")

    false_pos = 0
    n_trials = 20
    for seed in range(n_trials):
        clean_mag = make_synthetic_kspace(seed=4000 + seed)
        clean_kspace = to_complex_kspace(clean_mag, seed=4000 + seed)
        clean_screen = fake._quick_spike_fast_raw_support(clean_kspace)
        if clean_screen["accepted_count"] and clean_screen["patch_tile_count"] >= 2:
            false_pos += 1
    assert false_pos == 0, false_pos
    print(f"Commit0141 Quick Spike Detect patch_tile_count false positives on "
          f"{n_trials} clean images: {false_pos}: PASS")

# --- part 2: Raw Data Compensation Auto Correct now detects+accepts -------
import sys  # noqa: E402
sys.path.insert(0, ".")
from core.auto_correct import auto_correct  # noqa: E402

with warnings.catch_warnings():
    warnings.simplefilter("ignore")

    magnitude = make_synthetic_kspace(seed=7)
    for (y0, y1, x0, x1) in boxes:
        magnitude[y0:y1, x0:x1] *= 6.0
    kspace = to_complex_kspace(magnitude, seed=7)

    accepted_any = False
    for removal, protection in ((50, 80),):
        result = auto_correct(kspace, removal=removal, detail=70, protection=protection)
        patch_trials = [c for c in result.candidates if c.get("type") == "Patch"]
        assert len(patch_trials) >= 1, (removal, protection, "no Patch candidates produced")
        if any(c["accepted"] for c in patch_trials):
            accepted_any = True
    assert accepted_any, "no Patch candidate was accepted at removal=50/protection=80"
    print("Commit0141 Raw Data Compensation Auto Correct accepts per-region Patch "
          "candidates: PASS")

print("Commit0141 functional checks: PASS")
