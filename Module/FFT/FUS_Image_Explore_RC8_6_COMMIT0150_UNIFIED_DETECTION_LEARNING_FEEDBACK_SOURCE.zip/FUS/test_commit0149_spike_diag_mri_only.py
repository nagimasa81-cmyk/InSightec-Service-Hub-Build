"""Commit0149 regression test: Spike Diag ("Apply Spike Processing" and
its auto-trigger when switching to the Spike Diag tab) is now MRI-only,
matching Commit0148's Quick Spike Detect fix.

The user confirmed both paths (Spike Diag's "Apply Spike Processing" /
auto-trigger, and Quick Spike Detect) must exclude CT images, and asked
for Spike Diag to be brought in line with Commit0148.

Three call sites were fixed:
1. `_activate_spike_diag_from_workspace_selection`'s DICOM-indices loop:
   a Modality check per entry (same as Commit0148).
2. Its "current Image Workspace image" branch (no DICOM index selected):
   checks `self.current_ds`'s Modality if the current image is a DICOM,
   or `self.current_virtual_header`'s `image_category` (against the same
   `MRI_SPIKE_ELIGIBLE_CATEGORIES` allow-list Commit0148 introduced) if
   it is a RAW file.
3. `apply_spike_processing`'s DICOM-indices loop: the same Modality check.
4. `detect_spikes` (the generic RAW/BIN/DAT/PFile 1D fallback used when no
   DICOM is selected): a non-tracker RAW file is now classified via
   `_get_or_build_raw_virtual_header` and skipped if its `image_category`
   is not in the MRI allow-list.

Runs entirely without PySide6/pydicom.
"""
from pathlib import Path

text = Path("app.py").read_text(encoding="utf-8")

for marker in (
    # 1) _activate_spike_diag_from_workspace_selection DICOM loop
    'if modality and modality != "MR":\n                    excluded_modality += 1\n                    progress.setValue(number)\n                    continue\n                progress.setLabelText(\n                    f"Analyzing spike noise',
    # 2) current-image branch
    "elif self.current_virtual_header is not None:\n                category = self.current_virtual_header.get(\"image_category\", \"Excluded\")\n                is_non_mri = category not in MRI_SPIKE_ELIGIBLE_CATEGORIES",
    # 3) apply_spike_processing DICOM loop
    'f"Detecting repeated stripes and k-space spikes',
    # 4) detect_spikes RAW fallback
    '"Skipped: not MRI (spike detection is MRI-only)"',
):
    assert marker in text, marker[:80]
print("Commit0149 static markers: PASS")

# Count how many of the four spike-related loops now reference the
# MRI_SPIKE_ELIGIBLE_CATEGORIES allow-list or a Modality check (Commit0148
# introduced 2 in the Quick Spike Detect paths; this commit adds at least
# 3 more in the Spike Diag / detect_spikes paths).
modality_checks = text.count('modality != "MR"')
category_checks = text.count("not in MRI_SPIKE_ELIGIBLE_CATEGORIES")
assert modality_checks >= 3, modality_checks   # dicom, apply_spike_processing (Commit0148's own dicom path is a 3rd)
assert category_checks >= 3, category_checks  # raw path (0148), current-image branch, detect_spikes
print(f"Commit0149 MRI-only checks present: {modality_checks} Modality checks, "
      f"{category_checks} image_category allow-list checks (across Commit0148+0149): PASS")

print("Commit0149 Spike Diag MRI-only exclusion functional checks: PASS")
