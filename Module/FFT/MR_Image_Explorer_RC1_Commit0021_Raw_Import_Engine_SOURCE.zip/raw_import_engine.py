from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np


class RawImportError(RuntimeError):
    pass


@dataclass
class RawImportResult:
    path: Path
    data: np.ndarray
    rows: int
    cols: int
    dtype_name: str
    endian_name: str
    offset_bytes: int
    is_kspace: bool
    confidence: float
    reason: str


@dataclass
class _Candidate:
    rows: int
    cols: int
    dtype: np.dtype
    dtype_name: str
    endian_name: str
    offset: int
    is_complex: bool
    score: float = -1e9
    reason: str = ""


_COMMON_DIMS = (
    64, 96, 128, 160, 192, 224, 240, 256, 288, 320, 384,
    448, 480, 512, 576, 640, 768, 896, 1024, 1280, 1536, 2048,
)
_OFFSETS = (0, 128, 256, 512, 1024, 2048, 4096, 6144, 8192, 16384)


def _safe_cache_read(path: Optional[Path]) -> dict:
    if path is None or not path.exists():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _safe_cache_write(path: Optional[Path], value: dict) -> None:
    if path is None:
        return
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(value, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    except Exception:
        pass


def _profile_key(path: Path) -> str:
    return f"{path.suffix.lower()}:{path.stat().st_size}"


def _dtype_candidates() -> list[tuple[np.dtype, str, str, bool]]:
    values = []
    for endian, endian_name in (("<", "Little Endian"), (">", "Big Endian")):
        values.extend([
            (np.dtype(endian + "i2"), "Signed Int16", endian_name, False),
            (np.dtype(endian + "u2"), "Unsigned Int16", endian_name, False),
            (np.dtype(endian + "f4"), "Float32", endian_name, False),
            (np.dtype(endian + "c8"), "Complex Float32", endian_name, True),
        ])
    # Interleaved complex int16 is handled separately.
    values.extend([
        (np.dtype("<i2"), "Complex Int16", "Little Endian", True),
        (np.dtype(">i2"), "Complex Int16", "Big Endian", True),
    ])
    return values


def _matrix_shapes(element_count: int) -> list[tuple[int, int]]:
    shapes = set()
    side = int(round(math.sqrt(element_count)))
    if side * side == element_count:
        shapes.add((side, side))

    for rows in _COMMON_DIMS:
        if element_count % rows == 0:
            cols = element_count // rows
            if 32 <= cols <= 4096:
                ratio = max(rows, cols) / max(min(rows, cols), 1)
                if ratio <= 8.0:
                    shapes.add((rows, cols))
    return sorted(
        shapes,
        key=lambda rc: (
            abs(math.log(max(rc) / max(min(rc), 1))),
            abs(rc[0] - rc[1]),
        ),
    )[:40]


def _decode_candidate(path: Path, candidate: _Candidate) -> np.ndarray:
    raw = np.fromfile(path, dtype=candidate.dtype, offset=candidate.offset)
    expected = candidate.rows * candidate.cols

    if candidate.dtype_name == "Complex Int16":
        needed = expected * 2
        if raw.size < needed:
            raise RawImportError("Complex Int16 candidate is shorter than expected.")
        paired = raw[:needed].reshape((-1, 2))
        data = paired[:, 0].astype(np.float32) + 1j * paired[:, 1].astype(np.float32)
    else:
        if raw.size < expected:
            raise RawImportError("RAW candidate is shorter than expected.")
        data = raw[:expected]

    return data.reshape((candidate.rows, candidate.cols))


def _entropy_score(values: np.ndarray) -> float:
    finite = np.asarray(values, dtype=float)
    finite = finite[np.isfinite(finite)]
    if finite.size < 32:
        return -5.0
    low, high = np.percentile(finite, [1.0, 99.0])
    if not np.isfinite(low) or not np.isfinite(high) or high <= low:
        return -5.0
    hist, _ = np.histogram(finite, bins=64, range=(low, high))
    probabilities = hist.astype(float)
    probabilities /= max(probabilities.sum(), 1.0)
    probabilities = probabilities[probabilities > 0]
    entropy = -np.sum(probabilities * np.log2(probabilities))
    return float(entropy / 6.0)


def _score_candidate(array: np.ndarray, is_complex: bool) -> tuple[float, str]:
    data = np.asarray(array)
    magnitude = np.abs(data) if np.iscomplexobj(data) else np.asarray(data, dtype=float)
    finite = magnitude[np.isfinite(magnitude)]
    if finite.size < 128:
        return -100.0, "Too few finite samples"

    zero_fraction = float(np.mean(finite == 0))
    unique_estimate = np.unique(finite[: min(finite.size, 20000)]).size
    low, median, high = np.percentile(finite, [1.0, 50.0, 99.5])
    spread = float(high - low)
    robust_scale = float(np.median(np.abs(finite - median)) * 1.4826)
    dynamic = spread / max(robust_scale, 1e-9)

    score = 0.0
    reasons = []

    if zero_fraction < 0.98:
        score += 1.0
        reasons.append("non-empty")
    else:
        score -= 5.0

    if unique_estimate >= 32:
        score += 1.0
        reasons.append("sufficient variation")
    else:
        score -= 4.0

    if np.isfinite(dynamic) and 1.5 <= dynamic <= 1e6:
        score += min(math.log10(max(dynamic, 1.0)), 4.0) * 0.45
        reasons.append("plausible dynamic range")
    else:
        score -= 2.0

    score += _entropy_score(finite)

    # MRI-like frequency structure: energy is neither completely uniform nor a single constant.
    sample = magnitude
    if max(sample.shape) > 512:
        step_y = max(1, sample.shape[0] // 512)
        step_x = max(1, sample.shape[1] // 512)
        sample = sample[::step_y, ::step_x]

    if is_complex:
        kspace = sample
        image = np.abs(np.fft.fftshift(np.fft.ifft2(np.fft.ifftshift(kspace))))
    else:
        image = sample
        kspace = np.abs(np.fft.fftshift(np.fft.fft2(np.fft.ifftshift(image))))

    if np.all(np.isfinite(image)):
        image_low, image_high = np.percentile(image, [1.0, 99.0])
        if image_high > image_low:
            score += 0.8
            reasons.append("reconstructable")

    cy, cx = kspace.shape[0] // 2, kspace.shape[1] // 2
    radius_y = max(2, kspace.shape[0] // 16)
    radius_x = max(2, kspace.shape[1] // 16)
    center_energy = float(np.sum(np.abs(
        kspace[
            max(0, cy-radius_y):min(kspace.shape[0], cy+radius_y+1),
            max(0, cx-radius_x):min(kspace.shape[1], cx+radius_x+1),
        ]
    )))
    total_energy = float(np.sum(np.abs(kspace))) + 1e-12
    center_ratio = center_energy / total_energy
    if 0.002 <= center_ratio <= 0.95:
        score += 1.0
        reasons.append("MRI-like frequency distribution")

    return score, ", ".join(reasons)


def _candidate_from_cache(path: Path, profile: dict) -> Optional[_Candidate]:
    try:
        dtype = np.dtype(profile["dtype"])
        return _Candidate(
            rows=int(profile["rows"]),
            cols=int(profile["cols"]),
            dtype=dtype,
            dtype_name=str(profile["dtype_name"]),
            endian_name=str(profile["endian_name"]),
            offset=int(profile.get("offset", 0)),
            is_complex=bool(profile.get("is_complex", False)),
        )
    except Exception:
        return None


def load_raw_file_auto(
    path: Path,
    cache_path: Optional[Path] = None,
    minimum_confidence: float = 0.56,
) -> RawImportResult:
    path = Path(path)
    if not path.exists() or not path.is_file():
        raise RawImportError(f"RAW file does not exist: {path}")

    file_size = path.stat().st_size
    if file_size < 128:
        raise RawImportError("File is too small to be a supported RAW image.")

    cache = _safe_cache_read(cache_path)
    key = _profile_key(path)
    cached = _candidate_from_cache(path, cache.get(key, {}))
    candidates: list[_Candidate] = []

    if cached is not None:
        candidates.append(cached)

    for offset in _OFFSETS:
        if offset >= file_size:
            continue
        payload = file_size - offset

        for dtype, dtype_name, endian_name, is_complex in _dtype_candidates():
            item_size = dtype.itemsize
            if dtype_name == "Complex Int16":
                denominator = item_size * 2
            else:
                denominator = item_size
            if payload % denominator != 0:
                continue

            element_count = payload // denominator
            for rows, cols in _matrix_shapes(element_count):
                candidates.append(_Candidate(
                    rows=rows,
                    cols=cols,
                    dtype=dtype,
                    dtype_name=dtype_name,
                    endian_name=endian_name,
                    offset=offset,
                    is_complex=is_complex,
                ))

    # Remove duplicates while preserving cached candidate priority.
    unique: list[_Candidate] = []
    seen = set()
    for candidate in candidates:
        marker = (
            candidate.rows, candidate.cols, candidate.dtype.str,
            candidate.dtype_name, candidate.offset,
        )
        if marker not in seen:
            seen.add(marker)
            unique.append(candidate)

    if not unique:
        raise RawImportError(
            "No supported matrix/data-type combination matches the file size."
        )

    evaluated: list[tuple[_Candidate, np.ndarray]] = []
    for candidate in unique[:320]:
        try:
            array = _decode_candidate(path, candidate)
            score, reason = _score_candidate(array, candidate.is_complex)
            # Prefer common square MRI matrices and smaller header offsets.
            if candidate.rows == candidate.cols:
                score += 0.35
            if candidate.rows in _COMMON_DIMS and candidate.cols in _COMMON_DIMS:
                score += 0.20
            score -= candidate.offset / max(file_size, 1) * 0.4
            candidate.score = score
            candidate.reason = reason
            evaluated.append((candidate, array))
        except Exception:
            continue

    if not evaluated:
        raise RawImportError("All RAW decoding candidates failed.")

    evaluated.sort(key=lambda item: item[0].score, reverse=True)
    best, best_array = evaluated[0]
    second_score = evaluated[1][0].score if len(evaluated) > 1 else best.score - 3.0

    absolute = 1.0 / (1.0 + math.exp(-(best.score - 2.0)))
    separation = 1.0 / (1.0 + math.exp(-(best.score - second_score)))
    confidence = float(np.clip(0.65 * absolute + 0.35 * separation, 0.0, 1.0))

    if confidence < minimum_confidence:
        alternatives = ", ".join(
            f"{item[0].rows}×{item[0].cols} {item[0].dtype_name}"
            for item in evaluated[:3]
        )
        raise RawImportError(
            "RAW format could not be identified with sufficient confidence.\n"
            f"Best candidates: {alternatives}"
        )

    cache[key] = {
        "rows": best.rows,
        "cols": best.cols,
        "dtype": best.dtype.str,
        "dtype_name": best.dtype_name,
        "endian_name": best.endian_name,
        "offset": best.offset,
        "is_complex": best.is_complex,
    }
    _safe_cache_write(cache_path, cache)

    return RawImportResult(
        path=path,
        data=best_array,
        rows=best.rows,
        cols=best.cols,
        dtype_name=best.dtype_name,
        endian_name=best.endian_name,
        offset_bytes=best.offset,
        is_kspace=best.is_complex,
        confidence=confidence,
        reason=best.reason or "Best automatic RAW interpretation",
    )
