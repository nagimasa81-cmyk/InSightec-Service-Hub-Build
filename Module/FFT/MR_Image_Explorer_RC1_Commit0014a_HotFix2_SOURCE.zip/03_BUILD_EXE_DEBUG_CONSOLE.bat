@echo off
call "%~dp0\01_RUN_PYTHON_DEBUG.bat"
