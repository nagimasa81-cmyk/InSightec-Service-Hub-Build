from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import numpy as np

from .hybrid_compensation import compensate, detect_artifacts, ifft2c


@dataclass(frozen=True)
class AutoCorrectResult:
    kspace: np.ndarray
    image: np.ndarray
    mask: np.ndarray
    metrics: dict[str, float]
    candidates: list[dict[str, Any]]
    selected_types: list[str]


def _gradient_energy(image: np.ndarray) -> float:
    a = np.asarray(image, dtype=float)
    gy = np.diff(a, axis=0, append=a[-1:, :])
    gx = np.diff(a, axis=1, append=a[:, -1:])
    return float(np.mean(np.hypot(gx, gy)))


def _quality(before_k: np.ndarray, result, mask: np.ndarray, protection: float) -> dict[str, float]:
    before_img = np.abs(ifft2c(before_k))
    after_img = np.asarray(result.image, dtype=float)
    eps = 1e-12
    roi_before = np.abs(before_k)[mask]
    roi_after = np.abs(result.kspace)[mask]
    artifact_reduction = float(np.clip(1.0 - np.mean(roi_after) / max(np.mean(roi_before), eps), -1.0, 1.0)) if np.any(mask) else 0.0
    image_delta = float(np.mean(np.abs(after_img - before_img)) / max(np.mean(np.abs(before_img)), eps))
    edge_before = _gradient_energy(before_img)
    edge_after = _gradient_energy(after_img)
    detail_preservation = float(np.clip(1.0 - abs(edge_after - edge_before) / max(edge_before, eps), 0.0, 1.0))
    outside_change = image_delta
    residual = float(np.clip(np.mean(roi_after) / max(np.mean(roi_before), eps), 0.0, 2.0)) if np.any(mask) else 1.0
    overall = 100.0 * (0.58 * max(artifact_reduction, 0.0) + 0.30 * detail_preservation + 0.12 * (1.0 - min(outside_change, 1.0)))
    overall -= 100.0 * float(protection) * max(0.0, outside_change - 0.035)
    mask_coverage = float(np.count_nonzero(mask)) / float(mask.size) if mask.size else 0.0
    edge_preservation = detail_preservation
    return {
        "artifact_reduction": 100.0 * artifact_reduction,
        "detail_preservation": 100.0 * detail_preservation,
        "edge_preservation": 100.0 * edge_preservation,
        "outside_image_change": 100.0 * outside_change,
        "residual_artifact": 100.0 * residual,
        "mask_coverage": 100.0 * mask_coverage,
        "overall_quality": float(overall),
    }




def _bright_blob_mask(kspace: np.ndarray, removal_f: float, protect_f: float) -> np.ndarray:
    """Detect broad off-centre high-energy blobs that spike-only detection can miss.

    The detector is deliberately conservative: it excludes the DC centre, uses a
    robust percentile threshold, removes isolated pixels, and keeps only compact
    components within a bounded area range.
    """
    mag = np.abs(np.asarray(kspace))
    h, w = mag.shape
    yy, xx = np.ogrid[:h, :w]
    cy, cx = (h - 1) / 2.0, (w - 1) / 2.0
    centre_r = max(4.0, min(h, w) * (0.035 + 0.035 * protect_f))
    valid = ((yy - cy) ** 2 + (xx - cx) ** 2) >= centre_r ** 2
    vals = mag[valid]
    if vals.size < 32:
        return np.zeros_like(mag, dtype=bool)
    percentile = float(np.clip(99.85 - 0.45 * removal_f, 99.35, 99.85))
    threshold = float(np.percentile(vals, percentile))
    raw = valid & (mag >= threshold)
    # Majority close/open using only NumPy shifts.
    neigh = np.zeros(raw.shape, dtype=np.uint8)
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            neigh += np.roll(np.roll(raw, dy, axis=0), dx, axis=1)
    grown = neigh >= 3
    neigh2 = np.zeros(raw.shape, dtype=np.uint8)
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            neigh2 += np.roll(np.roll(grown, dy, axis=0), dx, axis=1)
    cleaned = grown & (neigh2 >= 4) & valid

    # Connected components; retain compact, meaningful blobs only.
    seen = np.zeros(cleaned.shape, dtype=bool)
    out = np.zeros(cleaned.shape, dtype=bool)
    min_area = max(4, int(round(min(h, w) * 0.015)))
    max_area = max(min_area + 1, int(round(cleaned.size * (0.004 + 0.025 * removal_f))))
    for y in range(h):
        for x in range(w):
            if not cleaned[y, x] or seen[y, x]:
                continue
            stack=[(y,x)]; seen[y,x]=True; pts=[]
            while stack:
                py, px = stack.pop(); pts.append((py,px))
                for ny in range(max(0,py-1), min(h,py+2)):
                    for nx in range(max(0,px-1), min(w,px+2)):
                        if cleaned[ny,nx] and not seen[ny,nx]:
                            seen[ny,nx]=True; stack.append((ny,nx))
            area=len(pts)
            if min_area <= area <= max_area:
                ys=[q[0] for q in pts]; xs=[q[1] for q in pts]
                bh=max(ys)-min(ys)+1; bw=max(xs)-min(xs)+1
                fill=area/max(1,bh*bw)
                if fill >= 0.16:
                    for py,px in pts: out[py,px]=True
    return out

def auto_correct(
    kspace: np.ndarray,
    *,
    threshold_sigma: float = 3.0,
    sensitivity: str = "Conservative",
    removal: int = 50,
    detail: int = 70,
    protection: int = 80,
    target_ratio: float = 1.0,
) -> AutoCorrectResult:
    """Candidate-by-candidate virtual reconstruction and quality selection.

    Detection is intentionally broad, but candidates are accepted only when a
    trial reconstruction improves artifact energy without excessive image change.
    """
    source = np.asarray(kspace)
    if source.ndim != 2:
        raise ValueError("Auto Correct requires a 2-D k-space array.")
    removal_f = float(np.clip(removal / 100.0, 0.0, 1.0))
    detail_f = float(np.clip(detail / 100.0, 0.0, 1.0))
    protect_f = float(np.clip(protection / 100.0, 0.0, 1.0))
    level = "Low" if removal < 30 else "Mid" if removal < 58 else "High" if removal < 85 else "Extreme"
    structure_preservation = float(np.clip(0.35 + 0.60 * max(detail_f, protect_f), 0.35, 0.97))
    magnitude = np.abs(source).astype(float)
    finite = magnitude[np.isfinite(magnitude)]
    if finite.size:
        median = float(np.median(finite))
        mad = float(np.median(np.abs(finite - median)))
        robust_sigma = max(1.4826 * mad, 1e-12)
        tail_ratio = float(np.percentile(finite, 99.5) / max(median + robust_sigma, 1e-12))
    else:
        tail_ratio = 1.0
    adaptive_offset = float(np.clip(0.35 * np.log10(max(tail_ratio, 1.0)), 0.0, 1.0))
    threshold = float(threshold_sigma + 0.8 * protect_f - 0.55 * removal_f - adaptive_offset)

    trials: list[dict[str, Any]] = []
    accepted_masks: list[np.ndarray] = []
    accepted_types: list[str] = []
    current = source.copy()
    type_order = ("Spike", "Blob", "Block", "Diagonal", "Line", "Band", "Ring")
    minimum_gain = 18.0 + 16.0 * protect_f - 10.0 * removal_f

    for artifact_type in type_order:
        if artifact_type == "Blob":
            mask = _bright_blob_mask(source, removal_f, protect_f)
            confidence = float(np.clip(np.count_nonzero(mask) / max(mask.size * 0.002, 1.0), 0.0, 1.0))
            compensation_type = "Block"
        else:
            detection = detect_artifacts(source, artifact_type, threshold, sensitivity)
            mask = np.asarray(detection.mask, dtype=bool)
            confidence = detection.confidence
            compensation_type = artifact_type
        if not np.any(mask):
            continue
        coverage = float(np.count_nonzero(mask)) / float(mask.size)
        # Large line/band proposals are especially likely to be normal encoding signal.
        if artifact_type in {"Line", "Band", "Ring"} and coverage > (0.012 + 0.030 * removal_f):
            trials.append({"type": artifact_type, "accepted": False, "reason": "coverage_guard", "coverage": coverage, "quality_gain": -999.0})
            continue
        try:
            trial = compensate(
                current, mask,
                artifact_type=compensation_type,
                level=level,
                threshold_sigma=threshold,
                target_ratio=target_ratio,
                adaptive_direction=True,
                frequency_aware=True,
                harmonic_poisson=True,
                multi_pass=True,
                hermitian_symmetry=True,
                mask_expansion=0 if protect_f >= 0.65 else 1,
                donor_halo=3 if protect_f >= 0.65 else 4,
                pass_count=1 if protect_f >= 0.75 else 2,
                strength_override=float(np.clip(0.35 + 0.55 * removal_f, 0.35, 0.90)),
                structure_preservation=structure_preservation,
                detection_sensitivity=sensitivity,
            )
            q = _quality(current, trial, mask, protect_f)
            gain = q["overall_quality"]
            accepted = bool(gain >= minimum_gain and q["artifact_reduction"] > 4.0 and q["outside_image_change"] <= (12.0 - 7.0 * protect_f))
            shape_bonus = 1.0 if artifact_type in {"Spike", "Blob", "Diagonal"} else 0.85
            candidate_score = float(np.clip(0.45 * gain + 35.0 * confidence + 20.0 * shape_bonus - 150.0 * coverage, -999.0, 100.0))
            record = {"type": artifact_type, "accepted": accepted, "coverage": coverage, "confidence": confidence, "quality_gain": gain, "candidate_score": candidate_score, "adaptive_threshold": threshold, **q}
            trials.append(record)
            if accepted:
                current = trial.kspace
                accepted_masks.append(mask)
                accepted_types.append(artifact_type)
        except Exception as exc:
            trials.append({"type": artifact_type, "accepted": False, "reason": str(exc), "coverage": coverage, "quality_gain": -999.0})

    if accepted_masks:
        final_mask = np.logical_or.reduce(accepted_masks)
    else:
        final_mask = np.zeros(source.shape, dtype=bool)
    final_image = np.abs(ifft2c(current))
    if np.any(final_mask):
        class R: pass
        r = R(); r.kspace = current; r.image = final_image
        metrics = _quality(source, r, final_mask, protect_f)
    else:
        metrics = {"artifact_reduction": 0.0, "detail_preservation": 100.0, "outside_image_change": 0.0, "residual_artifact": 100.0, "overall_quality": 0.0}
    metrics["accepted_candidates"] = float(len(accepted_types))
    metrics["mask_pixels"] = float(np.count_nonzero(final_mask))
    return AutoCorrectResult(current, final_image, final_mask, metrics, trials, accepted_types)


def recalculate_with_mask(
    kspace: np.ndarray,
    mask: np.ndarray,
    *,
    artifact_type: str = "Auto",
    threshold_sigma: float = 3.0,
    sensitivity: str = "Conservative",
    removal: int = 50,
    detail: int = 75,
    protection: int = 85,
    target_ratio: float = 1.0,
) -> AutoCorrectResult:
    """Reconstruct exactly once from the current mask and Quick Adjust values.

    This path never performs candidate selection or Auto Retry.  The supplied
    mask remains authoritative and is returned unchanged.
    """
    source = np.asarray(kspace)
    active_mask = np.asarray(mask, dtype=bool)
    if source.ndim != 2:
        raise ValueError("Quick Adjust requires a 2-D k-space array.")
    if active_mask.shape != source.shape or not np.any(active_mask):
        raise ValueError("The current compensation mask is empty or has an invalid shape.")

    removal_f = float(np.clip(removal / 100.0, 0.0, 1.0))
    detail_f = float(np.clip(detail / 100.0, 0.0, 1.0))
    protect_f = float(np.clip(protection / 100.0, 0.0, 1.0))
    level = "Low" if removal < 30 else "Mid" if removal < 58 else "High" if removal < 85 else "Extreme"
    structure_preservation = float(np.clip(0.35 + 0.60 * max(detail_f, protect_f), 0.35, 0.97))
    threshold = float(threshold_sigma + 0.8 * protect_f - 0.55 * removal_f)

    result = compensate(
        source, active_mask, artifact_type=artifact_type, level=level,
        threshold_sigma=threshold, target_ratio=target_ratio,
        adaptive_direction=False, frequency_aware=True, harmonic_poisson=True,
        multi_pass=True, hermitian_symmetry=True,
        mask_expansion=0 if protect_f >= 0.65 else 1,
        donor_halo=3 if protect_f >= 0.65 else 4,
        pass_count=1 if protect_f >= 0.75 else 2,
        strength_override=float(np.clip(0.35 + 0.55 * removal_f, 0.35, 0.90)),
        structure_preservation=structure_preservation,
        detection_sensitivity=sensitivity,
    )
    metrics = _quality(source, result, active_mask, protect_f)
    metrics["accepted_candidates"] = 1.0
    metrics["mask_pixels"] = float(np.count_nonzero(active_mask))
    return AutoCorrectResult(
        result.kspace, np.asarray(result.image), active_mask.copy(), metrics,
        [{"type": "Current Mask", "accepted": True, "source": "quick_adjust_once"}],
        ["Current Mask"],
    )


AUTO_RETRY_TRIALS: tuple[dict[str, int], ...] = (
    {"removal": 50, "detail": 75, "protection": 85},
    {"removal": 60, "detail": 75, "protection": 75},
    {"removal": 70, "detail": 75, "protection": 65},
    {"removal": 80, "detail": 75, "protection": 55},
    {"removal": 90, "detail": 75, "protection": 45},
    {"removal": 100, "detail": 75, "protection": 35},
)


def _result_rank(result: AutoCorrectResult) -> tuple[float, float, float, float, float]:
    """Rank quality first, then safer image change/residual/detail tie breakers."""
    m = result.metrics
    return (
        float(m.get("overall_quality", 0.0)),
        -float(m.get("outside_image_change", 100.0)),
        -float(m.get("residual_artifact", 100.0)),
        float(m.get("detail_preservation", 0.0)),
        float(m.get("artifact_reduction", 0.0)),
    )


def auto_correct_with_retry(
    kspace: np.ndarray,
    *,
    threshold_sigma: float = 3.0,
    sensitivity: str = "Conservative",
    target_ratio: float = 1.0,
    quality_threshold: float = 60.0,
    progress_callback=None,
    cancel_callback=None,
) -> tuple[AutoCorrectResult, list[dict[str, Any]]]:
    """Run six Quick Adjust trials and return the best validated result.

    The underlying candidate detection, validation, virtual compensation, and
    quality engine remain unchanged. This function only orchestrates retries.
    """
    source = np.asarray(kspace)
    trial_log: list[dict[str, Any]] = []
    results: list[AutoCorrectResult] = []
    for index, settings in enumerate(AUTO_RETRY_TRIALS, start=1):
        if cancel_callback is not None and cancel_callback():
            break
        if progress_callback is not None:
            progress_callback(index, len(AUTO_RETRY_TRIALS), "searching", settings, None)
        result = auto_correct(
            source,
            threshold_sigma=threshold_sigma,
            sensitivity=sensitivity,
            removal=settings["removal"],
            detail=settings["detail"],
            protection=settings["protection"],
            target_ratio=target_ratio,
        )
        results.append(result)
        candidate_found = bool(result.selected_types and np.any(result.mask))
        quality = float(result.metrics.get("overall_quality", 0.0))
        reliable = bool(candidate_found and quality >= quality_threshold)
        record = {
            "trial": index,
            **settings,
            "candidate_found": candidate_found,
            "quality": quality,
            "reliable": reliable,
            "selected_types": list(result.selected_types),
        }
        trial_log.append(record)
        if progress_callback is not None:
            progress_callback(index, len(AUTO_RETRY_TRIALS), "evaluating", settings, record)
    if not results:
        empty = auto_correct(
            source, threshold_sigma=threshold_sigma, sensitivity=sensitivity,
            removal=50, detail=75, protection=85, target_ratio=target_ratio,
        )
        return empty, trial_log
    reliable_results = [r for r, log in zip(results, trial_log) if log["reliable"]]
    candidate_results = [r for r, log in zip(results, trial_log) if log["candidate_found"]]
    pool = reliable_results or candidate_results or results
    return max(pool, key=_result_rank), trial_log
