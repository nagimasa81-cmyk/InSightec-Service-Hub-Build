"""Commit0157 regression test: an "Export CSV" button on the RAW/DICOM
header display window (DicomHeaderDialog), saving whatever header is
currently shown to a CSV file.

DicomHeaderDialog handles two cases:
1. A plain DICOM tag dump: self.tables has exactly one table
   (Tag/Keyword/Name/VR/VM/Value columns).
2. A multi-tab virtual RAW header (Acquisition/Geometry/Semantic/
   Correlation/Provenance/Other): self.tables has one table per tab.
export_header_csv() writes all of self.tables' rows to one CSV; when
there is more than one table, a "Section" column (the tab's title) is
prepended so the exported file preserves which group each row came from.

Runs entirely without PySide6/pydicom (the function itself is pure
Python + the `csv` module once given fake table/dialog objects).
"""
import ast
import csv
import tempfile
from pathlib import Path

text = Path("app.py").read_text(encoding="utf-8")

for marker in (
    "self.export_csv_button=QPushButton('Export CSV'); self.export_csv_button.clicked.connect(self.export_header_csv)",
    "def export_header_csv(self):",
    'writer.writerow(header_row)',
):
    assert marker in text, marker[:70]
print("Commit0157 static markers: PASS")

tree = ast.parse(text)
dialog_cls = next(
    n for n in ast.walk(tree) if isinstance(n, ast.ClassDef) and n.name == "DicomHeaderDialog"
)
node = next(
    item for item in dialog_cls.body
    if isinstance(item, ast.FunctionDef) and item.name == "export_header_csv"
)
src = ast.get_source_segment(text, node)


class _FakeItem:
    def __init__(self, text):
        self._text = text

    def text(self):
        return self._text


class _FakeTable:
    def __init__(self, rows):
        self._rows = rows

    def rowCount(self):
        return len(self._rows)

    def columnCount(self):
        return 6

    def item(self, r, c):
        value = self._rows[r][c]
        return _FakeItem(value) if value is not None else None


class _FakeTabs:
    def __init__(self, titles):
        self._titles = titles

    def tabText(self, i):
        return self._titles[i]


class _FakeFileDialog:
    saved_path = None

    @staticmethod
    def getSaveFileName(parent, title, default, filt):
        return (_FakeFileDialog.saved_path, filt)


class _FakeMessageBox:
    messages = []

    @staticmethod
    def information(parent, title, msg):
        _FakeMessageBox.messages.append(("info", msg))

    @staticmethod
    def critical(parent, title, msg):
        _FakeMessageBox.messages.append(("crit", msg))


namespace = {
    "csv": csv, "Path": Path,
    "QFileDialog": _FakeFileDialog, "QMessageBox": _FakeMessageBox,
}
exec(compile(src, "<extract>", "exec"), namespace)
export_header_csv = namespace["export_header_csv"]

tmpdir = tempfile.mkdtemp()

# --- Case 1: single-table DICOM tag dump -----------------------------
out_path = str(Path(tmpdir) / "dicom_header.csv")
_FakeFileDialog.saved_path = out_path
_FakeMessageBox.messages.clear()


class _FakeSelfSingle:
    source_path = Path("13-1.img")
    tables = [_FakeTable([
        ("(0010,0010)", "PatientName", "Patient Name", "PN", "1", "TEST^PATIENT"),
        ("(0028,0010)", "Rows", "Rows", "US", "1", "256"),
    ])]


export_header_csv(_FakeSelfSingle())
content = Path(out_path).read_text(encoding="utf-8-sig")
lines = content.strip().splitlines()
assert lines[0] == "Tag,Keyword,Name,VR,VM,Value", lines[0]
assert len(lines) == 3, lines
assert "PatientName" in lines[1]
assert any(m[0] == "info" for m in _FakeMessageBox.messages)
print("Commit0157 single-table (DICOM) export: no Section column, "
      "correct header + rows, success message shown: PASS")

# --- Case 2: multi-tab virtual RAW header -----------------------------
out_path2 = str(Path(tmpdir) / "raw_header.csv")
_FakeFileDialog.saved_path = out_path2
_FakeMessageBox.messages.clear()


class _FakeSelfMulti:
    source_path = Path("5-1-0-0.raw")
    tables = [
        _FakeTable([("(VIRT,0001)", "protocol_name", "Protocol / Series", "UT", "1", "TMAP-ME")]),
        _FakeTable([("(VIRT,0001)", "scan_plane", "Scan Plane", "UT", "1", "AXIAL")]),
    ]
    tabs = _FakeTabs(["Acquisition", "Geometry"])


export_header_csv(_FakeSelfMulti())
content2 = Path(out_path2).read_text(encoding="utf-8-sig")
lines2 = content2.strip().splitlines()
assert lines2[0] == "Section,Tag,Keyword,Name,VR,VM,Value", lines2[0]
assert lines2[1].startswith("Acquisition,"), lines2[1]
assert lines2[2].startswith("Geometry,"), lines2[2]
print("Commit0157 multi-tab (virtual RAW header) export: Section column "
      "prepended with each row's tab title: PASS")

# --- Case 3: no path chosen (dialog canceled) -> no file written, no crash
_FakeFileDialog.saved_path = ""
_FakeMessageBox.messages.clear()
export_header_csv(_FakeSelfSingle())
assert _FakeMessageBox.messages == [], "canceling the save dialog must not show any message"
print("Commit0157 canceling the save dialog does nothing (no crash, no message): PASS")

# --- Case 4: default filename derived from source_path, and .csv is
# enforced even if the user typed something else ------------------------
out_path3 = str(Path(tmpdir) / "no_extension")
_FakeFileDialog.saved_path = out_path3
_FakeMessageBox.messages.clear()
export_header_csv(_FakeSelfSingle())
assert Path(out_path3 + ".csv").exists(), "a .csv extension must be enforced"
print("Commit0157 a missing .csv extension is added automatically: PASS")

print("Commit0157 Export Header CSV functional checks: PASS")
