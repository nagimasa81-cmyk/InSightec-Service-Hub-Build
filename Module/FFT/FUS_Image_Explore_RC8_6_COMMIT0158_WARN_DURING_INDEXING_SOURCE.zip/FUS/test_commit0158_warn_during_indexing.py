"""Commit0158 regression test: warn before running Quick Spike Detect or
Correlation while RAW virtual-header indexing is still in progress.

User-reported (repeated, "やはり..." after Commit0156): after a ZIP
drop, running Quick Spike Detect / Correlation ("time かけて完了して") and
then opening the results shows no data ("データはない"). Investigation:
both buttons are enabled the whole time by design (Commit0145,
self.virtual_headers_ready is set True immediately and cannot be used to
tell whether background indexing has actually finished). A RAW file's
category classification -- which the MRI-only eligibility filter
(Commit0148) depends on -- can come back incomplete for files the
background indexing has not reached yet in some import timings, so
running the analysis too early can silently produce few or no eligible
images after a real wait, with nothing explaining why.

Fix: a new, accurate `self._virtual_header_indexing_in_progress` flag
(set True when the background thread starts, False only when it
actually completes -- unlike `virtual_headers_ready`, which is
Commit0145's "buttons stay enabled" flag and is not a completion
signal). `quick_spike_detect_prototype`/`run_relation_analysis` now call
a shared `_confirm_proceed_despite_indexing(action_name)` helper first;
if indexing is still running, it asks the user (Yes/No) whether to
proceed anyway, showing how many files are indexed so far. Answering No
cancels the action with no analysis run; answering Yes (or indexing
already being finished) proceeds exactly as before.

Runs entirely without PySide6/pydicom.
"""
from pathlib import Path

text = Path("app.py").read_text(encoding="utf-8")

for marker in (
    "self._virtual_header_indexing_in_progress = False",
    "self._virtual_header_indexing_in_progress = True",
    "self._virtual_header_indexing_in_progress = False\n        self.statusBar().showMessage(f\"Virtual Headers Ready:",
    "def _confirm_proceed_despite_indexing(self, action_name: str) -> bool:",
    'if not self._confirm_proceed_despite_indexing("Quick Spike Detect"):',
    'if not self._confirm_proceed_despite_indexing("Correlation"):',
):
    assert marker in text, marker[:70]
print("Commit0158 static markers: PASS")

# The confirm helper must be called before quick_spike_detect_prototype /
# run_relation_analysis do anything else that could run a real analysis.
qs_start = text.index("    def quick_spike_detect_prototype(self):")
qs_end = text.index("\n    def _confirm_proceed_despite_indexing", qs_start)
qs_body = text[qs_start:qs_end]
confirm_pos = qs_body.index("_confirm_proceed_despite_indexing")
detect_raw_pos = qs_body.index("_quick_spike_detect_raw(raw_paths)")
detect_dicom_pos = qs_body.index("_quick_spike_detect_dicom(indices)")
assert confirm_pos < detect_raw_pos < detect_dicom_pos, (
    "the indexing confirmation must happen before any real analysis dispatch"
)
print("Commit0158 quick_spike_detect_prototype confirms before dispatching "
      "to either the RAW or DICOM analysis path: PASS")

rel_start = text.index("    def run_relation_analysis(self):")
rel_end = text.index("\n    def _view_last_correlation_results", rel_start) if "_view_last_correlation_results" in text[rel_start:rel_start+3000] else rel_start + 2000
rel_body = text[rel_start:rel_start + 1500]
assert "_confirm_proceed_despite_indexing" in rel_body
print("Commit0158 run_relation_analysis also confirms before proceeding: PASS")

# --- functional: _confirm_proceed_despite_indexing itself -----------------
import ast  # noqa: E402

tree = ast.parse(text)
main_window = next(
    n for n in ast.walk(tree) if isinstance(n, ast.ClassDef) and n.name == "MainWindow"
)
node = next(
    item for item in main_window.body
    if isinstance(item, ast.FunctionDef) and item.name == "_confirm_proceed_despite_indexing"
)
src = ast.get_source_segment(text, node)


class _FakeMessageBox:
    Yes = 1
    No = 0
    next_answer = 0
    calls = []

    @staticmethod
    def question(parent, title, message, buttons, default):
        _FakeMessageBox.calls.append((title, message))
        return _FakeMessageBox.next_answer


namespace = {"QMessageBox": _FakeMessageBox}
exec(compile(src, "<extract>", "exec"), namespace)
confirm = namespace["_confirm_proceed_despite_indexing"]


class _Fake:
    raw_virtual_header_cache = {}


fake = _Fake()

# Indexing not in progress: proceeds without ever asking.
fake._virtual_header_indexing_in_progress = False
_FakeMessageBox.calls.clear()
assert confirm(fake, "Quick Spike Detect") is True
assert _FakeMessageBox.calls == [], "must not ask anything when indexing is not running"
print("Commit0158 proceeds silently when indexing is not in progress: PASS")

# Indexing in progress, user says No: action is canceled.
fake._virtual_header_indexing_in_progress = True
fake._virtual_header_indexing_total = 500
fake.raw_virtual_header_cache = {f"k{i}": {} for i in range(120)}
_FakeMessageBox.next_answer = 0
_FakeMessageBox.calls.clear()
assert confirm(fake, "Quick Spike Detect") is False
assert len(_FakeMessageBox.calls) == 1
assert "120" in _FakeMessageBox.calls[0][1] and "500" in _FakeMessageBox.calls[0][1]
print("Commit0158 asks (showing N/total indexed) and returns False on No: PASS")

# Indexing in progress, user says Yes: action proceeds.
_FakeMessageBox.next_answer = 1
_FakeMessageBox.calls.clear()
assert confirm(fake, "Correlation") is True
assert len(_FakeMessageBox.calls) == 1
print("Commit0158 returns True on Yes, letting the action proceed anyway: PASS")

print("Commit0158 indexing-in-progress warning functional checks: PASS")
