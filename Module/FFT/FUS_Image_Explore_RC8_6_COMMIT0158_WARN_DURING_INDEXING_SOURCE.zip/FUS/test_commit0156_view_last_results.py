"""Commit0156 regression test: Quick Spike Detect and Correlation results
can be reviewed again later without re-running the analysis.

User-reported: after running Quick Spike Detect or Correlation on a set
of images (either right after a ZIP import, or manually), the only way
to see those results was the moment the results dialog first appeared;
closing it (e.g. to go select a single image in Image Workspace) left no
way back to the same results short of re-running the entire analysis
from scratch, even though the underlying data
(self.quick_spike_correlation_records/summary,
self.relation_records/summary) was still sitting in memory the whole
time.

Fix: two new buttons, "View Last Spike Results" and
"View Last Correlation", disabled until a corresponding analysis has
completed at least once, that simply re-open the same results dialog
with the already-computed data -- no re-analysis. Both are disabled
again by "Clear All Images", since previously-computed results may
reference images that no longer exist after a full clear.

Runs entirely without PySide6/pydicom.
"""
from pathlib import Path

text = Path("app.py").read_text(encoding="utf-8")

for marker in (
    'self.view_quick_spike_results_button = QPushButton("View Last Spike Results")',
    "self.view_quick_spike_results_button.setEnabled(False)",
    "self.view_quick_spike_results_button.clicked.connect(self._view_last_quick_spike_results)",
    'self.view_correlation_results_button = QPushButton("View Last Correlation")',
    "self.view_correlation_results_button.setEnabled(False)",
    "self.view_correlation_results_button.clicked.connect(self._view_last_correlation_results)",
    "def _view_last_quick_spike_results(self):",
    "def _view_last_correlation_results(self):",
    "self.view_quick_spike_results_button.setEnabled(True)",
    "self.view_correlation_results_button.setEnabled(True)",
):
    assert text.count(marker) >= 1, marker[:70]
print("Commit0156 static markers: PASS")

# Both new buttons must actually be added to the toolbar layout, not just
# constructed.
toolbar_loop_start = text.index("for button in (\n            self.previous_import_button,")
toolbar_loop_end = text.index("):\n            global_toolbar_layout.addWidget(button)", toolbar_loop_start)
toolbar_loop = text[toolbar_loop_start:toolbar_loop_end]
assert "self.view_quick_spike_results_button" in toolbar_loop
assert "self.view_correlation_results_button" in toolbar_loop
print("Commit0156 both new buttons are added to the toolbar layout: PASS")

# clear_all_images must disable both buttons and drop the stale results,
# since they may reference images that no longer exist after a full
# clear.
clear_start = text.index("    def clear_all_images(self):")
clear_end = text.index("\n    def _reset_image_state", clear_start)
clear_body = text[clear_start:clear_end]
for marker in (
    "self.quick_spike_correlation_records = None",
    "self.quick_spike_correlation_summary = None",
    "self.relation_records = None",
    "self.relation_summary = None",
    "self.view_quick_spike_results_button.setEnabled(False)",
    "self.view_correlation_results_button.setEnabled(False)",
):
    assert marker in clear_body, marker
print("Commit0156 Clear All Images disables both View Last buttons and "
      "drops the now-stale stored results: PASS")


# --- functional: _view_last_quick_spike_results / _view_last_correlation_results
class _FakeButton:
    def __init__(self):
        self.enabled = True

    def setEnabled(self, value):
        self.enabled = bool(value)


class _FakeMessageBox:
    informed = []

    @staticmethod
    def information(parent, title, message):
        _FakeMessageBox.informed.append((title, message))


import ast  # noqa: E402

tree = ast.parse(text)
main_window = next(
    n for n in ast.walk(tree) if isinstance(n, ast.ClassDef) and n.name == "MainWindow"
)
found = {}
for item in main_window.body:
    if isinstance(item, ast.FunctionDef) and item.name in (
        "_view_last_quick_spike_results", "_view_last_correlation_results",
    ):
        found[item.name] = ast.get_source_segment(text, item)
assert {"_view_last_quick_spike_results", "_view_last_correlation_results"} <= found.keys()

namespace = {"QMessageBox": _FakeMessageBox}
exec(compile("\n\n".join(found.values()), "<extract>", "exec"), namespace)


class _Fake:
    quick_spike_correlation_records = None
    quick_spike_correlation_summary = None
    relation_records = None
    relation_summary = None

    def __init__(self):
        self.shown = []

    def _show_quick_spike_correlation_dialog(self, records, summary):
        self.shown.append(("quick_spike", records, summary))

    def _show_relation_dialog(self, records, summary):
        self.shown.append(("relation", records, summary))

    _view_last_quick_spike_results = namespace["_view_last_quick_spike_results"]
    _view_last_correlation_results = namespace["_view_last_correlation_results"]


fake = _Fake()

# No results yet: must inform, not raise, and not show anything.
_FakeMessageBox.informed.clear()
fake._view_last_quick_spike_results()
assert len(_FakeMessageBox.informed) == 1
assert fake.shown == []
fake._view_last_correlation_results()
assert len(_FakeMessageBox.informed) == 2
assert fake.shown == []
print("Commit0156 View Last buttons inform (not crash) when no results exist yet: PASS")

# Results exist: must re-open the dialog with the stored data, no
# re-analysis performed.
fake.quick_spike_correlation_records = [{"index": 1}]
fake.quick_spike_correlation_summary = {"spike": 1}
fake._view_last_quick_spike_results()
assert fake.shown[-1] == ("quick_spike", [{"index": 1}], {"spike": 1})

fake.relation_records = [{"index": 2}]
fake.relation_summary = {"total": 1}
fake._view_last_correlation_results()
assert fake.shown[-1] == ("relation", [{"index": 2}], {"total": 1})
print("Commit0156 View Last buttons re-open the dialog with the stored "
      "results, without re-running the analysis: PASS")

print("Commit0156 view-last-results functional checks: PASS")
