"""Commit0155 regression test: Cancel actually works for load_raw_file's
extended-fallback decode (load_raw_file_auto), which Commit0153 already
moved to a background thread.

User-reported (with a screenshot): the "Analyzing RAW Data" progress
panel's Cancel button showed "Canceling..." and stayed stuck that way --
the user had to wait for the (slow, brute-force offset/dtype/matrix-shape
search) decode to finish anyway.

Root cause: `ServiceProgressDialog._cancel()` only sets a `_canceled`
flag and relabels the button; nothing in Commit0153's background-thread
code ever checked that flag (load_raw_file_auto is a single call, not a
loop this code can interrupt mid-way -- there is no way to truly abort it
partway through). Fixed by connecting the panel's `canceled` signal to a
handler that (1) hides the panel immediately, giving instant feedback,
and (2) bumps the same request-id counter Commit0153 already introduced
for discarding a stale result, so whenever the background decode does
eventually finish, its result is silently thrown away instead of
overwriting the display -- the same mechanism already used when the user
picks a different file while a fallback decode is still running.

Runs entirely without PySide6/pydicom.
"""
from pathlib import Path

text = Path("app.py").read_text(encoding="utf-8")

for marker in (
    "def on_cancel_clicked():",
    "self._raw_load_request_id += 1",
    "progress.canceled.connect(on_cancel_clicked)",
    "progress.canceled.disconnect(on_cancel_clicked)",
):
    assert marker in text, marker
print("Commit0155 static markers: PASS")

# on_cancel_clicked and the connect/disconnect calls must all live inside
# load_raw_file's body (not some unrelated function), and the
# disconnect(before-connecting) / connect / (finish-time) disconnect
# sequence must appear in that relative order.
start = text.index("    def load_raw_file(self, path: Path):")
end = text.index("\n    def load_bitmap_image", start)
body = text[start:end]
for marker in (
    "def on_cancel_clicked():",
    "progress.canceled.connect(on_cancel_clicked)",
    "def finish(payload):",
    "progress.canceled.disconnect(on_cancel_clicked)",
):
    assert marker in body, marker
cancel_def_pos = body.index("def on_cancel_clicked():")
connect_pos = body.index("progress.canceled.connect(on_cancel_clicked)")
finish_def_pos = body.index("def finish(payload):")
disconnect_pos = body.index("progress.canceled.disconnect(on_cancel_clicked)")
assert cancel_def_pos < connect_pos < finish_def_pos < disconnect_pos, (
    "on_cancel_clicked must be defined and connected before finish() is "
    "defined, and finish() must disconnect it"
)
print("Commit0155 cancel handler wiring is inside load_raw_file, in the "
      "correct order (define -> connect -> finish defines -> disconnect): PASS")

# The handler must hide the progress panel immediately (not merely record
# a flag), giving the user instant feedback rather than a stuck "Canceling..."
# state.
cancel_handler_start = body.index("def on_cancel_clicked():")
cancel_handler_end = body.index("\n\n", cancel_handler_start)
cancel_handler_body = body[cancel_handler_start:cancel_handler_end]
assert "progress.hide()" in cancel_handler_body
print("Commit0155 clicking Cancel hides the progress panel immediately: PASS")

print("Commit0155 working Cancel for background RAW fallback decode functional checks: PASS")
