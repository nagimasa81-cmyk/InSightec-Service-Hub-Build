"""Commit0154 regression test: "Tracker Signal" and "1D Signal Studio"
tabs hidden for now, per request.

Uses `QTabWidget.setTabVisible(index, False)` rather than removing the
tabs or skipping their `addTab` calls, so tab indices 3 and 4 stay
exactly as they were. Several other places in the code still reference
`self.tabs.setCurrentIndex(3)`/`(4)` for tracker/1D-signal
auto-navigation on import (e.g. after dropping a tracker PFile); removing
the tabs outright would shift every later index and silently break that
navigation. Restoring visibility later is just deleting the two
`setTabVisible(..., False)` lines.

Runs entirely without PySide6/pydicom (checks source text only, since
`QTabWidget.setTabVisible`'s actual effect cannot be exercised without a
real Qt widget in this environment).
"""
from pathlib import Path

text = Path("app.py").read_text(encoding="utf-8")

for marker in (
    'self.tabs.addTab(self._build_workspace(), "Image Workspace")',
    'self.tabs.addTab(self._build_spike_results(), "Spike Diag")',
    'self.tabs.addTab(self._build_artifact_diag(), "Artifact Diag")',
    'self.tabs.addTab(self._build_tracker_signal_combined(), "Tracker Signal")',
    'self.tabs.addTab(self._build_signal_studio(), "1D Signal Studio")',
    "self.tabs.setTabVisible(3, False)",
    "self.tabs.setTabVisible(4, False)",
):
    assert marker in text, marker
print("Commit0154 static markers: PASS")

# The addTab calls (which establish indices 0-4) must all appear *before*
# the setTabVisible calls, and in the exact order that makes index 3 the
# Tracker Signal tab and index 4 the 1D Signal Studio tab.
tracker_pos = text.index('self.tabs.addTab(self._build_tracker_signal_combined(), "Tracker Signal")')
signal_studio_pos = text.index('self.tabs.addTab(self._build_signal_studio(), "1D Signal Studio")')
hide_tracker_pos = text.index("self.tabs.setTabVisible(3, False)")
hide_signal_studio_pos = text.index("self.tabs.setTabVisible(4, False)")
workspace_pos = text.index('self.tabs.addTab(self._build_workspace(), "Image Workspace")')
spike_pos = text.index('self.tabs.addTab(self._build_spike_results(), "Spike Diag")')
artifact_pos = text.index('self.tabs.addTab(self._build_artifact_diag(), "Artifact Diag")')

assert workspace_pos < spike_pos < artifact_pos < tracker_pos < signal_studio_pos, (
    "tab construction order must place Tracker Signal at index 3 and "
    "1D Signal Studio at index 4"
)
assert tracker_pos < hide_tracker_pos, "Tracker Signal must be added before it is hidden"
assert signal_studio_pos < hide_signal_studio_pos, "1D Signal Studio must be added before it is hidden"
print("Commit0154 tab order confirms index 3 = Tracker Signal, "
      "index 4 = 1D Signal Studio, both hidden after being added: PASS")

# Other code still navigates to indices 3/4 (tracker/1D signal
# auto-navigation); this must remain unchanged so those code paths keep
# working once the tabs are made visible again.
assert text.count("self.tabs.setCurrentIndex(3)") >= 1
assert text.count("self.tabs.setCurrentIndex(4)") >= 1
print("Commit0154 existing setCurrentIndex(3)/(4) navigation call sites "
      "are unaffected (indices were not removed/shifted): PASS")

print("Commit0154 hide Tracker Signal / 1D Signal Studio functional checks: PASS")
