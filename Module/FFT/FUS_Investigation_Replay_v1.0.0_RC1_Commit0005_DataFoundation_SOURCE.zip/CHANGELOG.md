# Changelog

## v1.0.0-RC1 — Commit0005_DataFoundation

- Added complete ZIP inventory.
- Added Data Coverage dashboard.
- Added RAW Investigation candidate preview.
- Added XML row extraction and Sonication metadata integration.
- Added explicit DQA classification from treatment protocol metadata.
- Added scan-normal based Axial/Sagittal/Coronal classification when available.
- Preserved all previous replay, mapping, Spectrum, timing, review.out and example-image features.
