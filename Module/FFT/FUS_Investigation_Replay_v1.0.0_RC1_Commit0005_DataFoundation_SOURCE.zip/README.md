# FUS Investigation & Treatment Replay Workstation — RC1

GitHub Actions compatible `*_SOURCE.zip` for the supplied RC1 Runtime Complete workflow.

## RC1 scope

- Treatment ZIP direct import
- Complete ZIP file inventory with signature, size, category and Sonication association
- Sonication master table
- XML metadata extraction from SonicationData / SonicationSummary / MriImageParams / ImageDataItem
- Explicit DQA protocol classification when available
- DQA / Treatment manual override
- Per-Sonication Axial / Sagittal / Coronal replay-plane mapping
- Oblique acquisitions classified to the nearest of the three basic planes
- Per-Sonication frequency-direction mapping
- review.out MR-series extraction
- mrserver and WS timing-evidence views
- MR–FUS explicit offset evidence handling
- DQA phantom and Treatment T2 example images for all three planes
- External DICOM/MR folder mapping
- RAW inventory and experimental candidate-image preview
- Data Coverage / Reconstruction Status dashboard
- Relative Spectrum preview and Sonication matching
- Evidence-oriented displays that distinguish confirmed, partial and experimental results

## Important limitations

- Proprietary RAW semantic roles (magnitude, phase, temperature, dose, mask) are not yet confirmed.
- Spectrum physical frequency calibration and Hydrophone channel identification are not yet confirmed.
- Cavitation trend and hotspot overlays remain simulations unless verified source data is decoded.
- Example MR and phantom images are synthetic placeholders and are clearly labeled.
- This application is for investigation, research and training prototyping only. It is not for clinical decisions.

## Build with the supplied YML

Place this ZIP under one of the module folders listed by the workflow. Until a dedicated FUS option is added to the YML, use:

```text
Module/FFT/FUS_Investigation_Replay_v1.0.0_RC1_Commit0005_DataFoundation_SOURCE.zip
```

Run **Build Selected Module RC1 Runtime Complete R3** with:

```text
module_name: FFT
build_engine: auto
```

The workflow reads `version.json`, installs `requirements.txt`, detects `app.py`, and builds the onedir PyInstaller package.
