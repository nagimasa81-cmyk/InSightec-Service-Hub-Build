# Changelog

## v1.1.0-RC1 — Commit0006_MultiHydrophone

- Added experimental `SpectrumMsg-*.dmp` discovery and per-sonication linking.
- Added candidate decoding for 4–8 acoustic channels without claiming verified hydrophone identity.
- Added Spectrum display modes: Single, All Overlay, All Separate, Average, Maximum Envelope, and Spectrogram.
- Added Hydrophone 1–8 selection. Until the channel map is verified, labels should be interpreted as candidate channels.
- Replaced the previous simulated cavitation plot. The Cavitation tab now shows experimental time-resolved acoustic activity only when a payload can be decoded; otherwise it shows unavailable.
- Added source, data type, byte offset, channel count, and calibration warnings to Spectrum notes.
- Added horizontal and vertical pixel scrolling to the Sonication list.
- Added a selected-Sonication detail panel directly below the left-side list.
- Preserved all RC1 Data Foundation, RAW Investigation, MR mapping, DQA/Treatment, inventory, and evidence functionality.
