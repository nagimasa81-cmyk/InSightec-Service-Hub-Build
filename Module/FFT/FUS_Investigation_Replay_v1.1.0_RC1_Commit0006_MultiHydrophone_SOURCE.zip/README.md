# FUS Investigation & Treatment Replay Workstation — RC1.1

Review/research software for exploring FUS treatment ZIP packages. It is not a clinical device and must not be used for treatment decisions.

## RC1.1 focus

This release adds multi-hydrophone acoustic review. `SpectrumMsg-*.dmp` files are linked to each Sonication and investigated as possible 4–8 channel time-resolved payloads.

Available Spectrum modes:

- Single channel
- All Overlay
- All Separate
- Average
- Maximum Envelope
- Spectrogram

The current decoder is experimental. It does **not** yet verify:

- physical Hydrophone ID mapping,
- FUS-selected Hydrophone,
- sampling interval,
- Hz/MHz calibration,
- validated cavitation-dose calculation,
- exact Pre/During/Post boundaries inside the proprietary payload.

The prior simulated Hydrophone Cavitation graph has been removed. Only decoded payload-derived relative acoustic activity is shown.

## Build

Place this `*_SOURCE.zip` in the selected Module folder and run the supplied RC1 Runtime Complete GitHub Actions YML.

- Entry point: `app.py`
- Python: 3.13
- Preferred engine: `fast_pyinstaller`
- Dependencies: PySide6, matplotlib, numpy, pydicom

## Basic use

1. Open a treatment ZIP.
2. Select a Sonication in the scrollable left list.
3. Review the selected-Sonication details below the list.
4. Open **Spectrum** and select a candidate Hydrophone and display mode.
5. Open **Hydrophone Cavitation** to inspect relative time-resolved acoustic activity when a `SpectrumMsg` payload is decoded.
6. Use **Complete Inventory**, **RAW Investigation**, and **Evidence** to verify source files and confidence.
