import sys, re, gzip, zipfile, struct, math, json, tempfile, shutil, hashlib, os
from pathlib import Path
from dataclasses import dataclass, asdict, field as dc_field
from datetime import datetime
import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QTableWidget,QTableWidgetItem,
    QPushButton,QFileDialog,QLabel,QSplitter,QTabWidget,QHeaderView,QMessageBox,QComboBox,QFormLayout,
    QGroupBox,QTextEdit,QCheckBox,QSpinBox,QDoubleSpinBox,QScrollArea,QSlider,QProgressDialog
)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as Canvas
from matplotlib.figure import Figure

@dataclass
class Sonication:
    no:int; time:str; x:float; y:float; roll:float; pitch:float; elevation:float
    fd:float; mode:int; duration:float; power:float; freq:float; max_power:float; avg_power:float; status:str


@dataclass
class InventoryItem:
    path:str; size:int; ext:str; category:str; sonication:str=''; signature:str=''; candidate:str=''; status:str='Inventory only'

def classify_inventory_path(name):
    low=name.lower(); ext=Path(name).suffix.lower() or '(none)'
    son=''
    m=re.search(r'sonication[_\\/ ]?(\d+)',low)
    if m: son=m.group(1)
    if low.endswith('/'):
        return 'Folder',son
    if ext in ('.xml',): return 'XML metadata',son
    if Path(name).name.lower() in ('review.out','review.out.ar'): return 'MR review report',son
    if 'mrserver' in low: return 'MR server log',son
    if 'spectrummsg' in low: return 'Spectrum message',son
    if 'spectrum' in low and ('fft' in low or ext in ('.dmp','.bin')): return 'Spectrum / FFT',son
    if 'reflection' in low: return 'Reflection',son
    if ext=='.raw': return 'MR / Thermometry RAW',son
    if 'skullheating' in low: return 'Skull heating',son
    if 'skullmeasure' in low: return 'Skull measures',son
    if 'bonespot' in low: return 'Bone spot data',son
    if any(k in low for k in ('wsfiles/','watersystem','gesys','cga','csa')): return 'System log',son
    if ext in ('.log','.txt','.out'): return 'Text log',son
    if ext in ('.dcm','.ima'): return 'DICOM / MR image',son
    if ext in ('.png','.jpg','.jpeg','.bmp','.tif','.tiff'): return 'Image',son
    return 'Other',son

def binary_signature(blob):
    h=blob[:16]
    if h.startswith(b'PK\x03\x04'): return 'ZIP'
    if h.startswith(b'\x1f\x8b'): return 'GZIP'
    if h.startswith(b'<?xml'): return 'XML'
    if len(blob)>132 and blob[128:132]==b'DICM': return 'DICOM'
    printable=sum(32<=b<127 or b in (9,10,13) for b in blob[:1024])
    if blob and printable/max(1,min(len(blob),1024))>.85: return 'Text-like'
    return h.hex(' ')

def raw_candidates(size):
    out=[]
    for bpp,dtype in ((2,'int16/uint16'),(4,'float32')):
        if size%bpp: continue
        pixels=size//bpp
        side=int(round(math.sqrt(pixels)))
        if side*side==pixels: out.append(f'{side}x{side} {dtype}')
        for w in (128,192,256,320,384,448,512,640,768,1024):
            if pixels%w==0:
                h=pixels//w
                if 64<=h<=2048 and abs(w-h)<=512:
                    cand=f'{w}x{h} {dtype}'
                    if cand not in out: out.append(cand)
    return '; '.join(out[:6]) or 'Unknown binary layout'

def make_inventory(zf):
    items=[]
    for info in zf.infolist():
        cat,son=classify_inventory_path(info.filename)
        sig=''; cand=''
        if not info.is_dir():
            try:
                blob=zf.read(info.filename)[:4096]
                sig=binary_signature(blob)
            except Exception: sig='Unreadable'
        if cat=='MR / Thermometry RAW': cand=raw_candidates(info.file_size)
        elif cat in ('Spectrum message','Spectrum / FFT','Reflection'): cand='Binary structure pending decoder'
        items.append(InventoryItem(info.filename,info.file_size,Path(info.filename).suffix.lower(),cat,son,sig,cand))
    return items

def try_render_raw(blob):
    candidates=[]
    for dt in ('<u2','<i2','<f4'):
        try:
            arr=np.frombuffer(blob,dtype=dt)
        except Exception: continue
        if arr.size<4096: continue
        for w in (128,192,256,320,384,448,512,640,768,1024):
            if arr.size%w: continue
            h=arr.size//w
            if not (64<=h<=2048): continue
            a=arr.reshape(h,w).astype(float)
            finite=np.isfinite(a)
            if finite.mean()<.98: continue
            p1,p99=np.percentile(a[finite],[1,99])
            if p99<=p1: continue
            norm=np.clip((a-p1)/(p99-p1),0,1)
            # Image-likeness: adjacent-pixel correlation and dynamic range.
            corrx=np.corrcoef(norm[:,:-1].ravel(),norm[:,1:].ravel())[0,1] if w>2 else 0
            corry=np.corrcoef(norm[:-1,:].ravel(),norm[1:,:].ravel())[0,1] if h>2 else 0
            score=np.nan_to_num((corrx+corry)/2) - .0001*abs(w-h)
            candidates.append((float(score),dt,w,h,norm))
    return max(candidates,key=lambda x:x[0]) if candidates else None

@dataclass
class MRSeries:
    date:str=''; time:str=''; protocol:str=''; description:str=''; plane:str='Unknown'; freq_dir:str='Unknown'
    image_mode:str=''; pulse_sequence:str=''; psd_name:str=''; coil:str=''; fov:str=''; thickness:str=''
    slices:str=''; matrix:str=''; start_loc:str=''; end_loc:str=''; center_fov:str=''; source:str='review.out'

ROW_RE=re.compile(r"^\s*(\d+)\s*\|\s*([\d:]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*(\d+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*(\w+)")

PLANE_OPTIONS=['Unknown','Axial','Sagittal','Coronal']
FREQ_OPTIONS=['Unknown','R/L','L/R','A/P','P/A','S/I','I/S']
PHASE_OPTIONS=['Auto','DQA','Treatment']
SPECTRUM_INTERVALS=['During Sonication','Pre-sonication','Post-sonication','Full Acquisition']
SPECTRUM_Y=['Amplitude','dB']
SPECTRUM_DISPLAY=['Single','All Overlay','All Separate','Average','Maximum Envelope','Spectrogram']



def resource_path(relative):
    base=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
    return base / relative

def normalize_plane(raw, evidence=''):
    """Map source geometry to the nearest replay plane while keeping raw evidence separately.
    Oblique acquisitions are represented as Axial/Sagittal/Coronal in the replay UI.
    """
    text=f'{raw} {evidence}'.lower()
    if 'sag' in text: return 'Sagittal'
    if 'cor' in text: return 'Coronal'
    if 'axi' in text or 'trans' in text: return 'Axial'
    if '3-plane' in text or '3 plane' in text: return 'Axial'
    if 'oblique' in text:
        # A generic OBLIQUE record has no reliable normal-vector in the parsed text.
        # Use Axial only as a visible fallback; the user can correct each sonication.
        return 'Axial'
    return 'Unknown'

def parse_summary(text):
    out=[]
    for line in text.replace('\r','').splitlines():
        m=ROW_RE.match(line)
        if m:
            g=m.groups(); out.append(Sonication(int(g[0]),g[1],*map(float,g[2:8]),int(g[8]),*map(float,g[9:14]),g[14]))
    return out

def time_seconds(s):
    try:
        h,m,sec=map(int,s.split(':')); return h*3600+m*60+sec
    except Exception:return 0

def spectrum_time(name):
    m=re.search(r'_(\d\d)_(\d\d)_(\d\d)_\d{4}',name)
    return int(m.group(1))*3600+int(m.group(2))*60+int(m.group(3)) if m else None

def decode_spectrum(blob):
    try: raw=gzip.decompress(blob)
    except Exception: raw=blob
    vals=[]
    for off in range(32, min(len(raw)-8, 700000), 8):
        try:v=struct.unpack_from('<d',raw,off)[0]
        except Exception:continue
        if math.isfinite(v) and 1e-10 < abs(v) < 1e7: vals.append(abs(v))
    if len(vals)<128:
        a=np.frombuffer(raw[:len(raw)//4*4],dtype='<f4').astype(float)
        a=a[np.isfinite(a) & (np.abs(a)<1e7)]; vals=np.abs(a).tolist()
    a=np.asarray(vals[:150000],float)
    if a.size<64:return None,None
    n=min(4096,max(512,a.size)); idx=np.linspace(0,a.size-1,n).astype(int); y=a[idx]
    floor=max(np.percentile(y,5),1e-12); y=np.log10(y+floor); y-=np.nanmin(y)
    if np.nanmax(y)>0:y/=np.nanmax(y)
    return np.linspace(0,1,n),y


def decode_spectrum_channels(blob, expected_channels=None):
    """Experimental, bounded-cost candidate decoder for proprietary SpectrumMsg payloads."""
    try: raw=gzip.decompress(blob)
    except Exception: raw=blob
    candidates=[]
    channel_options=[]
    if expected_channels: channel_options.append(expected_channels)
    channel_options += [4,5,6,7,8]
    for dt in ('<f4','<f8','<i2','<u2'):
        item=np.dtype(dt).itemsize
        offsets=list(range(0,min(128,len(raw)),max(item,8)))
        for off in offsets:
            usable=(len(raw)-off)//item*item
            if usable<item*1024: continue
            try:a=np.frombuffer(raw,offset=off,count=min(300000,usable//item),dtype=dt).astype(float)
            except Exception:continue
            finite=np.isfinite(a)
            if finite.mean()<.95:continue
            a=a[finite]
            if dt in ('<i2','<u2'): a=a-np.median(a)
            scale=np.percentile(np.abs(a),99.5)
            if not np.isfinite(scale) or scale<=0:continue
            a=np.clip(a/scale,-5,5)
            for ch in channel_options:
                if a.size<ch*128:continue
                n=(a.size//ch)*ch; b=a[:n].reshape(-1,ch).T
                sample=b[:,:min(10000,b.shape[1])]
                cors=[]
                for x in sample:
                    if x.size>3 and np.std(x)>1e-12:
                        cors.append(np.corrcoef(x[:-1],x[1:])[0,1])
                smooth=np.nanmean(cors) if cors else 0
                balance=np.std(np.std(sample,axis=1))/(np.mean(np.std(sample,axis=1))+1e-9)
                score=float(np.nan_to_num(smooth)-.08*np.nan_to_num(balance)-off/10000)
                candidates.append((score,dt,off,ch,b))
    if not candidates:return None
    score,dt,off,ch,b=max(candidates,key=lambda x:x[0])
    return {'channels':b,'count':ch,'dtype':dt,'offset':off,'score':score,'confidence':'Experimental'}

def channel_spectra_from_streams(streams, points=1024):
    out=[]
    for stream in streams:
        x=np.asarray(stream,float); x=x[np.isfinite(x)]
        if x.size<32: out.append((None,None)); continue
        x=x-np.mean(x)
        n=min(max(256,2**int(np.floor(np.log2(x.size)))),8192)
        x=x[:n]*np.hanning(n)
        y=np.abs(np.fft.rfft(x)); y=y/(np.max(y)+1e-12)
        f=np.linspace(0,1,len(y))
        if len(y)>points:
            idx=np.linspace(0,len(y)-1,points).astype(int); f=f[idx]; y=y[idx]
        out.append((f,y))
    return out

def field(block,label):
    m=re.search(rf'{re.escape(label)}\s*:\s*([^\t\r\n]+)',block,re.I)
    return m.group(1).strip() if m else ''

def parse_review(text):
    blocks=re.split(r'\n-{20,}\n',text.replace('\r',''))
    out=[]
    for b in blocks:
        if 'IMAGING PARAMETERS SCREEN' not in b: continue
        raw_plane=field(b,'Scan Plane') or 'Unknown'
        plane=normalize_plane(raw_plane,b)
        freq=field(b,'Freq. Dir') or 'Unknown'
        slices=field(b,'# Slices')
        if not slices:
            vals=[]
            for p in ('Axial','Sagittal','Coronal'):
                v=field(b,f'# Slices in {p} Plane')
                if v: vals.append(f'{p}:{v}')
            slices=', '.join(vals)
        out.append(MRSeries(
            date=field(b,'date'), time=field(b,'time'), protocol=field(b,'Protocol'),
            description=field(b,'Series De'), plane=plane,
            freq_dir=freq, image_mode=field(b,'Image Mode'), pulse_sequence=field(b,'Pulse Seq'),
            psd_name=field(b,'Psd Name'), coil=field(b,'Coil Name'), fov=field(b,'Field of View'),
            thickness=field(b,'Slice Thickness'), slices=slices, matrix=field(b,'Acq. Matrix'),
            start_loc=field(b,'Start Loc'), end_loc=field(b,'End Loc'), center_fov=field(b,'Center of FOV')))
    return out



def parse_xml_rows(text):
    rows=[]
    for m in re.finditer(r'<[^>]*?:?row\s+([^>]+)/?>',text,re.I):
        attrs={k.lower():v for k,v in re.findall(r'(\w+)="([^"]*)"',m.group(1))}
        rows.append(attrs)
    return rows

def parse_sonication_metadata(zf,names):
    out={}
    for n in names:
        bn=Path(n).name.lower()
        if bn not in ('sonicationdata.xml','sonicationsummary.xml','mriimageparams.xml','imagedataitem.xml'): continue
        try:text=zf.read(n).decode('utf-8','ignore')
        except Exception:continue
        for a in parse_xml_rows(text):
            no=a.get('sonicationindex') or a.get('sonication')
            if not no or not str(no).isdigit():continue
            d=out.setdefault(str(int(no)),{'evidence':[]})
            d['evidence'].append(n)
            for key in ('treatprotocol','scanplane','protocol','actualduration','measuredpower','measuredenergy','maxmaxtemp','maxaveragetemp','frequency','scannormalx','scannormaly','scannormalz','freqdirection','seriesdiscription','imgmatrixx','imgmatrixy','pixsizex','pixsizey','slicethick','tempimagesnum','magimagesnum','tempimagestimes'):
                if key in a and a[key]!='': d[key]=a[key]
    for no,d in out.items():
        proto=' '.join(str(d.get(k,'')) for k in ('treatprotocol','protocol','seriesdiscription')).lower()
        if 'dqa' in proto:
            d['phase']='DQA'; d['phase_confidence']='High'; d['phase_reason']='Explicit DQA protocol in XML metadata'
        rawplane=d.get('scanplane') or d.get('seriesdiscription','')
        if rawplane:
            d['plane']=normalize_plane(rawplane)
        # A scan normal is the strongest orientation evidence.
        try:
            normal=[abs(float(d.get('scannormalx',0))),abs(float(d.get('scannormaly',0))),abs(float(d.get('scannormalz',0)))]
            if max(normal)>0:
                axis=int(np.argmax(normal)); d['plane']=['Sagittal','Coronal','Axial'][axis]; d['plane_reason']=f'Scan normal {normal}'
        except Exception:pass
    return out

def classify_session(sonics):
    """Conservative DQA/Treatment split. A long workflow gap is the strongest signal.
    Low-power/test-looking sonications before that gap are DQA. Without a clear transition,
    keep the complete short session as DQA and expose manual override.
    """
    if not sonics: return {}
    gaps=[]
    for i in range(1,len(sonics)):
        gaps.append((time_seconds(sonics[i].time)-time_seconds(sonics[i-1].time),i))
    transition=None
    if gaps:
        gap,idx=max(gaps)
        if gap>=15*60: transition=idx
    out={}
    for i,son in enumerate(sonics):
        if transition is not None:
            phase='DQA' if i<transition else 'Treatment'
            confidence='High' if max(gaps)[0]>=30*60 else 'Medium'
            reason=f'workflow time gap before Sonication {transition}' if i>=transition else f'pre-treatment group before {max(gaps)[0]/60:.1f} min gap'
        else:
            phase='DQA'
            confidence='Medium' if len(sonics)<=6 else 'Low'
            reason='short continuous test/phantom-like session; no reliable patient-treatment transition found'
        out[str(son.no)]={'phase':phase,'confidence':confidence,'reason':reason}
    return out

def scan_timing_evidence(text,name):
    rows=[]; offsets=[]
    keys=('sonication','thermo','temperature','acquisition','scan','offset','time difference','clock')
    for line in text.replace('\r','').splitlines():
        low=line.lower()
        if any(k in low for k in keys):
            if len(rows)<3000: rows.append(f'{name}: {line.strip()}')
            # Accept explicit MR/FUS offset statements only; preserve direction as evidence.
            m=re.search(r'(?:mr.{0,20}fus|fus.{0,20}mr|time\s*(?:difference|offset)|clock\s*offset)[^+\-\d]{0,30}([+\-]?\d+(?:\.\d+)?)\s*(ms|msec|s|sec)',line,re.I)
            if m:
                v=float(m.group(1)); unit=m.group(2).lower();
                if unit.startswith('m'): v/=1000.0
                offsets.append((v,f'{name}: {line.strip()}'))
    return rows,offsets

def parse_mrserver(text,name):
    events=[]
    for line in text.replace('\r','').splitlines():
        if any(k in line for k in ('LoadProtocol','SetRxGeometry3p','Series type =','scanner=scanning','acquisition=complete','recon=done','SetCVs=')):
            events.append(f'{name}: {line.strip()}')
    return events

class Plot(Canvas):
    def __init__(self):
        self.fig=Figure(figsize=(5,4),tight_layout=True); super().__init__(self.fig)

class Main(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle('FUS Treatment Replay & Evidence Review'); self.resize(1580,940)
        self.zf=None; self.zip_path=None; self.sonics=[]; self.spectrum_files=[]; self.spectrum_msg_files=[]; self.reflection_files=[]; self.inventory=[]; self.raw_files=[]
        self.spec_cache={}; self.mr_series=[]; self.mrserver_events=[]; self.timing_evidence=[]; self.ws_offsets=[]; self.auto_phase={}; self.son_meta={}; self.manual={}; self.external_images={}
        self._updating=False
        self.build_ui()

    def build_ui(self):
        w=QWidget(); self.setCentralWidget(w); lay=QVBoxLayout(w)
        top=QHBoxLayout(); lay.addLayout(top)
        b=QPushButton('Open Treatment ZIP'); b.clicked.connect(self.open_zip); top.addWidget(b)
        add=QPushButton('Add MR Images / DICOM Folder'); add.clicked.connect(self.add_mr_images); top.addWidget(add)
        save=QPushButton('Save Review Mapping'); save.clicked.connect(self.save_mapping); top.addWidget(save)
        self.info=QLabel('No data loaded'); top.addWidget(self.info,1)
        badge=QLabel('REVIEW / RESEARCH ONLY — NOT FOR CLINICAL DECISIONS'); badge.setStyleSheet('font-weight:bold;color:#b00020'); top.addWidget(badge)

        split=QSplitter(); lay.addWidget(split,1)
        left=QWidget(); ll=QVBoxLayout(left)
        self.table=QTableWidget(0,12); self.table.setHorizontalHeaderLabels(['No.','Phase','Confidence','Start','Duration','Power','Avg','Freq.','F.D.','Status','MR Plane','Freq Dir'])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); self.table.currentCellChanged.connect(self.select_row)
        self.table.setHorizontalScrollMode(QTableWidget.ScrollPerPixel); self.table.setVerticalScrollMode(QTableWidget.ScrollPerPixel)
        ll.addWidget(self.table,3)
        self.left_details=QTextEdit(); self.left_details.setReadOnly(True); self.left_details.setMinimumHeight(210)
        ll.addWidget(self.left_details,1)
        nav=QHBoxLayout(); ll.addLayout(nav)
        prev=QPushButton('◀ Previous'); prev.clicked.connect(lambda:self.move_row(-1)); nav.addWidget(prev)
        nxt=QPushButton('Next ▶'); nxt.clicked.connect(lambda:self.move_row(1)); nav.addWidget(nxt)
        split.addWidget(left)

        right=QWidget(); rl=QVBoxLayout(right)
        controls=QGroupBox('Selected Sonication — MR Geometry Mapping'); form=QGridLayout(controls)
        self.source_label=QLabel('Source: unavailable'); form.addWidget(self.source_label,0,0,1,4)
        form.addWidget(QLabel('DQA / Treatment'),1,0); self.phase_combo=QComboBox(); self.phase_combo.addItems(PHASE_OPTIONS); self.phase_combo.currentTextChanged.connect(self.phase_changed); form.addWidget(self.phase_combo,1,1)
        self.phase_evidence=QLabel(''); self.phase_evidence.setWordWrap(True); form.addWidget(self.phase_evidence,1,2,1,2)
        form.addWidget(QLabel('Scan plane'),2,0); self.plane_combo=QComboBox(); self.plane_combo.addItems(PLANE_OPTIONS); self.plane_combo.currentTextChanged.connect(self.mapping_changed); form.addWidget(self.plane_combo,2,1)
        form.addWidget(QLabel('Frequency direction'),2,2); self.freq_combo=QComboBox(); self.freq_combo.addItems(FREQ_OPTIONS); self.freq_combo.currentTextChanged.connect(self.mapping_changed); form.addWidget(self.freq_combo,2,3)
        form.addWidget(QLabel('MR series'),3,0); self.series_combo=QComboBox(); self.series_combo.currentIndexChanged.connect(self.series_changed); form.addWidget(self.series_combo,3,1,1,3)
        self.use_auto=QCheckBox('Use automatically matched review.out / mrserver information when available'); self.use_auto.setChecked(True); self.use_auto.toggled.connect(self.refresh_selected); form.addWidget(self.use_auto,4,0,1,4)
        rl.addWidget(controls)
        self.tabs=QTabWidget(); rl.addWidget(self.tabs,1)
        self.imgplot=Plot(); self.tabs.addTab(self.imgplot,'MR / Hotspot Replay')
        self.overview=QTextEdit(); self.overview.setReadOnly(True); self.tabs.addTab(self.overview,'Maximum Information')
        self.mrtable=QTableWidget(0,12); self.mrtable.setHorizontalHeaderLabels(['Time','Description','Plane','Freq Dir','Mode','Sequence','PSD','Coil','FOV','Thickness','Slices','Matrix']); self.mrtable.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); self.tabs.addTab(self.mrtable,'MR Series from review.out')
        self.cavplot=Plot(); self.tabs.addTab(self.cavplot,'Hydrophone Cavitation')
        self.specpage=QWidget(); spl=QVBoxLayout(self.specpage); sc=QHBoxLayout(); spl.addLayout(sc)
        sc.addWidget(QLabel('Interval')); self.spec_interval=QComboBox(); self.spec_interval.addItems(SPECTRUM_INTERVALS); self.spec_interval.currentTextChanged.connect(self.refresh_selected); sc.addWidget(self.spec_interval)
        sc.addWidget(QLabel('Hydrophone')); self.hp_combo=QComboBox(); self.hp_combo.addItems(['Auto / FUS-selected']+[f'Hydrophone {i}' for i in range(1,9)]); self.hp_combo.currentTextChanged.connect(self.refresh_selected); sc.addWidget(self.hp_combo)
        sc.addWidget(QLabel('Display')); self.spec_display=QComboBox(); self.spec_display.addItems(SPECTRUM_DISPLAY); self.spec_display.currentTextChanged.connect(self.refresh_selected); sc.addWidget(self.spec_display)
        sc.addWidget(QLabel('Y axis')); self.spec_y=QComboBox(); self.spec_y.addItems(SPECTRUM_Y); self.spec_y.currentTextChanged.connect(self.refresh_selected); sc.addWidget(self.spec_y); sc.addStretch(1)
        self.spec_note=QLabel(''); self.spec_note.setWordWrap(True); spl.addWidget(self.spec_note)
        self.specplot=Plot(); spl.addWidget(self.specplot,1); self.tabs.addTab(self.specpage,'Spectrum')
        self.timeline=Plot(); self.tabs.addTab(self.timeline,'DQA / Treatment Timeline')
        self.syncinfo=QTextEdit(); self.syncinfo.setReadOnly(True); self.tabs.addTab(self.syncinfo,'Time Synchronization')
        self.evidence=QTextEdit(); self.evidence.setReadOnly(True); self.tabs.addTab(self.evidence,'mrserver / Raw Evidence')
        self.coverage=QTableWidget(0,4); self.coverage.setHorizontalHeaderLabels(['Data domain','Status','Evidence count','Notes']); self.coverage.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); self.tabs.addTab(self.coverage,'Data Coverage')
        self.inventory_table=QTableWidget(0,8); self.inventory_table.setHorizontalHeaderLabels(['Path','Size','Category','Sonication','Extension','Signature','Candidate layout','Status']); self.inventory_table.horizontalHeader().setSectionResizeMode(0,QHeaderView.Stretch); self.inventory_table.itemSelectionChanged.connect(self.inventory_selected); self.tabs.addTab(self.inventory_table,'Complete Inventory')
        self.rawpage=QWidget(); rawlay=QVBoxLayout(self.rawpage); rawtop=QHBoxLayout(); rawlay.addLayout(rawtop); rawtop.addWidget(QLabel('RAW candidate')); self.raw_combo=QComboBox(); self.raw_combo.currentIndexChanged.connect(self.draw_raw_candidate); rawtop.addWidget(self.raw_combo,1); self.raw_meta=QLabel('No RAW selected'); self.raw_meta.setWordWrap(True); rawlay.addWidget(self.raw_meta); self.rawplot=Plot(); rawlay.addWidget(self.rawplot,1); self.tabs.addTab(self.rawpage,'RAW Investigation')
        self.details=QTextEdit(); self.details.setReadOnly(True); self.tabs.addTab(self.details,'Sonication Details')
        split.addWidget(right); split.setSizes([530,1050])

    def open_zip(self):
        p,_=QFileDialog.getOpenFileName(self,'Open FUS ZIP','','ZIP files (*.zip)')
        if p:self.load_zip(p)

    def load_zip(self,p):
        try:
            if self.zf:self.zf.close()
            self.zf=zipfile.ZipFile(p); self.zip_path=Path(p); names=self.zf.namelist()
            sums=[n for n in names if '/Summary_' in n and n.lower().endswith('.txt')]
            if not sums: sums=[n for n in names if Path(n).name.lower().startswith('summary_') and n.lower().endswith('.txt')]
            if not sums: raise ValueError('Treatment Summary file was not found')
            self.sonics=parse_summary(self.zf.read(sums[0]).decode('utf-8','ignore'))
            self.spectrum_files=[n for n in names if n.endswith('.dmp_FFT')]
            self.spectrum_msg_files=[n for n in names if 'spectrummsg' in Path(n).name.lower() and not n.endswith('/')]
            self.reflection_files=[n for n in names if 'reflection' in n.lower() and not n.endswith('/')]
            self.inventory=make_inventory(self.zf); self.raw_files=[i.path for i in self.inventory if i.category=='MR / Thermometry RAW']
            self.mr_series=[]
            for n in names:
                if Path(n).name.lower() in ('review.out','review.out.ar'):
                    try:
                        parsed=parse_review(self.zf.read(n).decode('utf-8','ignore'))
                        if parsed: self.mr_series=parsed; break
                    except Exception: pass
            self.mrserver_events=[]; self.timing_evidence=[]; self.ws_offsets=[]
            for n in names:
                if 'mrserver' in Path(n).name.lower() and n.lower().endswith('.log'):
                    try:self.mrserver_events += parse_mrserver(self.zf.read(n).decode('utf-8','ignore'),Path(n).name)
                    except Exception:pass
            # Search WS, WaterSystem, acquisition and sonication logs for timing evidence and explicit MR/FUS clock offsets.
            for n in names:
                bn=Path(n).name.lower()
                if n.endswith('/') or not (bn.endswith('.log') or bn.endswith('.txt')): continue
                if not any(k in n.lower() for k in ('wsfiles/','watersystem','acquisition','sonication')): continue
                try:
                    rows,offs=scan_timing_evidence(self.zf.read(n).decode('utf-8','ignore'),Path(n).name)
                    self.timing_evidence += rows; self.ws_offsets += offs
                except Exception: pass
            self.auto_phase=classify_session(self.sonics)
            self.son_meta=parse_sonication_metadata(self.zf,names)
            for no,meta in self.son_meta.items():
                if meta.get('phase'):
                    self.auto_phase[no]={'phase':meta['phase'],'confidence':meta.get('phase_confidence','High'),'reason':meta.get('phase_reason','XML metadata')}
            self.spec_cache={}; self.manual={}; self.external_images={}; self.load_mapping()
            self.populate()
            self.info.setText(f'{self.zip_path.name} | {len(self.sonics)} sonications | {len(self.inventory)} files | {len(self.raw_files)} RAW | {len(self.mr_series)} MR series | {len(self.spectrum_files)} FFT | {len(self.spectrum_msg_files)} SpectrumMsg')
            self.draw_timeline(); self.show_mr_table(); self.show_evidence(); self.show_sync(); self.show_inventory(); self.show_coverage(); self.populate_raw_combo()
            if self.sonics:self.table.selectRow(0)
        except Exception as e: QMessageBox.critical(self,'Load error',str(e))

    def populate(self):
        self._updating=True
        self.table.setRowCount(len(self.sonics)); self.series_combo.clear(); self.series_combo.addItem('No linked MR series',-1)
        for i,m in enumerate(self.mr_series): self.series_combo.addItem(f'{m.time} | {m.description or m.protocol} | {m.plane} | {m.freq_dir}',i)
        for r,s in enumerate(self.sonics):
            auto=self.auto_series_index(s); m=self.mr_series[auto] if auto is not None else None
            man=self.manual.get(str(s.no),{})
            ap=self.auto_phase.get(str(s.no),{'phase':'DQA','confidence':'Low'})
            phase=man.get('phase') or ap['phase']
            meta=self.son_meta.get(str(s.no),{})
            vals=[s.no,phase,ap.get('confidence',''),s.time,meta.get('actualduration',s.duration),s.power,meta.get('measuredpower',s.avg_power),s.freq,s.fd,s.status,man.get('plane') or meta.get('plane') or (m.plane if m else 'Unknown'),man.get('freq_dir') or meta.get('freqdirection') or (m.freq_dir if m else 'Unknown')]
            for c,v in enumerate(vals):self.table.setItem(r,c,QTableWidgetItem(str(v)))
        self._updating=False

    def auto_series_index(self,s):
        if not self.mr_series:return None
        target=time_seconds(s.time); best=None
        for i,m in enumerate(self.mr_series):
            t=time_seconds(m.time) if m.time else 0
            d=target-t
            # Prefer the most recent MR acquisition before the sonication; otherwise nearest.
            score=(0 if d>=0 else 50000)+abs(d)
            if best is None or score<best[0]:best=(score,i)
        return best[1] if best else None

    def select_row(self,row,col,pr,pc):
        if 0<=row<len(self.sonics):self.refresh_selected()

    def refresh_selected(self,*args):
        row=self.table.currentRow()
        if not (0<=row<len(self.sonics)):return
        s=self.sonics[row]; man=self.manual.get(str(s.no),{}); auto=self.auto_series_index(s); chosen=man.get('series_index',auto if auto is not None else -1)
        self._updating=True
        ap=self.auto_phase.get(str(s.no),{'phase':'DQA','confidence':'Low','reason':'No evidence'})
        self.phase_combo.setCurrentText(man.get('phase','Auto'))
        effective=man.get('phase') or ap['phase']
        self.phase_evidence.setText(f'Effective: {effective} | Confidence: {ap.get("confidence","Low")} | {ap.get("reason","")}')
        self.series_combo.setCurrentIndex(self.series_combo.findData(chosen))
        m=self.mr_series[chosen] if isinstance(chosen,int) and 0<=chosen<len(self.mr_series) else None
        meta=self.son_meta.get(str(s.no),{})
        plane=man.get('plane') or meta.get('plane') or (m.plane if m and self.use_auto.isChecked() else 'Unknown')
        freq=man.get('freq_dir') or meta.get('freqdirection') or (m.freq_dir if m and self.use_auto.isChecked() else 'Unknown')
        self.plane_combo.setCurrentText(normalize_plane(plane) if plane not in PLANE_OPTIONS else plane)
        self.freq_combo.setCurrentText(freq if freq in FREQ_OPTIONS else 'Unknown')
        source=[]
        if meta:source.append('sonication XML metadata')
        if m and self.use_auto.isChecked():source.append('review.out auto-match')
        if man:source.append('manual override')
        if str(s.no) in self.external_images:source.append('external MR image')
        self.source_label.setText('Source: '+(', '.join(source) if source else 'simulation / not available'))
        self._updating=False
        self.draw_image(s,m); self.draw_cavitation(s); self.draw_spectrum(s); self.show_details(s,m); self.show_overview(s,m)

    def phase_changed(self,*args):
        if self._updating:return
        row=self.table.currentRow()
        if not (0<=row<len(self.sonics)):return
        son=self.sonics[row]; value=self.phase_combo.currentText(); d=self.manual.setdefault(str(son.no),{})
        if value=='Auto': d.pop('phase',None)
        else: d['phase']=value
        ap=self.auto_phase.get(str(son.no),{'phase':'DQA'})
        self.table.item(row,1).setText(d.get('phase') or ap['phase'])
        self.draw_timeline(); self.refresh_selected()

    def mapping_changed(self,*args):
        if self._updating:return
        row=self.table.currentRow()
        if not (0<=row<len(self.sonics)):return
        s=self.sonics[row]; d=self.manual.setdefault(str(s.no),{})
        d['plane']=self.plane_combo.currentText(); d['freq_dir']=self.freq_combo.currentText()
        self.table.item(row,10).setText(d['plane']); self.table.item(row,11).setText(d['freq_dir']); self.refresh_selected()

    def series_changed(self,*args):
        if self._updating:return
        row=self.table.currentRow()
        if not (0<=row<len(self.sonics)):return
        s=self.sonics[row]; self.manual.setdefault(str(s.no),{})['series_index']=self.series_combo.currentData(); self.refresh_selected()

    def move_row(self,d):
        if not self.sonics:return
        r=max(0,min(len(self.sonics)-1,self.table.currentRow()+d)); self.table.selectRow(r)

    def add_mr_images(self):
        if not self.sonics:return
        p=QFileDialog.getExistingDirectory(self,'Select DICOM / MR image folder')
        if not p:return
        files=[]
        for x in Path(p).rglob('*'):
            if x.is_file() and x.suffix.lower() in ('.dcm','.ima','.png','.jpg','.jpeg','.bmp','.tif','.tiff'): files.append(str(x))
        if not files: QMessageBox.information(self,'MR import','No supported MR/DICOM image files were found.'); return
        row=self.table.currentRow(); s=self.sonics[row]
        self.external_images[str(s.no)]={'folder':p,'files':files[:5000]}
        QMessageBox.information(self,'MR import',f'{len(files)} files registered for Sonication {s.no}.\nThe mapping is saved in the review sidecar JSON.\nPixel rendering of ordinary PNG/JPEG is enabled; DICOM metadata/pixel support is reserved for the pydicom option.')
        self.refresh_selected()

    def mapping_path(self):return self.zip_path.with_suffix('.fus_review.json') if self.zip_path else None
    def save_mapping(self):
        if not self.zip_path:return
        data={'zip':self.zip_path.name,'manual':self.manual,'external_images':self.external_images,'saved_at':datetime.now().isoformat(timespec='seconds'),'schema_version':4}
        self.mapping_path().write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
        QMessageBox.information(self,'Saved',f'Review mapping saved:\n{self.mapping_path()}')
    def load_mapping(self):
        p=self.mapping_path()
        if p and p.exists():
            try:
                d=json.loads(p.read_text(encoding='utf-8')); self.manual=d.get('manual',{}); self.external_images=d.get('external_images',{})
            except Exception:pass

    def effective_phase(self,s):
        d=self.manual.get(str(s.no),{}); return d.get('phase') or self.auto_phase.get(str(s.no),{}).get('phase','DQA')

    def draw_image(self,s,m):
        f=self.imgplot.fig; f.clear(); ax=f.add_subplot(111)
        n=360; yy,xx=np.mgrid[-1:1:complex(n),-1:1:complex(n)]
        base=None; ext=self.external_images.get(str(s.no),{}); image_source=''
        if ext:
            for fn in ext.get('files',[]):
                if Path(fn).suffix.lower() in ('.png','.jpg','.jpeg','.bmp','.tif','.tiff'):
                    try:
                        import matplotlib.image as mpimg; base=mpimg.imread(fn); image_source=f'External MR image: {Path(fn).name}'; break
                    except Exception: pass
        plane=self.plane_combo.currentText()
        if plane not in ('Axial','Sagittal','Coronal'):
            plane='Axial'
        if base is None:
            phase=self.effective_phase(s)
            key=plane.lower()
            rel=(f'resources/examples/dqa_phantom_{key}.png' if phase=='DQA' else f'resources/examples/treatment_t2_{key}.png')
            example=resource_path(rel)
            if example.exists():
                try:
                    import matplotlib.image as mpimg; base=mpimg.imread(example)
                except Exception: base=None
            if phase=='DQA':
                image_source=f'EXAMPLE DQA phantom — {plane}'
            else:
                image_source=f'EXAMPLE T2 brain — {plane} — NO PATIENT MR LOADED'
        if base is None:
            # Last-resort generated placeholder if a packaged image is missing.
            if self.effective_phase(s)=='DQA':
                base=np.exp(-((xx/.72)**2+(yy/.72)**2)*2.2)
                image_source=f'EXAMPLE DQA phantom — {plane} (generated fallback)'
            else:
                base=np.exp(-((xx/.78)**2+(yy/.92)**2)*2.1)+.07*np.sin(18*xx)*np.cos(14*yy)
                image_source=f'EXAMPLE T2 brain — {plane} (generated fallback)'
        ax.imshow(base,cmap='gray',origin='upper',extent=(-1,1,-1,1))
        scale=np.clip((s.avg_power/1100)*(s.duration/40),.03,1); cx=np.clip(s.x/100.0,-.65,.65); cy=np.clip(s.y/100.0,-.65,.65)
        if abs(cx)<.01 and abs(cy)<.01: cx=.18*math.sin(s.no*.65); cy=.14*math.cos(s.no*.51)
        hot=np.exp(-(((xx-cx)/(.055+.035*scale))**2+((yy-cy)/(.075+.045*scale))**2)*2)
        ax.imshow(np.ma.masked_where(hot<.08,hot*scale),cmap='hot',alpha=.72,origin='lower',extent=(-1,1,-1,1),vmin=0,vmax=1)
        ax.plot(cx,cy,'+',markersize=14,markeredgewidth=2)
        freq=self.freq_combo.currentText()
        if freq!='Unknown': ax.annotate(f'Frequency {freq}',xy=(.88,-.9),xytext=(-.1,-.9),arrowprops={'arrowstyle':'->'},fontsize=10)
        ax.text(-.97,.94,'EXAMPLE' if not ext else 'LINKED IMAGE',va='top',ha='left',fontsize=10,fontweight='bold',bbox={'facecolor':'black','alpha':.7,'edgecolor':'none'},color='white')
        ax.set_title(f'{image_source}\nSonication {s.no} | {self.effective_phase(s)} | Plane {plane} | Frequency {freq} | Hotspot simulated')
        ax.set_xticks([]); ax.set_yticks([]); self.imgplot.draw()

    def spectrum_message_for_sonication(self,s):
        # Prefer a file physically stored under SonicationN. Fall back to numeric filename match.
        pat=re.compile(rf'(^|[\\/])sonication[_ ]?{s.no}([\\/]|$)',re.I)
        direct=[n for n in self.spectrum_msg_files if pat.search(n)]
        if direct:return direct[0]
        numbered=[n for n in self.spectrum_msg_files if re.search(rf'spectrummsg[-_ ]?{s.no}(?:\D|$)',Path(n).name,re.I)]
        return numbered[0] if numbered else None

    def decoded_hydrophones(self,s):
        n=self.spectrum_message_for_sonication(s)
        if not n:return n,None
        key=('channels',n)
        if key not in self.spec_cache:
            try:self.spec_cache[key]=decode_spectrum_channels(self.zf.read(n))
            except Exception:self.spec_cache[key]=None
        return n,self.spec_cache[key]

    def draw_cavitation(self,s):
        f=self.cavplot.fig; f.clear(); ax=f.add_subplot(111)
        n,dec=self.decoded_hydrophones(s)
        if dec:
            streams=dec['channels']; duration=max(float(s.duration),.001)
            t=np.linspace(0,duration,streams.shape[1])
            # Envelope is an experimental relative acoustic activity trace, not a validated cavitation dose.
            for i,x in enumerate(streams):
                win=max(3,min(101,len(x)//80*2+1)); kernel=np.ones(win)/win
                env=np.convolve(np.abs(x-np.median(x)),kernel,mode='same')
                env=env/(np.percentile(env,99)+1e-12)
                ax.plot(t,env,label=f'Channel {i+1}')
            ax.set_title(f'Experimental time-resolved acoustic activity — {Path(n).name}\n{dec["count"]} candidate channels; not yet validated as cavitation dose')
            ax.set_xlabel('Time within payload mapped to actual sonication duration (s)'); ax.set_ylabel('Relative acoustic activity')
            ax.legend(ncol=2,fontsize=8); ax.grid(True,alpha=.25)
        else:
            ax.text(.5,.5,'No decodable time-resolved SpectrumMsg payload for this sonication',ha='center',va='center',transform=ax.transAxes)
            ax.set_title('Hydrophone Cavitation — unavailable (simulation removed)'); ax.set_xlabel('Time'); ax.set_ylabel('Cavitation')
        self.cavplot.draw()

    def nearest_spectrum(self,s):
        target=time_seconds(s.time); a=[(abs(spectrum_time(n)-target),n) for n in self.spectrum_files if spectrum_time(n) is not None]
        return min(a)[1] if a else None

    def draw_spectrum(self,s):
        f=self.specplot.fig; f.clear()
        interval=self.spec_interval.currentText(); hp=self.hp_combo.currentText(); ymode=self.spec_y.currentText(); mode=self.spec_display.currentText()
        msg,dec=self.decoded_hydrophones(s)
        spectra=[]; source=''; experimental=False
        if dec:
            spectra=channel_spectra_from_streams(dec['channels']); source=msg; experimental=True
        else:
            n=self.nearest_spectrum(s); x=y=None
            if n:
                if n not in self.spec_cache:self.spec_cache[n]=decode_spectrum(self.zf.read(n))
                x,y=self.spec_cache[n]
            if x is not None:spectra=[(x,y)]; source=n
        valid=[z for z in spectra if z[0] is not None]
        if not valid:
            ax=f.add_subplot(111); ax.text(.5,.5,'No decodable acoustic spectrum payload',ha='center',va='center',transform=ax.transAxes); ax.axis('off')
            self.spec_note.setText('No simulation is displayed. Spectrum and hydrophone data remain unavailable until a payload is decoded.'); self.specplot.draw(); return
        def yconvert(y):
            y=np.maximum(np.asarray(y,float),1e-12)
            return 20*np.log10(y/np.max(y)) if ymode=='dB' else y
        selected=0
        m=re.search(r'(\d+)',hp)
        if m:selected=max(0,min(len(valid)-1,int(m.group(1))-1))
        if mode=='All Separate' and len(valid)>1:
            cols=2; rows=int(math.ceil(len(valid)/cols))
            for i,(x,y) in enumerate(valid):
                ax=f.add_subplot(rows,cols,i+1); ax.plot(x,yconvert(y)); ax.set_title(f'Channel {i+1}'); ax.grid(True,alpha=.2)
                ax.set_xlabel('Relative frequency'); ax.set_ylabel('dB' if ymode=='dB' else 'Amplitude')
        elif mode=='Spectrogram' and dec:
            ax=f.add_subplot(111); x=dec['channels'][selected]; nper=max(64,min(512,2**int(np.floor(np.log2(max(64,len(x)//20)))))); nover=nper//2
            ax.specgram(x,NFFT=nper,Fs=1.0,noverlap=nover); ax.set_xlabel('Relative payload time'); ax.set_ylabel('Relative frequency'); ax.set_title(f'Channel {selected+1} spectrogram (uncalibrated)')
        else:
            ax=f.add_subplot(111)
            if mode=='Single':
                x,y=valid[selected]; ax.plot(x,yconvert(y),label=f'Channel {selected+1}')
            elif mode=='Average':
                n=min(len(y) for _,y in valid); x=valid[0][0][:n]; mat=np.vstack([y[:n] for _,y in valid]); ax.plot(x,yconvert(np.mean(mat,axis=0)),label='Channel average')
            elif mode=='Maximum Envelope':
                n=min(len(y) for _,y in valid); x=valid[0][0][:n]; mat=np.vstack([y[:n] for _,y in valid]); ax.plot(x,yconvert(np.max(mat,axis=0)),label='Maximum envelope')
            else:
                for i,(x,y) in enumerate(valid):ax.plot(x,yconvert(y),label=f'Channel {i+1}')
            ax.legend(ncol=2,fontsize=8); ax.grid(True,alpha=.25); ax.set_xlabel('Frequency (relative; physical calibration unavailable)'); ax.set_ylabel('Amplitude (dB re max)' if ymode=='dB' else 'Amplitude (normalized)')
            ax.set_title(f'{interval} | {mode} | {Path(source).name}')
        if experimental:
            self.spec_note.setText(f'Experimental decode of {Path(source).name}: {dec["count"]} candidate channels, dtype {dec["dtype"]}, offset {dec["offset"]}. Channel identity, sampling interval, Hz/MHz scale, and Pre/During/Post boundaries are not yet validated. The full payload is mapped to the sonication duration only for review.')
        else:
            self.spec_note.setText('Matched FFT payload is displayed as one unassigned channel. Physical frequency calibration and hydrophone identity are not verified.')
        self.specplot.draw()

    def draw_timeline(self):
        f=self.timeline.fig; f.clear(); ax=f.add_subplot(111)
        if self.sonics:
            for i,s in enumerate(self.sonics):
                phase=self.effective_phase(s); y=1 if phase=='Treatment' else 0
                ax.barh(y,max(s.duration,.2),left=time_seconds(s.time),height=.35,alpha=.65)
                ax.text(time_seconds(s.time)+max(s.duration,.2)/2,y,str(s.no),ha='center',va='center',fontsize=8)
            ax.set_yticks([0,1],['DQA (phantom)','Treatment (patient)']); ax.set_xlabel('Session clock (seconds from midnight)')
            ax.set_title('DQA and Treatment Sonication Timeline — manual overrides preserved'); ax.grid(True,axis='x',alpha=.25)
        self.timeline.draw()

    def show_mr_table(self):
        self.mrtable.setRowCount(len(self.mr_series))
        for r,m in enumerate(self.mr_series):
            vals=[m.time,m.description,m.plane,m.freq_dir,m.image_mode,m.pulse_sequence,m.psd_name,m.coil,m.fov,m.thickness,m.slices,m.matrix]
            for c,v in enumerate(vals):self.mrtable.setItem(r,c,QTableWidgetItem(v))

    def show_evidence(self):
        lines=['MR SERVER EVIDENCE','='*80]
        lines += self.mrserver_events[:10000]
        if not self.mrserver_events: lines.append('No mrserver.log evidence was found.')
        lines += ['','TIMING EVIDENCE','='*80] + self.timing_evidence[:5000]
        self.evidence.setPlainText('\n'.join(lines))

    def show_sync(self):
        offset='Not detected'
        source='No explicit MR–FUS offset statement was decoded. Manual verification is required.'
        if self.ws_offsets:
            vals=[v for v,_ in self.ws_offsets]; offset=f'{np.median(vals):+.3f} s (median of {len(vals)} records)'; source=self.ws_offsets[0][1]
        self.syncinfo.setHtml(f'<h2>MR–FUS Time Synchronization</h2><table cellpadding="5" border="1" cellspacing="0"><tr><td><b>WS offset</b></td><td>{offset}</td></tr><tr><td><b>Evidence</b></td><td>{source}</td></tr><tr><td><b>Time model</b></td><td>MR acquisition → pre-sonication → actual FUS duration → post-sonication. FUS and MR clocks are kept separately and corrected only when an explicit WS offset is available.</td></tr></table><p>Pre/post durations are not assumed to be fixed. They are reconstructed from MR acquisition events and sonication start/end evidence when available. Unverified values remain unknown rather than being fabricated.</p>')

    def show_overview(self,s,m):
        spec=self.nearest_spectrum(s); man=self.manual.get(str(s.no),{})
        rows=[
            ('Sonication',str(s.no)),('Category',self.effective_phase(s)),('Start',s.time),('Status',s.status),('Duration',f'{s.duration:.2f} s'),
            ('Power / Avg / Max',f'{s.power:.2f} / {s.avg_power:.2f} / {s.max_power:.2f}'),('Frequency',f'{s.freq:.3f}'),
            ('Focus coordinates',f'X {s.x:.2f}, Y {s.y:.2f}, Elevation {s.elevation:.2f}, FD {s.fd:.2f}'),
            ('Scan plane',self.plane_combo.currentText()),('Frequency direction',self.freq_combo.currentText()),
            ('Spectrum match',Path(spec).name if spec else 'None'),('Reflection files',str(len(self.reflection_files))),
            ('Spectrum interval',self.spec_interval.currentText()),('Hydrophone',self.hp_combo.currentText()),('Spectrum display',self.spec_display.currentText()),('MR series source',m.description if m else 'No matched review.out series'),('External image',self.external_images.get(str(s.no),{}).get('folder','None'))]
        html='<h2>Maximum Available Information</h2><table cellpadding="5" border="1" cellspacing="0">'+''.join(f'<tr><td><b>{a}</b></td><td>{b}</td></tr>' for a,b in rows)+'</table>'
        if m:
            html += '<h3>Matched MR acquisition from review.out</h3><table cellpadding="5" border="1" cellspacing="0">'+''.join(f'<tr><td><b>{a}</b></td><td>{b}</td></tr>' for a,b in [
                ('Protocol',m.protocol),('Series description',m.description),('Plane',m.plane),('Frequency direction',m.freq_dir),('Image mode',m.image_mode),('Pulse sequence',m.pulse_sequence),('PSD',m.psd_name),('Coil',m.coil),('FOV',m.fov),('Slice thickness',m.thickness),('Slices',m.slices),('Matrix',m.matrix),('Start / End location',f'{m.start_loc} / {m.end_loc}'),('Center FOV',m.center_fov)])+'</table>'
        meta=self.son_meta.get(str(s.no),{})
        if meta:
            html += '<h3>Sonication XML metadata</h3><table cellpadding="5" border="1" cellspacing="0">'+''.join(f'<tr><td><b>{k}</b></td><td>{v}</td></tr>' for k,v in meta.items() if k!='evidence' and len(str(v))<500)+'</table><p><b>Evidence files:</b> '+', '.join(meta.get('evidence',[]))+'</p>'
        html += '<h3>Timing model</h3><p>MR acquisition start → Pre → FUS start (0 s) → Actual duration → Post → MR acquisition end. WS clock-offset evidence is applied only when explicitly decoded.</p><p><b>Provenance:</b> Treatment parameters come from the ZIP summary. MR geometry is read from review.out when available and can be manually overridden per sonication. mrserver.log provides scanner workflow evidence. Hotspot and cavitation graphics remain simulated unless corresponding proprietary data is decoded or external images are linked.</p>'
        self.overview.setHtml(html)

    def show_inventory(self):
        self.inventory_table.setRowCount(len(self.inventory))
        for r,it in enumerate(self.inventory):
            vals=[it.path,f'{it.size:,}',it.category,it.sonication,it.ext,it.signature,it.candidate,it.status]
            for c,v in enumerate(vals): self.inventory_table.setItem(r,c,QTableWidgetItem(str(v)))

    def inventory_selected(self):
        rows=self.inventory_table.selectionModel().selectedRows() if self.inventory_table.selectionModel() else []
        if not rows:return
        r=rows[0].row()
        if 0<=r<len(self.inventory):
            it=self.inventory[r]
            if it.path in self.raw_files:
                idx=self.raw_combo.findData(it.path)
                if idx>=0:self.raw_combo.setCurrentIndex(idx)

    def populate_raw_combo(self):
        self.raw_combo.blockSignals(True); self.raw_combo.clear()
        for n in self.raw_files:self.raw_combo.addItem(n,n)
        self.raw_combo.blockSignals(False)
        if self.raw_files:self.raw_combo.setCurrentIndex(0); self.draw_raw_candidate()
        else:
            self.rawplot.fig.clear(); self.rawplot.draw(); self.raw_meta.setText('No .raw files were found in this ZIP.')

    def draw_raw_candidate(self,*args):
        if not self.zf:return
        n=self.raw_combo.currentData()
        if not n:return
        try: blob=self.zf.read(n)
        except Exception as e:
            self.raw_meta.setText(str(e)); return
        result=try_render_raw(blob)
        f=self.rawplot.fig; f.clear(); ax=f.add_subplot(111)
        if result:
            score,dt,w,h,img=result; ax.imshow(img,cmap='gray',origin='upper'); ax.set_title(f'Experimental RAW preview — {Path(n).name}\n{w}x{h} {dt}, image-likeness {score:.3f}'); ax.set_xticks([]); ax.set_yticks([])
            self.raw_meta.setText(f'Path: {n} | Size: {len(blob):,} bytes | Candidate: {w}x{h} {dt} | Status: Experimental. This preview is not identified as magnitude, phase, temperature, or dose until cross-file evidence confirms it.')
        else:
            ax.text(.5,.5,'No plausible 2-D image layout found',ha='center',va='center'); ax.axis('off'); self.raw_meta.setText(f'Path: {n} | Size: {len(blob):,} bytes | Candidate layouts: {raw_candidates(len(blob))}')
        self.rawplot.draw()

    def show_coverage(self):
        cats={}
        for it in self.inventory:cats[it.category]=cats.get(it.category,0)+1
        rows=[
            ('Sonication summary','Confirmed',len(self.sonics),'Parsed treatment summary rows'),
            ('DQA / Treatment','Partial',len(self.sonics),'Automatic workflow grouping plus manual override; explicit DQA log decoder remains under development'),
            ('MR review metadata','Confirmed' if self.mr_series else 'Missing',len(self.mr_series),'review.out series metadata'),
            ('MR server workflow','Confirmed' if self.mrserver_events else 'Missing',len(self.mrserver_events),'mrserver event evidence'),
            ('MR / Thermometry RAW','Experimental' if self.raw_files else 'Missing',len(self.raw_files),'Inventory and candidate 2-D preview; semantic channel identification pending'),
            ('Spectrum / Hydrophone','Experimental' if self.spectrum_msg_files else ('Partial' if self.spectrum_files else 'Missing'),len(self.spectrum_files)+len(self.spectrum_msg_files),'4–8 channel candidate decoding, Single/Overlay/Separate/Average/Envelope/Spectrogram; channel identity and physical calibration pending'),
            ('Reflection','Inventory',cats.get('Reflection',0),'Files linked by path/time; decoder pending'),
            ('Skull / Bone','Inventory',cats.get('Skull heating',0)+cats.get('Skull measures',0)+cats.get('Bone spot data',0),'Evidence indexed; structured decoder pending'),
            ('MR–FUS synchronization','Partial' if self.ws_offsets else 'Unknown',len(self.ws_offsets),'Explicit offset evidence only; no fabricated timing'),
            ('DICOM import','Available',sum(len(v.get('files',[])) for v in self.external_images.values()),'External image mapping supported; metadata/pixel display depends on pydicom')
        ]
        self.coverage.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for c,v in enumerate(row):self.coverage.setItem(r,c,QTableWidgetItem(str(v)))

    def show_details(self,s,m):
        spec=self.nearest_spectrum(s)
        html=(f'<h2>Sonication {s.no} — {self.effective_phase(s)}</h2><table cellpadding="5">'
              f'<tr><td>Start time</td><td>{s.time}</td></tr><tr><td>Status</td><td>{s.status}</td></tr>'
              f'<tr><td>Duration</td><td>{s.duration:.1f} s</td></tr><tr><td>Commanded power</td><td>{s.power:.1f}</td></tr>'
              f'<tr><td>Average / maximum power</td><td>{s.avg_power:.1f} / {s.max_power:.1f}</td></tr>'
              f'<tr><td>Frequency</td><td>{s.freq:.3f}</td></tr><tr><td>Focal distance</td><td>{s.fd:.1f}</td></tr>'
              f'<tr><td>Position</td><td>X {s.x:.1f}, Y {s.y:.1f}, Elevation {s.elevation:.1f}, Roll {s.roll:.1f}, Pitch {s.pitch:.1f}</td></tr>'
              f'<tr><td>MR plane / frequency direction</td><td>{self.plane_combo.currentText()} / {self.freq_combo.currentText()}</td></tr>'
              f'<tr><td>Matched spectrum</td><td>{Path(spec).name if spec else "None"}</td></tr></table>')
        self.details.setHtml(html)
        self.left_details.setHtml(html)

if __name__=='__main__':
    app=QApplication(sys.argv); m=Main(); m.show()
    if len(sys.argv)>1 and Path(sys.argv[1]).exists():m.load_zip(sys.argv[1])
    sys.exit(app.exec())
