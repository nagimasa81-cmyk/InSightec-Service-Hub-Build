# RC1 Test Checklist

1. Build succeeds with Python 3.13 and `fast_pyinstaller`.
2. Application starts without a console window.
3. Open `09-09-11_ANx.zip` and verify Sonication table, Complete Inventory and RAW Investigation tabs populate.
4. Open `22-55-19_ANx.zip` and verify explicit Brain-DQA metadata classifies Sonications as DQA.
5. Verify each Sonication can independently change Phase, Scan Plane and Frequency Direction.
6. Verify DQA displays a DQA phantom example and Treatment displays a T2 brain example when no image is linked.
7. Link an MR/DICOM folder and save the `.fus_review.json` sidecar.
8. Reopen the ZIP and verify mappings are restored.
9. Verify Spectrum axis defaults to frequency versus amplitude and remains labeled relative when calibration is unavailable.
10. Confirm simulated/experimental content is visibly labeled and not presented as confirmed clinical data.

## RC1.1 Multi-Hydrophone checks

- [ ] SpectrumMsg count appears in the loaded ZIP summary.
- [ ] Sonication selection links to the matching `SonicationN/SpectrumMsg-N.dmp`.
- [ ] Hydrophone selector includes 1–8.
- [ ] Display selector includes Single, All Overlay, All Separate, Average, Maximum Envelope, Spectrogram.
- [ ] All Separate renders without GUI failure for 4–8 candidate channels.
- [ ] Cavitation tab never displays simulated data.
- [ ] Experimental source/calibration warning is visible.
- [ ] Left Sonication list scrolls horizontally and vertically.
- [ ] Selected Sonication details appear below the list.
