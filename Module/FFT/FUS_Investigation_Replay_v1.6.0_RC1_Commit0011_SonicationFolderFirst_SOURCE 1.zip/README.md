# FUS Investigation & Treatment Replay Workstation RC1.6

## Sonication-folder-first reconstruction

For Sonication N, the application first reconstructs Replay, thermometry RAW sequences, SpectrumMsg, skull and other evidence from the exact `SonicationN/` folder.

Priority:

1. Exact `SonicationN/` folder data
2. Explicitly linked external MR/DICOM
3. Example image when no validated source is available

Time-near or similarly numbered RAW files from another folder are not silently substituted.

## RAW sequence selection

RAW files inside the exact Sonication folder are grouped by decoded binary geometry:

- data type
- width
- height
- consistent frame sequence
- natural filename/index order

The dominant consistent group is used as the primary Replay/Thermometry candidate. The UI displays the source priority and frame count.

## Geometry validation

Known plane or frequency-direction mismatches reject automatic Replay use. Unknown geometry is shown with an unconfirmed warning rather than being treated as a confirmed match.

## Build

Compatible with the supplied RC1 GitHub Actions workflow.

- Entry point: `app.py`
- Python: 3.13
- Build engine: `fast_pyinstaller`
