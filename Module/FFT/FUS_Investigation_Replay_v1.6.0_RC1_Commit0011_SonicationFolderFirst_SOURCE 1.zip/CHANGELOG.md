# Changelog

## v1.6.0-RC1 — Commit0011_SonicationFolderFirst

- Made the exact `SonicationN/` folder the primary source for Sonication Replay.
- Removed automatic cross-folder RAW substitution from normal Replay reconstruction.
- Grouped same-folder RAW files by decoded dtype and matrix geometry.
- Selected the dominant consistent frame sequence instead of the single highest-scoring RAW across the ZIP.
- Used the same dominant sequence for Thermometry Replay.
- Added source-priority and consistent-frame-count information.
- Added Sonication-folder content summary to the selected Sonication details.
- Kept known plane/frequency mismatches as a hard rejection condition.
- Allowed unknown geometry only with a visible unconfirmed warning.
- Preserved external MR/DICOM and Example images as lower-priority fallbacks.
