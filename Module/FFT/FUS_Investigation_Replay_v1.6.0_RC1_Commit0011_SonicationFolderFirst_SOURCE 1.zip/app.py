import sys, re, gzip, zipfile, struct, math, json, tempfile, shutil, hashlib, os
from pathlib import Path
from dataclasses import dataclass, asdict, field as dc_field
from datetime import datetime
import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QTableWidget,QTableWidgetItem,
    QPushButton,QFileDialog,QLabel,QSplitter,QTabWidget,QHeaderView,QMessageBox,QComboBox,QFormLayout,
    QGroupBox,QTextEdit,QCheckBox,QSpinBox,QDoubleSpinBox,QScrollArea,QSlider,QProgressDialog,QToolButton
)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as Canvas
from matplotlib.figure import Figure
from matplotlib.widgets import SpanSelector

@dataclass
class Sonication:
    no:int; time:str; x:float; y:float; roll:float; pitch:float; elevation:float
    fd:float; mode:int; duration:float; power:float; freq:float; max_power:float; avg_power:float; status:str


@dataclass
class InventoryItem:
    path:str; size:int; ext:str; category:str; sonication:str=''; signature:str=''; candidate:str=''; status:str='Inventory only'

def classify_inventory_path(name):
    low=name.lower(); ext=Path(name).suffix.lower() or '(none)'
    son=''
    m=re.search(r'sonication[_\\/ ]?(\d+)',low)
    if m: son=m.group(1)
    if low.endswith('/'):
        return 'Folder',son
    if ext in ('.xml',): return 'XML metadata',son
    if Path(name).name.lower() in ('review.out','review.out.ar'): return 'MR review report',son
    if 'mrserver' in low: return 'MR server log',son
    if 'spectrummsg' in low: return 'Spectrum message',son
    if 'spectrum' in low and ('fft' in low or ext in ('.dmp','.bin')): return 'Spectrum / FFT',son
    if 'reflection' in low: return 'Reflection',son
    if ext=='.raw': return 'MR / Thermometry RAW',son
    if 'skullheating' in low: return 'Skull heating',son
    if 'skullmeasure' in low: return 'Skull measures',son
    if 'bonespot' in low: return 'Bone spot data',son
    if any(k in low for k in ('wsfiles/','watersystem','gesys','cga','csa')): return 'System log',son
    if ext in ('.log','.txt','.out'): return 'Text log',son
    if ext in ('.dcm','.ima'): return 'DICOM / MR image',son
    if ext in ('.png','.jpg','.jpeg','.bmp','.tif','.tiff'): return 'Image',son
    return 'Other',son

def binary_signature(blob):
    h=blob[:16]
    if h.startswith(b'PK\x03\x04'): return 'ZIP'
    if h.startswith(b'\x1f\x8b'): return 'GZIP'
    if h.startswith(b'<?xml'): return 'XML'
    if len(blob)>132 and blob[128:132]==b'DICM': return 'DICOM'
    printable=sum(32<=b<127 or b in (9,10,13) for b in blob[:1024])
    if blob and printable/max(1,min(len(blob),1024))>.85: return 'Text-like'
    return h.hex(' ')

def raw_candidates(size):
    out=[]
    for bpp,dtype in ((2,'int16/uint16'),(4,'float32')):
        if size%bpp: continue
        pixels=size//bpp
        side=int(round(math.sqrt(pixels)))
        if side*side==pixels: out.append(f'{side}x{side} {dtype}')
        for w in (128,192,256,320,384,448,512,640,768,1024):
            if pixels%w==0:
                h=pixels//w
                if 64<=h<=2048 and abs(w-h)<=512:
                    cand=f'{w}x{h} {dtype}'
                    if cand not in out: out.append(cand)
    return '; '.join(out[:6]) or 'Unknown binary layout'

def make_inventory(zf):
    items=[]
    for info in zf.infolist():
        cat,son=classify_inventory_path(info.filename)
        sig=''; cand=''
        if not info.is_dir():
            try:
                blob=zf.read(info.filename)[:4096]
                sig=binary_signature(blob)
            except Exception: sig='Unreadable'
        if cat=='MR / Thermometry RAW': cand=raw_candidates(info.file_size)
        elif cat in ('Spectrum message','Spectrum / FFT','Reflection'): cand='Binary structure pending decoder'
        items.append(InventoryItem(info.filename,info.file_size,Path(info.filename).suffix.lower(),cat,son,sig,cand))
    return items

def try_render_raw(blob):
    candidates=[]
    for dt in ('<u2','<i2','<f4'):
        try:
            arr=np.frombuffer(blob,dtype=dt)
        except Exception: continue
        if arr.size<4096: continue
        for w in (128,192,256,320,384,448,512,640,768,1024):
            if arr.size%w: continue
            h=arr.size//w
            if not (64<=h<=2048): continue
            a=arr.reshape(h,w).astype(float)
            finite=np.isfinite(a)
            if finite.mean()<.98: continue
            p1,p99=np.percentile(a[finite],[1,99])
            if p99<=p1: continue
            norm=np.clip((a-p1)/(p99-p1),0,1)
            # Image-likeness: adjacent-pixel correlation and dynamic range.
            corrx=np.corrcoef(norm[:,:-1].ravel(),norm[:,1:].ravel())[0,1] if w>2 else 0
            corry=np.corrcoef(norm[:-1,:].ravel(),norm[1:,:].ravel())[0,1] if h>2 else 0
            score=np.nan_to_num((corrx+corry)/2) - .0001*abs(w-h)
            candidates.append((float(score),dt,w,h,norm))
    return max(candidates,key=lambda x:x[0]) if candidates else None

@dataclass
class MRSeries:
    date:str=''; time:str=''; protocol:str=''; description:str=''; plane:str='Unknown'; freq_dir:str='Unknown'
    image_mode:str=''; pulse_sequence:str=''; psd_name:str=''; coil:str=''; fov:str=''; thickness:str=''
    slices:str=''; matrix:str=''; start_loc:str=''; end_loc:str=''; center_fov:str=''; source:str='review.out'
    raw_plane:str='Unknown'; series_no:str=''; scan_time:str=''; acquisitions:str=''

@dataclass
class SyncMatch:
    series_index:int=-1; score:float=-1e9; confidence:str='Low'; corrected_gap:float=0.0
    applied_offset:float=0.0; offset_direction:str='None'; plane_match:bool=False; freq_match:bool=False
    protocol_match:bool=False; reasons:list=dc_field(default_factory=list); rejected:list=dc_field(default_factory=list)

ROW_RE=re.compile(r"^\s*(\d+)\s*\|\s*([\d:]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*(\d+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*(\w+)")

PLANE_OPTIONS=['Unknown','Axial','Sagittal','Coronal']
FREQ_OPTIONS=['Unknown','R/L','L/R','A/P','P/A','S/I','I/S']
PHASE_OPTIONS=['Auto','DQA','Treatment']
SPECTRUM_INTERVALS=['During Sonication','Pre-sonication','Post-sonication','Full Acquisition']
SPECTRUM_Y=['Amplitude','dB']
SPECTRUM_DISPLAY=['Single','All Overlay','All Separate','Average','Maximum Envelope','Spectrogram','Channel Heatmap','Relative Cavitation Bands']



def resource_path(relative):
    base=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
    return base / relative

def normalize_plane(raw, evidence=''):
    """Map source geometry to the nearest replay plane while keeping raw evidence separately.
    Oblique acquisitions are represented as Axial/Sagittal/Coronal in the replay UI.
    """
    text=f'{raw} {evidence}'.lower()
    if 'sag' in text: return 'Sagittal'
    if 'cor' in text: return 'Coronal'
    if 'axi' in text or 'trans' in text: return 'Axial'
    if '3-plane' in text or '3 plane' in text: return 'Axial'
    if 'oblique' in text:
        # A generic OBLIQUE record has no reliable normal-vector in the parsed text.
        # Use Axial only as a visible fallback; the user can correct each sonication.
        return 'Axial'
    return 'Unknown'

def parse_summary(text):
    out=[]
    for line in text.replace('\r','').splitlines():
        m=ROW_RE.match(line)
        if m:
            g=m.groups(); out.append(Sonication(int(g[0]),g[1],*map(float,g[2:8]),int(g[8]),*map(float,g[9:14]),g[14]))
    return out

def time_seconds(s):
    try:
        h,m,sec=map(int,s.split(':')); return h*3600+m*60+sec
    except Exception:return 0

def spectrum_time(name):
    m=re.search(r'_(\d\d)_(\d\d)_(\d\d)_\d{4}',name)
    return int(m.group(1))*3600+int(m.group(2))*60+int(m.group(3)) if m else None

def decode_spectrum(blob):
    try: raw=gzip.decompress(blob)
    except Exception: raw=blob
    vals=[]
    for off in range(32, min(len(raw)-8, 700000), 8):
        try:v=struct.unpack_from('<d',raw,off)[0]
        except Exception:continue
        if math.isfinite(v) and 1e-10 < abs(v) < 1e7: vals.append(abs(v))
    if len(vals)<128:
        a=np.frombuffer(raw[:len(raw)//4*4],dtype='<f4').astype(float)
        a=a[np.isfinite(a) & (np.abs(a)<1e7)]; vals=np.abs(a).tolist()
    a=np.asarray(vals[:150000],float)
    if a.size<64:return None,None
    n=min(4096,max(512,a.size)); idx=np.linspace(0,a.size-1,n).astype(int); y=a[idx]
    floor=max(np.percentile(y,5),1e-12); y=np.log10(y+floor); y-=np.nanmin(y)
    if np.nanmax(y)>0:y/=np.nanmax(y)
    return np.linspace(0,1,n),y


def decode_spectrum_channels(blob, expected_channels=None):
    """Experimental, bounded-cost candidate decoder for proprietary SpectrumMsg payloads."""
    try: raw=gzip.decompress(blob)
    except Exception: raw=blob
    candidates=[]
    channel_options=[]
    if expected_channels: channel_options.append(expected_channels)
    channel_options += [4,5,6,7,8]
    for dt in ('<f4','<f8','<i2','<u2'):
        item=np.dtype(dt).itemsize
        offsets=list(range(0,min(128,len(raw)),max(item,8)))
        for off in offsets:
            usable=(len(raw)-off)//item*item
            if usable<item*1024: continue
            try:a=np.frombuffer(raw,offset=off,count=min(300000,usable//item),dtype=dt).astype(float)
            except Exception:continue
            finite=np.isfinite(a)
            if finite.mean()<.95:continue
            a=a[finite]
            if dt in ('<i2','<u2'): a=a-np.median(a)
            scale=np.percentile(np.abs(a),99.5)
            if not np.isfinite(scale) or scale<=0:continue
            a=np.clip(a/scale,-5,5)
            for ch in channel_options:
                if a.size<ch*128:continue
                n=(a.size//ch)*ch; b=a[:n].reshape(-1,ch).T
                sample=b[:,:min(10000,b.shape[1])]
                cors=[]
                for x in sample:
                    if x.size>3 and np.std(x)>1e-12:
                        cors.append(np.corrcoef(x[:-1],x[1:])[0,1])
                smooth=np.nanmean(cors) if cors else 0
                balance=np.std(np.std(sample,axis=1))/(np.mean(np.std(sample,axis=1))+1e-9)
                score=float(np.nan_to_num(smooth)-.08*np.nan_to_num(balance)-off/10000)
                candidates.append((score,dt,off,ch,b))
    if not candidates:return None
    score,dt,off,ch,b=max(candidates,key=lambda x:x[0])
    return {'channels':b,'count':ch,'dtype':dt,'offset':off,'score':score,'confidence':'Experimental'}

def channel_spectra_from_streams(streams, points=1024):
    out=[]
    for stream in streams:
        x=np.asarray(stream,float); x=x[np.isfinite(x)]
        if x.size<32: out.append((None,None)); continue
        x=x-np.mean(x)
        n=min(max(256,2**int(np.floor(np.log2(x.size)))),8192)
        x=x[:n]*np.hanning(n)
        y=np.abs(np.fft.rfft(x)); y=y/(np.max(y)+1e-12)
        f=np.linspace(0,1,len(y))
        if len(y)>points:
            idx=np.linspace(0,len(y)-1,points).astype(int); f=f[idx]; y=y[idx]
        out.append((f,y))
    return out

def field(block,label):
    m=re.search(rf'{re.escape(label)}\s*:\s*([^\t\r\n]+)',block,re.I)
    return m.group(1).strip() if m else ''

def parse_review(text):
    blocks=re.split(r'\n-{20,}\n',text.replace('\r',''))
    out=[]
    for b in blocks:
        if 'IMAGING PARAMETERS SCREEN' not in b: continue
        raw_plane=field(b,'Scan Plane') or 'Unknown'
        plane=normalize_plane(raw_plane,b)
        freq=field(b,'Freq. Dir') or 'Unknown'
        slices=field(b,'# Slices')
        if not slices:
            vals=[]
            for p in ('Axial','Sagittal','Coronal'):
                v=field(b,f'# Slices in {p} Plane')
                if v: vals.append(f'{p}:{v}')
            slices=', '.join(vals)
        out.append(MRSeries(
            date=field(b,'date'), time=field(b,'time'), protocol=field(b,'Protocol'),
            description=field(b,'Series De'), plane=plane,
            freq_dir=freq, image_mode=field(b,'Image Mode'), pulse_sequence=field(b,'Pulse Seq'),
            psd_name=field(b,'Psd Name'), coil=field(b,'Coil Name'), fov=field(b,'Field of View'),
            thickness=field(b,'Slice Thickness'), slices=slices, matrix=field(b,'Acq. Matrix'),
            start_loc=field(b,'Start Loc'), end_loc=field(b,'End Loc'), center_fov=field(b,'Center of FOV'),
            raw_plane=raw_plane, series_no=field(b,'Series Number') or field(b,'Series No'),
            scan_time=field(b,'Scan Time'), acquisitions=field(b,'# Acquisitions')))
    return out



def normalize_freq(value):
    text=str(value or '').upper().replace(' ', '').replace('\\','/').replace('-','/')
    aliases={'RL':'R/L','LR':'L/R','AP':'A/P','PA':'P/A','SI':'S/I','IS':'I/S'}
    compact=text.replace('/','')
    if compact in aliases:return aliases[compact]
    if 'ROW' in text:return 'ROW'
    if 'COL' in text:return 'COL'
    return text if text in FREQ_OPTIONS else 'Unknown'

def is_thermometry_series(m):
    text=' '.join((m.protocol,m.description,m.psd_name,m.pulse_sequence,m.image_mode)).upper()
    return any(k in text for k in ('TMAP','MEMP','THERM','TEMP MAP','TEMPERATURE'))

def geometry_compatible(required_plane,required_freq,candidate_plane,candidate_freq):
    rp=normalize_plane(required_plane); cp=normalize_plane(candidate_plane)
    rf=normalize_freq(required_freq); cf=normalize_freq(candidate_freq)
    plane_ok=rp=='Unknown' or cp=='Unknown' or rp==cp
    freq_ok=rf=='Unknown' or cf=='Unknown' or rf in ('ROW','COL') or cf in ('ROW','COL') or rf==cf
    return plane_ok,freq_ok

def parse_xml_rows(text):
    rows=[]
    for m in re.finditer(r'<[^>]*?:?row\s+([^>]+)/?>',text,re.I):
        attrs={k.lower():v for k,v in re.findall(r'(\w+)="([^"]*)"',m.group(1))}
        rows.append(attrs)
    return rows

def parse_sonication_metadata(zf,names):
    out={}
    for n in names:
        bn=Path(n).name.lower()
        if bn not in ('sonicationdata.xml','sonicationsummary.xml','mriimageparams.xml','imagedataitem.xml'): continue
        try:text=zf.read(n).decode('utf-8','ignore')
        except Exception:continue
        for a in parse_xml_rows(text):
            no=a.get('sonicationindex') or a.get('sonication')
            if not no or not str(no).isdigit():continue
            d=out.setdefault(str(int(no)),{'evidence':[]})
            d['evidence'].append(n)
            for key in ('treatprotocol','scanplane','protocol','actualduration','measuredpower','measuredenergy','maxmaxtemp','maxaveragetemp','frequency','scannormalx','scannormaly','scannormalz','freqdirection','seriesdiscription','imgmatrixx','imgmatrixy','pixsizex','pixsizey','slicethick','tempimagesnum','magimagesnum','tempimagestimes'):
                if key in a and a[key]!='': d[key]=a[key]
    for no,d in out.items():
        proto=' '.join(str(d.get(k,'')) for k in ('treatprotocol','protocol','seriesdiscription')).lower()
        if 'dqa' in proto:
            d['phase']='DQA'; d['phase_confidence']='High'; d['phase_reason']='Explicit DQA protocol in XML metadata'
        rawplane=d.get('scanplane') or d.get('seriesdiscription','')
        if rawplane:
            d['plane']=normalize_plane(rawplane)
        # A scan normal is the strongest orientation evidence.
        try:
            normal=[abs(float(d.get('scannormalx',0))),abs(float(d.get('scannormaly',0))),abs(float(d.get('scannormalz',0)))]
            if max(normal)>0:
                axis=int(np.argmax(normal)); d['plane']=['Sagittal','Coronal','Axial'][axis]; d['plane_reason']=f'Scan normal {normal}'
        except Exception:pass
    return out

def classify_session(sonics):
    """Conservative DQA/Treatment split. A long workflow gap is the strongest signal.
    Low-power/test-looking sonications before that gap are DQA. Without a clear transition,
    keep the complete short session as DQA and expose manual override.
    """
    if not sonics: return {}
    gaps=[]
    for i in range(1,len(sonics)):
        gaps.append((time_seconds(sonics[i].time)-time_seconds(sonics[i-1].time),i))
    transition=None
    if gaps:
        gap,idx=max(gaps)
        if gap>=15*60: transition=idx
    out={}
    for i,son in enumerate(sonics):
        if transition is not None:
            phase='DQA' if i<transition else 'Treatment'
            confidence='High' if max(gaps)[0]>=30*60 else 'Medium'
            reason=f'workflow time gap before Sonication {transition}' if i>=transition else f'pre-treatment group before {max(gaps)[0]/60:.1f} min gap'
        else:
            phase='DQA'
            confidence='Medium' if len(sonics)<=6 else 'Low'
            reason='short continuous test/phantom-like session; no reliable patient-treatment transition found'
        out[str(son.no)]={'phase':phase,'confidence':confidence,'reason':reason}
    return out

def scan_timing_evidence(text,name):
    rows=[]; offsets=[]
    keys=('sonication','thermo','temperature','acquisition','scan','offset','time difference','clock')
    for line in text.replace('\r','').splitlines():
        low=line.lower()
        if any(k in low for k in keys):
            if len(rows)<3000: rows.append(f'{name}: {line.strip()}')
            # Accept explicit MR/FUS offset statements only; preserve direction as evidence.
            m=re.search(r'(?:mr.{0,20}fus|fus.{0,20}mr|time\s*(?:difference|offset)|clock\s*offset)[^+\-\d]{0,30}([+\-]?\d+(?:\.\d+)?)\s*(ms|msec|s|sec)',line,re.I)
            if m:
                v=float(m.group(1)); unit=m.group(2).lower();
                if unit.startswith('m'): v/=1000.0
                offsets.append((v,f'{name}: {line.strip()}'))
    return rows,offsets

def parse_mrserver(text,name):
    events=[]
    for line in text.replace('\r','').splitlines():
        if any(k in line for k in ('LoadProtocol','SetRxGeometry3p','Series type =','scanner=scanning','acquisition=complete','recon=done','SetCVs=')):
            events.append(f'{name}: {line.strip()}')
    return events

class Plot(Canvas):
    def __init__(self):
        self.fig=Figure(figsize=(5,4),tight_layout=True); super().__init__(self.fig)

class Main(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle('FUS Treatment Replay & Evidence Review - RC1.5 Sync Resolver'); self.resize(1580,940)
        self.zf=None; self.zip_path=None; self.sonics=[]; self.spectrum_files=[]; self.spectrum_msg_files=[]; self.reflection_files=[]; self.inventory=[]; self.raw_files=[]
        self.spec_cache={}; self.mr_series=[]; self.mrserver_events=[]; self.timing_evidence=[]; self.ws_offsets=[]; self.auto_phase={}; self.son_meta={}; self.manual={}; self.external_images={}
        self._updating=False
        self.raw_replay_cache={}; self.thermo_source_cache={}; self.sync_matches={}
        self.thermo_cache={}
        self.visible_sonics=[]
        self.cav_span=None
        self.cav_selected_range=None
        self.cav_current_streams=None
        self.cav_current_duration=0.0
        self.build_ui()

    def build_ui(self):
        w=QWidget(); self.setCentralWidget(w); lay=QVBoxLayout(w)
        top=QHBoxLayout(); lay.addLayout(top)
        b=QPushButton('Open Treatment ZIP'); b.clicked.connect(self.open_zip); top.addWidget(b)
        add=QPushButton('Add MR Images / DICOM Folder'); add.clicked.connect(self.add_mr_images); top.addWidget(add)
        save=QPushButton('Save Review Mapping'); save.clicked.connect(self.save_mapping); top.addWidget(save)
        self.info=QLabel('No data loaded'); top.addWidget(self.info,1)
        self.show_dqa=QCheckBox('Show DQA')
        self.show_dqa.setChecked(False)
        self.show_dqa.toggled.connect(self.populate)
        top.addWidget(self.show_dqa)
        badge=QLabel('REVIEW / RESEARCH ONLY — NOT FOR CLINICAL DECISIONS'); badge.setStyleSheet('font-weight:bold;color:#b00020'); top.addWidget(badge)

        split=QSplitter(); lay.addWidget(split,1)
        left=QWidget(); ll=QVBoxLayout(left)
        self.table=QTableWidget(0,12); self.table.setHorizontalHeaderLabels(['No.','Phase','Confidence','Start','Duration','Power','Avg','Freq.','F.D.','Status','MR Plane','Freq Dir'])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); self.table.currentCellChanged.connect(self.select_row)
        self.table.setHorizontalScrollMode(QTableWidget.ScrollPerPixel); self.table.setVerticalScrollMode(QTableWidget.ScrollPerPixel)
        ll.addWidget(self.table,3)
        detail_box=QGroupBox('Selected Sonication Details — fixed')
        dg=QGridLayout(detail_box); self.detail_labels={}
        fields=[('Sonication','sonication'),('Phase','phase'),('Start','start'),('Status','status'),('Duration','duration'),('Power','power'),('Average / Max','avgmax'),('Frequency','frequency'),('Focal distance','fd'),('Position','position'),('MR plane / Freq','mrfreq'),('Replay source','replay_source'),('Spectrum source','spectrum')]
        for i,(title,key) in enumerate(fields):
            r=i//2; c=(i%2)*2
            dg.addWidget(QLabel(title),r,c)
            lab=QLabel('—'); lab.setWordWrap(True); lab.setTextInteractionFlags(Qt.TextSelectableByMouse)
            self.detail_labels[key]=lab; dg.addWidget(lab,r,c+1)
        ll.addWidget(detail_box,0)
        nav=QHBoxLayout(); ll.addLayout(nav)
        prev=QPushButton('◀ Previous'); prev.clicked.connect(lambda:self.move_row(-1)); nav.addWidget(prev)
        nxt=QPushButton('Next ▶'); nxt.clicked.connect(lambda:self.move_row(1)); nav.addWidget(nxt)
        split.addWidget(left)

        right=QWidget(); rl=QVBoxLayout(right)
        controls=QGroupBox('Selected Sonication — MR Geometry Mapping'); form=QGridLayout(controls)
        self.source_label=QLabel('Source: unavailable'); form.addWidget(self.source_label,0,0,1,4)
        form.addWidget(QLabel('DQA / Treatment'),1,0); self.phase_combo=QComboBox(); self.phase_combo.addItems(PHASE_OPTIONS); self.phase_combo.currentTextChanged.connect(self.phase_changed); form.addWidget(self.phase_combo,1,1)
        self.phase_evidence=QLabel(''); self.phase_evidence.setWordWrap(True); form.addWidget(self.phase_evidence,1,2,1,2)
        form.addWidget(QLabel('Scan plane'),2,0); self.plane_combo=QComboBox(); self.plane_combo.addItems(PLANE_OPTIONS); self.plane_combo.currentTextChanged.connect(self.mapping_changed); form.addWidget(self.plane_combo,2,1)
        form.addWidget(QLabel('Frequency direction'),2,2); self.freq_combo=QComboBox(); self.freq_combo.addItems(FREQ_OPTIONS); self.freq_combo.currentTextChanged.connect(self.mapping_changed); form.addWidget(self.freq_combo,2,3)
        form.addWidget(QLabel('MR series'),3,0); self.series_combo=QComboBox(); self.series_combo.currentIndexChanged.connect(self.series_changed); form.addWidget(self.series_combo,3,1,1,3)
        self.use_auto=QCheckBox('Use automatically matched review.out / mrserver information when available'); self.use_auto.setChecked(True); self.use_auto.toggled.connect(self.refresh_selected); form.addWidget(self.use_auto,4,0,1,4)
        rl.addWidget(controls)
        self.tabs=QTabWidget(); rl.addWidget(self.tabs,1)
        self.imgplot=Plot(); self.tabs.addTab(self.imgplot,'MR / Hotspot Replay')
        self.thermopage=QWidget(); thl=QVBoxLayout(self.thermopage); thc=QHBoxLayout(); thl.addLayout(thc)
        thc.addWidget(QLabel('Thermometry frame')); self.thermo_slider=QSlider(Qt.Horizontal); self.thermo_slider.setMinimum(0); self.thermo_slider.setMaximum(0); self.thermo_slider.valueChanged.connect(self.draw_thermometry); thc.addWidget(self.thermo_slider,1)
        self.thermo_frame_label=QLabel('No frame'); thc.addWidget(self.thermo_frame_label)
        thc.addWidget(QLabel('Display')); self.thermo_mode=QComboBox(); self.thermo_mode.addItems(['Baseline / Current / Difference','Magnitude candidate','Phase-difference candidate','Temperature-rise candidate']); self.thermo_mode.currentTextChanged.connect(self.draw_thermometry); thc.addWidget(self.thermo_mode)
        self.thermo_note=QLabel(''); self.thermo_note.setWordWrap(True); thl.addWidget(self.thermo_note)
        self.thermoplot=Plot(); thl.addWidget(self.thermoplot,1); self.tabs.addTab(self.thermopage,'Thermometry Replay')
        self.overview=QTextEdit(); self.overview.setReadOnly(True); self.tabs.addTab(self.overview,'Maximum Information')
        self.mrtable=QTableWidget(0,12); self.mrtable.setHorizontalHeaderLabels(['Time','Description','Plane','Freq Dir','Mode','Sequence','PSD','Coil','FOV','Thickness','Slices','Matrix']); self.mrtable.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); self.tabs.addTab(self.mrtable,'MR Series from review.out')
        self.cavpage=QWidget(); cavl=QVBoxLayout(self.cavpage)
        cavtop=QHBoxLayout(); cavl.addLayout(cavtop)
        cavtop.addWidget(QLabel('Channels'))
        self.hp_checks=[]
        for i in range(8):
            cb=QCheckBox(f'Ch {i+1}'); cb.setChecked(i<4); cb.toggled.connect(self.refresh_selected); self.hp_checks.append(cb); cavtop.addWidget(cb)
        self.cav_metrics_toggle=QToolButton(); self.cav_metrics_toggle.setText('Show channel metrics'); self.cav_metrics_toggle.setCheckable(True); self.cav_metrics_toggle.toggled.connect(self.refresh_selected); cavtop.addWidget(self.cav_metrics_toggle)
        cavtop.addStretch(1)
        self.cav_range_label=QLabel('Drag across the activity chart to calculate FFT for a selected time range.'); cavl.addWidget(self.cav_range_label)
        self.cavplot=Plot(); cavl.addWidget(self.cavplot,1); self.tabs.addTab(self.cavpage,'Hydrophone Cavitation')
        self.specpage=QWidget(); spl=QVBoxLayout(self.specpage); sc=QHBoxLayout(); spl.addLayout(sc)
        sc.addWidget(QLabel('Interval')); self.spec_interval=QComboBox(); self.spec_interval.addItems(SPECTRUM_INTERVALS); self.spec_interval.currentTextChanged.connect(self.refresh_selected); sc.addWidget(self.spec_interval)
        sc.addWidget(QLabel('Hydrophone')); self.hp_combo=QComboBox(); self.hp_combo.addItems(['Auto / FUS-selected']+[f'Hydrophone {i}' for i in range(1,9)]); self.hp_combo.currentTextChanged.connect(self.refresh_selected); sc.addWidget(self.hp_combo)
        sc.addWidget(QLabel('Display')); self.spec_display=QComboBox(); self.spec_display.addItems(SPECTRUM_DISPLAY); self.spec_display.currentTextChanged.connect(self.refresh_selected); sc.addWidget(self.spec_display)
        sc.addWidget(QLabel('Y axis')); self.spec_y=QComboBox(); self.spec_y.addItems(SPECTRUM_Y); self.spec_y.currentTextChanged.connect(self.refresh_selected); sc.addWidget(self.spec_y); sc.addStretch(1)
        sch=QHBoxLayout(); spl.addLayout(sch); sch.addWidget(QLabel('Visible channels'))
        self.spec_checks=[]
        for i in range(8):
            cb=QCheckBox(f'Ch {i+1}'); cb.setChecked(i<4); cb.toggled.connect(self.refresh_selected); self.spec_checks.append(cb); sch.addWidget(cb)
        sch.addStretch(1)
        self.spec_note=QLabel(''); self.spec_note.setWordWrap(True); spl.addWidget(self.spec_note)
        self.specplot=Plot(); spl.addWidget(self.specplot,1); self.tabs.addTab(self.specpage,'Spectrum')
        self.timeline=Plot(); self.tabs.addTab(self.timeline,'DQA / Treatment Timeline')
        self.syncinfo=QTextEdit(); self.syncinfo.setReadOnly(True); self.tabs.addTab(self.syncinfo,'Time Synchronization')
        self.evidence=QTextEdit(); self.evidence.setReadOnly(True); self.tabs.addTab(self.evidence,'mrserver / Raw Evidence')
        self.coverage=QTableWidget(0,4); self.coverage.setHorizontalHeaderLabels(['Data domain','Status','Evidence count','Notes']); self.coverage.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); self.tabs.addTab(self.coverage,'Data Coverage')
        self.inventory_table=QTableWidget(0,8); self.inventory_table.setHorizontalHeaderLabels(['Path','Size','Category','Sonication','Extension','Signature','Candidate layout','Status']); self.inventory_table.horizontalHeader().setSectionResizeMode(0,QHeaderView.Stretch); self.inventory_table.itemSelectionChanged.connect(self.inventory_selected); self.tabs.addTab(self.inventory_table,'Complete Inventory')
        self.rawpage=QWidget(); rawlay=QVBoxLayout(self.rawpage); rawtop=QHBoxLayout(); rawlay.addLayout(rawtop); rawtop.addWidget(QLabel('RAW candidate')); self.raw_combo=QComboBox(); self.raw_combo.currentIndexChanged.connect(self.draw_raw_candidate); rawtop.addWidget(self.raw_combo,1); self.raw_meta=QLabel('No RAW selected'); self.raw_meta.setWordWrap(True); rawlay.addWidget(self.raw_meta); self.rawplot=Plot(); rawlay.addWidget(self.rawplot,1); self.tabs.addTab(self.rawpage,'RAW Investigation')
        self.details=QTextEdit(); self.details.setReadOnly(True); self.tabs.addTab(self.details,'Sonication Details')
        split.addWidget(right); split.setSizes([530,1050])

    def open_zip(self):
        p,_=QFileDialog.getOpenFileName(self,'Open FUS ZIP','','ZIP files (*.zip)')
        if p:self.load_zip(p)

    def load_zip(self,p):
        try:
            if self.zf:self.zf.close()
            self.zf=zipfile.ZipFile(p); self.zip_path=Path(p); names=self.zf.namelist()
            sums=[n for n in names if '/Summary_' in n and n.lower().endswith('.txt')]
            if not sums: sums=[n for n in names if Path(n).name.lower().startswith('summary_') and n.lower().endswith('.txt')]
            if not sums: raise ValueError('Treatment Summary file was not found')
            self.sonics=parse_summary(self.zf.read(sums[0]).decode('utf-8','ignore'))
            self.spectrum_files=[n for n in names if n.endswith('.dmp_FFT')]
            self.spectrum_msg_files=[n for n in names if 'spectrummsg' in Path(n).name.lower() and not n.endswith('/')]
            self.reflection_files=[n for n in names if 'reflection' in n.lower() and not n.endswith('/')]
            self.inventory=make_inventory(self.zf); self.raw_files=[i.path for i in self.inventory if i.category=='MR / Thermometry RAW']
            self.mr_series=[]
            for n in names:
                if Path(n).name.lower() in ('review.out','review.out.ar'):
                    try:
                        parsed=parse_review(self.zf.read(n).decode('utf-8','ignore'))
                        if parsed: self.mr_series=parsed; break
                    except Exception: pass
            self.mrserver_events=[]; self.timing_evidence=[]; self.ws_offsets=[]
            for n in names:
                if 'mrserver' in Path(n).name.lower() and n.lower().endswith('.log'):
                    try:self.mrserver_events += parse_mrserver(self.zf.read(n).decode('utf-8','ignore'),Path(n).name)
                    except Exception:pass
            # Search WS, WaterSystem, acquisition and sonication logs for timing evidence and explicit MR/FUS clock offsets.
            for n in names:
                bn=Path(n).name.lower()
                if n.endswith('/') or not (bn.endswith('.log') or bn.endswith('.txt')): continue
                if not any(k in n.lower() for k in ('wsfiles/','watersystem','acquisition','sonication')): continue
                try:
                    rows,offs=scan_timing_evidence(self.zf.read(n).decode('utf-8','ignore'),Path(n).name)
                    self.timing_evidence += rows; self.ws_offsets += offs
                except Exception: pass
            self.auto_phase=classify_session(self.sonics)
            self.son_meta=parse_sonication_metadata(self.zf,names)
            for no,meta in self.son_meta.items():
                if meta.get('phase'):
                    self.auto_phase[no]={'phase':meta['phase'],'confidence':meta.get('phase_confidence','High'),'reason':meta.get('phase_reason','XML metadata')}
            self.spec_cache={}; self.raw_replay_cache={}; self.thermo_source_cache={}; self.sync_matches={}; self.manual={}; self.external_images={}; self.load_mapping()
            self.populate()
            self.info.setText(f'{self.zip_path.name} | {len(self.sonics)} sonications | {len(self.inventory)} files | {len(self.raw_files)} RAW | {len(self.mr_series)} MR series | {len(self.spectrum_files)} FFT | {len(self.spectrum_msg_files)} SpectrumMsg')
            self.draw_timeline(); self.show_mr_table(); self.show_evidence(); self.show_sync(); self.show_inventory(); self.show_coverage(); self.populate_raw_combo()
            if self.visible_sonics:self.table.selectRow(0)
        except Exception as e: QMessageBox.critical(self,'Load error',str(e))

    def populate(self,*args):
        self._updating=True
        selected_no=None
        r=self.table.currentRow()
        if 0<=r<len(self.visible_sonics): selected_no=self.visible_sonics[r].no
        self.visible_sonics=[x for x in self.sonics if self.show_dqa.isChecked() or self.effective_phase(x)=='Treatment']
        self.table.setRowCount(len(self.visible_sonics)); self.series_combo.clear(); self.series_combo.addItem('No linked MR series',-1)
        for i,m in enumerate(self.mr_series): self.series_combo.addItem(f'{m.time} | {m.description or m.protocol} | {m.plane} | {m.freq_dir}',i)
        for r,s in enumerate(self.visible_sonics):
            auto=self.auto_series_index(s); m=self.mr_series[auto] if auto is not None else None
            man=self.manual.get(str(s.no),{})
            ap=self.auto_phase.get(str(s.no),{'phase':'DQA','confidence':'Low'})
            phase=man.get('phase') or ap['phase']
            meta=self.son_meta.get(str(s.no),{})
            vals=[s.no,phase,ap.get('confidence',''),s.time,f'{float(meta.get("actualduration",s.duration)):.2f}',f'{s.power:.1f}',f'{float(meta.get("measuredpower",s.avg_power)):.1f}',f'{s.freq:.3f}',f'{s.fd:.1f}',s.status,man.get('plane') or meta.get('plane') or (m.plane if m else 'Unknown'),man.get('freq_dir') or meta.get('freqdirection') or (m.freq_dir if m else 'Unknown')]
            for c,v in enumerate(vals):self.table.setItem(r,c,QTableWidgetItem(str(v)))
        self._updating=False
        if self.visible_sonics:
            idx=next((i for i,x in enumerate(self.visible_sonics) if x.no==selected_no),0)
            self.table.selectRow(idx)
        else:
            for lab in self.detail_labels.values(): lab.setText('—')

    def offset_candidates(self):
        vals=[float(v) for v,_ in self.ws_offsets if np.isfinite(v)]
        if not vals:return [(0.0,'No explicit offset')]
        med=float(np.median(vals))
        return [(med,'MR + WS offset'),(-med,'MR - WS offset'),(0.0,'Uncorrected')]

    def resolve_series_match(self,s):
        key=str(s.no)
        if key in self.sync_matches:return self.sync_matches[key]
        if not self.mr_series:
            result=SyncMatch(reasons=['No review.out MR series available'])
            self.sync_matches[key]=result; return result
        meta=self.son_meta.get(key,{})
        req_plane=normalize_plane(meta.get('plane') or meta.get('scanplane') or 'Unknown')
        req_freq=normalize_freq(meta.get('freqdirection') or 'Unknown')
        target=time_seconds(s.time); evaluated=[]
        for i,m in enumerate(self.mr_series):
            mt=time_seconds(m.time) if m.time else 0
            plane_ok,freq_ok=geometry_compatible(req_plane,req_freq,m.plane,m.freq_dir)
            protocol_ok=is_thermometry_series(m); best=None
            for off,desc in self.offset_candidates():
                gap=target-(mt+off); score=0.0; reasons=[]
                if protocol_ok:score+=120; reasons.append('TMAP/MEMP thermometry protocol')
                else:score-=35
                if req_plane!='Unknown':
                    if plane_ok:score+=100; reasons.append('plane match '+req_plane)
                    else:score-=500; reasons.append('plane mismatch '+m.plane)
                if req_freq!='Unknown':
                    if freq_ok:score+=80; reasons.append('frequency compatible '+req_freq)
                    else:score-=400; reasons.append('frequency mismatch '+m.freq_dir)
                if -2<=gap<=45:score+=100-max(0,abs(gap-10))*2.5; reasons.append(f'expected baseline window {gap:+.2f}s')
                elif -10<=gap<=90:score+=25-max(0,abs(gap-10))*.5; reasons.append(f'nearby acquisition {gap:+.2f}s')
                else:score-=min(abs(gap),600)*.35
                xml_desc=str(meta.get('seriesdiscription','')).lower(); text=(' '.join((m.description,m.protocol,m.series_no))).lower()
                if xml_desc and any(tok in text for tok in re.findall(r'[a-z0-9]+',xml_desc) if len(tok)>3):score+=70; reasons.append('XML series description match')
                cand=(score,i,gap,off,desc,plane_ok,freq_ok,protocol_ok,reasons)
                if best is None or score>best[0]:best=cand
            evaluated.append(best)
        evaluated.sort(key=lambda x:x[0],reverse=True); best=evaluated[0]
        confidence='High' if best[0]>=250 else ('Medium' if best[0]>=140 else 'Low')
        rejected=[]
        for e in evaluated[1:6]:
            mm=self.mr_series[e[1]]; rejected.append(f'{mm.time} {mm.description or mm.protocol}: score {e[0]:.1f}; plane={mm.plane}; freq={mm.freq_dir}; gap={e[2]:+.2f}s')
        result=SyncMatch(best[1],best[0],confidence,best[2],best[3],best[4],best[5],best[6],best[7],best[8],rejected)
        if not best[5] or not best[6]:result.series_index=-1; result.confidence='Low'; result.reasons.append('Auto-link rejected by geometry gate')
        self.sync_matches[key]=result; return result

    def auto_series_index(self,s):
        match=self.resolve_series_match(s)
        return match.series_index if match.series_index>=0 else None

    def raw_geometry_allowed(self,s):
        meta=self.son_meta.get(str(s.no),{})
        required_plane=normalize_plane(meta.get('plane') or meta.get('scanplane') or self.plane_combo.currentText())
        required_freq=normalize_freq(meta.get('freqdirection') or self.freq_combo.currentText())
        displayed_plane=normalize_plane(self.plane_combo.currentText()); displayed_freq=normalize_freq(self.freq_combo.currentText())
        plane_ok,freq_ok=geometry_compatible(required_plane,required_freq,displayed_plane,displayed_freq)
        reasons=[]
        if not plane_ok:reasons.append(f'plane mismatch: RAW {required_plane}, display {displayed_plane}')
        if not freq_ok:reasons.append(f'frequency mismatch: RAW {required_freq}, display {displayed_freq}')
        if required_plane=='Unknown':reasons.append('RAW plane is unconfirmed')
        if required_freq=='Unknown':reasons.append('RAW frequency direction is unconfirmed')
        return plane_ok and freq_ok and required_plane!='Unknown' and required_freq!='Unknown',reasons,required_plane,required_freq

    def select_row(self,row,col,pr,pc):
        if 0<=row<len(self.visible_sonics):
            if row!=pr:self.cav_selected_range=None
            self.refresh_selected()

    def refresh_selected(self,*args):
        row=self.table.currentRow()
        if not (0<=row<len(self.visible_sonics)):return
        s=self.visible_sonics[row]; man=self.manual.get(str(s.no),{}); auto=self.auto_series_index(s); chosen=man.get('series_index',auto if auto is not None else -1)
        self._updating=True
        ap=self.auto_phase.get(str(s.no),{'phase':'DQA','confidence':'Low','reason':'No evidence'})
        self.phase_combo.setCurrentText(man.get('phase','Auto'))
        effective=man.get('phase') or ap['phase']
        self.phase_evidence.setText(f'Effective: {effective} | Confidence: {ap.get("confidence","Low")} | {ap.get("reason","")}')
        self.series_combo.setCurrentIndex(self.series_combo.findData(chosen))
        m=self.mr_series[chosen] if isinstance(chosen,int) and 0<=chosen<len(self.mr_series) else None
        meta=self.son_meta.get(str(s.no),{})
        plane=man.get('plane') or meta.get('plane') or (m.plane if m and self.use_auto.isChecked() else 'Unknown')
        freq=man.get('freq_dir') or meta.get('freqdirection') or (m.freq_dir if m and self.use_auto.isChecked() else 'Unknown')
        self.plane_combo.setCurrentText(normalize_plane(plane) if plane not in PLANE_OPTIONS else plane)
        self.freq_combo.setCurrentText(freq if freq in FREQ_OPTIONS else 'Unknown')
        source=[]
        if meta:source.append('sonication XML metadata')
        match=self.resolve_series_match(s)
        if m and self.use_auto.isChecked():source.append(f'review.out synchronized match ({match.confidence}, gap {match.corrected_gap:+.2f}s)')
        elif self.use_auto.isChecked() and match.reasons:source.append('MR auto-match rejected')
        if man:source.append('manual override')
        if str(s.no) in self.external_images:source.append('external MR image')
        self.source_label.setText('Source: '+(', '.join(source) if source else 'simulation / not available'))
        self._updating=False
        self.draw_image(s,m); self.prepare_thermometry(s); self.draw_thermometry(); self.draw_cavitation(s); self.draw_spectrum(s); self.show_details(s,m); self.show_overview(s,m)

    def phase_changed(self,*args):
        if self._updating:return
        row=self.table.currentRow()
        if not (0<=row<len(self.visible_sonics)):return
        son=self.visible_sonics[row]; value=self.phase_combo.currentText(); d=self.manual.setdefault(str(son.no),{})
        if value=='Auto': d.pop('phase',None)
        else: d['phase']=value
        ap=self.auto_phase.get(str(son.no),{'phase':'DQA'})
        self.table.item(row,1).setText(d.get('phase') or ap['phase'])
        self.draw_timeline(); self.populate()

    def mapping_changed(self,*args):
        if self._updating:return
        row=self.table.currentRow()
        if not (0<=row<len(self.visible_sonics)):return
        s=self.visible_sonics[row]; d=self.manual.setdefault(str(s.no),{})
        d['plane']=self.plane_combo.currentText(); d['freq_dir']=self.freq_combo.currentText()
        self.table.item(row,10).setText(d['plane']); self.table.item(row,11).setText(d['freq_dir']); self.refresh_selected()

    def series_changed(self,*args):
        if self._updating:return
        row=self.table.currentRow()
        if not (0<=row<len(self.visible_sonics)):return
        s=self.visible_sonics[row]; self.manual.setdefault(str(s.no),{})['series_index']=self.series_combo.currentData(); self.refresh_selected()

    def move_row(self,d):
        if not self.visible_sonics:return
        r=max(0,min(len(self.visible_sonics)-1,self.table.currentRow()+d)); self.table.selectRow(r)

    def add_mr_images(self):
        if not self.visible_sonics:return
        p=QFileDialog.getExistingDirectory(self,'Select DICOM / MR image folder')
        if not p:return
        files=[]
        for x in Path(p).rglob('*'):
            if x.is_file() and x.suffix.lower() in ('.dcm','.ima','.png','.jpg','.jpeg','.bmp','.tif','.tiff'): files.append(str(x))
        if not files: QMessageBox.information(self,'MR import','No supported MR/DICOM image files were found.'); return
        row=self.table.currentRow(); s=self.visible_sonics[row]
        self.external_images[str(s.no)]={'folder':p,'files':files[:5000]}
        QMessageBox.information(self,'MR import',f'{len(files)} files registered for Sonication {s.no}.\nThe mapping is saved in the review sidecar JSON.\nPixel rendering of ordinary PNG/JPEG is enabled; DICOM metadata/pixel support is reserved for the pydicom option.')
        self.refresh_selected()

    def mapping_path(self):return self.zip_path.with_suffix('.fus_review.json') if self.zip_path else None
    def save_mapping(self):
        if not self.zip_path:return
        data={'zip':self.zip_path.name,'manual':self.manual,'external_images':self.external_images,'saved_at':datetime.now().isoformat(timespec='seconds'),'schema_version':5}
        self.mapping_path().write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
        QMessageBox.information(self,'Saved',f'Review mapping saved:\n{self.mapping_path()}')
    def load_mapping(self):
        p=self.mapping_path()
        if p and p.exists():
            try:
                d=json.loads(p.read_text(encoding='utf-8')); self.manual=d.get('manual',{}); self.external_images=d.get('external_images',{})
            except Exception:pass

    def effective_phase(self,s):
        d=self.manual.get(str(s.no),{}); return d.get('phase') or self.auto_phase.get(str(s.no),{}).get('phase','DQA')

    def sonication_folder_pattern(self,s):
        # Exact folder ownership is the primary reconstruction key.  Do not infer
        # ownership only because the same number appears somewhere in a filename.
        return re.compile(rf'(^|[\\/])sonication[_ -]?0*{int(s.no)}([\\/]|$)',re.I)

    def sonication_folder_files(self,s):
        pat=self.sonication_folder_pattern(s)
        return [n for n in self.zf.namelist() if pat.search(n)] if self.zf else []

    def raw_paths_for_sonication(self,s,allow_fallback=False):
        pat=self.sonication_folder_pattern(s)
        paths=[n for n in self.raw_files if pat.search(n)]
        source='Same Sonication folder'
        if not paths and allow_fallback:
            # Fallback is intentionally conservative and remains lower priority.
            paths=[n for n in self.raw_files if re.search(rf'(^|\D)0*{int(s.no)}(\D|$)',Path(n).stem)]
            source='Filename-number fallback'
        def natural(x):
            return [int(v) if v.isdigit() else v.lower() for v in re.split(r'(\d+)',x)]
        return sorted(paths,key=natural),source

    def raw_frame_groups_for_sonication(self,s):
        paths,source=self.raw_paths_for_sonication(s,allow_fallback=False)
        groups={}
        for n in paths:
            try:r=try_render_raw(self.zf.read(n))
            except Exception:continue
            if not r:continue
            score,dt,w,h,img=r
            # Group by actual binary geometry first.  Filename indices are retained
            # only as ordering evidence and are not interpreted semantically yet.
            key=(dt,w,h)
            groups.setdefault(key,[]).append({'path':n,'score':score,'dtype':dt,'width':w,'height':h,'image':img})
        for frames in groups.values():
            frames.sort(key=lambda fr:[int(v) if v.isdigit() else v.lower() for v in re.split(r'(\d+)',fr['path'])])
        ranked=sorted(groups.items(),key=lambda kv:(len(kv[1]),float(np.median([x['score'] for x in kv[1]]))),reverse=True)
        return ranked,source

    def best_raw_for_sonication(self,s):
        key=str(s.no)
        if key in self.raw_replay_cache:return self.raw_replay_cache[key]
        ranked,source=self.raw_frame_groups_for_sonication(s)
        best=None
        if ranked:
            geometry,frames=ranked[0]
            # Prefer a strong representative from the dominant sequence, not an
            # unrelated high-scoring image elsewhere in the ZIP.
            rep=max(frames,key=lambda fr:fr['score'])
            result=(rep['score'],rep['path'],(rep['score'],rep['dtype'],rep['width'],rep['height'],rep['image']),source,len(frames),geometry)
            best=result
        self.raw_replay_cache[key]=best
        return best

    def prepare_thermometry(self,s):
        key=str(s.no)
        if key not in self.thermo_cache:
            ranked,source=self.raw_frame_groups_for_sonication(s)
            paths=[]
            frames=[]
            if ranked:
                _,frames=ranked[0]
                self.thermo_cache[key]=frames
                self.thermo_source_cache[key]={'source':source,'group_count':len(ranked),'frame_count':len(frames),'geometry':ranked[0][0]}
            else:
                self.thermo_cache[key]=[]
                self.thermo_source_cache[key]={'source':'No same-folder RAW sequence','group_count':0,'frame_count':0,'geometry':None}
            frames=self.thermo_cache[key]
            # The dominant consistent group is already decoded above.
            sample_paths=[]
            # Same-folder dominant frame group is the primary thermometry sequence.
        frames=self.thermo_cache.get(key,[])
        self.thermo_slider.blockSignals(True)
        self.thermo_slider.setMaximum(max(0,len(frames)-1))
        self.thermo_slider.setValue(min(self.thermo_slider.value(),max(0,len(frames)-1)))
        self.thermo_slider.blockSignals(False)

    def draw_thermometry(self,*args):
        row=self.table.currentRow()
        f=self.thermoplot.fig; f.clear()
        if not (0<=row<len(self.visible_sonics)):
            self.thermoplot.draw(); return
        s=self.visible_sonics[row]; frames=self.thermo_cache.get(str(s.no),[])
        if len(frames)<2:
            ax=f.add_subplot(111); ax.text(.5,.5,'No consistent RAW frame sequence could be reconstructed',ha='center',va='center',transform=ax.transAxes); ax.axis('off')
            self.thermo_frame_label.setText('No frame')
            self.thermo_note.setText(f'No consistent RAW sequence was decoded inside Sonication{s.no}. Cross-folder/time-near RAW is not substituted automatically. Thermometry requires a baseline phase image and subsequent phase/magnitude frames.')
            self.thermoplot.draw(); return
        i=max(0,min(self.thermo_slider.value(),len(frames)-1)); base=frames[0]['image']; cur=frames[i]['image']
        # Wrapped normalized difference is a structural candidate only. Celsius conversion requires phase scale, TE, field strength and PRF coefficient.
        diff=cur-base
        lim=max(float(np.percentile(np.abs(diff),99)),1e-6)
        mode=self.thermo_mode.currentText()
        self.thermo_frame_label.setText(f'{i+1} / {len(frames)}')
        if mode=='Baseline / Current / Difference':
            axes=[f.add_subplot(1,3,j+1) for j in range(3)]
            axes[0].imshow(base,cmap='gray'); axes[0].set_title('Baseline phase/magnitude candidate')
            axes[1].imshow(cur,cmap='gray'); axes[1].set_title(f'Frame {i+1} candidate')
            im=axes[2].imshow(diff,cmap='coolwarm',vmin=-lim,vmax=lim); axes[2].set_title('Frame − baseline')
            f.colorbar(im,ax=axes[2],fraction=.046,pad=.04)
            for ax in axes: ax.set_xticks([]); ax.set_yticks([])
        elif mode=='Magnitude candidate':
            ax=f.add_subplot(111); ax.imshow(cur,cmap='gray'); ax.set_title(f'Magnitude/phase RAW candidate — frame {i+1}'); ax.set_xticks([]); ax.set_yticks([])
        else:
            ax=f.add_subplot(111); im=ax.imshow(diff,cmap='coolwarm',vmin=-lim,vmax=lim); f.colorbar(im,ax=ax)
            ax.set_xticks([]); ax.set_yticks([])
            ax.set_title(('Phase-difference candidate' if mode.startswith('Phase') else 'Temperature-rise spatial candidate')+f' — frame {i+1}')
        src=self.thermo_source_cache.get(str(s.no),{})
        self.thermo_note.setText(f'Source priority: {src.get("source","Unknown")} | Consistent frames: {src.get("frame_count",len(frames))} | Baseline: {Path(frames[0]["path"]).name} | Current: {Path(frames[i]["path"]).name}. Workflow follows baseline phase → repeated magnitude/phase acquisition → phase difference → temperature calculation. Display is reconstructed from real treatment RAW data, but phase identity, frame cadence, unwrap, TE/field-strength scaling and °C calibration remain under decoder validation.')
        self.thermoplot.draw()

    def draw_image(self,s,m):
        f=self.imgplot.fig; f.clear()
        gs=f.add_gridspec(3,2,width_ratios=[1.65,1],height_ratios=[1,1,1])
        ax=f.add_subplot(gs[:,0]); axt=f.add_subplot(gs[0,1]); axs=f.add_subplot(gs[1,1]); axa=f.add_subplot(gs[2,1])
        n=360; yy,xx=np.mgrid[-1:1:complex(n),-1:1:complex(n)]
        base=None; image_source=''; geometry_warning=''
        # Priority 1: reconstruct from the exact SonicationN folder.
        raw=self.best_raw_for_sonication(s)
        if raw:
            allowed,geo_reasons,req_plane,req_freq=self.raw_geometry_allowed(s)
            known_mismatch=any('mismatch' in r for r in geo_reasons)
            if not known_mismatch:
                score,nraw,result,raw_source,frame_count,geometry=raw
                _,dt,w,h,img=result; base=img
                geometry_warning='; '.join(r for r in geo_reasons if 'unconfirmed' in r)
                image_source=f'Priority 1 — {raw_source}: {Path(nraw).name} ({w}x{h} {dt}; {frame_count} consistent frames)'
                if geometry_warning:image_source+=f' | {geometry_warning}'
            else:
                image_source='Same-folder RAW rejected by known geometry mismatch: '+'; '.join(geo_reasons)
        # Priority 2: explicitly linked external MR/DICOM.
        if base is None:
            ext=self.external_images.get(str(s.no),{})
            if ext:
                for fn in ext.get('files',[]):
                    if Path(fn).suffix.lower() in ('.png','.jpg','.jpeg','.bmp','.tif','.tiff'):
                        try:
                            import matplotlib.image as mpimg; base=mpimg.imread(fn); image_source=f'Priority 2 — External MR image: {Path(fn).name}'; break
                        except Exception: pass
        plane=self.plane_combo.currentText(); plane=plane if plane in ('Axial','Sagittal','Coronal') else 'Axial'
        if base is None:
            phase=self.effective_phase(s); key=plane.lower(); rel=(f'resources/examples/dqa_phantom_{key}.png' if phase=='DQA' else f'resources/examples/treatment_t2_{key}.png'); example=resource_path(rel)
            if example.exists():
                try:
                    import matplotlib.image as mpimg; base=mpimg.imread(example)
                except Exception: base=None
            fallback=(f'EXAMPLE DQA phantom — {plane}' if phase=='DQA' else f'EXAMPLE T2 brain — {plane} — NO PATIENT MR LOADED'); image_source=(image_source+' | '+fallback) if image_source.startswith('RAW excluded:') else fallback
        if base is None:
            base=np.exp(-((xx/.78)**2+(yy/.92)**2)*2.1); image_source='Generated example image'
        ax.imshow(base,cmap='gray',origin='upper',extent=(-1,1,-1,1))
        frames=self.thermo_cache.get(str(s.no),[])
        hotspot_source='SIMULATED'
        if len(frames)>=2:
            cur=frames[min(max(1,self.thermo_slider.value()),len(frames)-1)]['image']; b0=frames[0]['image']; d=np.abs(cur-b0); d=d/(np.percentile(d,99.7)+1e-12)
            # emphasize contiguous hottest region, similar to the red thermal overlay in the treatment review display
            mask=np.ma.masked_where(d<.72,d)
            ax.imshow(mask,cmap='Reds',alpha=.82,origin='upper',extent=(-1,1,-1,1),vmin=.72,vmax=1.15); hotspot_source='RAW PHASE-DIFFERENCE CANDIDATE'
            iy,ix=np.unravel_index(np.argmax(d),d.shape); cx=-1+2*ix/max(1,d.shape[1]-1); cy=1-2*iy/max(1,d.shape[0]-1)
        else:
            scale=np.clip((s.avg_power/1100)*(s.duration/40),.03,1); cx=np.clip(s.x/100.0,-.65,.65); cy=np.clip(s.y/100.0,-.65,.65)
            if abs(cx)<.01 and abs(cy)<.01: cx=.18*math.sin(s.no*.65); cy=.14*math.cos(s.no*.51)
            hot=np.exp(-(((xx-cx)/(.11+.06*scale))**2+((yy-cy)/(.13+.07*scale))**2)*2)
            # filled red thermal region rather than a small point-like marker
            ax.contourf(xx,yy,hot,levels=[.24,.42,.62,.82,1.1],cmap='Reds',alpha=.82)
        ax.plot(cx,cy,'+',color='yellow',markersize=16,markeredgewidth=2)
        ax.text(-.97,.94,hotspot_source,va='top',ha='left',fontsize=9,fontweight='bold',bbox={'facecolor':'black','alpha':.65,'edgecolor':'none'},color='white')
        ax.set_title(f'{image_source}\nSonication {s.no} | {self.effective_phase(s)} | {plane} | Frequency {self.freq_combo.currentText()}'); ax.set_xticks([]); ax.set_yticks([])
        # Thermometry trend from real candidate frames.
        if len(frames)>=2:
            base0=frames[0]['image']; vals=[]; avgs=[]
            for fr in frames:
                dif=np.abs(fr['image']-base0); vals.append(float(np.percentile(dif,99.5))); avgs.append(float(np.mean(dif)))
            vals=np.asarray(vals); avgs=np.asarray(avgs); vals/=np.max(vals)+1e-12; avgs/=np.max(vals)+1e-12
            tt=np.linspace(0,max(s.duration,len(frames)*3.7),len(frames)); axt.plot(tt,vals,label='Peak phase-difference'); axt.plot(tt,avgs,label='Mean phase-difference'); axt.legend(fontsize=7)
            axt.set_title('Thermometry trend candidate')
        else:
            axt.text(.5,.5,'Thermometry sequence unavailable',ha='center',va='center',transform=axt.transAxes); axt.set_title('Thermometry')
        axt.set_xlabel('Mapped time (s)'); axt.set_ylabel('Relative'); axt.grid(True,alpha=.2)
        # Spectrum from selected hydrophone channels.
        msg,dec=self.decoded_hydrophones(s)
        if dec:
            specs=channel_spectra_from_streams(dec['channels']); idx=self.selected_channel_indices(self.spec_checks,len(specs))
            for i in idx:
                fx,sy=specs[i]
                if fx is not None: axs.plot(fx,sy,label=f'Ch {i+1}')
            axs.legend(fontsize=7,ncol=2); axs.set_title('Acoustic Spectrum — selected channels')
        else:
            axs.text(.5,.5,'Spectrum unavailable',ha='center',va='center',transform=axs.transAxes); axs.set_title('Acoustic Spectrum')
        axs.set_xlabel('Relative frequency'); axs.set_ylabel('Amplitude'); axs.grid(True,alpha=.2)
        # Acoustic activity resembles the treatment screen but remains review-only.
        if dec:
            duration=max(s.duration,.001); t=np.linspace(0,duration,dec['channels'].shape[1]); idx=self.selected_channel_indices(self.hp_checks,dec['channels'].shape[0])
            for i in idx:
                x=dec['channels'][i]-np.median(dec['channels'][i]); env=np.convolve(np.abs(x),np.ones(31)/31,mode='same'); env/=np.percentile(env,99)+1e-12; axa.plot(t,env,label=f'Ch {i+1}')
            axa.legend(fontsize=7,ncol=2); axa.set_title('Acoustic activity')
        else:
            axa.text(.5,.5,'Activity unavailable',ha='center',va='center',transform=axa.transAxes); axa.set_title('Acoustic activity')
        axa.set_xlabel('Mapped time (s)'); axa.set_ylabel('Relative'); axa.grid(True,alpha=.2)
        f.suptitle('Integrated MR / thermal hotspot / thermometry / acoustic review — research use only',fontsize=11)
        self.imgplot.draw()

    def spectrum_message_for_sonication(self,s):
        # Prefer a file physically stored under SonicationN. Fall back to numeric filename match.
        pat=re.compile(rf'(^|[\\/])sonication[_ ]?{s.no}([\\/]|$)',re.I)
        direct=[n for n in self.spectrum_msg_files if pat.search(n)]
        if direct:return direct[0]
        numbered=[n for n in self.spectrum_msg_files if re.search(rf'spectrummsg[-_ ]?{s.no}(?:\D|$)',Path(n).name,re.I)]
        return numbered[0] if numbered else None

    def decoded_hydrophones(self,s):
        n=self.spectrum_message_for_sonication(s)
        if not n:return n,None
        key=('channels',n)
        if key not in self.spec_cache:
            try:self.spec_cache[key]=decode_spectrum_channels(self.zf.read(n))
            except Exception:self.spec_cache[key]=None
        return n,self.spec_cache[key]

    def selected_channel_indices(self, checks, count):
        idx=[i for i,cb in enumerate(checks[:count]) if cb.isChecked()]
        return idx or list(range(min(count,4)))

    def draw_cavitation(self,s):
        f=self.cavplot.fig; f.clear(); self.cav_span=None
        n,dec=self.decoded_hydrophones(s)
        if not dec:
            ax=f.add_subplot(111); ax.text(.5,.5,'No decodable time-resolved SpectrumMsg payload for this sonication',ha='center',va='center',transform=ax.transAxes)
            ax.set_title('Hydrophone Cavitation — unavailable (simulation removed)'); ax.set_xlabel('Time'); ax.set_ylabel('Cavitation')
            self.cav_range_label.setText('No time-resolved payload available.'); self.cavplot.draw(); return
        streams=dec['channels']; duration=max(float(s.duration),.001); selected=self.selected_channel_indices(self.hp_checks,streams.shape[0])
        self.cav_current_streams=streams; self.cav_current_duration=duration
        show_metrics=self.cav_metrics_toggle.isChecked()
        rows=3 if show_metrics else 2
        ax=f.add_subplot(rows,1,1)
        t=np.linspace(0,duration,streams.shape[1]); metrics=[]
        for i in selected:
            x=streams[i]; centered=x-np.median(x); win=max(3,min(101,len(x)//80*2+1)); kernel=np.ones(win)/win
            env=np.convolve(np.abs(centered),kernel,mode='same'); env=env/(np.percentile(env,99)+1e-12)
            ax.plot(t,env,label=f'Ch {i+1}')
            rms=float(np.sqrt(np.mean(centered**2))); peak=float(np.max(np.abs(centered))); crest=peak/(rms+1e-12); impulse=float(np.mean(np.abs(centered)>3*(np.std(centered)+1e-12)))
            metrics.append((i,rms,crest,impulse))
        ax.set_title(f'Time-resolved acoustic activity — {Path(n).name}'); ax.set_xlabel('Mapped sonication time (s)'); ax.set_ylabel('Relative activity'); ax.legend(ncol=4,fontsize=7); ax.grid(True,alpha=.25)
        axfft=f.add_subplot(rows,1,2)
        if self.cav_selected_range:
            a,b=self.cav_selected_range; lo=max(0,min(a,b)); hi=min(duration,max(a,b)); mask=(t>=lo)&(t<=hi)
            for i in selected:
                x=np.asarray(streams[i])[mask]
                if x.size<16: continue
                x=x-np.mean(x); win=np.hanning(len(x)); y=np.abs(np.fft.rfft(x*win)); y=y/(np.max(y)+1e-12); freq=np.linspace(0,1,len(y))
                axfft.plot(freq,y,label=f'Ch {i+1}')
            axfft.set_title(f'FFT of selected interval {lo:.2f}–{hi:.2f} s'); self.cav_range_label.setText(f'Selected interval: {lo:.2f}–{hi:.2f} s. FFT uses only this mapped payload range.')
        else:
            axfft.text(.5,.5,'Drag across the upper chart to calculate interval FFT',ha='center',va='center',transform=axfft.transAxes); axfft.set_title('Selected-range FFT')
        axfft.set_xlabel('Relative frequency'); axfft.set_ylabel('Normalized amplitude'); axfft.grid(True,alpha=.25)
        if axfft.lines: axfft.legend(ncol=4,fontsize=7)
        if show_metrics:
            ax2=f.add_subplot(rows,1,3); ind=np.arange(len(metrics)); width=.25
            rms=np.array([m[1] for m in metrics]); rms=rms/(np.max(rms)+1e-12); crest=np.array([m[2] for m in metrics]); crest=crest/(np.max(crest)+1e-12); impulse=np.array([m[3] for m in metrics]); impulse=impulse/(np.max(impulse)+1e-12)
            ax2.bar(ind-width,rms,width,label='RMS activity'); ax2.bar(ind,crest,width,label='Crest factor'); ax2.bar(ind+width,impulse,width,label='Impulsive fraction')
            ax2.set_xticks(ind,[f'Ch {m[0]+1}' for m in metrics]); ax2.set_ylim(0,1.15); ax2.set_ylabel('Normalized comparison'); ax2.legend(ncol=3,fontsize=8); ax2.grid(True,axis='y',alpha=.2)
        f.suptitle(f'Experimental multi-hydrophone acoustic investigation — {dec["count"]} candidate channels\nNot a validated cavitation dose or Stable/Inertial classification')
        def onselect(xmin,xmax):
            self.cav_selected_range=(float(xmin),float(xmax)); self.draw_cavitation(s)
        self.cav_span=SpanSelector(ax,onselect,'horizontal',useblit=True,props=dict(alpha=.25,facecolor='tab:blue'),interactive=True,drag_from_anywhere=True)
        self.cavplot.draw()

    def nearest_spectrum(self,s):
        target=time_seconds(s.time); a=[(abs(spectrum_time(n)-target),n) for n in self.spectrum_files if spectrum_time(n) is not None]
        return min(a)[1] if a else None

    def draw_spectrum(self,s):
        f=self.specplot.fig; f.clear()
        interval=self.spec_interval.currentText(); hp=self.hp_combo.currentText(); ymode=self.spec_y.currentText(); mode=self.spec_display.currentText()
        msg,dec=self.decoded_hydrophones(s)
        spectra=[]; source=''; experimental=False
        if dec:
            spectra=channel_spectra_from_streams(dec['channels']); source=msg; experimental=True
        else:
            n=self.nearest_spectrum(s); x=y=None
            if n:
                if n not in self.spec_cache:self.spec_cache[n]=decode_spectrum(self.zf.read(n))
                x,y=self.spec_cache[n]
            if x is not None:spectra=[(x,y)]; source=n
        valid=[z for z in spectra if z[0] is not None]
        if dec and valid:
            idx=self.selected_channel_indices(self.spec_checks,len(valid)); valid=[valid[i] for i in idx]; valid_labels=[i+1 for i in idx]
        else:
            valid_labels=list(range(1,len(valid)+1))
        if not valid:
            ax=f.add_subplot(111); ax.text(.5,.5,'No decodable acoustic spectrum payload',ha='center',va='center',transform=ax.transAxes); ax.axis('off')
            self.spec_note.setText('No simulation is displayed. Spectrum and hydrophone data remain unavailable until a payload is decoded.'); self.specplot.draw(); return
        def yconvert(y):
            y=np.maximum(np.asarray(y,float),1e-12)
            return 20*np.log10(y/np.max(y)) if ymode=='dB' else y
        selected=0
        m=re.search(r'(\d+)',hp)
        if m:selected=max(0,min(len(valid)-1,int(m.group(1))-1))
        if mode=='Channel Heatmap' and len(valid)>1:
            ax=f.add_subplot(111); n=min(len(y) for _,y in valid); mat=np.vstack([yconvert(y[:n]) for _,y in valid]);
            im=ax.imshow(mat,aspect='auto',origin='lower',extent=(0,1,.5,len(valid)+.5),cmap='viridis'); f.colorbar(im,ax=ax,label='dB' if ymode=='dB' else 'Normalized amplitude')
            ax.set_yticks(range(1,len(valid)+1),[f'Ch {i}' for i in valid_labels]); ax.set_xlabel('Relative frequency'); ax.set_ylabel('Candidate hydrophone channel'); ax.set_title(f'All-channel acoustic spectrum heatmap | {Path(source).name}')
        elif mode=='Relative Cavitation Bands' and len(valid)>0:
            ax=f.add_subplot(111); bands=[(0.02,.20,'Low'),(.20,.55,'Mid'),(.55,.98,'High / broadband')]; vals=[]
            for x,y in valid:
                yy=np.asarray(y,float); xx=np.asarray(x,float); vals.append([float(np.trapz(yy[(xx>=a)&(xx<b)],xx[(xx>=a)&(xx<b)])) if np.any((xx>=a)&(xx<b)) else 0 for a,b,_ in bands])
            mat=np.asarray(vals); mat=mat/(np.max(mat,axis=0,keepdims=True)+1e-12); ind=np.arange(len(valid)); width=.24
            for j,(_,_,label) in enumerate(bands): ax.bar(ind+(j-1)*width,mat[:,j],width,label=label)
            ax.set_xticks(ind,[f'Ch {i}' for i in valid_labels]); ax.set_ylabel('Relative integrated spectral energy'); ax.set_ylim(0,1.15); ax.legend(); ax.grid(True,axis='y',alpha=.2); ax.set_title('Relative spectral-band comparison — exploratory, not validated cavitation bands')
        elif mode=='All Separate' and len(valid)>1:
            cols=2; rows=int(math.ceil(len(valid)/cols))
            for i,(x,y) in enumerate(valid):
                ax=f.add_subplot(rows,cols,i+1); ax.plot(x,yconvert(y)); ax.set_title(f'Channel {valid_labels[i]}'); ax.grid(True,alpha=.2)
                ax.set_xlabel('Relative frequency'); ax.set_ylabel('dB' if ymode=='dB' else 'Amplitude')
        elif mode=='Spectrogram' and dec:
            ax=f.add_subplot(111); x=dec['channels'][selected]; nper=max(64,min(512,2**int(np.floor(np.log2(max(64,len(x)//20)))))); nover=nper//2
            ax.specgram(x,NFFT=nper,Fs=1.0,noverlap=nover); ax.set_xlabel('Relative payload time'); ax.set_ylabel('Relative frequency'); ax.set_title(f'Channel {selected+1} spectrogram (uncalibrated)')
        else:
            ax=f.add_subplot(111)
            if mode=='Single':
                x,y=valid[selected]; ax.plot(x,yconvert(y),label=f'Channel {valid_labels[selected]}')
            elif mode=='Average':
                n=min(len(y) for _,y in valid); x=valid[0][0][:n]; mat=np.vstack([y[:n] for _,y in valid]); ax.plot(x,yconvert(np.mean(mat,axis=0)),label='Channel average')
            elif mode=='Maximum Envelope':
                n=min(len(y) for _,y in valid); x=valid[0][0][:n]; mat=np.vstack([y[:n] for _,y in valid]); ax.plot(x,yconvert(np.max(mat,axis=0)),label='Maximum envelope')
            else:
                for i,(x,y) in enumerate(valid):ax.plot(x,yconvert(y),label=f'Channel {valid_labels[i]}')
            ax.legend(ncol=2,fontsize=8); ax.grid(True,alpha=.25); ax.set_xlabel('Frequency (relative; physical calibration unavailable)'); ax.set_ylabel('Amplitude (dB re max)' if ymode=='dB' else 'Amplitude (normalized)')
            ax.set_title(f'{interval} | {mode} | {Path(source).name}')
        if experimental:
            self.spec_note.setText(f'Experimental decode of {Path(source).name}: {dec["count"]} candidate channels, dtype {dec["dtype"]}, offset {dec["offset"]}. Channel identity, sampling interval, Hz/MHz scale, and Pre/During/Post boundaries are not yet validated. The full payload is mapped to the sonication duration only for review.')
        else:
            self.spec_note.setText('Matched FFT payload is displayed as one unassigned channel. Physical frequency calibration and hydrophone identity are not verified.')
        self.specplot.draw()

    def draw_timeline(self):
        f=self.timeline.fig; f.clear(); ax=f.add_subplot(111)
        if self.sonics:
            for i,s in enumerate(self.sonics):
                phase=self.effective_phase(s); y=1 if phase=='Treatment' else 0
                ax.barh(y,max(s.duration,.2),left=time_seconds(s.time),height=.35,alpha=.65)
                ax.text(time_seconds(s.time)+max(s.duration,.2)/2,y,str(s.no),ha='center',va='center',fontsize=8)
            ax.set_yticks([0,1],['DQA (phantom)','Treatment (patient)']); ax.set_xlabel('Session clock (seconds from midnight)')
            ax.set_title('DQA and Treatment Sonication Timeline — manual overrides preserved'); ax.grid(True,axis='x',alpha=.25)
        self.timeline.draw()

    def show_mr_table(self):
        self.mrtable.setRowCount(len(self.mr_series))
        for r,m in enumerate(self.mr_series):
            vals=[m.time,m.description,m.plane,m.freq_dir,m.image_mode,m.pulse_sequence,m.psd_name,m.coil,m.fov,m.thickness,m.slices,m.matrix]
            for c,v in enumerate(vals):self.mrtable.setItem(r,c,QTableWidgetItem(v))

    def show_evidence(self):
        lines=['MR SERVER EVIDENCE','='*80]
        lines += self.mrserver_events[:10000]
        if not self.mrserver_events: lines.append('No mrserver.log evidence was found.')
        lines += ['','TIMING EVIDENCE','='*80] + self.timing_evidence[:5000]
        self.evidence.setPlainText('\n'.join(lines))

    def show_sync(self):
        offset='Not detected'; source='No explicit MR-FUS offset statement was decoded.'
        if self.ws_offsets:
            vals=[v for v,_ in self.ws_offsets]; offset=f'{np.median(vals):+.3f} s ({len(vals)} records; sign evaluated per Sonication)'; source=self.ws_offsets[0][1]
        rows=[]
        for sonic in self.sonics:
            mt=self.resolve_series_match(sonic); ms=self.mr_series[mt.series_index] if 0<=mt.series_index<len(self.mr_series) else None
            rows.append(f'<tr><td>{sonic.no}</td><td>{sonic.time}</td><td>{ms.time if ms else "-"}</td><td>{ms.description if ms else "Rejected / unavailable"}</td><td>{mt.corrected_gap:+.2f}s</td><td>{mt.offset_direction} {mt.applied_offset:+.3f}s</td><td>{mt.confidence}</td><td>{"Yes" if mt.plane_match else "No"}</td><td>{"Yes" if mt.freq_match else "No"}</td></tr>')
        html='<h2>MR-FUS Synchronization Resolver</h2>'
        html+=f'<table cellpadding="5" border="1"><tr><td><b>WS offset evidence</b></td><td>{offset}</td></tr><tr><td><b>First evidence</b></td><td>{source}</td></tr></table>'
        html+='<p><b>Priority:</b> Sonication XML geometry, TMAP/MEMP protocol, plane, frequency direction, corrected MR interval, then time proximity. Known geometry mismatch is rejected.</p>'
        html+='<table cellpadding="4" border="1"><tr><th>Son.</th><th>FUS</th><th>MR</th><th>Matched series</th><th>Gap</th><th>Offset model</th><th>Confidence</th><th>Plane</th><th>Freq</th></tr>'+''.join(rows)+'</table>'
        self.syncinfo.setHtml(html)

    def show_overview(self,s,m):
        spec=self.nearest_spectrum(s); man=self.manual.get(str(s.no),{})
        rows=[
            ('Sonication',str(s.no)),('Category',self.effective_phase(s)),('Start',s.time),('Status',s.status),('Duration',f'{s.duration:.2f} s'),
            ('Power / Avg / Max',f'{s.power:.2f} / {s.avg_power:.2f} / {s.max_power:.2f}'),('Frequency',f'{s.freq:.3f}'),
            ('Focus coordinates',f'X {s.x:.2f}, Y {s.y:.2f}, Elevation {s.elevation:.2f}, FD {s.fd:.2f}'),
            ('Scan plane',self.plane_combo.currentText()),('Frequency direction',self.freq_combo.currentText()),
            ('Spectrum match',Path(spec).name if spec else 'None'),('Reflection files',str(len(self.reflection_files))),
            ('Spectrum interval',self.spec_interval.currentText()),('Hydrophone',self.hp_combo.currentText()),('Spectrum display',self.spec_display.currentText()),('MR series source',m.description if m else 'No matched review.out series'),('External image',self.external_images.get(str(s.no),{}).get('folder','None'))]
        html='<h2>Maximum Available Information</h2><table cellpadding="5" border="1" cellspacing="0">'+''.join(f'<tr><td><b>{a}</b></td><td>{b}</td></tr>' for a,b in rows)+'</table>'
        if m:
            html += '<h3>Matched MR acquisition from review.out</h3><table cellpadding="5" border="1" cellspacing="0">'+''.join(f'<tr><td><b>{a}</b></td><td>{b}</td></tr>' for a,b in [
                ('Protocol',m.protocol),('Series description',m.description),('Plane',m.plane),('Frequency direction',m.freq_dir),('Image mode',m.image_mode),('Pulse sequence',m.pulse_sequence),('PSD',m.psd_name),('Coil',m.coil),('FOV',m.fov),('Slice thickness',m.thickness),('Slices',m.slices),('Matrix',m.matrix),('Start / End location',f'{m.start_loc} / {m.end_loc}'),('Center FOV',m.center_fov)])+'</table>'
        meta=self.son_meta.get(str(s.no),{})
        if meta:
            html += '<h3>Sonication XML metadata</h3><table cellpadding="5" border="1" cellspacing="0">'+''.join(f'<tr><td><b>{k}</b></td><td>{v}</td></tr>' for k,v in meta.items() if k!='evidence' and len(str(v))<500)+'</table><p><b>Evidence files:</b> '+', '.join(meta.get('evidence',[]))+'</p>'
        match=self.resolve_series_match(s)
        html += '<h3>Synchronization / Geometry Match</h3><table cellpadding="5" border="1">'+''.join(f'<tr><td><b>{a}</b></td><td>{b}</td></tr>' for a,b in [('Confidence',match.confidence),('Score',f'{match.score:.1f}'),('Corrected gap',f'{match.corrected_gap:+.3f} s'),('Offset model',f'{match.offset_direction} ({match.applied_offset:+.3f} s)'),('Plane match',match.plane_match),('Frequency match',match.freq_match),('Thermometry protocol',match.protocol_match),('Reasons','; '.join(match.reasons) or 'None')])+'</table>'
        if match.rejected:html += '<h4>Rejected MR candidates</h4><ul>'+''.join(f'<li>{x}</li>' for x in match.rejected)+'</ul>'
        html += '<h3>Timing model</h3><p>MR acquisition start → Pre → FUS start (0 s) → Actual duration → Post → MR acquisition end. WS clock-offset evidence is applied only when explicitly decoded.</p><p><b>Provenance:</b> Treatment parameters come from the ZIP summary. MR geometry is read from review.out when available and can be manually overridden per sonication. mrserver.log provides scanner workflow evidence. Hotspot and cavitation graphics remain simulated unless corresponding proprietary data is decoded or external images are linked.</p>'
        self.overview.setHtml(html)

    def show_inventory(self):
        self.inventory_table.setRowCount(len(self.inventory))
        for r,it in enumerate(self.inventory):
            vals=[it.path,f'{it.size:,}',it.category,it.sonication,it.ext,it.signature,it.candidate,it.status]
            for c,v in enumerate(vals): self.inventory_table.setItem(r,c,QTableWidgetItem(str(v)))

    def inventory_selected(self):
        rows=self.inventory_table.selectionModel().selectedRows() if self.inventory_table.selectionModel() else []
        if not rows:return
        r=rows[0].row()
        if 0<=r<len(self.inventory):
            it=self.inventory[r]
            if it.path in self.raw_files:
                idx=self.raw_combo.findData(it.path)
                if idx>=0:self.raw_combo.setCurrentIndex(idx)

    def populate_raw_combo(self):
        self.raw_combo.blockSignals(True); self.raw_combo.clear()
        for n in self.raw_files:self.raw_combo.addItem(n,n)
        self.raw_combo.blockSignals(False)
        if self.raw_files:self.raw_combo.setCurrentIndex(0); self.draw_raw_candidate()
        else:
            self.rawplot.fig.clear(); self.rawplot.draw(); self.raw_meta.setText('No .raw files were found in this ZIP.')

    def draw_raw_candidate(self,*args):
        if not self.zf:return
        n=self.raw_combo.currentData()
        if not n:return
        try: blob=self.zf.read(n)
        except Exception as e:
            self.raw_meta.setText(str(e)); return
        result=try_render_raw(blob)
        f=self.rawplot.fig; f.clear(); ax=f.add_subplot(111)
        if result:
            score,dt,w,h,img=result; ax.imshow(img,cmap='gray',origin='upper'); ax.set_title(f'Experimental RAW preview — {Path(n).name}\n{w}x{h} {dt}, image-likeness {score:.3f}'); ax.set_xticks([]); ax.set_yticks([])
            self.raw_meta.setText(f'Path: {n} | Size: {len(blob):,} bytes | Candidate: {w}x{h} {dt} | Status: Experimental. This preview is not identified as magnitude, phase, temperature, or dose until cross-file evidence confirms it.')
        else:
            ax.text(.5,.5,'No plausible 2-D image layout found',ha='center',va='center'); ax.axis('off'); self.raw_meta.setText(f'Path: {n} | Size: {len(blob):,} bytes | Candidate layouts: {raw_candidates(len(blob))}')
        self.rawplot.draw()

    def show_coverage(self):
        cats={}
        for it in self.inventory:cats[it.category]=cats.get(it.category,0)+1
        rows=[
            ('Sonication summary','Confirmed',len(self.sonics),'Parsed treatment summary rows'),
            ('DQA / Treatment','Partial',len(self.sonics),'Automatic workflow grouping plus manual override; explicit DQA log decoder remains under development'),
            ('MR review metadata','Confirmed' if self.mr_series else 'Missing',len(self.mr_series),'review.out series metadata'),
            ('MR server workflow','Confirmed' if self.mrserver_events else 'Missing',len(self.mrserver_events),'mrserver event evidence'),
            ('MR / Thermometry RAW','Experimental' if self.raw_files else 'Missing',len(self.raw_files),'Inventory and candidate 2-D preview; semantic channel identification pending'),
            ('Spectrum / Hydrophone','Experimental' if self.spectrum_msg_files else ('Partial' if self.spectrum_files else 'Missing'),len(self.spectrum_files)+len(self.spectrum_msg_files),'4–8 channel candidate decoding, spectrum heatmap, relative spectral-band comparison, activity/RMS/crest/impulsive metrics; channel identity and physical calibration pending'),
            ('Reflection','Inventory',cats.get('Reflection',0),'Files linked by path/time; decoder pending'),
            ('Skull / Bone','Inventory',cats.get('Skull heating',0)+cats.get('Skull measures',0)+cats.get('Bone spot data',0),'Evidence indexed; structured decoder pending'),
            ('MR–FUS synchronization','Partial' if self.ws_offsets else 'Unknown',len(self.ws_offsets),'Explicit offset evidence only; no fabricated timing'),
            ('DICOM import','Available',sum(len(v.get('files',[])) for v in self.external_images.values()),'External image mapping supported; metadata/pixel display depends on pydicom')
        ]
        self.coverage.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for c,v in enumerate(row):self.coverage.setItem(r,c,QTableWidgetItem(str(v)))

    def show_details(self,s,m):
        spec=self.nearest_spectrum(s)
        html=(f'<h2>Sonication {s.no} — {self.effective_phase(s)}</h2><table cellpadding="5">'
              f'<tr><td>Start time</td><td>{s.time}</td></tr><tr><td>Status</td><td>{s.status}</td></tr>'
              f'<tr><td>Duration</td><td>{s.duration:.1f} s</td></tr><tr><td>Commanded power</td><td>{s.power:.1f}</td></tr>'
              f'<tr><td>Average / maximum power</td><td>{s.avg_power:.1f} / {s.max_power:.1f}</td></tr>'
              f'<tr><td>Frequency</td><td>{s.freq:.3f}</td></tr><tr><td>Focal distance</td><td>{s.fd:.1f}</td></tr>'
              f'<tr><td>Position</td><td>X {s.x:.1f}, Y {s.y:.1f}, Elevation {s.elevation:.1f}, Roll {s.roll:.1f}, Pitch {s.pitch:.1f}</td></tr>'
              f'<tr><td>MR plane / frequency direction</td><td>{self.plane_combo.currentText()} / {self.freq_combo.currentText()}</td></tr>'
              f'<tr><td>Sonication folder files</td><td>{len(self.sonication_folder_files(s))}</td></tr>'
              f'<tr><td>Replay reconstruction priority</td><td>Same Sonication{s.no} folder first</td></tr>'
              f'<tr><td>Matched spectrum</td><td>{Path(spec).name if spec else "None"}</td></tr></table>')
        folder_files=self.sonication_folder_files(s)
        cats={}
        for n in folder_files:
            cat,_=classify_inventory_path(n); cats[cat]=cats.get(cat,0)+1
        folder_summary=', '.join(f'{k}: {v}' for k,v in sorted(cats.items())) or 'No exact Sonication folder data'
        html=html.replace('</table>',f'<tr><td>Folder content</td><td>{folder_summary}</td></tr></table>')
        self.details.setHtml(html)
        raw=self.best_raw_for_sonication(s)
        replay_source=(f'{raw[3]}: {Path(raw[1]).name} ({raw[4]} frames)' if raw else ('External MR' if str(s.no) in self.external_images else 'Example image'))
        values={'sonication':str(s.no),'phase':self.effective_phase(s),'start':s.time,'status':s.status,'duration':f'{s.duration:.2f} s','power':f'{s.power:.1f}','avgmax':f'{s.avg_power:.1f} / {s.max_power:.1f}','frequency':f'{s.freq:.3f} MHz','fd':f'{s.fd:.1f}','position':f'X {s.x:.1f}, Y {s.y:.1f}, E {s.elevation:.1f}, R {s.roll:.1f}, P {s.pitch:.1f}','mrfreq':f'{self.plane_combo.currentText()} / {self.freq_combo.currentText()}','replay_source':replay_source,'spectrum':Path(spec).name if spec else 'None'}
        for k,v in values.items():
            if k in self.detail_labels:self.detail_labels[k].setText(v)

if __name__=='__main__':
    app=QApplication(sys.argv); m=Main(); m.show()
    if len(sys.argv)>1 and Path(sys.argv[1]).exists():m.load_zip(sys.argv[1])
    sys.exit(app.exec())
