from __future__ import annotations

import csv
import shutil
import sys
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import pydicom
import pyqtgraph as pg
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFileDialog, QFormLayout, QFrame,
    QGroupBox, QHBoxLayout, QLabel, QMainWindow, QMessageBox, QPushButton,
    QSlider, QSpinBox, QSplitter, QStatusBar, QTabWidget, QTableWidget,
    QTableWidgetItem, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget,
)

APP_NAME = "MRI Raw & FFT Explorer"
APP_VERSION = "0.8.0 Prototype"

pg.setConfigOptions(imageAxisOrder="row-major", antialias=True)


def fft2c(image: np.ndarray) -> np.ndarray:
    return np.fft.fftshift(np.fft.fft2(np.fft.ifftshift(image)))


def ifft2c(kspace: np.ndarray) -> np.ndarray:
    return np.fft.fftshift(np.fft.ifft2(np.fft.ifftshift(kspace)))


def display_array(arr: np.ndarray, mode: str) -> np.ndarray:
    if mode == "FFT":
        return np.log1p(np.abs(arr))
    return np.abs(arr)


@dataclass
class DicomEntry:
    path: Path
    ds: pydicom.dataset.FileDataset
    image: np.ndarray
    sort_key: tuple


class DropBanner(QFrame):
    pathsDropped = Signal(list)

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.setObjectName("DropBanner")
        layout = QVBoxLayout(self)
        self.title = QLabel("Drop DICOM / Raw / P File / 1D Data / Folder / ZIP Here")
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setStyleSheet("font-size: 17px; font-weight: 600;")
        subtitle = QLabel("DICOM, RAW, GE TrackerImg/PFile, Siemens .dat, CSV/TXT/NPY/NPZ, images")
        subtitle.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.title)
        layout.addWidget(subtitle)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self.setProperty("dragActive", True)
            self.style().unpolish(self); self.style().polish(self)

    def dragLeaveEvent(self, event):
        self.setProperty("dragActive", False)
        self.style().unpolish(self); self.style().polish(self)

    def dropEvent(self, event):
        self.setProperty("dragActive", False)
        self.style().unpolish(self); self.style().polish(self)
        paths = [Path(u.toLocalFile()) for u in event.mimeData().urls() if u.isLocalFile()]
        if paths:
            self.pathsDropped.emit(paths)
            event.acceptProposedAction()


class ImagePanel(QWidget):
    lineChanged = Signal(int, int)

    def __init__(self, title: str):
        super().__init__()
        layout = QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        self.label = QLabel(title)
        self.label.setStyleSheet("font-weight: 600; padding: 3px;")
        layout.addWidget(self.label)
        self.plot = pg.PlotWidget()
        self.plot.setAspectLocked(True)
        self.plot.hideAxis("left"); self.plot.hideAxis("bottom")
        self.image_item = pg.ImageItem()
        self.plot.addItem(self.image_item)
        self.hline = pg.InfiniteLine(angle=0, movable=True, pen=pg.mkPen('#ff4949', width=1.5, style=Qt.DashLine))
        self.vline = pg.InfiniteLine(angle=90, movable=True, pen=pg.mkPen('#ff4949', width=1.5, style=Qt.DashLine))
        self.plot.addItem(self.hline); self.plot.addItem(self.vline)
        self.hline.sigPositionChanged.connect(self._emit_position)
        self.vline.sigPositionChanged.connect(self._emit_position)
        layout.addWidget(self.plot, 1)
        self.shape = (1, 1)

    def set_image(self, image: np.ndarray, auto_levels=True):
        image = np.asarray(image, dtype=float)
        self.shape = image.shape[:2]
        self.image_item.setImage(image, autoLevels=auto_levels)
        self.plot.setRange(xRange=(0, self.shape[1]), yRange=(0, self.shape[0]), padding=0)
        self.set_line_position(self.shape[0] // 2, self.shape[1] // 2)

    def set_line_position(self, row: int, col: int):
        row = max(0, min(int(row), self.shape[0] - 1))
        col = max(0, min(int(col), self.shape[1] - 1))
        self.hline.blockSignals(True); self.vline.blockSignals(True)
        self.hline.setPos(row); self.vline.setPos(col)
        self.hline.blockSignals(False); self.vline.blockSignals(False)

    def _emit_position(self):
        row = max(0, min(int(round(self.hline.value())), self.shape[0] - 1))
        col = max(0, min(int(round(self.vline.value())), self.shape[1] - 1))
        self.lineChanged.emit(row, col)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} {APP_VERSION}")
        self.resize(1550, 950)
        self.setAcceptDrops(True)
        self.temp_dirs: list[Path] = []
        self.dicom_entries: list[DicomEntry] = []
        self.current_image: Optional[np.ndarray] = None
        self.current_kspace: Optional[np.ndarray] = None
        self.current_recon: Optional[np.ndarray] = None
        self.current_ds = None
        self.current_source = ""
        self.view_mode = "FFT"
        self.line_orientation = "Row"
        self.line_row = 0
        self.line_col = 0
        self.signals: list[dict] = []

        self._build_ui()
        self._build_menu()
        self._apply_style()
        self.statusBar().showMessage("Ready — drop files or folders above")

    def _build_ui(self):
        root = QWidget(); root_l = QVBoxLayout(root); root_l.setContentsMargins(8, 8, 8, 8)
        self.drop_banner = DropBanner(); self.drop_banner.pathsDropped.connect(self.import_paths)
        root_l.addWidget(self.drop_banner)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_workspace(), "Image Workspace")
        self.tabs.addTab(self._build_signal_studio(), "1D Signal Studio")
        self.tabs.addTab(self._build_metadata(), "DICOM Header")
        root_l.addWidget(self.tabs, 1)
        self.setCentralWidget(root)
        self.setStatusBar(QStatusBar())

    def _build_workspace(self):
        page = QWidget(); layout = QHBoxLayout(page); layout.setContentsMargins(0, 6, 0, 0)
        main_split = QSplitter(Qt.Horizontal)

        left = QWidget(); ll = QVBoxLayout(left); ll.setContentsMargins(0, 0, 0, 0)
        self.tree = QTreeWidget(); self.tree.setHeaderLabel("Explorer")
        self.tree.itemClicked.connect(self._tree_clicked)
        ll.addWidget(self.tree, 1)
        self.info = QLabel("No file loaded")
        self.info.setWordWrap(True); self.info.setMinimumHeight(150)
        self.info.setObjectName("InfoCard")
        ll.addWidget(self.info)
        main_split.addWidget(left)

        center = QWidget(); cl = QVBoxLayout(center); cl.setContentsMargins(0, 0, 0, 0)
        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel("Display"))
        self.btn_fft = QPushButton("FFT")
        self.btn_original = QPushButton("Original")
        self.btn_both = QPushButton("Both")
        for b, mode in [(self.btn_fft, "FFT"), (self.btn_original, "Original"), (self.btn_both, "Both")]:
            b.setCheckable(True); b.clicked.connect(lambda checked=False, m=mode: self.set_view_mode(m)); mode_row.addWidget(b)
        mode_row.addStretch(1)
        self.slice_label = QLabel("Slice: -")
        self.prev_btn = QPushButton("Previous"); self.next_btn = QPushButton("Next")
        self.prev_btn.clicked.connect(lambda: self.change_slice(-1)); self.next_btn.clicked.connect(lambda: self.change_slice(1))
        mode_row.addWidget(self.prev_btn); mode_row.addWidget(self.next_btn); mode_row.addWidget(self.slice_label)
        cl.addLayout(mode_row)

        self.vertical_splitter = QSplitter(Qt.Vertical)
        image_container = QWidget(); il = QVBoxLayout(image_container); il.setContentsMargins(0, 0, 0, 0)
        self.image_splitter = QSplitter(Qt.Horizontal)
        self.primary_panel = ImagePanel("FFT (k-space)")
        self.secondary_panel = ImagePanel("Original")
        self.primary_panel.lineChanged.connect(self._line_moved)
        self.secondary_panel.lineChanged.connect(self._line_moved)
        self.image_splitter.addWidget(self.primary_panel); self.image_splitter.addWidget(self.secondary_panel)
        il.addWidget(self.image_splitter, 1)

        line_bar = QHBoxLayout()
        line_bar.addWidget(QLabel("Line"))
        self.orientation_combo = QComboBox(); self.orientation_combo.addItems(["Row", "Column"])
        self.orientation_combo.currentTextChanged.connect(self._orientation_changed)
        line_bar.addWidget(self.orientation_combo)
        self.line_spin = QSpinBox(); self.line_spin.valueChanged.connect(self._spin_line_changed)
        line_bar.addWidget(self.line_spin)
        self.line_slider = QSlider(Qt.Horizontal); self.line_slider.valueChanged.connect(self._slider_line_changed)
        line_bar.addWidget(self.line_slider, 1)
        self.line_value_label = QLabel("-")
        line_bar.addWidget(self.line_value_label)
        il.addLayout(line_bar)
        self.vertical_splitter.addWidget(image_container)

        lower = QWidget(); low = QHBoxLayout(lower); low.setContentsMargins(0, 0, 0, 0)
        self.profile_plot = pg.PlotWidget(title="Selected Line Profile")
        self.profile_plot.showGrid(x=True, y=True, alpha=.2)
        self.profile_plot.setLabel("bottom", "Sample")
        low.addWidget(self.profile_plot, 2)
        self.tracker_plot = pg.PlotWidget(title="Tracker / Active 1D Signal")
        self.tracker_plot.showGrid(x=True, y=True, alpha=.2)
        low.addWidget(self.tracker_plot, 1)
        self.vertical_splitter.addWidget(lower)
        self.vertical_splitter.setSizes([620, 260])
        cl.addWidget(self.vertical_splitter, 1)
        main_split.addWidget(center)

        right = QWidget(); rl = QVBoxLayout(right); rl.setContentsMargins(0, 0, 0, 0)
        profile_group = QGroupBox("Profile")
        form = QFormLayout(profile_group)
        self.profile_mode = QComboBox(); self.profile_mode.addItems(["Magnitude", "Real", "Imaginary", "Phase"])
        self.profile_mode.currentTextChanged.connect(self.update_line_profile)
        form.addRow("Type", self.profile_mode)
        self.log_profile = QCheckBox("Log scale"); self.log_profile.toggled.connect(self.update_line_profile)
        form.addRow(self.log_profile)
        rl.addWidget(profile_group)
        self.btn_send_signal = QPushButton("Send selected line to 1D Studio")
        self.btn_send_signal.clicked.connect(self.send_line_to_signal_studio)
        rl.addWidget(self.btn_send_signal)
        self.btn_auto = QPushButton("Auto Levels"); self.btn_auto.clicked.connect(self.auto_levels)
        rl.addWidget(self.btn_auto)
        rl.addStretch(1)
        main_split.addWidget(right)
        main_split.setSizes([230, 1100, 190])
        layout.addWidget(main_split)
        self.set_view_mode("FFT")
        return page

    def _build_signal_studio(self):
        page = QWidget(); layout = QVBoxLayout(page)
        top = QHBoxLayout()
        self.signal_combo = QComboBox(); self.signal_combo.currentIndexChanged.connect(self.update_signal_plot)
        self.signal_component = QComboBox(); self.signal_component.addItems(["Magnitude", "Real", "Imaginary", "Phase"])
        self.signal_component.currentTextChanged.connect(self.update_signal_plot)
        self.signal_fft = QCheckBox("Frequency display (FFT)"); self.signal_fft.setChecked(False); self.signal_fft.toggled.connect(self.update_signal_plot)
        clear = QPushButton("Clear signals"); clear.clicked.connect(self.clear_signals)
        top.addWidget(QLabel("Signal")); top.addWidget(self.signal_combo, 1); top.addWidget(self.signal_component); top.addWidget(self.signal_fft); top.addWidget(clear)
        layout.addLayout(top)
        self.signal_plot = pg.PlotWidget(); self.signal_plot.showGrid(x=True, y=True, alpha=.2)
        layout.addWidget(self.signal_plot, 1)
        note = QLabel("Tracker PFile/TrackerImg drops are automatically registered here as complex 1D raw signals.")
        note.setWordWrap(True); layout.addWidget(note)
        return page

    def _build_metadata(self):
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout()
        self.header_filter = QComboBox(); self.header_filter.setEditable(True); self.header_filter.setInsertPolicy(QComboBox.NoInsert)
        self.header_filter.lineEdit().setPlaceholderText("Filter header tags...")
        self.header_filter.lineEdit().textChanged.connect(self.filter_header)
        export = QPushButton("Export Current Header to Excel"); export.clicked.connect(self.export_header_excel)
        row.addWidget(self.header_filter, 1); row.addWidget(export)
        layout.addLayout(row)
        self.header_table = QTableWidget(0, 6)
        self.header_table.setHorizontalHeaderLabels(["Tag", "Keyword", "Name", "VR", "VM", "Value"])
        self.header_table.horizontalHeader().setStretchLastSection(True)
        self.header_table.setSortingEnabled(True)
        layout.addWidget(self.header_table)
        return page

    def _build_menu(self):
        file_menu = self.menuBar().addMenu("File")
        export_npz = QAction("Export Image/k-space NPZ", self); export_npz.triggered.connect(self.export_npz); file_menu.addAction(export_npz)
        export_header = QAction("Export DICOM Header Excel", self); export_header.triggered.connect(self.export_header_excel); file_menu.addAction(export_header)
        file_menu.addSeparator(); quit_action = QAction("Exit", self); quit_action.triggered.connect(self.close); file_menu.addAction(quit_action)

    def _apply_style(self):
        self.setStyleSheet("""
        QMainWindow, QWidget { background: #171a1f; color: #e6e9ee; }
        QMenuBar, QMenu { background: #20242b; }
        QPushButton, QComboBox, QSpinBox { background: #252b33; border: 1px solid #3b4654; padding: 6px; border-radius: 3px; }
        QPushButton:checked { background: #1464cc; border-color: #2c8cff; }
        QPushButton:hover { border-color: #6594c5; }
        QTreeWidget, QTableWidget { background: #111419; alternate-background-color: #191e25; border: 1px solid #303946; }
        QGroupBox { border: 1px solid #303946; border-radius: 4px; margin-top: 8px; padding-top: 8px; }
        QGroupBox::title { subcontrol-origin: margin; left: 8px; }
        #DropBanner { border: 1px dashed #5c7189; border-radius: 5px; background: #1d232b; }
        #DropBanner[dragActive="true"] { border: 2px solid #2f8cff; background: #20354f; }
        #InfoCard { border: 1px solid #303946; padding: 8px; background: #111419; }
        QSplitter::handle { background: #2f8cff; }
        QSplitter::handle:vertical { height: 4px; }
        QSplitter::handle:horizontal { width: 4px; }
        """)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls(): event.acceptProposedAction()

    def dropEvent(self, event):
        paths = [Path(u.toLocalFile()) for u in event.mimeData().urls() if u.isLocalFile()]
        if paths: self.import_paths(paths); event.acceptProposedAction()

    def import_paths(self, paths: list[Path]):
        try:
            files: list[Path] = []
            for p in paths:
                if p.is_dir(): files.extend([x for x in p.rglob('*') if x.is_file()])
                elif p.suffix.lower() == '.zip': files.extend(self.extract_zip(p))
                else: files.append(p)
            dicoms, deferred = [], []
            for p in files:
                try:
                    entry = self.read_dicom(p); dicoms.append(entry); continue
                except Exception: pass
                deferred.append(p)
            if dicoms:
                dicoms.sort(key=lambda e: e.sort_key); self.dicom_entries = dicoms; self.populate_dicom_tree(); self.show_dicom(0)
            for p in deferred:
                if self.looks_tracker(p): self.load_tracker(p)
                elif p.suffix.lower() in {'.csv', '.txt', '.npy', '.npz'}: self.load_signal_file(p)
                elif p.suffix.lower() in {'.raw', '.bin', '.dat'}: self.statusBar().showMessage(f"Generic binary detected: {p.name}; Tracker PFile is auto-supported in this prototype")
            if not dicoms and not deferred: QMessageBox.information(self, "No files", "No supported files were found.")
        except Exception as exc:
            QMessageBox.critical(self, "Import error", str(exc))

    def extract_zip(self, path: Path) -> list[Path]:
        root = Path(tempfile.mkdtemp(prefix='mri_fft_')); self.temp_dirs.append(root)
        with zipfile.ZipFile(path) as z:
            for m in z.infolist():
                if not str((root / m.filename).resolve()).startswith(str(root.resolve())): raise ValueError("Unsafe ZIP member")
            z.extractall(root)
        return [p for p in root.rglob('*') if p.is_file()]

    def read_dicom(self, path: Path) -> DicomEntry:
        ds = pydicom.dcmread(str(path), force=False)
        if not hasattr(ds, 'PixelData'): raise ValueError('No pixel data')
        arr = ds.pixel_array
        if arr.ndim == 3: arr = arr[0]
        if arr.ndim != 2: raise ValueError('Not 2D')
        arr = arr.astype(float) * float(getattr(ds, 'RescaleSlope', 1)) + float(getattr(ds, 'RescaleIntercept', 0))
        instance = int(getattr(ds, 'InstanceNumber', 0) or 0)
        pos = getattr(ds, 'ImagePositionPatient', None)
        z = float(pos[2]) if pos is not None and len(pos) >= 3 else float(instance)
        return DicomEntry(path, ds, arr, (z, instance, path.name.lower()))

    def populate_dicom_tree(self):
        self.tree.clear(); root = QTreeWidgetItem(["DICOM / 2D Raw"]); self.tree.addTopLevelItem(root)
        series = QTreeWidgetItem([f"Series ({len(self.dicom_entries)})"]); root.addChild(series)
        for i, e in enumerate(self.dicom_entries):
            item = QTreeWidgetItem([e.path.name]); item.setData(0, Qt.UserRole, ("dicom", i)); series.addChild(item)
        root.setExpanded(True); series.setExpanded(True)

    def show_dicom(self, index: int):
        if not self.dicom_entries: return
        index = max(0, min(index, len(self.dicom_entries)-1)); e = self.dicom_entries[index]
        self.current_image = e.image; self.current_kspace = fft2c(e.image); self.current_recon = ifft2c(self.current_kspace)
        self.current_ds = e.ds; self.current_source = str(e.path); self.slice_index = index
        self.slice_label.setText(f"Slice: {index+1}/{len(self.dicom_entries)}")
        self.info.setText(self.dicom_info(e.ds, e.path, index))
        self.fill_header(e.ds); self.refresh_images()

    def dicom_info(self, ds, path, index):
        spacing = getattr(ds, 'PixelSpacing', ['-', '-'])
        return (f"File: {path.name}\nType: DICOM\nSize: {getattr(ds,'Columns','-')} × {getattr(ds,'Rows','-')}\n"
                f"Bit Depth: {getattr(ds,'BitsAllocated','-')} bit\nPixel Spacing: {spacing}\n"
                f"Series: {getattr(ds,'SeriesDescription','-')}\nInstance: {index+1}/{len(self.dicom_entries)}\n"
                f"TE / TR: {getattr(ds,'EchoTime','-')} / {getattr(ds,'RepetitionTime','-')} ms")

    def change_slice(self, delta):
        if self.dicom_entries: self.show_dicom(getattr(self, 'slice_index', 0) + delta)

    def looks_tracker(self, p: Path) -> bool:
        n = p.name.lower()
        if 'trackerimg' in n or 'pfile' in n: return True
        if p.suffix == '' and p.stat().st_size > 4096:
            try:
                rev = np.frombuffer(p.read_bytes()[:4], dtype='<f4')[0]
                return np.isfinite(rev) and 1 < rev < 100
            except Exception: return False
        return False

    def load_tracker(self, path: Path):
        raw = path.read_bytes(); best = None
        for matrix in (256, 192, 160, 128, 96, 64):
            need = matrix * matrix * 4
            if len(raw) < need: continue
            offset = len(raw) - need
            vals = np.frombuffer(raw[offset:], dtype='<i2')
            complex_data = vals[0::2].astype(float) + 1j * vals[1::2].astype(float)
            ks = complex_data.reshape(matrix, matrix)
            image = ifft2c(ks)
            score = np.percentile(np.abs(image), 99) / (np.median(np.abs(image)) + 1e-9)
            if best is None or score > best[0]: best = (score, matrix, offset, ks, image, complex_data)
        if best is None: raise ValueError('No Tracker matrix candidate found')
        _, matrix, offset, ks, image, signal = best
        self.current_kspace = ks; self.current_recon = image; self.current_image = np.abs(image); self.current_ds = None; self.current_source = str(path)
        self.dicom_entries = []; self.slice_label.setText('Tracker PFile')
        self.tree.clear(); root = QTreeWidgetItem(["GE Tracker P File"]); self.tree.addTopLevelItem(root)
        file_item = QTreeWidgetItem([path.name]); root.addChild(file_item)
        signal_item = QTreeWidgetItem([f"Complex raw ({signal.size} samples)"]); signal_item.setData(0, Qt.UserRole, ('signal', len(self.signals))); file_item.addChild(signal_item)
        root.setExpanded(True); file_item.setExpanded(True)
        self.add_signal(signal, f"{path.name} raw complex")
        self.info.setText(f"File: {path.name}\nType: GE Tracker/PFile candidate\nMatrix: {matrix} × {matrix}\nOffset: {offset}\nLayout: complex int16, little-endian\n1D samples: {signal.size}")
        self.refresh_images(); self.update_tracker_preview(signal)

    def load_signal_file(self, path: Path):
        if path.suffix.lower() == '.npy': arr = np.load(path, allow_pickle=False)
        elif path.suffix.lower() == '.npz':
            z = np.load(path, allow_pickle=False); arr = z[list(z.keys())[0]]
        else:
            rows=[]
            with open(path, encoding='utf-8-sig', errors='replace') as f:
                for line in f:
                    nums=[]
                    for token in line.strip().replace(';', ',').split(','):
                        try: nums.append(float(token.strip()))
                        except ValueError: pass
                    if nums: rows.append(nums)
            if not rows: return
            arr = np.array([r[0]+1j*r[1] if len(r)>1 else r[0] for r in rows])
        arr=np.asarray(arr).squeeze()
        if arr.ndim == 1: self.add_signal(arr, path.name)
        elif arr.ndim == 2:
            self.current_image = np.abs(arr); self.current_kspace = fft2c(arr); self.current_recon = ifft2c(self.current_kspace); self.refresh_images()

    def add_signal(self, signal, name):
        signal=np.asarray(signal).squeeze()
        if signal.ndim != 1 or signal.size < 2: return
        self.signals.append({'name': name, 'data': signal})
        self.signal_combo.addItem(name)
        self.signal_combo.setCurrentIndex(len(self.signals)-1)
        self.update_signal_plot(); self.update_tracker_preview(signal)

    def clear_signals(self):
        self.signals.clear(); self.signal_combo.clear(); self.signal_plot.clear(); self.tracker_plot.clear()

    def update_signal_plot(self):
        self.signal_plot.clear(); idx=self.signal_combo.currentIndex()
        if idx < 0 or idx >= len(self.signals): return
        data=np.asarray(self.signals[idx]['data']); component=self.signal_component.currentText()
        if self.signal_fft.isChecked(): data=np.fft.fftshift(np.fft.fft(data)); self.signal_plot.setLabel('bottom','Frequency bin')
        else: self.signal_plot.setLabel('bottom','Sample')
        y=self.component(data, component); self.signal_plot.plot(y)

    def update_tracker_preview(self, signal):
        self.tracker_plot.clear(); self.tracker_plot.plot(np.abs(np.asarray(signal)))

    def component(self, arr, mode):
        if mode == 'Real': return np.real(arr)
        if mode == 'Imaginary': return np.imag(arr)
        if mode == 'Phase': return np.angle(arr)
        return np.abs(arr)

    def set_view_mode(self, mode):
        self.view_mode=mode
        for b, m in [(self.btn_fft,'FFT'),(self.btn_original,'Original'),(self.btn_both,'Both')]: b.setChecked(m==mode)
        self.refresh_images()

    def refresh_images(self):
        if self.current_image is None or self.current_kspace is None: return
        fft_img=np.log1p(np.abs(self.current_kspace)); orig=np.abs(self.current_image)
        if self.view_mode == 'FFT':
            self.primary_panel.show(); self.secondary_panel.hide(); self.primary_panel.label.setText('FFT (k-space)'); self.primary_panel.set_image(fft_img)
        elif self.view_mode == 'Original':
            self.primary_panel.show(); self.secondary_panel.hide(); self.primary_panel.label.setText('Original Image'); self.primary_panel.set_image(orig)
        else:
            self.primary_panel.show(); self.secondary_panel.show(); self.primary_panel.label.setText('FFT (k-space)'); self.secondary_panel.label.setText('Original Image')
            self.primary_panel.set_image(fft_img); self.secondary_panel.set_image(orig)
        rows, cols = orig.shape
        self.line_row=min(self.line_row or rows//2, rows-1); self.line_col=min(self.line_col or cols//2, cols-1)
        self._configure_line_control(rows, cols); self._sync_lines(); self.update_line_profile()

    def _configure_line_control(self, rows, cols):
        maximum = rows-1 if self.line_orientation=='Row' else cols-1
        self.line_spin.blockSignals(True); self.line_slider.blockSignals(True)
        self.line_spin.setRange(0, maximum); self.line_slider.setRange(0, maximum)
        value=self.line_row if self.line_orientation=='Row' else self.line_col
        self.line_spin.setValue(value); self.line_slider.setValue(value)
        self.line_spin.blockSignals(False); self.line_slider.blockSignals(False)

    def _orientation_changed(self, text):
        self.line_orientation=text
        if self.current_image is not None: self._configure_line_control(*self.current_image.shape); self.update_line_profile()

    def _spin_line_changed(self, value):
        self._set_selected_line(value)

    def _slider_line_changed(self, value):
        self._set_selected_line(value)

    def _set_selected_line(self, value):
        if self.current_image is None: return
        if self.line_orientation=='Row': self.line_row=value
        else: self.line_col=value
        self.line_spin.blockSignals(True); self.line_slider.blockSignals(True); self.line_spin.setValue(value); self.line_slider.setValue(value); self.line_spin.blockSignals(False); self.line_slider.blockSignals(False)
        self._sync_lines(); self.update_line_profile()

    def _line_moved(self, row, col):
        self.line_row=row; self.line_col=col
        value=row if self.line_orientation=='Row' else col
        self.line_spin.blockSignals(True); self.line_slider.blockSignals(True); self.line_spin.setValue(value); self.line_slider.setValue(value); self.line_spin.blockSignals(False); self.line_slider.blockSignals(False)
        self._sync_lines(); self.update_line_profile()

    def _sync_lines(self):
        self.primary_panel.set_line_position(self.line_row, self.line_col); self.secondary_panel.set_line_position(self.line_row, self.line_col)

    def active_display_array(self):
        if self.view_mode == 'Original': return np.asarray(self.current_image)
        return np.asarray(self.current_kspace)

    def update_line_profile(self):
        if self.current_image is None or self.current_kspace is None: return
        arr=self.active_display_array(); line=arr[self.line_row,:] if self.line_orientation=='Row' else arr[:,self.line_col]
        y=self.component(line, self.profile_mode.currentText())
        if self.log_profile.isChecked(): y=np.log10(np.maximum(np.abs(y), 1e-12))
        self.profile_plot.clear(); self.profile_plot.plot(y)
        pos=self.line_row if self.line_orientation=='Row' else self.line_col
        self.line_value_label.setText(f"{pos} / {len(y)-1}")

    def send_line_to_signal_studio(self):
        if self.current_image is None: return
        arr=self.active_display_array(); line=arr[self.line_row,:] if self.line_orientation=='Row' else arr[:,self.line_col]
        self.add_signal(line, f"{self.line_orientation} {self.line_row if self.line_orientation=='Row' else self.line_col} — {self.view_mode}")
        self.tabs.setCurrentIndex(1)

    def auto_levels(self):
        self.primary_panel.image_item.setLevels(None); self.secondary_panel.image_item.setLevels(None)

    def _tree_clicked(self, item, column):
        data=item.data(0, Qt.UserRole)
        if not data: return
        if data[0]=='dicom': self.show_dicom(data[1])
        elif data[0]=='signal': self.tabs.setCurrentIndex(1); self.signal_combo.setCurrentIndex(data[1])

    def fill_header(self, ds):
        rows=[]
        for elem in ds.iterall():
            if elem.tag.group == 0x7FE0: continue
            value=str(elem.value); value=value[:1000]+'...' if len(value)>1000 else value
            rows.append((str(elem.tag), elem.keyword, elem.name, elem.VR, str(elem.VM), value))
        self.header_table.setSortingEnabled(False); self.header_table.setRowCount(len(rows))
        for r, vals in enumerate(rows):
            for c, v in enumerate(vals): self.header_table.setItem(r,c,QTableWidgetItem(v))
        self.header_table.setSortingEnabled(True); self.header_table.resizeColumnsToContents()

    def filter_header(self, text):
        text=text.lower()
        for r in range(self.header_table.rowCount()):
            show=any(text in (self.header_table.item(r,c).text().lower() if self.header_table.item(r,c) else '') for c in range(self.header_table.columnCount()))
            self.header_table.setRowHidden(r, not show)

    def export_header_excel(self):
        if self.current_ds is None: QMessageBox.information(self,'No DICOM','Load a DICOM file first.'); return
        filename,_=QFileDialog.getSaveFileName(self,'Export DICOM Header','DICOM_Header.xlsx','Excel (*.xlsx)')
        if not filename: return
        if not filename.lower().endswith('.xlsx'): filename += '.xlsx'
        wb=Workbook(); ws=wb.active; ws.title='DICOM Header'; headers=['Tag','Keyword','Name','VR','VM','Value']; ws.append(headers)
        for cell in ws[1]: cell.font=Font(bold=True); cell.fill=PatternFill('solid', fgColor='D9EAF7')
        for elem in self.current_ds.iterall():
            if elem.tag.group != 0x7FE0: ws.append([str(elem.tag),elem.keyword,elem.name,elem.VR,str(elem.VM),str(elem.value)])
        ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
        for col,width in {'A':16,'B':28,'C':38,'D':8,'E':8,'F':80}.items(): ws.column_dimensions[col].width=width
        for row in ws.iter_rows():
            for cell in row: cell.alignment=Alignment(vertical='top', wrap_text=True)
        wb.save(filename); self.statusBar().showMessage(f'Exported {filename}')

    def export_npz(self):
        if self.current_image is None: return
        filename,_=QFileDialog.getSaveFileName(self,'Export NPZ','MRI_FFT_Data.npz','NPZ (*.npz)')
        if filename:
            if not filename.lower().endswith('.npz'): filename += '.npz'
            np.savez_compressed(filename,image=self.current_image,kspace=self.current_kspace,reconstruction=self.current_recon,source=self.current_source)

    def closeEvent(self,event):
        for d in self.temp_dirs: shutil.rmtree(d, ignore_errors=True)
        event.accept()


def main():
    app=QApplication(sys.argv); app.setApplicationName(APP_NAME)
    win=MainWindow(); win.show(); sys.exit(app.exec())


if __name__ == '__main__': main()
