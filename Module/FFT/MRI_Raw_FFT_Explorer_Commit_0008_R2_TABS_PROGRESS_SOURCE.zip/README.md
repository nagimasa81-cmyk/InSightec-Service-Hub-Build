# MRI Raw & FFT Explorer — Commit 0008 Prototype

Windows desktop prototype based on the approved image-first workspace.

## Main prototype behavior

- Large main image viewer.
- FFT/k-space log-magnitude is the default display.
- One-click display buttons: **FFT**, **Original**, and **Both**.
- The selected button always indicates the current display state.
- Movable horizontal and vertical crosshair lines over the main image.
- Dragging either line updates the lower profile graph immediately.
- Row/Column profile selection with slider and numeric position control.
- Magnitude, Real, Imaginary, and Phase profile modes.
- Resizable upper/lower areas using a live Qt splitter.
- In Both mode, FFT and Original images are displayed side by side with synchronized line positions.
- Drop-only main import workflow. DICOM files, folders, ZIP, GE TrackerImg/PFile, CSV, TXT, NPY, and NPZ are supported by the prototype.
- Existing export operations remain under the File menu.
- DICOM header display, filtering, and Excel export.
- Tracker PFile candidate reconstruction and automatic registration of its complex raw stream in **1D Signal Studio**.
- Selected DICOM/k-space line can be sent directly to 1D Signal Studio.

## Important prototype limitations

- GE Tracker reconstruction uses heuristic matrix and complex-int16 detection. It is not a replacement for GE Orchestra reconstruction.
- Generic `.raw`, `.bin`, and Siemens `.dat` are detected, but the full interactive binary-layout dialog/vendor reconstruction workflow will be reintegrated after evaluation of this new layout.
- FFT shown for DICOM is pseudo-k-space generated from the reconstructed DICOM pixels.

## Run from Python

```text
01_RUN_PYTHON_DEBUG.bat
```

## Recommended local build

```text
02_BUILD_FAST_STANDALONE.bat
```

## GitHub Actions

Place the workflow at the repository root:

```text
.github/workflows/build_mri_raw_fft.yml
```

Run the workflow with `fast_pyinstaller`. The output is a standalone Windows ZIP artifact.


## Commit 0008 R1 — Simple GitHub Artifact

The workflow no longer creates `MRI_Raw_FFT_Explorer_Windows.zip` inside the
GitHub Artifact.

GitHub Actions now uploads the completed standalone folder contents directly.
When the Artifact is downloaded from GitHub, there is only one ZIP layer. After
opening or extracting it, `MRI_Raw_FFT_Explorer.exe`, `_internal`, README, and
BUILD_INFO are immediately available.

Expected download structure:

```text
MRI_Raw_FFT_Explorer_Windows-fast_pyinstaller.zip
├── MRI_Raw_FFT_Explorer.exe
├── _internal
├── README.md
├── BUILD_INFO.txt
└── vendor_sdk_config.json
```


## Commit 0008 R2 — Tab Navigation and Import Progress

- Image Workspace, 1D Signal Studio, and DICOM Header remain available as persistent top tabs.
- 1D Signal Studio includes a prominent Back to Image Workspace button.
- Selecting a Tracker signal in Explorer opens the 1D Signal Studio tab without replacing the main workspace.
- A modal progress window is shown while scanning folders, extracting ZIP files, detecting DICOM images, and loading Tracker/1D data.
- The progress window shows the current file and supports Cancel.
- ZIP extraction still validates paths before extraction.
- The single-layer GitHub Artifact packaging introduced in R1 is retained.
