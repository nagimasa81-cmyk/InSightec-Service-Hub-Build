@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    py -3.13 -m venv .venv
    if errorlevel 1 (
        echo Failed to create Python virtual environment.
        pause
        exit /b 1
    )
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

if exist "build" rmdir /s /q "build"
if exist "dist" rmdir /s /q "dist"
if exist "app.build" rmdir /s /q "app.build"
if exist "app.dist" rmdir /s /q "app.dist"
if exist "app.onefile-build" rmdir /s /q "app.onefile-build"

python -m nuitka ^
  --standalone ^
  --onefile ^
  --enable-plugin=pyside6 ^
  --windows-console-mode=disable ^
  --assume-yes-for-downloads ^
  --output-dir=dist ^
  --output-filename=MRI_Raw_FFT_Explorer.exe ^
  --include-package=pydicom ^
  --include-package=pyqtgraph ^
  --include-package=pylibjpeg ^
  --include-package=pylibjpeg_libjpeg ^
  --include-package=openjpeg ^
  app.py

if errorlevel 1 (
    echo.
    echo Build failed.
    pause
    exit /b 1
)

echo.
echo Build completed:
echo %CD%\dist\MRI_Raw_FFT_Explorer.exe
pause
