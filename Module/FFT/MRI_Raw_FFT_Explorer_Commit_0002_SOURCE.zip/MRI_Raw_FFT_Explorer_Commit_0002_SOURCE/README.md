# MRI Raw & FFT Explorer — Commit 0001

Windows 11 / Python 3.13 / PySide6 application.

## Included functions

### DICOM / 2D
- Open one DICOM file.
- Open and sort a DICOM folder as a slice series.
- Display DICOM image and metadata.
- Convert reconstructed DICOM pixels to pseudo k-space using centered 2D FFT.
- Display k-space as log magnitude, magnitude, phase, real, or imaginary.
- Reconstruct image from k-space using centered 2D inverse FFT.
- Display original, reconstructed magnitude, phase, and difference.
- Import generic 2D raw binary data.
- Import `.npy` and `.npz`.
- Export image, k-space, and reconstruction to compressed `.npz`.

### 1D FFT
- Open CSV, TXT, RAW, BIN, DAT, NPY, or NPZ.
- Read real or complex data.
- Support interleaved real/imaginary binary data.
- Configure sampling rate, FFT length, DC removal, and window function.
- Display time-domain and frequency-domain plots.
- Display magnitude, dB, power, or phase.
- Show peak frequency, peak magnitude, RMS, sample count, and frequency resolution.
- Export FFT results to CSV.

## Important limitation

A normal MRI DICOM image is already reconstructed. Applying FFT to DICOM pixels creates a **pseudo k-space representation**. It does not restore the original scanner acquisition raw data, coil channels, gradients, calibration data, trajectory, or vendor-specific reconstruction information.

## Local debug run

Install Python 3.13, then run:

```text
01_RUN_PYTHON_DEBUG.bat
```

## Local EXE build

Run:

```text
02_BUILD_EXE_NUITKA.bat
```

The EXE is created under:

```text
dist\MRI_Raw_FFT_Explorer.exe
```

A console-enabled build is available with:

```text
03_BUILD_EXE_DEBUG_CONSOLE.bat
```

## GitHub Actions build

1. Create a GitHub repository.
2. Upload the complete contents of this source package.
3. Open the repository **Actions** tab.
4. Select **Build MRI Raw FFT Explorer**.
5. Select **Run workflow**.
6. Download the artifact named `MRI_Raw_FFT_Explorer_Windows`.

## Binary raw import notes

The generic raw importer requires the operator to know:

- data type
- endianness
- header offset
- matrix rows and columns
- whether values are direct, real-only, or interleaved real/imaginary
- whether the input represents image space or k-space

Vendor-specific MRI raw formats such as Siemens TWIX, GE P-file, Philips raw, or Canon raw require separate parsers and are not included in Commit 0001.

## Commit 0002 additions

- Dedicated `Open Tracker PFile` command for extensionless TrackerImg/P-file samples.
- Reads the leading little-endian revision value and displays file diagnostics.
- Generates end-aligned complex int16 candidates for 64, 96, 128, 160, 192, 224, and 256 matrices.
- Tests little- and big-endian layouts.
- Tests centered IFFT, unshifted IFFT, centered FFT, and stored complex magnitude.
- Candidate dropdown exposes matrix, offset, byte order, reconstruction method, and reference match score.
- `Open Reference Image` compares candidates with a JPEG/PNG reference across rotations and reflections.
- The supplied sample is preferentially opened as a 128 x 128, little-endian, interleaved complex int16 tail candidate when no reference image is loaded.

The candidate system is intentionally diagnostic. It does not claim full vendor P-file reconstruction because sequence-specific acquisition and reconstruction metadata may be required.
