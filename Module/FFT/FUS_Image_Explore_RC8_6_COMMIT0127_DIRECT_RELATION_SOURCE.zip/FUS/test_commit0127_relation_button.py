from pathlib import Path
text=Path('app.py').read_text(encoding='utf-8')
assert 'QPushButton("Relation")' in text
assert 'self.relation_button.clicked.connect(self.run_relation_analysis)' in text
assert 'Spike Noise detection was not executed.' in text
assert 'def _relation_records_dicom' in text
assert 'def _relation_records_raw' in text
assert 'Planning MR", "Anatomy MR", "TMAP3", "MEMP' in text
assert 'fft2c(image)' not in text[text.index('def _relation_records_dicom'):text.index('def _highlight_quick_spike_candidates')]
print('Commit0127 static checks: PASS')
