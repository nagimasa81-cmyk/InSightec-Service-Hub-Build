"""Static and isolated logic checks for Commit0126."""
from pathlib import Path
import ast
import json
import re

text = Path('app.py').read_text(encoding='utf-8')
ast.parse(text)
required = [
    'def _selected_raw_paths',
    'def _quick_spike_raw_category',
    'def _quick_spike_raw_virtual_header',
    'metadata_type": "virtual_raw_header',
    'Planning MR', 'Anatomy MR', 'TMAP3', 'MEMP',
    'def _quick_spike_detect_raw',
    'distribution_denominator',
    'spike_denominator',
    'source_type": "RAW',
    'No eligible RAW images were selected',
]
for marker in required:
    assert marker in text, marker

# DICOM and RAW execution paths must remain separate.
start = text.index('    def quick_spike_detect_prototype(self):')
end = text.index('    def _highlight_quick_spike_candidates', start)
dispatch = text[start:end]
assert '_selected_raw_paths(explicit_only=True)' in dispatch
assert '_quick_spike_detect_raw(raw_paths)' in dispatch
assert '_quick_spike_detect_dicom(indices)' in dispatch

# Distribution denominator must be all detected Spike images, not all images
# in the frequency-direction group.
start = text.index('    def _quick_spike_build_correlation')
end = text.index('    def _export_quick_spike_correlation', start)
builder = text[start:end]
assert 'spike_records = [r for r in records if r.get("spike_detected")]' in builder
assert '"distribution_denominator": len(spike_records)' in builder
assert '"spike_denominator": len(spike_state)' in builder

version = json.loads(Path('version.json').read_text(encoding='utf-8'))
assert int(version['commit']) >= 126
assert tuple(map(int, version['version'].split('.'))) >= (5, 53, 0)
print('Commit0126 static checks: PASS')
