"""Static regression checks for Commit0125."""
from pathlib import Path
import ast
text = Path('app.py').read_text(encoding='utf-8')
ast.parse(text)
required = [
    'def _quick_spike_frequency_direction',
    'angle <= 20.0',
    'Oblique >20°',
    'def _quick_spike_sonication_state',
    'def _quick_spike_build_correlation',
    'def _show_quick_spike_correlation_dialog',
    'Check Spike Images',
    'Export CSV / Excel',
    'indices = self._selected_dicom_indices()',
]
for marker in required:
    assert marker in text, marker
# Correlation must use complete selected scope, not the old 160 image sampling.
start = text.index('    def _quick_spike_detect_dicom(self, indices):')
end = text.index('    def _quick_spike_detect_raw', start)
quick = text[start:end]
assert '160' not in quick
assert 'spike_detected' in quick
assert 'review_detected' in quick
print('Commit0125 static checks: PASS')
