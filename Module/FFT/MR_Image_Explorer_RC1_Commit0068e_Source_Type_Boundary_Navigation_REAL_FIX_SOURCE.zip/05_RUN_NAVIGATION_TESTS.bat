@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 -m pytest -q test_commit0067_2_navigation_modules.py test_commit0067_3_navigation_architecture.py test_commit0068_series_boundary_navigation.py test_commit0068a_tree_series_autosync.py test_commit0068c_real_series_grouping.py test_commit0068d_tree_authoritative_navigation.py
) else (
    python -m pytest -q test_commit0067_2_navigation_modules.py test_commit0067_3_navigation_architecture.py test_commit0068_series_boundary_navigation.py test_commit0068a_tree_series_autosync.py test_commit0068c_real_series_grouping.py test_commit0068d_tree_authoritative_navigation.py
)
if errorlevel 1 (
    echo.
    echo Navigation tests FAILED.
    pause
    exit /b 1
)
echo.
echo Navigation tests PASSED.
pause
