# MRI Raw & FFT Explorer — Commit 0007

SDKなしで動作するGeneric FFT Engineを基盤に、任意導入のGE Orchestra / Siemens IDEA・ICE / Siemens TWIXプラグインへ自動フォールバックするWindowsツールです。

## Commit 0007 additions
- Plugin Manager / Vendor SDK status
- Auto reconstruction: official SDK/plugin first, Generic FFT fallback when unavailable
- SDK files and licenses are never bundled
- 1D Signal Studio integrated into the foundation
- Up to 8 overlaid signals
- Time ROI selection and ROI-only FFT
- FFT/IFFT, magnitude, dB, power, PSD, phase, real, imaginary
- Low-pass, high-pass, band-pass, band-stop, notch and Gaussian frequency filters
- Filtered IFFT preview
- Peak, RMS, noise floor, SNR, frequency resolution and -3 dB bandwidth
- Extract image or k-space center row into Signal Studio
- CSV/NPY/NPZ/RAW/BIN/DAT import
- FFT CSV and signal NPZ export
- Session save/load for image, k-space, signals and main settings

## Build
Recommended GitHub Actions option: `fast_pyinstaller`. It creates a standalone Windows folder and a one-level distribution ZIP.

Local: `02_BUILD_FAST_STANDALONE.bat`

## SDK behavior
Without any SDK, DICOM, generic raw, Tracker candidate reconstruction, 2D FFT/IFFT and the complete 1D Signal Studio remain available. Vendor SDK adapters are optional external executables configured in `vendor_sdk_config.json`.


## Commit 0007 additions

- Expanded DICOM header viewer with Tag, Keyword, Name, VR, VM, private-tag indicator, and full value.
- Search/filter across all displayed DICOM header columns.
- Export the current DICOM header to formatted Excel `.xlsx`.
- Export an entire loaded DICOM series to Excel with `Series Summary` and `All Header Elements` worksheets.
- Pixel Data is intentionally omitted from the header table and Excel output to avoid very large workbooks.


## Commit 0007 — Drag-and-Drop Smart Import

The complete main window accepts files and folders by drag and drop.

Supported drop targets:

- Individual DICOM files
- Multiple DICOM files as a series
- DICOM folders with recursive scanning
- GE Tracker/PFile and extensionless TrackerImg files
- CSV and TXT 1D signal files
- NPY and NPZ with automatic 1D/2D detection
- RAW and BIN through the generic import settings dialog
- Siemens `.dat` routed to the Vendor SDK/TWIX workflow
- JPEG, PNG, BMP, and TIFF as reference images
- ZIP packages, extracted to a temporary folder and imported automatically

The original File menu and Open buttons remain available.

Security:

- ZIP path traversal is checked before extraction.
- Temporary ZIP extraction folders are removed when the application closes.
- Unsupported files are reported without stopping other imports.

## Commit 0007 R1 — GitHub source path fix

The GitHub Actions workflow no longer assumes that `requirements.txt` is at the repository root.

It now:

- Searches recursively for an extracted source folder containing `app.py` and `requirements.txt`.
- If no extracted source exists, finds the newest matching MRI Source ZIP anywhere in the repository.
- Extracts the ZIP into a temporary build directory.
- Validates the required source files before installing dependencies.
- Builds from the detected source directory.
- Uploads a single distribution ZIP.

The `setup-python` pip cache option was removed because it fails before source discovery when dependency files are stored inside a module folder or Source ZIP.

## Commit 0007 R2 — Repository-root workflow correction

GitHub Actions only loads workflow files stored in the repository root at:

```text
.github/workflows/
```

A workflow located inside a module folder or inside a Source ZIP is not registered by GitHub Actions.

Copy the included file:

```text
.github/workflows/build_windows.yml
```

to the repository root and replace the older MRI workflow. The corrected `Set up Python 3.13` step intentionally has no `cache:` or `cache-dependency-path:` entry. Source discovery and ZIP extraction occur after Python setup.


## Commit 0007 R3 build correction

- Always selects the newest `MRI_Raw_FFT_Explorer*_SOURCE.zip`.
- Does not accidentally build an older extracted `app.py` directory.
- Creates an SDK-disabled `vendor_sdk_config.json` when missing.
- Creates a Generic-only adapter stub when `vendor_adapters.py` is missing.
- Prints the selected build directory and source file inventory before compilation.
- Keeps GE and Siemens SDKs optional.
