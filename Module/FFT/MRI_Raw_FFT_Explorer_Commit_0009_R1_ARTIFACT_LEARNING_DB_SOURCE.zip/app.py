from __future__ import annotations

import csv
import copy
import shutil
import sys
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import pydicom
import pyqtgraph as pg
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QAction
from pydicom.uid import generate_uid
from tracker_position import DirectionMeasurement, signal_peak_coordinate, solve_position
from artifact_learning_db import ArtifactDatabase, image_features
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFileDialog, QFormLayout, QFrame,
    QGroupBox, QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QPushButton,
    QDoubleSpinBox, QProgressDialog, QSlider, QSpinBox, QSplitter, QStatusBar, QTabWidget, QTableWidget,
    QTableWidgetItem, QTextEdit, QTreeWidget, QTreeWidgetItem, QTreeWidgetItemIterator, QVBoxLayout, QWidget,
)

APP_NAME = "MRI Raw & FFT Explorer"
APP_VERSION = "0.9.0 Prototype Commit0009 Artifact Learning"

pg.setConfigOptions(imageAxisOrder="row-major", antialias=True)


def fft2c(image: np.ndarray) -> np.ndarray:
    return np.fft.fftshift(np.fft.fft2(np.fft.ifftshift(image)))


def ifft2c(kspace: np.ndarray) -> np.ndarray:
    return np.fft.fftshift(np.fft.ifft2(np.fft.ifftshift(kspace)))


def display_array(arr: np.ndarray, mode: str) -> np.ndarray:
    if mode == "FFT":
        return np.log1p(np.abs(arr))
    return np.abs(arr)


@dataclass
class DicomEntry:
    path: Path
    ds: pydicom.dataset.FileDataset
    image: np.ndarray
    sort_key: tuple


class DropBanner(QFrame):
    pathsDropped = Signal(list)

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.setObjectName("DropBanner")
        layout = QVBoxLayout(self)
        self.title = QLabel("Drop DICOM / Raw / P File / 1D Data / Folder / ZIP Here")
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setStyleSheet("font-size: 17px; font-weight: 600;")
        subtitle = QLabel("DICOM, RAW, GE TrackerImg/PFile, Siemens .dat, CSV/TXT/NPY/NPZ, images")
        subtitle.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.title)
        layout.addWidget(subtitle)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self.setProperty("dragActive", True)
            self.style().unpolish(self); self.style().polish(self)

    def dragLeaveEvent(self, event):
        self.setProperty("dragActive", False)
        self.style().unpolish(self); self.style().polish(self)

    def dropEvent(self, event):
        self.setProperty("dragActive", False)
        self.style().unpolish(self); self.style().polish(self)
        paths = [Path(u.toLocalFile()) for u in event.mimeData().urls() if u.isLocalFile()]
        if paths:
            self.pathsDropped.emit(paths)
            event.acceptProposedAction()


class ImagePanel(QWidget):
    lineChanged = Signal(int, int)

    def __init__(self, title: str):
        super().__init__()
        layout = QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        self.label = QLabel(title)
        self.label.setStyleSheet("font-weight: 600; padding: 3px;")
        layout.addWidget(self.label)
        self.plot = pg.PlotWidget()
        self.plot.setAspectLocked(True)
        self.plot.hideAxis("left"); self.plot.hideAxis("bottom")
        self.image_item = pg.ImageItem()
        self.plot.addItem(self.image_item)
        self.hline = pg.InfiniteLine(angle=0, movable=True, pen=pg.mkPen('#ff4949', width=1.5, style=Qt.DashLine))
        self.vline = pg.InfiniteLine(angle=90, movable=True, pen=pg.mkPen('#ff4949', width=1.5, style=Qt.DashLine))
        self.plot.addItem(self.hline); self.plot.addItem(self.vline)
        self.hline.sigPositionChanged.connect(self._emit_position)
        self.vline.sigPositionChanged.connect(self._emit_position)
        self.comp_roi = pg.RectROI([10, 10], [40, 40], pen=pg.mkPen("#35a7ff", width=2))
        self.comp_roi.addScaleHandle([1, 1], [0, 0])
        self.comp_roi.addScaleHandle([0, 0], [1, 1])
        self.comp_roi.hide()
        self.plot.addItem(self.comp_roi)
        layout.addWidget(self.plot, 1)
        self.shape = (1, 1)
        self.current_levels = None

    def set_image(self, image: np.ndarray, auto_levels=True, levels=None):
        image = np.asarray(image, dtype=float)
        self.shape = image.shape[:2]
        self.current_levels = levels
        self.image_item.setImage(image, autoLevels=auto_levels if levels is None else False, levels=levels)
        self.plot.setRange(xRange=(0, self.shape[1]), yRange=(0, self.shape[0]), padding=0)
        self.set_line_position(self.shape[0] // 2, self.shape[1] // 2)

    def set_levels(self, low: float, high: float):
        if high <= low:
            high = low + 1.0
        self.current_levels = (float(low), float(high))
        self.image_item.setLevels(self.current_levels)

    def show_comp_roi(self):
        rows, cols = self.shape
        width = max(8, cols // 5)
        height = max(8, rows // 5)
        self.comp_roi.setPos((cols - width) / 2, (rows - height) / 2)
        self.comp_roi.setSize((width, height))
        self.comp_roi.show()

    def hide_comp_roi(self):
        self.comp_roi.hide()

    def comp_roi_bounds(self):
        pos = self.comp_roi.pos()
        size = self.comp_roi.size()
        x0 = max(0, min(int(round(pos.x())), self.shape[1] - 1))
        y0 = max(0, min(int(round(pos.y())), self.shape[0] - 1))
        x1 = max(x0 + 1, min(int(round(pos.x() + size.x())), self.shape[1]))
        y1 = max(y0 + 1, min(int(round(pos.y() + size.y())), self.shape[0]))
        return y0, y1, x0, x1

    def set_line_position(self, row: int, col: int):
        row = max(0, min(int(row), self.shape[0] - 1))
        col = max(0, min(int(col), self.shape[1] - 1))
        self.hline.blockSignals(True); self.vline.blockSignals(True)
        self.hline.setPos(row); self.vline.setPos(col)
        self.hline.blockSignals(False); self.vline.blockSignals(False)

    def _emit_position(self):
        row = max(0, min(int(round(self.hline.value())), self.shape[0] - 1))
        col = max(0, min(int(round(self.vline.value())), self.shape[1] - 1))
        self.lineChanged.emit(row, col)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} {APP_VERSION}")
        self.resize(1550, 950)
        self.setAcceptDrops(True)
        self.temp_dirs: list[Path] = []
        self.dicom_entries: list[DicomEntry] = []
        self.current_image: Optional[np.ndarray] = None
        self.current_kspace: Optional[np.ndarray] = None
        self.current_recon: Optional[np.ndarray] = None
        self.current_ds = None
        self.current_source = ""
        self.view_mode = "FFT"
        self.line_orientation = "Row"
        self.line_row = 0
        self.line_col = 0
        self.signals: list[dict] = []
        self.imported_paths: list[Path] = []
        self.spike_results: list[dict] = []
        self.active_spike_indices = np.array([], dtype=int)
        self.tracker_matrix: Optional[np.ndarray] = None
        self.tracker_source_path: Optional[Path] = None
        self.tracker_line_metrics: list[dict] = []
        self.tracker_selected_lines: list[int] = []
        self.tracker_position_measurements: list[DirectionMeasurement] = []
        self.artifact_db: Optional[ArtifactDatabase] = None
        self.artifact_db_path: Optional[Path] = None
        self.artifact_selected_indices: list[int] = []
        self.normal_reference_image: Optional[np.ndarray] = None
        self.normal_reference_path: Optional[Path] = None
        self.addsub_a: Optional[dict] = None
        self.addsub_b: Optional[dict] = None
        self.processed_images: dict[str, np.ndarray] = {}
        self.processed_sources: dict[str, Path] = {}
        self.window_level: Optional[float] = None
        self.dynamic_range: Optional[float] = None
        self.level_preset = "Auto"

        self._build_ui()
        self._build_menu()
        self._apply_style()
        self.statusBar().showMessage("Ready — drop files or folders above")

    def _build_ui(self):
        root = QWidget(); root_l = QVBoxLayout(root); root_l.setContentsMargins(8, 8, 8, 8)
        self.drop_banner = DropBanner(); self.drop_banner.pathsDropped.connect(self.import_paths)
        root_l.addWidget(self.drop_banner)

        self.tabs = QTabWidget()
        self.tabs.setMovable(False)
        self.tabs.setDocumentMode(False)
        self.tabs.setTabPosition(QTabWidget.North)
        self.tabs.addTab(self._build_workspace(), "Image Workspace")
        self.tabs.addTab(self._build_signal_studio(), "1D Signal Studio")
        self.tabs.addTab(self._build_metadata(), "DICOM Header")
        self.tabs.addTab(self._build_tracker_explorer(), "Tracker Signal Explorer")
        self.tabs.addTab(self._build_tracker_position(), "Tracker Position")
        self.tabs.addTab(self._build_spike_results(), "Spike Detection")
        self.tabs.addTab(self._build_artifact_learning(), "Artifact Learning")
        root_l.addWidget(self.tabs, 1)
        self.setCentralWidget(root)
        self.setStatusBar(QStatusBar())

    def _build_workspace(self):
        page = QWidget(); layout = QHBoxLayout(page); layout.setContentsMargins(0, 6, 0, 0)
        main_split = QSplitter(Qt.Horizontal)

        left = QWidget(); ll = QVBoxLayout(left); ll.setContentsMargins(0, 0, 0, 0)
        self.tree = QTreeWidget(); self.tree.setHeaderLabel("Explorer")
        self.tree.setSelectionMode(QTreeWidget.ExtendedSelection)
        self.tree.itemClicked.connect(self._tree_clicked)
        self.tree.itemSelectionChanged.connect(self._tree_selection_changed)
        self.tree.currentItemChanged.connect(self._tree_current_changed)
        ll.addWidget(self.tree, 1)
        self.info = QLabel("No file loaded")
        self.info.setWordWrap(True); self.info.setMinimumHeight(150)
        self.info.setObjectName("InfoCard")
        ll.addWidget(self.info)
        main_split.addWidget(left)

        center = QWidget(); cl = QVBoxLayout(center); cl.setContentsMargins(0, 0, 0, 0)
        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel("Display"))
        self.btn_fft = QPushButton("FFT")
        self.btn_original = QPushButton("Original")
        self.btn_both = QPushButton("Both")
        for b, mode in [(self.btn_fft, "FFT"), (self.btn_original, "Original"), (self.btn_both, "Both")]:
            b.setCheckable(True); b.clicked.connect(lambda checked=False, m=mode: self.set_view_mode(m)); mode_row.addWidget(b)
        mode_row.addStretch(1)
        self.slice_label = QLabel("Slice: -")
        self.prev_btn = QPushButton("Previous"); self.next_btn = QPushButton("Next")
        self.prev_btn.clicked.connect(lambda: self.change_slice(-1)); self.next_btn.clicked.connect(lambda: self.change_slice(1))
        mode_row.addWidget(self.prev_btn); mode_row.addWidget(self.next_btn); mode_row.addWidget(self.slice_label)
        cl.addLayout(mode_row)

        self.vertical_splitter = QSplitter(Qt.Vertical)
        image_container = QWidget(); il = QVBoxLayout(image_container); il.setContentsMargins(0, 0, 0, 0)
        self.image_splitter = QSplitter(Qt.Horizontal)
        self.primary_panel = ImagePanel("FFT (k-space)")
        self.secondary_panel = ImagePanel("Original")
        self.primary_panel.lineChanged.connect(self._line_moved)
        self.secondary_panel.lineChanged.connect(self._line_moved)
        self.image_splitter.addWidget(self.primary_panel); self.image_splitter.addWidget(self.secondary_panel)
        il.addWidget(self.image_splitter, 1)

        line_bar = QHBoxLayout()
        line_bar.addWidget(QLabel("Line"))
        self.orientation_combo = QComboBox(); self.orientation_combo.addItems(["Row", "Column"])
        self.orientation_combo.currentTextChanged.connect(self._orientation_changed)
        line_bar.addWidget(self.orientation_combo)
        self.line_spin = QSpinBox(); self.line_spin.valueChanged.connect(self._spin_line_changed)
        line_bar.addWidget(self.line_spin)
        self.line_slider = QSlider(Qt.Horizontal); self.line_slider.valueChanged.connect(self._slider_line_changed)
        line_bar.addWidget(self.line_slider, 1)
        self.line_value_label = QLabel("-")
        line_bar.addWidget(self.line_value_label)
        il.addLayout(line_bar)
        self.vertical_splitter.addWidget(image_container)

        lower = QWidget(); low = QHBoxLayout(lower); low.setContentsMargins(0, 0, 0, 0)
        self.profile_plot = pg.PlotWidget(title="Selected Line Profile")
        self.profile_plot.showGrid(x=True, y=True, alpha=.2)
        self.profile_plot.setLabel("bottom", "Sample")
        low.addWidget(self.profile_plot, 2)
        self.tracker_plot = pg.PlotWidget(title="Tracker / Active 1D Signal")
        self.tracker_plot.showGrid(x=True, y=True, alpha=.2)
        low.addWidget(self.tracker_plot, 1)
        self.vertical_splitter.addWidget(lower)
        self.vertical_splitter.setSizes([620, 260])
        cl.addWidget(self.vertical_splitter, 1)
        main_split.addWidget(center)

        right = QWidget(); rl = QVBoxLayout(right); rl.setContentsMargins(0, 0, 0, 0)
        profile_group = QGroupBox("Profile")
        form = QFormLayout(profile_group)
        self.profile_mode = QComboBox(); self.profile_mode.addItems(["Magnitude", "Real", "Imaginary", "Phase"])
        self.profile_mode.currentTextChanged.connect(self.update_line_profile)
        form.addRow("Type", self.profile_mode)
        self.log_profile = QCheckBox("Log scale"); self.log_profile.toggled.connect(self.update_line_profile)
        form.addRow(self.log_profile)
        rl.addWidget(profile_group)
        self.btn_send_signal = QPushButton("Send selected line to 1D Studio")
        self.btn_send_signal.clicked.connect(self.send_line_to_signal_studio)
        rl.addWidget(self.btn_send_signal)
        self.btn_auto = QPushButton("Auto Levels"); self.btn_auto.clicked.connect(self.auto_levels)
        rl.addWidget(self.btn_auto)
        self.btn_spike = QPushButton("Spike")
        self.btn_spike.setToolTip("Scan imported RAW/PFile data and list files containing spike-noise candidates")
        self.btn_spike.clicked.connect(self.detect_spikes)
        self.btn_spike.setStyleSheet("QPushButton { background: #7a2430; font-weight: 700; } QPushButton:hover { background: #a23242; }")
        rl.addWidget(self.btn_spike)

        display_group = QGroupBox("Dynamic Range / Window Level")
        display_form = QFormLayout(display_group)
        self.level_preset_combo = QComboBox()
        self.level_preset_combo.addItems(["Auto", "Wide", "Soft Tissue", "High Contrast", "Narrow"])
        self.level_preset_combo.currentTextChanged.connect(self.apply_level_preset)
        display_form.addRow("Preset", self.level_preset_combo)

        self.window_level_spin = QDoubleSpinBox()
        self.window_level_spin.setRange(-1e12, 1e12)
        self.window_level_spin.setDecimals(3)
        self.window_level_spin.valueChanged.connect(self._manual_levels_changed)
        display_form.addRow("Window level", self.window_level_spin)

        self.dynamic_range_spin = QDoubleSpinBox()
        self.dynamic_range_spin.setRange(1e-9, 1e12)
        self.dynamic_range_spin.setDecimals(3)
        self.dynamic_range_spin.valueChanged.connect(self._manual_levels_changed)
        display_form.addRow("Dynamic range", self.dynamic_range_spin)
        rl.addWidget(display_group)

        addsub_group = QGroupBox("Image Add / Subtract")
        addsub_layout = QVBoxLayout(addsub_group)
        addsub_row1 = QHBoxLayout()
        self.set_a_button = QPushButton("Set Current as A")
        self.set_b_button = QPushButton("Set Current as B")
        self.set_a_button.clicked.connect(lambda: self.set_addsub_source("A"))
        self.set_b_button.clicked.connect(lambda: self.set_addsub_source("B"))
        addsub_row1.addWidget(self.set_a_button); addsub_row1.addWidget(self.set_b_button)
        addsub_layout.addLayout(addsub_row1)
        self.addsub_status = QLabel("A: -\nB: -")
        self.addsub_status.setWordWrap(True)
        addsub_layout.addWidget(self.addsub_status)
        addsub_row2 = QHBoxLayout()
        self.add_button = QPushButton("A + B")
        self.subtract_button = QPushButton("A - B")
        self.add_button.clicked.connect(lambda: self.run_addsub("add"))
        self.subtract_button.clicked.connect(lambda: self.run_addsub("subtract"))
        addsub_row2.addWidget(self.add_button); addsub_row2.addWidget(self.subtract_button)
        addsub_layout.addLayout(addsub_row2)
        rl.addWidget(addsub_group)

        comp_group = QGroupBox("Signal Compensation")
        comp_layout = QVBoxLayout(comp_group)
        self.select_comp_button = QPushButton("Select Compensation Region")
        self.apply_comp_button = QPushButton("Apply Compensation")
        self.cancel_comp_button = QPushButton("Clear Region")
        self.select_comp_button.clicked.connect(self.start_compensation_roi)
        self.apply_comp_button.clicked.connect(self.apply_compensation)
        self.cancel_comp_button.clicked.connect(self.clear_compensation_roi)
        comp_layout.addWidget(self.select_comp_button)
        comp_row = QHBoxLayout()
        comp_row.addWidget(self.apply_comp_button); comp_row.addWidget(self.cancel_comp_button)
        comp_layout.addLayout(comp_row)
        rl.addWidget(comp_group)

        rl.addStretch(1)
        main_split.addWidget(right)
        main_split.setSizes([230, 1100, 190])
        layout.addWidget(main_split)
        self.set_view_mode("FFT")
        return page

    def _build_signal_studio(self):
        page = QWidget(); layout = QVBoxLayout(page)
        top = QHBoxLayout()
        self.back_to_workspace = QPushButton("← Back to Image Workspace")
        self.back_to_workspace.clicked.connect(lambda: self.tabs.setCurrentIndex(0))
        top.addWidget(self.back_to_workspace)
        self.signal_combo = QComboBox(); self.signal_combo.currentIndexChanged.connect(self.update_signal_plot)
        self.signal_component = QComboBox(); self.signal_component.addItems(["Magnitude", "Real", "Imaginary", "Phase"])
        self.signal_component.currentTextChanged.connect(self.update_signal_plot)
        self.signal_fft = QCheckBox("Frequency display (FFT)"); self.signal_fft.setChecked(False); self.signal_fft.toggled.connect(self.update_signal_plot)
        clear = QPushButton("Clear signals"); clear.clicked.connect(self.clear_signals)
        top.addWidget(QLabel("Signal")); top.addWidget(self.signal_combo, 1); top.addWidget(self.signal_component); top.addWidget(self.signal_fft); top.addWidget(clear)
        layout.addLayout(top)
        self.signal_plot = pg.PlotWidget(); self.signal_plot.showGrid(x=True, y=True, alpha=.2)
        layout.addWidget(self.signal_plot, 1)
        note = QLabel("Tracker PFile/TrackerImg drops are automatically registered here as complex 1D raw signals.")
        note.setWordWrap(True); layout.addWidget(note)
        return page

    def _build_metadata(self):
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout()
        self.header_filter = QComboBox(); self.header_filter.setEditable(True); self.header_filter.setInsertPolicy(QComboBox.NoInsert)
        self.header_filter.lineEdit().setPlaceholderText("Filter header tags...")
        self.header_filter.lineEdit().textChanged.connect(self.filter_header)
        export = QPushButton("Export Current Header to Excel"); export.clicked.connect(self.export_header_excel)
        row.addWidget(self.header_filter, 1); row.addWidget(export)
        layout.addLayout(row)
        self.header_table = QTableWidget(0, 6)
        self.header_table.setHorizontalHeaderLabels(["Tag", "Keyword", "Name", "VR", "VM", "Value"])
        self.header_table.horizontalHeader().setStretchLastSection(True)
        self.header_table.setSortingEnabled(True)
        layout.addWidget(self.header_table)
        return page

    def _build_tracker_explorer(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        controls = QHBoxLayout()
        self.tracker_drop_text = QLabel(
            "Drop a Tracker PFile / TrackerImg anywhere in the window. "
            "This tab reads and ranks raw lines directly without FFT."
        )
        self.tracker_drop_text.setWordWrap(True)
        controls.addWidget(self.tracker_drop_text, 1)

        controls.addWidget(QLabel("Top lines"))
        self.tracker_top_count = QSpinBox()
        self.tracker_top_count.setRange(1, 100)
        self.tracker_top_count.setValue(20)
        self.tracker_top_count.valueChanged.connect(self._refresh_tracker_ranking)
        controls.addWidget(self.tracker_top_count)

        controls.addWidget(QLabel("Rank by"))
        self.tracker_metric_combo = QComboBox()
        self.tracker_metric_combo.addItems(["Peak", "RMS", "Energy", "Mean magnitude", "Variance"])
        self.tracker_metric_combo.currentTextChanged.connect(self._refresh_tracker_ranking)
        controls.addWidget(self.tracker_metric_combo)

        self.tracker_export_button = QPushButton("Export CSV")
        self.tracker_export_button.clicked.connect(self.export_tracker_lines_csv)
        controls.addWidget(self.tracker_export_button)
        layout.addLayout(controls)

        self.tracker_summary = QLabel("No Tracker file loaded.")
        self.tracker_summary.setWordWrap(True)
        layout.addWidget(self.tracker_summary)

        splitter = QSplitter(Qt.Horizontal)

        ranking_box = QGroupBox("Strong Signal Lines")
        ranking_layout = QVBoxLayout(ranking_box)
        self.tracker_table = QTableWidget(0, 8)
        self.tracker_table.setHorizontalHeaderLabels(
            ["Rank", "Line", "Peak", "RMS", "Energy", "Mean", "Variance", "Relative strength"]
        )
        self.tracker_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.tracker_table.setSelectionMode(QTableWidget.ExtendedSelection)
        self.tracker_table.itemSelectionChanged.connect(self._tracker_selection_changed)
        self.tracker_table.horizontalHeader().setStretchLastSection(True)
        ranking_layout.addWidget(self.tracker_table)

        viewer_box = QGroupBox("Selected Tracker Raw Line — FFT Disabled")
        viewer_layout = QVBoxLayout(viewer_box)
        self.tracker_raw_plot = pg.PlotWidget()
        self.tracker_raw_plot.showGrid(x=True, y=True, alpha=0.25)
        self.tracker_raw_plot.setLabel("bottom", "Sample")
        self.tracker_raw_plot.setLabel("left", "Signal")
        viewer_layout.addWidget(self.tracker_raw_plot, 1)

        viewer_controls = QHBoxLayout()
        viewer_controls.addWidget(QLabel("Component"))
        self.tracker_component_combo = QComboBox()
        self.tracker_component_combo.addItems(["Magnitude", "Real", "Imaginary", "Phase"])
        self.tracker_component_combo.currentTextChanged.connect(self._plot_tracker_selected_lines)
        viewer_controls.addWidget(self.tracker_component_combo)

        self.tracker_previous_button = QPushButton("Previous Strong Line")
        self.tracker_previous_button.clicked.connect(self._select_previous_tracker_line)
        viewer_controls.addWidget(self.tracker_previous_button)

        self.tracker_next_button = QPushButton("Next Strong Line")
        self.tracker_next_button.clicked.connect(self._select_next_tracker_line)
        viewer_controls.addWidget(self.tracker_next_button)
        viewer_controls.addStretch(1)
        viewer_layout.addLayout(viewer_controls)

        self.tracker_metrics_label = QLabel("-")
        self.tracker_metrics_label.setWordWrap(True)
        viewer_layout.addWidget(self.tracker_metrics_label)

        splitter.addWidget(ranking_box)
        splitter.addWidget(viewer_box)
        splitter.setSizes([520, 900])
        layout.addWidget(splitter, 1)

        explanation = QLabel(
            "Tracker Signal Explorer and Spike Detection are separate. "
            "This tab automatically picks high-signal raw lines and displays their original samples without FFT."
        )
        explanation.setWordWrap(True)
        layout.addWidget(explanation)
        return page

    def _build_tracker_position(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        top = QHBoxLayout()
        top.addWidget(QLabel("FFT length"))
        self.position_fft_length = QSpinBox()
        self.position_fft_length.setRange(64, 65536)
        self.position_fft_length.setSingleStep(64)
        self.position_fft_length.setValue(1024)
        top.addWidget(self.position_fft_length)

        top.addWidget(QLabel("FOV (mm)"))
        self.position_fov = QDoubleSpinBox()
        self.position_fov.setRange(1.0, 5000.0)
        self.position_fov.setDecimals(3)
        self.position_fov.setValue(500.0)
        top.addWidget(self.position_fov)

        self.position_use_top = QPushButton("Use Top 3 Tracker Lines")
        self.position_use_top.clicked.connect(self.populate_position_top_lines)
        top.addWidget(self.position_use_top)

        self.position_calculate = QPushButton("Calculate Position")
        self.position_calculate.clicked.connect(self.calculate_tracker_position)
        top.addWidget(self.position_calculate)
        top.addStretch(1)
        layout.addLayout(top)

        offset_group = QGroupBox("Center Offset and Coordinate Convention")
        offset_form = QFormLayout(offset_group)
        offset_row = QHBoxLayout()
        self.position_offset_x = QDoubleSpinBox()
        self.position_offset_y = QDoubleSpinBox()
        self.position_offset_z = QDoubleSpinBox()
        for spin in (self.position_offset_x, self.position_offset_y, self.position_offset_z):
            spin.setRange(-5000.0, 5000.0)
            spin.setDecimals(4)
            spin.setValue(0.0)
        offset_row.addWidget(QLabel("X"))
        offset_row.addWidget(self.position_offset_x)
        offset_row.addWidget(QLabel("Y"))
        offset_row.addWidget(self.position_offset_y)
        offset_row.addWidget(QLabel("Z"))
        offset_row.addWidget(self.position_offset_z)
        offset_form.addRow("CenterOffset (mm)", offset_row)

        self.position_oppose_ap = QCheckBox("Oppose AP coordinate")
        self.position_oppose_ap.setChecked(True)
        offset_form.addRow(self.position_oppose_ap)
        layout.addWidget(offset_group)

        self.position_table = QTableWidget(3, 7)
        self.position_table.setHorizontalHeaderLabels([
            "Line", "Plane", "Rotation (deg)", "Peak bin",
            "Coordinate (mm)", "Peak/Background", "Use"
        ])
        plane_names = ["Axial", "Coronal", "Sagittal"]
        for row in range(3):
            self.position_table.setItem(row, 0, QTableWidgetItem(str(row)))
            plane_combo = QComboBox()
            plane_combo.addItems(plane_names)
            plane_combo.setCurrentIndex(row)
            self.position_table.setCellWidget(row, 1, plane_combo)

            rotation = QDoubleSpinBox()
            rotation.setRange(-360.0, 360.0)
            rotation.setDecimals(4)
            rotation.setValue(0.0)
            self.position_table.setCellWidget(row, 2, rotation)

            self.position_table.setItem(row, 3, QTableWidgetItem("-"))
            self.position_table.setItem(row, 4, QTableWidgetItem("-"))
            self.position_table.setItem(row, 5, QTableWidgetItem("-"))

            use_box = QCheckBox()
            use_box.setChecked(True)
            self.position_table.setCellWidget(row, 6, use_box)

        self.position_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.position_table)

        result_group = QGroupBox("Converted Tracker Position")
        result_layout = QVBoxLayout(result_group)
        self.position_result = QLabel(
            "Load a Tracker file, choose three directional lines, set Plane / Rotation / CenterOffset, "
            "then calculate the position."
        )
        self.position_result.setWordWrap(True)
        self.position_result.setTextInteractionFlags(Qt.TextSelectableByMouse)
        result_layout.addWidget(self.position_result)
        layout.addWidget(result_group)

        note = QLabel(
            "The basic conversion matches the attached TrackerApp structure: FFT peak bin → FOV coordinate → "
            "multi-direction geometric solve → CenterOffset → optional AP sign inversion. "
            "Gradient-map non-linearity correction is not applied unless a vendor gradient adapter is added."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        layout.addStretch(1)
        return page

    def _build_spike_results(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        controls = QHBoxLayout()
        controls.addWidget(QLabel("Robust threshold"))
        self.spike_threshold = QDoubleSpinBox()
        self.spike_threshold.setRange(3.0, 30.0)
        self.spike_threshold.setDecimals(1)
        self.spike_threshold.setSingleStep(0.5)
        self.spike_threshold.setValue(8.0)
        self.spike_threshold.setToolTip(
            "Higher values reduce false detections. Detection combines amplitude and first-difference robust Z scores."
        )
        controls.addWidget(self.spike_threshold)

        self.spike_rescan = QPushButton("Scan Imported RAW Files")
        self.spike_rescan.clicked.connect(self.detect_spikes)
        controls.addWidget(self.spike_rescan)

        self.spike_only_flagged = QCheckBox("Show flagged only")
        self.spike_only_flagged.setChecked(True)
        self.spike_only_flagged.toggled.connect(self._refresh_spike_table)
        controls.addWidget(self.spike_only_flagged)
        controls.addStretch(1)
        layout.addLayout(controls)

        self.spike_summary = QLabel("No spike scan has been run.")
        self.spike_summary.setWordWrap(True)
        layout.addWidget(self.spike_summary)

        self.spike_table = QTableWidget(0, 8)
        self.spike_table.setHorizontalHeaderLabels([
            "Status", "File", "Type", "Score", "Spike groups", "Strongest sample", "Samples checked", "Path"
        ])
        self.spike_table.horizontalHeader().setStretchLastSection(True)
        self.spike_table.setSortingEnabled(True)
        self.spike_table.cellDoubleClicked.connect(self._open_spike_result)
        layout.addWidget(self.spike_table, 1)

        note = QLabel(
            "Double-click a result to open the extracted signal in 1D Signal Studio. "
            "Detected spike locations are overlaid as red symbols."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        return page

    def _build_artifact_learning(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        db_row = QHBoxLayout()
        self.artifact_db_label = QLabel("Artifact DB: Not opened")
        db_row.addWidget(self.artifact_db_label, 1)
        for label, callback in [
            ("Open / Create DB", self.open_artifact_database),
            ("Import DB JSON", self.import_artifact_database),
            ("Export DB JSON", self.export_artifact_database),
        ]:
            button = QPushButton(label)
            button.clicked.connect(callback)
            db_row.addWidget(button)
        layout.addLayout(db_row)

        selection = QGroupBox("Training Image Selection")
        selection_layout = QVBoxLayout(selection)
        self.artifact_selection_label = QLabel(
            "Select one or more DICOM images in Explorer, then add them as training images."
        )
        self.artifact_selection_label.setWordWrap(True)
        selection_layout.addWidget(self.artifact_selection_label)
        selection_buttons = QHBoxLayout()
        self.artifact_add_selected_button = QPushButton("Add Selected Images")
        self.artifact_add_selected_button.clicked.connect(self.collect_selected_artifact_images)
        selection_buttons.addWidget(self.artifact_add_selected_button)
        self.artifact_set_normal_button = QPushButton("Set Current as Normal Reference")
        self.artifact_set_normal_button.clicked.connect(self.set_current_normal_reference)
        selection_buttons.addWidget(self.artifact_set_normal_button)
        self.artifact_load_normal_button = QPushButton("Load Normal Reference")
        self.artifact_load_normal_button.clicked.connect(self.load_normal_reference)
        selection_buttons.addWidget(self.artifact_load_normal_button)
        selection_buttons.addStretch(1)
        selection_layout.addLayout(selection_buttons)
        self.artifact_normal_label = QLabel("Normal reference: None")
        selection_layout.addWidget(self.artifact_normal_label)
        layout.addWidget(selection)

        classify = QGroupBox("Classification")
        classify_form = QFormLayout(classify)
        type_row = QHBoxLayout()
        self.artifact_type_combo = QComboBox()
        type_row.addWidget(self.artifact_type_combo, 1)
        self.artifact_new_type = QLineEdit()
        self.artifact_new_type.setPlaceholderText("Manual new Artifact type")
        type_row.addWidget(self.artifact_new_type, 1)
        add_type = QPushButton("Add Type")
        add_type.clicked.connect(self.add_artifact_type_manual)
        type_row.addWidget(add_type)
        classify_form.addRow("Artifact", type_row)

        resolution_row = QHBoxLayout()
        self.artifact_resolution_combo = QComboBox()
        resolution_row.addWidget(self.artifact_resolution_combo, 1)
        self.artifact_new_resolution = QLineEdit()
        self.artifact_new_resolution.setPlaceholderText("Manual How to Resolved")
        resolution_row.addWidget(self.artifact_new_resolution, 1)
        add_resolution = QPushButton("Add Resolution")
        add_resolution.clicked.connect(self.add_resolution_manual)
        resolution_row.addWidget(add_resolution)
        classify_form.addRow("How to Resolved", resolution_row)

        self.artifact_notes = QTextEdit()
        self.artifact_notes.setMaximumHeight(90)
        self.artifact_notes.setPlaceholderText("Notes, conditions, service action, reproducibility...")
        classify_form.addRow("Notes", self.artifact_notes)

        save_button = QPushButton("Save Training Samples to Artifact DB")
        save_button.clicked.connect(self.save_artifact_training_samples)
        classify_form.addRow(save_button)
        layout.addWidget(classify)

        self.artifact_training_table = QTableWidget(0, 8)
        self.artifact_training_table.setHorizontalHeaderLabels([
            "ID", "File", "Series", "Instance", "Artifact",
            "How to Resolved", "Normal Compared", "Source Path"
        ])
        self.artifact_training_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.artifact_training_table.setSelectionMode(QTableWidget.ExtendedSelection)
        self.artifact_training_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.artifact_training_table, 1)

        reclassify = QPushButton("Apply Current Classification to Selected DB Rows")
        reclassify.clicked.connect(self.reclassify_selected_db_rows)
        layout.addWidget(reclassify)

        self.artifact_summary = QLabel(
            "Current detector: Spike. Artifact DB supports Frequency and future Artifact detectors."
        )
        self.artifact_summary.setWordWrap(True)
        layout.addWidget(self.artifact_summary)
        return page

    def _build_menu(self):
        file_menu = self.menuBar().addMenu("File")
        export_npz = QAction("Export Image/k-space NPZ", self); export_npz.triggered.connect(self.export_npz); file_menu.addAction(export_npz)
        export_header = QAction("Export DICOM Header Excel", self); export_header.triggered.connect(self.export_header_excel); file_menu.addAction(export_header)
        file_menu.addSeparator(); quit_action = QAction("Exit", self); quit_action.triggered.connect(self.close); file_menu.addAction(quit_action)

    def _apply_style(self):
        self.setStyleSheet("""
        QMainWindow, QWidget { background: #171a1f; color: #e6e9ee; }
        QMenuBar, QMenu { background: #20242b; }
        QTabWidget::pane { border: 1px solid #303946; }
        QTabBar::tab { background: #20242b; padding: 9px 18px; border: 1px solid #303946; }
        QTabBar::tab:selected { background: #1464cc; color: white; font-weight: 600; }
        QTabBar::tab:hover { background: #2b3440; }
        QPushButton, QComboBox, QSpinBox { background: #252b33; border: 1px solid #3b4654; padding: 6px; border-radius: 3px; }
        QPushButton:checked { background: #1464cc; border-color: #2c8cff; }
        QPushButton:hover { border-color: #6594c5; }
        QTreeWidget, QTableWidget { background: #111419; alternate-background-color: #191e25; border: 1px solid #303946; }
        QGroupBox { border: 1px solid #303946; border-radius: 4px; margin-top: 8px; padding-top: 8px; }
        QGroupBox::title { subcontrol-origin: margin; left: 8px; }
        #DropBanner { border: 1px dashed #5c7189; border-radius: 5px; background: #1d232b; }
        #DropBanner[dragActive="true"] { border: 2px solid #2f8cff; background: #20354f; }
        #InfoCard { border: 1px solid #303946; padding: 8px; background: #111419; }
        QSplitter::handle { background: #2f8cff; }
        QSplitter::handle:vertical { height: 4px; }
        QSplitter::handle:horizontal { width: 4px; }
        """)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls(): event.acceptProposedAction()

    def dropEvent(self, event):
        paths = [Path(u.toLocalFile()) for u in event.mimeData().urls() if u.isLocalFile()]
        if paths: self.import_paths(paths); event.acceptProposedAction()

    def _make_progress(self, title: str, maximum: int = 0) -> QProgressDialog:
        progress = QProgressDialog("Preparing...", "Cancel", 0, maximum, self)
        progress.setWindowTitle(title)
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)
        progress.setAutoClose(False)
        progress.setAutoReset(False)
        progress.setValue(0)
        progress.show()
        QApplication.processEvents()
        return progress

    def _progress_step(self, progress: QProgressDialog, value: int, text: str) -> bool:
        progress.setLabelText(text)
        if progress.maximum() > 0:
            progress.setValue(min(value, progress.maximum()))
        QApplication.processEvents()
        return not progress.wasCanceled()

    def import_paths(self, paths: list[Path]):
        progress = self._make_progress("Importing MRI Data", 0)
        try:
            progress.setLabelText("Collecting dropped files and folders...")
            QApplication.processEvents()
            files: list[Path] = []
            for p in paths:
                if progress.wasCanceled():
                    self.statusBar().showMessage("Import canceled")
                    return
                if p.is_dir():
                    progress.setLabelText(f"Scanning folder: {p.name}")
                    QApplication.processEvents()
                    files.extend([x for x in p.rglob('*') if x.is_file()])
                elif p.suffix.lower() == '.zip':
                    progress.setLabelText(f"Extracting ZIP: {p.name}")
                    QApplication.processEvents()
                    files.extend(self.extract_zip(p, progress))
                else:
                    files.append(p)

            # Keep unique files for later batch operations such as Spike detection.
            known = {str(p.resolve()) for p in self.imported_paths if p.exists()}
            for imported in files:
                try:
                    key = str(imported.resolve())
                except Exception:
                    key = str(imported)
                if key not in known:
                    self.imported_paths.append(imported)
                    known.add(key)

            progress.setRange(0, max(len(files), 1))
            progress.setValue(0)
            dicoms, deferred = [], []
            for index, p in enumerate(files, start=1):
                if not self._progress_step(progress, index - 1, f"Checking {index}/{len(files)}: {p.name}"):
                    self.statusBar().showMessage("Import canceled")
                    return
                try:
                    entry = self.read_dicom(p)
                    dicoms.append(entry)
                    continue
                except Exception:
                    deferred.append(p)
                progress.setValue(index)

            if dicoms:
                progress.setLabelText(f"Sorting and displaying {len(dicoms)} DICOM images...")
                QApplication.processEvents()
                dicoms.sort(key=lambda e: e.sort_key)
                self.dicom_entries = dicoms
                self.populate_dicom_tree()
                self.show_dicom(0)

            total_deferred = len(deferred)
            for n, p in enumerate(deferred, start=1):
                if progress.wasCanceled():
                    self.statusBar().showMessage("Import canceled")
                    return
                progress.setLabelText(f"Loading additional data {n}/{total_deferred}: {p.name}")
                QApplication.processEvents()
                if self.looks_tracker(p):
                    self.load_tracker(p)
                elif p.suffix.lower() in {'.csv', '.txt', '.npy', '.npz'}:
                    self.load_signal_file(p)
                elif p.suffix.lower() in {'.raw', '.bin', '.dat'}:
                    self.statusBar().showMessage(
                        f"Generic binary detected: {p.name}; Tracker PFile is auto-supported in this prototype"
                    )

            if not dicoms and not deferred:
                QMessageBox.information(self, "No files", "No supported files were found.")
            else:
                self.statusBar().showMessage(
                    f"Import completed: {len(dicoms)} DICOM, {len(deferred)} other file(s)"
                )
        except Exception as exc:
            QMessageBox.critical(self, "Import error", str(exc))
        finally:
            progress.setValue(progress.maximum())
            progress.close()

    def extract_zip(self, path: Path, parent_progress: Optional[QProgressDialog] = None) -> list[Path]:
        root = Path(tempfile.mkdtemp(prefix='mri_fft_'))
        self.temp_dirs.append(root)
        with zipfile.ZipFile(path) as z:
            members = z.infolist()
            for index, m in enumerate(members, start=1):
                if parent_progress is not None:
                    parent_progress.setLabelText(f"Extracting {path.name}: {index}/{len(members)}")
                    QApplication.processEvents()
                    if parent_progress.wasCanceled():
                        return []
                target = (root / m.filename).resolve()
                if not str(target).startswith(str(root.resolve())):
                    raise ValueError("Unsafe ZIP member")
                z.extract(m, root)
        return [p for p in root.rglob('*') if p.is_file()]

    def read_dicom(self, path: Path) -> DicomEntry:
        ds = pydicom.dcmread(str(path), force=False)
        if not hasattr(ds, 'PixelData'): raise ValueError('No pixel data')
        arr = ds.pixel_array
        if arr.ndim == 3: arr = arr[0]
        if arr.ndim != 2: raise ValueError('Not 2D')
        arr = arr.astype(float) * float(getattr(ds, 'RescaleSlope', 1)) + float(getattr(ds, 'RescaleIntercept', 0))
        instance = int(getattr(ds, 'InstanceNumber', 0) or 0)
        pos = getattr(ds, 'ImagePositionPatient', None)
        z = float(pos[2]) if pos is not None and len(pos) >= 3 else float(instance)
        return DicomEntry(path, ds, arr, (z, instance, path.name.lower()))

    def populate_dicom_tree(self):
        self.tree.clear()
        root = QTreeWidgetItem(["DICOM / 2D Raw"])
        self.tree.addTopLevelItem(root)
        grouped = {}
        for index, entry in enumerate(self.dicom_entries):
            series_uid = str(getattr(entry.ds, "SeriesInstanceUID", "") or "UnknownSeries")
            description = str(
                getattr(entry.ds, "SeriesDescription", "")
                or getattr(entry.ds, "ProtocolName", "")
                or "Unnamed Series"
            )
            grouped.setdefault((series_uid, description), []).append((index, entry))
        for (series_uid, description), entries in grouped.items():
            series_item = QTreeWidgetItem([f"{description} ({len(entries)})"])
            series_item.setData(0, Qt.UserRole, ("series", series_uid))
            root.addChild(series_item)
            for index, entry in entries:
                item = QTreeWidgetItem([entry.path.name])
                item.setData(0, Qt.UserRole, ("dicom", index))
                series_item.addChild(item)
            series_item.setExpanded(False)
        root.setExpanded(True)

    def show_dicom(self, index: int):
        if not self.dicom_entries: return
        index = max(0, min(index, len(self.dicom_entries)-1)); e = self.dicom_entries[index]
        self.current_image = e.image; self.current_kspace = fft2c(e.image); self.current_recon = ifft2c(self.current_kspace)
        self.current_ds = e.ds; self.current_source = str(e.path); self.slice_index = index
        self.slice_label.setText(f"Slice: {index+1}/{len(self.dicom_entries)}")
        self.info.setText(self.dicom_info(e.ds, e.path, index))
        self.fill_header(e.ds)
        self._select_tree_dicom_index(index)
        self.refresh_images()

    def dicom_info(self, ds, path, index):
        spacing = getattr(ds, 'PixelSpacing', ['-', '-'])
        return (f"File: {path.name}\nType: DICOM\nSize: {getattr(ds,'Columns','-')} × {getattr(ds,'Rows','-')}\n"
                f"Bit Depth: {getattr(ds,'BitsAllocated','-')} bit\nPixel Spacing: {spacing}\n"
                f"Series: {getattr(ds,'SeriesDescription','-')}\nInstance: {index+1}/{len(self.dicom_entries)}\n"
                f"TE / TR: {getattr(ds,'EchoTime','-')} / {getattr(ds,'RepetitionTime','-')} ms")

    def change_slice(self, delta):
        if self.dicom_entries: self.show_dicom(getattr(self, 'slice_index', 0) + delta)

    def looks_tracker(self, p: Path) -> bool:
        n = p.name.lower()
        if 'trackerimg' in n or 'pfile' in n: return True
        if p.suffix == '' and p.stat().st_size > 4096:
            try:
                rev = np.frombuffer(p.read_bytes()[:4], dtype='<f4')[0]
                return np.isfinite(rev) and 1 < rev < 100
            except Exception: return False
        return False

    def load_tracker(self, path: Path):
        raw = path.read_bytes()
        best = None
        for matrix in (512, 384, 320, 256, 192, 160, 128, 96, 64):
            need = matrix * matrix * 4
            if len(raw) < need:
                continue
            offset = len(raw) - need
            vals = np.frombuffer(raw, dtype="<i2", count=matrix * matrix * 2, offset=offset)
            complex_data = vals[0::2].astype(float) + 1j * vals[1::2].astype(float)
            raw_matrix = complex_data.reshape(matrix, matrix)

            # Candidate selection uses line statistics only. No FFT is used for Tracker Signal Explorer.
            line_rms = np.sqrt(np.mean(np.abs(raw_matrix) ** 2, axis=1))
            score = float(np.percentile(line_rms, 99) / (np.median(line_rms) + 1e-9))
            if best is None or score > best[0]:
                best = (score, matrix, offset, raw_matrix)

        if best is None:
            raise ValueError("No Tracker matrix candidate found")

        _, matrix, offset, raw_matrix = best
        self.tracker_matrix = raw_matrix
        self.tracker_source_path = path
        self._analyze_tracker_lines()
        self._refresh_tracker_ranking()

        self.tree.clear()
        root = QTreeWidgetItem(["GE Tracker P File"])
        self.tree.addTopLevelItem(root)
        file_item = QTreeWidgetItem([path.name])
        root.addChild(file_item)
        lines_item = QTreeWidgetItem([f"Raw lines ({matrix})"])
        lines_item.setData(0, Qt.UserRole, ("tracker", str(path)))
        file_item.addChild(lines_item)
        root.setExpanded(True)
        file_item.setExpanded(True)

        self.tracker_summary.setText(
            f"{path.name} | Matrix candidate {matrix} × {matrix} | "
            f"Offset {offset} bytes | Complex int16 little-endian | FFT not applied"
        )
        self.info.setText(
            f"File: {path.name}\n"
            f"Type: GE Tracker/PFile candidate\n"
            f"Raw matrix: {matrix} × {matrix}\n"
            f"Offset: {offset}\n"
            f"Layout: complex int16, little-endian\n"
            f"Analysis: direct line ranking without FFT"
        )
        self.tabs.setCurrentIndex(3)
        self.statusBar().showMessage(f"Tracker Signal Explorer loaded: {path.name}")

    def load_signal_file(self, path: Path):
        if path.suffix.lower() == '.npy': arr = np.load(path, allow_pickle=False)
        elif path.suffix.lower() == '.npz':
            z = np.load(path, allow_pickle=False); arr = z[list(z.keys())[0]]
        else:
            rows=[]
            with open(path, encoding='utf-8-sig', errors='replace') as f:
                for line in f:
                    nums=[]
                    for token in line.strip().replace(';', ',').split(','):
                        try: nums.append(float(token.strip()))
                        except ValueError: pass
                    if nums: rows.append(nums)
            if not rows: return
            arr = np.array([r[0]+1j*r[1] if len(r)>1 else r[0] for r in rows])
        arr=np.asarray(arr).squeeze()
        if arr.ndim == 1: self.add_signal(arr, path.name)
        elif arr.ndim == 2:
            self.current_image = np.abs(arr); self.current_kspace = fft2c(arr); self.current_recon = ifft2c(self.current_kspace); self.refresh_images()

    def add_signal(self, signal, name):
        signal=np.asarray(signal).squeeze()
        if signal.ndim != 1 or signal.size < 2: return
        self.signals.append({'name': name, 'data': signal})
        self.active_spike_indices = np.array([], dtype=int)
        self.signal_combo.addItem(name)
        self.signal_combo.setCurrentIndex(len(self.signals)-1)
        self.update_signal_plot(); self.update_tracker_preview(signal)

    def clear_signals(self):
        self.signals.clear(); self.signal_combo.clear(); self.signal_plot.clear(); self.tracker_plot.clear()

    def update_signal_plot(self):
        self.signal_plot.clear(); idx=self.signal_combo.currentIndex()
        if idx < 0 or idx >= len(self.signals): return
        data=np.asarray(self.signals[idx]['data']); component=self.signal_component.currentText()
        if self.signal_fft.isChecked(): data=np.fft.fftshift(np.fft.fft(data)); self.signal_plot.setLabel('bottom','Frequency bin')
        else: self.signal_plot.setLabel('bottom','Sample')
        y=self.component(data, component)
        self.signal_plot.plot(y)
        if self.active_spike_indices.size:
            valid = self.active_spike_indices[self.active_spike_indices < len(y)]
            if valid.size:
                scatter = pg.ScatterPlotItem(
                    x=valid,
                    y=np.asarray(y)[valid],
                    pen=pg.mkPen("#ff3b3b"),
                    brush=pg.mkBrush("#ff3b3b"),
                    size=9,
                    symbol="x",
                )
                self.signal_plot.addItem(scatter)

    def update_tracker_preview(self, signal):
        self.tracker_plot.clear(); self.tracker_plot.plot(np.abs(np.asarray(signal)))

    def _analyze_tracker_lines(self):
        self.tracker_line_metrics = []
        if self.tracker_matrix is None:
            return

        magnitude = np.abs(self.tracker_matrix).astype(np.float64)
        for line_index, line in enumerate(magnitude):
            self.tracker_line_metrics.append({
                "line": line_index,
                "peak": float(np.max(line)),
                "rms": float(np.sqrt(np.mean(line ** 2))),
                "energy": float(np.sum(line ** 2)),
                "mean": float(np.mean(line)),
                "variance": float(np.var(line)),
                "relative": 0.0,
            })

        rms_values = np.array([item["rms"] for item in self.tracker_line_metrics], dtype=float)
        low = float(np.min(rms_values))
        high = float(np.max(rms_values))
        span = max(high - low, np.finfo(float).eps)
        for item in self.tracker_line_metrics:
            item["relative"] = 100.0 * (item["rms"] - low) / span

    def _tracker_metric_key(self) -> str:
        return {
            "Peak": "peak",
            "RMS": "rms",
            "Energy": "energy",
            "Mean magnitude": "mean",
            "Variance": "variance",
        }.get(self.tracker_metric_combo.currentText(), "peak")

    def _refresh_tracker_ranking(self):
        if not hasattr(self, "tracker_table"):
            return
        if not self.tracker_line_metrics:
            self.tracker_table.setRowCount(0)
            return

        key = self._tracker_metric_key()
        ranked = sorted(self.tracker_line_metrics, key=lambda item: item[key], reverse=True)
        ranked = ranked[: self.tracker_top_count.value()]

        self.tracker_table.blockSignals(True)
        self.tracker_table.setRowCount(len(ranked))
        for row, item in enumerate(ranked):
            values = [
                row + 1,
                item["line"],
                f'{item["peak"]:.6g}',
                f'{item["rms"]:.6g}',
                f'{item["energy"]:.6g}',
                f'{item["mean"]:.6g}',
                f'{item["variance"]:.6g}',
                f'{item["relative"]:.1f}%',
            ]
            for col, value in enumerate(values):
                table_item = QTableWidgetItem(str(value))
                table_item.setData(Qt.UserRole, item["line"])
                self.tracker_table.setItem(row, col, table_item)
        self.tracker_table.resizeColumnsToContents()
        self.tracker_table.blockSignals(False)

        if ranked:
            self.tracker_table.selectRow(0)
            self._tracker_selection_changed()

    def _tracker_selection_changed(self):
        rows = sorted({item.row() for item in self.tracker_table.selectedItems()})
        selected = []
        for row in rows:
            item = self.tracker_table.item(row, 1)
            if item is not None:
                selected.append(int(item.data(Qt.UserRole)))
        self.tracker_selected_lines = selected[:8]
        self._plot_tracker_selected_lines()

    def _tracker_component(self, line: np.ndarray) -> np.ndarray:
        mode = self.tracker_component_combo.currentText()
        if mode == "Real":
            return np.real(line)
        if mode == "Imaginary":
            return np.imag(line)
        if mode == "Phase":
            return np.angle(line)
        return np.abs(line)

    def _plot_tracker_selected_lines(self):
        if not hasattr(self, "tracker_raw_plot"):
            return
        self.tracker_raw_plot.clear()
        if self.tracker_matrix is None or not self.tracker_selected_lines:
            self.tracker_metrics_label.setText("-")
            return

        summaries = []
        for line_index in self.tracker_selected_lines:
            raw_line = self.tracker_matrix[line_index]
            values = np.asarray(self._tracker_component(raw_line), dtype=float)
            self.tracker_raw_plot.plot(values)

            metric = next(
                (item for item in self.tracker_line_metrics if item["line"] == line_index),
                None,
            )
            if metric:
                summaries.append(
                    f'Line {line_index}: Peak {metric["peak"]:.6g}, '
                    f'RMS {metric["rms"]:.6g}, Energy {metric["energy"]:.6g}'
                )
        self.tracker_metrics_label.setText(" | ".join(summaries))

    def _select_next_tracker_line(self):
        row = self.tracker_table.currentRow()
        if 0 <= row < self.tracker_table.rowCount() - 1:
            self.tracker_table.clearSelection()
            self.tracker_table.selectRow(row + 1)

    def _select_previous_tracker_line(self):
        row = self.tracker_table.currentRow()
        if row > 0:
            self.tracker_table.clearSelection()
            self.tracker_table.selectRow(row - 1)

    def export_tracker_lines_csv(self):
        if not self.tracker_line_metrics:
            QMessageBox.information(self, "Tracker Export", "Load a Tracker file first.")
            return
        filename, _ = QFileDialog.getSaveFileName(
            self, "Export Tracker Line Metrics", "tracker_line_metrics.csv", "CSV files (*.csv)"
        )
        if not filename:
            return
        if not filename.lower().endswith(".csv"):
            filename += ".csv"

        import csv
        with open(filename, "w", newline="", encoding="utf-8-sig") as stream:
            writer = csv.writer(stream)
            writer.writerow(["Line", "Peak", "RMS", "Energy", "MeanMagnitude", "Variance", "RelativeStrength"])
            for item in sorted(self.tracker_line_metrics, key=lambda value: value["line"]):
                writer.writerow([
                    item["line"], item["peak"], item["rms"], item["energy"],
                    item["mean"], item["variance"], item["relative"]
                ])
        self.statusBar().showMessage(f"Tracker metrics exported: {filename}")

    def _raw_candidate_paths(self) -> list[Path]:
        candidates = []
        seen = set()
        for path in self.imported_paths:
            if not path.exists() or not path.is_file():
                continue
            suffix = path.suffix.lower()
            if self.looks_tracker(path) or suffix in {".raw", ".bin", ".dat", ".pfile"}:
                key = str(path.resolve())
                if key not in seen:
                    candidates.append(path)
                    seen.add(key)
        return candidates

    @staticmethod
    def _robust_z(values: np.ndarray) -> np.ndarray:
        values = np.asarray(values, dtype=np.float64)
        if values.size == 0:
            return values
        median = np.nanmedian(values)
        mad = np.nanmedian(np.abs(values - median))
        scale = max(1.4826 * mad, np.finfo(float).eps)
        return np.abs(values - median) / scale

    @staticmethod
    def _group_spike_indices(indices: np.ndarray) -> list[np.ndarray]:
        indices = np.asarray(indices, dtype=int)
        if indices.size == 0:
            return []
        cuts = np.where(np.diff(indices) > 1)[0] + 1
        return [group for group in np.split(indices, cuts) if group.size]

    def _extract_tracker_signal(self, path: Path) -> tuple[np.ndarray, str]:
        raw = path.read_bytes()
        best = None
        for matrix in (512, 384, 320, 256, 192, 160, 128, 96, 64):
            need = matrix * matrix * 4
            if len(raw) < need:
                continue
            offset = len(raw) - need
            vals = np.frombuffer(raw, dtype="<i2", count=matrix * matrix * 2, offset=offset)
            signal = vals[0::2].astype(np.float64) + 1j * vals[1::2].astype(np.float64)
            image = ifft2c(signal.reshape(matrix, matrix))
            contrast = np.percentile(np.abs(image), 99) / (np.median(np.abs(image)) + 1e-9)
            if best is None or contrast > best[0]:
                best = (contrast, signal, f"Tracker complex int16 {matrix}x{matrix}, offset {offset}")
        if best is None:
            raise ValueError("No valid Tracker complex matrix candidate")
        return best[1], best[2]

    def _extract_generic_raw_signal(self, path: Path) -> tuple[np.ndarray, str]:
        # Limit analysis memory while retaining enough data for spike screening.
        max_bytes = 32 * 1024 * 1024
        size = path.stat().st_size
        offset = max(0, size - max_bytes)
        if offset % 2:
            offset += 1
        with open(path, "rb") as stream:
            stream.seek(offset)
            raw = np.fromfile(stream, dtype="<i2")
        if raw.size < 8:
            raise ValueError("Not enough int16 samples")
        # Treat even/odd pairs as complex when possible. Magnitude analysis is
        # resistant to phase rotation and works for many MRI raw layouts.
        if raw.size >= 16 and raw.size % 2 == 0:
            signal = raw[0::2].astype(np.float64) + 1j * raw[1::2].astype(np.float64)
            description = f"Generic complex int16 tail, byte offset {offset}"
        else:
            signal = raw.astype(np.float64)
            description = f"Generic real int16 tail, byte offset {offset}"
        return signal, description

    def _analyze_spike_signal(self, signal: np.ndarray, threshold: float) -> dict:
        signal = np.asarray(signal).squeeze()
        magnitude = np.abs(signal).astype(np.float64)
        finite = np.isfinite(magnitude)
        if magnitude.size < 8 or not np.any(finite):
            raise ValueError("Signal has insufficient valid samples")
        replacement = np.nanmedian(magnitude[finite])
        magnitude = np.where(finite, magnitude, replacement)

        amplitude_z = self._robust_z(magnitude)
        first_difference = np.abs(np.diff(magnitude, prepend=magnitude[0]))
        difference_z = self._robust_z(first_difference)

        combined = np.maximum(amplitude_z, difference_z)
        raw_indices = np.flatnonzero(combined >= threshold)
        groups = self._group_spike_indices(raw_indices)

        # Represent each consecutive group by its strongest sample.
        representatives = []
        for group in groups:
            representatives.append(int(group[np.argmax(combined[group])]))
        representatives = np.asarray(representatives, dtype=int)

        strongest = int(np.argmax(combined))
        score = float(combined[strongest])
        return {
            "score": score,
            "flagged": bool(representatives.size and score >= threshold),
            "indices": representatives,
            "groups": len(groups),
            "strongest": strongest,
            "samples": int(magnitude.size),
        }

    def detect_spikes(self):
        candidates = self._raw_candidate_paths()
        if not candidates:
            QMessageBox.information(
                self,
                "Spike Detection",
                "No RAW, BIN, DAT, PFile, or TrackerImg files are currently imported. "
                "Drop a file or folder first.",
            )
            return

        threshold = float(self.spike_threshold.value())
        progress = self._make_progress("Detecting Spike Noise", len(candidates))
        results = []
        try:
            for index, path in enumerate(candidates, start=1):
                if not self._progress_step(
                    progress,
                    index - 1,
                    f"Analyzing {index}/{len(candidates)}: {path.name}",
                ):
                    self.statusBar().showMessage("Spike detection canceled")
                    return
                try:
                    if self.looks_tracker(path):
                        signal, source_type = self._extract_tracker_signal(path)
                    else:
                        signal, source_type = self._extract_generic_raw_signal(path)
                    analysis = self._analyze_spike_signal(signal, threshold)
                    analysis.update({
                        "path": path,
                        "name": path.name,
                        "type": source_type,
                        "signal": signal,
                        "error": "",
                    })
                except Exception as exc:
                    analysis = {
                        "path": path,
                        "name": path.name,
                        "type": "Unreadable",
                        "signal": np.array([], dtype=float),
                        "score": 0.0,
                        "flagged": False,
                        "indices": np.array([], dtype=int),
                        "groups": 0,
                        "strongest": -1,
                        "samples": 0,
                        "error": str(exc),
                    }
                results.append(analysis)
                progress.setValue(index)
        finally:
            progress.close()

        self.spike_results = sorted(results, key=lambda item: item["score"], reverse=True)
        self._refresh_spike_table()
        flagged = sum(1 for item in results if item["flagged"])
        errors = sum(1 for item in results if item["error"])
        self.spike_summary.setText(
            f"Scanned {len(results)} raw file(s) at robust threshold {threshold:.1f}. "
            f"Spike candidates: {flagged}. Read errors: {errors}."
        )
        self.tabs.setCurrentIndex(5)
        self.statusBar().showMessage(f"Spike detection complete: {flagged}/{len(results)} flagged")

    def _refresh_spike_table(self):
        if not hasattr(self, "spike_table"):
            return
        show_flagged = self.spike_only_flagged.isChecked()
        rows = [
            result for result in self.spike_results
            if (result["flagged"] or not show_flagged)
        ]
        self.spike_table.setSortingEnabled(False)
        self.spike_table.setRowCount(len(rows))
        for row, result in enumerate(rows):
            status = "SPIKE" if result["flagged"] else ("ERROR" if result["error"] else "OK")
            values = [
                status,
                result["name"],
                result["type"],
                f'{result["score"]:.2f}',
                str(result["groups"]),
                str(result["strongest"]) if result["strongest"] >= 0 else "-",
                str(result["samples"]),
                str(result["path"]),
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                item.setData(Qt.UserRole, result)
                if status == "SPIKE":
                    item.setBackground(pg.mkColor("#7a2430"))
                elif status == "ERROR":
                    item.setBackground(pg.mkColor("#6a5520"))
                self.spike_table.setItem(row, col, item)
        self.spike_table.setSortingEnabled(True)
        self.spike_table.resizeColumnsToContents()

    def _open_spike_result(self, row: int, column: int):
        item = self.spike_table.item(row, 0)
        if item is None:
            return
        result = item.data(Qt.UserRole)
        if not result or result["signal"].size < 2:
            if result and result["error"]:
                QMessageBox.warning(self, "Spike Result", result["error"])
            return

        name = f'Spike scan: {result["name"]}'
        self.signals.append({"name": name, "data": result["signal"]})
        self.signal_combo.addItem(name)
        self.signal_combo.setCurrentIndex(len(self.signals) - 1)
        self.active_spike_indices = np.asarray(result["indices"], dtype=int)
        self.signal_fft.setChecked(False)
        self.signal_component.setCurrentText("Magnitude")
        self.update_signal_plot()
        self.update_tracker_preview(result["signal"])
        self.tabs.setCurrentIndex(1)
        self.statusBar().showMessage(
            f'Opened {result["name"]}: {len(self.active_spike_indices)} spike group(s)'
        )

    @staticmethod
    def _position_plane_index(name: str) -> int:
        return {"Axial": 0, "Coronal": 1, "Sagittal": 2}.get(name, 0)

    def populate_position_top_lines(self):
        if self.tracker_matrix is None or not self.tracker_line_metrics:
            QMessageBox.information(self, "Tracker Position", "Load a Tracker PFile / TrackerImg first.")
            return

        ranked = sorted(self.tracker_line_metrics, key=lambda item: item["rms"], reverse=True)[:3]
        for row, metric in enumerate(ranked):
            self.position_table.setItem(row, 0, QTableWidgetItem(str(metric["line"])))
        self.tabs.setCurrentIndex(4)
        self.statusBar().showMessage("Top three Tracker lines assigned to position conversion.")

    def calculate_tracker_position(self):
        if self.tracker_matrix is None:
            QMessageBox.information(self, "Tracker Position", "Load a Tracker file first.")
            return

        fft_length = int(self.position_fft_length.value())
        fov = float(self.position_fov.value())
        measurements = []

        try:
            for row in range(self.position_table.rowCount()):
                use_widget = self.position_table.cellWidget(row, 6)
                if use_widget is not None and not use_widget.isChecked():
                    continue

                line_item = self.position_table.item(row, 0)
                if line_item is None:
                    continue
                line_index = int(line_item.text())
                if line_index < 0 or line_index >= self.tracker_matrix.shape[0]:
                    raise ValueError(f"Line {line_index} is outside the available range.")

                plane_widget = self.position_table.cellWidget(row, 1)
                rotation_widget = self.position_table.cellWidget(row, 2)
                plane = self._position_plane_index(plane_widget.currentText())
                rotation_deg = float(rotation_widget.value())

                peak_bin, coordinate_mm, snr_like, spectrum = signal_peak_coordinate(
                    self.tracker_matrix[line_index],
                    fft_length=fft_length,
                    fov_mm=fov,
                )
                measurement = DirectionMeasurement(
                    line_index=line_index,
                    plane=plane,
                    rotation_deg=rotation_deg,
                    peak_bin=peak_bin,
                    coordinate_mm=coordinate_mm,
                    snr_like=snr_like,
                )
                measurements.append(measurement)

                self.position_table.setItem(row, 3, QTableWidgetItem(f"{peak_bin:.4f}"))
                self.position_table.setItem(row, 4, QTableWidgetItem(f"{coordinate_mm:.4f}"))
                self.position_table.setItem(row, 5, QTableWidgetItem(f"{snr_like:.3f}"))

            offset = np.array([
                self.position_offset_x.value(),
                self.position_offset_y.value(),
                self.position_offset_z.value(),
            ], dtype=float)

            scanner_xyz, pqr, rms_error = solve_position(
                measurements,
                center_offset=offset,
                oppose_ap=self.position_oppose_ap.isChecked(),
            )
            self.tracker_position_measurements = measurements
            self.position_result.setText(
                f"Coordinates MR / Scanner (mm):\n"
                f"  X = {scanner_xyz[0]:.4f}\n"
                f"  Y = {scanner_xyz[1]:.4f}\n"
                f"  Z = {scanner_xyz[2]:.4f}\n\n"
                f"Coordinates PQR (mm):\n"
                f"  P = {pqr[0]:.4f}\n"
                f"  Q = {pqr[1]:.4f}\n"
                f"  R = {pqr[2]:.4f}\n\n"
                f"Projection RMS residual = {rms_error:.5f} mm\n"
                f"Gradient-map correction = Not applied"
            )
            self.statusBar().showMessage("Tracker position conversion completed.")
        except Exception as exc:
            QMessageBox.critical(self, "Tracker Position Error", str(exc))

    def component(self, arr, mode):
        if mode == 'Real': return np.real(arr)
        if mode == 'Imaginary': return np.imag(arr)
        if mode == 'Phase': return np.angle(arr)
        return np.abs(arr)

    def set_view_mode(self, mode):
        self.view_mode=mode
        for b, m in [(self.btn_fft,'FFT'),(self.btn_original,'Original'),(self.btn_both,'Both')]: b.setChecked(m==mode)
        self.refresh_images()

    def refresh_images(self):
        if self.current_image is None or self.current_kspace is None:
            return
        fft_img = np.log1p(np.abs(self.current_kspace))
        orig = np.abs(self.current_image)

        active = orig if self.view_mode == "Original" else fft_img
        if self.window_level is None or self.dynamic_range is None:
            self._set_auto_levels_from_array(active)
        levels = self._current_levels()

        if self.view_mode == 'FFT':
            self.primary_panel.show()
            self.secondary_panel.hide()
            self.primary_panel.label.setText('FFT (k-space)')
            self.primary_panel.set_image(fft_img, levels=levels)
        elif self.view_mode == 'Original':
            self.primary_panel.show()
            self.secondary_panel.hide()
            self.primary_panel.label.setText('Original Image')
            self.primary_panel.set_image(orig, levels=levels)
        else:
            self.primary_panel.show()
            self.secondary_panel.show()
            self.primary_panel.label.setText('FFT (k-space)')
            self.secondary_panel.label.setText('Original Image')
            self.primary_panel.set_image(fft_img, levels=levels)
            self.secondary_panel.set_image(orig, levels=self._levels_for_array(orig))

        rows, cols = orig.shape
        self.line_row = min(self.line_row or rows // 2, rows - 1)
        self.line_col = min(self.line_col or cols // 2, cols - 1)
        self._configure_line_control(rows, cols)
        self._sync_lines()
        self.update_line_profile()

    def _configure_line_control(self, rows, cols):
        maximum = rows-1 if self.line_orientation=='Row' else cols-1
        self.line_spin.blockSignals(True); self.line_slider.blockSignals(True)
        self.line_spin.setRange(0, maximum); self.line_slider.setRange(0, maximum)
        value=self.line_row if self.line_orientation=='Row' else self.line_col
        self.line_spin.setValue(value); self.line_slider.setValue(value)
        self.line_spin.blockSignals(False); self.line_slider.blockSignals(False)

    def _orientation_changed(self, text):
        self.line_orientation=text
        if self.current_image is not None: self._configure_line_control(*self.current_image.shape); self.update_line_profile()

    def _spin_line_changed(self, value):
        self._set_selected_line(value)

    def _slider_line_changed(self, value):
        self._set_selected_line(value)

    def _set_selected_line(self, value):
        if self.current_image is None: return
        if self.line_orientation=='Row': self.line_row=value
        else: self.line_col=value
        self.line_spin.blockSignals(True); self.line_slider.blockSignals(True); self.line_spin.setValue(value); self.line_slider.setValue(value); self.line_spin.blockSignals(False); self.line_slider.blockSignals(False)
        self._sync_lines(); self.update_line_profile()

    def _line_moved(self, row, col):
        self.line_row=row; self.line_col=col
        value=row if self.line_orientation=='Row' else col
        self.line_spin.blockSignals(True); self.line_slider.blockSignals(True); self.line_spin.setValue(value); self.line_slider.setValue(value); self.line_spin.blockSignals(False); self.line_slider.blockSignals(False)
        self._sync_lines(); self.update_line_profile()

    def _sync_lines(self):
        self.primary_panel.set_line_position(self.line_row, self.line_col); self.secondary_panel.set_line_position(self.line_row, self.line_col)

    def active_display_array(self):
        if self.view_mode == 'Original': return np.asarray(self.current_image)
        return np.asarray(self.current_kspace)

    def update_line_profile(self):
        if self.current_image is None or self.current_kspace is None: return
        arr=self.active_display_array(); line=arr[self.line_row,:] if self.line_orientation=='Row' else arr[:,self.line_col]
        y=self.component(line, self.profile_mode.currentText())
        if self.log_profile.isChecked(): y=np.log10(np.maximum(np.abs(y), 1e-12))
        self.profile_plot.clear(); self.profile_plot.plot(y)
        pos=self.line_row if self.line_orientation=='Row' else self.line_col
        self.line_value_label.setText(f"{pos} / {len(y)-1}")

    def send_line_to_signal_studio(self):
        if self.current_image is None: return
        arr=self.active_display_array(); line=arr[self.line_row,:] if self.line_orientation=='Row' else arr[:,self.line_col]
        self.add_signal(line, f"{self.line_orientation} {self.line_row if self.line_orientation=='Row' else self.line_col} — {self.view_mode}")
        self.tabs.setCurrentIndex(1)

    def auto_levels(self):
        self.window_level = None
        self.dynamic_range = None
        self.level_preset_combo.blockSignals(True)
        self.level_preset_combo.setCurrentText("Auto")
        self.level_preset_combo.blockSignals(False)
        self.refresh_images()

    def _tree_current_changed(self, current, previous):
        if current is None:
            return
        self._tree_clicked(current, 0)

    def _tree_clicked(self, item, column):
        data=item.data(0, Qt.UserRole)
        if not data: return
        if data[0] == 'dicom':
            self.show_dicom(data[1])
        elif data[0] == 'signal':
            self.tabs.setCurrentIndex(1)
            self.signal_combo.setCurrentIndex(data[1])
        elif data[0] == 'processed':
            self.load_processed_image(data[1])

    def _select_tree_dicom_index(self, index: int):
        iterator = QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            item = iterator.value()
            data = item.data(0, Qt.UserRole)
            if data and data[0] == "dicom" and int(data[1]) == int(index):
                self.tree.blockSignals(True)
                self.tree.setCurrentItem(item)
                self.tree.blockSignals(False)
                return
            iterator += 1

    def _active_level_array(self) -> np.ndarray:
        if self.current_image is None or self.current_kspace is None:
            return np.array([0.0, 1.0])
        if self.view_mode == "Original":
            return np.abs(self.current_image)
        return np.log1p(np.abs(self.current_kspace))

    def _set_auto_levels_from_array(self, array: np.ndarray):
        finite = np.asarray(array, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            center, width = 0.5, 1.0
        else:
            low, high = np.percentile(finite, [1.0, 99.5])
            if high <= low:
                high = low + 1.0
            center = (low + high) / 2.0
            width = high - low
        self.window_level = float(center)
        self.dynamic_range = float(width)
        self._sync_level_controls()

    def _levels_for_array(self, array: np.ndarray):
        finite = np.asarray(array, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            return (0.0, 1.0)
        low, high = np.percentile(finite, [1.0, 99.5])
        if high <= low:
            high = low + 1.0
        return (float(low), float(high))

    def _current_levels(self):
        if self.window_level is None or self.dynamic_range is None:
            self._set_auto_levels_from_array(self._active_level_array())
        half = max(float(self.dynamic_range) / 2.0, 1e-9)
        return (float(self.window_level) - half, float(self.window_level) + half)

    def _sync_level_controls(self):
        if not hasattr(self, "window_level_spin"):
            return
        self.window_level_spin.blockSignals(True)
        self.dynamic_range_spin.blockSignals(True)
        self.window_level_spin.setValue(float(self.window_level or 0.0))
        self.dynamic_range_spin.setValue(max(float(self.dynamic_range or 1.0), 1e-9))
        self.window_level_spin.blockSignals(False)
        self.dynamic_range_spin.blockSignals(False)

    def _manual_levels_changed(self):
        self.window_level = float(self.window_level_spin.value())
        self.dynamic_range = max(float(self.dynamic_range_spin.value()), 1e-9)
        self.level_preset_combo.blockSignals(True)
        self.level_preset_combo.setCurrentText("Auto")
        self.level_preset_combo.blockSignals(False)
        levels = self._current_levels()
        self.primary_panel.set_levels(*levels)
        if self.secondary_panel.isVisible():
            self.secondary_panel.set_levels(*levels)

    def apply_level_preset(self, preset: str):
        if self.current_image is None:
            return
        array = self._active_level_array()
        finite = np.asarray(array, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            return

        percentiles = {
            "Auto": (1.0, 99.5),
            "Wide": (0.0, 100.0),
            "Soft Tissue": (5.0, 95.0),
            "High Contrast": (10.0, 90.0),
            "Narrow": (25.0, 75.0),
        }
        low_p, high_p = percentiles.get(preset, (1.0, 99.5))
        low, high = np.percentile(finite, [low_p, high_p])
        if high <= low:
            high = low + 1.0
        self.level_preset = preset
        self.window_level = float((low + high) / 2.0)
        self.dynamic_range = float(high - low)
        self._sync_level_controls()
        levels = self._current_levels()
        self.primary_panel.set_levels(*levels)
        if self.secondary_panel.isVisible():
            self.secondary_panel.set_levels(*levels)

    def _current_image_record(self):
        if self.current_image is None:
            return None
        name = Path(self.current_source).name if self.current_source else "current_image"
        return {
            "name": name,
            "path": Path(self.current_source) if self.current_source else None,
            "image": np.asarray(self.current_image, dtype=float).copy(),
            "ds": copy.deepcopy(self.current_ds) if self.current_ds is not None else None,
        }

    def set_addsub_source(self, slot: str):
        record = self._current_image_record()
        if record is None:
            QMessageBox.information(self, "Add/Subtract", "Load an image first.")
            return
        if slot == "A":
            self.addsub_a = record
        else:
            self.addsub_b = record
        self.addsub_status.setText(
            f"A: {self.addsub_a['name'] if self.addsub_a else '-'}\\n"
            f"B: {self.addsub_b['name'] if self.addsub_b else '-'}"
        )

    def run_addsub(self, operation: str):
        if self.addsub_a is None or self.addsub_b is None:
            QMessageBox.information(self, "Add/Subtract", "Set both image A and image B first.")
            return
        a = np.asarray(self.addsub_a["image"], dtype=float)
        b = np.asarray(self.addsub_b["image"], dtype=float)
        if a.shape != b.shape:
            QMessageBox.warning(self, "Add/Subtract", f"Image sizes do not match: {a.shape} and {b.shape}")
            return

        result = a + b if operation == "add" else a - b
        tag = "add" if operation == "add" else "sub"
        base = Path(self.addsub_a["name"]).stem
        output_path = self._save_processed_image(result, f"{base}_{tag}_addsub", "_addsub")
        self._display_processed_result(result, output_path)
        self.statusBar().showMessage(f"Add/Subtract saved: {output_path}")

    def start_compensation_roi(self):
        if self.current_image is None:
            QMessageBox.information(self, "Compensation", "Load an image first.")
            return
        self.primary_panel.show_comp_roi()
        self.statusBar().showMessage("Move and resize the blue ROI, then click Apply Compensation.")

    def clear_compensation_roi(self):
        self.primary_panel.hide_comp_roi()

    @staticmethod
    def _interpolate_rectangle(image: np.ndarray, y0: int, y1: int, x0: int, x1: int) -> np.ndarray:
        result = np.asarray(image, dtype=float).copy()
        rows, cols = result.shape
        y0 = max(1, min(y0, rows - 2))
        y1 = max(y0 + 1, min(y1, rows - 1))
        x0 = max(1, min(x0, cols - 2))
        x1 = max(x0 + 1, min(x1, cols - 1))

        height = y1 - y0
        width = x1 - x0
        left = result[y0:y1, x0 - 1][:, None]
        right = result[y0:y1, x1][:, None]
        tx = np.linspace(0.0, 1.0, width, endpoint=False)[None, :]
        horizontal = left * (1.0 - tx) + right * tx

        top = result[y0 - 1, x0:x1][None, :]
        bottom = result[y1, x0:x1][None, :]
        ty = np.linspace(0.0, 1.0, height, endpoint=False)[:, None]
        vertical = top * (1.0 - ty) + bottom * ty

        result[y0:y1, x0:x1] = (horizontal + vertical) / 2.0
        return result

    def apply_compensation(self):
        if self.current_image is None:
            QMessageBox.information(self, "Compensation", "Load an image first.")
            return
        if not self.primary_panel.comp_roi.isVisible():
            QMessageBox.information(self, "Compensation", "Select a compensation region first.")
            return

        y0, y1, x0, x1 = self.primary_panel.comp_roi_bounds()
        result = self._interpolate_rectangle(np.asarray(self.current_image), y0, y1, x0, x1)
        base = Path(self.current_source).stem if self.current_source else "image"
        output_path = self._save_processed_image(result, f"{base}_comp", "_comp")
        self.primary_panel.hide_comp_roi()
        self._display_processed_result(result, output_path)
        self.statusBar().showMessage(
            f"Compensated region ({x0}:{x1}, {y0}:{y1}) saved: {output_path}"
        )

    def _work_folder(self) -> Path:
        source = Path(self.current_source) if self.current_source else Path.cwd() / "image"
        parent = source.parent if source.parent.exists() else Path.cwd()
        folder = parent / "MRI_Raw_FFT_Work"
        folder.mkdir(parents=True, exist_ok=True)
        return folder

    def _save_processed_image(self, image: np.ndarray, stem: str, suffix: str) -> Path:
        folder = self._work_folder()
        safe_stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", stem)
        npy_path = folder / f"{safe_stem}.npy"
        np.save(npy_path, np.asarray(image, dtype=np.float32))

        # Save a derived DICOM when a DICOM source is available.
        if self.current_ds is not None:
            ds = copy.deepcopy(self.current_ds)
            arr = np.asarray(image, dtype=float)
            finite = arr[np.isfinite(arr)]
            low = float(np.min(finite)) if finite.size else 0.0
            high = float(np.max(finite)) if finite.size else 1.0
            if high <= low:
                high = low + 1.0
            scaled = np.clip((arr - low) / (high - low) * 65535.0, 0, 65535).astype(np.uint16)
            ds.PixelData = scaled.tobytes()
            ds.Rows, ds.Columns = scaled.shape
            ds.BitsAllocated = 16
            ds.BitsStored = 16
            ds.HighBit = 15
            ds.PixelRepresentation = 0
            ds.RescaleSlope = (high - low) / 65535.0
            ds.RescaleIntercept = low
            ds.SOPInstanceUID = generate_uid()
            ds.SeriesInstanceUID = generate_uid()
            ds.ImageType = ["DERIVED", "SECONDARY"]
            original_description = str(getattr(ds, "SeriesDescription", "MRI"))
            ds.SeriesDescription = f"{original_description} {suffix}"
            dcm_path = folder / f"{safe_stem}.dcm"
            ds.save_as(str(dcm_path), write_like_original=False)
            primary_path = dcm_path
        else:
            primary_path = npy_path

        self.processed_images[str(primary_path)] = np.asarray(image, dtype=float).copy()
        self.processed_sources[str(primary_path)] = primary_path
        self._add_processed_tree_item(primary_path)
        return primary_path

    def _add_processed_tree_item(self, path: Path):
        root = None
        for i in range(self.tree.topLevelItemCount()):
            candidate = self.tree.topLevelItem(i)
            if candidate.text(0) == "Processed Files":
                root = candidate
                break
        if root is None:
            root = QTreeWidgetItem(["Processed Files"])
            self.tree.addTopLevelItem(root)
        item = QTreeWidgetItem([path.name])
        item.setData(0, Qt.UserRole, ("processed", str(path)))
        root.addChild(item)
        root.setExpanded(True)
        self.tree.setCurrentItem(item)

    def _display_processed_result(self, image: np.ndarray, path: Path):
        self.current_image = np.asarray(image, dtype=float)
        self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)
        self.current_source = str(path)
        self.current_ds = None
        self.window_level = None
        self.dynamic_range = None
        self.refresh_images()

    def load_processed_image(self, path_value: str):
        path = Path(path_value)
        if str(path) in self.processed_images:
            image = self.processed_images[str(path)]
        elif path.suffix.lower() == ".npy":
            image = np.load(path, allow_pickle=False)
        elif path.suffix.lower() == ".dcm":
            entry = self.read_dicom(path)
            image = entry.image
            self.current_ds = entry.ds
        else:
            return
        self.current_image = np.asarray(image, dtype=float)
        self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)
        self.current_source = str(path)
        self.window_level = None
        self.dynamic_range = None
        self.refresh_images()

    def _tree_selection_changed(self):
        indices = []
        for item in self.tree.selectedItems():
            data = item.data(0, Qt.UserRole)
            if data and data[0] == "dicom":
                indices.append(int(data[1]))
        self.artifact_selected_indices = sorted(set(indices))
        if hasattr(self, "artifact_selection_label"):
            self.artifact_selection_label.setText(
                f"Selected DICOM images in Explorer: {len(self.artifact_selected_indices)}"
            )

    def _ensure_artifact_database(self):
        if self.artifact_db is None:
            self.open_artifact_database()
        return self.artifact_db is not None

    def open_artifact_database(self):
        filename, _ = QFileDialog.getSaveFileName(
            self, "Open or Create Artifact Database",
            "MRI_Artifact_Learning.sqlite",
            "SQLite database (*.sqlite *.db)"
        )
        if not filename:
            return
        path = Path(filename)
        if path.suffix.lower() not in {".sqlite", ".db"}:
            path = path.with_suffix(".sqlite")
        if self.artifact_db is not None:
            self.artifact_db.close()
        self.artifact_db = ArtifactDatabase(path)
        self.artifact_db_path = path
        self.artifact_db_label.setText(f"Artifact DB: {path}")
        self.refresh_artifact_lists()
        self.refresh_artifact_training_table()

    def refresh_artifact_lists(self):
        if self.artifact_db is None:
            return
        self.artifact_type_combo.clear()
        self.artifact_type_combo.addItems(self.artifact_db.artifact_types())
        self.artifact_resolution_combo.clear()
        self.artifact_resolution_combo.addItems(self.artifact_db.resolutions())

    def add_artifact_type_manual(self):
        if not self._ensure_artifact_database():
            return
        value = self.artifact_new_type.text().strip()
        if value:
            self.artifact_db.add_artifact_type(value)
            self.refresh_artifact_lists()
            self.artifact_type_combo.setCurrentText(value)
            self.artifact_new_type.clear()

    def add_resolution_manual(self):
        if not self._ensure_artifact_database():
            return
        value = self.artifact_new_resolution.text().strip()
        if value:
            self.artifact_db.add_resolution(value)
            self.refresh_artifact_lists()
            self.artifact_resolution_combo.setCurrentText(value)
            self.artifact_new_resolution.clear()

    def collect_selected_artifact_images(self):
        self._tree_selection_changed()
        if not self.artifact_selected_indices and self.dicom_entries:
            self.artifact_selected_indices = [getattr(self, "slice_index", 0)]
        self.artifact_selection_label.setText(
            f"Training images ready: {len(self.artifact_selected_indices)}"
        )
        self.tabs.setCurrentIndex(self.tabs.count() - 1)

    def set_current_normal_reference(self):
        if self.current_image is None:
            QMessageBox.information(self, "Normal Reference", "Load an image first.")
            return
        self.normal_reference_image = np.asarray(self.current_image, dtype=float).copy()
        self.normal_reference_path = Path(self.current_source) if self.current_source else None
        self.artifact_normal_label.setText(
            f"Normal reference: {self.normal_reference_path or 'Current image'}"
        )

    def load_normal_reference(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Load Normal Reference", "",
            "DICOM or NumPy (*.dcm *.ima *.npy *.npz);;All files (*)"
        )
        if not filename:
            return
        path = Path(filename)
        try:
            if path.suffix.lower() == ".npy":
                image = np.load(path, allow_pickle=False)
            elif path.suffix.lower() == ".npz":
                archive = np.load(path, allow_pickle=False)
                image = archive[list(archive.keys())[0]]
            else:
                image = self.read_dicom(path).image
            image = np.asarray(image).squeeze()
            if image.ndim != 2:
                raise ValueError(f"Normal reference must be 2D: {image.shape}")
            self.normal_reference_image = image.astype(float)
            self.normal_reference_path = path
            self.artifact_normal_label.setText(f"Normal reference: {path}")
        except Exception as exc:
            QMessageBox.critical(self, "Normal Reference Error", str(exc))

    def save_artifact_training_samples(self):
        if not self._ensure_artifact_database():
            return
        indices = [
            i for i in self.artifact_selected_indices
            if 0 <= i < len(self.dicom_entries)
        ]
        if not indices:
            QMessageBox.information(self, "Artifact Learning", "Select DICOM images first.")
            return
        artifact_type = self.artifact_type_combo.currentText().strip() or "Not Artifact"
        resolution = self.artifact_resolution_combo.currentText().strip()
        notes = self.artifact_notes.toPlainText().strip()
        progress = self._make_progress("Saving Artifact Training Samples", len(indices))
        saved = 0
        try:
            for count, index in enumerate(indices, start=1):
                if progress.wasCanceled():
                    break
                entry = self.dicom_entries[index]
                progress.setLabelText(f"Analyzing image: {entry.path.name}")
                features = image_features(entry.image, self.normal_reference_image)
                ds = entry.ds
                self.artifact_db.add_sample(
                    source_path=str(entry.path),
                    source_name=entry.path.name,
                    series_uid=str(getattr(ds, "SeriesInstanceUID", "")),
                    series_description=str(
                        getattr(ds, "SeriesDescription", "")
                        or getattr(ds, "ProtocolName", "")
                    ),
                    instance_number=int(getattr(ds, "InstanceNumber", index) or index),
                    artifact_type=artifact_type,
                    resolution=resolution,
                    is_normal_reference=False,
                    normal_reference_path=str(self.normal_reference_path or ""),
                    features=features,
                    notes=notes,
                )
                saved += 1
                progress.setValue(count)
        finally:
            progress.close()
        self.refresh_artifact_training_table()
        self.artifact_summary.setText(
            f"Saved {saved} sample(s) as {artifact_type}. "
            f"Normal comparison: {'Yes' if self.normal_reference_image is not None else 'No'}"
        )

    def refresh_artifact_training_table(self):
        if self.artifact_db is None:
            self.artifact_training_table.setRowCount(0)
            return
        rows = self.artifact_db.samples()
        self.artifact_training_table.setRowCount(len(rows))
        for r, sample in enumerate(rows):
            try:
                features = json.loads(sample.get("features_json", "{}"))
            except Exception:
                features = {}
            values = [
                sample["id"], sample["source_name"], sample["series_description"],
                sample["instance_number"], sample["artifact_type"],
                sample["resolution"] or "",
                "Yes" if features.get("normal_comparison") else "No",
                sample["source_path"] or "",
            ]
            for c, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.UserRole, int(sample["id"]))
                self.artifact_training_table.setItem(r, c, item)
        self.artifact_training_table.resizeColumnsToContents()

    def reclassify_selected_db_rows(self):
        if self.artifact_db is None:
            return
        rows = sorted({i.row() for i in self.artifact_training_table.selectedItems()})
        artifact_type = self.artifact_type_combo.currentText().strip() or "Not Artifact"
        resolution = self.artifact_resolution_combo.currentText().strip()
        notes = self.artifact_notes.toPlainText().strip()
        for row in rows:
            item = self.artifact_training_table.item(row, 0)
            if item is not None:
                self.artifact_db.update_sample_classification(
                    int(item.data(Qt.UserRole)), artifact_type, resolution, notes
                )
        self.refresh_artifact_training_table()

    def import_artifact_database(self):
        if not self._ensure_artifact_database():
            return
        filename, _ = QFileDialog.getOpenFileName(
            self, "Import Artifact DB JSON", "", "Artifact DB JSON (*.json)"
        )
        if filename:
            self.artifact_db.import_json(Path(filename))
            self.refresh_artifact_lists()
            self.refresh_artifact_training_table()

    def export_artifact_database(self):
        if self.artifact_db is None:
            QMessageBox.information(self, "Artifact DB", "Open an Artifact DB first.")
            return
        filename, _ = QFileDialog.getSaveFileName(
            self, "Export Artifact DB JSON", "MRI_Artifact_DB.json",
            "Artifact DB JSON (*.json)"
        )
        if filename:
            if not filename.lower().endswith(".json"):
                filename += ".json"
            self.artifact_db.export_json(Path(filename))

    def fill_header(self, ds):
        rows=[]
        for elem in ds.iterall():
            if elem.tag.group == 0x7FE0: continue
            value=str(elem.value); value=value[:1000]+'...' if len(value)>1000 else value
            rows.append((str(elem.tag), elem.keyword, elem.name, elem.VR, str(elem.VM), value))
        self.header_table.setSortingEnabled(False); self.header_table.setRowCount(len(rows))
        for r, vals in enumerate(rows):
            for c, v in enumerate(vals): self.header_table.setItem(r,c,QTableWidgetItem(v))
        self.header_table.setSortingEnabled(True); self.header_table.resizeColumnsToContents()

    def filter_header(self, text):
        text=text.lower()
        for r in range(self.header_table.rowCount()):
            show=any(text in (self.header_table.item(r,c).text().lower() if self.header_table.item(r,c) else '') for c in range(self.header_table.columnCount()))
            self.header_table.setRowHidden(r, not show)

    def export_header_excel(self):
        if self.current_ds is None: QMessageBox.information(self,'No DICOM','Load a DICOM file first.'); return
        filename,_=QFileDialog.getSaveFileName(self,'Export DICOM Header','DICOM_Header.xlsx','Excel (*.xlsx)')
        if not filename: return
        if not filename.lower().endswith('.xlsx'): filename += '.xlsx'
        wb=Workbook(); ws=wb.active; ws.title='DICOM Header'; headers=['Tag','Keyword','Name','VR','VM','Value']; ws.append(headers)
        for cell in ws[1]: cell.font=Font(bold=True); cell.fill=PatternFill('solid', fgColor='D9EAF7')
        for elem in self.current_ds.iterall():
            if elem.tag.group != 0x7FE0: ws.append([str(elem.tag),elem.keyword,elem.name,elem.VR,str(elem.VM),str(elem.value)])
        ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
        for col,width in {'A':16,'B':28,'C':38,'D':8,'E':8,'F':80}.items(): ws.column_dimensions[col].width=width
        for row in ws.iter_rows():
            for cell in row: cell.alignment=Alignment(vertical='top', wrap_text=True)
        wb.save(filename); self.statusBar().showMessage(f'Exported {filename}')

    def export_npz(self):
        if self.current_image is None: return
        filename,_=QFileDialog.getSaveFileName(self,'Export NPZ','MRI_FFT_Data.npz','NPZ (*.npz)')
        if filename:
            if not filename.lower().endswith('.npz'): filename += '.npz'
            np.savez_compressed(filename,image=self.current_image,kspace=self.current_kspace,reconstruction=self.current_recon,source=self.current_source)

    def closeEvent(self,event):
        if self.artifact_db is not None:
            try:
                self.artifact_db.close()
            except Exception:
                pass
        for d in self.temp_dirs:
            shutil.rmtree(d, ignore_errors=True)
        event.accept()


def main():
    app=QApplication(sys.argv); app.setApplicationName(APP_NAME)
    win=MainWindow(); win.show(); sys.exit(app.exec())


if __name__ == '__main__': main()
