# MRI Raw & FFT Explorer — Commit 0008 Prototype

Windows desktop prototype based on the approved image-first workspace.

## Main prototype behavior

- Large main image viewer.
- FFT/k-space log-magnitude is the default display.
- One-click display buttons: **FFT**, **Original**, and **Both**.
- The selected button always indicates the current display state.
- Movable horizontal and vertical crosshair lines over the main image.
- Dragging either line updates the lower profile graph immediately.
- Row/Column profile selection with slider and numeric position control.
- Magnitude, Real, Imaginary, and Phase profile modes.
- Resizable upper/lower areas using a live Qt splitter.
- In Both mode, FFT and Original images are displayed side by side with synchronized line positions.
- Drop-only main import workflow. DICOM files, folders, ZIP, GE TrackerImg/PFile, CSV, TXT, NPY, and NPZ are supported by the prototype.
- Existing export operations remain under the File menu.
- DICOM header display, filtering, and Excel export.
- Tracker PFile candidate reconstruction and automatic registration of its complex raw stream in **1D Signal Studio**.
- Selected DICOM/k-space line can be sent directly to 1D Signal Studio.

## Important prototype limitations

- GE Tracker reconstruction uses heuristic matrix and complex-int16 detection. It is not a replacement for GE Orchestra reconstruction.
- Generic `.raw`, `.bin`, and Siemens `.dat` are detected, but the full interactive binary-layout dialog/vendor reconstruction workflow will be reintegrated after evaluation of this new layout.
- FFT shown for DICOM is pseudo-k-space generated from the reconstructed DICOM pixels.

## Run from Python

```text
01_RUN_PYTHON_DEBUG.bat
```

## Recommended local build

```text
02_BUILD_FAST_STANDALONE.bat
```

## GitHub Actions

Place the workflow at the repository root:

```text
.github/workflows/build_mri_raw_fft.yml
```

Run the workflow with `fast_pyinstaller`. The output is a standalone Windows ZIP artifact.


## Commit 0008 R1 — Simple GitHub Artifact

The workflow no longer creates `MRI_Raw_FFT_Explorer_Windows.zip` inside the
GitHub Artifact.

GitHub Actions now uploads the completed standalone folder contents directly.
When the Artifact is downloaded from GitHub, there is only one ZIP layer. After
opening or extracting it, `MRI_Raw_FFT_Explorer.exe`, `_internal`, README, and
BUILD_INFO are immediately available.

Expected download structure:

```text
MRI_Raw_FFT_Explorer_Windows-fast_pyinstaller.zip
├── MRI_Raw_FFT_Explorer.exe
├── _internal
├── README.md
├── BUILD_INFO.txt
└── vendor_sdk_config.json
```


## Commit 0008 R2 — Tab Navigation and Import Progress

- Image Workspace, 1D Signal Studio, and DICOM Header remain available as persistent top tabs.
- 1D Signal Studio includes a prominent Back to Image Workspace button.
- Selecting a Tracker signal in Explorer opens the 1D Signal Studio tab without replacing the main workspace.
- A modal progress window is shown while scanning folders, extracting ZIP files, detecting DICOM images, and loading Tracker/1D data.
- The progress window shows the current file and supports Cancel.
- ZIP extraction still validates paths before extraction.
- The single-layer GitHub Artifact packaging introduced in R1 is retained.


## Commit 0008 R3 — Spike Noise Detection

A `Spike` button is available in Image Workspace.

- Scans imported GE Tracker/PFile, extensionless TrackerImg, RAW, BIN, and DAT files.
- Uses robust median/MAD amplitude and first-difference scores.
- Threshold is adjustable in the Spike Detection tab.
- Lists score, spike-group count, strongest sample, and inspected sample count.
- Double-clicking a result opens the extracted raw signal in 1D Signal Studio.
- Detected spike positions are overlaid with red markers.
- Long generic binary files are analyzed from a bounded tail region to limit memory usage.

This is a screening function. Vendor-specific headers, channel layouts, and expected
sequence impulses can affect the score, so flagged files should be reviewed visually.


## Commit 0008 R4 — Tracker Signal Explorer

Tracker file inspection is separated from Spike Detection.

- Adds a dedicated `Tracker Signal Explorer` tab.
- Reads Tracker PFile / TrackerImg data without FFT.
- Automatically evaluates every raw line.
- Picks and ranks the strongest lines by Peak, RMS, Energy, Mean Magnitude, or Variance.
- Displays the top lines immediately.
- Supports Magnitude, Real, Imaginary, and Phase views.
- Allows up to eight selected lines to be overlaid.
- Includes Previous / Next Strong Line navigation.
- Exports line metrics to CSV.
- Keeps the existing Spike Detection tab as a separate diagnostic view.


## Versioned GitHub Artifact workflow fix

The Artifact name now includes the application version, release identifier, and build engine:

```text
MRI_Raw_FFT_Explorer_v0.8.3_Commit0008_R4_fast_pyinstaller.zip
```

The Artifact remains a single ZIP layer. `BUILD_INFO.txt` includes the application
name, version, release, Git SHA, engine, Python version, and UTC build time.


## Commit 0008 R5 — Image Editing and Display Controls

- Explorer selection follows Up/Down arrow keys and immediately updates the image.
- Image A/B registration with Add and Subtract processing.
- Processed Add/Subtract files include `_addsub` in the name.
- A movable rectangular compensation ROI interpolates the selected region from surrounding signals.
- Compensation files include `_comp` in the name.
- Processed files are stored under `MRI_Raw_FFT_Work` beside the source data.
- DICOM sources produce a derived DICOM plus an NPY working copy.
- Dynamic Range and Window Level are directly adjustable.
- Presets: Auto, Wide, Soft Tissue, High Contrast, and Narrow.
- Saved processed files appear under `Processed Files` in Explorer.


## Commit 0008 R6 — Tracker Position Conversion

Analysis of the attached TrackerApp identified the following position pipeline:

1. Zero-padded FFT of a selected tracker direction (`GE_FFTLength = 1024`).
2. Peak-bin conversion into millimeters using FOV.
3. Plane and in-plane rotation mapping.
4. Least-squares solution from at least three directional measurements.
5. CenterOffset addition.
6. Optional AP-coordinate sign inversion (`OpposeAPcoordinate = 1`).
7. Optional vendor gradient-map correction.

The new `Tracker Position` tab implements steps 1–6. It is separate from:

- `Tracker Signal Explorer`, which continues to display raw tracker lines without FFT.
- `Spike Detection`, which remains an independent diagnostic workflow.

Gradient-map correction is explicitly reported as not applied until compatible field
distribution files and their exact interpolation format are available.


## Commit 0009 R1 — Artifact Learning and Artifact DB

- DICOM Explorer is grouped by Series and supports expand/collapse.
- Multiple images can be selected for training.
- Artifact labels include Spike, Frequency, and expandable custom types.
- Images can be manually reclassified, including `Not Artifact`.
- How to Resolved supports dropdown values and manual additions.
- Normal images can be selected from the study or loaded separately.
- Artifact-vs-normal difference features are stored.
- SQLite is the working DB format.
- JSON import/export supports sharing and master updates.
- Spike Detection remains separate and can be used as a source for later labeling.


## Commit 0009 R2 — Compensation ROI Fix

- Automatically switches to Original image mode.
- Adds an explicit Preview Compensation step.
- Shows ROI coordinates and mean/max pixel change.
- Uses all four surrounding borders for interpolation.
- Shows the compensated result immediately.
- Apply & Save writes the `_comp` file and displays the exact save path.
- Cancel restores the original image.


## Commit 0010 R1 — DB-trained Artifact Detection and Strongest Tracker Line

### Artifact Detection

- Spike is classified from Artifact DB training samples instead of a fixed threshold.
- Frequency and all additional Artifact classes use the same trainable detector.
- Classes require a configurable minimum number of labeled samples.
- Results show predicted class, confidence, normalized distance, training support, and alternatives.
- Low-confidence and insufficient-training results are explicitly identified.
- Selected detection results can be sent to Artifact Learning for manual correction or reclassification.
- Spike Diagnostic remains separate for raw waveform inspection.

### Tracker Signal Explorer

- Automatically identifies exactly one strongest line using RMS signal strength.
- Displays that line's Magnitude by default.
- Reports the strongest line number, RMS, and peak.
- FFT remains disabled in Tracker Signal Explorer.

### Reusable GitHub workflow

- `.github/workflows/build_module_generic.yml` no longer contains a hard-coded version or commit.
- `version.json` controls application name, version, commit, EXE name, and Artifact name.
- Future releases only require a new SOURCE ZIP with an updated `version.json`.
- The same YML can be reused without modification.
- Artifact output remains a single ZIP layer.


## Commit 0010 R2 — Universal Build Metadata

- `version.json` is now a required standard file for this SOURCE ZIP.
- The included Universal Build System v2 prefers `version.json`.
- Older SOURCE ZIP files without `version.json` remain buildable.
- Legacy metadata is inferred from the SOURCE ZIP filename.
- Unrecognized metadata falls back to `Unknown` without stopping the build.
- Future releases update only `version.json`; the YML remains unchanged.
- Artifact output remains a single ZIP layer.


## Commit 0010 R3 — Universal Build System v3

The common workflow now resolves build structure automatically.

Build strategy priority:

1. `version.json` entry point
2. Known build BAT files
3. PyInstaller `.spec`
4. `pyproject.toml`
5. Known Python entry filenames
6. Python source scoring

Python source scoring considers:

- `if __name__ == "__main__"`
- `QApplication`
- `QMainWindow`
- Tk / wx application creation
- `def main()`
- `.show()`
- entry-like filenames

The workflow also locates the generated EXE automatically after BAT, SPEC,
PyInstaller, or Nuitka builds. Existing legacy SOURCE ZIP files remain supported.


## Commit 0010 R4 — Ready-to-Build Universal Build v4

- BAT execution is completely disabled.
- A valid PyInstaller SPEC is used when present.
- Otherwise, the Python entry point is detected and packaged directly.
- Old BAT references to obsolete Python filenames can no longer break the build.
- Resources and common installed packages are collected automatically.
- Generated EXE and output folder are detected automatically.
- Artifact output remains a single ZIP layer.


## Commit 0011 R1 — Raw Compensation, Add/Sub Preview, Learning Preview

### Raw compensation
- Selecting compensation does not change Display mode, preset, Window Level, or Dynamic Range.
- ROI coordinates always map to raw/k-space data.
- Preview compensates raw data first, runs IFFT reconstruction again, and refreshes the image.
- Levels: Low, Mid, High.
- Multiple ROIs can be committed sequentially.
- Previous / Next navigates compensation history.
- The displayed history state can be saved with reconstructed image and raw NPY.

### Add/Subtract
- Preview opens Image A, Image B, and Result in three synchronized panels.
- Results are saved only after preview confirmation.

### Artifact Learning
- Selected training images can be previewed.
- Previous / Next Selected navigates multiple selected images.


## Commit 0012 R1 — Shared Tracker Data

Tracker PFile / TrackerImg data is now retained as common application data.

- Image Workspace can display Tracker raw magnitude and reconstructed image.
- Strongest Tracker line is registered in 1D Signal Studio automatically.
- Tracker Signal Explorer provides buttons to open Image Workspace and 1D Studio.
- Explorer tree includes the strongest line and Tracker workspace views.
- Artifact Detection can classify the current Tracker raw matrix using Artifact DB.
- Artifact Learning can preview Tracker magnitude and save it as a training sample.
- Tracker Position continues to use the same loaded Tracker matrix.
- Loading a Tracker file does not discard the shared data when changing tabs.


## Commit 0013 R1 — Multi Tracker Navigation and Clear Controls

- Multiple Tracker files with Previous/Next, dropdown, and Left/Right keys.
- Clear Current/All Tracker files.
- Clear Selected/All imported images.
- Remove Selected/Clear All 1D signals.
- Clear Add/Sub A, B, result; clear compensation history; clear Artifact Learning selection.


## MR Image Explorer RC1 Prototype Pack1 — Commit0014a

- Renamed application and five-tab RC1 layout.
- Tracker Position integrated under Tracker Signal.
- Artifact Detection/Learning integrated under Artifact Diag.
- DICOM Header popup with copy, edit, numbered save, and close.
- Single-open accordion for Spike, Raw Compensation, and Add/Sub.
- Prototype Range/Level controls and Quick Spike Detect candidate highlighting.
- Initial modular project folders for Pack2/Pack3 migration.


## Commit0014a HotFix1

- Fixed ZIP import completion error caused by obsolete `header_table` access.
- DICOM list clicks now update the image immediately.
- Auto Window/Level recalculates for every selected image.
- Type changes update Original, FFT, and line profile in real time.
- Explorer entries now show filename, instance, matrix size, and bit depth.
- Artifact DB Open/Create and JSON Import now use the correct dialogs.
- Compensation History Clear repeatedly restores the original image.
- Image right-click menu includes Window/Level, Pan, Zoom, Paging, ROI, and Auto Window/Level.
- Paging mode supports mouse-wheel image navigation.


## Commit0014a HotFix2

- Initial display after image loading is Both.
- Tracker source selector was removed from Image Workspace.
- Selected Explorer rows use translucent light-blue highlighting.
- Compensation ROI now has resize handles at all four corners.
- Original and Raw Window/Level are managed independently.
- Original Auto Window/Level recalculates per image.
- Raw Window/Level remains manual until explicitly reset.
- Right-click image menu now controls Pan, Zoom, Paging, ROI, FFT, Original,
  Both, Auto Window/Level, and Back to Default.
- Window/Level mode uses mouse wheel for Level and Ctrl+wheel for Width.
- Add/Sub and generated images can be displayed in FFT, Original, or Both.
- Saved generated images are added to Explorer and remain selectable.
- Output top folder is shown in the lower-right and can be changed.
- Default output is created below the opened image folder.
- JPEG, PNG, and BMP files are supported as Original-only images.
- Spike Apply now processes selected DICOM original images using raw/k-space
  spike suppression; RAW/PFile scanning remains available when no DICOM is selected.


## Commit0014a HotFix3

- Right-side settings are placed in a vertical scroll area with wider controls.
- Explorer minimum width was reduced so the user can freely make it narrow.
- Explorer text is single-line and elided; full details remain in tooltips.
- pyqtgraph's default context menu is disabled.
- The MR Image Explorer context menu now opens reliably on image right-click.
- Context menu actions include operating instructions through tooltips.
- `FFT Current Image` immediately recalculates FFT from the selected image and displays it.
- Back to Default resets view, Type, levels, and zoom.
- Multi-spike detection now uses local robust k-space outlier scoring,
  conjugate-pair correction, and repeated-stripe validation.
- Wide / Mid / Fine sensitivity was increased for heavy multi-spike examples.


## Commit0014a HotFix4

- Larger Service Hub-style progress window.
- Quick Spike Detect limited to high-confidence candidates, maximum 100.
- FFT Current Image replaces content in the current panel.
- Back from FFT restores the pre-FFT image.
- Manual WW/WL no longer returns to Auto.
- Current mouse action is displayed with hover help.
- Crosshair starts at center and preserves its normalized position.
- Spike Processing refreshes the four-panel Spike Diag view.
- Compensation preserves the expected central MRI cross pattern and suppresses ROI outliers toward local background noise.
- ZIP import recursively reads deeply nested folders.
- Tracker `.dat` and same-name `.txt` analysis are loaded together.
- Multiple Tracker files remain listed and do not force-open Tracker Signal.


## Commit0014a HotFix5
- Fixed EXE startup failure caused by missing QGridLayout import.
- Added startup import validation.
- Reworked Quick Spike Detect using Series-relative robust classification with High Confidence, Review, and No Spike.
- Removed arbitrary candidate count cap.
- Added Explorer drag-out to Windows Explorer for original files, multiple selection, Series selection, and Tracker DAT/TXT pairs.


## Commit0014a HotFix6

- Fixed the initial-import hang caused by decoding every DICOM Pixel Data item.
- DICOM import now reads headers first and builds the Explorer list without pixel decompression.
- Pixel Data is loaded only when an image is selected or required for analysis.
- A bounded lazy-image cache keeps recently viewed images while releasing older arrays.
- Only the first DICOM image is decoded during initial import.
- Folder and ZIP scanning filter unsupported files before DICOM probing.
- Same-name Tracker TXT files are no longer opened as independent 1D signals.
- Tracker files are collected and loaded as a batch without repeated tab switching.
- Explorer multi-selection blocks display signals until selection is complete.


## Commit0014a HotFix7

- Fixed duplicate import requests from overlapping drop handlers.
- Import is deferred until the drag/click event has completed.
- The progress window is forced to the foreground and remains accessible.
- Folder scanning updates the progress window every 100 checked files.
- The drop banner is disabled during import and restored afterward.
- Clicking the drop banner opens a Files / Folder selection dialog.
- Added File menu commands for Import Files and Import Folder.
- Repeated import requests bring the existing progress dialog to the front.
- Main-window and banner drops now use one shared import-request path.


## Commit0014a HotFix8

- Build packaging now validates the embedded Python runtime DLL.
- If PyInstaller does not place `python313.dll` in `_internal`, the workflow
  copies it explicitly from the GitHub Actions Python installation.
- `python3.dll` is also copied when available.
- Staging uses `robocopy` rather than wildcard `Copy-Item`.
- The staged Artifact is rejected if the startup EXE or Python DLL is missing.
- Added `VERIFY_PACKAGE.bat` to check the extracted distribution.
- Added `RUN_MR_IMAGE_EXPLORER.bat` to start the packaged EXE from its own folder.
- A SHA-256 package manifest is generated before Artifact upload.


## Commit0014a HotFix9

- Restored the missing second half of `import_paths()`.
- Fixed drag/drop accepting files but performing no indexing or display update.
- DICOM metadata indexing, Explorer population, first-image display, Tracker loading,
  raw-file listing, bitmap listing, and signal loading are all executed again.
- Import now reports recognized and skipped file counts.
- Raw/P files that cannot yet be decoded are still listed in Explorer.
- Raw/P file selections can be dragged to Windows Explorer as original files.
- The application returns to Image Workspace after a successful import.


## Commit0014a HotFix10

- Import now performs indexing only while the progress window is open.
- DICOM Pixel Data decoding starts only after the Import window closes.
- Tracker files are listed without being parsed during import.
- Tracker parsing starts only when the user selects a Tracker item.
- Bitmap and signal files are also loaded only when selected.
- Import completion no longer depends on image decoding or Tracker analysis.
- Tracker loading no longer clears the main Explorer or forces tab navigation.


## Commit0014a HotFix11

- ZIP extraction, deep folder scanning, and DICOM header indexing now run in a QThread.
- The UI thread no longer performs ZIP extraction or metadata indexing.
- The progress window is non-modal, always-on-top, and updated through Qt signals.
- Large ZIP members are copied in 1 MB chunks with cancellation checks.
- Explorer construction occurs only after the background worker completes.
- First-image Pixel Data is decoded only after the progress window closes.
- Cancel remains responsive during folder scanning, ZIP extraction, and indexing.


## Commit0015 Import Engine RC

- Replaced the Qt Worker/QThread import path with a Python thread plus event queue.
- The progress window is painted before the background thread starts.
- ZIP extraction, recursive scanning, and DICOM header indexing never run on the UI thread.
- A 50 ms UI timer receives progress, completion, failure, and cancellation events.
- A worker that exits without a result is detected and reported instead of leaving Importing displayed forever.
- Cancel uses a thread-safe Event and remains responsive during ZIP extraction and scanning.
- The existing lazy Pixel Data loading and Explorer population are retained.


## Commit0015a Startup Fix

- Restored the missing `main()` application entry point.
- Restored `if __name__ == "__main__"` so the packaged EXE opens the UI.
- Added startup dependency validation.
- Startup exceptions are written to:
  `%LOCALAPPDATA%\MR_Image_Explorer\startup_error.log`
- Added a visible startup error dialog when initialization fails.
- Added Python and packaged-EXE startup smoke tests to GitHub Actions.
- The workflow now rejects source packages that do not contain a runnable entry point.


## Commit0015b Import Start Fix

- Fixed a race condition between the Import worker and the 50 ms watchdog timer.
- The background worker now starts before the polling timer.
- The watchdog no longer reports a stopped worker during its startup period.
- Added a 1.5-second worker startup grace period.
- The result queue is drained one final time before reporting abnormal worker exit.
- ZIP extraction sends heartbeat progress updates while copying large members.
- Import state is fully reset after completion, cancellation, or failure.


## Commit0015c Embedded Progress

- Replaced the separate Import progress window with an in-window overlay.
- The progress overlay is always rendered inside MR Image Explorer.
- Windows focus, modal state, multi-monitor position, and window stacking can no
  longer hide the Import progress display.
- The overlay remains centered when the main window is resized.
- The current phase, determinate/indeterminate progress, and Cancel button remain
  visible throughout ZIP extraction, folder scanning, and file indexing.


## Commit0015d Layout Progress

- Removed floating and overlay-style Import progress presentation.
- Import progress is now a regular layout panel directly below the drop area.
- The panel cannot be hidden behind pyqtgraph, OpenGL, or native child windows.
- The tab area moves downward while Import is active.
- Current phase, progress bar, and Cancel remain continuously visible.
- The panel is hidden after completion, cancellation, or failure and reused later.


## Commit0015e Progress Import Fix

- Fixed startup failure caused by missing `QProgressBar` import.
- Added the required `QSizePolicy` import used by the layout progress panel.
- Added both classes to startup dependency validation.
- The application now fails the GitHub startup smoke test if either class is missing.
- Commit0015d layout-based progress presentation is retained.


## Commit0016 Interaction Stability

- Improved Import progress text wrapping and clipping.
- Added deferred layout stabilization after Import and image changes.
- Removed DICOM list tooltip popups.
- Added DICOM checkboxes for reliable multi-image processing selection.
- Added Previous Import to restore the prior DICOM list.
- Simplified right-click actions to deterministic commands.
- Fixed Compensation Preview failure caused by missing line position ratios.
- Quick Spike Detect now loads lazy DICOM pixels before analysis.
- Quick Spike Detect reports High Confidence, Review, and read errors.


## Commit0016a Add/Sub Save Fix

- Add/Sub output no longer uses the temporary ZIP extraction folder.
- Default output is stored under the original ZIP/file/folder location:
  `MR_Image_Explorer_Output/AddSub`.
- Add/Sub DICOM metadata is taken from Image A.
- Both DICOM and NPY output creation are verified after saving.
- A visible success message shows the complete saved path.
- Save errors now display the exact failure reason.
- Existing filenames are preserved by automatically adding `_1`, `_2`, etc.
