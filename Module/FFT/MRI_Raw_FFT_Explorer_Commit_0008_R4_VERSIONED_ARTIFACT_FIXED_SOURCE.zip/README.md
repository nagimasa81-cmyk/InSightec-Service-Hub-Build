# MRI Raw & FFT Explorer — Commit 0008 Prototype

Windows desktop prototype based on the approved image-first workspace.

## Main prototype behavior

- Large main image viewer.
- FFT/k-space log-magnitude is the default display.
- One-click display buttons: **FFT**, **Original**, and **Both**.
- The selected button always indicates the current display state.
- Movable horizontal and vertical crosshair lines over the main image.
- Dragging either line updates the lower profile graph immediately.
- Row/Column profile selection with slider and numeric position control.
- Magnitude, Real, Imaginary, and Phase profile modes.
- Resizable upper/lower areas using a live Qt splitter.
- In Both mode, FFT and Original images are displayed side by side with synchronized line positions.
- Drop-only main import workflow. DICOM files, folders, ZIP, GE TrackerImg/PFile, CSV, TXT, NPY, and NPZ are supported by the prototype.
- Existing export operations remain under the File menu.
- DICOM header display, filtering, and Excel export.
- Tracker PFile candidate reconstruction and automatic registration of its complex raw stream in **1D Signal Studio**.
- Selected DICOM/k-space line can be sent directly to 1D Signal Studio.

## Important prototype limitations

- GE Tracker reconstruction uses heuristic matrix and complex-int16 detection. It is not a replacement for GE Orchestra reconstruction.
- Generic `.raw`, `.bin`, and Siemens `.dat` are detected, but the full interactive binary-layout dialog/vendor reconstruction workflow will be reintegrated after evaluation of this new layout.
- FFT shown for DICOM is pseudo-k-space generated from the reconstructed DICOM pixels.

## Run from Python

```text
01_RUN_PYTHON_DEBUG.bat
```

## Recommended local build

```text
02_BUILD_FAST_STANDALONE.bat
```

## GitHub Actions

Place the workflow at the repository root:

```text
.github/workflows/build_mri_raw_fft.yml
```

Run the workflow with `fast_pyinstaller`. The output is a standalone Windows ZIP artifact.


## Commit 0008 R1 — Simple GitHub Artifact

The workflow no longer creates `MRI_Raw_FFT_Explorer_Windows.zip` inside the
GitHub Artifact.

GitHub Actions now uploads the completed standalone folder contents directly.
When the Artifact is downloaded from GitHub, there is only one ZIP layer. After
opening or extracting it, `MRI_Raw_FFT_Explorer.exe`, `_internal`, README, and
BUILD_INFO are immediately available.

Expected download structure:

```text
MRI_Raw_FFT_Explorer_Windows-fast_pyinstaller.zip
├── MRI_Raw_FFT_Explorer.exe
├── _internal
├── README.md
├── BUILD_INFO.txt
└── vendor_sdk_config.json
```


## Commit 0008 R2 — Tab Navigation and Import Progress

- Image Workspace, 1D Signal Studio, and DICOM Header remain available as persistent top tabs.
- 1D Signal Studio includes a prominent Back to Image Workspace button.
- Selecting a Tracker signal in Explorer opens the 1D Signal Studio tab without replacing the main workspace.
- A modal progress window is shown while scanning folders, extracting ZIP files, detecting DICOM images, and loading Tracker/1D data.
- The progress window shows the current file and supports Cancel.
- ZIP extraction still validates paths before extraction.
- The single-layer GitHub Artifact packaging introduced in R1 is retained.


## Commit 0008 R3 — Spike Noise Detection

A `Spike` button is available in Image Workspace.

- Scans imported GE Tracker/PFile, extensionless TrackerImg, RAW, BIN, and DAT files.
- Uses robust median/MAD amplitude and first-difference scores.
- Threshold is adjustable in the Spike Detection tab.
- Lists score, spike-group count, strongest sample, and inspected sample count.
- Double-clicking a result opens the extracted raw signal in 1D Signal Studio.
- Detected spike positions are overlaid with red markers.
- Long generic binary files are analyzed from a bounded tail region to limit memory usage.

This is a screening function. Vendor-specific headers, channel layouts, and expected
sequence impulses can affect the score, so flagged files should be reviewed visually.


## Commit 0008 R4 — Tracker Signal Explorer

Tracker file inspection is separated from Spike Detection.

- Adds a dedicated `Tracker Signal Explorer` tab.
- Reads Tracker PFile / TrackerImg data without FFT.
- Automatically evaluates every raw line.
- Picks and ranks the strongest lines by Peak, RMS, Energy, Mean Magnitude, or Variance.
- Displays the top lines immediately.
- Supports Magnitude, Real, Imaginary, and Phase views.
- Allows up to eight selected lines to be overlaid.
- Includes Previous / Next Strong Line navigation.
- Exports line metrics to CSV.
- Keeps the existing Spike Detection tab as a separate diagnostic view.


## Versioned GitHub Artifact workflow fix

The Artifact name now includes the application version, release identifier, and build engine:

```text
MRI_Raw_FFT_Explorer_v0.8.3_Commit0008_R4_fast_pyinstaller.zip
```

The Artifact remains a single ZIP layer. `BUILD_INFO.txt` includes the application
name, version, release, Git SHA, engine, Python version, and UTC build time.
