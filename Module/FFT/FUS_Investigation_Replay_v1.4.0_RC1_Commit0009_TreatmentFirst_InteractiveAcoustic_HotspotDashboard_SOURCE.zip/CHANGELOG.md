# Changelog

## v1.4.0-RC1 — Commit0009

- Treatment-only Sonication list is now the default.
- Added Show DQA toggle.
- Added independent channel checkboxes to Spectrum and Hydrophone pages.
- Added interactive time-range selection on Acoustic Activity.
- Added FFT calculated from the selected payload-time interval.
- Channel comparison metrics are collapsed by default.
- Reworked MR / Hotspot Replay into an integrated analysis dashboard.
- Added larger filled red thermal-region overlay.
- Uses RAW phase-difference candidate for hotspot localization when available.
- Preserved RC1 build metadata and runtime-compatible source layout.
