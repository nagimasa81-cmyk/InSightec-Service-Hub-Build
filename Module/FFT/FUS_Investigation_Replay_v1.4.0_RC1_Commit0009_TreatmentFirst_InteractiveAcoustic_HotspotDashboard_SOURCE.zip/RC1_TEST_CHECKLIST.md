# RC1 Test Checklist

1. Build succeeds with Python 3.13 and `fast_pyinstaller`.
2. Application starts without a console window.
3. Open `09-09-11_ANx.zip` and verify Sonication table, Complete Inventory and RAW Investigation tabs populate.
4. Open `22-55-19_ANx.zip` and verify explicit Brain-DQA metadata classifies Sonications as DQA.
5. Verify each Sonication can independently change Phase, Scan Plane and Frequency Direction.
6. Verify DQA displays a DQA phantom example and Treatment displays a T2 brain example when no image is linked.
7. Link an MR/DICOM folder and save the `.fus_review.json` sidecar.
8. Reopen the ZIP and verify mappings are restored.
9. Verify Spectrum axis defaults to frequency versus amplitude and remains labeled relative when calibration is unavailable.
10. Confirm simulated/experimental content is visibly labeled and not presented as confirmed clinical data.

## RC1.1 Multi-Hydrophone checks

- [ ] SpectrumMsg count appears in the loaded ZIP summary.
- [ ] Sonication selection links to the matching `SonicationN/SpectrumMsg-N.dmp`.
- [ ] Hydrophone selector includes 1–8.
- [ ] Display selector includes Single, All Overlay, All Separate, Average, Maximum Envelope, Spectrogram.
- [ ] All Separate renders without GUI failure for 4–8 candidate channels.
- [ ] Cavitation tab never displays simulated data.
- [ ] Experimental source/calibration warning is visible.
- [ ] Left Sonication list scrolls horizontally and vertically.
- [ ] Selected Sonication details appear below the list.


## RC1.3 Thermometry / Acoustic checks

- Open both supplied treatment ZIP formats.
- Select DQA and Treatment Sonications and confirm Thermometry Replay updates.
- Move the Thermometry frame slider and confirm baseline/current/difference updates.
- Confirm all thermometry candidate views retain the unvalidated calibration warning.
- Confirm Spectrum modes: Channel Heatmap and Relative Cavitation Bands.
- Confirm Hydrophone Cavitation contains no simulated trace.
- Confirm Previous/Next updates fixed details, replay, thermometry, spectrum and cavitation.


## RC1.4 checks

- Confirm Treatment only is shown immediately after ZIP load.
- Enable Show DQA and confirm DQA rows appear.
- Confirm Previous/Next follows the filtered list.
- Toggle Ch 1–8 and confirm Spectrum and Acoustic Activity update.
- Drag over the upper Acoustic Activity chart and confirm selected-range FFT appears.
- Confirm channel metrics are hidden initially and appear only when expanded.
- Confirm MR Replay shows the integrated image, thermometry, spectrum and activity dashboard.
- Confirm RAW-derived hotspot is labeled as a phase-difference candidate; fallback hotspot is labeled simulated.
