# FUS Investigation & Treatment Replay Workstation RC1.4

## Treatment-first review

- The Sonication list shows Treatment only by default.
- `Show DQA` adds phantom/DQA Sonications without changing the saved classification.
- Previous/Next navigation follows the currently visible list and refreshes every review panel.

## Multi-hydrophone interaction

- Candidate channels 1–8 are enabled or disabled independently with checkboxes.
- The Acoustic Activity chart supports click-and-drag interval selection.
- The selected interval is transformed to an FFT for all enabled channels.
- Channel metric bars remain collapsed unless `Show channel metrics` is enabled.
- No simulated hydrophone/cavitation trace is displayed.

## Integrated Replay dashboard

The MR / Hotspot Replay page combines:

- actual linked MR or best treatment RAW candidate
- red thermal-region overlay
- thermometry trend candidate
- selected-channel acoustic spectrum
- selected-channel acoustic activity

When a consistent RAW thermometry sequence is available, the red overlay is derived from the strongest phase-difference candidate. Otherwise, it is explicitly labeled simulated.

## Important validation boundary

Hydrophone identity, physical frequency calibration, SpectrumMsg timing, phase identity, PRF conversion and degrees-Celsius calibration remain experimental until their proprietary data structure is validated.

## Build

Compatible with the supplied RC1 GitHub Actions workflow.

- Entry point: `app.py`
- Python: 3.13
- Build engine: `fast_pyinstaller`
