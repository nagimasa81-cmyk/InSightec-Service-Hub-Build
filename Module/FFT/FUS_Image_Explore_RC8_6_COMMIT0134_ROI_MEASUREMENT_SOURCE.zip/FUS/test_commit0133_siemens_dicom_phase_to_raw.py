from pathlib import Path
from types import SimpleNamespace
from raw_metadata_resolver import RawMetadataResolver

class DS(SimpleNamespace):
    def get(self, tag):
        return None

# Siemens axial: IOP row=RL, col=AP. Phase ROW => frequency AP.
ds = DS(
    SeriesInstanceUID='1.2.3', SeriesNumber=6,
    SeriesDescription='MEMP Sonication 2', ProtocolName='MEMP',
    InPlanePhaseEncodingDirection='ROW',
    ImageOrientationPatient=[1,0,0,0,1,0],
    Manufacturer='SIEMENS',
)
entry = SimpleNamespace(ds=ds, path=Path('/exam/DICOM/MEMP/6-1.dcm'))
index = RawMetadataResolver.build_index([])
index['dicom_series'] = RawMetadataResolver.build_dicom_series_index([entry])
raw = Path('/exam/Sonication2/MEMP/6-2-0-4.raw')
header = RawMetadataResolver.resolve(raw, index)
assert header['dicom_series_match'] is True, header
assert header['phase_direction'] == 'ROW', header
assert header['frequency_direction'] == 'AP', header
assert header['scan_plane'] == 'AXIAL', header
assert header['dicom_series_number'] == '6', header
assert any('0018,1312' in e['method'] for e in header['evidence'])
assert any('0020,0037' in e['method'] for e in header['evidence'])

# Ambiguous same-series candidates must not be inherited.
ds2 = DS(
    SeriesInstanceUID='1.2.4', SeriesNumber=6,
    SeriesDescription='MEMP alternate', ProtocolName='MEMP',
    InPlanePhaseEncodingDirection='COL',
    ImageOrientationPatient=[1,0,0,0,1,0], Manufacturer='SIEMENS')
index2 = RawMetadataResolver.build_index([])
index2['dicom_series'] = RawMetadataResolver.build_dicom_series_index([
    entry, SimpleNamespace(ds=ds2, path=Path('/exam/DICOM/MEMP Sonication 2/6-2.dcm'))])
h2 = RawMetadataResolver.resolve(raw, index2)
assert h2['dicom_series_match'] is False, h2
print('Commit0133 Siemens DICOM phase-to-RAW tests: PASS')
