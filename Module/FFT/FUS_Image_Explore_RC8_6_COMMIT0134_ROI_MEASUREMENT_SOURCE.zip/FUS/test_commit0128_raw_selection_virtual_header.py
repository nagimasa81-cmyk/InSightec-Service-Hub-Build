from pathlib import Path
import ast, json
text=Path('app.py').read_text(encoding='utf-8')
ast.parse(text)
for marker in [
    'Commit0128 RAW Selection and Virtual Header',
    'self.raw_virtual_header_cache',
    'self.current_virtual_header',
    'def _get_or_build_raw_virtual_header',
    'def _build_import_raw_virtual_headers',
    'Virtual DICOM Header',
    'virtual_header=virtual',
    "for item in self.tree.selectedItems()",
    'Unclassified RAW',
]: assert marker in text, marker
# Import must generate virtual headers and RAW display must bind the current one.
assert 'self._build_import_raw_virtual_headers(raw_files)' in text
assert 'self.current_virtual_header = self._get_or_build_raw_virtual_header(path, result=result)' in text
# Header action must accept either real DICOM or virtual RAW metadata.
assert 'current_virtual_header' in text[text.index('header_action.setEnabled'):text.index('selected = menu.exec', text.index('header_action.setEnabled'))]
# Relation and Quick Spike both resolve virtual headers before category decisions.
for name in ('def _quick_spike_detect_raw','def _relation_records_raw'):
    block=text[text.index(name):]
    assert '_get_or_build_raw_virtual_header' in block[:1800]
version=json.loads(Path('version.json').read_text(encoding='utf-8'))
assert int(version['commit']) >= 128
print('Commit0128 static checks: PASS')
