import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import numpy as np
from PySide6.QtWidgets import QApplication
from app import ImagePanel

app = QApplication.instance() or QApplication([])
panel = ImagePanel('ROI Test')
image = np.arange(100, dtype=float).reshape(10,10)
panel.set_image(image)
panel.show_measure_roi()
panel.measure_roi.setPos(2,3)
panel.measure_roi.setSize((4,2))
panel._update_measurement()
r = panel._last_measurement
assert r is not None
assert (r['x'],r['y'],r['width_px'],r['height_px']) == (2,3,4,2)
expected=image[3:5,2:6]
assert np.isclose(r['mean'], expected.mean())
assert np.isclose(r['std'], expected.std())
assert r['pixels'] == 8
panel.hide_measure_roi()
assert not panel.measure_roi.isVisible()
print('PASS: Commit0134 ROI measurement')
