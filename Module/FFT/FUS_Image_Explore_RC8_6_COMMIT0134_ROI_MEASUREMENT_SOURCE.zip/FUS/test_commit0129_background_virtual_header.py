from pathlib import Path
text = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
required = [
    'QPushButton("Correlation")',
    'Generating Virtual Headers:',
    'Virtual Headers Ready:',
    'Derived from plane and phase direction',
    '"AXIAL": {"ROW": "RL", "COL": "AP"}',
    '"CORONAL": {"ROW": "RL", "COL": "SI"}',
    '"SAGITTAL": {"ROW": "AP", "COL": "SI"}',
    'Only list RAW files that can actually be decoded',
]
for marker in required:
    assert marker in text, marker
assert 'self._build_import_raw_virtual_headers(raw_files)' not in text
