from pathlib import Path
import tempfile
from raw_metadata_resolver import RawMetadataResolver


def write(root, name, text):
    p = root / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8')
    return p

with tempfile.TemporaryDirectory() as td:
    root = Path(td)
    raw = root / 'Sonication3' / 'MEMP' / '6-2-0-4.raw'
    raw.parent.mkdir(parents=True)
    raw.write_bytes(b'0')
    write(root, 'review.out', 'GE Medical\nPlane=AXIAL\nPhase Direction=ROW\nProtocol Name=MEMP')
    idx = RawMetadataResolver.build_index(root.rglob('*'))
    h = RawMetadataResolver.resolve(raw, idx)
    assert h['mr_vendor'] == 'GE'
    assert h['frequency_direction'] == 'AP', h
    assert h['series_key'] == '6-2-0'
    assert h['frame_number'] == 4

with tempfile.TemporaryDirectory() as td:
    root = Path(td)
    raw = root / 'Sonication2' / 'TMAP3' / '8-1-0-9.raw'
    raw.parent.mkdir(parents=True)
    raw.write_bytes(b'0')
    write(root, 'MRFILES/Phoenix.asc', '### ASCCONV BEGIN ###\nsSliceArray.asSlice[0].sNormal.dSag = 0\nsSliceArray.asSlice[0].sNormal.dCor = 0\nsSliceArray.asSlice[0].sNormal.dTra = 1\nucPhaseEncDir = COL\ntProtocolName = "TMAP"')
    idx = RawMetadataResolver.build_index(root.rglob('*'))
    h = RawMetadataResolver.resolve(raw, idx)
    assert h['mr_vendor'] == 'Siemens'
    assert h['scan_plane'] == 'AXIAL'
    assert h['frequency_direction'] == 'RL', h
    assert not any('review.out' in s.lower() for s in h['sources'])

with tempfile.TemporaryDirectory() as td:
    root = Path(td)
    raw = root / 'Anatomy MR' / '1-0-0-1.raw'
    raw.parent.mkdir(parents=True)
    raw.write_bytes(b'0')
    write(root, 'protocol.txt', 'Plane=CORONAL\nPhase Direction=SI\nFrequency Direction=AP')
    idx = RawMetadataResolver.build_index(root.rglob('*'))
    h = RawMetadataResolver.resolve(raw, idx)
    assert h['frequency_direction'] == 'AP'
    assert h['metadata_conflict'] is True

print('Commit0131 resolver tests: PASS')
