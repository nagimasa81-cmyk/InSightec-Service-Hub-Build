from pathlib import Path
import ast
import json
import math
import tempfile
import zipfile
from raw_metadata_resolver import RawMetadataResolver

ROOT = Path(__file__).parent
APP = (ROOT/'app.py').read_text(encoding='utf-8')

# Set 1: static structure (3 checks)
ast.parse(APP)
ast.parse((ROOT/'raw_metadata_resolver.py').read_text(encoding='utf-8'))
v=json.loads((ROOT/'version.json').read_text(encoding='utf-8')); assert v['commit']==131 and v['version']=='5.58.0'

# Helpers
def mk(root, rel, text=None, binary=b'0'):
    p=root/rel; p.parent.mkdir(parents=True,exist_ok=True)
    if text is None: p.write_bytes(binary)
    else: p.write_text(text,encoding='utf-8')
    return p

# Set 2: GE (3 checks)
with tempfile.TemporaryDirectory() as td:
    r=Path(td); raw=mk(r,'Sonication5/MEMP/6-2-0-4.raw')
    mk(r,'review.out','GE Medical\nPlane=AXIAL\nPhase Direction=ROW\nProtocol Name=MEMP')
    idx=RawMetadataResolver.build_index(r.rglob('*')); h=RawMetadataResolver.resolve(raw,idx)
    assert h['mr_vendor']=='GE'
    assert h['frequency_direction']=='AP'
    assert (h['series_key'],h['frame_number'],h['sonication_number'])==('6-2-0',4,5)
with tempfile.TemporaryDirectory() as td:
    r=Path(td); raw=mk(r,'Anatomy MR/2-0-0-1.raw'); mk(r,'MRFILES/protocol.txt','GE Medical\nPlane=CORONAL\nPhase Direction=COL')
    h=RawMetadataResolver.resolve(raw,RawMetadataResolver.build_index(r.rglob('*')))
    assert h['frequency_direction']=='RL'  # GE without review.out

# Set 3: Siemens (3 checks)
with tempfile.TemporaryDirectory() as td:
    r=Path(td); raw=mk(r,'Sonication2/TMAP3/8-1-0-9.raw')
    mk(r,'MRFILES/Phoenix.asc','### ASCCONV BEGIN ###\nSiemens\nsSliceArray.asSlice[0].sNormal.dSag = 0\nsSliceArray.asSlice[0].sNormal.dCor = 0\nsSliceArray.asSlice[0].sNormal.dTra = 1\nucPhaseEncDir = COL')
    idx=RawMetadataResolver.build_index(r.rglob('*')); h=RawMetadataResolver.resolve(raw,idx)
    assert h['mr_vendor']=='Siemens' and h['scan_plane']=='AXIAL'
    assert h['frequency_direction']=='RL'
    assert not any('review.out' in x.lower() for x in h['sources'])
with tempfile.TemporaryDirectory() as td:
    r=Path(td); raw=mk(r,'Planning MR/1-1-0-1.raw')
    # 45-degree normal is beyond the 20-degree classification boundary.
    mk(r,'Phoenix.asc','Siemens\nASCCONV\nsNormal.dSag = 0.70710678\nsNormal.dCor = 0\nsNormal.dTra = 0.70710678\nPhase Direction=ROW')
    h=RawMetadataResolver.resolve(raw,RawMetadataResolver.build_index(r.rglob('*')))
    assert h['frequency_direction']=='Oblique >20°' and h['angle']>20

# Set 4: UI/background workflow (3 checks)
assert 'self.tabs.setCurrentIndex(0)' in APP
assert '_set_virtual_header_actions_enabled(False)' in APP and 'Generating Virtual Headers:' in APP
assert 'QPushButton("Correlation")' in APP and 'Relation")' not in APP

# Set 5: safety/package-facing invariants (3 checks)
assert 'Only list RAW files that can actually be decoded' in APP
assert 'metadata_conflict' in APP and 'Metadata Evidence' in APP
assert 'RawMetadataResolver.resolve' in APP and 'RawMetadataResolver.build_index' in APP

print('Commit0131 five triple-check sets (15 checks): PASS')
