# Commit0130 Test Checklist

- [x] Python syntax compile
- [x] Sonication-style normalized RAW identity
- [x] Dataset-wide metadata index
- [x] Siemens vendor detection without review.out
- [x] GE vendor detection with optional review.out
- [x] Siemens slice-normal plane inference
- [x] Axial/Coronal/Sagittal phase-to-frequency mapping retained
- [x] Image Workspace selected after import
- [x] Virtual Header buttons gated until background completion
- [x] Unreadable RAW suppression retained
