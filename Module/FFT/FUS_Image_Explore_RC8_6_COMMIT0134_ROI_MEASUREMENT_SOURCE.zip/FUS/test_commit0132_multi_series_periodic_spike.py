from pathlib import Path
import ast
import numpy as np

ROOT=Path(__file__).resolve().parent
TEXT=(ROOT/'app.py').read_text(encoding='utf-8')

# Selection scope: highlighted + checked union, parent expansion, controls.
for token in [
    'Return the union of highlighted and checked DICOM scope',
    'Return the union of highlighted and checked RAW scope',
    'Check Selected', 'Uncheck Selected', 'Clear Checks',
    'Qt.ItemIsAutoTristate', '_tree_check_state_changed',
]:
    assert token in TEXT, token
assert 'if not ordered:' not in TEXT[TEXT.index('def _selected_dicom_indices'):TEXT.index('def _raw_descendant_paths')]

# Execute the exact detector methods without importing the Qt application.
module=ast.parse(TEXT)
methods={}
for node in module.body:
    if isinstance(node,ast.ClassDef) and node.name=='MainWindow':
        for item in node.body:
            if isinstance(item,ast.FunctionDef) and item.name in {'_robust_zscore','_periodic_spike_cluster_features'}:
                methods[item.name]=ast.unparse(item)
code='import numpy as np\nclass Detector:\n'
for name in ('_robust_zscore','_periodic_spike_cluster_features'):
    code += '\n'.join('    '+line for line in methods[name].splitlines())+'\n'
ns={}; exec(code,ns); Detector=ns['Detector']

rng=np.random.default_rng(13)
raw=rng.normal(size=(256,256))+1j*rng.normal(size=(256,256))
cy=cx=128
for xoff in (-28,28):
    for yoff in (-70,-45,-20,20,45,70):
        raw[cy+yoff,cx+xoff]=5000
positive=Detector._periodic_spike_cluster_features(raw)
assert positive['accepted']
assert positive['symmetric_pairs'] >= 2
assert positive['chain_count'] >= 4
assert positive['orientation']=='Vertical'

control=rng.normal(size=(256,256))+1j*rng.normal(size=(256,256))
negative=Detector._periodic_spike_cluster_features(control)
assert not negative['accepted']
print('Commit0132 multi-series and periodic-spike checks: PASS')
