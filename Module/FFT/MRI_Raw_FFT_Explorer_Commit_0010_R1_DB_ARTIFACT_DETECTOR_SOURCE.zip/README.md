# MRI Raw & FFT Explorer — Commit 0008 Prototype

Windows desktop prototype based on the approved image-first workspace.

## Main prototype behavior

- Large main image viewer.
- FFT/k-space log-magnitude is the default display.
- One-click display buttons: **FFT**, **Original**, and **Both**.
- The selected button always indicates the current display state.
- Movable horizontal and vertical crosshair lines over the main image.
- Dragging either line updates the lower profile graph immediately.
- Row/Column profile selection with slider and numeric position control.
- Magnitude, Real, Imaginary, and Phase profile modes.
- Resizable upper/lower areas using a live Qt splitter.
- In Both mode, FFT and Original images are displayed side by side with synchronized line positions.
- Drop-only main import workflow. DICOM files, folders, ZIP, GE TrackerImg/PFile, CSV, TXT, NPY, and NPZ are supported by the prototype.
- Existing export operations remain under the File menu.
- DICOM header display, filtering, and Excel export.
- Tracker PFile candidate reconstruction and automatic registration of its complex raw stream in **1D Signal Studio**.
- Selected DICOM/k-space line can be sent directly to 1D Signal Studio.

## Important prototype limitations

- GE Tracker reconstruction uses heuristic matrix and complex-int16 detection. It is not a replacement for GE Orchestra reconstruction.
- Generic `.raw`, `.bin`, and Siemens `.dat` are detected, but the full interactive binary-layout dialog/vendor reconstruction workflow will be reintegrated after evaluation of this new layout.
- FFT shown for DICOM is pseudo-k-space generated from the reconstructed DICOM pixels.

## Run from Python

```text
01_RUN_PYTHON_DEBUG.bat
```

## Recommended local build

```text
02_BUILD_FAST_STANDALONE.bat
```

## GitHub Actions

Place the workflow at the repository root:

```text
.github/workflows/build_mri_raw_fft.yml
```

Run the workflow with `fast_pyinstaller`. The output is a standalone Windows ZIP artifact.


## Commit 0008 R1 — Simple GitHub Artifact

The workflow no longer creates `MRI_Raw_FFT_Explorer_Windows.zip` inside the
GitHub Artifact.

GitHub Actions now uploads the completed standalone folder contents directly.
When the Artifact is downloaded from GitHub, there is only one ZIP layer. After
opening or extracting it, `MRI_Raw_FFT_Explorer.exe`, `_internal`, README, and
BUILD_INFO are immediately available.

Expected download structure:

```text
MRI_Raw_FFT_Explorer_Windows-fast_pyinstaller.zip
├── MRI_Raw_FFT_Explorer.exe
├── _internal
├── README.md
├── BUILD_INFO.txt
└── vendor_sdk_config.json
```


## Commit 0008 R2 — Tab Navigation and Import Progress

- Image Workspace, 1D Signal Studio, and DICOM Header remain available as persistent top tabs.
- 1D Signal Studio includes a prominent Back to Image Workspace button.
- Selecting a Tracker signal in Explorer opens the 1D Signal Studio tab without replacing the main workspace.
- A modal progress window is shown while scanning folders, extracting ZIP files, detecting DICOM images, and loading Tracker/1D data.
- The progress window shows the current file and supports Cancel.
- ZIP extraction still validates paths before extraction.
- The single-layer GitHub Artifact packaging introduced in R1 is retained.


## Commit 0008 R3 — Spike Noise Detection

A `Spike` button is available in Image Workspace.

- Scans imported GE Tracker/PFile, extensionless TrackerImg, RAW, BIN, and DAT files.
- Uses robust median/MAD amplitude and first-difference scores.
- Threshold is adjustable in the Spike Detection tab.
- Lists score, spike-group count, strongest sample, and inspected sample count.
- Double-clicking a result opens the extracted raw signal in 1D Signal Studio.
- Detected spike positions are overlaid with red markers.
- Long generic binary files are analyzed from a bounded tail region to limit memory usage.

This is a screening function. Vendor-specific headers, channel layouts, and expected
sequence impulses can affect the score, so flagged files should be reviewed visually.


## Commit 0008 R4 — Tracker Signal Explorer

Tracker file inspection is separated from Spike Detection.

- Adds a dedicated `Tracker Signal Explorer` tab.
- Reads Tracker PFile / TrackerImg data without FFT.
- Automatically evaluates every raw line.
- Picks and ranks the strongest lines by Peak, RMS, Energy, Mean Magnitude, or Variance.
- Displays the top lines immediately.
- Supports Magnitude, Real, Imaginary, and Phase views.
- Allows up to eight selected lines to be overlaid.
- Includes Previous / Next Strong Line navigation.
- Exports line metrics to CSV.
- Keeps the existing Spike Detection tab as a separate diagnostic view.


## Versioned GitHub Artifact workflow fix

The Artifact name now includes the application version, release identifier, and build engine:

```text
MRI_Raw_FFT_Explorer_v0.8.3_Commit0008_R4_fast_pyinstaller.zip
```

The Artifact remains a single ZIP layer. `BUILD_INFO.txt` includes the application
name, version, release, Git SHA, engine, Python version, and UTC build time.


## Commit 0008 R5 — Image Editing and Display Controls

- Explorer selection follows Up/Down arrow keys and immediately updates the image.
- Image A/B registration with Add and Subtract processing.
- Processed Add/Subtract files include `_addsub` in the name.
- A movable rectangular compensation ROI interpolates the selected region from surrounding signals.
- Compensation files include `_comp` in the name.
- Processed files are stored under `MRI_Raw_FFT_Work` beside the source data.
- DICOM sources produce a derived DICOM plus an NPY working copy.
- Dynamic Range and Window Level are directly adjustable.
- Presets: Auto, Wide, Soft Tissue, High Contrast, and Narrow.
- Saved processed files appear under `Processed Files` in Explorer.


## Commit 0008 R6 — Tracker Position Conversion

Analysis of the attached TrackerApp identified the following position pipeline:

1. Zero-padded FFT of a selected tracker direction (`GE_FFTLength = 1024`).
2. Peak-bin conversion into millimeters using FOV.
3. Plane and in-plane rotation mapping.
4. Least-squares solution from at least three directional measurements.
5. CenterOffset addition.
6. Optional AP-coordinate sign inversion (`OpposeAPcoordinate = 1`).
7. Optional vendor gradient-map correction.

The new `Tracker Position` tab implements steps 1–6. It is separate from:

- `Tracker Signal Explorer`, which continues to display raw tracker lines without FFT.
- `Spike Detection`, which remains an independent diagnostic workflow.

Gradient-map correction is explicitly reported as not applied until compatible field
distribution files and their exact interpolation format are available.


## Commit 0009 R1 — Artifact Learning and Artifact DB

- DICOM Explorer is grouped by Series and supports expand/collapse.
- Multiple images can be selected for training.
- Artifact labels include Spike, Frequency, and expandable custom types.
- Images can be manually reclassified, including `Not Artifact`.
- How to Resolved supports dropdown values and manual additions.
- Normal images can be selected from the study or loaded separately.
- Artifact-vs-normal difference features are stored.
- SQLite is the working DB format.
- JSON import/export supports sharing and master updates.
- Spike Detection remains separate and can be used as a source for later labeling.


## Commit 0009 R2 — Compensation ROI Fix

- Automatically switches to Original image mode.
- Adds an explicit Preview Compensation step.
- Shows ROI coordinates and mean/max pixel change.
- Uses all four surrounding borders for interpolation.
- Shows the compensated result immediately.
- Apply & Save writes the `_comp` file and displays the exact save path.
- Cancel restores the original image.


## Commit 0010 R1 — DB-trained Artifact Detection and Strongest Tracker Line

### Artifact Detection

- Spike is classified from Artifact DB training samples instead of a fixed threshold.
- Frequency and all additional Artifact classes use the same trainable detector.
- Classes require a configurable minimum number of labeled samples.
- Results show predicted class, confidence, normalized distance, training support, and alternatives.
- Low-confidence and insufficient-training results are explicitly identified.
- Selected detection results can be sent to Artifact Learning for manual correction or reclassification.
- Spike Diagnostic remains separate for raw waveform inspection.

### Tracker Signal Explorer

- Automatically identifies exactly one strongest line using RMS signal strength.
- Displays that line's Magnitude by default.
- Reports the strongest line number, RMS, and peak.
- FFT remains disabled in Tracker Signal Explorer.

### Reusable GitHub workflow

- `.github/workflows/build_module_generic.yml` no longer contains a hard-coded version or commit.
- `version.json` controls application name, version, commit, EXE name, and Artifact name.
- Future releases only require a new SOURCE ZIP with an updated `version.json`.
- The same YML can be reused without modification.
- Artifact output remains a single ZIP layer.
