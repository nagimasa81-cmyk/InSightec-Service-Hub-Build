from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import numpy as np

from .hybrid_compensation import compensate, detect_artifacts, ifft2c


@dataclass(frozen=True)
class AutoCorrectResult:
    kspace: np.ndarray
    image: np.ndarray
    mask: np.ndarray
    metrics: dict[str, float]
    candidates: list[dict[str, Any]]
    selected_types: list[str]


def _gradient_energy(image: np.ndarray) -> float:
    a = np.asarray(image, dtype=float)
    gy = np.diff(a, axis=0, append=a[-1:, :])
    gx = np.diff(a, axis=1, append=a[:, -1:])
    return float(np.mean(np.hypot(gx, gy)))


def _quality(before_k: np.ndarray, result, mask: np.ndarray, protection: float) -> dict[str, float]:
    before_img = np.abs(ifft2c(before_k))
    after_img = np.asarray(result.image, dtype=float)
    eps = 1e-12
    roi_before = np.abs(before_k)[mask]
    roi_after = np.abs(result.kspace)[mask]
    artifact_reduction = float(np.clip(1.0 - np.mean(roi_after) / max(np.mean(roi_before), eps), -1.0, 1.0)) if np.any(mask) else 0.0
    image_delta = float(np.mean(np.abs(after_img - before_img)) / max(np.mean(np.abs(before_img)), eps))
    edge_before = _gradient_energy(before_img)
    edge_after = _gradient_energy(after_img)
    detail_preservation = float(np.clip(1.0 - abs(edge_after - edge_before) / max(edge_before, eps), 0.0, 1.0))
    outside_change = image_delta
    residual = float(np.clip(np.mean(roi_after) / max(np.mean(roi_before), eps), 0.0, 2.0)) if np.any(mask) else 1.0
    overall = 100.0 * (0.58 * max(artifact_reduction, 0.0) + 0.30 * detail_preservation + 0.12 * (1.0 - min(outside_change, 1.0)))
    overall -= 100.0 * float(protection) * max(0.0, outside_change - 0.035)
    mask_coverage = float(np.count_nonzero(mask)) / float(mask.size) if mask.size else 0.0
    edge_preservation = detail_preservation
    return {
        "artifact_reduction": 100.0 * artifact_reduction,
        "detail_preservation": 100.0 * detail_preservation,
        "edge_preservation": 100.0 * edge_preservation,
        "outside_image_change": 100.0 * outside_change,
        "residual_artifact": 100.0 * residual,
        "mask_coverage": 100.0 * mask_coverage,
        "overall_quality": float(overall),
    }




def _bright_blob_mask(kspace: np.ndarray, removal_f: float, protect_f: float) -> np.ndarray:
    """Multi-scale off-centre blob detector.

    Commit0113 increases recall for broad, soft-edged blobs by combining robust
    global thresholds with local-contrast seeds and conservative region growing.
    The DC centre and large smooth encoding structures remain protected.
    """
    mag = np.abs(np.asarray(kspace, dtype=np.complex128)).astype(float)
    h, w = mag.shape
    yy, xx = np.ogrid[:h, :w]
    cy, cx = (h - 1) / 2.0, (w - 1) / 2.0
    centre_r = max(4.0, min(h, w) * (0.030 + 0.045 * protect_f))
    valid = ((yy - cy) ** 2 + (xx - cx) ** 2) >= centre_r ** 2
    vals = mag[valid & np.isfinite(mag)]
    if vals.size < 32:
        return np.zeros_like(mag, dtype=bool)
    med = float(np.median(vals)); mad = float(np.median(np.abs(vals-med)))
    sigma = max(1.4826*mad, 1e-12)
    # Higher removal lowers the seed threshold; protection keeps it conservative.
    pct = float(np.clip(99.72 - 0.80*removal_f + 0.20*protect_f, 98.85, 99.80))
    global_thr = max(float(np.percentile(vals,pct)), med + (3.6 + 1.8*protect_f - 1.6*removal_f)*sigma)

    # Local background estimate at two scales; catches soft blobs whose absolute
    # amplitude is not among the very top FFT pixels.
    def box_blur(a, r):
        pad=np.pad(a,((r,r),(r,r)),mode='reflect')
        integ=np.pad(pad,((1,0),(1,0)),mode='constant').cumsum(0).cumsum(1)
        k=2*r+1
        return (integ[k:,k:]-integ[:-k,k:]-integ[k:,:-k]+integ[:-k,:-k])/(k*k)
    bg_small=box_blur(mag,2)
    bg_large=box_blur(mag,5)
    contrast=np.maximum(mag-bg_small, mag-bg_large)
    contrast_vals=contrast[valid]
    cmed=float(np.median(contrast_vals)); cmad=float(np.median(np.abs(contrast_vals-cmed)))
    csig=max(1.4826*cmad,1e-12)
    local_thr=cmed+(2.8+1.6*protect_f-1.4*removal_f)*csig
    seeds=valid & ((mag>=global_thr) | ((contrast>=local_thr) & (mag>=med+1.8*sigma)))

    # Region grow into adjacent pixels with at least 42–58% of seed threshold.
    grow_thr=max(med+1.25*sigma, global_thr*(0.42+0.16*protect_f))
    grown=seeds.copy()
    for _ in range(4 + int(round(3*removal_f))):
        neigh=np.zeros_like(grown,dtype=np.uint8)
        for dy in (-1,0,1):
            for dx in (-1,0,1):
                neigh += np.roll(np.roll(grown,dy,0),dx,1)
        nxt=valid & (mag>=grow_thr) & (neigh>=2)
        merged=grown|nxt
        if np.array_equal(merged,grown): break
        grown=merged

    # Component filtering: permit larger and less rectangular blobs than before,
    # but reject huge smooth structures and one-pixel noise.
    seen=np.zeros_like(grown,dtype=bool); out=np.zeros_like(grown,dtype=bool)
    min_area=max(3,int(round(min(h,w)*0.008)))
    max_area=max(min_area+1,int(round(grown.size*(0.010+0.055*removal_f))))
    for y in range(h):
        for x in range(w):
            if not grown[y,x] or seen[y,x]: continue
            stack=[(y,x)]; seen[y,x]=True; pts=[]
            while stack:
                py,px=stack.pop(); pts.append((py,px))
                for ny in range(max(0,py-1),min(h,py+2)):
                    for nx in range(max(0,px-1),min(w,px+2)):
                        if grown[ny,nx] and not seen[ny,nx]:
                            seen[ny,nx]=True; stack.append((ny,nx))
            area=len(pts)
            if not (min_area<=area<=max_area): continue
            ys=np.array([q[0] for q in pts]); xs=np.array([q[1] for q in pts])
            bh=int(ys.max()-ys.min()+1); bw=int(xs.max()-xs.min()+1)
            fill=area/max(1,bh*bw)
            mean_contrast=float(np.mean(contrast[ys,xs]))/csig
            if fill>=0.07 and mean_contrast >= (1.25+0.75*protect_f):
                out[ys,xs]=True
    return out

def auto_correct(
    kspace: np.ndarray,
    *,
    threshold_sigma: float = 3.0,
    sensitivity: str = "Conservative",
    removal: int = 50,
    detail: int = 70,
    protection: int = 80,
    target_ratio: float = 1.0,
) -> AutoCorrectResult:
    """Candidate-by-candidate virtual reconstruction and quality selection.

    Detection is intentionally broad, but candidates are accepted only when a
    trial reconstruction improves artifact energy without excessive image change.
    """
    source = np.asarray(kspace)
    if source.ndim != 2:
        raise ValueError("Auto Correct requires a 2-D k-space array.")
    removal_f = float(np.clip(removal / 100.0, 0.0, 1.0))
    detail_f = float(np.clip(detail / 100.0, 0.0, 1.0))
    protect_f = float(np.clip(protection / 100.0, 0.0, 1.0))
    level = "Low" if removal < 30 else "Mid" if removal < 58 else "High" if removal < 85 else "Extreme"
    structure_preservation = float(np.clip(0.35 + 0.60 * max(detail_f, protect_f), 0.35, 0.97))
    magnitude = np.abs(source).astype(float)
    finite = magnitude[np.isfinite(magnitude)]
    if finite.size:
        median = float(np.median(finite))
        mad = float(np.median(np.abs(finite - median)))
        robust_sigma = max(1.4826 * mad, 1e-12)
        tail_ratio = float(np.percentile(finite, 99.5) / max(median + robust_sigma, 1e-12))
    else:
        tail_ratio = 1.0
    adaptive_offset = float(np.clip(0.35 * np.log10(max(tail_ratio, 1.0)), 0.0, 1.0))
    threshold = float(threshold_sigma + 0.8 * protect_f - 0.55 * removal_f - adaptive_offset)

    trials: list[dict[str, Any]] = []
    accepted_masks: list[np.ndarray] = []
    accepted_types: list[str] = []
    current = source.copy()
    type_order = ("Spike", "Blob", "Block", "Diagonal", "Line", "Band", "Ring")
    minimum_gain = 18.0 + 16.0 * protect_f - 10.0 * removal_f

    for artifact_type in type_order:
        if artifact_type == "Blob":
            mask = _bright_blob_mask(source, removal_f, protect_f)
            confidence = float(np.clip(np.count_nonzero(mask) / max(mask.size * 0.002, 1.0), 0.0, 1.0))
            compensation_type = "Block"
        else:
            detection = detect_artifacts(source, artifact_type, threshold, sensitivity)
            mask = np.asarray(detection.mask, dtype=bool)
            confidence = detection.confidence
            compensation_type = artifact_type
        if not np.any(mask):
            continue
        coverage = float(np.count_nonzero(mask)) / float(mask.size)
        # Large line/band proposals are especially likely to be normal encoding signal.
        if artifact_type in {"Line", "Band", "Ring"} and coverage > (0.012 + 0.030 * removal_f):
            trials.append({"type": artifact_type, "accepted": False, "reason": "coverage_guard", "coverage": coverage, "quality_gain": -999.0, "mask": mask.copy()})
            continue
        try:
            trial = compensate(
                current, mask,
                artifact_type=compensation_type,
                level=level,
                threshold_sigma=threshold,
                target_ratio=target_ratio,
                adaptive_direction=True,
                frequency_aware=True,
                harmonic_poisson=True,
                multi_pass=True,
                hermitian_symmetry=True,
                mask_expansion=0 if protect_f >= 0.65 else 1,
                donor_halo=3 if protect_f >= 0.65 else 4,
                pass_count=1 if protect_f >= 0.75 else 2,
                strength_override=float(np.clip(0.35 + 0.55 * removal_f, 0.35, 0.90)),
                structure_preservation=structure_preservation,
                detection_sensitivity=sensitivity,
            )
            q = _quality(current, trial, mask, protect_f)
            gain = q["overall_quality"]
            accepted = bool(gain >= minimum_gain and q["artifact_reduction"] > 4.0 and q["outside_image_change"] <= (12.0 - 7.0 * protect_f))
            shape_bonus = 1.0 if artifact_type in {"Spike", "Blob", "Diagonal"} else 0.85
            candidate_score = float(np.clip(0.45 * gain + 35.0 * confidence + 20.0 * shape_bonus - 150.0 * coverage, -999.0, 100.0))
            record = {"type": artifact_type, "accepted": accepted, "coverage": coverage, "confidence": confidence, "quality_gain": gain, "candidate_score": candidate_score, "adaptive_threshold": threshold, "mask": mask.copy(), **q}
            if not accepted:
                reasons = []
                if gain < minimum_gain: reasons.append("quality_below_threshold")
                if q["artifact_reduction"] <= 4.0: reasons.append("artifact_reduction_too_small")
                if q["outside_image_change"] > (12.0 - 7.0 * protect_f): reasons.append("image_change_too_large")
                record["reason"] = ", ".join(reasons) or "validation_rejected"
            trials.append(record)
            if accepted:
                current = trial.kspace
                accepted_masks.append(mask)
                accepted_types.append(artifact_type)
        except Exception as exc:
            trials.append({"type": artifact_type, "accepted": False, "reason": str(exc), "coverage": coverage, "quality_gain": -999.0, "mask": mask.copy()})

    if accepted_masks:
        final_mask = np.logical_or.reduce(accepted_masks)
    else:
        final_mask = np.zeros(source.shape, dtype=bool)
    final_image = np.abs(ifft2c(current))
    if np.any(final_mask):
        class R: pass
        r = R(); r.kspace = current; r.image = final_image
        metrics = _quality(source, r, final_mask, protect_f)
    else:
        metrics = {"artifact_reduction": 0.0, "detail_preservation": 100.0, "outside_image_change": 0.0, "residual_artifact": 100.0, "overall_quality": 0.0}
    metrics["accepted_candidates"] = float(len(accepted_types))
    metrics["mask_pixels"] = float(np.count_nonzero(final_mask))
    return AutoCorrectResult(current, final_image, final_mask, metrics, trials, accepted_types)


def recalculate_with_mask(
    kspace: np.ndarray,
    mask: np.ndarray,
    *,
    artifact_type: str = "Auto",
    threshold_sigma: float = 3.0,
    sensitivity: str = "Conservative",
    removal: int = 50,
    detail: int = 75,
    protection: int = 85,
    target_ratio: float = 1.0,
) -> AutoCorrectResult:
    """Reconstruct exactly once from the current mask and Quick Adjust values.

    This path never performs candidate selection or Auto Retry.  The supplied
    mask remains authoritative and is returned unchanged.
    """
    source = np.asarray(kspace)
    active_mask = np.asarray(mask, dtype=bool)
    if source.ndim != 2:
        raise ValueError("Quick Adjust requires a 2-D k-space array.")
    if active_mask.shape != source.shape or not np.any(active_mask):
        raise ValueError("The current compensation mask is empty or has an invalid shape.")

    removal_f = float(np.clip(removal / 100.0, 0.0, 1.0))
    detail_f = float(np.clip(detail / 100.0, 0.0, 1.0))
    protect_f = float(np.clip(protection / 100.0, 0.0, 1.0))
    level = "Low" if removal < 30 else "Mid" if removal < 58 else "High" if removal < 85 else "Extreme"
    structure_preservation = float(np.clip(0.35 + 0.60 * max(detail_f, protect_f), 0.35, 0.97))
    threshold = float(threshold_sigma + 0.8 * protect_f - 0.55 * removal_f)

    result = compensate(
        source, active_mask, artifact_type=artifact_type, level=level,
        threshold_sigma=threshold, target_ratio=target_ratio,
        adaptive_direction=False, frequency_aware=True, harmonic_poisson=True,
        multi_pass=True, hermitian_symmetry=True,
        mask_expansion=0 if protect_f >= 0.65 else 1,
        donor_halo=3 if protect_f >= 0.65 else 4,
        pass_count=1 if protect_f >= 0.75 else 2,
        strength_override=float(np.clip(0.35 + 0.55 * removal_f, 0.35, 0.90)),
        structure_preservation=structure_preservation,
        detection_sensitivity=sensitivity,
    )
    metrics = _quality(source, result, active_mask, protect_f)
    metrics["accepted_candidates"] = 1.0
    metrics["mask_pixels"] = float(np.count_nonzero(active_mask))
    return AutoCorrectResult(
        result.kspace, np.asarray(result.image), active_mask.copy(), metrics,
        [{"type": "Current Mask", "accepted": True, "source": "quick_adjust_once"}],
        ["Current Mask"],
    )


AUTO_RETRY_TRIALS: tuple[dict[str, int], ...] = (
    {"removal": 50, "detail": 75, "protection": 85},
    {"removal": 60, "detail": 75, "protection": 75},
    {"removal": 70, "detail": 75, "protection": 65},
    {"removal": 80, "detail": 75, "protection": 55},
    {"removal": 90, "detail": 75, "protection": 45},
    {"removal": 100, "detail": 75, "protection": 35},
)


def _result_rank(result: AutoCorrectResult) -> tuple[float, float, float, float, float]:
    """Rank quality first, then safer image change/residual/detail tie breakers."""
    m = result.metrics
    return (
        float(m.get("overall_quality", 0.0)),
        -float(m.get("outside_image_change", 100.0)),
        -float(m.get("residual_artifact", 100.0)),
        float(m.get("detail_preservation", 0.0)),
        float(m.get("artifact_reduction", 0.0)),
    )


def auto_correct_with_retry(
    kspace: np.ndarray,
    *,
    threshold_sigma: float = 3.0,
    sensitivity: str = "Conservative",
    target_ratio: float = 1.0,
    quality_threshold: float = 60.0,
    progress_callback=None,
    cancel_callback=None,
) -> tuple[AutoCorrectResult, list[dict[str, Any]]]:
    """Run six Quick Adjust trials and return the best validated result.

    The underlying candidate detection, validation, virtual compensation, and
    quality engine remain unchanged. This function only orchestrates retries.
    """
    source = np.asarray(kspace)
    trial_log: list[dict[str, Any]] = []
    results: list[AutoCorrectResult] = []
    for index, settings in enumerate(AUTO_RETRY_TRIALS, start=1):
        if cancel_callback is not None and cancel_callback():
            break
        if progress_callback is not None:
            progress_callback(index, len(AUTO_RETRY_TRIALS), "searching", settings, None)
        result = auto_correct(
            source,
            threshold_sigma=threshold_sigma,
            sensitivity=sensitivity,
            removal=settings["removal"],
            detail=settings["detail"],
            protection=settings["protection"],
            target_ratio=target_ratio,
        )
        results.append(result)
        candidate_found = bool(result.selected_types and np.any(result.mask))
        quality = float(result.metrics.get("overall_quality", 0.0))
        reliable = bool(candidate_found and quality >= quality_threshold)
        record = {
            "trial": index,
            **settings,
            "candidate_found": candidate_found,
            "quality": quality,
            "reliable": reliable,
            "selected_types": list(result.selected_types),
        }
        trial_log.append(record)
        if progress_callback is not None:
            progress_callback(index, len(AUTO_RETRY_TRIALS), "evaluating", settings, record)
    if not results:
        empty = auto_correct(
            source, threshold_sigma=threshold_sigma, sensitivity=sensitivity,
            removal=50, detail=75, protection=85, target_ratio=target_ratio,
        )
        return empty, trial_log
    reliable_results = [r for r, log in zip(results, trial_log) if log["reliable"]]
    candidate_results = [r for r, log in zip(results, trial_log) if log["candidate_found"]]
    pool = reliable_results or candidate_results or results
    return max(pool, key=_result_rank), trial_log
