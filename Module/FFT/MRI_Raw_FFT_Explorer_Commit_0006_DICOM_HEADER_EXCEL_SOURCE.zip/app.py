from __future__ import annotations

import csv
import json
import math
import os
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QSplitter,
    QStatusBar,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
    QTextEdit,
)
import pydicom
from pydicom.errors import InvalidDicomError
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from vendor_adapters import backend_status, reconstruct, config_path


APP_NAME = "MRI Raw & FFT Explorer"
APP_VERSION = "0.6.0"


def safe_normalize(image: np.ndarray) -> np.ndarray:
    arr = np.asarray(image, dtype=np.float64)
    finite = np.isfinite(arr)
    if not np.any(finite):
        return np.zeros_like(arr)
    lo = np.nanmin(arr[finite])
    hi = np.nanmax(arr[finite])
    if hi <= lo:
        return np.zeros_like(arr)
    return (arr - lo) / (hi - lo)


def fft2_centered(image: np.ndarray) -> np.ndarray:
    return np.fft.fftshift(np.fft.fft2(np.fft.ifftshift(image)))


def ifft2_centered(kspace: np.ndarray) -> np.ndarray:
    return np.fft.fftshift(np.fft.ifft2(np.fft.ifftshift(kspace)))


def window_values(name: str, n: int) -> np.ndarray:
    if n <= 0:
        return np.array([], dtype=np.float64)
    key = name.lower()
    if key == "hann":
        return np.hanning(n)
    if key == "hamming":
        return np.hamming(n)
    if key == "blackman":
        return np.blackman(n)
    return np.ones(n, dtype=np.float64)




def image_correlation(reference: np.ndarray, candidate: np.ndarray) -> tuple[float, int]:
    """Return best normalized correlation across rotations/reflections."""
    from PySide6.QtGui import QImage
    ref = np.asarray(reference, dtype=np.float64)
    cand = np.asarray(candidate, dtype=np.float64)
    if ref.ndim == 3:
        ref = np.mean(ref[..., :3], axis=2)
    if cand.ndim == 3:
        cand = np.mean(cand[..., :3], axis=2)

    def norm(a):
        a = np.nan_to_num(a, nan=0.0, posinf=0.0, neginf=0.0)
        lo, hi = np.percentile(a, [1, 99])
        if hi <= lo:
            return np.zeros_like(a)
        a = np.clip(a, lo, hi)
        return (a - a.mean()) / (a.std() + 1e-12)

    # resize candidate to reference dimensions through QImage to avoid an extra dependency
    c = safe_normalize(cand)
    c8 = np.ascontiguousarray((c * 255).astype(np.uint8))
    qimg = QImage(c8.data, c8.shape[1], c8.shape[0], c8.strides[0], QImage.Format_Grayscale8)
    qimg = qimg.scaled(ref.shape[1], ref.shape[0], Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
    ptr = qimg.bits()
    resized = np.frombuffer(ptr, dtype=np.uint8, count=qimg.height() * qimg.bytesPerLine())
    resized = resized.reshape(qimg.height(), qimg.bytesPerLine())[:, :qimg.width()].astype(np.float64)

    variants = [
        resized,
        np.flipud(resized),
        np.fliplr(resized),
        np.flipud(np.fliplr(resized)),
        resized.T,
        np.flipud(resized.T),
        np.fliplr(resized.T),
        np.flipud(np.fliplr(resized.T)),
    ]
    nr = norm(ref)
    scores = [float(np.mean(nr * norm(v))) for v in variants]
    best = int(np.argmax(scores))
    return scores[best], best


def apply_orientation(image: np.ndarray, index: int) -> np.ndarray:
    variants = [
        image,
        np.flipud(image),
        np.fliplr(image),
        np.flipud(np.fliplr(image)),
        image.T,
        np.flipud(image.T),
        np.fliplr(image.T),
        np.flipud(np.fliplr(image.T)),
    ]
    return variants[index]


@dataclass
class TrackerCandidate:
    matrix: int
    offset: int
    endian: str
    reconstruction: str
    kspace: np.ndarray
    image: np.ndarray
    score: Optional[float] = None
    orientation: int = 0

@dataclass
class DicomSlice:
    path: Path
    dataset: pydicom.dataset.FileDataset
    image: np.ndarray
    sort_key: tuple


class Raw2DDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("2D Raw Import Settings")
        self.resize(430, 300)

        self.rows = QSpinBox()
        self.rows.setRange(1, 16384)
        self.rows.setValue(256)

        self.cols = QSpinBox()
        self.cols.setRange(1, 16384)
        self.cols.setValue(256)

        self.dtype = QComboBox()
        self.dtype.addItems(["float32", "float64", "int16", "int32", "complex64", "complex128"])

        self.layout = QComboBox()
        self.layout.addItems([
            "Direct values",
            "Interleaved real/imaginary",
            "Real values only",
        ])

        self.byte_order = QComboBox()
        self.byte_order.addItems(["Little endian", "Big endian"])

        self.offset = QSpinBox()
        self.offset.setRange(0, 1_000_000_000)
        self.offset.setValue(0)

        self.domain = QComboBox()
        self.domain.addItems(["k-space", "image space"])

        form = QFormLayout()
        form.addRow("Rows", self.rows)
        form.addRow("Columns", self.cols)
        form.addRow("Data type", self.dtype)
        form.addRow("Data layout", self.layout)
        form.addRow("Byte order", self.byte_order)
        form.addRow("Header offset (bytes)", self.offset)
        form.addRow("Input domain", self.domain)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(buttons)

    def values(self) -> dict:
        return {
            "rows": self.rows.value(),
            "cols": self.cols.value(),
            "dtype": self.dtype.currentText(),
            "layout": self.layout.currentText(),
            "byte_order": self.byte_order.currentText(),
            "offset": self.offset.value(),
            "domain": self.domain.currentText(),
        }


class Raw1DDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("1D Binary Import Settings")
        self.resize(430, 260)

        self.dtype = QComboBox()
        self.dtype.addItems(["float32", "float64", "int16", "int32", "complex64", "complex128"])

        self.layout = QComboBox()
        self.layout.addItems([
            "Direct values",
            "Interleaved real/imaginary",
            "Real values only",
        ])

        self.byte_order = QComboBox()
        self.byte_order.addItems(["Little endian", "Big endian"])

        self.offset = QSpinBox()
        self.offset.setRange(0, 1_000_000_000)
        self.offset.setValue(0)

        self.max_samples = QSpinBox()
        self.max_samples.setRange(0, 100_000_000)
        self.max_samples.setValue(0)
        self.max_samples.setSpecialValueText("All")

        form = QFormLayout()
        form.addRow("Data type", self.dtype)
        form.addRow("Data layout", self.layout)
        form.addRow("Byte order", self.byte_order)
        form.addRow("Header offset (bytes)", self.offset)
        form.addRow("Maximum samples", self.max_samples)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(buttons)

    def values(self) -> dict:
        return {
            "dtype": self.dtype.currentText(),
            "layout": self.layout.currentText(),
            "byte_order": self.byte_order.currentText(),
            "offset": self.offset.value(),
            "max_samples": self.max_samples.value(),
        }


class MRIExplorer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} {APP_VERSION}")
        self.resize(1500, 900)

        pg.setConfigOptions(imageAxisOrder="row-major", antialias=True)

        self.dicom_slices: list[DicomSlice] = []
        self.current_image: Optional[np.ndarray] = None
        self.current_kspace: Optional[np.ndarray] = None
        self.current_reconstruction: Optional[np.ndarray] = None
        self.signal_1d: Optional[np.ndarray] = None
        self.signal_path: Optional[Path] = None
        self.signal_series: list[dict] = []
        self.filtered_signal: Optional[np.ndarray] = None
        self._last_fft = None
        self.reference_image: Optional[np.ndarray] = None
        self.tracker_candidates: list[TrackerCandidate] = []
        self.current_tracker_path: Optional[Path] = None

        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)
        self.tabs.addTab(self._build_2d_tab(), "DICOM / 2D Raw")
        self.tabs.addTab(self._build_1d_tab(), "1D Signal Studio")
        self.tabs.addTab(self._build_metadata_tab(), "Metadata")
        self.tabs.addTab(self._build_vendor_sdk_tab(), "Plugin Manager / Vendor SDK")

        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage("Ready")

        self._build_menu()

    def _build_menu(self):
        file_menu = self.menuBar().addMenu("&File")

        open_dicom = QAction("Open DICOM File", self)
        open_dicom.triggered.connect(self.open_dicom_file)
        file_menu.addAction(open_dicom)

        open_series = QAction("Open DICOM Folder", self)
        open_series.triggered.connect(self.open_dicom_folder)
        file_menu.addAction(open_series)

        export_header = QAction("Export Current DICOM Header to Excel", self)
        export_header.triggered.connect(self.export_current_dicom_header_excel)
        file_menu.addAction(export_header)

        export_series_header = QAction("Export DICOM Series Headers to Excel", self)
        export_series_header.triggered.connect(self.export_dicom_series_headers_excel)
        file_menu.addAction(export_series_header)

        open_tracker = QAction("Open Tracker PFile", self)
        open_tracker.triggered.connect(self.open_tracker_pfile)
        file_menu.addAction(open_tracker)

        open_reference = QAction("Open Reference Image", self)
        open_reference.triggered.connect(self.open_reference_image)
        file_menu.addAction(open_reference)

        open_raw2d = QAction("Open 2D Raw", self)
        open_raw2d.triggered.connect(self.open_raw_2d)
        file_menu.addAction(open_raw2d)

        vendor_recon = QAction("Vendor SDK Reconstruction", self)
        vendor_recon.triggered.connect(lambda: self.tabs.setCurrentWidget(self.vendor_sdk_tab))
        file_menu.addAction(vendor_recon)

        file_menu.addSeparator()

        export_npz = QAction("Export 2D Data as NPZ", self)
        export_npz.triggered.connect(self.export_2d_npz)
        file_menu.addAction(export_npz)

        save_session = QAction("Save Session", self)
        save_session.triggered.connect(self.save_session)
        file_menu.addAction(save_session)

        load_session = QAction("Load Session", self)
        load_session.triggered.connect(self.load_session)
        file_menu.addAction(load_session)

        file_menu.addSeparator()

        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

    def _build_2d_tab(self) -> QWidget:
        widget = QWidget()
        outer = QVBoxLayout(widget)

        controls = QHBoxLayout()
        self.btn_dicom_file = QPushButton("Open DICOM File")
        self.btn_dicom_folder = QPushButton("Open DICOM Folder")
        self.btn_raw2d = QPushButton("Open 2D Raw")
        self.btn_tracker = QPushButton("Open Tracker PFile")
        self.btn_reference = QPushButton("Open Reference Image")
        self.btn_prev = QPushButton("Previous")
        self.btn_next = QPushButton("Next")
        self.btn_export = QPushButton("Export NPZ")
        self.btn_reset_levels = QPushButton("Auto Levels")

        self.btn_dicom_file.clicked.connect(self.open_dicom_file)
        self.btn_dicom_folder.clicked.connect(self.open_dicom_folder)
        self.btn_raw2d.clicked.connect(self.open_raw_2d)
        self.btn_tracker.clicked.connect(self.open_tracker_pfile)
        self.btn_reference.clicked.connect(self.open_reference_image)
        self.btn_prev.clicked.connect(lambda: self.change_slice(-1))
        self.btn_next.clicked.connect(lambda: self.change_slice(1))
        self.btn_export.clicked.connect(self.export_2d_npz)
        self.btn_reset_levels.clicked.connect(self.auto_levels)

        self.slice_label = QLabel("Slice: -")
        self.source_label = QLabel("No file loaded")
        self.source_label.setTextInteractionFlags(Qt.TextSelectableByMouse)

        for w in [
            self.btn_dicom_file, self.btn_dicom_folder, self.btn_raw2d, self.btn_tracker, self.btn_reference,
            self.btn_prev, self.btn_next, self.btn_export, self.btn_reset_levels,
            self.slice_label
        ]:
            controls.addWidget(w)
        controls.addStretch(1)

        outer.addLayout(controls)
        outer.addWidget(self.source_label)
        candidate_row = QHBoxLayout()
        candidate_row.addWidget(QLabel("Tracker candidate"))
        self.tracker_candidate_combo = QComboBox()
        self.tracker_candidate_combo.currentIndexChanged.connect(self.select_tracker_candidate)
        candidate_row.addWidget(self.tracker_candidate_combo, 1)
        self.tracker_diag = QLabel("No Tracker PFile loaded")
        self.tracker_diag.setTextInteractionFlags(Qt.TextSelectableByMouse)
        candidate_row.addWidget(self.tracker_diag, 2)
        outer.addLayout(candidate_row)

        splitter = QSplitter(Qt.Horizontal)

        left_box = QGroupBox("Image Space")
        left_layout = QVBoxLayout(left_box)
        self.image_view = pg.ImageView()
        self.image_view.ui.roiBtn.hide()
        self.image_view.ui.menuBtn.hide()
        left_layout.addWidget(self.image_view)

        self.image_mode = QComboBox()
        self.image_mode.addItems(["Original", "Reconstructed Magnitude", "Reconstructed Phase", "Difference"])
        self.image_mode.currentTextChanged.connect(self.refresh_2d_views)
        left_layout.addWidget(self.image_mode)

        right_box = QGroupBox("k-space")
        right_layout = QVBoxLayout(right_box)
        self.kspace_view = pg.ImageView()
        self.kspace_view.ui.roiBtn.hide()
        self.kspace_view.ui.menuBtn.hide()
        right_layout.addWidget(self.kspace_view)

        self.kspace_mode = QComboBox()
        self.kspace_mode.addItems(["Log Magnitude", "Magnitude", "Phase", "Real", "Imaginary"])
        self.kspace_mode.currentTextChanged.connect(self.refresh_2d_views)
        right_layout.addWidget(self.kspace_mode)

        splitter.addWidget(left_box)
        splitter.addWidget(right_box)
        splitter.setSizes([750, 750])

        outer.addWidget(splitter, 1)

        profile_box = QGroupBox("Center-line Profiles")
        profile_layout = QGridLayout(profile_box)
        self.image_profile = pg.PlotWidget()
        self.kspace_profile = pg.PlotWidget()
        self.image_profile.showGrid(x=True, y=True, alpha=0.2)
        self.kspace_profile.showGrid(x=True, y=True, alpha=0.2)
        profile_layout.addWidget(QLabel("Image center row"), 0, 0)
        profile_layout.addWidget(QLabel("k-space center row"), 0, 1)
        profile_layout.addWidget(self.image_profile, 1, 0)
        profile_layout.addWidget(self.kspace_profile, 1, 1)
        outer.addWidget(profile_box, 0)

        return widget

    def _build_1d_tab(self) -> QWidget:
        widget = QWidget()
        outer = QVBoxLayout(widget)

        controls = QHBoxLayout()
        self.btn_open_1d = QPushButton("Add 1D Data")
        self.btn_open_1d.clicked.connect(self.open_1d_data)
        self.btn_extract_image_line = QPushButton("Image Center Line")
        self.btn_extract_image_line.clicked.connect(lambda: self.extract_2d_line(False))
        self.btn_extract_kspace_line = QPushButton("k-space Center Line")
        self.btn_extract_kspace_line.clicked.connect(lambda: self.extract_2d_line(True))
        self.btn_clear_signals = QPushButton("Clear Signals")
        self.btn_clear_signals.clicked.connect(self.clear_signals)

        self.sample_rate = QDoubleSpinBox()
        self.sample_rate.setRange(1e-9, 1e12); self.sample_rate.setDecimals(6); self.sample_rate.setValue(1000.0); self.sample_rate.setSuffix(" Hz")
        self.fft_length = QSpinBox()
        self.fft_length.setRange(0, 100_000_000); self.fft_length.setValue(0); self.fft_length.setSpecialValueText("Auto")
        self.window_combo = QComboBox(); self.window_combo.addItems(["Rectangular", "Hann", "Hamming", "Blackman"])
        self.remove_dc = QCheckBox("Remove DC"); self.remove_dc.setChecked(True)
        self.spectrum_mode = QComboBox(); self.spectrum_mode.addItems(["Magnitude", "dB", "Power", "PSD", "Phase", "Real", "Imaginary"])
        self.btn_update_fft = QPushButton("Calculate FFT"); self.btn_update_fft.clicked.connect(self.update_fft)
        self.btn_export_fft = QPushButton("Export FFT CSV"); self.btn_export_fft.clicked.connect(self.export_fft_csv)
        for w in [self.btn_open_1d,self.btn_extract_image_line,self.btn_extract_kspace_line,self.btn_clear_signals,QLabel("Sample rate"),self.sample_rate,QLabel("FFT length"),self.fft_length,QLabel("Window"),self.window_combo,self.remove_dc,QLabel("Display"),self.spectrum_mode,self.btn_update_fft,self.btn_export_fft]: controls.addWidget(w)
        outer.addLayout(controls)

        filter_row = QHBoxLayout()
        self.roi_enable = QCheckBox("ROI FFT"); self.roi_enable.setChecked(False)
        self.filter_combo = QComboBox(); self.filter_combo.addItems(["None", "Low Pass", "High Pass", "Band Pass", "Band Stop", "Notch", "Gaussian"])
        self.filter_low = QDoubleSpinBox(); self.filter_low.setRange(-1e12,1e12); self.filter_low.setValue(50.0); self.filter_low.setSuffix(" Hz")
        self.filter_high = QDoubleSpinBox(); self.filter_high.setRange(-1e12,1e12); self.filter_high.setValue(200.0); self.filter_high.setSuffix(" Hz")
        self.btn_apply_filter = QPushButton("Apply Filter + IFFT"); self.btn_apply_filter.clicked.connect(self.apply_frequency_filter)
        self.btn_export_signal = QPushButton("Export Signal NPZ"); self.btn_export_signal.clicked.connect(self.export_signal_npz)
        for w in [self.roi_enable,QLabel("Filter"),self.filter_combo,QLabel("F1"),self.filter_low,QLabel("F2"),self.filter_high,self.btn_apply_filter,self.btn_export_signal]: filter_row.addWidget(w)
        filter_row.addStretch(1); outer.addLayout(filter_row)

        self.signal_info = QLabel("No 1D data loaded"); self.signal_info.setTextInteractionFlags(Qt.TextSelectableByMouse); outer.addWidget(self.signal_info)
        splitter = QSplitter(Qt.Vertical)
        time_box = QGroupBox("Time Domain / Filtered IFFT Preview"); time_layout = QVBoxLayout(time_box)
        self.time_plot = pg.PlotWidget(); self.time_plot.showGrid(x=True,y=True,alpha=0.2); self.time_plot.setLabel("bottom","Time",units="s")
        self.time_plot.addLegend(); self.time_roi = pg.LinearRegionItem(values=(0.0,0.1)); self.time_roi.setVisible(False); self.time_plot.addItem(self.time_roi)
        self.roi_enable.toggled.connect(self.time_roi.setVisible); time_layout.addWidget(self.time_plot)
        freq_box = QGroupBox("Frequency Domain"); freq_layout = QVBoxLayout(freq_box)
        self.freq_plot = pg.PlotWidget(); self.freq_plot.showGrid(x=True,y=True,alpha=0.2); self.freq_plot.setLabel("bottom","Frequency",units="Hz"); self.freq_plot.addLegend(); freq_layout.addWidget(self.freq_plot)
        splitter.addWidget(time_box); splitter.addWidget(freq_box); splitter.setSizes([350,350]); outer.addWidget(splitter,1)

        metrics=QGroupBox("FFT Metrics"); ml=QGridLayout(metrics)
        self.metric_peak_freq=QLabel("-"); self.metric_peak_value=QLabel("-"); self.metric_rms=QLabel("-"); self.metric_samples=QLabel("-"); self.metric_resolution=QLabel("-"); self.metric_noise=QLabel("-"); self.metric_snr=QLabel("-"); self.metric_bandwidth=QLabel("-")
        labels=[("Peak frequency",self.metric_peak_freq),("Peak value",self.metric_peak_value),("RMS",self.metric_rms),("Samples",self.metric_samples),("Resolution",self.metric_resolution),("Noise floor",self.metric_noise),("SNR",self.metric_snr),("-3 dB bandwidth",self.metric_bandwidth)]
        for i,(name,val) in enumerate(labels): ml.addWidget(QLabel(name),i//4,(i%4)*2); ml.addWidget(val,i//4,(i%4)*2+1)
        outer.addWidget(metrics)
        return widget

    def _build_vendor_sdk_tab(self) -> QWidget:
        self.vendor_sdk_tab = QWidget()
        outer = QVBoxLayout(self.vendor_sdk_tab)

        info = QLabel(
            "Official vendor SDK files are not bundled. This page calls an adapter executable installed and licensed separately. "
            "The adapter must write an NPZ result containing image and/or kspace. Siemens TWIX fallback is optional and not an official Siemens SDK reconstruction."
        )
        info.setWordWrap(True)
        outer.addWidget(info)

        controls = QHBoxLayout()
        self.vendor_backend_combo = QComboBox()
        self.vendor_backend_combo.addItems([
            "Auto (SDK then Generic Fallback)",
            "Generic FFT Reconstruction",
            "GE Orchestra SDK",
            "Siemens IDEA/ICE external recon",
            "Siemens TWIX Python fallback",
        ])
        self.vendor_input = QLineEdit()
        self.vendor_input.setPlaceholderText("Select GE P-file or Siemens .dat raw file")
        browse = QPushButton("Browse")
        browse.clicked.connect(self.browse_vendor_input)
        run = QPushButton("Run Reconstruction")
        run.clicked.connect(self.run_vendor_reconstruction)
        refresh = QPushButton("Refresh Status")
        refresh.clicked.connect(self.refresh_vendor_status)
        controls.addWidget(QLabel("Backend"))
        controls.addWidget(self.vendor_backend_combo)
        controls.addWidget(self.vendor_input, 1)
        controls.addWidget(browse)
        controls.addWidget(run)
        controls.addWidget(refresh)
        outer.addLayout(controls)

        self.vendor_status_table = QTableWidget(0, 4)
        self.vendor_status_table.setHorizontalHeaderLabels(["Backend", "Enabled", "Available", "Details"])
        self.vendor_status_table.horizontalHeader().setStretchLastSection(True)
        outer.addWidget(self.vendor_status_table)

        self.vendor_log = QTextEdit()
        self.vendor_log.setReadOnly(True)
        self.vendor_log.setPlaceholderText(f"Configuration: {config_path()}")
        outer.addWidget(self.vendor_log, 1)
        self.refresh_vendor_status()
        return self.vendor_sdk_tab

    def browse_vendor_input(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Open Vendor Raw Data", "", "MRI raw files (*.7 *.dat *.raw *.pfile *);;All files (*)"
        )
        if filename:
            self.vendor_input.setText(filename)

    def refresh_vendor_status(self):
        rows = [{"title":"Generic FFT Reconstruction","enabled":True,"available":True,"detail":"Built-in CPU engine; no vendor SDK required"}] + backend_status()
        self.vendor_status_table.setRowCount(len(rows))
        for r, item in enumerate(rows):
            values = [item["title"], "Yes" if item["enabled"] else "No", "Yes" if item["available"] else "No", item["detail"]]
            for c, value in enumerate(values):
                self.vendor_status_table.setItem(r, c, QTableWidgetItem(value))
        self.vendor_log.append(f"Configuration file: {config_path()}")

    def run_vendor_reconstruction(self):
        source = Path(self.vendor_input.text().strip())
        if not source.exists():
            QMessageBox.warning(self, "Input Required", "Select an existing vendor raw data file."); return
        backend = self.vendor_backend_combo.currentText()
        try:
            self.statusBar().showMessage(f"Running {backend}..."); QApplication.processEvents()
            result = None
            if backend == "Generic FFT Reconstruction":
                self.open_generic_vendor_file(source)
                return
            if backend == "Auto (SDK then Generic Fallback)":
                statuses = {x["title"]: x for x in backend_status()}
                candidates=[]
                if source.suffix.lower()==".dat": candidates=["Siemens IDEA/ICE external recon","Siemens TWIX Python fallback"]
                else: candidates=["GE Orchestra SDK"]
                last_error=None
                for item in candidates:
                    st=statuses.get(item,{})
                    if st.get("enabled") and st.get("available"):
                        try: result=reconstruct(item,source); backend=item; break
                        except Exception as exc: last_error=exc; self.vendor_log.append(f"{item} failed: {exc}")
                if result is None:
                    self.vendor_log.append(f"Official SDK unavailable; using Generic FFT fallback. {last_error or ''}")
                    self.open_generic_vendor_file(source); return
            else:
                result = reconstruct(backend, source)
            self.vendor_log.append(f"\n[{backend}]\nOutput: {result.output_path}\n{result.log}")
            self.load_adapter_result(result, source, backend)
        except Exception as exc:
            self.vendor_log.append(f"ERROR: {exc}"); QMessageBox.critical(self,"Reconstruction Error",str(exc)); self.statusBar().showMessage("Reconstruction failed")

    def open_generic_vendor_file(self, source: Path):
        if source.suffix.lower() in {".npy",".npz"}:
            if source.suffix.lower()==".npy": arr=np.load(source,allow_pickle=False)
            else:
                d=np.load(source,allow_pickle=False); key="kspace" if "kspace" in d else list(d.keys())[0]; arr=d[key]
            while np.asarray(arr).ndim>2: arr=np.asarray(arr)[0]
            self._set_2d_array(np.asarray(arr),"k-space",source)
        else:
            raw=source.read_bytes()
            candidates=self._build_tracker_candidates(raw)
            if not candidates: raise RuntimeError("Generic fallback could not infer a 2D complex matrix. Use Open 2D Raw for manual settings.")
            self.tracker_candidates=candidates; self.current_tracker_path=source; self._rank_tracker_candidates()
        self.vendor_log.append("Generic FFT reconstruction completed without a vendor SDK."); self.tabs.setCurrentIndex(0)

    def load_adapter_result(self, result, source: Path, backend: str):
        if result.kspace is not None:
            arr=np.asarray(result.kspace)
            while arr.ndim>2: arr=arr[0]
            self.current_kspace=arr.astype(np.complex128); self.current_reconstruction=ifft2_centered(self.current_kspace); self.current_image=np.abs(result.image) if result.image is not None else np.abs(self.current_reconstruction)
        elif result.image is not None:
            arr=np.asarray(result.image)
            while arr.ndim>2: arr=arr[0]
            self.current_image=np.abs(arr); self.current_kspace=fft2_centered(arr); self.current_reconstruction=ifft2_centered(self.current_kspace)
        else: raise RuntimeError("Adapter returned neither image nor k-space data.")
        self.source_label.setText(f"{source} | {backend}"); self.refresh_2d_views(); self.tabs.setCurrentIndex(0); self.statusBar().showMessage(f"Reconstruction completed with {backend}")

    def _build_metadata_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout(widget)

        controls = QHBoxLayout()
        self.metadata_filter = QLineEdit()
        self.metadata_filter.setPlaceholderText("Filter by tag, keyword, name, VR, or value")
        self.metadata_filter.textChanged.connect(self._filter_metadata_table)
        self.btn_export_current_header = QPushButton("Export Current Header to Excel")
        self.btn_export_series_headers = QPushButton("Export Series Headers to Excel")
        self.btn_export_current_header.clicked.connect(self.export_current_dicom_header_excel)
        self.btn_export_series_headers.clicked.connect(self.export_dicom_series_headers_excel)
        controls.addWidget(QLabel("Search"))
        controls.addWidget(self.metadata_filter, 1)
        controls.addWidget(self.btn_export_current_header)
        controls.addWidget(self.btn_export_series_headers)
        layout.addLayout(controls)

        self.metadata_table = QTableWidget(0, 7)
        self.metadata_table.setHorizontalHeaderLabels([
            "Tag", "Keyword", "Name", "VR", "VM", "Private", "Value"
        ])
        self.metadata_table.setSortingEnabled(True)
        self.metadata_table.setAlternatingRowColors(True)
        self.metadata_table.horizontalHeader().setStretchLastSection(True)
        self.metadata_table.verticalHeader().setVisible(False)
        layout.addWidget(self.metadata_table)
        return widget

    def _filter_metadata_table(self, text: str):
        if not hasattr(self, "metadata_table"):
            return
        query = text.strip().lower()
        for row in range(self.metadata_table.rowCount()):
            visible = not query
            if query:
                for col in range(self.metadata_table.columnCount()):
                    item = self.metadata_table.item(row, col)
                    if item and query in item.text().lower():
                        visible = True
                        break
            self.metadata_table.setRowHidden(row, not visible)

    @staticmethod
    def _dicom_element_rows(ds):
        rows = []
        for element in ds.iterall():
            if element.tag.group == 0x7FE0:
                continue
            try:
                value = str(element.value)
            except Exception:
                value = "<unreadable>"
            rows.append({
                "tag": str(element.tag),
                "keyword": getattr(element, "keyword", "") or "",
                "name": getattr(element, "name", "") or "",
                "vr": getattr(element, "VR", "") or "",
                "vm": str(getattr(element, "VM", "") or ""),
                "private": "Yes" if element.tag.is_private else "No",
                "value": value,
            })
        return rows

    def _fill_metadata(self, ds):
        rows = self._dicom_element_rows(ds)
        self.metadata_table.setSortingEnabled(False)
        self.metadata_table.setRowCount(len(rows))
        keys = ["tag", "keyword", "name", "vr", "vm", "private", "value"]
        for r, row in enumerate(rows):
            for c, key in enumerate(keys):
                item = QTableWidgetItem(str(row[key]))
                item.setToolTip(str(row[key]))
                self.metadata_table.setItem(r, c, item)
        self.metadata_table.setSortingEnabled(True)
        self.metadata_table.resizeColumnsToContents()
        self.metadata_table.setColumnWidth(2, min(self.metadata_table.columnWidth(2), 300))
        self.metadata_table.setColumnWidth(6, min(max(self.metadata_table.columnWidth(6), 400), 700))
        self._filter_metadata_table(self.metadata_filter.text() if hasattr(self, "metadata_filter") else "")

    @staticmethod
    def _style_excel_sheet(ws, freeze="A2"):
        ws.freeze_panes = freeze
        ws.auto_filter.ref = ws.dimensions
        header_fill = PatternFill("solid", fgColor="D9EAF7")
        for cell in ws[1]:
            cell.font = Font(bold=True)
            cell.fill = header_fill
            cell.alignment = Alignment(vertical="top")
        widths = {}
        for row in ws.iter_rows():
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
                text = "" if cell.value is None else str(cell.value)
                widths[cell.column] = min(max(widths.get(cell.column, 0), len(text) + 2), 80)
        for col_idx, width in widths.items():
            ws.column_dimensions[get_column_letter(col_idx)].width = width

    def export_current_dicom_header_excel(self):
        if not self.dicom_slices:
            QMessageBox.information(self, "No DICOM", "Open a DICOM file or folder first.")
            return
        index = int(self.slice_label.property("slice_index") or 0)
        index = max(0, min(index, len(self.dicom_slices) - 1))
        item = self.dicom_slices[index]
        default_name = f"{item.path.stem}_DICOM_Header.xlsx"
        filename, _ = QFileDialog.getSaveFileName(self, "Export Current DICOM Header", default_name, "Excel Workbook (*.xlsx)")
        if not filename:
            return
        if not filename.lower().endswith(".xlsx"):
            filename += ".xlsx"
        try:
            wb = Workbook()
            ws = wb.active
            ws.title = "DICOM Header"
            ws.append(["Source File", str(item.path)])
            ws.append([])
            ws.append(["Tag", "Keyword", "Name", "VR", "VM", "Private", "Value"])
            for row in self._dicom_element_rows(item.dataset):
                ws.append([row["tag"], row["keyword"], row["name"], row["vr"], row["vm"], row["private"], row["value"]])
            # style actual header row 3
            header_fill = PatternFill("solid", fgColor="D9EAF7")
            for cell in ws[3]:
                cell.font = Font(bold=True); cell.fill = header_fill
            ws.freeze_panes = "A4"
            ws.auto_filter.ref = f"A3:G{ws.max_row}"
            for col, width in {"A":16,"B":28,"C":38,"D":10,"E":10,"F":10,"G":80}.items():
                ws.column_dimensions[col].width = width
            for row in ws.iter_rows(min_row=1):
                for cell in row:
                    cell.alignment = Alignment(vertical="top", wrap_text=True)
            wb.save(filename)
            self.statusBar().showMessage(f"DICOM header exported: {filename}")
        except Exception as exc:
            QMessageBox.critical(self, "Excel Export Error", str(exc))

    def export_dicom_series_headers_excel(self):
        if not self.dicom_slices:
            QMessageBox.information(self, "No DICOM", "Open a DICOM file or folder first.")
            return
        filename, _ = QFileDialog.getSaveFileName(self, "Export DICOM Series Headers", "DICOM_Series_Headers.xlsx", "Excel Workbook (*.xlsx)")
        if not filename:
            return
        if not filename.lower().endswith(".xlsx"):
            filename += ".xlsx"
        try:
            wb = Workbook()
            summary = wb.active
            summary.title = "Series Summary"
            summary.append(["Index", "File", "Patient ID", "Study Date", "Series Description", "Instance Number", "Rows", "Columns", "Slice Location"])
            headers = wb.create_sheet("All Header Elements")
            headers.append(["File Index", "File", "Tag", "Keyword", "Name", "VR", "VM", "Private", "Value"])
            for idx, item in enumerate(self.dicom_slices, start=1):
                ds = item.dataset
                summary.append([
                    idx, str(item.path), str(getattr(ds, "PatientID", "")), str(getattr(ds, "StudyDate", "")),
                    str(getattr(ds, "SeriesDescription", "")), str(getattr(ds, "InstanceNumber", "")),
                    str(getattr(ds, "Rows", "")), str(getattr(ds, "Columns", "")), str(getattr(ds, "SliceLocation", "")),
                ])
                for row in self._dicom_element_rows(ds):
                    headers.append([idx, str(item.path), row["tag"], row["keyword"], row["name"], row["vr"], row["vm"], row["private"], row["value"]])
                if idx % 20 == 0:
                    self.statusBar().showMessage(f"Preparing Excel: {idx}/{len(self.dicom_slices)} files")
                    QApplication.processEvents()
            self._style_excel_sheet(summary)
            self._style_excel_sheet(headers)
            wb.save(filename)
            self.statusBar().showMessage(f"DICOM series headers exported: {filename}")
        except Exception as exc:
            QMessageBox.critical(self, "Excel Export Error", str(exc))

    def open_dicom_file(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Open DICOM File", "", "DICOM files (*.dcm *.ima *);;All files (*)"
        )
        if not filename:
            return
        try:
            item = self._read_dicom(Path(filename))
            self.dicom_slices = [item]
            self._show_dicom_index(0)
        except Exception as exc:
            QMessageBox.critical(self, "DICOM Error", str(exc))

    def open_dicom_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Open DICOM Folder")
        if not folder:
            return

        self.statusBar().showMessage("Scanning DICOM folder...")
        QApplication.processEvents()

        items: list[DicomSlice] = []
        failures = 0
        for path in sorted(Path(folder).rglob("*")):
            if not path.is_file():
                continue
            try:
                items.append(self._read_dicom(path))
            except Exception:
                failures += 1

        if not items:
            QMessageBox.warning(self, "No DICOM", "No readable DICOM image was found.")
            self.statusBar().showMessage("Ready")
            return

        items.sort(key=lambda x: x.sort_key)
        self.dicom_slices = items
        self._show_dicom_index(0)
        self.statusBar().showMessage(f"Loaded {len(items)} DICOM slices; skipped {failures} files")

    def _read_dicom(self, path: Path) -> DicomSlice:
        try:
            ds = pydicom.dcmread(str(path), force=False)
        except InvalidDicomError:
            ds = pydicom.dcmread(str(path), force=True)

        if not hasattr(ds, "PixelData"):
            raise ValueError(f"No Pixel Data: {path.name}")

        image = ds.pixel_array.astype(np.float64)

        if image.ndim == 3:
            image = image[0]
        if image.ndim != 2:
            raise ValueError(f"Unsupported DICOM pixel shape: {image.shape}")

        slope = float(getattr(ds, "RescaleSlope", 1.0))
        intercept = float(getattr(ds, "RescaleIntercept", 0.0))
        image = image * slope + intercept

        instance = int(getattr(ds, "InstanceNumber", 0) or 0)
        position = getattr(ds, "ImagePositionPatient", None)
        pos_key = float(position[2]) if position is not None and len(position) >= 3 else float(instance)
        return DicomSlice(path, ds, image, (pos_key, instance, path.name.lower()))

    def _show_dicom_index(self, index: int):
        if not self.dicom_slices:
            return
        index = max(0, min(index, len(self.dicom_slices) - 1))
        item = self.dicom_slices[index]
        self.current_image = item.image
        self.current_kspace = fft2_centered(self.current_image)
        self.current_reconstruction = ifft2_centered(self.current_kspace)
        self.slice_label.setText(f"Slice: {index + 1}/{len(self.dicom_slices)}")
        self.slice_label.setProperty("slice_index", index)
        self.source_label.setText(str(item.path))
        self._fill_metadata(item.dataset)
        self.refresh_2d_views()
        self.statusBar().showMessage(f"Loaded {item.path.name}")

    def change_slice(self, delta: int):
        if not self.dicom_slices:
            return
        current = int(self.slice_label.property("slice_index") or 0)
        self._show_dicom_index(current + delta)


    def open_reference_image(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Open Reference Image", "", "Images (*.png *.jpg *.jpeg *.bmp *.tif *.tiff);;All files (*)"
        )
        if not filename:
            return
        from PySide6.QtGui import QImage
        qimg = QImage(filename)
        if qimg.isNull():
            QMessageBox.critical(self, "Reference Error", "The reference image could not be opened.")
            return
        qimg = qimg.convertToFormat(QImage.Format_Grayscale8)
        ptr = qimg.bits()
        arr = np.frombuffer(ptr, dtype=np.uint8, count=qimg.height() * qimg.bytesPerLine())
        self.reference_image = arr.reshape(qimg.height(), qimg.bytesPerLine())[:, :qimg.width()].copy()
        self.statusBar().showMessage(f"Reference image loaded: {Path(filename).name}")
        if self.current_tracker_path:
            self._rank_tracker_candidates()

    def open_tracker_pfile(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Open Tracker PFile", "", "Tracker/PFile files (*);;All files (*)"
        )
        if not filename:
            return
        try:
            self.current_tracker_path = Path(filename)
            raw = self.current_tracker_path.read_bytes()
            if len(raw) < 4096:
                raise ValueError("File is too small to contain a supported Tracker PFile.")
            revision = float(np.frombuffer(raw[:4], dtype="<f4", count=1)[0])
            self.tracker_candidates = self._build_tracker_candidates(raw)
            if not self.tracker_candidates:
                raise ValueError("No viable end-aligned complex int16 matrix candidates were found.")
            self._rank_tracker_candidates(revision=revision)
            self.source_label.setText(str(self.current_tracker_path))
        except Exception as exc:
            QMessageBox.critical(self, "Tracker PFile Error", str(exc))

    def _build_tracker_candidates(self, raw: bytes) -> list[TrackerCandidate]:
        candidates: list[TrackerCandidate] = []
        for matrix in (64, 96, 128, 160, 192, 224, 256):
            required = matrix * matrix * 4
            offset = len(raw) - required
            if offset < 0:
                continue
            for endian in ("little", "big"):
                dtype = "<i2" if endian == "little" else ">i2"
                values = np.frombuffer(raw, dtype=dtype, count=matrix * matrix * 2, offset=offset)
                if values.size != matrix * matrix * 2:
                    continue
                pair = values.astype(np.float64).reshape(matrix, matrix, 2)
                complex_data = pair[..., 0] + 1j * pair[..., 1]
                if np.std(np.abs(complex_data)) <= 0:
                    continue
                reconstructions = {
                    "Centered IFFT": np.abs(ifft2_centered(complex_data)),
                    "Unshifted IFFT": np.abs(np.fft.ifft2(complex_data)),
                    "Centered FFT": np.abs(fft2_centered(complex_data)),
                    "Stored magnitude": np.abs(complex_data),
                }
                for name, image in reconstructions.items():
                    candidates.append(TrackerCandidate(matrix, offset, endian, name, complex_data, image))
        return candidates

    def _rank_tracker_candidates(self, revision: Optional[float] = None):
        if not self.tracker_candidates:
            return
        if self.reference_image is not None:
            for candidate in self.tracker_candidates:
                score, orientation = image_correlation(self.reference_image, candidate.image)
                candidate.score = score
                candidate.orientation = orientation
            self.tracker_candidates.sort(key=lambda c: c.score if c.score is not None else -999, reverse=True)
        else:
            # Conservative sample-specific preference followed by a general central-energy heuristic.
            def heuristic(c: TrackerCandidate):
                img = np.asarray(c.image, dtype=float)
                h, w = img.shape
                center = img[h//4:3*h//4, w//4:3*w//4]
                central_ratio = float(np.mean(center) / (np.mean(img) + 1e-12))
                preferred = 1.0 if (c.matrix == 128 and c.endian == "little" and c.reconstruction == "Stored magnitude") else 0.0
                return preferred * 1000.0 + central_ratio
            self.tracker_candidates.sort(key=heuristic, reverse=True)

        self.tracker_candidate_combo.blockSignals(True)
        self.tracker_candidate_combo.clear()
        for c in self.tracker_candidates:
            score = f" | match {c.score:.4f}" if c.score is not None else ""
            self.tracker_candidate_combo.addItem(
                f"{c.matrix}x{c.matrix} | offset {c.offset} | {c.endian} | {c.reconstruction}{score}"
            )
        self.tracker_candidate_combo.blockSignals(False)
        rev_text = f"Revision {revision:.3f}" if revision is not None and np.isfinite(revision) else "Revision unknown"
        self.tracker_diag.setText(f"{rev_text} | file size {self.current_tracker_path.stat().st_size:,} bytes | {len(self.tracker_candidates)} candidates")
        self.select_tracker_candidate(0)

    def select_tracker_candidate(self, index: int):
        if index < 0 or index >= len(self.tracker_candidates):
            return
        c = self.tracker_candidates[index]
        image = apply_orientation(c.image, c.orientation)
        kspace = c.kspace
        if c.orientation >= 4:
            kspace = kspace.T
        # Orientation is applied to the reconstructed image for visual comparison.
        self.dicom_slices = []
        self.current_image = image
        self.current_kspace = kspace
        self.current_reconstruction = image.astype(np.complex128)
        self.slice_label.setText("Slice: 1/1")
        self.slice_label.setProperty("slice_index", 0)
        self.metadata_table.setRowCount(7)
        metadata = [
            ("Tracker", "Matrix", f"{c.matrix} x {c.matrix}"),
            ("Tracker", "Data offset", str(c.offset)),
            ("Tracker", "Scalar type", "signed int16"),
            ("Tracker", "Complex layout", "interleaved real/imaginary"),
            ("Tracker", "Endian", c.endian),
            ("Tracker", "Reconstruction", c.reconstruction),
            ("Tracker", "Reference match", "-" if c.score is None else f"{c.score:.6f}"),
        ]
        for r, row in enumerate(metadata):
            for col, value in enumerate(row):
                self.metadata_table.setItem(r, col, QTableWidgetItem(value))
        self.refresh_2d_views()
        self.statusBar().showMessage(self.tracker_candidate_combo.currentText())

    def open_raw_2d(self):
        filename, _ = QFileDialog.getOpenFileName(
            self,
            "Open 2D Raw",
            "",
            "Raw/NumPy files (*.raw *.bin *.dat *.npy *.npz);;All files (*)",
        )
        if not filename:
            return

        path = Path(filename)
        try:
            if path.suffix.lower() == ".npy":
                arr = np.load(path, allow_pickle=False)
                self._set_2d_array(arr, "k-space", path)
                return
            if path.suffix.lower() == ".npz":
                data = np.load(path, allow_pickle=False)
                if "kspace" in data:
                    self._set_2d_array(data["kspace"], "k-space", path)
                elif "image" in data:
                    self._set_2d_array(data["image"], "image space", path)
                else:
                    key = list(data.keys())[0]
                    self._set_2d_array(data[key], "k-space", path)
                return

            dialog = Raw2DDialog(self)
            if dialog.exec() != QDialog.Accepted:
                return
            cfg = dialog.values()
            dtype = np.dtype(cfg["dtype"])
            dtype = dtype.newbyteorder("<" if cfg["byte_order"] == "Little endian" else ">")

            with open(path, "rb") as f:
                f.seek(cfg["offset"])
                raw = np.fromfile(f, dtype=dtype)

            expected = cfg["rows"] * cfg["cols"]
            if cfg["layout"] == "Interleaved real/imaginary":
                if raw.size < expected * 2:
                    raise ValueError(f"Expected at least {expected * 2} scalar values, found {raw.size}.")
                raw = raw[: expected * 2]
                arr = raw[0::2].astype(np.float64) + 1j * raw[1::2].astype(np.float64)
            else:
                if raw.size < expected:
                    raise ValueError(f"Expected at least {expected} values, found {raw.size}.")
                arr = raw[:expected]
                if cfg["layout"] == "Real values only":
                    arr = arr.astype(np.float64)

            arr = arr.reshape(cfg["rows"], cfg["cols"])
            self._set_2d_array(arr, cfg["domain"], path)
        except Exception as exc:
            QMessageBox.critical(self, "Raw Import Error", str(exc))

    def _set_2d_array(self, arr: np.ndarray, domain: str, path: Path):
        arr = np.asarray(arr)
        if arr.ndim != 2:
            raise ValueError(f"2D data required. Loaded shape: {arr.shape}")

        self.dicom_slices = []
        self.slice_label.setText("Slice: 1/1")
        self.slice_label.setProperty("slice_index", 0)
        self.source_label.setText(str(path))
        self.metadata_table.setRowCount(0)

        if domain == "image space":
            self.current_image = np.abs(arr) if np.iscomplexobj(arr) else arr.astype(np.float64)
            self.current_kspace = fft2_centered(arr)
            self.current_reconstruction = ifft2_centered(self.current_kspace)
        else:
            self.current_kspace = arr.astype(np.complex128)
            self.current_reconstruction = ifft2_centered(self.current_kspace)
            self.current_image = np.abs(self.current_reconstruction)

        self.refresh_2d_views()
        self.statusBar().showMessage(f"Loaded 2D raw: {path.name}")

    def refresh_2d_views(self):
        if self.current_image is None or self.current_kspace is None:
            return

        image_mode = self.image_mode.currentText()
        if image_mode == "Original":
            image_display = np.abs(self.current_image)
        elif image_mode == "Reconstructed Magnitude":
            image_display = np.abs(self.current_reconstruction)
        elif image_mode == "Reconstructed Phase":
            image_display = np.angle(self.current_reconstruction)
        else:
            image_display = np.abs(self.current_image) - np.abs(self.current_reconstruction)

        ks_mode = self.kspace_mode.currentText()
        if ks_mode == "Log Magnitude":
            k_display = np.log1p(np.abs(self.current_kspace))
        elif ks_mode == "Magnitude":
            k_display = np.abs(self.current_kspace)
        elif ks_mode == "Phase":
            k_display = np.angle(self.current_kspace)
        elif ks_mode == "Real":
            k_display = np.real(self.current_kspace)
        else:
            k_display = np.imag(self.current_kspace)

        self.image_view.setImage(np.asarray(image_display), autoLevels=True)
        self.kspace_view.setImage(np.asarray(k_display), autoLevels=True)

        center_i = image_display.shape[0] // 2
        center_k = k_display.shape[0] // 2

        self.image_profile.clear()
        self.image_profile.plot(np.asarray(image_display[center_i], dtype=np.float64))

        self.kspace_profile.clear()
        self.kspace_profile.plot(np.asarray(k_display[center_k], dtype=np.float64))

    def auto_levels(self):
        self.image_view.autoLevels()
        self.kspace_view.autoLevels()

    def export_2d_npz(self):
        if self.current_image is None or self.current_kspace is None:
            QMessageBox.information(self, "No Data", "Load DICOM or 2D raw data first.")
            return

        filename, _ = QFileDialog.getSaveFileName(
            self, "Export 2D NPZ", "mri_2d_data.npz", "NumPy archive (*.npz)"
        )
        if not filename:
            return
        if not filename.lower().endswith(".npz"):
            filename += ".npz"

        np.savez_compressed(
            filename,
            image=np.asarray(self.current_image),
            kspace=np.asarray(self.current_kspace),
            reconstruction=np.asarray(self.current_reconstruction),
            fft_shifted=np.array(True),
            source=np.array(self.source_label.text()),
            version=np.array(APP_VERSION),
        )
        self.statusBar().showMessage(f"Exported {filename}")

    def open_1d_data(self):
        filename,_=QFileDialog.getOpenFileName(self,"Open 1D Data","","Supported files (*.csv *.txt *.raw *.bin *.dat *.npy *.npz);;All files (*)")
        if not filename:return
        path=Path(filename)
        try:
            suffix=path.suffix.lower()
            if suffix==".npy": signal=np.load(path,allow_pickle=False)
            elif suffix==".npz":
                data=np.load(path,allow_pickle=False); key=next((k for k in ["signal","data","raw","samples"] if k in data),list(data.keys())[0]); signal=data[key]
            elif suffix in {".csv",".txt"}: signal=self._read_text_signal(path)
            else:
                dialog=Raw1DDialog(self)
                if dialog.exec()!=QDialog.Accepted:return
                signal=self._read_binary_signal(path,dialog.values())
            self.add_signal(np.asarray(signal).squeeze(),path.name,path)
        except Exception as exc: QMessageBox.critical(self,"1D Import Error",str(exc))

    def add_signal(self, signal, name, path=None):
        signal=np.asarray(signal).squeeze()
        if signal.ndim!=1 or signal.size<2: raise ValueError(f"1D data with at least two samples required. Shape: {signal.shape}")
        if len(self.signal_series)>=8: raise ValueError("A maximum of 8 signals can be displayed.")
        signal=signal.astype(np.complex128 if np.iscomplexobj(signal) else np.float64)
        self.signal_series.append({"name":name,"data":signal,"path":str(path or "")})
        self.signal_1d=signal; self.signal_path=Path(path) if path else None
        self.signal_info.setText(f"Signals: {len(self.signal_series)} | Active: {name} | Samples: {signal.size}")
        self.update_fft()

    def clear_signals(self):
        self.signal_series=[]; self.signal_1d=None; self.filtered_signal=None; self.time_plot.clear(); self.freq_plot.clear(); self.signal_info.setText("No 1D data loaded")

    def extract_2d_line(self, kspace=False):
        arr=self.current_kspace if kspace else self.current_image
        if arr is None: QMessageBox.information(self,"No 2D Data","Load DICOM or raw 2D data first."); return
        a=np.asarray(arr); line=a[a.shape[0]//2,:]; self.add_signal(line,("k-space" if kspace else "Image")+" center row")

    def _read_text_signal(self,path:Path)->np.ndarray:
        rows=[]
        with open(path,"r",encoding="utf-8-sig",errors="replace") as f:
            for line in f:
                parts=[p.strip() for p in line.strip().replace(";",",").split(",")]; nums=[]
                for part in parts:
                    try: nums.append(float(part))
                    except ValueError: pass
                if nums: rows.append(nums)
        if not rows: raise ValueError("No numeric data found.")
        if all(len(r)>=2 for r in rows): return np.array([r[0]+1j*r[1] for r in rows])
        return np.array([r[0] for r in rows])

    def _read_binary_signal(self,path:Path,cfg:dict)->np.ndarray:
        dtype=np.dtype(cfg["dtype"]).newbyteorder("<" if cfg["byte_order"]=="Little endian" else ">")
        with open(path,"rb") as f: f.seek(cfg["offset"]); raw=np.fromfile(f,dtype=dtype)
        if cfg["max_samples"]>0: raw=raw[:cfg["max_samples"]*(2 if cfg["layout"]=="Interleaved real/imaginary" else 1)]
        if cfg["layout"]=="Interleaved real/imaginary":
            if raw.size%2:raw=raw[:-1]
            return raw[0::2].astype(float)+1j*raw[1::2].astype(float)
        return np.real(raw).astype(float) if cfg["layout"]=="Real values only" else raw

    def selected_signal_region(self, signal):
        if not self.roi_enable.isChecked(): return signal
        fs=float(self.sample_rate.value()); lo,hi=sorted(self.time_roi.getRegion()); i0=max(0,int(lo*fs)); i1=min(signal.size,int(hi*fs)); return signal[i0:i1] if i1-i0>=2 else signal

    def update_fft(self):
        if not self.signal_series:return
        fs=float(self.sample_rate.value()); self.time_plot.clear(); self.time_plot.addItem(self.time_roi); self.time_roi.setVisible(self.roi_enable.isChecked()); self.freq_plot.clear()
        active_metrics=None
        for idx,item in enumerate(self.signal_series):
            signal=np.asarray(item["data"]); t=np.arange(signal.size)/fs
            self.time_plot.plot(t,np.abs(signal) if np.iscomplexobj(signal) else signal,name=item["name"])
            region=self.selected_signal_region(signal); n=region.size; nfft=self.fft_length.value() or n
            proc=region.astype(complex if np.iscomplexobj(region) else float)
            if self.remove_dc.isChecked(): proc=proc-np.mean(proc)
            proc=proc*window_values(self.window_combo.currentText(),n)
            spec=np.fft.fftshift(np.fft.fft(proc,n=nfft)); freq=np.fft.fftshift(np.fft.fftfreq(nfft,d=1/fs)); mag=np.abs(spec)
            mode=self.spectrum_mode.currentText()
            if mode=="Magnitude": y=mag; ylabel="Magnitude"
            elif mode=="dB": y=20*np.log10(np.maximum(mag,np.finfo(float).eps)); ylabel="Magnitude (dB)"
            elif mode=="Power": y=mag**2; ylabel="Power"
            elif mode=="PSD": y=(mag**2)/(fs*max(n,1)); ylabel="PSD"
            elif mode=="Phase": y=np.angle(spec); ylabel="Phase (rad)"
            elif mode=="Real": y=np.real(spec); ylabel="Real"
            else: y=np.imag(spec); ylabel="Imaginary"
            self.freq_plot.plot(freq,y,name=item["name"]); self.freq_plot.setLabel("left",ylabel)
            if idx==len(self.signal_series)-1: active_metrics=(signal,freq,spec,mag,n,nfft)
        signal,freq,spec,mag,n,nfft=active_metrics; peak=int(np.argmax(mag)); peakv=float(mag[peak]); noise=float(np.median(mag)); snr=20*np.log10(max(peakv,np.finfo(float).eps)/max(noise,np.finfo(float).eps))
        half=peakv/np.sqrt(2); inds=np.where(mag>=half)[0]; bw=float(freq[inds[-1]]-freq[inds[0]]) if inds.size>1 else 0.0
        self.metric_peak_freq.setText(f"{freq[peak]:.6g} Hz"); self.metric_peak_value.setText(f"{peakv:.6g}"); self.metric_rms.setText(f"{np.sqrt(np.mean(np.abs(signal)**2)):.6g}"); self.metric_samples.setText(f"{n} ROI / {nfft} FFT"); self.metric_resolution.setText(f"{fs/nfft:.6g} Hz"); self.metric_noise.setText(f"{noise:.6g}"); self.metric_snr.setText(f"{snr:.3f} dB"); self.metric_bandwidth.setText(f"{bw:.6g} Hz")
        self._last_fft=(freq,spec); self.statusBar().showMessage("FFT calculated")

    def apply_frequency_filter(self):
        if not self.signal_series:return
        signal=np.asarray(self.signal_series[-1]["data"]); fs=float(self.sample_rate.value()); n=signal.size; spec=np.fft.fft(signal); freq=np.fft.fftfreq(n,d=1/fs); a=abs(self.filter_low.value()); b=abs(self.filter_high.value()); lo,hi=sorted((a,b)); kind=self.filter_combo.currentText(); mask=np.ones(n,float)
        af=np.abs(freq)
        if kind=="Low Pass": mask=(af<=a)
        elif kind=="High Pass": mask=(af>=a)
        elif kind=="Band Pass": mask=((af>=lo)&(af<=hi))
        elif kind=="Band Stop": mask=~((af>=lo)&(af<=hi))
        elif kind=="Notch": mask=(np.abs(af-a)>max((hi-lo)/2,fs/n))
        elif kind=="Gaussian": mask=np.exp(-0.5*(af/max(a,fs/n))**2)
        filtered=np.fft.ifft(spec*mask); self.filtered_signal=filtered
        t=np.arange(n)/fs; self.time_plot.plot(t,np.real(filtered),name="Filtered IFFT"); self.statusBar().showMessage(f"Applied {kind}")

    def export_fft_csv(self):
        if self._last_fft is None: QMessageBox.information(self,"No FFT","Calculate FFT first."); return
        filename,_=QFileDialog.getSaveFileName(self,"Export FFT CSV","fft_result.csv","CSV files (*.csv)")
        if not filename:return
        if not filename.lower().endswith(".csv"):filename+=".csv"
        freq,spectrum=self._last_fft
        with open(filename,"w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f); w.writerow(["Frequency_Hz","Real","Imaginary","Magnitude","Phase_rad","Magnitude_dB"]);
            for fr,v in zip(freq,spectrum):
                m=abs(v); w.writerow([fr,v.real,v.imag,m,np.angle(v),20*np.log10(max(m,np.finfo(float).eps))])

    def export_signal_npz(self):
        if not self.signal_series:return
        filename,_=QFileDialog.getSaveFileName(self,"Export Signal NPZ","signal_session.npz","NumPy archive (*.npz)")
        if not filename:return
        if not filename.lower().endswith(".npz"):filename+=".npz"
        payload={f"signal_{i}":x["data"] for i,x in enumerate(self.signal_series)}; payload["names"]=np.array([x["name"] for x in self.signal_series]); payload["sample_rate"]=np.array(self.sample_rate.value())
        if self.filtered_signal is not None: payload["filtered_signal"]=self.filtered_signal
        np.savez_compressed(filename,**payload)

    def save_session(self):
        filename,_=QFileDialog.getSaveFileName(self,"Save Session","mri_session.npz","MRI session (*.npz)")
        if not filename:return
        if not filename.lower().endswith(".npz"):filename+=".npz"
        payload={"settings":np.array(json.dumps({"sample_rate":self.sample_rate.value(),"window":self.window_combo.currentText(),"filter":self.filter_combo.currentText()}))}
        if self.current_image is not None:payload["image"]=self.current_image
        if self.current_kspace is not None:payload["kspace"]=self.current_kspace
        for i,x in enumerate(self.signal_series):payload[f"signal_{i}"]=x["data"]
        payload["signal_names"]=np.array([x["name"] for x in self.signal_series]); np.savez_compressed(filename,**payload)

    def load_session(self):
        filename,_=QFileDialog.getOpenFileName(self,"Load Session","","MRI session (*.npz)")
        if not filename:return
        d=np.load(filename,allow_pickle=False)
        if "image" in d:self.current_image=d["image"]
        if "kspace" in d:self.current_kspace=d["kspace"]; self.current_reconstruction=ifft2_centered(self.current_kspace)
        self.signal_series=[]; names=list(d["signal_names"]) if "signal_names" in d else []
        for key in sorted([k for k in d.keys() if k.startswith("signal_") and k!="signal_names"]): self.signal_series.append({"name":str(names[len(self.signal_series)]) if len(names)>len(self.signal_series) else key,"data":d[key],"path":""})
        if "settings" in d:
            cfg=json.loads(str(d["settings"])); self.sample_rate.setValue(float(cfg.get("sample_rate",1000))); self.window_combo.setCurrentText(cfg.get("window","Rectangular")); self.filter_combo.setCurrentText(cfg.get("filter","None"))
        if self.signal_series:self.signal_1d=self.signal_series[-1]["data"]
        self.refresh_2d_views(); self.update_fft(); self.statusBar().showMessage("Session loaded")


def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName("InSightec Tools")
    win = MRIExplorer()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
