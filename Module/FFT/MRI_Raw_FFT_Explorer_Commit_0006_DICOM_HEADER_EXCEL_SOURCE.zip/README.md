# MRI Raw & FFT Explorer — Commit 0006

SDKなしで動作するGeneric FFT Engineを基盤に、任意導入のGE Orchestra / Siemens IDEA・ICE / Siemens TWIXプラグインへ自動フォールバックするWindowsツールです。

## Commit 0006 additions
- Plugin Manager / Vendor SDK status
- Auto reconstruction: official SDK/plugin first, Generic FFT fallback when unavailable
- SDK files and licenses are never bundled
- 1D Signal Studio integrated into the foundation
- Up to 8 overlaid signals
- Time ROI selection and ROI-only FFT
- FFT/IFFT, magnitude, dB, power, PSD, phase, real, imaginary
- Low-pass, high-pass, band-pass, band-stop, notch and Gaussian frequency filters
- Filtered IFFT preview
- Peak, RMS, noise floor, SNR, frequency resolution and -3 dB bandwidth
- Extract image or k-space center row into Signal Studio
- CSV/NPY/NPZ/RAW/BIN/DAT import
- FFT CSV and signal NPZ export
- Session save/load for image, k-space, signals and main settings

## Build
Recommended GitHub Actions option: `fast_pyinstaller`. It creates a standalone Windows folder and a one-level distribution ZIP.

Local: `02_BUILD_FAST_STANDALONE.bat`

## SDK behavior
Without any SDK, DICOM, generic raw, Tracker candidate reconstruction, 2D FFT/IFFT and the complete 1D Signal Studio remain available. Vendor SDK adapters are optional external executables configured in `vendor_sdk_config.json`.


## Commit 0006 additions

- Expanded DICOM header viewer with Tag, Keyword, Name, VR, VM, private-tag indicator, and full value.
- Search/filter across all displayed DICOM header columns.
- Export the current DICOM header to formatted Excel `.xlsx`.
- Export an entire loaded DICOM series to Excel with `Series Summary` and `All Header Elements` worksheets.
- Pixel Data is intentionally omitted from the header table and Excel output to avoid very large workbooks.
