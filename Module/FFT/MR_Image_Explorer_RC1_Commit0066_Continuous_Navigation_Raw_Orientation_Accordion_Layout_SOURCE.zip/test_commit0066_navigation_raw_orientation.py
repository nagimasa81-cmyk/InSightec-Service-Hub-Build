from pathlib import Path

APP = Path(__file__).with_name("app.py").read_text(encoding="utf-8")

def test_delayed_tree_reassertion_present():
    assert "QTimer.singleShot(120" in APP
    assert "_reassert_tree_series_expansion" in APP

def test_raw_orientation_companion_dicom_present():
    assert "_resolve_raw_orientation_dataset" in APP
    assert "RAW orientation inherited from companion DICOM geometry" in APP

def test_raw_navigation_supported_types():
    assert '"raw_file", "raw_pending", "bitmap_pending", "bitmap", "processed"' in APP

def test_toolbar_above_workspace():
    assert "layout.insertWidget(0, self.mode_toolbar_widget)" in APP
