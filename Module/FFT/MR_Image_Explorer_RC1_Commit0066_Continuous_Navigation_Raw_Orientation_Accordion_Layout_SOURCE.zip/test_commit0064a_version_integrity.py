import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APP = (ROOT / 'app.py').read_text(encoding='utf-8')
VERSION = json.loads((ROOT / 'version.json').read_text(encoding='utf-8'))


def test_single_canonical_version_keys():
    assert VERSION['version']
    assert VERSION['commit'].startswith('Commit')
    assert 'Version' not in VERSION
    assert 'Commit' not in VERSION


def test_app_reads_version_json_for_title():
    assert 'VERSION_INFO = _load_version_info()' in APP
    assert 'APP_VERSION = f"{VERSION_INFO' in APP
    assert 'Commit0062' not in APP


def test_commit0064_layout_features_present():
    assert 'self.primary_panel = ImagePanel("Original")' in APP
    assert 'self.secondary_panel = ImagePanel("FFT (k-space)")' in APP
    assert 'Original — Horizontal Crosshair Profile' in APP
    assert 'Original — Vertical Crosshair Profile' in APP
    assert 'FFT — Horizontal Crosshair Profile' in APP
    assert 'FFT — Vertical Crosshair Profile' in APP


def test_view_state_and_continuous_navigation_present():
    assert 'Preserve the user\'s selected FFT / Original / Both layout' in APP
    assert 'def change_slice_continuous' in APP
    assert 'def _navigate_tree_source_continuous' in APP


def test_all_right_sections_use_accordion_behavior():
    assert 'self.accordion_sections.append(self.output_accordion)' in APP
    assert 'self.output_accordion.opened.connect(self._accordion_opened)' in APP
