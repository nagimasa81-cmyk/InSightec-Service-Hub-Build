import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from PySide6.QtWidgets import QApplication
from app import ImagePanel

app = QApplication.instance() or QApplication([])
panel = ImagePanel("Comp ROI Test")
panel.set_image([[0.0]*20 for _ in range(20)])
panel.show_comp_roi()
size = panel.comp_roi.size()
assert round(size.x()) == round(size.y())
assert panel.comp_roi.isVisible()
panel.hide_comp_roi()
assert not panel.comp_roi.isVisible()
print("PASS: Commit0136 circular compensation ROI")
