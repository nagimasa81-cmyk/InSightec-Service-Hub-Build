from __future__ import annotations

import csv
import json
import copy
import shutil
import sys
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import pydicom
import pyqtgraph as pg
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QAction, QKeySequence, QImage
from pydicom.uid import generate_uid
from tracker_position import DirectionMeasurement, signal_peak_coordinate, solve_position
from artifact_learning_db import ArtifactDatabase, image_features
from artifact_detection import classify_feature_vector, features_to_vector
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout, QFrame,
    QGroupBox, QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QPushButton,
    QDoubleSpinBox, QProgressDialog, QScrollArea, QSlider, QSpinBox, QSplitter, QStatusBar, QTabWidget, QTableWidget,
    QTableWidgetItem, QTextEdit, QTreeWidget, QTreeWidgetItem, QTreeWidgetItemIterator, QVBoxLayout, QWidget, QMenu,
)

APP_NAME = "MR Image Explorer"
APP_VERSION = "1.4.3 RC1 Prototype Pack1 Commit0014a HotFix3"

pg.setConfigOptions(imageAxisOrder="row-major", antialias=True)


def fft2c(image: np.ndarray) -> np.ndarray:
    return np.fft.fftshift(np.fft.fft2(np.fft.ifftshift(image)))


def ifft2c(kspace: np.ndarray) -> np.ndarray:
    return np.fft.fftshift(np.fft.ifft2(np.fft.ifftshift(kspace)))


def display_array(arr: np.ndarray, mode: str) -> np.ndarray:
    if mode == "FFT":
        return np.log1p(np.abs(arr))
    return np.abs(arr)


@dataclass
class DicomEntry:
    path: Path
    ds: pydicom.dataset.FileDataset
    image: np.ndarray
    sort_key: tuple


class DropBanner(QFrame):
    pathsDropped = Signal(list)

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.setObjectName("DropBanner")
        layout = QVBoxLayout(self)
        self.title = QLabel("Drop DICOM / Raw / P File / 1D Data / Folder / ZIP Here")
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setStyleSheet("font-size: 17px; font-weight: 600;")
        subtitle = QLabel("DICOM, RAW, GE TrackerImg/PFile, Siemens .dat, CSV/TXT/NPY/NPZ, images")
        subtitle.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.title)
        layout.addWidget(subtitle)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self.setProperty("dragActive", True)
            self.style().unpolish(self); self.style().polish(self)

    def dragLeaveEvent(self, event):
        self.setProperty("dragActive", False)
        self.style().unpolish(self); self.style().polish(self)

    def dropEvent(self, event):
        self.setProperty("dragActive", False)
        self.style().unpolish(self); self.style().polish(self)
        paths = [Path(u.toLocalFile()) for u in event.mimeData().urls() if u.isLocalFile()]
        if paths:
            self.pathsDropped.emit(paths)
            event.acceptProposedAction()


class ImagePanel(QWidget):
    lineChanged = Signal(int, int)
    pageRequested = Signal(int)
    mouseActionChanged = Signal(str)
    viewRequested = Signal(str)
    levelWheel = Signal(float, bool)

    def __init__(self, title: str):
        super().__init__()
        layout = QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        self.label = QLabel(title)
        self.label.setStyleSheet("font-weight: 600; padding: 3px;")
        layout.addWidget(self.label)
        self.plot = pg.PlotWidget()
        self.plot.setMenuEnabled(False)
        self.plot.getViewBox().setMenuEnabled(False)
        self.plot.scene().sigMouseClicked.connect(self._scene_mouse_clicked)
        self.mouse_action = "Window/Level"
        self.plot.setAspectLocked(True)
        self.plot.hideAxis("left"); self.plot.hideAxis("bottom")
        self.image_item = pg.ImageItem()
        self.plot.addItem(self.image_item)
        self.hline = pg.InfiniteLine(angle=0, movable=True, pen=pg.mkPen('#ff4949', width=1.5, style=Qt.DashLine))
        self.vline = pg.InfiniteLine(angle=90, movable=True, pen=pg.mkPen('#ff4949', width=1.5, style=Qt.DashLine))
        self.plot.addItem(self.hline); self.plot.addItem(self.vline)
        self.hline.sigPositionChanged.connect(self._emit_position)
        self.vline.sigPositionChanged.connect(self._emit_position)
        self.comp_roi = pg.RectROI([10, 10], [40, 40], pen=pg.mkPen("#35a7ff", width=2))
        self.comp_roi.addScaleHandle([1, 1], [0, 0])
        self.comp_roi.addScaleHandle([0, 0], [1, 1])
        self.comp_roi.addScaleHandle([1, 0], [0, 1])
        self.comp_roi.addScaleHandle([0, 1], [1, 0])
        self.comp_roi.hide()
        self.plot.addItem(self.comp_roi)
        layout.addWidget(self.plot, 1)
        self.shape = (1, 1)
        self.current_levels = None

    def _scene_mouse_clicked(self, event):
        if event.button() == Qt.RightButton:
            event.accept()
            self._show_mouse_action_menu(event.screenPos().toPoint())

    def _show_mouse_action_menu(self, global_pos):
        menu = QMenu(self)
        menu.setToolTipsVisible(True)

        action_group = {}
        descriptions = {
            "Window/Level": "Wheel changes Level; Ctrl+Wheel changes Width",
            "Pan": "Left-drag moves the image",
            "Zoom": "Drag a rectangle to zoom",
            "Paging": "Mouse wheel moves Previous/Next image",
            "ROI": "Show and resize the compensation ROI",
        }
        for label in ["Window/Level", "Pan", "Zoom", "Paging", "ROI"]:
            action = menu.addAction(label)
            action.setCheckable(True)
            action.setChecked(self.mouse_action == label)
            action.setToolTip(descriptions[label])
            action_group[action] = label

        menu.addSeparator()
        fft_action = menu.addAction("FFT Current Image")
        original_action = menu.addAction("Original View")
        both_action = menu.addAction("Both View")
        menu.addSeparator()
        auto_action = menu.addAction("Auto Window/Level")
        default_action = menu.addAction("Back to Default")

        selected = menu.exec(global_pos)
        if selected in action_group:
            self.mouse_action = action_group[selected]
            view_box = self.plot.getViewBox()
            if self.mouse_action == "Pan":
                view_box.setMouseMode(pg.ViewBox.PanMode)
                self.comp_roi.hide()
            elif self.mouse_action == "Zoom":
                view_box.setMouseMode(pg.ViewBox.RectMode)
                self.comp_roi.hide()
            elif self.mouse_action == "ROI":
                self.comp_roi.show()
            else:
                self.comp_roi.hide()
            self.mouseActionChanged.emit(self.mouse_action)
        elif selected == fft_action:
            self.viewRequested.emit("FFT_CURRENT")
        elif selected == original_action:
            self.viewRequested.emit("Original")
        elif selected == both_action:
            self.viewRequested.emit("Both")
        elif selected == auto_action:
            self.mouseActionChanged.emit("Auto Window/Level")
        elif selected == default_action:
            self.viewRequested.emit("Default")


    def wheelEvent(self, event):
        delta = event.angleDelta().y()
        if self.mouse_action == "Paging":
            self.pageRequested.emit(1 if delta < 0 else -1)
            event.accept()
            return
        if self.mouse_action == "Window/Level":
            self.levelWheel.emit(1.0 if delta > 0 else -1.0, bool(event.modifiers() & Qt.ControlModifier))
            event.accept()
            return
        super().wheelEvent(event)


    def set_image(self, image: np.ndarray, auto_levels=True, levels=None):
        image = np.asarray(image, dtype=float)
        self.shape = image.shape[:2]
        self.current_levels = levels
        self.image_item.setImage(image, autoLevels=auto_levels if levels is None else False, levels=levels)
        self.plot.setRange(xRange=(0, self.shape[1]), yRange=(0, self.shape[0]), padding=0)
        self.set_line_position(self.shape[0] // 2, self.shape[1] // 2)

    def set_levels(self, low: float, high: float):
        if high <= low:
            high = low + 1.0
        self.current_levels = (float(low), float(high))
        self.image_item.setLevels(self.current_levels)

    def show_comp_roi(self):
        rows, cols = self.shape
        width = max(8, cols // 5)
        height = max(8, rows // 5)
        self.comp_roi.setPos((cols - width) / 2, (rows - height) / 2)
        self.comp_roi.setSize((width, height))
        self.comp_roi.show()

    def hide_comp_roi(self):
        self.comp_roi.hide()

    def comp_roi_bounds(self):
        pos = self.comp_roi.pos()
        size = self.comp_roi.size()
        x0 = max(0, min(int(round(pos.x())), self.shape[1] - 1))
        y0 = max(0, min(int(round(pos.y())), self.shape[0] - 1))
        x1 = max(x0 + 1, min(int(round(pos.x() + size.x())), self.shape[1]))
        y1 = max(y0 + 1, min(int(round(pos.y() + size.y())), self.shape[0]))
        return y0, y1, x0, x1

    def set_line_position(self, row: int, col: int):
        row = max(0, min(int(row), self.shape[0] - 1))
        col = max(0, min(int(col), self.shape[1] - 1))
        self.hline.blockSignals(True); self.vline.blockSignals(True)
        self.hline.setPos(row); self.vline.setPos(col)
        self.hline.blockSignals(False); self.vline.blockSignals(False)

    def _emit_position(self):
        row = max(0, min(int(round(self.hline.value())), self.shape[0] - 1))
        col = max(0, min(int(round(self.vline.value())), self.shape[1] - 1))
        self.lineChanged.emit(row, col)



class AccordionSection(QWidget):
    opened = Signal(object)
    def __init__(self, title, content, expanded=False, parent=None):
        super().__init__(parent); self.title=title; self.content=content
        lay=QVBoxLayout(self); lay.setContentsMargins(0,0,0,0); lay.setSpacing(3)
        self.button=QPushButton(); self.button.setCheckable(True); self.button.clicked.connect(self._toggle)
        self.button.setStyleSheet("QPushButton{text-align:left;min-height:30px;font-weight:700;background:#1e4b72;border:1px solid #37698f;border-radius:4px;padding:4px 8px} QPushButton:hover{background:#265f8e}")
        lay.addWidget(self.button); lay.addWidget(content); self.set_expanded(expanded,False)
    def _label(self): self.button.setText(("▼" if self.button.isChecked() else "▶")+"  "+self.title)
    def _toggle(self): self.set_expanded(self.button.isChecked(),True)
    def set_expanded(self, expanded, notify=False):
        self.button.blockSignals(True); self.button.setChecked(bool(expanded)); self.button.blockSignals(False)
        self.content.setVisible(bool(expanded)); self._label()
        if expanded and notify: self.opened.emit(self)

class DicomHeaderDialog(QDialog):
    def __init__(self, ds, source_path, parent=None):
        super().__init__(parent); self.ds=copy.deepcopy(ds) if ds is not None else None; self.source_path=Path(source_path) if source_path else None; self._editable=False
        self.setWindowTitle('DICOM Header'); self.resize(1120,720)
        root=QVBoxLayout(self); row=QHBoxLayout(); self.filter_edit=QLineEdit(); self.filter_edit.setPlaceholderText('Filter DICOM header...'); self.filter_edit.textChanged.connect(self._filter); row.addWidget(self.filter_edit,1)
        for label,cb in [('Edit',self.enable_edit),('Save',self.save_edited),('Close',self.close)]: b=QPushButton(label); b.clicked.connect(cb); row.addWidget(b)
        root.addLayout(row); self.table=QTableWidget(0,6); self.table.setHorizontalHeaderLabels(['Tag','Keyword','Name','VR','VM','Value']); self.table.horizontalHeader().setStretchLastSection(True); self.table.setSelectionMode(QTableWidget.ExtendedSelection); self.table.setContextMenuPolicy(Qt.CustomContextMenu); self.table.customContextMenuRequested.connect(self._menu); root.addWidget(self.table,1); self.status=QLabel('Read-only. Press Edit to change values.'); root.addWidget(self.status); self._populate()
    def _populate(self):
        rows=[]
        if self.ds:
            for e in self.ds.iterall():
                if e.tag.group!=0x7FE0: rows.append((str(e.tag),e.keyword,e.name,e.VR,str(e.VM),str(e.value)))
        self.table.setRowCount(len(rows))
        for r,vals in enumerate(rows):
            for c,v in enumerate(vals):
                it=QTableWidgetItem(v); it.setFlags(it.flags() & ~Qt.ItemIsEditable); self.table.setItem(r,c,it)
        self.table.resizeColumnsToContents()
    def enable_edit(self):
        self._editable=True
        for r in range(self.table.rowCount()):
            it=self.table.item(r,5)
            if it: it.setFlags(it.flags()|Qt.ItemIsEditable)
        self.status.setText('Edit mode enabled. Value column is editable.')
    def _menu(self,pos):
        m=QMenu(self); a1=m.addAction('Copy Selection'); a2=m.addAction('Copy Value'); a3=m.addAction('Copy Row'); a4=m.addAction('Select All'); a=m.exec(self.table.viewport().mapToGlobal(pos))
        if a==a4: self.table.selectAll(); return
        cur=self.table.currentItem()
        if a==a1: QApplication.clipboard().setText('\n'.join(i.text() for i in self.table.selectedItems()))
        elif a==a2 and cur: QApplication.clipboard().setText(self.table.item(cur.row(),5).text())
        elif a==a3 and cur: QApplication.clipboard().setText('\t'.join(self.table.item(cur.row(),c).text() if self.table.item(cur.row(),c) else '' for c in range(6)))
    def _filter(self,q):
        q=q.lower()
        for r in range(self.table.rowCount()): self.table.setRowHidden(r, not any(q in (self.table.item(r,c).text().lower() if self.table.item(r,c) else '') for c in range(6)))
    def _next_path(self):
        folder=(self.source_path.parent if self.source_path else Path.cwd())/'Edited'; folder.mkdir(parents=True,exist_ok=True); base=self.source_path.stem if self.source_path else 'DICOM'; out=folder/f'{base}_Edit.dcm'; n=1
        while out.exists(): out=folder/f'{base}_Edit{n}.dcm'; n+=1
        return out
    def save_edited(self):
        if not self.ds or not self._editable: QMessageBox.information(self,'DICOM Header','Press Edit before saving.'); return
        changed=0
        for r in range(self.table.rowCount()):
            try:
                g,e=self.table.item(r,0).text().strip('()').split(','); tag=(int(g,16),int(e,16)); val=self.table.item(r,5).text()
                if tag in self.ds and str(self.ds[tag].value)!=val: self.ds[tag].value=val; changed+=1
            except Exception: pass
        out=self._next_path()
        try: self.ds.save_as(str(out))
        except Exception as exc: QMessageBox.critical(self,'Save Error',str(exc)); return
        self.status.setText(f'Saved {changed} changed value(s): {out}'); QMessageBox.information(self,'DICOM Header',f'Saved:\n{out}')

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} {APP_VERSION}")
        self.resize(1550, 950)
        self.setAcceptDrops(True)
        self.temp_dirs: list[Path] = []
        self.dicom_entries: list[DicomEntry] = []
        self.current_image: Optional[np.ndarray] = None
        self.current_kspace: Optional[np.ndarray] = None
        self.current_recon: Optional[np.ndarray] = None
        self.current_ds = None
        self.current_source = ""
        self.view_mode = "Both"
        self.line_orientation = "Row"
        self.line_row = 0
        self.line_col = 0
        self.signals: list[dict] = []
        self.imported_paths: list[Path] = []
        self.spike_results: list[dict] = []
        self.active_spike_indices = np.array([], dtype=int)
        self.tracker_matrix: Optional[np.ndarray] = None
        self.tracker_source_path: Optional[Path] = None
        self.tracker_files: list[dict] = []
        self.tracker_file_index: int = -1
        self.tracker_line_metrics: list[dict] = []
        self.tracker_selected_lines: list[int] = []
        self.tracker_position_measurements: list[DirectionMeasurement] = []
        self.tracker_reconstructed_image: Optional[np.ndarray] = None
        self.tracker_strongest_line: Optional[np.ndarray] = None
        self.tracker_strongest_line_index: int = -1
        self.tracker_shared_name: str = ""
        self.artifact_db: Optional[ArtifactDatabase] = None
        self.artifact_db_path: Optional[Path] = None
        self.artifact_selected_indices: list[int] = []
        self.normal_reference_image: Optional[np.ndarray] = None
        self.normal_reference_path: Optional[Path] = None
        self.compensation_preview: Optional[np.ndarray] = None
        self.compensation_original: Optional[np.ndarray] = None
        self.compensation_original_kspace: Optional[np.ndarray] = None
        self.compensation_history: list[dict] = []
        self.compensation_history_index: int = -1
        self.compensation_base_kspace: Optional[np.ndarray] = None
        self.compensation_base_image: Optional[np.ndarray] = None
        self.compensation_roi_panel: Optional[ImagePanel] = None
        self.addsub_preview_result: Optional[np.ndarray] = None
        self.addsub_preview_operation: str = ""
        self.addsub_a: Optional[dict] = None
        self.addsub_b: Optional[dict] = None
        self.processed_images: dict[str, np.ndarray] = {}
        self.processed_sources: dict[str, Path] = {}
        self.window_level: Optional[float] = None
        self.dynamic_range: Optional[float] = None
        self.original_window_level: Optional[float] = None
        self.original_dynamic_range: Optional[float] = None
        self.raw_window_level: Optional[float] = None
        self.raw_dynamic_range: Optional[float] = None
        self.level_preset = "Auto"
        self.source_kind = "none"
        self.output_root_override: Optional[Path] = None

        self._build_ui()
        self._build_menu()
        self._apply_style()
        self.statusBar().showMessage("Ready — drop files or folders above")

    def _build_ui(self):
        root = QWidget(); root_l = QVBoxLayout(root); root_l.setContentsMargins(8, 8, 8, 8)
        self.drop_banner = DropBanner(); self.drop_banner.pathsDropped.connect(self.import_paths)
        root_l.addWidget(self.drop_banner)

        self.tabs = QTabWidget()
        self.tabs.setMovable(False)
        self.tabs.setDocumentMode(False)
        self.tabs.setTabPosition(QTabWidget.North)
        self.tabs.addTab(self._build_workspace(), "Image Workspace")
        self.tabs.addTab(self._build_spike_results(), "Spike Diag")
        self.tabs.addTab(self._build_artifact_diag(), "Artifact Diag")
        self.tabs.addTab(self._build_tracker_signal_combined(), "Tracker Signal")
        self.tabs.addTab(self._build_signal_studio(), "1D Signal Studio")
        root_l.addWidget(self.tabs, 1)
        self.setCentralWidget(root)
        self.setStatusBar(QStatusBar())

    def _build_artifact_diag(self):
        page=QWidget(); lay=QVBoxLayout(page); inner=QTabWidget(); inner.addTab(self._build_artifact_detection(),'Detection'); inner.addTab(self._build_artifact_learning(),'Learning'); lay.addWidget(inner); return page

    def _build_tracker_signal_combined(self):
        page=QWidget(); lay=QVBoxLayout(page); inner=QTabWidget(); inner.addTab(self._build_tracker_explorer(),'Signal Explorer'); inner.addTab(self._build_tracker_position(),'Position'); lay.addWidget(inner); return page

    def _build_workspace(self):
        page = QWidget(); layout = QHBoxLayout(page); layout.setContentsMargins(0, 6, 0, 0)
        main_split = QSplitter(Qt.Horizontal)

        left = QWidget()
        left.setMinimumWidth(90)
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabel("Explorer")
        self.tree.setSelectionMode(QTreeWidget.ExtendedSelection)
        self.tree.setMinimumWidth(90)
        self.tree.setTextElideMode(Qt.ElideMiddle)
        self.tree.setUniformRowHeights(False)
        self.tree.setStyleSheet("""
            QTreeWidget::item:selected {
                background: rgba(55, 165, 255, 110);
                color: white;
            }
            QTreeWidget::item:selected:active {
                background: rgba(55, 165, 255, 145);
            }
        """)
        self.tree.itemClicked.connect(self._tree_clicked)
        self.tree.itemSelectionChanged.connect(self._tree_selection_changed)
        self.tree.currentItemChanged.connect(self._tree_current_changed)
        ll.addWidget(self.tree, 1)
        self.info = QLabel("No file loaded")
        self.info.setWordWrap(True); self.info.setMinimumHeight(150)
        self.info.setObjectName("InfoCard")
        ll.addWidget(self.info)
        main_split.addWidget(left)

        center = QWidget(); cl = QVBoxLayout(center); cl.setContentsMargins(0, 0, 0, 0)
        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel("Display"))
        self.workspace_source_combo = QComboBox()
        self.workspace_source_combo.addItems(["Current Image"])
        self.workspace_source_combo.hide()
        self.btn_fft = QPushButton("FFT")
        self.btn_original = QPushButton("Original")
        self.btn_both = QPushButton("Both")
        for b, mode in [(self.btn_fft, "FFT"), (self.btn_original, "Original"), (self.btn_both, "Both")]:
            b.setCheckable(True); b.clicked.connect(lambda checked=False, m=mode: self.set_view_mode(m)); mode_row.addWidget(b)
        mode_row.addStretch(1)
        self.slice_label = QLabel("Slice: -")
        self.prev_btn = QPushButton("Previous"); self.next_btn = QPushButton("Next")
        self.prev_btn.clicked.connect(lambda: self.change_slice(-1)); self.next_btn.clicked.connect(lambda: self.change_slice(1))
        self.clear_selected_images_button = QPushButton("Clear Selected")
        self.clear_all_images_button = QPushButton("Clear All Images")
        self.clear_selected_images_button.clicked.connect(self.clear_selected_images)
        self.clear_all_images_button.clicked.connect(self.clear_all_images)
        mode_row.addWidget(self.prev_btn); mode_row.addWidget(self.next_btn); mode_row.addWidget(self.slice_label)
        mode_row.addWidget(self.clear_selected_images_button); mode_row.addWidget(self.clear_all_images_button)
        self.header_popup_button=QPushButton("DICOM Header"); self.header_popup_button.clicked.connect(self.show_dicom_header_popup); mode_row.addWidget(self.header_popup_button)
        self.quick_spike_button=QPushButton("Quick Spike Detect"); self.quick_spike_button.clicked.connect(self.quick_spike_detect_prototype); mode_row.addWidget(self.quick_spike_button)
        cl.addLayout(mode_row)

        self.vertical_splitter = QSplitter(Qt.Vertical)
        image_container = QWidget(); il = QVBoxLayout(image_container); il.setContentsMargins(0, 0, 0, 0)
        self.image_splitter = QSplitter(Qt.Horizontal)
        self.primary_panel = ImagePanel("FFT (k-space)")
        self.secondary_panel = ImagePanel("Original")
        self.primary_panel.lineChanged.connect(self._line_moved)
        self.secondary_panel.lineChanged.connect(self._line_moved)
        self.primary_panel.pageRequested.connect(self.change_slice)
        self.secondary_panel.pageRequested.connect(self.change_slice)
        self.primary_panel.mouseActionChanged.connect(self._image_mouse_action_changed)
        self.secondary_panel.mouseActionChanged.connect(self._image_mouse_action_changed)
        self.primary_panel.viewRequested.connect(self._image_view_requested)
        self.secondary_panel.viewRequested.connect(self._image_view_requested)
        self.primary_panel.levelWheel.connect(
            lambda step, width: self._image_level_wheel(self.primary_panel, step, width)
        )
        self.secondary_panel.levelWheel.connect(
            lambda step, width: self._image_level_wheel(self.secondary_panel, step, width)
        )
        self.image_splitter.addWidget(self.primary_panel); self.image_splitter.addWidget(self.secondary_panel)
        il.addWidget(self.image_splitter, 1)

        line_bar = QHBoxLayout()
        line_bar.addWidget(QLabel("Line"))
        self.orientation_combo = QComboBox(); self.orientation_combo.addItems(["Row", "Column"])
        self.orientation_combo.currentTextChanged.connect(self._orientation_changed)
        line_bar.addWidget(self.orientation_combo)
        self.line_spin = QSpinBox(); self.line_spin.valueChanged.connect(self._spin_line_changed)
        line_bar.addWidget(self.line_spin)
        self.line_slider = QSlider(Qt.Horizontal); self.line_slider.valueChanged.connect(self._slider_line_changed)
        line_bar.addWidget(self.line_slider, 1)
        self.line_value_label = QLabel("-")
        line_bar.addWidget(self.line_value_label)
        il.addLayout(line_bar)
        self.vertical_splitter.addWidget(image_container)

        lower = QWidget(); low = QHBoxLayout(lower); low.setContentsMargins(0, 0, 0, 0)
        self.profile_plot = pg.PlotWidget(title="Selected Line Profile")
        self.profile_plot.showGrid(x=True, y=True, alpha=.2)
        self.profile_plot.setLabel("bottom", "Sample")
        low.addWidget(self.profile_plot, 2)
        self.tracker_plot = pg.PlotWidget(title="Tracker / Active 1D Signal")
        self.tracker_plot.showGrid(x=True, y=True, alpha=.2)
        low.addWidget(self.tracker_plot, 1)
        self.vertical_splitter.addWidget(lower)
        self.vertical_splitter.setSizes([620, 260])
        cl.addWidget(self.vertical_splitter, 1)
        main_split.addWidget(center)

        right = QWidget()
        right.setMinimumWidth(330)
        right.setMaximumWidth(520)
        rl = QVBoxLayout(right)
        rl.setContentsMargins(4, 0, 4, 0)
        rl.setSpacing(6)
        right.setStyleSheet("""
            QComboBox, QDoubleSpinBox, QSpinBox, QPushButton {
                min-height: 28px;
            }
            QGroupBox {
                margin-top: 8px;
            }
        """)
        profile_group = QGroupBox("Profile")
        form = QFormLayout(profile_group)
        self.profile_mode = QComboBox(); self.profile_mode.addItems(["Magnitude", "Real", "Imaginary", "Phase"])
        self.profile_mode.currentTextChanged.connect(self.on_display_type_changed)
        form.addRow("Type", self.profile_mode)
        self.log_profile = QCheckBox("Log scale"); self.log_profile.toggled.connect(self.update_line_profile)
        form.addRow(self.log_profile)
        rl.addWidget(profile_group)
        self.btn_send_signal = QPushButton("Send selected line to 1D Studio")
        self.btn_send_signal.clicked.connect(self.send_line_to_signal_studio)
        rl.addWidget(self.btn_send_signal)
        self.btn_auto = QPushButton("Auto Levels"); self.btn_auto.clicked.connect(self.auto_levels)
        rl.addWidget(self.btn_auto)
        spike_content=QFrame(); spike_layout=QFormLayout(spike_content)
        self.spike_range_combo=QComboBox(); self.spike_range_combo.addItems(["Large","Mid","Small","Scale"]); self.spike_range_combo.currentTextChanged.connect(self._spike_range_changed); spike_layout.addRow("Range",self.spike_range_combo)
        self.spike_scale_slider=QSlider(Qt.Horizontal); self.spike_scale_slider.setRange(10,100); self.spike_scale_slider.setValue(70); self.spike_scale_slider.setVisible(False); self.spike_scale_label=QLabel("70%"); self.spike_scale_label.setVisible(False); self.spike_scale_slider.valueChanged.connect(lambda v:self.spike_scale_label.setText(f"{v}%")); sr=QHBoxLayout(); sr.addWidget(self.spike_scale_slider,1); sr.addWidget(self.spike_scale_label); spike_layout.addRow("Scale",sr)
        self.spike_level_combo=QComboBox(); self.spike_level_combo.addItems(["Wide","Mid","Fine"]); spike_layout.addRow("Level",self.spike_level_combo)
        self.btn_spike=QPushButton("Apply Spike Processing"); self.btn_spike.clicked.connect(self.apply_spike_processing); self.btn_spike.setStyleSheet("QPushButton{background:#7a2430;font-weight:700;min-height:30px} QPushButton:hover{background:#a23242}"); spike_layout.addRow(self.btn_spike)

        display_group = QGroupBox("Dynamic Range / Window Level")
        display_form = QFormLayout(display_group)
        self.level_target_combo = QComboBox()
        self.level_target_combo.addItems(["Original Image", "Raw Data"])
        self.level_target_combo.currentTextChanged.connect(self._level_target_changed)
        display_form.addRow("Adjust", self.level_target_combo)

        self.level_preset_combo = QComboBox()
        self.level_preset_combo.addItems(["Auto", "Manual", "Wide", "Soft Tissue", "High Contrast", "Narrow"])
        self.level_preset_combo.currentTextChanged.connect(self.apply_level_preset)
        display_form.addRow("Preset", self.level_preset_combo)

        self.window_level_spin = QDoubleSpinBox()
        self.window_level_spin.setRange(-1e12, 1e12)
        self.window_level_spin.setDecimals(3)
        self.window_level_spin.valueChanged.connect(self._manual_levels_changed)
        display_form.addRow("Window level", self.window_level_spin)

        self.dynamic_range_spin = QDoubleSpinBox()
        self.dynamic_range_spin.setRange(1e-9, 1e12)
        self.dynamic_range_spin.setDecimals(3)
        self.dynamic_range_spin.valueChanged.connect(self._manual_levels_changed)
        display_form.addRow("Dynamic range", self.dynamic_range_spin)
        rl.addWidget(display_group)

        addsub_group = QGroupBox("Image Add / Subtract")
        addsub_layout = QVBoxLayout(addsub_group)
        addsub_row1 = QHBoxLayout()
        self.set_a_button = QPushButton("Set Current as A")
        self.set_b_button = QPushButton("Set Current as B")
        self.set_a_button.clicked.connect(lambda: self.set_addsub_source("A"))
        self.set_b_button.clicked.connect(lambda: self.set_addsub_source("B"))
        addsub_row1.addWidget(self.set_a_button)
        addsub_row1.addWidget(self.set_b_button)
        addsub_layout.addLayout(addsub_row1)
        self.addsub_status = QLabel("A: -\nB: -")
        self.addsub_status.setWordWrap(True)
        addsub_layout.addWidget(self.addsub_status)
        addsub_row2 = QHBoxLayout()
        self.add_button = QPushButton("Preview A + B")
        self.subtract_button = QPushButton("Preview A - B")
        self.add_button.clicked.connect(lambda: self.preview_addsub("add"))
        self.subtract_button.clicked.connect(lambda: self.preview_addsub("subtract"))
        addsub_row2.addWidget(self.add_button)
        addsub_row2.addWidget(self.subtract_button)
        addsub_layout.addLayout(addsub_row2)
        self.save_addsub_button = QPushButton("Save Preview Result")
        self.save_addsub_button.clicked.connect(self.save_addsub_preview)
        self.save_addsub_button.setEnabled(False)
        addsub_layout.addWidget(self.save_addsub_button)
        addsub_clear_row = QHBoxLayout()
        for label, callback in [
            ("Clear A", lambda: self.clear_addsub_slot("A")),
            ("Clear B", lambda: self.clear_addsub_slot("B")),
            ("Clear Result", self.clear_addsub_result),
        ]:
            button = QPushButton(label); button.clicked.connect(callback); addsub_clear_row.addWidget(button)
        addsub_layout.addLayout(addsub_clear_row)

        comp_group = QGroupBox("Raw Data Compensation")
        comp_layout = QVBoxLayout(comp_group)
        self.select_comp_button = QPushButton("Select Compensation ROI on Raw Data")
        self.preview_comp_button = QPushButton("Preview Reconstructed Image")
        self.apply_comp_button = QPushButton("Commit Compensation")
        self.save_comp_button = QPushButton("Save Displayed Compensation")
        self.cancel_comp_button = QPushButton("Cancel Current ROI")
        self.select_comp_button.clicked.connect(self.start_compensation_roi)
        self.preview_comp_button.clicked.connect(self.preview_compensation)
        self.apply_comp_button.clicked.connect(self.apply_compensation)
        self.save_comp_button.clicked.connect(self.save_compensation_history_state)
        self.cancel_comp_button.clicked.connect(self.clear_compensation_roi)
        comp_layout.addWidget(self.select_comp_button)

        level_row = QHBoxLayout()
        level_row.addWidget(QLabel("Level"))
        self.comp_level_combo = QComboBox()
        self.comp_level_combo.addItems(["Low", "Mid", "High"])
        self.comp_level_combo.setCurrentText("Mid")
        level_row.addWidget(self.comp_level_combo)
        comp_layout.addLayout(level_row)

        self.comp_status_label = QLabel("No RAW ROI selected")
        self.comp_status_label.setWordWrap(True)
        comp_layout.addWidget(self.comp_status_label)

        comp_preview_row = QHBoxLayout()
        comp_preview_row.addWidget(self.preview_comp_button)
        comp_preview_row.addWidget(self.apply_comp_button)
        comp_layout.addLayout(comp_preview_row)

        history_row = QHBoxLayout()
        self.comp_prev_button = QPushButton("Previous")
        self.comp_next_button = QPushButton("Next")
        self.comp_prev_button.clicked.connect(lambda: self.navigate_compensation_history(-1))
        self.comp_next_button.clicked.connect(lambda: self.navigate_compensation_history(1))
        history_row.addWidget(self.comp_prev_button)
        history_row.addWidget(self.comp_next_button)
        comp_layout.addLayout(history_row)
        comp_layout.addWidget(self.save_comp_button)
        self.clear_comp_history_button = QPushButton("Clear Compensation History")
        self.clear_comp_history_button.clicked.connect(self.clear_compensation_history)
        comp_layout.addWidget(self.clear_comp_history_button)
        comp_layout.addWidget(self.cancel_comp_button)

        self.preview_comp_button.setEnabled(False)
        self.apply_comp_button.setEnabled(False)
        self.save_comp_button.setEnabled(False)
        self.comp_prev_button.setEnabled(False)
        self.comp_next_button.setEnabled(False)

        self.accordion_sections=[]
        self.spike_accordion=AccordionSection("Spike",spike_content,True); self.comp_accordion=AccordionSection("Raw Data Compensation",comp_group,False); self.addsub_accordion=AccordionSection("Image Add/Sub",addsub_group,False)
        self.accordion_sections=[self.spike_accordion,self.comp_accordion,self.addsub_accordion]
        for section in self.accordion_sections: section.opened.connect(self._accordion_opened); rl.addWidget(section)
        rl.addStretch(1)

        output_group = QGroupBox("Output Folder")
        output_layout = QVBoxLayout(output_group)
        self.output_root_label = QLabel("Output: follows opened image folder")
        self.output_root_label.setWordWrap(True)
        output_layout.addWidget(self.output_root_label)
        self.output_root_button = QPushButton("Change Output Folder")
        self.output_root_button.clicked.connect(self.change_output_root)
        output_layout.addWidget(self.output_root_button)
        rl.addWidget(output_group)

        right_scroll = QScrollArea()
        right_scroll.setWidgetResizable(True)
        right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        right_scroll.setFrameShape(QFrame.NoFrame)
        right_scroll.setMinimumWidth(330)
        right_scroll.setWidget(right)
        main_split.addWidget(right_scroll)
        main_split.setCollapsible(0, True)
        main_split.setCollapsible(1, False)
        main_split.setCollapsible(2, True)
        main_split.setSizes([220, 1120, 350])
        layout.addWidget(main_split)
        self.set_view_mode("FFT")
        return page

    def _build_signal_studio(self):
        page = QWidget(); layout = QVBoxLayout(page)
        top = QHBoxLayout()
        self.back_to_workspace = QPushButton("← Back to Image Workspace")
        self.back_to_workspace.clicked.connect(lambda: self.tabs.setCurrentIndex(0))
        top.addWidget(self.back_to_workspace)
        self.signal_combo = QComboBox(); self.signal_combo.currentIndexChanged.connect(self.update_signal_plot)
        self.signal_component = QComboBox(); self.signal_component.addItems(["Magnitude", "Real", "Imaginary", "Phase"])
        self.signal_component.currentTextChanged.connect(self.update_signal_plot)
        self.signal_fft = QCheckBox("Frequency display (FFT)"); self.signal_fft.setChecked(False); self.signal_fft.toggled.connect(self.update_signal_plot)
        remove_signal = QPushButton("Remove Selected"); remove_signal.clicked.connect(self.remove_selected_signal)
        clear = QPushButton("Clear All Signals"); clear.clicked.connect(self.clear_signals)
        top.addWidget(QLabel("Signal")); top.addWidget(self.signal_combo, 1); top.addWidget(self.signal_component); top.addWidget(self.signal_fft); top.addWidget(remove_signal); top.addWidget(clear)
        layout.addLayout(top)
        self.signal_plot = pg.PlotWidget(); self.signal_plot.showGrid(x=True, y=True, alpha=.2)
        layout.addWidget(self.signal_plot, 1)
        note = QLabel("Tracker PFile/TrackerImg drops are automatically registered here as complex 1D raw signals.")
        note.setWordWrap(True); layout.addWidget(note)
        return page

    def _build_metadata(self):
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout()
        self.header_filter = QComboBox(); self.header_filter.setEditable(True); self.header_filter.setInsertPolicy(QComboBox.NoInsert)
        self.header_filter.lineEdit().setPlaceholderText("Filter header tags...")
        self.header_filter.lineEdit().textChanged.connect(self.filter_header)
        export = QPushButton("Export Current Header to Excel"); export.clicked.connect(self.export_header_excel)
        row.addWidget(self.header_filter, 1); row.addWidget(export)
        layout.addLayout(row)
        self.header_table = QTableWidget(0, 6)
        self.header_table.setHorizontalHeaderLabels(["Tag", "Keyword", "Name", "VR", "VM", "Value"])
        self.header_table.horizontalHeader().setStretchLastSection(True)
        self.header_table.setSortingEnabled(True)
        layout.addWidget(self.header_table)
        return page

    def _build_tracker_explorer(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        controls = QHBoxLayout()
        self.tracker_prev_file_button = QPushButton("◀ Previous File")
        self.tracker_next_file_button = QPushButton("Next File ▶")
        self.tracker_prev_file_button.clicked.connect(lambda: self.navigate_tracker_file(-1))
        self.tracker_next_file_button.clicked.connect(lambda: self.navigate_tracker_file(1))
        controls.addWidget(self.tracker_prev_file_button)
        self.tracker_file_combo = QComboBox()
        self.tracker_file_combo.currentIndexChanged.connect(self.select_tracker_file_index)
        controls.addWidget(self.tracker_file_combo)
        controls.addWidget(self.tracker_next_file_button)
        self.tracker_clear_current_button = QPushButton("Clear Current Tracker")
        self.tracker_clear_all_button = QPushButton("Clear All Trackers")
        self.tracker_clear_current_button.clicked.connect(self.clear_current_tracker)
        self.tracker_clear_all_button.clicked.connect(self.clear_all_trackers)
        controls.addWidget(self.tracker_clear_current_button)
        controls.addWidget(self.tracker_clear_all_button)
        self.tracker_drop_text = QLabel(
            "Drop a Tracker PFile / TrackerImg anywhere in the window. "
            "This tab reads and ranks raw lines directly without FFT."
        )
        self.tracker_drop_text.setWordWrap(True)
        controls.addWidget(self.tracker_drop_text, 1)

        controls.addWidget(QLabel("Top lines"))
        self.tracker_top_count = QSpinBox()
        self.tracker_top_count.setRange(1, 100)
        self.tracker_top_count.setValue(1)
        self.tracker_top_count.valueChanged.connect(self._refresh_tracker_ranking)
        controls.addWidget(self.tracker_top_count)

        controls.addWidget(QLabel("Rank by"))
        self.tracker_metric_combo = QComboBox()
        self.tracker_metric_combo.addItems(["Peak", "RMS", "Energy", "Mean magnitude", "Variance"])
        self.tracker_metric_combo.currentTextChanged.connect(self._refresh_tracker_ranking)
        controls.addWidget(self.tracker_metric_combo)

        self.tracker_export_button = QPushButton("Export CSV")
        self.tracker_export_button.clicked.connect(self.export_tracker_lines_csv)
        controls.addWidget(self.tracker_export_button)
        self.tracker_to_workspace_button = QPushButton("Show in Image Workspace")
        self.tracker_to_workspace_button.clicked.connect(self.show_tracker_in_workspace)
        controls.addWidget(self.tracker_to_workspace_button)
        self.tracker_to_1d_button = QPushButton("Show Strongest Line in 1D Studio")
        self.tracker_to_1d_button.clicked.connect(self.send_tracker_to_signal_studio)
        controls.addWidget(self.tracker_to_1d_button)
        layout.addLayout(controls)

        self.tracker_summary = QLabel("No Tracker file loaded.")
        self.tracker_summary.setWordWrap(True)
        layout.addWidget(self.tracker_summary)

        splitter = QSplitter(Qt.Horizontal)

        ranking_box = QGroupBox("Strongest Tracker Line")
        ranking_layout = QVBoxLayout(ranking_box)
        self.tracker_table = QTableWidget(0, 8)
        self.tracker_table.setHorizontalHeaderLabels(
            ["Rank", "Line", "Peak", "RMS", "Energy", "Mean", "Variance", "Relative strength"]
        )
        self.tracker_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.tracker_table.setSelectionMode(QTableWidget.ExtendedSelection)
        self.tracker_table.itemSelectionChanged.connect(self._tracker_selection_changed)
        self.tracker_table.horizontalHeader().setStretchLastSection(True)
        ranking_layout.addWidget(self.tracker_table)

        viewer_box = QGroupBox("Strongest Tracker Raw Line Magnitude — FFT Disabled")
        viewer_layout = QVBoxLayout(viewer_box)
        self.tracker_raw_plot = pg.PlotWidget()
        self.tracker_raw_plot.showGrid(x=True, y=True, alpha=0.25)
        self.tracker_raw_plot.setLabel("bottom", "Sample")
        self.tracker_raw_plot.setLabel("left", "Signal")
        viewer_layout.addWidget(self.tracker_raw_plot, 1)

        viewer_controls = QHBoxLayout()
        viewer_controls.addWidget(QLabel("Component"))
        self.tracker_component_combo = QComboBox()
        self.tracker_component_combo.addItems(["Magnitude", "Real", "Imaginary", "Phase"])
        self.tracker_component_combo.currentTextChanged.connect(self._plot_tracker_selected_lines)
        viewer_controls.addWidget(self.tracker_component_combo)

        self.tracker_previous_button = QPushButton("Previous Strong Line")
        self.tracker_previous_button.clicked.connect(self._select_previous_tracker_line)
        viewer_controls.addWidget(self.tracker_previous_button)

        self.tracker_next_button = QPushButton("Next Strong Line")
        self.tracker_next_button.clicked.connect(self._select_next_tracker_line)
        viewer_controls.addWidget(self.tracker_next_button)
        viewer_controls.addStretch(1)
        viewer_layout.addLayout(viewer_controls)

        self.tracker_metrics_label = QLabel("-")
        self.tracker_metrics_label.setWordWrap(True)
        viewer_layout.addWidget(self.tracker_metrics_label)

        splitter.addWidget(ranking_box)
        splitter.addWidget(viewer_box)
        splitter.setSizes([520, 900])
        layout.addWidget(splitter, 1)

        explanation = QLabel(
            "Tracker Signal Explorer and Spike Detection are separate. "
            "This tab automatically picks high-signal raw lines and displays their original samples without FFT."
        )
        explanation.setWordWrap(True)
        layout.addWidget(explanation)
        return page

    def _build_tracker_position(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        top = QHBoxLayout()
        top.addWidget(QLabel("FFT length"))
        self.position_fft_length = QSpinBox()
        self.position_fft_length.setRange(64, 65536)
        self.position_fft_length.setSingleStep(64)
        self.position_fft_length.setValue(1024)
        top.addWidget(self.position_fft_length)

        top.addWidget(QLabel("FOV (mm)"))
        self.position_fov = QDoubleSpinBox()
        self.position_fov.setRange(1.0, 5000.0)
        self.position_fov.setDecimals(3)
        self.position_fov.setValue(500.0)
        top.addWidget(self.position_fov)

        self.position_use_top = QPushButton("Use Top 3 Tracker Lines")
        self.position_use_top.clicked.connect(self.populate_position_top_lines)
        top.addWidget(self.position_use_top)

        self.position_calculate = QPushButton("Calculate Position")
        self.position_calculate.clicked.connect(self.calculate_tracker_position)
        top.addWidget(self.position_calculate)
        top.addStretch(1)
        layout.addLayout(top)

        offset_group = QGroupBox("Center Offset and Coordinate Convention")
        offset_form = QFormLayout(offset_group)
        offset_row = QHBoxLayout()
        self.position_offset_x = QDoubleSpinBox()
        self.position_offset_y = QDoubleSpinBox()
        self.position_offset_z = QDoubleSpinBox()
        for spin in (self.position_offset_x, self.position_offset_y, self.position_offset_z):
            spin.setRange(-5000.0, 5000.0)
            spin.setDecimals(4)
            spin.setValue(0.0)
        offset_row.addWidget(QLabel("X"))
        offset_row.addWidget(self.position_offset_x)
        offset_row.addWidget(QLabel("Y"))
        offset_row.addWidget(self.position_offset_y)
        offset_row.addWidget(QLabel("Z"))
        offset_row.addWidget(self.position_offset_z)
        offset_form.addRow("CenterOffset (mm)", offset_row)

        self.position_oppose_ap = QCheckBox("Oppose AP coordinate")
        self.position_oppose_ap.setChecked(True)
        offset_form.addRow(self.position_oppose_ap)
        layout.addWidget(offset_group)

        self.position_table = QTableWidget(3, 7)
        self.position_table.setHorizontalHeaderLabels([
            "Line", "Plane", "Rotation (deg)", "Peak bin",
            "Coordinate (mm)", "Peak/Background", "Use"
        ])
        plane_names = ["Axial", "Coronal", "Sagittal"]
        for row in range(3):
            self.position_table.setItem(row, 0, QTableWidgetItem(str(row)))
            plane_combo = QComboBox()
            plane_combo.addItems(plane_names)
            plane_combo.setCurrentIndex(row)
            self.position_table.setCellWidget(row, 1, plane_combo)

            rotation = QDoubleSpinBox()
            rotation.setRange(-360.0, 360.0)
            rotation.setDecimals(4)
            rotation.setValue(0.0)
            self.position_table.setCellWidget(row, 2, rotation)

            self.position_table.setItem(row, 3, QTableWidgetItem("-"))
            self.position_table.setItem(row, 4, QTableWidgetItem("-"))
            self.position_table.setItem(row, 5, QTableWidgetItem("-"))

            use_box = QCheckBox()
            use_box.setChecked(True)
            self.position_table.setCellWidget(row, 6, use_box)

        self.position_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.position_table)

        result_group = QGroupBox("Converted Tracker Position")
        result_layout = QVBoxLayout(result_group)
        self.position_result = QLabel(
            "Load a Tracker file, choose three directional lines, set Plane / Rotation / CenterOffset, "
            "then calculate the position."
        )
        self.position_result.setWordWrap(True)
        self.position_result.setTextInteractionFlags(Qt.TextSelectableByMouse)
        result_layout.addWidget(self.position_result)
        layout.addWidget(result_group)

        note = QLabel(
            "The basic conversion matches the attached TrackerApp structure: FFT peak bin → FOV coordinate → "
            "multi-direction geometric solve → CenterOffset → optional AP sign inversion. "
            "Gradient-map non-linearity correction is not applied unless a vendor gradient adapter is added."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        layout.addStretch(1)
        return page

    def _build_spike_results(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        controls = QHBoxLayout()
        controls.addWidget(QLabel("Robust threshold"))
        self.spike_threshold = QDoubleSpinBox()
        self.spike_threshold.setRange(3.0, 30.0)
        self.spike_threshold.setDecimals(1)
        self.spike_threshold.setSingleStep(0.5)
        self.spike_threshold.setValue(8.0)
        self.spike_threshold.setToolTip(
            "Higher values reduce false detections. Detection combines amplitude and first-difference robust Z scores."
        )
        controls.addWidget(self.spike_threshold)

        self.spike_rescan = QPushButton("Scan Imported RAW Files")
        self.spike_rescan.clicked.connect(self.detect_spikes)
        controls.addWidget(self.spike_rescan)

        self.spike_only_flagged = QCheckBox("Show flagged only")
        self.spike_only_flagged.setChecked(True)
        self.spike_only_flagged.toggled.connect(self._refresh_spike_table)
        controls.addWidget(self.spike_only_flagged)
        controls.addStretch(1)
        layout.addLayout(controls)

        self.spike_summary = QLabel("No spike scan has been run.")
        self.spike_summary.setWordWrap(True)
        layout.addWidget(self.spike_summary)

        self.spike_table = QTableWidget(0, 8)
        self.spike_table.setHorizontalHeaderLabels([
            "Status", "File", "Type", "Score", "Spike groups", "Strongest sample", "Samples checked", "Path"
        ])
        self.spike_table.horizontalHeader().setStretchLastSection(True)
        self.spike_table.setSortingEnabled(True)
        self.spike_table.cellDoubleClicked.connect(self._open_spike_result)
        layout.addWidget(self.spike_table, 1)

        note = QLabel(
            "Double-click a result to open the extracted signal in 1D Signal Studio. "
            "Detected spike locations are overlaid as red symbols."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        return page

    def _build_artifact_detection(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        controls = QHBoxLayout()
        self.detect_artifact_button = QPushButton("Detect Artifact on Selected Images")
        self.detect_artifact_button.clicked.connect(self.detect_artifacts_from_db)
        controls.addWidget(self.detect_artifact_button)
        self.detect_tracker_button = QPushButton("Detect Current Tracker File")
        self.detect_tracker_button.clicked.connect(self.detect_tracker_artifact_from_db)
        controls.addWidget(self.detect_tracker_button)

        self.detect_selected_only = QCheckBox("Selected images only")
        self.detect_selected_only.setChecked(True)
        controls.addWidget(self.detect_selected_only)

        controls.addWidget(QLabel("Minimum samples / class"))
        self.detect_min_samples = QSpinBox()
        self.detect_min_samples.setRange(1, 100)
        self.detect_min_samples.setValue(2)
        controls.addWidget(self.detect_min_samples)
        controls.addStretch(1)
        layout.addLayout(controls)

        self.artifact_detection_summary = QLabel(
            "Open an Artifact DB and run detection. Classes without enough labeled samples are not predicted."
        )
        self.artifact_detection_summary.setWordWrap(True)
        layout.addWidget(self.artifact_detection_summary)

        self.artifact_detection_table = QTableWidget(0, 9)
        self.artifact_detection_table.setHorizontalHeaderLabels([
            "File", "Series", "Predicted Artifact", "Confidence",
            "Distance", "Training Support", "Status", "Alternatives", "Source Path"
        ])
        self.artifact_detection_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.artifact_detection_table.setSelectionMode(QTableWidget.ExtendedSelection)
        self.artifact_detection_table.horizontalHeader().setStretchLastSection(True)
        self.artifact_detection_table.cellDoubleClicked.connect(
            self.open_detected_artifact_image
        )
        layout.addWidget(self.artifact_detection_table, 1)

        classify_row = QHBoxLayout()
        self.send_detection_to_learning_button = QPushButton(
            "Send Selected Detection Rows to Artifact Learning"
        )
        self.send_detection_to_learning_button.clicked.connect(
            self.send_detected_rows_to_learning
        )
        classify_row.addWidget(self.send_detection_to_learning_button)
        classify_row.addStretch(1)
        layout.addLayout(classify_row)

        note = QLabel(
            "Spike is no longer a hard-coded threshold classification. "
            "Spike, Frequency, and other Artifact classes are predicted from the labeled Artifact DB. "
            "The separate Spike Diagnostic tab remains available for raw waveform review."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        return page

    def _build_artifact_learning(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        db_row = QHBoxLayout()
        self.artifact_db_label = QLabel("Artifact DB: Not opened")
        db_row.addWidget(self.artifact_db_label, 1)
        for label, callback in [
            ("Open / Create DB", self.open_artifact_database),
            ("Import DB JSON", self.import_artifact_database),
            ("Export DB JSON", self.export_artifact_database),
        ]:
            button = QPushButton(label)
            button.clicked.connect(callback)
            db_row.addWidget(button)
        layout.addLayout(db_row)

        selection = QGroupBox("Training Image Selection")
        selection_layout = QVBoxLayout(selection)
        self.artifact_selection_label = QLabel(
            "Select one or more DICOM images in Explorer, then add them as training images."
        )
        self.artifact_selection_label.setWordWrap(True)
        selection_layout.addWidget(self.artifact_selection_label)
        selection_buttons = QHBoxLayout()
        self.artifact_add_selected_button = QPushButton("Add Selected Images")
        self.artifact_add_selected_button.clicked.connect(self.collect_selected_artifact_images)
        selection_buttons.addWidget(self.artifact_add_selected_button)
        self.artifact_set_normal_button = QPushButton("Set Current as Normal Reference")
        self.artifact_set_normal_button.clicked.connect(self.set_current_normal_reference)
        selection_buttons.addWidget(self.artifact_set_normal_button)
        self.artifact_load_normal_button = QPushButton("Load Normal Reference")
        self.artifact_load_normal_button.clicked.connect(self.load_normal_reference)
        selection_buttons.addWidget(self.artifact_load_normal_button)
        self.artifact_preview_tracker_button = QPushButton("Preview Tracker Data")
        self.artifact_preview_tracker_button.clicked.connect(self.preview_tracker_in_artifact_learning)
        selection_buttons.addWidget(self.artifact_preview_tracker_button)
        self.artifact_save_tracker_button = QPushButton("Save Tracker Training Sample")
        self.artifact_save_tracker_button.clicked.connect(self.save_tracker_training_sample)
        selection_buttons.addWidget(self.artifact_save_tracker_button)
        selection_buttons.addStretch(1)
        selection_layout.addLayout(selection_buttons)
        preview_row = QHBoxLayout()
        self.artifact_preview_button = QPushButton("Preview Selected Image")
        self.artifact_preview_button.clicked.connect(self.preview_artifact_learning_image)
        preview_row.addWidget(self.artifact_preview_button)
        self.artifact_preview_prev = QPushButton("Previous Selected")
        self.artifact_preview_next = QPushButton("Next Selected")
        self.artifact_preview_prev.clicked.connect(lambda: self.navigate_artifact_preview(-1))
        self.artifact_preview_next.clicked.connect(lambda: self.navigate_artifact_preview(1))
        preview_row.addWidget(self.artifact_preview_prev)
        preview_row.addWidget(self.artifact_preview_next)
        self.artifact_clear_selected_button = QPushButton("Clear Training Selection")
        self.artifact_clear_all_button = QPushButton("Clear Training + Normal")
        self.artifact_clear_selected_button.clicked.connect(self.clear_selected_artifact_training)
        self.artifact_clear_all_button.clicked.connect(self.clear_all_artifact_training)
        preview_row.addWidget(self.artifact_clear_selected_button)
        preview_row.addWidget(self.artifact_clear_all_button)
        preview_row.addStretch(1)
        selection_layout.addLayout(preview_row)
        self.artifact_preview_panel = ImagePanel("Artifact Learning Preview")
        self.artifact_preview_panel.setMinimumHeight(260)
        selection_layout.addWidget(self.artifact_preview_panel)
        self.artifact_preview_position = 0
        self.artifact_normal_label = QLabel("Normal reference: None")
        selection_layout.addWidget(self.artifact_normal_label)
        layout.addWidget(selection)

        classify = QGroupBox("Classification")
        classify_form = QFormLayout(classify)
        type_row = QHBoxLayout()
        self.artifact_type_combo = QComboBox()
        type_row.addWidget(self.artifact_type_combo, 1)
        self.artifact_new_type = QLineEdit()
        self.artifact_new_type.setPlaceholderText("Manual new Artifact type")
        type_row.addWidget(self.artifact_new_type, 1)
        add_type = QPushButton("Add Type")
        add_type.clicked.connect(self.add_artifact_type_manual)
        type_row.addWidget(add_type)
        classify_form.addRow("Artifact", type_row)

        resolution_row = QHBoxLayout()
        self.artifact_resolution_combo = QComboBox()
        resolution_row.addWidget(self.artifact_resolution_combo, 1)
        self.artifact_new_resolution = QLineEdit()
        self.artifact_new_resolution.setPlaceholderText("Manual How to Resolved")
        resolution_row.addWidget(self.artifact_new_resolution, 1)
        add_resolution = QPushButton("Add Resolution")
        add_resolution.clicked.connect(self.add_resolution_manual)
        resolution_row.addWidget(add_resolution)
        classify_form.addRow("How to Resolved", resolution_row)

        self.artifact_notes = QTextEdit()
        self.artifact_notes.setMaximumHeight(90)
        self.artifact_notes.setPlaceholderText("Notes, conditions, service action, reproducibility...")
        classify_form.addRow("Notes", self.artifact_notes)

        save_button = QPushButton("Save Training Samples to Artifact DB")
        save_button.clicked.connect(self.save_artifact_training_samples)
        classify_form.addRow(save_button)
        layout.addWidget(classify)

        self.artifact_training_table = QTableWidget(0, 8)
        self.artifact_training_table.setHorizontalHeaderLabels([
            "ID", "File", "Series", "Instance", "Artifact",
            "How to Resolved", "Normal Compared", "Source Path"
        ])
        self.artifact_training_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.artifact_training_table.setSelectionMode(QTableWidget.ExtendedSelection)
        self.artifact_training_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.artifact_training_table, 1)

        reclassify = QPushButton("Apply Current Classification to Selected DB Rows")
        reclassify.clicked.connect(self.reclassify_selected_db_rows)
        layout.addWidget(reclassify)

        self.artifact_summary = QLabel(
            "Current detector: Spike. Artifact DB supports Frequency and future Artifact detectors."
        )
        self.artifact_summary.setWordWrap(True)
        layout.addWidget(self.artifact_summary)
        return page

    def _build_menu(self):
        file_menu = self.menuBar().addMenu("File")
        export_npz = QAction("Export Image/k-space NPZ", self); export_npz.triggered.connect(self.export_npz); file_menu.addAction(export_npz)
        export_header = QAction("Export DICOM Header Excel", self); export_header.triggered.connect(self.export_header_excel); file_menu.addAction(export_header)
        file_menu.addSeparator(); quit_action = QAction("Exit", self); quit_action.triggered.connect(self.close); file_menu.addAction(quit_action)

    def _apply_style(self):
        self.setStyleSheet("""
        QMainWindow, QWidget { background: #171a1f; color: #e6e9ee; }
        QMenuBar, QMenu { background: #20242b; }
        QTabWidget::pane { border: 1px solid #303946; }
        QTabBar::tab { background: #20242b; padding: 9px 18px; border: 1px solid #303946; }
        QTabBar::tab:selected { background: #1464cc; color: white; font-weight: 600; }
        QTabBar::tab:hover { background: #2b3440; }
        QPushButton, QComboBox, QSpinBox { background: #252b33; border: 1px solid #3b4654; padding: 6px; border-radius: 3px; }
        QPushButton:checked { background: #1464cc; border-color: #2c8cff; }
        QPushButton:hover { border-color: #6594c5; }
        QTreeWidget, QTableWidget { background: #111419; alternate-background-color: #191e25; border: 1px solid #303946; }
        QGroupBox { border: 1px solid #303946; border-radius: 4px; margin-top: 8px; padding-top: 8px; }
        QGroupBox::title { subcontrol-origin: margin; left: 8px; }
        #DropBanner { border: 1px dashed #5c7189; border-radius: 5px; background: #1d232b; }
        #DropBanner[dragActive="true"] { border: 2px solid #2f8cff; background: #20354f; }
        #InfoCard { border: 1px solid #303946; padding: 8px; background: #111419; }
        QSplitter::handle { background: #2f8cff; }
        QSplitter::handle:vertical { height: 4px; }
        QSplitter::handle:horizontal { width: 4px; }
        """)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls(): event.acceptProposedAction()

    def dropEvent(self, event):
        paths = [Path(u.toLocalFile()) for u in event.mimeData().urls() if u.isLocalFile()]
        if paths: self.import_paths(paths); event.acceptProposedAction()

    def _make_progress(self, title: str, maximum: int = 0) -> QProgressDialog:
        progress = QProgressDialog("Preparing...", "Cancel", 0, maximum, self)
        progress.setWindowTitle(title)
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)
        progress.setAutoClose(False)
        progress.setAutoReset(False)
        progress.setValue(0)
        progress.show()
        QApplication.processEvents()
        return progress

    def _progress_step(self, progress: QProgressDialog, value: int, text: str) -> bool:
        progress.setLabelText(text)
        if progress.maximum() > 0:
            progress.setValue(min(value, progress.maximum()))
        QApplication.processEvents()
        return not progress.wasCanceled()

    def load_bitmap_image(self, path: Path):
        qimage = QImage(str(path))
        if qimage.isNull():
            raise ValueError(f"Unable to read image: {path}")
        gray = qimage.convertToFormat(QImage.Format_Grayscale8)
        width = gray.width()
        height = gray.height()
        ptr = gray.bits()
        array = np.frombuffer(ptr, dtype=np.uint8, count=gray.sizeInBytes())
        array = array.reshape((height, gray.bytesPerLine()))[:, :width].copy()

        self.current_image = array.astype(float)
        self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)
        self.current_ds = None
        self.current_source = str(path)
        self.source_kind = "bitmap"
        self.view_mode = "Original"
        self.original_window_level = None
        self.original_dynamic_range = None
        self.btn_original.setChecked(True)
        self.btn_fft.setChecked(False)
        self.btn_both.setChecked(False)

        self.processed_images[str(path)] = self.current_image.copy()
        self.processed_sources[str(path)] = path
        self._add_external_image_tree_item(path)
        self._update_output_root_label()
        self.refresh_images()
        self.info.setText(
            f"File: {path.name}\nType: Bitmap image\n"
            f"Size: {width} × {height}\nOriginal Image only"
        )

    def _add_external_image_tree_item(self, path: Path):
        root = None
        for index in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(index)
            if item.text(0) == "Image Files":
                root = item
                break
        if root is None:
            root = QTreeWidgetItem(["Image Files"])
            self.tree.addTopLevelItem(root)
        child = QTreeWidgetItem([path.name])
        child.setData(0, Qt.UserRole, ("processed", str(path)))
        root.addChild(child)
        root.setExpanded(True)
        self.tree.setCurrentItem(child)

    def import_paths(self, paths: list[Path]):
        progress = self._make_progress("Importing MRI Data", 0)
        try:
            progress.setLabelText("Collecting dropped files and folders...")
            QApplication.processEvents()
            files: list[Path] = []
            for p in paths:
                if progress.wasCanceled():
                    self.statusBar().showMessage("Import canceled")
                    return
                if p.is_dir():
                    progress.setLabelText(f"Scanning folder: {p.name}")
                    QApplication.processEvents()
                    files.extend([x for x in p.rglob('*') if x.is_file()])
                elif p.suffix.lower() == '.zip':
                    progress.setLabelText(f"Extracting ZIP: {p.name}")
                    QApplication.processEvents()
                    files.extend(self.extract_zip(p, progress))
                else:
                    files.append(p)

            # Keep unique files for later batch operations such as Spike detection.
            known = {str(p.resolve()) for p in self.imported_paths if p.exists()}
            for imported in files:
                try:
                    key = str(imported.resolve())
                except Exception:
                    key = str(imported)
                if key not in known:
                    self.imported_paths.append(imported)
                    known.add(key)

            progress.setRange(0, max(len(files), 1))
            progress.setValue(0)
            dicoms, deferred = [], []
            for index, p in enumerate(files, start=1):
                if not self._progress_step(progress, index - 1, f"Checking {index}/{len(files)}: {p.name}"):
                    self.statusBar().showMessage("Import canceled")
                    return
                try:
                    entry = self.read_dicom(p)
                    dicoms.append(entry)
                    continue
                except Exception:
                    deferred.append(p)
                progress.setValue(index)

            if dicoms:
                progress.setLabelText(f"Sorting and displaying {len(dicoms)} DICOM images...")
                QApplication.processEvents()
                dicoms.sort(key=lambda e: e.sort_key)
                self.dicom_entries = dicoms
                self.populate_dicom_tree()
                self.show_dicom(0)

            total_deferred = len(deferred)
            for n, p in enumerate(deferred, start=1):
                if progress.wasCanceled():
                    self.statusBar().showMessage("Import canceled")
                    return
                progress.setLabelText(f"Loading additional data {n}/{total_deferred}: {p.name}")
                QApplication.processEvents()
                if self.looks_tracker(p):
                    self.load_tracker(p)
                elif p.suffix.lower() in {'.csv', '.txt', '.npy', '.npz'}:
                    self.load_signal_file(p)
                elif p.suffix.lower() in {'.jpg', '.jpeg', '.png', '.bmp'}:
                    self.load_bitmap_image(p)
                elif p.suffix.lower() in {'.raw', '.bin', '.dat'}:
                    self.statusBar().showMessage(
                        f"Generic binary detected: {p.name}; Tracker PFile is auto-supported in this prototype"
                    )

            if not dicoms and not deferred:
                QMessageBox.information(self, "No files", "No supported files were found.")
            else:
                self.statusBar().showMessage(
                    f"Import completed: {len(dicoms)} DICOM, {len(deferred)} other file(s)"
                )
        except Exception as exc:
            QMessageBox.critical(self, "Import error", str(exc))
        finally:
            progress.setValue(progress.maximum())
            progress.close()

    def extract_zip(self, path: Path, parent_progress: Optional[QProgressDialog] = None) -> list[Path]:
        root = Path(tempfile.mkdtemp(prefix='mri_fft_'))
        self.temp_dirs.append(root)
        with zipfile.ZipFile(path) as z:
            members = z.infolist()
            for index, m in enumerate(members, start=1):
                if parent_progress is not None:
                    parent_progress.setLabelText(f"Extracting {path.name}: {index}/{len(members)}")
                    QApplication.processEvents()
                    if parent_progress.wasCanceled():
                        return []
                target = (root / m.filename).resolve()
                if not str(target).startswith(str(root.resolve())):
                    raise ValueError("Unsafe ZIP member")
                z.extract(m, root)
        return [p for p in root.rglob('*') if p.is_file()]

    def read_dicom(self, path: Path) -> DicomEntry:
        ds = pydicom.dcmread(str(path), force=False)
        if not hasattr(ds, 'PixelData'): raise ValueError('No pixel data')
        arr = ds.pixel_array
        if arr.ndim == 3: arr = arr[0]
        if arr.ndim != 2: raise ValueError('Not 2D')
        arr = arr.astype(float) * float(getattr(ds, 'RescaleSlope', 1)) + float(getattr(ds, 'RescaleIntercept', 0))
        instance = int(getattr(ds, 'InstanceNumber', 0) or 0)
        pos = getattr(ds, 'ImagePositionPatient', None)
        z = float(pos[2]) if pos is not None and len(pos) >= 3 else float(instance)
        return DicomEntry(path, ds, arr, (z, instance, path.name.lower()))

    def populate_dicom_tree(self):
        self.tree.clear()
        root = QTreeWidgetItem([f"DICOM Images ({len(self.dicom_entries)})"])
        self.tree.addTopLevelItem(root)

        grouped = {}
        for index, entry in enumerate(self.dicom_entries):
            series_uid = str(getattr(entry.ds, "SeriesInstanceUID", "") or "UnknownSeries")
            description = str(
                getattr(entry.ds, "SeriesDescription", "")
                or getattr(entry.ds, "ProtocolName", "")
                or "Unnamed Series"
            )
            series_number = str(getattr(entry.ds, "SeriesNumber", "") or "")
            grouped.setdefault((series_uid, description, series_number), []).append((index, entry))

        for (series_uid, description, series_number), entries in grouped.items():
            prefix = f"Series {series_number} — " if series_number else ""
            series_item = QTreeWidgetItem([f"{prefix}{description} ({len(entries)})"])
            series_item.setData(0, Qt.UserRole, ("series", series_uid))
            series_item.setToolTip(0, f"Series UID: {series_uid}")
            root.addChild(series_item)

            for index, entry in entries:
                instance = str(getattr(entry.ds, "InstanceNumber", index + 1) or index + 1)
                rows = str(getattr(entry.ds, "Rows", "") or "")
                cols = str(getattr(entry.ds, "Columns", "") or "")
                bits = str(getattr(entry.ds, "BitsStored", "") or "")
                detail = f"Inst {instance}"
                if rows and cols:
                    detail += f"  {rows}×{cols}"
                if bits:
                    detail += f"  {bits}bit"

                item = QTreeWidgetItem([f"{entry.path.name}  |  {detail}"])
                item.setData(0, Qt.UserRole, ("dicom", index))
                item.setToolTip(0, f"{entry.path}\nSeries: {description}\nInstance: {instance}")
                series_item.addChild(item)

            series_item.setExpanded(False)

        root.setExpanded(True)


    def show_dicom(self, index: int):
        if not self.dicom_entries:
            return

        index = max(0, min(int(index), len(self.dicom_entries) - 1))
        entry = self.dicom_entries[index]

        self.current_image = np.asarray(entry.image).copy()
        self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)
        self.current_ds = entry.ds
        self.current_source = str(entry.path)
        self.source_kind = "dicom"
        self.slice_index = index

        self.compensation_base_image = np.asarray(self.current_image).copy()
        self.compensation_base_kspace = np.asarray(self.current_kspace).copy()
        self.compensation_history = []
        self.compensation_history_index = -1
        self.compensation_preview = None
        self._update_compensation_history_buttons()

        self.original_window_level = None
        self.original_dynamic_range = None
        if self.raw_window_level is None or self.raw_dynamic_range is None:
            self._set_levels_for_target("Raw Data", np.log1p(np.abs(self.current_kspace)))

        self.view_mode = "Both"
        self.btn_both.setChecked(True)
        self.btn_fft.setChecked(False)
        self.btn_original.setChecked(False)

        self.slice_label.setText(f"Slice: {index + 1}/{len(self.dicom_entries)}")
        self.info.setText(self.dicom_info(entry.ds, entry.path, index))
        self._select_tree_dicom_index(index)
        self._update_output_root_label()
        self.refresh_images()
        QApplication.processEvents()


    def dicom_info(self, ds, path, index):
        spacing = getattr(ds, 'PixelSpacing', ['-', '-'])
        return (f"File: {path.name}\nType: DICOM\nSize: {getattr(ds,'Columns','-')} × {getattr(ds,'Rows','-')}\n"
                f"Bit Depth: {getattr(ds,'BitsAllocated','-')} bit\nPixel Spacing: {spacing}\n"
                f"Series: {getattr(ds,'SeriesDescription','-')}\nInstance: {index+1}/{len(self.dicom_entries)}\n"
                f"TE / TR: {getattr(ds,'EchoTime','-')} / {getattr(ds,'RepetitionTime','-')} ms")

    def change_slice(self, delta):
        if self.dicom_entries: self.show_dicom(getattr(self, 'slice_index', 0) + delta)

    def looks_tracker(self, p: Path) -> bool:
        n = p.name.lower()
        if 'trackerimg' in n or 'pfile' in n: return True
        if p.suffix == '' and p.stat().st_size > 4096:
            try:
                rev = np.frombuffer(p.read_bytes()[:4], dtype='<f4')[0]
                return np.isfinite(rev) and 1 < rev < 100
            except Exception: return False
        return False

    def show_tracker_in_workspace(self):
        if self.tracker_matrix is None:
            QMessageBox.information(self, "Tracker", "Load a Tracker file first.")
            return
        self.workspace_source_combo.setCurrentText("Tracker Raw Magnitude")
        self.current_kspace = np.asarray(self.tracker_matrix).copy()
        self.current_recon = ifft2c(self.current_kspace)
        self.current_image = np.abs(self.current_recon)
        self.current_source = str(self.tracker_source_path or "Tracker")
        self.tabs.setCurrentIndex(0)
        self.refresh_images()

    def _capture_tracker_state(self, path: Path, matrix: np.ndarray, matrix_size: int, offset: int):
        magnitude = np.abs(matrix).astype(np.float64)
        metrics=[]
        for i,line in enumerate(magnitude):
            metrics.append({"line":i,"peak":float(np.max(line)),"rms":float(np.sqrt(np.mean(line**2))),"energy":float(np.sum(line**2)),"mean":float(np.mean(line)),"variance":float(np.var(line)),"relative":0.0})
        rms=np.array([m["rms"] for m in metrics],float); lo=float(np.min(rms)); hi=float(np.max(rms)); span=max(hi-lo,np.finfo(float).eps)
        for m in metrics: m["relative"]=100.0*(m["rms"]-lo)/span
        strongest=max(metrics,key=lambda m:m["rms"]); idx=int(strongest["line"])
        return {"path":path,"matrix":np.asarray(matrix).copy(),"matrix_size":matrix_size,"offset":offset,"line_metrics":metrics,"strongest_line_index":idx,"strongest_line":np.asarray(matrix[idx]).copy(),"reconstructed_image":np.abs(ifft2c(matrix))}

    def _apply_tracker_state(self, index: int):
        if not (0 <= index < len(self.tracker_files)): return
        self.tracker_file_index=index; s=self.tracker_files[index]
        self.tracker_source_path=s["path"]; self.tracker_matrix=np.asarray(s["matrix"]).copy(); self.tracker_line_metrics=list(s["line_metrics"])
        self.tracker_strongest_line_index=int(s["strongest_line_index"]); self.tracker_strongest_line=np.asarray(s["strongest_line"]).copy(); self.tracker_reconstructed_image=np.asarray(s["reconstructed_image"]).copy(); self.tracker_shared_name=s["path"].name; self.tracker_selected_lines=[self.tracker_strongest_line_index]
        self.tracker_file_combo.blockSignals(True); self.tracker_file_combo.clear(); self.tracker_file_combo.addItems([x["path"].name for x in self.tracker_files]); self.tracker_file_combo.setCurrentIndex(index); self.tracker_file_combo.blockSignals(False)
        self._refresh_tracker_ranking(); self._plot_tracker_selected_lines(); self._update_tracker_navigation_buttons()
        self.tracker_summary.setText(f"{s['path'].name} | {index+1}/{len(self.tracker_files)} | Matrix {s['matrix_size']} × {s['matrix_size']} | Strongest line {self.tracker_strongest_line_index}")
        signal_name=f"{s['path'].name} | Strongest line {self.tracker_strongest_line_index}"
        self.signals=[x for x in self.signals if not str(x.get('name','')).startswith(f"{s['path'].name} | Strongest line")]
        self.signals.append({"name":signal_name,"data":self.tracker_strongest_line.copy()}); self.signal_combo.clear(); self.signal_combo.addItems([x["name"] for x in self.signals])
        if self.workspace_source_combo.currentText().startswith("Tracker"): self.change_workspace_source(self.workspace_source_combo.currentText())

    def _update_tracker_navigation_buttons(self):
        has=bool(self.tracker_files)
        self.tracker_prev_file_button.setEnabled(has and self.tracker_file_index>0); self.tracker_next_file_button.setEnabled(has and self.tracker_file_index<len(self.tracker_files)-1); self.tracker_clear_current_button.setEnabled(has); self.tracker_clear_all_button.setEnabled(has)

    def select_tracker_file_index(self, index:int):
        if 0 <= index < len(self.tracker_files): self._apply_tracker_state(index)

    def navigate_tracker_file(self, step:int):
        target=self.tracker_file_index+int(step)
        if 0 <= target < len(self.tracker_files): self._apply_tracker_state(target)

    def clear_current_tracker(self):
        if not self.tracker_files: return
        if QMessageBox.question(self,"Clear Tracker",f"Remove current Tracker file?\n{self.tracker_files[self.tracker_file_index]['path'].name}") != QMessageBox.Yes: return
        self.tracker_files.pop(self.tracker_file_index)
        if self.tracker_files: self._apply_tracker_state(min(self.tracker_file_index,len(self.tracker_files)-1))
        else: self._reset_tracker_state()

    def clear_all_trackers(self):
        if not self.tracker_files: return
        if QMessageBox.question(self,"Clear All Trackers","Clear all imported Tracker files?") != QMessageBox.Yes: return
        self.tracker_files.clear(); self._reset_tracker_state()

    def _reset_tracker_state(self):
        self.tracker_file_index=-1; self.tracker_matrix=None; self.tracker_source_path=None; self.tracker_line_metrics=[]; self.tracker_selected_lines=[]; self.tracker_strongest_line=None; self.tracker_strongest_line_index=-1; self.tracker_reconstructed_image=None; self.tracker_shared_name=""
        self.tracker_file_combo.clear(); self.tracker_table.setRowCount(0); self.tracker_raw_plot.clear(); self.tracker_summary.setText("No Tracker file loaded."); self.tracker_metrics_label.setText("-"); self._update_tracker_navigation_buttons()

    def keyPressEvent(self, event):
        if self.tabs.currentIndex() in (3,4,5,6,7):
            if event.key()==Qt.Key_Left: self.navigate_tracker_file(-1); event.accept(); return
            if event.key()==Qt.Key_Right: self.navigate_tracker_file(1); event.accept(); return
        super().keyPressEvent(event)

    def load_tracker(self, path: Path):
        raw = path.read_bytes()
        best = None
        for matrix in (512, 384, 320, 256, 192, 160, 128, 96, 64):
            need = matrix * matrix * 4
            if len(raw) < need:
                continue
            offset = len(raw) - need
            vals = np.frombuffer(raw, dtype="<i2", count=matrix * matrix * 2, offset=offset)
            complex_data = vals[0::2].astype(float) + 1j * vals[1::2].astype(float)
            raw_matrix = complex_data.reshape(matrix, matrix)

            # Candidate selection uses line statistics only. No FFT is used for Tracker Signal Explorer.
            line_rms = np.sqrt(np.mean(np.abs(raw_matrix) ** 2, axis=1))
            score = float(np.percentile(line_rms, 99) / (np.median(line_rms) + 1e-9))
            if best is None or score > best[0]:
                best = (score, matrix, offset, raw_matrix)

        if best is None:
            raise ValueError("No Tracker matrix candidate found")

        _, matrix, offset, raw_matrix = best
        state=self._capture_tracker_state(path,raw_matrix,matrix,offset)
        existing=next((i for i,x in enumerate(self.tracker_files) if x["path"]==path),None)
        if existing is None: self.tracker_files.append(state); index=len(self.tracker_files)-1
        else: self.tracker_files[existing]=state; index=existing
        self._apply_tracker_state(index)
        self.tree.clear(); root=QTreeWidgetItem([f"Tracker Files ({len(self.tracker_files)})"]); self.tree.addTopLevelItem(root)
        for i,s in enumerate(self.tracker_files):
            item=QTreeWidgetItem([s["path"].name]); item.setData(0,Qt.UserRole,("tracker_file",i)); root.addChild(item)
            child=QTreeWidgetItem([f"Strongest line: {s['strongest_line_index']}"]); child.setData(0,Qt.UserRole,("tracker_file",i)); item.addChild(child)
        root.setExpanded(True); self.tabs.setCurrentIndex(3); self.statusBar().showMessage(f"Loaded Tracker {index+1}/{len(self.tracker_files)}: {path.name}")

    def load_signal_file(self, path: Path):
        if path.suffix.lower() == '.npy': arr = np.load(path, allow_pickle=False)
        elif path.suffix.lower() == '.npz':
            z = np.load(path, allow_pickle=False); arr = z[list(z.keys())[0]]
        else:
            rows=[]
            with open(path, encoding='utf-8-sig', errors='replace') as f:
                for line in f:
                    nums=[]
                    for token in line.strip().replace(';', ',').split(','):
                        try: nums.append(float(token.strip()))
                        except ValueError: pass
                    if nums: rows.append(nums)
            if not rows: return
            arr = np.array([r[0]+1j*r[1] if len(r)>1 else r[0] for r in rows])
        arr=np.asarray(arr).squeeze()
        if arr.ndim == 1: self.add_signal(arr, path.name)
        elif arr.ndim == 2:
            self.current_image = np.abs(arr); self.current_kspace = fft2c(arr); self.current_recon = ifft2c(self.current_kspace); self.refresh_images()

    def add_signal(self, signal, name):
        signal=np.asarray(signal).squeeze()
        if signal.ndim != 1 or signal.size < 2: return
        self.signals.append({'name': name, 'data': signal})
        self.active_spike_indices = np.array([], dtype=int)
        self.signal_combo.addItem(name)
        self.signal_combo.setCurrentIndex(len(self.signals)-1)
        self.update_signal_plot(); self.update_tracker_preview(signal)

    def clear_signals(self):
        self.signals.clear(); self.signal_combo.clear(); self.signal_plot.clear(); self.tracker_plot.clear()

    def update_signal_plot(self):
        self.signal_plot.clear(); idx=self.signal_combo.currentIndex()
        if idx < 0 or idx >= len(self.signals): return
        data=np.asarray(self.signals[idx]['data']); component=self.signal_component.currentText()
        if self.signal_fft.isChecked(): data=np.fft.fftshift(np.fft.fft(data)); self.signal_plot.setLabel('bottom','Frequency bin')
        else: self.signal_plot.setLabel('bottom','Sample')
        y=self.component(data, component)
        self.signal_plot.plot(y)
        if self.active_spike_indices.size:
            valid = self.active_spike_indices[self.active_spike_indices < len(y)]
            if valid.size:
                scatter = pg.ScatterPlotItem(
                    x=valid,
                    y=np.asarray(y)[valid],
                    pen=pg.mkPen("#ff3b3b"),
                    brush=pg.mkBrush("#ff3b3b"),
                    size=9,
                    symbol="x",
                )
                self.signal_plot.addItem(scatter)

    def update_tracker_preview(self, signal):
        self.tracker_plot.clear(); self.tracker_plot.plot(np.abs(np.asarray(signal)))

    def _analyze_tracker_lines(self):
        self.tracker_line_metrics = []
        if self.tracker_matrix is None:
            return

        magnitude = np.abs(self.tracker_matrix).astype(np.float64)
        for line_index, line in enumerate(magnitude):
            self.tracker_line_metrics.append({
                "line": line_index,
                "peak": float(np.max(line)),
                "rms": float(np.sqrt(np.mean(line ** 2))),
                "energy": float(np.sum(line ** 2)),
                "mean": float(np.mean(line)),
                "variance": float(np.var(line)),
                "relative": 0.0,
            })

        rms_values = np.array([item["rms"] for item in self.tracker_line_metrics], dtype=float)
        low = float(np.min(rms_values))
        high = float(np.max(rms_values))
        span = max(high - low, np.finfo(float).eps)
        for item in self.tracker_line_metrics:
            item["relative"] = 100.0 * (item["rms"] - low) / span

    def _tracker_metric_key(self) -> str:
        return {
            "Peak": "peak",
            "RMS": "rms",
            "Energy": "energy",
            "Mean magnitude": "mean",
            "Variance": "variance",
        }.get(self.tracker_metric_combo.currentText(), "peak")

    def _refresh_tracker_ranking(self):
        if not hasattr(self, "tracker_table"):
            return
        if not self.tracker_line_metrics:
            self.tracker_table.setRowCount(0)
            return

        key = self._tracker_metric_key()
        ranked = sorted(self.tracker_line_metrics, key=lambda item: item[key], reverse=True)
        ranked = ranked[: self.tracker_top_count.value()]

        self.tracker_table.blockSignals(True)
        self.tracker_table.setRowCount(len(ranked))
        for row, item in enumerate(ranked):
            values = [
                row + 1,
                item["line"],
                f'{item["peak"]:.6g}',
                f'{item["rms"]:.6g}',
                f'{item["energy"]:.6g}',
                f'{item["mean"]:.6g}',
                f'{item["variance"]:.6g}',
                f'{item["relative"]:.1f}%',
            ]
            for col, value in enumerate(values):
                table_item = QTableWidgetItem(str(value))
                table_item.setData(Qt.UserRole, item["line"])
                self.tracker_table.setItem(row, col, table_item)
        self.tracker_table.resizeColumnsToContents()
        self.tracker_table.blockSignals(False)

        if ranked:
            self.tracker_table.selectRow(0)
            self._tracker_selection_changed()

    def _tracker_selection_changed(self):
        rows = sorted({item.row() for item in self.tracker_table.selectedItems()})
        selected = []
        for row in rows:
            item = self.tracker_table.item(row, 1)
            if item is not None:
                selected.append(int(item.data(Qt.UserRole)))
        self.tracker_selected_lines = selected[:8]
        self._plot_tracker_selected_lines()

    def _tracker_component(self, line: np.ndarray) -> np.ndarray:
        mode = self.tracker_component_combo.currentText()
        if mode == "Real":
            return np.real(line)
        if mode == "Imaginary":
            return np.imag(line)
        if mode == "Phase":
            return np.angle(line)
        return np.abs(line)

    def _plot_tracker_selected_lines(self):
        if not hasattr(self, "tracker_raw_plot"):
            return
        self.tracker_raw_plot.clear()
        if self.tracker_matrix is None or not self.tracker_selected_lines:
            self.tracker_metrics_label.setText("-")
            return

        summaries = []
        for line_index in self.tracker_selected_lines:
            raw_line = self.tracker_matrix[line_index]
            values = np.asarray(self._tracker_component(raw_line), dtype=float)
            self.tracker_raw_plot.plot(values)

            metric = next(
                (item for item in self.tracker_line_metrics if item["line"] == line_index),
                None,
            )
            if metric:
                summaries.append(
                    f'Line {line_index}: Peak {metric["peak"]:.6g}, '
                    f'RMS {metric["rms"]:.6g}, Energy {metric["energy"]:.6g}'
                )
        self.tracker_metrics_label.setText(" | ".join(summaries))

    def _select_next_tracker_line(self):
        row = self.tracker_table.currentRow()
        if 0 <= row < self.tracker_table.rowCount() - 1:
            self.tracker_table.clearSelection()
            self.tracker_table.selectRow(row + 1)

    def _select_previous_tracker_line(self):
        row = self.tracker_table.currentRow()
        if row > 0:
            self.tracker_table.clearSelection()
            self.tracker_table.selectRow(row - 1)

    def export_tracker_lines_csv(self):
        if not self.tracker_line_metrics:
            QMessageBox.information(self, "Tracker Export", "Load a Tracker file first.")
            return
        filename, _ = QFileDialog.getSaveFileName(
            self, "Export Tracker Line Metrics", "tracker_line_metrics.csv", "CSV files (*.csv)"
        )
        if not filename:
            return
        if not filename.lower().endswith(".csv"):
            filename += ".csv"

        import csv
        with open(filename, "w", newline="", encoding="utf-8-sig") as stream:
            writer = csv.writer(stream)
            writer.writerow(["Line", "Peak", "RMS", "Energy", "MeanMagnitude", "Variance", "RelativeStrength"])
            for item in sorted(self.tracker_line_metrics, key=lambda value: value["line"]):
                writer.writerow([
                    item["line"], item["peak"], item["rms"], item["energy"],
                    item["mean"], item["variance"], item["relative"]
                ])
        self.statusBar().showMessage(f"Tracker metrics exported: {filename}")

    def _raw_candidate_paths(self) -> list[Path]:
        candidates = []
        seen = set()
        for path in self.imported_paths:
            if not path.exists() or not path.is_file():
                continue
            suffix = path.suffix.lower()
            if self.looks_tracker(path) or suffix in {".raw", ".bin", ".dat", ".pfile"}:
                key = str(path.resolve())
                if key not in seen:
                    candidates.append(path)
                    seen.add(key)
        return candidates

    @staticmethod
    def _robust_z(values: np.ndarray) -> np.ndarray:
        values = np.asarray(values, dtype=np.float64)
        if values.size == 0:
            return values
        median = np.nanmedian(values)
        mad = np.nanmedian(np.abs(values - median))
        scale = max(1.4826 * mad, np.finfo(float).eps)
        return np.abs(values - median) / scale

    @staticmethod
    def _group_spike_indices(indices: np.ndarray) -> list[np.ndarray]:
        indices = np.asarray(indices, dtype=int)
        if indices.size == 0:
            return []
        cuts = np.where(np.diff(indices) > 1)[0] + 1
        return [group for group in np.split(indices, cuts) if group.size]

    def _extract_tracker_signal(self, path: Path) -> tuple[np.ndarray, str]:
        raw = path.read_bytes()
        best = None
        for matrix in (512, 384, 320, 256, 192, 160, 128, 96, 64):
            need = matrix * matrix * 4
            if len(raw) < need:
                continue
            offset = len(raw) - need
            vals = np.frombuffer(raw, dtype="<i2", count=matrix * matrix * 2, offset=offset)
            signal = vals[0::2].astype(np.float64) + 1j * vals[1::2].astype(np.float64)
            image = ifft2c(signal.reshape(matrix, matrix))
            contrast = np.percentile(np.abs(image), 99) / (np.median(np.abs(image)) + 1e-9)
            if best is None or contrast > best[0]:
                best = (contrast, signal, f"Tracker complex int16 {matrix}x{matrix}, offset {offset}")
        if best is None:
            raise ValueError("No valid Tracker complex matrix candidate")
        return best[1], best[2]

    def _extract_generic_raw_signal(self, path: Path) -> tuple[np.ndarray, str]:
        # Limit analysis memory while retaining enough data for spike screening.
        max_bytes = 32 * 1024 * 1024
        size = path.stat().st_size
        offset = max(0, size - max_bytes)
        if offset % 2:
            offset += 1
        with open(path, "rb") as stream:
            stream.seek(offset)
            raw = np.fromfile(stream, dtype="<i2")
        if raw.size < 8:
            raise ValueError("Not enough int16 samples")
        # Treat even/odd pairs as complex when possible. Magnitude analysis is
        # resistant to phase rotation and works for many MRI raw layouts.
        if raw.size >= 16 and raw.size % 2 == 0:
            signal = raw[0::2].astype(np.float64) + 1j * raw[1::2].astype(np.float64)
            description = f"Generic complex int16 tail, byte offset {offset}"
        else:
            signal = raw.astype(np.float64)
            description = f"Generic real int16 tail, byte offset {offset}"
        return signal, description

    def _analyze_spike_signal(self, signal: np.ndarray, threshold: float) -> dict:
        signal = np.asarray(signal).squeeze()
        magnitude = np.abs(signal).astype(np.float64)
        finite = np.isfinite(magnitude)
        if magnitude.size < 8 or not np.any(finite):
            raise ValueError("Signal has insufficient valid samples")
        replacement = np.nanmedian(magnitude[finite])
        magnitude = np.where(finite, magnitude, replacement)

        amplitude_z = self._robust_z(magnitude)
        first_difference = np.abs(np.diff(magnitude, prepend=magnitude[0]))
        difference_z = self._robust_z(first_difference)

        combined = np.maximum(amplitude_z, difference_z)
        raw_indices = np.flatnonzero(combined >= threshold)
        groups = self._group_spike_indices(raw_indices)

        # Represent each consecutive group by its strongest sample.
        representatives = []
        for group in groups:
            representatives.append(int(group[np.argmax(combined[group])]))
        representatives = np.asarray(representatives, dtype=int)

        strongest = int(np.argmax(combined))
        score = float(combined[strongest])
        return {
            "score": score,
            "flagged": bool(representatives.size and score >= threshold),
            "indices": representatives,
            "groups": len(groups),
            "strongest": strongest,
            "samples": int(magnitude.size),
        }

    def _selected_dicom_indices(self):
        indices = []
        for item in self.tree.selectedItems():
            data = item.data(0, Qt.UserRole)
            if data and data[0] == "dicom":
                indices.append(int(data[1]))
        if not indices and self.dicom_entries:
            indices = [getattr(self, "slice_index", 0)]
        return sorted(set(indices))

    def _spike_range_percent(self):
        mapping = {"Large": 100, "Mid": 70, "Small": 40}
        if self.spike_range_combo.currentText() == "Scale":
            return int(self.spike_scale_slider.value())
        return mapping.get(self.spike_range_combo.currentText(), 100)

    def _suppress_image_spikes(self, image: np.ndarray):
        source = np.asarray(image, dtype=float)
        kspace = fft2c(source)
        magnitude = np.abs(kspace)
        rows, cols = magnitude.shape
        cy, cx = rows // 2, cols // 2

        area_fraction = max(min(self._spike_range_percent() / 100.0, 1.0), 0.1)
        side_fraction = np.sqrt(area_fraction)
        half_h = max(4, int(rows * side_fraction / 2.0))
        half_w = max(4, int(cols * side_fraction / 2.0))
        y0, y1 = max(1, cy - half_h), min(rows - 1, cy + half_h)
        x0, x1 = max(1, cx - half_w), min(cols - 1, cx + half_w)

        # Robust local background from eight adjacent pixels.
        neighbor_stack = np.stack([
            np.roll(magnitude, (dy, dx), axis=(0, 1))
            for dy, dx in [
                (-1, -1), (-1, 0), (-1, 1),
                (0, -1),           (0, 1),
                (1, -1),  (1, 0),  (1, 1),
            ]
        ], axis=0)
        local_median = np.median(neighbor_stack, axis=0)
        local_mad = np.median(np.abs(neighbor_stack - local_median[None, ...]), axis=0)
        local_scale = np.maximum(1.4826 * local_mad, np.finfo(float).eps)

        region = magnitude[y0:y1, x0:x1]
        region_log = np.log1p(region)
        global_median = float(np.median(region_log))
        global_mad = float(np.median(np.abs(region_log - global_median)))
        global_scale = max(1.4826 * global_mad, np.finfo(float).eps)

        settings = {
            "Wide": (8.0, 7.0),
            "Mid": (5.0, 5.0),
            "Fine": (3.0, 3.5),
        }
        ratio_limit, global_z_limit = settings.get(
            self.spike_level_combo.currentText(), (5.0, 5.0)
        )

        ratio = magnitude / np.maximum(local_median, np.finfo(float).eps)
        global_z = (np.log1p(magnitude) - global_median) / global_scale

        mask = np.zeros_like(magnitude, dtype=bool)
        mask[y0:y1, x0:x1] = True
        # Protect the central low-frequency region.
        dc_radius = max(3, int(min(rows, cols) * 0.025))
        yy, xx = np.ogrid[:rows, :cols]
        mask &= ((yy - cy) ** 2 + (xx - cx) ** 2) > dc_radius ** 2

        candidate_mask = mask & (ratio > ratio_limit) & (global_z > global_z_limit)
        candidate_points = np.argwhere(candidate_mask)

        # Rank strongest candidates and cap correction to avoid over-processing.
        if candidate_points.size:
            scores = np.array([
                ratio[y, x] * max(global_z[y, x], 0.0)
                for y, x in candidate_points
            ])
            order = np.argsort(scores)[::-1]
            maximum_candidates = {
                "Wide": 40,
                "Mid": 120,
                "Fine": 300,
            }.get(self.spike_level_combo.currentText(), 120)
            candidate_points = candidate_points[order[:maximum_candidates]]

        corrected = kspace.copy()
        candidates = []

        def replace_point(y: int, x: int):
            ya, yb = max(0, y - 2), min(rows, y + 3)
            xa, xb = max(0, x - 2), min(cols, x + 3)
            patch = corrected[ya:yb, xa:xb].copy()
            patch_mag = magnitude[ya:yb, xa:xb]
            keep = patch_mag < np.percentile(patch_mag, 75)
            values = patch[keep]
            if values.size < 3:
                values = patch.reshape(-1)
            return np.median(np.real(values)) + 1j * np.median(np.imag(values))

        for y, x in candidate_points:
            y, x = int(y), int(x)
            corrected[y, x] = replace_point(y, x)
            candidates.append((y, x))

            # MRI image data has conjugate symmetry; compensate the paired point.
            sy = (2 * cy - y) % rows
            sx = (2 * cx - x) % cols
            if (sy, sx) != (y, x) and mask[sy, sx]:
                corrected[sy, sx] = replace_point(sy, sx)
                candidates.append((int(sy), int(sx)))

        result = np.abs(ifft2c(corrected))

        # Confirm that the candidate correction changes stripe energy.
        before_dx = np.mean(np.abs(np.diff(source, axis=1)))
        before_dy = np.mean(np.abs(np.diff(source, axis=0)))
        after_dx = np.mean(np.abs(np.diff(result, axis=1)))
        after_dy = np.mean(np.abs(np.diff(result, axis=0)))
        stripe_improvement = max(
            (before_dx - after_dx) / max(before_dx, 1e-9),
            (before_dy - after_dy) / max(before_dy, 1e-9),
        )

        # Multiple obvious k-space outliers are accepted even when the image-domain
        # improvement is modest, which is common in heavy multi-spike examples.
        detected = len(candidates) >= 2 and (
            stripe_improvement > 0.002 or len(candidates) >= 8
        )
        if not detected:
            return source.copy(), kspace, kspace.copy(), []

        return result, kspace, corrected, candidates


    def apply_spike_processing(self):
        dicom_indices = self._selected_dicom_indices()
        if not dicom_indices:
            # No original image selection: use existing RAW/PFile diagnostic.
            self.detect_spikes()
            return

        progress = self._make_progress("Spike Processing", len(dicom_indices))
        processed = []
        try:
            for number, index in enumerate(dicom_indices, start=1):
                if progress.wasCanceled():
                    return
                entry = self.dicom_entries[index]
                progress.setLabelText(
                    f"Detecting repeated stripes and k-space spikes {number}/{len(dicom_indices)}: {entry.path.name}"
                )
                QApplication.processEvents()

                corrected, raw_before, raw_after, candidates = self._suppress_image_spikes(entry.image)
                if candidates:
                    self.current_ds = entry.ds
                    self.current_source = str(entry.path)
                    output = self._save_processed_image(
                        corrected,
                        f"{entry.path.stem}_NS",
                        "_NS",
                    )
                    processed.append({
                        "index": index,
                        "path": entry.path,
                        "output": output,
                        "original": np.asarray(entry.image).copy(),
                        "corrected": corrected,
                        "raw_before": raw_before,
                        "raw_after": raw_after,
                        "candidates": candidates,
                    })
                progress.setValue(number)
        finally:
            progress.close()

        if not processed:
            QMessageBox.information(self, "Spike Processing", "No Spike")
            return

        self.spike_image_results = processed
        last = processed[-1]
        self._display_processed_result(last["corrected"], last["output"])
        self.tabs.setCurrentIndex(1)
        QMessageBox.information(
            self,
            "Spike Processing",
            f"Processed {len(dicom_indices)} image(s).\n"
            f"Spike corrected: {len(processed)} image(s).",
        )

    def detect_spikes(self):
        candidates = self._raw_candidate_paths()
        if not candidates:
            QMessageBox.information(
                self,
                "Spike Detection",
                "No RAW, BIN, DAT, PFile, or TrackerImg files are currently imported. "
                "Drop a file or folder first.",
            )
            return

        threshold = float(self.spike_threshold.value())
        progress = self._make_progress("Detecting Spike Noise", len(candidates))
        results = []
        try:
            for index, path in enumerate(candidates, start=1):
                if not self._progress_step(
                    progress,
                    index - 1,
                    f"Analyzing {index}/{len(candidates)}: {path.name}",
                ):
                    self.statusBar().showMessage("Spike detection canceled")
                    return
                try:
                    if self.looks_tracker(path):
                        signal, source_type = self._extract_tracker_signal(path)
                    else:
                        signal, source_type = self._extract_generic_raw_signal(path)
                    analysis = self._analyze_spike_signal(signal, threshold)
                    analysis.update({
                        "path": path,
                        "name": path.name,
                        "type": source_type,
                        "signal": signal,
                        "error": "",
                    })
                except Exception as exc:
                    analysis = {
                        "path": path,
                        "name": path.name,
                        "type": "Unreadable",
                        "signal": np.array([], dtype=float),
                        "score": 0.0,
                        "flagged": False,
                        "indices": np.array([], dtype=int),
                        "groups": 0,
                        "strongest": -1,
                        "samples": 0,
                        "error": str(exc),
                    }
                results.append(analysis)
                progress.setValue(index)
        finally:
            progress.close()

        self.spike_results = sorted(results, key=lambda item: item["score"], reverse=True)
        self._refresh_spike_table()
        flagged = sum(1 for item in results if item["flagged"])
        errors = sum(1 for item in results if item["error"])
        self.spike_summary.setText(
            f"Scanned {len(results)} raw file(s) at robust threshold {threshold:.1f}. "
            f"Spike candidates: {flagged}. Read errors: {errors}."
        )
        self.tabs.setCurrentIndex(1)
        self.statusBar().showMessage(f"Spike detection complete: {flagged}/{len(results)} flagged")

    def _refresh_spike_table(self):
        if not hasattr(self, "spike_table"):
            return
        show_flagged = self.spike_only_flagged.isChecked()
        rows = [
            result for result in self.spike_results
            if (result["flagged"] or not show_flagged)
        ]
        self.spike_table.setSortingEnabled(False)
        self.spike_table.setRowCount(len(rows))
        for row, result in enumerate(rows):
            status = "SPIKE" if result["flagged"] else ("ERROR" if result["error"] else "OK")
            values = [
                status,
                result["name"],
                result["type"],
                f'{result["score"]:.2f}',
                str(result["groups"]),
                str(result["strongest"]) if result["strongest"] >= 0 else "-",
                str(result["samples"]),
                str(result["path"]),
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                item.setData(Qt.UserRole, result)
                if status == "SPIKE":
                    item.setBackground(pg.mkColor("#7a2430"))
                elif status == "ERROR":
                    item.setBackground(pg.mkColor("#6a5520"))
                self.spike_table.setItem(row, col, item)
        self.spike_table.setSortingEnabled(True)
        self.spike_table.resizeColumnsToContents()

    def _open_spike_result(self, row: int, column: int):
        item = self.spike_table.item(row, 0)
        if item is None:
            return
        result = item.data(Qt.UserRole)
        if not result or result["signal"].size < 2:
            if result and result["error"]:
                QMessageBox.warning(self, "Spike Result", result["error"])
            return

        name = f'Spike scan: {result["name"]}'
        self.signals.append({"name": name, "data": result["signal"]})
        self.signal_combo.addItem(name)
        self.signal_combo.setCurrentIndex(len(self.signals) - 1)
        self.active_spike_indices = np.asarray(result["indices"], dtype=int)
        self.signal_fft.setChecked(False)
        self.signal_component.setCurrentText("Magnitude")
        self.update_signal_plot()
        self.update_tracker_preview(result["signal"])
        self.tabs.setCurrentIndex(1)
        self.statusBar().showMessage(
            f'Opened {result["name"]}: {len(self.active_spike_indices)} spike group(s)'
        )

    @staticmethod
    def _position_plane_index(name: str) -> int:
        return {"Axial": 0, "Coronal": 1, "Sagittal": 2}.get(name, 0)

    def populate_position_top_lines(self):
        if self.tracker_matrix is None or not self.tracker_line_metrics:
            QMessageBox.information(self, "Tracker Position", "Load a Tracker PFile / TrackerImg first.")
            return

        ranked = sorted(self.tracker_line_metrics, key=lambda item: item["rms"], reverse=True)[:3]
        for row, metric in enumerate(ranked):
            self.position_table.setItem(row, 0, QTableWidgetItem(str(metric["line"])))
        self.tabs.setCurrentIndex(4)
        self.statusBar().showMessage("Top three Tracker lines assigned to position conversion.")

    def calculate_tracker_position(self):
        if self.tracker_matrix is None:
            QMessageBox.information(self, "Tracker Position", "Load a Tracker file first.")
            return

        fft_length = int(self.position_fft_length.value())
        fov = float(self.position_fov.value())
        measurements = []

        try:
            for row in range(self.position_table.rowCount()):
                use_widget = self.position_table.cellWidget(row, 6)
                if use_widget is not None and not use_widget.isChecked():
                    continue

                line_item = self.position_table.item(row, 0)
                if line_item is None:
                    continue
                line_index = int(line_item.text())
                if line_index < 0 or line_index >= self.tracker_matrix.shape[0]:
                    raise ValueError(f"Line {line_index} is outside the available range.")

                plane_widget = self.position_table.cellWidget(row, 1)
                rotation_widget = self.position_table.cellWidget(row, 2)
                plane = self._position_plane_index(plane_widget.currentText())
                rotation_deg = float(rotation_widget.value())

                peak_bin, coordinate_mm, snr_like, spectrum = signal_peak_coordinate(
                    self.tracker_matrix[line_index],
                    fft_length=fft_length,
                    fov_mm=fov,
                )
                measurement = DirectionMeasurement(
                    line_index=line_index,
                    plane=plane,
                    rotation_deg=rotation_deg,
                    peak_bin=peak_bin,
                    coordinate_mm=coordinate_mm,
                    snr_like=snr_like,
                )
                measurements.append(measurement)

                self.position_table.setItem(row, 3, QTableWidgetItem(f"{peak_bin:.4f}"))
                self.position_table.setItem(row, 4, QTableWidgetItem(f"{coordinate_mm:.4f}"))
                self.position_table.setItem(row, 5, QTableWidgetItem(f"{snr_like:.3f}"))

            offset = np.array([
                self.position_offset_x.value(),
                self.position_offset_y.value(),
                self.position_offset_z.value(),
            ], dtype=float)

            scanner_xyz, pqr, rms_error = solve_position(
                measurements,
                center_offset=offset,
                oppose_ap=self.position_oppose_ap.isChecked(),
            )
            self.tracker_position_measurements = measurements
            self.position_result.setText(
                f"Coordinates MR / Scanner (mm):\n"
                f"  X = {scanner_xyz[0]:.4f}\n"
                f"  Y = {scanner_xyz[1]:.4f}\n"
                f"  Z = {scanner_xyz[2]:.4f}\n\n"
                f"Coordinates PQR (mm):\n"
                f"  P = {pqr[0]:.4f}\n"
                f"  Q = {pqr[1]:.4f}\n"
                f"  R = {pqr[2]:.4f}\n\n"
                f"Projection RMS residual = {rms_error:.5f} mm\n"
                f"Gradient-map correction = Not applied"
            )
            self.statusBar().showMessage("Tracker position conversion completed.")
        except Exception as exc:
            QMessageBox.critical(self, "Tracker Position Error", str(exc))

    def component(self, arr, mode):
        if mode == 'Real': return np.real(arr)
        if mode == 'Imaginary': return np.imag(arr)
        if mode == 'Phase': return np.angle(arr)
        return np.abs(arr)

    def change_workspace_source(self, source_name: str):
        if source_name == "Tracker Raw Magnitude":
            if self.tracker_matrix is None:
                return
            self.current_kspace = np.asarray(self.tracker_matrix).copy()
            self.current_recon = ifft2c(self.current_kspace)
            self.current_image = np.abs(self.current_recon)
            self.current_source = str(self.tracker_source_path or "Tracker")
        elif source_name == "Tracker Reconstructed":
            if self.tracker_reconstructed_image is None:
                return
            self.current_image = np.asarray(self.tracker_reconstructed_image).copy()
            self.current_kspace = fft2c(self.current_image)
            self.current_recon = ifft2c(self.current_kspace)
            self.current_source = str(self.tracker_source_path or "Tracker")
        self.refresh_images()

    def send_tracker_to_signal_studio(self):
        if self.tracker_strongest_line is None:
            QMessageBox.information(self, "Tracker", "Load a Tracker file first.")
            return
        name = f"{self.tracker_shared_name} | Strongest line {self.tracker_strongest_line_index}"
        existing = next((i for i, item in enumerate(self.signals) if item.get("name") == name), None)
        if existing is None:
            self.add_signal(np.asarray(self.tracker_strongest_line).copy(), name)
            existing = len(self.signals) - 1
        self.signal_combo.setCurrentIndex(existing)
        self.signal_component.setCurrentText("Magnitude")
        self.signal_fft.setChecked(False)
        self.tabs.setCurrentIndex(1)
        self.update_signal_plot()

    def preview_tracker_in_artifact_learning(self):
        if self.tracker_matrix is None:
            QMessageBox.information(self, "Artifact Learning", "Load a Tracker file first.")
            return
        image = np.log1p(np.abs(self.tracker_matrix))
        self.artifact_preview_panel.label.setText(
            f"Tracker Raw Magnitude: {self.tracker_shared_name}"
        )
        self.artifact_preview_panel.set_image(image)
        self.artifact_selection_label.setText(
            f"Tracker data ready for learning: {self.tracker_shared_name}"
        )

    def save_tracker_training_sample(self):
        if self.tracker_matrix is None or self.tracker_source_path is None:
            QMessageBox.information(self, "Artifact Learning", "Load a Tracker file first.")
            return
        if not self._ensure_artifact_database():
            return
        artifact_type = self.artifact_type_combo.currentText().strip() or "Not Artifact"
        resolution = self.artifact_resolution_combo.currentText().strip()
        notes = self.artifact_notes.toPlainText().strip()
        tracker_image = np.log1p(np.abs(self.tracker_matrix))
        features = image_features(tracker_image, self.normal_reference_image)
        features.update({
            "data_type": "Tracker Raw",
            "strongest_line": self.tracker_strongest_line_index,
            "line_peak": float(np.max(np.abs(self.tracker_strongest_line))) if self.tracker_strongest_line is not None else 0.0,
            "line_rms": float(np.sqrt(np.mean(np.abs(self.tracker_strongest_line) ** 2))) if self.tracker_strongest_line is not None else 0.0,
        })
        self.artifact_db.add_sample(
            source_path=str(self.tracker_source_path),
            source_name=self.tracker_source_path.name,
            series_uid="TRACKER",
            series_description="Tracker Raw Data",
            instance_number=self.tracker_strongest_line_index,
            artifact_type=artifact_type,
            resolution=resolution,
            is_normal_reference=False,
            normal_reference_path=str(self.normal_reference_path or ""),
            features=features,
            notes=notes,
        )
        self.refresh_artifact_training_table()
        self.artifact_summary.setText(
            f"Saved Tracker training sample as '{artifact_type}'."
        )

    def detect_tracker_artifact_from_db(self):
        if self.tracker_matrix is None:
            QMessageBox.information(self, "Artifact Detection", "Load a Tracker file first.")
            return
        if not self._ensure_artifact_database():
            return
        keys, training, labels, metadata = self.artifact_db.training_feature_vectors()
        tracker_image = np.log1p(np.abs(self.tracker_matrix))
        features = image_features(tracker_image, self.normal_reference_image)
        features.update({
            "data_type": "Tracker Raw",
            "strongest_line": self.tracker_strongest_line_index,
        })
        vector = features_to_vector(features, keys)
        result = classify_feature_vector(
            vector, training, labels,
            minimum_samples_per_class=self.detect_min_samples.value(),
        )
        self.artifact_detection_table.setRowCount(1)
        alternatives = ", ".join(
            f"{label} {confidence * 100:.1f}%"
            for label, confidence, distance, support in result.alternatives[1:4]
        )
        values = [
            self.tracker_source_path.name if self.tracker_source_path else "Tracker",
            "Tracker Raw Data",
            result.label,
            f"{result.confidence * 100:.1f}%",
            f"{result.distance:.4f}" if np.isfinite(result.distance) else "-",
            result.support,
            result.status,
            alternatives,
            str(self.tracker_source_path or ""),
        ]
        for column, value in enumerate(values):
            self.artifact_detection_table.setItem(0, column, QTableWidgetItem(str(value)))
        self.artifact_detection_summary.setText(
            f"Tracker prediction: {result.label} | Confidence {result.confidence * 100:.1f}%"
        )
        self.tabs.setCurrentIndex(2)

    def _image_mouse_action_changed(self, action: str):
        if action == "Auto Window/Level":
            self.auto_levels()
            self.statusBar().showMessage("Window/Level recalculated automatically")
            return
        self.primary_panel.mouse_action = action
        self.secondary_panel.mouse_action = action
        if action == "ROI":
            if self.current_kspace is not None and self.source_kind != "bitmap":
                self.primary_panel.show_comp_roi()
            else:
                self.statusBar().showMessage("ROI requires raw/k-space data")
        self.statusBar().showMessage(
            "Mouse action: "
            + action
            + (" | Wheel=Level, Ctrl+Wheel=Width" if action == "Window/Level" else "")
        )


    def _image_view_requested(self, mode: str):
        if mode == "FFT_CURRENT":
            if self.current_image is None:
                return
            self.current_kspace = fft2c(np.asarray(self.current_image, dtype=float))
            self.current_recon = ifft2c(self.current_kspace)
            self.raw_window_level = None
            self.raw_dynamic_range = None
            self.set_view_mode("FFT")
            self.statusBar().showMessage("FFT calculated from the currently selected image")
            return

        if mode == "Default":
            self.profile_mode.setCurrentText("Magnitude")
            self.level_target_combo.setCurrentText("Original Image")
            self.original_window_level = None
            self.original_dynamic_range = None
            self.raw_window_level = None
            self.raw_dynamic_range = None
            self.primary_panel.plot.getViewBox().autoRange()
            self.secondary_panel.plot.getViewBox().autoRange()
            self.set_view_mode("Both" if self.source_kind != "bitmap" else "Original")
            return

        self.set_view_mode(mode)


    def _image_level_wheel(self, panel, step: float, adjust_width: bool):
        target = "Raw Data" if panel is self.primary_panel and self.view_mode in {"FFT", "Both"} else "Original Image"
        self.level_target_combo.setCurrentText(target)

        if target == "Raw Data":
            center = float(self.raw_window_level or 0.0)
            width = max(float(self.raw_dynamic_range or 1.0), 1e-9)
        else:
            center = float(self.original_window_level or 0.0)
            width = max(float(self.original_dynamic_range or 1.0), 1e-9)

        increment = max(width * 0.04, 1e-6)
        if adjust_width:
            width = max(width + step * increment, 1e-9)
        else:
            center += step * increment

        if target == "Raw Data":
            self.raw_window_level = center
            self.raw_dynamic_range = width
        else:
            self.original_window_level = center
            self.original_dynamic_range = width

        self._sync_level_controls()
        self.refresh_images()

    def _accordion_opened(self, opened):
        for section in self.accordion_sections:
            if section is not opened: section.set_expanded(False,False)

    def _spike_range_changed(self,value):
        visible=value=="Scale"; self.spike_scale_slider.setVisible(visible); self.spike_scale_label.setVisible(visible)

    def show_dicom_header_popup(self):
        if self.current_ds is None: QMessageBox.information(self,"DICOM Header","Load a DICOM image first."); return
        DicomHeaderDialog(self.current_ds,self.current_source,self).exec()

    def quick_spike_detect_prototype(self):
        if not self.dicom_entries: QMessageBox.information(self,"Quick Spike Detect","Load DICOM images first."); return
        progress=self._make_progress("Quick Spike Detect",len(self.dicom_entries)); detected=[]
        try:
            for i,entry in enumerate(self.dicom_entries,1):
                if progress.wasCanceled(): break
                progress.setLabelText(f"Screening image: {entry.path.name}"); arr=np.asarray(entry.image,float); spec=np.abs(fft2c(arr-np.mean(arr))); ratio=float(np.max(spec))/max(float(np.median(spec)),np.finfo(float).eps)
                if ratio>45.0: detected.append(i-1)
                progress.setValue(i)
        finally: progress.close()
        self._highlight_quick_spike_candidates(detected)
        box=QMessageBox(self); box.setWindowTitle("Quick Spike Detect"); box.setText(f"Spike candidates detected: {len(detected)} / {len(self.dicom_entries)}"); box.addButton("Close",QMessageBox.RejectRole); apply=box.addButton("Apply All",QMessageBox.AcceptRole); box.exec()
        if box.clickedButton()==apply: self._select_quick_spike_candidates(detected)

    def _highlight_quick_spike_candidates(self,indices):
        target=set(indices); it=QTreeWidgetItemIterator(self.tree)
        while it.value():
            item=it.value(); data=item.data(0,Qt.UserRole)
            if data and data[0]=="dicom": item.setForeground(0,pg.mkBrush("#ff5a5a" if int(data[1]) in target else "#d8e5ef"))
            it+=1

    def _select_quick_spike_candidates(self,indices):
        target=set(indices); self.tree.clearSelection(); it=QTreeWidgetItemIterator(self.tree)
        while it.value():
            item=it.value(); data=item.data(0,Qt.UserRole)
            if data and data[0]=="dicom" and int(data[1]) in target: item.setSelected(True)
            it+=1

    def on_display_type_changed(self, value: str):
        self.refresh_images()
        self.update_line_profile()

    @staticmethod
    def _display_component(array: np.ndarray, mode: str) -> np.ndarray:
        data = np.asarray(array)
        if mode == "Real":
            return np.real(data)
        if mode == "Imaginary":
            return np.imag(data)
        if mode == "Phase":
            return np.angle(data)
        return np.abs(data)

    def set_view_mode(self, mode):
        if self.source_kind == "bitmap" and mode != "Original":
            mode = "Original"
        self.view_mode = mode
        for button, value in [
            (self.btn_fft, "FFT"),
            (self.btn_original, "Original"),
            (self.btn_both, "Both"),
        ]:
            button.setChecked(value == mode)
        self.refresh_images()


    def refresh_images(self):
        if self.current_image is None:
            return

        mode = self.profile_mode.currentText() if hasattr(self, "profile_mode") else "Magnitude"
        orig = self._display_component(self.current_image, mode)

        # Bitmap files have no acquired raw data. Only Original is available.
        if self.source_kind == "bitmap":
            self.view_mode = "Original"
            original_levels = self._levels_for_target("Original Image", orig, auto_original=True)
            self.primary_panel.show()
            self.secondary_panel.hide()
            self.primary_panel.label.setText(f"Original Image — {mode}")
            self.primary_panel.set_image(orig, levels=original_levels)
            self._sync_level_controls()
            rows, cols = orig.shape
            self._configure_line_control(rows, cols)
            self._sync_lines()
            self.update_line_profile()
            return

        if self.current_kspace is None:
            return

        raw_component = self._display_component(self.current_kspace, mode)
        fft_img = np.log1p(np.abs(raw_component)) if mode == "Magnitude" else raw_component

        # Original Auto is always recomputed for the selected image.
        original_levels = self._levels_for_target("Original Image", orig, auto_original=True)
        raw_levels = self._levels_for_target("Raw Data", fft_img, auto_original=False)

        if self.view_mode == "FFT":
            self.primary_panel.show()
            self.secondary_panel.hide()
            self.primary_panel.label.setText(f"FFT (k-space) — {mode}")
            self.primary_panel.set_image(fft_img, levels=raw_levels)
        elif self.view_mode == "Original":
            self.primary_panel.show()
            self.secondary_panel.hide()
            self.primary_panel.label.setText(f"Original Image — {mode}")
            self.primary_panel.set_image(orig, levels=original_levels)
        else:
            self.primary_panel.show()
            self.secondary_panel.show()
            self.primary_panel.label.setText(f"FFT (k-space) — {mode}")
            self.secondary_panel.label.setText(f"Original Image — {mode}")
            self.primary_panel.set_image(fft_img, levels=raw_levels)
            self.secondary_panel.set_image(orig, levels=original_levels)

        rows, cols = orig.shape
        self.line_row = min(self.line_row if self.line_row is not None else rows // 2, rows - 1)
        self.line_col = min(self.line_col if self.line_col is not None else cols // 2, cols - 1)
        self._configure_line_control(rows, cols)
        self._sync_lines()
        self._sync_level_controls()
        self.update_line_profile()


    def _configure_line_control(self, rows, cols):
        maximum = rows-1 if self.line_orientation=='Row' else cols-1
        self.line_spin.blockSignals(True); self.line_slider.blockSignals(True)
        self.line_spin.setRange(0, maximum); self.line_slider.setRange(0, maximum)
        value=self.line_row if self.line_orientation=='Row' else self.line_col
        self.line_spin.setValue(value); self.line_slider.setValue(value)
        self.line_spin.blockSignals(False); self.line_slider.blockSignals(False)

    def _orientation_changed(self, text):
        self.line_orientation=text
        if self.current_image is not None: self._configure_line_control(*self.current_image.shape); self.update_line_profile()

    def _spin_line_changed(self, value):
        self._set_selected_line(value)

    def _slider_line_changed(self, value):
        self._set_selected_line(value)

    def _set_selected_line(self, value):
        if self.current_image is None: return
        if self.line_orientation=='Row': self.line_row=value
        else: self.line_col=value
        self.line_spin.blockSignals(True); self.line_slider.blockSignals(True); self.line_spin.setValue(value); self.line_slider.setValue(value); self.line_spin.blockSignals(False); self.line_slider.blockSignals(False)
        self._sync_lines(); self.update_line_profile()

    def _line_moved(self, row, col):
        self.line_row=row; self.line_col=col
        value=row if self.line_orientation=='Row' else col
        self.line_spin.blockSignals(True); self.line_slider.blockSignals(True); self.line_spin.setValue(value); self.line_slider.setValue(value); self.line_spin.blockSignals(False); self.line_slider.blockSignals(False)
        self._sync_lines(); self.update_line_profile()

    def _sync_lines(self):
        self.primary_panel.set_line_position(self.line_row, self.line_col); self.secondary_panel.set_line_position(self.line_row, self.line_col)

    def active_display_array(self):
        if self.view_mode == 'Original': return np.asarray(self.current_image)
        return np.asarray(self.current_kspace)

    def update_line_profile(self):
        if self.current_image is None or self.current_kspace is None: return
        arr=self.active_display_array(); line=arr[self.line_row,:] if self.line_orientation=='Row' else arr[:,self.line_col]
        y=self.component(line, self.profile_mode.currentText())
        if self.log_profile.isChecked(): y=np.log10(np.maximum(np.abs(y), 1e-12))
        self.profile_plot.clear(); self.profile_plot.plot(y)
        pos=self.line_row if self.line_orientation=='Row' else self.line_col
        self.line_value_label.setText(f"{pos} / {len(y)-1}")

    def send_line_to_signal_studio(self):
        if self.current_image is None: return
        arr=self.active_display_array(); line=arr[self.line_row,:] if self.line_orientation=='Row' else arr[:,self.line_col]
        self.add_signal(line, f"{self.line_orientation} {self.line_row if self.line_orientation=='Row' else self.line_col} — {self.view_mode}")
        self.tabs.setCurrentIndex(1)

    def auto_levels(self):
        if self.current_image is None:
            return
        target = self.level_target_combo.currentText() if hasattr(self, "level_target_combo") else "Original Image"
        if target == "Raw Data" and self.current_kspace is not None:
            self._set_levels_for_target("Raw Data", np.log1p(np.abs(self.current_kspace)))
        else:
            self._set_levels_for_target("Original Image", np.asarray(self.current_image))
        self.level_preset_combo.blockSignals(True)
        self.level_preset_combo.setCurrentText("Auto")
        self.level_preset_combo.blockSignals(False)
        self._sync_level_controls()
        self.refresh_images()


    def _tree_current_changed(self, current, previous):
        if current is None:
            return
        data = current.data(0, Qt.UserRole)
        if data and data[0] == "dicom":
            self.show_dicom(int(data[1]))


    def _tree_clicked(self, item, column):
        data = item.data(0, Qt.UserRole)
        if not data:
            return
        if data[0] == "dicom":
            self.show_dicom(int(data[1]))
        elif data[0] == "signal":
            self.tabs.setCurrentIndex(4)
            self.signal_combo.setCurrentIndex(int(data[1]))
            self.update_signal_plot()
        elif data[0] == "processed":
            self.load_processed_image(data[1])
            self.refresh_images()
        elif data[0] == "tracker_workspace":
            self.show_tracker_in_workspace()
        elif data[0] == "tracker_signal":
            self.send_tracker_to_signal_studio()
        elif data[0] == "tracker_file":
            self._apply_tracker_state(int(data[1]))
            self.tabs.setCurrentIndex(3)


    def _select_tree_dicom_index(self, index: int):
        iterator = QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            item = iterator.value()
            data = item.data(0, Qt.UserRole)
            if data and data[0] == "dicom" and int(data[1]) == int(index):
                self.tree.blockSignals(True)
                self.tree.setCurrentItem(item)
                self.tree.blockSignals(False)
                return
            iterator += 1

    def _level_target_changed(self, target: str):
        self._sync_level_controls()
        self.refresh_images()

    def _set_levels_for_target(self, target: str, array: np.ndarray):
        finite = np.asarray(array, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            center, width = 0.5, 1.0
        else:
            low, high = np.percentile(finite, [1.0, 99.5])
            if high <= low:
                high = low + 1.0
            center = float((low + high) / 2.0)
            width = float(high - low)

        if target == "Raw Data":
            self.raw_window_level = center
            self.raw_dynamic_range = width
        else:
            self.original_window_level = center
            self.original_dynamic_range = width

    def _levels_for_target(self, target: str, array: np.ndarray, auto_original: bool = False):
        if target == "Original Image":
            if auto_original or self.original_window_level is None or self.original_dynamic_range is None:
                self._set_levels_for_target(target, array)
            center = float(self.original_window_level)
            width = max(float(self.original_dynamic_range), 1e-9)
        else:
            if self.raw_window_level is None or self.raw_dynamic_range is None:
                self._set_levels_for_target(target, array)
            center = float(self.raw_window_level)
            width = max(float(self.raw_dynamic_range), 1e-9)
        return center - width / 2.0, center + width / 2.0

    def _active_level_array(self) -> np.ndarray:
        if self.current_image is None or self.current_kspace is None:
            return np.array([0.0, 1.0])
        if self.view_mode == "Original":
            return np.abs(self.current_image)
        return np.log1p(np.abs(self.current_kspace))

    def _set_auto_levels_from_array(self, array: np.ndarray):
        finite = np.asarray(array, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            center, width = 0.5, 1.0
        else:
            low, high = np.percentile(finite, [1.0, 99.5])
            if high <= low:
                high = low + 1.0
            center = (low + high) / 2.0
            width = high - low
        self.window_level = float(center)
        self.dynamic_range = float(width)
        self._sync_level_controls()

    def _levels_for_array(self, array: np.ndarray):
        finite = np.asarray(array, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            return (0.0, 1.0)
        low, high = np.percentile(finite, [1.0, 99.5])
        if high <= low:
            high = low + 1.0
        return (float(low), float(high))

    def _current_levels(self):
        if self.window_level is None or self.dynamic_range is None:
            self._set_auto_levels_from_array(self._active_level_array())
        half = max(float(self.dynamic_range) / 2.0, 1e-9)
        return (float(self.window_level) - half, float(self.window_level) + half)

    def _sync_level_controls(self):
        if not hasattr(self, "window_level_spin"):
            return
        target = self.level_target_combo.currentText() if hasattr(self, "level_target_combo") else "Original Image"
        if target == "Raw Data":
            center = self.raw_window_level
            width = self.raw_dynamic_range
        else:
            center = self.original_window_level
            width = self.original_dynamic_range

        self.window_level_spin.blockSignals(True)
        self.dynamic_range_spin.blockSignals(True)
        self.window_level_spin.setValue(float(center or 0.0))
        self.dynamic_range_spin.setValue(max(float(width or 1.0), 1e-9))
        self.window_level_spin.blockSignals(False)
        self.dynamic_range_spin.blockSignals(False)


    def _manual_levels_changed(self):
        target = self.level_target_combo.currentText() if hasattr(self, "level_target_combo") else "Original Image"
        center = float(self.window_level_spin.value())
        width = max(float(self.dynamic_range_spin.value()), 1e-9)

        if target == "Raw Data":
            self.raw_window_level = center
            self.raw_dynamic_range = width
        else:
            self.original_window_level = center
            self.original_dynamic_range = width

        self.level_preset_combo.blockSignals(True)
        self.level_preset_combo.setCurrentText("Auto" if target == "Original Image" else "Manual")
        self.level_preset_combo.blockSignals(False)
        self.refresh_images()


    def apply_level_preset(self, preset: str):
        if self.current_image is None:
            return
        array = self._active_level_array()
        finite = np.asarray(array, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            return

        percentiles = {
            "Auto": (1.0, 99.5),
            "Wide": (0.0, 100.0),
            "Soft Tissue": (5.0, 95.0),
            "High Contrast": (10.0, 90.0),
            "Narrow": (25.0, 75.0),
        }
        low_p, high_p = percentiles.get(preset, (1.0, 99.5))
        low, high = np.percentile(finite, [low_p, high_p])
        if high <= low:
            high = low + 1.0
        self.level_preset = preset
        self.window_level = float((low + high) / 2.0)
        self.dynamic_range = float(high - low)
        self._sync_level_controls()
        levels = self._current_levels()
        self.primary_panel.set_levels(*levels)
        if self.secondary_panel.isVisible():
            self.secondary_panel.set_levels(*levels)

    def _current_image_record(self):
        if self.current_image is None:
            return None
        name = Path(self.current_source).name if self.current_source else "current_image"
        return {
            "name": name,
            "path": Path(self.current_source) if self.current_source else None,
            "image": np.asarray(self.current_image, dtype=float).copy(),
            "ds": copy.deepcopy(self.current_ds) if self.current_ds is not None else None,
        }

    def set_addsub_source(self, slot: str):
        record = self._current_image_record()
        if record is None:
            QMessageBox.information(self, "Add/Subtract", "Load an image first.")
            return
        if slot == "A":
            self.addsub_a = record
        else:
            self.addsub_b = record
        self.addsub_status.setText(
            f"A: {self.addsub_a['name'] if self.addsub_a else '-'}\\n"
            f"B: {self.addsub_b['name'] if self.addsub_b else '-'}"
        )

    def run_addsub(self, operation: str):
        # Backward-compatible alias.
        self.preview_addsub(operation)

    def preview_addsub(self, operation: str):
        if self.addsub_a is None or self.addsub_b is None:
            QMessageBox.information(self, "Add/Subtract", "Set both image A and image B first.")
            return
        a = np.asarray(self.addsub_a["image"], dtype=float)
        b = np.asarray(self.addsub_b["image"], dtype=float)
        if a.shape != b.shape:
            QMessageBox.warning(self, "Add/Subtract", f"Image sizes do not match: {a.shape} and {b.shape}")
            return

        result = a + b if operation == "add" else a - b
        self.addsub_preview_result = result
        self.addsub_preview_operation = operation
        self.save_addsub_button.setEnabled(True)

        dialog = QDialog(self)
        dialog.setWindowTitle("Add / Subtract Preview")
        dialog.resize(1450, 620)
        layout = QVBoxLayout(dialog)
        panels = QSplitter(Qt.Horizontal)
        panel_a = ImagePanel("Image A")
        panel_b = ImagePanel("Image B")
        panel_result = ImagePanel("Result: A + B" if operation == "add" else "Result: A - B")
        panels.addWidget(panel_a)
        panels.addWidget(panel_b)
        panels.addWidget(panel_result)
        panel_a.set_image(a)
        panel_b.set_image(b)
        panel_result.set_image(result)
        layout.addWidget(panels, 1)

        buttons = QHBoxLayout()
        save_button = QPushButton("Save Result")
        close_button = QPushButton("Close Preview")
        save_button.clicked.connect(lambda: (self.save_addsub_preview(), dialog.accept()))
        close_button.clicked.connect(dialog.reject)
        buttons.addStretch(1)
        buttons.addWidget(save_button)
        buttons.addWidget(close_button)
        layout.addLayout(buttons)
        dialog.exec()

    def save_addsub_preview(self):
        if self.addsub_preview_result is None or not self.addsub_preview_operation:
            QMessageBox.information(self, "Add/Subtract", "Preview an Add/Subtract result first.")
            return
        operation = self.addsub_preview_operation
        tag = "add" if operation == "add" else "sub"
        base = Path(self.addsub_a["name"]).stem if self.addsub_a else "image"
        output_path = self._save_processed_image(
            self.addsub_preview_result,
            f"{base}_{tag}_addsub",
            "_addsub",
        )
        self._display_processed_result(self.addsub_preview_result, output_path)
        self.addsub_status.setText(
            f"A: {self.addsub_a['name'] if self.addsub_a else '-'}\n"
            f"B: {self.addsub_b['name'] if self.addsub_b else '-'}\n"
            f"Saved: {output_path.name}"
        )
        self.save_addsub_button.setEnabled(False)
        self.statusBar().showMessage(f"Add/Subtract saved: {output_path}")

    def _raw_compensation_panel(self):
        # ROI coordinates always refer to raw/k-space dimensions. When FFT or Both
        # is visible, use its panel. In Original-only mode, keep the display unchanged
        # and place the ROI on the visible panel using the same matrix coordinates.
        return self.primary_panel

    def start_compensation_roi(self):
        if self.current_kspace is None:
            QMessageBox.information(self, "Compensation", "Load raw/k-space data first.")
            return

        if not self.compensation_history:
            self.compensation_history = [{
                "kspace": np.asarray(self.current_kspace).copy(),
                "image": np.asarray(self.current_image).copy(),
                "label": "Original",
                "roi": None,
                "level": None,
            }]
            self.compensation_history_index = 0

        self.compensation_original_kspace = np.asarray(self.current_kspace).copy()
        self.compensation_original = np.asarray(self.current_image).copy()
        self.compensation_preview = None
        self.compensation_roi_panel = self._raw_compensation_panel()
        self.compensation_roi_panel.show_comp_roi()
        self.preview_comp_button.setEnabled(True)
        self.apply_comp_button.setEnabled(False)
        self.comp_status_label.setText(
            "RAW ROI active. The current view mode and Window/Level are unchanged."
        )
        self.statusBar().showMessage("Move and resize the RAW compensation ROI.")

    def clear_compensation_roi(self):
        if self.compensation_roi_panel is not None:
            self.compensation_roi_panel.hide_comp_roi()
        if self.compensation_original_kspace is not None:
            self.current_kspace = self.compensation_original_kspace.copy()
            self.current_recon = ifft2c(self.current_kspace)
            self.current_image = np.abs(self.current_recon)
        self.compensation_preview = None
        self.compensation_original = None
        self.compensation_original_kspace = None
        self.compensation_roi_panel = None
        self.preview_comp_button.setEnabled(False)
        self.apply_comp_button.setEnabled(False)
        self.comp_status_label.setText("No RAW ROI selected")
        self.refresh_images()

    @staticmethod
    def _interpolate_rectangle(raw_data: np.ndarray, y0: int, y1: int, x0: int, x1: int, strength: float = 1.0) -> np.ndarray:
        source = np.asarray(raw_data)
        result = source.copy()
        rows, cols = source.shape
        if rows < 3 or cols < 3:
            raise ValueError("Raw data is too small for compensation.")

        y0 = max(1, min(int(y0), rows - 2))
        y1 = max(y0 + 1, min(int(y1), rows - 1))
        x0 = max(1, min(int(x0), cols - 2))
        x1 = max(x0 + 1, min(int(x1), cols - 1))
        height, width = y1 - y0, x1 - x0

        def interpolate_component(component):
            left = component[y0:y1, x0 - 1][:, None]
            right = component[y0:y1, x1][:, None]
            tx = np.linspace(0.0, 1.0, width, endpoint=True)[None, :]
            horizontal = left * (1.0 - tx) + right * tx

            top = component[y0 - 1, x0:x1][None, :]
            bottom = component[y1, x0:x1][None, :]
            ty = np.linspace(0.0, 1.0, height, endpoint=True)[:, None]
            vertical = top * (1.0 - ty) + bottom * ty
            return 0.5 * horizontal + 0.5 * vertical

        if np.iscomplexobj(source):
            replacement = (
                interpolate_component(np.real(source))
                + 1j * interpolate_component(np.imag(source))
            )
        else:
            replacement = interpolate_component(source.astype(float))

        original_roi = source[y0:y1, x0:x1]
        strength = float(np.clip(strength, 0.0, 1.0))
        result[y0:y1, x0:x1] = original_roi * (1.0 - strength) + replacement * strength
        return result

    def _compensation_strength(self):
        return {"Low": 0.40, "Mid": 0.70, "High": 1.00}.get(
            self.comp_level_combo.currentText(), 0.70
        )

    def _compensation_bounds(self):
        panel = self.compensation_roi_panel or self._raw_compensation_panel()
        if not panel.comp_roi.isVisible():
            raise ValueError("RAW compensation ROI is not active.")
        y0, y1, x0, x1 = panel.comp_roi_bounds()
        if (y1 - y0) < 2 or (x1 - x0) < 2:
            raise ValueError("Compensation ROI is too small.")
        return y0, y1, x0, x1

    def preview_compensation(self):
        if self.current_kspace is None:
            QMessageBox.information(self, "Compensation", "Load raw/k-space data first.")
            return
        try:
            y0, y1, x0, x1 = self._compensation_bounds()
            source_kspace = (
                self.compensation_original_kspace
                if self.compensation_original_kspace is not None
                else np.asarray(self.current_kspace)
            )
            strength = self._compensation_strength()
            compensated_kspace = self._interpolate_rectangle(
                source_kspace, y0, y1, x0, x1, strength
            )
            reconstructed = ifft2c(compensated_kspace)

            self.compensation_preview = compensated_kspace
            self.current_kspace = compensated_kspace
            self.current_recon = reconstructed
            self.current_image = np.abs(reconstructed)

            # Preserve view mode, preset, Window Level, and Dynamic Range.
            self.refresh_images()
            self.apply_comp_button.setEnabled(True)

            original_roi = np.abs(source_kspace[y0:y1, x0:x1])
            new_roi = np.abs(compensated_kspace[y0:y1, x0:x1])
            change = np.abs(new_roi - original_roi)
            self.comp_status_label.setText(
                f"Preview: {self.comp_level_combo.currentText()} | "
                f"RAW ROI x={x0}:{x1}, y={y0}:{y1} | "
                f"Mean change={float(np.mean(change)):.4g}"
            )
        except Exception as exc:
            QMessageBox.critical(self, "Compensation Preview Error", str(exc))

    def apply_compensation(self):
        try:
            y0, y1, x0, x1 = self._compensation_bounds()
            if self.compensation_preview is None:
                self.preview_compensation()
            if self.compensation_preview is None:
                return

            state = {
                "kspace": np.asarray(self.current_kspace).copy(),
                "image": np.asarray(self.current_image).copy(),
                "label": f"{self.comp_level_combo.currentText()} ROI {x0}:{x1},{y0}:{y1}",
                "roi": (y0, y1, x0, x1),
                "level": self.comp_level_combo.currentText(),
            }

            if self.compensation_history_index < len(self.compensation_history) - 1:
                self.compensation_history = self.compensation_history[
                    : self.compensation_history_index + 1
                ]
            self.compensation_history.append(state)
            self.compensation_history_index = len(self.compensation_history) - 1

            if self.compensation_roi_panel is not None:
                self.compensation_roi_panel.hide_comp_roi()
            self.compensation_roi_panel = None
            self.compensation_preview = None
            self.compensation_original_kspace = None
            self.compensation_original = None
            self.preview_comp_button.setEnabled(False)
            self.apply_comp_button.setEnabled(False)
            self.save_comp_button.setEnabled(True)
            self._update_compensation_history_buttons()
            self.comp_status_label.setText(
                f"Committed {self.compensation_history_index}/"
                f"{len(self.compensation_history)-1}: {state['label']}. "
                f"Select another ROI to continue."
            )
            self.refresh_images()
        except Exception as exc:
            QMessageBox.critical(self, "Compensation Error", str(exc))

    def _update_compensation_history_buttons(self):
        self.comp_prev_button.setEnabled(self.compensation_history_index > 0)
        self.comp_next_button.setEnabled(
            0 <= self.compensation_history_index < len(self.compensation_history) - 1
        )
        self.save_comp_button.setEnabled(self.compensation_history_index >= 0)

    def navigate_compensation_history(self, step: int):
        target = self.compensation_history_index + int(step)
        if target < 0 or target >= len(self.compensation_history):
            return
        self.compensation_history_index = target
        state = self.compensation_history[target]
        self.current_kspace = np.asarray(state["kspace"]).copy()
        self.current_recon = ifft2c(self.current_kspace)
        self.current_image = np.abs(self.current_recon)
        self.compensation_preview = None
        self.compensation_original_kspace = None
        if self.compensation_roi_panel is not None:
            self.compensation_roi_panel.hide_comp_roi()
        self.compensation_roi_panel = None
        self.refresh_images()
        self._update_compensation_history_buttons()
        self.comp_status_label.setText(
            f"History {target}/{len(self.compensation_history)-1}: {state['label']}"
        )

    def save_compensation_history_state(self):
        if not self.compensation_history or self.compensation_history_index < 0:
            QMessageBox.information(self, "Compensation", "No compensation state is available.")
            return
        state = self.compensation_history[self.compensation_history_index]
        base = Path(self.current_source).stem if self.current_source else "raw"
        output_path = self._save_processed_image(
            np.asarray(state["image"]),
            f"{base}_comp_h{self.compensation_history_index}",
            "_comp",
        )
        # Save raw/k-space separately for exact restoration.
        np.save(
            output_path.parent / f"{Path(output_path).stem}_raw.npy",
            np.asarray(state["kspace"]),
        )
        self.comp_status_label.setText(
            f"Saved displayed state {self.compensation_history_index}: {output_path.name}"
        )
        self.statusBar().showMessage(f"Compensation state saved: {output_path}")

    def change_output_root(self):
        initial = str(self._output_root())
        selected = QFileDialog.getExistingDirectory(self, "Select Output Top Folder", initial)
        if not selected:
            return
        self.output_root_override = Path(selected)
        self._update_output_root_label()

    def _output_root(self) -> Path:
        if self.output_root_override is not None:
            return self.output_root_override
        source = Path(self.current_source) if self.current_source else Path.cwd() / "image"
        parent = source.parent if source.parent.exists() else Path.cwd()
        return parent / "MR_Image_Explorer_Output"

    def _update_output_root_label(self):
        if hasattr(self, "output_root_label"):
            self.output_root_label.setText(f"Output: {self._output_root()}")

    def _work_folder(self, category: str = "Processed") -> Path:
        folder = self._output_root() / category
        folder.mkdir(parents=True, exist_ok=True)
        self._update_output_root_label()
        return folder


    def _save_processed_image(self, image: np.ndarray, stem: str, suffix: str) -> Path:
        suffix_lower = suffix.lower()
        if "addsub" in suffix_lower:
            category = "AddSub"
        elif "comp" in suffix_lower:
            category = "Compensated"
        elif "ns" in suffix_lower or "spike" in suffix_lower:
            category = "NoSpike"
        else:
            category = "Processed"

        folder = self._work_folder(category)
        safe_stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", stem)
        npy_path = folder / f"{safe_stem}.npy"
        np.save(npy_path, np.asarray(image, dtype=np.float32))

        if self.current_ds is not None:
            ds = copy.deepcopy(self.current_ds)
            arr = np.asarray(image, dtype=float)
            finite = arr[np.isfinite(arr)]
            low = float(np.min(finite)) if finite.size else 0.0
            high = float(np.max(finite)) if finite.size else 1.0
            if high <= low:
                high = low + 1.0
            scaled = np.clip((arr - low) / (high - low) * 65535.0, 0, 65535).astype(np.uint16)
            ds.PixelData = scaled.tobytes()
            ds.Rows, ds.Columns = scaled.shape
            ds.BitsAllocated = 16
            ds.BitsStored = 16
            ds.HighBit = 15
            ds.PixelRepresentation = 0
            ds.RescaleSlope = (high - low) / 65535.0
            ds.RescaleIntercept = low
            ds.SOPInstanceUID = generate_uid()
            ds.SeriesInstanceUID = generate_uid()
            ds.ImageType = ["DERIVED", "SECONDARY"]
            original_description = str(getattr(ds, "SeriesDescription", "MR"))
            ds.SeriesDescription = f"{original_description} {suffix}"
            dcm_path = folder / f"{safe_stem}.dcm"
            ds.save_as(str(dcm_path), write_like_original=False)
            primary_path = dcm_path
        else:
            primary_path = npy_path

        self.processed_images[str(primary_path)] = np.asarray(image, dtype=float).copy()
        self.processed_sources[str(primary_path)] = primary_path
        self._add_processed_tree_item(primary_path)
        self._update_output_root_label()
        return primary_path


    def _add_processed_tree_item(self, path: Path):
        root = None
        for i in range(self.tree.topLevelItemCount()):
            candidate = self.tree.topLevelItem(i)
            if candidate.text(0) == "Processed Files":
                root = candidate
                break
        if root is None:
            root = QTreeWidgetItem(["Processed Files"])
            self.tree.addTopLevelItem(root)
        item = QTreeWidgetItem([path.name])
        item.setData(0, Qt.UserRole, ("processed", str(path)))
        root.addChild(item)
        root.setExpanded(True)
        self.tree.setCurrentItem(item)

    def _display_processed_result(self, image: np.ndarray, path: Path):
        self.current_image = np.asarray(image, dtype=float)
        self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)
        self.current_source = str(path)
        self.current_ds = None
        self.source_kind = "processed"
        self.original_window_level = None
        self.original_dynamic_range = None
        self.raw_window_level = None
        self.raw_dynamic_range = None
        self.view_mode = "Both"
        self._update_output_root_label()
        self.refresh_images()


    def load_processed_image(self, path_value: str):
        path = Path(path_value)
        if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp"}:
            self.load_bitmap_image(path)
            return

        if str(path) in self.processed_images:
            image = self.processed_images[str(path)]
        elif path.suffix.lower() == ".npy":
            image = np.load(path, allow_pickle=False)
        elif path.suffix.lower() == ".dcm":
            entry = self.read_dicom(path)
            image = entry.image
            self.current_ds = entry.ds
        else:
            return

        self.current_image = np.asarray(image, dtype=float)
        self.current_kspace = fft2c(self.current_image)
        self.current_recon = ifft2c(self.current_kspace)
        self.current_source = str(path)
        self.source_kind = "processed"
        self.original_window_level = None
        self.original_dynamic_range = None
        self.raw_window_level = None
        self.raw_dynamic_range = None
        self.view_mode = "Both"
        self._update_output_root_label()
        self.refresh_images()


    def _artifact_detection_indices(self):
        self._tree_selection_changed()
        if self.detect_selected_only.isChecked() and self.artifact_selected_indices:
            return list(self.artifact_selected_indices)
        return list(range(len(self.dicom_entries)))

    def detect_artifacts_from_db(self):
        if not self._ensure_artifact_database():
            return

        keys, training, labels, metadata = self.artifact_db.training_feature_vectors()
        indices = self._artifact_detection_indices()
        if not indices:
            QMessageBox.information(self, "Artifact Detection", "No DICOM images are available.")
            return

        progress = self._make_progress("Artifact Detection", len(indices))
        results = []
        try:
            for count, index in enumerate(indices, start=1):
                if progress.wasCanceled():
                    break
                entry = self.dicom_entries[index]
                progress.setLabelText(f"Classifying image: {entry.path.name}")
                features = image_features(entry.image, self.normal_reference_image)
                vector = features_to_vector(features, keys)
                result = classify_feature_vector(
                    vector,
                    training,
                    labels,
                    minimum_samples_per_class=self.detect_min_samples.value(),
                )
                results.append({
                    "index": index,
                    "entry": entry,
                    "features": features,
                    "result": result,
                })
                progress.setValue(count)
        finally:
            progress.close()

        self._artifact_detection_results = results
        self.artifact_detection_table.setRowCount(len(results))
        predicted_counts = {}
        for row, item in enumerate(results):
            entry = item["entry"]
            result = item["result"]
            predicted_counts[result.label] = predicted_counts.get(result.label, 0) + 1
            alternatives = ", ".join(
                f"{label} {confidence * 100:.1f}%"
                for label, confidence, distance, support in result.alternatives[1:4]
            )
            values = [
                entry.path.name,
                str(getattr(entry.ds, "SeriesDescription", "") or getattr(entry.ds, "ProtocolName", "")),
                result.label,
                f"{result.confidence * 100:.1f}%",
                f"{result.distance:.4f}" if np.isfinite(result.distance) else "-",
                result.support,
                result.status,
                alternatives,
                str(entry.path),
            ]
            for column, value in enumerate(values):
                table_item = QTableWidgetItem(str(value))
                table_item.setData(Qt.UserRole, row)
                self.artifact_detection_table.setItem(row, column, table_item)

        self.artifact_detection_table.resizeColumnsToContents()
        summary = ", ".join(f"{label}: {count}" for label, count in sorted(predicted_counts.items()))
        self.artifact_detection_summary.setText(
            f"Detected {len(results)} image(s). {summary or 'No prediction results.'}"
        )

    def open_detected_artifact_image(self, row: int, column: int):
        if not hasattr(self, "_artifact_detection_results"):
            return
        if row < 0 or row >= len(self._artifact_detection_results):
            return
        result = self._artifact_detection_results[row]
        self.show_dicom(int(result["index"]))
        self.tabs.setCurrentIndex(0)

    def send_detected_rows_to_learning(self):
        if not hasattr(self, "_artifact_detection_results"):
            return
        selected_rows = sorted(
            {item.row() for item in self.artifact_detection_table.selectedItems()}
        )
        if not selected_rows:
            return
        indices = []
        predicted_labels = []
        for row in selected_rows:
            result = self._artifact_detection_results[row]
            indices.append(int(result["index"]))
            predicted_labels.append(result["result"].label)
        self.artifact_selected_indices = sorted(set(indices))
        if predicted_labels and len(set(predicted_labels)) == 1:
            self.artifact_type_combo.setCurrentText(predicted_labels[0])
        self.artifact_selection_label.setText(
            f"Training images ready from detection: {len(self.artifact_selected_indices)}"
        )
        self.tabs.setCurrentIndex(2)

    def clear_selected_images(self):
        selected=[]
        for item in self.tree.selectedItems():
            data=item.data(0,Qt.UserRole)
            if data and data[0]=="dicom": selected.append(int(data[1]))
        selected=sorted(set(selected),reverse=True)
        if not selected: return
        if QMessageBox.question(self,"Clear Selected Images",f"Remove {len(selected)} selected image(s)?") != QMessageBox.Yes: return
        for i in selected:
            if 0 <= i < len(self.dicom_entries): self.dicom_entries.pop(i)
        if self.dicom_entries: self.populate_dicom_tree(); self.show_dicom(min(getattr(self,"slice_index",0),len(self.dicom_entries)-1))
        else: self._reset_image_state()

    def clear_all_images(self):
        if QMessageBox.question(self,"Clear All Images","Clear all imported images and image editing state?") != QMessageBox.Yes: return
        self.dicom_entries.clear(); self._reset_image_state()

    def _reset_image_state(self):
        self.current_image=None; self.current_kspace=None; self.current_recon=None; self.current_ds=None; self.current_source=""; self.tree.clear(); self.primary_panel.image_item.clear(); self.secondary_panel.image_item.clear(); self.profile_plot.clear(); self.slice_label.setText("Slice: -"); self.info.setText("No file loaded")
        self.compensation_history=[]; self.compensation_history_index=-1; self.addsub_a=None; self.addsub_b=None; self.addsub_preview_result=None; self.addsub_status.setText("A: -\nB: -")

    def remove_selected_signal(self):
        i=self.signal_combo.currentIndex()
        if 0 <= i < len(self.signals): self.signals.pop(i); self.signal_combo.clear(); self.signal_combo.addItems([x["name"] for x in self.signals]); self.update_signal_plot()

    def clear_addsub_slot(self,slot:str):
        if slot=="A": self.addsub_a=None
        else: self.addsub_b=None
        self.addsub_status.setText(f"A: {self.addsub_a['name'] if self.addsub_a else '-'}\nB: {self.addsub_b['name'] if self.addsub_b else '-'}")

    def clear_addsub_result(self):
        self.addsub_preview_result=None; self.addsub_preview_operation=""; self.save_addsub_button.setEnabled(False)

    def clear_compensation_history(self):
        if self.compensation_base_kspace is not None:
            self.current_kspace = np.asarray(self.compensation_base_kspace).copy()
            self.current_recon = ifft2c(self.current_kspace)
            if self.compensation_base_image is not None:
                self.current_image = np.asarray(self.compensation_base_image).copy()
            else:
                self.current_image = np.abs(self.current_recon)

        self.compensation_history = []
        self.compensation_history_index = -1
        self.compensation_preview = None
        self.compensation_original = None
        self.compensation_original_kspace = None
        if self.compensation_roi_panel is not None:
            self.compensation_roi_panel.hide_comp_roi()
        self.compensation_roi_panel = None
        self._update_compensation_history_buttons()
        self.comp_status_label.setText("Compensation history cleared — original restored")
        self.refresh_images()


    def clear_selected_artifact_training(self):
        self.artifact_selected_indices=[]; self.artifact_preview_position=0; self.artifact_selection_label.setText("No training images selected."); self.artifact_preview_panel.image_item.clear()

    def clear_all_artifact_training(self):
        self.clear_selected_artifact_training(); self.normal_reference_image=None; self.normal_reference_path=None; self.artifact_normal_label.setText("Normal reference: None")

    def _tree_selection_changed(self):
        indices = []
        for item in self.tree.selectedItems():
            data = item.data(0, Qt.UserRole)
            if data and data[0] == "dicom":
                indices.append(int(data[1]))
        self.artifact_selected_indices = sorted(set(indices))
        if hasattr(self, "artifact_selection_label"):
            self.artifact_selection_label.setText(
                f"Selected DICOM images in Explorer: {len(self.artifact_selected_indices)}"
            )

    def _ensure_artifact_database(self):
        if self.artifact_db is None:
            self.open_artifact_database()
        return self.artifact_db is not None

    def open_artifact_database(self):
        choice = QMessageBox(self)
        choice.setWindowTitle("Artifact Database")
        choice.setText("Open an existing database or create a new database.")
        open_button = choice.addButton("Open Existing", QMessageBox.AcceptRole)
        create_button = choice.addButton("Create New", QMessageBox.ActionRole)
        choice.addButton("Cancel", QMessageBox.RejectRole)
        choice.exec()

        clicked = choice.clickedButton()
        if clicked == open_button:
            filename, _ = QFileDialog.getOpenFileName(
                self, "Open Artifact Database", "",
                "SQLite database (*.sqlite *.db);;All files (*)"
            )
        elif clicked == create_button:
            filename, _ = QFileDialog.getSaveFileName(
                self, "Create Artifact Database", "MR_Artifact_Learning.sqlite",
                "SQLite database (*.sqlite *.db)"
            )
        else:
            return

        if not filename:
            return
        path = Path(filename)
        if path.suffix.lower() not in {".sqlite", ".db"}:
            path = path.with_suffix(".sqlite")
        if self.artifact_db is not None:
            self.artifact_db.close()
        self.artifact_db = ArtifactDatabase(path)
        self.artifact_db_path = path
        self.artifact_db_label.setText(f"Artifact DB: {path}")
        self.refresh_artifact_lists()
        self.refresh_artifact_training_table()


    def refresh_artifact_lists(self):
        if self.artifact_db is None:
            return
        self.artifact_type_combo.clear()
        self.artifact_type_combo.addItems(self.artifact_db.artifact_types())
        self.artifact_resolution_combo.clear()
        self.artifact_resolution_combo.addItems(self.artifact_db.resolutions())

    def add_artifact_type_manual(self):
        if not self._ensure_artifact_database():
            return
        value = self.artifact_new_type.text().strip()
        if value:
            self.artifact_db.add_artifact_type(value)
            self.refresh_artifact_lists()
            self.artifact_type_combo.setCurrentText(value)
            self.artifact_new_type.clear()

    def add_resolution_manual(self):
        if not self._ensure_artifact_database():
            return
        value = self.artifact_new_resolution.text().strip()
        if value:
            self.artifact_db.add_resolution(value)
            self.refresh_artifact_lists()
            self.artifact_resolution_combo.setCurrentText(value)
            self.artifact_new_resolution.clear()

    def collect_selected_artifact_images(self):
        self._tree_selection_changed()
        if not self.artifact_selected_indices and self.dicom_entries:
            self.artifact_selected_indices = [getattr(self, "slice_index", 0)]
        self.artifact_selection_label.setText(
            f"Training images ready: {len(self.artifact_selected_indices)}"
        )
        self.tabs.setCurrentIndex(2)

    def preview_artifact_learning_image(self):
        self._tree_selection_changed()
        if not self.artifact_selected_indices:
            QMessageBox.information(
                self, "Artifact Learning Preview", "Select one or more DICOM images in Explorer."
            )
            return
        self.artifact_preview_position = max(
            0, min(self.artifact_preview_position, len(self.artifact_selected_indices) - 1)
        )
        index = self.artifact_selected_indices[self.artifact_preview_position]
        if not (0 <= index < len(self.dicom_entries)):
            return
        entry = self.dicom_entries[index]
        self.artifact_preview_panel.label.setText(
            f"Artifact Learning Preview: {entry.path.name} "
            f"({self.artifact_preview_position + 1}/{len(self.artifact_selected_indices)})"
        )
        self.artifact_preview_panel.set_image(np.asarray(entry.image, dtype=float))
        self.artifact_selection_label.setText(
            f"Training images ready: {len(self.artifact_selected_indices)} | "
            f"Previewing {entry.path.name}"
        )

    def navigate_artifact_preview(self, step: int):
        if not self.artifact_selected_indices:
            self._tree_selection_changed()
        if not self.artifact_selected_indices:
            return
        self.artifact_preview_position = (
            self.artifact_preview_position + int(step)
        ) % len(self.artifact_selected_indices)
        self.preview_artifact_learning_image()

    def set_current_normal_reference(self):
        if self.current_image is None:
            QMessageBox.information(self, "Normal Reference", "Load an image first.")
            return
        self.normal_reference_image = np.asarray(self.current_image, dtype=float).copy()
        self.normal_reference_path = Path(self.current_source) if self.current_source else None
        self.artifact_normal_label.setText(
            f"Normal reference: {self.normal_reference_path or 'Current image'}"
        )

    def load_normal_reference(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Load Normal Reference", "",
            "DICOM or NumPy (*.dcm *.ima *.npy *.npz);;All files (*)"
        )
        if not filename:
            return
        path = Path(filename)
        try:
            if path.suffix.lower() == ".npy":
                image = np.load(path, allow_pickle=False)
            elif path.suffix.lower() == ".npz":
                archive = np.load(path, allow_pickle=False)
                image = archive[list(archive.keys())[0]]
            else:
                image = self.read_dicom(path).image
            image = np.asarray(image).squeeze()
            if image.ndim != 2:
                raise ValueError(f"Normal reference must be 2D: {image.shape}")
            self.normal_reference_image = image.astype(float)
            self.normal_reference_path = path
            self.artifact_normal_label.setText(f"Normal reference: {path}")
        except Exception as exc:
            QMessageBox.critical(self, "Normal Reference Error", str(exc))

    def save_artifact_training_samples(self):
        if not self._ensure_artifact_database():
            return
        indices = [
            i for i in self.artifact_selected_indices
            if 0 <= i < len(self.dicom_entries)
        ]
        if not indices:
            QMessageBox.information(self, "Artifact Learning", "Select DICOM images first.")
            return
        artifact_type = self.artifact_type_combo.currentText().strip() or "Not Artifact"
        resolution = self.artifact_resolution_combo.currentText().strip()
        notes = self.artifact_notes.toPlainText().strip()
        progress = self._make_progress("Saving Artifact Training Samples", len(indices))
        saved = 0
        try:
            for count, index in enumerate(indices, start=1):
                if progress.wasCanceled():
                    break
                entry = self.dicom_entries[index]
                progress.setLabelText(f"Analyzing image: {entry.path.name}")
                features = image_features(entry.image, self.normal_reference_image)
                ds = entry.ds
                self.artifact_db.add_sample(
                    source_path=str(entry.path),
                    source_name=entry.path.name,
                    series_uid=str(getattr(ds, "SeriesInstanceUID", "")),
                    series_description=str(
                        getattr(ds, "SeriesDescription", "")
                        or getattr(ds, "ProtocolName", "")
                    ),
                    instance_number=int(getattr(ds, "InstanceNumber", index) or index),
                    artifact_type=artifact_type,
                    resolution=resolution,
                    is_normal_reference=False,
                    normal_reference_path=str(self.normal_reference_path or ""),
                    features=features,
                    notes=notes,
                )
                saved += 1
                progress.setValue(count)
        finally:
            progress.close()
        self.refresh_artifact_training_table()
        self.artifact_summary.setText(
            f"Saved {saved} sample(s) as {artifact_type}. "
            f"Normal comparison: {'Yes' if self.normal_reference_image is not None else 'No'}"
        )

    def refresh_artifact_training_table(self):
        if self.artifact_db is None:
            self.artifact_training_table.setRowCount(0)
            return
        rows = self.artifact_db.samples()
        self.artifact_training_table.setRowCount(len(rows))
        for r, sample in enumerate(rows):
            try:
                features = json.loads(sample.get("features_json", "{}"))
            except Exception:
                features = {}
            values = [
                sample["id"], sample["source_name"], sample["series_description"],
                sample["instance_number"], sample["artifact_type"],
                sample["resolution"] or "",
                "Yes" if features.get("normal_comparison") else "No",
                sample["source_path"] or "",
            ]
            for c, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.UserRole, int(sample["id"]))
                self.artifact_training_table.setItem(r, c, item)
        self.artifact_training_table.resizeColumnsToContents()

    def reclassify_selected_db_rows(self):
        if self.artifact_db is None:
            return
        rows = sorted({i.row() for i in self.artifact_training_table.selectedItems()})
        artifact_type = self.artifact_type_combo.currentText().strip() or "Not Artifact"
        resolution = self.artifact_resolution_combo.currentText().strip()
        notes = self.artifact_notes.toPlainText().strip()
        for row in rows:
            item = self.artifact_training_table.item(row, 0)
            if item is not None:
                self.artifact_db.update_sample_classification(
                    int(item.data(Qt.UserRole)), artifact_type, resolution, notes
                )
        self.refresh_artifact_training_table()

    def import_artifact_database(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Import Artifact DB JSON", "",
            "Artifact DB JSON (*.json);;All files (*)"
        )
        if not filename:
            return
        if self.artifact_db is None:
            self.open_artifact_database()
        if self.artifact_db is None:
            return
        self.artifact_db.import_json(Path(filename))
        self.refresh_artifact_lists()
        self.refresh_artifact_training_table()


    def export_artifact_database(self):
        if self.artifact_db is None:
            QMessageBox.information(self, "Artifact DB", "Open an Artifact DB first.")
            return
        filename, _ = QFileDialog.getSaveFileName(
            self, "Export Artifact DB JSON", "MRI_Artifact_DB.json",
            "Artifact DB JSON (*.json)"
        )
        if filename:
            if not filename.lower().endswith(".json"):
                filename += ".json"
            self.artifact_db.export_json(Path(filename))

    def fill_header(self, ds):
        return


    def filter_header(self, value):
        return


    def export_header_excel(self):
        if self.current_ds is None: QMessageBox.information(self,'No DICOM','Load a DICOM file first.'); return
        filename,_=QFileDialog.getSaveFileName(self,'Export DICOM Header','DICOM_Header.xlsx','Excel (*.xlsx)')
        if not filename: return
        if not filename.lower().endswith('.xlsx'): filename += '.xlsx'
        wb=Workbook(); ws=wb.active; ws.title='DICOM Header'; headers=['Tag','Keyword','Name','VR','VM','Value']; ws.append(headers)
        for cell in ws[1]: cell.font=Font(bold=True); cell.fill=PatternFill('solid', fgColor='D9EAF7')
        for elem in self.current_ds.iterall():
            if elem.tag.group != 0x7FE0: ws.append([str(elem.tag),elem.keyword,elem.name,elem.VR,str(elem.VM),str(elem.value)])
        ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
        for col,width in {'A':16,'B':28,'C':38,'D':8,'E':8,'F':80}.items(): ws.column_dimensions[col].width=width
        for row in ws.iter_rows():
            for cell in row: cell.alignment=Alignment(vertical='top', wrap_text=True)
        wb.save(filename); self.statusBar().showMessage(f'Exported {filename}')

    def export_npz(self):
        if self.current_image is None: return
        filename,_=QFileDialog.getSaveFileName(self,'Export NPZ','MRI_FFT_Data.npz','NPZ (*.npz)')
        if filename:
            if not filename.lower().endswith('.npz'): filename += '.npz'
            np.savez_compressed(filename,image=self.current_image,kspace=self.current_kspace,reconstruction=self.current_recon,source=self.current_source)

    def closeEvent(self,event):
        if self.artifact_db is not None:
            try:
                self.artifact_db.close()
            except Exception:
                pass
        for d in self.temp_dirs:
            shutil.rmtree(d, ignore_errors=True)
        event.accept()


def main():
    app=QApplication(sys.argv); app.setApplicationName(APP_NAME)
    win=MainWindow(); win.show(); sys.exit(app.exec())


if __name__ == '__main__': main()
