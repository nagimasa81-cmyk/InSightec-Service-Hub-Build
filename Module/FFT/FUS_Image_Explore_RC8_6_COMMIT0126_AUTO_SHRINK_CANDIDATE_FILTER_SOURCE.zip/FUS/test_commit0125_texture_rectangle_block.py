import numpy as np

from core.hybrid_compensation import _detect_texture_rectangles, detect_artifacts


def _textured_rectangle(shape=(192, 192)):
    y, x = np.indices(shape, dtype=float)
    base = 0.12*np.sin(x*0.18) + 0.10*np.cos(y*0.15) + 0.04*np.sin((x+y)*0.09)
    block = (y >= 54) & (y < 132) & (x >= 62) & (x < 148)
    changed = 0.13*np.sin(x*0.42 + y*0.05) + 0.10*np.cos(y*0.31)
    image = base.copy()
    image[block] = changed[block]
    return image


def _texture_detect(image):
    logmag = np.log1p(np.abs(np.asarray(image)))
    return _detect_texture_rectangles(logmag, np.zeros(logmag.shape, dtype=bool))


def test_texture_detector_finds_rectangle_edges_and_bounds():
    mask, candidates, _ = _texture_detect(_textured_rectangle())
    assert np.any(mask)
    assert candidates
    best = candidates[0]
    assert abs(best['x0'] - 62) <= 4
    assert abs(best['x1'] - 148) <= 4
    assert abs(best['y0'] - 54) <= 4
    assert abs(best['y1'] - 132) <= 4
    assert best['confidence'] >= 0.58


def test_uniform_texture_is_rejected_by_texture_detector():
    y, x = np.indices((192, 192), dtype=float)
    image = 0.1*np.sin(x*0.2) + 0.1*np.cos(y*0.18)
    mask, candidates, _ = _texture_detect(image)
    assert not np.any(mask)
    assert candidates == []


def test_public_block_mode_exposes_texture_audit_fields():
    result = detect_artifacts(_textured_rectangle(), 'Block', 3.0, 'Balanced')
    assert result.stats['texture_detector_revision'] == 'texture_rectangle_v1'
    assert result.stats['texture_rectangle_candidates']
    assert result.stats['counts']['block'] > 0
