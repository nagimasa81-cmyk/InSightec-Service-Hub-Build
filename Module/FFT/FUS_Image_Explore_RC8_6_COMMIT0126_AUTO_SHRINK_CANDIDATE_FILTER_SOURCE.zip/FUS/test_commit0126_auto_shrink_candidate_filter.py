import numpy as np
from core.auto_correct import _erode_candidate_mask, _mask_component_count


def test_one_step_shrink_matches_expected_interior():
    mask = np.zeros((9, 9), dtype=bool)
    mask[2:7, 2:7] = True
    shrunk = _erode_candidate_mask(mask, 1)
    expected = np.zeros_like(mask)
    expected[3:6, 3:6] = True
    assert np.array_equal(shrunk, expected)


def test_two_step_shrink_can_reduce_to_single_core():
    mask = np.zeros((9, 9), dtype=bool)
    mask[2:7, 2:7] = True
    shrunk = _erode_candidate_mask(mask, 2)
    assert np.count_nonzero(shrunk) == 1
    assert shrunk[4, 4]


def test_component_counter_supports_fragment_guard():
    mask = np.zeros((8, 8), dtype=bool)
    mask[1:3, 1:3] = True
    mask[5:7, 5:7] = True
    assert _mask_component_count(mask) == 2


def test_normal_auto_contains_shrink_rescue_filter():
    from pathlib import Path
    text = Path('core/auto_correct.py').read_text(encoding='utf-8')
    assert 'auto_shrink_filter' in text
    assert 'rescued_by_auto_shrink' in text
    assert 'for shrink_steps in (1, 2)' in text
