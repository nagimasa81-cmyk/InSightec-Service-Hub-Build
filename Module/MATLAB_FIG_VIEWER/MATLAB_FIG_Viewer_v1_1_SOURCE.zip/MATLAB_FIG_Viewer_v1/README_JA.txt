MATLAB FIG Viewer v1

MATLABを使わずに、MATLAB 7以降のMAT-file形式 .fig を読み込み、再描画するPythonビューアです。

使い方
1. 01_RUN_VIEWER.bat を実行します。
2. Open FIG または画面へのドラッグ＆ドロップで .fig を開きます。
3. Save PNG で300 dpiのPNGを保存します。
4. ツールバーでズーム、パン、表示リセットができます。

EXE作成
02_BUILD_EXE.bat を実行します。
生成先: dist\MATLAB_FIG_Viewer\MATLAB_FIG_Viewer.exe

対応
- axes
- image / CData / colormap / CLim
- line
- text
- 基本的な軸範囲、目盛、YDir
- text形式uicontrol

制限
MATLAB独自のコールバック、UI部品、特殊な描画オブジェクト、App Designer形式は完全再現できません。
このビューアは保存された数値・画像データをMatplotlibで再描画します。

GitHub Actionsビルド
- Module/MATLAB_FIG_Viewer/ に本Source ZIPを配置します。
- .github/workflows/build_matlab_fig_viewer.yml を配置します。
- Actionsから Run workflow を実行します。
- MATLAB_FIG_Viewer_v1.1.0_Windows.zip がArtifactとして生成されます。
