from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Iterable

import numpy as np
from scipy.io import loadmat

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QApplication, QFileDialog, QMainWindow, QMessageBox, QToolBar, QLabel
)

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT
from matplotlib.figure import Figure
from matplotlib.colors import ListedColormap


def fields(obj: Any) -> list[str]:
    return list(getattr(obj, "_fieldnames", []) or [])


def prop(obj: Any, name: str, default: Any = None) -> Any:
    try:
        return getattr(obj, name)
    except Exception:
        return default


def as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, np.ndarray):
        if value.size == 0:
            return []
        return list(value.flat)
    return [value]


def arr(value: Any) -> np.ndarray:
    return np.asarray(value)


def text_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    a = np.asarray(value)
    if a.size == 0:
        return ""
    if a.dtype.kind in "US":
        return "\n".join(str(x) for x in a.flat)
    return str(value)


def color_value(value: Any, default: Any = None) -> Any:
    if isinstance(value, str):
        return value
    try:
        a = np.asarray(value, dtype=float).reshape(-1)
        if a.size >= 3:
            return tuple(np.clip(a[:3], 0, 1))
    except Exception:
        pass
    return default


def finite_pair(value: Any) -> tuple[float, float] | None:
    try:
        a = np.asarray(value, dtype=float).reshape(-1)
        if a.size >= 2 and np.isfinite(a[:2]).all() and a[0] != a[1]:
            return float(a[0]), float(a[1])
    except Exception:
        pass
    return None


def iter_nodes(node: Any) -> Iterable[Any]:
    yield node
    for child in as_list(prop(node, "children")):
        yield from iter_nodes(child)


class FigRenderer:
    def __init__(self, mpl_figure: Figure):
        self.figure = mpl_figure
        self.root = None
        self.default_cmap = None

    def load(self, path: str | Path) -> None:
        data = loadmat(str(path), squeeze_me=True, struct_as_record=False)
        root = data.get("hgS_070000") or data.get("hgS_080000")
        if root is None:
            candidates = [v for k, v in data.items() if not k.startswith("__") and prop(v, "type") == "figure"]
            if not candidates:
                raise ValueError("MATLAB Figure object was not found in this .fig file.")
            root = candidates[0]
        self.root = root
        self.render()

    def render(self) -> None:
        self.figure.clear()
        root_props = prop(self.root, "properties")
        bg = color_value(prop(root_props, "Color"), "white")
        self.figure.patch.set_facecolor(bg)
        cmap_data = prop(root_props, "Colormap")
        if isinstance(cmap_data, np.ndarray) and cmap_data.ndim == 2 and cmap_data.shape[1] >= 3:
            self.default_cmap = ListedColormap(np.clip(cmap_data[:, :3].astype(float), 0, 1))

        axes_nodes = [n for n in as_list(prop(self.root, "children")) if prop(n, "type") == "axes"]
        # MATLAB stores children in reverse stacking order.
        for node in reversed(axes_nodes):
            self._draw_axes(node)

        # Preserve simple text uicontrols as figure annotations.
        for node in reversed(as_list(prop(self.root, "children"))):
            if prop(node, "type") == "uicontrol":
                self._draw_uicontrol(node)

        if not axes_nodes:
            self.figure.text(0.5, 0.5, "No supported axes found", ha="center", va="center")
        self.figure.canvas.draw_idle()

    def _draw_axes(self, node: Any) -> None:
        p = prop(node, "properties")
        pos = np.asarray(prop(p, "Position", [0.13, 0.11, 0.775, 0.815]), dtype=float).reshape(-1)
        if pos.size < 4 or not np.isfinite(pos[:4]).all():
            pos = np.array([0.13, 0.11, 0.775, 0.815])
        pos[:2] = np.clip(pos[:2], 0, 1)
        pos[2:] = np.clip(pos[2:], 0.01, 1)
        ax = self.figure.add_axes(pos[:4])

        ax.set_facecolor(color_value(prop(p, "Color"), "white"))
        ax.set_box_aspect(None)
        if text_value(prop(p, "Box", "off")).lower() == "on":
            for spine in ax.spines.values():
                spine.set_visible(True)

        cmap = self.default_cmap
        local_cmap = prop(p, "Colormap")
        if isinstance(local_cmap, np.ndarray) and local_cmap.ndim == 2 and local_cmap.shape[1] >= 3:
            cmap = ListedColormap(np.clip(local_cmap[:, :3].astype(float), 0, 1))

        clim = finite_pair(prop(p, "CLim"))
        last_mappable = None
        for child in reversed(as_list(prop(node, "children"))):
            ctype = prop(child, "type")
            cp = prop(child, "properties")
            try:
                if ctype == "image":
                    cdata = np.asarray(prop(cp, "CData"))
                    if cdata.size == 0:
                        continue
                    xdata = np.asarray(prop(cp, "XData", [1, cdata.shape[1] if cdata.ndim >= 2 else 1]), dtype=float).reshape(-1)
                    ydata = np.asarray(prop(cp, "YData", [1, cdata.shape[0] if cdata.ndim >= 2 else 1]), dtype=float).reshape(-1)
                    extent = None
                    if xdata.size >= 2 and ydata.size >= 2:
                        extent = [xdata[0], xdata[-1], ydata[-1], ydata[0]]
                    kwargs = {"origin": "upper", "aspect": "auto", "extent": extent}
                    if cdata.ndim == 2:
                        kwargs["cmap"] = cmap
                        if clim:
                            kwargs["vmin"], kwargs["vmax"] = clim
                    last_mappable = ax.imshow(cdata, **kwargs)
                elif ctype == "line":
                    x = np.asarray(prop(cp, "XData", []), dtype=float).reshape(-1)
                    y = np.asarray(prop(cp, "YData", []), dtype=float).reshape(-1)
                    if x.size and y.size:
                        n = min(x.size, y.size)
                        style = text_value(prop(cp, "LineStyle", "-")) or "-"
                        if style == "none":
                            style = ""
                        ax.plot(x[:n], y[:n], linestyle=style,
                                linewidth=float(prop(cp, "LineWidth", 1.0)),
                                color=color_value(prop(cp, "Color"), None))
                elif ctype == "text":
                    s = text_value(prop(cp, "String"))
                    position = np.asarray(prop(cp, "Position", [0, 0]), dtype=float).reshape(-1)
                    if s and position.size >= 2:
                        ax.text(position[0], position[1], s,
                                fontsize=float(prop(cp, "FontSize", 10)),
                                color=color_value(prop(cp, "Color"), "black"),
                                backgroundcolor=color_value(prop(cp, "BackgroundColor"), "none"),
                                visible=text_value(prop(cp, "Visible", "on")) != "off")
            except Exception:
                # Unsupported child objects should not prevent the rest of the figure from opening.
                continue

        xlim = finite_pair(prop(p, "XLim"))
        ylim = finite_pair(prop(p, "YLim"))
        if xlim:
            ax.set_xlim(xlim)
        if ylim:
            ax.set_ylim(ylim)
        if text_value(prop(p, "YDir", "normal")).lower() == "reverse" and not ax.yaxis_inverted():
            ax.invert_yaxis()

        xticks = np.asarray(prop(p, "XTick", []), dtype=float).reshape(-1)
        yticks = np.asarray(prop(p, "YTick", []), dtype=float).reshape(-1)
        if xticks.size:
            ax.set_xticks(xticks)
        if yticks.size:
            ax.set_yticks(yticks)
        xlabels = as_list(prop(p, "XTickLabel"))
        ylabels = as_list(prop(p, "YTickLabel"))
        if xlabels:
            ax.set_xticklabels([text_value(x) for x in xlabels])
        if ylabels:
            ax.set_yticklabels([text_value(x) for x in ylabels])

        ax.grid(text_value(prop(p, "XGrid", "off")) == "on" or text_value(prop(p, "YGrid", "off")) == "on")
        try:
            ax.tick_params(width=float(prop(p, "LineWidth", 0.8)))
        except Exception:
            pass

    def _draw_uicontrol(self, node: Any) -> None:
        p = prop(node, "properties")
        if text_value(prop(p, "Style", "")) != "text":
            return
        s = text_value(prop(p, "String"))
        pos = np.asarray(prop(p, "Position", []), dtype=float).reshape(-1)
        if not s or pos.size < 4:
            return
        self.figure.text(pos[0], pos[1] + pos[3] / 2, s,
                         ha="left", va="center",
                         fontsize=float(prop(p, "FontSize", 8)))


class MainWindow(QMainWindow):
    def __init__(self, initial_file: str | None = None):
        super().__init__()
        self.setWindowTitle("MATLAB FIG Viewer")
        self.resize(1200, 850)
        self.setAcceptDrops(True)

        self.figure = Figure(figsize=(10, 7), dpi=100)
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.renderer = FigRenderer(self.figure)
        self.current_path: Path | None = None
        self.setCentralWidget(self.canvas)

        toolbar = QToolBar("File")
        self.addToolBar(toolbar)
        open_action = QAction("Open FIG", self)
        open_action.setShortcut("Ctrl+O")
        open_action.triggered.connect(self.open_dialog)
        toolbar.addAction(open_action)
        save_action = QAction("Save PNG", self)
        save_action.setShortcut("Ctrl+S")
        save_action.triggered.connect(self.save_png)
        toolbar.addAction(save_action)
        toolbar.addSeparator()
        toolbar.addWidget(NavigationToolbar2QT(self.canvas, self))
        self.status = QLabel("Drop a MATLAB .fig file here")
        self.statusBar().addWidget(self.status)

        if initial_file:
            self.open_file(initial_file)

    def open_dialog(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Open MATLAB Figure", "", "MATLAB Figure (*.fig);;All files (*)")
        if path:
            self.open_file(path)

    def open_file(self, path: str) -> None:
        try:
            self.renderer.load(path)
            self.current_path = Path(path)
            self.setWindowTitle(f"MATLAB FIG Viewer - {self.current_path.name}")
            self.status.setText(str(self.current_path))
        except Exception as exc:
            QMessageBox.critical(self, "Open failed", f"Could not open the FIG file.\n\n{exc}")

    def save_png(self) -> None:
        default = str((self.current_path or Path("figure.fig")).with_suffix(".png"))
        path, _ = QFileDialog.getSaveFileName(self, "Save PNG", default, "PNG image (*.png)")
        if not path:
            return
        try:
            self.figure.savefig(path, dpi=300, facecolor=self.figure.get_facecolor(), bbox_inches="tight")
            self.status.setText(f"Saved: {path}")
        except Exception as exc:
            QMessageBox.critical(self, "Save failed", str(exc))

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls() and any(u.toLocalFile().lower().endswith(".fig") for u in event.mimeData().urls()):
            event.acceptProposedAction()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            path = url.toLocalFile()
            if path.lower().endswith(".fig"):
                self.open_file(path)
                break


def main() -> int:
    app = QApplication(sys.argv)
    initial = sys.argv[1] if len(sys.argv) > 1 else None
    win = MainWindow(initial)
    win.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
