@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PYTHON_CMD="
where py >nul 2>nul && set "PYTHON_CMD=py -3.12"
if not defined PYTHON_CMD (
  where python >nul 2>nul && set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD (
  echo [ERROR] Python was not found.
  exit /b 1
)

if not exist .venv (
  %PYTHON_CMD% -m venv .venv
  if errorlevel 1 exit /b 1
)
call .venv\Scripts\activate.bat
if errorlevel 1 exit /b 1

python -m pip install --upgrade pip wheel setuptools
if errorlevel 1 exit /b 1
python -m pip install -r requirements.txt pyinstaller
if errorlevel 1 exit /b 1

python -m py_compile matlab_fig_viewer.py
if errorlevel 1 exit /b 1

rmdir /s /q build 2>nul
rmdir /s /q dist 2>nul
del /q MATLAB_FIG_Viewer.spec 2>nul

pyinstaller --noconfirm --clean --windowed ^
  --name MATLAB_FIG_Viewer ^
  --collect-all scipy ^
  --collect-all matplotlib ^
  --collect-all PySide6 ^
  --hidden-import scipy.io.matlab ^
  matlab_fig_viewer.py
if errorlevel 1 (
  echo [ERROR] Build failed.
  exit /b 1
)

if not exist "dist\MATLAB_FIG_Viewer\MATLAB_FIG_Viewer.exe" (
  echo [ERROR] EXE was not generated.
  exit /b 1
)
copy /y version.json "dist\MATLAB_FIG_Viewer\version.json" >nul
copy /y README_JA.txt "dist\MATLAB_FIG_Viewer\README_JA.txt" >nul

echo [PASS] dist\MATLAB_FIG_Viewer\MATLAB_FIG_Viewer.exe
exit /b 0
