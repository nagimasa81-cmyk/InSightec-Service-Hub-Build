# RC2.6.1 test checklist

- Open Operation and confirm the outer Sonication panel is collapsed.
- Use Show Sonication Panel and Hide Sonication Panel.
- Confirm Operation Events is shown on the left.
- Confirm Phase Overview, Operation chart and Lifecycle track are stacked on the right.
- Confirm all three time axes align.
- Drag to zoom and verify all three rows zoom together.
- Double-click and verify all three rows reset.
- Click a phase band, event marker and lifecycle marker and verify row navigation.
- Load a DQA-only ZIP and confirm Show DQA turns on automatically.
- Confirm the smaller drop zone still accepts click and drag/drop.
