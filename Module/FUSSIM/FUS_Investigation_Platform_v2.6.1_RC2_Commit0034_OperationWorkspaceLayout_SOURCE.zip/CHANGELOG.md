# Changelog

## v2.6.1-RC2 — Commit0034_OperationWorkspaceLayout

- Operation tab collapses the outer Sonication/details panel by default.
- Added Show/Hide Sonication Panel control inside Operation.
- Moved Operation Events table to the left side of the Operation workspace.
- Right side contains three vertically synchronized timelines:
  1. Treatment Phase Overview
  2. Operation Event chart
  3. WS/CPC Lifecycle track
- All three timelines share identical x-limits and time ticks.
- Drag zoom updates all three timelines.
- Double-click reset restores all synchronized timelines.
- Clicking phase, event, or lifecycle markers navigates to the matching log row.
- Reduced the top drop zone to approximately one-quarter of the previous footprint.
- DQA-only datasets automatically enable Show DQA.
- Preserved progressive Operation row loading and all Consolidated Recovery baseline functions.
