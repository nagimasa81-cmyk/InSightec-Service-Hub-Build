# Changelog

## v2.6.0-RC2 — Commit0033_ConsolidatedRecoveryBaseline

- Established a consolidated baseline from the triple-checked RC2.5.2 source.
- Added a permanent feature manifest covering Loader, Sonication, MR, RAW, Thermometry, Spectrum, Operation, Review and Export.
- Added an executable regression checker and Windows BAT launcher.
- Added explicit release, refresh, evidence and performance contracts.
- Preserved all-Sonication RAW recovery, MEMP/TMAP thermometry rules, Operation progressive loading and WS/CPC lifecycle tracking.
- No experimental feature was removed during consolidation.
