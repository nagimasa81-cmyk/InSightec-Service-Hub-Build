# RC2.4.6 test checklist

- Open the ZIP that previously stalled at 88%.
- Confirm loading completes and the application remains responsive.
- Open Operation and confirm 500 rows are initially displayed.
- Press Load More repeatedly.
- Confirm displayed / total count updates.
- Click a chart marker linked to a row beyond the first 500 and confirm its page loads automatically.
- Verify full WS log filters and Treatment Phase tags remain available.
- Confirm chart phase backgrounds, zoom and double-click reset still work.
- Confirm RAW Series and MR Series viewers remain functional.
