# Changelog

## v2.4.6-RC2 — Commit0026_OperationProgressiveLoadingHotFix

- Fixed long UI stalls at `Building review tables...`.
- Operation initially renders the first 500 rows instead of every WS-log event.
- Added Load More paging in 500-row increments.
- Added displayed-row / total-row status.
- Row wrapping and automatic height are calculated only for newly displayed pages.
- Marker navigation automatically loads the page containing the target row.
- Operation chart limits plotted markers for extremely large logs while preserving the full table dataset.
- Chart points are grouped by category to reduce Matplotlib object count.
- Added periodic Qt event processing during page resizing.
- Preserved complete WS log scope, Treatment Phase tags and phase background overlays.
