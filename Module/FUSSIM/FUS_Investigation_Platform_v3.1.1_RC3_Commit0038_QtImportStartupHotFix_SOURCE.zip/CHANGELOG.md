# Changelog

## v3.1.1-RC3-PROTOTYPE — Commit0038_RC3QtImportStartupHotFix

- Fixed RC3 startup crash: `QProgressBar is not defined`.
- Added missing PySide6 QtWidgets imports used by RC3 workspaces.
- Automatically checked all known Qt widget classes referenced by `app.py`.
- Added pre-build Qt import validator.
- Preserved the independent New Analysis Core and all RC3 workspaces.
