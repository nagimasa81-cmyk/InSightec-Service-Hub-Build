@echo off
python VERIFY_RC3_QT_IMPORTS.py
if errorlevel 1 (
  echo RC3 source verification failed.
  pause
  exit /b 1
)
pause
