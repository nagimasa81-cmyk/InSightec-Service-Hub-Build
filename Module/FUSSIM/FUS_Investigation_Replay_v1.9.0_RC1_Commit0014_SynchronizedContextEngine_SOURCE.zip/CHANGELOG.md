# Changelog

## v1.9.0-RC1 — Commit0014_SynchronizedContextEngine

- Fixed the upper-left Sonication selection not updating the review panels.
- Added stable current-Sonication context keyed by Sonication number.
- Added row click, current-cell and selection-model event coverage.
- Added explicit refresh after Treatment/DQA list reconstruction.
- Previous/Next now uses the same central selection route.
- All Replay, Thermometry, Spectrum, Hydrophone, details and evidence panels refresh together.
- Matplotlib canvases are explicitly redrawn after every context change.
- Retained RC1.8.1 Spectrum regression fallbacks and RC1.7 deep RAW resolver.

See CHANGELOG.old.md for prior history.
