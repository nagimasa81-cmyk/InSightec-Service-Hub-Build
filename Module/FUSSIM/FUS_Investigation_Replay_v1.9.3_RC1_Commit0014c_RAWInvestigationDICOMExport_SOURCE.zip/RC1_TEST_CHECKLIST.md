# RC1 Test Checklist

1. Build succeeds with Python 3.13 and `fast_pyinstaller`.
2. Application starts without a console window.
3. Open `09-09-11_ANx.zip` and verify Sonication table, Complete Inventory and RAW Investigation tabs populate.
4. Open `22-55-19_ANx.zip` and verify explicit Brain-DQA metadata classifies Sonications as DQA.
5. Verify each Sonication can independently change Phase, Scan Plane and Frequency Direction.
6. Verify DQA displays a DQA phantom example and Treatment displays a T2 brain example when no image is linked.
7. Link an MR/DICOM folder and save the `.fus_review.json` sidecar.
8. Reopen the ZIP and verify mappings are restored.
9. Verify Spectrum axis defaults to frequency versus amplitude and remains labeled relative when calibration is unavailable.
10. Confirm simulated/experimental content is visibly labeled and not presented as confirmed clinical data.

## RC1.1 Multi-Hydrophone checks

- [ ] SpectrumMsg count appears in the loaded ZIP summary.
- [ ] Sonication selection links to the matching `SonicationN/SpectrumMsg-N.dmp`.
- [ ] Hydrophone selector includes 1–8.
- [ ] Display selector includes Single, All Overlay, All Separate, Average, Maximum Envelope, Spectrogram.
- [ ] All Separate renders without GUI failure for 4–8 candidate channels.
- [ ] Cavitation tab never displays simulated data.
- [ ] Experimental source/calibration warning is visible.
- [ ] Left Sonication list scrolls horizontally and vertically.
- [ ] Selected Sonication details appear below the list.


## RC1.3 Thermometry / Acoustic checks

- Open both supplied treatment ZIP formats.
- Select DQA and Treatment Sonications and confirm Thermometry Replay updates.
- Move the Thermometry frame slider and confirm baseline/current/difference updates.
- Confirm all thermometry candidate views retain the unvalidated calibration warning.
- Confirm Spectrum modes: Channel Heatmap and Relative Cavitation Bands.
- Confirm Hydrophone Cavitation contains no simulated trace.
- Confirm Previous/Next updates fixed details, replay, thermometry, spectrum and cavitation.


## RC1.4 checks

- Confirm Treatment only is shown immediately after ZIP load.
- Enable Show DQA and confirm DQA rows appear.
- Confirm Previous/Next follows the filtered list.
- Toggle Ch 1–8 and confirm Spectrum and Acoustic Activity update.
- Drag over the upper Acoustic Activity chart and confirm selected-range FFT appears.
- Confirm channel metrics are hidden initially and appear only when expanded.
- Confirm MR Replay shows the integrated image, thermometry, spectrum and activity dashboard.
- Confirm RAW-derived hotspot is labeled as a phase-difference candidate; fallback hotspot is labeled simulated.

## RC1.5 synchronization and geometry checks

- Confirm the Time Synchronization tab lists every Sonication.
- Confirm TMAP/MEMP series score higher than unrelated MR series.
- Confirm plane mismatch rejects an otherwise close-in-time MR series.
- Confirm frequency-direction mismatch rejects automatic Replay use.
- Confirm RAW Investigation can still inspect rejected RAW files.
- Confirm Replay falls back to an Example image when RAW geometry is unknown or mismatched.
- Confirm manual MR series, plane and frequency-direction override still works.
- Confirm Maximum Information shows match score, corrected gap, offset model, reasons and rejected candidates.

## RC1.6 Sonication-folder-first checks

- Select several Sonications and confirm Replay source begins with `Priority 1 — Same Sonication folder` when RAW exists in the exact folder.
- Confirm a RAW file from another Sonication folder is never silently used.
- Confirm the fixed details show the exact Sonication-folder content counts.
- Confirm Thermometry Replay uses the same dominant consistent RAW group.
- Confirm known plane/frequency mismatches reject the same-folder RAW and show the reason.
- Confirm unknown geometry is clearly marked unconfirmed.
- Confirm external MR/DICOM is used only after same-folder reconstruction is unavailable or rejected.
- Confirm Example image is the final fallback.


## RC1.7 Deep ZIP Resolver

- Open `09-09-11_ANx.zip` and confirm import progress remains responsive.
- Open `22-55-19_ANx.zip` and confirm `RAW Series Resolver` contains TMAP-ME and DQA series.
- Confirm Sonication 1 in the 2025 sample resolves Field 5/Zone 3 and Field 6/Zone 0 as TMAP-ME candidates.
- Confirm the 2026 sample resolves MEMP candidates separately from T2 Axial/Coronal/Sagittal and 512x512 anatomical series.
- Confirm Thermometry Replay reports exact field/zone/protocol and XML coverage.
- Confirm a large unrelated RAW series is not selected merely because it has the greatest frame count.
- Confirm Previous/Next updates Replay, Thermometry, Spectrum, Cavitation, fixed details, and evidence.

## RC1.8 Spectrum integration checks

- Load both supplied treatment ZIP exports.
- Confirm SpectrumMsg reports 8 hydrophone channels when present.
- Confirm 256 bins and approximately 1.953 kHz/bin are displayed.
- Confirm frequency axis is in MHz and centered on the selected Sonication frequency.
- Toggle Ch 1–8 and verify Spectrum and Hydrophone plots update.
- Test Single, All Overlay, All Separate, Average, Maximum Envelope, Spectrogram, Channel Heatmap, Cavitation Metrics and Frame Metrics Timeline.
- Drag a range on the acoustic activity chart and confirm the lower plot averages only FFT frames in that interval.
- Confirm no simulated cavitation trace is shown.

## RC1.9 synchronized context regression

- Click every visible Treatment row and confirm the fixed Sonication number changes.
- Confirm MR/Hotspot, Thermometry, Spectrum and Hydrophone panels update on every click.
- Click the already-selected row again and confirm an explicit refresh occurs.
- Use Previous and Next and confirm all panels update through the same route.
- Turn Show DQA on/off and confirm the selected Sonication is retained when still visible.
- Change phase, plane, frequency direction and MR series and confirm all panels redraw.


## RC1.9.1 selection regression

- Click every visible Sonication row and confirm fixed Sonication number, start time, phase and power change immediately.
- Confirm Previous and Next use the same selected Sonication.
- Toggle Show DQA and confirm selection remains consistent.
- Confirm a Spectrum or Thermometry decoder error does not prevent details, timeline, evidence and other panels from updating.
- Confirm failed charts show a diagnostic instead of retaining the previous Sonication plot.

## RC1.9.2 responsive selection checks

- Rapidly click through five Sonications and confirm the UI remains responsive.
- Confirm fixed details settle on the last selected Sonication.
- Switch to MR / Hotspot Replay and confirm only that heavy panel is decoded.
- Switch to Thermometry, Hydrophone and Spectrum tabs and confirm each loads on demand.
- Confirm no busy cursor remains indefinitely after changing rows.
- Confirm Previous / Next remain responsive.


## RC1.9.3 RAW-to-DICOM export

- Open a treatment ZIP containing RAW candidates.
- Open RAW Investigation and confirm the preview still works.
- Click `Export All Decoded Images as DICOM` and choose a writable empty folder.
- Confirm valid RAW candidates are written under Sonication subfolders.
- Confirm undecodable RAW files are skipped and the batch continues.
- Open several exported files with a DICOM viewer and verify dimensions and grayscale pixels.
- Confirm `RAW_DICOM_EXPORT_REPORT.txt` lists exported and skipped files with reasons.
- Cancel during a large export and confirm the application remains responsive and completed files remain valid.
