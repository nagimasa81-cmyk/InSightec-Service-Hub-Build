# Changelog

## v2.1.0-RC2 — Commit0016_ThermometryCoilRules_RAWLayout

- TMAP and MEMP are now confirmed thermometry protocols.
- Coil Name containing `FUS ... Tracking` is classified as XD position / motion detection and excluded from thermometry replay.
- 1.5T thermometry: `FUS 2ch Head` coil strengthens TMAP/MEMP classification.
- 3T thermometry: `Body` coil strengthens TMAP/MEMP classification. Body coil alone does not confirm thermometry.
- Calibration is classified as pre-acquisition calibration data and is not used as a replay image.
- RAW Investigation now has a collapsible Protocol Summary.
- RAW Protocol Summary shows protocol, coil, classification, confidence, frame count, plane and frequency direction.
- RAW list/details and image viewer are separated by a vertically adjustable splitter.
- RAW preview metadata now displays the classification rule and evidence.
