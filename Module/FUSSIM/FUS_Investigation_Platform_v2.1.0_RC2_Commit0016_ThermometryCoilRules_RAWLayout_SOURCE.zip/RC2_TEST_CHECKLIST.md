# RC2.1 Test Checklist

- Build using the supplied RC1 Runtime Complete workflow.
- Open a full treatment ZIP and a Sonication-only ZIP.
- Confirm TMAP/MEMP rows classify as Thermometry.
- Confirm `FUS ... Tracking` coil rows classify as XD Position / Motion Detection.
- Confirm Calibration rows are excluded from replay-image candidates.
- Confirm 1.5T `FUS 2ch Head` and 3T `Body` coil evidence appears in RAW metadata.
- Collapse and expand Protocol Summary in RAW Investigation.
- Drag the vertical splitter to enlarge the RAW list or image viewer.
- Confirm RAW DICOM export remains available.
- Confirm Sonication selection and existing Spectrum/Decoder Lab functionality still update.
