# Changelog

## v1.9.4-RC1 — Commit0014d_SonicationImageSequenceResolver

- Added standalone Sonication-folder ZIP import when no treatment Summary exists.
- Added ZIP drag-and-drop import.
- Added exact Sonication image-sequence catalog.
- Added Field/Sub/Zone/Array grouping and natural frame ordering.
- Added actual RAW frame viewer and first-frame difference view.
- Added candidate pre/during/post stage mapping using treatment duration and MR cadence evidence.
- Added explicit role/confidence labels and preserved unknown sequences.
- Retained RAW-to-DICOM bulk export and existing Replay/Spectrum features.
