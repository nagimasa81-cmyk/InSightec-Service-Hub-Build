from __future__ import annotations

from pathlib import Path
from typing import Any


class DisplayEngine:
    """Exclusive public gateway for DICOM, RAW, bitmap and processed display.

    The engine deliberately calls the stable private display implementations in
    MainWindow. Rendering and Spike engines receive arrays from this engine but
    are not allowed to replace its display route.
    """

    def __init__(self, host: Any):
        self.host = host
        self.last_source = None
        self.last_kind = "none"

    def show_dicom(self, index: int) -> None:
        self.host._display_impl_show_dicom(int(index))
        self._verify("dicom", index)

    def load_raw(self, path: Path) -> None:
        self.host._display_impl_load_raw_file(Path(path))
        self._verify("raw_file", path)

    def load_bitmap(self, path: Path) -> None:
        self.host._display_impl_load_bitmap_image(Path(path))
        self._verify("bitmap", path)

    def load_processed(self, key) -> None:
        self.host._display_impl_load_processed_image(key)
        self._verify("processed", key)

    def current_image(self):
        return self.host.current_image

    def current_metadata(self):
        return self.host.current_ds

    def _verify(self, kind: str, source) -> None:
        image = self.host.current_image
        if image is None:
            raise RuntimeError(f"DisplayEngine: {kind} produced no image")
        if getattr(image, "ndim", 0) < 2 or getattr(image, "size", 0) == 0:
            raise RuntimeError(
                f"DisplayEngine: {kind} produced invalid image shape "
                f"{getattr(image, 'shape', None)}"
            )
        self.last_kind = kind
        self.last_source = str(source)
