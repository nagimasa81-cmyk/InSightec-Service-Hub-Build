# Changelog

## v2.4.8-RC2 — Commit0028_ThermometryProtocolResolver

- TMAP and MEMP both acquire Magnitude and Phase images.
- MEMP is preferred on recent systems; TMAP supports GE HD23 and noise fallback.
- Added protocol-specific direction confidence.
- First TMAP in each Sonication is excluded by default as Setup / Reference candidate.
