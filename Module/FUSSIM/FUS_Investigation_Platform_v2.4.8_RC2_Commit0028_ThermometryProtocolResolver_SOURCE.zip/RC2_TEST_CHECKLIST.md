# RC2.4.8 test checklist

- Verify MEMP priority when available.
- Verify TMAP fallback when MEMP absent.
- Verify first TMAP exclusion.
- Verify direction confidence display.
