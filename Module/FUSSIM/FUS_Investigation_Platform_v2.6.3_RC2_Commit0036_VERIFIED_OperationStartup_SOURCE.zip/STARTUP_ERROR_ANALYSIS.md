# Startup error analysis

The supplied RC2.6.2 source contains `load_more_operation_rows` as a genuine
method of `Main`. The EXE screenshot therefore indicates that the build did not
use the same `app.py`, or an older Source ZIP / extracted source was selected.

This verified package adds:

- A class-bound callback: `Main.load_more_operation_rows(self)`
- A startup contract checking all progressive-loading methods
- A standalone pre-build validator
- A unique window title and source identity file

Before GitHub Actions, leave only this Source ZIP in the target Module folder.
Confirm the workflow log names this exact ZIP.
