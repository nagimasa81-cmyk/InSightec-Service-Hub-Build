from pathlib import Path
import ast
import sys

source=Path(__file__).with_name("app.py").read_text(encoding="utf-8")
tree=ast.parse(source)
main=next(node for node in tree.body if isinstance(node,ast.ClassDef) and node.name=="Main")
methods={item.name for item in main.body if isinstance(item,ast.FunctionDef)}
required={
    "load_more_operation_rows",
    "_update_operation_page_status",
    "_render_operation_rows",
    "_resize_operation_rows_page",
}
missing=sorted(required-methods)
if missing:
    print("STARTUP CONTRACT: FAILED")
    print("Missing:",", ".join(missing))
    sys.exit(1)
print("STARTUP CONTRACT: PASSED")
print("Source identity: RC2.6.3 VERIFIED Operation Startup")
