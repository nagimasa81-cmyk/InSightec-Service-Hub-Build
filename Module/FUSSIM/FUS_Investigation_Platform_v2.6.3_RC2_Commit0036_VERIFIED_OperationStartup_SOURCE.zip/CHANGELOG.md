# Changelog

## v2.6.2-RC2 — Commit0035_OperationEventReview

- Replaced Treatment Phase Overview with a direct Sonication Status Overview.
- Sonication active intervals are labeled `S# DQA ON` or `S# Treatment ON`.
- Sonication Power On is treated as Sonication status, not WS/CPC lifecycle.
- Removed verbose Operation Events explanatory text.
- Operation list defaults to Time and Message only.
- Event messages no longer wrap; rows remain a fixed compact height.
- Horizontal scrolling and full-message tooltips preserve the complete text.
- List-row background colors match the corresponding chart event colors.
- Added a single-line Selected Event display above the chart.
- Clicking a list row or chart marker updates the Selected Event message.
- Added category checkboxes beside the chart; they filter both the list and chart.
- Added category All and Clear controls.
- Sonication Details is expanded by default.
- Sonication Details uses a narrow one-column parameter layout.
- Reduced the Sonication panel width to approximately half of the previous width.
