@echo off
python VERIFY_SOURCE_BEFORE_BUILD.py
if errorlevel 1 (
  echo Source verification failed.
  pause
  exit /b 1
)
pause
