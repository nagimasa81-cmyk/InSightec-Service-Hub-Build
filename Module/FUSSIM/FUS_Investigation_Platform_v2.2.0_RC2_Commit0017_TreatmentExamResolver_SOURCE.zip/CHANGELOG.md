# Changelog

## v2.2.0-RC2 — Commit0017_TreatmentExamResolver

- Added Case/Exam/Series-level treatment data filtering.
- Added authoritative treatment Exam anchor from Sonication-linked `MriImageParams.xml` rows.
- `review.out` is now scored and filtered per acquisition block.
- Unrelated dates, distant acquisitions and unmatched series are excluded from Replay.
- Added treatment-time overlap validation for `mrserver` and synchronization logs when Exam identifiers are unavailable.
- Restricted RAW automatic analysis to Sonication-local sources.
- Added Exam Explorer with inclusion status, score, provenance and exclusion reasons.
- Renamed the normal MR table to Treatment MR Series.
- Added excluded-source counts to Evidence and Data Coverage.
- No unrelated Exam source is used as an automatic fallback.
