# RC2.1 Test Checklist

- Build using the supplied RC1 Runtime Complete workflow.
- Open a full treatment ZIP and a Sonication-only ZIP.
- Confirm TMAP/MEMP rows classify as Thermometry.
- Confirm `FUS ... Tracking` coil rows classify as XD Position / Motion Detection.
- Confirm Calibration rows are excluded from replay-image candidates.
- Confirm 1.5T `FUS 2ch Head` and 3T `Body` coil evidence appears in RAW metadata.
- Collapse and expand Protocol Summary in RAW Investigation.
- Drag the vertical splitter to enlarge the RAW list or image viewer.
- Confirm RAW DICOM export remains available.
- Confirm Sonication selection and existing Spectrum/Decoder Lab functionality still update.


## RC2.2 Treatment Exam Resolver

- Open a Treatment ZIP containing unrelated earlier MR exams.
- Confirm only Treatment Exam acquisitions appear in `Treatment MR Series`.
- Confirm all review.out blocks remain visible in `Exam Explorer` with Included/Review/Excluded status.
- Confirm a date mismatch is excluded even when protocol text looks similar.
- Confirm a TMAP/MEMP acquisition must also meet treatment date/series/time evidence.
- Confirm an unrelated mrserver log is not shown in normal Evidence.
- Confirm Sonication-local RAW and Spectrum sources remain included.
- Confirm Replay shows no unrelated MR fallback if no treatment-linked review acquisition passes.
- Confirm Exam UID, Exam number, treatment date/time and series numbers are displayed when available.
