# Architecture

Import -> Discovery -> Domain Model -> Capability -> UI
