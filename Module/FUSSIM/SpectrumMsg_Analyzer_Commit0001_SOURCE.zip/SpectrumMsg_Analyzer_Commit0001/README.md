# SpectrumMsg Analyzer RC1

Commit0001 Foundation prototype.

## Included
- ZIP/folder import and drag-and-drop
- Recursive discovery
- Treatment/Sonication explorer
- File classification
- Capability summary
- HEX/ASCII binary inspector
- Layout persistence and logging
- Debug and Nuitka build BAT files

Run `build\03_RUN_DEBUG.bat`. Build with `build\01_BUILD_EXE.bat`.
