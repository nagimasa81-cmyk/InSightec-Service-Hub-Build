from __future__ import annotations
import logging
from collections import defaultdict
from pathlib import Path
from PySide6.QtCore import QByteArray, Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import QFileDialog,QGroupBox,QHeaderView,QLabel,QMainWindow,QMessageBox,QSplitter,QTableWidget,QTableWidgetItem,QTreeWidget,QTreeWidgetItem,QVBoxLayout,QWidget
from src.common.constants import APP_NAME,APP_VERSION
from src.common.settings import create_settings
from src.services.capability_service import CapabilityService
from src.services.discovery_service import DiscoveryService
from src.services.import_service import ImportErrorUser,ImportService
from src.ui.binary_view import BinaryView
LOG=logging.getLogger(__name__)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle(f'{APP_NAME} - {APP_VERSION}'); self.resize(1400,900); self.setAcceptDrops(True)
        self.settings=create_settings(); self.import_service=ImportService(); self.discovery_service=DiscoveryService(); self.capability_service=CapabilityService(); self.package=None
        self._build_actions(); self._build_ui(); self._restore_layout(); self.statusBar().showMessage('Ready')
    def _build_actions(self):
        menu=self.menuBar().addMenu('&File'); a1=QAction('Open ZIP...',self); a1.triggered.connect(self.open_zip); menu.addAction(a1); a2=QAction('Open Folder...',self); a2.triggered.connect(self.open_folder); menu.addAction(a2); menu.addSeparator(); ex=QAction('Exit',self); ex.triggered.connect(self.close); menu.addAction(ex)
        tb=self.addToolBar('Main'); tb.setMovable(False); tb.addAction(a1); tb.addAction(a2)
    def _build_ui(self):
        self.tree=QTreeWidget(); self.tree.setHeaderLabels(['Item','Type','Size']); self.tree.header().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch); self.tree.itemSelectionChanged.connect(self._selection_changed)
        eb=QGroupBox('Treatment Explorer'); el=QVBoxLayout(eb); el.addWidget(self.tree)
        self.info=QLabel('Open a ZIP file or folder.'); self.info.setAlignment(Qt.AlignmentFlag.AlignTop); self.info.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.cap=QTableWidget(0,3); self.cap.setHorizontalHeaderLabels(['Capability','Status','Detail']); self.cap.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch); self.cap.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        ib=QGroupBox('Package Information'); il=QVBoxLayout(ib); il.addWidget(self.info); il.addWidget(self.cap,1)
        top=QSplitter(Qt.Orientation.Horizontal); top.addWidget(eb); top.addWidget(ib); top.setSizes([500,900])
        self.binary=BinaryView(); bb=QGroupBox('Binary Inspector'); bl=QVBoxLayout(bb); bl.addWidget(self.binary)
        self.main_splitter=QSplitter(Qt.Orientation.Vertical); self.main_splitter.addWidget(top); self.main_splitter.addWidget(bb); self.main_splitter.setSizes([540,300])
        c=QWidget(); l=QVBoxLayout(c); l.setContentsMargins(6,6,6,6); l.addWidget(self.main_splitter); self.setCentralWidget(c)
    def open_zip(self):
        fn,_=QFileDialog.getOpenFileName(self,'Open Treatment ZIP','','ZIP files (*.zip)');
        if fn:self.load_source(Path(fn))
    def open_folder(self):
        fn=QFileDialog.getExistingDirectory(self,'Open Treatment Folder');
        if fn:self.load_source(Path(fn))
    def load_source(self,source:Path):
        self.statusBar().showMessage(f'Loading {source.name}...')
        try:
            ws=self.import_service.import_path(source); p=self.discovery_service.discover(source,ws)
        except ImportErrorUser as e:
            QMessageBox.warning(self,APP_NAME,str(e)); self.statusBar().showMessage('Import failed'); return
        except Exception as e:
            LOG.exception('Unexpected import error'); QMessageBox.critical(self,APP_NAME,f'Unexpected error:\n{e}'); self.statusBar().showMessage('Import failed'); return
        self.package=p; self._populate_tree(p); self._populate_info(p); self.settings.setValue('recent_source',str(source)); self.statusBar().showMessage(f'Loaded {len(p.files)} files / {len(p.sonications)} sonications')
    def _populate_tree(self,p):
        self.tree.clear(); root=QTreeWidgetItem([p.source.name,'Treatment',f'{len(p.files)} files']); self.tree.addTopLevelItem(root); groups=defaultdict(list)
        for x in p.files: groups[x.sonication or 'Package'].append(x)
        for g in sorted(groups):
            gi=QTreeWidgetItem([g,'Group','']); root.addChild(gi); cats=defaultdict(list)
            for x in groups[g]: cats[x.category].append(x)
            for cat in sorted(cats):
                ci=QTreeWidgetItem([cat,'Category',f'{len(cats[cat])} files']); gi.addChild(ci)
                for x in cats[cat]:
                    fi=QTreeWidgetItem([x.path.name,x.category,self._fmt(x.size)]); fi.setToolTip(0,str(x.path)); fi.setData(0,Qt.ItemDataRole.UserRole,str(x.path)); ci.addChild(fi)
            gi.setExpanded(True)
        root.setExpanded(True)
    def _populate_info(self,p):
        total=sum(x.size for x in p.files); self.info.setText(f'<b>Source:</b> {p.source}<br><b>Workspace:</b> {p.workspace}<br><b>Files:</b> {len(p.files):,}<br><b>Sonications:</b> {len(p.sonications):,}<br><b>Total size:</b> {self._fmt(total)}')
        caps=self.capability_service.analyze(p); self.cap.setRowCount(len(caps))
        for r,(n,(s,d)) in enumerate(caps.items()):
            self.cap.setItem(r,0,QTableWidgetItem(n)); self.cap.setItem(r,1,QTableWidgetItem(s)); self.cap.setItem(r,2,QTableWidgetItem(d))
    def _selection_changed(self):
        items=self.tree.selectedItems();
        if not items:return
        raw=items[0].data(0,Qt.ItemDataRole.UserRole)
        if raw and Path(raw).is_file(): self.binary.show_file(Path(raw))
    @staticmethod
    def _fmt(size):
        v=float(size)
        for u in ('B','KB','MB','GB'):
            if v<1024 or u=='GB': return f'{v:.1f} {u}'
            v/=1024
    def dragEnterEvent(self,e):
        if any(u.isLocalFile() for u in e.mimeData().urls()): e.acceptProposedAction()
    def dropEvent(self,e):
        for u in e.mimeData().urls():
            if u.isLocalFile():
                p=Path(u.toLocalFile())
                if p.is_dir() or p.suffix.lower()=='.zip': self.load_source(p); e.acceptProposedAction(); return
        QMessageBox.information(self,APP_NAME,'Drop a treatment ZIP file or folder.')
    def _restore_layout(self):
        g=self.settings.value('geometry'); st=self.settings.value('window_state'); sp=self.settings.value('main_splitter')
        if isinstance(g,QByteArray): self.restoreGeometry(g)
        if isinstance(st,QByteArray): self.restoreState(st)
        if isinstance(sp,QByteArray): self.main_splitter.restoreState(sp)
    def closeEvent(self,e):
        self.settings.setValue('geometry',self.saveGeometry()); self.settings.setValue('window_state',self.saveState()); self.settings.setValue('main_splitter',self.main_splitter.saveState()); self.import_service.cleanup(); super().closeEvent(e)
