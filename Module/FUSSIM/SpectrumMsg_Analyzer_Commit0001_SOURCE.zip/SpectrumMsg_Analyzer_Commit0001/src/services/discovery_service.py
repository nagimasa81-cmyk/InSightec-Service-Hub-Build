from __future__ import annotations
import re
from pathlib import Path
from src.domain.models import DiscoveredFile, TreatmentPackage
SONICATION_RE=re.compile(r"(sonication\s*[_-]?\s*\d+)",re.I)

class DiscoveryService:
    def discover(self, source:Path, workspace:Path)->TreatmentPackage:
        out=[]
        for path in workspace.rglob('*'):
            if not path.is_file(): continue
            out.append(DiscoveredFile(path,self.classify(path),self.find_sonication(path.relative_to(workspace))))
        out.sort(key=lambda x:str(x.path).lower())
        return TreatmentPackage(source,workspace,out)
    @staticmethod
    def find_sonication(rel:Path):
        for part in rel.parts:
            m=SONICATION_RE.search(part)
            if m:
                d=re.findall(r'\d+',m.group(1)); return f"Sonication{int(d[0])}" if d else m.group(1)
        return None
    @staticmethod
    def classify(path:Path):
        n=path.name.lower(); s=path.suffix.lower(); parts={p.lower() for p in path.parts}
        if 'spectrummsg' in n: return 'SpectrumMsg'
        if s=='.raw': return 'RAW'
        if s=='.act': return 'ACT'
        if s=='.xml': return 'XML'
        if 'mrfiles' in parts or 'mrfiles' in n: return 'MRFILES'
        if 'cpcfiles' in parts or 'cpcfiles' in n: return 'CPCFiles'
        if s in {'.dmp','.fft'} or 'spectrum' in n: return 'Spectrum'
        return 'Others'
