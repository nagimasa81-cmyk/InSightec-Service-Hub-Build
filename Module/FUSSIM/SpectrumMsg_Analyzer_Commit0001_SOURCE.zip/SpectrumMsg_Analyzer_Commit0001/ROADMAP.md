# Roadmap

- Commit0001: Foundation
- Commit0002: Binary Explorer
- Commit0003: Spectrum parser
- Commit0004: FFT viewer
- Commit0005: Peak/cavitation
- Commit0006: Replay API
