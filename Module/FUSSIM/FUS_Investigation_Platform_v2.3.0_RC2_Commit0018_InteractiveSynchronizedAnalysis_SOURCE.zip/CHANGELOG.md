# Changelog

## v2.3.0-RC2 — Commit0018_InteractiveSynchronizedAnalysis

- Added shared wheel zoom, middle/right-drag pan and double-click reset to Matplotlib charts.
- Added Reset View and Reset Analysis controls to Spectrum and Hydrophone analysis.
- Added Synchronized Analysis tab with a common Sonication time cursor.
- Linked included TMAP/MEMP MR acquisition windows to SpectrumMsg frames.
- Added Play/Pause and previous/next MR-frame navigation.
- Selecting an acquisition window updates the common time and current spectrum.
- Added acquisition-to-spectrum link table with frame count, nearest time, gap and confidence.
- Preserved Treatment Exam filtering: excluded review.out/MR sources are not mixed into synchronized analysis.
- Reset All restores channel selections, interval, display mode, selected range and chart limits.
