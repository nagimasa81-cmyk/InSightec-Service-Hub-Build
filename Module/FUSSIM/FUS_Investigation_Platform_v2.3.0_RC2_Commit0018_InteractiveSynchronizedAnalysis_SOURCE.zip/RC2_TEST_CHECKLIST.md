# RC2.3 test checklist

- Open a full Treatment ZIP and confirm only Treatment Exam-linked review.out acquisitions are listed.
- Select each Treatment Sonication and open Synchronized Analysis.
- Verify the common-time slider, Play/Pause and frame-step controls.
- Click an acquisition row and confirm the cursor and spectrum update.
- Wheel-zoom, pan and double-click reset on Spectrum, Cavitation and Synchronized Analysis.
- Select an interval in Hydrophone Cavitation and verify actual FFT frames are averaged.
- Press Reset View and Reset All.
- Verify changing Sonication does not retain the prior Sonication's selected range.
- Confirm excluded Exam data never appears in synchronized MR acquisition windows.
