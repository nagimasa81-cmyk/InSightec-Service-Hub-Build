# RC2.5.2 test checklist

- Load the ZIP that previously showed `natural_key is not defined`.
- Confirm no Load error dialog appears.
- Open Synchronized Analysis and confirm no `is_thermometry_text` error appears.
- Open Operation and verify WS/CPC lifecycle markers are retained.
- Verify Boot, Reboot, Shutdown, Logon and Application Quit entries appear when present in logs.
- Confirm Operation progressive loading remains responsive.
- Confirm all Sonications containing RAW files appear in RAW Investigation.
- Confirm MEMP/TMAP replay remains preferred and RAW Fallback remains available.
