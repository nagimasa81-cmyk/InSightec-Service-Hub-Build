# Changelog

## v2.5.2-RC2 — Commit0032_TripleCheckStability

- Triple-check pass covering syntax, unresolved references and core workflow logic.
- Fixed missing `is_thermometry_text` used by Synchronized Analysis.
- Fixed WS/CPC lifecycle events being discarded by generic software-noise filtering.
- Lifecycle classification now occurs before meaningful-event filtering.
- Power On, Reboot, Shutdown, Logon, Logoff, Application Start and Application Quit lines are retained when timestamps are present.
- Hardened natural sorting for mixed numeric/text path tokens and empty values.
- Preserved Operation progressive loading, lifecycle track, all-Sonication RAW resolution and RAW thermometry fallback.
