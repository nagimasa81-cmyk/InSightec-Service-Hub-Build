# Changelog

## v2.4.2a-RC2 — Commit0022_MRSeriesLoadHotFix

- Fixed the load-stopping `row_role` local-variable error.
- MR row classification is calculated before TMAP/MEMP component use.
- Errors are isolated per RAW file and per Sonication.
- One malformed RAW/XML association no longer stops the remaining catalog.
- Added catalogued/skipped RAW counts to the load summary.
- Added skipped-file reasons to the Evidence panel.
- A failed MR frame is skipped without stopping other frames or Series.
