# RC2.4.2a test checklist

- Drop/open the previously failing Treatment ZIP.
- Confirm no `row_role` error dialog appears.
- Confirm Sonication, Treatment MR Series and RAW catalog populate.
- Confirm load summary shows catalogued and skipped RAW counts.
- Open Evidence and inspect skipped-file reasons if present.
- Select every Treatment MR Series and verify images display where available.
- Confirm one undecodable frame does not stop other frames or Series.
