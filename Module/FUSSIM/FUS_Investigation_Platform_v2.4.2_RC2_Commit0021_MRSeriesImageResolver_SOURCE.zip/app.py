import sys, re, gzip, zipfile, struct, math, json, tempfile, shutil, hashlib, os
from pathlib import Path
from dataclasses import dataclass, asdict, field as dc_field
from datetime import datetime, timedelta
import numpy as np
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QAction, QCursor
from PySide6.QtWidgets import (
    QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QTableWidget,QTableWidgetItem,
    QPushButton,QFileDialog,QLabel,QSplitter,QTabWidget,QHeaderView,QMessageBox,QComboBox,QFormLayout,
    QGroupBox,QTextEdit,QCheckBox,QLineEdit,QSpinBox,QDoubleSpinBox,QScrollArea,QSlider,QProgressDialog,QToolButton,QMenu,QInputDialog
)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as Canvas, NavigationToolbar2QT
from matplotlib.figure import Figure
from matplotlib.widgets import SpanSelector
from matplotlib.ticker import FuncFormatter
from fus_spectrum_core import parse_spectrum_bytes, frequency_axis_hz, frame_time_s, analyze_frame

@dataclass
class Sonication:
    no:int; time:str; x:float; y:float; roll:float; pitch:float; elevation:float
    fd:float; mode:int; duration:float; power:float; freq:float; max_power:float; avg_power:float; status:str


@dataclass
class InventoryItem:
    path:str; size:int; ext:str; category:str; sonication:str=''; signature:str=''; candidate:str=''; status:str='Inventory only'

def classify_inventory_path(name):
    low=name.lower(); ext=Path(name).suffix.lower() or '(none)'
    son=''
    m=re.search(r'sonication[_\\/ ]?(\d+)',low)
    if m: son=m.group(1)
    if low.endswith('/'):
        return 'Folder',son
    if ext in ('.xml',): return 'XML metadata',son
    if Path(name).name.lower() in ('review.out','review.out.ar'): return 'MR review report',son
    if 'mrserver' in low: return 'MR server log',son
    if 'spectrummsg' in low: return 'Spectrum message',son
    if 'spectrum' in low and ('fft' in low or ext in ('.dmp','.bin')): return 'Spectrum / FFT',son
    if 'reflection' in low: return 'Reflection',son
    if ext=='.raw': return 'MR / Thermometry RAW',son
    if 'skullheating' in low: return 'Skull heating',son
    if 'skullmeasure' in low: return 'Skull measures',son
    if 'bonespot' in low: return 'Bone spot data',son
    if any(k in low for k in ('wsfiles/','watersystem','gesys','cga','csa')): return 'System log',son
    if ext in ('.log','.txt','.out'): return 'Text log',son
    if ext in ('.dcm','.ima'): return 'DICOM / MR image',son
    if ext in ('.png','.jpg','.jpeg','.bmp','.tif','.tiff'): return 'Image',son
    return 'Other',son

def binary_signature(blob):
    h=blob[:16]
    if h.startswith(b'PK\x03\x04'): return 'ZIP'
    if h.startswith(b'\x1f\x8b'): return 'GZIP'
    if h.startswith(b'<?xml'): return 'XML'
    if len(blob)>132 and blob[128:132]==b'DICM': return 'DICOM'
    printable=sum(32<=b<127 or b in (9,10,13) for b in blob[:1024])
    if blob and printable/max(1,min(len(blob),1024))>.85: return 'Text-like'
    return h.hex(' ')

def raw_candidates(size):
    out=[]
    for bpp,dtype in ((2,'int16/uint16'),(4,'float32')):
        if size%bpp: continue
        pixels=size//bpp
        side=int(round(math.sqrt(pixels)))
        if side*side==pixels: out.append(f'{side}x{side} {dtype}')
        for w in (128,192,256,320,384,448,512,640,768,1024):
            if pixels%w==0:
                h=pixels//w
                if 64<=h<=2048 and abs(w-h)<=512:
                    cand=f'{w}x{h} {dtype}'
                    if cand not in out: out.append(cand)
    return '; '.join(out[:6]) or 'Unknown binary layout'

def make_inventory(zf, progress_callback=None):
    """Build a complete inventory without inflating every large binary member.

    ZIP metadata is enough for RAW/Spectrum candidates; only small/text-like files are
    sampled for signatures. This keeps 200 MB+ treatment ZIP loading responsive.
    """
    items=[]; infos=zf.infolist(); total=max(1,len(infos))
    for idx,info in enumerate(infos):
        cat,son=classify_inventory_path(info.filename)
        sig=''; cand=''
        if not info.is_dir():
            should_sample=(info.file_size<=2_000_000 and cat not in ('MR / Thermometry RAW','Spectrum message','Spectrum / FFT','Reflection'))
            if should_sample:
                try: sig=binary_signature(zf.read(info.filename)[:4096])
                except Exception: sig='Unreadable'
            else:
                sig='ZIP metadata only'
        if cat=='MR / Thermometry RAW': cand=raw_candidates(info.file_size)
        elif cat in ('Spectrum message','Spectrum / FFT','Reflection'): cand='Binary structure pending decoder'
        items.append(InventoryItem(info.filename,info.file_size,Path(info.filename).suffix.lower(),cat,son,sig,cand))
        if progress_callback and (idx%50==0 or idx==total-1): progress_callback(idx+1,total)
    return items

def try_render_raw(blob):
    candidates=[]
    for dt in ('<u2','<i2','<f4'):
        try:
            arr=np.frombuffer(blob,dtype=dt)
        except Exception: continue
        if arr.size<4096: continue
        for w in (128,192,256,320,384,448,512,640,768,1024):
            if arr.size%w: continue
            h=arr.size//w
            if not (64<=h<=2048): continue
            a=arr.reshape(h,w).astype(float)
            finite=np.isfinite(a)
            if finite.mean()<.98: continue
            p1,p99=np.percentile(a[finite],[1,99])
            if p99<=p1: continue
            norm=np.clip((a-p1)/(p99-p1),0,1)
            # Image-likeness: adjacent-pixel correlation and dynamic range.
            corrx=np.corrcoef(norm[:,:-1].ravel(),norm[:,1:].ravel())[0,1] if w>2 else 0
            corry=np.corrcoef(norm[:-1,:].ravel(),norm[1:,:].ravel())[0,1] if h>2 else 0
            score=np.nan_to_num((corrx+corry)/2) - .0001*abs(w-h)
            candidates.append((float(score),dt,w,h,norm))
    return max(candidates,key=lambda x:x[0]) if candidates else None

@dataclass
class MRSeries:
    date:str=''; time:str=''; protocol:str=''; description:str=''; plane:str='Unknown'; freq_dir:str='Unknown'
    image_mode:str=''; pulse_sequence:str=''; psd_name:str=''; coil:str=''; fov:str=''; thickness:str=''
    slices:str=''; matrix:str=''; start_loc:str=''; end_loc:str=''; center_fov:str=''; source:str='review.out'
    raw_plane:str='Unknown'; series_no:str=''; scan_time:str=''; acquisitions:str=''
    source_file:str='review.out'; exam_status:str='Unresolved'; exam_score:float=0.0; exam_reasons:list=dc_field(default_factory=list)
    role:str='MR Acquisition'; component_summary:str=''; matched_raw_count:int=0

@dataclass
class ExamAnchor:
    exam_uid:str=''; exam_number:str=''; treat_date:str=''; treat_time:str=''
    series_numbers:set=dc_field(default_factory=set); series_uids:set=dc_field(default_factory=set)
    protocols:set=dc_field(default_factory=set); coils:set=dc_field(default_factory=set)
    source_files:list=dc_field(default_factory=list)

@dataclass
class SourceDecision:
    source:str=''; category:str=''; status:str='Excluded'; score:float=0.0
    reasons:list=dc_field(default_factory=list); matched_items:int=0; total_items:int=0

@dataclass
class SyncMatch:
    series_index:int=-1; score:float=-1e9; confidence:str='Low'; corrected_gap:float=0.0
    applied_offset:float=0.0; offset_direction:str='None'; plane_match:bool=False; freq_match:bool=False
    protocol_match:bool=False; reasons:list=dc_field(default_factory=list); rejected:list=dc_field(default_factory=list)

ROW_RE=re.compile(r"^\s*(\d+)\s*\|\s*([\d:]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*(\d+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*([-\d.]+)\s*\|\s*(\w+)")

PLANE_OPTIONS=['Unknown','Axial','Sagittal','Coronal']
FREQ_OPTIONS=['Unknown','R/L','L/R','A/P','P/A','S/I','I/S']
PHASE_OPTIONS=['Auto','DQA','Treatment']
SPECTRUM_INTERVALS=['During Sonication','Pre-sonication','Post-sonication','Full Acquisition']
SPECTRUM_Y=['Amplitude','dB']
SPECTRUM_DISPLAY=['Single','All Overlay','All Separate','Average','Maximum Envelope','Spectrogram','Channel Heatmap','Relative Cavitation Bands','Cavitation Metrics','Frame Metrics Timeline']



def resource_path(relative):
    base=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
    return base / relative

def normalize_plane(raw, evidence=''):
    """Map source geometry to the nearest replay plane while keeping raw evidence separately.
    Oblique acquisitions are represented as Axial/Sagittal/Coronal in the replay UI.
    """
    text=f'{raw} {evidence}'.lower()
    if 'sag' in text: return 'Sagittal'
    if 'cor' in text: return 'Coronal'
    if 'axi' in text or 'trans' in text: return 'Axial'
    if '3-plane' in text or '3 plane' in text: return 'Axial'
    if 'oblique' in text:
        # A generic OBLIQUE record has no reliable normal-vector in the parsed text.
        # Use Axial only as a visible fallback; the user can correct each sonication.
        return 'Axial'
    return 'Unknown'

def parse_summary(text):
    out=[]
    for line in text.replace('\r','').splitlines():
        m=ROW_RE.match(line)
        if m:
            g=m.groups(); out.append(Sonication(int(g[0]),g[1],*map(float,g[2:8]),int(g[8]),*map(float,g[9:14]),g[14]))
    return out

def time_seconds(s):
    try:
        h,m,sec=map(int,s.split(':')); return h*3600+m*60+sec
    except Exception:return 0

def spectrum_time(name):
    m=re.search(r'_(\d\d)_(\d\d)_(\d\d)_\d{4}',name)
    return int(m.group(1))*3600+int(m.group(2))*60+int(m.group(3)) if m else None

def decode_spectrum(blob):
    try: raw=gzip.decompress(blob)
    except Exception: raw=blob
    vals=[]
    for off in range(32, min(len(raw)-8, 700000), 8):
        try:v=struct.unpack_from('<d',raw,off)[0]
        except Exception:continue
        if math.isfinite(v) and 1e-10 < abs(v) < 1e7: vals.append(abs(v))
    if len(vals)<128:
        a=np.frombuffer(raw[:len(raw)//4*4],dtype='<f4').astype(float)
        a=a[np.isfinite(a) & (np.abs(a)<1e7)]; vals=np.abs(a).tolist()
    a=np.asarray(vals[:150000],float)
    if a.size<64:return None,None
    n=min(4096,max(512,a.size)); idx=np.linspace(0,a.size-1,n).astype(int); y=a[idx]
    floor=max(np.percentile(y,5),1e-12); y=np.log10(y+floor); y-=np.nanmin(y)
    if np.nanmax(y)>0:y/=np.nanmax(y)
    return np.linspace(0,1,n),y


def decode_spectrum_channels(blob, expected_channels=None):
    """Experimental, bounded-cost candidate decoder for proprietary SpectrumMsg payloads."""
    try: raw=gzip.decompress(blob)
    except Exception: raw=blob
    candidates=[]
    channel_options=[]
    if expected_channels: channel_options.append(expected_channels)
    channel_options += [4,5,6,7,8]
    for dt in ('<f4','<f8','<i2','<u2'):
        item=np.dtype(dt).itemsize
        offsets=list(range(0,min(128,len(raw)),max(item,8)))
        for off in offsets:
            usable=(len(raw)-off)//item*item
            if usable<item*1024: continue
            try:a=np.frombuffer(raw,offset=off,count=min(300000,usable//item),dtype=dt).astype(float)
            except Exception:continue
            finite=np.isfinite(a)
            if finite.mean()<.95:continue
            a=a[finite]
            if dt in ('<i2','<u2'): a=a-np.median(a)
            scale=np.percentile(np.abs(a),99.5)
            if not np.isfinite(scale) or scale<=0:continue
            a=np.clip(a/scale,-5,5)
            for ch in channel_options:
                if a.size<ch*128:continue
                n=(a.size//ch)*ch; b=a[:n].reshape(-1,ch).T
                sample=b[:,:min(10000,b.shape[1])]
                cors=[]
                for x in sample:
                    if x.size>3 and np.std(x)>1e-12:
                        cors.append(np.corrcoef(x[:-1],x[1:])[0,1])
                smooth=np.nanmean(cors) if cors else 0
                balance=np.std(np.std(sample,axis=1))/(np.mean(np.std(sample,axis=1))+1e-9)
                score=float(np.nan_to_num(smooth)-.08*np.nan_to_num(balance)-off/10000)
                candidates.append((score,dt,off,ch,b))
    if not candidates:return None
    score,dt,off,ch,b=max(candidates,key=lambda x:x[0])
    return {'channels':b,'count':ch,'dtype':dt,'offset':off,'score':score,'confidence':'Experimental'}

def channel_spectra_from_streams(streams, points=1024):
    out=[]
    for stream in streams:
        x=np.asarray(stream,float); x=x[np.isfinite(x)]
        if x.size<32: out.append((None,None)); continue
        x=x-np.mean(x)
        n=min(max(256,2**int(np.floor(np.log2(x.size)))),8192)
        x=x[:n]*np.hanning(n)
        y=np.abs(np.fft.rfft(x)); y=y/(np.max(y)+1e-12)
        f=np.linspace(0,1,len(y))
        if len(y)>points:
            idx=np.linspace(0,len(y)-1,points).astype(int); f=f[idx]; y=y[idx]
        out.append((f,y))
    return out

def field(block,label):
    m=re.search(rf'{re.escape(label)}\s*:\s*([^\t\r\n]+)',block,re.I)
    return m.group(1).strip() if m else ''

def parse_review(text, source_file="review.out"):
    blocks=re.split(r'\n-{20,}\n',text.replace('\r',''))
    out=[]
    for b in blocks:
        if 'IMAGING PARAMETERS SCREEN' not in b: continue
        raw_plane=field(b,'Scan Plane') or 'Unknown'
        plane=normalize_plane(raw_plane,b)
        freq=field(b,'Freq. Dir') or 'Unknown'
        slices=field(b,'# Slices')
        if not slices:
            vals=[]
            for p in ('Axial','Sagittal','Coronal'):
                v=field(b,f'# Slices in {p} Plane')
                if v: vals.append(f'{p}:{v}')
            slices=', '.join(vals)
        series_no=field(b,'Series Number') or field(b,'Series No')
        description=field(b,'Series De')
        protocol=field(b,'Protocol')
        coil=field(b,'Coil Name')
        role=classify_series_description(description,protocol,field(b,'Pulse Seq'),coil)
        component_summary=('Magnitude + Phase + temperature calculation/display products'
                           if role=='Thermometry Compound Series' else '')
        out.append(MRSeries(
            date=field(b,'date'), time=field(b,'time'), protocol=protocol,
            description=description, plane=plane,
            freq_dir=freq, image_mode=field(b,'Image Mode'), pulse_sequence=field(b,'Pulse Seq'),
            psd_name=field(b,'Psd Name'), coil=coil, fov=field(b,'Field of View'),
            thickness=field(b,'Slice Thickness'), slices=slices, matrix=field(b,'Acq. Matrix'),
            start_loc=field(b,'Start Loc'), end_loc=field(b,'End Loc'), center_fov=field(b,'Center of FOV'),
            raw_plane=raw_plane, series_no=series_no,
            scan_time=field(b,'Scan Time'), acquisitions=field(b,'# Acquisitions'), source_file=source_file,
            role=role,component_summary=component_summary))
    return out



def _norm_date(value):
    text=str(value or '').strip()
    for fmt in ('%Y-%m-%d','%Y/%m/%d','%m/%d/%Y','%m-%d-%Y'):
        try:return datetime.strptime(text,fmt).strftime('%Y-%m-%d')
        except Exception:pass
    m=re.search(r'(20\d{2})[-/](\d{1,2})[-/](\d{1,2})',text)
    if m:return f'{int(m.group(1)):04d}-{int(m.group(2)):02d}-{int(m.group(3)):02d}'
    return ''

def _time_gap_seconds(a,b):
    try:
        def cv(x):
            q=[int(float(v)) for v in str(x).strip().split(':')[:3]]
            while len(q)<3:q.append(0)
            return q[0]*3600+q[1]*60+q[2]
        d=abs(cv(a)-cv(b)); return min(d,86400-d)
    except Exception:return 1e9

def build_exam_anchor(zf,names,son_meta):
    anchor=ExamAnchor()
    # MriImageParams is authoritative because its rows are explicitly linked to Sonication indexes.
    for no,meta in son_meta.items():
        for row in meta.get('mri_rows',[]):
            uid=str(row.get('imgexamuid') or '').strip()
            num=str(row.get('imgexamnum') or '').strip()
            td=_norm_date(row.get('treatdate'))
            tt=str(row.get('treattime') or '').strip()
            sn=str(row.get('imgseriesnum') or '').strip()
            su=str(row.get('seriesuid') or '').strip()
            pr=str(row.get('seriesdiscription') or '').strip()
            co=str(row.get('coilname') or row.get('coilchannels') or '').strip()
            if uid and not anchor.exam_uid: anchor.exam_uid=uid
            if num and not anchor.exam_number: anchor.exam_number=num
            if td and not anchor.treat_date: anchor.treat_date=td
            if tt and not anchor.treat_time: anchor.treat_time=tt
            if sn:anchor.series_numbers.add(sn)
            if su:anchor.series_uids.add(su)
            if pr:anchor.protocols.add(pr.upper())
            if co:anchor.coils.add(co.upper())
            src=row.get('_source')
            if src and src not in anchor.source_files:anchor.source_files.append(src)
    return anchor

def score_review_series_for_exam(m,anchor,sonics):
    score=0.0; reasons=[]
    md=_norm_date(m.date)
    if anchor.treat_date and md:
        if md==anchor.treat_date: score+=35; reasons.append('Treatment date matched')
        else: score-=100; reasons.append(f'Date mismatch ({md} vs {anchor.treat_date})')
    elif anchor.treat_date: reasons.append('Review date unavailable')
    if m.series_no and anchor.series_numbers:
        if str(m.series_no) in anchor.series_numbers: score+=35; reasons.append('Series number matched MriImageParams')
        else: reasons.append('Series number not present in treatment MriImageParams')
    text=f'{m.protocol} {m.description}'.upper()
    if any(p and (p in text or text in p) for p in anchor.protocols):
        score+=25; reasons.append('Protocol/description matched treatment MR metadata')
    if any(k in text for k in ('TMAP','MEMP')):
        score+=20; reasons.append('Thermometry protocol')
    role,conf,why=classify_mr_acquisition(m.protocol,m.description,m.coil,m.pulse_sequence)
    if role in ('Thermometry','XD Position / Motion Detection','Calibration Acquisition'):
        score+=10; reasons.append(f'FUS workflow role: {role}')
    if anchor.coils and m.coil:
        cu=m.coil.upper()
        if any(c and (c in cu or cu in c) for c in anchor.coils): score+=8; reasons.append('Coil matched treatment metadata')
    # review.out often contains unrelated exams from earlier dates. Time is supporting evidence only.
    if m.time and sonics:
        gap=min(_time_gap_seconds(m.time,x.time) for x in sonics)
        if gap<=900: score+=15; reasons.append(f'Within {gap:.0f}s of a Sonication')
        elif gap<=3600: score+=5; reasons.append(f'Within {gap/60:.1f} min of a Sonication')
        else: score-=10; reasons.append(f'Time distant from treatment ({gap/60:.1f} min)')
    if score>=55:status='Included'
    elif score>=30:status='Review'
    else:status='Excluded'
    return status,score,reasons

def filter_review_series_for_exam(series,anchor,sonics):
    included=[]; all_series=[]
    for m in series:
        st,sc,rs=score_review_series_for_exam(m,anchor,sonics)
        m.exam_status=st; m.exam_score=sc; m.exam_reasons=rs
        all_series.append(m)
        if st=='Included':included.append(m)
    # Never silently use unrelated review.out. If no high-confidence match exists,
    # retain no series and require manual review in Exam Explorer.
    return included,all_series

def source_exam_decision(path,category,anchor,sonics,content=''):
    low=(path+' '+content[:20000]).lower(); score=0.0; reasons=[]
    if anchor.exam_number and anchor.exam_number.lower() in low:
        score+=60; reasons.append('Exam number found')
    if anchor.exam_uid and anchor.exam_uid.lower() in low:
        score+=80; reasons.append('Exam UID found')
    if anchor.treat_date:
        variants={anchor.treat_date,anchor.treat_date.replace('-','/'),anchor.treat_date.replace('-','')}
        if any(v.lower() in low for v in variants):score+=30; reasons.append('Treatment date found')
    if re.search(r'(?i)sonication\s*\d+|sonication\d+',path):
        score+=50; reasons.append('Stored in a Sonication folder')
    if category in ('MR / Thermometry RAW','Spectrum message','Skull analysis') and 'sonication' in path.lower():
        score+=30; reasons.append('Sonication-local data source')
    if category=='MR review report':
        # Content is filtered at series/block level, not accepted wholesale.
        reasons.append('review.out evaluated per acquisition block')
    if category=='MR server log':
        # mrserver is accepted only when its events overlap the treatment date/time window.
        if anchor.treat_date and any(v in low for v in (anchor.treat_date.lower(),anchor.treat_date.replace('-','/').lower())):
            score+=30; reasons.append('mrserver contains treatment date')
    # Many exported logs omit or obfuscate Exam identifiers. In that case require
    # actual event timestamps near a Sonication instead of accepting the whole file.
    found_times=re.findall(r'(?<!\d)([0-2]?\d:[0-5]\d:[0-5]\d)(?!\d)',content[:200000])
    if found_times and sonics:
        gap=min(_time_gap_seconds(t,x.time) for t in found_times[:500] for x in sonics)
        if gap<=120: score+=50; reasons.append(f'Log event within {gap:.0f}s of Sonication')
        elif gap<=900: score+=30; reasons.append(f'Log event within {gap/60:.1f} min of Sonication')
    status='Included' if score>=50 else ('Review' if score>=25 else 'Excluded')
    return SourceDecision(path,category,status,score,reasons)

def normalize_freq(value):
    text=str(value or '').upper().replace(' ', '').replace('\\','/').replace('-','/')
    aliases={'RL':'R/L','LR':'L/R','AP':'A/P','PA':'P/A','SI':'S/I','IS':'I/S'}
    compact=text.replace('/','')
    if compact in aliases:return aliases[compact]
    if 'ROW' in text:return 'ROW'
    if 'COL' in text:return 'COL'
    return text if text in FREQ_OPTIONS else 'Unknown'



def classify_mr_acquisition(protocol='', description='', coil='', sequence='', field_strength=''):
    """Classify FUS MR acquisitions using confirmed workflow rules.

    Priority:
    1) FUS * Tracking coil => XD position / movement detection.
    2) TMAP or MEMP => MR thermometry. 1.5T commonly uses a coil name
       containing ``FUS 2ch Head``; 3T commonly uses ``Body``.
    3) Calibration => pre-acquisition calibration data, not a replay image.
    """
    proto=' '.join(str(x or '') for x in (protocol, description, sequence)).upper()
    coil_u=str(coil or '').upper()
    fs=str(field_strength or '').upper()
    if 'FUS' in coil_u and 'TRACKING' in coil_u:
        return 'XD Position / Motion Detection','Confirmed','Coil Name contains FUS and Tracking'
    therm_proto=any(k in proto for k in ('TMAP','MEMP'))
    if therm_proto:
        if 'FUS 2CH HEAD' in coil_u:
            return 'Thermometry','Confirmed','TMAP/MEMP with FUS 2ch Head coil (1.5T workflow)'
        if coil_u.strip()=='BODY' or ' BODY' in coil_u or coil_u.startswith('BODY'):
            return 'Thermometry','Confirmed','TMAP/MEMP with Body coil (3T workflow)'
        return 'Thermometry','High','TMAP/MEMP protocol; coil does not match a known field-strength-specific rule'
    if 'CALIB' in proto:
        return 'Calibration Acquisition','Confirmed','Calibration is pre-acquisition data used before same-day MRI image generation'
    if 'FUS 2CH HEAD' in coil_u:
        return 'Thermometry Candidate','Medium','FUS 2ch Head coil without explicit TMAP/MEMP protocol'
    if coil_u.strip()=='BODY' or ' BODY' in coil_u or coil_u.startswith('BODY'):
        return 'MR Acquisition','Low','Body coil alone is not sufficient; TMAP/MEMP is required for thermometry classification'
    return 'MR Acquisition','Low','No confirmed FUS protocol/coil rule matched'


def classify_series_description(description='', protocol='', sequence='', coil=''):
    """Classify an Exam MR Series from its description and protocol.

    Series Number is the acquisition order. Description is the primary clue to
    the scan purpose. TMAP/MEMP are compound thermometry acquisitions and may
    contain magnitude, phase, calculation and display products.
    """
    value=' '.join(str(x or '') for x in (description,protocol,sequence)).upper()
    coil_u=str(coil or '').upper()
    if 'FUS' in coil_u and 'TRACKING' in coil_u:
        return 'XD Position / Motion Detection'
    if 'CALIB' in value:
        return 'Calibration Acquisition'
    if 'TMAP' in value or 'MEMP' in value:
        return 'Thermometry Compound Series'
    if any(k in value for k in ('T2','ANATOM','STRUCT','LOCALIZER','SCOUT')):
        return 'Anatomical / Reference MRI'
    if any(k in value for k in ('FUS','HEAD','TREATMENT')):
        return 'Treatment MRI'
    return 'MR Acquisition'

def thermometry_component_from_row(row, path=''):
    """Identify a TMAP/MEMP sub-product without claiming unsupported semantics."""
    desc=' '.join(str(row.get(k,'') or '') for k in (
        'seriesdiscription','description','protocol','protocolname','imagetype',
        'image_type','imagekind','displaytype','datatype','sequence','psdname'
    )).upper()
    name=Path(path).name.upper()
    combined=f'{desc} {name}'
    if any(k in combined for k in ('TEMPERATURE','TEMP MAP','THERMAL MAP','TMAP DISPLAY','COLOR MAP','DISPLAY IMAGE')):
        return 'Temperature map / display image'
    if any(k in combined for k in ('PHASE','PHS')):
        return 'Phase image'
    if any(k in combined for k in ('MAGNITUDE','MAG IMAGE','MAGN','ANATOMY')):
        return 'Magnitude / anatomy image'
    if any(k in combined for k in ('DOSE','CEM43','THERMAL DOSE')):
        return 'Thermal dose image'
    if any(k in combined for k in ('MASK','ROI','OVERLAY')):
        return 'Mask / overlay'
    # Known TMAP/MEMP series can contain multiple arrays whose exact semantics
    # are not always explicit. Preserve them as separate unresolved components.
    arr=row.get('arrayindex')
    return f'Thermometry component array {arr}' if str(arr or '').strip() else 'Thermometry component (unresolved)'

def _series_number_from_row(row):
    for key in ('seriesnumber','seriesno','seriesindex','seriesnum','mrseriesnumber','mrseries'):
        value=str(row.get(key,'') or '').strip()
        if value:
            m=re.search(r'\d+',value)
            if m:return str(int(m.group()))
    return ''

def _series_sort_key(value):
    try:return (0,int(float(str(value).strip())))
    except Exception:return (1,10**9)

def is_thermometry_series(m):
    role,_,_=classify_mr_acquisition(m.protocol,m.description,m.coil,m.pulse_sequence)
    return role=='Thermometry'

def geometry_compatible(required_plane,required_freq,candidate_plane,candidate_freq):
    rp=normalize_plane(required_plane); cp=normalize_plane(candidate_plane)
    rf=normalize_freq(required_freq); cf=normalize_freq(candidate_freq)
    plane_ok=rp=='Unknown' or cp=='Unknown' or rp==cp
    freq_ok=rf=='Unknown' or cf=='Unknown' or rf in ('ROW','COL') or cf in ('ROW','COL') or rf==cf
    return plane_ok,freq_ok

def parse_xml_rows(text):
    rows=[]
    for m in re.finditer(r'<[^>]*?:?row\s+([^>]+)/?>',text,re.I):
        attrs={k.lower():v for k,v in re.findall(r'(\w+)="([^"]*)"',m.group(1))}
        rows.append(attrs)
    return rows

def plane_from_mri_row(a):
    """Resolve nearest orthogonal plane from direction cosines, then numeric plane code."""
    try:
        r=np.array([float(a.get('rowdirectcosrasx',0)),float(a.get('rowdirectcosrasy',0)),float(a.get('rowdirectcosrasz',0))])
        c=np.array([float(a.get('coldirectcosrasx',0)),float(a.get('coldirectcosrasy',0)),float(a.get('coldirectcosrasz',0))])
        n=np.cross(r,c)
        if np.linalg.norm(n)>0.1:
            axis=int(np.argmax(np.abs(n)))
            return ['Sagittal','Coronal','Axial'][axis],float(np.degrees(np.arccos(np.clip(np.max(np.abs(n))/np.linalg.norm(n),-1,1))))
    except Exception: pass
    code=str(a.get('imgplane') or a.get('seriesplane') or '')
    return {'2':'Axial','4':'Sagittal','8':'Coronal'}.get(code,'Unknown'),None

def raw_name_indices(path):
    m=re.match(r'(?i).*/(\d+)-(\d+)-(\d+)-(\d+)\.raw$',path)
    if not m:return None
    return tuple(map(int,m.groups()))  # field, sub-index, zone, array

def parse_sonication_metadata(zf,names):
    out={}
    for n in names:
        bn=Path(n).name.lower()
        if bn not in ('sonicationdata.xml','sonicationsummary.xml','mriimageparams.xml','imagedataitem.xml'): continue
        try:text=zf.read(n).decode('utf-8','ignore')
        except Exception:continue
        for a in parse_xml_rows(text):
            no=a.get('sonicationindex') or a.get('sonication')
            if not no or not str(no).isdigit():continue
            d=out.setdefault(str(int(no)),{'evidence':[],'mri_rows':[],'image_items':[]})
            if n not in d['evidence']:d['evidence'].append(n)
            if bn=='mriimageparams.xml':
                row=dict(a); row['_source']=n
                row['_plane'],row['_oblique_angle']=plane_from_mri_row(row)
                row['_freq']=normalize_freq(row.get('freqdirection'))
                d['mri_rows'].append(row)
            elif bn=='imagedataitem.xml':
                d['image_items'].append(dict(a))
            for key in ('treatprotocol','scanplane','protocol','actualduration','measuredpower','measuredenergy','maxmaxtemp','maxaveragetemp','frequency','scannormalx','scannormaly','scannormalz','freqdirection','seriesdiscription','imgmatrixx','imgmatrixy','pixsizex','pixsizey','slicethick','tempimagesnum','magimagesnum','tempimagestimes','energy','nominaldosearea','lowdosearea','treateddose','scantime'):
                if key in a and a[key]!='': d[key]=a[key]
    for no,d in out.items():
        proto=' '.join(str(d.get(k,'')) for k in ('treatprotocol','protocol','seriesdiscription')).lower()
        if 'dqa' in proto:
            d['phase']='DQA'; d['phase_confidence']='High'; d['phase_reason']='Explicit DQA protocol in XML metadata'
        rawplane=d.get('scanplane') or d.get('seriesdiscription','')
        if rawplane:d['plane']=normalize_plane(rawplane)
        try:
            normal=[abs(float(d.get('scannormalx',0))),abs(float(d.get('scannormaly',0))),abs(float(d.get('scannormalz',0)))]
            if max(normal)>0:
                axis=int(np.argmax(normal)); d['plane']=['Sagittal','Coronal','Axial'][axis]; d['plane_reason']=f'Scan normal {normal}'
        except Exception:pass
        # Thermometry geometry comes from TMAP/MEMP rows belonging to this exact Sonication.
        therm=[r for r in d.get('mri_rows',[]) if any(k in str(r.get('seriesdiscription','')).upper() for k in ('TMAP','MEMP','THERM'))]
        if therm:
            d['thermometry_rows']=therm
            planes=[r.get('_plane','Unknown') for r in therm if r.get('_plane')!='Unknown']
            freqs=[r.get('_freq','Unknown') for r in therm if r.get('_freq')!='Unknown']
            if planes:d['plane']=max(set(planes),key=planes.count); d['plane_reason']='MriImageParams thermometry direction cosines'
            if freqs:d['freqdirection']=max(set(freqs),key=freqs.count)
            d['thermometry_protocol']=max((str(r.get('seriesdiscription','')) for r in therm),key=lambda x:sum(str(r.get('seriesdiscription',''))==x for r in therm))
    return out

def build_raw_series_catalog(zf, raw_paths, son_meta):
    """Map exact Sonication RAW names to MriImageParams field/zone/array records."""
    catalog={}
    for no,meta in son_meta.items():
        rows=meta.get('mri_rows',[])
        row_map={}
        for r in rows:
            try:key=(int(r.get('fieldindex')),int(r.get('zoneindex')),int(r.get('arrayindex')))
            except Exception:continue
            row_map[key]=r
        groups={}
        pat=re.compile(rf'(^|[\/])sonication[_ -]?0*{int(no)}([\/]|$)',re.I)
        for path in raw_paths:
            if not pat.search(path):continue
            idx=raw_name_indices(path)
            if not idx:continue
            field,sub,zone,array=idx
            info=zf.getinfo(path); row=row_map.get((field,zone,array))
            desc=(row or {}).get('seriesdiscription','')
            coil=(row or {}).get('coilname') or (row or {}).get('coil') or (row or {}).get('coil_name') or ''
            protocol=(row or {}).get('protocol') or (row or {}).get('protocolname') or desc
            sequence=(row or {}).get('sequence') or (row or {}).get('psdname') or ''
            role,role_conf,role_reason=classify_mr_acquisition(protocol,desc,coil,sequence,(row or {}).get('fieldstrength',''))
            therm=role=='Thermometry'
            key=(field,sub,zone,info.file_size)
            series_no=_series_number_from_row(row or {})
            component=thermometry_component_from_row(row or {},path) if therm else role
            g=groups.setdefault(key,{'field':field,'sub':sub,'zone':zone,'size':info.file_size,'paths':[],'rows':[],'description':desc,'protocol':protocol,'coil':coil,'series_no':series_no,'component':component,'thermometry':therm,'classification':role,'classification_confidence':role_conf,'classification_reason':role_reason,'plane':(row or {}).get('_plane','Unknown'),'freq':(row or {}).get('_freq','Unknown'),'matrix':None,'matched_rows':0})
            g['paths'].append(path)
            if row:
                g['rows'].append(row); g['matched_rows']+=1
                try:g['matrix']=(int(row.get('imgmatrixx')),int(row.get('imgmatrixy')))
                except Exception:pass
                if not g['description']:g['description']=row.get('seriesdiscription','')
                if not g.get('series_no'):g['series_no']=_series_number_from_row(row)
                if g.get('thermometry') or row_role=='Thermometry':
                    g['component']=thermometry_component_from_row(row,path)
                if g['plane']=='Unknown':g['plane']=row.get('_plane','Unknown')
                if g['freq']=='Unknown':g['freq']=row.get('_freq','Unknown')
                row_role,row_conf,row_reason=classify_mr_acquisition(row.get('protocol') or row.get('protocolname') or row.get('seriesdiscription',''),row.get('seriesdiscription',''),row.get('coilname') or row.get('coil') or '',row.get('sequence') or row.get('psdname') or '',row.get('fieldstrength',''))
                if row_role in ('XD Position / Motion Detection','Thermometry','Calibration Acquisition'):
                    g['classification']=row_role; g['classification_confidence']=row_conf; g['classification_reason']=row_reason
                g['thermometry']=g['thermometry'] or row_role=='Thermometry'
        def nat(x):return [int(v) if v.isdigit() else v.lower() for v in re.split(r'(\d+)',x)]
        for g in groups.values():
            g['paths'].sort(key=nat)
            g['xml_coverage']=g['matched_rows']/max(1,len(g['paths']))
            if g.get('classification')=='XD Position / Motion Detection': g['role']='XD Position / Motion Detection'
            elif g.get('classification')=='Calibration Acquisition': g['role']='Calibration Acquisition (not replay image)'
            elif g['thermometry']: g['role']='Thermometry MR series (TMAP/MEMP)'
            else: g['role']='MR image series' if g['matched_rows'] else 'Unmapped RAW series'
            score=(300 if g['thermometry'] else 0)+(120*g['xml_coverage'])+min(len(g['paths']),100)
            if g['matrix'] and g['matrix'][0]*g['matrix'][1]*2==g['size']:score+=80
            g['resolver_score']=score
        catalog[no]=sorted(groups.values(),key=lambda g:g['resolver_score'],reverse=True)
    return catalog


def synthesize_sonics_from_folders(names):
    """Create minimal Sonication records when a folder-set ZIP has no Summary file."""
    nums=sorted({int(m.group(2)) for n in names for m in [re.search(r'(^|[\\/])sonication[_ -]?0*(\d+)([\\/]|$)',n,re.I)] if m})
    # Correct group is 2 because group 1 is the path boundary.
    if not nums:
        nums=sorted({int(m.group(1)) for n in names for m in [re.search(r'sonication[_ -]?0*(\d+)',n,re.I)] if m})
    return [Sonication(no,'00:00:00',0,0,0,0,0,0,0,0,0,0,0,0,'Unknown') for no in nums]

def _matrix_from_raw_size(size):
    candidates=[]
    for bpp,dt in ((2,'uint16/int16'),(4,'float32')):
        if size<=0 or size%bpp: continue
        pix=size//bpp
        side=int(round(math.sqrt(pix)))
        if side*side==pix:candidates.append((side,side,dt))
        for w in (128,192,256,320,384,448,512,640,768,1024):
            if pix%w==0:
                h=pix//w
                if 64<=h<=2048 and abs(w-h)<=512:candidates.append((w,h,dt))
    if not candidates:return None
    return min(candidates,key=lambda x:(abs(x[0]-x[1]),abs(x[0]-256)))

def infer_sequence_role(field,sub,zone,size,xml_group=None):
    if xml_group:
        if xml_group.get('thermometry'):return 'Thermometry series (XML confirmed)','High'
        if xml_group.get('matched_rows'):return 'MR image series (XML linked)','High'
    # Observed Sonication-folder conventions. These remain candidates until XML/log evidence confirms semantics.
    if field in (5,6) and size in (131072,262144):
        label='Thermometry paired stream A' if field==5 else 'Thermometry paired stream B'
        return label+' (phase/magnitude identity pending)','Medium'
    if field in (7,8,12) and size==524288:
        return 'Anatomical / motion / baseline MR candidate','Medium'
    if field in (16,19,20,21) and size==524288:
        return 'Planning / fusion / supporting MR volume candidate','Low'
    if field in (23,28,33,34,37,38,39,40,41,42):
        return 'Auxiliary image / mask / geometry candidate','Low'
    if size==0:return 'Placeholder / empty RAW','High'
    return 'Unclassified image sequence','Low'

def build_sonication_sequence_catalog(zf,raw_paths,raw_series_catalog=None):
    """Build exact Sonication-folder image sequences without requiring treatment summary metadata."""
    by={}
    for path in raw_paths:
        sm=re.search(r'(^|[\\/])sonication[_ -]?0*(\d+)([\\/]|$)',path,re.I)
        if not sm:continue
        no=int(sm.group(2)); idx=raw_name_indices(path)
        if not idx:continue
        field,sub,zone,array=idx; size=zf.getinfo(path).file_size
        key=(field,sub,zone,size)
        g=by.setdefault(no,{}).setdefault(key,{'sonication':no,'field':field,'sub':sub,'zone':zone,'size':size,'paths':[]})
        g['paths'].append((array,path))
    output={}
    for no,groups in by.items():
        xml_groups=(raw_series_catalog or {}).get(str(no),[])
        arr=[]
        for (field,sub,zone,size),g in groups.items():
            g['paths']=[p for _,p in sorted(g['paths'],key=lambda x:x[0])]
            xml=next((x for x in xml_groups if x.get('field')==field and x.get('sub')==sub and x.get('zone')==zone and x.get('size')==size),None)
            role,confidence=infer_sequence_role(field,sub,zone,size,xml)
            g.update({'role':role,'confidence':confidence,'matrix':(xml or {}).get('matrix') or _matrix_from_raw_size(size),
                      'plane':(xml or {}).get('plane','Unknown'),'freq':(xml or {}).get('freq','Unknown'),
                      'description':(xml or {}).get('description',''),'xml_coverage':(xml or {}).get('xml_coverage',0.0)})
            arr.append(g)
        output[no]=sorted(arr,key=lambda x:(0 if 'Thermometry' in x['role'] else 1,-len(x['paths']),x['field'],x['sub']))
    return output

def classify_session(sonics):
    """Conservative DQA/Treatment split. A long workflow gap is the strongest signal.
    Low-power/test-looking sonications before that gap are DQA. Without a clear transition,
    keep the complete short session as DQA and expose manual override.
    """
    if not sonics: return {}
    gaps=[]
    for i in range(1,len(sonics)):
        gaps.append((time_seconds(sonics[i].time)-time_seconds(sonics[i-1].time),i))
    transition=None
    if gaps:
        gap,idx=max(gaps)
        if gap>=15*60: transition=idx
    out={}
    for i,son in enumerate(sonics):
        if transition is not None:
            phase='DQA' if i<transition else 'Treatment'
            confidence='High' if max(gaps)[0]>=30*60 else 'Medium'
            reason=f'workflow time gap before Sonication {transition}' if i>=transition else f'pre-treatment group before {max(gaps)[0]/60:.1f} min gap'
        else:
            phase='DQA'
            confidence='Medium' if len(sonics)<=6 else 'Low'
            reason='short continuous test/phantom-like session; no reliable patient-treatment transition found'
        out[str(son.no)]={'phase':phase,'confidence':confidence,'reason':reason}
    return out

def scan_timing_evidence(text,name):
    rows=[]; offsets=[]
    keys=('sonication','thermo','temperature','acquisition','scan','offset','time difference','clock')
    for line in text.replace('\r','').splitlines():
        low=line.lower()
        if any(k in low for k in keys):
            if len(rows)<3000: rows.append(f'{name}: {line.strip()}')
            # Accept explicit MR/FUS offset statements only; preserve direction as evidence.
            m=re.search(r'(?:mr.{0,20}fus|fus.{0,20}mr|time\s*(?:difference|offset)|clock\s*offset)[^+\-\d]{0,30}([+\-]?\d+(?:\.\d+)?)\s*(ms|msec|s|sec)',line,re.I)
            if m:
                v=float(m.group(1)); unit=m.group(2).lower();
                if unit.startswith('m'): v/=1000.0
                offsets.append((v,f'{name}: {line.strip()}'))
    return rows,offsets

def parse_mrserver(text,name):
    events=[]
    for line in text.replace('\r','').splitlines():
        if any(k in line for k in ('LoadProtocol','SetRxGeometry3p','Series type =','scanner=scanning','acquisition=complete','recon=done','SetCVs=')):
            events.append(f'{name}: {line.strip()}')
    return events


@dataclass
class OperationEvent:
    seconds:float=0.0
    time_text:str=''
    category:str='Software'
    actor:str='Software'
    severity:str='Info'
    message:str=''
    source:str=''
    sonication:int=-1
    phase:str='Unlinked'
    confidence:str='Medium'

OPERATION_RULES=[
    ('Error','System','Error',('error','exception','failed','failure','fatal','abort','aborted')),
    ('Warning','System','Warning',('warning','warn','timeout','retry','motion detected','not ready','interlock')),
    ('Treatment','Operator','Info',('treat high','treat low','start sonication','stop sonication','continue treatment','pause treatment','sonication start','sonication stop')),
    ('Tracking','Operator','Info',('tracking','detect patient movement','position detect','transducer position','xd position')),
    ('Thermometry','Software','Info',('tmap','memp','thermometry','temperature map','phase image','temperature')),
    ('MRI','Software','Info',('loadprotocol','scan start','scanner=scanning','acquisition=complete','recon=done','setrxgeometry','series type')),
    ('Registration','Operator','Info',('fusion','registration','ctmr','mrmr','fiducial','align')),
    ('Planning','Operator','Info',('sdr','calcification','non-path','npr','target','planning','preplan')),
    ('Acoustic','Software','Info',('spectrum','hydrophone','cavitation','reflection','acoustic control')),
    ('Cooling','Software','Info',('cooling','cool down','post sonication')),
    ('Data','Operator','Info',('save','export','import','retrieve','database update','load patient','open patient')),
]

def _operation_time(line):
    # Supports HH:MM:SS(.mmm), HH-MM-SS and common date-prefixed logs.
    m=re.search(r'(?<!\d)(\d{1,2})[:\-](\d{2})[:\-](\d{2})(?:[.,:](\d{1,6}))?',line)
    if not m:return None,''
    h,mi,se=map(int,m.group(1,2,3))
    frac=(m.group(4) or '')[:6]
    value=h*3600+mi*60+se+(float('0.'+frac) if frac else 0.0)
    return value,f'{h:02d}:{mi:02d}:{se:02d}'+(f'.{frac[:3]}' if frac else '')

def categorize_operation(line):
    low=line.lower()
    for category,actor,severity,keys in OPERATION_RULES:
        if any(k in low for k in keys):
            # User-facing actions are more likely when button/menu verbs appear.
            if any(k in low for k in ('clicked','button','selected','user','operator','menu','pressed')):
                actor='Operator'
            return category,actor,severity
    return 'Software','Software','Info'

def parse_operation_events(text,name,sonics,phase_lookup):
    events=[]
    for raw in text.replace('\r','').splitlines():
        sec,tlabel=_operation_time(raw)
        if sec is None:continue
        category,actor,severity=categorize_operation(raw)
        # Keep meaningful workflow/software lines; discard ordinary noise.
        low=raw.lower()
        meaningful=category!='Software' or any(k in low for k in ('state','workflow','command','request','response','scan','protocol','patient','database'))
        if not meaningful:continue
        nearest=None; gap=1e9
        for s in sonics:
            d=abs(sec-time_seconds(s.time))
            if d<gap:nearest=s; gap=d
        son_no=int(nearest.no) if nearest is not None and gap<=180 else -1
        phase=phase_lookup.get(str(son_no),{}).get('phase','Unlinked') if son_no>=0 else 'Unlinked'
        conf='High' if gap<=30 else ('Medium' if gap<=180 else 'Low')
        events.append(OperationEvent(sec,tlabel,category,actor,severity,raw.strip(),name,son_no,phase,conf))
    events.sort(key=lambda e:e.seconds)
    return events

def clock_formatter(value,pos=None):
    if not np.isfinite(value):return ''
    value=float(value)%86400
    h=int(value//3600); m=int((value%3600)//60); s=int(value%60)
    return f'{h:02d}:{m:02d}' if abs(value-round(value/60)*60)<1 else f'{h:02d}:{m:02d}:{s:02d}'

class Plot(Canvas):
    """Matplotlib canvas with shared review-workstation interactions.

    - Wheel: zoom around cursor
    - Middle/right drag: pan
    - Double-click: reset to the first rendered limits
    """
    def __init__(self):
        self.fig=Figure(figsize=(5,4),tight_layout=True)
        super().__init__(self.fig)
        self._initial_limits={}
        self._pan_state=None
        self.mpl_connect('scroll_event',self._on_scroll)
        self.mpl_connect('button_press_event',self._on_press)
        self.mpl_connect('button_release_event',self._on_release)
        self.mpl_connect('motion_notify_event',self._on_motion)

    def _polish_axes(self):
        for ax in self.fig.axes:
            title=ax.get_title()
            if title:
                ax.set_title(title,fontsize=10,pad=7,
                             bbox=dict(facecolor='#eef4f8',edgecolor='#c8d6df',boxstyle='round,pad=0.28',alpha=.95))
            ax.tick_params(labelsize=8)
    def draw(self,*args,**kwargs):
        self._polish_axes()
        return super().draw(*args,**kwargs)
    def draw_idle(self,*args,**kwargs):
        self._polish_axes()
        return super().draw_idle(*args,**kwargs)

    def remember_initial_view(self,force=False):
        for ax in self.fig.axes:
            if not hasattr(ax,'get_xlim'): continue
            key=id(ax)
            if force or key not in self._initial_limits:
                self._initial_limits[key]=(ax.get_xlim(),ax.get_ylim())

    def reset_view(self):
        restored=False
        for ax in self.fig.axes:
            lim=self._initial_limits.get(id(ax))
            if lim:
                ax.set_xlim(*lim[0]); ax.set_ylim(*lim[1]); restored=True
            else:
                try: ax.relim(); ax.autoscale_view(); restored=True
                except Exception: pass
        if restored:self.draw_idle()

    def _on_scroll(self,event):
        ax=event.inaxes
        if ax is None or event.xdata is None or event.ydata is None:return
        self.remember_initial_view()
        scale=.82 if event.button=='up' else 1.22
        x0,x1=ax.get_xlim(); y0,y1=ax.get_ylim()
        cx,cy=event.xdata,event.ydata
        ax.set_xlim(cx+(x0-cx)*scale,cx+(x1-cx)*scale)
        ax.set_ylim(cy+(y0-cy)*scale,cy+(y1-cy)*scale)
        self.draw_idle()

    def _on_press(self,event):
        if getattr(event,'dblclick',False):
            self.reset_view(); return
        if event.inaxes is not None and event.button in (2,3) and event.xdata is not None and event.ydata is not None:
            self.remember_initial_view()
            self._pan_state=(event.inaxes,event.xdata,event.ydata,event.inaxes.get_xlim(),event.inaxes.get_ylim())

    def _on_release(self,event):
        self._pan_state=None

    def _on_motion(self,event):
        if self._pan_state is None or event.inaxes is None or event.xdata is None or event.ydata is None:return
        ax,x0,y0,xlim,ylim=self._pan_state
        if event.inaxes is not ax:return
        dx=event.xdata-x0; dy=event.ydata-y0
        ax.set_xlim(xlim[0]-dx,xlim[1]-dx); ax.set_ylim(ylim[0]-dy,ylim[1]-dy)
        self.draw_idle()

class Main(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle('FUS Investigation Platform - RC2.4.2 MR Series Image Resolver'); self.resize(1580,940)
        self.zf=None; self.zip_path=None; self.sonics=[]; self.spectrum_files=[]; self.spectrum_msg_files=[]; self.reflection_files=[]; self.inventory=[]; self.raw_files=[]
        self.spec_cache={}; self.mr_series=[]; self.all_mr_series=[]; self.exam_anchor=ExamAnchor(); self.source_decisions=[]; self.mrserver_events=[]; self.all_mrserver_events=[]; self.timing_evidence=[]; self.all_timing_evidence=[]; self.ws_offsets=[]; self.auto_phase={}; self.son_meta={}; self.manual={}; self.external_images={}
        self._updating=False
        self._context_refreshing=False
        self._refresh_generation=0
        self._pending_refresh_force=False
        self._refresh_timer=QTimer(self)
        self._refresh_timer.setSingleShot(True)
        self._refresh_timer.setInterval(60)
        self._refresh_timer.timeout.connect(self._run_scheduled_refresh)
        self.current_sonication_no=None
        self.panel_errors={}
        self.raw_replay_cache={}; self.thermo_source_cache={}; self.sync_matches={}; self.raw_series_catalog={}; self.sequence_catalog={}; self.decoder_registry={}; self.decoder_registry_path=None
        self.thermo_cache={}
        self.visible_sonics=[]
        self.cav_span=None
        self.cav_selected_range=None
        self.cav_current_streams=None
        self.cav_current_duration=0.0
        self.common_time_s=0.0
        self.sync_play_timer=QTimer(self)
        self.sync_play_timer.setInterval(150)
        self.sync_play_timer.timeout.connect(self.advance_common_time)
        self.sync_link_cache={}
        self.operation_events=[]
        self.all_operation_events=[]
        self.setAcceptDrops(True)
        self.build_ui()

    def build_ui(self):
        w=QWidget(); self.setCentralWidget(w); lay=QVBoxLayout(w)
        top=QHBoxLayout(); lay.addLayout(top)
        import_hint=QToolButton(); import_hint.setText('Drop ZIP / Folder here, or click to select'); import_hint.clicked.connect(self.open_zip); top.addWidget(import_hint)
        save=QPushButton('Save Review Mapping'); save.clicked.connect(self.save_mapping); top.addWidget(save)
        self.info=QLabel('No data loaded'); top.addWidget(self.info,1)
        self.show_dqa=QCheckBox('Show DQA')
        self.show_dqa.setChecked(False)
        self.show_dqa.toggled.connect(self.populate)
        top.addWidget(self.show_dqa)
        badge=QLabel('REVIEW / RESEARCH ONLY — NOT FOR CLINICAL DECISIONS'); badge.setStyleSheet('font-weight:bold;color:#b00020'); top.addWidget(badge)

        split=QSplitter(); lay.addWidget(split,1)
        left=QWidget(); ll=QVBoxLayout(left)
        self.table=QTableWidget(0,12); self.table.setHorizontalHeaderLabels(['No.','Phase','Confidence','Start','Duration','Power','Avg','Freq.','F.D.','Status','MR Plane','Freq Dir'])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.setSelectionBehavior(QTableWidget.SelectRows); self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.currentCellChanged.connect(self.select_row); self.table.cellClicked.connect(self.select_row_clicked); self.table.itemSelectionChanged.connect(self.selection_changed)
        self.table.setHorizontalScrollMode(QTableWidget.ScrollPerPixel); self.table.setVerticalScrollMode(QTableWidget.ScrollPerPixel)
        selector_row=QHBoxLayout()
        selector_row.addWidget(QLabel('Sonication'))
        self.sonication_combo=QComboBox()
        self.sonication_combo.setMinimumContentsLength(24)
        self.sonication_combo.currentIndexChanged.connect(self.sonication_combo_changed)
        selector_row.addWidget(self.sonication_combo,1)
        ll.addLayout(selector_row)
        self.table.setVisible(False)
        ll.addWidget(self.table,0)

        self.detail_toggle=QToolButton()
        self.detail_toggle.setText('▶ Selected Sonication details')
        self.detail_toggle.setCheckable(True)
        self.detail_toggle.setChecked(False)
        self.detail_toggle.toggled.connect(self.toggle_selected_details)
        ll.addWidget(self.detail_toggle)
        detail_box=QGroupBox()
        self.detail_box=detail_box
        detail_box.setVisible(False)
        dg=QGridLayout(detail_box); self.detail_labels={}
        fields=[('Sonication','sonication'),('Phase','phase'),('Start','start'),('Status','status'),('Duration','duration'),('Power','power'),('Average / Max','avgmax'),('Frequency','frequency'),('Focal distance','fd'),('Position','position'),('MR plane / Freq','mrfreq'),('Replay source','replay_source'),('Spectrum source','spectrum')]
        for i,(title,key) in enumerate(fields):
            r=i//2; c=(i%2)*2
            dg.addWidget(QLabel(title),r,c)
            lab=QLabel('—'); lab.setWordWrap(True); lab.setTextInteractionFlags(Qt.TextSelectableByMouse)
            self.detail_labels[key]=lab; dg.addWidget(lab,r,c+1)
        ll.addWidget(detail_box,0)
        nav=QHBoxLayout(); ll.addLayout(nav)
        prev=QPushButton('◀ Previous'); prev.clicked.connect(lambda:self.move_row(-1)); nav.addWidget(prev)
        nxt=QPushButton('Next ▶'); nxt.clicked.connect(lambda:self.move_row(1)); nav.addWidget(nxt)
        split.addWidget(left)

        right=QWidget(); rl=QVBoxLayout(right)
        controls=QGroupBox('Selected Sonication — MR Geometry Mapping')
        controls.setCheckable(True); controls.setChecked(False)
        self.mapping_controls=controls
        form=QGridLayout(controls)
        self.source_label=QLabel('Source: unavailable'); form.addWidget(self.source_label,0,0,1,4)
        form.addWidget(QLabel('DQA / Treatment'),1,0); self.phase_combo=QComboBox(); self.phase_combo.addItems(PHASE_OPTIONS); self.phase_combo.currentTextChanged.connect(self.phase_changed); form.addWidget(self.phase_combo,1,1)
        self.phase_evidence=QLabel(''); self.phase_evidence.setWordWrap(True); form.addWidget(self.phase_evidence,1,2,1,2)
        form.addWidget(QLabel('Scan plane'),2,0); self.plane_combo=QComboBox(); self.plane_combo.addItems(PLANE_OPTIONS); self.plane_combo.currentTextChanged.connect(self.mapping_changed); form.addWidget(self.plane_combo,2,1)
        form.addWidget(QLabel('Frequency direction'),2,2); self.freq_combo=QComboBox(); self.freq_combo.addItems(FREQ_OPTIONS); self.freq_combo.currentTextChanged.connect(self.mapping_changed); form.addWidget(self.freq_combo,2,3)
        form.addWidget(QLabel('MR series'),3,0); self.series_combo=QComboBox(); self.series_combo.currentIndexChanged.connect(self.series_changed); form.addWidget(self.series_combo,3,1,1,3)
        self.use_auto=QCheckBox('Use automatically matched review.out / mrserver information when available'); self.use_auto.setChecked(True); self.use_auto.toggled.connect(self.refresh_selected); form.addWidget(self.use_auto,4,0,1,4)
        rl.addWidget(controls)
        controls.toggled.connect(self.toggle_mapping_controls)
        QTimer.singleShot(0,lambda:self.toggle_mapping_controls(False))
        self.tabs=QTabWidget(); rl.addWidget(self.tabs,1)
        self.tabs.currentChanged.connect(self._tab_changed)
        self.imgplot=Plot(); self.tabs.addTab(self.imgplot,'MR / Hotspot Replay')
        self.thermopage=QWidget(); thl=QVBoxLayout(self.thermopage); thc=QHBoxLayout(); thl.addLayout(thc)
        thc.addWidget(QLabel('Thermometry frame')); self.thermo_slider=QSlider(Qt.Horizontal); self.thermo_slider.setMinimum(0); self.thermo_slider.setMaximum(0); self.thermo_slider.valueChanged.connect(self.draw_thermometry); thc.addWidget(self.thermo_slider,1)
        self.thermo_frame_label=QLabel('No frame'); thc.addWidget(self.thermo_frame_label)
        thc.addWidget(QLabel('Display')); self.thermo_mode=QComboBox(); self.thermo_mode.addItems(['Baseline / Current / Difference','Magnitude candidate','Phase-difference candidate','Temperature-rise candidate']); self.thermo_mode.currentTextChanged.connect(self.draw_thermometry); thc.addWidget(self.thermo_mode)
        self.thermo_note=QLabel(''); self.thermo_note.setWordWrap(True); thl.addWidget(self.thermo_note)
        self.thermoplot=Plot(); thl.addWidget(self.thermoplot,1); self.tabs.addTab(self.thermopage,'Thermometry Replay')
        self.overview=QTextEdit(); self.overview.setReadOnly(True); self.tabs.addTab(self.overview,'Maximum Information')
        self.mrseries_page=QWidget(); mrsl=QVBoxLayout(self.mrseries_page)
        mrssplit=QSplitter(Qt.Vertical); mrsl.addWidget(mrssplit,1)
        self.mrtable=QTableWidget(0,17)
        self.mrtable.setHorizontalHeaderLabels(['Series','Time','Description','Role','Components','Images','Plane','Freq Dir','Mode','Sequence','PSD','Coil','FOV','Thickness','Slices','Matrix','Source'])
        self.mrtable.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.mrtable.horizontalHeader().setSectionResizeMode(2,QHeaderView.Stretch)
        self.mrtable.setSelectionBehavior(QTableWidget.SelectRows)
        self.mrtable.setSelectionMode(QTableWidget.SingleSelection)
        self.mrtable.currentCellChanged.connect(self.mr_series_selected)
        mrssplit.addWidget(self.mrtable)
        mrviewer=QWidget(); mrvl=QVBoxLayout(mrviewer)
        mrvc=QHBoxLayout(); mrvl.addLayout(mrvc)
        mrvc.addWidget(QLabel('Component'))
        self.mr_component_combo=QComboBox(); self.mr_component_combo.currentIndexChanged.connect(self.mr_component_changed); mrvc.addWidget(self.mr_component_combo,1)
        mrvc.addWidget(QLabel('Frame'))
        self.mr_frame_slider=QSlider(Qt.Horizontal); self.mr_frame_slider.setRange(0,0); self.mr_frame_slider.valueChanged.connect(self.draw_selected_mr_series); mrvc.addWidget(self.mr_frame_slider,2)
        self.mr_frame_label=QLabel('No image'); mrvc.addWidget(self.mr_frame_label)
        mr_reset=QPushButton('Reset View'); mr_reset.clicked.connect(lambda:self.mrseries_plot.reset_view()); mrvc.addWidget(mr_reset)
        self.mr_series_note=QLabel('Select a Treatment Exam MR Series. Series number is treated as acquisition order.'); self.mr_series_note.setWordWrap(True); mrvl.addWidget(self.mr_series_note)
        self.mrseries_plot=Plot(); mrvl.addWidget(self.mrseries_plot,1)
        mrssplit.addWidget(mrviewer); mrssplit.setSizes([300,650])
        self.tabs.addTab(self.mrseries_page,'Treatment MR Series')
        self.exampage=QWidget(); exl=QVBoxLayout(self.exampage)
        self.exam_summary=QTextEdit(); self.exam_summary.setReadOnly(True); self.exam_summary.setMaximumHeight(190); exl.addWidget(self.exam_summary)
        self.exam_table=QTableWidget(0,8); self.exam_table.setHorizontalHeaderLabels(['Status','Source / Acquisition','Category','Date / Time','Series','Protocol / Description','Score','Reasons']); self.exam_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); self.exam_table.setSelectionBehavior(QTableWidget.SelectRows); exl.addWidget(self.exam_table,1)
        self.tabs.addTab(self.exampage,'Exam Explorer')
        self.cavpage=QWidget(); cavl=QVBoxLayout(self.cavpage)
        cavtop=QHBoxLayout(); cavl.addLayout(cavtop)
        cavtop.addWidget(QLabel('Channels'))
        self.hp_checks=[]
        for i in range(8):
            cb=QCheckBox(f'Ch {i+1}'); cb.setChecked(i<4); cb.toggled.connect(self.refresh_selected); self.hp_checks.append(cb); cavtop.addWidget(cb)
        self.cav_metrics_toggle=QToolButton(); self.cav_metrics_toggle.setText('Show channel metrics'); self.cav_metrics_toggle.setCheckable(True); self.cav_metrics_toggle.toggled.connect(self.refresh_selected); cavtop.addWidget(self.cav_metrics_toggle)
        cav_reset=QPushButton('Reset View'); cav_reset.clicked.connect(lambda:self.cavplot.reset_view()); cavtop.addWidget(cav_reset)
        cav_reset_all=QPushButton('Reset Analysis'); cav_reset_all.clicked.connect(self.reset_all_analysis); cavtop.addWidget(cav_reset_all)
        cavtop.addStretch(1)
        self.cav_range_label=QLabel('Drag across the activity chart to calculate FFT for a selected time range.'); cavl.addWidget(self.cav_range_label)
        self.cavplot=Plot(); cavl.addWidget(self.cavplot,1); self.tabs.addTab(self.cavpage,'Hydrophone Cavitation')
        self.specpage=QWidget(); spl=QVBoxLayout(self.specpage); sc=QHBoxLayout(); spl.addLayout(sc)
        sc.addWidget(QLabel('Interval')); self.spec_interval=QComboBox(); self.spec_interval.addItems(SPECTRUM_INTERVALS); self.spec_interval.currentTextChanged.connect(self.refresh_selected); sc.addWidget(self.spec_interval)
        sc.addWidget(QLabel('Hydrophone')); self.hp_combo=QComboBox(); self.hp_combo.addItems(['Auto / FUS-selected']+[f'Hydrophone {i}' for i in range(1,9)]); self.hp_combo.currentTextChanged.connect(self.refresh_selected); sc.addWidget(self.hp_combo)
        sc.addWidget(QLabel('Display')); self.spec_display=QComboBox(); self.spec_display.addItems(SPECTRUM_DISPLAY); self.spec_display.currentTextChanged.connect(self.refresh_selected); sc.addWidget(self.spec_display)
        sc.addWidget(QLabel('Y axis')); self.spec_y=QComboBox(); self.spec_y.addItems(SPECTRUM_Y); self.spec_y.currentTextChanged.connect(self.refresh_selected); sc.addWidget(self.spec_y)
        spec_reset=QPushButton('Reset View'); spec_reset.clicked.connect(lambda:self.specplot.reset_view()); sc.addWidget(spec_reset)
        spec_reset_all=QPushButton('Reset Analysis'); spec_reset_all.clicked.connect(self.reset_all_analysis); sc.addWidget(spec_reset_all)
        sc.addStretch(1)
        sch=QHBoxLayout(); spl.addLayout(sch); sch.addWidget(QLabel('Visible channels'))
        self.spec_checks=[]
        for i in range(8):
            cb=QCheckBox(f'Ch {i+1}'); cb.setChecked(i<4); cb.toggled.connect(self.refresh_selected); self.spec_checks.append(cb); sch.addWidget(cb)
        sch.addStretch(1)
        self.spec_note=QLabel(''); self.spec_note.setWordWrap(True); spl.addWidget(self.spec_note)
        self.specplot=Plot(); spl.addWidget(self.specplot,1); self.tabs.addTab(self.specpage,'Spectrum')

        self.syncpage=QWidget(); syncl=QVBoxLayout(self.syncpage)
        syncctl=QHBoxLayout(); syncl.addLayout(syncctl)
        self.sync_play=QPushButton('▶ Play'); self.sync_play.clicked.connect(self.toggle_sync_play); syncctl.addWidget(self.sync_play)
        pframe=QPushButton('◀ Frame'); pframe.clicked.connect(lambda:self.step_common_time(-1)); syncctl.addWidget(pframe)
        nframe=QPushButton('Frame ▶'); nframe.clicked.connect(lambda:self.step_common_time(1)); syncctl.addWidget(nframe)
        syncctl.addWidget(QLabel('Common time'))
        self.common_time_slider=QSlider(Qt.Horizontal); self.common_time_slider.setRange(0,1000); self.common_time_slider.valueChanged.connect(self.common_time_changed); syncctl.addWidget(self.common_time_slider,1)
        self.common_time_label=QLabel('0.000 s'); syncctl.addWidget(self.common_time_label)
        reset_sync=QPushButton('Reset View'); reset_sync.clicked.connect(lambda:self.syncplot.reset_view()); syncctl.addWidget(reset_sync)
        reset_sync_all=QPushButton('Reset All'); reset_sync_all.clicked.connect(self.reset_all_analysis); syncctl.addWidget(reset_sync_all)
        self.sync_link_note=QLabel('Select a Sonication to link TMAP/MEMP acquisitions with SpectrumMsg frames.'); self.sync_link_note.setWordWrap(True); syncl.addWidget(self.sync_link_note)
        self.syncplot=Plot(); syncl.addWidget(self.syncplot,2)
        self.sync_link_table=QTableWidget(0,8); self.sync_link_table.setHorizontalHeaderLabels(['MR frame','Acquisition window','Protocol','Series','Spectrum frames','Nearest spectrum time','Gap','Confidence'])
        self.sync_link_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.sync_link_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.sync_link_table.cellClicked.connect(self.sync_link_row_clicked)
        syncl.addWidget(self.sync_link_table,1)
        self.tabs.addTab(self.syncpage,'Synchronized Analysis')
        self.operation_page=QWidget(); opl=QVBoxLayout(self.operation_page)
        opctl=QHBoxLayout(); opl.addLayout(opctl)
        opctl.addWidget(QLabel('Category'))
        self.operation_category=QComboBox(); self.operation_category.addItems(['All','Operator','Software','Planning','Registration','Tracking','MRI','Treatment','Thermometry','Acoustic','Cooling','Data','Warning','Error'])
        self.operation_category.currentTextChanged.connect(self.show_operation); opctl.addWidget(self.operation_category)
        opctl.addWidget(QLabel('Search'))
        self.operation_search=QLineEdit(); self.operation_search.textChanged.connect(self.show_operation); opctl.addWidget(self.operation_search,1)
        op_reset=QPushButton('Reset'); op_reset.clicked.connect(self.reset_operation_filters); opctl.addWidget(op_reset)
        self.operation_columns_btn=QToolButton(); self.operation_columns_btn.setText('Columns ▾'); self.operation_columns_btn.clicked.connect(self.show_operation_column_menu); opctl.addWidget(self.operation_columns_btn)
        self.operation_summary=QLabel('No operation data'); self.operation_summary.setWordWrap(True); opl.addWidget(self.operation_summary)
        self.operation_plot=Plot(); opl.addWidget(self.operation_plot,1)
        self.operation_plot.mpl_connect('button_press_event',self.operation_plot_clicked)
        self.operation_zoom_selector=None
        self.operation_table=QTableWidget(0,8); self.operation_table.setHorizontalHeaderLabels(['Time','Category','Actor','Severity','Sonication','Phase','Source','Operation / software event'])
        self.operation_table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.operation_table.horizontalHeader().setSectionResizeMode(7,QHeaderView.Stretch)
        self.operation_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.operation_table.setSelectionMode(QTableWidget.SingleSelection)
        self.operation_table.setWordWrap(True)
        self.operation_table.verticalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.operation_table.cellDoubleClicked.connect(self.operation_row_activated)
        self.operation_table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.operation_table.customContextMenuRequested.connect(self.operation_table_context_menu)
        self.operation_table.horizontalHeader().setContextMenuPolicy(Qt.CustomContextMenu)
        self.operation_table.horizontalHeader().customContextMenuRequested.connect(self.operation_header_context_menu)
        self.operation_table.horizontalHeader().setSectionsMovable(True)
        self.operation_column_filters={}
        self.operation_column_searches={}
        self.operation_visible_events=[]
        self.selected_mr_series_groups=[]
        opl.addWidget(self.operation_table,2)
        self.tabs.addTab(self.operation_page,'Operation')

        self.timeline=Plot(); self.tabs.addTab(self.timeline,'Treatment Timeline')
        self.syncinfo=QTextEdit(); self.syncinfo.setReadOnly(True); self.tabs.addTab(self.syncinfo,'Time Synchronization')
        self.evidence=QTextEdit(); self.evidence.setReadOnly(True); self.tabs.addTab(self.evidence,'mrserver / Raw Evidence')
        self.coverage=QTableWidget(0,4); self.coverage.setHorizontalHeaderLabels(['Data domain','Status','Evidence count','Notes']); self.coverage.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); self.tabs.addTab(self.coverage,'Data Coverage')
        self.inventory_table=QTableWidget(0,8); self.inventory_table.setHorizontalHeaderLabels(['Path','Size','Category','Sonication','Extension','Signature','Candidate layout','Status']); self.inventory_table.horizontalHeader().setSectionResizeMode(0,QHeaderView.Stretch); self.inventory_table.itemSelectionChanged.connect(self.inventory_selected); self.tabs.addTab(self.inventory_table,'Complete Inventory')
        self.rawpage=QWidget(); rawlay=QVBoxLayout(self.rawpage)
        self.raw_protocol_toggle=QToolButton(); self.raw_protocol_toggle.setText('▼ Protocol Summary'); self.raw_protocol_toggle.setCheckable(True); self.raw_protocol_toggle.setChecked(True); self.raw_protocol_toggle.setToolButtonStyle(Qt.ToolButtonTextOnly); self.raw_protocol_toggle.toggled.connect(self.toggle_raw_protocol_summary); rawlay.addWidget(self.raw_protocol_toggle)
        self.raw_protocol_panel=QWidget(); rpl=QVBoxLayout(self.raw_protocol_panel); rpl.setContentsMargins(0,0,0,0)
        self.raw_protocol_table=QTableWidget(0,7); self.raw_protocol_table.setHorizontalHeaderLabels(['Protocol / Series','Coil','Classification','Confidence','Frames','Plane','Freq Dir']); self.raw_protocol_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); self.raw_protocol_table.setMaximumHeight(180); rpl.addWidget(self.raw_protocol_table); rawlay.addWidget(self.raw_protocol_panel)
        self.raw_splitter=QSplitter(Qt.Vertical); rawlay.addWidget(self.raw_splitter,1)
        self.raw_list_panel=QWidget(); rawlistlay=QVBoxLayout(self.raw_list_panel); rawlistlay.setContentsMargins(0,0,0,0)
        rawtop=QHBoxLayout(); rawlistlay.addLayout(rawtop); rawtop.addWidget(QLabel('RAW candidate')); self.raw_combo=QComboBox(); self.raw_combo.currentIndexChanged.connect(self.draw_raw_candidate); rawtop.addWidget(self.raw_combo,1); self.raw_export_btn=QPushButton('Export All Decoded Images as DICOM'); self.raw_export_btn.setToolTip('Decode every RAW image candidate shown by RAW Investigation and save valid images as anonymized Secondary Capture DICOM files. Undecodable files are skipped.'); self.raw_export_btn.clicked.connect(self.export_all_raw_as_dicom); rawtop.addWidget(self.raw_export_btn); self.raw_meta=QLabel('No RAW selected'); self.raw_meta.setWordWrap(True); rawlistlay.addWidget(self.raw_meta)
        self.raw_splitter.addWidget(self.raw_list_panel); self.rawplot=Plot(); self.raw_splitter.addWidget(self.rawplot); self.raw_splitter.setSizes([220,620]); self.tabs.addTab(self.rawpage,'RAW Investigation')

        self.seqpage=QWidget(); sql=QVBoxLayout(self.seqpage)
        sqtop=QHBoxLayout(); sql.addLayout(sqtop)
        sqtop.addWidget(QLabel('Image sequence'))
        self.seq_combo=QComboBox(); self.seq_combo.currentIndexChanged.connect(self.sequence_group_changed); sqtop.addWidget(self.seq_combo,1)
        self.seq_stage=QLabel('No sequence selected'); sqtop.addWidget(self.seq_stage)
        self.seq_table=QTableWidget(0,10); self.seq_table.setHorizontalHeaderLabels(['Sonication','Field','Sub','Zone','Role candidate','Confidence','Frames','Matrix','Plane','Freq'])
        self.seq_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); self.seq_table.setSelectionBehavior(QTableWidget.SelectRows); self.seq_table.setSelectionMode(QTableWidget.SingleSelection)
        self.seq_table.currentCellChanged.connect(self.sequence_table_selected); sql.addWidget(self.seq_table,1)
        fr=QHBoxLayout(); sql.addLayout(fr); fr.addWidget(QLabel('Frame'))
        self.seq_slider=QSlider(Qt.Horizontal); self.seq_slider.setMinimum(0); self.seq_slider.setMaximum(0); self.seq_slider.valueChanged.connect(self.draw_sequence_frame); fr.addWidget(self.seq_slider,1)
        self.seq_frame_label=QLabel('0 / 0'); fr.addWidget(self.seq_frame_label)
        self.seq_note=QLabel('Sequence stages are evidence-based candidates. Phase/magnitude identity and exact acquisition cadence remain under validation.'); self.seq_note.setWordWrap(True); sql.addWidget(self.seq_note)
        self.seqplot=Plot(); sql.addWidget(self.seqplot,2); self.tabs.addTab(self.seqpage,'Sonication Image Sequence')
        # Decoder Lab: validate RAW series before they are allowed into Replay.
        self.decoderpage=QWidget(); dll=QVBoxLayout(self.decoderpage)
        dtop=QHBoxLayout(); dll.addLayout(dtop)
        dtop.addWidget(QLabel('Primary series'))
        self.decoder_primary=QComboBox(); self.decoder_primary.currentIndexChanged.connect(self.decoder_selection_changed); dtop.addWidget(self.decoder_primary,1)
        dtop.addWidget(QLabel('Compare with'))
        self.decoder_secondary=QComboBox(); self.decoder_secondary.currentIndexChanged.connect(self.draw_decoder_lab); dtop.addWidget(self.decoder_secondary,1)
        dtop.addWidget(QLabel('Confirmed role'))
        self.decoder_role=QComboBox(); self.decoder_role.addItems(['Unconfirmed','Magnitude','Phase','Temperature Map','Thermal Dose','Motion / Position Detection','Anatomical T2','CT / Fusion Support','Mask / Geometry','Other']); dtop.addWidget(self.decoder_role)
        self.decoder_apply=QPushButton('Confirm Role'); self.decoder_apply.clicked.connect(self.confirm_decoder_role); dtop.addWidget(self.decoder_apply)
        self.decoder_save=QPushButton('Save Decoder Registry'); self.decoder_save.clicked.connect(self.save_decoder_registry); dtop.addWidget(self.decoder_save)
        self.decoder_table=QTableWidget(0,13); self.decoder_table.setHorizontalHeaderLabels(['Son.','Field','Sub','Zone','Current role','Confirmed role','Confidence','Frames','Matrix','Plane','Freq','Mean correlation','Temporal variation'])
        self.decoder_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); self.decoder_table.setSelectionBehavior(QTableWidget.SelectRows); self.decoder_table.setSelectionMode(QTableWidget.SingleSelection); self.decoder_table.currentCellChanged.connect(self.decoder_table_selected); dll.addWidget(self.decoder_table,1)
        dfr=QHBoxLayout(); dll.addLayout(dfr); dfr.addWidget(QLabel('Frame'))
        self.decoder_slider=QSlider(Qt.Horizontal); self.decoder_slider.setMinimum(0); self.decoder_slider.setMaximum(0); self.decoder_slider.valueChanged.connect(self.draw_decoder_lab); dfr.addWidget(self.decoder_slider,1)
        self.decoder_frame_label=QLabel('0 / 0'); dfr.addWidget(self.decoder_frame_label)
        self.decoder_note=QLabel('Only a manually confirmed or high-confidence XML-linked series should be promoted to Replay.'); self.decoder_note.setWordWrap(True); dll.addWidget(self.decoder_note)
        self.decoderplot=Plot(); dll.addWidget(self.decoderplot,2); self.tabs.addTab(self.decoderpage,'Sonication Decoder Lab')

        self.rawseries_table=QTableWidget(0,11); self.rawseries_table.setHorizontalHeaderLabels(['Sonication','Field','Zone','Role','Description','Frames','XML matched','Matrix','Plane','Freq Dir','Resolver score']); self.rawseries_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); self.tabs.addTab(self.rawseries_table,'RAW Series Resolver')
        self.details=QTextEdit(); self.details.setReadOnly(True); self.tabs.addTab(self.details,'Sonication Details')
        split.addWidget(right); split.setSizes([530,1050])

    def open_zip(self):
        p,_=QFileDialog.getOpenFileName(self,'Open FUS ZIP','','ZIP files (*.zip)')
        if p:self.load_zip(p)

    def load_zip(self,p):
        progress=QProgressDialog('Opening treatment ZIP...','Cancel',0,100,self); progress.setWindowModality(Qt.WindowModal); progress.setMinimumDuration(0); progress.setValue(1)
        try:
            if self.zf:self.zf.close()
            self.zf=zipfile.ZipFile(p); self.zip_path=Path(p); self.decoder_registry_path=self.zip_path.with_suffix('.decoder_registry.json'); self.load_decoder_registry(); names=self.zf.namelist(); progress.setValue(5); QApplication.processEvents()
            sums=[n for n in names if '/Summary_' in n and n.lower().endswith('.txt')]
            if not sums:sums=[n for n in names if Path(n).name.lower().startswith('summary_') and n.lower().endswith('.txt')]
            self.folder_only_mode=not bool(sums)
            if sums:
                self.sonics=parse_summary(self.zf.read(sums[0]).decode('utf-8','ignore'))
            else:
                self.sonics=synthesize_sonics_from_folders(names)
                if not self.sonics:raise ValueError('Treatment Summary and Sonication folders were not found')
            progress.setLabelText('Reading Sonication and MR metadata...'); progress.setValue(12); QApplication.processEvents()
            self.spectrum_files=[n for n in names if n.endswith('.dmp_FFT')]
            self.spectrum_msg_files=[n for n in names if 'spectrummsg' in Path(n).name.lower() and not n.endswith('/')]
            self.reflection_files=[n for n in names if 'reflection' in n.lower() and not n.endswith('/')]
            self.son_meta=parse_sonication_metadata(self.zf,names); progress.setValue(25); QApplication.processEvents()
            def inv_progress(done,total):
                progress.setLabelText(f'Inventory scan {done}/{total}...'); progress.setValue(25+int(25*done/max(1,total))); QApplication.processEvents()
                if progress.wasCanceled():raise RuntimeError('Import canceled')
            self.inventory=make_inventory(self.zf,inv_progress)
            # Sonication-local RAW/Spectrum/Skull data are treatment-linked by folder identity.
            for it in self.inventory:
                if it.category in ('MR / Thermometry RAW','Spectrum message','Spectrum / FFT','Reflection','Skull analysis','MR review report'):
                    self.source_decisions.append(source_exam_decision(it.path,it.category,self.exam_anchor,self.sonics))
            self.raw_files=[i.path for i in self.inventory if i.category=='MR / Thermometry RAW' and ('sonication' in i.path.lower())]
            progress.setLabelText('Resolving exact Sonication RAW series...'); progress.setValue(52); QApplication.processEvents()
            self.raw_series_catalog=build_raw_series_catalog(self.zf,self.raw_files,self.son_meta)
            self.sequence_catalog=build_sonication_sequence_catalog(self.zf,self.raw_files,self.raw_series_catalog)
            self.exam_anchor=build_exam_anchor(self.zf,names,self.son_meta)
            parsed_review=[]
            for n in names:
                if Path(n).name.lower() in ('review.out','review.out.ar'):
                    try: parsed_review += parse_review(self.zf.read(n).decode('utf-8','ignore'),n)
                    except Exception: pass
            self.mr_series,self.all_mr_series=filter_review_series_for_exam(parsed_review,self.exam_anchor,self.sonics)
            progress.setValue(62); self.mrserver_events=[]; self.all_mrserver_events=[]; self.timing_evidence=[]; self.all_timing_evidence=[]; self.ws_offsets=[]; QApplication.processEvents()
            for n in names:
                if 'mrserver' in Path(n).name.lower() and n.lower().endswith('.log'):
                    try:
                        txt=self.zf.read(n).decode('utf-8','ignore'); ev=parse_mrserver(txt,Path(n).name); self.all_mrserver_events+=ev
                        dec=source_exam_decision(n,'MR server log',self.exam_anchor,self.sonics,txt); self.source_decisions.append(dec)
                        if dec.status=='Included': self.mrserver_events+=ev
                    except Exception:pass
            progress.setLabelText('Reading synchronization evidence...'); progress.setValue(70); QApplication.processEvents()
            for n in names:
                bn=Path(n).name.lower()
                if n.endswith('/') or not (bn.endswith('.log') or bn.endswith('.txt')):continue
                if not any(k in n.lower() for k in ('wsfiles/','watersystem','acquisition','sonication')):continue
                try:
                    txt=self.zf.read(n).decode('utf-8','ignore'); rows,offs=scan_timing_evidence(txt,Path(n).name); self.all_timing_evidence+=rows
                    dec=source_exam_decision(n,'Synchronization log',self.exam_anchor,self.sonics,txt); self.source_decisions.append(dec)
                    if dec.status=='Included': self.timing_evidence+=rows; self.ws_offsets+=offs
                except Exception:pass
            self.auto_phase=classify_session(self.sonics)
# Build operation intelligence only from Treatment Exam-linked logs.
            self.all_operation_events=[]
            for n in names:
                bn=Path(n).name.lower()
                if n.endswith('/') or not (bn.endswith('.log') or bn.endswith('.txt') or bn.endswith('.out')):continue
                if not any(k in n.lower() for k in ('wsfiles/','watersystem','sonication','treatment','fus','workstation','mrserver')):continue
                try:
                    txt=self.zf.read(n).decode('utf-8','ignore')
                    dec=source_exam_decision(n,'Operation log',self.exam_anchor,self.sonics,txt)
                    self.source_decisions.append(dec)
                    parsed=parse_operation_events(txt,Path(n).name,self.sonics,self.auto_phase)
                    self.all_operation_events.extend(parsed)
                    if dec.status=='Included':self.operation_events.extend(parsed)
                except Exception:pass
            self.operation_events.sort(key=lambda e:e.seconds)
            self.all_operation_events.sort(key=lambda e:e.seconds)

            if getattr(self,'folder_only_mode',False):
                self.auto_phase={str(x.no):{'phase':'Treatment','confidence':'Low','reason':'Folder-set ZIP without treatment Summary; shown as Treatment for investigation'} for x in self.sonics}
            for no,meta in self.son_meta.items():
                if meta.get('phase'):self.auto_phase[no]={'phase':meta['phase'],'confidence':meta.get('phase_confidence','High'),'reason':meta.get('phase_reason','XML metadata')}
            self.spec_cache={}; self.raw_replay_cache={}; self.thermo_cache={}; self.thermo_source_cache={}; self.sync_matches={}; self.manual={}; self.external_images={}; self.load_mapping()
            progress.setLabelText('Building review tables...'); progress.setValue(88); QApplication.processEvents()
            self.populate(); self.show_raw_series_catalog(); self.show_sequence_catalog(); self.show_decoder_lab()
            self.info.setText(f'{self.zip_path.name} | {len(self.sonics)} sonications | {len(self.inventory)} files | {len(self.raw_files)} RAW | {sum(len(v) for v in self.raw_series_catalog.values())} resolved RAW series | {len(self.mr_series)}/{len(self.all_mr_series)} treatment-linked MR series | {len(self.spectrum_msg_files)} SpectrumMsg | {sum(len(v) for v in self.sequence_catalog.values())} image sequences')
            self.draw_timeline(); self.show_operation(); self.show_mr_table(); self.show_exam_explorer(); self.show_evidence(); self.show_sync(); self.show_inventory(); self.show_coverage(); self.populate_raw_combo()
            progress.setValue(100)
            if self.visible_sonics:self.table.selectRow(0)
        except Exception as e:
            progress.close()
            if str(e)!='Import canceled':QMessageBox.critical(self,'Load error',str(e))

    def populate(self,*args):
        # Rebuild the filtered list without relying on Qt to emit a selection signal.
        # The previous implementation selected a row after rebuilding, but when the
        # current cell did not change Qt emitted no currentCellChanged signal.  That
        # left every review panel showing the old Sonication.
        selected_no=self.current_sonication_no
        if selected_no is None:
            r=self.table.currentRow()
            if 0<=r<len(self.visible_sonics): selected_no=self.visible_sonics[r].no
        self._updating=True
        self.table.blockSignals(True); self.series_combo.blockSignals(True)
        self.visible_sonics=[x for x in self.sonics if self.show_dqa.isChecked() or self.effective_phase(x)=='Treatment']
        self.table.clearContents(); self.table.setRowCount(len(self.visible_sonics))
        self.sonication_combo.blockSignals(True); self.sonication_combo.clear()
        for sx in self.visible_sonics:
            self.sonication_combo.addItem(f'Sonication {sx.no} — {self.effective_phase(sx)} — {sx.time}',int(sx.no))
        self.sonication_combo.blockSignals(False)
        self.series_combo.clear(); self.series_combo.addItem('No linked MR series',-1)
        for i,m in enumerate(self.mr_series): self.series_combo.addItem(f'{m.time} | {m.description or m.protocol} | {m.plane} | {m.freq_dir}',i)
        for r,s in enumerate(self.visible_sonics):
            auto=self.auto_series_index(s); m=self.mr_series[auto] if auto is not None else None
            man=self.manual.get(str(s.no),{})
            ap=self.auto_phase.get(str(s.no),{'phase':'DQA','confidence':'Low'})
            phase=man.get('phase') or ap['phase']
            meta=self.son_meta.get(str(s.no),{})
            vals=[s.no,phase,ap.get('confidence',''),s.time,f'{float(meta.get("actualduration",s.duration)):.2f}',f'{s.power:.1f}',f'{float(meta.get("measuredpower",s.avg_power)):.1f}',f'{s.freq:.3f}',f'{s.fd:.1f}',s.status,man.get('plane') or meta.get('plane') or (m.plane if m else 'Unknown'),man.get('freq_dir') or meta.get('freqdirection') or (m.freq_dir if m else 'Unknown')]
            for c,v in enumerate(vals):
                item=QTableWidgetItem(str(v))
                if c==0:item.setData(Qt.UserRole,int(s.no))
                self.table.setItem(r,c,item)
        self.table.blockSignals(False); self.series_combo.blockSignals(False); self._updating=False
        if self.visible_sonics:
            idx=next((i for i,x in enumerate(self.visible_sonics) if x.no==selected_no),0)
            self.set_selected_row(idx,force=True)
            self.show_operation()
            self.draw_timeline()
        else:
            self.current_sonication_no=None
            self.panel_errors={}
            for lab in self.detail_labels.values(): lab.setText('—')

    def offset_candidates(self):
        vals=[float(v) for v,_ in self.ws_offsets if np.isfinite(v)]
        if not vals:return [(0.0,'No explicit offset')]
        med=float(np.median(vals))
        return [(med,'MR + WS offset'),(-med,'MR - WS offset'),(0.0,'Uncorrected')]

    def resolve_series_match(self,s):
        key=str(s.no)
        if key in self.sync_matches:return self.sync_matches[key]
        if not self.mr_series:
            result=SyncMatch(reasons=['No review.out MR series available'])
            self.sync_matches[key]=result; return result
        meta=self.son_meta.get(key,{})
        req_plane=normalize_plane(meta.get('plane') or meta.get('scanplane') or 'Unknown')
        req_freq=normalize_freq(meta.get('freqdirection') or 'Unknown')
        target=time_seconds(s.time); evaluated=[]
        for i,m in enumerate(self.mr_series):
            mt=time_seconds(m.time) if m.time else 0
            plane_ok,freq_ok=geometry_compatible(req_plane,req_freq,m.plane,m.freq_dir)
            protocol_ok=is_thermometry_series(m); best=None
            for off,desc in self.offset_candidates():
                gap=target-(mt+off); score=0.0; reasons=[]
                if protocol_ok:score+=120; reasons.append('TMAP/MEMP thermometry protocol')
                else:score-=35
                if req_plane!='Unknown':
                    if plane_ok:score+=100; reasons.append('plane match '+req_plane)
                    else:score-=500; reasons.append('plane mismatch '+m.plane)
                if req_freq!='Unknown':
                    if freq_ok:score+=80; reasons.append('frequency compatible '+req_freq)
                    else:score-=400; reasons.append('frequency mismatch '+m.freq_dir)
                if -2<=gap<=45:score+=100-max(0,abs(gap-10))*2.5; reasons.append(f'expected baseline window {gap:+.2f}s')
                elif -10<=gap<=90:score+=25-max(0,abs(gap-10))*.5; reasons.append(f'nearby acquisition {gap:+.2f}s')
                else:score-=min(abs(gap),600)*.35
                xml_desc=str(meta.get('seriesdiscription','')).lower(); text=(' '.join((m.description,m.protocol,m.series_no))).lower()
                if xml_desc and any(tok in text for tok in re.findall(r'[a-z0-9]+',xml_desc) if len(tok)>3):score+=70; reasons.append('XML series description match')
                cand=(score,i,gap,off,desc,plane_ok,freq_ok,protocol_ok,reasons)
                if best is None or score>best[0]:best=cand
            evaluated.append(best)
        evaluated.sort(key=lambda x:x[0],reverse=True); best=evaluated[0]
        confidence='High' if best[0]>=250 else ('Medium' if best[0]>=140 else 'Low')
        rejected=[]
        for e in evaluated[1:6]:
            mm=self.mr_series[e[1]]; rejected.append(f'{mm.time} {mm.description or mm.protocol}: score {e[0]:.1f}; plane={mm.plane}; freq={mm.freq_dir}; gap={e[2]:+.2f}s')
        result=SyncMatch(best[1],best[0],confidence,best[2],best[3],best[4],best[5],best[6],best[7],best[8],rejected)
        if not best[5] or not best[6]:result.series_index=-1; result.confidence='Low'; result.reasons.append('Auto-link rejected by geometry gate')
        self.sync_matches[key]=result; return result

    def auto_series_index(self,s):
        match=self.resolve_series_match(s)
        return match.series_index if match.series_index>=0 else None

    def raw_geometry_allowed(self,s):
        meta=self.son_meta.get(str(s.no),{})
        required_plane=normalize_plane(meta.get('plane') or meta.get('scanplane') or self.plane_combo.currentText())
        required_freq=normalize_freq(meta.get('freqdirection') or self.freq_combo.currentText())
        displayed_plane=normalize_plane(self.plane_combo.currentText()); displayed_freq=normalize_freq(self.freq_combo.currentText())
        plane_ok,freq_ok=geometry_compatible(required_plane,required_freq,displayed_plane,displayed_freq)
        reasons=[]
        if not plane_ok:reasons.append(f'plane mismatch: RAW {required_plane}, display {displayed_plane}')
        if not freq_ok:reasons.append(f'frequency mismatch: RAW {required_freq}, display {displayed_freq}')
        if required_plane=='Unknown':reasons.append('RAW plane is unconfirmed')
        if required_freq=='Unknown':reasons.append('RAW frequency direction is unconfirmed')
        return plane_ok and freq_ok and required_plane!='Unknown' and required_freq!='Unknown',reasons,required_plane,required_freq

    def sonication_combo_changed(self,index):
        if self._updating or index<0:return
        son_no=self.sonication_combo.itemData(index)
        row=self.row_for_sonication(son_no)
        if row>=0:self.set_selected_row(row,force=True)

    def toggle_selected_details(self,checked):
        self.detail_box.setVisible(bool(checked))
        self.detail_toggle.setText(('▼' if checked else '▶')+' Selected Sonication details')

    def toggle_mapping_controls(self,checked):
        box=getattr(self,'mapping_controls',None)
        if box is None:return
        # Keep the title/check box available while collapsing the form body.
        for child in box.findChildren(QWidget):
            if child is not box:
                child.setVisible(bool(checked))
        box.setMaximumHeight(16777215 if checked else 28)

    def reset_operation_filters(self):
        self.operation_category.setCurrentText('All')
        self.operation_search.clear()
        self.operation_column_filters={}
        self.operation_column_searches={}
        if hasattr(self,'operation_plot'):self.operation_plot._initial_limits.clear()
        self.show_operation()

    def _operation_value(self,event,column):
        values=[event.time_text,event.category,event.actor,event.severity,
                event.sonication if event.sonication>=0 else '—',
                event.phase,event.source,event.message]
        return str(values[column]) if 0<=column<len(values) else ''

    def _visible_operation_events(self):
        events=list(self.operation_events)
        if not self.show_dqa.isChecked():
            events=[e for e in events if e.phase!='DQA']
        category=self.operation_category.currentText() if hasattr(self,'operation_category') else 'All'
        if category!='All':
            if category in ('Operator','Software'):events=[e for e in events if e.actor==category]
            elif category in ('Warning','Error'):events=[e for e in events if e.severity==category]
            else:events=[e for e in events if e.category==category]
        query=self.operation_search.text().strip().lower() if hasattr(self,'operation_search') else ''
        if query:
            events=[e for e in events if query in e.message.lower() or query in e.source.lower() or query in e.category.lower()]
        for column,accepted in getattr(self,'operation_column_filters',{}).items():
            if accepted:
                events=[e for e in events if self._operation_value(e,column) in accepted]
        for column,needle in getattr(self,'operation_column_searches',{}).items():
            needle=str(needle).strip().lower()
            if needle:
                events=[e for e in events if needle in self._operation_value(e,column).lower()]
        return events

    def show_operation_column_menu(self):
        menu=QMenu(self)
        headers=[self.operation_table.horizontalHeaderItem(i).text() for i in range(self.operation_table.columnCount())]
        action=menu.addAction('Show all columns'); action.triggered.connect(lambda:self.set_all_operation_columns(True))
        action=menu.addAction('Hide optional columns'); action.triggered.connect(self.hide_optional_operation_columns)
        menu.addSeparator()
        for column,name in enumerate(headers):
            action=menu.addAction(name); action.setCheckable(True)
            action.setChecked(not self.operation_table.isColumnHidden(column))
            action.toggled.connect(lambda checked,c=column:self.operation_table.setColumnHidden(c,not checked))
        menu.exec(QCursor.pos())

    def set_all_operation_columns(self,visible):
        for column in range(self.operation_table.columnCount()):
            self.operation_table.setColumnHidden(column,not visible)

    def hide_optional_operation_columns(self):
        keep={0,1,3,4,7}
        for column in range(self.operation_table.columnCount()):
            self.operation_table.setColumnHidden(column,column not in keep)

    def operation_header_context_menu(self,pos):
        header=self.operation_table.horizontalHeader()
        column=header.logicalIndexAt(pos)
        if column<0:return
        menu=QMenu(self); name=self.operation_table.horizontalHeaderItem(column).text()
        action=menu.addAction(f'Filter “{name}”…'); action.triggered.connect(lambda:self.configure_operation_column_filter(column))
        action=menu.addAction(f'Search “{name}”…'); action.triggered.connect(lambda:self.configure_operation_column_search(column))
        menu.addSeparator()
        action=menu.addAction(f'Hide “{name}”'); action.triggered.connect(lambda:self.operation_table.setColumnHidden(column,True))
        action=menu.addAction('Show / Hide Columns…'); action.triggered.connect(self.show_operation_column_menu)
        menu.addSeparator()
        action=menu.addAction(f'Clear filter/search for “{name}”'); action.triggered.connect(lambda:self.clear_operation_column_constraints(column))
        menu.exec(header.mapToGlobal(pos))

    def operation_table_context_menu(self,pos):
        index=self.operation_table.indexAt(pos)
        column=index.column() if index.isValid() else -1
        menu=QMenu(self)
        if column>=0:
            name=self.operation_table.horizontalHeaderItem(column).text()
            item=self.operation_table.item(index.row(),column)
            value=item.text() if item else ''
            action=menu.addAction(f'Filter {name} = “{value[:50]}”'); action.triggered.connect(lambda:self.set_operation_single_value_filter(column,value))
            action=menu.addAction(f'Search this column…'); action.triggered.connect(lambda:self.configure_operation_column_search(column))
            menu.addSeparator()
            action=menu.addAction(f'Hide “{name}”'); action.triggered.connect(lambda:self.operation_table.setColumnHidden(column,True))
        action=menu.addAction('Show / Hide Columns…'); action.triggered.connect(self.show_operation_column_menu)
        menu.exec(self.operation_table.viewport().mapToGlobal(pos))

    def configure_operation_column_filter(self,column):
        values=sorted({self._operation_value(e,column) for e in self.operation_events})
        if not values:return
        current=', '.join(sorted(self.operation_column_filters.get(column,set())))
        prompt='Enter exact values separated by commas. Leave blank to clear.\n\nAvailable values:\n'+' | '.join(values[:80])
        value,ok=QInputDialog.getMultiLineText(self,'Column Filter',prompt,current)
        if not ok:return
        selected={v.strip() for v in value.split(',') if v.strip()}
        if selected:self.operation_column_filters[column]=selected
        else:self.operation_column_filters.pop(column,None)
        self.show_operation()

    def configure_operation_column_search(self,column):
        current=self.operation_column_searches.get(column,'')
        value,ok=QInputDialog.getText(self,'Column Search','Contains text:',text=current)
        if not ok:return
        value=value.strip()
        if value:self.operation_column_searches[column]=value
        else:self.operation_column_searches.pop(column,None)
        self.show_operation()

    def set_operation_single_value_filter(self,column,value):
        self.operation_column_filters[column]={str(value)}
        self.show_operation()

    def clear_operation_column_constraints(self,column):
        self.operation_column_filters.pop(column,None)
        self.operation_column_searches.pop(column,None)
        self.show_operation()

    def operation_zoom_selected(self,xmin,xmax):
        if not np.isfinite(xmin) or not np.isfinite(xmax) or xmax<=xmin:return
        axes=self.operation_plot.fig.axes
        if axes:
            self.operation_plot.remember_initial_view()
            axes[0].set_xlim(xmin,xmax)
            self.operation_plot.draw_idle()

    def operation_plot_clicked(self,event):
        if getattr(event,'dblclick',False):
            self.operation_plot.reset_view(); return
        if event.button!=1 or event.xdata is None or event.ydata is None:return
        events=getattr(self,'operation_visible_events',[])
        categories=getattr(self,'operation_plot_categories',[])
        axes=self.operation_plot.fig.axes
        if not events or not categories or not axes:return
        ax=axes[0]; xspan=max(abs(ax.get_xlim()[1]-ax.get_xlim()[0]),1.0)
        best_row=None; best_score=1e99
        for row,e in enumerate(events):
            try:y=categories.index(e.category)
            except ValueError:continue
            score=abs(e.seconds-event.xdata)/xspan+abs(y-event.ydata)*.15
            if score<best_score:best_score=score; best_row=row
        if best_row is not None:
            self.operation_table.selectRow(best_row)
            item=self.operation_table.item(best_row,0)
            if item:self.operation_table.scrollToItem(item,QTableWidget.PositionAtCenter)

    def show_operation(self,*args):
        if not hasattr(self,'operation_table'):return
        events=self._visible_operation_events()
        self.operation_visible_events=events
        self.operation_table.setUpdatesEnabled(False)
        self.operation_table.setRowCount(len(events))
        for r,e in enumerate(events):
            vals=[e.time_text,e.category,e.actor,e.severity,e.sonication if e.sonication>=0 else '—',e.phase,e.source,e.message]
            for c,v in enumerate(vals):
                item=QTableWidgetItem(str(v)); item.setData(Qt.UserRole,float(e.seconds))
                item.setToolTip(str(v)); item.setTextAlignment(Qt.AlignLeft|Qt.AlignTop)
                self.operation_table.setItem(r,c,item)
        self.operation_table.resizeRowsToContents()
        self.operation_table.setUpdatesEnabled(True)

        cats={}
        for e in events:cats[e.category]=cats.get(e.category,0)+1
        summary=(f'{len(events)} treatment-linked events | '+', '.join(f'{k}: {v}' for k,v in sorted(cats.items()))) if events else 'No treatment-linked operation events for the current filter.'
        active=[]
        if self.operation_column_filters:active.append('column filters')
        if self.operation_column_searches:active.append('column searches')
        if active:summary+=' | Active: '+', '.join(active)
        self.operation_summary.setText(summary)

        f=self.operation_plot.fig; f.clear(); ax=f.add_subplot(111)
        if events:
            categories=list(dict.fromkeys(e.category for e in events))
            self.operation_plot_categories=categories
            cmap={c:i for i,c in enumerate(categories)}
            for e in events:
                ax.scatter(e.seconds,cmap[e.category],s=34,marker='|' if e.actor=='Software' else 'o')
            ax.set_yticks(range(len(categories)),categories)
            ax.xaxis.set_major_formatter(FuncFormatter(clock_formatter))
            ax.set_xlabel('Treatment session time')
            ax.set_title('Operator actions and software workflow — click: jump | drag: zoom | double-click: reset')
            ax.grid(True,axis='x',alpha=.25)
        else:
            self.operation_plot_categories=[]
            ax.text(.5,.5,'No included operation events',ha='center',va='center',transform=ax.transAxes)
            ax.set_axis_off()
        try:
            if self.operation_zoom_selector is not None:self.operation_zoom_selector.disconnect_events()
        except Exception:pass
        self.operation_zoom_selector=SpanSelector(ax,self.operation_zoom_selected,'horizontal',useblit=True,interactive=False,
                                                   drag_from_anywhere=True,props=dict(alpha=.18,facecolor='#6baed6'))
        self.operation_plot.remember_initial_view(force=True); self.operation_plot.draw_idle()

    def operation_row_activated(self,row,column):
        item=self.operation_table.item(row,0)
        if item is None:return
        sec=float(item.data(Qt.UserRole) or 0.0)
        # Jump to nearest visible Sonication.
        if self.visible_sonics:
            s=min(self.visible_sonics,key=lambda x:abs(time_seconds(x.time)-sec))
            rr=self.row_for_sonication(s.no)
            if rr>=0:self.set_selected_row(rr,force=True)

    def sonication_for_row(self,row):
        """Resolve the selected Sonication by the ID stored in the table item.

        This avoids stale visible_sonics row mappings after filtering or table rebuilds.
        """
        if not (0<=row<self.table.rowCount()):return None
        item=self.table.item(row,0)
        son_no=item.data(Qt.UserRole) if item is not None else None
        if son_no is None:
            try:son_no=int(item.text())
            except Exception:return None
        return next((x for x in self.sonics if int(x.no)==int(son_no)),None)

    def row_for_sonication(self,son_no):
        for row in range(self.table.rowCount()):
            item=self.table.item(row,0)
            if item is None:continue
            value=item.data(Qt.UserRole)
            try:
                if int(value if value is not None else item.text())==int(son_no):return row
            except Exception:pass
        return -1

    def select_row(self,row,col,pr,pc):
        if self._updating:return
        if self.sonication_for_row(row) is not None:self.set_selected_row(row,force=True)

    def select_row_clicked(self,row,col):
        if not self._updating:self.set_selected_row(row,force=True)

    def selection_changed(self):
        if self._updating:return
        row=self.table.currentRow()
        if row>=0:self.set_selected_row(row,force=True)

    def set_selected_row(self,row,force=False):
        son=self.sonication_for_row(row)
        if son is None:return
        changed=(int(son.no)!=int(self.current_sonication_no)) if self.current_sonication_no is not None else True
        if changed:self.cav_selected_range=None
        self.current_sonication_no=int(son.no)
        if hasattr(self,'sonication_combo'):
            ci=self.sonication_combo.findData(int(son.no))
            if ci>=0:
                self.sonication_combo.blockSignals(True); self.sonication_combo.setCurrentIndex(ci); self.sonication_combo.blockSignals(False)
        self.table.blockSignals(True)
        try:
            self.table.setCurrentCell(row,0)
            self.table.selectRow(row)
            item=self.table.item(row,0)
            if item:self.table.scrollToItem(item)
        finally:
            self.table.blockSignals(False)
        self.refresh_selected(force=True)

    def _panel_error_text(self,name,error):
        return f'{name} update failed for Sonication {self.current_sonication_no}: {type(error).__name__}: {error}'

    def _safe_update(self,name,func,*args):
        try:
            func(*args)
            self.panel_errors.pop(name,None)
            return True
        except Exception as exc:
            self.panel_errors[name]=self._panel_error_text(name,exc)
            print(self.panel_errors[name])
            return False

    def _draw_error_plot(self,plot,title,message):
        try:
            plot.fig.clear()
            ax=plot.fig.add_subplot(111)
            ax.axis('off')
            ax.text(.5,.55,title,ha='center',va='center',fontsize=13,fontweight='bold')
            ax.text(.5,.42,message,ha='center',va='center',wrap=True,fontsize=9)
            plot.draw_idle()
        except Exception:pass

    def refresh_selected(self,*args,force=False):
        """Debounce context refreshes so rapid row changes never queue heavy decoders."""
        if self._updating:
            return
        self._refresh_generation += 1
        self._pending_refresh_force = self._pending_refresh_force or bool(force)
        self._refresh_timer.start()

    def _run_scheduled_refresh(self):
        force=self._pending_refresh_force
        self._pending_refresh_force=False
        self._refresh_selected_now(force=force)

    def _tab_changed(self,*args):
        if self.zf is not None and not self._updating:
            self.refresh_selected(force=True)

    def _refresh_selected_now(self,*args,force=False):
        if self._context_refreshing:return
        row=self.table.currentRow()
        s=self.sonication_for_row(row)
        if s is None and self.current_sonication_no is not None:
            row=self.row_for_sonication(self.current_sonication_no)
            s=self.sonication_for_row(row)
        if s is None:return
        self.current_sonication_no=int(s.no)
        self._context_refreshing=True
        self.panel_errors={}
        man=self.manual.get(str(s.no),{})
        auto=self.auto_series_index(s)
        chosen=man.get('series_index',auto if auto is not None else -1)
        self._updating=True
        try:
            ap=self.auto_phase.get(str(s.no),{'phase':'DQA','confidence':'Low','reason':'No evidence'})
            self.phase_combo.setCurrentText(man.get('phase','Auto'))
            effective=man.get('phase') or ap['phase']
            self.phase_evidence.setText(f'Effective: {effective} | Confidence: {ap.get("confidence","Low")} | {ap.get("reason","")}')
            idx=self.series_combo.findData(chosen)
            self.series_combo.setCurrentIndex(idx if idx>=0 else 0)
            m=self.mr_series[chosen] if isinstance(chosen,int) and 0<=chosen<len(self.mr_series) else None
            meta=self.son_meta.get(str(s.no),{})
            plane=man.get('plane') or meta.get('plane') or (m.plane if m and self.use_auto.isChecked() else 'Unknown')
            freq=man.get('freq_dir') or meta.get('freqdirection') or (m.freq_dir if m and self.use_auto.isChecked() else 'Unknown')
            self.plane_combo.setCurrentText(normalize_plane(plane) if plane not in PLANE_OPTIONS else plane)
            self.freq_combo.setCurrentText(freq if freq in FREQ_OPTIONS else 'Unknown')
            source=[]
            if meta:source.append('sonication XML metadata')
            match=self.resolve_series_match(s)
            if m and self.use_auto.isChecked():source.append(f'review.out synchronized match ({match.confidence}, gap {match.corrected_gap:+.2f}s)')
            elif self.use_auto.isChecked() and match.reasons:source.append('MR auto-match rejected')
            if man:source.append('manual override')
            if str(s.no) in self.external_images:source.append('external MR image')
            self.source_label.setText('Source: '+(', '.join(source) if source else 'simulation / not available'))
        finally:
            self._updating=False

        try:
            # Fixed details are updated before any potentially failing decoder or plot.
            self._safe_update('Selected details',self.show_details,s,m)
            self._safe_update('Maximum information',self.show_overview,s,m)
            self._safe_update('Time synchronization',self.show_sync)
            self._safe_update('Evidence',self.show_evidence)
            self._safe_update('Data coverage',self.show_coverage)
            self._safe_update('Timeline',self.draw_timeline)

            # Heavy binary decoding is restricted to the currently visible tab.
            # Other heavy tabs are refreshed when the user opens them. This prevents
            # RAW + Thermometry + Spectrum + Hydrophone from blocking the GUI at once.
            current=self.tabs.currentWidget()
            if current is self.imgplot:
                if not self._safe_update('MR / Hotspot Replay',self.draw_image,s,m):
                    self._draw_error_plot(self.imgplot,'MR / Hotspot Replay unavailable',self.panel_errors.get('MR / Hotspot Replay','Unknown error'))
            elif current is self.thermopage:
                if self._safe_update('Thermometry preparation',self.prepare_thermometry,s):
                    if not self._safe_update('Thermometry Replay',self.draw_thermometry):
                        self._draw_error_plot(self.thermoplot,'Thermometry Replay unavailable',self.panel_errors.get('Thermometry Replay','Unknown error'))
                else:
                    self._draw_error_plot(self.thermoplot,'Thermometry preparation failed',self.panel_errors.get('Thermometry preparation','Unknown error'))
            elif current is self.cavpage:
                if not self._safe_update('Hydrophone Cavitation',self.draw_cavitation,s):
                    self._draw_error_plot(self.cavplot,'Hydrophone / Cavitation unavailable',self.panel_errors.get('Hydrophone Cavitation','Unknown error'))
            elif current is self.specpage:
                if not self._safe_update('Spectrum',self.draw_spectrum,s):
                    self._draw_error_plot(self.specplot,'Spectrum unavailable',self.panel_errors.get('Spectrum','Unknown error'))
            elif current is self.syncpage:
                if not self._safe_update('Synchronized Analysis',self.draw_synchronized_analysis,s,m):
                    self._draw_error_plot(self.syncplot,'Synchronized Analysis unavailable',self.panel_errors.get('Synchronized Analysis','Unknown error'))
            elif current is self.mrseries_page:
                if self.mrtable.currentRow()>=0:self.draw_selected_mr_series()

            # Surface panel-specific errors without hiding successfully updated data.
            if self.panel_errors:
                errors='\n'.join('• '+v for v in self.panel_errors.values())
                try:self.evidence.append('\n\nPanel update diagnostics:\n'+errors)
                except Exception:pass
            for canvas in (self.imgplot,self.thermoplot,self.cavplot,self.specplot,self.syncplot,self.operation_plot,self.mrseries_plot,self.timeline):
                try:canvas.draw_idle()
                except Exception:pass
            # Do not call processEvents here: it can re-enter table-selection signals.
        finally:
            self._context_refreshing=False


    def reset_all_analysis(self):
        """Return interactive analysis controls to their reproducible defaults."""
        self.cav_selected_range=None
        self.common_time_s=0.0
        self.sync_play_timer.stop()
        if hasattr(self,'sync_play'):self.sync_play.setText('▶ Play')
        if hasattr(self,'common_time_slider'):
            self.common_time_slider.blockSignals(True); self.common_time_slider.setValue(0); self.common_time_slider.blockSignals(False)
        if hasattr(self,'spec_interval'):self.spec_interval.setCurrentText('During Sonication')
        if hasattr(self,'spec_display'):self.spec_display.setCurrentText('Single')
        if hasattr(self,'spec_y'):self.spec_y.setCurrentText('Amplitude')
        for checks in (getattr(self,'hp_checks',[]),getattr(self,'spec_checks',[])):
            for i,cb in enumerate(checks):cb.setChecked(i<4)
        for plot in (getattr(self,'imgplot',None),getattr(self,'thermoplot',None),getattr(self,'cavplot',None),getattr(self,'specplot',None),getattr(self,'syncplot',None),getattr(self,'timeline',None)):
            if plot is not None:plot._initial_limits.clear()
        self.refresh_selected(force=True)

    def _parse_seconds_text(self,value,default=0.0):
        txt=str(value or '').strip()
        if not txt:return default
        try:return float(txt)
        except Exception:pass
        try:
            parts=[float(x) for x in txt.split(':')]
            if len(parts)==3:return parts[0]*3600+parts[1]*60+parts[2]
            if len(parts)==2:return parts[0]*60+parts[1]
        except Exception:pass
        return default

    def _acquisition_link_rows(self,s,m,dump):
        """Link lower-rate MR acquisitions to higher-rate SpectrumMsg frames by time windows.

        The link is deterministic and marked Estimated when exact per-frame timestamps
        are not available in the MR metadata.
        """
        duration=max(float(s.duration or 0.0),0.1)
        scan_total=self._parse_seconds_text(getattr(m,'scan_time','') if m else '',0.0)
        acq_count=0
        try:acq_count=int(float(getattr(m,'acquisitions','') or 0))
        except Exception:acq_count=0
        if acq_count<=0:
            # Thermometry usually samples every ~3.4–4 s. This is only fallback evidence.
            acq_count=max(1,int(round(max(scan_total,duration+10.0)/3.8)))
        if scan_total<=0:scan_total=max(duration+10.0,acq_count*3.8)
        interval=scan_total/max(acq_count,1)
        # Put FUS start after an estimated pre-acquisition baseline period.
        pre=max(0.0,scan_total-duration)
        pre=min(pre,10.0) if pre>0 else 0.0
        start=-pre
        spec_times=np.array([],dtype=float)
        if dump is not None and dump.channels:
            ch=dump.channels[0]
            idx=self._valid_frame_indices(ch,duration)
            spec_times=idx*ch.frame_interval_s
        rows=[]
        for i in range(acq_count):
            lo=start+i*interval; hi=start+(i+1)*interval
            if spec_times.size:
                mask=(spec_times>=max(0.0,lo))&(spec_times<max(0.0,hi))
                sf=np.where(mask)[0]
                count=int(sf.size)
                nearest=float(spec_times[np.argmin(np.abs(spec_times-((lo+hi)/2)))])
                gap=nearest-((lo+hi)/2)
            else:
                count=0; nearest=float('nan'); gap=float('nan')
            phase='Pre' if hi<=0 else ('During' if lo<duration and hi>0 else 'Post')
            rows.append(dict(frame=i,lo=lo,hi=hi,phase=phase,count=count,nearest=nearest,gap=gap,
                             confidence='High' if count>0 and m and is_thermometry_text(f'{m.protocol} {m.description}') else ('Medium' if count>0 else 'Low')))
        return rows,interval,scan_total

    def draw_synchronized_analysis(self,s,m=None):
        f=self.syncplot.fig; f.clear()
        if not self.show_dqa.isChecked() and self.effective_phase(s)=='DQA':
            ax=f.add_subplot(111); ax.text(.5,.5,'DQA hidden by Show DQA filter',ha='center',va='center',transform=ax.transAxes); ax.set_axis_off(); self.syncplot.draw_idle(); return
        name,dump=self.decoded_hydrophones(s)
        rows,interval,scan_total=self._acquisition_link_rows(s,m,dump)
        duration=max(float(s.duration or 0.0),0.1)
        tmin=min([r['lo'] for r in rows]+[0.0]); tmax=max([r['hi'] for r in rows]+[duration])
        self.sync_link_cache[int(s.no)]=rows

        ax=f.add_subplot(311)
        for r in rows:
            color_alpha=.25 if r['phase']=='Pre' else (.45 if r['phase']=='During' else .2)
            ax.axvspan(r['lo'],r['hi'],alpha=color_alpha)
            ax.text((r['lo']+r['hi'])/2,.55,str(r['frame']),ha='center',va='center',fontsize=7)
        ax.axvspan(0,duration,alpha=.18,label='FUS on')
        ax.axvline(self.common_time_s,linewidth=1.5)
        ax.set_xlim(tmin,tmax); ax.set_ylim(0,1); ax.set_yticks([])
        ax.set_title('MR acquisition windows linked to Sonication time')
        ax.set_xlabel('Time relative to FUS start (s)'); ax.grid(True,axis='x',alpha=.2)

        axs=f.add_subplot(312)
        if dump is not None:
            selected=self._spectrum_selected_channels(dump,self.spec_checks)
            center=float(s.freq)*1e6
            for i in selected:
                ch=dump.channels[i]; idx=self._valid_frame_indices(ch,duration)
                if idx.size==0:continue
                vals=[]
                for k in idx:
                    metric=analyze_frame(ch,int(k),center)
                    vals.append(metric.broadband_energy)
                vals=np.asarray(vals,float); vals/=np.nanpercentile(vals,99)+1e-12
                axs.plot(idx*ch.frame_interval_s,vals,label=f'Ch {i+1}')
            if axs.lines:axs.legend(ncol=4,fontsize=7)
            axs.set_ylabel('Relative broadband')
        else:
            axs.text(.5,.5,'No linked SpectrumMsg frames',ha='center',va='center',transform=axs.transAxes)
        axs.axvspan(0,duration,alpha=.12); axs.axvline(self.common_time_s,linewidth=1.5)
        axs.set_xlim(tmin,tmax); axs.set_title('Spectrum activity on the same Sonication time axis'); axs.grid(True,alpha=.25)

        axf=f.add_subplot(313)
        if dump is not None and dump.channels:
            ch_index=self._spectrum_selected_channels(dump,self.spec_checks)[0]
            ch=dump.channels[ch_index]
            idx=self._valid_frame_indices(ch,duration)
            if idx.size:
                nearest_idx=int(idx[np.argmin(np.abs(idx*ch.frame_interval_s-self.common_time_s))])
                y=np.abs(ch.spectra[nearest_idx].astype(float)); y/=np.max(y)+1e-12
                freq=frequency_axis_hz(ch,float(s.freq)*1e6)/1e6
                axf.plot(freq,y,label=f'Ch {ch_index+1} at {nearest_idx*ch.frame_interval_s:.3f} s')
                axf.legend(fontsize=8)
                axf.set_xlabel('Frequency (MHz)'); axf.set_ylabel('Normalized amplitude')
        else:
            axf.text(.5,.5,'Spectrum at current cursor unavailable',ha='center',va='center',transform=axf.transAxes)
        axf.set_title('Spectrum at common time cursor'); axf.grid(True,alpha=.25)
        f.tight_layout()
        self.syncplot.remember_initial_view(force=True); self.syncplot.draw_idle()

        self.sync_link_table.setRowCount(len(rows))
        protocol=(getattr(m,'protocol','') or getattr(m,'description','') or 'TMAP/MEMP candidate') if m else 'No included MR acquisition'
        series=getattr(m,'series_no','') if m else ''
        for rr,r in enumerate(rows):
            vals=[str(r['frame']),f'{r["lo"]:.2f} – {r["hi"]:.2f} s ({r["phase"]})',protocol,series,str(r['count']),
                  '—' if not np.isfinite(r['nearest']) else f'{r["nearest"]:.3f} s',
                  '—' if not np.isfinite(r['gap']) else f'{r["gap"]:+.3f} s',r['confidence']]
            for c,v in enumerate(vals):self.sync_link_table.setItem(rr,c,QTableWidgetItem(v))
        source=Path(name).name if name else 'No SpectrumMsg'
        self.sync_link_note.setText(
            f'Sonication {s.no}: {len(rows)} MR acquisition windows, nominal interval {interval:.3f} s, '
            f'scan span {scan_total:.2f} s, Spectrum source {source}. '
            'Exact MR-frame timestamps are used when available; otherwise acquisition windows are explicitly marked as estimated.'
        )
        self._update_common_time_controls(tmin,tmax)

    def _update_common_time_controls(self,tmin,tmax):
        self._common_time_bounds=(float(tmin),float(tmax))
        self.common_time_s=min(max(self.common_time_s,tmin),tmax)
        span=max(tmax-tmin,1e-9)
        value=int(round((self.common_time_s-tmin)/span*1000))
        self.common_time_slider.blockSignals(True); self.common_time_slider.setValue(max(0,min(1000,value))); self.common_time_slider.blockSignals(False)
        self.common_time_label.setText(f'{self.common_time_s:.3f} s')

    def common_time_changed(self,value):
        tmin,tmax=getattr(self,'_common_time_bounds',(0.0,1.0))
        self.common_time_s=tmin+(tmax-tmin)*(float(value)/1000.0)
        self.common_time_label.setText(f'{self.common_time_s:.3f} s')
        if self.zf is not None and self.tabs.currentWidget() is self.syncpage:
            row=self.table.currentRow(); s=self.sonication_for_row(row)
            if s is not None:
                m=None
                man=self.manual.get(str(s.no),{}); chosen=man.get('series_index',self.auto_series_index(s) if self.auto_series_index(s) is not None else -1)
                if isinstance(chosen,int) and 0<=chosen<len(self.mr_series):m=self.mr_series[chosen]
                self.draw_synchronized_analysis(s,m)

    def step_common_time(self,direction):
        row=self.table.currentRow(); s=self.sonication_for_row(row)
        if s is None:return
        m=None
        chosen=self.manual.get(str(s.no),{}).get('series_index',self.auto_series_index(s) if self.auto_series_index(s) is not None else -1)
        if isinstance(chosen,int) and 0<=chosen<len(self.mr_series):m=self.mr_series[chosen]
        rows,interval,_=self._acquisition_link_rows(s,m,self.decoded_hydrophones(s)[1])
        self.common_time_s+=float(direction)*max(interval,0.001)
        if rows:self._update_common_time_controls(rows[0]['lo'],rows[-1]['hi'])
        self.draw_synchronized_analysis(s,m)

    def toggle_sync_play(self):
        if self.sync_play_timer.isActive():
            self.sync_play_timer.stop(); self.sync_play.setText('▶ Play')
        else:
            self.sync_play_timer.start(); self.sync_play.setText('⏸ Pause')

    def advance_common_time(self):
        tmin,tmax=getattr(self,'_common_time_bounds',(0.0,1.0))
        step=max((tmax-tmin)/200.0,.01)
        self.common_time_s+=step
        if self.common_time_s>tmax:self.common_time_s=tmin
        span=max(tmax-tmin,1e-9)
        self.common_time_slider.setValue(int((self.common_time_s-tmin)/span*1000))

    def sync_link_row_clicked(self,row,column):
        srows=self.sync_link_cache.get(int(self.current_sonication_no or -1),[])
        if not (0<=row<len(srows)):return
        r=srows[row]; self.common_time_s=(r['lo']+r['hi'])/2
        tmin,tmax=getattr(self,'_common_time_bounds',(r['lo'],r['hi']))
        self._update_common_time_controls(tmin,tmax)
        self.common_time_changed(self.common_time_slider.value())

    def phase_changed(self,*args):
        if self._updating:return
        row=self.table.currentRow()
        if not (0<=row<len(self.visible_sonics)):return
        son=self.visible_sonics[row]; value=self.phase_combo.currentText(); d=self.manual.setdefault(str(son.no),{})
        if value=='Auto': d.pop('phase',None)
        else: d['phase']=value
        ap=self.auto_phase.get(str(son.no),{'phase':'DQA'})
        self.table.item(row,1).setText(d.get('phase') or ap['phase'])
        self.draw_timeline(); self.populate()

    def mapping_changed(self,*args):
        if self._updating:return
        row=self.table.currentRow()
        if not (0<=row<len(self.visible_sonics)):return
        s=self.visible_sonics[row]; d=self.manual.setdefault(str(s.no),{})
        d['plane']=self.plane_combo.currentText(); d['freq_dir']=self.freq_combo.currentText()
        self.table.item(row,10).setText(d['plane']); self.table.item(row,11).setText(d['freq_dir']); self.refresh_selected()

    def series_changed(self,*args):
        if self._updating:return
        row=self.table.currentRow()
        if not (0<=row<len(self.visible_sonics)):return
        s=self.visible_sonics[row]; self.manual.setdefault(str(s.no),{})['series_index']=self.series_combo.currentData(); self.refresh_selected()

    def move_row(self,d):
        if not self.visible_sonics:return
        current=self.table.currentRow()
        if current<0 and self.current_sonication_no is not None:current=next((i for i,x in enumerate(self.visible_sonics) if x.no==self.current_sonication_no),0)
        r=max(0,min(len(self.visible_sonics)-1,current+d)); self.set_selected_row(r,force=True)

    def add_mr_images(self):
        if not self.visible_sonics:return
        p=QFileDialog.getExistingDirectory(self,'Select DICOM / MR image folder')
        if not p:return
        files=[]
        for x in Path(p).rglob('*'):
            if x.is_file() and x.suffix.lower() in ('.dcm','.ima','.png','.jpg','.jpeg','.bmp','.tif','.tiff'): files.append(str(x))
        if not files: QMessageBox.information(self,'MR import','No supported MR/DICOM image files were found.'); return
        row=self.table.currentRow(); s=self.visible_sonics[row]
        self.external_images[str(s.no)]={'folder':p,'files':files[:5000]}
        QMessageBox.information(self,'MR import',f'{len(files)} files registered for Sonication {s.no}.\nThe mapping is saved in the review sidecar JSON.\nPixel rendering of ordinary PNG/JPEG is enabled; DICOM metadata/pixel support is reserved for the pydicom option.')
        self.refresh_selected()

    def mapping_path(self):return self.zip_path.with_suffix('.fus_review.json') if self.zip_path else None
    def save_mapping(self):
        if not self.zip_path:return
        data={'zip':self.zip_path.name,'manual':self.manual,'external_images':self.external_images,'saved_at':datetime.now().isoformat(timespec='seconds'),'schema_version':5}
        self.mapping_path().write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
        QMessageBox.information(self,'Saved',f'Review mapping saved:\n{self.mapping_path()}')
    def load_mapping(self):
        p=self.mapping_path()
        if p and p.exists():
            try:
                d=json.loads(p.read_text(encoding='utf-8')); self.manual=d.get('manual',{}); self.external_images=d.get('external_images',{})
            except Exception:pass

    def effective_phase(self,s):
        d=self.manual.get(str(s.no),{}); return d.get('phase') or self.auto_phase.get(str(s.no),{}).get('phase','DQA')

    def sonication_folder_pattern(self,s):
        # Exact folder ownership is the primary reconstruction key.  Do not infer
        # ownership only because the same number appears somewhere in a filename.
        return re.compile(rf'(^|[\\/])sonication[_ -]?0*{int(s.no)}([\\/]|$)',re.I)

    def sonication_folder_files(self,s):
        pat=self.sonication_folder_pattern(s)
        return [n for n in self.zf.namelist() if pat.search(n)] if self.zf else []

    def raw_paths_for_sonication(self,s,allow_fallback=False):
        pat=self.sonication_folder_pattern(s)
        paths=[n for n in self.raw_files if pat.search(n)]
        source='Same Sonication folder'
        if not paths and allow_fallback:
            # Fallback is intentionally conservative and remains lower priority.
            paths=[n for n in self.raw_files if re.search(rf'(^|\D)0*{int(s.no)}(\D|$)',Path(n).stem)]
            source='Filename-number fallback'
        def natural(x):
            return [int(v) if v.isdigit() else v.lower() for v in re.split(r'(\d+)',x)]
        return sorted(paths,key=natural),source

    def raw_frame_groups_for_sonication(self,s):
        """Decode groups already resolved by exact field/zone/array XML mapping."""
        groups=[]
        for cat in self.raw_series_catalog.get(str(s.no),[]):
            frames=[]
            for n in cat['paths']:
                try:r=try_render_raw(self.zf.read(n))
                except Exception:continue
                if not r:continue
                score,dt,w,h,img=r
                frames.append({'path':n,'score':score,'dtype':dt,'width':w,'height':h,'image':img,'field':cat['field'],'zone':cat['zone'],'description':cat['description'],'plane':cat['plane'],'freq':cat['freq'],'role':cat['role']})
            if frames:
                geometry=(frames[0]['dtype'],frames[0]['width'],frames[0]['height'])
                groups.append((geometry,frames,cat))
        groups.sort(key=lambda item:(item[2]['resolver_score'],len(item[1])),reverse=True)
        return groups,'Exact Sonication folder + MriImageParams field/zone/array resolver'

    def best_raw_for_sonication(self,s):
        key=str(s.no)
        if key in self.raw_replay_cache:return self.raw_replay_cache[key]
        ranked,source=self.raw_frame_groups_for_sonication(s); best=None
        if ranked:
            geometry,frames,cat=ranked[0]
            # Prefer a thermometry magnitude-looking representative from the exact XML-mapped series.
            rep=max(frames,key=lambda fr:fr['score'])
            best=(rep['score'],rep['path'],(rep['score'],rep['dtype'],rep['width'],rep['height'],rep['image']),source,len(frames),geometry,cat)
        self.raw_replay_cache[key]=best; return best

    def prepare_thermometry(self,s):
        key=str(s.no)
        ranked,source=self.raw_frame_groups_for_sonication(s)
        therm=[x for x in ranked if x[2].get('thermometry')]
        chosen=therm[0] if therm else (ranked[0] if ranked else None)
        self.thermo_cache[key]=chosen[1] if chosen else []
        cat=chosen[2] if chosen else {}
        self.thermo_source_cache[key]={'source':source if chosen else 'No exact mapped RAW sequence','group_count':len(ranked),'frame_count':len(chosen[1]) if chosen else 0,'geometry':chosen[0] if chosen else None,'field':cat.get('field'),'zone':cat.get('zone'),'description':cat.get('description'),'xml_coverage':cat.get('xml_coverage',0),'resolver_score':cat.get('resolver_score',0)}
        frames=self.thermo_cache[key]
        self.thermo_slider.blockSignals(True); self.thermo_slider.setMaximum(max(0,len(frames)-1)); self.thermo_slider.setValue(min(self.thermo_slider.value(),max(0,len(frames)-1))); self.thermo_slider.blockSignals(False)

    def draw_thermometry(self,*args):
        row=self.table.currentRow()
        f=self.thermoplot.fig; f.clear()
        if not (0<=row<len(self.visible_sonics)):
            self.thermoplot.draw(); return
        s=self.visible_sonics[row]; frames=self.thermo_cache.get(str(s.no),[])
        if len(frames)<2:
            ax=f.add_subplot(111); ax.text(.5,.5,'No consistent RAW frame sequence could be reconstructed',ha='center',va='center',transform=ax.transAxes); ax.axis('off')
            self.thermo_frame_label.setText('No frame')
            self.thermo_note.setText(f'No consistent RAW sequence was decoded inside Sonication{s.no}. Cross-folder/time-near RAW is not substituted automatically. Thermometry requires a baseline phase image and subsequent phase/magnitude frames.')
            self.thermoplot.draw(); return
        i=max(0,min(self.thermo_slider.value(),len(frames)-1)); base=frames[0]['image']; cur=frames[i]['image']
        # Wrapped normalized difference is a structural candidate only. Celsius conversion requires phase scale, TE, field strength and PRF coefficient.
        diff=cur-base
        lim=max(float(np.percentile(np.abs(diff),99)),1e-6)
        mode=self.thermo_mode.currentText()
        self.thermo_frame_label.setText(f'{i+1} / {len(frames)}')
        if mode=='Baseline / Current / Difference':
            axes=[f.add_subplot(1,3,j+1) for j in range(3)]
            axes[0].imshow(base,cmap='gray'); axes[0].set_title('Baseline phase/magnitude candidate')
            axes[1].imshow(cur,cmap='gray'); axes[1].set_title(f'Frame {i+1} candidate')
            im=axes[2].imshow(diff,cmap='coolwarm',vmin=-lim,vmax=lim); axes[2].set_title('Frame − baseline')
            f.colorbar(im,ax=axes[2],fraction=.046,pad=.04)
            for ax in axes: ax.set_xticks([]); ax.set_yticks([])
        elif mode=='Magnitude candidate':
            ax=f.add_subplot(111); ax.imshow(cur,cmap='gray'); ax.set_title(f'Magnitude/phase RAW candidate — frame {i+1}'); ax.set_xticks([]); ax.set_yticks([])
        else:
            ax=f.add_subplot(111); im=ax.imshow(diff,cmap='coolwarm',vmin=-lim,vmax=lim); f.colorbar(im,ax=ax)
            ax.set_xticks([]); ax.set_yticks([])
            ax.set_title(('Phase-difference candidate' if mode.startswith('Phase') else 'Temperature-rise spatial candidate')+f' — frame {i+1}')
        src=self.thermo_source_cache.get(str(s.no),{})
        self.thermo_note.setText(f'Source priority: {src.get("source","Unknown")} | XML field/zone: {src.get("field")}/{src.get("zone")} | Protocol: {src.get("description") or "Unknown"} | XML coverage: {src.get("xml_coverage",0):.0%} | Frames: {src.get("frame_count",len(frames))} | Baseline: {Path(frames[0]["path"]).name} | Current: {Path(frames[i]["path"]).name}. Exact Sonication folder and MriImageParams field/zone/array mapping are used before image-likeness scoring. Phase identity, echo pairing, cadence, unwrap and °C calibration remain under validation.')
        self.thermoplot.draw()

    def draw_image(self,s,m):
        f=self.imgplot.fig; f.clear()
        gs=f.add_gridspec(3,2,width_ratios=[1.65,1],height_ratios=[1,1,1])
        ax=f.add_subplot(gs[:,0]); axt=f.add_subplot(gs[0,1]); axs=f.add_subplot(gs[1,1]); axa=f.add_subplot(gs[2,1])
        n=360; yy,xx=np.mgrid[-1:1:complex(n),-1:1:complex(n)]
        base=None; image_source=''; geometry_warning=''
        # Priority 1: reconstruct from the exact SonicationN folder.
        raw=self.best_raw_for_sonication(s)
        if raw:
            allowed,geo_reasons,req_plane,req_freq=self.raw_geometry_allowed(s)
            known_mismatch=any('mismatch' in r for r in geo_reasons)
            if not known_mismatch:
                score,nraw,result,raw_source,frame_count,geometry,rawcat=raw
                _,dt,w,h,img=result; base=img
                geometry_warning='; '.join(r for r in geo_reasons if 'unconfirmed' in r)
                image_source=f'Priority 1 — {raw_source}: Field {rawcat.get("field")} / {rawcat.get("description") or rawcat.get("role")} / {Path(nraw).name} ({w}x{h} {dt}; {frame_count} frames; XML {rawcat.get("xml_coverage",0):.0%})'
                if geometry_warning:image_source+=f' | {geometry_warning}'
            else:
                image_source='Same-folder RAW rejected by known geometry mismatch: '+'; '.join(geo_reasons)
        # Priority 2: explicitly linked external MR/DICOM.
        if base is None:
            ext=self.external_images.get(str(s.no),{})
            if ext:
                for fn in ext.get('files',[]):
                    if Path(fn).suffix.lower() in ('.png','.jpg','.jpeg','.bmp','.tif','.tiff'):
                        try:
                            import matplotlib.image as mpimg; base=mpimg.imread(fn); image_source=f'Priority 2 — External MR image: {Path(fn).name}'; break
                        except Exception: pass
        plane=self.plane_combo.currentText(); plane=plane if plane in ('Axial','Sagittal','Coronal') else 'Axial'
        if base is None:
            phase=self.effective_phase(s); key=plane.lower(); rel=(f'resources/examples/dqa_phantom_{key}.png' if phase=='DQA' else f'resources/examples/treatment_t2_{key}.png'); example=resource_path(rel)
            if example.exists():
                try:
                    import matplotlib.image as mpimg; base=mpimg.imread(example)
                except Exception: base=None
            fallback=(f'EXAMPLE DQA phantom — {plane}' if phase=='DQA' else f'EXAMPLE T2 brain — {plane} — NO PATIENT MR LOADED'); image_source=(image_source+' | '+fallback) if image_source.startswith('RAW excluded:') else fallback
        if base is None:
            base=np.exp(-((xx/.78)**2+(yy/.92)**2)*2.1); image_source='Generated example image'
        ax.imshow(base,cmap='gray',origin='upper',extent=(-1,1,-1,1))
        frames=self.thermo_cache.get(str(s.no),[])
        hotspot_source='SIMULATED'
        if len(frames)>=2:
            cur=frames[min(max(1,self.thermo_slider.value()),len(frames)-1)]['image']; b0=frames[0]['image']; d=np.abs(cur-b0); d=d/(np.percentile(d,99.7)+1e-12)
            # emphasize contiguous hottest region, similar to the red thermal overlay in the treatment review display
            mask=np.ma.masked_where(d<.72,d)
            ax.imshow(mask,cmap='Reds',alpha=.82,origin='upper',extent=(-1,1,-1,1),vmin=.72,vmax=1.15); hotspot_source='RAW PHASE-DIFFERENCE CANDIDATE'
            iy,ix=np.unravel_index(np.argmax(d),d.shape); cx=-1+2*ix/max(1,d.shape[1]-1); cy=1-2*iy/max(1,d.shape[0]-1)
        else:
            scale=np.clip((s.avg_power/1100)*(s.duration/40),.03,1); cx=np.clip(s.x/100.0,-.65,.65); cy=np.clip(s.y/100.0,-.65,.65)
            if abs(cx)<.01 and abs(cy)<.01: cx=.18*math.sin(s.no*.65); cy=.14*math.cos(s.no*.51)
            hot=np.exp(-(((xx-cx)/(.11+.06*scale))**2+((yy-cy)/(.13+.07*scale))**2)*2)
            # filled red thermal region rather than a small point-like marker
            ax.contourf(xx,yy,hot,levels=[.24,.42,.62,.82,1.1],cmap='Reds',alpha=.82)
        ax.plot(cx,cy,'+',color='yellow',markersize=16,markeredgewidth=2)
        ax.text(-.97,.94,hotspot_source,va='top',ha='left',fontsize=9,fontweight='bold',bbox={'facecolor':'black','alpha':.65,'edgecolor':'none'},color='white')
        ax.set_title(f'{image_source}\nSonication {s.no} | {self.effective_phase(s)} | {plane} | Frequency {self.freq_combo.currentText()}'); ax.set_xticks([]); ax.set_yticks([])
        # Thermometry trend from real candidate frames.
        if len(frames)>=2:
            base0=frames[0]['image']; vals=[]; avgs=[]
            for fr in frames:
                dif=np.abs(fr['image']-base0); vals.append(float(np.percentile(dif,99.5))); avgs.append(float(np.mean(dif)))
            vals=np.asarray(vals); avgs=np.asarray(avgs); vals/=np.max(vals)+1e-12; avgs/=np.max(vals)+1e-12
            tt=np.linspace(0,max(s.duration,len(frames)*3.7),len(frames)); axt.plot(tt,vals,label='Peak phase-difference'); axt.plot(tt,avgs,label='Mean phase-difference'); axt.legend(fontsize=7)
            axt.set_title('Thermometry trend candidate')
        else:
            axt.text(.5,.5,'Thermometry sequence unavailable',ha='center',va='center',transform=axt.transAxes); axt.set_title('Thermometry')
        axt.set_xlabel('Mapped time (s)'); axt.set_ylabel('Relative'); axt.grid(True,alpha=.2)
        # Spectrum from selected hydrophone channels.
        msg,dec=self.decoded_hydrophones(s)
        if dec:
            specs=channel_spectra_from_streams(dec['channels']); idx=self.selected_channel_indices(self.spec_checks,len(specs))
            for i in idx:
                fx,sy=specs[i]
                if fx is not None: axs.plot(fx,sy,label=f'Ch {i+1}')
            axs.legend(fontsize=7,ncol=2); axs.set_title('Acoustic Spectrum — selected channels')
        else:
            axs.text(.5,.5,'Spectrum unavailable',ha='center',va='center',transform=axs.transAxes); axs.set_title('Acoustic Spectrum')
        axs.set_xlabel('Relative frequency'); axs.set_ylabel('Amplitude'); axs.grid(True,alpha=.2)
        # Acoustic activity resembles the treatment screen but remains review-only.
        if dec:
            duration=max(s.duration,.001); t=np.linspace(0,duration,dec['channels'].shape[1]); idx=self.selected_channel_indices(self.hp_checks,dec['channels'].shape[0])
            for i in idx:
                x=dec['channels'][i]-np.median(dec['channels'][i]); env=np.convolve(np.abs(x),np.ones(31)/31,mode='same'); env/=np.percentile(env,99)+1e-12; axa.plot(t,env,label=f'Ch {i+1}')
            axa.legend(fontsize=7,ncol=2); axa.set_title('Acoustic activity')
        else:
            axa.text(.5,.5,'Activity unavailable',ha='center',va='center',transform=axa.transAxes); axa.set_title('Acoustic activity')
        axa.set_xlabel('Mapped time (s)'); axa.set_ylabel('Relative'); axa.grid(True,alpha=.2)
        f.suptitle('Integrated MR / thermal hotspot / thermometry / acoustic review — research use only',fontsize=11)
        self.imgplot.draw()

    def spectrum_message_for_sonication(self,s):
        # Prefer a file physically stored under SonicationN. Fall back to numeric filename match.
        pat=re.compile(rf'(^|[\\/])sonication[_ ]?{s.no}([\\/]|$)',re.I)
        direct=[n for n in self.spectrum_msg_files if pat.search(n)]
        if direct:return direct[0]
        numbered=[n for n in self.spectrum_msg_files if re.search(rf'spectrummsg[-_ ]?{s.no}(?:\D|$)',Path(n).name,re.I)]
        return numbered[0] if numbered else None

    def decoded_hydrophones(self,s):
        """Decode the exact SpectrumMsg record structure first; use no guessed stream decoder."""
        n=self.spectrum_message_for_sonication(s)
        if not n:return None,None
        key=('exact-spectrum',n)
        if key not in self.spec_cache:
            try:
                self.spec_cache[key]=parse_spectrum_bytes(self.zf.read(n), n)
            except Exception as exc:
                self.spec_cache[key]=exc
        dump=self.spec_cache[key]
        if isinstance(dump,Exception):return n,None
        return n,dump

    def legacy_decoded_hydrophones(self,s):
        """Retain the RC1.7 candidate decoder as a compatibility fallback."""
        n=self.spectrum_message_for_sonication(s)
        if not n:return None,None
        key=('legacy-channels',n)
        if key not in self.spec_cache:
            try:self.spec_cache[key]=decode_spectrum_channels(self.zf.read(n))
            except Exception:self.spec_cache[key]=None
        return n,self.spec_cache[key]

    def _legacy_selected_channel_indices(self, checks, count):
        idx=[i for i,cb in enumerate(checks[:count]) if cb.isChecked()]
        return idx or list(range(min(count,4)))

    def _spectrum_selected_channels(self,dump, checks):
        enabled=[i for i,c in enumerate(checks) if c.isChecked() and i<dump.channel_count]
        return enabled or list(range(min(dump.channel_count,8)))

    def _valid_frame_indices(self,ch, duration=None):
        idx=np.where(ch.valid_mask)[0]
        if duration is not None and duration>0:
            idx=idx[idx*ch.frame_interval_s<=duration]
        return idx

    def _mean_spectrum(self,ch,idx):
        if idx.size==0:return None
        y=np.nanmean(np.abs(ch.spectra[idx].astype(float)),axis=0)
        return np.nan_to_num(y,nan=0.0,posinf=0.0,neginf=0.0)

    def draw_cavitation(self,s):
        f=self.cavplot.fig; f.clear()
        n,dump=self.decoded_hydrophones(s)
        if dump is None:
            legacy_name,dec=self.legacy_decoded_hydrophones(s)
            if not dec:
                ax=f.add_subplot(111); ax.text(.5,.5,'No decodable time-resolved SpectrumMsg payload for this sonication',ha='center',va='center',transform=ax.transAxes)
                ax.set_title('Hydrophone acoustic analysis unavailable'); ax.axis('off'); self.cav_range_label.setText('No real payload was decoded. No simulated trace is displayed.'); self.cavplot.draw(); return
            streams=dec['channels']; duration=max(float(s.duration),.001); selected=self._legacy_selected_channel_indices(self.hp_checks,streams.shape[0])
            show_metrics=self.cav_metrics_toggle.isChecked(); rows=3 if show_metrics else 2
            ax=f.add_subplot(rows,1,1); t=np.linspace(0,duration,streams.shape[1]); metrics=[]
            for i in selected:
                x=streams[i]; centered=x-np.median(x); win=max(3,min(101,len(x)//80*2+1)); kernel=np.ones(win)/win
                env=np.convolve(np.abs(centered),kernel,mode='same'); env=env/(np.percentile(env,99)+1e-12)
                ax.plot(t,env,label=f'Ch {i+1}')
                rms=float(np.sqrt(np.mean(centered**2))); peak=float(np.max(np.abs(centered))); crest=peak/(rms+1e-12); impulse=float(np.mean(np.abs(centered)>3*(np.std(centered)+1e-12)))
                metrics.append((i,rms,crest,impulse))
            ax.set_title(f'Compatibility acoustic activity — {Path(legacy_name).name}'); ax.set_xlabel('Mapped sonication time (s)'); ax.set_ylabel('Relative activity'); ax.legend(ncol=4,fontsize=7); ax.grid(True,alpha=.25)
            axfft=f.add_subplot(rows,1,2)
            if self.cav_selected_range:
                a,b=self.cav_selected_range; lo=max(0,min(a,b)); hi=min(duration,max(a,b)); mask=(t>=lo)&(t<=hi)
                for i in selected:
                    x=np.asarray(streams[i])[mask]
                    if x.size<16:continue
                    x=x-np.mean(x); y=np.abs(np.fft.rfft(x*np.hanning(len(x)))); y=y/(np.max(y)+1e-12)
                    axfft.plot(np.linspace(0,1,len(y)),y,label=f'Ch {i+1}')
                axfft.set_title(f'Compatibility FFT of selected interval {lo:.2f}–{hi:.2f} s')
                self.cav_range_label.setText(f'Compatibility decoder selected interval: {lo:.2f}–{hi:.2f} s. Physical time/frequency calibration is unverified.')
            else:
                axfft.text(.5,.5,'Drag across the upper chart to calculate interval FFT',ha='center',va='center',transform=axfft.transAxes); axfft.set_title('Selected-range FFT')
            axfft.set_xlabel('Relative frequency'); axfft.set_ylabel('Normalized amplitude'); axfft.grid(True,alpha=.25)
            if axfft.lines:axfft.legend(ncol=4,fontsize=7)
            if show_metrics:
                axm=f.add_subplot(rows,1,3); ind=np.arange(len(metrics)); width=.25
                rms=np.array([m[1] for m in metrics]); rms/=np.max(rms)+1e-12; crest=np.array([m[2] for m in metrics]); crest/=np.max(crest)+1e-12; impulse=np.array([m[3] for m in metrics]); impulse/=np.max(impulse)+1e-12
                axm.bar(ind-width,rms,width,label='RMS activity'); axm.bar(ind,crest,width,label='Crest factor'); axm.bar(ind+width,impulse,width,label='Impulsive fraction')
                axm.set_xticks(ind,[f'Ch {m[0]+1}' for m in metrics]); axm.set_ylim(0,1.15); axm.legend(ncol=3,fontsize=8); axm.grid(True,axis='y',alpha=.2)
            f.suptitle('Compatibility fallback: legacy real-payload candidate decoder — not simulated')
            f.tight_layout(); self.cavplot.draw(); return
        selected=self._spectrum_selected_channels(dump,self.hp_checks)
        show_metrics=self.cav_metrics_toggle.isChecked(); rows=3 if show_metrics else 2
        ax=f.add_subplot(rows,1,1)
        timeline=[]
        center=float(s.freq)*1e6
        for i in selected:
            ch=dump.channels[i]; idx=self._valid_frame_indices(ch,float(s.duration))
            if idx.size==0:continue
            times=idx*ch.frame_interval_s
            broad=[]; sub=[]; fund=[]
            for k in idx:
                m=analyze_frame(ch,int(k),center)
                broad.append(m.broadband_energy); sub.append(m.subharmonic_energy); fund.append(m.fundamental_energy)
            broad=np.asarray(broad,float); broad/=np.nanpercentile(broad,99)+1e-12
            ax.plot(times,broad,label=f'Ch {i+1} broadband activity')
            timeline.append((i,ch,idx,times,np.asarray(fund),np.asarray(sub),broad))
        ax.set_title(f'Time-resolved acoustic spectrum metrics — {Path(n).name}')
        ax.set_xlabel('Spectrum frame time from header (s)'); ax.set_ylabel('Relative broadband energy'); ax.grid(True,alpha=.25); ax.legend(ncol=2,fontsize=7)
        axfft=f.add_subplot(rows,1,2)
        if self.cav_selected_range:
            lo,hi=sorted(self.cav_selected_range)
            for i,ch,idx,times,_,_,_ in timeline:
                use=idx[(times>=lo)&(times<=hi)]
                y=self._mean_spectrum(ch,use)
                if y is None:continue
                freq=frequency_axis_hz(ch,center)/1e6
                y/=np.max(y)+1e-12
                axfft.plot(freq,y,label=f'Ch {i+1}')
            axfft.set_title(f'Average acoustic spectrum for selected interval {lo:.3f}–{hi:.3f} s')
            self.cav_range_label.setText(f'Selected {lo:.3f}–{hi:.3f} s. The lower graph averages the actual FFT frames in this interval.')
        else:
            axfft.text(.5,.5,'Drag across the upper chart to average the FFT frames in that interval',ha='center',va='center',transform=axfft.transAxes)
            axfft.set_title('Selected-range acoustic spectrum')
        axfft.set_xlabel('Frequency (MHz)'); axfft.set_ylabel('Normalized amplitude'); axfft.grid(True,alpha=.25)
        if axfft.lines:axfft.legend(ncol=4,fontsize=7)
        if show_metrics:
            axm=f.add_subplot(rows,1,3); labels=[]; vals=[]
            for i,ch,idx,_,_,_,_ in timeline:
                ms=[analyze_frame(ch,int(k),center) for k in idx]
                labels.append(f'Ch {i+1}')
                vals.append([np.mean([m.fundamental_energy for m in ms]),np.mean([m.subharmonic_energy for m in ms]),np.mean([m.broadband_energy for m in ms])])
            if vals:
                a=np.asarray(vals,float); a=a/(np.max(a,axis=0,keepdims=True)+1e-12); x=np.arange(len(labels)); w=.25
                axm.bar(x-w,a[:,0],w,label='Fundamental'); axm.bar(x,a[:,1],w,label='Subharmonic'); axm.bar(x+w,a[:,2],w,label='Broadband')
                axm.set_xticks(x,labels); axm.set_ylim(0,1.15); axm.legend(ncol=3); axm.grid(True,axis='y',alpha=.2)
                axm.set_ylabel('Relative channel comparison')
        dt=dump.channels[0].frame_interval_s; bins=dump.channels[0].bin_count; spacing=dump.channels[0].bin_spacing_hz
        f.suptitle(f'Exact SpectrumMsg structure: {dump.channel_count} hydrophones, {bins} bins, {spacing/1000:.3f} kHz/bin, header interval {dt*1000:.3f} ms\nCandidate cavitation metrics — not a clinical Stable/Inertial classification')
        def onselect(xmin,xmax):
            self.cav_selected_range=(float(xmin),float(xmax)); self.draw_cavitation(s)
        self.cav_span=SpanSelector(ax,onselect,'horizontal',useblit=True,props=dict(alpha=.25,facecolor='tab:blue'),interactive=True,drag_from_anywhere=True)
        self.cavplot.remember_initial_view(force=True); self.cavplot.draw()

    def nearest_spectrum(self,s):
        target=time_seconds(s.time); a=[(abs(spectrum_time(n)-target),n) for n in self.spectrum_files if spectrum_time(n) is not None]
        return min(a)[1] if a else None

    def draw_spectrum(self,s):
        f=self.specplot.fig; f.clear()
        interval=self.spec_interval.currentText(); ymode=self.spec_y.currentText(); mode=self.spec_display.currentText()
        n,dump=self.decoded_hydrophones(s)
        if dump is None:
            legacy_name,dec=self.legacy_decoded_hydrophones(s)
            spectra=[]; source=''; note=''
            if dec:
                spectra=channel_spectra_from_streams(dec['channels']); source=legacy_name
                note=f'Compatibility fallback decoded {dec["count"]} candidate channels from {Path(source).name}. Channel identity, time interval and physical frequency scale are unverified.'
            else:
                legacy_fft=self.nearest_spectrum(s); x=y=None
                if legacy_fft:
                    key=('legacy-fft',legacy_fft)
                    if key not in self.spec_cache:
                        try:self.spec_cache[key]=decode_spectrum(self.zf.read(legacy_fft))
                        except Exception:self.spec_cache[key]=(None,None)
                    x,y=self.spec_cache[key]
                if x is not None:
                    spectra=[(x,y)]; source=legacy_fft; note=f'Legacy matched FFT payload: {Path(source).name}. Hydrophone identity and physical frequency calibration are unverified.'
            valid=[z for z in spectra if z[0] is not None]
            if not valid:
                ax=f.add_subplot(111); ax.text(.5,.5,'No decodable acoustic spectrum payload',ha='center',va='center',transform=ax.transAxes); ax.axis('off')
                self.spec_note.setText('Exact parser and compatibility fallback found no real spectrum payload. No simulated spectrum is displayed.'); self.specplot.remember_initial_view(force=True); self.specplot.draw(); return
            idx=self._legacy_selected_channel_indices(self.spec_checks,len(valid)) if dec else list(range(len(valid)))
            valid=[valid[i] for i in idx]; labels=[i+1 for i in idx]
            def legacy_conv(y):
                y=np.maximum(np.asarray(y,float),1e-12); return 20*np.log10(y/np.max(y)) if ymode=='dB' else y/(np.max(y)+1e-12)
            if mode=='All Separate' and len(valid)>1:
                cols=2; rows=int(math.ceil(len(valid)/cols))
                for j,(x,y) in enumerate(valid):
                    ax=f.add_subplot(rows,cols,j+1); ax.plot(x,legacy_conv(y)); ax.set_title(f'Ch {labels[j]}'); ax.set_xlabel('Relative frequency'); ax.grid(True,alpha=.2)
            elif mode=='Channel Heatmap' and len(valid)>1:
                ax=f.add_subplot(111); nmin=min(len(y) for _,y in valid); mat=np.vstack([legacy_conv(y[:nmin]) for _,y in valid]);
                im=ax.imshow(mat,aspect='auto',origin='lower',extent=(0,1,.5,len(valid)+.5),cmap='viridis'); f.colorbar(im,ax=ax,label='dB' if ymode=='dB' else 'Normalized amplitude')
                ax.set_yticks(range(1,len(valid)+1),[f'Ch {i}' for i in labels]); ax.set_xlabel('Relative frequency'); ax.set_title('Compatibility channel heatmap')
            elif mode=='Relative Cavitation Bands':
                ax=f.add_subplot(111); bands=[(.02,.20,'Low'),(.20,.55,'Mid'),(.55,.98,'High / broadband')]; vals=[]
                for x,y in valid:
                    xx=np.asarray(x,float); yy=np.asarray(y,float); vals.append([float(np.trapezoid(yy[(xx>=a)&(xx<b)],xx[(xx>=a)&(xx<b)])) if np.any((xx>=a)&(xx<b)) else 0 for a,b,_ in bands])
                mat=np.asarray(vals); mat/=np.max(mat,axis=0,keepdims=True)+1e-12; ind=np.arange(len(valid)); width=.24
                for j,(_,_,label) in enumerate(bands):ax.bar(ind+(j-1)*width,mat[:,j],width,label=label)
                ax.set_xticks(ind,[f'Ch {i}' for i in labels]); ax.set_ylim(0,1.15); ax.legend(); ax.grid(True,axis='y',alpha=.2); ax.set_title('Compatibility relative spectral-band comparison')
            else:
                ax=f.add_subplot(111)
                if mode=='Average' and len(valid)>1:
                    nmin=min(len(y) for _,y in valid); x=valid[0][0][:nmin]; y=np.mean(np.vstack([z[1][:nmin] for z in valid]),axis=0); ax.plot(x,legacy_conv(y),label='Average')
                elif mode=='Maximum Envelope' and len(valid)>1:
                    nmin=min(len(y) for _,y in valid); x=valid[0][0][:nmin]; y=np.max(np.vstack([z[1][:nmin] for z in valid]),axis=0); ax.plot(x,legacy_conv(y),label='Maximum envelope')
                elif mode=='Single':
                    ax.plot(valid[0][0],legacy_conv(valid[0][1]),label=f'Ch {labels[0]}')
                else:
                    for j,(x,y) in enumerate(valid):ax.plot(x,legacy_conv(y),label=f'Ch {labels[j]}')
                ax.set_xlabel('Relative frequency'); ax.set_ylabel('dB re max' if ymode=='dB' else 'Normalized amplitude'); ax.grid(True,alpha=.25); ax.legend(ncol=2,fontsize=8); ax.set_title(f'{interval} | {mode} | compatibility source')
            self.spec_note.setText(note); f.tight_layout(); self.specplot.remember_initial_view(force=True); self.specplot.draw(); return
        selected=self._spectrum_selected_channels(dump,self.spec_checks); center=float(s.freq)*1e6
        series=[]
        for i in selected:
            ch=dump.channels[i]; idx=self._valid_frame_indices(ch,float(s.duration)); y=self._mean_spectrum(ch,idx)
            if y is not None:series.append((i,ch,idx,y))
        if not series:
            ax=f.add_subplot(111); ax.text(.5,.5,'No valid FFT frames in selected interval',ha='center',va='center',transform=ax.transAxes); self.specplot.remember_initial_view(force=True); self.specplot.draw(); return
        def conv(y):
            y=np.maximum(np.asarray(y,float),1e-30)
            return 20*np.log10(y/np.max(y)) if ymode=='dB' else y/(np.max(y)+1e-30)
        if mode=='Channel Heatmap':
            ax=f.add_subplot(111); mat=np.vstack([conv(y) for _,_,_,y in series]); ch0=series[0][1]; freq=frequency_axis_hz(ch0,center)/1e6
            im=ax.imshow(mat,aspect='auto',origin='lower',extent=(freq[0],freq[-1],.5,len(series)+.5),cmap='viridis'); f.colorbar(im,ax=ax,label='dB' if ymode=='dB' else 'Normalized amplitude')
            ax.set_yticks(range(1,len(series)+1),[f'Ch {i+1}' for i,_,_,_ in series]); ax.set_xlabel('Frequency (MHz)'); ax.set_title('Hydrophone average-spectrum heatmap')
        elif mode=='Spectrogram':
            i,ch,idx,_=series[0]; ax=f.add_subplot(111); mat=np.abs(ch.spectra[idx].astype(float)); mat=np.where(np.isfinite(mat),mat,0); mat=20*np.log10(mat/(np.max(mat)+1e-30)+1e-12)
            freq=frequency_axis_hz(ch,center)/1e6; times=idx*ch.frame_interval_s
            im=ax.imshow(mat.T,aspect='auto',origin='lower',extent=(times[0],times[-1],freq[0],freq[-1]),cmap='viridis',vmin=-60,vmax=0); f.colorbar(im,ax=ax,label='dB re max')
            ax.set_xlabel('Time from SpectrumMsg header (s)'); ax.set_ylabel('Frequency (MHz)'); ax.set_title(f'Ch {i+1} time-frequency spectrum')
        elif mode=='Relative Cavitation Bands':
            ax=f.add_subplot(111); bands=[(.02,.20,'Low'),(.20,.55,'Mid'),(.55,.98,'High / broadband')]; vals=[]
            for i,ch,idx,y in series:
                yy=np.asarray(y,float); xx=np.linspace(0,1,len(yy)); vals.append([float(np.trapezoid(yy[(xx>=a)&(xx<b)],xx[(xx>=a)&(xx<b)])) if np.any((xx>=a)&(xx<b)) else 0 for a,b,_ in bands])
            a=np.asarray(vals,float); a/=np.max(a,axis=0,keepdims=True)+1e-12; x=np.arange(len(series)); w=.24
            for j,(_,_,label) in enumerate(bands):ax.bar(x+(j-1)*w,a[:,j],w,label=label)
            ax.set_xticks(x,[f'Ch {i+1}' for i,_,_,_ in series]); ax.set_ylim(0,1.15); ax.legend(); ax.grid(True,axis='y',alpha=.2); ax.set_ylabel('Relative integrated energy'); ax.set_title('Relative spectral-band comparison — compatibility view')
        elif mode=='Cavitation Metrics':
            ax=f.add_subplot(111); labels=[]; vals=[]
            for i,ch,idx,_ in series:
                ms=[analyze_frame(ch,int(k),center) for k in idx]
                labels.append(f'Ch {i+1}'); vals.append([np.mean([m.fundamental_energy for m in ms]),np.mean([m.subharmonic_energy for m in ms]),np.mean([m.broadband_energy for m in ms])])
            a=np.asarray(vals,float); a=a/(np.max(a,axis=0,keepdims=True)+1e-12); x=np.arange(len(labels)); w=.25
            ax.bar(x-w,a[:,0],w,label='Fundamental'); ax.bar(x,a[:,1],w,label='Subharmonic'); ax.bar(x+w,a[:,2],w,label='Broadband'); ax.set_xticks(x,labels); ax.set_ylim(0,1.15); ax.legend(); ax.grid(True,axis='y',alpha=.2); ax.set_ylabel('Relative energy')
            ax.set_title('Hydrophone cavitation-related spectral metrics (candidate)')
        elif mode=='Frame Metrics Timeline':
            ax=f.add_subplot(111)
            for i,ch,idx,_ in series:
                ms=[analyze_frame(ch,int(k),center) for k in idx]; t=idx*ch.frame_interval_s; b=np.asarray([m.broadband_energy for m in ms]); b/=np.percentile(b,99)+1e-12
                ax.plot(t,b,label=f'Ch {i+1}')
            ax.set_xlabel('Time (s)'); ax.set_ylabel('Relative broadband energy'); ax.set_title('Frame-by-frame broadband activity'); ax.legend(ncol=4,fontsize=7); ax.grid(True,alpha=.25)
        elif mode=='All Separate' and len(series)>1:
            cols=2; rows=int(math.ceil(len(series)/cols))
            for j,(i,ch,idx,y) in enumerate(series):
                ax=f.add_subplot(rows,cols,j+1); ax.plot(frequency_axis_hz(ch,center)/1e6,conv(y)); ax.set_title(f'Ch {i+1}'); ax.set_xlabel('MHz'); ax.grid(True,alpha=.2)
        else:
            ax=f.add_subplot(111)
            if mode=='Single': use=[series[0]]
            elif mode=='Average':
                i,ch,idx,y=series[0]; use=[(-1,ch,idx,np.mean(np.vstack([z[3] for z in series]),axis=0))]
            elif mode=='Maximum Envelope':
                i,ch,idx,y=series[0]; use=[(-2,ch,idx,np.max(np.vstack([z[3] for z in series]),axis=0))]
            else:use=series
            for i,ch,idx,y in use:
                label='Average' if i==-1 else ('Maximum envelope' if i==-2 else f'Ch {i+1}')
                ax.plot(frequency_axis_hz(ch,center)/1e6,conv(y),label=label)
            ax.set_xlabel('Frequency (MHz)'); ax.set_ylabel('dB re max' if ymode=='dB' else 'Normalized amplitude'); ax.grid(True,alpha=.25); ax.legend(ncol=4,fontsize=8); ax.set_title(f'{interval} | {mode} | {Path(n).name}')
        ch=dump.channels[0]
        self.spec_note.setText(f'Exact parser: {dump.message_count} messages, {dump.channel_count} hydrophones, {ch.bin_count} FFT bins, {ch.bin_spacing_hz:.1f} Hz/bin, ±{ch.half_span_hz/1000:.1f} kHz span, {ch.frame_interval_s*1000:.3f} ms header interval. Frequency axis is centered on the Sonication frequency ({s.freq:.3f} MHz). Fundamental/subharmonic/broadband metrics are exploratory and not a clinical diagnosis.')
        self.specplot.remember_initial_view(force=True); self.specplot.draw()

    def draw_timeline(self):
        f=self.timeline.fig; f.clear(); ax=f.add_subplot(111)
        sonics=self.sonics if self.show_dqa.isChecked() else [s for s in self.sonics if self.effective_phase(s)=='Treatment']
        if sonics:
            if self.show_dqa.isChecked():
                for s in sonics:
                    phase=self.effective_phase(s); y=1 if phase=='Treatment' else 0
                    ax.barh(y,max(s.duration,.2),left=time_seconds(s.time),height=.35,alpha=.65)
                    ax.text(time_seconds(s.time)+max(s.duration,.2)/2,y,str(s.no),ha='center',va='center',fontsize=8)
                ax.set_yticks([0,1],['DQA','Treatment'])
                title='DQA and Treatment Sonication Timeline'
            else:
                for s in sonics:
                    ax.barh(0,max(s.duration,.2),left=time_seconds(s.time),height=.42,alpha=.7)
                    ax.text(time_seconds(s.time)+max(s.duration,.2)/2,0,str(s.no),ha='center',va='center',fontsize=8)
                ax.set_yticks([0],['Treatment'])
                title='Treatment Sonication Timeline'
            ax.xaxis.set_major_formatter(FuncFormatter(clock_formatter))
            ax.set_xlabel('Session time')
            ax.set_title(title); ax.grid(True,axis='x',alpha=.25)
        else:
            ax.text(.5,.5,'No Treatment Sonications',ha='center',va='center',transform=ax.transAxes)
            ax.set_axis_off()
        self.timeline.remember_initial_view(force=True); self.timeline.draw_idle()

    def _all_raw_series_groups(self):
        rows=[]
        for son_no,groups in self.raw_series_catalog.items():
            for group in groups:
                item=dict(group)
                item['_sonication']=int(son_no) if str(son_no).isdigit() else -1
                rows.append(item)
        return rows

    def _mr_group_match_score(self,m,group):
        score=0.0; reasons=[]
        ms=str(m.series_no or '').strip()
        gs=str(group.get('series_no') or '').strip()
        if ms and gs:
            if ms==gs:score+=100; reasons.append('Series number matched')
            else:score-=60; reasons.append(f'Series number mismatch {gs}')
        md=' '.join((m.description,m.protocol)).upper()
        gd=' '.join((str(group.get('description','')),str(group.get('protocol','')))).upper()
        for token in ('TMAP','MEMP','CALIB','TRACKING','T2','AXIAL','SAG','COR'):
            if token in md and token in gd:
                score+=25; reasons.append(f'{token} description matched')
        if m.role=='Thermometry Compound Series' and group.get('thermometry'):
            score+=65; reasons.append('Thermometry role matched')
        if m.role=='XD Position / Motion Detection' and group.get('classification')=='XD Position / Motion Detection':
            score+=65; reasons.append('Tracking role matched')
        if m.plane!='Unknown' and group.get('plane')==m.plane:
            score+=15; reasons.append('Plane matched')
        if m.freq_dir!='Unknown' and normalize_freq(group.get('freq'))==normalize_freq(m.freq_dir):
            score+=10; reasons.append('Frequency direction matched')
        if m.coil and group.get('coil') and m.coil.lower() in str(group.get('coil')).lower():
            score+=15; reasons.append('Coil matched')
        score+=min(len(group.get('paths',[])),40)*.25
        return score,reasons

    def raw_groups_for_mr_series(self,m):
        candidates=[]
        for group in self._all_raw_series_groups():
            score,reasons=self._mr_group_match_score(m,group)
            if score>0:
                item=dict(group); item['_match_score']=score; item['_match_reasons']=reasons
                candidates.append(item)
        candidates.sort(key=lambda x:(x.get('_match_score',0),len(x.get('paths',[]))),reverse=True)
        # Strong exact matches only. If no Series Number exists, allow a high
        # description/protocol/role match as an explicit fallback.
        exact=[g for g in candidates if m.series_no and str(g.get('series_no') or '')==str(m.series_no)]
        if exact:return exact
        return [g for g in candidates if g.get('_match_score',0)>=65]

    def mr_series_selected(self,row,column,previous_row=-1,previous_column=-1):
        if self._updating or not (0<=row<len(self.mr_series)):return
        m=self.mr_series[row]
        self.selected_mr_series_groups=self.raw_groups_for_mr_series(m)
        self.mr_component_combo.blockSignals(True); self.mr_component_combo.clear()
        for idx,g in enumerate(self.selected_mr_series_groups):
            label=(f'{g.get("component") or g.get("role")} | '
                   f'Sonication {g.get("_sonication")} | Field {g.get("field")} / Zone {g.get("zone")} | '
                   f'{len(g.get("paths",[]))} images')
            self.mr_component_combo.addItem(label,idx)
        self.mr_component_combo.blockSignals(False)
        if self.selected_mr_series_groups:
            self.mr_component_combo.setCurrentIndex(0)
            self.mr_component_changed(0)
        else:
            self.mr_frame_slider.setRange(0,0)
            self.mr_frame_label.setText('No matched image')
            self.mr_series_note.setText(
                f'Series {m.series_no or "Unknown"} — {m.description or m.protocol}. '
                'No RAW group passed the Series Number / Description / Protocol matching rules. '
                'The Series remains listed, but an unrelated image is not substituted.'
            )
            f=self.mrseries_plot.fig; f.clear(); ax=f.add_subplot(111)
            ax.text(.5,.5,'No treatment-linked image group matched this MR Series',ha='center',va='center',transform=ax.transAxes)
            ax.set_axis_off(); self.mrseries_plot.draw_idle()

    def mr_component_changed(self,index):
        if not (0<=index<len(self.selected_mr_series_groups)):return
        g=self.selected_mr_series_groups[index]
        count=len(g.get('paths',[]))
        self.mr_frame_slider.blockSignals(True); self.mr_frame_slider.setRange(0,max(0,count-1)); self.mr_frame_slider.setValue(0); self.mr_frame_slider.blockSignals(False)
        self.draw_selected_mr_series()

    def draw_selected_mr_series(self,*args):
        row=self.mrtable.currentRow()
        if not (0<=row<len(self.mr_series)):return
        m=self.mr_series[row]
        ci=self.mr_component_combo.currentData()
        if not isinstance(ci,int) or not (0<=ci<len(self.selected_mr_series_groups)):return
        g=self.selected_mr_series_groups[ci]
        paths=g.get('paths',[])
        if not paths:return
        frame=max(0,min(self.mr_frame_slider.value(),len(paths)-1))
        path=paths[frame]
        f=self.mrseries_plot.fig; f.clear(); ax=f.add_subplot(111)
        try:
            decoded=try_render_raw(self.zf.read(path))
            if not decoded:raise ValueError('RAW image decoder found no valid 2-D matrix')
            score,dt,w,h,img=decoded
            ax.imshow(img,cmap='gray',origin='upper')
            ax.set_xticks([]); ax.set_yticks([])
            component=g.get('component') or g.get('role') or 'MR image'
            ax.set_title(f'Series {m.series_no or "Unknown"} — {m.description or m.protocol}\n{component} | frame {frame+1}/{len(paths)}')
            self.mr_frame_label.setText(f'{frame+1} / {len(paths)}')
            reasons='; '.join(g.get('_match_reasons',[]))
            self.mr_series_note.setText(
                f'Acquisition order: Series {m.series_no or "Unknown"} | Role: {m.role} | '
                f'Protocol/Description: {m.protocol or "—"} / {m.description or "—"} | '
                f'RAW source: Sonication {g.get("_sonication")} / Field {g.get("field")} / Zone {g.get("zone")} | '
                f'Component: {component} | Matrix: {w}×{h} {dt} | '
                f'Match score: {g.get("_match_score",0):.1f} | Evidence: {reasons or "Description/role fallback"}'
            )
        except Exception as exc:
            ax.text(.5,.5,str(exc),ha='center',va='center',transform=ax.transAxes)
            ax.set_axis_off()
            self.mr_frame_label.setText('Decode failed')
        self.mrseries_plot.remember_initial_view(force=True); self.mrseries_plot.draw_idle()

    def show_mr_table(self):
        self.mr_series.sort(key=lambda m:(_series_sort_key(m.series_no),time_seconds(m.time)))
        self.mrtable.blockSignals(True); self.mrtable.setRowCount(len(self.mr_series))
        for r,m in enumerate(self.mr_series):
            groups=self.raw_groups_for_mr_series(m)
            image_count=sum(len(g.get('paths',[])) for g in groups)
            components=[]
            for g in groups:
                value=g.get('component') or g.get('role')
                if value and value not in components:components.append(value)
            if m.role=='Thermometry Compound Series' and not components:
                components=['Magnitude','Phase','Temperature calculation/display (not yet matched)']
            m.component_summary='; '.join(components)
            m.matched_raw_count=image_count
            vals=[m.series_no,m.time,m.description,m.role,m.component_summary,image_count,m.plane,m.freq_dir,m.image_mode,m.pulse_sequence,m.psd_name,m.coil,m.fov,m.thickness,m.slices,m.matrix,m.source_file]
            for c,v in enumerate(vals):
                item=QTableWidgetItem(str(v)); item.setToolTip(str(v))
                self.mrtable.setItem(r,c,item)
        self.mrtable.blockSignals(False)
        if self.mr_series:
            self.mrtable.selectRow(0); self.mr_series_selected(0,0)

    def show_exam_explorer(self):
        a=self.exam_anchor
        summary=[
            '<h2>Treatment Exam Resolver</h2>',
            '<p>Only data linked to the treatment Exam are passed to Replay and analysis. Other Exam/Study data remain visible here only as excluded evidence.</p>',
            '<table cellpadding="5" border="1">',
            f'<tr><td><b>Exam UID</b></td><td>{a.exam_uid or "Unavailable"}</td></tr>',
            f'<tr><td><b>Exam number</b></td><td>{a.exam_number or "Unavailable"}</td></tr>',
            f'<tr><td><b>Treatment date/time</b></td><td>{a.treat_date or "Unavailable"} {a.treat_time or ""}</td></tr>',
            f'<tr><td><b>Treatment series numbers</b></td><td>{", ".join(sorted(a.series_numbers)) or "Unavailable"}</td></tr>',
            f'<tr><td><b>Thermometry protocols</b></td><td>{", ".join(sorted(a.protocols)) or "Unavailable"}</td></tr>',
            f'<tr><td><b>Included review acquisitions</b></td><td>{len(self.mr_series)} / {len(self.all_mr_series)}</td></tr>',
            '</table>'
        ]
        self.exam_summary.setHtml(''.join(summary))
        rows=[]
        for m in self.all_mr_series:
            rows.append((m.exam_status,f'{m.source_file} / {m.time}', 'review.out acquisition',f'{m.date} {m.time}',m.series_no,m.description or m.protocol,m.exam_score,'; '.join(m.exam_reasons)))
        # Deduplicate source decisions by path/category/status.
        seen=set()
        for d in self.source_decisions:
            key=(d.source,d.category,d.status)
            if key in seen:continue
            seen.add(key); rows.append((d.status,d.source,d.category,'','', '',d.score,'; '.join(d.reasons)))
        order={'Included':0,'Review':1,'Excluded':2,'Unresolved':3}
        rows.sort(key=lambda x:(order.get(x[0],9),-float(x[6] or 0),str(x[1])))
        self.exam_table.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for c,v in enumerate(row):self.exam_table.setItem(r,c,QTableWidgetItem(f'{v:.1f}' if c==6 and isinstance(v,(int,float)) else str(v)))

    def show_evidence(self):
        lines=['TREATMENT-EXAM FILTERED MR SERVER EVIDENCE','='*80]
        lines += self.mrserver_events[:10000]
        if not self.mrserver_events: lines.append('No mrserver.log source passed the Treatment Exam filter. See Exam Explorer.')
        lines += ['','TREATMENT-EXAM FILTERED TIMING EVIDENCE','='*80] + self.timing_evidence[:5000]
        lines += ['',f'Excluded/unresolved mrserver events: {max(0,len(self.all_mrserver_events)-len(self.mrserver_events))}',f'Excluded/unresolved timing evidence rows: {max(0,len(self.all_timing_evidence)-len(self.timing_evidence))}']
        self.evidence.setPlainText('\n'.join(lines))

    def show_sync(self):
        offset='Not detected'; source='No explicit MR-FUS offset statement was decoded.'
        if self.ws_offsets:
            vals=[v for v,_ in self.ws_offsets]; offset=f'{np.median(vals):+.3f} s ({len(vals)} records; sign evaluated per Sonication)'; source=self.ws_offsets[0][1]
        rows=[]
        for sonic in self.sonics:
            mt=self.resolve_series_match(sonic); ms=self.mr_series[mt.series_index] if 0<=mt.series_index<len(self.mr_series) else None
            rows.append(f'<tr><td>{sonic.no}</td><td>{sonic.time}</td><td>{ms.time if ms else "-"}</td><td>{ms.description if ms else "Rejected / unavailable"}</td><td>{mt.corrected_gap:+.2f}s</td><td>{mt.offset_direction} {mt.applied_offset:+.3f}s</td><td>{mt.confidence}</td><td>{"Yes" if mt.plane_match else "No"}</td><td>{"Yes" if mt.freq_match else "No"}</td></tr>')
        html='<h2>MR-FUS Synchronization Resolver</h2>'
        html+=f'<table cellpadding="5" border="1"><tr><td><b>WS offset evidence</b></td><td>{offset}</td></tr><tr><td><b>First evidence</b></td><td>{source}</td></tr></table>'
        html+='<p><b>Priority:</b> Sonication XML geometry, TMAP/MEMP protocol, plane, frequency direction, corrected MR interval, then time proximity. Known geometry mismatch is rejected.</p>'
        html+='<table cellpadding="4" border="1"><tr><th>Son.</th><th>FUS</th><th>MR</th><th>Matched series</th><th>Gap</th><th>Offset model</th><th>Confidence</th><th>Plane</th><th>Freq</th></tr>'+''.join(rows)+'</table>'
        self.syncinfo.setHtml(html)

    def show_overview(self,s,m):
        spec=self.nearest_spectrum(s); man=self.manual.get(str(s.no),{})
        rows=[
            ('Sonication',str(s.no)),('Category',self.effective_phase(s)),('Start',s.time),('Status',s.status),('Duration',f'{s.duration:.2f} s'),
            ('Power / Avg / Max',f'{s.power:.2f} / {s.avg_power:.2f} / {s.max_power:.2f}'),('Frequency',f'{s.freq:.3f}'),
            ('Focus coordinates',f'X {s.x:.2f}, Y {s.y:.2f}, Elevation {s.elevation:.2f}, FD {s.fd:.2f}'),
            ('Scan plane',self.plane_combo.currentText()),('Frequency direction',self.freq_combo.currentText()),
            ('Spectrum match',Path(spec).name if spec else 'None'),('Reflection files',str(len(self.reflection_files))),
            ('Spectrum interval',self.spec_interval.currentText()),('Hydrophone',self.hp_combo.currentText()),('Spectrum display',self.spec_display.currentText()),('MR series source',m.description if m else 'No matched review.out series'),('External image',self.external_images.get(str(s.no),{}).get('folder','None'))]
        html='<h2>Maximum Available Information</h2><table cellpadding="5" border="1" cellspacing="0">'+''.join(f'<tr><td><b>{a}</b></td><td>{b}</td></tr>' for a,b in rows)+'</table>'
        if m:
            html += '<h3>Matched MR acquisition from review.out</h3><table cellpadding="5" border="1" cellspacing="0">'+''.join(f'<tr><td><b>{a}</b></td><td>{b}</td></tr>' for a,b in [
                ('Protocol',m.protocol),('Series description',m.description),('Plane',m.plane),('Frequency direction',m.freq_dir),('Image mode',m.image_mode),('Pulse sequence',m.pulse_sequence),('PSD',m.psd_name),('Coil',m.coil),('FOV',m.fov),('Slice thickness',m.thickness),('Slices',m.slices),('Matrix',m.matrix),('Start / End location',f'{m.start_loc} / {m.end_loc}'),('Center FOV',m.center_fov)])+'</table>'
        meta=self.son_meta.get(str(s.no),{})
        if meta:
            html += '<h3>Sonication XML metadata</h3><table cellpadding="5" border="1" cellspacing="0">'+''.join(f'<tr><td><b>{k}</b></td><td>{v}</td></tr>' for k,v in meta.items() if k!='evidence' and len(str(v))<500)+'</table><p><b>Evidence files:</b> '+', '.join(meta.get('evidence',[]))+'</p>'
        match=self.resolve_series_match(s)
        html += '<h3>Synchronization / Geometry Match</h3><table cellpadding="5" border="1">'+''.join(f'<tr><td><b>{a}</b></td><td>{b}</td></tr>' for a,b in [('Confidence',match.confidence),('Score',f'{match.score:.1f}'),('Corrected gap',f'{match.corrected_gap:+.3f} s'),('Offset model',f'{match.offset_direction} ({match.applied_offset:+.3f} s)'),('Plane match',match.plane_match),('Frequency match',match.freq_match),('Thermometry protocol',match.protocol_match),('Reasons','; '.join(match.reasons) or 'None')])+'</table>'
        if match.rejected:html += '<h4>Rejected MR candidates</h4><ul>'+''.join(f'<li>{x}</li>' for x in match.rejected)+'</ul>'
        html += '<h3>Timing model</h3><p>MR acquisition start → Pre → FUS start (0 s) → Actual duration → Post → MR acquisition end. WS clock-offset evidence is applied only when explicitly decoded.</p><p><b>Provenance:</b> Treatment parameters come from the ZIP summary. MR geometry is read from review.out when available and can be manually overridden per sonication. mrserver.log provides scanner workflow evidence. Hotspot and cavitation graphics remain simulated unless corresponding proprietary data is decoded or external images are linked.</p>'
        self.overview.setHtml(html)

    def decoder_key(self,g):
        return f'{g.get("sonication",0)}:{g.get("field",0)}:{g.get("sub",0)}:{g.get("zone",0)}:{g.get("size",0)}'

    def load_decoder_registry(self):
        self.decoder_registry={}
        path=getattr(self,'decoder_registry_path',None)
        if path and Path(path).exists():
            try:self.decoder_registry=json.loads(Path(path).read_text(encoding='utf-8'))
            except Exception:self.decoder_registry={}

    def save_decoder_registry(self):
        path=getattr(self,'decoder_registry_path',None)
        if not path:
            QMessageBox.warning(self,'Decoder Registry','Open a ZIP before saving the registry.'); return
        try:
            Path(path).write_text(json.dumps(self.decoder_registry,indent=2,ensure_ascii=False),encoding='utf-8')
            QMessageBox.information(self,'Decoder Registry',f'Saved:\n{path}')
        except Exception as e:QMessageBox.critical(self,'Decoder Registry',str(e))

    def _series_metrics(self,g):
        paths=g.get('paths',[])
        if not self.zf or not paths:return ('—','—')
        imgs=[]
        # Use representative frames only to keep selection responsive.
        indices=sorted(set([0,len(paths)//4,len(paths)//2,(3*len(paths))//4,len(paths)-1]))
        for i in indices:
            try:
                r=try_render_raw(self.zf.read(paths[i]))
                if r:imgs.append(np.asarray(r[4],dtype=np.float32))
            except Exception:pass
        if len(imgs)<2:return ('—','—')
        cors=[]; diffs=[]
        for a,b in zip(imgs[:-1],imgs[1:]):
            if a.shape!=b.shape:continue
            av=a.ravel(); bv=b.ravel()
            if np.std(av)>1e-9 and np.std(bv)>1e-9:
                cors.append(float(np.corrcoef(av,bv)[0,1]))
            scale=max(float(np.std(a)),1e-6); diffs.append(float(np.mean(np.abs(b-a))/scale))
        return (f'{np.mean(cors):.4f}' if cors else '—',f'{np.mean(diffs):.4f}' if diffs else '—')

    def show_decoder_lab(self):
        rows=[]
        for no,groups in sorted(self.sequence_catalog.items()):rows.extend(groups)
        self.decoder_primary.blockSignals(True); self.decoder_secondary.blockSignals(True)
        self.decoder_primary.clear(); self.decoder_secondary.clear(); self.decoder_secondary.addItem('None',None)
        self.decoder_table.setRowCount(len(rows))
        for r,g in enumerate(rows):
            key=self.decoder_key(g); confirmed=self.decoder_registry.get(key,{}).get('role','Unconfirmed')
            corr,var=self._series_metrics(g); g['_corr']=corr; g['_variation']=var
            matrix=g.get('matrix'); mtxt=f'{matrix[0]}x{matrix[1]}' if matrix else 'Unknown'
            vals=[g.get('sonication'),g.get('field'),g.get('sub'),g.get('zone'),g.get('role'),confirmed,g.get('confidence'),len(g.get('paths',[])),mtxt,g.get('plane','Unknown'),g.get('freq','Unknown'),corr,var]
            for c,v in enumerate(vals):self.decoder_table.setItem(r,c,QTableWidgetItem(str(v)))
            label=f'S{g["sonication"]} | F{g["field"]}-{g["sub"]}-{g["zone"]} | {confirmed if confirmed!="Unconfirmed" else g["role"]} | {len(g["paths"])} frames'
            self.decoder_primary.addItem(label,g); self.decoder_secondary.addItem(label,g)
        self.decoder_primary.blockSignals(False); self.decoder_secondary.blockSignals(False)
        if rows:self.decoder_primary.setCurrentIndex(0); self.decoder_selection_changed()
        else:self.decoder_note.setText('No Sonication RAW series were detected.')

    def decoder_table_selected(self,row,*args):
        if 0<=row<self.decoder_primary.count():self.decoder_primary.setCurrentIndex(row)

    def decoder_selection_changed(self,*args):
        g=self.decoder_primary.currentData()
        if not g:return
        n=len(g.get('paths',[])); self.decoder_slider.blockSignals(True); self.decoder_slider.setMaximum(max(0,n-1)); self.decoder_slider.setValue(min(self.decoder_slider.value(),max(0,n-1))); self.decoder_slider.blockSignals(False)
        role=self.decoder_registry.get(self.decoder_key(g),{}).get('role','Unconfirmed')
        idx=self.decoder_role.findText(role); self.decoder_role.setCurrentIndex(max(0,idx))
        self.draw_decoder_lab()

    def confirm_decoder_role(self):
        g=self.decoder_primary.currentData()
        if not g:return
        role=self.decoder_role.currentText(); key=self.decoder_key(g)
        self.decoder_registry[key]={'role':role,'confirmed_at':datetime.now().isoformat(timespec='seconds'),'source_zip':self.zip_path.name if self.zip_path else ''}
        self.show_decoder_lab()
        # restore the edited series where possible
        for i in range(self.decoder_primary.count()):
            x=self.decoder_primary.itemData(i)
            if x and self.decoder_key(x)==key:self.decoder_primary.setCurrentIndex(i); break

    def draw_decoder_lab(self,*args):
        if not self.zf:return
        a=self.decoder_primary.currentData(); b=self.decoder_secondary.currentData()
        if not a:return
        i=max(0,min(self.decoder_slider.value(),len(a.get('paths',[]))-1)); self.decoder_frame_label.setText(f'{i+1} / {len(a.get("paths",[]))}')
        f=self.decoderplot.fig; f.clear(); axes=[f.add_subplot(2,3,j+1) for j in range(6)]
        def decode(g,idx):
            if not g or not g.get('paths'):return None
            idx=max(0,min(idx,len(g['paths'])-1))
            r=try_render_raw(self.zf.read(g['paths'][idx])); return (r[4],g['paths'][idx]) if r else None
        try:
            ca=decode(a,i); ba=decode(a,0)
            if not ca:raise ValueError('Primary series cannot be decoded as a 2-D image')
            img,path=ca; base=ba[0] if ba else None
            axes[0].imshow(img,cmap='gray'); axes[0].set_title('Primary current')
            if base is not None and base.shape==img.shape:
                d=img-base; lim=max(float(np.percentile(np.abs(d),99)),1e-6); axes[1].imshow(d,cmap='coolwarm',vmin=-lim,vmax=lim); axes[1].set_title('Primary − baseline')
            else:axes[1].text(.5,.5,'Difference unavailable',ha='center',va='center')
            axes[2].hist(np.asarray(img).ravel(),bins=100); axes[2].set_title('Primary histogram')
            cb=decode(b,round(i*(len(b.get('paths',[]))-1)/max(1,len(a.get('paths',[]))-1))) if b else None
            if cb:
                img2,path2=cb; axes[3].imshow(img2,cmap='gray'); axes[3].set_title('Comparison current')
                if img2.shape==img.shape:
                    dd=img.astype(float)-img2.astype(float); lim=max(float(np.percentile(np.abs(dd),99)),1e-6); axes[4].imshow(dd,cmap='coolwarm',vmin=-lim,vmax=lim); axes[4].set_title('Primary − comparison')
                    axes[5].scatter(img.ravel()[::max(1,img.size//5000)],img2.ravel()[::max(1,img2.size//5000)],s=2,alpha=.3); axes[5].set_title('Pixel relationship')
                else:
                    axes[4].text(.5,.5,'Matrix mismatch',ha='center',va='center'); axes[5].axis('off')
            else:
                axes[3].text(.5,.5,'Select a comparison series',ha='center',va='center'); axes[4].axis('off'); axes[5].axis('off')
            for ax in axes[:5]:
                if ax.images:ax.set_xticks([]); ax.set_yticks([])
            confirmed=self.decoder_registry.get(self.decoder_key(a),{}).get('role','Unconfirmed')
            self.decoder_note.setText(f'Primary: {Path(path).name} | Candidate: {a.get("role")} | Confirmed: {confirmed} | Correlation: {a.get("_corr","—")} | Temporal variation: {a.get("_variation","—")} | Plane: {a.get("plane","Unknown")} | Frequency direction: {a.get("freq","Unknown")}. Confirmation is saved separately and does not modify the treatment ZIP.')
        except Exception as e:
            axes[0].text(.5,.5,str(e),ha='center',va='center')
        self.decoderplot.draw()

    def show_sequence_catalog(self):
        rows=[]
        for no,groups in sorted(self.sequence_catalog.items()):
            for g in groups:rows.append(g)
        self.seq_table.blockSignals(True); self.seq_table.setRowCount(len(rows)); self.seq_combo.blockSignals(True); self.seq_combo.clear()
        for r,g in enumerate(rows):
            matrix=g.get('matrix'); mtxt=f'{matrix[0]}x{matrix[1]} {matrix[2]}' if matrix and len(matrix)>2 else (f'{matrix[0]}x{matrix[1]}' if matrix else 'Unknown')
            vals=[g['sonication'],g['field'],g['sub'],g['zone'],g['role'],g['confidence'],len(g['paths']),mtxt,g.get('plane','Unknown'),g.get('freq','Unknown')]
            for c,v in enumerate(vals):self.seq_table.setItem(r,c,QTableWidgetItem(str(v)))
            label=f'Sonication {g["sonication"]} | {g["field"]}-{g["sub"]}-{g["zone"]} | {g["role"]} | {len(g["paths"])} frames'
            self.seq_combo.addItem(label,g)
        self.seq_table.blockSignals(False); self.seq_combo.blockSignals(False)
        if rows:self.seq_combo.setCurrentIndex(0); self.sequence_group_changed()
        else:self.seq_stage.setText('No RAW image sequences found')

    def sequence_table_selected(self,row,*args):
        if row>=0 and row<self.seq_combo.count():self.seq_combo.setCurrentIndex(row)

    def sequence_group_changed(self,*args):
        g=self.seq_combo.currentData()
        if not g:return
        n=len(g['paths']); self.seq_slider.blockSignals(True); self.seq_slider.setMaximum(max(0,n-1)); self.seq_slider.setValue(0); self.seq_slider.blockSignals(False)
        self.draw_sequence_frame()

    def _sequence_stage(self,g,i):
        n=max(1,len(g['paths'])); baseline=min(3,n)
        son=next((x for x in self.sonics if x.no==g['sonication']),None)
        duration=float(son.duration) if son and son.duration>0 else 0.0
        during=max(1,int(math.ceil(duration/4.0))) if duration>0 else max(1,(n-baseline)//2)
        if i<baseline:return 'Pre-sonication / baseline candidate'
        if i<min(n,baseline+during):return 'During-sonication candidate'
        return 'Post-sonication / cooling candidate'

    def draw_sequence_frame(self,*args):
        if not self.zf:return
        g=self.seq_combo.currentData()
        if not g:return
        paths=g['paths']; i=max(0,min(self.seq_slider.value(),len(paths)-1)); self.seq_frame_label.setText(f'{i+1} / {len(paths)}')
        stage=self._sequence_stage(g,i); self.seq_stage.setText(stage)
        f=self.seqplot.fig; f.clear(); ax1=f.add_subplot(1,2,1); ax2=f.add_subplot(1,2,2)
        try:
            cur=try_render_raw(self.zf.read(paths[i])); base=try_render_raw(self.zf.read(paths[0]))
            if not cur:raise ValueError('Current RAW cannot be decoded as a 2-D image')
            img=cur[4]; ax1.imshow(img,cmap='gray'); ax1.set_title(f'{stage}\n{Path(paths[i]).name}')
            if base and base[4].shape==img.shape:
                diff=img-base[4]; lim=max(float(np.percentile(np.abs(diff),99)),1e-6); ax2.imshow(diff,cmap='coolwarm',vmin=-lim,vmax=lim); ax2.set_title('Current − first frame')
            else:ax2.text(.5,.5,'Baseline difference unavailable',ha='center',va='center')
            for ax in (ax1,ax2):ax.set_xticks([]); ax.set_yticks([])
            matrix=g.get('matrix'); self.seq_note.setText(f'Exact source: Sonication{g["sonication"]} folder | Field/Sub/Zone: {g["field"]}/{g["sub"]}/{g["zone"]} | Role: {g["role"]} ({g["confidence"]}) | Frames: {len(paths)} | Matrix candidate: {matrix or "Unknown"} | Plane: {g.get("plane","Unknown")} | Frequency direction: {g.get("freq","Unknown")} | Stage timing assumes ~4 s/frame and ~10 s baseline only when exact timing evidence is unavailable.')
        except Exception as e:
            ax1.text(.5,.5,str(e),ha='center',va='center'); ax2.axis('off')
        self.seqplot.draw()

    def dragEnterEvent(self,event):
        if event.mimeData().hasUrls() and any(Path(u.toLocalFile()).suffix.lower()=='.zip' for u in event.mimeData().urls()):event.acceptProposedAction()
        else:event.ignore()

    def dropEvent(self,event):
        zips=[u.toLocalFile() for u in event.mimeData().urls() if Path(u.toLocalFile()).suffix.lower()=='.zip']
        if zips:self.load_zip(zips[0]); event.acceptProposedAction()

    def show_raw_series_catalog(self):
        rows=[]
        for no,groups in self.raw_series_catalog.items():
            for g in groups:
                rows.append((int(no),g))
        rows.sort(key=lambda x:(x[0],-x[1]['resolver_score']))
        self.rawseries_table.setRowCount(len(rows))
        for r,(no,g) in enumerate(rows):
            vals=[no,g['field'],g['zone'],g['role'],g['description'] or '—',len(g['paths']),g['matched_rows'],f'{g["matrix"][0]}x{g["matrix"][1]}' if g.get('matrix') else raw_candidates(g['size']),g['plane'],g['freq'],f'{g["resolver_score"]:.1f}']
            for c,v in enumerate(vals):self.rawseries_table.setItem(r,c,QTableWidgetItem(str(v)))

    def show_inventory(self):
        self.inventory_table.setRowCount(len(self.inventory))
        for r,it in enumerate(self.inventory):
            vals=[it.path,f'{it.size:,}',it.category,it.sonication,it.ext,it.signature,it.candidate,it.status]
            for c,v in enumerate(vals): self.inventory_table.setItem(r,c,QTableWidgetItem(str(v)))

    def inventory_selected(self):
        rows=self.inventory_table.selectionModel().selectedRows() if self.inventory_table.selectionModel() else []
        if not rows:return
        r=rows[0].row()
        if 0<=r<len(self.inventory):
            it=self.inventory[r]
            if it.path in self.raw_files:
                idx=self.raw_combo.findData(it.path)
                if idx>=0:self.raw_combo.setCurrentIndex(idx)

    def toggle_raw_protocol_summary(self,checked):
        self.raw_protocol_panel.setVisible(bool(checked))
        self.raw_protocol_toggle.setText(('▼' if checked else '▶')+' Protocol Summary')

    def populate_raw_protocol_summary(self):
        rows=[]
        for no,groups in sorted(getattr(self,'raw_series_catalog',{}).items(),key=lambda x:int(x[0]) if str(x[0]).isdigit() else 999999):
            for g in groups:
                rows.append(g)
        self.raw_protocol_table.setRowCount(len(rows))
        for r,g in enumerate(rows):
            vals=[g.get('protocol') or g.get('description') or f"Field {g.get('field')}",g.get('coil',''),g.get('classification') or g.get('role',''),g.get('classification_confidence',''),str(len(g.get('paths',[]))),g.get('plane','Unknown'),g.get('freq','Unknown')]
            for c,v in enumerate(vals): self.raw_protocol_table.setItem(r,c,QTableWidgetItem(str(v)))

    def populate_raw_combo(self):
        self.populate_raw_protocol_summary()
        self.raw_combo.blockSignals(True); self.raw_combo.clear()
        for n in self.raw_files:self.raw_combo.addItem(n,n)
        self.raw_combo.blockSignals(False)
        if self.raw_files:self.raw_combo.setCurrentIndex(0); self.draw_raw_candidate()
        else:
            self.rawplot.fig.clear(); self.rawplot.draw(); self.raw_meta.setText('No .raw files were found in this ZIP.')

    def draw_raw_candidate(self,*args):
        if not self.zf:return
        n=self.raw_combo.currentData()
        if not n:return
        try: blob=self.zf.read(n)
        except Exception as e:
            self.raw_meta.setText(str(e)); return
        result=try_render_raw(blob)
        f=self.rawplot.fig; f.clear(); ax=f.add_subplot(111)
        if result:
            score,dt,w,h,img=result; ax.imshow(img,cmap='gray',origin='upper'); ax.set_title(f'Experimental RAW preview — {Path(n).name}\n{w}x{h} {dt}, image-likeness {score:.3f}'); ax.set_xticks([]); ax.set_yticks([])
            role='Unmapped RAW'; reason='No XML-linked protocol/coil classification found'
            for groups in getattr(self,'raw_series_catalog',{}).values():
                for g in groups:
                    if n in g.get('paths',[]):
                        role=g.get('classification') or g.get('role',role); reason=g.get('classification_reason',reason); break
            self.raw_meta.setText(f'Path: {n} | Size: {len(blob):,} bytes | Candidate: {w}x{h} {dt} | Classification: {role} | Reason: {reason} | Status: Experimental decode. TMAP/MEMP are thermometry; FUS * Tracking is XD position detection; Calibration is not a replay image.')
        else:
            ax.text(.5,.5,'No plausible 2-D image layout found',ha='center',va='center'); ax.axis('off'); self.raw_meta.setText(f'Path: {n} | Size: {len(blob):,} bytes | Candidate layouts: {raw_candidates(len(blob))}')
        self.rawplot.draw()

    def export_all_raw_as_dicom(self):
        """Export every RAW file that RAW Investigation can decode as a 2-D image.

        The exported objects are anonymized Secondary Capture DICOM images. Pixel
        values are the same percentile-normalized 16-bit representation used by the
        investigation preview; no clinical temperature or magnitude meaning is
        asserted. Files that cannot be decoded are skipped and recorded in a report.
        """
        if not self.zf or not self.raw_files:
            QMessageBox.information(self,'DICOM export','No RAW image candidates are available.')
            return
        out_dir=QFileDialog.getExistingDirectory(self,'Select DICOM export folder')
        if not out_dir:return
        try:
            from pydicom.dataset import Dataset, FileDataset
            from pydicom.uid import ExplicitVRLittleEndian, SecondaryCaptureImageStorage, generate_uid
        except Exception as e:
            QMessageBox.critical(self,'DICOM export',f'pydicom is not available:\n{e}')
            return

        root=Path(out_dir)
        study_uid=generate_uid()
        series_uids={}
        exported=[]; skipped=[]
        progress=QProgressDialog('Decoding RAW images and writing DICOM...','Cancel',0,len(self.raw_files),self)
        progress.setWindowModality(Qt.WindowModal); progress.setMinimumDuration(0); progress.setValue(0)

        def safe_component(text):
            text=re.sub(r'[^A-Za-z0-9._-]+','_',str(text)).strip('._')
            return text[:100] or 'RAW'

        for index,name in enumerate(self.raw_files,1):
            if progress.wasCanceled():break
            progress.setLabelText(f'RAW {index}/{len(self.raw_files)}\n{Path(name).name}')
            progress.setValue(index-1)
            QApplication.processEvents()
            try:
                blob=self.zf.read(name)
                result=try_render_raw(blob)
                if not result:
                    skipped.append((name,'No plausible 2-D image layout'))
                    continue
                score,dt,w,h,img=result
                if not np.isfinite(img).all() or img.ndim!=2 or img.shape!=(h,w):
                    skipped.append((name,'Decoded array is invalid'))
                    continue
                pixels=np.rint(np.clip(img,0,1)*65535.0).astype('<u2')
                son_match=re.search(r'(?i)(?:^|[/\\])Sonication[_ ]?(\d+)(?:[/\\]|$)',name)
                son_no=int(son_match.group(1)) if son_match else 0
                series_key=f'Sonication{son_no}' if son_no else 'Unassigned'
                if series_key not in series_uids:series_uids[series_key]=generate_uid()
                target_dir=root/safe_component(series_key)
                target_dir.mkdir(parents=True,exist_ok=True)
                stem=safe_component(Path(name).stem)
                target=target_dir/f'{stem}.dcm'
                duplicate=1
                while target.exists():
                    target=target_dir/f'{stem}_{duplicate:03d}.dcm'; duplicate+=1

                file_meta=Dataset()
                file_meta.MediaStorageSOPClassUID=SecondaryCaptureImageStorage
                file_meta.MediaStorageSOPInstanceUID=generate_uid()
                file_meta.TransferSyntaxUID=ExplicitVRLittleEndian
                file_meta.ImplementationClassUID=generate_uid()
                ds=FileDataset(str(target),{},file_meta=file_meta,preamble=b'\0'*128)
                now=datetime.now()
                ds.SOPClassUID=SecondaryCaptureImageStorage
                ds.SOPInstanceUID=file_meta.MediaStorageSOPInstanceUID
                ds.StudyInstanceUID=study_uid
                ds.SeriesInstanceUID=series_uids[series_key]
                ds.PatientName='ANON^FUS_RAW_EXPORT'
                ds.PatientID='FUS_RAW_EXPORT'
                ds.PatientIdentityRemoved='YES'
                ds.DeidentificationMethod='Generated from proprietary RAW by FUS Investigation Replay'
                ds.StudyDate=now.strftime('%Y%m%d'); ds.StudyTime=now.strftime('%H%M%S')
                ds.ContentDate=ds.StudyDate; ds.ContentTime=now.strftime('%H%M%S.%f')
                ds.Modality='OT'
                ds.ConversionType='WSD'
                ds.StudyDescription='FUS RAW Investigation Export'
                ds.SeriesDescription=f'{series_key} decoded RAW candidates'
                ds.InstanceNumber=index
                ds.ImageType=['DERIVED','SECONDARY','RAW_DECODED']
                ds.Rows=h; ds.Columns=w
                ds.SamplesPerPixel=1
                ds.PhotometricInterpretation='MONOCHROME2'
                ds.BitsAllocated=16; ds.BitsStored=16; ds.HighBit=15; ds.PixelRepresentation=0
                ds.SmallestImagePixelValue=int(pixels.min()); ds.LargestImagePixelValue=int(pixels.max())
                ds.WindowCenter=32768; ds.WindowWidth=65536
                ds.BurnedInAnnotation='NO'
                ds.LossyImageCompression='00'
                ds.DerivationDescription=(f'Best 2-D candidate decoded from {name}; source dtype {dt}; '
                                          f'image-likeness score {score:.6f}; percentile normalized for review export.')
                ds.ImageComments=('RESEARCH/INVESTIGATION EXPORT. Not identified as magnitude, phase, '
                                  'temperature or dose. Original ZIP member: '+name)[:1024]
                ds.PixelData=pixels.tobytes(order='C')
                ds.is_little_endian=True; ds.is_implicit_VR=False
                ds.save_as(str(target),write_like_original=False)
                exported.append((name,str(target),w,h,dt,score))
            except Exception as e:
                skipped.append((name,f'{type(e).__name__}: {e}'))
        progress.setValue(len(self.raw_files)); progress.close()

        report=root/'RAW_DICOM_EXPORT_REPORT.txt'
        lines=[
            'FUS Investigation Replay - RAW to DICOM Export Report',
            f'Created: {datetime.now().isoformat(timespec="seconds")}',
            f'Source ZIP: {self.zip_path.name if self.zip_path else "Unknown"}',
            f'Exported: {len(exported)}',
            f'Skipped: {len(skipped)}',
            '',
            'IMPORTANT: Exported images are anonymized DERIVED/SECONDARY review images.',
            'They are percentile-normalized RAW candidates and are not asserted to be',
            'magnitude, phase, temperature, dose, or diagnostic images.',
            '',
            '[EXPORTED]'
        ]
        lines += [f'{src} -> {dst} | {w}x{h} {dt} | score={score:.6f}' for src,dst,w,h,dt,score in exported]
        lines += ['', '[SKIPPED]']
        lines += [f'{src} | {reason}' for src,reason in skipped]
        try:report.write_text('\n'.join(lines),encoding='utf-8')
        except Exception:pass

        canceled=progress.wasCanceled()
        summary=(f'DICOM export {"canceled" if canceled else "completed"}.\n\n'
                 f'Exported: {len(exported)}\nSkipped: {len(skipped)}\n\n'
                 f'Report: {report}')
        QMessageBox.information(self,'DICOM export',summary)

    def show_coverage(self):
        cats={}
        for it in self.inventory:cats[it.category]=cats.get(it.category,0)+1
        rows=[
            ('Sonication summary','Confirmed',len(self.sonics),'Parsed treatment summary rows'),
            ('DQA / Treatment','Partial',len(self.sonics),'Automatic workflow grouping plus manual override; explicit DQA log decoder remains under development'),
            ('Treatment MR review metadata','Confirmed' if self.mr_series else 'Missing',len(self.mr_series),f'Treatment-linked review.out acquisitions; {max(0,len(self.all_mr_series)-len(self.mr_series))} excluded'),
            ('MR server workflow','Confirmed' if self.mrserver_events else 'Missing',len(self.mrserver_events),'mrserver event evidence'),
            ('MR / Thermometry RAW','Experimental' if self.raw_files else 'Missing',len(self.raw_files),'Inventory and candidate 2-D preview; semantic channel identification pending'),
            ('Spectrum / Hydrophone','Experimental' if self.spectrum_msg_files else ('Partial' if self.spectrum_files else 'Missing'),len(self.spectrum_files)+len(self.spectrum_msg_files),'4–8 channel candidate decoding, spectrum heatmap, relative spectral-band comparison, activity/RMS/crest/impulsive metrics; channel identity and physical calibration pending'),
            ('Reflection','Inventory',cats.get('Reflection',0),'Files linked by path/time; decoder pending'),
            ('Skull / Bone','Inventory',cats.get('Skull heating',0)+cats.get('Skull measures',0)+cats.get('Bone spot data',0),'Evidence indexed; structured decoder pending'),
            ('MR–FUS synchronization','Partial' if self.ws_offsets else 'Unknown',len(self.ws_offsets),'Explicit offset evidence only; no fabricated timing'),
            ('DICOM import','Available',sum(len(v.get('files',[])) for v in self.external_images.values()),'External image mapping supported; metadata/pixel display depends on pydicom')
        ]
        self.coverage.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for c,v in enumerate(row):self.coverage.setItem(r,c,QTableWidgetItem(str(v)))

    def show_details(self,s,m):
        spec=self.nearest_spectrum(s)
        html=(f'<h2>Sonication {s.no} — {self.effective_phase(s)}</h2><table cellpadding="5">'
              f'<tr><td>Start time</td><td>{s.time}</td></tr><tr><td>Status</td><td>{s.status}</td></tr>'
              f'<tr><td>Duration</td><td>{s.duration:.1f} s</td></tr><tr><td>Commanded power</td><td>{s.power:.1f}</td></tr>'
              f'<tr><td>Average / maximum power</td><td>{s.avg_power:.1f} / {s.max_power:.1f}</td></tr>'
              f'<tr><td>Frequency</td><td>{s.freq:.3f}</td></tr><tr><td>Focal distance</td><td>{s.fd:.1f}</td></tr>'
              f'<tr><td>Position</td><td>X {s.x:.1f}, Y {s.y:.1f}, Elevation {s.elevation:.1f}, Roll {s.roll:.1f}, Pitch {s.pitch:.1f}</td></tr>'
              f'<tr><td>MR plane / frequency direction</td><td>{self.plane_combo.currentText()} / {self.freq_combo.currentText()}</td></tr>'
              f'<tr><td>Sonication folder files</td><td>{len(self.sonication_folder_files(s))}</td></tr>'
              f'<tr><td>Replay reconstruction priority</td><td>Same Sonication{s.no} folder first</td></tr>'
              f'<tr><td>Matched spectrum</td><td>{Path(spec).name if spec else "None"}</td></tr></table>')
        folder_files=self.sonication_folder_files(s)
        cats={}
        for n in folder_files:
            cat,_=classify_inventory_path(n); cats[cat]=cats.get(cat,0)+1
        folder_summary=', '.join(f'{k}: {v}' for k,v in sorted(cats.items())) or 'No exact Sonication folder data'
        html=html.replace('</table>',f'<tr><td>Folder content</td><td>{folder_summary}</td></tr></table>')
        self.details.setHtml(html)
        raw=self.best_raw_for_sonication(s)
        replay_source=(f'{raw[3]}: {Path(raw[1]).name} ({raw[4]} frames)' if raw else ('External MR' if str(s.no) in self.external_images else 'Example image'))
        values={'sonication':str(s.no),'phase':self.effective_phase(s),'start':s.time,'status':s.status,'duration':f'{s.duration:.2f} s','power':f'{s.power:.1f}','avgmax':f'{s.avg_power:.1f} / {s.max_power:.1f}','frequency':f'{s.freq:.3f} MHz','fd':f'{s.fd:.1f}','position':f'X {s.x:.1f}, Y {s.y:.1f}, E {s.elevation:.1f}, R {s.roll:.1f}, P {s.pitch:.1f}','mrfreq':f'{self.plane_combo.currentText()} / {self.freq_combo.currentText()}','replay_source':replay_source,'spectrum':Path(spec).name if spec else 'None'}
        for k,v in values.items():
            if k in self.detail_labels:self.detail_labels[k].setText(v)

if __name__=='__main__':
    app=QApplication(sys.argv); m=Main(); m.show()
    if len(sys.argv)>1 and Path(sys.argv[1]).exists():m.load_zip(sys.argv[1])
    sys.exit(app.exec())
