# Changelog

## v2.4.2-RC2 — Commit0021_MRSeriesImageResolver

- Treatment Exam MR Series are sorted by numeric Series Number, representing MRI acquisition order.
- Series Description and Protocol are parsed to classify Calibration, Tracking, Anatomical, Treatment MRI and TMAP/MEMP Thermometry series.
- TMAP/MEMP are treated as compound thermometry series containing magnitude, phase, temperature calculation and display products.
- Treatment MR Series tab now includes an interactive image viewer.
- Selecting a Series searches the Treatment-linked RAW catalog using Series Number first, then Description, Protocol, coil, plane and frequency direction.
- Component dropdown separates matched magnitude/phase/temperature/display/overlay candidate groups.
- Frame slider displays every matched image in the selected component.
- Unmatched Series display a clear reason instead of substituting an unrelated image.
- Added match score and evidence text for every displayed image.
