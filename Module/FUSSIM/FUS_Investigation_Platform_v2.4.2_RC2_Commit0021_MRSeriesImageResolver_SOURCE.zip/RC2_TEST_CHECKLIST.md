# RC2.4.2 test checklist

- Confirm Treatment MR Series are ordered by numeric Series Number.
- Select every MR Series row and confirm the image viewer updates.
- Verify Series 29, 30, 31... follow acquisition order.
- Confirm MEMP/TMAP rows show Thermometry Compound Series.
- Switch Component and Frame controls and confirm images update.
- Verify Series Number exact matches are preferred over time-only matching.
- Verify an unmatched Series shows a clear no-match message rather than an unrelated image.
- Confirm Calibration and FUS Tracking images are not classified as thermometry.
- Verify Operation interactive review remains functional.
