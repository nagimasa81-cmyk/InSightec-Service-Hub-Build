# Full WS Log and Treatment Phase Overlay

A WS log is included at file level when it contains events overlapping the
resolved Treatment session. Once included, the complete parsed log is shown.

Each event is tagged from the Treatment Sonication timeline:

- Pre-treatment: 15 minutes before first Treatment Sonication to 10 seconds before it
- Sonication N — Pre: approximately 10 seconds before FUS start
- Sonication N — During: commanded Sonication duration
- Sonication N — Post / Cooling: up to 30 seconds after FUS stop
- Between Sonications
- Post-treatment: up to 30 minutes after the final Treatment Sonication
- Outside Treatment phase

These windows are review labels and remain distinguishable from directly logged
MR/FUS state transitions.
