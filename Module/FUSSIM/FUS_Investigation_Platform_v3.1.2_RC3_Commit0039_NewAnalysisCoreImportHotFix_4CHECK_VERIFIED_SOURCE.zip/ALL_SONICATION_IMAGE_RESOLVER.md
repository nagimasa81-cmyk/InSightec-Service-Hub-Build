# All Sonication Image Resolver

Every Sonication folder is inventoried before Series matching. Unresolved but decodable RAW images remain available as low-confidence fallback Series.
