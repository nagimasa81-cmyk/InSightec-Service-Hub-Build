# RC3.1.1 startup test

1. Build the EXE from this Source ZIP.
2. Double-click the EXE.
3. Confirm the title contains `RC3.1.1 Qt Import Startup HotFix`.
4. Confirm Dashboard opens without a QProgressBar error.
5. Load a Treatment ZIP.
6. Open New Analysis Core and run the independent analysis.
7. Confirm Dashboard, Treatment Review, Operation, MR, Thermometry,
   Acoustic, Investigation, Reports and Diagnostics tabs open.
