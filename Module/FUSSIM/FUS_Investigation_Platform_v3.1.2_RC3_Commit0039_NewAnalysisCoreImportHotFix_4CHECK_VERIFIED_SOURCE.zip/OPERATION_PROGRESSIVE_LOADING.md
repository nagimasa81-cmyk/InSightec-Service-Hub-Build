# Operation Progressive Loading

The complete accepted WS log remains available, but the table is rendered progressively.

- Initial page: 500 events
- Load More: additional 500 events
- Chart marker click: automatically loads the page containing the selected event
- Full filtering/searching still uses the complete event dataset
- Wrapped row-height calculation runs only for displayed pages

This prevents the Qt UI thread from being blocked by thousands of QTableWidget
items and row-resize calculations during ZIP loading.
