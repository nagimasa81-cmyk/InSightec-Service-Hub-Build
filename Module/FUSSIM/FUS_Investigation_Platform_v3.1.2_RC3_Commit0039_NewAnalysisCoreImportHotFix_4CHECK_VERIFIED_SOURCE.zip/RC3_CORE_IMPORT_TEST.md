# RC3.1.2 test

1. Run `00_VERIFY_RC3_BEFORE_BUILD.bat`.
2. Confirm both Qt import and New Analysis Core import checks pass.
3. Build the EXE from this exact Source ZIP.
4. Confirm the title contains `RC3.1.2 New Analysis Core Import HotFix`.
5. Load a Treatment ZIP.
6. Open `New Analysis Core`.
7. Click `Run New Analysis`.
8. Confirm Package Inventory and reconstruction tables populate without NameError.
