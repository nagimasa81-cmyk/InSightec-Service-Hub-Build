# RAW Series Navigation

RAW Investigation is organized by:

1. Series Number, ascending
2. Sonication Number
3. Field and Zone

Selecting a row updates the image automatically. Use the arrow buttons or lower
slider to move through every image in that Series.

When Series Number is unavailable, the row is placed after numbered Series and
retains its Field/Zone description.
