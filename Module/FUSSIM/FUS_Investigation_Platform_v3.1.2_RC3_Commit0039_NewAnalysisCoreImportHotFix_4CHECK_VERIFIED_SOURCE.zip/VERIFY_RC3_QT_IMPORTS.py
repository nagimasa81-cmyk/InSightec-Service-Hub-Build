from pathlib import Path
import re
import sys

source=Path(__file__).with_name("app.py").read_text(encoding="utf-8")
match=re.search(r"from PySide6\.QtWidgets import \((.*?)\)",source,re.S)
if not match:
    print("QT IMPORT CHECK: FAILED — import block missing")
    sys.exit(1)

imports={
    token.strip()
    for token in match.group(1).replace("\n"," ").split(",")
    if token.strip()
}
required={
    "QProgressBar","QTreeWidget","QTreeWidgetItem",
    "QScrollArea","QSlider","QFrame"
}
missing=sorted(required-imports)
if missing:
    print("QT IMPORT CHECK: FAILED")
    print("Missing:",", ".join(missing))
    sys.exit(1)

print("QT IMPORT CHECK: PASSED")
print("Required RC3 widgets:",", ".join(sorted(required)))
