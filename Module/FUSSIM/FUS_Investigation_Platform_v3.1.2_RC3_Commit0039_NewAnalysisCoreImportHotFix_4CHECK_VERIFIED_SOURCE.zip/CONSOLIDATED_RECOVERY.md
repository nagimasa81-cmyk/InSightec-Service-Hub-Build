# RC2.6 Consolidated Recovery Baseline

This package establishes the recovery baseline after the RC2.4–RC2.5 HotFix sequence.

## Release rule

No feature may be removed or replaced without updating `BASELINE_FEATURE_MANIFEST.json` and the regression checker. New work must preserve the complete loader, Sonication, MR, RAW, Thermometry, Spectrum, Operation, Review and Export paths.

## Refresh contract

Changing Sonication must refresh the currently visible analysis and preserve source evidence. A tab may use lazy rendering, but it must not retain data from the previously selected Sonication.

## Evidence contract

Resolved MEMP/TMAP evidence takes priority. RAW fallback remains available when metadata is incomplete, but must be labeled estimated and must not report absolute temperature.

## Performance contract

Operation uses progressive table loading. A complete accepted WS log remains searchable even when only the first page is rendered. A single RAW or metadata failure must not stop the rest of the ZIP.
