# RC3 Purpose-Oriented Workspace Prototype

Concept: **Follow the Treatment**

Workspaces: Dashboard, Treatment Review, Operation Timeline, MR Workspace, Thermometry, Acoustic, Investigation, Reports, Diagnostics.

All RC2.6.2 parsers and legacy tabs remain intact under Diagnostics for regression testing.
