# RC3.1.2 Four-Check Report

## 1. ZIP structure: PASSED
- zip_test: PASSED
- missing_files: []
- file_count: 71

## 2. Python compile/import: PASSED
- compile_failures: []
- core_import: PASSED

## 3. UI startup/static references: PASSED
- main_class: True
- undefined_connected_methods: []
- missing_qt_imports: []
- missing_global_imports: []

## 4. Validators/build inclusion: PASSED
- validators: {'VERIFY_RC3_QT_IMPORTS.py': {'returncode': 0, 'stdout': 'QT IMPORT CHECK: PASSED\nRequired RC3 widgets: QFrame, QProgressBar, QScrollArea, QSlider, QTreeWidget, QTreeWidgetItem', 'stderr': 'Spreadsheet runtime warmup failed during python startup\nTraceback (most recent call last):\n  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py", line 26, in warm_spreadsheet_runtime_on_startup\n  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/spreadsheet_warmup.py", line 785, in warm_spreadsheet_runtime\n  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/spreadsheet_warmup.py", line 720, in _warm_feature_flows\n  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/spreadsheet_warmup.py", line 704, in _warm_collaboration_flows\n  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/generated/interface/models.py", line 30820, in hydrate_crdt_from_proto\n  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/rpc/remote.py", line 749, in __call__\n  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/rpc/client.py", line 150, in call\nartifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.'}, 'VERIFY_RC3_NEW_CORE_IMPORT.py': {'returncode': 0, 'stdout': 'RC3 CORE IMPORT CHECK: PASSED\nModule: rc3_new_analysis_core.py\nClass: NewAnalysisCore', 'stderr': 'Spreadsheet runtime warmup failed during python startup\nTraceback (most recent call last):\n  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py", line 26, in warm_spreadsheet_runtime_on_startup\n  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/spreadsheet_warmup.py", line 785, in warm_spreadsheet_runtime\n  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/spreadsheet_warmup.py", line 720, in _warm_feature_flows\n  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/spreadsheet_warmup.py", line 704, in _warm_collaboration_flows\n  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/generated/interface/models.py", line 30820, in hydrate_crdt_from_proto\n  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/rpc/remote.py", line 749, in __call__\n  File "/tmp/tmp.yTcnQsZYiA/artifact_tool_v2-2.8.4/artifact_tool/rpc/client.py", line 150, in call\nartifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.'}}
- build_files: ['00_VERIFY_RC3_BEFORE_BUILD.bat', '01_RUN_PYTHON.bat', 'RUN_REGRESSION_CHECK.bat']
- build_mentions_app: True
- build_excludes_core: False

# Overall: PASSED