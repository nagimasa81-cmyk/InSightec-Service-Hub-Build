# RC2.6.2 test checklist

- Confirm Sonication Details is expanded by default.
- Confirm the Sonication panel is narrow and all parameters are listed vertically.
- Confirm Operation list initially shows Time and Message only.
- Confirm long messages stay on one row and use horizontal scrolling.
- Confirm list-row colors match chart event colors.
- Click list rows and chart markers and verify Selected Event updates above the chart.
- Toggle category checkboxes and confirm list and chart change together.
- Confirm Sonication Status Overview clearly shows each DQA/Treatment active interval.
- Confirm Sonication Power On does not appear in WS/CPC Lifecycle.
- Confirm all three time axes remain synchronized during zoom/reset.
