from pathlib import Path
import ast
import importlib.util
import sys

base=Path(__file__).resolve().parent
app_source=(base/"app.py").read_text(encoding="utf-8")
tree=ast.parse(app_source)

import_ok=any(
    isinstance(node,ast.ImportFrom)
    and node.module=="rc3_new_analysis_core"
    and any(alias.name=="NewAnalysisCore" for alias in node.names)
    for node in ast.walk(tree)
)
if not import_ok:
    print("RC3 CORE IMPORT CHECK: FAILED — app.py import missing")
    sys.exit(1)

core=base/"rc3_new_analysis_core.py"
if not core.exists():
    print("RC3 CORE IMPORT CHECK: FAILED — module file missing")
    sys.exit(1)

spec=importlib.util.spec_from_file_location("rc3_new_analysis_core",core)
module=importlib.util.module_from_spec(spec)
sys.modules["rc3_new_analysis_core"]=module
spec.loader.exec_module(module)

if not hasattr(module,"NewAnalysisCore"):
    print("RC3 CORE IMPORT CHECK: FAILED — class missing")
    sys.exit(1)

print("RC3 CORE IMPORT CHECK: PASSED")
print("Module: rc3_new_analysis_core.py")
print("Class: NewAnalysisCore")
