# RC3 New Analysis Core Prototype

This build introduces an independent evidence-first analysis engine.

## Independence

The new engine does not use legacy results for:

- Sonication extraction
- MR/RAW grouping
- Treatment Session selection
- Spectrum linkage
- Synchronization confidence

It reads ZIP members directly.

## Stage 1

- Complete package inventory
- File category classification
- Sonication-folder extraction
- Full-date extraction
- Competing calendar-year detection
- Treatment Session candidates

## Stage 2

- Sonication reconstruction from folder membership and evidence types
- RAW, Spectrum, ACT and metadata coverage
- Confidence and unresolved evidence

## Stage 3 prototype

- RAW sequence candidates grouped by Sonication, file size and inferred matrix
- MEMP/TMAP hints are evidence only
- Magnitude/Phase remains unresolved unless explicit evidence exists

## Safety

Legacy RC2/RC3 analysis remains under Diagnostics for comparison.
The new engine does not silently replace existing clinical or service conclusions.
