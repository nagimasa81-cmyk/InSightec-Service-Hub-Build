from pathlib import Path
import ast, json, py_compile, sys, zipfile, tempfile

ROOT=Path(__file__).resolve().parent
APP=ROOT/'app.py'
errors=[]

try:
    py_compile.compile(str(APP),doraise=True)
except Exception as exc:
    errors.append(f'Compile failed: {exc}')

source=APP.read_text(encoding='utf-8')
try:
    tree=ast.parse(source)
except Exception as exc:
    errors.append(f'AST parse failed: {exc}')
    tree=None

required_functions=[
 'natural_key','build_exam_anchor','filter_review_series_for_exam','build_raw_series_catalog',
 'sonication_number_from_path','inventory_raw_by_sonication','classify_system_lifecycle_event',
 'parse_operation_events','is_thermometry_text'
]
required_methods=[
 'load_zip','populate','sonication_combo_changed','set_selected_row','refresh_selected',
 'populate_raw_protocol_summary','raw_protocol_row_selected','move_raw_frame',
 'populate_prf_sources','refresh_prf_replay','show_operation','load_more_operation_rows',
 'operation_plot_clicked','export_all_raw_as_dicom'
]
if tree:
    functions={n.name for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    for name in required_functions+required_methods:
        if name not in functions: errors.append(f'Missing function/method: {name}')

required_strings=[
 'Show DQA','Selected Sonication details','RAW Investigation','PRF Thermometry Replay',
 'Treatment MR Series','Operation','Load More','Export All Decoded Images as DICOM',
 'RAW Fallback','Initial TMAP','MEMP','TMAP','Lifecycle:'
]
for value in required_strings:
    if value not in source: errors.append(f'Missing UI/feature marker: {value}')

for filename in ['version.json','BASELINE_FEATURE_MANIFEST.json','CONSOLIDATED_RECOVERY.md']:
    if not (ROOT/filename).exists(): errors.append(f'Missing package file: {filename}')

try:
    version=json.loads((ROOT/'version.json').read_text(encoding='utf-8'))
    if version.get('version')!='v2.6.0-RC2': errors.append('Unexpected version.json version')
except Exception as exc:
    errors.append(f'version.json invalid: {exc}')

# Lightweight behavior check that needs no GUI.
import re
def _nk(value):
    return [int(x) if x.isdigit() else x.casefold() for x in re.split(r'(\d+)',value)]
try:
    ordered=sorted(['Frame10','Frame2','Frame1'],key=_nk)
    if ordered!=['Frame1','Frame2','Frame10']:
        errors.append(f'Natural-order semantic check failed: {ordered}')
except Exception as exc:
    errors.append(f'Natural-order semantic check failed: {type(exc).__name__}: {exc}')

if errors:
    print('REGRESSION CHECK: FAILED')
    for error in errors: print('-',error)
    sys.exit(1)
print('REGRESSION CHECK: PASSED')
print(f'Checked {len(required_functions)+len(required_methods)} functions/methods and {len(required_strings)} feature markers.')
