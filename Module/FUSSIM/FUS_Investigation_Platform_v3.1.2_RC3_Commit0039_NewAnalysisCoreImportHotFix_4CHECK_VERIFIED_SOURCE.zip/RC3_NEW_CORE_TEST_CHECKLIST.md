# RC3.1 New Analysis Core test checklist

- Load each available Treatment ZIP.
- Open New Analysis Core and click Run New Analysis.
- Confirm every ZIP member appears in Package Inventory.
- Verify competing years such as 2020 vs 2026 appear under rejected date groups.
- Verify every Sonication folder appears in Sonication Reconstruction.
- Confirm Sonications containing RAW files never show RAW=0.
- Compare RAW sequence candidates across Sonication 1, 2 and later Sonications.
- Confirm MEMP/TMAP are hints and unresolved components are not forced.
- Compare the independent result with Diagnostics without using Diagnostics as truth.
