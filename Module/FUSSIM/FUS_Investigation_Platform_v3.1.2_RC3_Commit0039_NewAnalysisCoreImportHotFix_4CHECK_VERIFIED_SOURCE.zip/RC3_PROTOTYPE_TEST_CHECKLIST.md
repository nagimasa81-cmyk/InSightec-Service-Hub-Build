# RC3 Prototype Test Checklist

- Load treatment ZIP/folder and verify Dashboard counts.
- Select Sonications in Treatment Review and verify detail synchronization.
- Toggle Show DQA.
- Open every Legacy source from RC3 workspaces.
- Test Operation presets.
- Verify MR Series tree population.
- Verify Threshold and Channel controls.
- Confirm all RC2.6.2 pages remain available under Diagnostics.
