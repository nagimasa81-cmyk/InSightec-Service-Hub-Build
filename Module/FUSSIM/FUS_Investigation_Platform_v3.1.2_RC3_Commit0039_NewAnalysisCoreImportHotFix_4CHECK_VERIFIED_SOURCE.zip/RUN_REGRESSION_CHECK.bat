@echo off
setlocal
python regression_check.py
if errorlevel 1 (
  echo.
  echo REGRESSION CHECK FAILED
  pause
  exit /b 1
)
echo.
echo REGRESSION CHECK PASSED
pause
