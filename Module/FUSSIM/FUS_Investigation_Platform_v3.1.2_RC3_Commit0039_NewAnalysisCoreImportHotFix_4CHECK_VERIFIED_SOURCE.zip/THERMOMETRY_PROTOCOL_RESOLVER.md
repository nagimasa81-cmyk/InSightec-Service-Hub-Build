# Thermometry Protocol Resolver

MEMP: multi-echo, lower noise robustness, phase direction High, frequency direction Medium.

TMAP: more noise robust, phase direction High, frequency direction Low.

Initial TMAP is retained but excluded from automatic temperature calculation until explicit evidence promotes it.
