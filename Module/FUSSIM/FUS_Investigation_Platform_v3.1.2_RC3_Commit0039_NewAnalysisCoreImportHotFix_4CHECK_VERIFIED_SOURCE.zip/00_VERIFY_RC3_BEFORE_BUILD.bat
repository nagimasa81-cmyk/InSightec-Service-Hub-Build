@echo off
python VERIFY_RC3_QT_IMPORTS.py
if errorlevel 1 goto failed
python VERIFY_RC3_NEW_CORE_IMPORT.py
if errorlevel 1 goto failed
echo RC3 source verification passed.
pause
exit /b 0
:failed
echo RC3 source verification failed.
pause
exit /b 1
