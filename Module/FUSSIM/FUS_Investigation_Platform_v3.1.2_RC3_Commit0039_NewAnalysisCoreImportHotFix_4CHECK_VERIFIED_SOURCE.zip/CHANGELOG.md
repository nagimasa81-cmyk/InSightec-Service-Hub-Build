# Changelog

## v3.1.2-RC3-PROTOTYPE — Commit0039_RC3NewAnalysisCoreImportHotFix

- Fixed `NameError: NewAnalysisCore is not defined`.
- Added a normal top-level import from `rc3_new_analysis_core.py`.
- Ensures PyInstaller/Nuitka detects and bundles the independent analysis module.
- Added a clear runtime error when the module is missing from a build.
- Added pre-build module/class import validation.
- Preserved the Qt import startup fixes from RC3.1.1.
