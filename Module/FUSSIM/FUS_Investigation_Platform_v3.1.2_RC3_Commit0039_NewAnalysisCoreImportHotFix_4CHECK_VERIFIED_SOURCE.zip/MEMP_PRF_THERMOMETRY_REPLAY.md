# MEMP PRF Thermometry Replay

MEMP acquires Magnitude and Phase images. Temperature change is derived from the phase difference relative to a pre-heating reference phase image. TMAP is treated as the temperature calculation/display product.

The current implementation shows a relative negative Delta Phase proxy. It does not report absolute degrees Celsius until phase scaling and PRF calibration parameters are validated.
