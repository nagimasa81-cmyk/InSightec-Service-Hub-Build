# WS Operation Scope

Operation analysis is event-scoped rather than accepting a whole log file.

Only WS log events inside the resolved Treatment session window are admitted:

- 15 minutes before the first Treatment Sonication
- through 30 minutes after the final Treatment Sonication

The complete log remains available in inventory/evidence, but unrelated events
do not appear in the normal Operation timeline.
