# v1.9.1-RC1 — Commit0014a_ContextRefreshIsolationHotFix

- Fixed selected table row not updating fixed details and review panels.
- Selection is resolved by stored Sonication ID.
- Panel updates are isolated so one decoder error no longer blocks all remaining data.
- Added visible per-panel diagnostics.
- Preserved RC1.8.1 spectrum fallback and RC1.9 synchronized context behavior.

# Changelog

## v1.9.0-RC1 — Commit0014_SynchronizedContextEngine

- Fixed the upper-left Sonication selection not updating the review panels.
- Added stable current-Sonication context keyed by Sonication number.
- Added row click, current-cell and selection-model event coverage.
- Added explicit refresh after Treatment/DQA list reconstruction.
- Previous/Next now uses the same central selection route.
- All Replay, Thermometry, Spectrum, Hydrophone, details and evidence panels refresh together.
- Matplotlib canvases are explicitly redrawn after every context change.
- Retained RC1.8.1 Spectrum regression fallbacks and RC1.7 deep RAW resolver.

See CHANGELOG.old.md for prior history.

## v1.9.2-RC1 — Commit0014b_ResponsiveContextFreezeHotFix

- Fixed GUI freeze when switching Sonications.
- Added debounced selection refresh.
- Removed re-entrant `QApplication.processEvents()` from context updates.
- Heavy RAW, Thermometry, Spectrum and Hydrophone decoding now runs only for the visible tab.
- Opening a heavy tab refreshes it for the current Sonication.
- Rapid selection changes discard superseded refresh requests.
