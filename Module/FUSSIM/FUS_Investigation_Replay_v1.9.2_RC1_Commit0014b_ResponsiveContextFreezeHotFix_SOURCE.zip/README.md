# FUS Investigation & Treatment Replay Workstation RC1.9.1

This hotfix repairs Sonication selection refresh and isolates panel failures.

# FUS Investigation & Treatment Replay Workstation RC1.9

## RC1.9 focus

- Central synchronized Sonication context engine.
- Upper-left row selection immediately updates every review panel.
- Previous/Next and Show DQA use the same update route.
- Selection is retained by Sonication number when the list is rebuilt.
- Existing RC1.8.1 exact Spectrum parser and legacy fallbacks are retained.
- Sonication-folder-first RAW/Thermometry reconstruction is retained.

# FUS Investigation & Treatment Replay Workstation RC1.7

## Deep ZIP / RAW Series Resolver

This release changes treatment ZIP loading from file-size/image-likeness selection to exact metadata mapping whenever possible.

### Exact RAW mapping

A Sonication RAW filename such as `5-1-3-7.raw` is interpreted as a candidate tuple:

- field index: 5
- sub-index: 1
- zone index: 3
- array index: 7

It is matched against the same Sonication in `MriImageParams.xml` using `fieldindex`, `zoneindex`, and `arrayindex`.

### Selection priority

1. Exact `SonicationN` folder
2. Exact `MriImageParams.xml` field/zone/array match
3. TMAP / MEMP / Thermometry protocol classification
4. Matrix and byte-size consistency
5. Direction-cosine plane and frequency-direction agreement
6. Image-likeness only as a final representative-frame score

### Loading improvements

- Large RAW and Spectrum members are inventoried from ZIP metadata without fully inflating each file.
- Progress is shown during metadata, inventory, RAW-series, synchronization, and review-table stages.
- A new **RAW Series Resolver** tab shows each resolved field, zone, role, protocol, frame count, XML coverage, matrix, plane, frequency direction, and resolver score.

### Thermometry

Thermometry Replay now prefers exact XML-mapped TMAP/MEMP series inside the selected Sonication folder. It no longer automatically chooses the globally dominant RAW geometry.

Temperature conversion remains investigational until magnitude/phase identity, echo pairing, phase unwrap, cadence, TE, field strength, PRF coefficient, and scaling are validated.

## Build

Compatible with the supplied RC1 GitHub Actions workflow.

## RC1.8 exact SpectrumMsg integration

The spectrum analyzer supplied in `source(3).zip` is now integrated as the reusable `fus_spectrum_core` package. SpectrumMsg files are decoded using their confirmed record structure instead of guessed numeric interleaving.

The Spectrum and Hydrophone pages now show physical frequency in MHz, actual frame timing from the payload header, time-frequency spectrograms, all-channel heatmaps, and exploratory fundamental/subharmonic/broadband metrics. Dragging a time range in Hydrophone Acoustic Analysis averages the actual FFT frames inside that interval.
