
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from pathlib import PurePosixPath
from collections import Counter, defaultdict
import math
import re
import zipfile


@dataclass
class FileEvidence:
    path: str
    size: int
    extension: str
    category: str
    sonication: int | None = None
    timestamp: datetime | None = None
    timestamp_source: str = ""
    matrix_candidate: str = ""
    decode_candidate: bool = False
    confidence: float = 0.0
    notes: list[str] = field(default_factory=list)


@dataclass
class SessionCandidate:
    session_id: int
    start: datetime | None
    end: datetime | None
    file_count: int
    sonications: list[int]
    categories: dict[str, int]
    confidence: float
    evidence: list[str]


@dataclass
class SonicationCandidate:
    number: int
    file_count: int
    categories: dict[str, int]
    earliest: datetime | None
    latest: datetime | None
    raw_count: int
    spectrum_count: int
    act_count: int
    metadata_count: int
    likely_phase: str
    confidence: float
    evidence: list[str]
    unresolved: list[str]


@dataclass
class SequenceCandidate:
    sonication: int
    signature: str
    file_count: int
    size: int
    matrix: str
    component_hint: str
    role_hint: str
    confidence: float
    evidence: list[str]


@dataclass
class NewAnalysisResult:
    files: list[FileEvidence]
    sessions: list[SessionCandidate]
    sonications: list[SonicationCandidate]
    sequences: list[SequenceCandidate]
    rejected_dates: list[str]
    warnings: list[str]

    def summary(self) -> dict:
        return {
            "files": len(self.files),
            "sessions": len(self.sessions),
            "sonications": len(self.sonications),
            "sequences": len(self.sequences),
            "unknown": sum(f.category == "Unknown" for f in self.files),
            "dated_files": sum(f.timestamp is not None for f in self.files),
        }


class NewAnalysisCore:
    """Independent evidence-first treatment reconstruction.

    This engine intentionally does not use the legacy Sonication, MR, RAW,
    synchronization or Operation results. It reads ZIP members directly and
    produces candidate structures with explicit confidence and evidence.
    """

    TIME_PATTERNS = [
        # YYYY-MM-DD_HH-MM-SS, YYYY_MM_DD-HH_MM_SS
        re.compile(
            r"(?<!\d)(20\d{2})[-_](\d{1,2})[-_](\d{1,2})"
            r"[T _-](\d{1,2})[-_:](\d{1,2})[-_:](\d{1,2})(?!\d)"
        ),
        # Thu_Jun_11_18_29_57_2026
        re.compile(
            r"(?i)(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)?_?"
            r"(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
            r"[_-](\d{1,2})[_-](\d{1,2})[_-](\d{1,2})[_-](\d{1,2})[_-](20\d{2})"
        ),
        # HH-MM-SS plus year elsewhere is handled conservatively later.
        re.compile(r"(?<!\d)(\d{1,2})[-_:](\d{2})[-_:](\d{2})(?!\d)"),
    ]

    MONTHS = {
        name: index + 1
        for index, name in enumerate(
            ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
             "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        )
    }

    def analyze(
        self,
        zf: zipfile.ZipFile,
        level: str = 'standard',
        matching_level: str = 'balanced',
        progress_callback=None
    ) -> NewAnalysisResult:
        level=str(level or 'standard').lower()
        matching_level=str(matching_level or 'balanced').lower()
        self.matching_level=matching_level
        members=[info for info in zf.infolist() if not info.is_dir()]
        files=[]
        total=max(1,len(members))
        for index,info in enumerate(members,1):
            files.append(self._inspect_member(zf,info,level=level))
            if progress_callback and (index%40==0 or index==total):
                progress_callback(index,total,'Inventory')
        sessions,rejected_dates=self._build_sessions(files)
        sonications=self._reconstruct_sonications(files)
        sequences=[] if level=='quick' else self._build_sequence_candidates(files)
        if level=='standard':
            # Keep the most useful candidates and avoid rendering thousands
            # of low-evidence groups in the prototype.
            sequences=sorted(
                sequences,
                key=lambda item:(item.confidence,item.file_count),
                reverse=True
            )[:500]
        warnings=self._validate(files,sessions,sonications,sequences)
        return NewAnalysisResult(
            files=files,
            sessions=sessions,
            sonications=sonications,
            sequences=sequences,
            rejected_dates=rejected_dates,
            warnings=warnings,
        )

    def _matching_policy(self):
        level=getattr(self,'matching_level','balanced')
        if level=='loose':
            return {
                'session_gap_hours':24,
                'minimum_sonication_score':0.25,
                'minimum_sequence_score':0.25,
                'keep_unknown':True,
            }
        if level=='strict':
            return {
                'session_gap_hours':4,
                'minimum_sonication_score':0.70,
                'minimum_sequence_score':0.72,
                'keep_unknown':False,
            }
        return {
            'session_gap_hours':8,
            'minimum_sonication_score':0.48,
            'minimum_sequence_score':0.50,
            'keep_unknown':True,
        }

    def _inspect_member(
        self,
        zf: zipfile.ZipFile,
        info: zipfile.ZipInfo,
        level: str = 'standard'
    ) -> FileEvidence:
        path = info.filename.replace("\\", "/")
        suffix = PurePosixPath(path).suffix.lower()
        lower = path.lower()
        category = self._classify(path, suffix)
        sonication = self._sonication_number(path)
        timestamp, source = self._timestamp_from_name(path)

        notes: list[str] = []
        matrix = ""
        decode_candidate = False
        confidence = 0.25

        if category in {"RAW Image", "DICOM"}:
            matrix = self._infer_matrix(info.file_size, suffix)
            decode_candidate = bool(matrix) or category == "DICOM"
            confidence += 0.25 if matrix else 0.05

        if sonication is not None:
            confidence += 0.2
        if timestamp is not None:
            confidence += 0.15
        if category != "Unknown":
            confidence += 0.15

        # Small text preview: only used for evidence extraction, never as truth.
        if (
            level!='quick'
            and category in {"XML / Metadata", "Log", "Review", "Summary", "ACT"}
        ):
            try:
                preview_limit=8192 if level=='standard' else 65536
                preview = zf.read(info)[:preview_limit].decode("utf-8", "ignore")
                if timestamp is None:
                    timestamp, source = self._timestamp_from_text(preview)
                    if timestamp:
                        confidence += 0.1
                if sonication is None:
                    sonication = self._sonication_from_text(preview)
                    if sonication is not None:
                        confidence += 0.1
                if "memp" in preview.lower():
                    notes.append("MEMP mentioned in content")
                if "tmap" in preview.lower():
                    notes.append("TMAP mentioned in content")
                if "power" in preview.lower():
                    notes.append("Power-related content")
            except Exception as exc:
                notes.append(f"Preview unavailable: {type(exc).__name__}")

        return FileEvidence(
            path=path,
            size=info.file_size,
            extension=suffix or "(none)",
            category=category,
            sonication=sonication,
            timestamp=timestamp,
            timestamp_source=source,
            matrix_candidate=matrix,
            decode_candidate=decode_candidate,
            confidence=min(confidence, 0.99),
            notes=notes,
        )

    def _classify(self, path: str, suffix: str) -> str:
        name = PurePosixPath(path).name.lower()
        full = path.lower()

        if suffix in {".dcm", ".dicom", ".ima"}:
            return "DICOM"
        if suffix == ".raw":
            return "RAW Image"
        if name.endswith(".dmp_fft") or "spectrum" in name and "fft" in name:
            return "Spectrum"
        if suffix == ".act":
            return "ACT"
        if "summary_" in name and suffix in {".txt", ".xml", ".csv"}:
            return "Summary"
        if "review.out" in name or name.startswith("review"):
            return "Review"
        if "mrserver" in full:
            return "MR Server"
        if suffix in {".xml", ".json", ".ini", ".cfg", ".yml", ".yaml"}:
            return "XML / Metadata"
        if suffix in {".log", ".txt", ".out", ".csv"}:
            return "Log"
        if suffix in {".bmp", ".png", ".jpg", ".jpeg", ".tif", ".tiff"}:
            return "Bitmap Image"
        return "Unknown"

    def _sonication_number(self, path: str) -> int | None:
        patterns = [
            r"(?i)(?:^|/)sonication[\s_-]*0*(\d+)(?:/|$)",
            r"(?i)(?:^|/)sonic[\s_-]*0*(\d+)(?:/|$)",
            r"(?i)(?:^|/)son[\s_-]*0*(\d+)(?:/|$)",
        ]
        for pattern in patterns:
            match = re.search(pattern, path)
            if match:
                return int(match.group(1))
        return None

    def _sonication_from_text(self, text: str) -> int | None:
        match = re.search(r"(?i)\bsonication\s*(?:number|no\.?|#)?\s*[:=]?\s*(\d+)", text)
        return int(match.group(1)) if match else None

    def _timestamp_from_name(self, path: str) -> tuple[datetime | None, str]:
        name = PurePosixPath(path).name
        for index, pattern in enumerate(self.TIME_PATTERNS):
            match = pattern.search(name)
            if not match:
                continue
            try:
                groups = match.groups()
                if index == 0:
                    return datetime(*map(int, groups)), "filename full datetime"
                if index == 1:
                    month, day, hour, minute, second, year = groups
                    return datetime(
                        int(year), self.MONTHS[month.title()], int(day),
                        int(hour), int(minute), int(second)
                    ), "filename textual datetime"
                # Time-only candidates are deliberately not converted to a date.
            except (TypeError, ValueError):
                continue
        return None, ""

    def _timestamp_from_text(self, text: str) -> tuple[datetime | None, str]:
        candidates = [
            re.compile(
                r"(?<!\d)(20\d{2})[-/](\d{1,2})[-/](\d{1,2})"
                r"[ T](\d{1,2}):(\d{2}):(\d{2})(?!\d)"
            ),
            re.compile(
                r"(?<!\d)(\d{1,2})/(\d{1,2})/(20\d{2})"
                r"[ T](\d{1,2}):(\d{2}):(\d{2})(?!\d)"
            ),
        ]
        for index, pattern in enumerate(candidates):
            match = pattern.search(text)
            if not match:
                continue
            try:
                values = list(map(int, match.groups()))
                if index == 0:
                    return datetime(*values), "content datetime"
                month, day, year, hour, minute, second = values
                return datetime(year, month, day, hour, minute, second), "content datetime"
            except ValueError:
                continue
        return None, ""

    def _infer_matrix(self, size: int, suffix: str) -> str:
        # Common FUS RAWs are often unsigned 16-bit square matrices.
        candidates: list[str] = []
        for bytes_per_pixel, dtype in [(2, "u16"), (4, "f32"), (1, "u8")]:
            if size % bytes_per_pixel:
                continue
            pixels = size // bytes_per_pixel
            side = int(math.isqrt(pixels))
            if side * side == pixels and side in {
                64, 96, 128, 192, 256, 320, 384, 512, 768, 1024
            }:
                candidates.append(f"{side}x{side} {dtype}")
        return " / ".join(candidates)

    def _build_sessions(
        self, files: list[FileEvidence]
    ) -> tuple[list[SessionCandidate], list[str]]:
        dated = sorted(
            [f for f in files if f.timestamp is not None],
            key=lambda item: item.timestamp
        )
        if not dated:
            return [], []

        # Select the dominant calendar year first. Large date jumps are treated
        # as competing sessions, not silently merged.
        year_counts = Counter(f.timestamp.year for f in dated)
        dominant_year, _ = year_counts.most_common(1)[0]
        rejected = [
            f"{year}: {count} file(s)"
            for year, count in sorted(year_counts.items())
            if year != dominant_year
        ]

        dominant = [f for f in dated if f.timestamp.year == dominant_year]
        clusters: list[list[FileEvidence]] = []
        for evidence in dominant:
            if not clusters:
                clusters.append([evidence])
                continue
            gap = evidence.timestamp - clusters[-1][-1].timestamp
            if gap > timedelta(hours=self._matching_policy()['session_gap_hours']):
                clusters.append([evidence])
            else:
                clusters[-1].append(evidence)

        sessions: list[SessionCandidate] = []
        for session_id, cluster in enumerate(clusters, 1):
            categories = Counter(item.category for item in cluster)
            sonications = sorted({
                item.sonication for item in cluster
                if item.sonication is not None
            })
            evidence = [
                f"Dominant year {dominant_year}",
                f"{len(cluster)} timestamped file(s)",
            ]
            score = 0.35
            if sonications:
                score += 0.25
                evidence.append(f"Contains Sonication folders {sonications}")
            if categories.get("Summary"):
                score += 0.15
                evidence.append("Contains Treatment Summary")
            if categories.get("Spectrum"):
                score += 0.1
                evidence.append("Contains Spectrum data")
            if categories.get("RAW Image"):
                score += 0.1
                evidence.append("Contains RAW images")
            sessions.append(SessionCandidate(
                session_id=session_id,
                start=cluster[0].timestamp,
                end=cluster[-1].timestamp,
                file_count=len(cluster),
                sonications=sonications,
                categories=dict(categories),
                confidence=min(score, 0.99),
                evidence=evidence,
            ))
        return sessions, rejected

    def _reconstruct_sonications(
        self, files: list[FileEvidence]
    ) -> list[SonicationCandidate]:
        grouped: dict[int, list[FileEvidence]] = defaultdict(list)
        for evidence in files:
            if evidence.sonication is not None:
                grouped[evidence.sonication].append(evidence)

        output: list[SonicationCandidate] = []
        for number, group in sorted(grouped.items()):
            categories = Counter(item.category for item in group)
            timestamps = sorted(
                item.timestamp for item in group if item.timestamp is not None
            )
            raw_count = categories.get("RAW Image", 0)
            spectrum_count = categories.get("Spectrum", 0)
            act_count = categories.get("ACT", 0)
            metadata_count = (
                categories.get("XML / Metadata", 0)
                + categories.get("Summary", 0)
            )
            evidence: list[str] = []
            unresolved: list[str] = []
            score = 0.2

            if raw_count:
                score += 0.2
                evidence.append(f"{raw_count} RAW image(s)")
            else:
                unresolved.append("No RAW image found")
            if spectrum_count:
                score += 0.15
                evidence.append(f"{spectrum_count} Spectrum file(s)")
            if act_count:
                score += 0.15
                evidence.append(f"{act_count} ACT file(s)")
            if metadata_count:
                score += 0.15
                evidence.append(f"{metadata_count} metadata file(s)")
            if timestamps:
                score += 0.1
                evidence.append("Internal/filename timestamp evidence")
            if len(group) >= 5:
                score += 0.05

            text_hints = " ".join(
                " ".join(item.notes) for item in group
            ).lower()
            phase = "Unknown"
            if number == 0 or "dqa" in text_hints:
                phase = "DQA candidate"
            elif raw_count and (spectrum_count or act_count):
                phase = "Treatment candidate"

            candidate=SonicationCandidate(
                number=number,
                file_count=len(group),
                categories=dict(categories),
                earliest=timestamps[0] if timestamps else None,
                latest=timestamps[-1] if timestamps else None,
                raw_count=raw_count,
                spectrum_count=spectrum_count,
                act_count=act_count,
                metadata_count=metadata_count,
                likely_phase=phase,
                confidence=min(score, 0.99),
                evidence=evidence,
                unresolved=unresolved,
            )
            policy=self._matching_policy()
            if candidate.confidence>=policy['minimum_sonication_score'] or policy['keep_unknown']:
                output.append(candidate)
        return output

    def _build_sequence_candidates(
        self, files: list[FileEvidence]
    ) -> list[SequenceCandidate]:
        raw_files = [
            item for item in files
            if item.category == "RAW Image" and item.sonication is not None
        ]
        grouped: dict[tuple[int, int, str], list[FileEvidence]] = defaultdict(list)
        for item in raw_files:
            grouped[(item.sonication, item.size, item.matrix_candidate)].append(item)

        sequences: list[SequenceCandidate] = []
        for (sonication, size, matrix), group in sorted(grouped.items()):
            names = " ".join(item.path.lower() for item in group)
            notes = " ".join(" ".join(item.notes).lower() for item in group)
            component = "Unresolved"
            role = "Image sequence candidate"
            score = 0.25

            if matrix:
                score += 0.2
            if len(group) >= 3:
                score += 0.15
            if "memp" in names or "memp" in notes:
                role = "MEMP candidate"
                score += 0.2
            elif "tmap" in names or "tmap" in notes:
                role = "TMAP candidate"
                score += 0.2
            if any(token in names for token in ("phase", "_ph", "-ph")):
                component = "Phase candidate"
                score += 0.1
            elif any(token in names for token in ("magnitude", "_mag", "-mag")):
                component = "Magnitude candidate"
                score += 0.1

            evidence = [
                f"{len(group)} file(s) with identical size",
                f"Matrix candidate: {matrix or 'unresolved'}",
            ]
            signature = f"S{sonication} | {size:,} bytes | {matrix or 'unknown matrix'}"
            candidate=SequenceCandidate(
                sonication=sonication,
                signature=signature,
                file_count=len(group),
                size=size,
                matrix=matrix or "Unknown",
                component_hint=component,
                role_hint=role,
                confidence=min(score, 0.95),
                evidence=evidence,
            )
            policy=self._matching_policy()
            if candidate.confidence>=policy['minimum_sequence_score'] or policy['keep_unknown']:
                sequences.append(candidate)
        return sequences

    def _validate(
        self,
        files: list[FileEvidence],
        sessions: list[SessionCandidate],
        sonications: list[SonicationCandidate],
        sequences: list[SequenceCandidate],
    ) -> list[str]:
        warnings: list[str] = []
        if not sessions:
            warnings.append("No reliable full-date Treatment Session candidate was found.")
        if not sonications:
            warnings.append("No Sonication folder could be reconstructed.")
        unknown = sum(item.category == "Unknown" for item in files)
        if unknown:
            warnings.append(f"{unknown} file(s) remain unclassified.")
        sonication_numbers = [item.number for item in sonications]
        if sonication_numbers:
            expected = set(range(min(sonication_numbers), max(sonication_numbers) + 1))
            missing = sorted(expected - set(sonication_numbers))
            if missing:
                warnings.append(f"Missing Sonication folder number(s): {missing}")
        for sonication in sonications:
            if sonication.raw_count and not any(
                sequence.sonication == sonication.number for sequence in sequences
            ):
                warnings.append(
                    f"Sonication {sonication.number}: RAW exists but no sequence candidate was built."
                )
        return warnings
