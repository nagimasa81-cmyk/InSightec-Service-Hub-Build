# RC3.1.4 test checklist

1. Quick + Loose:
   - Confirm broad file/image candidates appear quickly.
2. Standard + Balanced:
   - Confirm normal MR/RAW/Spectrum matching.
3. Deep + Strict:
   - Confirm weak/unknown matches are excluded from primary views.
4. Deep + Loose:
   - Confirm the maximum number of candidates is retained.
5. Compare the same Sonication at all three Matching Levels.
6. Confirm match score/confidence fields appear in Diagnostics.
7. Confirm Strict does not display unresolved plane/frequency matches as accepted.
8. Confirm Balanced remains the default.
