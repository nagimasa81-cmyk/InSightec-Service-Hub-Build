# RC3 Matching Levels

Matching Level is independent from Analysis Level.

## Loose

Purpose: discovery and recall.

- Wide time windows
- Sonication number may be unknown
- Unknown plane/frequency direction is allowed
- Weak and ambiguous MR/RAW/file candidates remain visible
- Best for finding data that strict rules would miss

## Balanced

Purpose: normal service investigation.

- Uses time, Sonication folder, Series, protocol, plane,
  frequency direction, file size and image evidence together
- Probable and stronger candidates are prioritized
- Ambiguous candidates remain visible but are ranked lower

## Strict

Purpose: verified evidence only.

- Narrow time windows
- Sonication identity required
- Plane and frequency direction must be resolved
- Only strong multi-evidence candidates are accepted
- Rejected/ambiguous candidates remain visible in Diagnostics only

## Independence from Analysis Level

Examples:

- Quick + Loose: fast discovery
- Standard + Balanced: normal default
- Deep + Strict: detailed verified investigation
- Deep + Loose: maximum candidate recovery
