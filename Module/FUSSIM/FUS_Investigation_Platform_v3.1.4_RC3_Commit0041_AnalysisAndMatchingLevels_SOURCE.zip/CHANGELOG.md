# Changelog

## v3.1.4-RC3-PROTOTYPE — Commit0041_AnalysisAndMatchingLevels

- Added independent Loose, Balanced and Strict Matching Levels.
- Matching Level applies to MR Series, RAW Series and independent Core candidates.
- Added match scores, confidence labels and accepted/rejected state.
- Loose mode preserves weak and ambiguous candidates.
- Balanced mode combines multiple evidence types and is the default.
- Strict mode requires stronger evidence and resolved Sonication/geometry.
- Added Matching Level selector to the main toolbar.
- Added Matching Level selector to New Analysis Core.
- Case status shows both Analysis Level and Matching Level.
