# Changelog

## v2.5.0-RC2 — Commit0030_LifecycleTrack_RAWThermometryFallback

- Added a WS/CPC lifecycle track below Operation.
- Detects Boot, Reboot, Shutdown, Logon, Logoff, Application Start and Application Quit.
- Lifecycle markers navigate to the corresponding Operation log rows.
- Added RAW-first thermometry fallback for every Sonication with decodable RAW images.
- Fallback chooses the dominant image matrix and builds a natural-order frame sequence.
- Fallback maps are normalized frame-minus-reference hotspot estimates.
- RAW fallback is explicitly low-confidence and never reports absolute temperature.
- Resolved MEMP/TMAP remains preferred.
