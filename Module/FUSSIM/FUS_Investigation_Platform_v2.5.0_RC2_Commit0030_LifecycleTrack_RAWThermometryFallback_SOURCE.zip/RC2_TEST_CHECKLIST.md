# RC2.5.0 test checklist

- Verify the lower WS/CPC lifecycle track in Operation.
- Confirm lifecycle markers when matching events exist.
- Click lifecycle markers and verify row navigation.
- Select every Sonication with RAW images.
- Confirm unresolved Sonications receive an estimated relative hotspot display.
- Confirm RAW Fallback is labeled low confidence and does not report absolute Celsius.
- Confirm MEMP/TMAP remains preferred when available.
