# FUS Investigation Platform RC2.0

RC2 starts the evidence-first Sonication Decoder Lab. The application no longer assumes that the largest or most image-like RAW series is the correct treatment image.

## Main additions

- Sonication Decoder Lab
- Side-by-side RAW series comparison
- Current frame, baseline difference and histogram
- Cross-series difference and pixel relationship view
- Representative-frame temporal correlation and variation metrics
- Manual role confirmation:
  - Magnitude
  - Phase
  - Temperature Map
  - Thermal Dose
  - Motion / Position Detection
  - Anatomical T2
  - CT / Fusion Support
  - Mask / Geometry
- Decoder Registry saved beside the source ZIP
- Existing Replay, Spectrum, Thermometry, RAW Investigation and DICOM export retained

## Safety rule

A visual RAW candidate is not automatically treated as a verified temperature or treatment image. Decoder Lab confirmation and XML/log evidence are kept separate from the original ZIP.

## Build

Compatible with the supplied RC1 Runtime Complete GitHub Actions workflow.

- Python 3.13
- Entry point: `app.py`
- Build engine: `fast_pyinstaller`
