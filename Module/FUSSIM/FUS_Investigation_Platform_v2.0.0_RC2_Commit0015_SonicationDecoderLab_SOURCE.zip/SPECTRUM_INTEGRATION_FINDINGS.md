# Spectrum integration findings

The supplied `source(3).zip` contains a reusable `fus_spectrum_core` decoder. It was integrated into RC1.8 rather than retaining the previous guessed binary stream decoder.

## Confirmed SpectrumMsg structure

- GZIP-compressed payload
- Message count stored at the beginning
- 4–8 hydrophone channels supported; supplied treatment exports decode as 8 channels
- 24 spectrum slots per message
- 256 FFT bins per slot
- Channel header contains:
  - FFT window duration
  - bin spacing
  - half span
  - frame interval
  - bin count
- Supplied examples decode with approximately:
  - 1.953 kHz/bin
  - ±250 kHz span
  - 1 ms header interval

## New review displays

- Frequency-calibrated MHz axis centered on each Sonication frequency
- Single / overlay / separate / average / maximum-envelope spectra
- Channel spectrum heatmap
- Channel time-frequency spectrogram
- Frame-by-frame broadband activity
- Fundamental, subharmonic and broadband candidate metrics
- Drag-select time interval and average the real FFT frames in that interval

Candidate cavitation metrics are exploratory and are not a clinical Stable/Inertial cavitation diagnosis.
