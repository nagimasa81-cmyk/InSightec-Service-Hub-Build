# Changelog

## v2.0.0-RC2 — Commit0015_SonicationDecoderLab

- Added Sonication Decoder Lab as the primary RC2 investigation feature.
- Added comparison of two RAW image sequences at matched relative frame positions.
- Added baseline difference, cross-series difference, histogram and pixel relationship views.
- Added representative-frame temporal correlation and normalized variation metrics.
- Added manual RAW-series role confirmation.
- Added per-case Decoder Registry sidecar JSON.
- Preserved all previous RC1.9.4 analysis and export functions.
