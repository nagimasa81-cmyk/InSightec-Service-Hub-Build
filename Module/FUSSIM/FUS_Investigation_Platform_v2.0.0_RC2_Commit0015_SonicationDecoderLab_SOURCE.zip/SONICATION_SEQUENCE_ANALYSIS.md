# Supplied Sonication Folder Set Analysis

- Sonication folders: [1, 2, 3, 4, 5, 6, 7, 8]
- Total files: 750
- RAW files: 585

## Largest RAW sequences
- Field/Sub/Zone 16/1/0: 153 frames
- Field/Sub/Zone 19/1/0: 44 frames
- Field/Sub/Zone 20/1/0: 44 frames
- Field/Sub/Zone 21/1/0: 44 frames
- Field/Sub/Zone 7/1/0: 23 frames
- Field/Sub/Zone 12/1/0: 21 frames
- Field/Sub/Zone 8/1/0: 21 frames
- Field/Sub/Zone 6/8/0: 15 frames
- Field/Sub/Zone 5/8/3: 14 frames
- Field/Sub/Zone 6/7/0: 13 frames
- Field/Sub/Zone 5/7/3: 12 frames
- Field/Sub/Zone 6/1/0: 11 frames
- Field/Sub/Zone 6/2/0: 11 frames
- Field/Sub/Zone 6/3/0: 11 frames
- Field/Sub/Zone 5/1/3: 10 frames
- Field/Sub/Zone 5/2/3: 10 frames
- Field/Sub/Zone 5/3/3: 10 frames
- Field/Sub/Zone 6/6/0: 10 frames
- Field/Sub/Zone 5/6/3: 9 frames
- Field/Sub/Zone 6/5/0: 8 frames

## RAW sizes
- 524,288 bytes: 358 files
- 131,072 bytes: 111 files
- 262,144 bytes: 84 files
- 65,536 bytes: 8 files
- 0 bytes: 8 files
- 3,528 bytes: 4 files
- 4,232 bytes: 2 files
- 4,600 bytes: 2 files
- 4,968 bytes: 2 files
- 5,800 bytes: 2 files
- 5,400 bytes: 2 files
- 6,696 bytes: 2 files

## Interpretation guardrails

- Repeated Field 5 and Field 6 streams are strong thermometry-pair candidates, but phase versus magnitude identity is not asserted without XML/log evidence.
- 512×512-equivalent streams can contain anatomical, planning, fusion, motion or supporting images and are retained as separate sequences.
- Stage timing is shown as estimated when explicit SBAT/mrserver/WS timing is not available.