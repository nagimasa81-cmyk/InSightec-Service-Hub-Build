# Context Refresh Isolation HotFix

## Root cause

The RC1.9 selection event reached the table, but one failing decoder or chart update could abort the central refresh before fixed details and later panels were updated. The screen therefore continued to show Sonication 0 even when another table row was highlighted.

## Changes

- Store the Sonication ID in column 0 using Qt UserRole.
- Resolve selection by Sonication ID rather than a potentially stale filtered row index.
- Force the same refresh route for click, current-cell change, selection change, Previous and Next.
- Update fixed details and text evidence before binary decoders and plotting.
- Isolate every panel update with independent error handling.
- Continue updating other panels if MR, thermometry, spectrum or hydrophone decoding fails.
- Display a diagnostic message inside a failed chart and append details to Raw Evidence.
- Force idle redraw of all canvases after each context change.
