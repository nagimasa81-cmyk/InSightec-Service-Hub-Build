# Changelog

## v1.7.0-RC1 — Commit0012_DeepZipRawSeriesResolver

- Added exact RAW filename index parsing.
- Linked RAW field/zone/array values to `MriImageParams.xml` for the same Sonication.
- Added direction-cosine plane resolution and oblique-angle evidence.
- Added TMAP/MEMP thermometry-series classification.
- Added RAW Series Resolver table.
- Thermometry Replay now prioritizes XML-mapped thermometry series.
- Replay representative image now reports field, protocol, XML coverage, and resolver source.
- Improved large ZIP loading by avoiding unnecessary decompression during inventory.
- Added staged import progress.
- Preserved Treatment-first filtering, DQA toggle, multi-channel Spectrum, interval FFT, and fixed Sonication details.

## v1.8.0-RC1 — Commit0013_ExactSpectrumCavitationAnalyzer

- Integrated the supplied `fus_spectrum_core` package.
- Replaced guessed SpectrumMsg stream decoding with structural parsing.
- Added exact message/channel/bin/header metadata display.
- Added MHz frequency axis centered on Sonication frequency.
- Added actual FFT-frame time-frequency spectrogram.
- Added channel heatmap and frame metrics timeline.
- Added fundamental, subharmonic and broadband candidate analysis.
- Drag selection now averages actual FFT frames in the selected time interval.
- Preserved 4–8 channel checkbox selection.
