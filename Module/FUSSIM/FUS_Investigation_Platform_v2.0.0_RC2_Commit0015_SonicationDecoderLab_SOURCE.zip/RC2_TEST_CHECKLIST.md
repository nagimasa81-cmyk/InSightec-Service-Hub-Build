# RC2.0 Test Checklist

- Open the full treatment ZIP.
- Open the Sonication-only ZIP.
- Confirm Sonication Decoder Lab lists Field/Sub/Zone series.
- Select different series and verify all six analysis panels update.
- Select a comparison series and verify cross-series comparison appears.
- Move the frame slider and verify the selected frame changes.
- Confirm a role and save Decoder Registry.
- Reopen the same ZIP and confirm the saved role is restored.
- Confirm the treatment ZIP itself is unchanged.
- Confirm existing RAW Investigation DICOM export still works.
- Confirm Spectrum and Replay tabs still open without blocking Decoder Lab.
