from __future__ import annotations
from pathlib import Path
import re, shutil, tempfile, zipfile
from .models import DiscoveredStudy, SonicationSet

SPECTRUM_EXTENSIONS = ('.dmp', '.dump', '.gz')
SONICATION_RE = re.compile(r'^sonication\s*[_-]?(\d+)$', re.I)

def _safe_extract(zf: zipfile.ZipFile, destination: Path) -> None:
    base = destination.resolve()
    for info in zf.infolist():
        target = (destination / info.filename).resolve()
        if base not in target.parents and target != base:
            raise ValueError(f"Unsafe ZIP member: {info.filename}")
    zf.extractall(destination)

def _collapse_single_root(root: Path) -> Path:
    children = [p for p in root.iterdir() if p.name != '__MACOSX']
    return children[0] if len(children) == 1 and children[0].is_dir() else root

def _is_spectrum(p: Path) -> bool:
    n = p.name.lower()
    return n.startswith('spectrummsg') and n.endswith(SPECTRUM_EXTENSIONS)

def _find_cpc_root(root: Path) -> Path | None:
    direct = root / 'CPCFiles'
    if direct.is_dir(): return direct
    matches = [p for p in root.rglob('*') if p.is_dir() and p.name.lower() == 'cpcfiles']
    return sorted(matches, key=lambda p: (len(p.parts), str(p).lower()))[0] if matches else None

def _ini_roots(cpc: Path | None, root: Path) -> list[Path]:
    candidates: list[Path] = []
    if cpc:
        for rel in [('Site','Ini'), ('Ini',), ('App','Ini')]:
            p = cpc.joinpath(*rel)
            if p.is_dir(): candidates.append(p)
    for p in root.rglob('*'):
        if p.is_dir() and p.name.lower() == 'ini' and p not in candidates:
            candidates.append(p)
    return candidates

def discover_input(path: str | Path) -> DiscoveredStudy:
    source = Path(path).expanduser().resolve()
    if not source.exists(): raise FileNotFoundError(source)
    temporary = False
    if source.is_file() and zipfile.is_zipfile(source):
        extract = Path(tempfile.mkdtemp(prefix='fus_export_'))
        temporary = True
        with zipfile.ZipFile(source) as zf: _safe_extract(zf, extract)
        root = _collapse_single_root(extract)
    elif source.is_dir(): root = source
    elif source.is_file(): root = source.parent
    else: raise ValueError(f'Unsupported input: {source}')

    cpc = _find_cpc_root(root)
    ini_roots = _ini_roots(cpc, root)
    all_files = [p for p in root.rglob('*') if p.is_file()]
    if source.is_file() and not zipfile.is_zipfile(source) and source not in all_files:
        all_files.insert(0, source)

    geometry = sorted({p for r in ini_roots for p in r.rglob('*.ini') if p.name.lower().startswith('xdgeometry_')}, key=lambda p: str(p).lower())
    xd_files = sorted({p for r in ini_roots for p in r.rglob('*.ini') if re.match(r'^xd_[^/\\]+\.ini$', p.name, re.I)}, key=lambda p: str(p).lower())
    if not geometry:
        geometry = sorted([p for p in all_files if p.name.lower().startswith('xdgeometry_') and p.suffix.lower()=='.ini'], key=lambda p: str(p).lower())
    if not xd_files:
        xd_files = sorted([p for p in all_files if re.match(r'^xd_[^/\\]+\.ini$', p.name, re.I)], key=lambda p: str(p).lower())

    scan_root = cpc if cpc else root
    sonications: list[SonicationSet] = []
    sonication_dirs: set[Path] = set()
    for p in scan_root.rglob('*'):
        if not p.is_dir(): continue
        m = SONICATION_RE.match(p.name)
        if not m: continue
        sonication_dirs.add(p)
        files = [f for f in p.rglob('*') if f.is_file()]
        spectra = sorted([f for f in files if _is_spectrum(f)], key=lambda x: str(x).lower())
        related = sorted([f for f in files if not _is_spectrum(f) and any(k in f.name.lower() for k in ('reply','replay','temperature','acquisition','vimeasure','spectrum'))], key=lambda x: str(x).lower())
        sonications.append(SonicationSet(p.name, int(m.group(1)), p, spectra, related))
    sonications.sort(key=lambda s: (s.number if s.number is not None else 10**9, s.name.lower()))

    assigned = {p.resolve() for s in sonications for p in s.spectrum_files}
    unassigned = sorted([p for p in all_files if _is_spectrum(p) and p.resolve() not in assigned], key=lambda p: str(p).lower())
    others = sorted([p for p in all_files if any(k in p.name.lower() for k in ('treatment','vimeasure','temperature','acquisition','replay'))], key=lambda p: str(p).lower())
    return DiscoveredStudy(root, source, cpc is not None, cpc, ini_roots, geometry, xd_files, sonications, unassigned, others, temporary)
