from __future__ import annotations
from pathlib import Path
import configparser
import math
import re
from .models import HydrophonePosition, XdParameters


def clock_to_angle(clock_text: str) -> float:
    h, m = clock_text.strip().split(":", 1)
    hours = (int(h) % 12) + int(m) / 60.0
    # 12 o'clock = +90 degrees, clockwise rotation.
    return 90.0 - hours * 30.0


def parse_geometry(path: str | Path) -> list[HydrophonePosition]:
    p = Path(path)
    text = p.read_text(encoding="utf-8", errors="replace")
    in_section = False
    last_comment = ""
    positions: list[HydrophonePosition] = []
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith("["):
            in_section = line.upper() == "[ADDITIONAL_CHANNELS]"
            continue
        if not in_section:
            continue
        if line.startswith(";"):
            value = line[1:].strip()
            if value and not value.lower().startswith(("channel", "=", "3d", "x")):
                last_comment = value
            continue
        m = re.match(r"CH(\d+)\s*=\s*([^\s]+)\s+([-+\d.eE]+)\s+([-+\d.eE]+)\s+([-+\d.eE]+)\s+([-+\d.eE]+)", line, re.I)
        if not m:
            continue
        ch = int(m.group(1)); clock = m.group(2)
        x, y, z, area = map(float, m.groups()[2:])
        try:
            angle = clock_to_angle(clock)
        except Exception:
            angle = None
        positions.append(HydrophonePosition(channel=ch, label=last_comment or f"CH{ch}", x=x, y=y, z=z, area_mm2=area, clock_text=clock, angle_deg=angle, source="geometry-ini"))
        last_comment = ""
    return sorted(positions, key=lambda x: x.channel)


def parse_xd_parameters(path: str | Path) -> XdParameters:
    p = Path(path)
    cfg = configparser.ConfigParser(inline_comment_prefixes=(";", "#"), strict=False)
    cfg.optionxform = str
    cfg.read(p, encoding="utf-8")
    out = XdParameters(source_file=p)
    if cfg.has_section("GENERAL_INFO"):
        sec = cfg["GENERAL_INFO"]
        out.serial_number = sec.get("SerialNumber")
        out.xd_type = sec.get("Type")
        try: out.acoustic_power_limit = float(sec.get("AcousticPowerLimit", "nan"))
        except ValueError: pass
    if cfg.has_section("AVAILABLE_FREQUENCIES"):
        sec = cfg["AVAILABLE_FREQUENCIES"]
        rows = []
        for key, val in sec.items():
            if not key.upper().startswith("FREQ"):
                continue
            parts = val.split()
            if not parts:
                continue
            try:
                hz = float(parts[0]); enabled = int(float(parts[3])) if len(parts) > 3 else 1
            except ValueError:
                continue
            rows.append((int(re.sub(r"\D", "", key) or 0), hz, enabled))
        rows.sort()
        out.all_frequencies_hz = [r[1] for r in rows]
        out.enabled_frequencies_hz = [r[1] for r in rows if r[2] != 0]
        if out.enabled_frequencies_hz:
            # The INI does not explicitly identify the treatment frequency.
            # Use the median enabled value as a neutral display default.
            vals = sorted(out.enabled_frequencies_hz)
            out.preferred_frequency_hz = vals[len(vals)//2]
    return out
