from .models import HydrophonePosition

# Standard layout from the supplied XD photograph.
# Display coordinates preserve inner Cap RCV (CH0-3) and outer Tile RCV (CH4-7).
def default_hydrophone_layout() -> list[HydrophonePosition]:
    coords={
      0:(-0.55, 0.48,'cap0'), 1:(0.55,0.48,'cap1'),
      2:(0.55,-0.48,'cap2'), 3:(-0.55,-0.48,'cap3'),
      4:(-0.72,0.82,'tile4'), 5:(0.72,0.82,'tile5'),
      6:(0.72,-0.82,'tile6'), 7:(-0.72,-0.82,'tile7')}
    return [HydrophonePosition(ch,label,x,y,0.0,None,'',None,'default-photo') for ch,(x,y,label) in coords.items()]
