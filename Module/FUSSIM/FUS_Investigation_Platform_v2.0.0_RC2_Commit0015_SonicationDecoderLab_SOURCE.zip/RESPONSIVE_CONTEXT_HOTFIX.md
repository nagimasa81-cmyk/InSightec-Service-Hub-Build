# Responsive Context Freeze HotFix

## Symptom

Selecting another Sonication could leave the application showing the busy cursor and appear frozen.

## Root cause

Each selection synchronously rebuilt all expensive panels on the GUI thread:

- MR / RAW reconstruction
- Thermometry series preparation
- SpectrumMsg decoding
- Hydrophone / cavitation charts

The refresh route also called `QApplication.processEvents()`, allowing table-selection signals to re-enter the same refresh while it was still running.

## Fix

- Debounce rapid selection changes with a single-shot `QTimer`.
- Cancel superseded refresh requests and process only the latest selection.
- Refresh fixed details and lightweight evidence first.
- Decode only the currently visible heavy tab.
- Refresh another heavy panel only when its tab is opened.
- Remove `processEvents()` from Sonication context refresh to prevent re-entrant selection loops.
- Preserve independent panel error handling from RC1.9.1.
