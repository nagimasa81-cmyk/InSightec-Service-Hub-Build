# RC1.9 Synchronized Context Engine

## Fixed regression

Changing the Sonication in the upper-left table could leave the fixed details,
MR replay, Thermometry, Spectrum and Hydrophone panels on the previous
Sonication. The table selection signal was not guaranteed to fire after list
repopulation or when selecting an already-current cell.

## New update route

Every selection source now uses the same route:

- mouse row click
- current-cell change
- selection-model change
- Previous / Next
- Show DQA filter rebuild
- phase / geometry / MR mapping change

The route sets a stable `current_sonication_no` context and then refreshes:

1. MR geometry mapping
2. MR/Hotspot replay
3. Thermometry sequence
4. Hydrophone activity
5. Spectrum
6. fixed details
7. maximum information
8. timeline, synchronization, evidence and coverage
9. all Matplotlib canvases

Qt table signals are blocked only while rows are rebuilt. A forced explicit
context refresh follows row restoration, so the UI no longer depends on Qt
emitting `currentCellChanged`.
