# RC1.8.1 Spectrum Regression HotFix

RC1.8 replaced the RC1.7 compatibility spectrum path with the exact SpectrumMsg parser. This caused data to disappear where an exact SpectrumMsg was absent, incomplete, or unsupported.

RC1.8.1 changes the design to additive decoding:

1. Exact SpectrumMsg parser
2. Legacy real-payload multi-channel candidate decoder
3. Matched Spectrum_*.dmp_FFT decoder
4. Unavailable only when all real-data paths fail

No simulated acoustic data are used. The previously available Relative Cavitation Bands view is restored.
