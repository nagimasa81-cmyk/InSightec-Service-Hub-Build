# Deep ZIP Analysis Findings

Generated from the two supplied treatment ZIPs. These findings are used by the RC1.7 resolver.

## 2026 sample
- ZIP members: 2026
- Sonication folders: 13 (1–13)
- MriImageParams rows: 724

### Sonication 1
- Field 2, zone 3: `MEMP`, 256x256, frequency direction `COL`, arrays 1
- Field 5, zone 3: `MEMP`, 256x256, frequency direction `COL`, arrays 9
- Field 6, zone 0: `MEMP`, 256x256, frequency direction `COL`, arrays 10
- Field 7, zone 0: `tse_T2w_tra`, 256x256, frequency direction `ROW`, arrays 19
- Field 8, zone 0: `tse_T2w_cor`, 256x256, frequency direction `ROW`, arrays 19
- Field 12, zone 0: `tse_T2w_sag`, 320x320, frequency direction `ROW`, arrays 19
- Field 16, zone 0: `1.25mm`, 512x512, frequency direction `Unknown`, arrays 144
- Field 19, zone 0: `AXL T2 STIR`, 320x320, frequency direction `ROW`, arrays 27
- Field 20, zone 0: `COR T2 MRgFUS P`, 320x320, frequency direction `ROW`, arrays 45
- Field 21, zone 0: `SAG T2 MRgFUS P`, 320x320, frequency direction `ROW`, arrays 45
- Field 28, zone 0: `MEMP`, 256x256, frequency direction `COL`, arrays 1
- Field 33, zone 0: `MEMP`, 256x256, frequency direction `COL`, arrays 1
- Field 34, zone 3: `MEMP`, 256x256, frequency direction `COL`, arrays 1

### Sonication 2
- Field 2, zone 3: `MEMP`, 256x256, frequency direction `COL`, arrays 1
- Field 5, zone 3: `MEMP`, 256x256, frequency direction `COL`, arrays 10
- Field 6, zone 0: `MEMP`, 256x256, frequency direction `COL`, arrays 11
- Field 28, zone 0: `MEMP`, 256x256, frequency direction `COL`, arrays 1
- Field 33, zone 0: `MEMP`, 256x256, frequency direction `COL`, arrays 1
- Field 34, zone 3: `MEMP`, 256x256, frequency direction `COL`, arrays 1

### Sonication 3
- Field 2, zone 3: `MEMP`, 256x256, frequency direction `ROW`, arrays 1
- Field 5, zone 3: `MEMP`, 256x256, frequency direction `ROW`, arrays 10
- Field 6, zone 0: `MEMP`, 256x256, frequency direction `ROW`, arrays 11
- Field 28, zone 0: `MEMP`, 256x256, frequency direction `ROW`, arrays 1
- Field 33, zone 0: `MEMP`, 256x256, frequency direction `ROW`, arrays 1
- Field 34, zone 3: `MEMP`, 256x256, frequency direction `ROW`, arrays 1

## 2025 sample
- ZIP members: 1075
- Sonication folders: 5 (1–5)
- MriImageParams rows: 152

### Sonication 1
- Field 2, zone 3: `TMAP-ME`, 256x256, frequency direction `ROW`, arrays 1
- Field 5, zone 3: `TMAP-ME`, 256x256, frequency direction `ROW`, arrays 10
- Field 6, zone 0: `TMAP-ME`, 256x256, frequency direction `ROW`, arrays 11
- Field 7, zone 0: `DQA-Axial`, 256x256, frequency direction `COL`, arrays 11
- Field 8, zone 0: `DQA-Coronal`, 256x256, frequency direction `ROW`, arrays 11
- Field 12, zone 0: `DQA-Sagittal`, 256x256, frequency direction `ROW`, arrays 11
- Field 28, zone 0: `TMAP-ME`, 256x256, frequency direction `ROW`, arrays 1
- Field 34, zone 3: `TMAP-ME`, 256x256, frequency direction `ROW`, arrays 1

### Sonication 2
- Field 2, zone 3: `TMAP-ME`, 256x256, frequency direction `COL`, arrays 1
- Field 5, zone 3: `TMAP-ME`, 256x256, frequency direction `COL`, arrays 10
- Field 6, zone 0: `TMAP-ME`, 256x256, frequency direction `COL`, arrays 11
- Field 28, zone 0: `TMAP-ME`, 256x256, frequency direction `COL`, arrays 1
- Field 34, zone 3: `TMAP-ME`, 256x256, frequency direction `COL`, arrays 1

### Sonication 3
- Field 2, zone 3: `TMAP-ME`, 256x256, frequency direction `COL`, arrays 1
- Field 5, zone 3: `TMAP-ME`, 256x256, frequency direction `COL`, arrays 10
- Field 6, zone 0: `TMAP-ME`, 256x256, frequency direction `COL`, arrays 11
- Field 28, zone 0: `TMAP-ME`, 256x256, frequency direction `COL`, arrays 1
- Field 34, zone 3: `TMAP-ME`, 256x256, frequency direction `COL`, arrays 1
