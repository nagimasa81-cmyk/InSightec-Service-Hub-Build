# RAW Investigation DICOM Export

The export uses the exact same best-candidate decoder as the RAW Investigation preview. Each successful 2-D candidate is written as an anonymized DICOM Secondary Capture object.

## Output

```text
Selected folder/
  Sonication1/
    5-1-3-0.dcm
    ...
  Unassigned/
    ...
  RAW_DICOM_EXPORT_REPORT.txt
```

Files that cannot be decoded are skipped. The report records the reason. Exported pixels are percentile-normalized unsigned 16-bit values for investigation/review and must not be treated as original quantitative phase, temperature, dose, or diagnostic pixel values.
