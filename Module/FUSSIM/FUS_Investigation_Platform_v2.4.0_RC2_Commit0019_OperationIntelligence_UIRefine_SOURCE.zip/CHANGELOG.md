# Changelog

## v2.4.0-RC2 — Commit0019_OperationIntelligence_UIRefine

- Replaced the visible Sonication table with a compact Sonication dropdown.
- Selected Sonication details are collapsed by default.
- MR Geometry Mapping is collapsed by default.
- Reduced chart-title size and added a light header background.
- Show DQA now removes DQA from Timeline, Synchronized Analysis and Operation views.
- Timeline horizontal axis now uses clock time rather than seconds from midnight.
- Added Operation tab for Treatment Exam-linked WS/workstation logs.
- Categorizes operator actions and software events into Planning, Registration, Tracking, MRI, Treatment, Thermometry, Acoustic, Cooling, Data, Warning and Error.
- Added Operation timeline, category/search filters and double-click navigation to the nearest Sonication.
- Preserved interactive zoom, pan, reset and synchronized analysis.
