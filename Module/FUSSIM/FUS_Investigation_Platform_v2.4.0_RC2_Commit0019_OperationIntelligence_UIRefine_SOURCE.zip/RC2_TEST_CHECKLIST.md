# RC2.4 test checklist

- Open a Treatment ZIP and confirm Sonication selection uses the dropdown.
- Confirm Selected Sonication details and MR Geometry Mapping start collapsed.
- Change the Sonication dropdown and confirm all open analysis tabs update.
- Leave Show DQA disabled and confirm no DQA entries appear in Timeline, Synchronized Analysis or Operation.
- Enable Show DQA and confirm DQA returns.
- Confirm Timeline x-axis uses HH:MM or HH:MM:SS.
- Open Operation and test category and search filters.
- Double-click an Operation row and confirm selection moves to the nearest Sonication.
- Test chart wheel zoom, pan, double-click reset, Reset View and Reset All.
- Confirm unrelated Exam logs remain excluded by Exam Explorer.
