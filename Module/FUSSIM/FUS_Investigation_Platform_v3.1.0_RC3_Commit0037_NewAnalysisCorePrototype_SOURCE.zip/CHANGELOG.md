# Changelog

## v3.1.0-RC3-PROTOTYPE — Commit0037_RC3NewAnalysisCorePrototype

- Added an independent New Analysis Core workspace.
- Added direct ZIP package inventory without consuming legacy parser results.
- Added full-date and competing-year analysis to isolate unrelated sessions.
- Added evidence-based Treatment Session candidates.
- Added zero-based Sonication reconstruction using folder, RAW, Spectrum, ACT and metadata evidence.
- Added explicit confidence, evidence and unresolved fields.
- Added RAW sequence candidates by Sonication, byte size and inferred matrix.
- MEMP/TMAP and Magnitude/Phase are treated as evidence hints, not forced conclusions.
- Preserved all previous workspaces and Diagnostics for comparison.
