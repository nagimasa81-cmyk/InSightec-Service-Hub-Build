# RC3.1.3 test checklist

1. Select Quick, load a ZIP and confirm the Sonication screen appears quickly.
2. While the app is analyzing, open/move/copy the original ZIP in Explorer.
3. Load a folder by clicking the drop area and selecting a folder.
4. Confirm the source folder is not held after the working snapshot is created.
5. Select Standard and confirm RAW Series and normal review data appear.
6. Select Deep and confirm all diagnostic analysis remains available.
7. Confirm the status changes from `Rendering views...` to `Ready`.
8. Confirm New Analysis Core runs at Quick, Standard and Deep levels.
9. Close the application and confirm its temporary working folder is removed.
