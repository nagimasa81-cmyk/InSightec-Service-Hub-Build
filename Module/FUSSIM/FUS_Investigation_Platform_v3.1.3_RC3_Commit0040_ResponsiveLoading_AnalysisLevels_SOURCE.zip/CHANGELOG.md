# Changelog

## v3.1.3-RC3-PROTOTYPE — Commit0040_ResponsiveLoadingAnalysisLevels

- Added Quick, Standard and Deep analysis levels.
- Added the same three levels to RC3 New Analysis Core.
- Treatment ZIPs are copied to a temporary working cache before analysis.
- Treatment folders are snapshotted into a temporary working ZIP.
- The original ZIP/folder is released and remains available in Windows Explorer.
- The first Sonication screen is displayed before optional heavy views.
- Remaining panels are refreshed in short QTimer stages.
- A failure in one optional panel no longer stops the remaining screen updates.
- Quick mode skips deep RAW, sequence, MR synchronization and Operation scans.
- Standard mode limits the most expensive scans and omits deep sequence/decoder views.
- Deep mode retains the full current analysis.
