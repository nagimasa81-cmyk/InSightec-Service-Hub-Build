# RC3 Analysis Levels

## Quick

Purpose: immediate package preview.

- ZIP/folder inventory from member metadata
- Summary/Sonication folder reconstruction
- Basic Sonication list
- Basic Timeline and Dashboard
- No deep RAW series resolution
- No sequence reconstruction
- No large log correlation

## Standard

Purpose: normal service review.

- Complete inventory
- Sonication metadata
- RAW series resolution
- Treatment Exam review matching
- Limited synchronization and Operation source scans
- No deep image-sequence resolver/decoder laboratory during initial load

## Deep

Purpose: detailed investigation.

- Full current analysis
- Complete RAW and sequence resolution
- Full synchronization evidence
- Full Operation intelligence
- All diagnostic tables

The selected level is displayed in the case status line.
