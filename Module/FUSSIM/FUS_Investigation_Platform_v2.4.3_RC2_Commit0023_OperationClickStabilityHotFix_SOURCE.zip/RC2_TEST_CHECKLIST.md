# RC2.4.3 test checklist

- Open an Operation view containing several thousand events.
- Single-click a marker and confirm the matching row is selected after a short delay.
- Double-click a marker and confirm the chart resets without jumping to a row.
- Confirm the application does not remain busy after double-click.
- Drag horizontally and confirm zoom still works.
- Double-click after zoom and confirm the full range returns.
- Repeatedly click the same marker and confirm no prolonged processing occurs.
- Confirm filters, search, column menus, MR Series viewer and ZIP loading remain functional.
