# MR Series Load HotFix

RC2.4.2 referenced `row_role` before it was assigned. The catalog now classifies
the XML row first and then applies TMAP/MEMP component logic.

Every RAW candidate is isolated. Invalid names, missing ZIP entries, malformed
metadata and unsupported image payloads are skipped while the remaining
Treatment Exam Series continue loading.
