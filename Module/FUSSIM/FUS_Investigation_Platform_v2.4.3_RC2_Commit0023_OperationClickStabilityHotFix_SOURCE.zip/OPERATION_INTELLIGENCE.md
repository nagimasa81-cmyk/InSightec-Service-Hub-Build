# Operation Intelligence

Only logs accepted by the Treatment Exam Resolver are used in the normal Operation view.

## Categories

- Planning: SDR, calcification, NPR, target and preplan
- Registration: CT/MR fusion and registration
- Tracking: XD/position/motion detection
- MRI: protocol load, scan, acquisition and reconstruction
- Treatment: Treat Low/High, sonication start/stop, pause and continue
- Thermometry: TMAP, MEMP, phase and temperature workflow
- Acoustic: Spectrum, Hydrophone, Cavitation and Reflection
- Cooling: post-sonication and cooling workflow
- Data: patient load, retrieve, import, save and export
- Warning / Error

Events are linked to the nearest Sonication only when the time gap is within three minutes.
DQA-linked events are hidden whenever Show DQA is disabled.
