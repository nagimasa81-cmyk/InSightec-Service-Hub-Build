# Operation Click Stability HotFix

- Single click: select and center the matching row after a short confirmation delay.
- Horizontal drag: zoom the time range.
- Double-click: cancel pending row navigation and reset the chart only.

The table is not regenerated during chart navigation.
