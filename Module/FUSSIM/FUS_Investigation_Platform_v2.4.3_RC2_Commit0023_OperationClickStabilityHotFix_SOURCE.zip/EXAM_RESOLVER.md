# Treatment Exam Resolver

## Authoritative anchor

The resolver starts with MR rows explicitly linked to a Sonication in `MriImageParams.xml`. The following identifiers are collected:

1. Exam UID (`imgexamuid`)
2. Exam number (`imgexamnum`)
3. treatment date/time
4. MR series number and series UID
5. protocol / series description
6. Sonication index

## review.out acquisition scoring

Positive evidence includes:

- treatment date match
- series number present in Sonication-linked MR metadata
- protocol / series description match
- TMAP or MEMP thermometry role
- FUS tracking / calibration workflow role
- coil match
- timestamp near a Sonication

A date mismatch receives a strong negative score. Only **Included** acquisitions are exposed to automatic MR matching and Replay.

## Logs

When Exam UID or Exam number is unavailable in a text log, the log must contain event timestamps overlapping the actual Sonication session. Merely being present in the ZIP is not sufficient.

## Source policy

- Included: used by Replay and automated analysis
- Review: visible in Exam Explorer; not used automatically
- Excluded: evidence only; never used for treatment calculations
