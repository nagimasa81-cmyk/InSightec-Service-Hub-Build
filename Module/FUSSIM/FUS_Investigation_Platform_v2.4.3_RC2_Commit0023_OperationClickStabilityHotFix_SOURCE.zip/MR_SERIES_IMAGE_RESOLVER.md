# MR Series Image Resolver

## Ordering

Within the Treatment Exam, Series Number is treated as the MRI acquisition order.

## Classification

Series Description and Protocol classify:

- Calibration Acquisition
- XD Position / Motion Detection
- Anatomical / Reference MRI
- Treatment MRI
- TMAP / MEMP Thermometry Compound Series

TMAP/MEMP can contain:

- Magnitude / anatomy images
- Phase images
- Temperature calculation products
- Temperature display images
- Dose, mask or overlay products

## Image matching

1. Exact Treatment Exam
2. Exact Series Number
3. Series Description / Protocol
4. Thermometry or tracking role
5. Coil
6. Plane
7. Frequency direction

An image is not shown when no sufficiently linked RAW group exists.
