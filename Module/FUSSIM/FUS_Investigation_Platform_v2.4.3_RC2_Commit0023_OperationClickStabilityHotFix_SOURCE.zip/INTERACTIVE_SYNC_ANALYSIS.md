# Interactive synchronized analysis

## Common time model

SpectrumMsg generally has much higher time resolution than MR thermometry. The tool therefore
links many Spectrum frames to one TMAP/MEMP acquisition window rather than forcing a one-to-one match.

Link priority:

1. Included Treatment Exam
2. Same Sonication folder
3. TMAP/MEMP acquisition
4. MR Series and protocol match
5. Corrected FUS/MR timing evidence
6. Estimated acquisition interval only when exact frame timestamps are absent

Estimated windows are explicitly labeled and do not become confirmed evidence automatically.

## Chart controls

- Mouse wheel: zoom at cursor
- Middle/right drag: pan
- Double-click: reset view
- Reset View: restore the current chart
- Reset All: restore time cursor, selected range, channels and display controls
