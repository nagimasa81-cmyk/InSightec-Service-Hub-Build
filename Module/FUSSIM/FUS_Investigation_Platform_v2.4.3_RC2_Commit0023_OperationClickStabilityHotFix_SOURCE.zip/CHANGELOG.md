# Changelog

## v2.4.3-RC2 — Commit0023_OperationClickStabilityHotFix

- Fixed Operation chart double-click triggering both row navigation and reset.
- Single-click navigation is delayed briefly and cancelled when a double-click is detected.
- Double-click now performs chart reset only.
- SpanSelector is temporarily disabled during double-click reset.
- Tiny click movements no longer trigger time-range zoom.
- Marker navigation updates only table selection and scroll position.
- Operation table and chart are not rebuilt during marker navigation.
- Nearest-row search is limited to the clicked category before fallback.
- Repeated clicks on the already-selected marker no longer repeat expensive selection work.
- Preserves MR Series Load HotFix and Treatment Exam filtering.
