# FUS Investigation Platform RC2.2

## Treatment Exam Resolver

RC2.2 no longer treats every `review.out`, `mrserver.log`, MR series, or synchronization log in the ZIP as treatment data.

The treatment Exam anchor is built primarily from Sonication-linked rows in `MriImageParams.xml`:

- `imgexamuid`
- `imgexamnum`
- treatment date and time
- Sonication index
- MR series number and UID
- protocol / series description

Each external source is then classified as:

- **Included** — sufficiently linked to the treatment Exam
- **Review** — possibly related, but not automatically used
- **Excluded** — not passed to Replay or analysis

`review.out` is evaluated per acquisition block rather than accepted as a whole file. Date, series number, TMAP/MEMP role, coil, protocol and Sonication-time proximity are combined. If no acquisition reaches the required confidence, no `review.out` series is automatically linked.

## Exam Explorer

The new **Exam Explorer** tab shows:

- resolved treatment Exam UID and Exam number
- treatment date and time
- treatment-linked series numbers
- included and excluded `review.out` acquisitions
- filtered log and binary sources
- score and exact inclusion/exclusion reasons

Excluded sources remain available only for investigation and do not contaminate Replay, synchronization, MR geometry or thermometry selection.

## Existing RC2 functionality retained

- TMAP/MEMP thermometry classification
- 1.5T `FUS 2ch Head` and 3T `Body` thermometry coil rules
- `FUS ... Tracking` XD position-detection classification
- Calibration acquisition classification
- collapsible protocol summary and adjustable RAW Investigation splitters
- Sonication Decoder Lab and Decoder Registry
- Spectrum / multi-hydrophone analysis
- RAW-to-DICOM export

## Build

Compatible with the supplied RC1/RC2 GitHub Actions workflow.
