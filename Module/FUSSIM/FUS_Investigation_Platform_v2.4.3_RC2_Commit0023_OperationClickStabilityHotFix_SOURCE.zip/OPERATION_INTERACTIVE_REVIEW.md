# Operation Interactive Review

## Chart
- Click event: jump to matching row.
- Left drag: zoom time range.
- Double-click: reset.
- Mouse wheel and middle/right drag: zoom and pan.

## Table
- Wrapped full text and automatic row height.
- Hover for complete cell tooltip.
- Right-click header/cell for filter, search, hide and column controls.
- Columns button toggles all fields.
