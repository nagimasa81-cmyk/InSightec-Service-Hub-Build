Tracker SNR Analyzer - FUS Comparison Source

Implemented in this release
- Drag and drop: individual files, multiple files, folders, and ZIP archives.
- ZIP discovery: extracts .log/.txt targets only and ignores unrelated files.
- Folder discovery: selected folder plus five levels below it.
- Multiple-file comparison in chronological order.
- Four separate graphs: Tracker 0, 1, 2, and 3.
- Each tracker graph displays Scan 0, 1, 2, and 3 as separate curves.
- SNR, Signal, and Noise metric selection.
- FUS-style dark-blue header and blue-gray analysis workspace.
- Latest-file SNR matrix and chronological source summary.
- Project and Excel export compatibility retained.

Input behavior
- Supported direct files: .log and .txt
- Supported archive: .zip
- Nested ZIP files are intentionally not expanded in this release.
- Files without valid Tracker SNR rows are reported as skipped.
- Time order is determined from YYYY_Mmm_DD_HH_MM_SS in the filename, with file modified time as fallback.

Build
1. Place this source ZIP in the GitHub module folder and extract it.
2. Run 00_BUILD_EXE_RECOMMENDED_PYINSTALLER.bat.
3. Output EXE: dist\TrackerSNR_CLEAN_EXE.exe
4. GitHub artifact ZIP: dist\TrackerSNR_CLEAN_EXE_DISTRIBUTION.zip

Future Treatment Export integration
The input pipeline is separated through collect_inputs(). A Treatment Export adapter can discover the tracker log members in an export package, pass their paths to parse_files(), and expose Tracker SNR as one analysis output without changing the chart/parser layer.
