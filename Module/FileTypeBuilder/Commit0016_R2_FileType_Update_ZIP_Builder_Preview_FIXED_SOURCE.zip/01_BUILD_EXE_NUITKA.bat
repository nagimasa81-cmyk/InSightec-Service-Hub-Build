@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "APP_NAME=InSightec_FileType_Update_ZIP_Builder_Commit0016_R2"
set "MAIN_PY=FileTypeUpdateZipBuilder.py"
set "PYEXE=python"

echo ============================================================
echo  File Type Update ZIP Builder - Commit0016 R2
echo ============================================================

if not exist "%MAIN_PY%" (
  echo [ERROR] %MAIN_PY% was not found.
  exit /b 1
)

%PYEXE% -m pip install --upgrade pip setuptools wheel
if errorlevel 1 exit /b 1

%PYEXE% -m pip install --upgrade -r requirements.txt
if errorlevel 1 exit /b 1

%PYEXE% -m py_compile "%MAIN_PY%"
if errorlevel 1 exit /b 1

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist "%APP_NAME%.build" rmdir /s /q "%APP_NAME%.build"
if exist "%APP_NAME%.dist" rmdir /s /q "%APP_NAME%.dist"
if exist "%APP_NAME%.onefile-build" rmdir /s /q "%APP_NAME%.onefile-build"

%PYEXE% -m nuitka ^
  --standalone ^
  --onefile ^
  --assume-yes-for-downloads ^
  --enable-plugin=pyside6 ^
  --windows-console-mode=disable ^
  --output-dir=dist ^
  --output-filename=%APP_NAME%.exe ^
  --company-name="InSightec" ^
  --product-name="File Type Update ZIP Builder" ^
  --file-description="File Type Update ZIP Builder Commit0016 R2" ^
  --file-version=1.0.0.17 ^
  --product-version=1.0.0.17 ^
  "%MAIN_PY%"

if errorlevel 1 exit /b 1

echo Build completed: %CD%\dist\%APP_NAME%.exe
exit /b 0
