from __future__ import annotations

import csv
import fnmatch
import json
import re
import sys
import zipfile
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox,
    QLabel, QLineEdit, QPushButton, QFileDialog, QMessageBox, QCheckBox,
    QComboBox, QTableWidget, QTableWidgetItem, QHeaderView, QPlainTextEdit,
    QTabWidget, QListWidget, QListWidgetItem, QSpinBox, QAbstractItemView,
)

APP_TITLE = "InSightec File Type Update ZIP Builder - Commit0016 R2"
SUPPORTED_SAMPLE_FILTER = "Log files (*.txt *.log *.out *.ar *.csv);;All files (*.*)"


def read_lines(path: Path) -> tuple[list[str], str]:
    for enc in ("utf-8-sig", "utf-8", "cp932", "shift_jis", "latin-1"):
        try:
            return path.read_text(encoding=enc, errors="strict").splitlines(), enc
        except Exception:
            continue
    return path.read_text(encoding="utf-8", errors="replace").splitlines(), "utf-8-replace"


def safe_id(text: str) -> str:
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", text.strip()).strip("_")
    return value.lower() or "new_file_type"


def split_tokens(text: str, delimiter_mode: str, delimiter: str = "") -> list[str]:
    if delimiter_mode == "whitespace":
        return [x for x in re.split(r"\s+", text.strip()) if x]
    if delimiter_mode == "csv":
        return next(csv.reader([text]))
    if delimiter_mode == "tab":
        return text.split("\t")
    if delimiter_mode == "custom" and delimiter:
        return text.split(delimiter)
    return [text]


def looks_like_time(token: str) -> bool:
    return bool(re.fullmatch(r"\d{1,2}:\d{2}:\d{2}(?:(?:[.:])\d{1,6})?", token.strip()))


def infer_pattern(path: Path) -> str:
    name = path.name
    stem = path.stem
    # Replace common filename timestamps while preserving a useful prefix.
    patterns = [
        r"(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)[_-]+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[_-]+\d{1,2}(?:[_-]+\d{1,2}){3}[_-]+20\d{2}",
        r"20\d{2}[_-](?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[_-]\d{1,2}(?:[_-]\d{1,2}){3}",
        r"20\d{2}[_-]\d{1,2}[_-]\d{1,2}(?:[_-]\d{1,2}){3}",
    ]
    generic_stem = stem
    for pattern in patterns:
        generic_stem = re.sub(pattern, "*", generic_stem, flags=re.I)
    if "*" not in generic_stem:
        # Keep leading word block, remove numeric suffixes.
        generic_stem = re.sub(r"(?:[_-]?\d+)+$", "*", generic_stem)
    if "*" not in generic_stem:
        generic_stem += "*"
    return generic_stem + path.suffix


def detect_format(path: Path) -> dict[str, Any]:
    lines, encoding = read_lines(path)
    nonempty = [(i, line) for i, line in enumerate(lines) if line.strip()][:200]
    if not nonempty:
        raise ValueError("The sample file contains no readable data.")

    result: dict[str, Any] = {
        "encoding": encoding,
        "format": "structured_whitespace",
        "delimiter_mode": "whitespace",
        "delimiter": "",
        "header_line_number": 1,
        "header_prefix": "",
        "timestamp_mode": "filename_date_plus_line_time",
        "time_column": 0,
        "columns": [],
        "skip_first_lines": 0,
        "data_start_line": 1,
    }

    # VIMeasure/header-driven style.
    for index, line in nonempty[:40]:
        m = re.match(r"^\s*[;#]?\s*Data\s*:\s*(.+)$", line, re.I)
        if m:
            columns = split_tokens(m.group(1), "whitespace")
            result.update({
                "format": "header_driven_whitespace",
                "header_line_number": index + 1,
                "header_prefix": line[: line.lower().find("data")],
                "columns": columns,
                "data_start_line": index + 2,
            })
            return result

    sample_lines = [line for _, line in nonempty[:20]]
    comma_score = sum(line.count(",") for line in sample_lines)
    tab_score = sum(line.count("\t") for line in sample_lines)
    if comma_score > tab_score and comma_score >= len(sample_lines):
        result["delimiter_mode"] = "csv"
        result["format"] = "delimited"
    elif tab_score > 0:
        result["delimiter_mode"] = "tab"
        result["format"] = "delimited"

    first_index, first_line = nonempty[0]
    first_tokens = split_tokens(first_line, result["delimiter_mode"])
    second_tokens = split_tokens(nonempty[1][1], result["delimiter_mode"]) if len(nonempty) > 1 else []

    def numeric_ratio(tokens: list[str]) -> float:
        if not tokens:
            return 0.0
        count = 0
        for token in tokens:
            try:
                float(token.strip().strip("<>"))
                count += 1
            except Exception:
                pass
        return count / len(tokens)

    # Header if first row is mostly labels and second row is mostly values.
    if first_tokens and numeric_ratio(first_tokens) < 0.25 and numeric_ratio(second_tokens) > 0.35:
        result["header_line_number"] = first_index + 1
        result["columns"] = [x.strip() or f"Column{i+1}" for i, x in enumerate(first_tokens)]
        result["data_start_line"] = first_index + 2
    else:
        count = max(len(first_tokens), len(second_tokens), 1)
        result["header_line_number"] = 0
        result["columns"] = [f"Column{i+1}" for i in range(count)]
        result["data_start_line"] = first_index + 1

    first_data = nonempty[min(1 if result["header_line_number"] else 0, len(nonempty) - 1)][1]
    data_tokens = split_tokens(first_data, result["delimiter_mode"])
    if data_tokens and looks_like_time(data_tokens[0]):
        result["time_column"] = 0
        if not result["columns"] or result["columns"][0].lower() not in {"time", "timestamp"}:
            result["columns"] = ["Timestamp"] + result["columns"]
    return result


@dataclass
class TestResult:
    sample: str
    rows: int
    columns: int
    errors: list[str]
    encoding: str
    passed: bool
    first_rows: list[dict[str, Any]]


def parse_sample(path: Path, spec: dict[str, Any], limit: Optional[int] = None) -> TestResult:
    lines, encoding = read_lines(path)
    errors: list[str] = []
    rows: list[dict[str, Any]] = []
    columns = list(spec.get("columns") or [])
    mode = spec.get("delimiter_mode", "whitespace")
    delimiter = spec.get("delimiter", "")
    data_start = max(1, int(spec.get("data_start_line", 1)))
    time_column = int(spec.get("time_column", 0))

    for line_no, line in enumerate(lines[data_start - 1 :], data_start):
        if not line.strip() or line.lstrip().startswith((";", "#")):
            continue
        tokens = split_tokens(line, mode, delimiter)
        if len(tokens) < 2:
            continue
        expected = len(columns)
        # Header-driven specs store numeric columns only; timestamp is separate.
        has_separate_ts = spec.get("timestamp_mode") == "filename_date_plus_line_time"
        expected_tokens = expected + (1 if has_separate_ts and (not columns or columns[0] != "Timestamp") else 0)
        if expected_tokens and len(tokens) != expected_tokens:
            errors.append(f"Line {line_no}: expected {expected_tokens} fields, got {len(tokens)}")
            if len(errors) >= 100:
                break
            continue
        row: dict[str, Any] = {}
        if has_separate_ts:
            if time_column >= len(tokens) or not looks_like_time(tokens[time_column]):
                errors.append(f"Line {line_no}: timestamp was not detected at column {time_column + 1}")
                continue
            row["Timestamp"] = tokens[time_column]
            values = tokens[:time_column] + tokens[time_column + 1 :]
            target_columns = columns
        else:
            values = tokens
            target_columns = columns
        for i, col in enumerate(target_columns):
            if i >= len(values):
                break
            value = values[i].strip()
            try:
                row[col] = float(value.strip("<>"))
            except Exception:
                row[col] = value
        rows.append(row)
        if limit and len(rows) >= limit:
            break

    return TestResult(
        sample=path.name,
        rows=len(rows),
        columns=len(columns),
        errors=errors,
        encoding=encoding,
        passed=bool(rows) and not errors,
        first_rows=rows[:8],
    )


class Builder(QWidget):
    def __init__(self):
        super().__init__()
        self.samples: list[Path] = []
        self.last_report: Optional[dict[str, Any]] = None
        self.detected: dict[str, Any] = {}
        self.setWindowTitle(APP_TITLE)
        self.resize(1180, 860)
        self.build_ui()

    def build_ui(self) -> None:
        root = QVBoxLayout(self)
        title = QLabel(APP_TITLE)
        title.setStyleSheet("font-size:20px;font-weight:bold;")
        root.addWidget(title)
        description = QLabel(
            "Load one or more real sample files, review the detected import/view settings, "
            "run full parser tests, then create an installable File Type Update ZIP."
        )
        description.setWordWrap(True)
        root.addWidget(description)

        self.tabs = QTabWidget()
        root.addWidget(self.tabs, 1)
        self.tabs.addTab(self.build_samples_tab(), "1. Samples")
        self.tabs.addTab(self.build_detection_tab(), "2. Detection & Parser")
        self.tabs.addTab(self.build_viewer_tab(), "3. Viewer & Investigation")
        self.tabs.addTab(self.build_test_tab(), "4. Preview & Test")

        footer = QHBoxLayout()
        self.build_btn = QPushButton("Build File Type Update ZIP")
        self.build_btn.setEnabled(False)
        self.close_btn = QPushButton("Close")
        footer.addStretch(1)
        footer.addWidget(self.build_btn)
        footer.addWidget(self.close_btn)
        root.addLayout(footer)
        self.build_btn.clicked.connect(self.build_zip)
        self.close_btn.clicked.connect(self.close)

    def build_samples_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout()
        self.add_files_btn = QPushButton("Add Sample Files")
        self.add_folder_btn = QPushButton("Add Sample Folder")
        self.remove_btn = QPushButton("Remove Selected")
        self.detect_btn = QPushButton("Analyze Samples")
        for w in (self.add_files_btn, self.add_folder_btn, self.remove_btn, self.detect_btn): row.addWidget(w)
        row.addStretch(1); layout.addLayout(row)
        self.sample_list = QListWidget(); self.sample_list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        layout.addWidget(self.sample_list, 1)
        self.sample_summary = QPlainTextEdit(); self.sample_summary.setReadOnly(True); self.sample_summary.setMaximumHeight(180)
        layout.addWidget(self.sample_summary)
        self.add_files_btn.clicked.connect(self.add_files)
        self.add_folder_btn.clicked.connect(self.add_folder)
        self.remove_btn.clicked.connect(self.remove_samples)
        self.detect_btn.clicked.connect(self.analyze_samples)
        return page

    def build_detection_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        info_box = QGroupBox("File Type Information"); form = QFormLayout(info_box)
        self.id_edit = QLineEdit(); self.name_edit = QLineEdit(); self.version_edit = QLineEdit("1.0.0")
        self.pattern_edit = QLineEdit(); self.encoding_edit = QLineEdit("auto")
        form.addRow("File Type ID", self.id_edit); form.addRow("Display Name", self.name_edit)
        form.addRow("Version", self.version_edit); form.addRow("File Pattern(s)", self.pattern_edit)
        form.addRow("Detected Encoding", self.encoding_edit); layout.addWidget(info_box)

        parser_box = QGroupBox("Parser Definition"); pf = QFormLayout(parser_box)
        self.format_combo = QComboBox(); self.format_combo.addItems(["header_driven_whitespace", "structured_whitespace", "delimited"])
        self.delimiter_combo = QComboBox(); self.delimiter_combo.addItems(["whitespace", "csv", "tab", "custom"])
        self.delimiter_edit = QLineEdit(); self.header_line_spin = QSpinBox(); self.header_line_spin.setRange(0, 100000)
        self.data_start_spin = QSpinBox(); self.data_start_spin.setRange(1, 100000)
        self.timestamp_combo = QComboBox(); self.timestamp_combo.addItems(["filename_date_plus_line_time", "full_timestamp_column", "no_timestamp"])
        self.time_column_spin = QSpinBox(); self.time_column_spin.setRange(1, 1000)
        self.columns_edit = QPlainTextEdit(); self.columns_edit.setMaximumHeight(120)
        pf.addRow("Format", self.format_combo); pf.addRow("Delimiter", self.delimiter_combo)
        pf.addRow("Custom Delimiter", self.delimiter_edit); pf.addRow("Header Line (0 = none)", self.header_line_spin)
        pf.addRow("First Data Line", self.data_start_spin); pf.addRow("Timestamp Rule", self.timestamp_combo)
        pf.addRow("Timestamp Column", self.time_column_spin); pf.addRow("Columns (one per line)", self.columns_edit)
        layout.addWidget(parser_box); layout.addStretch(1)
        return page

    def build_viewer_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        viewer_box = QGroupBox("Smart Discovery and Viewer"); form = QFormLayout(viewer_box)
        self.discovery_group = QComboBox(); self.discovery_group.addItems(["GENERAL", "MEASUREMENT", "SYSTEM", "IMPORT ONLY"])
        self.default_checked = QCheckBox("Checked by default in Smart File Discovery")
        self.import_chk = QCheckBox("Allow Import"); self.import_chk.setChecked(True)
        self.merge_chk = QCheckBox("Allow Merge"); self.merge_chk.setChecked(True)
        self.hover_chk = QCheckBox("Enable Hover Popup")
        self.visible_edit = QLineEdit("Timestamp")
        self.hidden_edit = QLineEdit()
        self.default_filter_edit = QLineEdit()
        self.auto_fit_chk = QCheckBox("Auto-fit visible columns after load"); self.auto_fit_chk.setChecked(True)
        capabilities = QWidget(); cap_l = QHBoxLayout(capabilities); cap_l.setContentsMargins(0,0,0,0)
        for w in (self.import_chk, self.merge_chk, self.hover_chk): cap_l.addWidget(w)
        cap_l.addStretch(1)
        form.addRow("Discovery Group", self.discovery_group); form.addRow("Discovery Default", self.default_checked)
        form.addRow("Capabilities", capabilities); form.addRow("Visible Columns", self.visible_edit)
        form.addRow("Hidden Columns", self.hidden_edit); form.addRow("Default Filter", self.default_filter_edit)
        form.addRow("Column Sizing", self.auto_fit_chk); layout.addWidget(viewer_box)

        inv_box = QGroupBox("Investigation Mode"); inv = QFormLayout(inv_box)
        self.investigation_combo = QComboBox(); self.investigation_combo.addItems(["NONE", "INITIAL", "WATER", "MR", "SONICATION", "CUSTOM"])
        self.chart_chk = QCheckBox("Enable chart from numeric columns")
        self.chart_series_edit = QLineEdit()
        self.default_view_combo = QComboBox(); self.default_view_combo.addItems(["LOGS", "CHART", "LOGS + CHART"])
        inv.addRow("Investigation Profile", self.investigation_combo); inv.addRow("Chart", self.chart_chk)
        inv.addRow("Default Chart Series", self.chart_series_edit); inv.addRow("Default Investigation View", self.default_view_combo)
        layout.addWidget(inv_box); layout.addStretch(1)
        return page

    def build_test_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)

        controls = QHBoxLayout()
        controls.addWidget(QLabel("Preview Sample"))
        self.preview_sample_combo = QComboBox()
        self.preview_sample_combo.setMinimumWidth(360)
        self.refresh_preview_btn = QPushButton("Refresh Preview")
        self.test_btn = QPushButton("Run Full Tests")
        controls.addWidget(self.preview_sample_combo, 1)
        controls.addWidget(self.refresh_preview_btn)
        controls.addWidget(self.test_btn)
        layout.addLayout(controls)

        self.preview_tabs = QTabWidget()

        raw_page = QWidget(); raw_layout = QVBoxLayout(raw_page)
        self.raw_preview = QPlainTextEdit(); self.raw_preview.setReadOnly(True)
        raw_layout.addWidget(self.raw_preview)
        self.preview_tabs.addTab(raw_page, "Raw File")

        parsed_page = QWidget(); parsed_layout = QVBoxLayout(parsed_page)
        self.preview_table = QTableWidget(0, 0)
        self.preview_table.setAlternatingRowColors(True)
        self.preview_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.preview_table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.preview_table.horizontalHeader().setStretchLastSection(True)
        parsed_layout.addWidget(self.preview_table)
        self.preview_tabs.addTab(parsed_page, "Parsed Preview")

        layout.addWidget(self.preview_tabs, 1)

        self.preview_status = QLabel("Analyze samples to preview the source file and parsed result.")
        self.preview_status.setWordWrap(True)
        layout.addWidget(self.preview_status)

        self.test_table = QTableWidget(0, 6)
        self.test_table.setHorizontalHeaderLabels(["Sample", "Rows", "Columns", "Encoding", "Errors", "Result"])
        self.test_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.test_table.setMaximumHeight(220)
        layout.addWidget(self.test_table)

        self.report_text = QPlainTextEdit(); self.report_text.setReadOnly(True); self.report_text.setMaximumHeight(180)
        layout.addWidget(self.report_text)

        self.refresh_preview_btn.clicked.connect(self.preview_sample)
        self.preview_sample_combo.currentIndexChanged.connect(self.preview_sample)
        self.test_btn.clicked.connect(self.run_tests)
        return page

    def add_files(self) -> None:
        files, _ = QFileDialog.getOpenFileNames(self, "Select sample files", str(Path.home()), SUPPORTED_SAMPLE_FILTER)
        self._add_paths([Path(x) for x in files])

    def add_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Select sample folder", str(Path.home()))
        if not folder: return
        paths = [p for p in Path(folder).rglob("*") if p.is_file() and p.suffix.lower() in {".txt", ".log", ".out", ".ar", ".csv"}]
        self._add_paths(paths)

    def _add_paths(self, paths: list[Path]) -> None:
        for path in paths:
            if path not in self.samples:
                self.samples.append(path); self.sample_list.addItem(str(path))
        self.build_btn.setEnabled(False); self.last_report = None
        if hasattr(self, "preview_sample_combo"):
            self.refresh_preview_samples()

    def remove_samples(self) -> None:
        selected = {item.text() for item in self.sample_list.selectedItems()}
        self.samples = [p for p in self.samples if str(p) not in selected]
        for item in self.sample_list.selectedItems(): self.sample_list.takeItem(self.sample_list.row(item))
        self.build_btn.setEnabled(False); self.last_report = None
        self.refresh_preview_samples()

    def refresh_preview_samples(self) -> None:
        if not hasattr(self, "preview_sample_combo"):
            return
        current = self.preview_sample_combo.currentText()
        self.preview_sample_combo.blockSignals(True)
        self.preview_sample_combo.clear()
        for path in self.samples:
            self.preview_sample_combo.addItem(path.name, str(path))
        if current:
            index = self.preview_sample_combo.findText(current)
            if index >= 0:
                self.preview_sample_combo.setCurrentIndex(index)
        self.preview_sample_combo.blockSignals(False)

    def selected_preview_path(self) -> Optional[Path]:
        if not self.samples:
            return None
        if hasattr(self, "preview_sample_combo") and self.preview_sample_combo.currentIndex() >= 0:
            value = self.preview_sample_combo.currentData()
            if value:
                path = Path(value)
                if path.exists():
                    return path
        return self.samples[0]

    def analyze_samples(self) -> None:
        if not self.samples:
            QMessageBox.information(self, "Samples", "Add at least one sample file."); return
        try:
            detections = [detect_format(path) for path in self.samples]
        except Exception as exc:
            QMessageBox.critical(self, "Detection Failed", str(exc)); return
        base = detections[0]; self.detected = base
        first = self.samples[0]
        display = re.split(r"[_-]", first.stem)[0] or "New File Type"
        self.id_edit.setText(safe_id(display)); self.name_edit.setText(display.upper())
        patterns = sorted({infer_pattern(p) for p in self.samples})
        self.pattern_edit.setText(",".join(patterns)); self.encoding_edit.setText(base.get("encoding", "auto"))
        self.format_combo.setCurrentText(base.get("format", "structured_whitespace"))
        self.delimiter_combo.setCurrentText(base.get("delimiter_mode", "whitespace")); self.delimiter_edit.setText(base.get("delimiter", ""))
        self.header_line_spin.setValue(int(base.get("header_line_number", 0))); self.data_start_spin.setValue(int(base.get("data_start_line", 1)))
        self.timestamp_combo.setCurrentText(base.get("timestamp_mode", "filename_date_plus_line_time")); self.time_column_spin.setValue(int(base.get("time_column", 0)) + 1)
        columns = list(base.get("columns") or [])
        self.columns_edit.setPlainText("\n".join(columns))
        visible = ["Timestamp"] + columns[: min(6, len(columns))]
        self.visible_edit.setText(",".join(dict.fromkeys(visible)))
        hidden = [c for c in columns if c not in visible]
        self.hidden_edit.setText(",".join(hidden))
        numeric_candidates = [c for c in columns if c.lower() not in {"timestamp", "time", "message", "type", "status"}]
        self.chart_series_edit.setText(",".join(numeric_candidates[:8]))
        if numeric_candidates:
            self.chart_chk.setChecked(True)
        self.sample_summary.setPlainText(json.dumps({"samples": [p.name for p in self.samples], "detection": base}, ensure_ascii=False, indent=2))
        self.refresh_preview_samples()
        self.preview_sample_combo.setCurrentIndex(0)
        self.preview_sample()
        self.tabs.setCurrentIndex(3)

    def spec(self) -> dict[str, Any]:
        columns = [x.strip() for x in self.columns_edit.toPlainText().splitlines() if x.strip()]
        return {
            "format": self.format_combo.currentText(), "delimiter_mode": self.delimiter_combo.currentText(),
            "delimiter": self.delimiter_edit.text(), "header_line_number": self.header_line_spin.value(),
            "data_start_line": self.data_start_spin.value(), "timestamp_mode": self.timestamp_combo.currentText(),
            "time_column": self.time_column_spin.value() - 1, "columns": columns,
            "encoding": self.encoding_edit.text().strip() or "auto",
        }

    def preview_sample(self) -> None:
        path = self.selected_preview_path()
        if path is None:
            if hasattr(self, "raw_preview"):
                self.raw_preview.clear()
                self.preview_table.setRowCount(0)
                self.preview_table.setColumnCount(0)
                self.preview_status.setText("Add and analyze at least one sample file.")
            return

        try:
            lines, encoding = read_lines(path)
            raw_limit = 1000
            raw_text = "\n".join(lines[:raw_limit])
            if len(lines) > raw_limit:
                raw_text += f"\n\n--- Preview truncated: showing first {raw_limit} of {len(lines)} lines ---"
            self.raw_preview.setPlainText(raw_text)

            result = parse_sample(path, self.spec(), limit=200)
            rows = result.first_rows
            headers: list[str] = []
            for row in rows:
                for key in row.keys():
                    if key not in headers:
                        headers.append(key)

            self.preview_table.clear()
            self.preview_table.setColumnCount(len(headers))
            self.preview_table.setHorizontalHeaderLabels(headers)
            self.preview_table.setRowCount(len(rows))
            for r, row in enumerate(rows):
                for c, header in enumerate(headers):
                    self.preview_table.setItem(r, c, QTableWidgetItem(str(row.get(header, ""))))
            self.preview_table.resizeColumnsToContents()

            error_text = "" if not result.errors else f" | Errors detected: {len(result.errors)}"
            self.preview_status.setText(
                f"{path.name} | Encoding: {encoding} | Parsed preview rows: {len(rows)}{error_text}"
            )
        except Exception as exc:
            self.preview_status.setText(f"Preview failed: {exc}")
            self.raw_preview.setPlainText(str(exc))
            self.preview_table.setRowCount(0)
            self.preview_table.setColumnCount(0)

    def run_tests(self) -> bool:
        if not self.samples:
            QMessageBox.information(self, "Tests", "Add at least one sample file."); return False
        spec = self.spec(); results = [parse_sample(path, spec) for path in self.samples]
        self.test_table.setRowCount(len(results))
        for row, result in enumerate(results):
            values = [result.sample, result.rows, result.columns, result.encoding, len(result.errors), "PASS" if result.passed else "FAIL"]
            for col, value in enumerate(values): self.test_table.setItem(row, col, QTableWidgetItem(str(value)))
        passed = all(x.passed for x in results)
        self.last_report = {"generated_at": datetime.now().isoformat(timespec="seconds"), "passed": passed, "results": [asdict(x) for x in results]}
        self.report_text.setPlainText(json.dumps(self.last_report, ensure_ascii=False, indent=2))
        self.build_btn.setEnabled(passed)
        if passed: QMessageBox.information(self, "Tests", "All sample parser tests passed. The Update ZIP can now be built.")
        else: QMessageBox.warning(self, "Tests", "One or more sample parser tests failed. Review the parser settings.")
        return passed

    def build_zip(self) -> None:
        if not self.run_tests(): return
        file_type_id = safe_id(self.id_edit.text())
        patterns = [x.strip() for x in re.split(r"[,;]", self.pattern_edit.text()) if x.strip()]
        visible = [x.strip() for x in self.visible_edit.text().split(",") if x.strip()]
        hidden = [x.strip() for x in self.hidden_edit.text().split(",") if x.strip()]
        chart_series = [x.strip() for x in self.chart_series_edit.text().split(",") if x.strip()]
        manifest = {
            "package_type": "file_type_update", "schema": "insightec.filetype.v1",
            "id": file_type_id, "display_name": self.name_edit.text().strip() or file_type_id.upper(),
            "version": self.version_edit.text().strip() or "1.0.0", "patterns": patterns,
            "enabled": True, "plugin_api": "2.1", "structured_fields": True,
            "import_enabled": self.import_chk.isChecked(), "merge_enabled": self.merge_chk.isChecked(),
            "generated_by": APP_TITLE,
        }
        discovery = {
            "display_name": manifest["display_name"].upper(), "checkbox_group": self.discovery_group.currentText(),
            "default_checked": self.default_checked.isChecked(), "order_before": "UNKNOWN",
        }
        viewer = {
            "default_visible_columns": visible, "default_hidden_columns": hidden,
            "default_filter": self.default_filter_edit.text().strip(), "auto_fit_on_load": self.auto_fit_chk.isChecked(),
            "hover_popup": self.hover_chk.isChecked(), "numeric_columns_from_header": True,
        }
        investigation = {
            "profile": self.investigation_combo.currentText().lower(), "enabled": self.investigation_combo.currentText() != "NONE",
            "chart_enabled": self.chart_chk.isChecked(), "chart_series": chart_series,
            "default_view": self.default_view_combo.currentText().lower().replace(" + ", "_and_").replace(" ", "_"),
        }
        output, _ = QFileDialog.getSaveFileName(self, "Save File Type Update ZIP", str(Path.home() / f"{file_type_id}_FileType_Update_v{manifest['version']}.plugin.zip"), "Plugin ZIP (*.plugin.zip *.zip)")
        if not output: return
        output_path = Path(output)
        if not output_path.name.lower().endswith(".zip"): output_path = output_path.with_suffix(".plugin.zip")
        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
            zf.writestr("parser.json", json.dumps(self.spec(), ensure_ascii=False, indent=2))
            zf.writestr("discovery_profile.json", json.dumps(discovery, ensure_ascii=False, indent=2))
            zf.writestr("viewer_defaults.json", json.dumps(viewer, ensure_ascii=False, indent=2))
            zf.writestr("investigation_profile.json", json.dumps(investigation, ensure_ascii=False, indent=2))
            zf.writestr("tests/test_report.json", json.dumps(self.last_report, ensure_ascii=False, indent=2))
            zf.writestr("README.txt", "Install using Update File Type, reload file types, then verify Smart File Discovery, Viewer and Investigation Mode.\n")
            for sample in self.samples: zf.write(sample, f"samples/{sample.name}")
        QMessageBox.information(self, "Created", f"File Type Update ZIP created:\n{output_path}")


def main() -> int:
    app = QApplication(sys.argv)
    window = Builder(); window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
