InSightec File Type Update ZIP Builder - Commit0016 R2

This source is intentionally standalone.
It does not contain LogMergeTool_NoExcel_Main.py or any Log Merge Tool build BAT.

New in R2:
- After Analyze Samples, the Builder opens Preview & Test automatically.
- Raw File and Parsed Preview are available as separate tabs.
- Multiple samples can be selected from the Preview Sample list.
- Raw preview shows up to 1,000 lines.
- Parsed preview shows the structured extraction result.

Run:
  Run_FileType_Update_ZIP_Builder.bat

Build:
  01_BUILD_EXE_NUITKA.bat

Expected EXE:
  dist\InSightec_FileType_Update_ZIP_Builder_Commit0016_R2.exe
