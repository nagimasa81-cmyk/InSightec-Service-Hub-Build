@echo off
cd /d "%~dp0"
python FileTypeUpdateZipBuilder.py
