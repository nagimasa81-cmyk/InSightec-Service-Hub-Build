InSightec File Type Update ZIP Builder - Commit0016 R1

This source is intentionally standalone.
It does not contain LogMergeTool_NoExcel_Main.py or any Log Merge Tool build BAT.

Run:
  Run_FileType_Update_ZIP_Builder.bat

Build:
  01_BUILD_EXE_NUITKA.bat

Expected EXE:
  dist\InSightec_FileType_Update_ZIP_Builder_Commit0016_R1.exe
