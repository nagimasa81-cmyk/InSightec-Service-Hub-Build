WaterSystemAnalyzer Version 7.3 RC1-6 UsageAxisForecast
==========================================================

What changed vs RC1-5 LogCoverageDatabase:

1) Life Forecast can now measure component life in more than calendar days.
   New "Life Axis" selector in the Life Forecast dialog:
     - Calendar Days (unchanged default)
     - Clean Count (est.)
     - Treatment Circulate Hours (est.)
     - Degas Circulate Hours (est.)
     - Cleaning Circulate Hours (est.)

   How it works: Log_Coverage_History.xlsx (added in RC1-5) now also accumulates Clean
   Count and Treat/Degas/Clean Circulate Hours per linked log session, in addition to
   Observed Runtime Hours. From this, an average per-day usage rate is computed for the
   selected SN (falling back to the average rate across every linked SN if this one has
   no log coverage yet), and shown directly in the dialog ("Using this SN's own rate: 0.16
   Clean Count / day (from 1 linked session, 31 observed days)").

   Because Weibull is a scale family (if T ~ Weibull(k, lambda) then c*T ~ Weibull(k,
   c*lambda)), the existing calendar-day fit is reused and simply rescaled by that rate for
   display/axis purposes - no refit, no change to the calendar-date forecast logic, so this
   is purely an additional, safe view of the same fitted model. The Kaplan-Meier curve's
   x-axis is rescaled the same way. The forecast table gets an extra "Residual" column
   showing the remaining life in the selected unit alongside the calendar forecast date.

   This is an estimate, not a per-unit measured value: it assumes usage accrues at a
   roughly constant daily rate, using whatever has been linked via "Link Analyzed Logs to
   Database" so far. More linked sessions for a given SN make its own rate more reliable;
   until then it borrows the global average rate.

2) The survival chart is richer and easier to read:
   - A light green/red background split at the 50% survival line (quick "still likely fine"
     vs "past the risk threshold" visual cue).
   - Dashed median guide lines with the actual value labelled, for both Kaplan-Meier (blue)
     and Weibull (red), instead of only the raw curves.
   - A proper legend box (top-right) instead of overlapping text.
   - Rug ticks along the x-axis marking every individual interval used in the fit (red =
     failure/uncensored, grey = censored/still-in-service), so the amount and shape of the
     underlying data is visible at a glance.
   - A title line showing the current Scope/Component Type, and an axis caption showing the
     selected Life Axis unit.

No new dependencies were introduced (still pure PySide6 + openpyxl; no numpy/scipy/
matplotlib/pandas).
