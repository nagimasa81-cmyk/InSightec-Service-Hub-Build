WaterSystemAnalyzer Version 7.3 RC1-10 AxisLabelFix
======================================================

What this fixes (from the screenshot report):

Symptom: the Life Axis dropdown still showed "Clean Count (est.)", "Treatment Circulate
Hours (est.)", "Degas Circulate Hours (est.)", "Cleaning Circulate Hours (est.)" - the
"(est.)" suffix left over from before RC1-7, even though RC1-7 already changed these axes
to fit on the ACTUAL recorded log totals by default (only the separate "Extrapolate"
Coverage Mode is genuinely an estimate now). The dropdown labels were never updated to match
- this was purely a leftover/cosmetic label bug (LF_USAGE_METRICS dict keys), not a
calculation bug. The underlying real-data fitting logic from RC1-7/RC1-8/RC1-9 is unchanged.

Fix: renamed the dropdown entries to "Clean Count", "Treatment Circulate Hours", "Degas
Circulate Hours", "Cleaning Circulate Hours" (no suffix). Whether a given result is real
log-derived data or an extrapolated estimate is now shown only where it's actually true:
in the "Coverage Mode" dropdown and in the calculated summary text (e.g. "Estimated day
equivalent..." only appears next to numbers that really are estimated).
