WaterSystemAnalyzer Version 7.3 RC1-5 LogCoverageDatabase
============================================================

What changed vs RC1-4 LifeForecastModule:

New button on the main screen (Forecast group): "Link Analyzed Logs to Database
(SN / Hospital / Country / Region)".

Why: WaterSystem_*.txt raw logs carry no Serial Number field internally (verified -
they only contain a timestamped sensor table). The app has always relied on the user
or the ResultSummary_<SN>.xlsx filename to know which machine a log folder belongs to.
This update makes that link explicit, persistent, and reusable in Life Forecast:

  1. After running Analyze, click the new button. It asks for the Serial Number
     (pre-filled from the ResultSummary filename if available).
  2. If that SN is not yet in Hospital_Master.xlsx, you are prompted for Hospital /
     Country / Region and it is registered automatically (Status defaults to Active).
     If it already exists, its Hospital/Country/Region are reused.
  3. One row is appended (never overwritten) to a new master file,
     Master/Log_Coverage_History.xlsx, recording: Run Date, Serial Number, Hospital,
     Country, Region, Source Folder, Period Start/End (from the log DateTimes),
     Rows Analyzed, Observed Runtime Hours, Algorithm Version.

Doing this every time you analyze a new log batch for a machine builds up a growing,
append-only database of what has actually been observed, for which SN, over time -
"どんどんdatabase化" - without ever losing older sessions.

Life Forecast integration:
  - In the Life Forecast dialog, selecting Scope = Hospital (SN) now also shows a
    "Log coverage database" line for that SN: number of linked sessions, total observed
    runtime hours, and the earliest/latest observed dates across all linked sessions.
  - A new button, "Use Log Coverage Window as Date Range", fills the Replacement Date
    From/To fields from that accumulated window, so a forecast run can be bounded to only
    the period that has actually been instrumented for that unit (this is the "forcast出す
    時の範囲指定に使える" requirement) instead of guessing a date range by hand.
  - Because Hospital_Master already carries Country/Region, any SN registered this way is
    immediately usable in the existing Region/Country/Global cuts too.

No new file formats or dependencies were introduced; this reuses the same
read_master_foundation_rows / write_master_foundation_rows append pattern already used
elsewhere in the app (e.g. Replacement_History.xlsx editing).
