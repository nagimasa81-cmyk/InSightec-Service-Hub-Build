WaterSystemAnalyzer Version 7.3 RC1-8 GapClassification
===========================================================

What changed vs RC1-7 RealUsageAxis:

Design premise (per feedback): WaterSystem logs are only produced while the system is
actually running, so gaps between linked log sessions are EXPECTED BY DESIGN - a gap is not
automatically a data quality problem. Whether a given gap means "genuinely not used" or
"unknown / possibly missed usage" cannot be inferred automatically; it needs a person to say
which is true. RC1-7's strict "must be fully covered" rule has been replaced with a
flexible, explicit system:

1) New "Classify Log Gaps for this SN..." button in the Life Forecast dialog.
   Opens a table of every gap between that SN's linked log sessions (lf_detect_gaps), each
   with a dropdown: (unmarked) / Idle (Not Used) / Unknown (Data Gap), plus a free-text
   comment. Saved to a new master file, Log_Gap_Classification.xlsx (Serial Number, Gap
   Start, Gap End, Classification, Comment, Marked Date) - append/update, never silently
   overwritten.

2) New "Coverage Mode" selector controls how gaps are treated when fitting a usage-based
   Life Axis (Clean Count / Treat/Degas/Clean Circulate Hours):
     - Strict: an interval is only used if logged sessions + gaps explicitly marked Idle
       together explain its entire span. Any Unknown-marked or still-unclassified remainder
       excludes it.
     - Assume unmarked gaps are idle (default, matches the log design): unclassified gaps
       are treated as zero usage automatically - only a gap explicitly marked Unknown
       excludes the interval. This is the "count everything from first log to last log,
       assuming no logs = not running" mode from the request.
     - Extrapolate partial coverage: uses whatever logged portion exists and scales it up
       to the full interval length (the RC1-6 estimate behavior), ignoring gap
       classification entirely - always available even with very little linked data, but
       is explicitly an estimate.

   The dialog's summary always states which mode was used and how many intervals qualified
   under it, so results are traceable back to the assumption that produced them.

Verified: a synthetic SN with two log sessions separated by an unclassified 91-day gap
behaves correctly across all three modes, and re-classifying that gap as Unknown vs Idle
changes Strict/Assume-idle results exactly as expected (Extrapolate mode is unaffected by
gap classification, as designed - it only depends on how much has been logged).
