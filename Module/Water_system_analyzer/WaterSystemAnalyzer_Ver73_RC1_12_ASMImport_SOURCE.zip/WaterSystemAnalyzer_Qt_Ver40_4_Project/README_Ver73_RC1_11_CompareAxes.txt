WaterSystemAnalyzer Version 7.3 RC1-11 CompareAxes
=====================================================

What this addresses (from the screenshot report):

1) "Weibull fit only shows for Calendar Days" - explanation, not a bug:
   Calendar Days can always use every SN's real replacement dates, so a Global fallback
   almost always finds enough data. A usage axis (Clean Count, Treat/Degas/Clean Circulate
   Hours) can only use intervals that have been through "Link Analyzed Logs to Database" -
   right now only SN 4278 has any linked sessions, so even the Global fallback for a usage
   axis has very little to work with. This isn't something code can fix - it needs more SNs'
   logs linked over time (the database this feature is built around is meant to grow).

2) "The Weibull curve doesn't look like a Weibull chart" - this WAS a real rendering bug,
   now fixed:
   When the Weibull fit came from a broader fallback scope (e.g. Global) with a much longer
   life scale than the exact SN's own tiny interval range, the chart's x-axis was still sized
   to that tiny range - so the red Weibull curve, whose median might be tens of thousands of
   days out, rendered as a flat line stuck near 100% survival with no visible decay. The
   chart now widens its x-axis to also cover the fitted Weibull curve's own scale (median x
   1.4) whenever a fit is present, so the S-shaped decay is actually visible.

3) New "Compare All Life Axes..." button:
   Runs the same Scope / Model / Unknown-handling / Coverage Mode / date range across every
   Life Axis at once (Calendar Days, Clean Count, Treatment/Degas/Cleaning Circulate Hours)
   and shows them side by side in one table: unit, how many intervals were actually used,
   which scope the fit ended up using (exact vs. fallback), the Weibull median, and the
   Kaplan-Meier median. This avoids having to re-select the axis and press Calculate
   repeatedly just to see how the different axes compare for the current scope.

Verified: the compare loop runs cleanly across all 5 axes without errors, correctly
reporting "no data" for usage axes with no linked log coverage yet, and the widened
max-axis calculation was checked against the RC1-9 screenshot's numbers (median 16748 days
-> widened range ~23447 days, enough to show the curve's decay).
