WaterSystemAnalyzer Version 7.3 RC1-4 LifeForecastModule
==========================================================

What changed vs RC1-3d WorkflowDispatchFix:

New "Life Forecast (Weibull / Kaplan-Meier)" dialog, opened from a new button in the
Forecast group. It lets the operator pick, in the GUI, before every calculation:

  - Model:            Weibull (MLE with right-censoring) / Kaplan-Meier / Simple Average Interval
  - Unknown handling: Conservative (Unknown replacement = still-alive/censored)
                       or Sensitivity (Unknown replacement = failure-equivalent)
  - Scope:            Global / Region / Country / Hospital (SN)
  - Component Type:   from whatever is present in Replacement_History.xlsx
  - Replacement Date From/To range filter

Results are shown as:
  - A native Qt survival-curve chart (Kaplan-Meier step curve in blue, fitted Weibull
    S(t) curve in red) - pure QGraphicsView/QPainter, no matplotlib/numpy/pandas,
    consistent with this project's existing chart and Nuitka build policy.
  - A text summary (shape k, scale lambda, mean/median life, KM median).
  - A per-active-unit forecast table (last event date, age, forecast date), using a
    hierarchical fallback (SN's own history -> Country -> Region -> Global) whenever a
    scope has too few events for its own Weibull fit.
  - "Export Result to Excel" writes Intervals / Forecast / Fit_Summary sheets.

Editing / adding / importing data:
  - "Edit Hospital Master" reuses the existing Master Foundation dialog. Hospital_Master
    now also has Country and Region columns (added to HP_MASTER_HEADERS) so they can be
    filled in/edited directly in the app; existing Hospital_Master.xlsx files get the two
    new columns appended automatically (ensure_headers already does this).
  - "Import / Edit Replacement History" reuses the existing Replacement Import Wizard, so
    any of its supported source layouts (header-based xlsx/csv/json, legacy multi-hospital
    xlsx) can be dropped in without any new import code.

Inherits data from the Main Analysis session:
  - When opened, the dialog reads the main window's already-analyzed self.summary_rows and
    the Serial Number implied by the currently loaded ResultSummary file (same convention as
    calculate_forecast_now: "ResultSummary_<SN>...xlsx"). If found, Scope is pre-set to that
    Hospital (SN), and a status line shows how many log-summary rows were inherited and their
    date range.
  - A checkbox ("Use Main Analysis session as data source") lets the last log date from that
    session be used as the 'now' reference for age/forecast, instead of today's calendar date.
    This matters when analyzing an exported/older log snapshot, so the forecast is anchored to
    the data's own timeline rather than the machine running the analysis.
  - If no Main Analysis has been run yet, the dialog falls back to master-file data only and
    disables the checkbox, with a note explaining why.

Known data-quality caveat carried over from analysis: if most Replacement_History rows
have Replacement Type = "Unknown", the two scenarios (Conservative vs Sensitivity) can
diverge by years. Classifying "Unknown" rows into Failure / Scheduled Replacement /
Hospital Request / Company Instruction is the single highest-value data fix for
forecast accuracy, and can be done directly in the Replacement Import Wizard / Master
Foundation table.

Implementation note: the Weibull MLE fit is solved with a small dependency-free 2-D
Nelder-Mead simplex (see lf_nelder_mead_2d / lf_weibull_negloglik / lf_fit_weibull).
No numpy, scipy, pandas, or matplotlib were added - requirements_py313_pyside6_nuitka.txt
is unchanged from RC1-3d.
