WaterSystemAnalyzer Version 7.3 RC1-9 ScopeFallbackFix
=========================================================

What this fixes (from the screenshot report):

Symptom: with Scope = Hospital (SN) = 4278, the dialog showed "Weibull fit unavailable...
need at least 2 uncensored events and 4 intervals" and the forecast table showed
"(n/a - no Weibull fit)", even though the app had usable Replacement_History data overall.

Root cause: a single machine (SN) almost never has enough of its own replacement events to
fit a Weibull distribution by itself (in the screenshot: only 2 intervals total for that SN
in the chosen date range). The dialog was only ever trying the exact scope you selected and
giving up if that alone was insufficient - it never actually used the described
SN -> Country -> Region -> Global fallback (that idea was mentioned in an earlier README
but had not actually been wired into the calculation code).

Fix: lf_scope_fallback_chain() now builds the real broadening chain (Hospital (SN) ->
Country -> Region -> Global, skipping any level whose Country/Region is still "(Unset)"),
and calculate() walks it for the Weibull fit (both the Calendar Days fit used for the
forecast dates, and the usage-axis fit) until it finds a scope with enough data. The exact
scope's Kaplan-Meier curve is still always shown as-is (KM does not need the fallback - it
works with as few as 1-2 points, it just won't reach a median). When a fallback scope was
used, the dialog now says so explicitly, e.g.:
  "Note: SN/scope-level data was too sparse to fit Weibull on its own, so this fit uses the
  broader scope 'Country = Japan (fallback)' instead."

Also relevant to the screenshot: SN 4278's Hospital_Master Country/Region were shown as
"(Unset)/(Unset)". That is a data gap, not a bug - use "Edit Hospital Master (Country /
Region / Status)" in the dialog to fill them in. Until they're filled in, this SN's fallback
chain skips straight from Hospital (SN) to Global (there is no Country/Region step to use).

Verified with the real multi-hospital dataset: SN 4048 alone had 4 intervals and no usable
Weibull fit; the fallback chain correctly escalated to Country = Japan (85 intervals, fit
succeeded, k=0.997), then Global (99 intervals, k=0.983) as a further check.
