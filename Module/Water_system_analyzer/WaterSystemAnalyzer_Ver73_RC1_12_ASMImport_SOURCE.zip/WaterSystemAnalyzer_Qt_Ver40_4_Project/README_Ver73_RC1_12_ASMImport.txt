WaterSystemAnalyzer Version 7.3 RC1-12 ASMImport
===================================================

1) About the "Compare Life Axes" screenshot showing 0 for everything except Calendar Days:

This is almost certainly the Data-folder-carryover issue explained earlier (see the
"新しいビルドに引き継ぐためには何が必要？" answer), not a new code bug: every GitHub Actions build
starts from an empty Data folder, so if the previous build's Data folder (with 25 hospitals'
worth of Replacement_History, and the 2 Log_Coverage_History sessions for SN 4278) was not
copied next to this build's exe, the app is working from an almost-empty database - only
whatever was re-entered in the current session. That matches exactly what the screenshot
shows: only SN 4278's own 2 replacement intervals exist anywhere (so even the Global
fallback for Calendar Days has just those same 2, which is below Weibull's minimum), and
zero linked log sessions exist for any SN (so every usage axis has nothing to work with).
Please carry the Data folder forward (Import Release Package, manual copy, or a pinned
external Data folder) when moving to this build, and this will resolve itself.

2) New: "Import ASM Replacement File (Region/Country/Install Date)..." button.

Imports an "ASM<part>_Replacement History.xlsx" export directly (uses its 'Replacement
History' sheet: Part Number, Region, Country, Site, System Serial, Installation Date, Part
Serial Number, Action Date, Case Number, Reason, Case Status, Case Solution Summary,
Replacement Confirmation).

  - Hospital_Master.xlsx is upserted by Serial Number: Hospital Name/Site, Country, Region,
    and Installation Date (if not already set) are filled in directly from the file - this
    solves the "(Unset)/(Unset)" Country/Region problem for every hospital in the file in
    one step, rather than typing them in by hand via Master Foundation.
  - Replacement_History.xlsx is upserted by (Component Type = Part Number, Component ID =
    Part Serial Number, Case Number) - a new "Case Number" column was added to
    REPLACEMENT_HISTORY_HEADERS for this. Rows whose case is still open/pending logistics are
    skipped (not a completed replacement yet). Replacement Type is set to "Failure" when
    Replacement Confirmation is Confirmed/Likely, otherwise "Unknown".
  - Safe to re-run whenever you get a refreshed version of this file later ("あとで内容を
    アップデートできるように") - matching rows are updated in place (dates/status refreshed),
    nothing is duplicated. Verified: importing the same file twice in a row produces
    identical row counts on the second pass, only "updated" counts change.

Tested with the uploaded file: 122 hospitals (with real Country/Region/Installation Date)
and 203 completed replacement events were imported from 324 source rows (114 still-open
cases were correctly skipped) - this alone should make Region/Country/Global-scope Weibull
fits far more usable once it's imported into your working Data folder.
