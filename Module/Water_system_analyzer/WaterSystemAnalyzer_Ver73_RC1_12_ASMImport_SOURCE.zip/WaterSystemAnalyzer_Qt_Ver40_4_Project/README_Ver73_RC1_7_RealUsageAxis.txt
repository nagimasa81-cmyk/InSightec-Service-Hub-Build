WaterSystemAnalyzer Version 7.3 RC1-7 RealUsageAxis
======================================================

What changed vs RC1-6 UsageAxisForecast:

Previously, non-Calendar-Days Life Axes (Clean Count, Treat/Degas/Clean Circulate Hours)
were shown by rescaling the calendar-day Weibull/KM fit with a single blanket rate
("(est.)" in every axis name). Per feedback, this has been replaced with a fit on the
ACTUAL recorded values from the WaterSystem logs:

  - Every linked log session (Log_Coverage_History.xlsx) already stores its own Clean
    Count / Treat / Degas / Clean Circulate Hours totals for its exact Period Start/End.
  - For each replacement-to-replacement interval, lf_build_usage_dataset() sums the real
    totals from every linked session that overlaps that interval, apportioning a session's
    total by the fraction of its days that fall inside the interval when the overlap is
    partial.
  - An interval is only used for the usage-axis fit if its ENTIRE calendar span is covered
    by linked sessions - if there is any gap, the true total for that interval is unknown,
    so it is excluded rather than guessed. The dialog reports "X of Y intervals are fully
    log-covered" so it's clear how much of the fit is backed by real data.
  - Weibull and Kaplan-Meier are then fit directly on these real per-interval totals (no
    rescaling of the calendar-day fit).

The estimate has moved to the other side, as requested: the day-based numbers shown
alongside a usage-axis result ("Estimated day equivalent...") are now the estimated ones,
derived from the average rate implied by the same real, fully-covered intervals used in
the fit. Calendar Days itself is never an estimate - it always uses the exact replacement
dates.

The forecast table's calendar "Forecast Date" column is unaffected (it always uses the
calendar-day Weibull fit on the real replacement history, regardless of which Life Axis is
selected for display) - the new "Residual (est. <unit>)" column is the only place an
estimate is shown for individual units.

Practical implication: usage-axis analysis will show few or zero usable intervals until
enough "Link Analyzed Logs to Database" sessions have been recorded back-to-back so that a
full replace-to-replace period is completely covered by linked logs. This is intentional -
it prevents the tool from silently guessing usage for periods that were never actually
analyzed.
