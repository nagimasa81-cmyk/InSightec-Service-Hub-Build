WaterSystemAnalyzer Version 7.3 RC1-1 DashboardFirst
=======================================================

This RC1-1 confirmation source focuses on information presentation.

Added:
- Runtime Reconstruction opens with summary cards.
- Potential GAP records are shown vertically as review cards.
- Reference and detailed tables are hidden under Show Details.
- Reliability Dashboard opens with summary cards and explanation.
- Detailed reliability tables are hidden under Show Details.
- Dashboard Preview JSON is collapsed by default.
- Workflow Assistant uses larger vertical Current Step / Next Action cards.
- Existing ZIP performance, compact Drop Areas, session, update, and
  chart-control fixes are retained.

This is a confirmation source for the Dashboard-First direction.
