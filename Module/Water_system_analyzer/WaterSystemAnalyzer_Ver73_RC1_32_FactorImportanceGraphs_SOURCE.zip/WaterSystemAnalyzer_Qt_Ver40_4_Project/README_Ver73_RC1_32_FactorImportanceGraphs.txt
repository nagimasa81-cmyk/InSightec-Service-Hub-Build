WaterSystemAnalyzer Version 7.3 RC1-32 FactorImportanceGraphs
==================================================================

What changed: Factor Importance previously only showed the CV ranking as a bar chart plus a
numeric table - no actual survival curve for any axis. As requested, every Life Axis that
gets a valid Weibull fit now also gets its own graph.

Below the CV bar chart and results table, a new scrollable row shows one full KM + Weibull
survival chart per successfully-fit axis (same chart type used everywhere else in Life
Forecast - risk-zone shading, median guide lines, rug ticks for individual events), each in
its own unit (days, Clean Count, Circulate Hours, ...) and ordered by rank (#1 = best
candidate driver first). Axes that couldn't be fit (shown as "n/a" in the table) simply
don't get a chart, since there's nothing valid to plot.

Verified the data pipeline end to end on a synthetic dataset: for the Calendar Days axis,
confirmed the Weibull fit, the Kaplan-Meier curve (14 points), the chart's x-axis range
(sized to comfortably show the fitted median), and the per-interval rug points all build
correctly and get handed to the same NativeSurvivalChartView class already used elsewhere.
