WaterSystemAnalyzer Version 7.3g Fix1 MissingMethods
=====================================================

Cause:
- During the Version 7.3g Drop-First UI conversion, a broad source-range
  replacement accidentally removed several AnalyzerWindow methods.
- The UI still connected buttons and chart controls to those methods.
- Startup therefore failed at `self.scan_folder_check`.

Restored methods:
- scan_folder_check
- date_parse_check
- show_analyze_debug
- show_analyze_performance
- set_all
- set_group
- set_names_checked
- group_names
- sync_group_checks
- on_child_check_changed

Retained:
- Drop-first Project / ResultSummary / Replacement / Update / Restore UI
- Runtime/Dashboard fixes from Version 7.3f R2
- Potential GAP and Reference Intervals
- Interactive Workflow
- Session continuation
- Dashboard Scope
- Degas Module terminology

Validation:
- Python syntax compile for all .py files
- AnalyzerWindow UI callback audit
- Missing-method comparison against Version 7.3f R2
- ZIP integrity check
