WaterSystemAnalyzer Version 7.3g Fix2 ZipChartInstruction
============================================================

- WaterSystem ZIP direct import without manual extraction.
- Replacement History ZIP direct import.
- Safe ZIP extraction with path traversal protection.
- Chart Controls closed by default and explicit-only.
- Chart clicks/loading never open Chart Controls or change menu state.
- Interactive Workflow cards resize so instructions remain visible.
- Version 7.3g Fix1 startup/method restoration retained.
