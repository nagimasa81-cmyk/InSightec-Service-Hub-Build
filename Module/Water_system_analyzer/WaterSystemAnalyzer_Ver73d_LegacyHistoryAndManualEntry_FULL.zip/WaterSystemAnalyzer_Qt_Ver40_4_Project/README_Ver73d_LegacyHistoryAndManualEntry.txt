WaterSystemAnalyzer Version 7.3d LegacyHistoryAndManualEntry
============================================================

Base:
- Version 7.3c ReplacementImportWizard

Added / Fixed:
- Robust detection for legacy multi-hospital History.xlsx:
  A = SN
  B = HP/Hospital
  C onward = date history
- SN/HP headers no longer cause the legacy format to be misclassified.
- Each date cell is expanded into one replacement event.
- Placeholder row NA / Not selected is skipped with a validation warning.
- Guided Step explanations inside the wizard.
- Manual replacement entry.
- Edit selected preview row.
- Remove selected preview row.
- Master-linked dropdowns for Component Type, Replacement Type, and Failure Type.
- Unified professional dialog styling.
- Validation now includes unique system count and legacy conversion summary.
- Test data included for xlsx, csv, and json.

Sample validation:
- History(1).xlsx should be detected as Legacy multi-hospital History.xlsx.
- Multiple hospitals and serial numbers must be expanded correctly.

Notes:
- The default interpretation is that all populated dates are replacement dates.
- Installation-event handling and row-level table dropdown widgets will be refined with Section Manager.
