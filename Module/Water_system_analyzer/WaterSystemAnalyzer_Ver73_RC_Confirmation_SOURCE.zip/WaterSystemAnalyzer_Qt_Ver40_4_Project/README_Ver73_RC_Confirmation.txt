WaterSystemAnalyzer Version 7.3 RC Confirmation
================================================

This is a confirmation SOURCE package, not the final 7.3 release.

Included:
- Project menu open by default; Analysis/Forecast start closed.
- Continue Previous / Start New session foundation.
- session_state.json persistence.
- Interactive Forecast Workflow status and recommended action.
- Recommended Forecast button highlighting.
- Degas Module terminology unification.
- Compatibility aliases: DO / DO Module / Degas -> Degas Module.
- Dashboard Scope selector:
  Hospital (default), Selected Hospitals, Country, Region, Distributor, All Hospitals.
- Scope selection persistence.
- Module Update Foundation:
  update ZIP selection, manifest inspection, Dry Run, protected-data check,
  metadata backup, staging, pending_update.json, update history.
- Replacement Import/Manual Entry improvements from 7.3d/7.3e.
- Data Foundation and visual Dashboard Preview retained.

Important RC limitations:
- Non-Hospital Dashboard scopes are selector/persistence foundations.
  Full grouped recalculation is connected in the reliability model phase.
- Program EXE replacement is staged for an external updater; a running EXE is not overwritten.
- Investigation performance improvements remain an optimization task after UX validation.
