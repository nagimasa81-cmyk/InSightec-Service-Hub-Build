WaterSystemAnalyzer Version 7.3 RC1-13 PerfAndFallbackToggle
================================================================

1) "Calendar Days still calculates as Global even with an SN selected"

This was intentional fallback behavior (explained in RC1-9), not a bug, but you should be
able to turn it off. New checkbox: "Allow Weibull to automatically use a broader scope
(Country/Region/Global) when the exact scope above doesn't have enough data on its own" -
checked by default (previous behavior unchanged). Uncheck it to force the exact Scope only;
you will then see "Weibull fit unavailable" instead of a silently broader result whenever
the exact SN/Country/Region alone isn't enough. This applies to both Calculate and Compare
All Life Axes.

2) "The Weibull window is just slow"

Root cause found: nearly every dialog action (opening the dialog, changing Scope, changing
Life Axis, pressing Calculate, Compare All Axes) was independently re-reading
Hospital_Master.xlsx / Replacement_History.xlsx / Log_Coverage_History.xlsx /
Log_Gap_Classification.xlsx from disk via openpyxl - often several times per click, and
"Compare All Life Axes" in particular could trigger this dozens of times (once per axis,
plus once per fallback scope tried per axis). openpyxl workbook loads are the expensive part
here, not the actual math.

Fix: added a small in-memory cache (lf_cached_master_rows / lf_write_master_rows /
lf_clear_cache) for these four files, used by every Life Forecast function. A file is now
read from disk at most once per dialog session unless something actually writes to it (in
which case only that file's cache entry is refreshed, in memory, from the rows just written -
no re-read needed). The cache is cleared whenever the dialog is freshly opened, or after
using Edit Hospital Master / Import Replacement History / Import ASM Replacement File /
Classify Log Gaps, so edits are always picked up correctly.

Verified: 5 repeated lf_load_hospitals()/lf_lookup_hospital() calls now trigger 1 disk read
instead of 5+; 3 repeated lf_build_intervals() calls trigger 2 disk reads (one per file) total
instead of 6.
