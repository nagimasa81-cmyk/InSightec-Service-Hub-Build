WaterSystemAnalyzer Version 7.3 RC1-14 BackupDetectFix
=========================================================

What this fixes (from the screenshot report):

Symptom: a ZIP created by the app's own "Backup Manager" / "Project Backup" feature was
rejected by "Restore Project Backup" with "This ZIP does not look like a Project Backup" /
"Detected: Update Package".

Root cause (pre-existing, unrelated to the Life Forecast work in RC1-4 through RC1-13):
classify_dropped_path() checked for a manifest.json file FIRST (returning "Update Package"
immediately if found anywhere in the zip), and only checked for the "Data/" folder prefix
(the actual signature of a real Project Backup, written by create_project_backup_to())
afterwards. A real backup's Data folder can perfectly legitimately contain a manifest.json
somewhere inside it - for example, left over from a previous "Import Release Package" /
Update Package extraction into the Data folder. Whenever that happened, the manifest.json
check fired first and the ZIP was misclassified as an Update Package, even though it was a
genuine backup.

Fix: swapped the check order. "Data/" prefix (the backup's actual structural signature) is
now checked first; only a ZIP with a root-level-ish manifest.json and NO "Data/" folder is
classified as an Update Package. This is used by both the general classify_dropped_path()
helper and the "Restore Project Backup" dialog (which calls it directly), so both are fixed
by the same change.

Verified: a synthetic ZIP built exactly like the bug scenario - Data/Master/... files plus a
nested Data/UpdatePackageSample/manifest.json - now correctly classifies as "Project
Backup", while a genuine root-level manifest.json + payload ZIP (no Data/ folder) still
correctly classifies as "Update Package".
