WaterSystemAnalyzer Version 7.3e ReplacementSelectionForecastGuide
====================================================================

- Selected preview row is highlighted in blue.
- Selected Record panel clearly shows Edit/Delete target.
- Component Type, Replacement Type, and Failure Type are dropdowns in Preview.
- Remove Selected requires confirmation with target details.
- Current Step / Next Action / Status are always visible.
- Forecast menu includes a vertical recommended workflow and numbered actions.
- Import completion explains the required next steps.
