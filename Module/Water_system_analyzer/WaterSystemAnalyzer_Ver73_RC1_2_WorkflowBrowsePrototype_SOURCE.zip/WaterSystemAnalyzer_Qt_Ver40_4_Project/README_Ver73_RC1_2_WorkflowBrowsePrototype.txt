WaterSystemAnalyzer Version 7.3 RC1-2 WorkflowBrowsePrototype
=================================================================

- Forecast actions are ordered by click sequence.
- Completed, recommended, and pending steps use ✓ / ▶ / □.
- A single Run Recommended Action button is provided.
- Dashboard Review is required before Calculate Forecast.
- Browse Folder, Browse ZIP, and Browse ResultSummary remain available.
- Drag and drop remains the primary operation.
