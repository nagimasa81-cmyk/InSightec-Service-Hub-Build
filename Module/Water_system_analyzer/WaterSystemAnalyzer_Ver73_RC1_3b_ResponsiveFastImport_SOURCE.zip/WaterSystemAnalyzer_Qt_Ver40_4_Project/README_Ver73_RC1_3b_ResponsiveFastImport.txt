WaterSystemAnalyzer Version 7.3 RC1-3b ResponsiveFastImport

- Unrelated TXT/LOG files are rejected by a 64 KB content probe.
- ZIP extraction skips unrelated files before extraction.
- Sidebar is scrollable and adapts to smaller windows.
- Drop Area spacing is reduced to prevent text overlap.
- Forecast actions show Analysis in progress while parsing.
- Controls unlock automatically after success or failure.
