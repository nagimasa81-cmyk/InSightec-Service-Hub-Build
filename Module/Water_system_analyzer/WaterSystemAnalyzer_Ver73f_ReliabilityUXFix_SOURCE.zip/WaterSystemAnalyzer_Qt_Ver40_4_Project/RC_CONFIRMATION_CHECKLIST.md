# Version 7.3 RC Confirmation Checklist

## Startup and session
- [ ] On first start, Project is open; other major menus are closed.
- [ ] Select a WaterSystem folder and close the application.
- [ ] Restart and confirm the prior session summary is shown.
- [ ] Click Continue Previous and confirm the last valid selection is restored.
- [ ] Click Start New and confirm paths/data are cleared.

## Interactive workflow
- [ ] Expand Forecast.
- [ ] Confirm Current Status and Next Recommended Action change with project/data state.
- [ ] Confirm the recommended button is highlighted.
- [ ] After Replacement History change, Runtime Reconstruction is recommended.
- [ ] After Runtime Reconstruction, Explainable Reliability is recommended.

## Terminology
- [ ] UI and new records use Degas Module.
- [ ] Import old DO / DO Module values and confirm conversion to Degas Module.

## Dashboard scope
- [ ] Open Dashboard Preview.
- [ ] Confirm default scope is Hospital.
- [ ] Test Selected Hospitals / Country / Region / Distributor / All Hospitals.
- [ ] Close/reopen and confirm scope selection is retained.

## Replacement History
- [ ] Selected row is clearly highlighted.
- [ ] Selected Record identifies Edit/Delete target.
- [ ] Component / Replacement Type / Failure Type are dropdowns.
- [ ] Legacy multi-hospital History.xlsx converts correctly.
- [ ] Manual Add/Edit/Remove works.

## Update Foundation
- [ ] Open Backup / Migration > Module Update Foundation.
- [ ] Select the included sample update ZIP.
- [ ] Confirm manifest details appear.
- [ ] Run Dry Run and confirm protected user-data checks.
- [ ] Run Backup and Stage.
- [ ] Confirm Data/Update/pending_update.json and Update/Staging are created.

## Regression
- [ ] Analyze / Update ResultSummary works.
- [ ] Runtime Reconstruction works.
- [ ] Reliability Dashboard works.
- [ ] Dashboard Preview works.
- [ ] Backup / Restore menus still open.
