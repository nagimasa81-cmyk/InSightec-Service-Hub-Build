# Version 7.3f Test Checklist

## GAP
- [ ] Run Runtime Reconstruction.
- [ ] Confirm only unusually long intervals appear under Potential GAP.
- [ ] Confirm normal intervals appear under Reference Intervals.
- [ ] Confirm the threshold references cleaning frequency.

## Workflow
- [ ] Confirm Current Step / Next Recommended Action are readable.
- [ ] Run Runtime Reconstruction; next action becomes Explainable Reliability.
- [ ] Run Explainable Reliability; Calculate Forecast becomes enabled/recommended.
- [ ] Calculate Forecast; workflow becomes complete/current.

## Dashboard
- [ ] Open Dashboard Preview without AttributeError.
- [ ] Hospital is the default scope.
- [ ] Hospital target dropdown is available.
- [ ] Scope selection persists after reopen.

## Replacement
- [ ] Filter preview by Hospital.
- [ ] Filter preview by Serial Number.
- [ ] Edit Component / Replacement Type / Failure Type via dropdown.
- [ ] Confirm Import remains enabled after edit.
- [ ] Confirm Edit/Delete target remains clear.

## Regression
- [ ] Legacy multi-hospital History.xlsx import works.
- [ ] Manual replacement entry works.
- [ ] Update Foundation opens.
- [ ] Continue Previous / Start New works.
