WaterSystemAnalyzer Version 7.3f ReliabilityUXFix
===================================================

Main fixes:
- GAP classification now uses normal cleaning/WaterSystem frequency.
- Only extremely long intervals appear in Potential GAP.
- Ordinary intervals are shown separately in Reference Intervals.
- Dashboard Preview scope_changed AttributeError fixed.
- Dashboard scope target is a dropdown (editable); Hospital remains default.
- Replacement preview has Hospital and Serial filters.
- Edit/dropdown changes refresh validation immediately; Import stays available.
- Explainable Reliability has its own action.
- Interactive Workflow advances correctly:
  Replacement -> Runtime -> Explainable -> Forecast -> Dashboard.
- Calculate Forecast is enabled only after Explainable Reliability.
- Interactive Workflow text is larger and shorter.
- Degas Module terminology retained.
- Update Foundation and session continuation retained.

Notes:
- Potential GAP threshold is based on the median cleaning interval and a robust
  long-interval threshold, with a minimum of 14 days.
- Hospital-specific grouping uses the currently loaded project. Full cross-project
  grouped reliability remains part of the model/scoping phase.
