WaterSystemAnalyzer Version 7.3 RC1-3 ProjectCardPrototype
=============================================================

Project UI prototype:
- Source is shown as filename/folder name plus file count.
- Full source path is available only as a tooltip.
- Large Drop Area is hidden after successful loading.
- Change Source expands the Drop Area again.
- ResultSummary uses its own compact card.
- Browse Folder / Browse ZIP / Browse ResultSummary remain available.
- Previous Session is shown only when a valid session exists.
- Long path text boxes are hidden from the normal UI.

Retained:
- Ordered Workflow Assistant
- Dashboard-First Runtime and Reliability views
- ZIP direct import and short extraction paths
- Update, session, and chart-control behavior
