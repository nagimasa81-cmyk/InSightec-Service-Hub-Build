WaterSystemAnalyzer Version 7.3f R1 DashboardScopeFix
===================================================

Fix:
- Dashboard Preview AttributeError: scope_changed was attached to the wrong dialog class.
- scope_changed is now correctly implemented inside DashboardPreviewDialog.
- Dashboard scope selector and persistence remain enabled.

Validation:
1. Build EXE.
2. Load a ResultSummary.
3. Open Dashboard Preview.
4. Confirm no AttributeError occurs.
5. Change Dashboard Scope and target, close, reopen, and confirm persistence.
