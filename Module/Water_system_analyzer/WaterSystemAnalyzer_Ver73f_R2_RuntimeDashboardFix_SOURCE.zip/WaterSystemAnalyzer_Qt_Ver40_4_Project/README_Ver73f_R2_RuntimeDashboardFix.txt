WaterSystemAnalyzer Version 7.3f R2 RuntimeDashboardFix
==========================================================

Fixes:
- Missing `statistics` import added.
- Dashboard Preview `scope_changed` class ownership verified.
- Runtime Reconstruction return signatures verified.
- Potential GAP / Reference Intervals behavior retained.
- Hospital/Serial filters, workflow guidance, session continuation,
  Degas Module terminology, and Update Foundation retained.

Please use VER73F_R2_QA_REPORT.md for the Windows validation sequence.
