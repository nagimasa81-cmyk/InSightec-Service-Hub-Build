WaterSystemAnalyzer Version 7.3b VisibleDashboardUX
===================================================

Fixes / Added:
- Dashboard Preview button is explicitly visible under Forecast.
- Dashboard Preview opens an independent visual dialog.
- Added Health Score card, Reliability Trend, Failure Distribution, Forecast Timeline, Confidence Breakdown, Why, and Details/JSON.
- Added tooltips for Forecast menu buttons.
- Progress popup is used when Dashboard Preview builds context.
- Data Foundation is retained.

Notes:
- Remaining Life and final Forecast Date are placeholders until Forecast Engine.
- Failure Distribution uses prototype/sample distribution until Section/Failure data is fully connected.
- Replacement import wizard/dropdown validation is planned for the next implementation step.
