WaterSystemAnalyzer Version 7.3 RC1-17 DbStatusBySN
=======================================================

New "Database Status by SN..." button (next to the other Database buttons in Life Forecast).

Shows one row per Serial Number known anywhere in the database (Hospital_Master,
Replacement_History, or Log_Coverage_History - a SN only in one of these still gets a row,
with the others shown as empty/zero so gaps in registration are visible):

  SN | Hospital | Country | Region | Status | Replacement Events | Last Replacement |
  Log Sessions | Total Runtime Hrs | Log Span | Gaps (idle / unknown / unclassified)

This is a quick way to see, per unit, how complete its data is: has it been registered in
Hospital_Master, does it have replacement history, has any log been linked to it yet, and
how many of its log gaps still need manual classification. Includes an "Export to Excel..."
button for the same table.

Verified with two synthetic SNs: one with a full picture (1 replacement event, 2 linked log
sessions with a gap between them correctly classified as Idle) and one registered in
Hospital_Master only, correctly showing all-zero/empty for the rest.
