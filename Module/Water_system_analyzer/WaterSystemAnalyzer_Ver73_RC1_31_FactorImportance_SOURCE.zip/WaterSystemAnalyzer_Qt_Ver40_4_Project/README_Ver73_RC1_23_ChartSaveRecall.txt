WaterSystemAnalyzer Version 7.3 RC1-23 ChartSaveRecall
==========================================================

Answering "can the chart be recalled later?": until this version, no - it existed only in
memory while the Life Forecast dialog was open, redrawn fresh on every Calculate, and
completely lost when the dialog closed. "Export Result to Excel" only ever saved the
numeric summary, never the chart itself.

Three new buttons next to "Compare All Life Axes...":

1) "Save Chart..." - saves the just-calculated chart (KM curve, Weibull fit, axis/unit,
   rug points, title) together with the settings that produced it (Scope, Model, Life Axis,
   Coverage Mode, Unknown handling, date range) and the summary text, under a name you give
   it. Stored in a new database table, Life_Forecast_Snapshots.

2) "Load Saved Chart..." - lists every saved chart (date, title, scope, life axis, model);
   double-click or select + Load to redraw it INSTANTLY from the saved data - no
   recalculation, so it looks exactly as it did when saved even if the underlying
   Replacement_History/Log_Coverage_History has changed since. "Delete Selected" removes
   old ones.

3) "Save Chart as Image..." - simple PNG export of the current chart, for pasting into a
   report/email outside the app.

Verified: saved a synthetic chart snapshot (KM curve, Weibull fit, settings, summary text),
confirmed it round-trips correctly through the database (JSON-encoded chart data parses
back with the exact same values), and confirmed deletion removes it.
