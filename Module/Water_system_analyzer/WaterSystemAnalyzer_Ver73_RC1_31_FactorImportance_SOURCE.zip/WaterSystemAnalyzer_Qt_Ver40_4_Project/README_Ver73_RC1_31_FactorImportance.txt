WaterSystemAnalyzer Version 7.3 RC1-31 FactorImportance
============================================================

New "Factor Importance..." button: evaluates which Life Axis (Calendar Days, Clean Count,
Treatment/Degas/Cleaning Circulate Hours) most deterministically drives replacement timing.

Method: fits a Weibull distribution on each axis (same fitting/fallback logic as Compare
All Life Axes), then computes each fit's coefficient of variation (CV) from its shape
parameter k. This is the standard reliability-engineering way to compare candidate "clocks"
for a wear-out mechanism - the true underlying driver of failure should show the LEAST
relative scatter (lowest CV) when time is measured in its unit, versus measuring in some
other unit that isn't the real cause. Axes are ranked ascending by CV (#1 = best candidate
driver); axes without enough data to fit are shown as "n/a" rather than guessed.

Results are shown as a horizontal bar chart (shorter bar = lower CV = better predictor) and
a table with rank / n used / fit basis / shape k / median / CV / a plain-language
interpretation, plus an Excel export.

Verified the CV formula against known Weibull theory (k=1, the exponential distribution,
gives CV=1.0 exactly; CV decreases monotonically as k increases, e.g. k=15.8 -> CV=0.078),
and ran the full evaluation end to end on a synthetic dataset: Calendar Days (which had real
replacement-history data) produced a valid ranked fit (k=2.957, CV=0.368), while the usage
axes (which had no linked log coverage in that test) correctly reported "n/a" instead of a
misleading result.
