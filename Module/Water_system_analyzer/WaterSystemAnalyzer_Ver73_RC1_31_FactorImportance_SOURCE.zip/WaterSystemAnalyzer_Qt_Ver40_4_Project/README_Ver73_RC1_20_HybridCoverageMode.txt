WaterSystemAnalyzer Version 7.3 RC1-20 HybridCoverageMode
=============================================================

New 4th Coverage Mode: "Hybrid (measured portion real + estimated fill for unknown/
unmarked gaps only)".

Why: the previous three modes always treated a replacement interval as a single unit -
Strict/Assume-idle either use an interval whole or exclude it entirely; Extrapolate scales
the ENTIRE interval up from whatever fraction is logged. None of them let a partially-logged
interval keep its real measured data for the days that ARE logged while only estimating the
days that aren't.

How Hybrid works, per interval:
  - Days covered by a linked log session: use the real recorded usage as-is (never
    estimated).
  - Days inside a gap marked Idle: contribute zero, same as every other mode - a real
    "not used" period should never be padded with an estimate.
  - Days that are Unknown-marked OR still unclassified: filled in using a rate (usage per
    day) - this SN's own rate (its measured usage / its own covered days) if it has any log
    coverage at all, otherwise the global average rate across every linked SN
    (lf_usage_rates). This is exactly the "old period with no logs, but the machine was
    presumably running" case - it gets estimated, not thrown away, but it never overrides
    real data where real data exists.
  - An interval is only excluded if it has neither any measured usage nor any rate to fall
    back on (nothing at all to go on).

This directly targets the mixed old/new log coverage situation: intervals fully in the
logged era behave like Strict/Assume-idle (real data), intervals with no log era rely on the
population rate (similar to Extrapolate in effect for that portion), and mixed intervals get
the best of both instead of an all-or-nothing choice.

Verified: a synthetic interval with two logged sessions (57 Clean Count over 182 covered
days) and a 91-day gap behaves correctly across all four modes, and re-classifying that gap
Idle vs Unknown correctly switches Hybrid between "no fill" (57) and "filled" (85.5, matching
Extrapolate's result for this case since the gap's rate assumption is the same either way).
