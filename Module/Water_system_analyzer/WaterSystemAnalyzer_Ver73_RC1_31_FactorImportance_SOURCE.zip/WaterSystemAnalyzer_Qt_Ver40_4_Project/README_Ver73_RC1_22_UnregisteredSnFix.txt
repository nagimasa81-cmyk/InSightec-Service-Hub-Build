WaterSystemAnalyzer Version 7.3 RC1-22 UnregisteredSnFix
============================================================

Critical fix, from the report: "I entered 90 Replacement records, expecting Calendar Days
to use all 90, but only the SNs I'd read WaterSystem logs for were actually used."

Root cause: lf_build_intervals() looked up each SN's metadata via lf_load_hospitals()
(backed by Hospital_Master), and silently skipped the SN entirely - via `if not meta:
continue` - whenever it had no Hospital_Master row. Hospital_Master rows only ever got
created for a SN through "Link Analyzed Logs to Database", "Edit Hospital Master", or an
ASM import - never automatically just from adding a Replacement_History row (e.g. via
"Replacement History - Quick Edit" or the Import Wizard). So any SN added only to
Replacement_History, without also registering it in Hospital_Master, had 100% of its data
silently dropped from every Life Forecast calculation - including Calendar Days, which
needs nothing but the replacement dates themselves and should never have depended on
Hospital_Master at all.

Fix: lf_load_hospitals() now also scans Replacement_History and Log_Coverage_History for
any Serial Number with no Hospital_Master row, and synthesizes a placeholder entry for it
(Hospital Name taken from the Replacement_History row if present, Country/Region
"(Unset)", Status "Active"). This makes lf_build_intervals (and everything downstream: SN
Status Overview, Compare All Life Axes, etc.) use every SN's data regardless of whether it
happens to be registered in Hospital_Master.

Also added: "Replacement History - Quick Edit" now reports, after saving, which SNs (if
any) still have no real Hospital_Master entry - their data is used either way now, but
Country/Region grouping won't work for them until they're registered via Edit Hospital
Master or Database Management.

Verified: reproduced the exact scenario (1 SN registered in Hospital_Master, 90
Replacement_History rows spanning 82 distinct SNs, most unregistered). Before this fix's
logic, only the 1 registered SN's events would have built any intervals; with the fix, all
82 SNs correctly contribute intervals, and an unregistered SN's synthesized metadata
(hospital name from its own row, Country/Region "(Unset)", Status "Active") is correct.
