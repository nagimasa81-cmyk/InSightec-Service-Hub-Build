WaterSystemAnalyzer Version 7.3 RC1-19 DatabaseManagementDialog
====================================================================

What changed: every database/master-data button that used to be scattered across the Life
Forecast dialog (and one on the main screen) is now in one place, a new "Database
Management" window, opened either from the main screen's Forecast group or from a single
"Database Management..." button inside Life Forecast.

Database Management contains, grouped:
  - Log Coverage: "Link Analyzed Logs to Database" (delegates to the main window's Analyze
    session, same as before) and "Classify Log Gaps..." with its own SN box (type or pick a
    SN - this no longer depends on whatever Scope happens to be selected in Life Forecast).
  - Master Data Editing: Edit Hospital Master, Import/Edit Replacement History, Replacement
    History Quick Edit.
  - Reports / Bulk Import: SN Status Overview, Import ASM Replacement File.
  - Database File: Export Database to Excel, Backup Database Now, Optimize (VACUUM).

Life Forecast itself now only has calculation-related controls (Model, Scope, Life Axis,
Coverage Mode, Calculate, Export Result, Compare All Life Axes) plus the one "Database
Management..." button and its own "Classify Log Gaps for this SN..." (kept there too,
since that one is intentionally tied to whatever Scope/SN is currently selected for the
calculation in progress - it's the one exception left in Life Forecast on purpose).

Cleanup note: while doing this, two duplicate/orphaned code paths were found and removed -
an earlier draft of the SN overview (open_db_status_by_sn, superseded by SN Status
Overview) and a duplicated button row in Life Forecast's own layout. Removing them changes
nothing about existing behavior; they were unreachable dead code.

Verified: the app still imports and compiles cleanly, and DatabaseManagementDialog
constructs without error (button wiring/signal connections all resolve).
