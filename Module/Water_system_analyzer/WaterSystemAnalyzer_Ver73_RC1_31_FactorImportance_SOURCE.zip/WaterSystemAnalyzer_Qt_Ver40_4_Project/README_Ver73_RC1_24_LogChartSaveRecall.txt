WaterSystemAnalyzer Version 7.3 RC1-24 LogChartSaveRecall
=============================================================

Correction from RC1-23: "Chart" meant the main WaterSystem-log analysis chart (the
interactive Treat/Degas/Clean/Runtime trend chart shown after Analyze, with its zoom/pan
and series checkboxes) - not the Life Forecast survival curve. RC1-23's save/recall was
built for the wrong chart; this version adds the same capability for the right one. (The
Life Forecast "Save Chart..."/"Load Saved Chart..."/"Save Chart as Image..." buttons from
RC1-23 remain, unrelated and unaffected - they're for the survival curve specifically.)

New, in the main screen's "Chart Controls" group, right after "Clear change":

1) "Save Chart..." - saves the current analysis chart: the parsed log data
   (self.summary_rows, including every DateTime), which series checkboxes are on/off, and
   the current zoom range (manual_x0/x1) and cumulative start/end choices - under a name
   you give it (pre-filled with the SN guessed from the loaded ResultSummary filename, same
   convention used elsewhere). Stored in a new database table, Log_Chart_Snapshots.

2) "Load Saved Chart..." - lists every saved chart (date, title, SN, period, row count);
   double-click or select + Load to redraw it INSTANTLY - no re-reading or re-analyzing the
   original WaterSystem_*.txt log files, and no folder needs to still exist or be selected.
   Restores the series checkboxes and zoom range exactly as saved. "Delete Selected" removes
   old ones. Loading also updates self.summary_rows, so Life Forecast's "Use Main Analysis
   session as data source" checkbox and inherited-SN detection work against the loaded
   snapshot too.

Verified: saved a synthetic 2-row chart snapshot (with real datetime values, mixed
checkbox states, and a zoom range), confirmed it round-trips through the database exactly -
DateTime objects deserialize back to real datetime instances, not strings - and confirmed
deletion removes it.
