WaterSystemAnalyzer Version 7.3 RC1-15 SqliteDatabase
========================================================

What changed: Master data storage switched from individual Master/*.xlsx files to a single
SQLite database, Data/WaterSystemAnalyzer.db (Python's built-in sqlite3 module - no new
dependency, requirements_py313_pyside6_nuitka.txt is unchanged).

Why here specifically: read_master_foundation_rows(filename, headers) and
write_master_foundation_rows(filename, headers, rows) are the single choke point every
existing caller already goes through - Master Foundation dialog (Edit Hospital Master),
Replacement Import Wizard, and every Life Forecast function (lf_register_hospital,
lf_append_log_coverage, lf_classify_gap, lf_import_asm_replacement_file, lf_build_intervals,
etc.). Redirecting just these two functions to SQLite means every one of those callers is
now database-backed automatically, with no changes needed anywhere else.

How it works:
  - Each xlsx file becomes one SQLite table (Hospital_Master, Component_Master,
    Replacement_History, Log_Coverage_History, Log_Gap_Classification), keyed only by name -
    no row IDs are needed because every existing caller already works by reading the whole
    table, editing the Python list, and writing the whole table back (the same pattern used
    for xlsx), so write_master_foundation_rows just does DELETE + re-INSERT of the full table
    each time.
  - Missing columns are added automatically (ALTER TABLE ADD COLUMN) the same way
    ensure_headers() used to for xlsx, so older schemas migrate forward safely.
  - One-time automatic migration: the first time the app runs after this update, if
    WaterSystemAnalyzer.db doesn't exist yet but old Master/*.xlsx files do, every row is
    copied into the new database automatically (migrate_xlsx_masters_to_sqlite). Nothing
    already recorded is lost. The original xlsx files are also copied to
    Master/PreSqliteMigration_Backup/ as an extra safety net.
  - Important, found during testing: the original xlsx files are intentionally NOT deleted
    after migration. There turned out to be a second, older, unrelated code path in this
    app (ensure_master_files/master_path/read_master_rows, used by get_hospital_for_sn /
    get_installation_date_for_site for the old "Calculate Forecast Now" stub) that
    recreates a blank Hospital_Master.xlsx/Replacement_History.xlsx - with a DIFFERENT,
    older column schema - the instant either file goes missing, since it runs on nearly
    every ensure_data_folders() call. Deleting them just made them reappear empty a moment
    later. Leaving the migrated-from xlsx files in place (already safely backed up
    regardless) avoids fighting that unrelated legacy code path; nothing in the Life
    Forecast / Master Foundation / Replacement Import features reads from them any more.

Verified: a simulated pre-upgrade Data folder (xlsx Hospital_Master with 2 rows,
Replacement_History with 1 row) migrates its rows correctly into SQLite, backs up the
originals, and read_master_foundation_rows/write_master_foundation_rows/lf_build_intervals
all work correctly against the new database on repeated calls; the ASM replacement-history
importer (203 events, 122 hospitals) was also re-verified end to end on the SQLite backend.
