WaterSystemAnalyzer Version 7.3 RC1-16 DbMaintenanceTools
=============================================================

Three new buttons in the Life Forecast dialog, under "Database (WaterSystemAnalyzer.db):"

1) "Export Database to Excel..."
   Writes every table (Hospital_Master, Component_Master, Replacement_History,
   Log_Coverage_History, Log_Gap_Classification) into one Excel workbook you choose the name
   and location for, one sheet per table with the same headers/formatting as the old
   standalone xlsx files - for sharing with someone who doesn't have the app, or just
   inspecting the data in Excel.

2) "Backup Database Now"
   Copies the current Data/WaterSystemAnalyzer.db file, with a timestamp, into Data/Backup/
   (the same Backup subfolder ensure_data_folders() already creates). This is a quick,
   standalone safety copy separate from the full "Project Backup" - useful right before a
   large import or bulk edit.

3) "Optimize Database (VACUUM)"
   Runs SQLite's VACUUM command, which rebuilds the file to reclaim space left behind by
   edits/deletes and defragment it. Purely a maintenance operation - it does not change any
   data, and shows the file size before/after so you can see the effect.

Note: the existing "Project Backup" feature already includes WaterSystemAnalyzer.db
automatically (it backs up the whole Data folder), so these are additional, more targeted
options on top of that, not a replacement for it.

Verified: all three were tested end to end (export produced a valid multi-sheet workbook
with correct row counts per table, backup copy matched the live database, and VACUUM ran
cleanly with data intact afterward).
