WaterSystemAnalyzer Version 7.3 RC1-21 InstallDateClamp
===========================================================

Confirmed and tightened: calculations only ever count time on/after each Site's
Installation Date, since a unit isn't actually in service before then.

Already correct before this update: lf_build_intervals() has always used Installation Date
as the starting boundary of a SN's very first replacement interval, and
lf_interval_usage_from_coverage()/lf_interval_gap_breakdown() clamp to whatever interval
they're given - so the core Weibull/KM calendar-day and usage-axis fits were already safe.

Two remaining gaps found and fixed:

1) lf_usage_rates() (the SN's own day-rate, and the global fallback rate used by Hybrid/
   Extrapolate) now clamps every Log_Coverage_History session to the SN's Installation Date
   before summing days/usage - a log session that starts before installation (test runs,
   data entry errors) can no longer inflate the rate. Verified: a session logged from
   2025-01-01 for a unit installed 2025-03-01 is correctly clamped to start 2025-03-01.

2) lf_detect_gaps() (used by "Classify Log Gaps...") now also surfaces the
   Installation-Date-to-first-log-session period as a classifiable gap, and clamps any
   session that starts before installation the same way as (1). Previously that early
   period was invisible to the gap-classification UI - the math already handled it
   correctly (falls into "unclassified"), but a person had no way to review or explicitly
   mark it. Verified: a unit installed 2024-01-01 with its first log session starting
   2025-01-01 now shows a classifiable 366-day gap for exactly that period.
