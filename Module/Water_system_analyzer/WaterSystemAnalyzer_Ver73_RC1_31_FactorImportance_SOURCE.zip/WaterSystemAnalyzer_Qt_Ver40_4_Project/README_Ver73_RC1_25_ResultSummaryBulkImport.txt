WaterSystemAnalyzer Version 7.3 RC1-25 ResultSummaryBulkImport
===================================================================

New: "Import ResultSummary File(s) into Chart Database..." button, next to "Load Saved
Chart..." in Chart Controls.

For every ResultSummary_<SN>.xlsx (or similarly-produced) file you already have on disk
from past analyses: select one or more files, and each is read the same way the app has
always been able to read a dropped/browsed ResultSummary (read_existing_rows +
read_chart_summary_direct + build_summary_rows) and saved straight into the
Log_Chart_Snapshots database - so it appears in "Load Saved Chart..." from then on without
needing to remember where the file is.

As requested, display state (which series were checked, zoom range) is not part of this -
just the underlying data, saved with a default view (every series shown, full range). The
existing "Save Chart..." button remains the way to also capture the exact
checkbox/zoom state for a chart you're currently looking at.

Verified with a real ResultSummary_4048.xlsx (from the earlier Watersystem.zip upload):
correctly read 289 rows, correctly inferred SN 4048 from the filename, and the resulting
snapshot appears correctly in the database (Period 2025/07/07 -> 2026/07/03, 289 rows).
