WaterSystemAnalyzer Version 7.3 RC1-26 UnifyHospitalSnLookup
=================================================================

What was found: the app had (at least) three separate, disconnected places that could each
claim to be "the" Hospital/SN data:

  1. The Database Management / Life Forecast Hospital_Master (SQLite-backed since RC1-15,
     maintained by Edit Hospital Master, Import ASM Replacement File, Link Analyzed Logs to
     Database, etc.) - this is the one that's actually kept up to date.
  2. An older, separate SN_Master.xlsx (SN, Hospital, System, Install Date, ...) that
     nothing in the app ever wrote a row into - it was created once with just headers and
     stayed empty forever.
  3. An older, separate Hospital_Master.xlsx with a different schema (Hospital, Country,
     Region, Installation Date, Data Coverage Note, Comment - no Serial Number column at
     all) used only by the old Calculate Forecast Now feature, via
     get_hospital_for_sn()/get_installation_date_for_site() - frozen at whatever it
     contained before RC1-15's SQLite migration (or empty, if it never existed), since
     nothing writes to it either.

This is exactly the reported symptom: entering a hospital/SN anywhere in the app only ever
updated store (1); stores (2) and (3), read by the old forecast feature, never saw it.

Fix: get_hospital_for_sn() and get_installation_date_for_site() now read from the same
unified Hospital_Master data as everything else (lf_load_hospitals()), instead of the
disconnected SN_Master.xlsx / old Hospital_Master.xlsx pair. There is now exactly one place
Hospital/SN data lives, and everything that looks it up - Database Management, Life
Forecast, and the old Calculate Forecast Now - sees the same thing.

Side effect (a genuine improvement, not just a side effect): Calculate Forecast Now, which
has been a non-functional stub since the very first analysis in this conversation (it
always returned a blank hospital and installation date because SN_Master.xlsx was always
empty), now actually reports a real hospital name and installation date whenever the SN is
registered - as long as it's registered anywhere via any of the current tools.

Verified: registered a hospital via lf_register_hospital(), then confirmed
get_hospital_for_sn/get_installation_date_for_site immediately see it, and confirmed
calculate_forecast() (Calculate Forecast Now's underlying function) now returns the correct
hospital name and installation date instead of blank/None. An unregistered SN still returns
blank/None cleanly, without error.

Known remaining legacy quirk (not fixed, out of scope for this pass): a separate,
older "Validate Masters" check and several other pre-existing features (Reliability
Dashboard, Explainable Reliability, Section/Failure/Replacement-Type/Reliability-Model
masters) still use their own master_path()/df_master_path() xlsx files, unrelated to
Hospital/SN data specifically. Say if you'd like those folded into the same database next.
