WaterSystemAnalyzer Version 7.3 RC1-30 ScenarioComparison
==============================================================

New "Scenario Comparison..." button next to "Compare All Life Axes...". Covers all three
directions requested:

1) Multiple assumption patterns for the same SN/scope - add several "Computed" rows, each
   with its own Scope + Scope Value + Unknown-handling + Coverage Mode, and see how the
   resulting Weibull curves diverge.

2) Manually-entered custom assumptions - add a "Custom" row and type a Shape k and a Median
   life directly (in whatever unit the shared Life Axis uses); it's converted to a full
   Weibull curve (scale lambda = median / ln(2)^(1/k), mean via the gamma function) and
   overlaid exactly like a computed one.

3) Multiple SNs/hospitals at once - just add one "Computed" row per SN/Country/Region you
   want to compare (Scope = Hospital (SN), a different Scope Value in each row).

All rows share one Life Axis (Calendar Days or a usage metric) so every curve is on the
same units and directly comparable. "Plot Comparison" overlays every scenario's Weibull
survival curve on one chart (each in its own color, with a legend showing the median), and
fills a results table with n used / fit basis (whether a fallback scope had to be used) /
shape k / scale lambda / median / mean for each row. "Export to Excel" saves that table.

Verified the underlying math directly: two Computed scenarios differing only in Unknown-
handling (Conservative vs Sensitivity) on the same synthetic multi-hospital dataset produced
different Weibull fits as expected (k=15.8/median=819 vs k=3.4/median=656), and a Custom
row's median-life-to-lambda conversion round-trips exactly (input median 700 -> lambda 950,
k 1.2 -> mean 893.7, consistent with the Weibull formulas). The chart/dialog widgets follow
the same PySide6 patterns already used and confirmed working elsewhere in this app (this
sandbox's lightweight Qt stub can't simulate real widget geometry, so full on-screen
rendering should be checked in the actual build).
