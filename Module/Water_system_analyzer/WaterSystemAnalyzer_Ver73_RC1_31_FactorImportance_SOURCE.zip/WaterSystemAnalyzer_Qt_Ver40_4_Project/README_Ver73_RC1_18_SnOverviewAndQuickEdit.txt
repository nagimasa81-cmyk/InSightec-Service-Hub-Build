WaterSystemAnalyzer Version 7.3 RC1-18 SnOverviewAndQuickEdit
==================================================================

Two new buttons in the Life Forecast dialog.

1) "SN Status Overview..."
   One row per known Serial Number (from Hospital_Master), combining:
     - Hospital / Country / Region / Status / Installation Date
     - Replacement History: count, last replacement date, last replacement type
     - Log Coverage: number of linked log sessions, total observed runtime hours, last
       linked log date
     - Whether that SN alone currently has enough data to fit its own Weibull (Yes/No) -
       so it's obvious at a glance which units still rely on a Country/Region/Global
       fallback in Life Forecast.
   Sortable by clicking any column header; "Export to Excel" writes the same table out.
   "Refresh" re-pulls current data (clears the Life Forecast cache first).

2) "Replacement History - Quick Edit..."
   A simple spreadsheet-style editor for Replacement_History, as an easier alternative to
   the full Import Wizard when you just need to add, fix, or remove a handful of entries -
   e.g. logging a new Degas Module replacement. Every cell is directly editable; "Add Row"
   adds a blank one, "Duplicate Selected Row" copies a row (handy for a repeat replacement
   of the same component/SN with just the date changed), "Delete Selected Row(s)" removes
   rows, and a filter box narrows the view by Hospital/SN/Component Type/Case Number.
   "Save All Changes" writes the whole table back and warns (without blocking) if any
   Replacement Type value isn't one of the standard Failure / Scheduled Replacement /
   Company Instruction / Hospital Request / Unknown - since Life Forecast treats anything
   else the same as Unknown.

Verified: lf_build_sn_status_overview() correctly combined a hospital with 3 replacement
records + 1 linked log session against one with neither, and the quick-edit save path
(read -> append a new row -> write) correctly persisted a 4th replacement record.
