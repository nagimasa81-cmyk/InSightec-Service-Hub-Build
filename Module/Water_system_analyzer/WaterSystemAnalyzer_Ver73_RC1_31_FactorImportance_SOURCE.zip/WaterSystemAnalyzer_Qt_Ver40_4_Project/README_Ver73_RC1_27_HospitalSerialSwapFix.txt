WaterSystemAnalyzer Version 7.3 RC1-27 HospitalSerialSwapFix
=================================================================

What this fixes (from the screenshot): rows like "Hospital Name=4069, Serial Number=TMU" -
the hospital name and serial number were swapped for every row imported via the "Import
History.xlsx" button in Step6.2 Master Foundation (a different, older import path than
"Import ASM Replacement File").

Root cause: import_history_xlsx_to_master() hardcoded Column A = Serial Number, Column B =
Hospital/Site name, per its own docstring. The actual file used had them the other way
around (Column A = Hospital name like "TMU", Column B = Serial Number like "4069"), so
every row got silently swapped on import - Hospital Name/Site ended up holding the serial
number, and Serial Number ended up holding the hospital name.

Fix:
  1) import_history_xlsx_to_master() no longer assumes a fixed column order. For each row,
     whichever of Column A/B is purely numeric is treated as the Serial Number; the other
     becomes the Hospital Name - regardless of which physical column it's in. Verified with
     a synthetic file laid out exactly like the problem case (Column A="TMU"/"CMUH", Column
     B="4069"/"4052"): now imports correctly as Hospital Name=TMU/CMUH, Serial
     Number=4069/4052.
  2) New "Fix Swapped Hospital/Serial Rows..." button in Database Management. Scans
     Hospital_Master for rows where Serial Number is non-numeric text while Hospital
     Name/Site is a pure number (the unambiguous signature of this bug) and swaps them back
     - only touching rows that clearly match the pattern, so already-correct rows (like a
     normal SN such as "4048" with a real hospital name) are left untouched. Verified: fixed
     2 deliberately-swapped rows in a test set while correctly leaving a normal, correct row
     alone.

If you already have swapped rows from a previous import (as in the screenshot), run "Fix
Swapped Hospital/Serial Rows..." once in Database Management to correct them.
