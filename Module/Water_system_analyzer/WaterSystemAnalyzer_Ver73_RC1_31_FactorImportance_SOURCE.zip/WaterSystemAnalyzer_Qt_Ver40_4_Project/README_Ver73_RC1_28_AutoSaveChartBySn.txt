WaterSystemAnalyzer Version 7.3 RC1-28 AutoSaveChartBySn
============================================================

1) "Because of the swap bug, even a registered Site gets told it's not registered"

Confirmed - this was a direct consequence of the RC1-27 bug: any lookup by Serial Number
(e.g. checking whether a SN is already in Hospital_Master before offering to register it)
searches the "Serial Number" column, but a swapped row has the actual serial number sitting
in "Hospital Name"/"Site" instead - so the lookup finds nothing and reports "not
registered" even though that Site/SN pair does exist in the table, just corrupted. Running
"Fix Swapped Hospital/Serial Rows..." (added in RC1-27, in Database Management) repairs
this - once a row's Serial Number column actually holds the serial number again, every
lookup that searches by Serial Number works correctly.

2) New: the WaterSystem-log chart now saves itself automatically, linked to the Serial
   Number - no manual "Save Chart..." click needed.

   Hooked into both places that populate the chart's data:
     - Right after every successful Analyze.
     - Right after loading a previous ResultSummary file.

   Each auto-save infers the SN the same way the rest of the app already does (from the
   ResultSummary_<SN>.xlsx filename convention) and keeps exactly ONE auto-saved chart per
   SN (upsert - re-analyzing the same SN replaces its previous auto-save rather than piling
   up duplicates). It only touches its own auto-saved entries (titled "[Auto] SN <sn>");
   anything you named yourself via "Save Chart..." is never touched or overwritten by this.
   If the SN can't be inferred (e.g. no ResultSummary filename yet), auto-save is silently
   skipped - it never interrupts or blocks the main Analyze workflow.

Verified: analyzing the same SN twice with different data keeps exactly one snapshot for
that SN (updated to the latest data each time), while a separately named manual save for a
different SN is left completely untouched alongside it.
