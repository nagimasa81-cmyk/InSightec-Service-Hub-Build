from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Sequence

EXCLUDED_PARTS = {".git", "__pycache__", ".pytest_cache", ".mypy_cache", "site-packages", "node_modules", "work"}
SOURCE_ZIP_EXCLUDED_PATTERNS = ("program_update", "master_update", "plugin_update", "artifact", "built", "distribution", "release")
PREFERRED_BUILD_BATS = ("01_BUILD_EXE_NUITKA.bat", "01_BUILD_EXE.bat", "BUILD_EXE_NUITKA.bat", "BUILD_EXE.bat")


class BuildControllerError(RuntimeError):
    pass


@dataclass(frozen=True)
class BuildPlan:
    module_name: str
    module_path: str
    source_zip: str
    source_root: str
    method: str
    build_file: str
    build_path: str
    build_name: str


@dataclass(frozen=True)
class BuildResult:
    artifact_name: str
    artifact_zip: str
    package_root: str
    log_dir: str
    build_seconds: float


def write_github_output(key: str, value: str) -> None:
    output_path = os.environ.get("GITHUB_OUTPUT")
    if not output_path:
        return
    normalized = str(value).replace("\r", " ").replace("\n", " ")
    with open(output_path, "a", encoding="utf-8") as handle:
        handle.write(f"{key}={normalized}\n")


def is_excluded(path: Path) -> bool:
    lowered_parts = {part.lower() for part in path.parts}
    return any(part.lower() in lowered_parts for part in EXCLUDED_PARTS)


def safe_remove(path: Path) -> None:
    if not path.exists():
        return
    if path.is_file() or path.is_symlink():
        path.unlink()
    else:
        shutil.rmtree(path)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def latest_source_zip(module_path: Path) -> Path:
    candidates: list[Path] = []
    for path in module_path.rglob("*.zip"):
        if not path.is_file() or is_excluded(path):
            continue
        lower_name = path.name.lower()
        if any(pattern in lower_name for pattern in SOURCE_ZIP_EXCLUDED_PATTERNS):
            continue
        candidates.append(path)
    if not candidates:
        raise BuildControllerError(f"No source ZIP was found below module folder: {module_path}")
    return max(candidates, key=lambda item: item.stat().st_mtime_ns)


def extract_source(source_zip: Path, work_dir: Path) -> Path:
    safe_remove(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(source_zip, "r") as archive:
        archive.extractall(work_dir)
    children = [child for child in work_dir.iterdir() if child.name != "__MACOSX"]
    if len(children) == 1 and children[0].is_dir():
        return children[0].resolve()
    return work_dir.resolve()


def find_named_file(root: Path, names: Sequence[str]) -> Path | None:
    for name in names:
        matches = sorted((p for p in root.rglob(name) if p.is_file() and not is_excluded(p)), key=lambda p: (len(p.parts), str(p).lower()))
        if matches:
            return matches[0]
    return None


def find_build_bat(root: Path) -> Path | None:
    preferred = find_named_file(root, PREFERRED_BUILD_BATS)
    if preferred:
        return preferred
    candidates = []
    for path in root.rglob("*.bat"):
        if not path.is_file() or is_excluded(path):
            continue
        name = path.name.lower()
        if re.search(r"build.*exe|exe.*build", name) or name.startswith("01_"):
            candidates.append(path)
    return sorted(candidates, key=lambda p: (len(p.parts), str(p).lower()))[0] if candidates else None


def find_spec(root: Path) -> Path | None:
    candidates = sorted((p for p in root.rglob("*.spec") if p.is_file() and not is_excluded(p)), key=lambda p: (len(p.parts), str(p).lower()))
    return candidates[0] if candidates else None


def find_entry_point(root: Path) -> Path | None:
    preferred = find_named_file(root, ("main.py", "app.py", "launcher.py"))
    if preferred:
        return preferred
    candidates = []
    for path in root.rglob("*.py"):
        if not path.is_file() or is_excluded(path):
            continue
        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if "__main__" in content:
            candidates.append(path)
    return sorted(candidates, key=lambda p: (len(p.parts), str(p).lower()))[0] if candidates else None


def detect_build_plan(repo_root: Path, module_name: str) -> BuildPlan:
    module_path = (repo_root / "Module" / module_name).resolve()
    if not module_path.is_dir():
        raise BuildControllerError(f"Module folder was not found: {module_path}")
    source_zip = latest_source_zip(module_path)
    source_root = extract_source(source_zip, module_path / "work")
    build_file = find_build_bat(source_root)
    method = "bat" if build_file else ""
    if not build_file:
        build_file = find_spec(source_root)
        method = "spec" if build_file else ""
    if not build_file:
        build_file = find_entry_point(source_root)
        method = "nuitka" if build_file else ""
    if not build_file:
        raise BuildControllerError("No supported build input was found: build BAT, .spec, main.py, app.py, launcher.py, or Python __main__.")
    build_path = build_file.parent.resolve()
    if not str(build_path).strip():
        raise BuildControllerError("Detected build path is empty.")
    if not build_path.is_dir():
        raise BuildControllerError(f"Detected build path does not exist: {build_path}")
    return BuildPlan(module_name, str(module_path), str(source_zip.resolve()), str(source_root.resolve()), method, str(build_file.resolve()), str(build_path), build_file.name)


def run_command(command: Sequence[str], cwd: Path, log_path: Path, env: dict[str, str] | None = None) -> None:
    cwd = cwd.resolve()
    if not cwd.is_dir():
        raise BuildControllerError(f"Command working directory does not exist: {cwd}")
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    printable = subprocess.list2cmdline(list(command))
    print(f"\n>>> {printable}\n    cwd: {cwd}")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8", errors="replace") as log_handle:
        log_handle.write(f"\n>>> {printable}\ncwd: {cwd}\n")
        process = subprocess.Popen(command, cwd=str(cwd), env=merged_env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="")
            log_handle.write(line)
        exit_code = process.wait()
    if exit_code != 0:
        raise BuildControllerError(f"Command failed with exit code {exit_code}: {printable}")


def requirement_files(source_root: Path, build_path: Path) -> list[Path]:
    files: dict[str, Path] = {}
    for search_root in (build_path, source_root):
        for path in search_root.glob("requirements*.txt"):
            if path.is_file():
                files[str(path.resolve()).lower()] = path.resolve()
    return sorted(files.values(), key=lambda p: p.name.lower())


def install_dependencies(plan: BuildPlan, log_dir: Path) -> None:
    source_root = Path(plan.source_root)
    build_path = Path(plan.build_path)
    log_path = log_dir / "dependency_install.log"
    run_command([sys.executable, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"], build_path, log_path)
    for requirement in requirement_files(source_root, build_path):
        run_command([sys.executable, "-m", "pip", "install", "-r", str(requirement)], build_path, log_path)
    run_command([sys.executable, "-m", "pip", "install", "--upgrade", "pyinstaller", "nuitka", "ordered-set", "zstandard"], build_path, log_path)


def prepare_bat_for_ci(original_bat: Path, log_dir: Path) -> Path:
    content = original_bat.read_text(encoding="utf-8", errors="ignore")
    content = re.sub(r"(?im)^\s*pause\s*$", "rem pause removed for GitHub Actions", content)
    if re.search(r"(?i)-m\s+nuitka", content) and not re.search(r"(?i)--assume-yes-for-downloads", content):
        content = re.sub(r"(?i)(-m\s+nuitka\b)", r"\1 --assume-yes-for-downloads", content, count=1)
    elif re.search(r"(?im)^\s*nuitka(?:\.exe)?\s+", content) and not re.search(r"(?i)--assume-yes-for-downloads", content):
        content = re.sub(r"(?im)^(\s*nuitka(?:\.exe)?\s+)", r"\1--assume-yes-for-downloads ", content, count=1)
    prepared = original_bat.with_name(f"{original_bat.stem}_GITHUB_CI.bat")
    prepared.write_text(content, encoding="utf-8", newline="\r\n")
    (log_dir / "prepared_bat_path.txt").write_text(str(prepared.resolve()), encoding="utf-8")
    return prepared


def execute_build(plan: BuildPlan, log_dir: Path) -> float:
    started = time.perf_counter()
    build_path = Path(plan.build_path)
    build_file = Path(plan.build_file)
    env = {"NUITKA_ASSUME_YES_FOR_DOWNLOADS": "yes", "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"}
    log_path = log_dir / "build.log"
    if plan.method == "bat":
        prepared = prepare_bat_for_ci(build_file, log_dir)
        run_command(["cmd.exe", "/d", "/s", "/c", f'call "{prepared}"'], build_path, log_path, env)
    elif plan.method == "spec":
        run_command([sys.executable, "-m", "PyInstaller", "--noconfirm", str(build_file)], build_path, log_path, env)
    elif plan.method == "nuitka":
        run_command([sys.executable, "-m", "nuitka", "--mode=standalone", "--enable-plugin=pyside6", "--windows-console-mode=disable", "--assume-yes-for-downloads", "--output-dir=build", str(build_file)], build_path, log_path, env)
    else:
        raise BuildControllerError(f"Unsupported build method: {plan.method}")
    return time.perf_counter() - started


def copy_tree_contents(source: Path, destination: Path) -> int:
    copied = 0
    destination.mkdir(parents=True, exist_ok=True)
    for item in source.iterdir():
        target = destination / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        else:
            shutil.copy2(item, target)
        copied += 1
    return copied


def find_candidate_output_dirs(plan: BuildPlan) -> list[Path]:
    build_path = Path(plan.build_path)
    source_root = Path(plan.source_root)
    direct = [build_path / "dist", build_path / "release", build_path / "output", build_path / "build", build_path / "main.dist"]
    detected = sorted({p.resolve() for root in (build_path, source_root) for p in root.rglob("*.dist") if p.is_dir() and not is_excluded(p)}, key=lambda p: str(p).lower())
    result, seen = [], set()
    for path in direct + detected:
        resolved = path.resolve()
        key = str(resolved).lower()
        if resolved.is_dir() and key not in seen:
            result.append(resolved)
            seen.add(key)
    return result


def collect_executables(plan: BuildPlan) -> list[Path]:
    source_root = Path(plan.source_root)
    return sorted({p.resolve() for p in source_root.rglob("*.exe") if p.is_file() and not is_excluded(p)}, key=lambda p: str(p).lower())


def package_results(plan: BuildPlan, output_root: Path, log_dir: Path, build_seconds: float) -> BuildResult:
    package_root = output_root / "distribution"
    safe_remove(package_root)
    package_root.mkdir(parents=True, exist_ok=True)
    copied_count = 0
    copied_sources: list[str] = []
    for candidate in find_candidate_output_dirs(plan):
        copied_count += copy_tree_contents(candidate, package_root / candidate.name)
        copied_sources.append(str(candidate))
    for executable in collect_executables(plan):
        target = package_root / executable.name
        if not target.exists():
            shutil.copy2(executable, target)
            copied_count += 1
            copied_sources.append(str(executable))
    if copied_count == 0:
        raise BuildControllerError("Build finished, but no EXE or supported output directory was found.")
    python_version = f"{sys.version_info.major}{sys.version_info.minor}"
    safe_module = re.sub(r"[^A-Za-z0-9_.-]", "_", plan.module_name)
    artifact_name = f"{safe_module}_Python{python_version}_build"
    artifact_zip = output_root / f"{artifact_name}.zip"
    if artifact_zip.exists():
        artifact_zip.unlink()
    with zipfile.ZipFile(artifact_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in package_root.rglob("*"):
            if path.is_file():
                archive.write(path, path.relative_to(package_root))
    manifest = {"artifact_name": artifact_name, "artifact_zip": str(artifact_zip.resolve()), "module_name": plan.module_name, "python_version": sys.version, "build_method": plan.method, "build_file": plan.build_file, "source_zip": plan.source_zip, "source_zip_sha256": sha256_file(Path(plan.source_zip)), "copied_sources": copied_sources, "build_seconds": round(build_seconds, 3)}
    (log_dir / "build_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    return BuildResult(artifact_name, str(artifact_zip.resolve()), str(package_root.resolve()), str(log_dir.resolve()), build_seconds)


def command_detect(args: argparse.Namespace) -> int:
    plan = detect_build_plan(Path(args.repo_root).resolve(), args.module)
    payload = json.dumps(asdict(plan), indent=2, ensure_ascii=False)
    print(payload)
    if args.plan_file:
        path = Path(args.plan_file).resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(payload, encoding="utf-8")
    for key, value in asdict(plan).items():
        write_github_output(key, str(value))
    return 0


def command_build(args: argparse.Namespace) -> int:
    repo_root = Path(args.repo_root).resolve()
    output_root = Path(args.output_root).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    log_dir = output_root / "build_logs"
    safe_remove(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    try:
        plan = detect_build_plan(repo_root, args.module)
        (log_dir / "build_plan.json").write_text(json.dumps(asdict(plan), indent=2, ensure_ascii=False), encoding="utf-8")
        print(json.dumps(asdict(plan), indent=2, ensure_ascii=False))
        if not args.skip_dependencies:
            install_dependencies(plan, log_dir)
        build_seconds = execute_build(plan, log_dir)
        result = package_results(plan, output_root, log_dir, build_seconds)
        payload = json.dumps(asdict(result), indent=2, ensure_ascii=False)
        print(payload)
        (log_dir / "build_result.json").write_text(payload, encoding="utf-8")
        for key, value in asdict(result).items():
            write_github_output(key, str(value))
        return 0
    except Exception as exc:
        message = f"{type(exc).__name__}: {exc}"
        print(message, file=sys.stderr)
        (log_dir / "failure.txt").write_text(message, encoding="utf-8")
        write_github_output("log_dir", str(log_dir.resolve()))
        raise


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Detect, build, log, and package a selected service module.")
    sub = parser.add_subparsers(dest="command", required=True)
    detect = sub.add_parser("detect")
    detect.add_argument("--module", required=True)
    detect.add_argument("--repo-root", default=".")
    detect.add_argument("--plan-file")
    detect.set_defaults(func=command_detect)
    build = sub.add_parser("build")
    build.add_argument("--module", required=True)
    build.add_argument("--repo-root", default=".")
    build.add_argument("--output-root", required=True)
    build.add_argument("--skip-dependencies", action="store_true")
    build.set_defaults(func=command_build)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        return int(args.func(args))
    except BuildControllerError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    except (OSError, subprocess.SubprocessError, zipfile.BadZipFile) as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
