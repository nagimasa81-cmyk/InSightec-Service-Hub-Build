# Commit 0009 — GitHub Build Controller

This package replaces the long PowerShell build chain with one Python controller.

## Files

```text
.github/workflows/selected_auto_python.yml
tools/build_controller.py
```

## Main fixes

- Prevents `Join-Path` from receiving an empty build path.
- Detects the newest eligible source ZIP below `Module/<module>`.
- Extracts the ZIP into `Module/<module>/work`.
- Detects BAT, PyInstaller spec, or direct Nuitka build automatically.
- Supports Python 3.14 with fallback to Python 3.13.
- Adds Nuitka non-interactive download handling.
- Uploads build logs even when the build fails.
- Packages standalone output and EXE files automatically.
- Uses a 180-minute workflow timeout.

## Installation

Copy both files into the repository while preserving their paths, replacing the existing workflow.

## Local detection test

```bat
python tools\build_controller.py detect --module Water_system_analyzer --repo-root .
```

## Local full build test

```bat
python tools\build_controller.py build --module Water_system_analyzer --repo-root . --output-root build_test
```
