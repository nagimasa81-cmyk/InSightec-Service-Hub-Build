WaterSystemAnalyzer Version 7.3 RC1-37 ForecastDatesAndScreenFit
======================================================================

1) Scenario Comparison and Factor Importance now show a Forecast Date column.

   - Scenario Comparison: each row (Computed or Custom) gets a Forecast Date whenever its
     "Scope Value" names a real, registered SN - the SN's own last replacement date and
     current age are used together with that row's fit (computed OR the manually-entered
     Custom k/median) to predict its next replacement date, exactly like the main
     Calculate screen does for a single scope. Rows scoped at a population level (Country/
     Region/Global/"All") show a blank Forecast Date, since there's no single unit to date.
   - Factor Importance: the same Forecast Date is added per Life Axis whenever the
     dialog's Scope = Hospital (SN) and Scope Value is a real SN - so you can see not just
     which axis best explains life (by CV) but what date each axis's model actually
     predicts for that unit.
   - Implemented via a new shared helper, lf_quick_forecast_date(), which correctly
     handles both Calendar Days fits and usage-axis fits (Clean Count, Circulate Hours) by
     converting the residual back to a calendar date using that specific SN's own usage
     rate, independent of whichever population the fit itself came from.

2) Popup windows now fit within the screen.

   Every dialog added in this project (Life Forecast, Database Management, Scenario
   Comparison, Factor Importance, Weibull Probability Plot, SN Status Overview, Gap
   Classification, Replacement History Quick Edit, Saved Log Analysis Charts) now sizes
   itself through a new fit_dialog_to_screen() helper instead of a fixed pixel size - it
   still requests the same size as before, but caps it to the available screen area (via
   Qt's screen().availableGeometry()) so it can never open larger than the screen and get
   cut off. Pre-existing dialogs from before this project were left untouched.

Verified: lf_quick_forecast_date() correctly finds a SN's open (ongoing) interval, computes
its age from the real last replacement date, and produces a forecast date consistent with
the fit passed in (tested against a Global Weibull fit applied to one specific SN's own
age/history).
