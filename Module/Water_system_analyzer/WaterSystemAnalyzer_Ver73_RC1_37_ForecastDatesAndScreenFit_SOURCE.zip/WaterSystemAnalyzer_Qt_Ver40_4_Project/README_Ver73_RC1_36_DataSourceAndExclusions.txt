WaterSystemAnalyzer Version 7.3 RC1-36 DataSourceAndExclusions
====================================================================

Two new controls in Life Forecast, right below "Allow Weibull to automatically use a
broader scope...":

1) "Data Source (for the statistical fit)": Scope + Value fields, separate from the target
   Scope/Scope Value above. By default ("(same as target Scope above)", value left blank),
   nothing changes - the fit still uses the target scope, auto-escalating (Country -> Region
   -> Global) only if that scope alone has too little data, exactly as before.

   Set this explicitly (e.g. Scope=Country, Value=Japan) to MANUALLY choose which
   population's data fits the model, decoupled from what you're forecasting for. This
   answers "各サイト、各国、各region、グローバル個別に次の予測を計算...その時にどの範囲の
   データを使うか": you can forecast for one Site while explicitly fitting on its whole
   Country, Region, or Global population instead of relying on automatic escalation - the
   Forecast table still lists the target Site's own unit(s), just using the manually chosen
   data source's Weibull fit. No further auto-escalation happens once you've set this
   manually; it uses exactly what you chose.

2) "Exclude SNs (comma-separated)": any SN listed here is removed from ALL data - Target,
   Data Source, and every fallback level - before any scope filtering happens. For known
   outliers or units under separate investigation that shouldn't influence the model at
   all, for either the target or the fitting population.

Both are reported in the calculated summary text (which SNs were excluded, and which exact
Data Source was used if manually overridden).

Verified on a synthetic 4-hospital dataset: excluding a deliberately-added "OutlierSite" SN
correctly dropped it everywhere (20 -> 15 intervals total), and manually setting Data
Source = Country/Japan while targeting a single Site (4048) correctly built a Weibull fit
from that Country's data (Japan, outlier excluded: 10 intervals, k=3.6) independently of
the target Site's own small dataset (5 intervals).
