WaterSystemAnalyzer Version 7.3 RC1-35 WeibullProbabilityPlot
===================================================================

New "Weibull Probability Plot..." button in Life Forecast, next to "Save Chart as Image...".

Shows the classic reliability-engineering diagnostic plot: ln(x) on the x-axis, ln(-ln(1-p))
on the y-axis. The Kaplan-Meier survival curve from the last Calculate is transformed into
this linearized space and plotted as points; the fitted Weibull line is overlaid (since
S(t) = exp(-(t/lambda)^k) implies ln(-ln(S)) = k*ln(t) - k*ln(lambda), a straight line of
slope k). If the fit is good, the points sit close to the line - curved/bowed points are a
visual signal that Weibull may not be the right model for that data, exactly like the
reference image.

Uses whatever the most recent "Calculate" produced (same km_curve/weibull_fit/unit stored
for "Save Chart..."), so no recalculation is needed - just run Calculate once, then open
this to see the diagnostic view alongside the usual survival chart.

Verified the math itself against a known Weibull distribution (k=1.699, lambda=1029.48,
matching the reference image's estimated values): generating survival points directly from
that distribution and transforming them lands exactly on the fitted line (difference =
0.000000 at every test point), confirming the ln(x)/ln(-ln(1-p)) linearization and the line
equation are implemented correctly.
