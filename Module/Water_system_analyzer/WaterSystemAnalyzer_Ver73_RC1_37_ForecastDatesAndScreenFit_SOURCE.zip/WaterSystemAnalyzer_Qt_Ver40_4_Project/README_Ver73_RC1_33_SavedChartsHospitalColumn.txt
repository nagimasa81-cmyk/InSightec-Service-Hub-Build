WaterSystemAnalyzer Version 7.3 RC1-33 SavedChartsHospitalColumn
======================================================================

What changed: "Saved Log Analysis Charts" (the "Load Saved Chart..." picker) now shows a
"Hospital" column between Serial Number and Period Start, looked up from Hospital_Master
by that row's SN - so you can tell which site a saved chart belongs to without having to
remember/cross-reference the SN yourself.

If a SN has no Hospital_Master entry, the column is left blank rather than showing an
internal placeholder string.

Verified: a registered SN (4083 -> "Miyagi") shows its hospital name correctly, while an
unregistered SN shows a blank cell instead of the raw "(not registered in Hospital_Master)"
placeholder text.
