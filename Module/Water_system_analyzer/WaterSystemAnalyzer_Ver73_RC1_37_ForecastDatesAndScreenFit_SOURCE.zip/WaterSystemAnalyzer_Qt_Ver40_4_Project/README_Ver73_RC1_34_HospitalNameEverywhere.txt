WaterSystemAnalyzer Version 7.3 RC1-34 HospitalNameEverywhere
===================================================================

What changed: every place that shows a Serial Number (SN) now also shows the hospital name
next to it, wherever it's known - not just the "Saved Log Analysis Charts" picker from last
time.

  - Life Forecast: a "-> Hospital Name" label appears next to the Scope Value dropdown
    whenever Scope = Hospital (SN) and that SN is registered.
  - Database Management: the same kind of label appears next to the "Gap classification
    SN" box.
  - "Classify Log Gaps" dialog title now reads "Classify Log Gaps - SN 4048 (Hospital)"
    instead of just the SN.
  - Factor Importance: the same "-> Hospital Name" label next to its Scope Value field.
  - A new shared helper, lf_scope_label(), is now used everywhere a "Scope = Value" basis
    string is built or displayed (Calculate's summary text, Compare All Life Axes,
    Scenario Comparison, Factor Importance) - so any "Hospital (SN) = 4048" text
    automatically becomes "Hospital (SN) = 4048 (Hospital Name)" when that SN is
    registered, with no per-dialog duplication.

An unregistered SN is left showing just the SN (no misleading placeholder text), same
behavior as the Saved Charts picker fix.

Verified: lf_scope_label() returns "Hospital (SN) = 4048 (北野)" for a registered SN,
"Hospital (SN) = 9999" (unchanged) for an unregistered one, and passes Country/Region/
Global scopes through unmodified since hospital names don't apply to those.
