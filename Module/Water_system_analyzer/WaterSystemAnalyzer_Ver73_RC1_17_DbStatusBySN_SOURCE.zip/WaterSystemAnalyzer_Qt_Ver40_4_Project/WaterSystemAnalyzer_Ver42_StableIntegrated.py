# -*- coding: utf-8 -*-
"""
WaterSystem Analyzer Qt Ver40
=============================

Ver40 goals:
- Qt GUI, no tkinter.
- Worker-thread analysis; UI does not freeze.
- ResultSummary file selection is a file dialog.
- If a ResultSummary file is selected:
    * Analyze/update uses that file as the base.
    * Save updates that selected workbook path instead of creating a new file.
    * If serial number changes, the selected file is renamed and the selected-file path is updated.
- If no ResultSummary file is selected:
    * Analyze uses only the log files in the selected folder by default.
    * Existing ResultSummary is used only when the checkbox is enabled.
    * Save creates ResultSummary_<SN>.xlsx.
- CRC32 + file size duplicate prevention.
- X Start/End defines chart horizontal axis.
- Cum Start/End recalculates cumulative curves only.
- Checkboxes update chart immediately.
- Display Size presets.
"""

from __future__ import print_function
import hashlib
import statistics
import uuid

import os
import zipfile
from pathlib import Path
import re
import sys
import glob
import zlib
import time
import shutil
import traceback
import json
import math
import datetime as dt
import sqlite3

from PySide6 import QtCore, QtWidgets, QtGui
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QMessageBox, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QCheckBox, QComboBox, QScrollArea, QInputDialog,
    QProgressBar, QLineEdit, QGraphicsView, QGraphicsScene
)

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter



APP_NAME = "WaterSystem Analyzer Version 7.3 RC1-17 DbStatusBySN"
APP_VERSION = "7.3-RC1-17-DbStatusBySN"
ALGORITHM_VERSION = "Ver7.3-RC1-17-DbStatusBySN"

RESULT_HEADERS = [
    "File Name",
    "Start Datetime (YYYY-MM-DD HH:MM)",
    "TREAT_CIRCULATE (HH:MM:SS)",
    "DEGAS_CIRCULATE (HH:MM:SS)",
    "CLEAN_TANK_CIRCULATE (HH:MM:SS)",
    "CLEAN_XD_CIRCULATE (HH:MM:SS)",
    "Total File Runtime (HH:MM:SS)",
    "Total File Runtime (Seconds)",
    "Total Circulate Time (Seconds)",
    "DEGAS_PAUSE (HH:MM:SS)",
    "TREAT_PAUSE (HH:MM:SS)",
    "ERROR (HH:MM:SS)",
    "Clean Count",
    "Primary Flow",
    "Chiller Temp",
    "Absolute Pressure",
    "Dynamic Pressure",
    "File CRC32",
    "File Size",
]


def normalize_space(s):
    return " ".join(str(s).replace("\t", " ").split())


def get_token(line, idx):
    p = normalize_space(line).split(" ")
    return p[idx].strip() if 0 <= idx < len(p) else ""


def parse_time_seconds(line):
    m = re.match(r"^\s*(\d{1,2}):(\d{2}):(\d{2})", str(line))
    if not m:
        return None
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3))


def seconds_to_hms(sec):
    sec = int(round(float(sec or 0)))
    if sec < 0:
        sec = 0
    return "%02d:%02d:%02d" % (sec // 3600, (sec % 3600) // 60, sec % 60)


def hms_to_seconds(v):
    if isinstance(v, (int, float)):
        return float(v)
    m = re.match(r"^\s*(\d+):(\d{2}):(\d{2})", str(v or ""))
    if not m:
        return 0.0
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3))


def month_value(s):
    return {
        "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
        "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12
    }.get(str(s).lower()[:3], 0)


def build_file_datetime_text(name):
    """
    Robust filename datetime parser.
    Supports weekday-included names:
      WaterSystem_Fri_Apr_10_11_44_23_2026.txt
      WaterSystem_Mon_Apr_20_18_48_50_2026.txt
      WaterSystem_Thu_Apr_02_08_28_03_2026.txt
    """
    base = os.path.splitext(os.path.basename(str(name)))[0]
    s = base.replace("-", "_").replace(".", "_").replace(" ", "_")
    tokens = [t for t in re.split(r"[_\W]+", s) if t]
    weekdays = set(["mon","monday","tue","tues","tuesday","wed","wednesday",
                    "thu","thur","thurs","thursday","fri","friday",
                    "sat","saturday","sun","sunday"])

    def make_dt(y, mo, d, hh=0, mm=0, ss=0):
        try:
            y = int(y); mo = int(mo); d = int(d)
            hh = int(hh); mm = int(mm); ss = int(ss)
            if y < 2000 or y > 2100:
                return None
            return dt.datetime(y, mo, d, hh, mm, ss)
        except Exception:
            return None

    # Token parse: optional prefix, optional weekday, month name, day, hh, mm, ss, year
    for i in range(len(tokens)):
        low = tokens[i].lower()

        # Month + day + hh + mm + ss + year
        mo = month_value(tokens[i])
        if mo and i + 5 < len(tokens):
            d, hh, mm, ss, y = tokens[i+1], tokens[i+2], tokens[i+3], tokens[i+4], tokens[i+5]
            if (re.fullmatch(r"\d{1,2}", str(d)) and re.fullmatch(r"\d{1,2}", str(hh)) and
                re.fullmatch(r"\d{1,2}", str(mm)) and re.fullmatch(r"\d{1,2}", str(ss)) and
                re.fullmatch(r"20\d{2}", str(y))):
                out = make_dt(y, mo, d, hh, mm, ss)
                if out:
                    return out

        # Weekday + Month + day + hh + mm + ss + year
        if low in weekdays and i + 6 < len(tokens):
            mo = month_value(tokens[i+1])
            if mo:
                d, hh, mm, ss, y = tokens[i+2], tokens[i+3], tokens[i+4], tokens[i+5], tokens[i+6]
                if (re.fullmatch(r"\d{1,2}", str(d)) and re.fullmatch(r"\d{1,2}", str(hh)) and
                    re.fullmatch(r"\d{1,2}", str(mm)) and re.fullmatch(r"\d{1,2}", str(ss)) and
                    re.fullmatch(r"20\d{2}", str(y))):
                    out = make_dt(y, mo, d, hh, mm, ss)
                    if out:
                        return out

    # Token parse: year + month text + day + hh + mm + ss
    # Example: 2026_Jul_05_10_22_57
    for i in range(len(tokens) - 5):
        if re.fullmatch(r"20\d{2}", str(tokens[i])):
            mo = month_value(tokens[i+1])
            if mo:
                d, hh, mm, ss = tokens[i+2], tokens[i+3], tokens[i+4], tokens[i+5]
                if (re.fullmatch(r"\d{1,2}", str(d)) and re.fullmatch(r"\d{1,2}", str(hh)) and
                    re.fullmatch(r"\d{1,2}", str(mm)) and re.fullmatch(r"\d{1,2}", str(ss))):
                    out = make_dt(tokens[i], mo, d, hh, mm, ss)
                    if out:
                        return out

    # Year first numeric: 2026_07_05_10_22_57
    m = re.search(r"(20\d{2})\D+(\d{1,2})\D+(\d{1,2})\D+(\d{1,2})\D+(\d{1,2})(?:\D+(\d{1,2}))?", s)
    if m:
        out = make_dt(m.group(1), m.group(2), m.group(3), m.group(4), m.group(5), m.group(6) or 0)
        if out:
            return out

    # Year first month text: 2026_Jun_04_08_09_20
    m = re.search(r"(20\d{2})\D*([A-Za-z]{3,9})\D*(\d{1,2})\D+(\d{1,2})\D+(\d{1,2})(?:\D+(\d{1,2}))?", s)
    if m:
        mo = month_value(m.group(2))
        if mo:
            out = make_dt(m.group(1), mo, m.group(3), m.group(4), m.group(5), m.group(6) or 0)
            if out:
                return out

    # Month text first, year last, no weekday
    m = re.search(r"([A-Za-z]{3,9})\D*(\d{1,2})\D+(\d{1,2})\D+(\d{1,2})\D+(\d{1,2})\D+(20\d{2})", s)
    if m:
        mo = month_value(m.group(1))
        if mo:
            out = make_dt(m.group(6), mo, m.group(2), m.group(3), m.group(4), m.group(5))
            if out:
                return out

    # Day-month text first, year last
    m = re.search(r"(\d{1,2})\D+([A-Za-z]{3,9})\D+(\d{1,2})\D+(\d{1,2})\D+(\d{1,2})\D+(20\d{2})", s)
    if m:
        mo = month_value(m.group(2))
        if mo:
            out = make_dt(m.group(6), mo, m.group(1), m.group(3), m.group(4), m.group(5))
            if out:
                return out

    # Numeric month/day/time/year
    m = re.search(r"(\d{1,2})\D+(\d{1,2})\D+(\d{1,2})\D+(\d{1,2})\D+(\d{1,2})\D+(20\d{2})", s)
    if m:
        out = make_dt(m.group(6), m.group(1), m.group(2), m.group(3), m.group(4), m.group(5))
        if out:
            return out

    return None


def coerce_datetime(value):
    if isinstance(value, dt.datetime):
        return value
    if isinstance(value, dt.date):
        return dt.datetime(value.year, value.month, value.day)
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    for fmt in (
        "%Y/%m/%d %H:%M",
        "%Y/%m/%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d %H:%M:%S",
        "%m/%d/%Y %H:%M",
        "%m/%d/%Y %H:%M:%S",
        "%Y/%m/%d",
        "%Y-%m-%d",
        "%m/%d/%Y",
    ):
        try:
            return dt.datetime.strptime(s, fmt)
        except Exception:
            pass
    return None


WATERSYSTEM_CONTENT_MARKERS = (
    b"DEGAS_CIRCULATE", b"TREAT_CIRCULATE",
    b"CLEAN_TANK_CIRCULATE", b"CLEAN_XD_CIRCULATE",
    b"PRIMARYFLOW", b"SECONDARYFLOW", b"DO LEVEL",
)

def looks_like_watersystem_bytes(data):
    if not data:
        return False
    upper = bytes(data).upper()
    return any(marker in upper for marker in WATERSYSTEM_CONTENT_MARKERS)

def is_watersystem_file(path):
    name = os.path.basename(path).lower()
    ext = os.path.splitext(name)[1].lower()
    if ext not in (".txt", ".log"):
        return False
    if "resultsummary" in name or name.startswith(("forecast", "replacement", "hospital")):
        return False
    if "watersystem" in name or "water_system" in name:
        return True
    try:
        with open(path, "rb") as f:
            return looks_like_watersystem_bytes(f.read(65536))
    except Exception:
        return False


def scan_folder_diagnostics(folder):
    total = txtlog = accepted = resultsummary = 0
    samples = []
    for root, dirs, files in os.walk(folder):
        dirs[:] = [d for d in dirs if d.lower() not in ("$recycle.bin", "system volume information", "__pycache__")]
        for name in files:
            total += 1
            p = os.path.join(root, name)
            if os.path.splitext(name)[1].lower() in (".txt", ".log"):
                txtlog += 1
            if "resultsummary" in name.lower() and os.path.splitext(name)[1].lower() in (".xlsx", ".xlsm"):
                resultsummary += 1
            if is_watersystem_file(p):
                accepted += 1
                if len(samples) < 10:
                    samples.append(p)
    return {"total": total, "txtlog": txtlog, "accepted": accepted, "resultsummary": resultsummary, "samples": samples}


def file_crc32_hex(path):
    crc = 0
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            crc = zlib.crc32(b, crc)
    return "%08X" % (crc & 0xFFFFFFFF)


def content_key(h, size):
    if not h or size in ("", None):
        return ""
    return "CRC32SIZE|%s|%s" % (str(h).upper(), str(size))


def result_key(file_name, file_dt):
    d = file_dt.strftime("%Y-%m-%d %H:%M:%S") if isinstance(file_dt, dt.datetime) else str(file_dt or "")
    return "FILEDATE|%s|%s" % (str(file_name).lower().strip(), d.lower().strip())


def name_key(file_name):
    return "NAME|%s" % str(file_name).lower().strip()


def safe_sn(sn):
    sn = str(sn or "NA").strip() or "NA"
    return re.sub(r'[\\/:*?"<>|]+', "_", sn)


def resultsummary_mode_text(explicit_result_file, use_existing_result):
    if explicit_result_file:
        return "Explicit selected ResultSummary"
    if use_existing_result:
        return "Latest ResultSummary in selected folder"
    return "Log files only / no existing ResultSummary"


def resolve_resultsummary_base_file(folder, explicit_result_file, use_existing_result):
    """
    Step4 ResultSummary base-file policy.

    Priority:
    1. Explicit selected ResultSummary
    2. Latest ResultSummary in folder only when checkbox is ON
    3. Empty string: analyze log files only
    """
    if explicit_result_file:
        return explicit_result_file
    if use_existing_result:
        return find_latest_result_summary(folder) or ""
    return ""


def resultsummary_mode_text(explicit_result_file, use_existing_result):
    if explicit_result_file:
        return "Explicit selected ResultSummary"
    if use_existing_result:
        return "Latest ResultSummary in selected folder"
    return "Log files only / no existing ResultSummary"


def result_summary_path_for_sn(folder, sn):
    return os.path.join(folder, "ResultSummary_%s.xlsx" % safe_sn(sn))



def write_startup_log(message):
    try:
        base = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(base, "startup_error.log")
        with open(path, "a", encoding="utf-8") as f:
            f.write("[%s] %s\n" % (dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S"), message))
    except Exception:
        pass


def app_base_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))



def app_settings_path():
    return os.path.join(app_base_dir(), "WaterSystemAnalyzer_Settings.ini")


def default_data_folder():
    return os.path.join(app_base_dir(), "Data")


def get_data_root():
    """
    Step6.8:
    Default Data folder is under the EXE/application folder.
    User can move Data folder. The selected location is stored in WaterSystemAnalyzer_Settings.ini.
    """
    default_root = default_data_folder()
    path = default_root
    try:
        settings = app_settings_path()
        if os.path.exists(settings):
            with open(settings, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip().startswith("DataFolder="):
                        candidate = line.split("=", 1)[1].strip()
                        if candidate:
                            path = candidate
                        break
    except Exception:
        path = default_root
    return path or default_root


def set_data_root(path):
    path = os.path.abspath(path)
    os.makedirs(path, exist_ok=True)
    with open(app_settings_path(), "w", encoding="utf-8") as f:
        f.write("DataFolder=%s\n" % path)
        f.write("APP_VERSION=%s\n" % APP_VERSION)
        f.write("UPDATED=%s\n" % dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S"))
    return path



def master_foundation_path(name):
    root = ensure_data_folders()
    master = os.path.join(root, "Master")
    os.makedirs(master, exist_ok=True)
    return os.path.join(master, name)


HP_MASTER_HEADERS = ["Hospital Name", "Site", "Serial Number", "Installation Date", "Coil Type", "Status", "Comment", "Country", "Region"]
REPLACEMENT_HISTORY_HEADERS = ["Hospital Name", "Serial Number", "Component Type", "Component ID", "Coil ID", "Replacement Date", "Replacement Type", "Reason", "Comment", "Case Number"]
COMPONENT_MASTER_HEADERS = ["Hospital Name", "Serial Number", "Component Type", "Component ID", "Install Date", "Status", "Comment"]

# Version 7.3 RC1-5: growing, append-only index that links each analyzed WaterSystem log
# batch to a Serial Number (and, through Hospital_Master, to Hospital/Country/Region).
# Every time logs are analyzed and linked, one row is appended here - it is never
# overwritten - so this becomes a database of "what has been observed, for which SN,
# over time" that Life Forecast can use to bound its data range.
LOG_COVERAGE_HEADERS = [
    "Run Date", "Serial Number", "Hospital Name", "Country", "Region",
    "Source Folder", "Period Start", "Period End", "Rows Analyzed",
    "Observed Runtime Hours", "Clean Count", "Treat Circulate Hours",
    "Degas Circulate Hours", "Clean Circulate Hours", "Algorithm Version",
]

LF_USAGE_METRICS = {
    "Calendar Days": None,
    "Clean Count": "Clean Count",
    "Treatment Circulate Hours": "Treat Circulate Hours",
    "Degas Circulate Hours": "Degas Circulate Hours",
    "Cleaning Circulate Hours": "Clean Circulate Hours",
}


_LF_CACHE = {}


def lf_cached_master_rows(fname, headers):
    """Cache master-file reads for the duration of one Life Forecast operation (Calculate /
    Compare All Axes can otherwise re-read the same xlsx file via openpyxl a dozen+ times,
    which is the main cause of the dialog feeling slow). Cleared by lf_write_master_rows and
    lf_clear_cache whenever the underlying data actually changes."""
    if fname not in _LF_CACHE:
        _LF_CACHE[fname] = read_master_foundation_rows(fname, headers)
    return _LF_CACHE[fname]


def lf_write_master_rows(fname, headers, rows):
    write_master_foundation_rows(fname, headers, rows)
    _LF_CACHE[fname] = rows


def lf_clear_cache():
    _LF_CACHE.clear()


def lf_lookup_hospital(sn):
    for h in lf_cached_master_rows("Hospital_Master.xlsx", HP_MASTER_HEADERS):
        if normalize_text_value(h.get("Serial Number")) == normalize_text_value(sn):
            return h
    return None


def lf_register_hospital(sn, hospital_name, country, region, install_date=None, status="Active"):
    rows = lf_cached_master_rows("Hospital_Master.xlsx", HP_MASTER_HEADERS)
    for h in rows:
        if normalize_text_value(h.get("Serial Number")) == normalize_text_value(sn):
            h["Hospital Name"] = hospital_name or h.get("Hospital Name", "")
            h["Country"] = country or h.get("Country", "")
            h["Region"] = region or h.get("Region", "")
            if install_date:
                h["Installation Date"] = install_date
            h["Status"] = status or h.get("Status", "Active")
            lf_write_master_rows("Hospital_Master.xlsx", HP_MASTER_HEADERS, rows)
            return h
    new_row = {
        "Hospital Name": hospital_name, "Site": hospital_name, "Serial Number": sn,
        "Installation Date": install_date or "", "Coil Type": "", "Status": status,
        "Comment": "Registered from Life Forecast log linking", "Country": country, "Region": region,
    }
    rows.append(new_row)
    lf_write_master_rows("Hospital_Master.xlsx", HP_MASTER_HEADERS, rows)
    return new_row


def lf_append_log_coverage(sn, hospital_name, country, region, folder, summary_rows, raw_rows=None):
    dates = sorted({r.get("DateTime").date() for r in (summary_rows or [])
                    if isinstance(r.get("DateTime"), dt.datetime)})
    period_start = dates[0].isoformat() if dates else ""
    period_end = dates[-1].isoformat() if dates else ""
    observed_runtime = round(sum(float(r.get("Runtime", 0) or 0) for r in (summary_rows or [])), 2)

    clean_count = 0
    treat_hrs = degas_hrs = clean_hrs = 0.0
    for r in (raw_rows or []):
        try:
            clean_count += int(r.get("Clean Count") or 0)
        except Exception:
            pass
        treat_hrs += hms_to_seconds(r.get("TREAT_CIRCULATE (HH:MM:SS)")) / 3600.0
        degas_hrs += hms_to_seconds(r.get("DEGAS_CIRCULATE (HH:MM:SS)")) / 3600.0
        clean_hrs += (hms_to_seconds(r.get("CLEAN_TANK_CIRCULATE (HH:MM:SS)")) +
                      hms_to_seconds(r.get("CLEAN_XD_CIRCULATE (HH:MM:SS)"))) / 3600.0

    row = {
        "Run Date": dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S"),
        "Serial Number": sn, "Hospital Name": hospital_name, "Country": country, "Region": region,
        "Source Folder": folder or "", "Period Start": period_start, "Period End": period_end,
        "Rows Analyzed": len(summary_rows or []), "Observed Runtime Hours": observed_runtime,
        "Clean Count": clean_count, "Treat Circulate Hours": round(treat_hrs, 2),
        "Degas Circulate Hours": round(degas_hrs, 2), "Clean Circulate Hours": round(clean_hrs, 2),
        "Algorithm Version": ALGORITHM_VERSION,
    }
    rows = lf_cached_master_rows("Log_Coverage_History.xlsx", LOG_COVERAGE_HEADERS)
    rows = list(rows)
    rows.append(row)
    lf_write_master_rows("Log_Coverage_History.xlsx", LOG_COVERAGE_HEADERS, rows)
    return row


def lf_usage_rates(sn=None):
    """Average per-day rate for each usage metric, from the accumulated Log_Coverage_History.
    Used only as a secondary 'estimated day equivalent' indicator - the primary Weibull/KM
    fit on a usage axis uses lf_build_usage_dataset's real, log-derived interval totals below."""
    cov = lf_load_log_coverage(sn)
    span_days = 0
    sums = {"Clean Count": 0.0, "Treat Circulate Hours": 0.0,
            "Degas Circulate Hours": 0.0, "Clean Circulate Hours": 0.0}
    for r in cov["rows"]:
        ps, pe = parse_date_value(r.get("Period Start")), parse_date_value(r.get("Period End"))
        d = max((pe - ps).days + 1, 1) if (ps and pe) else 1
        span_days += d
        for k in sums:
            sums[k] += float(r.get(k, 0) or 0)
    rates = {}
    for k, total in sums.items():
        rates[k] = round(total / span_days, 4) if span_days > 0 else None
    rates["_span_days"] = span_days
    rates["_n_sessions"] = cov["n_sessions"]
    return rates


LOG_GAP_HEADERS = ["Serial Number", "Gap Start", "Gap End", "Classification", "Comment", "Marked Date"]
LF_GAP_IDLE = "Idle (Not Used)"
LF_GAP_UNKNOWN = "Unknown (Data Gap)"

LF_COVERAGE_MODES = [
    "Strict (only intervals fully explained by logs + marked idle periods)",
    "Assume unmarked gaps are idle (matches log design: logs only exist while running)",
    "Extrapolate partial coverage (scale up to the full interval - estimate)",
]


def lf_load_gap_classifications(sn=None):
    rows = lf_cached_master_rows("Log_Gap_Classification.xlsx", LOG_GAP_HEADERS)
    if sn:
        rows = [r for r in rows if normalize_text_value(r.get("Serial Number")) == normalize_text_value(sn)]
    return rows


def lf_detect_gaps(sn):
    """Gaps between consecutive linked Log_Coverage_History sessions for this SN (does not
    include the open-ended periods before the first / after the last session)."""
    cov = lf_load_log_coverage(sn)
    sessions = []
    for r in cov["rows"]:
        ps, pe = parse_date_value(r.get("Period Start")), parse_date_value(r.get("Period End"))
        if ps and pe:
            sessions.append((ps, pe))
    sessions.sort(key=lambda s: s[0])
    merged = []
    for ps, pe in sessions:
        if merged and ps <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], pe))
        else:
            merged.append((ps, pe))
    gaps = []
    for a, b in zip(merged, merged[1:]):
        gap_start, gap_end = a[1], b[0]
        if gap_end > gap_start:
            gaps.append({"start": gap_start, "end": gap_end, "days": (gap_end - gap_start).days})
    return gaps


def lf_classify_gap(sn, gap_start, gap_end, classification, comment=""):
    rows = list(lf_cached_master_rows("Log_Gap_Classification.xlsx", LOG_GAP_HEADERS))
    key = (normalize_text_value(sn), gap_start.strftime("%Y-%m-%d"), gap_end.strftime("%Y-%m-%d"))
    for r in rows:
        rkey = (normalize_text_value(r.get("Serial Number")), str(r.get("Gap Start"))[:10], str(r.get("Gap End"))[:10])
        if rkey == key:
            r["Classification"] = classification
            r["Comment"] = comment
            r["Marked Date"] = dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
            lf_write_master_rows("Log_Gap_Classification.xlsx", LOG_GAP_HEADERS, rows)
            return
    rows.append({
        "Serial Number": sn, "Gap Start": gap_start.strftime("%Y-%m-%d"), "Gap End": gap_end.strftime("%Y-%m-%d"),
        "Classification": classification, "Comment": comment,
        "Marked Date": dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S"),
    })
    lf_write_master_rows("Log_Gap_Classification.xlsx", LOG_GAP_HEADERS, rows)


def lf_interval_gap_breakdown(interval, gap_rows):
    """How much of this interval's span overlaps gaps marked Idle vs Unknown."""
    i_start, i_end = interval["start"], interval["end"]
    idle_days = unknown_days = 0
    for r in gap_rows:
        if normalize_text_value(r.get("Serial Number")) != normalize_text_value(interval["sn"]):
            continue
        gs, ge = parse_date_value(r.get("Gap Start")), parse_date_value(r.get("Gap End"))
        if not gs or not ge:
            continue
        overlap = (min(i_end, ge) - max(i_start, gs)).days
        if overlap <= 0:
            continue
        if r.get("Classification") == LF_GAP_IDLE:
            idle_days += overlap
        elif r.get("Classification") == LF_GAP_UNKNOWN:
            unknown_days += overlap
    return idle_days, unknown_days


def lf_interval_usage_from_coverage(interval, cov_rows, metric_key):
    """Sum the ACTUAL recorded usage (metric_key) from Log_Coverage_History sessions that
    overlap this replacement interval, apportioned to the overlapping days when a session only
    partially overlaps. Returns (usage_sum, covered_days)."""
    i_start, i_end = interval["start"], interval["end"]
    usage_sum = 0.0
    covered_days = 0
    for r in cov_rows:
        ps, pe = parse_date_value(r.get("Period Start")), parse_date_value(r.get("Period End"))
        if not ps or not pe:
            continue
        overlap_start = max(i_start, ps)
        overlap_end = min(i_end, pe)
        overlap_len = (overlap_end - overlap_start).days
        if overlap_len <= 0:
            continue
        session_len = max((pe - ps).days, 1)
        metric_total = float(r.get(metric_key, 0) or 0)
        usage_sum += metric_total * (overlap_len / session_len)
        covered_days += overlap_len
    return usage_sum, covered_days


def lf_build_usage_dataset(intervals, metric_key, mode=None):
    """Rebuild the interval list with 'days' replaced by REAL usage totals (Clean Count /
    Treat/Degas/Clean Circulate Hours) taken from Log_Coverage_History.

    Because WaterSystem logs are only produced while the system is running, gaps between
    linked log sessions are expected by design - they are NOT automatically treated as a data
    problem. Whether an unlogged gap means "genuinely idle" (safe to count as zero usage) or
    "unknown / possibly missed usage" is a manual classification (Log_Gap_Classification.xlsx,
    see lf_classify_gap), since only a person can know which is true.

    mode selects how gaps are handled (see LF_COVERAGE_MODES):
      - Strict: interval included only if logged sessions + idle-marked gaps fully explain its
        whole span (any Unknown-marked or unclassified remainder excludes it).
      - Assume idle (default / recommended, matches the log design): unclassified gaps are
        treated as idle (zero usage) automatically; only explicitly Unknown-marked gaps
        exclude the interval. Always includes intervals with zero unknown remainder.
      - Extrapolate: uses whatever logged coverage exists and scales it up to the full
        interval length, assuming the covered portion's rate applies throughout - always
        included if there is at least some logged coverage, but is an estimate.
    """
    mode = mode or LF_COVERAGE_MODES[1]
    all_cov = lf_cached_master_rows("Log_Coverage_History.xlsx", LOG_COVERAGE_HEADERS)
    cov_by_sn = {}
    for r in all_cov:
        cov_by_sn.setdefault(normalize_text_value(r.get("Serial Number")), []).append(r)
    gap_rows = lf_cached_master_rows("Log_Gap_Classification.xlsx", LOG_GAP_HEADERS)

    usage_intervals = []
    excluded = 0
    rate_samples = []
    for i in intervals:
        cov_rows = cov_by_sn.get(normalize_text_value(i["sn"]), [])
        usage_sum, covered_days = lf_interval_usage_from_coverage(i, cov_rows, metric_key)
        idle_days, unknown_days = lf_interval_gap_breakdown(i, gap_rows)
        unclassified_days = max(i["days"] - covered_days - idle_days - unknown_days, 0)

        if mode == LF_COVERAGE_MODES[0]:  # Strict
            if unknown_days > 0 or unclassified_days > 0 or usage_sum <= 0:
                excluded += 1
                continue
            final_usage = usage_sum
        elif mode == LF_COVERAGE_MODES[2]:  # Extrapolate
            if covered_days <= 0 or usage_sum <= 0:
                excluded += 1
                continue
            final_usage = usage_sum * (i["days"] / covered_days)
        else:  # Assume idle (default)
            if unknown_days > 0 or usage_sum <= 0:
                excluded += 1
                continue
            final_usage = usage_sum

        usage_intervals.append(dict(i, days=final_usage, calendar_days=i["days"]))
        if i["days"] > 0:
            rate_samples.append(final_usage / i["days"])

    day_rate = round(sum(rate_samples) / len(rate_samples), 4) if rate_samples else None
    return usage_intervals, excluded, day_rate


def lf_load_log_coverage(sn=None):
    rows = lf_cached_master_rows("Log_Coverage_History.xlsx", LOG_COVERAGE_HEADERS)
    if sn:
        rows = [r for r in rows if normalize_text_value(r.get("Serial Number")) == normalize_text_value(sn)]
    total_hours = sum(float(r.get("Observed Runtime Hours", 0) or 0) for r in rows)
    starts = [parse_date_value(r.get("Period Start")) for r in rows if r.get("Period Start")]
    ends = [parse_date_value(r.get("Period End")) for r in rows if r.get("Period End")]
    return {
        "rows": rows, "n_sessions": len(rows), "total_runtime_hours": round(total_hours, 2),
        "earliest": min(starts) if starts else None, "latest": max(ends) if ends else None,
    }



def lf_import_asm_replacement_file(path):
    """Import an 'ASM<part>_Replacement History' export (Part Number, Region, Country, Site,
    System Serial, Installation Date, Part Serial Number, Action Date, Status, Case Number,
    Reason, Case Status, Case Solution Summary, Replacement Confirmation columns - see the
    'Replacement History' sheet).

    Upserts (never duplicates, safe to re-run whenever an updated file arrives):
      - Hospital_Master.xlsx by Serial Number (Hospital Name/Site, Country, Region,
        Installation Date - existing Status is preserved, new entries default to Active).
      - Replacement_History.xlsx by (Component Type, Component ID, Case Number) - matching
        rows are updated in place instead of re-added, so importing the same file (or a
        refreshed version of it) again just updates dates/status rather than creating
        duplicates.

    Rows whose case is still open / not yet actually replaced (Case Status containing
    'Pending' or Replacement Confirmation starting with 'Case Open') are skipped - they are
    not a completed replacement event yet.
    """
    wb = load_workbook(path, data_only=True)
    if "Replacement History" not in wb.sheetnames:
        raise ValueError("Expected a 'Replacement History' sheet in %s" % os.path.basename(path))
    ws = wb["Replacement History"]
    headers = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
    src_rows = [dict(zip(headers, r)) for r in ws.iter_rows(min_row=2, values_only=True) if any(r)]

    # --- Hospital_Master upsert ---
    hosp_rows = list(lf_cached_master_rows("Hospital_Master.xlsx", HP_MASTER_HEADERS))
    hosp_by_sn = {normalize_text_value(h.get("Serial Number")): h for h in hosp_rows if h.get("Serial Number")}
    hosp_added = hosp_updated = 0
    for r in src_rows:
        sn = normalize_text_value(r.get("System Serial"))
        if not sn:
            continue
        existing = hosp_by_sn.get(sn)
        if existing:
            existing["Hospital Name"] = r.get("Site") or existing.get("Hospital Name", "")
            existing["Site"] = r.get("Site") or existing.get("Site", "")
            existing["Country"] = r.get("Country") or existing.get("Country", "")
            existing["Region"] = r.get("Region") or existing.get("Region", "")
            if r.get("Installation Date") and not existing.get("Installation Date"):
                existing["Installation Date"] = r.get("Installation Date")
            hosp_updated += 1
        else:
            new_row = {
                "Hospital Name": r.get("Site") or "", "Site": r.get("Site") or "", "Serial Number": sn,
                "Installation Date": r.get("Installation Date") or "", "Coil Type": "", "Status": "Active",
                "Comment": "Imported from ASM replacement file", "Country": r.get("Country") or "",
                "Region": r.get("Region") or "",
            }
            hosp_rows.append(new_row)
            hosp_by_sn[sn] = new_row
            hosp_added += 1
    lf_write_master_rows("Hospital_Master.xlsx", HP_MASTER_HEADERS, hosp_rows)

    # --- Replacement_History upsert ---
    hist_rows = list(lf_cached_master_rows("Replacement_History.xlsx", REPLACEMENT_HISTORY_HEADERS))
    key_index = {}
    for i, r in enumerate(hist_rows):
        key_index[(normalize_text_value(r.get("Component Type")), normalize_text_value(r.get("Component ID")),
                   normalize_text_value(r.get("Case Number")))] = i

    hist_added = hist_updated = hist_skipped = 0
    for r in src_rows:
        case_status = normalize_text_value(r.get("Case Status"))
        confirmation = normalize_text_value(r.get("Replacement Confirmation"))
        if "Pending" in case_status or confirmation.startswith("Case Open"):
            hist_skipped += 1
            continue
        action_date = r.get("Action Date")
        if not action_date:
            hist_skipped += 1
            continue
        sn = normalize_text_value(r.get("System Serial"))
        part = normalize_text_value(r.get("Part Number"))
        part_sn = normalize_text_value(r.get("Part Serial Number"))
        rtype = "Failure" if confirmation.startswith(("Confirmed", "Likely")) else "Unknown"
        comment_bits = [b for b in [r.get("Case Solution Summary"), ("Case %s" % r.get("Case Number") if r.get("Case Number") else "")] if b]
        row = {
            "Hospital Name": r.get("Site") or "", "Serial Number": sn, "Component Type": part,
            "Component ID": part_sn, "Coil ID": "",
            "Replacement Date": action_date.strftime("%Y/%m/%d") if hasattr(action_date, "strftime") else str(action_date),
            "Replacement Type": rtype, "Reason": r.get("Reason") or "",
            "Comment": " | ".join(comment_bits) or "Imported from ASM replacement file",
            "Case Number": normalize_text_value(r.get("Case Number")),
        }
        key = (part, part_sn, normalize_text_value(r.get("Case Number")))
        if key in key_index:
            hist_rows[key_index[key]] = row
            hist_updated += 1
        else:
            hist_rows.append(row)
            key_index[key] = len(hist_rows) - 1
            hist_added += 1
    lf_write_master_rows("Replacement_History.xlsx", REPLACEMENT_HISTORY_HEADERS, hist_rows)

    return {
        "hospitals_added": hosp_added, "hospitals_updated": hosp_updated,
        "history_added": hist_added, "history_updated": hist_updated, "history_skipped": hist_skipped,
        "source_rows": len(src_rows),
    }


def migrate_legacy_hp_master():
    """Version 7.0.1: migrate legacy HP_Master.xlsx to Hospital_Master.xlsx if needed."""
    try:
        root = ensure_data_folders()
        master = os.path.join(root, "Master")
        old_path = os.path.join(master, "HP_Master.xlsx")
        new_path = os.path.join(master, "Hospital_Master.xlsx")
        if os.path.exists(old_path) and not os.path.exists(new_path):
            shutil.copy2(old_path, new_path)
    except Exception:
        pass


def ensure_master_foundation_files():
    """Version 7.3 RC1-15: master data now lives in the SQLite database (see wsdb_*
    functions) rather than Master/*.xlsx. This only runs the one-time legacy filename
    migration (HP_Master.xlsx -> Hospital_Master.xlsx) so migrate_xlsx_masters_to_sqlite can
    find it; it no longer creates or rewrites any xlsx files."""
    migrate_legacy_hp_master()


def _xlsx_read_master_foundation_rows_legacy(filename, headers):
    """Legacy xlsx reader, kept only so existing Master/*.xlsx files can be migrated into
    the SQLite database once (see migrate_xlsx_masters_to_sqlite). Not used for normal
    reads/writes any more."""
    path = master_foundation_path(filename)
    rows = []
    try:
        wb = load_workbook(path, data_only=True, read_only=True)
        ws = wb.active
        sheet_headers = [ws.cell(1, c).value or "" for c in range(1, ws.max_column + 1)]
        for r in range(2, ws.max_row + 1):
            if not any(ws.cell(r, c).value not in ("", None) for c in range(1, ws.max_column + 1)):
                continue
            row = {}
            for c, h in enumerate(sheet_headers, 1):
                if h:
                    row[h] = ws.cell(r, c).value
            rows.append(row)
    except Exception:
        pass
    return rows


def wsdb_path():
    return os.path.join(ensure_data_folders(), "WaterSystemAnalyzer.db")


def wsdb_connect():
    conn = sqlite3.connect(wsdb_path())
    conn.row_factory = sqlite3.Row
    return conn


def _wsdb_table_name(filename):
    # Table names come only from our own fixed set of master filenames, never from user input.
    return os.path.splitext(filename)[0]


def _wsdb_serialize(v):
    if isinstance(v, (dt.datetime, dt.date)):
        return v.isoformat()
    return v


def _wsdb_ensure_table(conn, table, headers):
    cols = conn.execute("PRAGMA table_info(\"%s\")" % table).fetchall()
    if not cols:
        col_defs = ", ".join('"%s"' % h for h in headers)
        conn.execute('CREATE TABLE "%s" (%s)' % (table, col_defs))
        conn.commit()
        return
    existing = {c["name"] for c in cols}
    for h in headers:
        if h not in existing:
            conn.execute('ALTER TABLE "%s" ADD COLUMN "%s"' % (table, h))
    conn.commit()


_WSDB_MIGRATED_CHECKED = False


def migrate_xlsx_masters_to_sqlite():
    """One-time migration: if the SQLite database doesn't exist yet but legacy Master/*.xlsx
    files do (from before Version 7.3 RC1-15), copy their rows into the database so nothing
    already recorded (Hospital_Master, Replacement_History, Log_Coverage_History,
    Log_Gap_Classification, Component_Master) is lost when switching storage engines."""
    global _WSDB_MIGRATED_CHECKED
    if _WSDB_MIGRATED_CHECKED:
        return
    _WSDB_MIGRATED_CHECKED = True
    if os.path.exists(wsdb_path()):
        return
    legacy_specs = {
        "Hospital_Master.xlsx": HP_MASTER_HEADERS,
        "Component_Master.xlsx": COMPONENT_MASTER_HEADERS,
        "Replacement_History.xlsx": REPLACEMENT_HISTORY_HEADERS,
        "Log_Coverage_History.xlsx": LOG_COVERAGE_HEADERS,
        "Log_Gap_Classification.xlsx": LOG_GAP_HEADERS,
    }
    migrated_any = False
    for fname, headers in legacy_specs.items():
        path = master_foundation_path(fname)
        if not os.path.exists(path):
            continue
        rows = _xlsx_read_master_foundation_rows_legacy(fname, headers)
        if rows:
            wsdb_write_rows(fname, headers, rows)
            migrated_any = True
    if migrated_any:
        try:
            # NOTE: do not delete the original xlsx files here. A separate, older code path
            # (ensure_master_files, invoked from ensure_data_folders which almost everything
            # calls) recreates a blank Hospital_Master.xlsx/Replacement_History.xlsx with a
            # DIFFERENT legacy header schema the instant either file is missing. Deleting them
            # would just cause them to silently reappear empty. They are harmless, inert
            # leftovers once SQLite is the live store (nothing reads them any more), and are
            # also copied to PreSqliteMigration_Backup below as an extra safety net.
            backup_dir = os.path.join(ensure_data_folders(), "Master", "PreSqliteMigration_Backup")
            os.makedirs(backup_dir, exist_ok=True)
            for fname in legacy_specs:
                src = master_foundation_path(fname)
                if os.path.exists(src):
                    shutil.copy2(src, os.path.join(backup_dir, fname))
        except Exception:
            pass


def wsdb_read_rows(filename, headers):
    migrate_xlsx_masters_to_sqlite()
    table = _wsdb_table_name(filename)
    conn = wsdb_connect()
    try:
        _wsdb_ensure_table(conn, table, headers)
        cur = conn.execute('SELECT * FROM "%s"' % table)
        rows = []
        for r in cur.fetchall():
            row = {h: r[h] for h in headers if h in r.keys()}
            if any(v not in ("", None) for v in row.values()):
                rows.append(row)
        return rows
    finally:
        conn.close()


def wsdb_write_rows(filename, headers, rows):
    migrate_xlsx_masters_to_sqlite()
    table = _wsdb_table_name(filename)
    conn = wsdb_connect()
    try:
        _wsdb_ensure_table(conn, table, headers)
        conn.execute('DELETE FROM "%s"' % table)
        col_list = ", ".join('"%s"' % h for h in headers)
        placeholders = ", ".join(["?"] * len(headers))
        conn.executemany(
            'INSERT INTO "%s" (%s) VALUES (%s)' % (table, col_list, placeholders),
            [[_wsdb_serialize(row.get(h, "")) for h in headers] for row in rows],
        )
        conn.commit()
    finally:
        conn.close()
    return wsdb_path()


def read_master_foundation_rows(filename, headers):
    ensure_master_foundation_files()
    return wsdb_read_rows(filename, headers)


def write_master_foundation_rows(filename, headers, rows):
    ensure_master_foundation_files()
    return wsdb_write_rows(filename, headers, rows)


def excel_serial_to_datetime(value):
    """
    Convert Excel serial date or common date text to datetime.
    History.xlsx uses Excel date serial values in date columns.
    """
    if value in ("", None):
        return None
    if isinstance(value, dt.datetime):
        return value
    if isinstance(value, dt.date):
        return dt.datetime(value.year, value.month, value.day)
    try:
        # Excel serial date system. 25569 = 1970-01-01.
        if isinstance(value, (int, float)) and value > 20000:
            return dt.datetime(1899, 12, 30) + dt.timedelta(days=float(value))
    except Exception:
        pass

    s = str(value).strip()
    if not s:
        return None
    # Guard impossible typo-like strings such as 2025/07/61.
    for fmt in ("%Y/%m/%d", "%Y-%m-%d", "%m/%d/%Y", "%Y/%m/%d %H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return dt.datetime.strptime(s, fmt)
        except Exception:
            pass
    try:
        if re.fullmatch(r"\d+(\.\d+)?", s):
            num = float(s)
            if num > 20000:
                return dt.datetime(1899, 12, 30) + dt.timedelta(days=num)
    except Exception:
        pass
    return None


def normalize_history_key(value):
    if value in ("", None):
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()



def calculate_data_coverage_skeleton(summary_rows):
    dates = [r.get("DateTime") for r in (summary_rows or []) if isinstance(r.get("DateTime"), dt.datetime)]
    if not dates:
        return {"First Log Date": "", "Last Log Date": "", "Coverage Days": 0, "Estimated Usage Candidate": "No log dates"}
    first = min(dates)
    last = max(dates)
    return {"First Log Date": first.strftime("%Y/%m/%d"), "Last Log Date": last.strftime("%Y/%m/%d"), "Coverage Days": (last-first).days + 1, "Estimated Usage Candidate": "Prepared for Step7"}




def normalize_text_value(v):
    if v is None:
        return ""
    try:
        if isinstance(v, float) and v.is_integer():
            return str(int(v))
    except Exception:
        pass
    return str(v).strip()


def parse_date_value(v):
    if isinstance(v, dt.datetime):
        return v
    if isinstance(v, dt.date):
        return dt.datetime(v.year, v.month, v.day)
    if v in ("", None):
        return None
    s = str(v).strip()
    for fmt in ("%Y/%m/%d", "%Y-%m-%d", "%Y/%m/%d %H:%M:%S", "%Y-%m-%d %H:%M:%S", "%m/%d/%Y", "%d/%m/%Y"):
        try:
            return dt.datetime.strptime(s, fmt)
        except Exception:
            pass
    try:
        return coerce_datetime(s)
    except Exception:
        return None


# ==============================
# Version 7.1 Reliability Engine
# ==============================

REPLACEMENT_VALIDATION_HEADERS = [
    "Run Date", "Hospital Name", "Serial Number", "Component Type",
    "Replacement Date", "Replacement Type", "Status",
    "Duplicate Check", "Date Check", "Mapping Check", "Warning", "Source"
]

GAP_ANALYSIS_HEADERS = [
    "Run Date", "Hospital Name", "Serial Number", "Component Type",
    "Gap Start", "Gap End", "Gap Days", "Handling",
    "Estimated Runtime Hours", "Basis", "Confidence Impact", "Warning"
]

RELIABILITY_HISTORY_HEADERS = [
    "Run Date", "Hospital Name", "Serial Number", "Component Type",
    "Coverage %", "Gap Score", "Replacement Score", "Runtime Continuity Score",
    "Log Quality Score", "Confidence Score", "Confidence Stars",
    "Data Quality", "Estimated Runtime Hours", "Warning", "Algorithm Version"
]

FORECAST_SNAPSHOT_HEADERS = [
    "Run Date", "Hospital Name", "Serial Number", "Component Type",
    "Observed Runtime Hours", "Estimated Runtime Hours", "Total Runtime Basis Hours",
    "Coverage %", "Confidence Score", "Confidence Stars",
    "Forecast Basis", "Explanation", "Algorithm Version"
]


def ensure_reliability_files():
    specs = {
        "Replacement_Validation.xlsx": REPLACEMENT_VALIDATION_HEADERS,
        "Gap_Analysis.xlsx": GAP_ANALYSIS_HEADERS,
        "Reliability_History.xlsx": RELIABILITY_HISTORY_HEADERS,
        "Forecast_Snapshot.xlsx": FORECAST_SNAPSHOT_HEADERS,
    }
    for fname, headers in specs.items():
        path = master_path(fname)
        if not os.path.exists(path):
            wb = Workbook()
            ws = wb.active
            ws.title = os.path.splitext(fname)[0]
            for c, h in enumerate(headers, 1):
                cell = ws.cell(1, c, h)
                cell.font = Font(bold=True)
                ws.column_dimensions[get_column_letter(c)].width = max(14, len(h) + 3)
            ws.freeze_panes = "A2"
            wb.save(path)


def append_reliability_rows(fname, headers, rows):
    ensure_reliability_files()
    path = master_path(fname)
    wb = load_workbook(path)
    ws = wb.active
    for row in rows:
        r = ws.max_row + 1
        for c, h in enumerate(headers, 1):
            ws.cell(r, c, row.get(h, ""))
    wb.save(path)
    return path


def confidence_stars(score):
    try:
        score = float(score)
    except Exception:
        score = 0
    if score >= 95:
        return "★★★★★"
    if score >= 85:
        return "★★★★☆"
    if score >= 70:
        return "★★★☆☆"
    if score >= 50:
        return "★★☆☆☆"
    return "★☆☆☆☆"


def read_replacement_history_rows():
    # Primary V7 file name; read via current header layout.
    try:
        return read_master_foundation_rows("Replacement_History.xlsx", REPLACEMENT_HISTORY_HEADERS)
    except Exception:
        return []


def validate_replacement_history():
    run_date = dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
    rows = read_replacement_history_rows()
    seen = set()
    out = []
    for r in rows:
        hospital = normalize_text_value(r.get("Hospital Name") or r.get("Hospital") or r.get("Site"))
        sn = normalize_text_value(r.get("Serial Number") or r.get("SN"))
        ctype = normalize_text_value(r.get("Component Type") or r.get("Part")) or "Degas Module"
        rdate = parse_date_value(r.get("Replacement Date"))
        rtype = normalize_text_value(r.get("Replacement Type")) or "Unknown"

        key = (hospital, sn, ctype, rdate.strftime("%Y/%m/%d") if rdate else "")
        duplicate = "Duplicate" if key in seen and key[-1] else "OK"
        if key[-1]:
            seen.add(key)

        warnings = []
        date_check = "OK" if rdate else "Missing/Invalid"
        mapping_check = "OK" if (hospital and sn and ctype) else "Missing mapping"
        if date_check != "OK":
            warnings.append("Replacement date is missing or invalid.")
        if mapping_check != "OK":
            warnings.append("Hospital Name / Serial Number / Component Type is incomplete.")
        if duplicate != "OK":
            warnings.append("Possible duplicate replacement record.")

        status = "OK" if not warnings else "Warning"
        out.append({
            "Run Date": run_date,
            "Hospital Name": hospital,
            "Serial Number": sn,
            "Component Type": ctype,
            "Replacement Date": rdate.strftime("%Y/%m/%d") if rdate else "",
            "Replacement Type": rtype,
            "Status": status,
            "Duplicate Check": duplicate,
            "Date Check": date_check,
            "Mapping Check": mapping_check,
            "Warning": " ".join(warnings),
            "Source": "Replacement_History.xlsx",
        })
    return out


def detect_log_gaps(summary_rows, gap_threshold_days=3, missing_handling="Unknown"):
    run_date = dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
    dates = sorted({r.get("DateTime").date() for r in (summary_rows or []) if isinstance(r.get("DateTime"), dt.datetime)})
    if len(dates) < 2:
        return []
    gaps = []
    for a, b in zip(dates, dates[1:]):
        missing_days = (b - a).days - 1
        if missing_days >= gap_threshold_days:
            gap_start = a + dt.timedelta(days=1)
            gap_end = b - dt.timedelta(days=1)
            if missing_handling == "Estimated Usage":
                # Conservative initial estimate: use average Runtime daily value when available.
                runtime_vals = [float(r.get("Runtime", 0) or 0) for r in (summary_rows or []) if isinstance(r.get("DateTime"), dt.datetime)]
                avg_runtime = sum(runtime_vals) / len(runtime_vals) if runtime_vals else 0.0
                est_hours = round(avg_runtime * missing_days, 2)
                basis = "Average observed daily Runtime x missing days"
                impact = "Medium"
            elif missing_handling == "Conservative":
                runtime_vals = [float(r.get("Runtime", 0) or 0) for r in (summary_rows or []) if isinstance(r.get("DateTime"), dt.datetime)]
                avg_runtime = sum(runtime_vals) / len(runtime_vals) if runtime_vals else 0.0
                est_hours = round(avg_runtime * missing_days * 0.5, 2)
                basis = "50% of average observed daily Runtime x missing days"
                impact = "Medium"
            else:
                est_hours = 0.0
                basis = "Unknown gap / no usage estimate"
                impact = "High"

            gaps.append({
                "Run Date": run_date,
                "Hospital Name": "",
                "Serial Number": "",
                "Component Type": "Degas Module",
                "Gap Start": gap_start.strftime("%Y/%m/%d"),
                "Gap End": gap_end.strftime("%Y/%m/%d"),
                "Gap Days": missing_days,
                "Handling": missing_handling,
                "Estimated Runtime Hours": est_hours,
                "Basis": basis,
                "Confidence Impact": impact,
                "Warning": "Log gap detected.",
            })
    return gaps


def build_reliability_dashboard(summary_rows, missing_handling="Unknown"):
    ensure_reliability_files()
    run_date = dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S")

    dates = sorted({r.get("DateTime").date() for r in (summary_rows or []) if isinstance(r.get("DateTime"), dt.datetime)})
    if dates:
        first = dates[0]
        last = dates[-1]
        total_days = (last - first).days + 1
        observed_days = len(dates)
        coverage = round((observed_days / max(1, total_days)) * 100.0, 1)
    else:
        first = last = None
        total_days = observed_days = 0
        coverage = 0.0

    validation_rows = validate_replacement_history()
    warning_count = sum(1 for r in validation_rows if r.get("Status") != "OK")
    replacement_score = max(0, 100 - warning_count * 15)
    gaps = detect_log_gaps(summary_rows, 3, missing_handling)
    gap_days = sum(int(g.get("Gap Days", 0) or 0) for g in gaps)
    estimated_hours = round(sum(float(g.get("Estimated Runtime Hours", 0) or 0) for g in gaps), 2)

    coverage_score = min(100, coverage)
    gap_score = max(0, 100 - gap_days * 2)
    runtime_score = 100 if observed_days >= 30 else (70 if observed_days >= 7 else 40)
    log_quality_score = 100 if coverage >= 85 else (75 if coverage >= 60 else 45)

    confidence_score = round(
        coverage_score * 0.25 +
        gap_score * 0.25 +
        replacement_score * 0.20 +
        runtime_score * 0.15 +
        log_quality_score * 0.15,
        1
    )

    stars = confidence_stars(confidence_score)
    data_quality = "Excellent" if confidence_score >= 90 else ("Good" if confidence_score >= 75 else ("Fair" if confidence_score >= 55 else "Poor"))
    warnings = []
    if warning_count:
        warnings.append("%d replacement warning(s)" % warning_count)
    if gap_days:
        warnings.append("%d missing log day(s)" % gap_days)
    if not dates:
        warnings.append("No log data loaded")

    reliability_row = {
        "Run Date": run_date,
        "Hospital Name": "",
        "Serial Number": "",
        "Component Type": "Degas Module",
        "Coverage %": coverage,
        "Gap Score": gap_score,
        "Replacement Score": replacement_score,
        "Runtime Continuity Score": runtime_score,
        "Log Quality Score": log_quality_score,
        "Confidence Score": confidence_score,
        "Confidence Stars": stars,
        "Data Quality": data_quality,
        "Estimated Runtime Hours": estimated_hours,
        "Warning": " / ".join(warnings),
        "Algorithm Version": ALGORITHM_VERSION,
    }

    observed_runtime = round(sum(float(r.get("Runtime", 0) or 0) for r in (summary_rows or [])), 2)
    snapshot_row = {
        "Run Date": run_date,
        "Hospital Name": "",
        "Serial Number": "",
        "Component Type": "Degas Module",
        "Observed Runtime Hours": observed_runtime,
        "Estimated Runtime Hours": estimated_hours,
        "Total Runtime Basis Hours": round(observed_runtime + estimated_hours, 2),
        "Coverage %": coverage,
        "Confidence Score": confidence_score,
        "Confidence Stars": stars,
        "Forecast Basis": "Measured + Estimated" if estimated_hours else "Measured only",
        "Explanation": "Observed runtime %.2f h + estimated gap %.2f h. Coverage %.1f%%. Confidence %s." % (observed_runtime, estimated_hours, coverage, stars),
        "Algorithm Version": ALGORITHM_VERSION,
    }

    return validation_rows, gaps, [reliability_row], [snapshot_row]


def save_reliability_dashboard(summary_rows, missing_handling="Unknown"):
    validation_rows, gap_rows, reliability_rows, snapshot_rows = build_reliability_dashboard(summary_rows, missing_handling)
    p1 = append_reliability_rows("Replacement_Validation.xlsx", REPLACEMENT_VALIDATION_HEADERS, validation_rows)
    p2 = append_reliability_rows("Gap_Analysis.xlsx", GAP_ANALYSIS_HEADERS, gap_rows)
    p3 = append_reliability_rows("Reliability_History.xlsx", RELIABILITY_HISTORY_HEADERS, reliability_rows)
    p4 = append_reliability_rows("Forecast_Snapshot.xlsx", FORECAST_SNAPSHOT_HEADERS, snapshot_rows)
    return (p1, p2, p3, p4), validation_rows, gap_rows, reliability_rows, snapshot_rows



RUNTIME_RECONSTRUCTION_HEADERS = [
    "Run Date", "Hospital Name", "Serial Number", "Component Type",
    "Period Start", "Period End", "Runtime Type",
    "Measured Runtime Hours", "Estimated Runtime Hours", "Confirmed Stop Hours",
    "Unknown Days", "Total Runtime Basis Hours",
    "Handling", "Basis", "Confidence Impact", "Warning", "Algorithm Version"
]
GAP_HISTORY_HEADERS = [
    "Run Date", "Hospital Name", "Serial Number", "Component Type",
    "Gap Start", "Gap End", "Gap Days", "Handling",
    "Estimated Runtime Hours", "Basis", "Resolved By", "Algorithm Version"
]

REFERENCE_INTERVAL_HEADERS = [
    "Run Date", "Hospital Name", "Serial Number", "Component Type",
    "Interval Start", "Interval End", "Interval Days",
    "Reference Median Days", "Potential Gap Threshold Days",
    "Classification", "Basis", "Algorithm Version"
]

PREDICTION_HISTORY_HEADERS = [
    "Run Date", "Hospital Name", "Serial Number", "Component Type",
    "Observed Runtime Hours", "Estimated Runtime Hours", "Total Runtime Basis Hours",
    "Forecast Method", "Prediction Status", "Prediction Note", "Algorithm Version"
]
CONFIDENCE_HISTORY_HEADERS = [
    "Run Date", "Hospital Name", "Serial Number", "Component Type",
    "Coverage Score", "Gap Quality Score", "Replacement History Score",
    "Runtime Quality Score", "Prediction Stability Score",
    "Overall Confidence Score", "Overall Confidence Stars",
    "Explanation", "Algorithm Version"
]

def ensure_runtime_reconstruction_files():
    specs = {
        "Runtime_Reconstruction.xlsx": RUNTIME_RECONSTRUCTION_HEADERS,
        "Gap_History.xlsx": GAP_HISTORY_HEADERS,
        "Reference_Intervals.xlsx": REFERENCE_INTERVAL_HEADERS,
        "Prediction_History.xlsx": PREDICTION_HISTORY_HEADERS,
        "Confidence_History.xlsx": CONFIDENCE_HISTORY_HEADERS,
    }
    for fname, headers in specs.items():
        path = master_path(fname)
        if not os.path.exists(path):
            wb = Workbook()
            ws = wb.active
            ws.title = os.path.splitext(fname)[0]
            for c, h in enumerate(headers, 1):
                cell = ws.cell(1, c, h)
                cell.font = Font(bold=True)
                ws.column_dimensions[get_column_letter(c)].width = max(14, len(h) + 3)
            ws.freeze_panes = "A2"
            wb.save(path)

def append_runtime_rows(fname, headers, rows):
    ensure_runtime_reconstruction_files()
    path = master_path(fname)
    wb = load_workbook(path)
    ws = wb.active
    for row in rows:
        r = ws.max_row + 1
        for c, h in enumerate(headers, 1):
            ws.cell(r, c, row.get(h, ""))
    wb.save(path)
    return path

def runtime_daily_map(summary_rows):
    daily = {}
    for r in summary_rows or []:
        d = r.get("DateTime")
        if not isinstance(d, dt.datetime):
            continue
        day = d.date()
        try:
            val = float(r.get("Runtime", 0) or 0)
        except Exception:
            val = 0.0
        if val == 0:
            for key in ["Treat", "Degas", "Clean"]:
                try:
                    val += float(r.get(key, 0) or 0)
                except Exception:
                    pass
        daily[day] = daily.get(day, 0.0) + val
    return daily

def build_runtime_reconstruction(summary_rows, missing_handling="Unknown"):
    """
    Runtime reconstruction using site-operation-aware intervals.

    All observed intervals are retained as Reference Interval rows.
    Only intervals that are extremely longer than the site's normal
    cleaning frequency are classified as Potential GAP.
    """
    ensure_runtime_reconstruction_files()
    run_date = dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
    daily = runtime_daily_map(summary_rows)
    days = sorted(daily.keys())
    runtime_rows = []
    gap_rows = []
    reference_rows = []

    if not days:
        runtime_rows.append({
            "Run Date": run_date, "Hospital Name": "", "Serial Number": "",
            "Component Type": "Degas Module", "Period Start": "", "Period End": "",
            "Runtime Type": "Unknown Runtime", "Measured Runtime Hours": 0,
            "Estimated Runtime Hours": 0, "Confirmed Stop Hours": 0,
            "Unknown Days": 0, "Total Runtime Basis Hours": 0,
            "Handling": missing_handling, "Basis": "No log data",
            "Confidence Impact": "High", "Warning": "No runtime data available.",
            "Algorithm Version": ALGORITHM_VERSION,
        })
        return runtime_rows, gap_rows, reference_rows

    measured_total = round(sum(daily.values()), 2)
    runtime_rows.append({
        "Run Date": run_date, "Hospital Name": "", "Serial Number": "",
        "Component Type": "Degas Module", "Period Start": days[0].strftime("%Y/%m/%d"),
        "Period End": days[-1].strftime("%Y/%m/%d"), "Runtime Type": "Measured Runtime",
        "Measured Runtime Hours": measured_total, "Estimated Runtime Hours": 0,
        "Confirmed Stop Hours": 0, "Unknown Days": 0,
        "Total Runtime Basis Hours": measured_total, "Handling": "Measured",
        "Basis": "Runtime from ResultSummary/log data", "Confidence Impact": "Low",
        "Warning": "", "Algorithm Version": ALGORITHM_VERSION,
    })

    # Cleaning frequency is the best available proxy for normal WaterSystem use.
    clean_days = []
    for row in summary_rows or []:
        d = row.get("DateTime")
        if not isinstance(d, dt.datetime):
            continue
        try:
            clean_value = float(row.get("Clean", 0) or 0)
        except Exception:
            clean_value = 0.0
        if clean_value > 0 and d.date() not in clean_days:
            clean_days.append(d.date())
    clean_days = sorted(clean_days)

    clean_intervals = [(b - a).days for a, b in zip(clean_days, clean_days[1:]) if (b - a).days > 0]
    all_observed_intervals = [(b - a).days for a, b in zip(days, days[1:]) if (b - a).days > 0]

    basis_intervals = clean_intervals if clean_intervals else all_observed_intervals
    if basis_intervals:
        median_interval = float(statistics.median(basis_intervals))
        if len(basis_intervals) >= 4:
            sorted_i = sorted(basis_intervals)
            q1 = statistics.median(sorted_i[:len(sorted_i)//2])
            q3 = statistics.median(sorted_i[(len(sorted_i)+1)//2:])
            iqr_threshold = float(q3 + 1.5 * (q3 - q1))
        else:
            iqr_threshold = median_interval * 3.0
        # Do not classify ordinary weekly/biweekly use as a GAP.
        gap_threshold = max(14.0, median_interval * 3.0, iqr_threshold)
    else:
        median_interval = 0.0
        gap_threshold = 30.0

    avg_runtime = measured_total / max(1, len(days))
    for a, b in zip(days, days[1:]):
        interval_days = (b - a).days
        if interval_days <= 0:
            continue

        is_potential_gap = interval_days > gap_threshold
        reference_rows.append({
            "Run Date": run_date, "Hospital Name": "", "Serial Number": "",
            "Component Type": "Degas Module",
            "Interval Start": a.strftime("%Y/%m/%d"),
            "Interval End": b.strftime("%Y/%m/%d"),
            "Interval Days": interval_days,
            "Reference Median Days": round(median_interval, 1),
            "Potential Gap Threshold Days": round(gap_threshold, 1),
            "Classification": "Potential GAP" if is_potential_gap else "Reference",
            "Basis": "Cleaning frequency" if clean_intervals else "Observed WaterSystem frequency",
            "Algorithm Version": ALGORITHM_VERSION,
        })

        if not is_potential_gap:
            continue

        missing_days = max(0, interval_days - 1)
        gap_start = a + dt.timedelta(days=1)
        gap_end = b - dt.timedelta(days=1)

        if missing_handling == "Estimated Usage":
            est = round(avg_runtime * missing_days, 2)
            rt_type = "Estimated Runtime"
            basis = "Potential GAP: average measured runtime x gap days"
            impact = "Medium"
            unknown_days = 0
        elif missing_handling == "Conservative":
            est = round(avg_runtime * missing_days * 0.5, 2)
            rt_type = "Estimated Runtime"
            basis = "Potential GAP: 50% average runtime x gap days"
            impact = "Medium"
            unknown_days = 0
        else:
            est = 0.0
            rt_type = "Unknown Runtime"
            basis = "Potential GAP is treated as unknown; no runtime estimate"
            impact = "High"
            unknown_days = missing_days

        runtime_rows.append({
            "Run Date": run_date, "Hospital Name": "", "Serial Number": "",
            "Component Type": "Degas Module",
            "Period Start": gap_start.strftime("%Y/%m/%d"),
            "Period End": gap_end.strftime("%Y/%m/%d"),
            "Runtime Type": rt_type,
            "Measured Runtime Hours": 0, "Estimated Runtime Hours": est,
            "Confirmed Stop Hours": 0, "Unknown Days": unknown_days,
            "Total Runtime Basis Hours": est, "Handling": missing_handling,
            "Basis": basis, "Confidence Impact": impact,
            "Warning": "Potential GAP: interval %.0f d exceeds threshold %.1f d." %
                       (interval_days, gap_threshold),
            "Algorithm Version": ALGORITHM_VERSION,
        })
        gap_rows.append({
            "Run Date": run_date, "Hospital Name": "", "Serial Number": "",
            "Component Type": "Degas Module",
            "Gap Start": gap_start.strftime("%Y/%m/%d"),
            "Gap End": gap_end.strftime("%Y/%m/%d"),
            "Gap Days": missing_days,
            "Handling": missing_handling, "Estimated Runtime Hours": est,
            "Basis": basis,
            "Resolved By": "Cleaning-frequency GAP classifier",
            "Algorithm Version": ALGORITHM_VERSION,
        })

    return runtime_rows, gap_rows, reference_rows


# =====================================
# Version 7.2c Explainable Reliability Engine
# =====================================

EXPLAINABLE_RELIABILITY_HEADERS = [
    "Run Date", "Hospital Name", "Serial Number", "Component Type",
    "Forecast Readiness", "Forecast Readiness Score",
    "Overall Confidence Score", "Overall Confidence Stars",
    "Coverage Score", "Coverage Reason",
    "Data Continuity Score", "Data Continuity Reason",
    "Gap Quality Score", "Gap Quality Reason",
    "Runtime Confidence Score", "Runtime Confidence Reason",
    "Replacement Quality Score", "Replacement Quality Reason",
    "Prediction Stability Score", "Prediction Stability Reason",
    "Data Quality Score", "Data Quality Reason",
    "Overall Explanation", "Algorithm Version"
]

RELIABILITY_TREND_HEADERS = [
    "Run Date", "Hospital Name", "Serial Number", "Component Type",
    "Forecast Readiness", "Overall Confidence Score", "Overall Confidence Stars",
    "Coverage Score", "Data Continuity Score", "Gap Quality Score",
    "Runtime Confidence Score", "Replacement Quality Score",
    "Prediction Stability Score", "Data Quality Score",
    "Measured Runtime Hours", "Estimated Runtime Hours", "Unknown Days",
    "Algorithm Version"
]


def ensure_explainable_reliability_files():
    specs = {
        "Explainable_Reliability.xlsx": EXPLAINABLE_RELIABILITY_HEADERS,
        "Reliability_Trend.xlsx": RELIABILITY_TREND_HEADERS,
    }
    for fname, headers in specs.items():
        path = master_path(fname)
        if not os.path.exists(path):
            wb = Workbook()
            ws = wb.active
            ws.title = os.path.splitext(fname)[0]
            for c, h in enumerate(headers, 1):
                cell = ws.cell(1, c, h)
                cell.font = Font(bold=True)
                ws.column_dimensions[get_column_letter(c)].width = max(14, len(h) + 3)
            ws.freeze_panes = "A2"
            wb.save(path)


def append_explainable_rows(fname, headers, rows):
    ensure_explainable_reliability_files()
    path = master_path(fname)
    wb = load_workbook(path)
    ws = wb.active
    for row in rows:
        r = ws.max_row + 1
        for c, h in enumerate(headers, 1):
            ws.cell(r, c, row.get(h, ""))
    wb.save(path)
    return path


def score_readiness(score, unknown_days, replacement_score):
    try:
        score = float(score)
    except Exception:
        score = 0
    try:
        unknown_days = int(unknown_days or 0)
    except Exception:
        unknown_days = 0
    try:
        replacement_score = float(replacement_score)
    except Exception:
        replacement_score = 0

    if score >= 85 and unknown_days <= 7 and replacement_score >= 80:
        return "READY"
    if score >= 65 and unknown_days <= 45:
        return "READY WITH CAUTION"
    return "NOT READY"


def build_explainable_reliability(summary_rows, runtime_rows, gap_rows, replacement_validation_rows=None, prediction_rows=None):
    run_date = dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
    replacement_validation_rows = replacement_validation_rows or []
    prediction_rows = prediction_rows or []

    daily = runtime_daily_map(summary_rows)
    days = sorted(daily.keys())
    if days:
        total_span_days = (days[-1] - days[0]).days + 1
        observed_days = len(days)
        coverage_score = round((observed_days / max(1, total_span_days)) * 100.0, 1)
        coverage_reason = "%d observed day(s) over %d calendar day(s)." % (observed_days, total_span_days)
    else:
        total_span_days = 0
        observed_days = 0
        coverage_score = 0.0
        coverage_reason = "No log date data."

    gap_count = len(gap_rows or [])
    gap_days = sum(int(g.get("Gap Days", 0) or 0) for g in (gap_rows or []))
    max_gap = max([int(g.get("Gap Days", 0) or 0) for g in (gap_rows or [])] + [0])

    data_continuity_score = max(0, 100 - gap_count * 8 - max_gap * 1.5)
    data_continuity_reason = "%d gap(s), maximum gap %d day(s)." % (gap_count, max_gap)

    gap_quality_score = max(0, 100 - gap_days * 2)
    gap_quality_reason = "%d total missing day(s)." % gap_days

    measured = round(sum(float(r.get("Measured Runtime Hours", 0) or 0) for r in (runtime_rows or [])), 2)
    estimated = round(sum(float(r.get("Estimated Runtime Hours", 0) or 0) for r in (runtime_rows or [])), 2)
    unknown_days = sum(int(r.get("Unknown Days", 0) or 0) for r in (runtime_rows or []))
    total_runtime = measured + estimated

    if total_runtime > 0:
        measured_ratio = measured / total_runtime
        runtime_confidence_score = round(max(0, min(100, measured_ratio * 100 - unknown_days * 1.5)), 1)
        runtime_reason = "Measured runtime %.1f%% of runtime basis; unknown days %d." % (measured_ratio * 100, unknown_days)
    else:
        runtime_confidence_score = 0.0
        runtime_reason = "No runtime basis data."

    rep_rows = replacement_validation_rows
    rep_warning_count = sum(1 for r in rep_rows if r.get("Status") != "OK")
    if rep_rows:
        replacement_quality_score = max(0, 100 - rep_warning_count * 18)
        replacement_reason = "%d replacement record(s), %d warning(s)." % (len(rep_rows), rep_warning_count)
    else:
        replacement_quality_score = 50
        replacement_reason = "No replacement validation rows; neutral initial score."

    # Until prediction dates are available, use neutral stability score.
    prediction_stability_score = 50
    prediction_stability_reason = "Prediction date is not calculated yet; neutral initial score."

    # Basic data quality checks: negative runtime, duplicate days not detectable after aggregation but negative values are.
    negative_count = 0
    for r in summary_rows or []:
        for key in ["Runtime", "Treat", "Degas", "Clean"]:
            try:
                if float(r.get(key, 0) or 0) < 0:
                    negative_count += 1
            except Exception:
                pass
    data_quality_score = max(0, 100 - negative_count * 10)
    data_quality_reason = "%d negative runtime value(s) detected." % negative_count if negative_count else "No basic runtime anomaly detected."

    overall = round(
        coverage_score * 0.15 +
        data_continuity_score * 0.15 +
        gap_quality_score * 0.15 +
        replacement_quality_score * 0.20 +
        runtime_confidence_score * 0.20 +
        prediction_stability_score * 0.15,
        1
    )
    stars = confidence_stars(overall)
    readiness = score_readiness(overall, unknown_days, replacement_quality_score)

    explanation = (
        "Overall %.1f (%s). Coverage %.1f because %s "
        "Continuity %.1f because %s "
        "Gap %.1f because %s "
        "Runtime %.1f because %s "
        "Replacement %.1f because %s "
        "Prediction stability %.1f because %s"
    ) % (
        overall, stars,
        coverage_score, coverage_reason,
        data_continuity_score, data_continuity_reason,
        gap_quality_score, gap_quality_reason,
        runtime_confidence_score, runtime_reason,
        replacement_quality_score, replacement_reason,
        prediction_stability_score, prediction_stability_reason
    )

    row = {
        "Run Date": run_date,
        "Hospital Name": "",
        "Serial Number": "",
        "Component Type": "Degas Module",
        "Forecast Readiness": readiness,
        "Forecast Readiness Score": overall,
        "Overall Confidence Score": overall,
        "Overall Confidence Stars": stars,
        "Coverage Score": coverage_score,
        "Coverage Reason": coverage_reason,
        "Data Continuity Score": round(data_continuity_score, 1),
        "Data Continuity Reason": data_continuity_reason,
        "Gap Quality Score": round(gap_quality_score, 1),
        "Gap Quality Reason": gap_quality_reason,
        "Runtime Confidence Score": runtime_confidence_score,
        "Runtime Confidence Reason": runtime_reason,
        "Replacement Quality Score": round(replacement_quality_score, 1),
        "Replacement Quality Reason": replacement_reason,
        "Prediction Stability Score": prediction_stability_score,
        "Prediction Stability Reason": prediction_stability_reason,
        "Data Quality Score": data_quality_score,
        "Data Quality Reason": data_quality_reason,
        "Overall Explanation": explanation,
        "Algorithm Version": ALGORITHM_VERSION,
    }

    trend = {
        "Run Date": run_date,
        "Hospital Name": "",
        "Serial Number": "",
        "Component Type": "Degas Module",
        "Forecast Readiness": readiness,
        "Overall Confidence Score": overall,
        "Overall Confidence Stars": stars,
        "Coverage Score": coverage_score,
        "Data Continuity Score": round(data_continuity_score, 1),
        "Gap Quality Score": round(gap_quality_score, 1),
        "Runtime Confidence Score": runtime_confidence_score,
        "Replacement Quality Score": round(replacement_quality_score, 1),
        "Prediction Stability Score": prediction_stability_score,
        "Data Quality Score": data_quality_score,
        "Measured Runtime Hours": measured,
        "Estimated Runtime Hours": estimated,
        "Unknown Days": unknown_days,
        "Algorithm Version": ALGORITHM_VERSION,
    }

    return [row], [trend]


def save_explainable_reliability(summary_rows, runtime_rows, gap_rows, replacement_validation_rows=None, prediction_rows=None):
    rows, trend_rows = build_explainable_reliability(summary_rows, runtime_rows, gap_rows, replacement_validation_rows, prediction_rows)
    p1 = append_explainable_rows("Explainable_Reliability.xlsx", EXPLAINABLE_RELIABILITY_HEADERS, rows)
    p2 = append_explainable_rows("Reliability_Trend.xlsx", RELIABILITY_TREND_HEADERS, trend_rows)
    return (p1, p2), rows, trend_rows

def build_prediction_and_confidence(runtime_rows):
    run_date = dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
    observed = round(sum(float(r.get("Measured Runtime Hours", 0) or 0) for r in runtime_rows), 2)
    estimated = round(sum(float(r.get("Estimated Runtime Hours", 0) or 0) for r in runtime_rows), 2)
    unknown_days = sum(int(r.get("Unknown Days", 0) or 0) for r in runtime_rows)
    total = round(observed + estimated, 2)

    coverage_score = 100 if observed > 0 else 0
    gap_score = max(0, 100 - unknown_days * 3)
    replacement_score = 100
    runtime_quality_score = 100 if estimated == 0 else max(50, 100 - min(50, (estimated / max(1, total)) * 100))
    prediction_stability_score = 50
    overall = round(coverage_score*0.20 + gap_score*0.20 + replacement_score*0.20 + runtime_quality_score*0.25 + prediction_stability_score*0.15, 1)

    pred = [{
        "Run Date": run_date, "Hospital Name": "", "Serial Number": "",
        "Component Type": "Degas Module", "Observed Runtime Hours": observed,
        "Estimated Runtime Hours": estimated, "Total Runtime Basis Hours": total,
        "Forecast Method": "Runtime reconstruction foundation",
        "Prediction Status": "Not calculated",
        "Prediction Note": "Version 7.2c reconstructs runtime basis and saves explainable reliability/readiness. Final replacement prediction date is not calculated yet.",
        "Algorithm Version": ALGORITHM_VERSION,
    }]
    conf = [{
        "Run Date": run_date, "Hospital Name": "", "Serial Number": "",
        "Component Type": "Degas Module", "Coverage Score": coverage_score,
        "Gap Quality Score": gap_score, "Replacement History Score": replacement_score,
        "Runtime Quality Score": round(runtime_quality_score, 1),
        "Prediction Stability Score": prediction_stability_score,
        "Overall Confidence Score": overall, "Overall Confidence Stars": confidence_stars(overall),
        "Explanation": "Observed %.2f h + estimated %.2f h = runtime basis %.2f h. Unknown days: %d." % (observed, estimated, total, unknown_days),
        "Algorithm Version": ALGORITHM_VERSION,
    }]
    return pred, conf

def save_runtime_reconstruction(summary_rows, missing_handling="Unknown", save_explainable=False):
    runtime_rows, gap_rows, reference_rows = build_runtime_reconstruction(summary_rows, missing_handling)
    prediction_rows, confidence_rows = build_prediction_and_confidence(runtime_rows)

    explain_paths = ()
    if save_explainable:
        replacement_validation_rows = validate_replacement_history() if "validate_replacement_history" in globals() else []
        explain_paths, _explain_rows, _trend_rows = save_explainable_reliability(
            summary_rows, runtime_rows, gap_rows, replacement_validation_rows, prediction_rows
        )

    p1 = append_runtime_rows("Runtime_Reconstruction.xlsx", RUNTIME_RECONSTRUCTION_HEADERS, runtime_rows)
    p2 = append_runtime_rows("Gap_History.xlsx", GAP_HISTORY_HEADERS, gap_rows)
    p_ref = append_runtime_rows("Reference_Intervals.xlsx", REFERENCE_INTERVAL_HEADERS, reference_rows)
    p3 = append_runtime_rows("Prediction_History.xlsx", PREDICTION_HISTORY_HEADERS, prediction_rows)
    p4 = append_runtime_rows("Confidence_History.xlsx", CONFIDENCE_HISTORY_HEADERS, confidence_rows)
    return (p1, p2, p_ref, p3, p4) + explain_paths, runtime_rows, gap_rows, reference_rows, prediction_rows, confidence_rows


class SummaryMetricCard(QtWidgets.QFrame):
    def __init__(self, title, value, note="", parent=None):
        super(SummaryMetricCard, self).__init__(parent)
        self.setObjectName("SummaryMetricCard")
        self.setMinimumHeight(104)
        self.setStyleSheet(
            "QFrame#SummaryMetricCard {"
            "background:#ffffff; border:1px solid #cbd7e3; border-radius:9px;"
            "}"
            "QFrame#SummaryMetricCard QLabel { background:transparent; }"
        )
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        title_label = QLabel(str(title))
        title_label.setStyleSheet("font-size:12px; color:#5a6a79; font-weight:600;")
        value_label = QLabel(str(value))
        value_label.setStyleSheet("font-size:24px; color:#1f3d59; font-weight:700;")
        value_label.setWordWrap(True)
        note_label = QLabel(str(note))
        note_label.setStyleSheet("font-size:11px; color:#6d7781;")
        note_label.setWordWrap(True)
        layout.addWidget(title_label)
        layout.addWidget(value_label)
        layout.addWidget(note_label)


class CollapsibleDetails(QtWidgets.QWidget):
    def __init__(self, title="Show Details", parent=None):
        super(CollapsibleDetails, self).__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.toggle = QPushButton("▶ " + title)
        self.toggle.setCheckable(True)
        self.toggle.setChecked(False)
        self.toggle.setStyleSheet(
            "QPushButton { text-align:left; font-weight:600; padding:7px 10px; }"
        )
        layout.addWidget(self.toggle)

        self.content = QWidget()
        self.content_layout = QVBoxLayout(self.content)
        self.content_layout.setContentsMargins(0, 6, 0, 0)
        self.content.setVisible(False)
        layout.addWidget(self.content)

        self._title = title
        self.toggle.toggled.connect(self._set_open)

    def _set_open(self, opened):
        self.content.setVisible(bool(opened))
        self.toggle.setText(("▼ " if opened else "▶ ") + self._title)
        self.updateGeometry()


def add_readable_table_tab(tabs, title, headers, rows):
    table = QtWidgets.QTableWidget()
    table.setColumnCount(len(headers))
    table.setHorizontalHeaderLabels(headers)
    table.setRowCount(len(rows))
    for r_idx, row in enumerate(rows):
        for c_idx, header in enumerate(headers):
            table.setItem(
                r_idx,
                c_idx,
                QtWidgets.QTableWidgetItem(str(row.get(header, "")))
            )
    table.setAlternatingRowColors(True)
    table.setSelectionBehavior(
        QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows
    )
    table.setSelectionMode(
        QtWidgets.QAbstractItemView.SelectionMode.SingleSelection
    )
    table.verticalHeader().setDefaultSectionSize(25)
    table.horizontalHeader().setStretchLastSection(True)
    table.setWordWrap(False)
    table.resizeColumnsToContents()
    table.setHorizontalScrollMode(
        QtWidgets.QAbstractItemView.ScrollMode.ScrollPerPixel
    )
    tabs.addTab(table, title)
    return table


class RuntimeReconstructionDialog(QtWidgets.QDialog):
    def __init__(self, runtime_rows, gap_rows, reference_rows, prediction_rows, confidence_rows, parent=None):
        super(RuntimeReconstructionDialog, self).__init__(parent)
        self.setWindowTitle("Runtime Reconstruction")
        self.resize(1080, 760)
        self.runtime_rows = runtime_rows or []
        self.gap_rows = gap_rows or []
        self.reference_rows = reference_rows or []
        self.prediction_rows = prediction_rows or []
        self.confidence_rows = confidence_rows or []
        apply_servicehub_dialog_style(self)
        self._ui()

    def _ui(self):
        layout = QVBoxLayout(self)

        heading = QLabel(
            "<div style='font-size:22px; font-weight:700;'>Runtime Reconstruction</div>"
            "<div style='color:#647484;'>Summary first. Open Details only when the full tables are needed.</div>"
        )
        heading.setWordWrap(True)
        layout.addWidget(heading)

        prediction = self.prediction_rows[-1] if self.prediction_rows else {}
        confidence = self.confidence_rows[-1] if self.confidence_rows else {}

        observed = prediction.get("Observed Runtime Hours", 0)
        estimated = prediction.get("Estimated Runtime Hours", 0)
        total = prediction.get("Total Runtime Basis Hours", 0)
        stars = confidence.get("Overall Confidence Stars", "—")
        score = confidence.get("Overall Confidence Score", "—")

        cards = QHBoxLayout()
        cards.addWidget(SummaryMetricCard("Measured Runtime", "%s h" % observed, "Observed from ResultSummary/log data"))
        cards.addWidget(SummaryMetricCard("Estimated Runtime", "%s h" % estimated, "Estimated only for confirmed Potential GAP"))
        cards.addWidget(SummaryMetricCard("Runtime Basis", "%s h" % total, "Measured plus accepted estimate"))
        cards.addWidget(SummaryMetricCard("Confidence", "%s" % stars, "Score: %s" % score))
        layout.addLayout(cards)

        second_cards = QHBoxLayout()
        second_cards.addWidget(SummaryMetricCard("Potential GAP", len(self.gap_rows), "Intervals requiring review"))
        second_cards.addWidget(SummaryMetricCard("Reference Intervals", len(self.reference_rows), "Normal operating intervals"))
        unknown_days = 0
        for row in self.runtime_rows:
            try:
                unknown_days += int(float(row.get("Unknown Days", 0) or 0))
            except Exception:
                pass
        second_cards.addWidget(SummaryMetricCard("Unknown Days", unknown_days, "Not converted into estimated runtime"))
        note = prediction.get("Prediction Note", "") or "No prediction note."
        second_cards.addWidget(SummaryMetricCard("Current Status", "READY" if self.runtime_rows else "NO DATA", note))
        layout.addLayout(second_cards)

        gap_box = QtWidgets.QGroupBox("Potential GAP Review")
        gap_layout = QVBoxLayout(gap_box)
        if not self.gap_rows:
            gap_layout.addWidget(QLabel(
                "No interval exceeded the hospital-specific long-gap threshold."
            ))
        else:
            for row in self.gap_rows[:8]:
                card = QLabel(
                    "<b>{start} → {end}</b><br>"
                    "Gap: {days} day(s) &nbsp;&nbsp; Handling: {handling}<br>"
                    "<span style='color:#667;'>{basis}</span>".format(
                        start=row.get("Gap Start", ""),
                        end=row.get("Gap End", ""),
                        days=row.get("Gap Days", ""),
                        handling=row.get("Handling", ""),
                        basis=row.get("Basis", ""),
                    )
                )
                card.setWordWrap(True)
                card.setStyleSheet(
                    "padding:8px; background:#fff8e5; border:1px solid #e4c978; border-radius:6px;"
                )
                gap_layout.addWidget(card)
            if len(self.gap_rows) > 8:
                gap_layout.addWidget(QLabel(
                    "%d additional Potential GAP record(s) are available in Details."
                    % (len(self.gap_rows) - 8)
                ))
        layout.addWidget(gap_box)

        details = CollapsibleDetails("Show Details")
        tabs = QtWidgets.QTabWidget()
        add_readable_table_tab(
            tabs, "Runtime", RUNTIME_RECONSTRUCTION_HEADERS, self.runtime_rows
        )
        add_readable_table_tab(
            tabs, "Potential GAP", GAP_HISTORY_HEADERS, self.gap_rows
        )
        add_readable_table_tab(
            tabs, "Reference Intervals", REFERENCE_INTERVAL_HEADERS, self.reference_rows
        )
        add_readable_table_tab(
            tabs, "Prediction", PREDICTION_HISTORY_HEADERS, self.prediction_rows
        )
        add_readable_table_tab(
            tabs, "Confidence", CONFIDENCE_HISTORY_HEADERS, self.confidence_rows
        )
        details.content_layout.addWidget(tabs)
        layout.addWidget(details, 1)

        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        layout.addWidget(close)


class ReliabilityDashboardDialog(QtWidgets.QDialog):
    def __init__(self, validation_rows, gap_rows, reliability_rows, snapshot_rows, parent=None):
        super(ReliabilityDashboardDialog, self).__init__(parent)
        self.setWindowTitle("Reliability Dashboard")
        self.resize(1080, 760)
        self.validation_rows = validation_rows or []
        self.gap_rows = gap_rows or []
        self.reliability_rows = reliability_rows or []
        self.snapshot_rows = snapshot_rows or []
        apply_servicehub_dialog_style(self)
        self._ui()

    def _ui(self):
        layout = QVBoxLayout(self)

        heading = QLabel(
            "<div style='font-size:22px; font-weight:700;'>Reliability Dashboard</div>"
            "<div style='color:#647484;'>Key reliability results are shown as cards. Detailed tables are collapsed by default.</div>"
        )
        heading.setWordWrap(True)
        layout.addWidget(heading)

        latest = self.reliability_rows[-1] if self.reliability_rows else {}
        snapshot = self.snapshot_rows[-1] if self.snapshot_rows else {}

        coverage = latest.get("Coverage %", "—")
        stars = latest.get("Confidence Stars", "—")
        score = latest.get("Confidence Score", "—")
        quality = latest.get("Data Quality", "—")
        estimated = latest.get("Estimated Runtime Hours", "—")
        warning = latest.get("Warning", "") or "No active warning."

        cards = QHBoxLayout()
        cards.addWidget(SummaryMetricCard("Coverage", "%s%%" % coverage, "Available observation coverage"))
        cards.addWidget(SummaryMetricCard("Confidence", stars, "Score: %s" % score))
        cards.addWidget(SummaryMetricCard("Data Quality", quality, "Current reliability input quality"))
        cards.addWidget(SummaryMetricCard("Estimated Runtime", "%s h" % estimated, "Estimated contribution to runtime"))
        layout.addLayout(cards)

        second = QHBoxLayout()
        second.addWidget(SummaryMetricCard("Replacement Validation", len(self.validation_rows), "Replacement records checked"))
        second.addWidget(SummaryMetricCard("Gap Findings", len(self.gap_rows), "Potential gaps affecting reliability"))
        forecast_status = snapshot.get("Forecast Readiness", snapshot.get("Readiness", "—"))
        second.addWidget(SummaryMetricCard("Forecast Status", forecast_status, "Latest forecast snapshot"))
        second.addWidget(SummaryMetricCard("Warning", warning, "Review before final forecast"))
        layout.addLayout(second)

        explanation_box = QtWidgets.QGroupBox("What this means")
        explanation_layout = QVBoxLayout(explanation_box)
        explanation = QLabel(
            "✓ Coverage and runtime quality contribute to the confidence score.<br>"
            "✓ Potential GAP records are separated from ordinary reference intervals.<br>"
            "✓ Replacement History validation affects forecast readiness.<br>"
            "✓ Open Details only when the row-level evidence is required."
        )
        explanation.setWordWrap(True)
        explanation.setStyleSheet(
            "padding:9px; background:#eef6fc; border:1px solid #bfd4e5; border-radius:6px;"
        )
        explanation_layout.addWidget(explanation)
        layout.addWidget(explanation_box)

        details = CollapsibleDetails("Show Details")
        tabs = QtWidgets.QTabWidget()
        add_readable_table_tab(
            tabs, "Reliability", RELIABILITY_HISTORY_HEADERS, self.reliability_rows
        )
        add_readable_table_tab(
            tabs, "Replacement Validation", REPLACEMENT_VALIDATION_HEADERS, self.validation_rows
        )
        add_readable_table_tab(
            tabs, "Gap Analysis", GAP_ANALYSIS_HEADERS, self.gap_rows
        )
        add_readable_table_tab(
            tabs, "Forecast Snapshot", FORECAST_SNAPSHOT_HEADERS, self.snapshot_rows
        )
        details.content_layout.addWidget(tabs)
        layout.addWidget(details, 1)

        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        layout.addWidget(close)


DATA_COVERAGE_HEADERS = ["Run Date","Hospital Name","Serial Number","Component Type","First Log Date","Last Log Date","Observation Days","Missing Log Handling","Coverage %","Data Quality","Confidence","Warning","Algorithm Version"]
FORECAST_RUN_HISTORY_HEADERS = ["Run Date","Hospital Name","Serial Number","Component Type","Missing Log Handling","Replacement Count","First Log Date","Last Log Date","Coverage %","Data Quality","Confidence","Forecast Basis","Warning","Algorithm Version"]

def ensure_forecast_foundation_files():
    for fname, headers in {"Data_Coverage_Master.xlsx": DATA_COVERAGE_HEADERS, "Forecast_Run_History.xlsx": FORECAST_RUN_HISTORY_HEADERS}.items():
        path = master_path(fname)
        if not os.path.exists(path):
            wb = Workbook()
            ws = wb.active
            ws.title = os.path.splitext(fname)[0]
            for c, h in enumerate(headers, 1):
                ws.cell(1, c, h)
                ws.column_dimensions[get_column_letter(c)].width = max(14, len(h) + 3)
            ws.freeze_panes = "A2"
            wb.save(path)

def append_forecast_rows(path, headers, rows):
    ensure_forecast_foundation_files()
    wb = load_workbook(path)
    ws = wb.active
    for row in rows:
        r = ws.max_row + 1
        for c, h in enumerate(headers, 1):
            ws.cell(r, c, row.get(h, ""))
    wb.save(path)

def save_forecast_foundation(summary_rows, missing_handling="Unknown"):
    ensure_forecast_foundation_files()
    dates = [r.get("DateTime") for r in (summary_rows or []) if isinstance(r.get("DateTime"), dt.datetime)]
    first = min(dates) if dates else None
    last = max(dates) if dates else None
    days = (last - first).days + 1 if first and last else 0
    quality = "High" if days >= 180 else ("Medium" if days >= 30 else "Low")
    confidence = "Medium" if days > 0 else "Low"
    warning = "" if days > 0 else "No log date data available."
    run_date = dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
    row = {"Run Date": run_date, "Hospital Name": "", "Serial Number": "", "Component Type": "Degas Module", "First Log Date": first.strftime("%Y/%m/%d") if first else "", "Last Log Date": last.strftime("%Y/%m/%d") if last else "", "Observation Days": days, "Missing Log Handling": missing_handling, "Coverage %": 100.0 if days > 0 else 0.0, "Data Quality": quality, "Confidence": confidence, "Warning": warning, "Algorithm Version": ALGORITHM_VERSION}
    hist = {"Run Date": run_date, "Hospital Name": "", "Serial Number": "", "Component Type": "Degas Module", "Missing Log Handling": missing_handling, "Replacement Count": "", "First Log Date": row["First Log Date"], "Last Log Date": row["Last Log Date"], "Coverage %": row["Coverage %"], "Data Quality": quality, "Confidence": confidence, "Forecast Basis": "Coverage foundation only / no final prediction in Version 7.0 Initial", "Warning": warning, "Algorithm Version": ALGORITHM_VERSION}
    append_forecast_rows(master_path("Data_Coverage_Master.xlsx"), DATA_COVERAGE_HEADERS, [row])
    append_forecast_rows(master_path("Forecast_Run_History.xlsx"), FORECAST_RUN_HISTORY_HEADERS, [hist])
    return [row], [hist]

class ForecastFoundationDialog(QtWidgets.QDialog):
    def __init__(self, coverage_rows, history_rows, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Forecast Foundation / Data Coverage")
        self.resize(1000, 600)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Version 7.0 Initial: Forecast foundation only. Final prediction is not calculated yet."))
        tabs = QtWidgets.QTabWidget()
        layout.addWidget(tabs, 1)
        for title, headers, rows in [("Data Coverage", DATA_COVERAGE_HEADERS, coverage_rows), ("Forecast Run History", FORECAST_RUN_HISTORY_HEADERS, history_rows)]:
            table = QtWidgets.QTableWidget()
            table.setColumnCount(len(headers))
            table.setHorizontalHeaderLabels(headers)
            table.setRowCount(len(rows))
            for r_idx, row in enumerate(rows):
                for c_idx, h in enumerate(headers):
                    table.setItem(r_idx, c_idx, QtWidgets.QTableWidgetItem(str(row.get(h, ""))))
            table.resizeColumnsToContents()
            tabs.addTab(table, title)
        b = QPushButton("Close")
        b.clicked.connect(self.accept)
        layout.addWidget(b)

def import_history_xlsx_to_master(path):
    """
    Import the attached History.xlsx layout:
      Row 1: SN / HP
      Column A: HP SN
      Column B: HP/Site name
      Columns C onward: replacement dates as Excel serials or date text

    This step only imports/editable history data.
    It does not calculate forecast, MTBF, reliability, or remaining life.
    """
    ensure_master_foundation_files()

    wb = load_workbook(path, data_only=True, read_only=True)
    ws = wb[wb.sheetnames[0]]

    hp_existing = read_master_foundation_rows("Hospital_Master.xlsx", HP_MASTER_HEADERS)
    rep_existing = read_master_foundation_rows("Replacement_History.xlsx", REPLACEMENT_HISTORY_HEADERS)

    hp_by_id = {}
    for row in hp_existing:
        key = normalize_history_key(row.get("Hospital Name"))
        if key:
            hp_by_id[key] = row

    rep_keys = set()
    for row in rep_existing:
        hp_id = normalize_history_key(row.get("Hospital Name"))
        d = excel_serial_to_datetime(row.get("Replacement Date"))
        d_key = d.strftime("%Y-%m-%d") if d else str(row.get("Replacement Date", "")).strip()
        rep_keys.add((hp_id, d_key))

    imported_hp = 0
    imported_rep = 0
    skipped_dates = 0

    for r in range(2, ws.max_row + 1):
        hp_id = normalize_history_key(ws.cell(r, 1).value)
        site = normalize_history_key(ws.cell(r, 2).value)

        if not hp_id and not site:
            continue
        if hp_id.upper() == "NA":
            continue

        if hp_id:
            if hp_id not in hp_by_id:
                hp_row = {
                    "Hospital Name": site or hp_id,
                    "Site": site,
                    "Serial Number": hp_id,
                    "Installation Date": "",
                    "Coil Type": "",
                    "Status": "Active",
                    "Comment": "Imported from History.xlsx",
                }
                hp_by_id[hp_id] = hp_row
                hp_existing.append(hp_row)
                imported_hp += 1
            else:
                # Fill missing site/serial without overwriting user edits.
                if site and not hp_by_id[hp_id].get("Site"):
                    hp_by_id[hp_id]["Site"] = site
                if not hp_by_id[hp_id].get("Serial Number"):
                    hp_by_id[hp_id]["Serial Number"] = hp_id

        for c in range(3, ws.max_column + 1):
            raw = ws.cell(r, c).value
            if raw in ("", None):
                continue
            d = excel_serial_to_datetime(raw)
            if not d:
                skipped_dates += 1
                continue

            d_key = d.strftime("%Y-%m-%d")
            key = (hp_id, d_key)
            if key in rep_keys:
                continue

            rep_existing.append({
                "Hospital Name": site or hp_id,
                "Serial Number": hp_id,
                "Component Type": "Degas Module",
                "Component ID": "",
                "Coil ID": "",
                "Replacement Date": d.strftime("%Y/%m/%d"),
                "Replacement Type": "Unknown",
                "Reason": "",
                "Comment": "Imported from History.xlsx",
            })
            rep_keys.add(key)
            imported_rep += 1

    hp_path = write_master_foundation_rows("Hospital_Master.xlsx", HP_MASTER_HEADERS, hp_existing)
    rep_path = write_master_foundation_rows("Replacement_History.xlsx", REPLACEMENT_HISTORY_HEADERS, rep_existing)

    return {
        "hp_path": hp_path,
        "rep_path": rep_path,
        "imported_hp": imported_hp,
        "imported_replacement": imported_rep,
        "skipped_dates": skipped_dates,
        "total_hp": len(hp_existing),
        "total_replacement": len(rep_existing),
    }



class MasterFoundationDialog(QtWidgets.QDialog):
    """
    Step5 simple master editor.
    This is intentionally basic and safe: no Forecast calculation is performed.
    """
    def __init__(self, parent=None):
        super(MasterFoundationDialog, self).__init__(parent)
        self.setWindowTitle("Step6.2 Master Foundation")
        self.resize(1000, 650)
        self.hp_rows = []
        self.rep_rows = []
        self._ui()
        self.load_all()

    def _ui(self):
        layout = QVBoxLayout(self)
        info = QLabel("Step6.2 Master Foundation: edit HP Master and Replacement History, or import History.xlsx. No forecast calculation is performed in this step.")
        info.setWordWrap(True)
        layout.addWidget(info)

        self.tabs = QtWidgets.QTabWidget()
        layout.addWidget(self.tabs, 1)

        self.hp_table = QtWidgets.QTableWidget()
        self.hp_table.setColumnCount(len(HP_MASTER_HEADERS))
        self.hp_table.setHorizontalHeaderLabels(HP_MASTER_HEADERS)
        self.hp_table.horizontalHeader().setStretchLastSection(True)
        self.tabs.addTab(self.hp_table, "HP Master")

        self.component_table = QtWidgets.QTableWidget()
        self.component_table.setColumnCount(len(COMPONENT_MASTER_HEADERS))
        self.component_table.setHorizontalHeaderLabels(COMPONENT_MASTER_HEADERS)
        self.component_table.horizontalHeader().setStretchLastSection(True)
        self.tabs.addTab(self.component_table, "Component Master")

        self.rep_table = QtWidgets.QTableWidget()
        self.rep_table.setColumnCount(len(REPLACEMENT_HISTORY_HEADERS))
        self.rep_table.setHorizontalHeaderLabels(REPLACEMENT_HISTORY_HEADERS)
        self.rep_table.horizontalHeader().setStretchLastSection(True)
        self.tabs.addTab(self.rep_table, "Replacement History")

        btns = QHBoxLayout()
        layout.addLayout(btns)

        b = QPushButton("Add Row")
        b.clicked.connect(self.add_row)
        btns.addWidget(b)

        b = QPushButton("Delete Selected Row")
        b.clicked.connect(self.delete_selected_row)
        btns.addWidget(b)

        b = QPushButton("Save")
        b.clicked.connect(self.save_all)
        btns.addWidget(b)

        b = QPushButton("Reload")
        b.clicked.connect(self.load_all)
        btns.addWidget(b)

        b = QPushButton("Import History.xlsx")
        b.clicked.connect(self.import_history_file)
        btns.addWidget(b)

        b = QPushButton("Open Master Folder")
        b.clicked.connect(self.open_master_folder)
        btns.addWidget(b)

        b = QPushButton("Close")
        b.clicked.connect(self.accept)
        btns.addWidget(b)

    def show_wait(self, text="Updating... Please wait."):
        try:
            self._wait = QProgressDialog(text, None, 0, 0, self)
            self._wait.setWindowTitle("Updating")
            self._wait.setWindowModality(QtCore.Qt.WindowModality.ApplicationModal)
            self._wait.setMinimumDuration(0)
            self._wait.setCancelButton(None)
            self._wait.show()
            QApplication.processEvents()
        except Exception:
            self._wait = None

    def hide_wait(self):
        try:
            if getattr(self, "_wait", None):
                self._wait.close()
                self._wait = None
            QApplication.processEvents()
        except Exception:
            pass

    def active_table_and_headers(self):
        if self.tabs.currentIndex() == 0:
            return self.hp_table, HP_MASTER_HEADERS, "Hospital_Master.xlsx"
        if self.tabs.currentIndex() == 1:
            return self.component_table, COMPONENT_MASTER_HEADERS, "Component_Master.xlsx"
        return self.rep_table, REPLACEMENT_HISTORY_HEADERS, "Replacement_History.xlsx"

    def populate_table(self, table, headers, rows):
        table.setRowCount(len(rows))
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(headers)
        for r_idx, row in enumerate(rows):
            for c_idx, h in enumerate(headers):
                val = row.get(h, "")
                if val is None:
                    val = ""
                item = QtWidgets.QTableWidgetItem(str(val))
                table.setItem(r_idx, c_idx, item)
        table.resizeColumnsToContents()

    def table_to_rows(self, table, headers):
        rows = []
        for r in range(table.rowCount()):
            row = {}
            empty = True
            for c, h in enumerate(headers):
                item = table.item(r, c)
                val = item.text().strip() if item else ""
                if val:
                    empty = False
                row[h] = val
            if not empty:
                rows.append(row)
        return rows

    def load_all(self):
        try:
            ensure_master_foundation_files()
            self.hp_rows = read_master_foundation_rows("Hospital_Master.xlsx", HP_MASTER_HEADERS)
            self.component_rows = read_master_foundation_rows("Component_Master.xlsx", COMPONENT_MASTER_HEADERS)
            self.rep_rows = read_master_foundation_rows("Replacement_History.xlsx", REPLACEMENT_HISTORY_HEADERS)
            self.populate_table(self.hp_table, HP_MASTER_HEADERS, self.hp_rows)
            self.populate_table(self.component_table, COMPONENT_MASTER_HEADERS, self.component_rows)
            self.populate_table(self.rep_table, REPLACEMENT_HISTORY_HEADERS, self.rep_rows)
        except Exception:
            self.hide_wait()
            QMessageBox.critical(self, "Master Foundation", traceback.format_exc())

    def save_all(self):
        try:
            self.show_wait("Saving master files...")
            hp_rows = self.table_to_rows(self.hp_table, HP_MASTER_HEADERS)
            component_rows = self.table_to_rows(self.component_table, COMPONENT_MASTER_HEADERS)
            rep_rows = self.table_to_rows(self.rep_table, REPLACEMENT_HISTORY_HEADERS)
            hp_path = write_master_foundation_rows("Hospital_Master.xlsx", HP_MASTER_HEADERS, hp_rows)
            component_path = write_master_foundation_rows("Component_Master.xlsx", COMPONENT_MASTER_HEADERS, component_rows)
            rep_path = write_master_foundation_rows("Replacement_History.xlsx", REPLACEMENT_HISTORY_HEADERS, rep_rows)
            self.hide_wait()
            QMessageBox.information(self, "Master Foundation", "Saved:\n%s\n%s\n%s" % (hp_path, component_path, rep_path))
        except Exception:
            QMessageBox.critical(self, "Master Foundation", traceback.format_exc())

    def add_row(self):
        table, headers, _fname = self.active_table_and_headers()
        r = table.rowCount()
        table.insertRow(r)
        for c in range(len(headers)):
            table.setItem(r, c, QtWidgets.QTableWidgetItem(""))

    def delete_selected_row(self):
        table, _headers, _fname = self.active_table_and_headers()
        rows = sorted(set(i.row() for i in table.selectedIndexes()), reverse=True)
        for r in rows:
            table.removeRow(r)

    def import_history_file(self):
        try:
            path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Select History.xlsx", "", "Excel Files (*.xlsx *.xlsm);;All Files (*.*)")
            if not path:
                return
            self.show_wait("Importing History.xlsx... Please wait.")
            result = import_history_xlsx_to_master(path)
            self.load_all()
            self.hide_wait()
            QMessageBox.information(
                self,
                "Master Foundation",
                "History import complete.\n\nImported data was written to Hospital_Master.xlsx and Replacement_History.xlsx.\n\n"
                "Imported HP rows: %d\n"
                "Imported replacement rows: %d\n"
                "Skipped invalid date cells: %d\n\n"
                "HP total: %d\n"
                "Replacement total: %d\n\n"
                "Saved:\n%s\n%s\n\n"
                "Replacement Type is set to Unknown. Edit each row to Failure or Preventive before Forecast calculation."
                % (
                    result["imported_hp"],
                    result["imported_replacement"],
                    result["skipped_dates"],
                    result["total_hp"],
                    result["total_replacement"],
                    result["hp_path"],
                    result["rep_path"],
                )
            )
        except Exception:
            QMessageBox.critical(self, "Master Foundation", traceback.format_exc())

    def open_master_folder(self):
        try:
            ensure_master_foundation_files()
            os.startfile(os.path.dirname(master_foundation_path("Hospital_Master.xlsx")))
        except Exception:
            QMessageBox.critical(self, "Master Foundation", traceback.format_exc())


def ensure_data_folders():
    root = get_data_root()
    for sub in ["Master", "History", "Backup", "Log", "Reports"]:
        p = os.path.join(root, sub)
        if not os.path.exists(p):
            os.makedirs(p)
    ensure_master_files(root)
    return root


def master_path(name):
    return os.path.join(ensure_data_folders(), "Master", name)


def ensure_master_files(root):
    master = os.path.join(root, "Master")
    files = {
        "SN_Master.xlsx": ["SN", "Hospital", "System", "Install Date", "Last Update", "Comment"],
        "Hospital_Master.xlsx": ["Hospital", "Country", "Region", "Installation Date", "Data Coverage Note", "Comment"],
        "Replacement_History.xlsx": ["SN", "Hospital", "Replacement Date", "Replacement Type", "Part", "Reason", "Engineer", "Comment"],
        "Forecast_Master.xlsx": ["Calc Date", "SN", "Hospital", "Forecast Mode", "Forecast Scope", "Installation Date", "Last Replacement Date", "Data Start Date", "Data End Date", "Data Coverage Status", "Used Data Count", "Excluded Data Count", "Forecast Date", "Remaining Days", "Confidence", "Algorithm Version"],
        "Outlier_Master.xlsx": ["SN", "Date", "File", "Item", "Value", "Reason", "User", "Date Removed", "Use for Forecast"],
        "Ignore_Period.xlsx": ["SN", "Start Date", "End Date", "Reason", "User", "Created Date"],
    }
    for name, headers in files.items():
        p = os.path.join(master, name)
        if not os.path.exists(p):
            wb = Workbook()
            ws = wb.active
            ws.title = os.path.splitext(name)[0]
            for c, h in enumerate(headers, 1):
                ws.cell(1, c, h).font = Font(bold=True)
            wb.save(p)
        else:
            ensure_headers(p, headers)


def ensure_headers(path, required_headers):
    try:
        wb = load_workbook(path)
        ws = wb.active
        existing = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
        changed = False
        for h in required_headers:
            if h not in existing:
                ws.cell(1, ws.max_column + 1, h).font = Font(bold=True)
                existing.append(h)
                changed = True
        if changed:
            wb.save(path)
    except Exception:
        pass


def read_master_rows(path):
    if not path or not os.path.exists(path):
        return []
    wb = load_workbook(path, data_only=True, read_only=True)
    ws = wb.active
    headers = [ws.cell(1, c).value or "" for c in range(1, ws.max_column + 1)]
    rows = []
    for r in range(2, ws.max_row + 1):
        row = {}
        has_value = False
        for c, h in enumerate(headers, 1):
            if h:
                v = ws.cell(r, c).value
                row[h] = v
                if v not in ("", None):
                    has_value = True
        if has_value:
            rows.append(row)
    return rows


def get_hospital_for_sn(sn):
    for r in read_master_rows(master_path("SN_Master.xlsx")):
        if str(r.get("SN", "")).strip() == str(sn):
            return str(r.get("Hospital", "") or "").strip()
    return ""


def get_installation_date_for_site(sn, hospital=""):
    """
    Priority:
      1) SN_Master.Install Date for the specific SN
      2) Hospital_Master.Installation Date for the hospital/site
      3) None
    """
    for r in read_master_rows(master_path("SN_Master.xlsx")):
        if str(r.get("SN", "")).strip() == str(sn):
            d = coerce_datetime(r.get("Install Date"))
            if d:
                return d

    hospital = hospital or get_hospital_for_sn(sn)
    if hospital:
        for r in read_master_rows(master_path("Hospital_Master.xlsx")):
            if str(r.get("Hospital", "")).strip() == str(hospital):
                d = coerce_datetime(r.get("Installation Date"))
                if d:
                    return d
    return None


def data_coverage_status(installation_date, last_replacement_date, data_start_date):
    if not data_start_date:
        return "No data"

    base_date = last_replacement_date or installation_date

    if not base_date:
        return "Unknown installation/replacement"

    gap_days = (data_start_date - base_date).days

    if gap_days <= 7:
        return "Full from install/replacement"

    return "Left-censored: no older data before first log (%d days missing)" % gap_days


def forecast_data_start_date(sn, hospital, mode, data_start_date):
    """
    Forecast should start from the later of:
      - last replacement date for the selected mode
      - installation date
      - first available data date

    This handles sites where there is no data before the first log.
    """
    install_date = get_installation_date_for_site(sn, hospital)
    last_rep = None
    if "get_last_replacement_date" in globals():
        try:
            last_rep = get_last_replacement_date(sn, mode)
        except Exception:
            last_rep = None

    candidates = [d for d in [install_date, last_rep, data_start_date] if d]
    return max(candidates) if candidates else data_start_date



def is_clean_state(s):
    return str(s).upper() in ("CLEAN_TANK_CIRCULATE", "CLEAN_XD_CIRCULATE")


def parse_watersystem_log(path):
    treat = degas = tank = xd = dpause = tpause = errtime = 0.0
    clean_count = 0
    clean_active = False
    clean_context = ""

    start = last = end = None
    prev_state = ""
    prev_err = ""

    sensors = {
        "Primary Flow": [0.0, 0],
        "Chiller Temp": [0.0, 0],
        "Absolute Pressure": [0.0, 0],
        "Dynamic Pressure": [0.0, 0],
    }

    raw = open(path, "rb").read()
    lines = []
    for enc in ("utf-8-sig", "cp932", "latin-1"):
        try:
            lines = raw.decode(enc, errors="replace").splitlines()
            break
        except Exception:
            pass

    for line in lines:
        cur = parse_time_seconds(line)
        if cur is None:
            continue

        state = get_token(line, 1).upper()
        er = get_token(line, 3).upper()

        if start is None:
            start = cur
        elif last is not None:
            diff = cur - last
            if diff < 0:
                diff = diff + 86400 if last > 86300 and cur < 300 else 0

            if prev_state == "TREAT_CIRCULATE":
                treat += diff
            elif prev_state == "DEGAS_CIRCULATE":
                degas += diff
            elif prev_state == "CLEAN_TANK_CIRCULATE":
                tank += diff
            elif prev_state == "CLEAN_XD_CIRCULATE":
                xd += diff
            elif prev_state == "DEGAS_PAUSE":
                dpause += diff
            elif prev_state == "TREAT_PAUSE":
                tpause += diff

            if prev_err and prev_err != "NO_ERROR":
                errtime += diff

            if clean_context and not is_clean_state(prev_state):
                if clean_context == "CLEAN_TANK_CIRCULATE":
                    tank += diff
                elif clean_context == "CLEAN_XD_CIRCULATE":
                    xd += diff

        if "DRAIN" in state:
            clean_active = False
            clean_context = ""
        elif is_clean_state(state):
            if not clean_active:
                clean_count += 1
                clean_active = True
            clean_context = state

        for label, keys in {
            "Primary Flow": ["PrimaryFlow", "Primary Flow", "PrimaryFlowMeter"],
            "Chiller Temp": ["ChillerTemp", "Chiller Temp"],
            "Absolute Pressure": ["AbsolutePressure", "Absolute Pressure"],
            "Dynamic Pressure": ["DynamicPressure", "Dynamic Pressure"],
        }.items():
            for k in keys:
                m = re.search(re.escape(k) + r"\s*[:=]?\s*(-?\d+(?:\.\d+)?)", line, re.I)
                if m:
                    sensors[label][0] += float(m.group(1))
                    sensors[label][1] += 1
                    break

        last = end = cur
        prev_state = state
        prev_err = er

    if start is None:
        return None

    runtime = (end or 0) - start
    if runtime < 0:
        runtime += 86400

    if clean_count == 0 and (tank + xd) > 0:
        clean_count = 1

    h = file_crc32_hex(path)
    size = os.path.getsize(path)

    def avg(label):
        total, cnt = sensors[label]
        return total / cnt if cnt else ""

    return {
        "File Name": os.path.basename(path),
        "Start Datetime (YYYY-MM-DD HH:MM)": build_file_datetime_text(path),
        "TREAT_CIRCULATE (HH:MM:SS)": seconds_to_hms(treat),
        "DEGAS_CIRCULATE (HH:MM:SS)": seconds_to_hms(degas),
        "CLEAN_TANK_CIRCULATE (HH:MM:SS)": seconds_to_hms(tank),
        "CLEAN_XD_CIRCULATE (HH:MM:SS)": seconds_to_hms(xd),
        "Total File Runtime (HH:MM:SS)": seconds_to_hms(runtime),
        "Total File Runtime (Seconds)": runtime,
        "Total Circulate Time (Seconds)": treat + degas + tank + xd,
        "DEGAS_PAUSE (HH:MM:SS)": seconds_to_hms(dpause),
        "TREAT_PAUSE (HH:MM:SS)": seconds_to_hms(tpause),
        "ERROR (HH:MM:SS)": seconds_to_hms(errtime),
        "Clean Count": clean_count,
        "Primary Flow": avg("Primary Flow"),
        "Chiller Temp": avg("Chiller Temp"),
        "Absolute Pressure": avg("Absolute Pressure"),
        "Dynamic Pressure": avg("Dynamic Pressure"),
        "File CRC32": h,
        "File Size": size,
    }


def find_latest_result_summary(folder):
    files = glob.glob(os.path.join(folder, "ResultSummary*.xlsx"))
    return sorted(files, key=os.path.getmtime, reverse=True)[0] if files else None


def read_existing_rows(path, progress=None, cancel=None):
    rows = []
    keys = set()

    if not path or not os.path.exists(path):
        return rows, keys

    wb = load_workbook(path, data_only=True, read_only=True)
    if "Result" not in wb.sheetnames:
        return rows, keys

    ws = wb["Result"]
    header_row = next(ws.iter_rows(min_row=1, max_row=1, values_only=True), [])
    headers = [h or "" for h in header_row]
    max_row = ws.max_row or 1

    for idx, values in enumerate(ws.iter_rows(min_row=2, values_only=True), 2):
        if cancel and cancel():
            break
        if not values or not values[0]:
            continue

        row = {}
        for i, h in enumerate(headers):
            if h and i < len(values):
                row[h] = values[i]

        row["Start Datetime (YYYY-MM-DD HH:MM)"] = coerce_datetime(row.get("Start Datetime (YYYY-MM-DD HH:MM)"))
        rows.append(row)

        keys.add(result_key(row.get("File Name", ""), row.get("Start Datetime (YYYY-MM-DD HH:MM)")))
        if row.get("File Name"):
            keys.add(name_key(row.get("File Name")))
        ck = content_key(row.get("File CRC32"), row.get("File Size"))
        if ck:
            keys.add(ck)

        if progress and (idx == 2 or idx % 250 == 0 or idx == max_row):
            try:
                progress(idx, max_row, "Reading existing ResultSummary rows")
            except Exception:
                pass

    try:
        wb.close()
    except Exception:
        pass
    return rows, keys



def read_chart_summary_direct(path):
    """
    Load chart data directly from Daily_Summary when available.
    This fixes cases where ResultSummary exists but the Result sheet cannot be
    rebuilt into chart rows because date/time column names differ.
    """
    if not path or not os.path.exists(path):
        return []

    wb = load_workbook(path, data_only=True, read_only=True)

    target_sheet = None
    for name in ["Daily_Summary", "Daily Summary", "Summary", "Chart_Data", "Chart Data"]:
        if name in wb.sheetnames:
            target_sheet = wb[name]
            break

    if target_sheet is None:
        return []

    ws = target_sheet
    headers = [str(ws.cell(1, c).value or "").strip() for c in range(1, ws.max_column + 1)]
    header_map = {h.lower(): i + 1 for i, h in enumerate(headers) if h}

    def get_cell(row, names):
        for n in names:
            c = header_map.get(n.lower())
            if c:
                return ws.cell(row, c).value
        return None

    def num(v):
        try:
            if v in ("", None):
                return 0.0
            return float(v)
        except Exception:
            return 0.0

    out = []
    for r in range(2, ws.max_row + 1):
        raw_dt = get_cell(r, ["DateTime", "Date Time", "Start Datetime (YYYY-MM-DD HH:MM)", "Start Datetime", "Datetime"])
        d = coerce_datetime(raw_dt)
        if not d:
            # Try date + time split columns.
            raw_date = get_cell(r, ["Date", "Start Date"])
            raw_time = get_cell(r, ["Time", "Start Time"])
            dd = coerce_datetime(raw_date)
            if dd and raw_time not in ("", None):
                try:
                    if isinstance(raw_time, dt.time):
                        d = dt.datetime.combine(dd.date(), raw_time)
                    else:
                        ts = str(raw_time).strip()
                        for fmt in ["%H:%M:%S", "%H:%M"]:
                            try:
                                tt = dt.datetime.strptime(ts, fmt).time()
                                d = dt.datetime.combine(dd.date(), tt)
                                break
                            except Exception:
                                pass
                except Exception:
                    d = dd
            else:
                d = dd

        if not d:
            continue

        row = {"DateTime": d}
        for key in [
            "Treat", "Degas", "Clean", "Runtime",
            "DEGAS_PAUSE", "TREAT_PAUSE", "ERROR",
            "Treat Cum", "Degas Cum", "Clean Cum", "Runtime Cum",
            "DEGAS_PAUSE Cum", "TREAT_PAUSE Cum", "ERROR Cum",
        ]:
            row[key] = num(get_cell(r, [key, key.replace(" ", ""), key.replace("_", " ")]))
        out.append(row)

    return out


def collect_files(folder, progress=None, cancel=None):
    files = []
    scanned = 0
    errors = []
    for root, dirs, names in os.walk(folder):
        if cancel and cancel():
            break
        dirs[:] = [d for d in dirs if d.lower() not in ("$recycle.bin", "system volume information", "__pycache__")]
        for name in names:
            if cancel and cancel():
                break
            scanned += 1
            p = os.path.join(root, name)
            try:
                if is_watersystem_file(p):
                    files.append(p)
            except Exception as e:
                if len(errors) < 20:
                    errors.append("%s : %s" % (p, e))
            if progress and scanned % 100 == 0:
                progress(scanned, os.path.basename(root))
    files.sort(key=lambda p: (build_file_datetime_text(os.path.basename(p)) or dt.datetime.min, p.lower()))
    collect_files.last_scan = {"scanned": scanned, "matched": len(files), "errors": errors, "first_files": files[:10]}
    return files


def build_summary_rows(rows):
    """
    Build chart rows from Result rows.

    ChartDataFix:
    - If Start Datetime is missing, fallback to File Name date parsing.
    - If Total File Runtime (Seconds) is missing, fallback to HH:MM:SS.
    - This prevents a blank chart when Result rows exist but Daily_Summary rows were not generated.
    """
    out = []
    cum = dict((k, 0.0) for k in ["Treat", "Degas", "Clean", "Runtime", "DEGAS_PAUSE", "TREAT_PAUSE", "ERROR"])

    def get_dt(r):
        xdt = coerce_datetime(r.get("Start Datetime (YYYY-MM-DD HH:MM)"))
        if xdt:
            return xdt
        fn = r.get("File Name", "")
        if fn:
            return build_file_datetime_text(fn)
        return None

    def runtime_hours(r):
        try:
            sec = float(r.get("Total File Runtime (Seconds)") or 0)
            if sec > 0:
                return sec / 3600.0
        except Exception:
            pass
        return hms_to_seconds(r.get("Total File Runtime (HH:MM:SS)")) / 3600.0

    sorted_rows = []
    for r in rows:
        xdt = get_dt(r)
        if xdt:
            sorted_rows.append((xdt, r))
    sorted_rows.sort(key=lambda x: x[0])

    for xdt, r in sorted_rows:
        vals = {
            "Treat": hms_to_seconds(r.get("TREAT_CIRCULATE (HH:MM:SS)")) / 3600.0,
            "Degas": hms_to_seconds(r.get("DEGAS_CIRCULATE (HH:MM:SS)")) / 3600.0,
            "Clean": (hms_to_seconds(r.get("CLEAN_TANK_CIRCULATE (HH:MM:SS)")) +
                      hms_to_seconds(r.get("CLEAN_XD_CIRCULATE (HH:MM:SS)"))) / 3600.0,
            "Runtime": runtime_hours(r),
            "DEGAS_PAUSE": hms_to_seconds(r.get("DEGAS_PAUSE (HH:MM:SS)")) / 3600.0,
            "TREAT_PAUSE": hms_to_seconds(r.get("TREAT_PAUSE (HH:MM:SS)")) / 3600.0,
            "ERROR": hms_to_seconds(r.get("ERROR (HH:MM:SS)")) / 3600.0,
        }

        for k, v in vals.items():
            cum[k] += v

        row = {"DateTime": xdt}
        row.update(vals)
        row.update({
            "Treat Cum": cum["Treat"],
            "Degas Cum": cum["Degas"],
            "Clean Cum": cum["Clean"],
            "Runtime Cum": cum["Runtime"],
            "DEGAS_PAUSE Cum": cum["DEGAS_PAUSE"],
            "TREAT_PAUSE Cum": cum["TREAT_PAUSE"],
            "ERROR Cum": cum["ERROR"],
        })
        out.append(row)

    return out


def write_resultsummary_workbook(path, rows, summary_rows):
    wb = Workbook()
    wb.remove(wb.active)

    ws = wb.create_sheet("Result")
    for c, h in enumerate(RESULT_HEADERS, 1):
        cell = ws.cell(1, c, h)
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="D9EAF7")
        cell.alignment = Alignment(horizontal="center")

    for rr, row in enumerate(rows, 2):
        for c, h in enumerate(RESULT_HEADERS, 1):
            ws.cell(rr, c, row.get(h, ""))

    ws.column_dimensions["R"].hidden = True
    ws.column_dimensions["S"].hidden = True
    ws.freeze_panes = "A2"

    for col in range(1, len(RESULT_HEADERS) + 1):
        letter = get_column_letter(col)
        if letter in ("R", "S"):
            continue
        ws.column_dimensions[letter].width = min(max(len(str(RESULT_HEADERS[col - 1])) + 2, 12), 34)

    sw = wb.create_sheet("Daily_Summary")
    if summary_rows:
        headers = list(summary_rows[0].keys())
        for c, h in enumerate(headers, 1):
            sw.cell(1, c, h).font = Font(bold=True)
        for rr, row in enumerate(summary_rows, 2):
            for c, h in enumerate(headers, 1):
                sw.cell(rr, c, row[h])
        sw.freeze_panes = "A2"

    wb.save(path)


def save_or_update_resultsummary(folder, selected_path, rows, summary_rows, serial_number):
    """
    If selected_path exists, update that file.
    If serial_number implies a different file name, save to the new name and remove the old selected file.
    Return the final path.
    """
    final_path = selected_path

    if selected_path:
        current_folder = os.path.dirname(selected_path)
        target_path = result_summary_path_for_sn(current_folder, serial_number)
        if os.path.abspath(target_path).lower() != os.path.abspath(selected_path).lower():
            final_path = target_path
        else:
            final_path = selected_path
    else:
        final_path = result_summary_path_for_sn(folder, serial_number)
        if os.path.exists(final_path):
            final_path = os.path.join(folder, "ResultSummary_%s_%s.xlsx" % (
                safe_sn(serial_number), dt.datetime.now().strftime("%Y%m%d_%H%M%S")))

    # Step2: backup existing ResultSummary before overwrite.
    try:
        if final_path and os.path.exists(final_path):
            backup_dir = os.path.join(os.path.dirname(final_path), "ResultSummary_Backup")
            os.makedirs(backup_dir, exist_ok=True)
            backup_path = os.path.join(
                backup_dir,
                os.path.splitext(os.path.basename(final_path))[0] + "_backup_" + dt.datetime.now().strftime("%Y%m%d_%H%M%S") + ".xlsx"
            )
            shutil.copy2(final_path, backup_path)
    except Exception:
        pass

    write_resultsummary_workbook(final_path, rows, summary_rows)

    if selected_path and os.path.exists(selected_path):
        if os.path.abspath(final_path).lower() != os.path.abspath(selected_path).lower():
            try:
                os.remove(selected_path)
            except Exception:
                pass

    return final_path


def calculate_forecast(summary_rows, sn, mode="Failure only", scope="Current SN", selected_hospitals=None):
    hospital = get_hospital_for_sn(sn)
    dates = [coerce_datetime(r.get("DateTime")) for r in summary_rows if coerce_datetime(r.get("DateTime"))]
    raw_start = min(dates) if dates else None
    raw_end = max(dates) if dates else None
    install = get_installation_date_for_site(sn, hospital)
    last_rep = None
    effective_start = forecast_data_start_date(sn, hospital, mode, raw_start)
    coverage = data_coverage_status(install, last_rep, raw_start)
    usable = [r for r in summary_rows if coerce_datetime(r.get("DateTime")) and (not effective_start or coerce_datetime(r.get("DateTime")) >= effective_start)]
    conf = min(90, max(0, len(usable) * 5))
    if "Left-censored" in coverage:
        conf = max(0, conf - 10)
    return {"hospital": hospital, "installation_date": install, "last_replacement": last_rep, "data_start": effective_start, "data_end": raw_end, "coverage_status": coverage, "used": len(usable), "excluded": len(summary_rows)-len(usable), "confidence": conf, "remaining_days": "", "forecast_date": ""}


def append_forecast_master(sn, summary_rows, mode="Failure only", scope="Current SN", selected_hospitals=None):
    return calculate_forecast(summary_rows, sn, mode, scope, selected_hospitals)


class NativeChartView(QGraphicsView):
    """
    Ver40.4 chart logic, rendered with pure Qt.
    No matplotlib / numpy / pandas.
    """

    DAILY_SERIES = ["Treat", "Degas", "Clean", "Runtime", "DEGAS_PAUSE", "TREAT_PAUSE", "ERROR"]
    CUM_SERIES = ["Treat Cum", "Degas Cum", "Clean Cum", "Runtime Cum", "DEGAS_PAUSE Cum", "TREAT_PAUSE Cum", "ERROR Cum"]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.scene_obj = QGraphicsScene(self)
        self.setScene(self.scene_obj)
        self.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        self.setMinimumSize(760, 520)
        self.summary_rows = []
        self.checks = {}
        self.x0 = None
        self.x1 = None
        self.c0 = None
        self.c1 = None
        self.last_status = ""
        self.manual_x0 = None
        self.manual_x1 = None
        self.current_x0 = None
        self.current_x1 = None
        self.plot_left = 0
        self.plot_top = 0
        self.plot_pw = 1
        self.plot_ph = 1
        self.drag_start = None
        self.drag_item = None
        self.pan_start = None
        self.pan_x0 = None
        self.pan_x1 = None
        self.setMouseTracking(True)
        self.tooltip_item = None
        self.tooltip_bg = None
        self.crosshair_v = None
        self.crosshair_h = None
        self.tooltip_mode = "Point"
        self.last_plot_rows = []
        self.last_active_daily = []
        self.last_active_cum = []
        self.last_cum_values = {}

    def set_data(self, summary_rows, checks, x0, x1, c0, c1):
        self.summary_rows = summary_rows or []
        self.checks = checks or {}
        self.x0 = x0
        self.x1 = x1
        # Keep manual zoom across checkbox/series redraws. Reset is done by double-click.
        self.c0 = c0
        self.c1 = c1
        QtCore.QTimer.singleShot(0, self.redraw)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        QtCore.QTimer.singleShot(0, self.redraw)

    def f(self, value):
        try:
            if value in ("", None):
                return 0.0
            return float(value)
        except Exception:
            return 0.0

    def txt(self, x, y, s, size=9, bold=False, center=False, rotate=0):
        item = self.scene_obj.addText(str(s))
        font = QtGui.QFont()
        font.setPointSize(size)
        font.setBold(bold)
        item.setFont(font)
        item.setDefaultTextColor(QtGui.QColor(40, 40, 40))
        br = item.boundingRect()
        if center:
            item.setPos(x - br.width()/2, y - br.height()/2)
        else:
            item.setPos(x, y - br.height()/2)
        if rotate:
            item.setTransformOriginPoint(br.width()/2, br.height()/2)
            item.setRotation(rotate)

    def message(self, s):
        self.scene_obj.clear()
        w = max(700, self.viewport().width() - 8)
        h = max(480, self.viewport().height() - 8)
        self.scene_obj.setSceneRect(0, 0, w, h)
        self.txt(w/2, h/2 - 18, s, 12, True, True)
        self.txt(w/2, h/2 + 14, "Rows=%d" % len(self.summary_rows), 9, False, True)
        self.last_status = s

    def axis_ranges_for_visible(self, plot_rows, visible_rows, active_daily, active_cum, cum_values):
        """
        Version 7.1a axis rule:
        - Left axis is Daily/bar series. If any daily series is visible, left Y minimum is fixed at 0.
        - Right axis is Cumulative series. It floats independently to the visible cumulative range.
        - If only cumulative is visible, only the right scale matters and it floats.
        """
        daily_vals = []
        for r in plot_rows:
            for n in active_daily:
                daily_vals.append(self.f(r.get(n, 0.0)))
        if daily_vals:
            daily_max = max(daily_vals + [1.0])
            daily_min = 0.0
            daily_max = daily_max * 1.10
        else:
            daily_min, daily_max = 0.0, 1.0

        cum_vals = []
        for n in active_cum:
            cum_vals.extend([self.f(v) for v in cum_values.get(n, {}).values()])
        if cum_vals:
            cum_min = min(cum_vals)
            cum_max = max(cum_vals)
            if cum_min == cum_max:
                margin = max(1.0, abs(cum_max) * 0.05)
            else:
                margin = (cum_max - cum_min) * 0.08
            cum_min -= margin
            cum_max += margin
        else:
            cum_min, cum_max = 0.0, 1.0

        return daily_min, daily_max, cum_min, cum_max

    def redraw(self):
        self.scene_obj.clear()
        w = max(700, self.viewport().width() - 8)
        h = max(480, self.viewport().height() - 8)
        self.scene_obj.setSceneRect(0, 0, w, h)

        if not self.summary_rows:
            self.message("No chart data loaded")
            return

        all_x = [r.get("DateTime") for r in self.summary_rows if isinstance(r.get("DateTime"), dt.datetime)]
        if not all_x:
            self.message("No DateTime data for chart")
            return

        x0 = self.manual_x0 or self.x0 or min(all_x)
        x1 = self.manual_x1 or self.x1 or max(all_x)
        if x1 <= x0:
            x0, x1 = min(all_x), max(all_x)

        visible_rows = [r for r in self.summary_rows if isinstance(r.get("DateTime"), dt.datetime) and x0 <= r["DateTime"] <= x1]
        if not visible_rows:
            self.message("No data in X Start/End range")
            return

        active_daily = [n for n in self.DAILY_SERIES if self.checks.get(n, False)]
        active_cum = [n for n in self.CUM_SERIES if self.checks.get(n, False)]
        self.last_active_daily = active_daily
        self.last_active_cum = active_cum

        if not active_daily and not active_cum:
            self.message("All chart series are OFF")
            return

        # Downsample for UI performance only. Cumulative base still uses all rows.
        if len(visible_rows) > 180:
            step = max(1, len(visible_rows) // 180)
            plot_rows = visible_rows[::step]
            if visible_rows[-1] not in plot_rows:
                plot_rows.append(visible_rows[-1])
        else:
            plot_rows = visible_rows
        self.last_plot_rows = plot_rows

        left, right, top, bottom = 88, 82, 42, 96
        pw = max(100, w - left - right)
        ph = max(100, h - top - bottom)
        self.current_x0 = x0
        self.current_x1 = x1
        self.plot_left = left
        self.plot_top = top
        self.plot_pw = pw
        self.plot_ph = ph

        axis_pen = QtGui.QPen(QtGui.QColor(45,45,45), 1.2)
        grid_pen = QtGui.QPen(QtGui.QColor(225,225,225), 1)
        self.scene_obj.addLine(left, top, left, top+ph, axis_pen)
        self.scene_obj.addLine(left, top+ph, left+pw, top+ph, axis_pen)
        self.scene_obj.addLine(left+pw, top, left+pw, top+ph, axis_pen)
        for i in range(1,5):
            y = top + ph*i/5
            self.scene_obj.addLine(left, y, left+pw, y, grid_pen)

        # Version 7.0: build cumulative values and calculate visible Y axis.
        cum_values = {}
        for n in active_cum:
            vals = []
            running = 0.0
            for r in visible_rows:
                running += self.f(r.get(n.replace(" Cum", ""), 0.0))
                vals.append((r["DateTime"], running))
            cum_values[n] = {d: v for d, v in vals}

        daily_min, daily_max, cum_min, cum_max = self.axis_ranges_for_visible(plot_rows, visible_rows, active_daily, active_cum, cum_values)
        self.last_cum_values = cum_values

        for i in range(6):
            y = top + ph - ph*i/5
            daily_val = daily_min + (daily_max - daily_min) * i / 5.0
            cum_val = cum_min + (cum_max - cum_min) * i / 5.0
            self.txt(left-25, y, "%.1f" % daily_val, 8, False, True)
            self.txt(left+pw+30, y, "%.1f" % cum_val, 8, False, True)
            x = left + pw*i/5
            d = x0 + (x1-x0)*(i/5)
            self.txt(x, top+ph+26, d.strftime("%Y/%m/%d"), 8, False, True, -35)

        self.txt(16, top+ph/2, "Daily Hours", 9, False, True, -90)
        self.txt(left+pw+56, top+ph/2, "Cumulative Hours", 9, False, True, 90)

        span = max(1.0, (x1-x0).total_seconds())
        def xp(x):
            return left + ((x-x0).total_seconds()/span)*pw
        def yd(v):
            return top + ph - ((v - daily_min) / max(0.000001, (daily_max - daily_min))) * ph
        def yc(v):
            return top + ph - ((v - cum_min) / max(0.000001, (cum_max - cum_min))) * ph

        bar_colors = [
            QtGui.QColor(70,130,180,170), QtGui.QColor(240,128,128,170),
            QtGui.QColor(60,179,113,170), QtGui.QColor(186,85,211,170),
            QtGui.QColor(210,180,140,170), QtGui.QColor(255,165,0,170),
            QtGui.QColor(128,128,128,170)
        ]
        line_colors = [
            QtGui.QColor(31,119,180), QtGui.QColor(255,127,14),
            QtGui.QColor(44,160,44), QtGui.QColor(148,103,189),
            QtGui.QColor(140,86,75), QtGui.QColor(227,119,194),
            QtGui.QColor(90,90,90)
        ]

        group_w = max(6.0, min(36.0, pw / max(20, len(plot_rows)*1.4)))
        single_w = max(2.0, group_w / max(1, len(active_daily)))
        for r in plot_rows:
            x_center = xp(r["DateTime"])
            for idx, n in enumerate(active_daily):
                v = self.f(r.get(n, 0.0))
                if v <= 0:
                    continue
                x = x_center - group_w / 2 + idx * single_w
                y0 = yd(0.0)
                y1 = yd(v)
                rect = QtCore.QRectF(x, y1, max(1.0, single_w * 0.85), max(1.0, y0-y1))
                self.scene_obj.addRect(rect, QtGui.QPen(QtCore.Qt.PenStyle.NoPen), QtGui.QBrush(bar_colors[idx % len(bar_colors)]))

        for idx, n in enumerate(active_cum):
            vals = cum_values.get(n, {})
            pen = QtGui.QPen(line_colors[idx % len(line_colors)], 2)
            prev = None
            for r in plot_rows:
                x = r.get("DateTime")
                if x not in vals:
                    prev = None
                    continue
                pt = QtCore.QPointF(xp(x), yc(vals[x]))
                self.scene_obj.addEllipse(pt.x()-2.4, pt.y()-2.4, 4.8, 4.8, pen, QtGui.QBrush(line_colors[idx % len(line_colors)]))
                if prev is not None:
                    self.scene_obj.addLine(prev.x(), prev.y(), pt.x(), pt.y(), pen)
                prev = pt

        lx = left
        ly = h - 34
        for idx, n in enumerate(active_daily[:4] + active_cum[:4]):
            if lx > w - 120:
                break
            color = bar_colors[idx % len(bar_colors)] if n in active_daily else line_colors[idx % len(line_colors)]
            self.scene_obj.addRect(lx, ly-6, 10, 10, QtGui.QPen(QtCore.Qt.PenStyle.NoPen), QtGui.QBrush(color))
            self.txt(lx+14, ly, n, 8, False, False)
            lx += min(140, 24 + len(n)*7)

        title = "WaterSystem Summary Chart  (rows=%d, visible=%d, plotted=%d)" % (len(self.summary_rows), len(visible_rows), len(plot_rows))
        if self.manual_x0 and self.manual_x1:
            title += "  [zoom: double-click to reset]"
        if daily_max <= 1.15 and cum_max <= 1.15:
            title += "  [all plotted values are zero/near zero]"
        self.txt(left+pw/2, 18, title, 13, True, True)
        self.last_status = title

    def set_tooltip_mode(self, mode):
        self.tooltip_mode = mode or "Point"
        self.hide_cursor_tooltip()

    def hide_cursor_tooltip(self):
        try:
            for attr in ["tooltip_item", "tooltip_bg", "crosshair_v", "crosshair_h"]:
                item = getattr(self, attr, None)
                if item:
                    self.scene_obj.removeItem(item)
                    setattr(self, attr, None)
        except Exception:
            self.tooltip_item = None
            self.tooltip_bg = None
            self.crosshair_v = None
            self.crosshair_h = None

    def draw_crosshair(self, scene_pos):
        try:
            for attr in ["crosshair_v", "crosshair_h"]:
                item = getattr(self, attr, None)
                if item:
                    self.scene_obj.removeItem(item)
                    setattr(self, attr, None)
            pen = QtGui.QPen(QtGui.QColor(80, 80, 80, 150), 1.0, QtCore.Qt.PenStyle.DashLine)
            self.crosshair_v = self.scene_obj.addLine(scene_pos.x(), self.plot_top, scene_pos.x(), self.plot_top + self.plot_ph, pen)
            self.crosshair_h = self.scene_obj.addLine(self.plot_left, scene_pos.y(), self.plot_left + self.plot_pw, scene_pos.y(), pen)
            self.crosshair_v.setZValue(9996)
            self.crosshair_h.setZValue(9996)
        except Exception:
            pass

    def show_cursor_tooltip(self, scene_pos):
        try:
            if self.tooltip_mode == "Off":
                self.hide_cursor_tooltip()
                return
            if self.drag_start is not None or self.pan_start is not None or not self.in_plot_area(scene_pos) or not self.last_plot_rows:
                self.hide_cursor_tooltip()
                return
            self.draw_crosshair(scene_pos)

            target_dt = self.scene_x_to_datetime(scene_pos.x())
            if not target_dt:
                self.hide_cursor_tooltip()
                return
            nearest = min(self.last_plot_rows, key=lambda r: abs((r.get("DateTime") - target_dt).total_seconds()) if isinstance(r.get("DateTime"), dt.datetime) else 10**18)
            d = nearest.get("DateTime")
            if not isinstance(d, dt.datetime):
                self.hide_cursor_tooltip()
                return

            if self.tooltip_mode == "Crosshair":
                lines = [d.strftime("%Y/%m/%d %H:%M")]
                for n in self.last_active_daily:
                    lines.append("%s: %.2f" % (n, self.f(nearest.get(n, 0.0))))
                for n in self.last_active_cum:
                    vals = self.last_cum_values.get(n, {})
                    v = vals.get(d, None)
                    if v is not None:
                        lines.append("%s: %.2f" % (n, v))
                txt = "\n".join(lines[:20])
            else:
                candidates = []
                for n in self.last_active_daily:
                    v = self.f(nearest.get(n, 0.0))
                    if v != 0:
                        candidates.append((n, v))
                for n in self.last_active_cum:
                    vals = self.last_cum_values.get(n, {})
                    v = vals.get(d, None)
                    if v is not None:
                        candidates.append((n, v))
                if candidates:
                    n, v = candidates[0]
                    txt = "%s\n%s: %.2f" % (d.strftime("%Y/%m/%d %H:%M"), n, v)
                else:
                    txt = "%s\n(no visible value)" % d.strftime("%Y/%m/%d %H:%M")

            if self.tooltip_item:
                self.scene_obj.removeItem(self.tooltip_item)
                self.tooltip_item = None
            if self.tooltip_bg:
                self.scene_obj.removeItem(self.tooltip_bg)
                self.tooltip_bg = None

            self.tooltip_item = self.scene_obj.addText(txt)
            font = QtGui.QFont(); font.setPointSize(9)
            self.tooltip_item.setFont(font)
            self.tooltip_item.setDefaultTextColor(QtGui.QColor(30, 30, 30))
            br = self.tooltip_item.boundingRect()
            x, y = scene_pos.x() + 14, scene_pos.y() + 14
            scene_rect = self.scene_obj.sceneRect()
            if x + br.width() + 16 > scene_rect.right():
                x = scene_pos.x() - br.width() - 24
            if y + br.height() + 16 > scene_rect.bottom():
                y = scene_pos.y() - br.height() - 24
            x, y = max(6, x), max(6, y)
            self.tooltip_bg = self.scene_obj.addRect(QtCore.QRectF(x - 6, y - 4, br.width() + 12, br.height() + 8), QtGui.QPen(QtGui.QColor(110,110,110)), QtGui.QBrush(QtGui.QColor(255,255,230,235)))
            self.tooltip_bg.setZValue(9998)
            self.tooltip_item.setZValue(9999)
            self.tooltip_item.setPos(x, y)
        except Exception:
            self.hide_cursor_tooltip()

    def in_plot_area(self, p):
        return (self.plot_left <= p.x() <= self.plot_left + self.plot_pw and
                self.plot_top <= p.y() <= self.plot_top + self.plot_ph)

    def scene_x_to_datetime(self, sx):
        if not self.current_x0 or not self.current_x1:
            return None
        ratio = (sx - self.plot_left) / float(max(1, self.plot_pw))
        ratio = max(0.0, min(1.0, ratio))
        span = (self.current_x1 - self.current_x0).total_seconds()
        return self.current_x0 + dt.timedelta(seconds=span * ratio)

    def mouseDoubleClickEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.hide_cursor_tooltip()
            self.manual_x0 = None
            self.manual_x1 = None
            self.redraw()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def mousePressEvent(self, event):
        p = self.mapToScene(event.position().toPoint())
        self.hide_cursor_tooltip()
        if event.button() == QtCore.Qt.MouseButton.LeftButton and self.in_plot_area(p):
            self.drag_start = p
            if self.drag_item:
                self.scene_obj.removeItem(self.drag_item)
                self.drag_item = None
            event.accept()
            return
        if event.button() == QtCore.Qt.MouseButton.RightButton and self.in_plot_area(p):
            self.pan_start = p
            self.pan_x0 = self.current_x0
            self.pan_x1 = self.current_x1
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        p = self.mapToScene(event.position().toPoint())
        if self.drag_start is not None:
            x0 = max(self.plot_left, min(self.drag_start.x(), p.x()))
            x1 = min(self.plot_left + self.plot_pw, max(self.drag_start.x(), p.x()))
            y0 = self.plot_top
            rect = QtCore.QRectF(x0, y0, max(1, x1-x0), self.plot_ph)
            if self.drag_item:
                self.scene_obj.removeItem(self.drag_item)
            pen = QtGui.QPen(QtGui.QColor(30, 120, 220), 1.5, QtCore.Qt.PenStyle.DashLine)
            brush = QtGui.QBrush(QtGui.QColor(30, 120, 220, 35))
            self.drag_item = self.scene_obj.addRect(rect, pen, brush)
            event.accept()
            return
        if self.pan_start is not None and self.pan_x0 and self.pan_x1:
            dx = p.x() - self.pan_start.x()
            span_sec = (self.pan_x1 - self.pan_x0).total_seconds()
            shift_sec = -dx / float(max(1, self.plot_pw)) * span_sec
            self.manual_x0 = self.pan_x0 + dt.timedelta(seconds=shift_sec)
            self.manual_x1 = self.pan_x1 + dt.timedelta(seconds=shift_sec)
            self.redraw()
            event.accept()
            return
        if self.drag_start is None and self.pan_start is None:
            self.show_cursor_tooltip(p)
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton and self.drag_start is not None:
            p = self.mapToScene(event.position().toPoint())
            x0 = max(self.plot_left, min(self.drag_start.x(), p.x()))
            x1 = min(self.plot_left + self.plot_pw, max(self.drag_start.x(), p.x()))
            if self.drag_item:
                self.scene_obj.removeItem(self.drag_item)
                self.drag_item = None
            self.drag_start = None
            if abs(x1 - x0) > 10:
                d0 = self.scene_x_to_datetime(x0)
                d1 = self.scene_x_to_datetime(x1)
                if d0 and d1 and d1 > d0:
                    self.manual_x0 = d0
                    self.manual_x1 = d1
                    self.redraw()
            event.accept()
            return
        if event.button() == QtCore.Qt.MouseButton.RightButton and self.pan_start is not None:
            self.pan_start = None
            self.pan_x0 = None
            self.pan_x1 = None
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def wheelEvent(self, event):
        p = self.mapToScene(event.position().toPoint())
        if not self.in_plot_area(p) or not self.current_x0 or not self.current_x1:
            super().wheelEvent(event)
            return
        center = self.scene_x_to_datetime(p.x())
        if not center:
            super().wheelEvent(event)
            return

        factor = 0.80 if event.angleDelta().y() > 0 else 1.25
        span = max(60.0, (self.current_x1 - self.current_x0).total_seconds() * factor)
        left_sec = (center - self.current_x0).total_seconds()
        old_span = max(1.0, (self.current_x1 - self.current_x0).total_seconds())
        ratio = left_sec / old_span
        new_left = center - dt.timedelta(seconds=span * ratio)
        new_right = new_left + dt.timedelta(seconds=span)
        self.manual_x0 = new_left
        self.manual_x1 = new_right
        self.redraw()
        event.accept()


class AnalyzeWorker(QtCore.QThread):
    progress = QtCore.Signal(int, int, str, int, int, str, float)
    finished_ok = QtCore.Signal(list, list, int, int)
    failed = QtCore.Signal(str)

    def __init__(self, folder, result_file="", use_existing_result=False, parent=None):
        super(AnalyzeWorker, self).__init__(parent)
        self.folder = folder
        self.result_file = result_file
        self.use_existing_result = use_existing_result
        self.cancel_requested = False
        self.t0 = 0

    def cancel(self):
        self.cancel_requested = True

    def emit_progress(self, cur, total, name, added, skipped, stage):
        self.progress.emit(cur, total, name, added, skipped, stage, time.time() - self.t0)

    def run(self):
        try:
            self.t0 = time.time()

            base_file = resolve_resultsummary_base_file(self.folder, self.result_file, self.use_existing_result)
            self.emit_progress(0, 100, os.path.basename(base_file or "(no existing ResultSummary)"), 0, 0, "Reading ResultSummary")
            def existing_progress(cur, total, stage):
                self.progress.emit(cur, total, os.path.basename(base_file or ""), 0, 0, stage, time.time() - self.t0)
            rows, keys = read_existing_rows(base_file, progress=existing_progress, cancel=lambda: self.cancel_requested)

            if self.cancel_requested:
                self.finished_ok.emit(rows, build_summary_rows(rows), 0, 0)
                return

            def scan_progress(scanned, curdir):
                self.progress.emit(0, 0, curdir, 0, 0, "Searching files: %d scanned" % scanned, time.time() - self.t0)

            files = collect_files(self.folder, progress=scan_progress, cancel=lambda: self.cancel_requested)
            total = len(files)
            added = 0
            skipped = 0
            parse_fail = 0
            duplicate = 0
            errors = []
            self.debug_info = {
                "mode": resultsummary_mode_text(self.result_file, self.use_existing_result),
                "base_file": base_file,
                "scanned": getattr(collect_files, "last_scan", {}).get("scanned", 0),
                "matched": total,
                "first_files": files[:10],
                "parse_fail": 0,
                "duplicate": 0,
                "errors": [],
            }

            self.emit_progress(0, total, "Matched files: %d" % total, added, skipped, "File scan complete")

            for i, p in enumerate(files, 1):
                if self.cancel_requested:
                    break

                name = os.path.basename(p)
                self.emit_progress(i, total, name, added, skipped, "Reading file %d/%d" % (i, total))

                try:
                    dtv = build_file_datetime_text(p)
                    size = os.path.getsize(p)

                    if name_key(name) in keys or result_key(name, dtv) in keys:
                        skipped += 1
                        duplicate += 1
                        continue

                    h = file_crc32_hex(p)
                    ck = content_key(h, size)
                    if ck in keys:
                        skipped += 1
                        duplicate += 1
                        continue

                    parsed = parse_watersystem_log(p)
                    if parsed:
                        rows.append(parsed)
                        keys.add(content_key(parsed["File CRC32"], parsed["File Size"]))
                        keys.add(result_key(parsed["File Name"], parsed["Start Datetime (YYYY-MM-DD HH:MM)"]))
                        keys.add(name_key(parsed["File Name"]))
                        added += 1
                    else:
                        skipped += 1
                        parse_fail += 1
                        if len(errors) < 20:
                            errors.append("Parse returned no data: %s" % p)
                except Exception as e:
                    skipped += 1
                    parse_fail += 1
                    if len(errors) < 20:
                        errors.append("%s : %s" % (p, e))

                self.debug_info = {
                    "mode": resultsummary_mode_text(self.result_file, self.use_existing_result),
                    "base_file": base_file,
                    "scanned": getattr(collect_files, "last_scan", {}).get("scanned", 0),
                    "matched": total,
                    "first_files": files[:10],
                    "parse_fail": parse_fail,
                    "duplicate": duplicate,
                    "errors": errors,
                }
                self.emit_progress(i, total, name, added, skipped, "Analyzing file %d/%d" % (i, total))

            self.debug_info = {
                "mode": resultsummary_mode_text(self.result_file, self.use_existing_result),
                "base_file": base_file,
                "scanned": getattr(collect_files, "last_scan", {}).get("scanned", 0),
                "matched": total,
                "first_files": files[:10],
                "parse_fail": parse_fail,
                "duplicate": duplicate,
                "errors": errors,
            }
            AnalyzeWorker.last_debug = self.debug_info
            self.emit_progress(total, total, "", added, skipped, "Building summary / ParseFail=%d / Duplicate=%d" % (parse_fail, duplicate))
            rows.sort(key=lambda r: coerce_datetime(r.get("Start Datetime (YYYY-MM-DD HH:MM)")) or dt.datetime.min)
            summary = build_summary_rows(rows)
            self.finished_ok.emit(rows, summary, added, skipped)

        except Exception:
            self.failed.emit(traceback.format_exc())



# =====================================
# Version 7.3 Data Foundation
# =====================================
DATA_SCHEMA_VERSION = "1.0"
PROJECT_SCHEMA_VERSION = "1.0"


COMPONENT_NAME_ALIASES = {
    "do": "Degas Module",
    "do module": "Degas Module",
    "degas": "Degas Module",
    "degas module": "Degas Module",
}

def canonical_component_name(value):
    raw = str(value or "").strip()
    key = re.sub(r"[^a-z0-9]+", " ", raw.lower()).strip()
    return COMPONENT_NAME_ALIASES.get(key, raw or "Degas Module")

SECTION_MASTER_HEADERS = [
    "Section ID", "Hospital Name", "Serial Number", "Component Type",
    "Section Start", "Section End", "Section Type",
    "Replacement Type", "Failure Type", "Failure Type Version",
    "Data State", "Data Confidence", "Section Quality",
    "Use For Reliability", "Use For Forecast", "Censored",
    "Outlier", "Outlier Reason", "Manual Review",
    "Source", "Metadata JSON", "Comment", "Created At", "Updated At",
    "Schema Version", "Algorithm Version"
]
FAILURE_TYPE_MASTER_HEADERS = [
    "Component Type", "Failure Type", "Failure Code", "Description",
    "Active", "Use For Reliability", "Use For Forecast",
    "Default Severity", "Version", "Created At", "Updated At", "Comment"
]
REPLACEMENT_TYPE_MASTER_HEADERS = [
    "Replacement Type", "Description", "Use For Reliability", "Use For Forecast",
    "Censored", "Failure Event", "Default Section End", "Active",
    "Version", "Created At", "Updated At", "Comment"
]
RELIABILITY_MODEL_CONFIG_HEADERS = [
    "Model Name", "Model Type", "Active", "Component Type",
    "Failure Type Scope", "Use Censored Data", "Minimum Section Quality",
    "Minimum Samples", "Default Weight", "Plugin Name",
    "Model Version", "Config JSON", "Comment"
]
PROJECT_MANIFEST_HEADERS = ["Key", "Value"]


def df_now():
    return dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S")


def df_master_path(filename):
    try:
        return master_path(filename)
    except Exception:
        root = ensure_data_folders()
        master = os.path.join(root, "Master")
        os.makedirs(master, exist_ok=True)
        return os.path.join(master, filename)



def data_foundation_master_path(filename):
    return df_master_path(filename)


def df_project_path():
    path = os.path.join(ensure_data_folders(), "Project")
    os.makedirs(path, exist_ok=True)
    return path


def df_docs_path():
    path = os.path.join(df_project_path(), "docs")
    os.makedirs(path, exist_ok=True)
    return path


def df_write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def df_ensure_workbook(path, headers, sheet_name):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if not os.path.exists(path):
        wb = Workbook()
        ws = wb.active
        ws.title = sheet_name[:31]
        for c, h in enumerate(headers, 1):
            cell = ws.cell(1, c, h)
            cell.font = Font(bold=True)
            ws.column_dimensions[get_column_letter(c)].width = max(14, min(36, len(h) + 4))
        ws.freeze_panes = "A2"
        wb.save(path)
    else:
        wb = load_workbook(path)
        ws = wb.active
        current = [ws.cell(1, c).value or "" for c in range(1, ws.max_column + 1)]
        changed = False
        for h in headers:
            if h not in current:
                ws.cell(1, ws.max_column + 1, h)
                changed = True
        if changed:
            wb.save(path)


def df_append_defaults(path, headers, rows):
    wb = load_workbook(path)
    ws = wb.active
    if ws.max_row <= 1:
        for row in rows:
            r = ws.max_row + 1
            for c, h in enumerate(headers, 1):
                ws.cell(r, c, row.get(h, ""))
        wb.save(path)


def ensure_project_metadata_files():
    project = df_project_path()
    docs = df_docs_path()
    now = df_now()

    manifest = {
        "project_name": "WaterSystem Reliability Project",
        "project_id": str(uuid.uuid4()),
        "created_at": now,
        "last_modified": now,
        "software_version": APP_VERSION,
        "schema_version": DATA_SCHEMA_VERSION,
        "project_schema_version": PROJECT_SCHEMA_VERSION,
        "platform": "Medical Reliability Platform",
        "primary_component": "Degas Module",
        "status": "Data Foundation initialized"
    }
    files = {
        "manifest.json": manifest,
        "metadata.json": {
            "metadata_version": "1.0",
            "data_policy": "Raw data never changes",
            "reproducibility_policy": "Analysis requires metadata, engine version, schema version, and inputs."
        },
        "engine.json": {
            "runtime_engine": ALGORITHM_VERSION,
            "reliability_engine": ALGORITHM_VERSION,
            "forecast_engine": "Not calculated yet",
            "supported_models": ["Standard Statistics", "Weibull", "Kaplan-Meier", "Nelson-Aalen", "MTBF", "MTTF", "Hazard Rate"]
        },
        "schema.json": {
            "schema_version": DATA_SCHEMA_VERSION,
            "section_master": SECTION_MASTER_HEADERS,
            "failure_type_master": FAILURE_TYPE_MASTER_HEADERS,
            "replacement_type_master": REPLACEMENT_TYPE_MASTER_HEADERS,
            "reliability_model_config": RELIABILITY_MODEL_CONFIG_HEADERS
        },
        "settings.json": {
            "mode": "User",
            "maintenance_mode_planned": True,
            "snapshot_before_migration": True,
            "module_update_dry_run_required": True
        },
        "migration.json": {
            "migration_history": [],
            "current_schema_version": DATA_SCHEMA_VERSION,
            "rollback_policy": "Snapshot before migration"
        }
    }
    for name, data in files.items():
        path = os.path.join(project, name)
        if not os.path.exists(path):
            df_write_json(path, data)

    docs_data = {
        "Architecture.md": "# Architecture\n\nMedical Reliability Platform principles:\n\n- Everything is a Project\n- Raw Data Never Changes\n- Everything is Reproducible\n- Everything is Explainable\n- Everything is Upgradeable\n- Everything is Auditable\n- Backward Compatibility First\n",
        "Roadmap.md": "# Roadmap\n\nM1 Data Foundation / Version 7.3\nM2 Reliability Models / Version 7.4\nM3 Forecast Engine / Version 7.5\nM4 Learning Engine / Version 7.6\nM5 Platform Foundation / Version 8.0\n",
        "DecisionLog.md": "# Decision Log\n\n## Decision 001\nScheduled Replacement is treated as censored data by default because the failure time is not observed.\n\n## Decision 002\nFailure Type is defined per Component Type.\n\n## Decision 003\nRaw Log must not be overwritten.\n",
        "DataModel.md": "# Data Model\n\nProject -> Hospital Name -> Serial Number -> Component Type -> Section -> Runtime/Reliability/Forecast\n\nSection is the main analysis unit.\n",
        "ReleaseNotes.md": "# Release Notes\n\n## Version 7.3 DataFoundation\n- Section Master\n- Failure Type Master\n- Replacement Type Master\n- Reliability Model Config\n- Project JSON metadata and docs foundation\n"
    }
    for name, content in docs_data.items():
        path = os.path.join(docs, name)
        if not os.path.exists(path):
            Path(path).write_text(content, encoding="utf-8")


def ensure_data_foundation_files():
    section_path = df_master_path("Section_Master.xlsx")
    failure_path = df_master_path("Failure_Type_Master.xlsx")
    repl_path = df_master_path("Replacement_Type_Master.xlsx")
    model_path = df_master_path("Reliability_Model_Config.xlsx")
    manifest_path = df_master_path("Project_Manifest.xlsx")

    df_ensure_workbook(section_path, SECTION_MASTER_HEADERS, "Section_Master")
    df_ensure_workbook(failure_path, FAILURE_TYPE_MASTER_HEADERS, "Failure_Type_Master")
    df_ensure_workbook(repl_path, REPLACEMENT_TYPE_MASTER_HEADERS, "Replacement_Type_Master")
    df_ensure_workbook(model_path, RELIABILITY_MODEL_CONFIG_HEADERS, "Reliability_Model_Config")
    df_ensure_workbook(manifest_path, PROJECT_MANIFEST_HEADERS, "Project_Manifest")

    now = df_now()
    df_append_defaults(failure_path, FAILURE_TYPE_MASTER_HEADERS, [
        {"Component Type":"Degas Module","Failure Type":"Water in Vacuum Cup","Failure Code":"DO-WATER-CUP","Description":"Water accumulation in vacuum cup","Active":"Yes","Use For Reliability":"Yes","Use For Forecast":"Yes","Default Severity":"Medium","Version":"1.0","Created At":now,"Updated At":now},
        {"Component Type":"Degas Module","Failure Type":"Slow Degas","Failure Code":"DO-SLOW-DEGAS","Description":"Degas is slower than expected","Active":"Yes","Use For Reliability":"Yes","Use For Forecast":"Yes","Default Severity":"Medium","Version":"1.0","Created At":now,"Updated At":now},
        {"Component Type":"Degas Module","Failure Type":"Degas Minimum High","Failure Code":"DO-MIN-HIGH","Description":"Degas minimum value remains high","Active":"Yes","Use For Reliability":"Yes","Use For Forecast":"Yes","Default Severity":"High","Version":"1.0","Created At":now,"Updated At":now},
        {"Component Type":"Degas Module","Failure Type":"Unknown","Failure Code":"UNKNOWN","Description":"Unknown failure type","Active":"Yes","Use For Reliability":"Conditional","Use For Forecast":"Conditional","Default Severity":"Unknown","Version":"1.0","Created At":now,"Updated At":now}
    ])

    df_append_defaults(repl_path, REPLACEMENT_TYPE_MASTER_HEADERS, [
        {"Replacement Type":"Failure","Description":"Replacement caused by failure","Use For Reliability":"Yes","Use For Forecast":"Yes","Censored":"No","Failure Event":"Yes","Default Section End":"Yes","Active":"Yes","Version":"1.0","Created At":now,"Updated At":now},
        {"Replacement Type":"Scheduled Replacement","Description":"Planned replacement; failure time not observed","Use For Reliability":"Yes","Use For Forecast":"Conditional","Censored":"Yes","Failure Event":"No","Default Section End":"Yes","Active":"Yes","Version":"1.0","Created At":now,"Updated At":now},
        {"Replacement Type":"Hospital Request","Description":"Hospital requested replacement; not failure-related by default","Use For Reliability":"No","Use For Forecast":"No","Censored":"No","Failure Event":"No","Default Section End":"Yes","Active":"Yes","Version":"1.0","Created At":now,"Updated At":now},
        {"Replacement Type":"Company Instruction","Description":"Company/service instruction replacement","Use For Reliability":"No","Use For Forecast":"No","Censored":"No","Failure Event":"No","Default Section End":"Yes","Active":"Yes","Version":"1.0","Created At":now,"Updated At":now},
        {"Replacement Type":"Unknown","Description":"Unknown replacement type","Use For Reliability":"Conditional","Use For Forecast":"Conditional","Censored":"Conditional","Failure Event":"Unknown","Default Section End":"Yes","Active":"Yes","Version":"1.0","Created At":now,"Updated At":now}
    ])

    df_append_defaults(model_path, RELIABILITY_MODEL_CONFIG_HEADERS, [
        {"Model Name":"Standard Statistics","Model Type":"Statistics","Active":"Yes","Component Type":"All","Failure Type Scope":"All","Use Censored Data":"No","Minimum Section Quality":50,"Minimum Samples":3,"Default Weight":1.0,"Plugin Name":"standard_statistics","Model Version":"1.0","Config JSON":"{\"method\":\"mean_median_percentile\"}"},
        {"Model Name":"Weibull","Model Type":"Parametric","Active":"Planned","Component Type":"All","Failure Type Scope":"Failure only","Use Censored Data":"Yes","Minimum Section Quality":70,"Minimum Samples":5,"Default Weight":1.0,"Plugin Name":"weibull","Model Version":"0.1-planned","Config JSON":"{\"distribution\":\"weibull\",\"censored\":true}"},
        {"Model Name":"Kaplan-Meier","Model Type":"Survival","Active":"Planned","Component Type":"All","Failure Type Scope":"All","Use Censored Data":"Yes","Minimum Section Quality":70,"Minimum Samples":5,"Default Weight":1.0,"Plugin Name":"kaplan_meier","Model Version":"0.1-planned","Config JSON":"{\"survival_model\":\"kaplan_meier\"}"},
        {"Model Name":"Nelson-Aalen","Model Type":"Survival","Active":"Planned","Component Type":"All","Failure Type Scope":"All","Use Censored Data":"Yes","Minimum Section Quality":70,"Minimum Samples":5,"Default Weight":1.0,"Plugin Name":"nelson_aalen","Model Version":"0.1-planned","Config JSON":"{\"hazard_model\":\"nelson_aalen\"}"},
        {"Model Name":"MTBF","Model Type":"Metric","Active":"Planned","Component Type":"All","Failure Type Scope":"Failure only","Use Censored Data":"No","Minimum Section Quality":60,"Minimum Samples":3,"Default Weight":1.0,"Plugin Name":"mtbf","Model Version":"0.1-planned","Config JSON":"{\"metric\":\"mtbf\"}"}
    ])

    ensure_project_metadata_files()
    return {
        "Section_Master.xlsx": section_path,
        "Failure_Type_Master.xlsx": failure_path,
        "Replacement_Type_Master.xlsx": repl_path,
        "Reliability_Model_Config.xlsx": model_path,
        "Project_Manifest.xlsx": manifest_path,
        "Project Folder": df_project_path()
    }


def build_data_foundation_report():
    paths = ensure_data_foundation_files()
    lines = ["Data Foundation initialized.", "", "Schema Version: %s" % DATA_SCHEMA_VERSION, "", "Created/checked:"]
    for k, v in paths.items():
        lines.append("- %s: %s" % (k, v))
    return "\n".join(lines), paths


class DataFoundationDialog(QtWidgets.QDialog):
    def __init__(self, report_text, paths, parent=None):
        super(DataFoundationDialog, self).__init__(parent)
        self.setWindowTitle("Data Foundation")
        self.resize(900, 600)
        self.report_text = report_text
        self.paths = paths or {}
        self._ui()

    def _ui(self):
        layout = QVBoxLayout(self)
        label = QLabel("<b>Version 7.3 Data Foundation</b><br>Project metadata, Section Master, Failure Type Master, Replacement Type Master, and Model Config are initialized.")
        label.setWordWrap(True)
        layout.addWidget(label)
        t = QtWidgets.QTextEdit()
        t.setReadOnly(True)
        t.setPlainText(self.report_text)
        layout.addWidget(t, 1)
        buttons = QHBoxLayout()
        b = QPushButton("Open Master Folder")
        b.clicked.connect(lambda: QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(os.path.dirname(df_master_path("Section_Master.xlsx")))))
        buttons.addWidget(b)
        b = QPushButton("Open Project Folder")
        b.clicked.connect(lambda: QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(df_project_path())))
        buttons.addWidget(b)
        b = QPushButton("Close")
        b.clicked.connect(self.accept)
        buttons.addWidget(b)
        layout.addLayout(buttons)


# =====================================
# Version 7.3a Dashboard Design Preview
# =====================================

def dashboard_safe_float(v, default=0.0):
    try:
        if v in ("", None):
            return default
        return float(v)
    except Exception:
        return default


def dashboard_latest_xlsx_rows(filename, max_rows=50):
    try:
        path = data_foundation_master_path(filename) if "data_foundation_master_path" in globals() else master_path(filename)
    except Exception:
        return []
    rows = []
    try:
        if not os.path.exists(path):
            return rows
        wb = load_workbook(path, data_only=True, read_only=True)
        ws = wb.active
        headers = [ws.cell(1, c).value or "" for c in range(1, ws.max_column + 1)]
        for values in ws.iter_rows(min_row=2, values_only=True):
            row = {}
            for i, h in enumerate(headers):
                if h:
                    row[h] = values[i] if i < len(values) else ""
            rows.append(row)
        try:
            wb.close()
        except Exception:
            pass
    except Exception:
        return []
    return rows[-max_rows:]


def dashboard_context(summary_rows):
    explain = dashboard_latest_xlsx_rows("Explainable_Reliability.xlsx", 50)
    trend = dashboard_latest_xlsx_rows("Reliability_Trend.xlsx", 50)
    latest = explain[-1] if explain else {}
    if not latest:
        has_data = bool(summary_rows)
        latest = {
            "Forecast Readiness": "READY WITH CAUTION" if has_data else "NOT READY",
            "Overall Confidence Score": 75 if has_data else 0,
            "Overall Confidence Stars": "★★★☆☆" if has_data else "★☆☆☆☆",
            "Coverage Score": 80 if has_data else 0,
            "Data Continuity Score": 75 if has_data else 0,
            "Gap Quality Score": 75 if has_data else 0,
            "Runtime Confidence Score": 80 if has_data else 0,
            "Replacement Quality Score": 50,
            "Prediction Stability Score": 50,
            "Data Quality Score": 90 if has_data else 0,
            "Overall Explanation": "Dashboard preview fallback. Run Runtime Reconstruction / Explainable Reliability for calculated values."
        }
    return latest, trend, explain


class DashboardCard(QtWidgets.QFrame):
    def __init__(self, title, value, subtitle="", parent=None):
        super(DashboardCard, self).__init__(parent)
        self.setFrameShape(QtWidgets.QFrame.Shape.StyledPanel)
        self.setMinimumHeight(110)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("<b>%s</b>" % title))
        lay.addWidget(QLabel("<span style='font-size:28px; font-weight:bold;'>%s</span>" % value))
        sub = QLabel("<span style='color:#666;'>%s</span>" % subtitle)
        sub.setWordWrap(True)
        lay.addWidget(sub)


class MiniTrendWidget(QtWidgets.QWidget):
    def __init__(self, trend_rows, parent=None):
        super(MiniTrendWidget, self).__init__(parent)
        self.trend_rows = trend_rows or []
        self.setMinimumHeight(220)

    def paintEvent(self, event):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        r = self.rect().adjusted(14,14,-14,-14)
        f = QtGui.QFont(); f.setPointSize(12); f.setBold(True); p.setFont(f)
        p.setPen(QtGui.QColor(35,35,35)); p.drawText(r.left(), r.top(), "Reliability Trend")
        plot = QtCore.QRectF(r.left()+30, r.top()+40, r.width()-60, r.height()-70)
        p.setPen(QtGui.QPen(QtGui.QColor(225,225,225), 1))
        for i in range(5):
            y = plot.top() + plot.height()*i/4
            p.drawLine(plot.left(), y, plot.right(), y)
        vals = []
        for row in self.trend_rows[-12:]:
            vals.append(dashboard_safe_float(row.get("Overall Confidence Score"), 0))
        if not vals:
            vals = [70, 73, 75, 78, 80, 82]
        n = max(1, len(vals)-1)
        pts = []
        for i,v in enumerate(vals):
            pts.append(QtCore.QPointF(plot.left()+plot.width()*(i/n if n else 0), plot.bottom()-plot.height()*max(0,min(100,v))/100.0))
        p.setPen(QtGui.QPen(QtGui.QColor(70,145,220), 3))
        for a,b in zip(pts, pts[1:]):
            p.drawLine(a,b)
        p.setBrush(QtGui.QColor(70,145,220))
        for pt in pts:
            p.drawEllipse(pt, 4, 4)


class ScoreBarsWidget(QtWidgets.QWidget):
    def __init__(self, items, parent=None):
        super(ScoreBarsWidget, self).__init__(parent)
        self.items = items or []
        self.setMinimumHeight(280)

    def paintEvent(self, event):
        p = QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        r = self.rect().adjusted(14,14,-14,-14)
        f = QtGui.QFont(); f.setPointSize(12); f.setBold(True); p.setFont(f)
        p.setPen(QtGui.QColor(35,35,35)); p.drawText(r.left(), r.top(), "Confidence Breakdown")
        y = r.top()+42
        for label, score in self.items:
            score = dashboard_safe_float(score, 0)
            p.setPen(QtGui.QColor(60,60,60)); f.setPointSize(9); f.setBold(True); p.setFont(f)
            p.drawText(r.left(), y+13, label)
            bar = QtCore.QRectF(r.left()+155, y, r.width()-230, 16)
            p.setPen(QtCore.Qt.PenStyle.NoPen); p.setBrush(QtGui.QColor(232,232,232)); p.drawRoundedRect(bar,8,8)
            color = QtGui.QColor(75,170,95) if score >= 85 else (QtGui.QColor(230,180,70) if score >= 65 else QtGui.QColor(220,90,80))
            fill = QtCore.QRectF(bar.left(), bar.top(), bar.width()*max(0,min(100,score))/100.0, bar.height())
            p.setBrush(color); p.drawRoundedRect(fill,8,8)
            p.setPen(QtGui.QColor(40,40,40)); f.setBold(False); p.setFont(f); p.drawText(bar.right()+10, y+13, "%.0f" % score)
            y += 34


class FailureMixWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super(FailureMixWidget, self).__init__(parent)
        self.setMinimumHeight(220)
        self.items = [("Water in Vacuum Cup",35),("Slow Degas",28),("Degas Minimum High",20),("Unknown",17)]

    def paintEvent(self, event):
        p = QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        r = self.rect().adjusted(14,14,-14,-14)
        f = QtGui.QFont(); f.setPointSize(12); f.setBold(True); p.setFont(f)
        p.setPen(QtGui.QColor(35,35,35)); p.drawText(r.left(), r.top(), "Failure Distribution")
        pie = QtCore.QRectF(r.left()+20, r.top()+45, 130, 130)
        total = sum(v for _,v in self.items); start=0
        colors=[QtGui.QColor(70,145,220), QtGui.QColor(245,170,70), QtGui.QColor(220,90,80), QtGui.QColor(160,160,160)]
        p.setPen(QtCore.Qt.PenStyle.NoPen)
        for i,(name,val) in enumerate(self.items):
            span=int(360*16*val/total); p.setBrush(colors[i]); p.drawPie(pie, start, span); start += span
        y=r.top()+48; f.setPointSize(9); f.setBold(False); p.setFont(f)
        for i,(name,val) in enumerate(self.items):
            p.setBrush(colors[i]); p.drawRect(r.left()+180,y-9,10,10)
            p.setPen(QtGui.QColor(60,60,60)); p.drawText(r.left()+198, y, "%s  %d%%" % (name,val)); y += 28


class ForecastTimelineWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super(ForecastTimelineWidget, self).__init__(parent)
        self.setMinimumHeight(180)

    def paintEvent(self, event):
        p=QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        r=self.rect().adjusted(14,14,-14,-14)
        f=QtGui.QFont(); f.setPointSize(12); f.setBold(True); p.setFont(f)
        p.setPen(QtGui.QColor(35,35,35)); p.drawText(r.left(), r.top(), "Forecast Timeline")
        y=r.top()+82; x1=r.left()+50; x2=r.right()-50
        p.setPen(QtGui.QPen(QtGui.QColor(80,80,80),2)); p.drawLine(x1,y,x2,y)
        p.setBrush(QtGui.QColor(70,145,220)); p.drawEllipse(QtCore.QPointF(x1,y),6,6)
        p.setBrush(QtGui.QColor(230,180,70)); p.drawRoundedRect(QtCore.QRectF(x2-120,y-10,95,20),8,8)
        p.setPen(QtGui.QColor(60,60,60)); f.setPointSize(9); f.setBold(False); p.setFont(f)
        p.drawText(x1-20,y+28,"Today"); p.drawText(x2-140,y+28,"Forecast Window"); p.drawText(x2-35,y+28,"Replace")


class DashboardPreviewDialog(QtWidgets.QDialog):
    def __init__(self, latest, trend_rows, explain_rows, parent=None):
        super(DashboardPreviewDialog, self).__init__(parent)
        self.setWindowTitle("Medical Reliability Dashboard Preview")
        self.resize(1280, 820)
        self.latest = latest or {}; self.trend_rows = trend_rows or []; self.explain_rows = explain_rows or []
        self._ui()

    def _ui(self):
        layout=QVBoxLayout(self)
        scroll=QScrollArea(); scroll.setWidgetResizable(True)
        body=QWidget(); bl=QVBoxLayout(body); scroll.setWidget(body); layout.addWidget(scroll,1)
        readiness=self.latest.get("Forecast Readiness","READY WITH CAUTION")
        overall=dashboard_safe_float(self.latest.get("Overall Confidence Score"),75)
        stars=self.latest.get("Overall Confidence Stars","★★★☆☆")
        if readiness == "READY":
            title, color = "HEALTHY / READY FOR FORECAST", "#2e9d55"
        elif readiness == "READY WITH CAUTION":
            title, color = "MONITOR / FORECAST WITH CAUTION", "#c99722"
        else:
            title, color = "INSUFFICIENT DATA", "#c94c44"
        scope_row = QHBoxLayout()
        scope_row.addWidget(QLabel("<b>Dashboard Scope</b>"))
        self.scope_combo = QComboBox()
        self.scope_combo.addItems(DASHBOARD_SCOPE_OPTIONS)
        saved_scope = rc_read_json(rc_session_path(), {}).get("dashboard_scope", "Hospital")
        self.scope_combo.setCurrentText(saved_scope if saved_scope in DASHBOARD_SCOPE_OPTIONS else "Hospital")
        self.scope_combo.setToolTip("Hospital is the default. Other scopes are foundation selectors and will be fully connected to grouped reliability models in the next analysis release.")
        self.scope_combo.currentTextChanged.connect(self.scope_changed)
        scope_row.addWidget(self.scope_combo)
        self.scope_target = QComboBox()
        self.scope_target.setEditable(True)
        self.scope_target.addItem("")
        try:
            hp_rows = read_master_foundation_rows("Hospital_Master.xlsx", HP_MASTER_HEADERS)
            hospitals = sorted(set(str(r.get("Hospital Name", "")).strip() for r in hp_rows if str(r.get("Hospital Name", "")).strip()))
            self.scope_target.addItems(hospitals)
        except Exception:
            pass
        saved_target = str(rc_read_json(rc_session_path(), {}).get("dashboard_scope_target", ""))
        self.scope_target.setCurrentText(saved_target)
        self.scope_target.currentTextChanged.connect(self.scope_changed)
        scope_row.addWidget(self.scope_target, 1)
        bl.addLayout(scope_row)

        self.scope_note = QLabel("")
        self.scope_note.setWordWrap(True)
        bl.addWidget(self.scope_note)

        header=QLabel("<div style='font-size:28px; font-weight:bold;'>Medical Reliability Dashboard</div><div style='font-size:22px; font-weight:bold; color:%s;'>%s</div><div style='font-size:18px;'>Reliability: <b>%.1f</b> %s</div>" % (color,title,overall,stars))
        header.setWordWrap(True); header.setMinimumHeight(110); bl.addWidget(header)
        self.dashboard_header = header
        self.scope_changed()
        cards=QHBoxLayout()
        cards.addWidget(DashboardCard("Health Score","%.1f"%overall,"Overall reliability confidence"))
        cards.addWidget(DashboardCard("Remaining Life","Preview","Forecast Engine starts in Version 7.5"))
        cards.addWidget(DashboardCard("Confidence",stars,"Explainable reliability"))
        cards.addWidget(DashboardCard("Recommendation","Monitor","Prototype rule-based display"))
        bl.addLayout(cards)
        row1=QHBoxLayout(); row1.addWidget(MiniTrendWidget(self.trend_rows)); row1.addWidget(ForecastTimelineWidget()); bl.addLayout(row1)
        row2=QHBoxLayout(); row2.addWidget(FailureMixWidget())
        breakdown=[("Coverage",self.latest.get("Coverage Score",0)),("Continuity",self.latest.get("Data Continuity Score",0)),("Gap quality",self.latest.get("Gap Quality Score",0)),("Runtime",self.latest.get("Runtime Confidence Score",0)),("Replacement",self.latest.get("Replacement Quality Score",0)),("Prediction",self.latest.get("Prediction Stability Score",0)),("Data quality",self.latest.get("Data Quality Score",0))]
        row2.addWidget(ScoreBarsWidget(breakdown)); bl.addLayout(row2)
        why=QLabel("<b>Why?</b><br>%s" % self.latest.get("Overall Explanation","Run Explainable Reliability to populate detailed reasons."))
        why.setWordWrap(True); why.setMinimumHeight(90); bl.addWidget(why)
        details = CollapsibleDetails("Show Details / JSON")
        txt = QtWidgets.QTextEdit()
        txt.setReadOnly(True)
        txt.setPlainText(json.dumps(self.latest, ensure_ascii=False, indent=2, default=str))
        details.content_layout.addWidget(txt)
        bl.addWidget(details)
        b=QPushButton("Close"); b.clicked.connect(self.accept); layout.addWidget(b)


    def scope_changed(self, *args):
        scope = self.scope_combo.currentText() if hasattr(self, "scope_combo") else "Hospital"
        target = self.scope_target.currentText().strip() if hasattr(self, "scope_target") else ""
        state = rc_read_json(rc_session_path(), {})
        state["dashboard_scope"] = scope
        state["dashboard_scope_target"] = target
        rc_write_json(rc_session_path(), state)
        label = target or ("Current Hospital" if scope == "Hospital" else scope)
        self.scope_note.setText(
            "<b>Current scope:</b> %s — %s<br>"
            "Hospital is the default. This RC confirms scope selection/persistence; full multi-hospital/country/region recalculation is connected in the reliability model phase."
            % (scope, label)
        )


# =====================================
# Version 7.3c Replacement Import Wizard
# =====================================

REPLACEMENT_IMPORT_FIELDS = [
    "Hospital Name", "Serial Number", "Component Type", "Replacement Date",
    "Replacement Type", "Failure Type", "Reason", "Comment"
]

REPLACEMENT_IMPORT_ALIASES = {
    "Hospital Name": ["hospital name", "hospital", "site", "site name", "hp", "facility", "customer"],
    "Serial Number": ["serial number", "serial", "sn", "system serial", "system sn", "device serial"],
    "Component Type": ["component type", "component", "module", "module type", "part type"],
    "Replacement Date": ["replacement date", "replace date", "date", "service date", "replacement datetime"],
    "Replacement Type": ["replacement type", "replace type", "event type", "maintenance type"],
    "Failure Type": ["failure type", "failure", "fault type", "failure mode", "symptom"],
    "Reason": ["reason", "cause", "failure reason", "description"],
    "Comment": ["comment", "comments", "note", "notes", "remark", "remarks"]
}

REPLACEMENT_TYPE_SYNONYMS = {
    "failure": "Failure",
    "failed": "Failure",
    "breakdown": "Failure",
    "scheduled": "Scheduled Replacement",
    "scheduled replacement": "Scheduled Replacement",
    "preventive": "Scheduled Replacement",
    "preventive maintenance": "Scheduled Replacement",
    "pm": "Scheduled Replacement",
    "periodic": "Scheduled Replacement",
    "hospital request": "Hospital Request",
    "customer request": "Hospital Request",
    "company request": "Company Instruction",
    "company instruction": "Company Instruction",
    "service instruction": "Company Instruction",
    "unknown": "Unknown",
}

FAILURE_TYPE_SYNONYMS = {
    "water cup": "Water in Vacuum Cup",
    "water in cup": "Water in Vacuum Cup",
    "water in vacuum cup": "Water in Vacuum Cup",
    "vacuum cup water": "Water in Vacuum Cup",
    "slow": "Slow Degas",
    "slow degas": "Slow Degas",
    "degas slow": "Slow Degas",
    "minimum high": "Degas Minimum High",
    "degas minimum high": "Degas Minimum High",
    "min high": "Degas Minimum High",
    "unknown": "Unknown",
}


def import_normalize_header(value):
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").strip().lower()).strip()


def import_normalize_choice(value, synonyms, allowed, default="Unknown"):
    raw = str(value or "").strip()
    if not raw:
        return default
    key = import_normalize_header(raw)
    if key in synonyms:
        return synonyms[key]
    for item in allowed:
        if import_normalize_header(item) == key:
            return item
    for synonym, canonical in synonyms.items():
        if synonym in key or key in synonym:
            return canonical
    return default


def import_load_master_choices(filename, field, defaults):
    choices = list(defaults)
    try:
        path = df_master_path(filename) if "df_master_path" in globals() else master_foundation_path(filename)
        if os.path.exists(path):
            wb = load_workbook(path, data_only=True, read_only=True)
            ws = wb.active
            headers = [str(ws.cell(1, c).value or "") for c in range(1, ws.max_column + 1)]
            if field in headers:
                idx = headers.index(field)
                for values in ws.iter_rows(min_row=2, values_only=True):
                    v = values[idx] if idx < len(values) else ""
                    if v not in ("", None) and str(v) not in choices:
                        choices.append(str(v))
            try:
                wb.close()
            except Exception:
                pass
    except Exception:
        pass
    return choices


def import_read_source(path):
    ext = os.path.splitext(path)[1].lower()
    rows = []
    headers = []
    legacy = False

    if ext in (".xlsx", ".xlsm"):
        wb = load_workbook(path, data_only=True, read_only=True)
        ws = wb[wb.sheetnames[0]]
        first = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
        normalized = [import_normalize_header(v) for v in first]

        # Robust legacy detection:
        # A=SN, B=HP/Hospital, C onward mostly blank headers, with date-like values below.
        first_a = normalized[0] if len(normalized) > 0 else ""
        first_b = normalized[1] if len(normalized) > 1 else ""
        sn_like = first_a in ("sn", "serial", "serial number", "system sn", "system serial")
        hp_like = first_b in ("hp", "hospital", "hospital name", "site", "site name")
        trailing_blank_headers = sum(1 for v in first[2:] if v in ("", None))
        trailing_total = max(0, len(first) - 2)

        date_cells = 0
        populated_trailing = 0
        sample_end = min(ws.max_row, 40)
        for r in range(2, sample_end + 1):
            for c in range(3, ws.max_column + 1):
                v = ws.cell(r, c).value
                if v not in ("", None):
                    populated_trailing += 1
                    if excel_serial_to_datetime(v):
                        date_cells += 1

        legacy = (
            sn_like and hp_like and ws.max_column >= 3 and
            trailing_total > 0 and
            trailing_blank_headers >= max(1, int(trailing_total * 0.6)) and
            date_cells >= 1 and
            date_cells >= int(populated_trailing * 0.7)
        )

        if legacy:
            headers = ["Serial Number", "Hospital Name"] + [
                "Replacement Date %d" % (i - 1) for i in range(3, ws.max_column + 1)
            ]
            for r in range(2, ws.max_row + 1):
                vals = [ws.cell(r, c).value for c in range(1, ws.max_column + 1)]
                if any(v not in ("", None) for v in vals):
                    rows.append(vals)
        else:
            headers = [str(v or "Column %d" % (i + 1)) for i, v in enumerate(first)]
            for values in ws.iter_rows(min_row=2, values_only=True):
                if any(v not in ("", None) for v in values):
                    rows.append(list(values))
        try:
            wb.close()
        except Exception:
            pass

    elif ext == ".csv":
        with open(path, "r", encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f)
            all_rows = list(reader)
        if all_rows:
            headers = [str(v or "Column %d" % (i + 1)) for i, v in enumerate(all_rows[0])]
            rows = [list(r) for r in all_rows[1:] if any(str(v).strip() for v in r)]

    elif ext == ".json":
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            data = data.get("replacement_history", data.get("rows", data.get("data", [])))
        if isinstance(data, list):
            keys = []
            for item in data:
                if isinstance(item, dict):
                    for k in item:
                        if k not in keys:
                            keys.append(k)
            headers = keys
            for item in data:
                if isinstance(item, dict):
                    rows.append([item.get(k, "") for k in headers])
    else:
        raise ValueError("Supported files: .xlsx, .xlsm, .csv, .json")

    return headers, rows, legacy


def import_auto_mapping(headers):
    mapping = {}
    normalized_headers = [import_normalize_header(h) for h in headers]
    for target, aliases in REPLACEMENT_IMPORT_ALIASES.items():
        best = -1
        alias_norm = [import_normalize_header(a) for a in aliases] + [import_normalize_header(target)]
        for i, header in enumerate(normalized_headers):
            if header in alias_norm:
                best = i
                break
        if best < 0:
            for i, header in enumerate(normalized_headers):
                if any(a in header or header in a for a in alias_norm if a and header):
                    best = i
                    break
        mapping[target] = best
    return mapping


def import_value(row, index):
    if index is None or index < 0 or index >= len(row):
        return ""
    return row[index]


def import_convert_generic_rows(headers, rows, mapping, default_component, default_replacement, default_failure):
    converted = []
    warnings = []
    for row_no, row in enumerate(rows, 2):
        hospital = normalize_text_value(import_value(row, mapping.get("Hospital Name", -1)))
        serial = normalize_text_value(import_value(row, mapping.get("Serial Number", -1)))
        component_raw = canonical_component_name(normalize_text_value(import_value(row, mapping.get("Component Type", -1))) or default_component)
        date_raw = import_value(row, mapping.get("Replacement Date", -1))
        replacement_raw = normalize_text_value(import_value(row, mapping.get("Replacement Type", -1))) or default_replacement
        failure_raw = normalize_text_value(import_value(row, mapping.get("Failure Type", -1))) or default_failure
        reason = normalize_text_value(import_value(row, mapping.get("Reason", -1)))
        comment = normalize_text_value(import_value(row, mapping.get("Comment", -1)))

        date_value = excel_serial_to_datetime(date_raw)
        if not date_value:
            warnings.append("Row %d: Replacement Date could not be converted." % row_no)
            continue
        if not serial and not hospital:
            warnings.append("Row %d: Hospital Name and Serial Number are both blank." % row_no)
            continue

        replacement_type = import_normalize_choice(
            replacement_raw,
            REPLACEMENT_TYPE_SYNONYMS,
            import_load_master_choices("Replacement_Type_Master.xlsx", "Replacement Type",
                                       ["Failure", "Scheduled Replacement", "Hospital Request", "Company Instruction", "Unknown"]),
            default_replacement
        )
        failure_type = import_normalize_choice(
            failure_raw,
            FAILURE_TYPE_SYNONYMS,
            import_load_master_choices("Failure_Type_Master.xlsx", "Failure Type",
                                       ["Water in Vacuum Cup", "Slow Degas", "Degas Minimum High", "Unknown"]),
            default_failure
        )

        converted.append({
            "Hospital Name": hospital,
            "Serial Number": serial,
            "Component Type": component_raw or "Degas Module",
            "Component ID": "",
            "Coil ID": "",
            "Replacement Date": date_value.strftime("%Y/%m/%d"),
            "Replacement Type": replacement_type,
            "Reason": reason or failure_type,
            "Comment": comment,
            "_Failure Type": failure_type,
            "_Source Row": row_no,
        })
    return converted, warnings


def import_convert_legacy_rows(headers, rows, default_component, default_replacement, default_failure):
    converted = []
    warnings = []
    skipped_placeholders = 0
    system_count = 0
    for row_no, row in enumerate(rows, 2):
        serial = normalize_text_value(row[0] if len(row) > 0 else "")
        hospital = normalize_text_value(row[1] if len(row) > 1 else "")

        serial_key = serial.strip().lower()
        hospital_key = hospital.strip().lower()
        if (
            not serial and not hospital
        ) or (
            serial_key in ("na", "n/a", "none", "not selected") and
            hospital_key in ("", "na", "n/a", "none", "not selected")
        ):
            skipped_placeholders += 1
            warnings.append("Row %d: Placeholder row skipped (%s / %s)." % (row_no, serial or "(blank)", hospital or "(blank)"))
            continue

        event_count_before = len(converted)
        for col in range(2, len(row)):
            raw = row[col]
            if raw in ("", None):
                continue
            d = excel_serial_to_datetime(raw)
            if not d:
                warnings.append("Row %d, column %d: Date could not be converted." % (row_no, col + 1))
                continue
            converted.append({
                "Hospital Name": hospital,
                "Serial Number": serial,
                "Component Type": canonical_component_name(default_component),
                "Component ID": "",
                "Coil ID": "",
                "Replacement Date": d.strftime("%Y/%m/%d"),
                "Replacement Type": default_replacement,
                "Reason": default_failure,
                "Comment": "Converted from legacy multi-hospital History.xlsx layout",
                "_Failure Type": default_failure,
                "_Source Row": row_no,
                "_Source Column": col + 1,
            })
        if len(converted) > event_count_before:
            system_count += 1

    warnings.insert(0, "Legacy conversion summary: %d system(s), %d event(s), %d placeholder row(s) skipped." %
                    (system_count, len(converted), skipped_placeholders))
    return converted, warnings


def import_commit_replacement_rows(converted):
    ensure_master_foundation_files()
    existing = read_master_foundation_rows("Replacement_History.xlsx", REPLACEMENT_HISTORY_HEADERS)
    existing_keys = set()
    for row in existing:
        d = excel_serial_to_datetime(row.get("Replacement Date"))
        dkey = d.strftime("%Y-%m-%d") if d else str(row.get("Replacement Date", "")).strip()
        existing_keys.add((
            normalize_text_value(row.get("Hospital Name")).lower(),
            normalize_text_value(row.get("Serial Number")).lower(),
            normalize_text_value(row.get("Component Type")).lower(),
            dkey,
            normalize_text_value(row.get("Replacement Type")).lower(),
        ))

    added = 0
    duplicates = 0
    for row in converted:
        d = excel_serial_to_datetime(row.get("Replacement Date"))
        dkey = d.strftime("%Y-%m-%d") if d else str(row.get("Replacement Date", "")).strip()
        key = (
            normalize_text_value(row.get("Hospital Name")).lower(),
            normalize_text_value(row.get("Serial Number")).lower(),
            normalize_text_value(row.get("Component Type")).lower(),
            dkey,
            normalize_text_value(row.get("Replacement Type")).lower(),
        )
        if key in existing_keys:
            duplicates += 1
            continue
        existing.append({h: row.get(h, "") for h in REPLACEMENT_HISTORY_HEADERS})
        existing_keys.add(key)
        added += 1

    path = write_master_foundation_rows("Replacement_History.xlsx", REPLACEMENT_HISTORY_HEADERS, existing)
    return path, added, duplicates



def apply_servicehub_dialog_style(widget):
    widget.setStyleSheet("""
        QDialog, QWidget { background: #f4f7fb; color: #1f2d3d; }
        QLabel { color: #1f2d3d; }
        QGroupBox {
            border: 1px solid #cfd8e3; border-radius: 8px;
            margin-top: 10px; padding-top: 10px;
            font-weight: 600; background: #ffffff;
        }
        QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 5px; }
        QPushButton {
            min-height: 30px; padding: 4px 14px;
            border-radius: 6px; border: 1px solid #8fa9c3;
            background: #ffffff;
        }
        QPushButton:hover { background: #eaf2fb; }
        QPushButton:disabled { color: #8b98a5; background: #edf1f5; }
        QLineEdit, QComboBox, QDateEdit, QTextEdit, QTableWidget {
            background: #ffffff; border: 1px solid #c8d3df;
            border-radius: 5px; padding: 4px;
        }
        QTabWidget::pane { border: 1px solid #cfd8e3; background: #ffffff; }
        QTabBar::tab { padding: 7px 14px; background: #e8eef5; }
        QTabBar::tab:selected { background: #ffffff; font-weight: 600; }
        QHeaderView::section { background: #e8eef5; padding: 5px; border: 0; border-right: 1px solid #cfd8e3; }
    """)


class ReplacementManualEntryDialog(QtWidgets.QDialog):
    def __init__(self, parent=None, initial=None):
        super(ReplacementManualEntryDialog, self).__init__(parent)
        self.setWindowTitle("Add Replacement History")
        self.resize(600, 520)
        self.result_row = None
        self.initial = initial or {}
        apply_servicehub_dialog_style(self)
        self._ui()

    def _ui(self):
        layout = QVBoxLayout(self)
        guide = QLabel(
            "<b>Manual Replacement Entry</b><br>"
            "Add one replacement event. Fields with fixed choices use Master-linked dropdowns."
        )
        guide.setWordWrap(True)
        layout.addWidget(guide)

        form_box = QtWidgets.QGroupBox("Replacement Event")
        form = QtWidgets.QFormLayout(form_box)

        self.hospital_edit = QLineEdit(str(self.initial.get("Hospital Name", "")))
        self.hospital_edit.setToolTip("Hospital Name. Free text is allowed until Hospital Master linking is completed.")
        form.addRow("Hospital Name", self.hospital_edit)

        self.serial_edit = QLineEdit(str(self.initial.get("Serial Number", "")))
        self.serial_edit.setToolTip("System Serial Number.")
        form.addRow("Serial Number", self.serial_edit)

        self.component_combo = QComboBox()
        self.component_combo.setEditable(True)
        self.component_combo.addItems(["Degas Module", "Degas Module"])
        self.component_combo.setCurrentText(str(self.initial.get("Component Type", "Degas Module")))
        form.addRow("Component Type", self.component_combo)

        self.date_edit = QtWidgets.QDateEdit(QtCore.QDate.currentDate())
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDisplayFormat("yyyy/MM/dd")
        initial_date = excel_serial_to_datetime(self.initial.get("Replacement Date"))
        if initial_date:
            self.date_edit.setDate(QtCore.QDate(initial_date.year, initial_date.month, initial_date.day))
        form.addRow("Replacement Date", self.date_edit)

        self.replacement_combo = QComboBox()
        self.replacement_combo.addItems(import_load_master_choices(
            "Replacement_Type_Master.xlsx", "Replacement Type",
            ["Failure", "Scheduled Replacement", "Hospital Request", "Company Instruction", "Unknown"]))
        self.replacement_combo.setCurrentText(str(self.initial.get("Replacement Type", "Unknown")))
        form.addRow("Replacement Type", self.replacement_combo)

        self.failure_combo = QComboBox()
        self.failure_combo.addItems(import_load_master_choices(
            "Failure_Type_Master.xlsx", "Failure Type",
            ["Water in Vacuum Cup", "Slow Degas", "Degas Minimum High", "Unknown"]))
        self.failure_combo.setCurrentText(str(self.initial.get("_Failure Type", "Unknown")))
        form.addRow("Failure Type", self.failure_combo)

        self.reason_edit = QLineEdit(str(self.initial.get("Reason", "")))
        form.addRow("Reason", self.reason_edit)

        self.comment_edit = QTextEdit()
        self.comment_edit.setPlainText(str(self.initial.get("Comment", "")))
        self.comment_edit.setMaximumHeight(90)
        form.addRow("Comment", self.comment_edit)

        layout.addWidget(form_box)

        buttons = QHBoxLayout()
        save = QPushButton("Save")
        save.setToolTip("Add this row to the current preview. Import is not executed until the Wizard Import button is pressed.")
        save.clicked.connect(self.save_row)
        buttons.addWidget(save)

        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        buttons.addWidget(cancel)
        layout.addLayout(buttons)

    def save_row(self):
        hospital = self.hospital_edit.text().strip()
        serial = self.serial_edit.text().strip()
        if not hospital and not serial:
            QMessageBox.warning(self, APP_NAME, "Hospital Name and Serial Number cannot both be blank.")
            return

        qd = self.date_edit.date()
        self.result_row = {
            "Hospital Name": hospital,
            "Serial Number": serial,
            "Component Type": canonical_component_name(self.component_combo.currentText().strip() or "Degas Module"),
            "Component ID": "",
            "Coil ID": "",
            "Replacement Date": "%04d/%02d/%02d" % (qd.year(), qd.month(), qd.day()),
            "Replacement Type": self.replacement_combo.currentText(),
            "Reason": self.reason_edit.text().strip() or self.failure_combo.currentText(),
            "Comment": self.comment_edit.toPlainText().strip(),
            "_Failure Type": self.failure_combo.currentText(),
            "_Source Row": "Manual",
        }
        self.accept()


class WizardStepGuide(QtWidgets.QFrame):
    def __init__(self, parent=None):
        super(WizardStepGuide, self).__init__(parent)
        self.setFrameShape(QtWidgets.QFrame.Shape.StyledPanel)
        lay = QVBoxLayout(self)
        title = QLabel("<b>Import workflow</b>")
        lay.addWidget(title)
        detail = QLabel(
            "1. Select File — choose xlsx/xlsm/csv/json.<br>"
            "2. Auto Mapping — confirm detected format and columns.<br>"
            "3. Preview — verify converted event rows and adjust choices.<br>"
            "4. Validation — review warnings, skipped rows, and duplicates.<br>"
            "5. Import — write validated rows to Replacement_History.xlsx."
        )
        detail.setWordWrap(True)
        lay.addWidget(detail)


# =====================================
# Version 7.3g Drop-First UI Foundation
# =====================================

def safe_extract_zip(zip_path, destination, selective_extensions=None, flatten=False, watersystem_only=False):
    """Safely extract only the files needed by the application."""
    destination = os.path.abspath(destination)
    os.makedirs(destination, exist_ok=True)
    allowed = {str(x).lower() for x in selective_extensions} if selective_extensions else None
    extracted = []

    with zipfile.ZipFile(zip_path, "r") as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            member = info.filename.replace("\\", "/")
            suffix = os.path.splitext(member)[1].lower()
            if allowed is not None and suffix not in allowed:
                continue

            if watersystem_only and suffix in (".txt", ".log", ".out", ".ar"):
                base_lower = os.path.basename(member).lower()
                if "watersystem" not in base_lower and "water_system" not in base_lower:
                    try:
                        with z.open(info, "r") as probe:
                            if not looks_like_watersystem_bytes(probe.read(65536)):
                                continue
                    except Exception:
                        continue

            if flatten:
                base = os.path.basename(member)
                if not base:
                    continue
                target = os.path.join(destination, base)
                if os.path.exists(target):
                    stem, ext = os.path.splitext(base)
                    token = hashlib.sha1(member.encode("utf-8", errors="ignore")).hexdigest()[:8]
                    target = os.path.join(destination, "%s_%s%s" % (stem, token, ext))
            else:
                target = os.path.abspath(os.path.join(destination, member))
                if not (target == destination or target.startswith(destination + os.sep)):
                    raise ValueError("Unsafe ZIP entry was blocked: %s" % info.filename)

            os.makedirs(os.path.dirname(target), exist_ok=True)
            with z.open(info, "r") as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst, length=1024 * 1024)
            extracted.append(target)

    return destination, extracted


def zip_member_summary(zip_path):
    total = 0
    counts = {}
    with zipfile.ZipFile(zip_path, "r") as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            total += 1
            ext = os.path.splitext(info.filename)[1].lower() or "(none)"
            counts[ext] = counts.get(ext, 0) + 1
    return total, counts


def imported_zip_root(category, source_path):
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    token = hashlib.sha1(os.path.abspath(source_path).encode("utf-8", errors="ignore")).hexdigest()[:8]
    root = os.path.join(ensure_data_folders(), "IZ", category[:8], "%s_%s" % (stamp, token))
    os.makedirs(root, exist_ok=True)
    return root


def find_best_log_folder(extracted_root):
    supported = {".txt", ".log", ".out", ".ar"}
    best_dir, best_count = extracted_root, 0
    for current, _dirs, files in os.walk(extracted_root):
        count = sum(1 for name in files if os.path.splitext(name)[1].lower() in supported)
        if count > best_count:
            best_dir, best_count = current, count
    return best_dir, best_count

def find_result_summary_files(extracted_root):
    matches=[]
    for path in Path(extracted_root).rglob("*"):
        if path.is_file() and path.suffix.lower() in (".xlsx", ".xlsm"):
            low=path.name.lower()
            if "resultsummary" in low or "result_summary" in low:
                matches.append(str(path))
    return sorted(matches)

def extract_history_source_from_zip(zip_path):
    destination = imported_zip_root("ReplacementHistory", zip_path)
    _destination, extracted = safe_extract_zip(
        zip_path,
        destination,
        selective_extensions={".xlsx", ".xlsm", ".csv", ".json"},
        flatten=True,
    )
    candidates = []
    for filename in extracted:
        path = Path(filename)
        low = path.name.lower()
        score = 0
        if "replacement" in low:
            score += 10
        if "history" in low:
            score += 8
        if path.suffix.lower() in (".xlsx", ".xlsm"):
            score += 3
        candidates.append((score, str(path)))
    if not candidates:
        raise ValueError("No supported replacement-history file was found in the ZIP.")
    candidates.sort(key=lambda x: (-x[0], x[1].lower()))
    return candidates[0][1], destination


class DropAreaWidget(QtWidgets.QFrame):
    pathDropped = QtCore.Signal(str)
    clicked = QtCore.Signal()

    def __init__(self, title, subtitle="", accepted_extensions=None,
                 accept_folders=False, parent=None):
        super(DropAreaWidget, self).__init__(parent)
        self.title_text = title
        self.subtitle_text = subtitle
        self.accepted_extensions = [
            str(x).lower() for x in (accepted_extensions or [])
        ]
        self.accept_folders = bool(accept_folders)
        self.current_path = ""
        self.setAcceptDrops(True)
        self.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(78)
        self.setObjectName("DropAreaWidget")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        self.title_label = QLabel(
            "<div style='font-size:14px; font-weight:700;'>%s</div>" % title
        )
        self.title_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.title_label)

        self.subtitle_label = QLabel(subtitle)
        self.subtitle_label.setWordWrap(True)
        self.subtitle_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.subtitle_label)

        self.path_label = QLabel("")
        self.path_label.setWordWrap(True)
        self.path_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.path_label)

        self.set_state("idle")

    def set_compact(self, compact=True, summary=""):
        self.setMinimumHeight(48 if compact else 92)
        self.title_label.setVisible(not compact)
        self.subtitle_label.setVisible(not compact)
        if compact and summary:
            self.path_label.setText(summary)
            self.path_label.setStyleSheet("font-weight:600;")
        else:
            self.path_label.setStyleSheet("")
        self.updateGeometry()

    def expand_drop_area(self):
        self.set_compact(False)
        if self.current_path:
            self.set_path(self.current_path, True)

    def set_state(self, state, message=""):
        styles = {
            "idle": (
                "#f7fbff", "#86a9ca", "#27445e"
            ),
            "hover": (
                "#e6f2ff", "#2f78b7", "#173d5d"
            ),
            "success": (
                "#eaf8ef", "#4eaa6b", "#225c35"
            ),
            "error": (
                "#fff0f0", "#cc5b5b", "#7d2929"
            ),
            "working": (
                "#fff8e6", "#d7a635", "#6d5217"
            ),
        }
        bg, border, fg = styles.get(state, styles["idle"])
        self.setStyleSheet(
            "QFrame#DropAreaWidget {"
            "background:%s; border:2px dashed %s; border-radius:9px;"
            "}"
            "QFrame#DropAreaWidget QLabel { color:%s; background:transparent; }"
            % (bg, border, fg)
        )
        if message:
            self.path_label.setText(message)

    def set_path(self, path, success=True):
        self.current_path = str(path or "")
        if self.current_path:
            self.set_state(
                "success" if success else "error",
                self.current_path
            )
        else:
            self.path_label.clear()
            self.set_state("idle")

    def validate_path(self, path):
        path = str(path or "")
        if not path:
            return False, "No file or folder was detected."
        if os.path.isdir(path):
            if self.accept_folders:
                return True, ""
            return False, "This area accepts files, not folders."
        if not os.path.isfile(path):
            return False, "The dropped path does not exist."
        if self.accepted_extensions:
            ext = os.path.splitext(path)[1].lower()
            if ext not in self.accepted_extensions:
                return False, "Unsupported file type: %s" % (ext or "(none)")
        return True, ""

    def handle_path(self, path):
        ok, message = self.validate_path(path)
        if not ok:
            self.set_state("error", message)
            return
        self.set_path(path, True)
        self.pathDropped.emit(path)

    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            if not self.title_label.isVisible():
                self.expand_drop_area()
            else:
                self.clicked.emit()
        super(DropAreaWidget, self).mouseReleaseEvent(event)


    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self.set_state("hover", "Release to load")
        else:
            event.ignore()

    def dragLeaveEvent(self, event):
        if self.current_path:
            self.set_path(self.current_path, True)
        else:
            self.set_state("idle", "")
        super(DropAreaWidget, self).dragLeaveEvent(event)

    def dropEvent(self, event):
        urls = event.mimeData().urls()
        if not urls:
            self.set_state("error", "No usable path was detected.")
            return
        path = urls[0].toLocalFile()
        self.handle_path(path)
        event.acceptProposedAction()


def classify_dropped_path(path):
    """Lightweight smart recognition used for status guidance."""
    path = str(path or "")
    if os.path.isdir(path):
        return "WaterSystem Folder"
    ext = os.path.splitext(path)[1].lower()
    name = os.path.basename(path).lower()
    if ext == ".zip":
        try:
            with zipfile.ZipFile(path, "r") as z:
                names = [n.lower() for n in z.namelist()]
                # Check Project Backup first: its defining signature is that every payload
                # file lives under a top-level "Data/" folder (see create_project_backup_to).
                # An Update Package's manifest.json can end up nested inside a real backup's
                # Data/ folder too (e.g. left over from a prior Update Package import), so
                # checking manifest.json first would misclassify a genuine backup - only treat
                # a manifest.json as an Update Package when it is NOT inside a Data/ backup.
                if any(n.startswith("data/") for n in names):
                    return "Project Backup"
                if any(n.endswith("manifest.json") for n in names):
                    return "Update Package"
        except Exception:
            pass
        return "ZIP Package"
    if ext in (".xlsx", ".xlsm"):
        if "resultsummary" in name or "result_summary" in name:
            return "ResultSummary"
        if "history" in name or "replacement" in name:
            return "Replacement History"
        return "Excel Data"
    if ext == ".csv":
        return "CSV Data"
    if ext == ".json":
        return "JSON Data"
    return "File"


class RestoreBackupDropDialog(QtWidgets.QDialog):
    def __init__(self, restore_callback, parent=None):
        super(RestoreBackupDropDialog, self).__init__(parent)
        self.restore_callback = restore_callback
        self.setWindowTitle("Restore Project Backup")
        self.resize(760, 390)
        apply_servicehub_dialog_style(self)
        layout = QVBoxLayout(self)

        title = QLabel(
            "<div style='font-size:22px; font-weight:bold;'>Restore Project Backup</div>"
            "<div style='color:#667;'>Drop a project backup ZIP below. "
            "The package type is checked before restore.</div>"
        )
        title.setWordWrap(True)
        layout.addWidget(title)

        self.drop_area = DropAreaWidget(
            "Drop Project Backup ZIP Here",
            "ZIP only — click this area when drag and drop is not available",
            accepted_extensions=[".zip"],
        )
        self.drop_area.pathDropped.connect(self.handle_path)
        self.drop_area.clicked.connect(self.select_path)
        layout.addWidget(self.drop_area)

        self.detected_label = QLabel("Detected: —")
        self.detected_label.setWordWrap(True)
        layout.addWidget(self.detected_label)

        buttons = QHBoxLayout()
        self.restore_button = QPushButton("Restore")
        self.restore_button.setEnabled(False)
        self.restore_button.clicked.connect(self.execute_restore)
        buttons.addWidget(self.restore_button)
        close = QPushButton("Close")
        close.clicked.connect(self.reject)
        buttons.addWidget(close)
        layout.addLayout(buttons)

        self.selected_path = ""

    def select_path(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Select Project Backup ZIP", "", "Backup ZIP (*.zip)"
        )
        if path:
            self.drop_area.handle_path(path)

    def handle_path(self, path):
        detected = classify_dropped_path(path)
        self.detected_label.setText("<b>Detected:</b> %s" % detected)
        self.selected_path = path
        is_backup = detected == "Project Backup"
        self.restore_button.setEnabled(is_backup)
        if not is_backup:
            self.drop_area.set_state(
                "error",
                "This ZIP does not look like a Project Backup."
            )

    def execute_restore(self):
        if not self.selected_path:
            return
        self.accept()
        self.restore_callback(self.selected_path)

class ReplacementImportWizard(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super(ReplacementImportWizard, self).__init__(parent)
        self.setWindowTitle("Import Replacement History")
        self.resize(1180, 760)
        self.source_path = ""
        self.headers = []
        self.rows = []
        self.legacy = False
        self.mapping_boxes = {}
        self.converted = []
        self.warnings = []
        self.current_step = 1
        self.preview_dirty = False
        self._ui()

    def _ui(self):
        layout = QVBoxLayout(self)

        title = QLabel("<div style='font-size:22px; font-weight:bold;'>Replacement History Import Wizard</div>"
                       "<div style='color:#666;'>Select → Auto Mapping → Preview → Validation → Import</div>")
        title.setWordWrap(True)
        layout.addWidget(title)

        self.guide = WizardStepGuide()
        layout.addWidget(self.guide)

        self.steps = QLabel("① Select File   →   ② Mapping   →   ③ Preview   →   ④ Validation   →   ⑤ Import")
        self.steps.setStyleSheet("font-weight:600; color:#365a7a; padding:6px;")
        layout.addWidget(self.steps)

        state_box = QtWidgets.QGroupBox("Workflow Status")
        state_layout = QVBoxLayout(state_box)
        self.current_step_label = QLabel("<b>Current Step:</b> Select a source file")
        self.next_action_label = QLabel("<b>Next Action:</b> Click Select File")
        self.change_state_label = QLabel("<b>Status:</b> No pending changes")
        for w in (self.current_step_label, self.next_action_label, self.change_state_label):
            w.setWordWrap(True)
            state_layout.addWidget(w)
        layout.addWidget(state_box)

        self.source_drop_area = DropAreaWidget(
            "Drop Replacement History or ZIP Here",
            "ZIP / XLSX / XLSM / CSV / JSON — ZIP is opened automatically",
            accepted_extensions=[".zip", ".xlsx", ".xlsm", ".csv", ".json"],
        )
        self.source_drop_area.pathDropped.connect(self.handle_source_path)
        self.source_drop_area.clicked.connect(self.select_file)
        layout.addWidget(self.source_drop_area)

        self.path_edit = QLineEdit()
        self.path_edit.setReadOnly(True)
        self.path_edit.setPlaceholderText("No replacement-history source loaded")
        layout.addWidget(self.path_edit)

        defaults = QHBoxLayout()
        self.component_combo = QComboBox()
        self.component_combo.addItems(["Degas Module", "Degas Module"])
        defaults.addWidget(QLabel("Default Component Type"))
        defaults.addWidget(self.component_combo)

        self.replacement_combo = QComboBox()
        self.replacement_combo.addItems(import_load_master_choices(
            "Replacement_Type_Master.xlsx", "Replacement Type",
            ["Failure", "Scheduled Replacement", "Hospital Request", "Company Instruction", "Unknown"]))
        self.replacement_combo.setCurrentText("Unknown")
        defaults.addWidget(QLabel("Default Replacement Type"))
        defaults.addWidget(self.replacement_combo)

        self.failure_combo = QComboBox()
        self.failure_combo.addItems(import_load_master_choices(
            "Failure_Type_Master.xlsx", "Failure Type",
            ["Water in Vacuum Cup", "Slow Degas", "Degas Minimum High", "Unknown"]))
        self.failure_combo.setCurrentText("Unknown")
        defaults.addWidget(QLabel("Default Failure Type"))
        defaults.addWidget(self.failure_combo)
        layout.addLayout(defaults)

        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel("Legacy History interpretation"))
        self.legacy_mode_combo = QComboBox()
        self.legacy_mode_combo.addItems([
            "All detected dates are replacement dates",
            "Review each converted event in Preview"
        ])
        self.legacy_mode_combo.setToolTip("The uploaded legacy sample contains multiple hospitals and systems. Each non-empty date cell becomes one event.")
        mode_row.addWidget(self.legacy_mode_combo, 1)
        layout.addLayout(mode_row)

        self.tabs = QtWidgets.QTabWidget()
        layout.addWidget(self.tabs, 1)

        map_page = QWidget()
        map_layout = QVBoxLayout(map_page)
        self.mapping_info = QLabel("Select a file to detect columns.")
        self.mapping_info.setWordWrap(True)
        map_layout.addWidget(self.mapping_info)
        self.mapping_form = QtWidgets.QFormLayout()
        map_layout.addLayout(self.mapping_form)
        self.tabs.addTab(map_page, "Mapping")

        preview_page = QWidget()
        preview_layout = QVBoxLayout(preview_page)
        filter_row = QHBoxLayout()
        filter_row.addWidget(QLabel("Hospital Filter"))
        self.hospital_filter = QComboBox()
        self.hospital_filter.addItem("All")
        self.hospital_filter.currentTextChanged.connect(self.apply_preview_filters)
        filter_row.addWidget(self.hospital_filter)

        filter_row.addWidget(QLabel("Serial Filter"))
        self.serial_filter = QComboBox()
        self.serial_filter.addItem("All")
        self.serial_filter.currentTextChanged.connect(self.apply_preview_filters)
        filter_row.addWidget(self.serial_filter)
        filter_row.addStretch(1)
        preview_layout.addLayout(filter_row)

        preview_toolbar = QHBoxLayout()
        add_manual = QPushButton("Add Manually")
        add_manual.setToolTip("Add a replacement event by hand using Master-linked dropdowns.")
        add_manual.clicked.connect(self.add_manual_row)
        preview_toolbar.addWidget(add_manual)

        edit_row = QPushButton("Edit Selected")
        edit_row.setToolTip("Edit the currently selected preview row.")
        edit_row.clicked.connect(self.edit_selected_row)
        preview_toolbar.addWidget(edit_row)

        remove_row = QPushButton("Remove Selected")
        remove_row.setToolTip("Remove the selected row from this import preview.")
        remove_row.clicked.connect(self.remove_selected_row)
        preview_toolbar.addWidget(remove_row)
        preview_toolbar.addStretch(1)
        preview_layout.addLayout(preview_toolbar)

        selected_box = QtWidgets.QGroupBox("Selected Record")
        selected_layout = QVBoxLayout(selected_box)
        self.selected_record_label = QLabel("No row selected.")
        self.selected_record_label.setWordWrap(True)
        self.selected_record_label.setStyleSheet("padding:6px; background:#eef5fc; border-radius:5px;")
        selected_layout.addWidget(self.selected_record_label)
        preview_layout.addWidget(selected_box)

        self.preview_table = QtWidgets.QTableWidget()
        self.preview_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        self.preview_table.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.SingleSelection)
        self.preview_table.itemSelectionChanged.connect(self.update_selected_record)
        self.preview_table.setAlternatingRowColors(True)
        self.preview_table.setStyleSheet("QTableWidget::item:selected { background:#2f78b7; color:white; } QTableWidget { gridline-color:#d5dde5; }")
        preview_layout.addWidget(self.preview_table)
        self.tabs.addTab(preview_page, "Preview")

        validation_page = QWidget()
        validation_layout = QVBoxLayout(validation_page)
        self.validation_text = QtWidgets.QTextEdit()
        self.validation_text.setReadOnly(True)
        validation_layout.addWidget(self.validation_text)
        self.tabs.addTab(validation_page, "Validation")

        buttons = QHBoxLayout()
        self.refresh_button = QPushButton("Refresh Preview")
        self.refresh_button.setToolTip("Apply the selected mapping/default choices and rebuild the preview.")
        self.refresh_button.clicked.connect(self.refresh_preview)
        buttons.addWidget(self.refresh_button)

        self.import_button = QPushButton("Import")
        self.import_button.setEnabled(False)
        self.import_button.clicked.connect(self.do_import)
        buttons.addWidget(self.import_button)

        close = QPushButton("Close")
        close.clicked.connect(self.reject)
        buttons.addWidget(close)
        layout.addLayout(buttons)

    def select_file(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Select Replacement History", "",
            "Supported (*.xlsx *.xlsm *.csv *.json);;"
            "Excel (*.xlsx *.xlsm);;CSV (*.csv);;JSON (*.json)"
        )
        if path:
            self.source_drop_area.handle_path(path)

    def handle_source_path(self, path):
        try:
            self.source_drop_area.set_state("working", "Reading and detecting format...")
            QtWidgets.QApplication.setOverrideCursor(
                QtCore.Qt.CursorShape.WaitCursor
            )
            original_path = path
            extracted_note = ""
            if os.path.splitext(path)[1].lower() == ".zip":
                path, _extracted_root = extract_history_source_from_zip(path)
                extracted_note = "\nInner file: %s" % path
            self.headers, self.rows, self.legacy = import_read_source(path)
            self.source_path = path
            self.path_edit.setText(original_path + extracted_note)
            self.build_mapping()
            self.set_workflow_state(
                2,
                "File dropped and format detected.",
                "Review Auto Mapping, then click Refresh Preview.",
                "Source loaded"
            )
            self.refresh_preview()
            detected = (
                "Legacy multi-hospital Replacement History"
                if self.legacy else classify_dropped_path(path)
            )
            self.source_drop_area.set_state(
                "success",
                "Detected: %s\n%s" % (detected, original_path)
            )
            self.source_drop_area.set_compact(
                True, "%s Loaded — click to change" % detected
            )
        except Exception:
            self.source_drop_area.set_state(
                "error",
                "The source could not be loaded."
            )
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())
        finally:
            QtWidgets.QApplication.restoreOverrideCursor()


    def clear_mapping_form(self):
        while self.mapping_form.rowCount():
            self.mapping_form.removeRow(0)
        self.mapping_boxes = {}

    def build_mapping(self):
        self.clear_mapping_form()
        mapping = import_auto_mapping(self.headers)
        options = ["(Not mapped)"] + self.headers
        for target in REPLACEMENT_IMPORT_FIELDS:
            combo = QComboBox()
            combo.addItems(options)
            index = mapping.get(target, -1)
            combo.setCurrentIndex(index + 1 if index >= 0 else 0)
            self.mapping_boxes[target] = combo
            self.mapping_form.addRow(target, combo)
        if self.legacy:
            date_columns = max(0, len(self.headers) - 2)
            self.mapping_info.setText(
                "<b>Detected format: Legacy multi-hospital History.xlsx</b><br>"
                "Column A = Serial Number<br>"
                "Column B = Hospital Name<br>"
                "Column C onward = replacement date history (%d date column(s))<br>"
                "Each non-empty date cell is expanded into one preview event. Placeholder rows such as NA / Not selected are skipped."
                % date_columns
            )
        else:
            mapped = sum(1 for i in mapping.values() if i >= 0)
            self.mapping_info.setText("Detected %d column(s). Auto-mapped %d of %d target fields." %
                                      (len(self.headers), mapped, len(REPLACEMENT_IMPORT_FIELDS)))

    def current_mapping(self):
        mapping = {}
        for target, combo in self.mapping_boxes.items():
            mapping[target] = combo.currentIndex() - 1
        return mapping

    def refresh_preview(self):
        if not self.rows:
            return
        try:
            QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.CursorShape.WaitCursor)
            if self.legacy:
                converted, warnings = import_convert_legacy_rows(
                    self.headers, self.rows,
                    self.component_combo.currentText(),
                    self.replacement_combo.currentText(),
                    self.failure_combo.currentText())
            else:
                converted, warnings = import_convert_generic_rows(
                    self.headers, self.rows, self.current_mapping(),
                    self.component_combo.currentText(),
                    self.replacement_combo.currentText(),
                    self.failure_combo.currentText())
            self.converted = converted
            self.warnings = warnings
            self.populate_preview()
            self.populate_validation()
            self.preview_dirty = False
            self.import_button.setEnabled(bool(converted))
            self.set_workflow_state(4, "Validation ready.", "Review Validation, then click Import.", "Ready to import" if converted else "No valid rows")
            self.tabs.setCurrentIndex(1)
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())
        finally:
            QtWidgets.QApplication.restoreOverrideCursor()

    def add_manual_row(self):
        dlg = ReplacementManualEntryDialog(self)
        if dlg.exec() == QtWidgets.QDialog.DialogCode.Accepted and dlg.result_row:
            self.converted.append(dlg.result_row)
            self.populate_preview()
            self.populate_validation()
            self.import_button.setEnabled(True)
            self.tabs.setCurrentIndex(1)

    def edit_selected_row(self):
        row_index = self.selected_source_index()
        if row_index < 0 or row_index >= len(self.converted):
            QMessageBox.information(self, APP_NAME, "Select one preview row first. The selected row is highlighted in blue and summarized above the table.")
            return
        dlg = ReplacementManualEntryDialog(self, self.converted[row_index])
        if dlg.exec() == QtWidgets.QDialog.DialogCode.Accepted and dlg.result_row:
            self.converted[row_index] = dlg.result_row
            self.populate_preview()
            self.populate_validation()
            self.preview_table.selectRow(row_index)

    def remove_selected_row(self):
        row_index = self.selected_source_index()
        if row_index < 0 or row_index >= len(self.converted):
            QMessageBox.information(self, APP_NAME, "Select one preview row first. The selected row is highlighted in blue and summarized above the table.")
            return
        row = self.converted[row_index]
        answer = QMessageBox.question(self, APP_NAME, "Remove this preview row?\n\nHospital: %s\nSerial: %s\nDate: %s\nReplacement Type: %s" % (row.get("Hospital Name", ""), row.get("Serial Number", ""), row.get("Replacement Date", ""), row.get("Replacement Type", "")), QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes:
            return
        del self.converted[row_index]
        self.populate_preview()
        self.populate_validation()
        self.import_button.setEnabled(bool(self.converted))

    def refresh_filter_choices(self):
        current_h = self.hospital_filter.currentText() if hasattr(self, "hospital_filter") else "All"
        current_s = self.serial_filter.currentText() if hasattr(self, "serial_filter") else "All"
        hospitals = sorted(set(str(r.get("Hospital Name", "")).strip() for r in self.converted if str(r.get("Hospital Name", "")).strip()))
        serials = sorted(set(str(r.get("Serial Number", "")).strip() for r in self.converted if str(r.get("Serial Number", "")).strip()))
        self.hospital_filter.blockSignals(True)
        self.serial_filter.blockSignals(True)
        self.hospital_filter.clear(); self.hospital_filter.addItem("All"); self.hospital_filter.addItems(hospitals)
        self.serial_filter.clear(); self.serial_filter.addItem("All"); self.serial_filter.addItems(serials)
        self.hospital_filter.setCurrentText(current_h if current_h in hospitals else "All")
        self.serial_filter.setCurrentText(current_s if current_s in serials else "All")
        self.hospital_filter.blockSignals(False)
        self.serial_filter.blockSignals(False)

    def apply_preview_filters(self, *args):
        self.populate_preview(refresh_filters=False)

    def filtered_source_indices(self):
        hospital = self.hospital_filter.currentText() if hasattr(self, "hospital_filter") else "All"
        serial = self.serial_filter.currentText() if hasattr(self, "serial_filter") else "All"
        result = []
        for i, row in enumerate(self.converted):
            if hospital != "All" and str(row.get("Hospital Name", "")) != hospital:
                continue
            if serial != "All" and str(row.get("Serial Number", "")) != serial:
                continue
            result.append(i)
        return result

    def populate_preview(self, refresh_filters=True):
        if refresh_filters:
            self.refresh_filter_choices()

        headers = ["Hospital Name", "Serial Number", "Component Type", "Replacement Date",
                   "Replacement Type", "Failure Type", "Reason", "Comment", "Source Row"]
        self.preview_table.clear()
        self.preview_table.setColumnCount(len(headers))
        self.preview_table.setHorizontalHeaderLabels(headers)

        self.displayed_indices = self.filtered_source_indices()[:500]
        self.preview_table.setRowCount(len(self.displayed_indices))

        replacement_choices = import_load_master_choices(
            "Replacement_Type_Master.xlsx", "Replacement Type",
            ["Failure", "Scheduled Replacement", "Hospital Request", "Company Instruction", "Unknown"])
        failure_choices = import_load_master_choices(
            "Failure_Type_Master.xlsx", "Failure Type",
            ["Water in Vacuum Cup", "Slow Degas", "Degas Minimum High", "Unknown"])
        component_choices = ["Degas Module"]

        for display_row, source_index in enumerate(self.displayed_indices):
            row = self.converted[source_index]
            values = [
                row.get("Hospital Name", ""), row.get("Serial Number", ""), None,
                row.get("Replacement Date", ""), None, None,
                row.get("Reason", ""), row.get("Comment", ""), row.get("_Source Row", "")
            ]
            for c, value in enumerate(values):
                if value is not None:
                    self.preview_table.setItem(display_row, c, QtWidgets.QTableWidgetItem(str(value)))

            comp = QComboBox()
            comp.addItems(component_choices)
            comp.setCurrentText(str(row.get("Component Type", "Degas Module")))
            comp.currentTextChanged.connect(
                lambda value, idx=source_index: self.preview_choice_changed(idx, "Component Type", value))
            self.preview_table.setCellWidget(display_row, 2, comp)

            repl = QComboBox()
            repl.addItems(replacement_choices)
            repl.setCurrentText(str(row.get("Replacement Type", "Unknown")))
            repl.currentTextChanged.connect(
                lambda value, idx=source_index: self.preview_choice_changed(idx, "Replacement Type", value))
            self.preview_table.setCellWidget(display_row, 4, repl)

            fail = QComboBox()
            fail.addItems(failure_choices)
            fail.setCurrentText(str(row.get("_Failure Type", "Unknown")))
            fail.currentTextChanged.connect(
                lambda value, idx=source_index: self.preview_choice_changed(idx, "_Failure Type", value))
            self.preview_table.setCellWidget(display_row, 5, fail)

        self.preview_table.resizeColumnsToContents()
        self.preview_table.setColumnWidth(7, max(240, self.preview_table.columnWidth(7)))
        self.update_selected_record()
        self.set_workflow_state(
            3,
            "Review converted rows and adjust dropdown values if needed.",
            "Import is available whenever at least one valid row exists."
        )

    def selected_source_index(self):
        display_row = self.preview_table.currentRow()
        if display_row < 0 or display_row >= len(getattr(self, "displayed_indices", [])):
            return -1
        return self.displayed_indices[display_row]

    def preview_choice_changed(self, source_index, key, value):
        if 0 <= source_index < len(self.converted):
            self.converted[source_index][key] = value
            if key == "_Failure Type" and not self.converted[source_index].get("Reason"):
                self.converted[source_index]["Reason"] = value
            self.preview_dirty = True
            self.populate_validation()
            self.change_state_label.setText("<b>Status:</b> Preview changed and validation refreshed.")
            self.import_button.setEnabled(bool(self.converted))

    def update_selected_record(self):
        source_index = self.selected_source_index()
        if source_index < 0:
            self.selected_record_label.setText("No row selected. Click a row before Edit Selected or Remove Selected.")
            return
        row = self.converted[source_index]
        self.selected_record_label.setText(
            "<b>Target record</b><br>"
            "Hospital: %s &nbsp;&nbsp; Serial: %s<br>"
            "Component: %s &nbsp;&nbsp; Date: %s<br>"
            "Replacement Type: %s &nbsp;&nbsp; Failure Type: %s"
            % (
                row.get("Hospital Name", ""), row.get("Serial Number", ""),
                row.get("Component Type", ""), row.get("Replacement Date", ""),
                row.get("Replacement Type", ""), row.get("_Failure Type", "")
            )
        )

    def set_workflow_state(self, step, current, next_action, status=None):
        self.current_step = step
        self.current_step_label.setText("<b>Current Step:</b> %s" % current)
        self.next_action_label.setText("<b>Next Action:</b> %s" % next_action)
        if status is not None:
            self.change_state_label.setText("<b>Status:</b> %s" % status)

    def populate_validation(self):
        mapped_count = len(self.converted)
        warning_count = len(self.warnings)
        replacement_counts = {}
        failure_counts = {}
        for row in self.converted:
            replacement_counts[row.get("Replacement Type", "Unknown")] = replacement_counts.get(row.get("Replacement Type", "Unknown"), 0) + 1
            failure_counts[row.get("_Failure Type", "Unknown")] = failure_counts.get(row.get("_Failure Type", "Unknown"), 0) + 1
        lines = [
            "Import validation",
            "",
            "Source: %s" % (self.source_path or "(none)"),
            "Detected layout: %s" % ("Legacy History.xlsx" if self.legacy else "Header-based table"),
            "Converted / manual records: %d" % mapped_count,
            "Unique systems: %d" % len(set((str(r.get("Hospital Name", "")), str(r.get("Serial Number", ""))) for r in self.converted)),
            "Warnings / skipped rows: %d" % warning_count,
            "",
            "Replacement Type:",
        ]
        for k, v in sorted(replacement_counts.items()):
            lines.append("  %s: %d" % (k, v))
        lines.append("")
        lines.append("Failure Type:")
        for k, v in sorted(failure_counts.items()):
            lines.append("  %s: %d" % (k, v))
        if self.warnings:
            lines += ["", "Warnings:"] + ["- " + x for x in self.warnings[:100]]
        self.validation_text.setPlainText("\n".join(lines))

    def do_import(self):
        if not self.converted:
            return
        answer = QMessageBox.question(
            self, APP_NAME,
            "Import %d converted record(s) into Replacement_History.xlsx?" % len(self.converted),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            progress = QtWidgets.QProgressDialog("Importing replacement history...", "Cancel", 0, 100, self)
            progress.setWindowTitle("Medical Reliability Platform")
            progress.setWindowModality(QtCore.Qt.WindowModality.WindowModal)
            progress.setValue(10)
            QtWidgets.QApplication.processEvents()

            path, added, duplicates = import_commit_replacement_rows(self.converted)
            progress.setValue(100)
            QtWidgets.QApplication.processEvents()
            progress.close()

            QMessageBox.information(
                self, APP_NAME,
                "Import complete.\n\n"
                "Converted: %d\n"
                "Imported: %d\n"
                "Duplicates skipped: %d\n"
                "Warnings/skipped: %d\n\n"
                "Saved to:\n%s\n\nNext steps:\n1. Close this wizard.\n2. Run Runtime Reconstruction.\n3. Run Explainable Reliability.\n4. Review the Dashboard." %
                (len(self.converted), added, duplicates, len(self.warnings), path)
            )
            self.accept()
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())


# =====================================
# Version 7.3 RC: Session / Scope / Update Foundation
# =====================================

SESSION_SCHEMA_VERSION = "1.0"
UPDATE_FOUNDATION_VERSION = "1.0"
DASHBOARD_SCOPE_OPTIONS = [
    "Hospital",
    "Selected Hospitals",
    "Country",
    "Region",
    "Distributor",
    "All Hospitals",
]

def rc_settings_folder():
    path = os.path.join(ensure_data_folders(), "settings")
    os.makedirs(path, exist_ok=True)
    return path

def rc_session_path():
    return os.path.join(rc_settings_folder(), "session_state.json")

def rc_read_json(path, default=None):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {} if default is None else default

def rc_write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, default=str)
    os.replace(tmp, path)

def rc_update_folder():
    path = os.path.join(ensure_data_folders(), "Update")
    os.makedirs(path, exist_ok=True)
    return path

def rc_update_log_path():
    return os.path.join(rc_update_folder(), "update_history.json")

def rc_file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            block = f.read(1024 * 1024)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def rc_workflow_state_path():
    return os.path.join(rc_settings_folder(), "workflow_state.json")

def rc_get_workflow_state():
    state = rc_read_json(rc_workflow_state_path(), {})
    return state if isinstance(state, dict) else {}

def rc_mark_workflow(step):
    state = rc_get_workflow_state()
    state[step] = dt.datetime.now().isoformat(timespec="seconds")
    rc_write_json(rc_workflow_state_path(), state)

class UpdateFoundationDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super(UpdateFoundationDialog, self).__init__(parent)
        self.setWindowTitle("Module Update Foundation")
        self.resize(920, 680)
        self.package_path = ""
        self.manifest = {}
        self.entries = []
        self._ui()

    def _ui(self):
        apply_servicehub_dialog_style(self)
        layout = QVBoxLayout(self)
        title = QLabel(
            "<div style='font-size:22px; font-weight:bold;'>Module Update Foundation</div>"
            "<div style='color:#667;'>Select ZIP → Inspect Manifest → Dry Run → Backup/Staging</div>"
        )
        title.setWordWrap(True)
        layout.addWidget(title)

        self.update_drop_area = DropAreaWidget(
            "Drop Update ZIP Here",
            "ZIP with manifest.json — click this area as a fallback",
            accepted_extensions=[".zip"],
        )
        self.update_drop_area.pathDropped.connect(self.handle_package_path)
        self.update_drop_area.clicked.connect(self.select_package)
        layout.addWidget(self.update_drop_area)

        self.path_box = QLineEdit()
        self.path_box.setReadOnly(True)
        self.path_box.setPlaceholderText("No update package loaded")
        layout.addWidget(self.path_box)

        self.status_label = QLabel("No package selected.")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        self.details = QTextEdit()
        self.details.setReadOnly(True)
        layout.addWidget(self.details, 1)

        buttons = QHBoxLayout()
        self.dry_run_button = QPushButton("Dry Run")
        self.dry_run_button.setEnabled(False)
        self.dry_run_button.clicked.connect(self.dry_run)
        buttons.addWidget(self.dry_run_button)

        self.stage_button = QPushButton("Backup and Stage")
        self.stage_button.setEnabled(False)
        self.stage_button.clicked.connect(self.stage_update)
        buttons.addWidget(self.stage_button)

        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        buttons.addWidget(close)
        layout.addLayout(buttons)

    def select_package(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Select Update ZIP", "", "Update ZIP (*.zip)"
        )
        if path:
            self.update_drop_area.handle_path(path)

    def handle_package_path(self, path):
        try:
            self.update_drop_area.set_state(
                "working", "Reading manifest and package contents..."
            )
            with zipfile.ZipFile(path, "r") as z:
                names = z.namelist()
                manifest_name = next(
                    (n for n in names if n.lower().endswith("manifest.json")),
                    None
                )
                if not manifest_name:
                    raise ValueError("manifest.json was not found in the ZIP.")
                self.manifest = json.loads(
                    z.read(manifest_name).decode("utf-8-sig")
                )
                self.entries = names

            self.package_path = path
            self.path_box.setText(path)
            module = str(self.manifest.get("module", ""))
            target = str(
                self.manifest.get(
                    "target_version",
                    self.manifest.get("version", "")
                )
            )
            compatible = (
                "WaterSystem" in module
                or "Water System" in module
                or module in ("", "WaterSystem Analyzer")
            )
            self.status_label.setText(
                "<b>Detected:</b> Update Package<br>"
                "<b>Package:</b> %s<br>"
                "<b>Target:</b> %s<br>"
                "<b>Compatibility:</b> %s"
                % (
                    module or "(not specified)",
                    target or "(not specified)",
                    "OK" if compatible else "Review required",
                )
            )
            self.details.setPlainText(
                json.dumps(self.manifest, ensure_ascii=False, indent=2)
            )
            self.dry_run_button.setEnabled(True)
            self.stage_button.setEnabled(False)
            self.update_drop_area.set_state(
                "success",
                "Detected: Update Package\n%s" % path
            )
        except Exception:
            self.package_path = ""
            self.dry_run_button.setEnabled(False)
            self.stage_button.setEnabled(False)
            self.update_drop_area.set_state(
                "error",
                "Invalid Update ZIP or manifest.json was not found."
            )
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())


    def dry_run(self):
        if not self.package_path:
            return
        protected = []
        allowed = []
        for name in self.entries:
            low = name.lower()
            if any(token in low for token in ["rawlogs/", "replacement_history.xlsx", "resultsummary"]):
                protected.append(name)
            else:
                allowed.append(name)
        lines = [
            "Dry Run Result",
            "",
            "Package: %s" % os.path.basename(self.package_path),
            "SHA256: %s" % rc_file_sha256(self.package_path),
            "Files in package: %d" % len(self.entries),
            "Allowed/stageable: %d" % len(allowed),
            "Protected/rejected: %d" % len(protected),
            "",
            "Protected items:",
        ] + ["- " + x for x in protected[:100]]
        self.details.setPlainText("\n".join(lines))
        self.stage_button.setEnabled(len(protected) == 0)
        self.status_label.setText(
            "<b>Dry Run:</b> %s" % ("PASS — ready for backup and staging." if not protected else "BLOCKED — protected user data detected.")
        )

    def stage_update(self):
        if not self.package_path:
            return
        try:
            stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            update_root = rc_update_folder()
            staging = os.path.join(update_root, "Staging", stamp)
            os.makedirs(staging, exist_ok=True)

            # Safety copy of current source package metadata and current Data location.
            backup_dir = os.path.join(update_root, "PreUpdateBackup", stamp)
            os.makedirs(backup_dir, exist_ok=True)
            session = rc_read_json(rc_session_path(), {})
            rc_write_json(os.path.join(backup_dir, "session_state.json"), session)
            rc_write_json(os.path.join(backup_dir, "current_version.json"), {
                "software_version": APP_VERSION,
                "algorithm_version": ALGORITHM_VERSION,
                "saved_at": dt.datetime.now().isoformat(timespec="seconds"),
            })

            with zipfile.ZipFile(self.package_path, "r") as z:
                z.extractall(staging)

            pending = {
                "package_path": self.package_path,
                "staging_path": staging,
                "manifest": self.manifest,
                "created_at": dt.datetime.now().isoformat(timespec="seconds"),
                "status": "STAGED",
                "requires_external_updater": bool(self.manifest.get("requires_restart", True)),
            }
            pending_path = os.path.join(update_root, "pending_update.json")
            rc_write_json(pending_path, pending)

            history = rc_read_json(rc_update_log_path(), [])
            if not isinstance(history, list):
                history = []
            history.append(pending)
            rc_write_json(rc_update_log_path(), history[-200:])

            self.status_label.setText("<b>Staged successfully.</b> Program replacement will be handled by the external updater/restart phase.")
            self.details.setPlainText(
                "Update staged.\n\nStaging:\n%s\n\nPending instruction:\n%s\n\nNo Raw Log, ResultSummary, or Replacement History was overwritten."
                % (staging, pending_path)
            )
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())





class WorkflowAssistantCard(QtWidgets.QFrame):
    actionRequested = QtCore.Signal(str)

    def __init__(self, parent=None):
        super(WorkflowAssistantCard, self).__init__(parent)
        self.setObjectName("WorkflowAssistantCard")
        self.setStyleSheet(
            "QFrame#WorkflowAssistantCard { background:#ffffff; border:1px solid #cbd7e3; border-radius:10px; }"
        )
        self._steps = []
        self._buttons = {}
        self.recommended_key = ""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        title = QLabel(
            "<div style='font-size:18px; font-weight:700;'>Forecast Workflow</div>"
            "<div style='color:#667;'>Follow the numbered actions from top to bottom.</div>"
        )
        title.setWordWrap(True)
        layout.addWidget(title)

        self.progress = QtWidgets.QProgressBar()
        self.progress.setRange(0, 7)
        layout.addWidget(self.progress)

        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet(
            "padding:9px; background:#eef6fc; border:1px solid #bfd4e5; border-radius:6px;"
        )
        layout.addWidget(self.status_label)

        self.next_label = QLabel("")
        self.next_label.setWordWrap(True)
        self.next_label.setStyleSheet(
            "padding:9px; background:#fff8e5; border:1px solid #e4c978; border-radius:6px;"
        )
        layout.addWidget(self.next_label)

        self.steps_box = QtWidgets.QGroupBox("Actions")
        self.steps_layout = QVBoxLayout(self.steps_box)
        self.steps_layout.setSpacing(6)
        layout.addWidget(self.steps_box)

        self.primary_button = QPushButton("Run Recommended Action")
        self.primary_button.setMinimumHeight(36)
        self.primary_button.setStyleSheet(
            "QPushButton { background:#2f78b7; color:white; font-weight:700; border-radius:6px; }"
        )
        self.primary_button.clicked.connect(self._emit_recommended)
        layout.addWidget(self.primary_button)

    def configure_steps(self, steps):
        self._steps = list(steps)
        while self.steps_layout.count():
            item = self.steps_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        self._buttons = {}
        for number, key, title in self._steps:
            button = QPushButton("%d. %s" % (number, title))
            button.setMinimumHeight(31)
            button.clicked.connect(
                lambda _checked=False, k=key, b=button: self._emit_step(k, b)
            )
            self.steps_layout.addWidget(button)
            self._buttons[key] = button

    def _emit_step(self, key, button):
        original = button.text()
        button.setText("Opening...")
        QtWidgets.QApplication.processEvents()
        self.actionRequested.emit(key)
        if button.text() == "Opening...":
            button.setText(original)

    def _title_for_key(self, key):
        for _number, item_key, title in self._steps:
            if item_key == key:
                return title
        return ""

    def update_state(self, completed_keys, recommended_key, current_status, reason):
        completed_keys = set(completed_keys or [])
        self.recommended_key = recommended_key or ""
        completed_count = len([k for _, k, _ in self._steps if k in completed_keys])
        self.progress.setValue(completed_count)
        self.progress.setFormat("%d / %d Complete" % (completed_count, len(self._steps)))

        self.status_label.setText(
            "<div style='font-size:11px; color:#657786;'>CURRENT STATUS</div>"
            "<div style='font-size:16px; font-weight:700;'>%s</div>" % current_status
        )
        self.next_label.setText(
            "<div style='font-size:11px; color:#7a6a39;'>RECOMMENDED NEXT STEP</div>"
            "<div style='font-size:15px; font-weight:700;'>%s</div>"
            "<div style='margin-top:4px;'>%s</div>" %
            (self._title_for_key(recommended_key) if recommended_key else "Review current results", reason or "")
        )

        for _number, key, title in self._steps:
            button = self._buttons[key]
            button.setEnabled(True)
            if key in completed_keys:
                button.setText("✓ %s" % title)
                button.setStyleSheet("QPushButton { text-align:left; background:#eaf8ef; border:1px solid #82bb91; }")
            elif key == recommended_key:
                button.setText("▶ %s" % title)
                button.setStyleSheet("QPushButton { text-align:left; background:#fff0b8; border:2px solid #d59b18; font-weight:700; }")
            else:
                button.setText("□ %s" % title)
                button.setStyleSheet("QPushButton { text-align:left; background:#f3f5f7; border:1px solid #cfd6dc; color:#56616b; }")

        self.primary_button.setEnabled(bool(recommended_key))
        self.primary_button.setText(
            "Run: %s" % self._title_for_key(recommended_key)
            if recommended_key else "No Pending Recommended Action"
        )

    def _emit_recommended(self):
        if self.recommended_key:
            self.primary_button.setText("Opening: %s..." % self._title_for_key(self.recommended_key))
            QtWidgets.QApplication.processEvents()
            self.actionRequested.emit(self.recommended_key)



class ProjectSummaryCard(QtWidgets.QFrame):
    changeSourceRequested = QtCore.Signal()

    def __init__(self, parent=None):
        super(ProjectSummaryCard, self).__init__(parent)
        self.setObjectName("ProjectSummaryCard")
        self.setStyleSheet(
            "QFrame#ProjectSummaryCard {"
            "background:#ffffff; border:1px solid #cbd7e3; border-radius:9px;"
            "}"
        )
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(5)

        self.status_label = QLabel("○ No source loaded")
        self.status_label.setStyleSheet("font-size:13px; font-weight:700; color:#596775;")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        self.name_label = QLabel("")
        self.name_label.setStyleSheet("font-size:16px; font-weight:700; color:#244867;")
        self.name_label.setWordWrap(True)
        layout.addWidget(self.name_label)

        self.detail_label = QLabel("")
        self.detail_label.setStyleSheet("font-size:12px; color:#667786;")
        self.detail_label.setWordWrap(True)
        layout.addWidget(self.detail_label)

        self.change_button = QPushButton("Change Source")
        self.change_button.setVisible(False)
        self.change_button.clicked.connect(self.changeSourceRequested)
        layout.addWidget(self.change_button)

        self.full_path = ""

    def set_empty(self, message="No source loaded"):
        self.full_path = ""
        self.status_label.setText("○ %s" % message)
        self.name_label.clear()
        self.detail_label.clear()
        self.change_button.setVisible(False)
        self.setToolTip("")

    def set_loaded(self, display_name, detail="", full_path=""):
        self.full_path = full_path or ""
        self.status_label.setText("✓ Source Loaded")
        self.name_label.setText(display_name or "Loaded source")
        self.detail_label.setText(detail or "")
        self.change_button.setVisible(True)
        self.setToolTip(self.full_path)


class ResultSummaryCard(QtWidgets.QFrame):
    browseRequested = QtCore.Signal()
    changeRequested = QtCore.Signal()

    def __init__(self, parent=None):
        super(ResultSummaryCard, self).__init__(parent)
        self.setObjectName("ResultSummaryCard")
        self.setStyleSheet(
            "QFrame#ResultSummaryCard {"
            "background:#ffffff; border:1px solid #cbd7e3; border-radius:9px;"
            "}"
        )
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(5)

        title = QLabel("ResultSummary")
        title.setStyleSheet("font-size:13px; font-weight:700; color:#596775;")
        layout.addWidget(title)

        self.status_label = QLabel("○ Not loaded")
        self.status_label.setStyleSheet("font-size:15px; font-weight:700; color:#244867;")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        self.detail_label = QLabel("Drop XLSX/XLSM here or use Browse ResultSummary.")
        self.detail_label.setWordWrap(True)
        self.detail_label.setStyleSheet("font-size:12px; color:#667786;")
        layout.addWidget(self.detail_label)

        row = QHBoxLayout()
        self.browse_button = QPushButton("Browse ResultSummary...")
        self.browse_button.clicked.connect(self.browseRequested)
        row.addWidget(self.browse_button)
        self.change_button = QPushButton("Change")
        self.change_button.setVisible(False)
        self.change_button.clicked.connect(self.changeRequested)
        row.addWidget(self.change_button)
        row.addStretch(1)
        layout.addLayout(row)

        self.full_path = ""

    def set_empty(self):
        self.full_path = ""
        self.status_label.setText("○ Not loaded")
        self.detail_label.setText("Drop XLSX/XLSM here or use Browse ResultSummary.")
        self.change_button.setVisible(False)
        self.setToolTip("")

    def set_loaded(self, display_name, full_path=""):
        self.full_path = full_path or ""
        self.status_label.setText("✓ %s" % (display_name or "ResultSummary loaded"))
        self.detail_label.setText("Ready for chart and reliability analysis.")
        self.change_button.setVisible(True)
        self.setToolTip(self.full_path)


# ==============================================================
# Version 7.3 RC1-4: Life Forecast Module (Weibull / Kaplan-Meier)
#
# Pure Python only (no numpy / scipy / pandas / matplotlib), consistent
# with this project's Nuitka single-file build policy.
#
# - Builds right-censored survival intervals from Replacement_History.xlsx
#   (Hospital Request rows are excluded from reliability per common practice;
#   Failure = event, Scheduled Replacement / Company Instruction = censored,
#   Unknown = user-selectable scenario, see LF_UNKNOWN_SCENARIOS below).
# - Fits Weibull by maximum likelihood with censoring (2-D Nelder-Mead simplex,
#   implemented locally, no scipy) and computes the Kaplan-Meier estimator
#   as a non-parametric cross-check.
# - Cuts: Global / Region / Country / Hospital (SN), selectable in the dialog.
# - Data range: optional Replacement Date From/To filter.
# - Results are shown as text + a native Qt survival-curve chart, and can be
#   exported to an Excel workbook (openpyxl, already a project dependency).
# - Editing / adding / importing history data reuses the existing
#   Master Foundation table (Hospital_Master incl. Country/Region) and the
#   existing Replacement Import Wizard - no new file formats are introduced.
# ==============================================================

LF_REPL_TYPE_CENSOR = {
    "Failure": "uncensored",
    "Scheduled Replacement": "censored",
    "Company Instruction": "censored",
    "Hospital Request": "exclude",
}

LF_UNKNOWN_SCENARIOS = {
    "Conservative (Unknown = still alive / censored)": "conservative",
    "Sensitivity (Unknown = failure-equivalent)": "sensitivity",
}

LF_MODELS = ["Weibull (MLE, censored)", "Kaplan-Meier (non-parametric)", "Simple Average Interval"]
LF_SCOPES = ["Global", "Region", "Country", "Hospital (SN)"]


def lf_nelder_mead_2d(func, x0, args=(), step=0.6, max_iter=800, tol=1e-8):
    """Minimal, dependency-free 2-D Nelder-Mead simplex minimizer."""
    def f(x):
        try:
            return func(x, *args)
        except Exception:
            return float("inf")

    x0 = list(x0)
    simplex = [x0, [x0[0] + step, x0[1]], [x0[0], x0[1] + step]]
    values = [f(p) for p in simplex]

    for _ in range(max_iter):
        order = sorted(range(3), key=lambda i: values[i])
        simplex = [simplex[i] for i in order]
        values = [values[i] for i in order]

        if abs(values[-1] - values[0]) < tol:
            break

        centroid = [(simplex[0][0] + simplex[1][0]) / 2.0, (simplex[0][1] + simplex[1][1]) / 2.0]

        refl = [centroid[0] + (centroid[0] - simplex[2][0]),
                centroid[1] + (centroid[1] - simplex[2][1])]
        f_refl = f(refl)

        if f_refl < values[0]:
            exp = [centroid[0] + 2 * (centroid[0] - simplex[2][0]),
                   centroid[1] + 2 * (centroid[1] - simplex[2][1])]
            f_exp = f(exp)
            if f_exp < f_refl:
                simplex[2], values[2] = exp, f_exp
            else:
                simplex[2], values[2] = refl, f_refl
        elif f_refl < values[1]:
            simplex[2], values[2] = refl, f_refl
        else:
            contr = [centroid[0] + 0.5 * (simplex[2][0] - centroid[0]),
                     centroid[1] + 0.5 * (simplex[2][1] - centroid[1])]
            f_contr = f(contr)
            if f_contr < values[2]:
                simplex[2], values[2] = contr, f_contr
            else:
                simplex[1] = [simplex[0][0] + 0.5 * (simplex[1][0] - simplex[0][0]),
                              simplex[0][1] + 0.5 * (simplex[1][1] - simplex[0][1])]
                simplex[2] = [simplex[0][0] + 0.5 * (simplex[2][0] - simplex[0][0]),
                              simplex[0][1] + 0.5 * (simplex[2][1] - simplex[0][1])]
                values[1], values[2] = f(simplex[1]), f(simplex[2])

    best = min(range(3), key=lambda i: values[i])
    return simplex[best]


def lf_weibull_negloglik(params, t_unc, t_cen):
    a, b = params
    try:
        k, lam = math.exp(a), math.exp(b)
    except OverflowError:
        return float("inf")
    ll = 0.0
    for t in t_unc:
        if t <= 0 or lam <= 0 or k <= 0:
            return float("inf")
        ll += math.log(k) - math.log(lam) + (k - 1) * (math.log(t) - math.log(lam)) - (t / lam) ** k
    for t in t_cen:
        ll += -((t / lam) ** k)
    return -ll


def lf_fit_weibull(intervals):
    t_unc = [i["days"] for i in intervals if not i["censored"]]
    t_cen = [i["days"] for i in intervals if i["censored"]]
    n = len(t_unc) + len(t_cen)
    if len(t_unc) < 2 or n < 4:
        return None
    all_t = t_unc + t_cen
    a0 = math.log(1.2)
    b0 = math.log(max(sum(all_t) / len(all_t), 1.0))
    a, b = lf_nelder_mead_2d(lf_weibull_negloglik, [a0, b0], args=(t_unc, t_cen))
    k, lam = math.exp(a), math.exp(b)
    try:
        mean_life = lam * math.gamma(1 + 1 / k)
        median_life = lam * (math.log(2)) ** (1 / k)
    except Exception:
        mean_life = median_life = None
    return {
        "k_shape": round(k, 3), "lambda_scale_days": round(lam, 1),
        "mean_life_days": round(mean_life, 1) if mean_life else None,
        "median_life_days": round(median_life, 1) if median_life else None,
        "n_uncensored": len(t_unc), "n_censored": len(t_cen), "n_total": n,
    }


def lf_kaplan_meier(intervals):
    times = sorted(set(i["days"] for i in intervals))
    at_risk = len(intervals)
    s = 1.0
    curve = []
    for t in times:
        d = sum(1 for i in intervals if i["days"] == t and not i["censored"])
        c = sum(1 for i in intervals if i["days"] == t and i["censored"])
        if at_risk > 0 and d > 0:
            s *= (1 - d / at_risk)
        curve.append({"days": t, "at_risk": at_risk, "events": d, "survival": round(s, 4)})
        at_risk -= (d + c)
    return curve


def lf_km_median(curve):
    for row in curve:
        if row["survival"] <= 0.5:
            return row["days"]
    return None


def lf_simple_average(intervals):
    t_unc = [i["days"] for i in intervals if not i["censored"]]
    if not t_unc:
        return None
    return {"mean_interval_days": round(sum(t_unc) / len(t_unc), 1), "n": len(t_unc)}


def lf_load_hospitals():
    hosp_rows = lf_cached_master_rows("Hospital_Master.xlsx", HP_MASTER_HEADERS)
    hosp_by_sn = {}
    for h in hosp_rows:
        sn = normalize_text_value(h.get("Serial Number"))
        if not sn:
            continue
        hosp_by_sn[sn] = {
            "sn": sn,
            "hospital_name": normalize_text_value(h.get("Hospital Name")) or normalize_text_value(h.get("Site")),
            "country": normalize_text_value(h.get("Country")) or "(Unset)",
            "region": normalize_text_value(h.get("Region")) or "(Unset)",
            "install_date": parse_date_value(h.get("Installation Date")),
            "status": normalize_text_value(h.get("Status")) or "Active",
        }
    return hosp_by_sn


def lf_load_events(component_type=None, date_from=None, date_to=None):
    events_by_sn = {}
    for r in lf_cached_master_rows("Replacement_History.xlsx", REPLACEMENT_HISTORY_HEADERS):
        sn = normalize_text_value(r.get("Serial Number") or r.get("SN"))
        if not sn:
            continue
        d = parse_date_value(r.get("Replacement Date"))
        if not d:
            continue
        if date_from and d < date_from:
            continue
        if date_to and d > date_to:
            continue
        ctype = normalize_text_value(r.get("Component Type") or r.get("Part")) or "Degas Module"
        if component_type and component_type != "All" and ctype != component_type:
            continue
        rtype = normalize_text_value(r.get("Replacement Type")) or "Unknown"
        events_by_sn.setdefault(sn, []).append({"date": d, "type": rtype, "component": ctype})
    for sn in events_by_sn:
        events_by_sn[sn].sort(key=lambda e: e["date"])
    return events_by_sn


def lf_build_intervals(scenario_key, component_type=None, date_from=None, date_to=None, now=None):
    """Returns (intervals, hosp_by_sn, events_by_sn). scenario_key is one of
    LF_UNKNOWN_SCENARIOS values ('conservative' / 'sensitivity')."""
    now = now or dt.datetime.now()
    hosp_by_sn = lf_load_hospitals()
    events_by_sn = lf_load_events(component_type, date_from, date_to)

    intervals = []
    for sn, evs in events_by_sn.items():
        meta = hosp_by_sn.get(sn)
        if not meta:
            continue
        left = meta["install_date"]
        for e in evs:
            if e["type"] == "Hospital Request":
                left = e["date"]
                continue
            if left is None:
                left = e["date"]
                continue
            days = (e["date"] - left).days
            if days <= 0:
                left = e["date"]
                continue
            base = LF_REPL_TYPE_CENSOR.get(e["type"], "unknown")
            if base == "unknown":
                censored = (scenario_key == "conservative")
            else:
                censored = (base == "censored")
            intervals.append({
                "sn": sn, "hospital": meta["hospital_name"], "country": meta["country"], "region": meta["region"],
                "start": left, "end": e["date"], "days": days, "censored": censored,
                "is_open": False, "event_type": e["type"],
            })
            left = e["date"]
        if str(meta["status"]).strip().lower() == "active" and left is not None:
            days = (now - left).days
            if days > 0:
                intervals.append({
                    "sn": sn, "hospital": meta["hospital_name"], "country": meta["country"], "region": meta["region"],
                    "start": left, "end": now, "days": days, "censored": True,
                    "is_open": True, "event_type": "In service (censored)",
                })
    return intervals, hosp_by_sn, events_by_sn


def lf_filter_scope(intervals, scope, scope_value):
    if scope == "Global" or not scope_value or scope_value == "All":
        return intervals
    key = {"Region": "region", "Country": "country", "Hospital (SN)": "sn"}.get(scope)
    if not key:
        return intervals
    return [i for i in intervals if str(i.get(key)) == str(scope_value)]


def lf_scope_values(intervals, scope):
    key = {"Region": "region", "Country": "country", "Hospital (SN)": "sn"}.get(scope)
    if not key:
        return []
    return sorted(set(str(i.get(key)) for i in intervals if i.get(key)))


def lf_scope_fallback_chain(intervals_all, hosp_by_sn, scope, scope_value):
    """Broadening chain of (label, filtered_intervals) from the exact requested scope up to
    Global. A single Hospital/SN very rarely has enough of its own replacement events to fit
    a Weibull distribution on its own (real reliability work always needs a population), so
    callers should walk this chain and use the first scope with enough data, rather than
    giving up as soon as the exact scope is insufficient."""
    chain = []
    if scope == "Hospital (SN)" and scope_value and scope_value != "All":
        chain.append(("Hospital (SN) = %s" % scope_value, lf_filter_scope(intervals_all, "Hospital (SN)", scope_value)))
        meta = hosp_by_sn.get(scope_value)
        if meta:
            country, region = meta.get("country"), meta.get("region")
            if country and country != "(Unset)":
                chain.append(("Country = %s (fallback)" % country, lf_filter_scope(intervals_all, "Country", country)))
            if region and region != "(Unset)":
                chain.append(("Region = %s (fallback)" % region, lf_filter_scope(intervals_all, "Region", region)))
    elif scope == "Country" and scope_value and scope_value != "All":
        chain.append(("Country = %s" % scope_value, lf_filter_scope(intervals_all, "Country", scope_value)))
        region = next((i["region"] for i in intervals_all if i["country"] == scope_value and i.get("region") not in (None, "(Unset)")), None)
        if region:
            chain.append(("Region = %s (fallback)" % region, lf_filter_scope(intervals_all, "Region", region)))
    elif scope == "Region" and scope_value and scope_value != "All":
        chain.append(("Region = %s" % scope_value, lf_filter_scope(intervals_all, "Region", scope_value)))
    chain.append(("Global (fallback)" if chain else "Global", intervals_all))
    return chain


def lf_conditional_residual_days(weibull_fit, age_days):
    if not weibull_fit or not weibull_fit.get("k_shape"):
        return None
    k, lam = weibull_fit["k_shape"], weibull_fit["lambda_scale_days"]
    try:
        target = (age_days / lam) ** k + math.log(2)
        t_abs = lam * (target ** (1 / k))
        return round(t_abs - age_days, 1)
    except Exception:
        return None


def lf_forecast_for_scope(intervals, hosp_by_sn, weibull_fit, now=None):
    """Per active-SN forecast using the supplied (already scope-filtered) Weibull fit."""
    now = now or dt.datetime.now()
    by_sn = {}
    for i in intervals:
        by_sn.setdefault(i["sn"], []).append(i)

    rows = []
    for sn, ivs in sorted(by_sn.items()):
        meta = hosp_by_sn.get(sn)
        if not meta or str(meta["status"]).strip().lower() != "active":
            continue
        open_iv = next((i for i in ivs if i["is_open"]), None)
        if open_iv is not None:
            last_date = open_iv["start"]
            age_days = open_iv["days"]
        else:
            closed = sorted([i for i in ivs if not i["is_open"]], key=lambda i: i["end"])
            last_date = closed[-1]["end"] if closed else meta["install_date"]
            if not last_date:
                continue
            age_days = (now - last_date).days
        resid = lf_conditional_residual_days(weibull_fit, age_days)
        fdate = (now + dt.timedelta(days=resid)) if resid is not None else None
        rows.append({
            "sn": sn, "hospital": meta["hospital_name"], "country": meta["country"], "region": meta["region"],
            "last_event_date": last_date, "age_days": age_days,
            "residual_days": resid, "forecast_date": fdate,
        })
    rows.sort(key=lambda r: (r["forecast_date"] or dt.datetime.max))
    return rows


def lf_last_log_date(summary_rows):
    """Last log DateTime from the main Analyze session's summary rows, or None."""
    if not summary_rows:
        return None
    try:
        last = summary_rows[-1].get("DateTime")
        return parse_date_value(last) if last is not None else None
    except Exception:
        return None


def lf_infer_current_sn(window):
    """Best-effort current Serial Number from the main window's loaded ResultSummary file,
    same convention as calculate_forecast_now()."""
    try:
        result_file = getattr(window, "result_file", "") or ""
        if result_file:
            m = re.search(r"ResultSummary_(.+?)(?:_\d{8}_\d{6})?\.xlsx$", os.path.basename(result_file), re.I)
            if m:
                return m.group(1)
    except Exception:
        pass
    return ""


class NativeSurvivalChartView(QGraphicsView):
    """Richer pure-Qt survival curve chart: KM step curve + Weibull S(t), with a legend box,
    median guide lines, a shaded 'below 50% survival' risk zone, and rug ticks marking
    individual event/censoring points. Axis unit label follows the selected Life Axis."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.scene_obj = QGraphicsScene(self)
        self.setScene(self.scene_obj)
        self.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        self.setMinimumSize(600, 380)
        self.km_curve = []
        self.weibull_fit = None
        self.max_x = 1
        self.unit_label = "days"
        self.raw_points = []  # [(x, censored_bool), ...] for rug ticks
        self.title_text = ""

    def set_data(self, km_curve, weibull_fit, max_x, unit_label="days", raw_points=None, title_text=""):
        self.km_curve = km_curve or []
        self.weibull_fit = weibull_fit
        self.max_x = max(max_x, 1e-6)
        self.unit_label = unit_label
        self.raw_points = raw_points or []
        self.title_text = title_text
        self.redraw()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.redraw()

    def txt(self, x, y, s, size=8, bold=False, center=False, color=(40, 40, 40)):
        item = self.scene_obj.addText(str(s))
        font = QtGui.QFont()
        font.setPointSize(size)
        font.setBold(bold)
        item.setFont(font)
        item.setDefaultTextColor(QtGui.QColor(*color))
        br = item.boundingRect()
        if center:
            item.setPos(x - br.width() / 2, y - br.height() / 2)
        else:
            item.setPos(x, y - br.height() / 2)
        return br

    def fmt_x(self, v):
        if self.unit_label == "days":
            return "%d d" % v
        if "hrs" in self.unit_label or "Hours" in self.unit_label:
            return "%.0f h" % v
        return "%.0f" % v

    def redraw(self):
        self.scene_obj.clear()
        w = max(560, self.viewport().width() - 8)
        h = max(340, self.viewport().height() - 8)
        self.scene_obj.setSceneRect(0, 0, w, h)

        if self.title_text:
            self.txt(w / 2, 12, self.title_text, 10, True, True)

        left, right, top, bottom = 64, 24, 32, 58
        pw = max(80, w - left - right)
        ph = max(80, h - top - bottom)
        max_x = self.max_x

        def x_of(v):
            return left + pw * min(max(v, 0), max_x) / max_x

        def y_of(surv):
            return top + ph * (1 - max(0.0, min(1.0, surv)))

        # Risk zone shading: below 50% survival
        risk_brush = QtGui.QBrush(QtGui.QColor(255, 235, 235))
        self.scene_obj.addRect(left, y_of(0.5), pw, ph - (y_of(0.5) - top), QtGui.QPen(QtCore.Qt.PenStyle.NoPen), risk_brush)
        safe_brush = QtGui.QBrush(QtGui.QColor(235, 245, 235))
        self.scene_obj.addRect(left, top, pw, y_of(0.5) - top, QtGui.QPen(QtCore.Qt.PenStyle.NoPen), safe_brush)

        axis_pen = QtGui.QPen(QtGui.QColor(45, 45, 45), 1.2)
        grid_pen = QtGui.QPen(QtGui.QColor(210, 210, 210), 1)
        self.scene_obj.addLine(left, top, left, top + ph, axis_pen)
        self.scene_obj.addLine(left, top + ph, left + pw, top + ph, axis_pen)
        for i in range(1, 5):
            y = top + ph * i / 5
            self.scene_obj.addLine(left, y, left + pw, y, grid_pen)
            self.txt(left - 6, y, "%.0f%%" % (100 * (1 - i / 5)), 8, False, True)
        self.txt(left - 6, top, "100%", 8, False, True)
        self.txt(left - 44, top + ph / 2, "Survival", 9, True, True)

        for frac in (0, 0.25, 0.5, 0.75, 1.0):
            x = left + pw * frac
            self.txt(x, top + ph + 14, self.fmt_x(max_x * frac), 8, False, True)
        self.txt(left + pw / 2, top + ph + 32, "Life axis: %s" % self.unit_label, 9, True, True)

        # Rug ticks: individual observations along the x-axis (event=red tick, censored=grey tick)
        for v, censored in self.raw_points:
            cx = x_of(v)
            color = (170, 170, 170) if censored else (200, 40, 40)
            pen = QtGui.QPen(QtGui.QColor(*color), 1.3)
            self.scene_obj.addLine(cx, top + ph, cx, top + ph + 6, pen)

        # Kaplan-Meier step curve (blue)
        if self.km_curve:
            pen = QtGui.QPen(QtGui.QColor(30, 90, 200), 2.4)
            prev_x, prev_y = x_of(0), y_of(1.0)
            for row in self.km_curve:
                cx, cy = x_of(row["days"]), y_of(row["survival"])
                self.scene_obj.addLine(prev_x, prev_y, cx, prev_y, pen)
                self.scene_obj.addLine(cx, prev_y, cx, cy, pen)
                prev_x, prev_y = cx, cy
            self.scene_obj.addLine(prev_x, prev_y, x_of(max_x), prev_y, pen)

        # Weibull smooth curve (red)
        weib_median = None
        if self.weibull_fit and self.weibull_fit.get("k_shape"):
            k, lam = self.weibull_fit["k_shape"], self.weibull_fit["lambda_scale_days"]
            weib_median = self.weibull_fit.get("median_life_days")
            pen = QtGui.QPen(QtGui.QColor(200, 40, 40), 2.4)
            steps = 80
            prev = None
            for s in range(steps + 1):
                d = max_x * s / steps
                try:
                    surv = math.exp(-((d / lam) ** k)) if d > 0 else 1.0
                except Exception:
                    surv = 0.0
                cx, cy = x_of(d), y_of(surv)
                if prev:
                    self.scene_obj.addLine(prev[0], prev[1], cx, cy, pen)
                prev = (cx, cy)

        # Median guide lines + labels
        dash_pen_km = QtGui.QPen(QtGui.QColor(30, 90, 200), 1, QtCore.Qt.PenStyle.DashLine)
        dash_pen_w = QtGui.QPen(QtGui.QColor(200, 40, 40), 1, QtCore.Qt.PenStyle.DashLine)
        km_median = None
        for row in self.km_curve:
            if row["survival"] <= 0.5:
                km_median = row["days"]
                break
        if km_median is not None:
            cx = x_of(km_median)
            self.scene_obj.addLine(cx, y_of(0.5), cx, top + ph, dash_pen_km)
            self.txt(cx, top + ph - 14, self.fmt_x(km_median), 8, True, True, color=(30, 90, 200))
        if weib_median is not None:
            cx = x_of(weib_median)
            self.scene_obj.addLine(cx, y_of(0.5), cx, top + ph, dash_pen_w)
            self.txt(cx, top + ph - 28 if km_median is not None else top + ph - 14,
                      self.fmt_x(weib_median), 8, True, True, color=(200, 40, 40))
        if km_median is not None or weib_median is not None:
            self.scene_obj.addLine(left, y_of(0.5), left + pw, y_of(0.5), QtGui.QPen(QtGui.QColor(120, 120, 120), 1, QtCore.Qt.PenStyle.DotLine))

        # Legend box (top-right)
        lx, ly = left + pw - 148, top + 6
        self.scene_obj.addRect(lx, ly, 140, 62, QtGui.QPen(QtGui.QColor(190, 190, 190)), QtGui.QBrush(QtGui.QColor(255, 255, 255, 235)))
        self.scene_obj.addLine(lx + 8, ly + 14, lx + 26, ly + 14, QtGui.QPen(QtGui.QColor(30, 90, 200), 2.4))
        self.txt(lx + 32, ly + 14, "Kaplan-Meier", 8, False, False)
        self.scene_obj.addLine(lx + 8, ly + 30, lx + 26, ly + 30, QtGui.QPen(QtGui.QColor(200, 40, 40), 2.4))
        self.txt(lx + 32, ly + 30, "Weibull fit", 8, False, False)
        self.scene_obj.addRect(lx + 8, ly + 40, 18, 8, QtGui.QPen(QtCore.Qt.PenStyle.NoPen), QtGui.QBrush(QtGui.QColor(255, 200, 200)))
        self.txt(lx + 32, ly + 44, "Below 50% (risk)", 8, False, False)

        if not self.km_curve and not (self.weibull_fit and self.weibull_fit.get("k_shape")):
            self.txt(left + pw / 2, top + ph / 2, "No data for this scope", 11, True, True)


class GapClassificationDialog(QtWidgets.QDialog):
    """Manually classify each detected gap between linked log sessions for one SN as
    genuinely Idle (not used) or Unknown (a real data gap) - since logs only exist while the
    system is running, gaps are expected by design and only a person can say which is which."""

    def __init__(self, sn, parent=None):
        super().__init__(parent)
        self.sn = sn
        self.setWindowTitle("Classify Log Gaps - SN %s" % sn)
        self.resize(720, 420)
        outer = QVBoxLayout(self)
        outer.addWidget(QLabel(
            "Gaps below are periods with no linked log session for SN %s. Mark each as Idle "
            "(the machine genuinely was not used) or Unknown (we don't know - treat as a real "
            "data gap). Unmarked gaps are treated as Idle by the default forecast mode." % sn))

        self.table = QtWidgets.QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["Gap Start", "Gap End", "Days", "Classification", "Comment"])
        outer.addWidget(self.table, 1)

        self._gaps = lf_detect_gaps(sn)
        existing = {(normalize_text_value(r.get("Serial Number")), str(r.get("Gap Start"))[:10], str(r.get("Gap End"))[:10]): r
                    for r in lf_load_gap_classifications(sn)}
        self.table.setRowCount(len(self._gaps))
        self._combos = []
        self._comments = []
        for r, g in enumerate(self._gaps):
            key = (normalize_text_value(sn), g["start"].strftime("%Y-%m-%d"), g["end"].strftime("%Y-%m-%d"))
            existing_row = existing.get(key)
            self.table.setItem(r, 0, QtWidgets.QTableWidgetItem(g["start"].strftime("%Y/%m/%d")))
            self.table.setItem(r, 1, QtWidgets.QTableWidgetItem(g["end"].strftime("%Y/%m/%d")))
            self.table.setItem(r, 2, QtWidgets.QTableWidgetItem(str(g["days"])))
            combo = QComboBox()
            combo.addItems(["(unmarked - treated as Idle by default)", LF_GAP_IDLE, LF_GAP_UNKNOWN])
            if existing_row and existing_row.get("Classification") in (LF_GAP_IDLE, LF_GAP_UNKNOWN):
                combo.setCurrentText(existing_row["Classification"])
            self.table.setCellWidget(r, 3, combo)
            comment = QLineEdit(existing_row.get("Comment", "") if existing_row else "")
            self.table.setCellWidget(r, 4, comment)
            self._combos.append(combo)
            self._comments.append(comment)
        self.table.resizeColumnsToContents()

        btn_row = QHBoxLayout()
        outer.addLayout(btn_row)
        btn_row.addStretch(1)
        b_save = QPushButton("Save")
        b_save.clicked.connect(self.save_all)
        btn_row.addWidget(b_save)
        b_close = QPushButton("Close")
        b_close.clicked.connect(self.accept)
        btn_row.addWidget(b_close)

    def save_all(self):
        try:
            for g, combo, comment in zip(self._gaps, self._combos, self._comments):
                choice = combo.currentText()
                if choice in (LF_GAP_IDLE, LF_GAP_UNKNOWN):
                    lf_classify_gap(self.sn, g["start"], g["end"], choice, comment.text())
            QMessageBox.information(self, APP_NAME, "Gap classifications saved.")
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())


class LifeForecastDialog(QtWidgets.QDialog):
    """Version 7.3 RC1-4: model/scope-selectable Weibull & Kaplan-Meier life forecast."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lf_clear_cache()
        self.setWindowTitle("Life Forecast (Weibull / Kaplan-Meier)")
        self.resize(1020, 760)
        self._last_intervals = []
        self._last_hosp = {}
        self._last_fit = None
        self._last_forecast_rows = []

        # Inherit data already produced on the Main analysis screen (Analyze / ResultSummary),
        # so this dialog can continue the calculation from where the main workflow left off
        # instead of only reading the static master files.
        main_window = parent
        self._main_summary_rows = list(getattr(main_window, "summary_rows", None) or [])
        self._main_sn = lf_infer_current_sn(main_window) if main_window is not None else ""
        self._main_last_log_date = lf_last_log_date(self._main_summary_rows)

        self._ui()
        self.refresh_scope_values()
        self._apply_inherited_session()

    def _ui(self):
        outer = QVBoxLayout(self)

        info = QLabel(
            "Select a survival model, a data cut (Global / Region / Country / Hospital), an optional "
            "Replacement Date range, and how to treat 'Unknown' replacement records, then press Calculate."
        )
        info.setWordWrap(True)
        outer.addWidget(info)

        self.session_label = QLabel("")
        self.session_label.setWordWrap(True)
        self.session_label.setStyleSheet("color: #205080;")
        outer.addWidget(self.session_label)

        self.use_session_now_check = QCheckBox(
            "Use Main Analysis session as data source: pre-select this SN, and use its last log "
            "date (instead of today's calendar date) as the 'now' reference for age/forecast."
        )
        self.use_session_now_check.setChecked(True)
        outer.addWidget(self.use_session_now_check)

        controls = QtWidgets.QGridLayout()
        outer.addLayout(controls)

        controls.addWidget(QLabel("Model:"), 0, 0)
        self.model_combo = QComboBox()
        self.model_combo.addItems(LF_MODELS)
        controls.addWidget(self.model_combo, 0, 1)

        controls.addWidget(QLabel("Unknown handling:"), 0, 2)
        self.scenario_combo = QComboBox()
        self.scenario_combo.addItems(list(LF_UNKNOWN_SCENARIOS.keys()))
        controls.addWidget(self.scenario_combo, 0, 3)

        controls.addWidget(QLabel("Scope:"), 1, 0)
        self.scope_combo = QComboBox()
        self.scope_combo.addItems(LF_SCOPES)
        self.scope_combo.currentIndexChanged.connect(self.refresh_scope_values)
        controls.addWidget(self.scope_combo, 1, 1)

        controls.addWidget(QLabel("Scope value:"), 1, 2)
        self.scope_value_combo = QComboBox()
        controls.addWidget(self.scope_value_combo, 1, 3)

        controls.addWidget(QLabel("Component Type:"), 2, 0)
        self.component_combo = QComboBox()
        self.component_combo.addItem("All")
        controls.addWidget(self.component_combo, 2, 1)

        controls.addWidget(QLabel("Replacement Date From (YYYY/MM/DD, blank = no limit):"), 2, 2)
        self.date_from_edit = QLineEdit()
        controls.addWidget(self.date_from_edit, 2, 3)

        controls.addWidget(QLabel("Replacement Date To (YYYY/MM/DD, blank = no limit):"), 3, 2)
        self.date_to_edit = QLineEdit()
        controls.addWidget(self.date_to_edit, 3, 3)

        self.log_coverage_label = QLabel("")
        self.log_coverage_label.setWordWrap(True)
        self.log_coverage_label.setStyleSheet("color: #555555;")
        controls.addWidget(self.log_coverage_label, 4, 0, 1, 3)

        b_cov = QPushButton("Use Log Coverage Window as Date Range")
        b_cov.setToolTip(
            "Fill Date From/To above from the accumulated Log_Coverage_History.xlsx database "
            "for the currently selected Hospital (SN) scope - i.e. only the period that has "
            "actually been observed via analyzed logs for that unit."
        )
        b_cov.clicked.connect(self.use_log_coverage_range)
        controls.addWidget(b_cov, 4, 3)

        self.scope_value_combo.currentIndexChanged.connect(self.refresh_log_coverage_label)
        self.scope_combo.currentIndexChanged.connect(self.refresh_log_coverage_label)
        self.scope_value_combo.currentIndexChanged.connect(self.refresh_axis_rate_label)
        self.scope_combo.currentIndexChanged.connect(self.refresh_axis_rate_label)

        controls.addWidget(QLabel("Life Axis:"), 5, 0)
        self.axis_combo = QComboBox()
        self.axis_combo.addItems(list(LF_USAGE_METRICS.keys()))
        self.axis_combo.setToolTip(
            "Measure component life in Calendar Days (exact), or in a usage unit (Clean Count, "
            "Treatment/Degas/Cleaning Circulate Hours) fit on the ACTUAL recorded totals from "
            "linked log sessions (Log_Coverage_History.xlsx) for each replacement interval."
        )
        controls.addWidget(self.axis_combo, 5, 1)
        self.axis_rate_label = QLabel("")
        self.axis_rate_label.setWordWrap(True)
        self.axis_rate_label.setStyleSheet("color: #555555;")
        controls.addWidget(self.axis_rate_label, 5, 2, 1, 2)
        self.axis_combo.currentIndexChanged.connect(self.refresh_axis_rate_label)

        controls.addWidget(QLabel("Coverage Mode:"), 6, 0)
        self.coverage_mode_combo = QComboBox()
        self.coverage_mode_combo.addItems(LF_COVERAGE_MODES)
        self.coverage_mode_combo.setCurrentIndex(1)
        self.coverage_mode_combo.setToolTip(
            "WaterSystem logs only exist while the system is running, so gaps between linked log "
            "sessions are expected by design, not automatically a data problem. This controls how "
            "those gaps are treated when fitting a usage-based Life Axis."
        )
        controls.addWidget(self.coverage_mode_combo, 6, 1, 1, 2)
        self.coverage_mode_combo.currentIndexChanged.connect(self.refresh_axis_rate_label)

        b_gap = QPushButton("Classify Log Gaps for this SN...")
        b_gap.setToolTip(
            "Manually mark each gap between linked log sessions as Idle (genuinely not used) or "
            "Unknown (a real data gap) - only a person can know which is true."
        )
        b_gap.clicked.connect(self.open_gap_classification)
        controls.addWidget(b_gap, 6, 3)

        self.allow_fallback_check = QCheckBox(
            "Allow Weibull to automatically use a broader scope (Country/Region/Global) when the "
            "exact scope above doesn't have enough data on its own"
        )
        self.allow_fallback_check.setChecked(True)
        self.allow_fallback_check.setToolTip(
            "Uncheck to force the exact Scope selected above only - you'll see 'Weibull fit "
            "unavailable' instead of a broader-scope result whenever the exact scope alone "
            "isn't enough."
        )
        controls.addWidget(self.allow_fallback_check, 7, 0, 1, 4)

        btn_row = QHBoxLayout()
        outer.addLayout(btn_row)

        b = QPushButton("Calculate")
        b.clicked.connect(self.calculate)
        btn_row.addWidget(b)

        b = QPushButton("Export Result to Excel")
        b.clicked.connect(self.export_excel)
        btn_row.addWidget(b)

        b = QPushButton("Compare All Life Axes...")
        b.setToolTip(
            "Run the same Scope / Model / Unknown-handling / Coverage Mode settings across "
            "every Life Axis at once, and show the results side by side."
        )
        b.clicked.connect(self.open_compare_axes)
        btn_row.addWidget(b)

        btn_row.addStretch(1)

        b = QPushButton("Edit Hospital Master (Country / Region / Status)")
        b.clicked.connect(self.open_hospital_master)
        btn_row.addWidget(b)

        b = QPushButton("Import / Edit Replacement History")
        b.clicked.connect(self.open_replacement_import)
        btn_row.addWidget(b)

        b = QPushButton("Import ASM Replacement File (Region/Country/Install Date)...")
        b.setToolTip(
            "Import an 'ASM<part>_Replacement History' Excel export - updates Hospital_Master "
            "(Country/Region/Installation Date) and Replacement_History by Serial Number/Case "
            "Number. Safe to re-run on an updated version of the same file later - matching "
            "rows are updated in place, not duplicated."
        )
        b.clicked.connect(self.import_asm_file)
        btn_row.addWidget(b)

        db_row = QHBoxLayout()
        outer.addLayout(db_row)
        db_row.addWidget(QLabel("Database (WaterSystemAnalyzer.db):"))

        b = QPushButton("Export Database to Excel...")
        b.setToolTip(
            "Write every table (Hospital_Master, Component_Master, Replacement_History, "
            "Log_Coverage_History, Log_Gap_Classification) to one Excel workbook, one sheet "
            "per table - for sharing or inspecting outside the app."
        )
        b.clicked.connect(self.export_database_to_excel)
        db_row.addWidget(b)

        b = QPushButton("Backup Database Now")
        b.setToolTip(
            "Copy the current WaterSystemAnalyzer.db file to Data/Backup with a timestamp - "
            "a quick, standalone backup separate from the full Project Backup."
        )
        b.clicked.connect(self.backup_database_now)
        db_row.addWidget(b)

        b = QPushButton("Optimize Database (VACUUM)")
        b.setToolTip(
            "Rebuilds the database file to reclaim space left behind by edits/deletes over "
            "time and defragment it. Safe to run any time; does not change any data."
        )
        b.clicked.connect(self.optimize_database)
        db_row.addWidget(b)

        b = QPushButton("Database Status by SN...")
        b.setToolTip(
            "One row per Serial Number: Hospital/Country/Region, how many replacement events "
            "and log-coverage sessions are recorded, total observed runtime, and how many "
            "log gaps are classified vs. still unclassified - a quick view of how complete "
            "the database is for each unit."
        )
        b.clicked.connect(self.open_db_status_by_sn)
        db_row.addWidget(b)
        db_row.addStretch(1)

        split = QHBoxLayout()
        outer.addLayout(split, 1)

        self.chart = NativeSurvivalChartView()
        split.addWidget(self.chart, 1)

        right_col = QVBoxLayout()
        split.addLayout(right_col, 1)

        self.summary_label = QLabel("No calculation yet.")
        self.summary_label.setWordWrap(True)
        right_col.addWidget(self.summary_label)

        self.forecast_table = QtWidgets.QTableWidget()
        self.forecast_table.setColumnCount(7)
        self.forecast_table.setHorizontalHeaderLabels(
            ["SN", "Hospital", "Country/Region", "Last Event", "Age (days)", "Forecast Date", "Residual"])
        self.forecast_table.horizontalHeader().setStretchLastSection(True)
        right_col.addWidget(self.forecast_table, 1)

        close_row = QHBoxLayout()
        outer.addLayout(close_row)
        close_row.addStretch(1)
        b = QPushButton("Close")
        b.clicked.connect(self.accept)
        close_row.addWidget(b)

    def _parse_date_box(self, edit):
        s = edit.text().strip()
        if not s:
            return None
        return parse_date_value(s)

    def refresh_scope_values(self, *args):
        try:
            intervals, hosp_by_sn, _ = lf_build_intervals("conservative")
        except Exception:
            intervals, hosp_by_sn = [], {}
        scope = self.scope_combo.currentText()
        self.scope_value_combo.clear()
        self.scope_value_combo.addItem("All")
        for v in lf_scope_values(intervals, scope):
            self.scope_value_combo.addItem(v)

        try:
            comp_types = sorted(set(
                e["component"] for evs in lf_load_events().values() for e in evs
            ))
        except Exception:
            comp_types = []
        current = self.component_combo.currentText()
        self.component_combo.clear()
        self.component_combo.addItem("All")
        for c in comp_types:
            self.component_combo.addItem(c)
        idx = self.component_combo.findText(current)
        if idx >= 0:
            self.component_combo.setCurrentIndex(idx)

    def _apply_inherited_session(self):
        if self._main_summary_rows:
            span = ""
            try:
                first_dt = self._main_summary_rows[0].get("DateTime")
                span = " (%s -> %s)" % (str(first_dt)[:10], str(self._main_last_log_date)[:10])
            except Exception:
                pass
            self.session_label.setText(
                "Inherited from Main Analysis: SN=%s | %d log-summary rows loaded%s | last log date=%s" % (
                    self._main_sn or "(unknown)", len(self._main_summary_rows), span,
                    str(self._main_last_log_date)[:10] if self._main_last_log_date else "(n/a)")
            )
        else:
            self.session_label.setText(
                "No Main Analysis session data loaded (run Analyze on the main screen first to link this "
                "SN's own log data into the forecast). Falling back to master-file data and today's date only."
            )
            self.use_session_now_check.setChecked(False)
            self.use_session_now_check.setEnabled(False)

        if self._main_sn:
            idx = self.scope_combo.findText("Hospital (SN)")
            if idx >= 0:
                self.scope_combo.setCurrentIndex(idx)
            self.refresh_scope_values()
            vidx = self.scope_value_combo.findText(self._main_sn)
            if vidx < 0:
                self.scope_value_combo.addItem(self._main_sn)
                vidx = self.scope_value_combo.findText(self._main_sn)
            self.scope_value_combo.setCurrentIndex(vidx)
        self.refresh_log_coverage_label()
        self.refresh_axis_rate_label()

    def open_gap_classification(self):
        try:
            sn = self.scope_value_combo.currentText() if self.scope_combo.currentText() == "Hospital (SN)" else self._main_sn
            if not sn or sn == "All":
                QMessageBox.warning(self, APP_NAME, "Select Scope = Hospital (SN) and a specific SN first.")
                return
            gaps = lf_detect_gaps(sn)
            if not gaps:
                QMessageBox.information(self, APP_NAME, "No gaps detected between linked log sessions for SN %s "
                                                         "(need 2+ linked sessions with a gap between them)." % sn)
                return
            GapClassificationDialog(sn, self).exec()
            self.refresh_axis_rate_label()
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def refresh_axis_rate_label(self, *args):
        try:
            metric_key = LF_USAGE_METRICS.get(self.axis_combo.currentText())
            if not metric_key:
                self.axis_rate_label.setText("")
                return
            scenario_key = LF_UNKNOWN_SCENARIOS[self.scenario_combo.currentText()]
            intervals_all, _hosp, _events = lf_build_intervals(scenario_key)
            scope = self.scope_combo.currentText()
            scope_value = self.scope_value_combo.currentText()
            intervals = lf_filter_scope(intervals_all, scope, scope_value)
            usage_intervals, excluded, day_rate = lf_build_usage_dataset(
                intervals, metric_key, mode=self.coverage_mode_combo.currentText())
            total = len(usage_intervals) + excluded
            if total == 0:
                self.axis_rate_label.setText("No replacement intervals in this scope yet.")
            elif not usage_intervals:
                self.axis_rate_label.setText(
                    "0 of %d replacement interval(s) are fully covered by linked logs for %s yet - "
                    "link log batches spanning full replace-to-replace periods to enable this axis." % (
                        total, metric_key))
            else:
                self.axis_rate_label.setText(
                    "%d of %d replacement interval(s) are fully log-covered and will be used for the "
                    "real %s fit (implied rate ~%.4g %s/day)." % (
                        len(usage_intervals), total, metric_key, day_rate or 0, metric_key))
        except Exception:
            self.axis_rate_label.setText("")

    def refresh_log_coverage_label(self, *args):
        try:
            if self.scope_combo.currentText() != "Hospital (SN)":
                self.log_coverage_label.setText("")
                return
            sn = self.scope_value_combo.currentText()
            if not sn or sn == "All":
                self.log_coverage_label.setText("")
                return
            cov = lf_load_log_coverage(sn)
            if cov["n_sessions"] == 0:
                self.log_coverage_label.setText(
                    "Log coverage database: no linked sessions yet for SN %s. "
                    "Use 'Link Analyzed Logs to Database' on the main screen after Analyze." % sn)
            else:
                self.log_coverage_label.setText(
                    "Log coverage database for SN %s: %d linked session(s), %.1f total observed runtime hrs, "
                    "span %s -> %s" % (
                        sn, cov["n_sessions"], cov["total_runtime_hours"],
                        str(cov["earliest"])[:10] if cov["earliest"] else "n/a",
                        str(cov["latest"])[:10] if cov["latest"] else "n/a")
                )
        except Exception:
            self.log_coverage_label.setText("")

    def use_log_coverage_range(self):
        try:
            sn = self.scope_value_combo.currentText()
            if self.scope_combo.currentText() != "Hospital (SN)" or not sn or sn == "All":
                QMessageBox.warning(self, APP_NAME, "Select Scope = Hospital (SN) and a specific SN first.")
                return
            cov = lf_load_log_coverage(sn)
            if not cov["earliest"] or not cov["latest"]:
                QMessageBox.warning(self, APP_NAME, "No log coverage recorded yet for SN %s." % sn)
                return
            self.date_from_edit.setText(cov["earliest"].strftime("%Y/%m/%d"))
            self.date_to_edit.setText(cov["latest"].strftime("%Y/%m/%d"))
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def open_compare_axes(self):
        try:
            scenario_key = LF_UNKNOWN_SCENARIOS[self.scenario_combo.currentText()]
            component_type = self.component_combo.currentText()
            date_from = self._parse_date_box(self.date_from_edit)
            date_to = self._parse_date_box(self.date_to_edit)
            now_override = self._main_last_log_date if (self.use_session_now_check.isChecked() and self._main_last_log_date) else None

            intervals_all, hosp_by_sn, _events = lf_build_intervals(
                scenario_key, component_type=component_type, date_from=date_from, date_to=date_to, now=now_override)
            scope = self.scope_combo.currentText()
            scope_value = self.scope_value_combo.currentText()
            intervals = lf_filter_scope(intervals_all, scope, scope_value)
            exact_label = "%s = %s" % (scope, scope_value)
            if self.allow_fallback_check.isChecked():
                fallback_chain = lf_scope_fallback_chain(intervals_all, hosp_by_sn, scope, scope_value)
            else:
                fallback_chain = [(exact_label, intervals)]
            mode = self.coverage_mode_combo.currentText()
            model_is_weibull = self.model_combo.currentText().startswith("Weibull")

            rows = []
            for axis_name, metric_key in LF_USAGE_METRICS.items():
                exact_basis = "%s = %s" % (scope, scope_value)
                fit, basis = None, exact_basis
                if metric_key is None:
                    disp = intervals
                    if model_is_weibull:
                        for label, ivs in fallback_chain:
                            f = lf_fit_weibull(ivs)
                            if f:
                                fit, basis = f, label
                                break
                    unit = "days"
                else:
                    disp, excl, rate = lf_build_usage_dataset(intervals, metric_key, mode=mode)
                    if model_is_weibull:
                        fit = lf_fit_weibull(disp)
                        if not fit:
                            for label, ivs in fallback_chain[1:]:
                                d2, e2, r2 = lf_build_usage_dataset(ivs, metric_key, mode=mode)
                                f = lf_fit_weibull(d2)
                                if f:
                                    fit, basis, disp = f, label, d2
                                    break
                    unit = metric_key
                km_curve = lf_kaplan_meier(disp)
                km_med = lf_km_median(km_curve)
                rows.append({
                    "axis": axis_name, "unit": unit, "n_used": len(disp), "basis": basis,
                    "weibull_median": fit["median_life_days"] if fit else None,
                    "weibull_mean": fit["mean_life_days"] if fit else None,
                    "km_median": km_med,
                })

            dlg = QtWidgets.QDialog(self)
            dlg.setWindowTitle("Compare Life Axes - %s = %s" % (scope, scope_value))
            dlg.resize(820, 320)
            lay = QVBoxLayout(dlg)
            lay.addWidget(QLabel(
                "Same Model / Unknown-handling / Coverage Mode / date range, compared across every Life Axis "
                "(the fit basis column shows if a broader scope had to be used):"))
            table = QtWidgets.QTableWidget()
            table.setColumnCount(6)
            table.setHorizontalHeaderLabels(["Life Axis", "Unit", "n used", "Fit basis", "Weibull median", "KM median"])
            table.setRowCount(len(rows))
            for r, row in enumerate(rows):
                table.setItem(r, 0, QtWidgets.QTableWidgetItem(row["axis"]))
                table.setItem(r, 1, QtWidgets.QTableWidgetItem(row["unit"]))
                table.setItem(r, 2, QtWidgets.QTableWidgetItem(str(row["n_used"])))
                table.setItem(r, 3, QtWidgets.QTableWidgetItem(row["basis"]))
                table.setItem(r, 4, QtWidgets.QTableWidgetItem(
                    "%.1f %s" % (row["weibull_median"], row["unit"]) if row["weibull_median"] else "n/a"))
                table.setItem(r, 5, QtWidgets.QTableWidgetItem(
                    "%.1f %s" % (row["km_median"], row["unit"]) if row["km_median"] else "n/a"))
            table.resizeColumnsToContents()
            lay.addWidget(table, 1)
            b = QPushButton("Close")
            b.clicked.connect(dlg.accept)
            lay.addWidget(b)
            dlg.exec()
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def calculate(self):
        try:
            scenario_key = LF_UNKNOWN_SCENARIOS[self.scenario_combo.currentText()]
            component_type = self.component_combo.currentText()
            date_from = self._parse_date_box(self.date_from_edit)
            date_to = self._parse_date_box(self.date_to_edit)

            now_override = None
            if self.use_session_now_check.isChecked() and self._main_last_log_date:
                now_override = self._main_last_log_date

            intervals_all, hosp_by_sn, _events = lf_build_intervals(
                scenario_key, component_type=component_type, date_from=date_from, date_to=date_to,
                now=now_override)

            scope = self.scope_combo.currentText()
            scope_value = self.scope_value_combo.currentText()
            intervals = lf_filter_scope(intervals_all, scope, scope_value)

            model = self.model_combo.currentText()
            n_total = len(intervals)
            n_unc = sum(1 for i in intervals if not i["censored"])

            exact_label = "%s = %s" % (scope, scope_value)
            if self.allow_fallback_check.isChecked():
                fallback_chain = lf_scope_fallback_chain(intervals_all, hosp_by_sn, scope, scope_value)
            else:
                fallback_chain = [(exact_label, intervals)]

            # Calendar-day fit: a single Hospital/SN very rarely has enough of its own
            # replacement events to fit Weibull, so escalate to Country -> Region -> Global
            # (in that order) until a scope with enough real replacement-date data is found.
            # KM (which works fine even with very few points) still uses the exact scope
            # selected, so the chart always shows the exact-scope KM curve; only the smooth
            # Weibull curve/forecast may come from a broader scope, and that is stated plainly.
            weibull_fit_days = None
            days_basis = "%s = %s" % (scope, scope_value)
            if model.startswith("Weibull"):
                for label, ivs in fallback_chain:
                    fit = lf_fit_weibull(ivs)
                    if fit:
                        weibull_fit_days, days_basis = fit, label
                        break
            km_curve_days = lf_kaplan_meier(intervals)
            km_median_days = lf_km_median(km_curve_days)
            simple = lf_simple_average(intervals) if model.startswith("Simple") else None

            # -- Life Axis: Calendar Days uses the real interval lengths directly (exact, no
            # estimate needed). Any other axis (Clean Count / Treat/Degas/Clean Circulate Hours)
            # is fit on the ACTUAL recorded usage from Log_Coverage_History for each replacement
            # interval (lf_build_usage_dataset). The day-rate implied by that same real data is
            # then used only as a secondary "estimated day equivalent" figure.
            metric_key = LF_USAGE_METRICS.get(self.axis_combo.currentText())
            axis_label = self.axis_combo.currentText()

            if not metric_key:
                unit_short = "days"
                display_intervals = intervals
                weibull_display = weibull_fit_days
                usage_basis = days_basis
                km_curve_display = km_curve_days
                excluded_n = 0
                day_rate = None
            else:
                unit_short = metric_key
                usage_basis = "%s = %s" % (scope, scope_value)
                display_intervals, excluded_n, day_rate = lf_build_usage_dataset(
                    intervals, metric_key, mode=self.coverage_mode_combo.currentText())
                weibull_display = lf_fit_weibull(display_intervals) if model.startswith("Weibull") else None
                if model.startswith("Weibull") and not weibull_display:
                    for label, ivs in fallback_chain[1:]:  # skip the exact scope, already tried
                        cand_intervals, cand_excl, cand_rate = lf_build_usage_dataset(
                            ivs, metric_key, mode=self.coverage_mode_combo.currentText())
                        fit = lf_fit_weibull(cand_intervals)
                        if fit:
                            weibull_display, usage_basis = fit, label
                            display_intervals, excluded_n, day_rate = cand_intervals, cand_excl, cand_rate
                            break
                km_curve_display = lf_kaplan_meier(display_intervals)

            km_median_display = lf_km_median(km_curve_display)
            max_axis = max([i["days"] for i in display_intervals] + [1])
            if weibull_display and weibull_display.get("median_life_days"):
                # The Weibull curve may come from a broader fallback scope with a very
                # different scale than the exact scope's own (possibly tiny) interval range.
                # Without this, the curve renders as a flat, invisible line near 100% because
                # the plotted x-range never reaches anywhere near its median/decay region.
                max_axis = max(max_axis, weibull_display["median_life_days"] * 1.4)
            raw_points = [(i["days"], i["censored"]) for i in display_intervals]
            title = "%s = %s (%s)" % (scope, scope_value, component_type)
            self.chart.set_data(km_curve_display, weibull_display, max_axis,
                                 unit_label=unit_short, raw_points=raw_points, title_text=title)

            lines = [
                "Model: %s | Life Axis: %s" % (model, axis_label),
                "Scope: %s = %s | Component Type: %s" % (scope, scope_value, component_type),
                "Unknown handling: %s" % self.scenario_combo.currentText(),
                "'Now' reference: %s" % (
                    "%s (from Main Analysis last log date)" % now_override.strftime("%Y/%m/%d")
                    if now_override else "today's calendar date"),
                "Intervals in scope: %d (uncensored/failure-like: %d, censored: %d)" % (n_total, n_unc, n_total - n_unc),
            ]
            if metric_key:
                lines.append("Coverage Mode: %s" % self.coverage_mode_combo.currentText())
                lines.append(
                    "Real log-derived data used for this axis: %d of %d intervals qualify under this mode "
                    "(%d excluded)." % (
                        len(display_intervals), n_total, excluded_n))
            lines.append("")

            if weibull_display:
                basis_for_axis = usage_basis if metric_key else days_basis
                if basis_for_axis != "%s = %s" % (scope, scope_value):
                    lines.append(
                        "Note: SN/scope-level data was too sparse to fit Weibull on its own, so this "
                        "fit uses the broader scope '%s' instead (the forecast below still applies it "
                        "to your selected unit(s))." % basis_for_axis)
                lines.append("Weibull MLE (censored), fit on %s: shape k=%.3f, scale lambda=%.1f %s" % (
                    unit_short, weibull_display["k_shape"], weibull_display["lambda_scale_days"], unit_short))
                lines.append("  Mean life: %.1f %s | Median life: %.1f %s" % (
                    weibull_display["mean_life_days"], unit_short, weibull_display["median_life_days"], unit_short))
                if metric_key and day_rate:
                    lines.append("  Estimated day equivalent (using this data's own implied rate ~%.4g %s/day): "
                                 "mean %.1f days (%.2f yrs) | median %.1f days (%.2f yrs)" % (
                                     day_rate, unit_short,
                                     weibull_display["mean_life_days"] / day_rate, weibull_display["mean_life_days"] / day_rate / 365.25,
                                     weibull_display["median_life_days"] / day_rate, weibull_display["median_life_days"] / day_rate / 365.25))
                elif not metric_key:
                    lines.append("  (%.2f yrs mean / %.2f yrs median)" % (
                        weibull_display["mean_life_days"] / 365.25, weibull_display["median_life_days"] / 365.25))
            elif model.startswith("Weibull"):
                lines.append("Weibull fit unavailable on %s: need at least 2 uncensored (failure-type) events and "
                             "4 total intervals, even after trying broader scopes up to Global. Not enough "
                             "replacement-history data exists for %s yet." % (unit_short, component_type))
            if simple:
                lines.append("Simple average interval (uncensored only): %.1f days (%.2f yrs), n=%d" % (
                    simple["mean_interval_days"], simple["mean_interval_days"] / 365.25, simple["n"]))
            if km_median_display is not None:
                extra = ""
                if metric_key and day_rate:
                    extra = " (est. %.1f days / %.2f yrs)" % (km_median_display / day_rate, km_median_display / day_rate / 365.25)
                lines.append("Kaplan-Meier median (all-cause, non-parametric): %.1f %s%s" % (km_median_display, unit_short, extra))
            else:
                lines.append("Kaplan-Meier median: not reached (majority still censored/excluded)")

            self.summary_label.setText("\n".join(lines))

            forecast_rows = lf_forecast_for_scope(intervals, hosp_by_sn, weibull_fit_days, now=now_override)
            self._last_intervals, self._last_hosp, self._last_fit, self._last_forecast_rows = (
                display_intervals, hosp_by_sn, weibull_display, forecast_rows)

            self.forecast_table.setColumnCount(7)
            self.forecast_table.setHorizontalHeaderLabels(
                ["SN", "Hospital", "Country/Region", "Last Event", "Age (days)", "Forecast Date",
                 "Residual (est. %s)" % unit_short if metric_key else "Residual (days)"])
            self.forecast_table.setRowCount(len(forecast_rows))
            for r, row in enumerate(forecast_rows):
                self.forecast_table.setItem(r, 0, QtWidgets.QTableWidgetItem(row["sn"]))
                self.forecast_table.setItem(r, 1, QtWidgets.QTableWidgetItem(row["hospital"]))
                self.forecast_table.setItem(r, 2, QtWidgets.QTableWidgetItem("%s / %s" % (row["country"], row["region"])))
                self.forecast_table.setItem(r, 3, QtWidgets.QTableWidgetItem(row["last_event_date"].strftime("%Y/%m/%d")))
                self.forecast_table.setItem(r, 4, QtWidgets.QTableWidgetItem(str(row["age_days"])))
                fd = row["forecast_date"].strftime("%Y/%m/%d") if row["forecast_date"] else "(n/a - no Weibull fit in scope)"
                self.forecast_table.setItem(r, 5, QtWidgets.QTableWidgetItem(fd))
                resid_disp = row["residual_days"]
                if resid_disp is not None and metric_key and day_rate:
                    resid_disp = round(resid_disp * day_rate, 1)
                self.forecast_table.setItem(r, 6, QtWidgets.QTableWidgetItem(str(resid_disp) if resid_disp is not None else ""))
            self.forecast_table.resizeColumnsToContents()
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def export_excel(self):
        if not self._last_intervals and not self._last_forecast_rows:
            QMessageBox.warning(self, APP_NAME, "Run Calculate first.")
            return
        try:
            path, _ = QtWidgets.QFileDialog.getSaveFileName(
                self, "Export Life Forecast", "LifeForecast_Export.xlsx", "Excel Files (*.xlsx)")
            if not path:
                return
            wb = Workbook()
            wb.remove(wb.active)

            ws = wb.create_sheet("Intervals")
            headers = ["sn", "hospital", "country", "region", "start", "end", "days", "censored", "event_type"]
            for c, h in enumerate(headers, 1):
                ws.cell(1, c, h).font = Font(bold=True)
            for r, i in enumerate(self._last_intervals, 2):
                ws.cell(r, 1, i["sn"]); ws.cell(r, 2, i["hospital"]); ws.cell(r, 3, i["country"])
                ws.cell(r, 4, i["region"]); ws.cell(r, 5, i["start"].strftime("%Y/%m/%d"))
                ws.cell(r, 6, i["end"].strftime("%Y/%m/%d")); ws.cell(r, 7, i["days"])
                ws.cell(r, 8, "Yes" if i["censored"] else "No"); ws.cell(r, 9, i["event_type"])

            ws2 = wb.create_sheet("Forecast")
            headers2 = ["sn", "hospital", "country", "region", "last_event_date", "age_days", "forecast_date"]
            for c, h in enumerate(headers2, 1):
                ws2.cell(1, c, h).font = Font(bold=True)
            for r, row in enumerate(self._last_forecast_rows, 2):
                ws2.cell(r, 1, row["sn"]); ws2.cell(r, 2, row["hospital"]); ws2.cell(r, 3, row["country"])
                ws2.cell(r, 4, row["region"]); ws2.cell(r, 5, row["last_event_date"].strftime("%Y/%m/%d"))
                ws2.cell(r, 6, row["age_days"])
                ws2.cell(r, 7, row["forecast_date"].strftime("%Y/%m/%d") if row["forecast_date"] else "")

            ws3 = wb.create_sheet("Fit_Summary")
            ws3.cell(1, 1, "Algorithm Version").font = Font(bold=True)
            ws3.cell(1, 2, ALGORITHM_VERSION)
            if self._last_fit:
                for i, (k, v) in enumerate(self._last_fit.items(), 2):
                    ws3.cell(i, 1, k); ws3.cell(i, 2, v)

            wb.save(path)
            QMessageBox.information(self, APP_NAME, "Exported:\n%s" % path)
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def open_db_status_by_sn(self):
        try:
            hosp_by_sn = lf_load_hospitals()
            events_by_sn = lf_load_events()
            all_cov = read_master_foundation_rows("Log_Coverage_History.xlsx", LOG_COVERAGE_HEADERS)
            all_gaps = read_master_foundation_rows("Log_Gap_Classification.xlsx", LOG_GAP_HEADERS)

            cov_by_sn = {}
            for r in all_cov:
                cov_by_sn.setdefault(normalize_text_value(r.get("Serial Number")), []).append(r)
            gaps_by_sn = {}
            for r in all_gaps:
                gaps_by_sn.setdefault(normalize_text_value(r.get("Serial Number")), []).append(r)

            all_sn = sorted(set(list(hosp_by_sn.keys()) + list(events_by_sn.keys()) + list(cov_by_sn.keys())))
            rows = []
            for sn in all_sn:
                meta = hosp_by_sn.get(sn, {})
                evs = events_by_sn.get(sn, [])
                last_repl = max((e["date"] for e in evs), default=None)
                cov_rows = cov_by_sn.get(sn, [])
                total_runtime = sum(float(r.get("Observed Runtime Hours", 0) or 0) for r in cov_rows)
                starts = [parse_date_value(r.get("Period Start")) for r in cov_rows if r.get("Period Start")]
                ends = [parse_date_value(r.get("Period End")) for r in cov_rows if r.get("Period End")]
                gap_rows = gaps_by_sn.get(sn, [])
                n_idle = sum(1 for r in gap_rows if r.get("Classification") == LF_GAP_IDLE)
                n_unknown = sum(1 for r in gap_rows if r.get("Classification") == LF_GAP_UNKNOWN)
                n_gaps_detected = len(lf_detect_gaps(sn)) if len(cov_rows) >= 2 else 0
                n_unclassified = max(n_gaps_detected - n_idle - n_unknown, 0)
                rows.append({
                    "sn": sn,
                    "hospital": meta.get("hospital_name", "") if meta else "",
                    "country": meta.get("country", "") if meta else "(no Hospital_Master entry)",
                    "region": meta.get("region", "") if meta else "",
                    "status": meta.get("status", "") if meta else "",
                    "n_replacements": len(evs),
                    "last_replacement": last_repl.strftime("%Y/%m/%d") if last_repl else "",
                    "n_sessions": len(cov_rows),
                    "total_runtime": round(total_runtime, 1),
                    "span": "%s -> %s" % (min(starts).strftime("%Y/%m/%d"), max(ends).strftime("%Y/%m/%d")) if starts and ends else "",
                    "gaps": "%d idle / %d unknown / %d unclassified" % (n_idle, n_unknown, n_unclassified) if (n_idle or n_unknown or n_unclassified) else "",
                })

            dlg = QtWidgets.QDialog(self)
            dlg.setWindowTitle("Database Status by SN (%d units)" % len(rows))
            dlg.resize(1080, 480)
            lay = QVBoxLayout(dlg)
            lay.addWidget(QLabel(
                "One row per Serial Number known anywhere in the database "
                "(Hospital_Master, Replacement_History, or Log_Coverage_History)."))
            table = QtWidgets.QTableWidget()
            headers = ["SN", "Hospital", "Country", "Region", "Status", "Replacement Events",
                       "Last Replacement", "Log Sessions", "Total Runtime Hrs", "Log Span", "Gaps"]
            table.setColumnCount(len(headers))
            table.setHorizontalHeaderLabels(headers)
            table.setRowCount(len(rows))
            for r, row in enumerate(rows):
                for c, key in enumerate(["sn", "hospital", "country", "region", "status", "n_replacements",
                                          "last_replacement", "n_sessions", "total_runtime", "span", "gaps"]):
                    table.setItem(r, c, QtWidgets.QTableWidgetItem(str(row[key])))
            table.resizeColumnsToContents()
            lay.addWidget(table, 1)

            btn_row2 = QHBoxLayout()
            lay.addLayout(btn_row2)
            btn_row2.addStretch(1)

            def export_status():
                try:
                    path, _ = QtWidgets.QFileDialog.getSaveFileName(
                        dlg, "Export Database Status", "Database_Status_By_SN.xlsx", "Excel Files (*.xlsx)")
                    if not path:
                        return
                    wb = Workbook()
                    ws = wb.active
                    ws.title = "Status_By_SN"
                    for c, h in enumerate(headers, 1):
                        ws.cell(1, c, h).font = Font(bold=True)
                    for r_idx, row in enumerate(rows, 2):
                        for c, key in enumerate(["sn", "hospital", "country", "region", "status", "n_replacements",
                                                  "last_replacement", "n_sessions", "total_runtime", "span", "gaps"], 1):
                            ws.cell(r_idx, c, row[key])
                    wb.save(path)
                    QMessageBox.information(dlg, APP_NAME, "Exported:\n%s" % path)
                except Exception:
                    QMessageBox.critical(dlg, APP_NAME, traceback.format_exc())

            b_exp = QPushButton("Export to Excel...")
            b_exp.clicked.connect(export_status)
            btn_row2.addWidget(b_exp)
            b_close = QPushButton("Close")
            b_close.clicked.connect(dlg.accept)
            btn_row2.addWidget(b_close)
            dlg.exec()
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def export_database_to_excel(self):
        try:
            default_name = "WaterSystemAnalyzer_DB_Export_%s.xlsx" % dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            path, _ = QtWidgets.QFileDialog.getSaveFileName(
                self, "Export Database to Excel", default_name, "Excel Files (*.xlsx)")
            if not path:
                return
            tables = [
                ("Hospital_Master.xlsx", HP_MASTER_HEADERS),
                ("Component_Master.xlsx", COMPONENT_MASTER_HEADERS),
                ("Replacement_History.xlsx", REPLACEMENT_HISTORY_HEADERS),
                ("Log_Coverage_History.xlsx", LOG_COVERAGE_HEADERS),
                ("Log_Gap_Classification.xlsx", LOG_GAP_HEADERS),
            ]
            wb = Workbook()
            wb.remove(wb.active)
            counts = []
            for fname, headers in tables:
                rows = read_master_foundation_rows(fname, headers)
                sheet_name = os.path.splitext(fname)[0][:31]
                ws = wb.create_sheet(sheet_name)
                for c, h in enumerate(headers, 1):
                    cell = ws.cell(1, c, h)
                    cell.font = Font(bold=True)
                    cell.fill = PatternFill("solid", fgColor="D9EAF7")
                for r_idx, row in enumerate(rows, 2):
                    for c, h in enumerate(headers, 1):
                        ws.cell(r_idx, c, row.get(h, ""))
                ws.freeze_panes = "A2"
                for c in range(1, len(headers) + 1):
                    ws.column_dimensions[get_column_letter(c)].width = max(14, len(headers[c - 1]) + 3)
                counts.append("  %s: %d rows" % (sheet_name, len(rows)))
            wb.save(path)
            QMessageBox.information(
                self, APP_NAME, "Exported database to:\n%s\n\n%s" % (path, "\n".join(counts)))
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def backup_database_now(self):
        try:
            db_path = wsdb_path()
            if not os.path.exists(db_path):
                QMessageBox.warning(self, APP_NAME, "No database file found yet at:\n%s" % db_path)
                return
            backup_dir = os.path.join(get_data_root(), "Backup")
            os.makedirs(backup_dir, exist_ok=True)
            ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            dest = os.path.join(backup_dir, "WaterSystemAnalyzer_%s.db" % ts)
            shutil.copy2(db_path, dest)
            size_kb = os.path.getsize(dest) / 1024.0
            QMessageBox.information(
                self, APP_NAME, "Database backed up to:\n%s\n\nSize: %.1f KB" % (dest, size_kb))
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def optimize_database(self):
        try:
            db_path = wsdb_path()
            if not os.path.exists(db_path):
                QMessageBox.warning(self, APP_NAME, "No database file found yet at:\n%s" % db_path)
                return
            before_kb = os.path.getsize(db_path) / 1024.0
            conn = wsdb_connect()
            try:
                conn.execute("VACUUM")
                conn.commit()
            finally:
                conn.close()
            after_kb = os.path.getsize(db_path) / 1024.0
            QMessageBox.information(
                self, APP_NAME,
                "Database optimized.\n\nSize before: %.1f KB\nSize after: %.1f KB" % (before_kb, after_kb))
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def import_asm_file(self):
        try:
            path, _ = QtWidgets.QFileDialog.getOpenFileName(
                self, "Import ASM Replacement History", "", "Excel Files (*.xlsx)")
            if not path:
                return
            result = lf_import_asm_replacement_file(path)
            QMessageBox.information(
                self, APP_NAME,
                "Import complete from %s\n\n"
                "Source rows read: %d\n"
                "Hospital_Master: %d added, %d updated\n"
                "Replacement_History: %d added, %d updated, %d skipped (still-open cases / no date)\n\n"
                "Re-run this same import later on an updated version of this file to refresh - "
                "matching rows are updated in place, not duplicated." % (
                    os.path.basename(path), result["source_rows"],
                    result["hospitals_added"], result["hospitals_updated"],
                    result["history_added"], result["history_updated"], result["history_skipped"])
            )
            self.refresh_scope_values()
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def open_hospital_master(self):
        try:
            dlg = MasterFoundationDialog(self)
            dlg.exec()
            lf_clear_cache()
            self.refresh_scope_values()
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def open_replacement_import(self):
        try:
            dlg = ReplacementImportWizard(self)
            dlg.exec()
            lf_clear_cache()
            self.refresh_scope_values()
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())



class AnalyzerWindow(QMainWindow):
    def __init__(self):
        super(AnalyzerWindow, self).__init__()
        self.setWindowTitle("%s %s" % (APP_NAME, APP_VERSION))
        self.resize(1280, 800)

        self.folder = ""
        self.result_file = ""
        self.rows = []
        self.summary_rows = []
        self.worker = None
        self.analysis_active = False
        self.checks = {}
        self.session_state = rc_read_json(rc_session_path(), {})
        self.workflow_last_status = ""

        self.resize(1600, 900)
        self.setMinimumSize(1100, 720)
        self.setStyleSheet("QPushButton{min-height:24px;} QLineEdit{min-height:24px;} QCheckBox{min-height:22px;}")
        self._ui()
        ensure_data_folders()
        self.restore_session_state(silent=True)
        self.workflow_timer = QtCore.QTimer(self)
        self.workflow_timer.timeout.connect(self.update_interactive_workflow)
        self.workflow_timer.start(1200)
        self.update_interactive_workflow()
        self.status.setText("Ready. Select a WaterSystem folder or ResultSummary file to start.")

    def _ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        main = QHBoxLayout(root)

        panel = QWidget()
        panel.setMinimumWidth(300)
        panel.setMaximumWidth(520)
        self.panel = panel
        panel.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Preferred
        )
        self.panel_scroll = QScrollArea()
        self.panel_scroll.setWidgetResizable(True)
        self.panel_scroll.setHorizontalScrollBarPolicy(
            QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self.panel_scroll.setMinimumWidth(320)
        self.panel_scroll.setMaximumWidth(540)
        self.panel_scroll.setWidget(panel)
        self.menu_collapsed = False
        self.menu_button_widgets = []
        pl = QVBoxLayout(panel)

        self.btn_menu_toggle = QPushButton("▼ Menu")
        self.btn_menu_toggle.clicked.connect(self.toggle_menu_panel)
        pl.addWidget(self.btn_menu_toggle)

        # Main workflow groups.
        self.project_group = self.create_group("Project", expanded=True)
        project_lay = self.project_group["layout"]
        pl.addWidget(self.project_group["box"])

        project_header = QLabel(
            "<div style='font-size:18px; font-weight:700;'>PROJECT</div>"
            "<div style='color:#667;'>Drop is primary. Browse remains available as a fallback.</div>"
        )
        project_header.setWordWrap(True)
        project_lay.addWidget(project_header)

        self.source_summary_card = ProjectSummaryCard()
        self.source_summary_card.changeSourceRequested.connect(
            self.show_project_drop_area
        )
        project_lay.addWidget(self.source_summary_card)

        self.folder_drop_area = DropAreaWidget(
            "Drop WaterSystem Folder or ZIP Here",
            "Folder / ZIP — ZIP is extracted automatically",
            accepted_extensions=[".zip"],
            accept_folders=True,
        )
        self.folder_drop_area.pathDropped.connect(
            self.handle_project_folder_path
        )
        self.folder_drop_area.clicked.connect(self.select_folder)
        project_lay.addWidget(self.folder_drop_area)

        self.folder_box = QLineEdit()
        self.folder_box.setReadOnly(True)
        self.folder_box.setVisible(False)
        project_lay.addWidget(self.folder_box)

        folder_browse_row = QHBoxLayout()
        browse_folder = QPushButton("Browse Folder...")
        browse_folder.clicked.connect(self.browse_water_system_folder)
        folder_browse_row.addWidget(browse_folder)
        browse_zip = QPushButton("Browse ZIP...")
        browse_zip.clicked.connect(self.browse_water_system_zip)
        folder_browse_row.addWidget(browse_zip)
        folder_browse_row.addStretch(1)
        project_lay.addLayout(folder_browse_row)

        self.result_summary_card = ResultSummaryCard()
        self.result_summary_card.browseRequested.connect(self.select_result_file)
        self.result_summary_card.changeRequested.connect(self.show_result_drop_area)
        project_lay.addWidget(self.result_summary_card)

        self.result_drop_area = DropAreaWidget(
            "Drop ResultSummary Here",
            "XLSX / XLSM",
            accepted_extensions=[".xlsx", ".xlsm"],
        )
        self.result_drop_area.pathDropped.connect(
            self.handle_result_summary_path
        )
        self.result_drop_area.clicked.connect(self.select_result_file)
        project_lay.addWidget(self.result_drop_area)

        self.result_box = QLineEdit()
        self.result_box.setReadOnly(True)
        self.result_box.setVisible(False)
        project_lay.addWidget(self.result_box)

        self.use_existing_result_check = QCheckBox("Use existing ResultSummary")
        self.use_existing_result_check.setChecked(False)
        self.use_existing_result_check.setToolTip(
            "OFF: analyze only log files. ON: merge with latest ResultSummary "
            "if no explicit file is selected."
        )
        project_lay.addWidget(self.use_existing_result_check)

        self.session_box = QtWidgets.QGroupBox("Previous Session")
        session_lay = QVBoxLayout(self.session_box)
        self.session_summary_label = QLabel("")
        self.session_summary_label.setWordWrap(True)
        session_lay.addWidget(self.session_summary_label)
        session_buttons = QHBoxLayout()
        self.continue_session_button = QPushButton("Continue Previous")
        self.continue_session_button.clicked.connect(
            lambda: self.restore_session_state(silent=False)
        )
        session_buttons.addWidget(self.continue_session_button)
        new_session_button = QPushButton("Start New")
        new_session_button.clicked.connect(self.start_new_session)
        session_buttons.addWidget(new_session_button)
        session_lay.addLayout(session_buttons)
        project_lay.addWidget(self.session_box)
        self.session_box.setVisible(False)

        self.analysis_group = self.create_group("Analysis", expanded=False)
        analysis_lay = self.analysis_group["layout"]
        pl.addWidget(self.analysis_group["box"])

        self.btn_analyze = QPushButton("Analyze / Update ResultSummary")
        self.btn_analyze.clicked.connect(self.start_analyze)
        analysis_lay.addWidget(self.btn_analyze)

        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self.cancel_analyze)
        self.btn_cancel.setEnabled(False)
        analysis_lay.addWidget(self.btn_cancel)

        b = QPushButton("Save / Update ResultSummary")
        b.clicked.connect(self.save_result_summary_action)
        analysis_lay.addWidget(b)

        b = QPushButton("Refresh Current Chart")
        b.clicked.connect(self.update_chart)
        analysis_lay.addWidget(b)

        self.forecast_group = self.create_group("Forecast", expanded=True)
        try:
            self.forecast_group["box"].setToolTip(
                "Follow the numbered reliability and forecast workflow."
            )
        except Exception:
            pass
        pl.addWidget(self.forecast_group["box"])

        forecast_lay = self.forecast_group["layout"]

        self.workflow_assistant = WorkflowAssistantCard()
        self.workflow_assistant.configure_steps([
            (1, "replacement", "Import / Manage Replacement History"),
            (2, "runtime", "Runtime Reconstruction"),
            (3, "explainable", "Explainable Reliability"),
            (4, "dashboard_preview", "Dashboard Review"),
            (5, "forecast", "Calculate Forecast"),
            (6, "foundation", "Forecast Foundation / Data Coverage"),
            (7, "reliability_dashboard", "Reliability Dashboard"),
        ])
        self.workflow_assistant.actionRequested.connect(self.run_workflow_action)
        forecast_lay.addWidget(self.workflow_assistant)

        self.btn_replacement_history = self.workflow_assistant._buttons["replacement"]
        self.btn_runtime_reconstruction = self.workflow_assistant._buttons["runtime"]
        self.btn_explainable_reliability = self.workflow_assistant._buttons["explainable"]
        self.btn_dashboard_preview = self.workflow_assistant._buttons["dashboard_preview"]
        self.btn_forecast_calculate = self.workflow_assistant._buttons["forecast"]
        self.btn_reliability_dashboard = self.workflow_assistant._buttons["reliability_dashboard"]

        b = QPushButton("Link Analyzed Logs to Database (SN / Hospital / Country / Region)")
        b.setToolTip(
            "Link the currently analyzed WaterSystem logs to a Serial Number, resolve its "
            "Hospital/Country/Region (registering it if new), and append this session to the "
            "growing Log_Coverage_History.xlsx database. Run this each time you analyze a new "
            "log batch to keep building up the database over time."
        )
        b.clicked.connect(self.link_log_to_database_action)
        forecast_lay.addWidget(b)

        b = QPushButton("Life Forecast (Weibull / Kaplan-Meier)")
        b.setToolTip(
            "Model- and scope-selectable survival analysis (Weibull MLE with censoring, "
            "Kaplan-Meier, or simple average interval) by Global / Region / Country / Hospital, "
            "with a native chart and Excel export."
        )
        b.clicked.connect(self.open_life_forecast_dialog)
        forecast_lay.addWidget(b)

        self.master_group = self.create_group("Masters", expanded=False)
        try:
            self.master_group["box"].setToolTip("Create and maintain Hospital, Component, Section, Failure Type, and Replacement Type masters.")
        except Exception:
            pass
        master_lay = self.master_group["layout"]
        pl.addWidget(self.master_group["box"])

        b = QPushButton("Master Foundation")
        b.clicked.connect(self.open_master_foundation)
        master_lay.addWidget(b)

        b = QPushButton("Data Foundation")
        b.setToolTip("Create/check Section Master, Failure Type Master, Replacement Type Master, Model Config, and Project metadata.")
        b.clicked.connect(self.data_foundation_action)
        master_lay.addWidget(b)

        self.migration_group = self.create_group("Backup / Migration", expanded=False)
        try:
            self.migration_group["box"].setToolTip("Backup, restore, release package, migration, and data movement tools.")
        except Exception:
            pass
        migration_lay = self.migration_group["layout"]
        pl.addWidget(self.migration_group["box"])

        b = QPushButton("Export Release Package")
        b.clicked.connect(self.export_release_package)
        migration_lay.addWidget(b)

        b = QPushButton("Import Release Package")
        b.clicked.connect(self.import_release_package)
        migration_lay.addWidget(b)

        b = QPushButton("Project Backup")
        b.clicked.connect(self.project_backup)
        migration_lay.addWidget(b)

        b = QPushButton("Restore Project Backup (Drop ZIP)")
        b.clicked.connect(self.restore_project_backup)
        migration_lay.addWidget(b)

        b = QPushButton("Migration Wizard")
        b.clicked.connect(self.migration_wizard)
        migration_lay.addWidget(b)

        b = QPushButton("Move Data Folder")
        b.clicked.connect(self.move_data_folder)
        migration_lay.addWidget(b)

        b = QPushButton("Module Update (Drop ZIP)")
        b.setToolTip("Select an update ZIP, inspect manifest.json, run a dry run, create safety metadata backup, and stage the update.")
        b.clicked.connect(self.module_update_foundation_action)
        migration_lay.addWidget(b)

        self.tools_group = self.create_group("Tools / Debug", expanded=False)
        try:
            self.tools_group["box"].setToolTip("Validation and diagnostic tools for internal checks.")
        except Exception:
            pass
        tools_lay = self.tools_group["layout"]
        pl.addWidget(self.tools_group["box"])

        b = QPushButton("Scan Folder Check")
        b.clicked.connect(self.scan_folder_check)
        tools_lay.addWidget(b)

        b = QPushButton("Date Parse Check")
        b.clicked.connect(self.date_parse_check)
        tools_lay.addWidget(b)

        b = QPushButton("Show Analyze Debug")
        b.clicked.connect(self.show_analyze_debug)
        tools_lay.addWidget(b)

        b = QPushButton("Show Analyze Performance")
        b.clicked.connect(self.show_analyze_performance)
        tools_lay.addWidget(b)

        b = QPushButton("Show Current Data Count")
        b.clicked.connect(self.show_current_data_count)
        tools_lay.addWidget(b)

        b = QPushButton("ResultSummary Check")
        b.clicked.connect(self.resultsummary_check)
        tools_lay.addWidget(b)

        b = QPushButton("Validate Masters")
        b.clicked.connect(self.validate_masters)
        tools_lay.addWidget(b)

        b = QPushButton("Migration Check")
        b.clicked.connect(self.migration_check)
        tools_lay.addWidget(b)

        b = QPushButton("Backup Manager")
        b.clicked.connect(self.backup_manager)
        tools_lay.addWidget(b)

        b = QPushButton("Show Data Location")
        b.clicked.connect(self.show_data_location)
        tools_lay.addWidget(b)

        b = QPushButton("Open Data Folder")
        b.clicked.connect(self.open_data_folder)
        tools_lay.addWidget(b)

        self.progress = QProgressBar()
        pl.addWidget(self.progress)

        self.chart_controls_group = self.create_group("Chart Controls", expanded=False)
        self.chart_controls_group["box"].setToolTip("Open manually only. Chart loading and chart clicks do not open this section.")
        pl.addWidget(self.chart_controls_group["box"])
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMinimumHeight(250)
        ctrl = QWidget()
        cl = QVBoxLayout(ctrl)
        scroll.setWidget(ctrl)
        self.chart_controls_group["layout"].addWidget(scroll)

        cl.addWidget(QLabel("<b>Chart Controls</b><br><span style='color:#667;'>Open only when needed.</span>"))

        self.tooltip_mode_combo = self.add_combo(cl, "Popup Mode", ["Point", "Crosshair", "Off"])
        self.tooltip_mode_combo.currentTextChanged.connect(lambda v: self.chart_view.set_tooltip_mode(v))

        self.all_check = QCheckBox("ALL")
        self.all_check.setChecked(True)
        self.all_check.setStyleSheet("font-weight: bold; text-decoration: underline;")
        self.all_check.stateChanged.connect(lambda _=None: self.set_all())
        cl.addWidget(self.all_check)

        self.daily_group_check = QCheckBox("DAILY")
        self.daily_group_check.setChecked(True)
        self.daily_group_check.setStyleSheet("font-weight: bold; text-decoration: underline;")
        self.daily_group_check.stateChanged.connect(lambda _=None: self.set_group("daily"))
        cl.addWidget(self.daily_group_check)
        for n in ["Treat", "Degas", "Clean", "Runtime"]:
            self.add_check(cl, n, "daily")

        self.cum_group_check = QCheckBox("CUMULATIVE")
        self.cum_group_check.setChecked(True)
        self.cum_group_check.setStyleSheet("font-weight: bold; text-decoration: underline;")
        self.cum_group_check.stateChanged.connect(lambda _=None: self.set_group("cum"))
        cl.addWidget(self.cum_group_check)
        for n in ["Treat Cum", "Degas Cum", "Clean Cum", "Runtime Cum"]:
            self.add_check(cl, n, "cum")

        self.pause_group_check = QCheckBox("PAUSE/ERROR")
        self.pause_group_check.setChecked(True)
        self.pause_group_check.setStyleSheet("font-weight: bold; text-decoration: underline;")
        self.pause_group_check.stateChanged.connect(lambda _=None: self.set_group("pause"))
        cl.addWidget(self.pause_group_check)
        for n in ["DEGAS_PAUSE", "TREAT_PAUSE", "ERROR", "DEGAS_PAUSE Cum", "TREAT_PAUSE Cum", "ERROR Cum"]:
            self.add_check(cl, n, "pause")

        # X Start / End are intentionally hidden. Chart uses drag zoom / double click reset.
        self.x_start = QComboBox()
        self.x_start.addItems(["Auto"])
        self.x_end = QComboBox()
        self.x_end.addItems(["Auto"])
        self.cum_start = self.add_combo(cl, "Cum Start Date / Time")
        self.cum_end = self.add_combo(cl, "Cum End Date / Time")
        self.display_size = self.add_combo(cl, "Display Size", ["Auto Fit", "Laptop", "Full HD", "QHD", "4K"])
        self.forecast_mode = self.add_combo(cl, "Forecast Mode", ["Failure only", "Preventive included", "Compare both"])
        self.forecast_scope = self.add_combo(cl, "Forecast Scope", ["Current SN", "Same Hospital", "Selected Hospitals", "All Hospitals"])
        self.missing_log_handling = self.add_combo(cl, "Missing Log Handling", ["Unknown", "Estimated Usage", "Conservative"])

        b = QPushButton("Clear change")
        b.clicked.connect(self.clear_change)
        cl.addWidget(b)
        cl.addStretch(1)

        self.status = QLabel("Select a folder. Folder selection does not start analysis.")
        self.status.setWordWrap(True)
        pl.addWidget(self.status)

        chart = QWidget()
        chl = QVBoxLayout(chart)
        self.chart_view = NativeChartView()
        self.chart_view.installEventFilter(self)
        try:
            self.chart_view.viewport().installEventFilter(self)
        except Exception:
            pass
        chl.addWidget(self.chart_view)

        main.addWidget(self.panel_scroll, 0)
        main.addWidget(chart, 1)


    def create_group(self, title, expanded=True):
        box = QtWidgets.QGroupBox()
        box.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Preferred)
        outer = QVBoxLayout(box)
        outer.setContentsMargins(6, 6, 6, 6)
        btn = QPushButton(("▼ " if expanded else "▶ ") + title)
        content = QWidget()
        lay = QVBoxLayout(content)
        lay.setContentsMargins(8, 4, 4, 4)
        content.setVisible(expanded)
        outer.addWidget(btn)
        outer.addWidget(content)
        group = {"box": box, "button": btn, "content": content, "layout": lay, "title": title}
        def toggle():
            self.expand_only_group(group if not content.isVisible() else None)
        btn.clicked.connect(toggle)
        return group

    def expand_only_group(self, target_group):
        for grp_name in ["project_group", "analysis_group", "forecast_group", "master_group", "migration_group", "tools_group", "chart_controls_group"]:
            grp = getattr(self, grp_name, None)
            if not grp:
                continue
            vis = (grp is target_group)
            grp["content"].setVisible(vis)
            grp["button"].setText(("▼ " if vis else "▶ ") + grp["title"])
        try:
            self.panel_scroll.setMinimumWidth(320)
        except Exception:
            pass


    def collect_menu_button_widgets(self):
        try:
            widgets = []
            for grp_name in ["project_group", "analysis_group", "forecast_group", "master_group", "migration_group", "tools_group", "chart_controls_group"]:
                grp = getattr(self, grp_name, None)
                if grp:
                    widgets.append(grp["box"])
            self.menu_button_widgets = widgets
        except Exception:
            self.menu_button_widgets = []


    def set_menu_collapsed(self, collapsed=True):
        self.menu_collapsed = collapsed
        self.collect_menu_button_widgets()
        for w in self.menu_button_widgets:
            w.setVisible(not collapsed)

        # Also hide path fields and result options when collapsed; keep checkboxes visible.
        for w in [getattr(self, "folder_box", None), getattr(self, "result_box", None), getattr(self, "use_existing_result_check", None)]:
            if w:
                w.setVisible(not collapsed)

        self.btn_menu_toggle.setText("▶ Menu" if collapsed else "▼ Menu")
        if collapsed:
            self.panel.setFixedWidth(260)
        else:
            self.panel_scroll.setMinimumWidth(320)

    def toggle_menu_panel(self):
        self.set_menu_collapsed(not getattr(self, "menu_collapsed", False))

    def collapse_menu_after_chart_ready(self):
        # No automatic menu or Chart Controls change after chart loading.
        return

    def eventFilter(self, obj, event):
        # Chart interaction never opens Chart Controls and never changes menu state.
        return super(AnalyzerWindow, self).eventFilter(obj, event)


    def add_check(self, layout, name, group=""):
        cb = QCheckBox("    " + name)
        cb.setChecked(True)
        cb.group = group
        cb.stateChanged.connect(lambda _=None: self.on_child_check_changed())
        self.checks[name] = cb
        layout.addWidget(cb)

    def add_combo(self, layout, label, values=None):
        layout.addWidget(QLabel(label))
        c = QComboBox()
        c.addItems(values or ["Auto"])
        c.currentIndexChanged.connect(self.update_chart)
        layout.addWidget(c)
        return c

    def apply_display_size(self):
        v = self.display_size.currentText()
        if v == "Laptop":
            self.resize(1180, 720)
        elif v == "Full HD":
            self.resize(1500, 900)
        elif v == "QHD":
            self.resize(1900, 1050)
        elif v == "4K":
            self.resize(2500, 1350)


    def show_project_drop_area(self):
        self.folder_drop_area.setVisible(True)
        self.folder_drop_area.set_compact(False)
        self.source_summary_card.setVisible(False)

    def show_result_drop_area(self):
        self.result_drop_area.setVisible(True)
        self.result_drop_area.set_compact(False)
        self.result_summary_card.setVisible(False)

    def compact_source_name(self, source_path):
        source_path = str(source_path or "")
        if not source_path:
            return ""
        return os.path.basename(os.path.normpath(source_path)) or source_path

    def update_project_source_card(self, source_path, detail):
        name = self.compact_source_name(source_path)
        self.source_summary_card.set_loaded(
            name,
            detail,
            source_path
        )
        self.source_summary_card.setVisible(True)
        self.folder_drop_area.setVisible(False)

    def update_result_summary_card(self, result_path):
        name = self.compact_source_name(result_path)
        self.result_summary_card.set_loaded(name, result_path)
        self.result_summary_card.setVisible(True)
        self.result_drop_area.setVisible(False)

    def browse_water_system_folder(self):
        folder = QtWidgets.QFileDialog.getExistingDirectory(
            self, "Select WaterSystem folder", self.folder or os.getcwd(),
            QtWidgets.QFileDialog.Option.ShowDirsOnly
            | QtWidgets.QFileDialog.Option.DontResolveSymlinks
        )
        if folder:
            self.folder_drop_area.handle_path(folder)

    def browse_water_system_zip(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Select WaterSystem ZIP", self.folder or os.getcwd(),
            "ZIP files (*.zip)"
        )
        if path:
            self.folder_drop_area.handle_path(path)

    def run_workflow_action(self, key):
        """Dispatch one workflow action without resolving unrelated methods."""
        action_names = {
            "replacement": "import_replacement_history_action",
            "runtime": "runtime_reconstruction_action",
            "explainable": "explainable_reliability_action",
            "dashboard_preview": "dashboard_preview_action",
            "forecast": "calculate_forecast_now",
            "foundation": "forecast_foundation_action",
            "reliability_dashboard": "reliability_dashboard_action",
        }
        method_name = action_names.get(key, "")
        if not method_name:
            QMessageBox.warning(
                self, APP_NAME,
                "Unknown workflow action: %s" % key
            )
            return

        action = getattr(self, method_name, None)
        if not callable(action):
            QMessageBox.critical(
                self, APP_NAME,
                "Workflow action is unavailable.\n\n"
                "Action: %s\nMethod: %s" % (key, method_name)
            )
            return

        try:
            action()
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def link_log_to_database_action(self):
        """Version 7.3 RC1-5: link the currently analyzed logs to a Serial Number, resolve
        that SN's Hospital/Country/Region (registering it if new), and append one row to the
        growing Log_Coverage_History.xlsx database (never overwritten - accumulates over time)."""
        try:
            if not self.summary_rows and getattr(self, "rows", None):
                self.summary_rows = build_summary_rows(self.rows)
            if not self.summary_rows:
                QMessageBox.warning(self, APP_NAME, "No chart/log summary data loaded. Run Analyze first.")
                return

            default_sn = lf_infer_current_sn(self)
            sn, ok = QInputDialog.getText(self, APP_NAME, "Serial Number for this log batch:", text=default_sn)
            if not ok or not sn.strip():
                return
            sn = sn.strip()

            existing = lf_lookup_hospital(sn)
            if existing:
                hospital_name = existing.get("Hospital Name") or existing.get("Site") or ""
                country = existing.get("Country") or ""
                region = existing.get("Region") or ""
            else:
                QMessageBox.information(
                    self, APP_NAME,
                    "SN %s is not yet in Hospital_Master. Please provide Hospital / Country / Region "
                    "so it can be registered (you can edit these later in Master Foundation)." % sn
                )
                hospital_name, ok1 = QInputDialog.getText(self, APP_NAME, "Hospital Name:")
                if not ok1:
                    return
                country, ok2 = QInputDialog.getText(self, APP_NAME, "Country:")
                if not ok2:
                    return
                region, ok3 = QInputDialog.getText(self, APP_NAME, "Region (e.g. Japan / APAC):")
                if not ok3:
                    return
                lf_register_hospital(sn, hospital_name.strip(), country.strip(), region.strip())

            row = lf_append_log_coverage(sn, hospital_name, country, region, self.folder, self.summary_rows,
                                          raw_rows=getattr(self, "rows", None))
            cov = lf_load_log_coverage(sn)
            QMessageBox.information(
                self, APP_NAME,
                "Linked to database.\n\n"
                "SN: %s | Hospital: %s | %s / %s\n"
                "This session: %s -> %s (%d rows, %.1f runtime hrs, %s clean count, "
                "%.1f treat / %.1f degas / %.1f clean circulate hrs)\n\n"
                "Accumulated so far for this SN: %d linked sessions, %.1f total runtime hrs, "
                "span %s -> %s" % (
                    sn, hospital_name, country, region,
                    row["Period Start"], row["Period End"], row["Rows Analyzed"], row["Observed Runtime Hours"],
                    row["Clean Count"], row["Treat Circulate Hours"], row["Degas Circulate Hours"],
                    row["Clean Circulate Hours"],
                    cov["n_sessions"], cov["total_runtime_hours"],
                    str(cov["earliest"])[:10] if cov["earliest"] else "n/a",
                    str(cov["latest"])[:10] if cov["latest"] else "n/a",
                )
            )
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def open_life_forecast_dialog(self):
        try:
            dlg = LifeForecastDialog(self)
            dlg.exec()
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def mark_dashboard_reviewed(self):
        rc_mark_workflow("dashboard_preview")
        self.update_interactive_workflow()

    def current_session_payload(self):
        expanded = "Project"
        for name, attr in [
            ("Project", "project_group"), ("Analysis", "analysis_group"), ("Forecast", "forecast_group"),
            ("Masters", "master_group"), ("Backup / Migration", "migration_group"), ("Tools / Debug", "tools_group")
        ]:
            grp = getattr(self, attr, None)
            if grp and grp["content"].isVisible():
                expanded = name
                break
        state = rc_read_json(rc_session_path(), {})
        state.update({
            "schema_version": SESSION_SCHEMA_VERSION,
            "software_version": APP_VERSION,
            "saved_at": dt.datetime.now().isoformat(timespec="seconds"),
            "water_system_folder": self.folder,
            "result_summary_file": self.result_file,
            "use_existing_result_summary": bool(self.use_existing_result_check.isChecked()),
            "expanded_menu": expanded,
            "dashboard_scope": state.get("dashboard_scope", "Hospital"),
            "dashboard_scope_target": state.get("dashboard_scope_target", ""),
        })
        return state

    def save_session_state(self):
        try:
            rc_write_json(rc_session_path(), self.current_session_payload())
        except Exception:
            pass

    def restore_session_state(self, silent=True):
        state = rc_read_json(rc_session_path(), {})
        folder = str(state.get("water_system_folder", "") or "")
        result_file = str(state.get("result_summary_file", "") or "")
        valid_folder = folder if os.path.isdir(folder) else ""
        valid_result = result_file if os.path.isfile(result_file) else ""

        if valid_folder:
            self.folder = valid_folder
            self.folder_box.setText(valid_folder)
            if hasattr(self, "folder_drop_area"):
                self.folder_drop_area.set_path(valid_folder, True)
            if hasattr(self, "source_summary_card"):
                self.update_project_source_card(valid_folder, "Previous folder")
        if valid_result:
            self.result_file = valid_result
            self.result_box.setText(valid_result)
            if hasattr(self, "result_drop_area"):
                self.result_drop_area.set_path(valid_result, True)
            if hasattr(self, "result_summary_card"):
                self.update_result_summary_card(valid_result)
            if not self.folder:
                self.folder = os.path.dirname(valid_result)
                self.folder_box.setText(self.folder)
        try:
            self.use_existing_result_check.setChecked(bool(state.get("use_existing_result_summary", False)))
        except Exception:
            pass

        summary = []
        if valid_folder:
            summary.append("Folder: %s" % valid_folder)
        if valid_result:
            summary.append("ResultSummary: %s" % valid_result)
        saved_at = state.get("saved_at", "")
        if saved_at:
            summary.append("Saved: %s" % saved_at)
        has_session = bool(valid_folder or valid_result)
        self.session_summary_label.setText(
            "<br>".join(summary) if summary else ""
        )
        self.continue_session_button.setEnabled(has_session)
        if hasattr(self, "session_box"):
            self.session_box.setVisible(has_session)

        # Basic start remains Project selection; restore only when user explicitly clicks Continue.
        if not silent and valid_result:
            self.select_result_file_from_path(valid_result)
        elif not silent:
            self.status.setText("Previous folder restored. Click Analyze / Update ResultSummary to continue.")
        self.update_interactive_workflow()

    def select_result_file_from_path(self, path):
        if not os.path.isfile(path):
            return
        self.result_file = path
        self.result_box.setText(path)
        if not self.folder:
            self.folder = os.path.dirname(path)
            self.folder_box.setText(self.folder)
        try:
            self.show_progress_dialog("Updating", "Loading ResultSummary", "Reading workbook...", 0, allow_cancel=False)
            QApplication.processEvents()
            def rs_progress(cur, total, stage):
                self.update_progress_dialog(stage, os.path.basename(path), cur, total, None)
            self.rows, _existing_keys = read_existing_rows(path, progress=rs_progress, cancel=None)
            direct_summary = read_chart_summary_direct(path)
            rebuilt_summary = build_summary_rows(self.rows)
            self.summary_rows = rebuilt_summary or direct_summary or []
            self.refresh_dropdowns()
            self.update_chart()
            self.close_progress_dialog()
            self.status.setText("Previous ResultSummary loaded. Rows: %d / Chart: %d" % (len(self.rows), len(self.summary_rows)))
        except Exception:
            self.close_progress_dialog()
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def start_new_session(self):
        self.folder = ""
        self.result_file = ""
        self.rows = []
        self.summary_rows = []
        self.folder_box.clear()
        self.result_box.clear()
        if hasattr(self, "folder_drop_area"):
            self.folder_drop_area.set_path("")
            self.folder_drop_area.setVisible(True)
        if hasattr(self, "result_drop_area"):
            self.result_drop_area.set_path("")
            self.result_drop_area.setVisible(True)
        if hasattr(self, "source_summary_card"):
            self.source_summary_card.set_empty()
            self.source_summary_card.setVisible(False)
        if hasattr(self, "result_summary_card"):
            self.result_summary_card.set_empty()
            self.result_summary_card.setVisible(True)
        if hasattr(self, "session_box"):
            self.session_box.setVisible(False)
        self.use_existing_result_check.setChecked(False)
        state = rc_read_json(rc_session_path(), {})
        keep_scope = {
            "dashboard_scope": state.get("dashboard_scope", "Hospital"),
            "dashboard_scope_target": state.get("dashboard_scope_target", ""),
        }
        rc_write_json(rc_session_path(), keep_scope)
        self.session_summary_label.setText("New session. Select a WaterSystem folder or ResultSummary file.")
        self.expand_only_group(self.project_group)
        self.status.setText("Start New: select a folder or ResultSummary file.")
        self.update_interactive_workflow()

    def workflow_file_time(self, filename):
        try:
            path = master_path(filename)
            return os.path.getmtime(path) if os.path.exists(path) else 0
        except Exception:
            return 0

    def update_interactive_workflow(self):
        if not hasattr(self, "workflow_assistant"):
            return

        analysis_busy = bool(getattr(self, "analysis_active", False))
        project_ready = bool(self.folder or self.result_file)
        result_ready = bool(self.summary_rows)
        replacement_ready = self.workflow_file_time("Replacement_History.xlsx") > 0
        state = rc_get_workflow_state()

        runtime_done = bool(state.get("runtime"))
        explainable_done = bool(state.get("explainable"))
        dashboard_done = bool(state.get("dashboard_preview"))
        forecast_done = bool(state.get("forecast"))
        foundation_done = bool(state.get("foundation"))
        reliability_done = bool(state.get("reliability_dashboard"))

        completed = set()
        if replacement_ready: completed.add("replacement")
        if runtime_done: completed.add("runtime")
        if explainable_done: completed.add("explainable")
        if dashboard_done: completed.add("dashboard_preview")
        if forecast_done: completed.add("forecast")
        if foundation_done: completed.add("foundation")
        if reliability_done: completed.add("reliability_dashboard")

        if analysis_busy:
            current, recommended, reason = (
                "Analysis in progress", "",
                "Workflow actions will unlock automatically after parsing and chart refresh complete."
            )
        elif not project_ready:
            current, recommended, reason = (
                "Select project data", "",
                "Drop or browse for a folder, ZIP, or ResultSummary."
            )
        elif not result_ready:
            current, recommended, reason = (
                "Project source selected", "",
                "Run Analyze / Update ResultSummary or load an existing ResultSummary."
            )
        elif not replacement_ready:
            current, recommended, reason = (
                "ResultSummary ready", "replacement",
                "Replacement History is required before runtime and reliability calculation."
            )
        elif not runtime_done:
            current, recommended, reason = (
                "Replacement History ready", "runtime",
                "Reconstruct measured, estimated, and unknown runtime."
            )
        elif not explainable_done:
            current, recommended, reason = (
                "Runtime ready", "explainable",
                "Update reliability confidence, readiness, and reasons."
            )
        elif not dashboard_done:
            current, recommended, reason = (
                "Reliability ready", "dashboard_preview",
                "Review confidence and data quality before calculating Forecast."
            )
        elif not forecast_done:
            current, recommended, reason = (
                "Dashboard reviewed", "forecast",
                "The required workflow steps are complete. Forecast can now be calculated."
            )
        elif not foundation_done:
            current, recommended, reason = (
                "Forecast calculated", "foundation",
                "Review coverage and forecast foundation for completeness."
            )
        elif not reliability_done:
            current, recommended, reason = (
                "Forecast foundation reviewed", "reliability_dashboard",
                "Open the final Reliability Dashboard."
            )
        else:
            current, recommended, reason = (
                "Workflow complete", "",
                "All seven actions are complete."
            )

        self.workflow_assistant.update_state(completed, recommended, current, reason)
        self.workflow_assistant.setEnabled(True)
        for workflow_button in self.workflow_assistant._buttons.values():
            workflow_button.setEnabled(not analysis_busy)
        self.workflow_assistant.primary_button.setEnabled(
            bool(recommended) and not analysis_busy
        )
        if hasattr(self, "btn_forecast_calculate"):
            self.btn_forecast_calculate.setEnabled(
                bool(explainable_done and dashboard_done and result_ready)
                and not analysis_busy
            )
        self.save_session_state()


    def module_update_foundation_action(self):
        UpdateFoundationDialog(self).exec()

    def closeEvent(self, event):
        self.save_session_state()
        super(AnalyzerWindow, self).closeEvent(event)

    def select_folder(self):
        menu = QtWidgets.QMenu(self)
        folder_action = menu.addAction("Select WaterSystem Folder")
        zip_action = menu.addAction("Select WaterSystem ZIP")
        chosen = menu.exec(QtGui.QCursor.pos())
        if chosen == zip_action:
            path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Select WaterSystem ZIP", self.folder or os.getcwd(), "ZIP files (*.zip)")
            if path: self.folder_drop_area.handle_path(path)
            return
        if chosen == folder_action:
            folder = QtWidgets.QFileDialog.getExistingDirectory(self, "Select WaterSystem folder", self.folder or os.getcwd(), QtWidgets.QFileDialog.Option.ShowDirsOnly | QtWidgets.QFileDialog.Option.DontResolveSymlinks)
            if folder: self.folder_drop_area.handle_path(folder)


    def handle_project_folder_path(self, folder):
        path = str(folder or "")
        if os.path.isfile(path) and os.path.splitext(path)[1].lower() == ".zip":
            try:
                total_members, member_counts = zip_member_summary(path)
                self.folder_drop_area.set_state(
                    "working",
                    "ZIP detected — %d file(s). Extracting only supported data..." % total_members
                )
                QtWidgets.QApplication.processEvents()

                destination = imported_zip_root("WaterSystemProject", path)
                _destination, extracted_files = safe_extract_zip(
                    path,
                    destination,
                    selective_extensions={".txt", ".log", ".out", ".ar", ".xlsx", ".xlsm"},
                    flatten=True,
                    watersystem_only=True,
                )

                self.folder_drop_area.set_state(
                    "working",
                    "Extraction complete — %d relevant file(s). Locating logs..." % len(extracted_files)
                )
                QtWidgets.QApplication.processEvents()

                result_files = find_result_summary_files(destination)
                best_folder, log_count = find_best_log_folder(destination)

                if log_count == 0 and result_files:
                    self.folder_drop_area.set_state("success", "Detected: ResultSummary ZIP\n%s" % path)
                    self.handle_result_summary_path(result_files[0])
                    self.folder_drop_area.set_compact(True, "ResultSummary ZIP Loaded — click to change")
                    self.status.setText("ZIP loaded directly. ResultSummary was found and opened.")
                    return

                if log_count == 0:
                    self.folder_drop_area.set_state(
                        "error",
                        "ZIP extracted, but no WaterSystem logs or ResultSummary were found."
                    )
                    return

                self.folder = best_folder
                self.folder_box.setText(best_folder)
                self.folder_drop_area.set_state(
                    "success",
                    "Detected: WaterSystem ZIP\nLogs: %d\nWorking folder: %s" % (
                        log_count, best_folder
                    )
                )
                self.update_project_source_card(
                    path,
                    "%d log file(s)" % log_count
                )
                self.status.setText(
                    "ZIP imported without manual extraction. Next: Analyze / Update ResultSummary."
                )
                self.save_session_state()
                self.update_interactive_workflow()
                return
            except Exception:
                self.folder_drop_area.set_state("error", "The ZIP could not be imported.")
                QMessageBox.critical(self, APP_NAME, traceback.format_exc())
                return

        if not os.path.isdir(path):
            self.folder_drop_area.set_state("error", "Drop a valid folder or ZIP file.")
            return

        self.folder = path
        self.folder_box.setText(path)
        self.folder_drop_area.set_state("success", "Detected: WaterSystem Folder\n%s" % path)
        try:
            file_count = len([
                name for name in os.listdir(path)
                if os.path.isfile(os.path.join(path, name))
            ])
        except Exception:
            file_count = 0
        self.update_project_source_card(
            path,
            "%d file(s)" % file_count if file_count else "Folder ready"
        )
        self.status.setText("Folder loaded. Next: Analyze / Update ResultSummary.")
        self.save_session_state()
        self.update_interactive_workflow()


    def handle_result_summary_path(self, path):
        if not os.path.isfile(path):
            self.result_drop_area.set_state(
                "error", "A valid ResultSummary file is required."
            )
            return
        self.result_drop_area.set_state(
            "working", "Detected: ResultSummary — loading..."
        )
        self.select_result_file_from_path(path)
        if self.result_file == path:
            self.result_drop_area.set_state(
                "success",
                "Detected: ResultSummary\n%s" % path
            )
            self.update_result_summary_card(path)
        self.save_session_state()
        self.update_interactive_workflow()


    def select_result_file(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Select ResultSummary file",
            self.folder or os.getcwd(),
            "Excel files (*.xlsx *.xlsm);;All files (*.*)"
        )
        if path:
            self.result_drop_area.handle_path(path)


    # -------------------------------------------------------------
    # Restored in Version 7.3g Fix1.
    # These methods were unintentionally removed when the Project
    # browse controls were replaced by DropAreaWidget handlers.
    # -------------------------------------------------------------

    def date_parse_check(self):
        if not self.folder:
            self.select_folder()
        if not self.folder:
            return
        try:
            files = collect_files(self.folder)
            ok = []
            ng = []
            for p in files[:300]:
                d = build_file_datetime_text(p)
                if d:
                    ok.append("%s -> %s" % (os.path.basename(p), d.strftime("%Y/%m/%d %H:%M:%S")))
                else:
                    ng.append(os.path.basename(p))
            msg = (
                "Date Parse Check\n\n"
                "Candidate files: %d\n"
                "Parsed date: %d\n"
                "No date: %d\n\n"
                "First parsed:\n%s\n\n"
                "First no-date files:\n%s"
            ) % (
                len(files),
                len(ok),
                len(ng),
                "\n".join(ok[:10]) if ok else "(none)",
                "\n".join(ng[:10]) if ng else "(none)",
            )
            QMessageBox.information(self, APP_NAME, msg)
        except Exception:
            self.hide_wait()
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())


    def group_names(self, group):
        if group == "daily":
            return ["Treat", "Degas", "Clean", "Runtime"]
        if group == "cum":
            return ["Treat Cum", "Degas Cum", "Clean Cum", "Runtime Cum"]
        if group == "pause":
            return ["DEGAS_PAUSE", "TREAT_PAUSE", "ERROR", "DEGAS_PAUSE Cum", "TREAT_PAUSE Cum", "ERROR Cum"]
        return list(self.checks.keys())


    def on_child_check_changed(self):
        self.sync_group_checks()
        self.update_chart()


    def scan_folder_check(self):
        if not self.folder:
            self.select_folder()
        if not self.folder:
            return
        try:
            d = scan_folder_diagnostics(self.folder)
            msg = "Folder scan check\n\nFolder:\n%s\n\nTotal files: %d\n.txt/.log files: %d\nCandidate log files: %d\nResultSummary files: %d\n\nFirst candidates:\n%s" % (
                self.folder, d["total"], d["txtlog"], d["accepted"], d.get("resultsummary", 0),
                "\n".join(d["samples"]) if d["samples"] else "(none)"
            )
            self.status.setText("Scan: total=%d / txt-log=%d / log candidates=%d / ResultSummary=%d" % (d["total"], d["txtlog"], d["accepted"], d.get("resultsummary", 0)))
            QMessageBox.information(self, APP_NAME, msg)
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())


    def set_all(self):
        st = self.all_check.isChecked()
        self.set_names_checked(self.group_names("all"), st)
        for parent in [getattr(self, "daily_group_check", None), getattr(self, "cum_group_check", None), getattr(self, "pause_group_check", None)]:
            if parent:
                parent.blockSignals(True)
                parent.setChecked(st)
                parent.blockSignals(False)
        self.update_chart()


    def set_group(self, group):
        parent = {"daily": getattr(self, "daily_group_check", None),
                  "cum": getattr(self, "cum_group_check", None),
                  "pause": getattr(self, "pause_group_check", None)}.get(group)
        if not parent:
            return
        self.set_names_checked(self.group_names(group), parent.isChecked())
        self.sync_group_checks()
        self.update_chart()


    def set_names_checked(self, names, checked):
        for n in names:
            cb = self.checks.get(n)
            if cb:
                cb.blockSignals(True)
                cb.setChecked(checked)
                cb.blockSignals(False)


    def show_analyze_debug(self):
        d = getattr(AnalyzeWorker, "last_debug", {})
        if not d:
            QMessageBox.information(self, APP_NAME, "No analyze debug data yet. Run Analyze / Update first.")
            return
        msg = (
            "Analyze debug\n\n"
            "Scanned: %s\n"
            "Matched: %s\n"
            "Parse failed: %s\n"
            "Duplicates: %s\n\n"
            "First matched files:\n%s\n\n"
            "First errors:\n%s"
        ) % (
            d.get("scanned", ""),
            d.get("matched", ""),
            d.get("parse_fail", ""),
            d.get("duplicate", ""),
            "\n".join(d.get("first_files", [])[:10]) if d.get("first_files") else "(none)",
            "\n".join(d.get("errors", [])[:10]) if d.get("errors") else "(none)",
        )
        QMessageBox.information(self, APP_NAME, msg)


    def show_analyze_performance(self):
        msg = getattr(self, "last_performance_report", "")
        if not msg:
            msg = "No performance report yet. Run Analyze first."
        QMessageBox.information(self, APP_NAME, msg)


    def sync_group_checks(self):
        groups = [("daily", getattr(self, "daily_group_check", None)),
                  ("cum", getattr(self, "cum_group_check", None)),
                  ("pause", getattr(self, "pause_group_check", None))]
        all_values = []
        for group, parent in groups:
            if not parent:
                continue
            vals = [self.checks[n].isChecked() for n in self.group_names(group) if n in self.checks]
            all_values.extend(vals)
            parent.blockSignals(True)
            parent.setChecked(bool(vals) and all(vals))
            parent.blockSignals(False)
        if hasattr(self, "all_check"):
            self.all_check.blockSignals(True)
            self.all_check.setChecked(bool(all_values) and all(all_values))
            self.all_check.blockSignals(False)


    def start_analyze(self):
        if not self.folder:
            self.select_folder()
        if not self.folder:
            return
        if self.worker and self.worker.isRunning():
            return

        self.show_progress_dialog("Updating", "Analyzing WaterSystem Logs", "Preparing analysis...", 0, allow_cancel=True)
        self.analyze_start_time = time.time()
        self.analysis_active = True
        self.set_busy_ui(True)
        self.update_interactive_workflow()
        self.progress.setValue(0)
        self.status.setText("Starting analysis...\nResultSummary mode: %s" % resultsummary_mode_text(self.result_file, self.use_existing_result_check.isChecked()))
        try:
            self.chart_view.set_data([], {}, None, None, None, None)
            self.chart_view.redraw()
        except Exception:
            pass
        self.btn_analyze.setEnabled(False)
        self.btn_cancel.setEnabled(True)

        self.worker = AnalyzeWorker(self.folder, self.result_file, self.use_existing_result_check.isChecked())
        self.worker.progress.connect(self.on_progress)
        self.worker.finished_ok.connect(self.on_finished)
        self.worker.failed.connect(self.on_failed)
        self.worker.finished.connect(self.on_worker_thread_finished)
        self.worker.start()

    def on_worker_thread_finished(self):
        """Final UI unlock after QThread.isRunning() has become False."""
        self.analysis_active = False
        self.set_busy_ui(False)
        if hasattr(self, "btn_analyze"):
            self.btn_analyze.setEnabled(True)
        if hasattr(self, "btn_cancel"):
            self.btn_cancel.setEnabled(False)
        self.update_interactive_workflow()
        try:
            self.worker.deleteLater()
        except Exception:
            pass
        self.worker = None

    def cancel_analyze(self):
        if self.worker:
            self.worker.cancel()
            self.status.setText("Cancel requested... controls will unlock when the current file safely stops.")
            try:
                self.update_progress_dialog("Cancel requested", "Waiting for the current file/read step to finish safely.", 0, 0, None)
            except Exception:
                pass

    def on_progress(self, c, t, n, a, s, stage, elapsed):
        try:
            detail = "%s\nAdded: %d / Skipped: %d" % (n, a, s)
            self.update_progress_dialog(stage, detail, c, t, elapsed)
        except Exception:
            pass
        if t > 0:
            if self.progress.maximum() == 0:
                self.progress.setRange(0, 100)
            self.progress.setValue(int(c * 100 / t))
        else:
            self.progress.setRange(0, 0)
        self.status.setText("%s\n%d / %d\n%s\nAdded: %d  Skipped: %d  Elapsed: %.1fs" % (stage, c, t, n, a, s, elapsed))

    def on_finished(self, rows, summary, added, skipped):
        self.analysis_active = False
        self.close_progress_dialog()
        self.hide_wait2()
        self.progress.setRange(0, 100)
        self.progress.setValue(100)

        self.rows = rows
        rebuilt = build_summary_rows(rows)
        self.summary_rows = rebuilt if rebuilt else (summary or [])
        self.refresh_dropdowns()
        self.update_chart()
        self.collapse_menu_after_chart_ready()

        self.set_busy_ui(False)
        self.btn_analyze.setEnabled(True)
        self.update_interactive_workflow()
        self.btn_cancel.setEnabled(False)
        self.status.setText("Complete and chart redrawn. Mode: %s / Result rows: %d / Chart rows: %d / Added: %d / Skipped: %d / Scanned: %s / Matched: %s / ParseFail: %s / Duplicate: %s" % (getattr(AnalyzeWorker, "last_debug", {}).get("mode", "?"), len(rows), len(self.summary_rows), added, skipped, getattr(AnalyzeWorker, "last_debug", {}).get("scanned", "?"), getattr(AnalyzeWorker, "last_debug", {}).get("matched", "?"), getattr(AnalyzeWorker, "last_debug", {}).get("parse_fail", "?"), getattr(AnalyzeWorker, "last_debug", {}).get("duplicate", "?")))

        try:
            self.show_performance_report(rows, self.summary_rows, added, skipped, time.time() - getattr(self, "analyze_start_time", time.time()))
        except Exception:
            pass

    def on_failed(self, e):
        self.analysis_active = False
        self.close_progress_dialog()
        self.hide_wait2()
        self.set_busy_ui(False)
        self.progress.setRange(0, 100)
        self.btn_analyze.setEnabled(True)
        self.btn_cancel.setEnabled(False)
        self.status.setText("Error")
        self.update_interactive_workflow()
        QMessageBox.critical(self, APP_NAME, e)

    def refresh_dropdowns(self):
        vals = ["Auto"]
        for r in self.summary_rows:
            d = r.get("DateTime")
            if isinstance(d, dt.datetime):
                vals.append(d.strftime("%Y/%m/%d %H:%M"))
        vals = list(dict.fromkeys(vals))

        for c in [self.x_start, self.x_end, self.cum_start, self.cum_end]:
            c.blockSignals(True)
            c.clear()
            c.addItems(vals)
            c.setCurrentIndex(0)
            c.blockSignals(False)

        self.display_size.blockSignals(True)
        self.display_size.setCurrentText("Auto Fit")
        self.display_size.blockSignals(False)

    def parse_choice(self, c):
        s = c.currentText().strip()
        if not s or s == "Auto":
            return None
        try:
            return dt.datetime.strptime(s, "%Y/%m/%d %H:%M")
        except Exception:
            return None

    def update_chart(self):
        if not hasattr(self, "chart_view"):
            return

        self.apply_display_size()

        if not self.summary_rows and getattr(self, "rows", None):
            self.summary_rows = build_summary_rows(self.rows)
            if self.summary_rows:
                self.refresh_dropdowns()

        if not self.summary_rows:
            self.chart_view.set_data([], {}, None, None, None, None)
            try:
                self.chart_view.redraw()
            except Exception:
                pass
            self.status.setText(
                "No chart data. Result rows=%d / Chart rows=0. Check Date Parse Check and Show Analyze Debug."
                % len(getattr(self, "rows", []) or [])
            )
            return

        all_x = [r["DateTime"] for r in self.summary_rows if isinstance(r.get("DateTime"), dt.datetime)]
        if not all_x:
            self.chart_view.set_data(self.summary_rows, {}, None, None, None, None)
            self.status.setText("No datetime data for chart.")
            return

        # Step6.3: X range is controlled by direct chart interactions.
        x0 = getattr(self.chart_view, "manual_x0", None) or min(all_x)
        x1 = getattr(self.chart_view, "manual_x1", None) or max(all_x)
        if x1 <= x0:
            x0, x1 = min(all_x), max(all_x)

        c0 = self.parse_choice(self.cum_start)
        c1 = self.parse_choice(self.cum_end)

        check_state = {}
        for name, cb in self.checks.items():
            check_state[name] = cb.isChecked()

        self.chart_view.set_data(self.summary_rows, check_state, x0, x1, c0, c1)
        try:
            self.chart_view.redraw()
        except Exception:
            pass

        visible_count = 0
        for r in self.summary_rows:
            d = r.get("DateTime")
            if isinstance(d, dt.datetime) and x0 <= d <= x1:
                visible_count += 1

        self.status.setText("Chart refreshed. Result rows: %d / Chart rows: %d / Visible rows: %d / X range: %s - %s" % (
            len(getattr(self, "rows", []) or []),
            len(self.summary_rows),
            visible_count,
            x0.strftime("%Y/%m/%d %H:%M") if x0 else "Auto",
            x1.strftime("%Y/%m/%d %H:%M") if x1 else "Auto"
        ))

    def show_wait(self, text="Updating... Please wait."):
        try:
            self._wait = QProgressDialog(text, None, 0, 0, self)
            self._wait.setWindowTitle("Updating")
            self._wait.setWindowModality(QtCore.Qt.WindowModality.ApplicationModal)
            self._wait.setMinimumDuration(0)
            self._wait.setCancelButton(None)
            self._wait.show()
            QApplication.processEvents()
        except Exception:
            self._wait = None

    def hide_wait(self):
        try:
            if getattr(self, "_wait", None):
                self._wait.close()
                self._wait = None
            QApplication.processEvents()
        except Exception:
            pass

    def set_busy_ui(self, busy):
        try:
            for b in self.panel.findChildren(QPushButton):
                if getattr(self, "btn_cancel", None) is b:
                    continue
                b.setEnabled(not busy)
            # Workflow state/gating is recalculated immediately after busy mode.
            if hasattr(self, "btn_analyze"):
                self.btn_analyze.setEnabled(not busy)
        except Exception:
            pass

    def show_wait2(self, text="Updating... Please wait."):
        try:
            self._wait2 = QtWidgets.QDialog(self)
            self._wait2.setWindowTitle("Updating")
            self._wait2.setWindowModality(QtCore.Qt.WindowModality.ApplicationModal)
            self._wait2.setMinimumSize(420, 170)
            lay = QVBoxLayout(self._wait2)
            title = QLabel("<b>WaterSystem Analyzer</b>")
            title.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            lay.addWidget(title)
            self._wait2_label = QLabel(text)
            self._wait2_label.setWordWrap(True)
            self._wait2_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            lay.addWidget(self._wait2_label)
            bar = QProgressBar()
            bar.setRange(0, 0)
            lay.addWidget(bar)
            self._wait2.show()
            self._wait2.raise_()
            self._wait2.activateWindow()
            for _ in range(8):
                QApplication.processEvents()
        except Exception:
            self._wait2 = None

    def update_wait2(self, text):
        try:
            if getattr(self, "_wait2_label", None):
                self._wait2_label.setText(text)
            QApplication.processEvents()
        except Exception:
            pass

    def hide_wait2(self):
        try:
            if getattr(self, "_wait2", None):
                self._wait2.close()
                self._wait2 = None
            self._wait2_label = None
            QApplication.processEvents()
        except Exception:
            pass

    def project_backup(self):
        try:
            dest = QtWidgets.QFileDialog.getExistingDirectory(self, "Select folder for project backup", self.backup_root_dir())
            if not dest:
                return
            self.show_progress_dialog("Backup", "Creating Project Backup", "Collecting Data and Master files...", 0, allow_cancel=False)
            backup_zip = self.create_project_backup_to(dest, reason="Manual")
            self.close_progress_dialog()
            QMessageBox.information(self, APP_NAME, "Backup created:\n%s" % backup_zip)
        except Exception:
            self.close_progress_dialog()
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())


    def show_progress_dialog(self, title="Updating", step="Starting...", detail="", total=0, allow_cancel=True):
        try:
            self._prog_total = max(0, int(total or 0))
            self._prog_start_time = time.time()
            self._prog_dialog = QtWidgets.QDialog(self)
            self._prog_dialog.setWindowTitle(title)
            self._prog_dialog.setWindowModality(QtCore.Qt.WindowModality.ApplicationModal)
            self._prog_dialog.setMinimumSize(640, 220)
            lay = QVBoxLayout(self._prog_dialog)

            title_label = QLabel("<b>WaterSystem Analyzer</b>")
            title_label.setStyleSheet("font-size:16px;")
            title_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            lay.addWidget(title_label)

            self._prog_step_label = QLabel(step)
            self._prog_step_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            self._prog_step_label.setStyleSheet("font-size:14px; font-weight:bold;")
            lay.addWidget(self._prog_step_label)

            self._prog_detail_label = QLabel(detail or "")
            self._prog_detail_label.setWordWrap(True)
            self._prog_detail_label.setStyleSheet("font-size:12px; color:#455;")
            self._prog_detail_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            lay.addWidget(self._prog_detail_label)

            self._prog_count_label = QLabel("")
            self._prog_count_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            lay.addWidget(self._prog_count_label)

            self._prog_bar = QProgressBar()
            if self._prog_total > 0:
                self._prog_bar.setRange(0, self._prog_total)
                self._prog_bar.setValue(0)
            else:
                self._prog_bar.setRange(0, 0)
            lay.addWidget(self._prog_bar)

            if allow_cancel:
                btns = QHBoxLayout()
                btns.addStretch(1)
                self._prog_cancel_button = QPushButton("Cancel")
                self._prog_cancel_button.clicked.connect(self.cancel_analyze)
                btns.addWidget(self._prog_cancel_button)
                btns.addStretch(1)
                lay.addLayout(btns)

            self._prog_dialog.show()
            self._prog_dialog.raise_()
            self._prog_dialog.activateWindow()
            for _ in range(8):
                QApplication.processEvents()
        except Exception:
            self._prog_dialog = None

    def update_progress_dialog(self, step="", detail="", cur=0, total=0, elapsed=None):
        try:
            if not getattr(self, "_prog_dialog", None):
                return
            if step:
                self._prog_step_label.setText(step)
            if detail:
                self._prog_detail_label.setText(detail)
            total = int(total or getattr(self, "_prog_total", 0) or 0)
            cur = int(cur or 0)
            if total > 0:
                self._prog_bar.setRange(0, total)
                self._prog_bar.setValue(max(0, min(cur, total)))
                pct = int((cur / max(1, total)) * 100)
            else:
                pct = 0
            if elapsed is None:
                elapsed = time.time() - getattr(self, "_prog_start_time", time.time())
            remain = ""
            if total > 0 and cur > 0:
                rate = elapsed / max(1, cur)
                remain_sec = max(0, (total - cur) * rate)
                remain = " / Remaining: %s" % self.format_duration(remain_sec)
            self._prog_count_label.setText("Progress: %d / %d  (%d%%) / Elapsed: %s%s" % (
                cur, total, pct, self.format_duration(elapsed), remain
            ))
            QApplication.processEvents()
        except Exception:
            pass

    def close_progress_dialog(self):
        try:
            if getattr(self, "_prog_dialog", None):
                self._prog_dialog.close()
                self._prog_dialog = None
            QApplication.processEvents()
        except Exception:
            pass

    def format_duration(self, seconds):
        try:
            seconds = int(max(0, seconds))
            h = seconds // 3600
            m = (seconds % 3600) // 60
            s = seconds % 60
            if h:
                return "%d:%02d:%02d" % (h, m, s)
            return "%02d:%02d" % (m, s)
        except Exception:
            return "00:00"

    def show_performance_report(self, rows, summary, added, skipped, elapsed):
        try:
            debug = getattr(AnalyzeWorker, "last_debug", {}) or {}
            msg = (
                "Analyze Completed\n\n"
                "Result rows: %d\n"
                "Chart rows: %d\n"
                "Added: %d\n"
                "Skipped: %d\n"
                "Scanned: %s\n"
                "Matched: %s\n"
                "ParseFail: %s\n"
                "Duplicate: %s\n\n"
                "Total elapsed: %s\n"
                "Mode: %s"
            ) % (
                len(rows), len(summary), added, skipped,
                debug.get("scanned", "?"), debug.get("matched", "?"),
                debug.get("parse_fail", "?"), debug.get("duplicate", "?"),
                self.format_duration(elapsed), debug.get("mode", "?"),
            )
            self.last_performance_report = msg
            self.status.setToolTip(msg)
        except Exception:
            pass

    def show_data_location(self):
        try:
            msg = (
                "Current Data Folder\n\n%s\n\n"
                "Default Data Folder\n\n%s\n\n"
                "Settings File\n\n%s"
            ) % (ensure_data_folders(), default_data_folder(), app_settings_path())
            QMessageBox.information(self, APP_NAME, msg)
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def move_data_folder(self):
        try:
            current = ensure_data_folders()
            new_root = QtWidgets.QFileDialog.getExistingDirectory(
                self,
                "Select new Data folder location",
                default_data_folder()
            )
            if not new_root:
                return
            new_root = os.path.abspath(new_root)
            if os.path.abspath(current).lower() == new_root.lower():
                QMessageBox.information(self, APP_NAME, "Selected folder is already the current Data folder.")
                return

            ret = QMessageBox.question(
                self,
                APP_NAME,
                "Move Data folder?\n\nCurrent:\n%s\n\nNew:\n%s\n\nData will be copied, verified, and the application setting will be updated." % (current, new_root)
            )
            if ret != QMessageBox.StandardButton.Yes:
                return

            self.show_progress_dialog("Move Data", "Moving Data Folder", "Copying Data folder...", 0, allow_cancel=False)
            os.makedirs(new_root, exist_ok=True)
            shutil.copytree(current, new_root, dirs_exist_ok=True)

            self.update_progress_dialog("Move Data", "Updating DataFolder setting...", 0, 0)
            set_data_root(new_root)
            ensure_data_folders()

            self.close_progress_dialog()
            delete_ret = QMessageBox.question(
                self,
                APP_NAME,
                "Data folder moved successfully.\n\nNew Data folder:\n%s\n\nDelete old Data folder?\n\n%s" % (new_root, current)
            )
            if delete_ret == QMessageBox.StandardButton.Yes:
                try:
                    shutil.rmtree(current)
                except Exception as e:
                    QMessageBox.warning(self, APP_NAME, "Could not delete old Data folder:\n%s" % e)

            QMessageBox.information(self, APP_NAME, "Data folder is now:\n%s\n\nRestart is recommended." % new_root)
        except Exception:
            self.close_progress_dialog()
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def import_release_package(self):
        try:
            # Default selection starts from the application folder, not the current custom Data folder.
            release_dir = QtWidgets.QFileDialog.getExistingDirectory(
                self,
                "Select WaterSystemAnalyzer Release Package folder",
                app_base_dir()
            )
            if not release_dir:
                return
            release_dir = os.path.abspath(release_dir)
            if not os.path.isdir(os.path.join(release_dir, "Data")):
                QMessageBox.warning(self, APP_NAME, "Invalid Release Package.\n\nData folder was not found:\n%s" % release_dir)
                return

            install_dir = QtWidgets.QFileDialog.getExistingDirectory(
                self,
                "Select install/import destination folder",
                app_base_dir()
            )
            if not install_dir:
                return
            install_dir = os.path.abspath(install_dir)

            running_dir = os.path.abspath(app_base_dir())
            release_abs = os.path.abspath(release_dir)
            if install_dir.lower() == running_dir.lower():
                QMessageBox.warning(self, APP_NAME, "Cannot import directly into the running application folder.\n\nPlease select a new destination folder, for example:\nC:\\WaterSystemAnalyzer_New")
                return
            if install_dir.lower() == release_abs.lower() or release_abs.lower().startswith(install_dir.lower() + os.sep):
                QMessageBox.warning(self, APP_NAME, "Destination cannot be the same as the selected Release Package folder or its parent.\n\nPlease select an empty/new install folder.")
                return

            ret = QMessageBox.question(
                self,
                APP_NAME,
                "Import Release Package?\n\nRelease:\n%s\n\nDestination:\n%s\n\nFiles will be copied to the destination. DataFolder will default to Destination\\Data." % (release_dir, install_dir)
            )
            if ret != QMessageBox.StandardButton.Yes:
                return

            self.show_progress_dialog("Import Release", "Importing Release Package", "Copying release files...", 0, allow_cancel=False)
            os.makedirs(install_dir, exist_ok=True)

            for name in os.listdir(release_dir):
                src = os.path.join(release_dir, name)
                dst = os.path.join(install_dir, name)
                self.update_progress_dialog("Importing Release Package", "Copying: %s" % name, 0, 0)
                if os.path.isdir(src):
                    shutil.copytree(src, dst, dirs_exist_ok=True)
                else:
                    # Do not overwrite a running EXE in the current app folder.
                    try:
                        if os.path.abspath(dst).lower() == os.path.abspath(sys.executable).lower():
                            continue
                    except Exception:
                        pass
                    shutil.copy2(src, dst)

            data_dest = os.path.join(install_dir, "Data")
            self.update_progress_dialog("Importing Release Package", "Setting Data folder...", 0, 0)
            set_data_root(data_dest)
            ensure_data_folders()
            self.close_progress_dialog()

            QMessageBox.information(
                self,
                APP_NAME,
                "Release Package imported.\n\nInstall folder:\n%s\n\nData folder:\n%s\n\nRun Migration Wizard next." % (install_dir, data_dest)
            )
        except Exception:
            self.close_progress_dialog()
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def backup_root_dir(self):
        d = os.path.join(ensure_data_folders(), "Backups")
        os.makedirs(d, exist_ok=True)
        return d

    def create_project_backup_to(self, dest_folder=None, reason="Manual"):
        if dest_folder is None:
            dest_folder = self.backup_root_dir()
        os.makedirs(dest_folder, exist_ok=True)
        ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_zip = os.path.join(dest_folder, "WaterSystemAnalyzer_Ver42_Backup_%s.zip" % ts)
        data_dir = ensure_data_folders()

        with zipfile.ZipFile(backup_zip, "w", zipfile.ZIP_DEFLATED) as z:
            if os.path.isdir(data_dir):
                for f in Path(data_dir).rglob("*"):
                    if f.is_file():
                        # Avoid nesting backup zips inside backup zips.
                        if "Backups" in f.parts and f.suffix.lower() == ".zip":
                            continue
                        z.write(str(f), "Data/" + str(f.relative_to(data_dir)).replace("\\", "/"))
            info = (
                "WaterSystem Analyzer Ver42 Backup\n"
                "Version: %s\n"
                "Algorithm: %s\n"
                "Created: %s\n"
                "Reason: %s\n"
            ) % (APP_VERSION, ALGORITHM_VERSION, dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S"), reason)
            z.writestr("BACKUP_INFO.txt", info)
        return backup_zip

    def automatic_backup(self, reason="Auto"):
        try:
            return self.create_project_backup_to(self.backup_root_dir(), reason=reason)
        except Exception:
            return ""

    def restore_project_backup(self):
        RestoreBackupDropDialog(
            self.restore_project_backup_from_path,
            self
        ).exec()

    def restore_project_backup_from_path(self, path):
        try:
            if not path or not os.path.isfile(path):
                QMessageBox.warning(
                    self, APP_NAME, "The backup ZIP could not be found."
                )
                return

            detected = classify_dropped_path(path)
            if detected != "Project Backup":
                QMessageBox.warning(
                    self, APP_NAME,
                    "This ZIP is not recognized as a Project Backup."
                )
                return

            ret = QMessageBox.question(
                self,
                APP_NAME,
                "Restore this backup?\n\n%s\n\n"
                "A safety backup will be created first. "
                "The Backup folder itself will not be deleted." % path
            )
            if ret != QMessageBox.StandardButton.Yes:
                return

            self.show_progress_dialog(
                "Restore",
                "Restoring Project Backup",
                "Creating safety backup...",
                0,
                allow_cancel=False
            )
            safety = self.create_project_backup_to(
                self.backup_root_dir(),
                reason="Before restore"
            )
            data_dir = ensure_data_folders()

            self.update_progress_dialog(
                "Restoring Project Backup",
                "Extracting backup ZIP...",
                0, 0
            )
            tmp = os.path.join(app_base_dir(), "_restore_tmp")
            if os.path.exists(tmp):
                shutil.rmtree(tmp, ignore_errors=True)
            os.makedirs(tmp, exist_ok=True)

            with zipfile.ZipFile(path, "r") as z:
                z.extractall(tmp)

            backup_data = os.path.join(tmp, "Data")
            if not os.path.isdir(backup_data):
                self.close_progress_dialog()
                QMessageBox.warning(
                    self, APP_NAME,
                    "Invalid backup ZIP. Data folder was not found."
                )
                shutil.rmtree(tmp, ignore_errors=True)
                return

            self.update_progress_dialog(
                "Restoring Project Backup",
                "Restoring Data subfolders safely...",
                0, 0
            )

            protected = {"backup", "backups"}
            for child in Path(backup_data).iterdir():
                if child.name.lower() in protected:
                    continue
                dest = Path(data_dir) / child.name
                if dest.exists():
                    if dest.is_dir():
                        shutil.rmtree(dest, ignore_errors=True)
                    else:
                        dest.unlink()
                if child.is_dir():
                    shutil.copytree(child, dest)
                else:
                    shutil.copy2(child, dest)

            shutil.rmtree(tmp, ignore_errors=True)

            self.update_progress_dialog(
                "Restoring Project Backup",
                "Reloading current data and chart...",
                0, 0
            )
            self.rows = []
            self.summary_rows = []
            self.result_file = ""
            self.result_box.clear()
            if hasattr(self, "result_drop_area"):
                self.result_drop_area.set_path("")
            self.refresh_dropdowns()
            self.update_chart()
            self.close_progress_dialog()
            self.status.setText(
                "Restore complete. Restart is recommended. "
                "Safety backup: %s" % safety
            )
            QMessageBox.information(
                self,
                APP_NAME,
                "Restore completed.\n\n"
                "Safety backup created:\n%s\n\n"
                "Backup folders were preserved.\nRestart is recommended."
                % safety
            )
        except Exception:
            self.close_progress_dialog()
            QMessageBox.critical(
                self, APP_NAME, traceback.format_exc()
            )


    def backup_manager(self):
        try:
            bdir = self.backup_root_dir()
            backups = sorted(Path(bdir).glob("WaterSystemAnalyzer_Ver42_Backup_*.zip"), reverse=True)
            if not backups:
                QMessageBox.information(self, APP_NAME, "No backups found.\n\nBackup folder:\n%s" % bdir)
                return

            lines = []
            for i, p in enumerate(backups[:30], 1):
                size_mb = p.stat().st_size / (1024 * 1024)
                lines.append("%02d. %s   %.1f MB" % (i, p.name, size_mb))

            msg = "Backup Manager\n\nBackup folder:\n%s\n\nLatest backups:\n%s\n\nUse Restore Project Backup to restore a selected ZIP." % (bdir, "\n".join(lines))
            QMessageBox.information(self, APP_NAME, msg)
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def migration_wizard(self):
        try:
            self.show_progress_dialog("Migration Wizard", "Checking migration readiness", "Checking files and permissions...", 0, allow_cancel=False)
            QApplication.processEvents()

            data_dir = ensure_data_folders()
            master_dir = os.path.join(data_dir, "Master")
            required = [
                "Hospital_Master.xlsx",
                "Component_Master.xlsx",
                "SN_Master.xlsx",
                "Hospital_Master.xlsx",
                "Replacement_History.xlsx",
                "Forecast_Master.xlsx",
                "Outlier_Master.xlsx",
            ]

            missing = []
            for fname in required:
                if not os.path.exists(os.path.join(master_dir, fname)):
                    missing.append(fname)

            self.update_progress_dialog("Migration Wizard", "Checking write permission...", 0, 0)
            write_ok = True
            try:
                test_file = os.path.join(data_dir, "_migration_write_test.tmp")
                with open(test_file, "w", encoding="utf-8") as f:
                    f.write("ok")
                os.remove(test_file)
            except Exception:
                write_ok = False

            self.close_progress_dialog()

            if missing or not write_ok:
                QMessageBox.warning(
                    self,
                    APP_NAME,
                    "Migration Check completed with warnings.\n\nMissing:\n%s\n\nWrite permission: %s\n\nRun Validate Masters or Master Foundation to recreate missing files." %
                    ("\n".join(missing) if missing else "(none)", "OK" if write_ok else "NG")
                )
            else:
                QMessageBox.information(
                    self,
                    APP_NAME,
                    "Migration Complete / Ready\n\nData folder:\n%s\n\nMaster files: OK\nWrite permission: OK\n\nYou can start normal operation." % data_dir
                )
        except Exception:
            self.close_progress_dialog()
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def migration_check(self):
        try:
            checks = []
            base = app_base_dir()
            data_dir = ensure_data_folders()
            master_dir = os.path.join(data_dir, "Master")

            def mark(name, ok, detail=""):
                checks.append((name, ok, detail))

            mark("Application folder", os.path.exists(base), base)
            mark("Data folder", os.path.isdir(data_dir), data_dir)
            mark("Master folder", os.path.isdir(master_dir), master_dir)

            for fname in ["Hospital_Master.xlsx", "Component_Master.xlsx", "SN_Master.xlsx", "Hospital_Master.xlsx", "Replacement_History.xlsx", "Forecast_Master.xlsx", "Outlier_Master.xlsx"]:
                p = os.path.join(master_dir, fname)
                mark(fname, os.path.exists(p), p)

            try:
                test_file = os.path.join(data_dir, "_write_test.tmp")
                with open(test_file, "w", encoding="utf-8") as f:
                    f.write("ok")
                os.remove(test_file)
                mark("Data write permission", True, data_dir)
            except Exception as e:
                mark("Data write permission", False, str(e))

            try:
                import openpyxl
                mark("openpyxl", True, getattr(openpyxl, "__version__", "OK"))
            except Exception as e:
                mark("openpyxl", False, str(e))

            qt_ok = any("Qt" in n or "PySide" in n for n in os.listdir(base)) if os.path.isdir(base) else False
            mark("Qt/PySide files nearby", qt_ok, "Copy the whole dist folder, not only the EXE.")

            ok_count = sum(1 for _n, ok, _d in checks if ok)
            ng = [c for c in checks if not c[1]]
            lines = ["Migration Check", "", "Data folder: %s" % ensure_data_folders(), "Settings: %s" % app_settings_path(), "", "OK: %d / %d" % (ok_count, len(checks)), ""]
            for name, ok, detail in checks:
                lines.append("%s %s" % ("OK " if ok else "NG ", name))
                if detail:
                    lines.append("    %s" % detail)
            if not ng:
                lines.append("")
                lines.append("Ready for another PC. Copy the whole dist folder including Data.")
            else:
                lines.append("")
                lines.append("Warnings found. See NG lines above.")
            QMessageBox.information(self, APP_NAME, "\n".join(lines))
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def export_release_package(self):
        try:
            dest = QtWidgets.QFileDialog.getExistingDirectory(self, "Select output folder for release package", os.getcwd())
            if not dest:
                return
            self.show_wait("Creating release package... Please wait.")
            package = os.path.join(dest, "WaterSystemAnalyzer_Ver42_Release_%s" % dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
            if os.path.exists(package):
                shutil.rmtree(package)
            os.makedirs(package, exist_ok=True)

            base = app_base_dir()
            # Copy app folder contents when running from Nuitka dist; when running source, copy project files.
            for name in os.listdir(base):
                if name in ("build", "build_debug", "__pycache__"):
                    continue
                src = os.path.join(base, name)
                dst = os.path.join(package, name)
                if os.path.isdir(src):
                    if name.lower() == "data":
                        shutil.copytree(src, dst, dirs_exist_ok=True)
                    elif name.endswith(".dist") or name in ("PySide6", "qt-plugins"):
                        shutil.copytree(src, dst, dirs_exist_ok=True)
                else:
                    if name.lower().endswith((".exe", ".dll", ".pyd", ".py", ".bat", ".txt")):
                        shutil.copy2(src, dst)

            data_dir = ensure_data_folders()
            if os.path.isdir(data_dir):
                shutil.copytree(data_dir, os.path.join(package, "Data"), dirs_exist_ok=True)

            with open(os.path.join(package, "WaterSystemAnalyzer_Settings.ini"), "w", encoding="utf-8") as f:
                f.write("DataFolder=%s\n" % os.path.join(package, "Data"))
                f.write("APP_VERSION=%s\n" % APP_VERSION)
            with open(os.path.join(package, "README_RELEASE.txt"), "w", encoding="utf-8") as f:
                f.write("WaterSystem Analyzer Ver42 Release Package\n")
                f.write("Version: %s\n\n" % APP_VERSION)
                f.write("Copy this whole folder to another PC. Do not copy only the EXE.\n")
                f.write("Run Migration Wizard after first launch.\n")
                f.write("Use Restore Project Backup if you need to restore a backup ZIP.\n")
            with open(os.path.join(package, "Version.txt"), "w", encoding="utf-8") as f:
                f.write("APP_VERSION=%s\nALGORITHM_VERSION=%s\nBUILD_DATE=%s\n" % (APP_VERSION, ALGORITHM_VERSION, dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S")))
            with open(os.path.join(package, "MigrationGuide.txt"), "w", encoding="utf-8") as f:
                f.write("Migration Guide\n")
                f.write("1. Copy this whole folder to the target PC.\n")
                f.write("2. Do not copy only the EXE.\n")
                f.write("3. Start the EXE.\n")
                f.write("4. Run Migration Wizard.\n")
                f.write("5. Run Migration Check if needed.\n")
                f.write("6. Use Restore Project Backup only when restoring from a backup ZIP.\n")
            with open(os.path.join(package, "Version.txt"), "w", encoding="utf-8") as f:
                f.write("APP_VERSION=%s\nALGORITHM_VERSION=%s\nBUILD_DATE=%s\n" % (APP_VERSION, ALGORITHM_VERSION, dt.datetime.now().strftime("%Y/%m/%d %H:%M:%S")))
            with open(os.path.join(package, "MigrationGuide.txt"), "w", encoding="utf-8") as f:
                f.write("Migration Guide\n")
                f.write("1. Copy this whole folder to the target PC.\n")
                f.write("2. Do not copy only the EXE.\n")
                f.write("3. Start the EXE.\n")
                f.write("4. Run Migration Wizard.\n")
                f.write("5. Run Migration Check if needed.\n")
                f.write("6. Use Restore Project Backup only when restoring from a backup ZIP.\n")

            self.hide_wait()
            QMessageBox.information(self, APP_NAME, "Release package created:\n%s" % package)
        except Exception:
            self.hide_wait()
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def dashboard_preview_action(self):
        try:
            if not self.summary_rows and getattr(self, "rows", None):
                self.summary_rows = build_summary_rows(self.rows)
            mode = "Unknown"
            try:
                mode = self.missing_log_handling.currentText()
            except Exception:
                pass
            self.show_progress_dialog("Dashboard Preview", "Building Dashboard Preview", "Updating reliability context...", 0, allow_cancel=False)

            latest, trend_rows, explain_rows = dashboard_context(getattr(self, "summary_rows", []))
            self.close_progress_dialog()
            DashboardPreviewDialog(latest, trend_rows, explain_rows, self).exec()
            self.mark_dashboard_reviewed()
        except Exception:
            self.close_progress_dialog()
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def data_foundation_action(self):
        try:
            self.show_progress_dialog("Data Foundation", "Initializing Data Foundation", "Creating project metadata and master files...", 0, allow_cancel=False)
            report, paths = build_data_foundation_report()
            self.close_progress_dialog()
            DataFoundationDialog(report, paths, self).exec()
        except Exception:
            self.close_progress_dialog()
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def open_master_foundation(self):
        try:
            ensure_master_foundation_files()
            dlg = MasterFoundationDialog(self)
            dlg.exec()
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def open_data_folder(self):
        try:
            path = ensure_data_folders()
            os.startfile(path)
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def validate_masters(self):
        try:
            ensure_data_folders()
            files = [master_path("Hospital_Master.xlsx"), master_path("Replacement_History.xlsx"), master_path("Forecast_Master.xlsx"), master_path("Outlier_Master.xlsx")]
            msg = "Master validation\n\n"
            for p in files:
                msg += "%s : %s\n" % (os.path.basename(p), "OK" if os.path.exists(p) else "MISSING")
            msg += "\nData folder:\n%s" % ensure_data_folders()
            QMessageBox.information(self, APP_NAME, msg)
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def runtime_reconstruction_action(self):
        try:
            if not self.summary_rows and getattr(self, "rows", None):
                self.summary_rows = build_summary_rows(self.rows)
            if not self.summary_rows:
                QMessageBox.warning(self, APP_NAME, "No chart/log summary data loaded. Run Analyze or load ResultSummary first.")
                return

            mode = "Unknown"
            try:
                mode = self.missing_log_handling.currentText()
            except Exception:
                pass

            self.show_progress_dialog("Runtime Reconstruction", "Reconstructing Runtime", "Building measured / estimated / unknown runtime basis...", 0, allow_cancel=False)
            paths, runtime_rows, gap_rows, reference_rows, prediction_rows, confidence_rows = save_runtime_reconstruction(self.summary_rows, mode, save_explainable=False)
            self.close_progress_dialog()

            RuntimeReconstructionDialog(runtime_rows, gap_rows, reference_rows, prediction_rows, confidence_rows, self).exec()
            rc_mark_workflow("runtime")
            self.update_interactive_workflow()
        except Exception:
            self.close_progress_dialog()
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def explainable_reliability_action(self):
        try:
            if not self.summary_rows and getattr(self, "rows", None):
                self.summary_rows = build_summary_rows(self.rows)
            if not self.summary_rows:
                QMessageBox.warning(self, APP_NAME, "No chart/log summary data loaded. Run Analyze or load ResultSummary first.")
                return

            mode = self.missing_log_handling.currentText() if hasattr(self, "missing_log_handling") else "Unknown"
            self.show_progress_dialog(
                "Explainable Reliability",
                "Updating Explainable Reliability",
                "Calculating readiness, confidence, and reasons...",
                0, allow_cancel=False
            )
            runtime_rows, gap_rows, _reference_rows = build_runtime_reconstruction(self.summary_rows, mode)
            prediction_rows, _confidence_rows = build_prediction_and_confidence(runtime_rows)
            validation_rows = validate_replacement_history() if "validate_replacement_history" in globals() else []
            paths, explain_rows, trend_rows = save_explainable_reliability(
                self.summary_rows, runtime_rows, gap_rows, validation_rows, prediction_rows
            )
            self.close_progress_dialog()
            rc_mark_workflow("explainable")
            self.status.setText(
                "Explainable Reliability updated. Forecast is now available; Dashboard review is recommended."
            )
            self.update_interactive_workflow()
        except Exception:
            self.close_progress_dialog()
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def reliability_dashboard_action(self):
        try:
            if not self.summary_rows and getattr(self, "rows", None):
                self.summary_rows = build_summary_rows(self.rows)
            if not self.summary_rows:
                QMessageBox.warning(self, APP_NAME, "No chart/log summary data loaded. Run Analyze or load ResultSummary first.")
                return

            mode = "Unknown"
            try:
                mode = self.missing_log_handling.currentText()
            except Exception:
                pass

            self.show_progress_dialog("Reliability", "Building Reliability Dashboard", "Validating replacement history and log gaps...", 0, allow_cancel=False)
            paths, validation_rows, gap_rows, reliability_rows, snapshot_rows = save_reliability_dashboard(self.summary_rows, mode)
            self.close_progress_dialog()

            ReliabilityDashboardDialog(validation_rows, gap_rows, reliability_rows, snapshot_rows, self).exec()
            rc_mark_workflow("reliability_dashboard")
            self.update_interactive_workflow()
            self.update_interactive_workflow()
        except Exception:
            self.close_progress_dialog()
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def import_replacement_history_action(self):
        try:
            ensure_master_foundation_files()
            if "ensure_data_foundation_files" in globals():
                try:
                    ensure_data_foundation_files()
                except Exception:
                    pass
            result = ReplacementImportWizard(self).exec()
            if result == QtWidgets.QDialog.DialogCode.Accepted:
                state = rc_get_workflow_state()
                state.pop("runtime", None); state.pop("explainable", None); state.pop("forecast", None)
                rc_write_json(rc_workflow_state_path(), state)
            self.update_interactive_workflow()
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def forecast_foundation_action(self):
        try:
            if not self.summary_rows and getattr(self, "rows", None):
                self.summary_rows = build_summary_rows(self.rows)
            if not self.summary_rows:
                QMessageBox.warning(self, APP_NAME, "No chart/log summary data loaded. Run Analyze or load ResultSummary first.")
                return
            mode = self.missing_log_handling.currentText() if hasattr(self, "missing_log_handling") else "Unknown"
            self.show_progress_dialog("Forecast Foundation", "Building Data Coverage", "Checking logs and summary data...", 0, allow_cancel=False)
            coverage_rows, history_rows = save_forecast_foundation(self.summary_rows, mode)
            self.close_progress_dialog()
            ForecastFoundationDialog(coverage_rows, history_rows, self).exec()
        except Exception:
            self.close_progress_dialog()
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def calculate_forecast_action(self):
        """Compatibility alias for older Workflow Assistant builds."""
        return self.calculate_forecast_now()

    def calculate_forecast_now(self):
        if not self.summary_rows:
            QMessageBox.warning(self, APP_NAME, "No chart data. Analyze logs or select a ResultSummary first.")
            return
        default_sn = "NA"
        if self.result_file:
            m = re.search(r"ResultSummary_(.+?)(?:_\d{8}_\d{6})?\.xlsx$", os.path.basename(self.result_file), re.I)
            if m:
                default_sn = m.group(1)
        sn, ok = QInputDialog.getText(self, APP_NAME, "Serial Number:", text=default_sn)
        if not ok:
            return
        try:
            f1 = append_forecast_master(sn or "NA", self.summary_rows, "Failure only", self.forecast_scope.currentText())
            f2 = append_forecast_master(sn or "NA", self.summary_rows, "Preventive included", self.forecast_scope.currentText())
            QMessageBox.information(self, APP_NAME, "Forecast updated.\n\nFailure Only Confidence: %s%%\nAll Replacement Confidence: %s%%" % (f1.get("confidence", ""), f2.get("confidence", "")))
            rc_mark_workflow("forecast")
            self.update_interactive_workflow()
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def resultsummary_check(self):
        try:
            use_existing = self.use_existing_result_check.isChecked() if hasattr(self, "use_existing_result_check") else False
            mode = resultsummary_mode_text(self.result_file, use_existing)
            latest = find_latest_result_summary(self.folder) if self.folder else ""

            resolved = resolve_resultsummary_base_file(self.folder or "", self.result_file, use_existing)
            msg = (
                "ResultSummary check\n\n"
                "Mode: %s\n\n"
                "Selected folder:\n%s\n\n"
                "Explicit selected ResultSummary:\n%s\n\n"
                "Latest ResultSummary in selected folder:\n%s\n\n"
                "Resolved base used by Analyze:\n%s\n\n"
                "Current loaded result rows: %d\n"
                "Current chart rows: %d\n\n"
                "This check does not change Save or chart data."
            ) % (
                mode,
                self.folder or "(none)",
                self.result_file or "(none)",
                latest or "(none)",
                resolved or "(none / log files only)",
                len(self.rows),
                len(self.summary_rows),
            )
            QMessageBox.information(self, APP_NAME, msg)
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())

    def show_current_data_count(self):
        dates = [r.get("DateTime") for r in self.summary_rows if isinstance(r.get("DateTime"), dt.datetime)]
        max_daily = 0.0
        for r in self.summary_rows:
            for n in ["Treat", "Degas", "Clean", "Runtime", "DEGAS_PAUSE", "TREAT_PAUSE", "ERROR"]:
                try:
                    max_daily = max(max_daily, float(r.get(n) or 0.0))
                except Exception:
                    pass

        QMessageBox.information(
            self,
            APP_NAME,
            "Current data count\n\n"
            "Result rows: %d\n"
            "Chart rows: %d\n"
            "First chart date: %s\n"
            "Last chart date: %s\n"
            "Max daily value: %.3f\n\n"
            "Last analyze debug:\n%s"
            % (
                len(self.rows),
                len(self.summary_rows),
                min(dates).strftime("%Y/%m/%d %H:%M") if dates else "(none)",
                max(dates).strftime("%Y/%m/%d %H:%M") if dates else "(none)",
                max_daily,
                str(getattr(AnalyzeWorker, "last_debug", {})),
            )
        )

    def clear_change(self):
        for cb in self.checks.values():
            cb.blockSignals(True)
            cb.setChecked(True)
            cb.blockSignals(False)
        self.sync_group_checks()
        for c in [self.x_start, self.x_end, self.cum_start, self.cum_end]:
            c.setCurrentIndex(0)
        self.display_size.setCurrentText("Auto Fit")
        if hasattr(self, "chart_view"):
            self.chart_view.manual_x0 = None
            self.chart_view.manual_x1 = None
        self.update_chart()

    def save_result_summary_action(self):
        if not self.rows:
            QMessageBox.warning(self, APP_NAME, "No data to save.")
            return

        default_sn = "NA"
        if self.result_file:
            m = re.search(r"ResultSummary_(.+?)(?:_\d{8}_\d{6})?\.xlsx$", os.path.basename(self.result_file), re.I)
            if m:
                default_sn = m.group(1)

        sn, ok = QInputDialog.getText(self, APP_NAME, "Serial Number:", text=default_sn)
        if not ok:
            return

        try:
            self.automatic_backup("Before Save ResultSummary")
            self.show_wait("Saving ResultSummary... Please wait.")
            final_path = save_or_update_resultsummary(self.folder or os.getcwd(), self.result_file, self.rows, self.summary_rows, sn or "NA")
            self.result_file = final_path
            self.result_box.setText(final_path)
            self.folder = os.path.dirname(final_path)
            self.folder_box.setText(self.folder)
            self.hide_wait()
            QMessageBox.information(self, APP_NAME, "Updated:\n%s\n\nBackup is created in ResultSummary_Backup when an existing file is overwritten." % final_path)
        except Exception:
            QMessageBox.critical(self, APP_NAME, traceback.format_exc())


def main():
    write_startup_log("Application start")
    try:
        app = QApplication(sys.argv)
        win = AnalyzerWindow()
        win.show()
        return app.exec()
    except Exception:
        try:
            with open(os.path.join(app_base_dir(), "startup_error.log"), "w", encoding="utf-8") as f:
                f.write(traceback.format_exc())
        except Exception:
            pass
        raise


if __name__ == "__main__":
    sys.exit(main())
