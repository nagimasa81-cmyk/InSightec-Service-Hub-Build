# RC1-3d Workflow Dispatch Test

1. Load and analyze a folder or ZIP.
2. Click the yellow Runtime Reconstruction row.
3. Confirm the button briefly shows Opening and the dialog opens.
4. Close it and click the blue Run: Runtime Reconstruction button.
5. Confirm the same dialog opens.
6. Click completed Import / Manage Replacement History.
7. Confirm the import manager opens.
8. Progress through Explainable Reliability and Dashboard Review.
9. Confirm Calculate Forecast calls the existing forecast calculation.
10. Confirm any unavailable action produces a visible error instead of silence.
