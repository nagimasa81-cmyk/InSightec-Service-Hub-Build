WaterSystemAnalyzer Version 7.3 RC1-3d WorkflowDispatchFix
=============================================================

Root cause:
- `run_workflow_action()` created a dictionary using bound method references.
- One referenced method, `calculate_forecast_action`, did not exist.
- Python evaluated every dictionary value before selecting the clicked action.
- Therefore clicking Runtime Reconstruction, Explainable Reliability, or any
  other workflow button raised AttributeError before the selected action ran.
- Qt printed the slot error silently, so the buttons appeared to do nothing.

Fixed:
- Workflow dispatch now stores method names as strings.
- Only the selected method is resolved with `getattr`.
- Forecast routes to the existing `calculate_forecast_now`.
- Added `calculate_forecast_action` compatibility alias.
- Missing actions now show an explicit error dialog.
- Buttons show immediate Opening feedback when clicked.

Retained:
- Explicit analysis-active state and UI unlock
- Fast ZIP filtering
- Responsive scrollable sidebar
- Project Card and Dashboard-First views
