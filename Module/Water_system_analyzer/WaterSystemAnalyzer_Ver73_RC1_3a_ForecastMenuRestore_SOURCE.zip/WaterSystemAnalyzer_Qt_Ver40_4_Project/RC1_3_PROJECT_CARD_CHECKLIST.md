# RC1-3 Project Card Checklist

- [ ] Drop a WaterSystem folder.
- [ ] Confirm the large Drop Area disappears.
- [ ] Confirm only folder/ZIP name and file count are shown.
- [ ] Hover the card and confirm full path appears as tooltip.
- [ ] Click Change Source and confirm Drop Area returns.
- [ ] Load ResultSummary and confirm compact ResultSummary card.
- [ ] Confirm Browse Folder, Browse ZIP and Browse ResultSummary remain usable.
- [ ] Confirm Previous Session is hidden when no session exists.
- [ ] Confirm Previous Session appears when valid saved paths exist.
- [ ] Confirm Forecast Workflow Assistant still opens and updates.
