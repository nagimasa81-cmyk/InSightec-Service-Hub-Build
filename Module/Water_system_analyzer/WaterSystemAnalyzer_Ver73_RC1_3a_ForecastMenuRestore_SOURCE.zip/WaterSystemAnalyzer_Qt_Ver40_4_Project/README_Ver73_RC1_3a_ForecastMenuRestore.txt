WaterSystemAnalyzer Version 7.3 RC1-3a ForecastMenuRestore
===========================================================

Fixed:
- Forecast group opened but displayed no content.
- Workflow Assistant is inserted into the visible Forecast group layout.
- Forecast opens expanded by default for confirmation.
- Ordered actions 1 through 7 are restored.
- Project Card UI, Browse fallback, ZIP import, Dashboard-First dialogs,
  session handling, and Chart Controls behavior are retained.
