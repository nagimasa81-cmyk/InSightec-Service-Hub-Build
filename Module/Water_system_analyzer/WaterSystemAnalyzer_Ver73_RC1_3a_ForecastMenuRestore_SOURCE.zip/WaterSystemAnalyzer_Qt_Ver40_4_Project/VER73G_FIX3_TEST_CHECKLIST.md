# Version 7.3g Fix3 Test Checklist

## ZIP
- [ ] Drop a deeply nested WaterSystem ZIP.
- [ ] Confirm only relevant files are extracted.
- [ ] Confirm the extraction path is short under Data/IZ.
- [ ] Confirm ZIP member/relevant file counts appear.
- [ ] Confirm duplicate filenames are preserved with unique suffixes.

## Performance
- [ ] Drop a folder and run analysis.
- [ ] Confirm progress changes occasionally and the UI remains responsive.
- [ ] Confirm Cancel does not leave another analysis running.

## Compact UI
- [ ] Confirm Drop Area becomes compact after successful load.
- [ ] Click once to expand it.
- [ ] Click again to open the picker fallback.
- [ ] Confirm popup text is larger and spacing is reduced.
- [ ] Confirm Forecast buttons use one consistent group.
- [ ] Confirm detail tables use alternating rows and compact height.

## Regression
- [ ] EXE starts.
- [ ] Runtime Reconstruction works.
- [ ] Dashboard Preview works.
- [ ] Replacement History ZIP import works.
- [ ] Update/Restore ZIP functions work.
