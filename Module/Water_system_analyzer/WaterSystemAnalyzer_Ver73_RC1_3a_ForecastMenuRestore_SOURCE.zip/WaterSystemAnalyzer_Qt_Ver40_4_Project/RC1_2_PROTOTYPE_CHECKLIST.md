# RC1-2 Prototype Checklist

- [ ] Browse Folder, Browse ZIP, Browse ResultSummary are visible.
- [ ] Workflow order is 1 through 7.
- [ ] ✓ / ▶ / □ states update correctly.
- [ ] Current Status and Recommended Next Step are fully visible.
- [ ] Dashboard Review unlocks Calculate Forecast.
- [ ] Forecast advances to Foundation, then Reliability Dashboard.
- [ ] EXE starts and ZIP/folder import still work.
