# RC1-3a Forecast Menu Checklist

- [ ] Start the EXE.
- [ ] Confirm Forecast is expanded and not empty.
- [ ] Confirm Current Status and Recommended Next Step are visible.
- [ ] Confirm actions 1 through 7 are visible in click order.
- [ ] Confirm Run Recommended Action is visible.
- [ ] Collapse and reopen Forecast.
- [ ] Confirm the contents remain visible.
- [ ] Confirm Project Card, Browse buttons, ZIP import, Runtime Reconstruction,
      Dashboard Preview, and Chart Controls still work.
