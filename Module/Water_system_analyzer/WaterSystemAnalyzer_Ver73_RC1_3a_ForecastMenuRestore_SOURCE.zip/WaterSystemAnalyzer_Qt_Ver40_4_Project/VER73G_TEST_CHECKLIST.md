# Version 7.3g Drop-First UI Test Checklist

## Project
- [ ] Drop a WaterSystem folder onto the folder area.
- [ ] Click the area and confirm folder picker fallback.
- [ ] Drop ResultSummary.xlsx onto the ResultSummary area.
- [ ] Confirm chart/result data loads.
- [ ] Drop an unsupported file and confirm red validation state.

## Replacement History
- [ ] Open Import / Manage Replacement History.
- [ ] Drop XLSX, CSV, and JSON samples.
- [ ] Confirm format detection and Preview update.
- [ ] Click the drop area and confirm picker fallback.

## Module Update
- [ ] Open Backup / Migration > Module Update (Drop ZIP).
- [ ] Drop the included sample update ZIP.
- [ ] Confirm manifest and compatibility information.
- [ ] Run Dry Run and Backup and Stage.
- [ ] Drop a backup ZIP and confirm it is rejected as an update package.

## Restore
- [ ] Open Restore Project Backup (Drop ZIP).
- [ ] Drop a valid project backup.
- [ ] Confirm package recognition.
- [ ] Drop an update ZIP and confirm Restore is disabled.
- [ ] Click the drop area and confirm picker fallback.

## Regression
- [ ] Runtime Reconstruction works.
- [ ] Dashboard Preview opens.
- [ ] Explainable Reliability advances workflow.
- [ ] Replacement History editing/import works.
