# Version 7.3 RC1-1 Confirmation Checklist

## Runtime Reconstruction
- [ ] Open Runtime Reconstruction.
- [ ] Confirm cards show Measured Runtime, Estimated Runtime, Runtime Basis and Confidence.
- [ ] Confirm Potential GAP appears vertically as cards.
- [ ] Confirm detailed tables are closed by default.
- [ ] Open Show Details and confirm all tabs remain available.

## Reliability Dashboard
- [ ] Confirm Coverage, Confidence, Data Quality and Runtime are cards.
- [ ] Confirm explanation is visible without horizontal scrolling.
- [ ] Confirm detailed tables are closed by default.
- [ ] Open Show Details and confirm row-level tables remain available.

## Dashboard Preview
- [ ] Confirm Details / JSON is closed by default.
- [ ] Confirm Scope remains Hospital by default.

## Workflow
- [ ] Confirm Current Step and Next Recommended Action use large vertical text.
- [ ] Confirm Forecast layout matches the other grouped menus.

## Regression
- [ ] EXE starts.
- [ ] Folder and ZIP direct import work.
- [ ] Drop Areas compact after load.
- [ ] Runtime Reconstruction works.
- [ ] Explainable Reliability works.
- [ ] Dashboard Preview opens.
- [ ] Update and Restore ZIP functions work.
