# Version 7.3g Fix1 Test Checklist

## Startup
- [ ] Build the EXE.
- [ ] Double-click the application EXE.
- [ ] Confirm the main window opens without `scan_folder_check` error.

## Tools / Debug
- [ ] Open Tools / Debug.
- [ ] Run Scan Folder Check.
- [ ] Run Date Parse Check.
- [ ] Open Analyze Debug.
- [ ] Open Analyze Performance.

## Chart controls
- [ ] Toggle ALL and grouped checkboxes.
- [ ] Confirm chart series update correctly.
- [ ] Confirm no missing `set_all` / `sync_group_checks` errors.

## Drop-first regression
- [ ] Drop WaterSystem folder.
- [ ] Drop ResultSummary.
- [ ] Drop Replacement History.
- [ ] Drop Update ZIP.
- [ ] Open Restore Project Backup drop dialog.

## Reliability regression
- [ ] Runtime Reconstruction.
- [ ] Dashboard Preview.
- [ ] Explainable Reliability.
