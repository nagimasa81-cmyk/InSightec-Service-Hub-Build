# Version 7.3g Fix2 Test Checklist

- Drop WaterSystem ZIP and confirm direct extraction/import.
- Drop Replacement History ZIP and confirm Preview.
- Confirm Chart Controls are closed on startup.
- Load non-event chart data and click chart; controls stay closed.
- Confirm Forecast instruction cards are fully visible.
- Confirm EXE starts and prior reliability functions still work.
