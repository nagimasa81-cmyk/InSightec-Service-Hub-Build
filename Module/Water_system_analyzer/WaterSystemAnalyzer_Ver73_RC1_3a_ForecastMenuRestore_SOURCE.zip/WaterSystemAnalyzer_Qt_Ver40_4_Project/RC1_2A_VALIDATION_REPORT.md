# RC1-2a Validation Report

Fixed `sidebar_lay` startup NameError by using the existing `panel_lay`.

## Windows test
1. Build EXE.
2. Double-click EXE.
3. Expand Forecast.
4. Confirm ordered actions 1-7.
5. Confirm Browse Folder / ZIP / ResultSummary.
