WaterSystemAnalyzer Version 7.3g Fix3 ZipPerformanceCompactUI
================================================================

ZIP performance:
- Extracts only supported WaterSystem logs and ResultSummary files.
- Flattens deep ZIP wrapper folders.
- Uses short extraction paths under Data/IZ.
- Resolves duplicate filenames with short hashes.
- Shows ZIP member count and relevant-file count during import.

UI:
- Drop areas collapse to compact status cards after successful loading.
- Click a compact card once to expand; click again to browse.
- Progress popup text is larger and excess vertical space is reduced.
- Forecast buttons are grouped in the same visual style.
- Table views use alternating rows, compact row height and row selection.

Retained:
- Direct ZIP import
- Chart Controls remain manually opened only
- Interactive Workflow
- Startup/callback fixes
- Dashboard and Runtime fixes
