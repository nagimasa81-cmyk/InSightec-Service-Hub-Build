WaterSystemAnalyzer Version 7.3 RC1-2b ActualLayoutFix
=========================================================

Cause of the RC1-2 / RC1-2a startup failures:
- The original AnalyzerWindow._ui creates the left layout as:
    pl = QVBoxLayout(panel)
- RC1-2 used sidebar_lay.
- RC1-2a changed it to panel_lay.
- Neither sidebar_lay nor panel_lay exists.

Fixed:
- Forecast Workflow Assistant is now added using the real layout:
    pl.addWidget(self.forecast_group["box"])

Retained:
- Ordered Forecast workflow 1 through 7
- Browse Folder / Browse ZIP / Browse ResultSummary
- Drag-and-drop primary operation
- Dashboard-First Runtime and Reliability displays
- ZIP performance and compact Drop Areas
