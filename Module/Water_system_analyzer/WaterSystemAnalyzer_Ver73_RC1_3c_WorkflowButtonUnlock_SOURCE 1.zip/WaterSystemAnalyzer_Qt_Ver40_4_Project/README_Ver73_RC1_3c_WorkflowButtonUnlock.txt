WaterSystemAnalyzer Version 7.3 RC1-3c WorkflowButtonUnlock
================================================================

Cause:
- `on_finished()` was called while the QThread could still report isRunning=True.
- Workflow refresh therefore disabled the entire Workflow Assistant again.
- The card looked complete, but Runtime Reconstruction and other actions could
  not receive clicks.

Fixed:
- Added explicit `analysis_active` state.
- Cleared analysis state before success/failure workflow refresh.
- Added final QThread finished cleanup and another workflow refresh.
- The Workflow Assistant container itself is never disabled.
- Only step buttons are temporarily disabled during active parsing.
- Every step button is explicitly restored after parsing.
- Calculate Forecast remains gated until Explainable Reliability and
  Dashboard Review are complete.

Retained:
- Fast ZIP content filtering
- Scrollable responsive sidebar
- Project Card and Browse fallback
- Ordered actions 1 through 7
- Dashboard-First views
