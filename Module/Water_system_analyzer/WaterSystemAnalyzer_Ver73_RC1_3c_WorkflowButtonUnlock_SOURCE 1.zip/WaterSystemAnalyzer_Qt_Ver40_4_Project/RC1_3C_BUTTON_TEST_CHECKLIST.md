# RC1-3c Workflow Button Test

1. Load a folder or ZIP and run analysis.
2. During analysis, confirm Workflow shows `Analysis in progress`.
3. After analysis completes, click the yellow Runtime Reconstruction row.
4. Confirm the Runtime Reconstruction dialog opens.
5. Close it and click the blue `Run: Runtime Reconstruction` button.
6. Confirm the same dialog opens.
7. Complete Runtime and verify Explainable Reliability becomes recommended.
8. Confirm unrelated pending steps are also clickable for review.
9. Confirm Calculate Forecast remains disabled until Dashboard Review.
10. Force/cancel an analysis and confirm controls unlock afterward.
