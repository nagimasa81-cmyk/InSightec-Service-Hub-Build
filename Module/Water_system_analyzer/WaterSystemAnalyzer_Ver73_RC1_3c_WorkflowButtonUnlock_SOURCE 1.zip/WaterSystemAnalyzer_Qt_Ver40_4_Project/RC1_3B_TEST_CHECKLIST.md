# RC1-3b Test Checklist
- [ ] ZIP with unrelated TXT/LOG files imports only WaterSystem logs.
- [ ] Small window shows scrollable Project and Forecast panels.
- [ ] Drop text does not overlap.
- [ ] During analysis actions show Analysis in progress.
- [ ] After completion Runtime Reconstruction is clickable.
- [ ] After an error all buttons unlock.
