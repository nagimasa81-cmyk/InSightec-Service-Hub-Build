WaterSystemAnalyzer Version 7.3 RC1-2a SidebarLayoutFix
==========================================================

Fixed:
- Startup NameError: sidebar_lay is not defined.
- Forecast Workflow Assistant is now inserted into the existing panel_lay.
- Browse Folder / Browse ZIP / Browse ResultSummary remain available.
- Drag and drop remains the primary operation.
- Ordered Forecast workflow 1 through 7 is retained.
- Dashboard-First Runtime and Reliability dialogs are retained.
