WaterSystemAnalyzer Version 7.3c ReplacementImportWizard
========================================================

Base:
- Version 7.3b VisibleDashboardUX

Added:
- Replacement History Import Wizard.
- Step flow:
  Select File -> Auto Mapping -> Preview -> Validation -> Import.
- Supports:
  .xlsx / .xlsm / .csv / .json
- Automatic column mapping using header aliases.
- Legacy History.xlsx conversion:
  Column A = Serial Number
  Column B = Hospital Name
  Column C onward = Replacement Dates
- Master-based default choices:
  Component Type
  Replacement Type
  Failure Type
- Replacement Type normalization:
  Scheduled / Preventive / PM / Periodic -> Scheduled Replacement
- Failure Type normalization:
  Water Cup -> Water in Vacuum Cup
  Slow -> Slow Degas
  Minimum High -> Degas Minimum High
- Duplicate detection before commit.
- Preview and validation summary.
- Import progress dialog.
- Updated menu tooltips.

Notes:
- .xls legacy binary format is not directly supported; save it as .xlsx first.
- Row-by-row editable dropdowns are planned for the next refinement; 7.3c provides master-based default dropdowns and automatic conversion.

Validation:
1. Build EXE.
2. Forecast -> Import Replacement History.
3. Select a legacy History.xlsx and confirm automatic legacy detection.
4. Select a header-based xlsx/csv/json and confirm auto mapping.
5. Review Preview and Validation.
6. Import and confirm Replacement_History.xlsx is updated.
