WaterSystemAnalyzer Version 7.3g DropFirstUI
================================================

Drop-first input areas added:
- WaterSystem Folder
- ResultSummary
- Replacement History
- Module Update ZIP
- Project Backup Restore ZIP

Behavior:
- Drag and drop is the primary operation.
- Clicking a drop area opens the file/folder picker as a fallback.
- Drop areas change visually:
  blue while hovering, green on success, red on invalid input.
- Smart recognition shows the detected file/package type.
- Update ZIP requires manifest.json.
- Project Backup ZIP requires a Data/ folder.
- Incorrect package types are blocked before processing.

Retained:
- Reliability UX fixes
- Potential GAP / Reference Intervals
- Dashboard Scope
- Hospital / Serial filters
- Session continuation
- Degas Module terminology
- Update Foundation safety checks

See VER73G_TEST_CHECKLIST.md for validation.
