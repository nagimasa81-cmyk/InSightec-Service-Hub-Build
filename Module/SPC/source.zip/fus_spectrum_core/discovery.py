from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import shutil
import tempfile
import zipfile

@dataclass
class DiscoveredFiles:
    root: Path
    spectrum_files: list[Path]
    geometry_files: list[Path]
    xd_files: list[Path]
    other_candidate_files: list[Path]
    temporary: bool = False

    def cleanup(self) -> None:
        if self.temporary and self.root.exists():
            shutil.rmtree(self.root, ignore_errors=True)


def _safe_extract(zf: zipfile.ZipFile, destination: Path) -> None:
    base = destination.resolve()
    for info in zf.infolist():
        target = (destination / info.filename).resolve()
        if base not in target.parents and target != base:
            raise ValueError(f"Unsafe ZIP member: {info.filename}")
    zf.extractall(destination)


def discover_input(path: str | Path) -> DiscoveredFiles:
    source = Path(path).expanduser().resolve()
    if not source.exists():
        raise FileNotFoundError(source)

    temporary = False
    if source.is_file() and zipfile.is_zipfile(source):
        root = Path(tempfile.mkdtemp(prefix="fus_spectrum_"))
        temporary = True
        with zipfile.ZipFile(source) as zf:
            _safe_extract(zf, root)
    elif source.is_dir():
        root = source
    elif source.is_file():
        root = source.parent
    else:
        raise ValueError(f"Unsupported input: {source}")

    files = [p for p in root.rglob("*") if p.is_file()]
    if source.is_file() and not zipfile.is_zipfile(source):
        files = [source] + [p for p in files if p != source]

    spectrum = []
    geometry = []
    xd = []
    others = []
    for p in files:
        n = p.name.lower()
        if n.startswith("spectrummsg") and (n.endswith(".dmp") or n.endswith(".dump") or n.endswith(".gz")):
            spectrum.append(p)
        elif n.startswith("xdgeometry") and n.endswith(".ini"):
            geometry.append(p)
        elif n.startswith("xd_") and n.endswith(".ini"):
            xd.append(p)
        elif "spectrum" in n or "sonication" in n or "vim" in n or "treatment" in n:
            others.append(p)

    spectrum.sort(key=lambda p: p.as_posix().lower())
    geometry.sort(key=lambda p: p.as_posix().lower())
    xd.sort(key=lambda p: p.as_posix().lower())
    others.sort(key=lambda p: p.as_posix().lower())
    return DiscoveredFiles(root, spectrum, geometry, xd, others, temporary)
