from __future__ import annotations
from pathlib import Path
import gzip
import struct
import numpy as np
from .models import SpectrumChannel, SpectrumDump

CHANNEL_HEADER_BYTES = 20
SPECTRUM_BINS = 256
SLOT_METADATA_VALUES = 5
SLOT_FLOATS = SPECTRUM_BINS + SLOT_METADATA_VALUES
SLOTS_PER_MESSAGE = 24
CHANNEL_BLOCK_BYTES = CHANNEL_HEADER_BYTES + SLOTS_PER_MESSAGE * SLOT_FLOATS * 4
RECORD_HEADER_BYTES = 12
RECORD_FOOTER_BYTES = 24


def _read_payload(path: Path) -> bytes:
    raw = path.read_bytes()
    if raw[:2] == b"\x1f\x8b":
        return gzip.decompress(raw)
    return raw


def parse_spectrum_dump(path: str | Path) -> SpectrumDump:
    p = Path(path)
    data = _read_payload(p)
    if len(data) < 32:
        raise ValueError("File is too small to be a SpectrumMsg dump")
    message_count = struct.unpack_from("<I", data, 0)[0]
    if not 1 <= message_count <= 1_000_000:
        raise ValueError(f"Unreasonable message count: {message_count}")
    record_size = (len(data) - 4) // message_count
    if 4 + record_size * message_count != len(data):
        raise ValueError("File length does not match its message count")

    warnings: list[str] = []
    channels_acc: list[list[np.ndarray]] = []
    metadata_acc: list[list[np.ndarray]] = []
    valid_acc: list[list[np.ndarray]] = []
    channel_headers: list[tuple[float,float,float,float,int]] = []
    footers = []
    detected_channel_count = None

    for mi in range(message_count):
        ro = 4 + mi * record_size
        payload_size, channel_count, reserved = struct.unpack_from("<III", data, ro)
        if detected_channel_count is None:
            detected_channel_count = channel_count
            channels_acc = [[] for _ in range(channel_count)]
            metadata_acc = [[] for _ in range(channel_count)]
            valid_acc = [[] for _ in range(channel_count)]
        if channel_count != detected_channel_count:
            raise ValueError(f"Channel count changed at message {mi}: {channel_count}")
        expected = RECORD_HEADER_BYTES + channel_count * CHANNEL_BLOCK_BYTES + RECORD_FOOTER_BYTES
        if expected != record_size:
            raise ValueError(f"Unsupported record size {record_size}; expected {expected} for {channel_count} channels")
        if payload_size not in (record_size - 4, record_size, expected - 4):
            warnings.append(f"Message {mi}: unexpected payload marker {payload_size}")

        for ch in range(channel_count):
            co = ro + RECORD_HEADER_BYTES + ch * CHANNEL_BLOCK_BYTES
            window_s, spacing_hz, half_span_hz, interval_s, bins = struct.unpack_from("<4fI", data, co)
            if bins != SPECTRUM_BINS:
                raise ValueError(f"Unsupported FFT bin count {bins} in message {mi}, channel {ch}")
            if mi == 0:
                channel_headers.append((window_s, spacing_hz, half_span_hz, interval_s, bins))
            values = np.frombuffer(data, dtype="<f4", count=SLOTS_PER_MESSAGE*SLOT_FLOATS,
                                   offset=co + CHANNEL_HEADER_BYTES).reshape(SLOTS_PER_MESSAGE, SLOT_FLOATS).copy()
            spec = values[:, :bins]
            meta = values[:, bins:]
            finite_fraction = np.isfinite(spec).mean(axis=1)
            safe = np.where(np.isfinite(spec), np.abs(spec), 0.0)
            magnitude = safe.max(axis=1)
            valid = (finite_fraction > 0.95) & (magnitude > 0)
            channels_acc[ch].append(spec)
            metadata_acc[ch].append(meta)
            valid_acc[ch].append(valid)

        fo = ro + RECORD_HEADER_BYTES + channel_count * CHANNEL_BLOCK_BYTES
        footers.append(np.frombuffer(data, dtype="<f4", count=6, offset=fo).copy())

    channels: list[SpectrumChannel] = []
    for ch in range(detected_channel_count or 0):
        h = channel_headers[ch]
        channels.append(SpectrumChannel(
            channel=ch, window_s=h[0], bin_spacing_hz=h[1], half_span_hz=h[2],
            frame_interval_s=h[3], bin_count=h[4],
            spectra=np.vstack(channels_acc[ch]), metadata=np.vstack(metadata_acc[ch]),
            valid_mask=np.concatenate(valid_acc[ch])
        ))
    return SpectrumDump(p, message_count, detected_channel_count or 0, channels, np.vstack(footers), warnings)


def frequency_axis_hz(channel: SpectrumChannel, center_hz: float | None = None) -> np.ndarray:
    # Header values are internally consistent with a 500 kHz span / 256 bins.
    offsets = (np.arange(channel.bin_count, dtype=float) - channel.bin_count / 2.0) * channel.bin_spacing_hz
    return offsets if center_hz is None else center_hz + offsets


def frame_time_s(channel: SpectrumChannel) -> np.ndarray:
    return np.arange(channel.spectra.shape[0], dtype=float) * channel.frame_interval_s
