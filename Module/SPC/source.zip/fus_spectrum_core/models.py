from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
import numpy as np

@dataclass
class HydrophonePosition:
    channel: int
    label: str
    clock_text: str | None = None
    angle_deg: float | None = None
    x: float | None = None
    y: float | None = None
    z: float | None = None
    area_mm2: float | None = None

@dataclass
class XdParameters:
    serial_number: str | None = None
    xd_type: str | None = None
    acoustic_power_limit: float | None = None
    enabled_frequencies_hz: list[float] = field(default_factory=list)
    all_frequencies_hz: list[float] = field(default_factory=list)
    preferred_frequency_hz: float | None = None
    source_file: Path | None = None

@dataclass
class SpectrumChannel:
    channel: int
    window_s: float
    bin_spacing_hz: float
    half_span_hz: float
    frame_interval_s: float
    bin_count: int
    spectra: np.ndarray          # shape: frames x bins
    metadata: np.ndarray         # shape: frames x 5
    valid_mask: np.ndarray       # shape: frames

@dataclass
class SpectrumDump:
    source_file: Path
    message_count: int
    channel_count: int
    channels: list[SpectrumChannel]
    message_footer: np.ndarray   # shape: messages x 6 float32 (unknown)
    warnings: list[str] = field(default_factory=list)

    @property
    def total_frames(self) -> int:
        return int(self.channels[0].spectra.shape[0]) if self.channels else 0
