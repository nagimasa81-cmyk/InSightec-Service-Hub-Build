# FUS Hydrophone Spectrum Analyzer

Standalone PySide6 tool and reusable parser package for `SpectrumMsg*.dmp` files generated during FUS sonication.

## Input

Use **Open ZIP / File**, **Open Folder**, or drag and drop:

- a ZIP containing nested folders;
- a hierarchical treatment folder;
- a `SpectrumMsg*.dmp` file.

The tool recursively finds:

- `SpectrumMsg*.dmp`, `.dump`, or `.gz`;
- `XdGeometry*.ini` for channel-to-hydrophone position mapping;
- `Xd_*.ini` for XD serial/type and available frequencies.

Missing INI files do not stop parsing. A generic circular layout and offset-frequency axis are used instead.

## Implemented binary format

Validated against the supplied sample:

- gzip container;
- one global `uint32` message count;
- each message: 12-byte header, 8 hydrophone blocks, 24-byte unknown footer;
- each hydrophone block: 20-byte header plus 24 short-time FFT slots;
- each slot: 256 `float32` spectrum values and 5 `float32` metadata values.

Unknown footer and slot metadata are preserved by the core parser but deliberately not assigned undocumented meanings.

## Reuse in other tools

Import the package without the UI:

```python
from fus_spectrum_core import discover_input, parse_spectrum_dump, parse_geometry, parse_xd_parameters

found = discover_input(r"C:\Treatment.zip")
dump = parse_spectrum_dump(found.spectrum_files[0])
layout = parse_geometry(found.geometry_files[0]) if found.geometry_files else []
xd = parse_xd_parameters(found.xd_files[0]) if found.xd_files else None
```

The core package has no Qt dependency. It depends only on NumPy.

## Current safeguards

- ZIP path traversal protection;
- recursive discovery;
- format-size validation;
- variable message and channel counts where the validated block format remains compatible;
- invalid/NaN/zero spectrum slots excluded from plots;
- temporary ZIP extraction is removed when the next input is loaded or the app exits.

## Important interpretation note

The display treats the FFT as a centered ±250 kHz offset axis because `256 × 1953 Hz ≈ 500 kHz`. Absolute frequency is optional and uses a user-editable center frequency. The XD INI does not reliably identify the exact frequency of each sonication, so the center must later be synchronized with treatment/sonication records when those formats are added.
