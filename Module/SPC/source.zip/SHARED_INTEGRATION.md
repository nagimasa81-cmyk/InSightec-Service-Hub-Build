# Shared Integration Contract

Other Service Hub modules should reuse `fus_spectrum_core` rather than copying binary parsing code.

## Stable entry points

- `discover_input(path)` — recursively extracts/searches ZIPs and folders.
- `parse_spectrum_dump(path)` — returns a structured `SpectrumDump`.
- `parse_geometry(path)` — returns channel positions from `[ADDITIONAL_CHANNELS]`.
- `parse_xd_parameters(path)` — returns XD identity and available frequencies.
- `frequency_axis_hz(channel, center_hz=None)` — creates offset or absolute frequency axes.

## Data contract

`SpectrumDump.channels[ch].spectra` is a NumPy array shaped `(time_slots, fft_bins)`.

`valid_mask` identifies usable slots. Consumers must not assume every 24-slot message contains 24 valid spectra.

`metadata` and `message_footer` are retained as raw floats because their meanings are not yet proven. Do not label them as cavitation, power, time, or status until correlation with treatment logs establishes their definitions.

## Future adapters

Recommended additions should be separate modules:

- sonication timeline adapter;
- treatment-frequency resolver;
- MRI/temperature synchronization adapter;
- stable/inertial/broadband metric engine;
- export adapter for CSV/XLSX/JSON.

This keeps the validated dump parser independent from UI and treatment-specific assumptions.
