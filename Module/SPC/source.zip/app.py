from __future__ import annotations
import sys, math, traceback
from pathlib import Path
import numpy as np
from PySide6.QtCore import Qt, Signal, QThread
from PySide6.QtGui import QAction, QDragEnterEvent, QDropEvent
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QFileDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QListWidget, QListWidgetItem, QSplitter, QComboBox, QSpinBox,
    QDoubleSpinBox, QCheckBox, QTableWidget, QTableWidgetItem, QHeaderView,
    QMessageBox, QProgressBar, QGroupBox, QFormLayout, QTabWidget, QTextEdit
)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from fus_spectrum_core import (
    discover_input, parse_geometry, parse_xd_parameters, parse_spectrum_dump,
    frequency_axis_hz
)

class Worker(QThread):
    done = Signal(object)
    failed = Signal(str)
    def __init__(self, path):
        super().__init__(); self.path=path
    def run(self):
        bundle = None
        try:
            found = discover_input(self.path)
            geom = parse_geometry(found.geometry_files[0]) if found.geometry_files else []
            xd = parse_xd_parameters(found.xd_files[0]) if found.xd_files else None
            dumps=[]
            for p in found.spectrum_files:
                try: dumps.append(parse_spectrum_dump(p))
                except Exception as e: dumps.append((p,e))
            self.done.emit((found, geom, xd, dumps))
        except Exception:
            self.failed.emit(traceback.format_exc())

class PlotCanvas(FigureCanvas):
    def __init__(self):
        self.fig=Figure(figsize=(7,5), tight_layout=True)
        self.ax=self.fig.add_subplot(111)
        super().__init__(self.fig)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('FUS Hydrophone Spectrum Analyzer')
        self.resize(1450, 900)
        self.setAcceptDrops(True)
        self.found=None; self.geom=[]; self.xd=None; self.dumps=[]; self.current=None
        self._build()

    def _build(self):
        root=QWidget(); self.setCentralWidget(root); outer=QVBoxLayout(root)
        top=QHBoxLayout(); outer.addLayout(top)
        self.open_zip=QPushButton('Open ZIP / File'); self.open_folder=QPushButton('Open Folder')
        self.open_zip.clicked.connect(self.choose_file); self.open_folder.clicked.connect(self.choose_folder)
        top.addWidget(self.open_zip); top.addWidget(self.open_folder)
        self.path_label=QLabel('Drop a ZIP, SpectrumMsg dump, or a hierarchical folder here')
        self.path_label.setStyleSheet('padding:10px;border:1px dashed #777;')
        top.addWidget(self.path_label,1)
        self.progress=QProgressBar(); self.progress.setRange(0,0); self.progress.hide(); top.addWidget(self.progress)

        split=QSplitter(); outer.addWidget(split,1)
        left=QWidget(); ll=QVBoxLayout(left); split.addWidget(left)
        self.files=QListWidget(); self.files.itemSelectionChanged.connect(self.select_dump)
        ll.addWidget(QLabel('Detected Spectrum Dumps')); ll.addWidget(self.files,2)
        self.info=QTableWidget(0,2); self.info.setHorizontalHeaderLabels(['Item','Value'])
        self.info.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeToContents)
        self.info.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch)
        ll.addWidget(self.info,2)
        self.log=QTextEdit(); self.log.setReadOnly(True); ll.addWidget(self.log,1)

        tabs=QTabWidget(); split.addWidget(tabs); split.setStretchFactor(1,1)
        # Spectrum tab
        sp=QWidget(); sl=QVBoxLayout(sp); tabs.addTab(sp,'Spectrum')
        controls=QHBoxLayout(); sl.addLayout(controls)
        controls.addWidget(QLabel('Frame'))
        self.frame=QSpinBox(); self.frame.setRange(0,0); self.frame.valueChanged.connect(self.redraw); controls.addWidget(self.frame)
        controls.addWidget(QLabel('Center frequency (kHz)'))
        self.center=QDoubleSpinBox(); self.center.setRange(0,2000); self.center.setDecimals(3); self.center.setValue(0); self.center.valueChanged.connect(self.redraw); controls.addWidget(self.center)
        self.absolute=QCheckBox('Absolute frequency'); self.absolute.stateChanged.connect(self.redraw); controls.addWidget(self.absolute)
        self.logscale=QCheckBox('dB display'); self.logscale.stateChanged.connect(self.redraw); controls.addWidget(self.logscale)
        controls.addStretch(1)
        self.channel_checks=[]
        for i in range(8):
            cb=QCheckBox(f'CH{i}'); cb.setChecked(True); cb.stateChanged.connect(self.redraw); controls.addWidget(cb); self.channel_checks.append(cb)
        self.plot=PlotCanvas(); sl.addWidget(self.plot,1)

        # Spectrogram tab
        sg=QWidget(); sgl=QVBoxLayout(sg); tabs.addTab(sg,'Spectrogram')
        row=QHBoxLayout(); sgl.addLayout(row); row.addWidget(QLabel('Channel'))
        self.sg_channel=QComboBox(); self.sg_channel.currentIndexChanged.connect(self.redraw_spectrogram); row.addWidget(self.sg_channel); row.addStretch(1)
        self.sg_plot=PlotCanvas(); sgl.addWidget(self.sg_plot,1)

        # Layout tab
        ly=QWidget(); lyl=QVBoxLayout(ly); tabs.addTab(ly,'XD Hydrophone Layout')
        self.layout_plot=PlotCanvas(); lyl.addWidget(self.layout_plot,1)

    def dragEnterEvent(self,e:QDragEnterEvent):
        if e.mimeData().hasUrls(): e.acceptProposedAction()
    def dropEvent(self,e:QDropEvent):
        urls=e.mimeData().urls()
        if urls: self.load_path(urls[0].toLocalFile())
    def choose_file(self):
        p,_=QFileDialog.getOpenFileName(self,'Open ZIP or Spectrum dump','','ZIP / dump (*.zip *.dmp *.dump *.gz);;All files (*)')
        if p:self.load_path(p)
    def choose_folder(self):
        p=QFileDialog.getExistingDirectory(self,'Open hierarchical folder')
        if p:self.load_path(p)
    def load_path(self,p):
        if self.found: self.found.cleanup()
        self.path_label.setText(p); self.progress.show(); self.setEnabled(False)
        self.worker=Worker(p); self.worker.done.connect(self.loaded); self.worker.failed.connect(self.failed); self.worker.start()
    def failed(self,text):
        self.progress.hide(); self.setEnabled(True); QMessageBox.critical(self,'Load failed',text)
    def loaded(self,result):
        self.progress.hide(); self.setEnabled(True)
        self.found,self.geom,self.xd,raw=result
        self.dumps=[x for x in raw if not isinstance(x,tuple)]
        self.files.clear(); self.log.clear()
        for x in raw:
            if isinstance(x,tuple): self.log.append(f'FAILED: {x[0]}\n{x[1]}')
            else:
                it=QListWidgetItem(str(x.source_file.relative_to(self.found.root) if x.source_file.is_relative_to(self.found.root) else x.source_file.name)); it.setData(Qt.UserRole,x); self.files.addItem(it)
        self.log.append(f'Spectrum dumps: {len(self.found.spectrum_files)}')
        self.log.append(f'Geometry files: {len(self.found.geometry_files)}')
        self.log.append(f'XD parameter files: {len(self.found.xd_files)}')
        if not self.dumps: QMessageBox.warning(self,'No spectrum','No compatible SpectrumMsg dump was found.')
        else: self.files.setCurrentRow(0)
        self.draw_layout()
    def select_dump(self):
        it=self.files.currentItem()
        if not it:return
        self.current=it.data(Qt.UserRole)
        maxf=max((c.spectra.shape[0] for c in self.current.channels),default=1)-1
        self.frame.setRange(0,maxf); self.frame.setValue(0)
        self.sg_channel.clear(); self.sg_channel.addItems([f'CH{c.channel}' for c in self.current.channels])
        if self.xd and self.xd.preferred_frequency_hz:
            self.center.setValue(self.xd.preferred_frequency_hz/1000)
        self.fill_info(); self.redraw(); self.redraw_spectrogram(); self.draw_layout()
    def fill_info(self):
        d=self.current
        rows=[('File',str(d.source_file)),('Messages',d.message_count),('Hydrophones',d.channel_count),('FFT bins',d.channels[0].bin_count),('Slots/message',24),('Total slots/channel',d.total_frames),('Valid spectra',[int(c.valid_mask.sum()) for c in d.channels]),('Bin spacing',f'{d.channels[0].bin_spacing_hz:.3f} Hz'),('Frequency span',f'±{d.channels[0].half_span_hz/1000:.3f} kHz'),('Frame interval',f'{d.channels[0].frame_interval_s*1000:.3f} ms')]
        if self.xd:
            rows += [('XD serial',self.xd.serial_number or 'Unknown'),('XD type',self.xd.xd_type or 'Unknown'),('Enabled frequencies',', '.join(f'{x/1000:g}' for x in self.xd.enabled_frequencies_hz)+' kHz')]
        rows += [('Geometry', 'Loaded' if self.geom else 'Not found; generic circular layout used')]
        self.info.setRowCount(len(rows))
        for r,(a,b) in enumerate(rows): self.info.setItem(r,0,QTableWidgetItem(str(a))); self.info.setItem(r,1,QTableWidgetItem(str(b)))
    def redraw(self):
        if not self.current:return
        ax=self.plot.ax; ax.clear(); idx=self.frame.value(); center=self.center.value()*1000 if self.absolute.isChecked() else None
        for c,cb in zip(self.current.channels,self.channel_checks):
            if not cb.isChecked() or idx>=len(c.spectra):continue
            y=c.spectra[idx].astype(float)
            if not c.valid_mask[idx]: continue
            if self.logscale.isChecked(): y=20*np.log10(np.maximum(np.abs(y),1e-12))
            x=frequency_axis_hz(c,center)/1000
            ax.plot(x,y,label=f'CH{c.channel}')
        ax.set_xlabel('Frequency (kHz)' if center is not None else 'Frequency offset (kHz)')
        ax.set_ylabel('Magnitude (dB)' if self.logscale.isChecked() else 'Magnitude')
        ax.grid(True,alpha=.25); ax.legend(loc='best',ncol=4); ax.set_title(f'FFT Spectrum — frame {idx}')
        self.plot.draw_idle(); self.draw_layout()
    def redraw_spectrogram(self):
        if not self.current or self.sg_channel.currentIndex()<0:return
        c=self.current.channels[self.sg_channel.currentIndex()]; arr=c.spectra.astype(float).copy(); arr[~c.valid_mask,:]=np.nan
        z=20*np.log10(np.maximum(np.abs(arr),1e-12)); x=frequency_axis_hz(c,None)/1000; t=np.arange(arr.shape[0])*c.frame_interval_s
        ax=self.sg_plot.ax; ax.clear(); ax.imshow(z.T,origin='lower',aspect='auto',extent=[t[0],t[-1] if len(t)>1 else 0,x[0],x[-1]])
        ax.set_xlabel('Time (s)'); ax.set_ylabel('Frequency offset (kHz)'); ax.set_title(f'CH{c.channel} Spectrogram (dB)'); self.sg_plot.draw_idle()
    def draw_layout(self):
        ax=self.layout_plot.ax; ax.clear(); ax.set_aspect('equal'); ax.axis('off')
        positions={p.channel:p for p in self.geom}
        strengths={}
        if self.current:
            idx=self.frame.value()
            for c in self.current.channels:
                strengths[c.channel]=float(np.nanmax(np.abs(c.spectra[idx]))) if idx<len(c.spectra) and c.valid_mask[idx] else 0.0
        vmax=max(strengths.values(),default=1) or 1
        n=self.current.channel_count if self.current else max(len(positions),8)
        for ch in range(n):
            p=positions.get(ch)
            angle=p.angle_deg if p and p.angle_deg is not None else 90-ch*360/max(n,1)
            # Cap channels inside, tile channels outside when labels provide the distinction.
            radius=.72 if p and p.label.lower().startswith('cap') else 1.0
            x=radius*math.cos(math.radians(angle)); y=radius*math.sin(math.radians(angle))
            s=500+2200*(strengths.get(ch,0)/vmax)
            ax.scatter([x],[y],s=s,alpha=.55)
            label=f'CH{ch}' + (f'\n{p.label}\n{p.clock_text}' if p else '')
            ax.text(x,y,label,ha='center',va='center',fontsize=9)
        circ=np.linspace(0,2*np.pi,300); ax.plot(np.cos(circ),np.sin(circ),linewidth=1); ax.plot(.55*np.cos(circ),.55*np.sin(circ),linewidth=1)
        serial=self.xd.serial_number if self.xd and self.xd.serial_number else 'Unknown'
        ax.set_title(f'XD Hydrophone Layout — Serial {serial}\nMarker size = selected-frame maximum spectrum magnitude')
        ax.set_xlim(-1.35,1.35); ax.set_ylim(-1.25,1.25); self.layout_plot.draw_idle()

def main():
    app = QApplication.instance() or QApplication(sys.argv)
    window = MainWindow()
    window.show()
    return app.exec()

if __name__ == '__main__':
    sys.exit(main())
