@echo off
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set NUITKA_ASSUME_YES_FOR_DOWNLOADS=yes

python -m pip install --upgrade pip setuptools wheel
if errorlevel 1 exit /b 1
python -m pip install -r requirements.txt
if errorlevel 1 exit /b 1

python -m nuitka ^
  --mode=onefile ^
  --enable-plugin=pyside6 ^
  --include-package=matplotlib ^
  --windows-console-mode=force ^
  --assume-yes-for-downloads ^
  --output-dir=build_debug ^
  --output-filename=FUS_Spectrum_Analyzer_DEBUG.exe ^
  app.py
if errorlevel 1 pause
