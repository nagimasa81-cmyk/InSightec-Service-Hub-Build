"""Compatibility entry point for generic GitHub Actions build workflows."""
from app import main

if __name__ == "__main__":
    main()
