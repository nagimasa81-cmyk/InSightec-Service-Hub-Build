# SPC build placement

Place this ZIP as:

```text
Repository/Module/SPC/source.zip
```

Run `build_investigation_workspace_improved_SPC.yml` and select `SPC`.
The workflow extracts only `Module/SPC/source.zip`, runs `01_BUILD_EXE_NUITKA.bat`, and uploads the packaged EXE.
