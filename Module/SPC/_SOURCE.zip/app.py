from __future__ import annotations

import sys
import traceback
from pathlib import Path

import numpy as np
from PySide6.QtCore import Qt, Signal, QThread, QTimer
from PySide6.QtGui import QDragEnterEvent, QDropEvent, QColor, QBrush
from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QFileDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSplitter,
    QComboBox,
    QSpinBox,
    QDoubleSpinBox,
    QCheckBox,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QMessageBox,
    QProgressBar,
    QTabWidget,
    QTextEdit,
    QTreeWidget,
    QTreeWidgetItem,
    QGroupBox,
)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from fus_spectrum_core import (
    discover_input,
    parse_geometry,
    parse_xd_parameters,
    parse_spectrum_dump,
    frequency_axis_hz,
    default_hydrophone_layout,
    analyze_frame,
)


class Worker(QThread):
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, path: str):
        super().__init__()
        self.path = path

    def run(self) -> None:
        try:
            study = discover_input(self.path)
            geom = parse_geometry(study.geometry_files[0]) if study.geometry_files else []
            xd = parse_xd_parameters(study.xd_files[0]) if study.xd_files else None
            parsed = []
            son_by_path = {
                p.resolve(): s.name
                for s in study.sonications
                for p in s.spectrum_files
            }
            for path in study.spectrum_files:
                try:
                    dump = parse_spectrum_dump(path)
                    dump.sonication_name = son_by_path.get(path.resolve(), "Unassigned")
                    parsed.append(dump)
                except Exception as exc:
                    parsed.append((path, exc))
            self.done.emit((study, geom, xd, parsed))
        except Exception:
            self.failed.emit(traceback.format_exc())


class PlotCanvas(FigureCanvas):
    def __init__(self, width: float = 7, height: float = 5):
        self.fig = Figure(figsize=(width, height), tight_layout=True)
        self.ax = self.fig.add_subplot(111)
        super().__init__(self.fig)


class StackedSpectrumCanvas(FigureCanvas):
    """Eight independent, vertically stacked hydrophone plots."""

    def __init__(self):
        self.fig = Figure(figsize=(8.5, 11.5), constrained_layout=True)
        self.axes = self.fig.subplots(8, 1, sharex=True)
        super().__init__(self.fig)


CHANNEL_COLORS = [
    "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728",
    "#9467bd", "#8c564b", "#e377c2", "#7f7f7f",
]


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("FUS Hydrophone Spectrum Analyzer v0.5")
        self.resize(1680, 980)
        self.setAcceptDrops(True)

        self.study = None
        self.geom = []
        self.xd = None
        self.current = None
        self.dumps = []
        self.dump_items = []
        self._tree_selection_guard = False
        self.frame0_global_max = 1.0

        self.replay_timer = QTimer(self)
        self.replay_timer.timeout.connect(self.replay_step)

        self._build()

    def _build(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)

        top = QHBoxLayout()
        outer.addLayout(top)
        open_file = QPushButton("Open ZIP / File")
        open_folder = QPushButton("Open Folder")
        open_file.clicked.connect(self.choose_file)
        open_folder.clicked.connect(self.choose_folder)
        top.addWidget(open_file)
        top.addWidget(open_folder)

        self.path_label = QLabel(
            "Drop an export ZIP, SpectrumMsg dump, or hierarchical folder here"
        )
        self.path_label.setStyleSheet("padding:10px;border:1px dashed #777;")
        top.addWidget(self.path_label, 1)
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.hide()
        top.addWidget(self.progress)

        main_split = QSplitter(Qt.Horizontal)
        outer.addWidget(main_split, 1)

        # Study navigation panel.
        navigation = QWidget()
        nav_layout = QVBoxLayout(navigation)
        main_split.addWidget(navigation)
        nav_layout.addWidget(QLabel("Export / Sonication structure"))
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Item", "Files"])
        self.tree.itemSelectionChanged.connect(self.select_tree)
        nav_layout.addWidget(self.tree, 3)

        self.info = QTableWidget(0, 2)
        self.info.setHorizontalHeaderLabels(["Item", "Value"])
        self.info.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.info.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        nav_layout.addWidget(self.info, 2)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        nav_layout.addWidget(self.log, 1)

        tabs = QTabWidget()
        main_split.addWidget(tabs)
        main_split.setStretchFactor(0, 0)
        main_split.setStretchFactor(1, 1)
        main_split.setSizes([390, 1290])

        # Main spectrum/replay workspace.
        spectrum_page = QWidget()
        spectrum_layout = QVBoxLayout(spectrum_page)
        tabs.addTab(spectrum_page, "Spectrum / Replay")

        controls = QHBoxLayout()
        spectrum_layout.addLayout(controls)

        controls.addWidget(QLabel("Displayed spectrum"))
        self.frame = QSpinBox()
        self.frame.setRange(0, 0)
        self.frame.setValue(0)
        self.frame.setEnabled(False)
        self.frame.setToolTip(
            "The main Spectrum/Replay view intentionally displays only frame 0 "
            "from each dump. Other internal FFT slots remain available in the "
            "Spectrogram tab for investigation."
        )
        controls.addWidget(QLabel("Frame 0 only"))
        self.frame.hide()

        controls.addWidget(QLabel("Sonication frequency (kHz)"))
        self.center = QDoubleSpinBox()
        self.center.setRange(1, 2000)
        self.center.setDecimals(3)
        self.center.setValue(650)
        self.center.valueChanged.connect(self.redraw_all)
        controls.addWidget(self.center)

        controls.addWidget(QLabel("Axis model"))
        self.axis_mode = QComboBox()
        self.axis_mode.addItems(["Centered on f0 (offset ±span)", "Raw 0-based bins"])
        self.axis_mode.currentIndexChanged.connect(self.redraw_all)
        controls.addWidget(self.axis_mode)

        self.logscale = QCheckBox("dB")
        self.logscale.stateChanged.connect(self.redraw_all)
        controls.addWidget(self.logscale)
        controls.addStretch(1)

        replay_group = QGroupBox("Replay")
        replay_row = QHBoxLayout(replay_group)
        self.previous_button = QPushButton("◀ Previous")
        self.play_button = QPushButton("▶ Play")
        self.next_button = QPushButton("Next ▶")
        self.previous_button.clicked.connect(self.replay_previous)
        self.play_button.clicked.connect(self.toggle_replay)
        self.next_button.clicked.connect(self.replay_step)
        replay_row.addWidget(self.previous_button)
        replay_row.addWidget(self.play_button)
        replay_row.addWidget(self.next_button)
        replay_row.addWidget(QLabel("Interval (ms)"))
        self.replay_interval = QSpinBox()
        self.replay_interval.setRange(50, 10000)
        self.replay_interval.setSingleStep(50)
        self.replay_interval.setValue(250)
        self.replay_interval.valueChanged.connect(self._update_replay_interval)
        replay_row.addWidget(self.replay_interval)
        self.replay_loop = QCheckBox("Loop all")
        self.replay_loop.setChecked(True)
        replay_row.addWidget(self.replay_loop)
        spectrum_layout.addWidget(replay_group)

        replay_status_row = QHBoxLayout()
        spectrum_layout.addLayout(replay_status_row)
        self.replay_status = QLabel("Replay stopped")
        replay_status_row.addWidget(self.replay_status)
        replay_status_row.addStretch(1)

        workspace = QSplitter(Qt.Horizontal)
        spectrum_layout.addWidget(workspace, 1)

        # Left: eight individual spectra arranged vertically.
        left_plot_wrap = QWidget()
        left_plot_layout = QVBoxLayout(left_plot_wrap)
        left_plot_layout.setContentsMargins(0, 0, 0, 0)
        self.stacked_plot = StackedSpectrumCanvas()
        left_plot_layout.addWidget(self.stacked_plot)
        workspace.addWidget(left_plot_wrap)

        # Right: hydrophone image/schematic always visible.
        right_wrap = QWidget()
        right_layout = QVBoxLayout(right_wrap)
        right_header = QHBoxLayout()
        right_layout.addLayout(right_header)
        right_header.addWidget(QLabel("Hydrophone layout"))
        self.layout_mode = QComboBox()
        self.layout_mode.addItems(["Auto (Geometry preferred)", "Default supplied layout"])
        self.layout_mode.currentIndexChanged.connect(self.draw_layout)
        right_header.addWidget(self.layout_mode)
        right_header.addStretch(1)
        self.layout_plot = PlotCanvas(5.5, 7.5)
        right_layout.addWidget(self.layout_plot, 1)
        workspace.addWidget(right_wrap)
        workspace.setSizes([930, 530])

        # Analysis page.
        analysis_page = QWidget()
        analysis_layout = QVBoxLayout(analysis_page)
        tabs.addTab(analysis_page, "Cavitation Analysis")
        self.metrics = QTableWidget(0, 10)
        self.metrics.setHorizontalHeaderLabels(
            [
                "CH",
                "Class",
                "Fund peak",
                "Fund energy",
                "Sub peak",
                "Sub energy",
                "Broad mean",
                "Broad energy",
                "Flatness",
                "Elevated BW kHz",
            ]
        )
        self.metrics.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        analysis_layout.addWidget(self.metrics)
        self.analysis_plot = PlotCanvas()
        analysis_layout.addWidget(self.analysis_plot, 1)

        # Spectrogram page.
        spectrogram_page = QWidget()
        spectrogram_layout = QVBoxLayout(spectrogram_page)
        tabs.addTab(spectrogram_page, "Spectrogram")
        channel_row = QHBoxLayout()
        spectrogram_layout.addLayout(channel_row)
        channel_row.addWidget(QLabel("Channel"))
        self.sg_channel = QComboBox()
        self.sg_channel.currentIndexChanged.connect(self.redraw_spectrogram)
        channel_row.addWidget(self.sg_channel)
        channel_row.addStretch(1)
        self.sg_plot = PlotCanvas()
        spectrogram_layout.addWidget(self.sg_plot, 1)

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event: QDropEvent) -> None:
        if event.mimeData().urls():
            self.load_path(event.mimeData().urls()[0].toLocalFile())

    def choose_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Open export ZIP or dump",
            "",
            "ZIP / dump (*.zip *.dmp *.dump *.gz);;All files (*)",
        )
        if path:
            self.load_path(path)

    def choose_folder(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "Open export or hierarchical folder")
        if path:
            self.load_path(path)

    def load_path(self, path: str) -> None:
        self.stop_replay()
        if self.study:
            self.study.cleanup()
        self.path_label.setText(path)
        self.progress.show()
        self.setEnabled(False)
        self.worker = Worker(path)
        self.worker.done.connect(self.loaded)
        self.worker.failed.connect(self.failed)
        self.worker.start()

    def failed(self, text: str) -> None:
        self.progress.hide()
        self.setEnabled(True)
        QMessageBox.critical(self, "Load failed", text)

    def loaded(self, result: object) -> None:
        self.progress.hide()
        self.setEnabled(True)
        self.study, self.geom, self.xd, raw = result
        self.dumps = [item for item in raw if not isinstance(item, tuple)]
        self.frame0_global_max = self._calculate_frame0_global_max()
        self.dump_items = []
        self.tree.clear()
        self.log.clear()

        study_item = QTreeWidgetItem(
            ["Export Study", "Export mode" if self.study.export_mode else "Generic mode"]
        )
        self.tree.addTopLevelItem(study_item)
        if self.study.cpc_root:
            QTreeWidgetItem(study_item, ["CPCFiles", str(self.study.cpc_root)])
        QTreeWidgetItem(
            study_item,
            [
                "INI files",
                f"Geometry {len(self.study.geometry_files)}, XD {len(self.study.xd_files)}",
            ],
        )

        for sonication in self.study.sonications:
            son_item = QTreeWidgetItem(
                study_item,
                [sonication.name, f"{len(sonication.spectrum_files)} spectrum"],
            )
            for dump in self.dumps:
                if dump.sonication_name == sonication.name:
                    dump_item = QTreeWidgetItem(
                        son_item,
                        [dump.source_file.name, f"{dump.message_count} messages"],
                    )
                    dump_item.setData(0, Qt.UserRole, dump)
                    self.dump_items.append((dump, dump_item))

        if self.study.unassigned_spectrum_files:
            unassigned = QTreeWidgetItem(
                study_item,
                ["Unassigned", str(len(self.study.unassigned_spectrum_files))],
            )
            for dump in self.dumps:
                if dump.sonication_name == "Unassigned":
                    dump_item = QTreeWidgetItem(
                        unassigned,
                        [dump.source_file.name, f"{dump.message_count} messages"],
                    )
                    dump_item.setData(0, Qt.UserRole, dump)
                    self.dump_items.append((dump, dump_item))

        study_item.setExpanded(True)
        self.tree.expandToDepth(1)

        for item in raw:
            if isinstance(item, tuple):
                self.log.append(f"FAILED: {item[0]}\n{item[1]}")
        self.log.append(f"Export mode: {self.study.export_mode}")
        self.log.append(f"Sonications: {len(self.study.sonications)}")
        self.log.append(f"Spectrum dumps: {len(self.study.spectrum_files)}")
        self.log.append(
            f"Geometry: {len(self.study.geometry_files)}; "
            f"XD parameters: {len(self.study.xd_files)}"
        )

        if self.dumps:
            self.current = self.dumps[0]
            self.configure_current()
            self._select_current_tree_item()
        else:
            QMessageBox.warning(self, "No spectrum", "No compatible SpectrumMsg dump was found.")
        self.draw_layout()

    def select_tree(self) -> None:
        if self._tree_selection_guard:
            return
        items = self.tree.selectedItems()
        if items and items[0].data(0, Qt.UserRole):
            self.current = items[0].data(0, Qt.UserRole)
            self.configure_current()

    def configure_current(self) -> None:
        # The primary view uses one representative spectrum per dump: frame 0.
        self.frame.blockSignals(True)
        self.frame.setRange(0, 0)
        self.frame.setValue(0)
        self.frame.blockSignals(False)
        self.sg_channel.clear()
        self.sg_channel.addItems([f"CH{channel.channel}" for channel in self.current.channels])
        if self.xd and self.xd.preferred_frequency_hz:
            self.center.setValue(self.xd.preferred_frequency_hz / 1000)
        self.fill_info()
        self.redraw_all()
        self._update_replay_status()

    def _calculate_frame0_global_max(self) -> float:
        maximum = 0.0
        for dump in self.dumps:
            for channel in dump.channels:
                if len(channel.spectra) > 0 and channel.valid_mask[0]:
                    values = np.abs(channel.spectra[0].astype(float))
                    finite = values[np.isfinite(values)]
                    if finite.size:
                        maximum = max(maximum, float(np.max(finite)))
        return maximum if maximum > 0 else 1.0

    def fill_info(self) -> None:
        dump = self.current
        rows = [
            ("Sonication", dump.sonication_name),
            ("File", str(dump.source_file)),
            ("Messages", dump.message_count),
            ("Hydrophones", dump.channel_count),
            ("FFT bins", dump.channels[0].bin_count),
            ("Valid spectra", [int(channel.valid_mask.sum()) for channel in dump.channels]),
            ("Bin spacing", f"{dump.channels[0].bin_spacing_hz:.3f} Hz"),
            ("Offset span", f"±{dump.channels[0].half_span_hz / 1000:.3f} kHz"),
            ("Displayed frame", "Frame 0 only"),
            ("Frame 0 global Y max", f"{self.frame0_global_max:.6g}"),
            ("Geometry", "Loaded" if self.geom else "Default supplied layout"),
        ]
        if self.xd:
            rows += [
                ("XD serial", self.xd.serial_number or "Unknown"),
                ("XD type", self.xd.xd_type or "Unknown"),
                (
                    "Enabled frequencies",
                    ", ".join(f"{value / 1000:g}" for value in self.xd.enabled_frequencies_hz)
                    + " kHz",
                ),
            ]
        self.info.setRowCount(len(rows))
        for row, (name, value) in enumerate(rows):
            self.info.setItem(row, 0, QTableWidgetItem(str(name)))
            self.info.setItem(row, 1, QTableWidgetItem(str(value)))

    def redraw_all(self) -> None:
        self.redraw_stacked_spectra()
        self.redraw_metrics()
        self.redraw_spectrogram()
        self.draw_layout()
        self._update_replay_status()

    def _frequency_axis(self, channel) -> np.ndarray:
        center_hz = self.center.value() * 1000
        if self.axis_mode.currentIndex() == 1:
            return np.arange(channel.bin_count) * channel.bin_spacing_hz / 1000
        return frequency_axis_hz(channel, center_hz) / 1000

    def redraw_stacked_spectra(self) -> None:
        if not self.current:
            return
        frame_index = self.frame.value()
        center_khz = self.center.value()

        for plot_index, axis in enumerate(self.stacked_plot.axes):
            axis.clear()
            if plot_index >= len(self.current.channels):
                axis.set_visible(False)
                continue
            axis.set_visible(True)
            channel = self.current.channels[plot_index]
            valid = frame_index < len(channel.spectra) and channel.valid_mask[frame_index]
            if valid:
                values = np.abs(channel.spectra[frame_index].astype(float))
                if self.logscale.isChecked():
                    values = 20 * np.log10(np.maximum(values, 1e-12))
                x_values = self._frequency_axis(channel)
                axis.plot(
                    x_values,
                    values,
                    linewidth=1.0,
                    color=CHANNEL_COLORS[channel.channel % len(CHANNEL_COLORS)],
                )

                for frequency, label in (
                    (center_khz / 2, "Subharmonic"),
                    (center_khz, "Fundamental"),
                    (center_khz * 1.5, "Ultraharmonic"),
                ):
                    axis.axvline(frequency, linestyle="--", linewidth=0.8)
                    if plot_index == 0:
                        axis.text(
                            frequency,
                            0.98,
                            label,
                            rotation=90,
                            va="top",
                            ha="right",
                            fontsize=7,
                            transform=axis.get_xaxis_transform(),
                        )
            else:
                axis.text(
                    0.5,
                    0.5,
                    "No valid spectrum",
                    transform=axis.transAxes,
                    ha="center",
                    va="center",
                )

            axis.set_ylabel(f"CH{channel.channel}", rotation=0, labelpad=22)
            if self.logscale.isChecked():
                top_db = 20 * np.log10(max(self.frame0_global_max, 1e-12))
                axis.set_ylim(top_db - 80.0, top_db + 1.0)
            else:
                axis.set_ylim(0.0, self.frame0_global_max * 1.05)
            axis.grid(True, alpha=0.22)
            if plot_index < 7:
                axis.tick_params(labelbottom=False)

        axis_label = (
            "Frequency (kHz) — raw 0-based"
            if self.axis_mode.currentIndex() == 1
            else "Frequency (kHz) — centered on f0"
        )
        self.stacked_plot.axes[-1].set_xlabel(axis_label)
        title = (
            f"{self.current.sonication_name} / {self.current.source_file.name} / "
            "Frame 0"
        )
        self.stacked_plot.fig.suptitle(title, fontsize=11)
        self.stacked_plot.draw_idle()

    def redraw_metrics(self) -> None:
        if not self.current:
            return
        center = self.center.value() * 1000
        frame_index = self.frame.value()
        mode = "zero_based" if self.axis_mode.currentIndex() == 1 else "centered"
        values = [
            analyze_frame(channel, frame_index, center, axis_mode=mode)
            for channel in self.current.channels
        ]
        self.metrics.setRowCount(len(values))
        for row, metric in enumerate(values):
            cells = [
                metric.channel,
                metric.classification,
                metric.fundamental_peak,
                metric.fundamental_energy,
                metric.subharmonic_peak,
                metric.subharmonic_energy,
                metric.broadband_mean,
                metric.broadband_energy,
                metric.spectral_flatness,
                metric.elevated_bandwidth_hz / 1000,
            ]
            for column, value in enumerate(cells):
                text = f"{value:.6g}" if isinstance(value, float) else str(value)
                item = QTableWidgetItem(text)
                color = QColor(CHANNEL_COLORS[metric.channel % len(CHANNEL_COLORS)])
                item.setBackground(QBrush(color.lighter(175)))
                self.metrics.setItem(row, column, item)

        axis = self.analysis_plot.ax
        axis.clear()
        channels = [metric.channel for metric in values]
        for metric in values:
            channel_color = CHANNEL_COLORS[metric.channel % len(CHANNEL_COLORS)]
            axis.scatter(
                [metric.channel], [metric.subharmonic_energy],
                marker="o", color=channel_color,
            )
            axis.scatter(
                [metric.channel], [metric.broadband_energy],
                marker="x", color=channel_color,
            )
        axis.plot([], [], marker="o", linestyle="", label="Subharmonic energy")
        axis.plot([], [], marker="x", linestyle="", label="Broadband energy")
        axis.set_xlabel("Hydrophone channel")
        axis.set_ylabel("Integrated energy")
        axis.grid(True, alpha=0.25)
        axis.legend()
        axis.set_title("Per-hydrophone cavitation signal candidates")
        self.analysis_plot.draw_idle()

    def redraw_spectrogram(self) -> None:
        if not self.current or self.sg_channel.currentIndex() < 0:
            return
        channel = self.current.channels[self.sg_channel.currentIndex()]
        array = np.abs(channel.spectra.astype(float))
        array[~channel.valid_mask, :] = np.nan
        values = 20 * np.log10(np.maximum(array, 1e-12))
        frequency = self._frequency_axis(channel)
        time_values = np.arange(len(array)) * channel.frame_interval_s

        axis = self.sg_plot.ax
        axis.clear()
        axis.imshow(
            values.T,
            origin="lower",
            aspect="auto",
            extent=[
                time_values[0],
                time_values[-1] if len(time_values) > 1 else 0,
                frequency[0],
                frequency[-1],
            ],
        )
        axis.axhline(self.center.value(), linestyle="--", linewidth=1)
        axis.axhline(self.center.value() / 2, linestyle="--", linewidth=1)
        axis.set_xlabel("Time (s)")
        axis.set_ylabel("Frequency (kHz)")
        axis.set_title(f"CH{channel.channel} spectrogram (dB)")
        self.sg_plot.draw_idle()

    def draw_layout(self) -> None:
        axis = self.layout_plot.ax
        axis.clear()
        axis.set_aspect("equal")
        axis.axis("off")

        use_geometry = self.layout_mode.currentIndex() == 0 and bool(self.geom)
        layout = self.geom if use_geometry else default_hydrophone_layout()
        positions = {position.channel: position for position in layout}
        strengths = {}

        if self.current:
            frame_index = 0
            for channel in self.current.channels:
                if frame_index < len(channel.spectra) and channel.valid_mask[frame_index]:
                    strengths[channel.channel] = float(
                        np.nanmax(np.abs(channel.spectra[frame_index]))
                    )
                else:
                    strengths[channel.channel] = 0.0

        maximum = max(strengths.values(), default=1.0) or 1.0
        circle = np.linspace(0, 2 * np.pi, 300)
        axis.plot(0.62 * np.cos(circle), 0.62 * np.sin(circle), linewidth=1)
        axis.plot(0.98 * np.cos(circle), 0.98 * np.sin(circle), linewidth=1)
        axis.text(0, 0, "Cap RCV", ha="center", va="center", fontsize=12)
        axis.text(0, 1.08, "Tile RCV", ha="center", fontsize=12)
        axis.text(-1.2, 0, "Cable\noutlets", ha="center", va="center")

        for channel_number in range(8):
            position = positions.get(channel_number)
            if (
                position
                and position.x is not None
                and position.y is not None
                and abs(float(position.x)) + abs(float(position.y)) > 1e-9
            ):
                scale = max(abs(float(position.x)), abs(float(position.y)), 1.0)
                x_value = float(position.x) / scale * 0.82
                y_value = float(position.y) / scale * 0.82
            elif position and position.angle_deg is not None:
                radius = 0.72 if position.label.lower().startswith("cap") else 1.0
                x_value = radius * np.cos(np.deg2rad(position.angle_deg))
                y_value = radius * np.sin(np.deg2rad(position.angle_deg))
            else:
                x_value, y_value = 0.0, 0.0

            marker_size = 620 + 2500 * (strengths.get(channel_number, 0.0) / maximum)
            axis.scatter(
                [x_value], [y_value], s=marker_size, alpha=0.58,
                color=CHANNEL_COLORS[channel_number % len(CHANNEL_COLORS)],
            )
            label = position.label if position else ""
            axis.text(
                x_value,
                y_value,
                f"CH{channel_number}\n{label}",
                ha="center",
                va="center",
                fontsize=9,
            )

        source = "Geometry INI" if use_geometry else "Default supplied layout"
        frame_text = 0 if self.current else "-"
        axis.set_title(
            f"Hydrophone layout — {source}\n"
            f"Frame {frame_text}: marker size = maximum magnitude; channel colors fixed",
            fontsize=11,
        )
        axis.set_xlim(-1.42, 1.42)
        axis.set_ylim(-1.25, 1.25)
        self.layout_plot.draw_idle()

    # Replay control -------------------------------------------------
    def _update_replay_interval(self) -> None:
        if self.replay_timer.isActive():
            self.replay_timer.setInterval(self.replay_interval.value())

    def toggle_replay(self) -> None:
        if self.replay_timer.isActive():
            self.stop_replay()
        else:
            if not self.current:
                return
            self.replay_timer.start(self.replay_interval.value())
            self.play_button.setText("⏸ Pause")
            self._update_replay_status()

    def stop_replay(self) -> None:
        self.replay_timer.stop()
        if hasattr(self, "play_button"):
            self.play_button.setText("▶ Play")
            self._update_replay_status()

    def replay_step(self) -> None:
        """Advance to frame 0 of the next dump."""
        if not self.current:
            return
        current_index = self._current_dump_index()
        if current_index < 0:
            self.stop_replay()
            return
        next_index = current_index + 1
        if next_index >= len(self.dump_items):
            if self.replay_loop.isChecked() and self.dump_items:
                next_index = 0
            else:
                self.stop_replay()
                return
        self._activate_dump(next_index, 0)

    def replay_previous(self) -> None:
        """Move to frame 0 of the previous dump."""
        if not self.current:
            return
        current_index = self._current_dump_index()
        if current_index < 0:
            return
        previous_index = current_index - 1
        if previous_index < 0:
            if self.replay_loop.isChecked() and self.dump_items:
                previous_index = len(self.dump_items) - 1
            else:
                return
        self._activate_dump(previous_index, 0)

    def _current_dump_index(self) -> int:
        for index, (dump, _) in enumerate(self.dump_items):
            if dump is self.current:
                return index
        return -1

    def _activate_dump(self, index: int, frame: int) -> None:
        if not (0 <= index < len(self.dump_items)):
            return
        self.current = self.dump_items[index][0]
        self.configure_current()
        self.frame.setValue(min(frame, self.frame.maximum()))
        self._select_current_tree_item()

    def _select_current_tree_item(self) -> None:
        for dump, item in self.dump_items:
            if dump is self.current:
                self._tree_selection_guard = True
                self.tree.setCurrentItem(item)
                self.tree.scrollToItem(item)
                self._tree_selection_guard = False
                break

    def _update_replay_status(self) -> None:
        if not hasattr(self, "replay_status"):
            return
        if not self.current:
            self.replay_status.setText("Replay stopped")
            return
        state = "Playing" if self.replay_timer.isActive() else "Stopped"
        dump_index = self._current_dump_index()
        dump_count = len(self.dump_items)
        self.replay_status.setText(
            f"{state}: {self.current.sonication_name} / {self.current.source_file.name} "
            f"— dump {dump_index + 1}/{dump_count}, frame 0"
        )

    def closeEvent(self, event) -> None:
        self.stop_replay()
        if self.study:
            self.study.cleanup()
        super().closeEvent(event)


def main() -> int:
    app = QApplication.instance() or QApplication(sys.argv)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
