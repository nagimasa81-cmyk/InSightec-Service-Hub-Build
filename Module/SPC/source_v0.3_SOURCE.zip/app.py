from __future__ import annotations
import sys, traceback
from pathlib import Path
import numpy as np
from PySide6.QtCore import Qt, Signal, QThread
from PySide6.QtGui import QDragEnterEvent, QDropEvent
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QFileDialog,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,
 QListWidget,QListWidgetItem,QSplitter,QComboBox,QSpinBox,QDoubleSpinBox,QCheckBox,QTableWidget,QTableWidgetItem,
 QHeaderView,QMessageBox,QProgressBar,QTabWidget,QTextEdit,QTreeWidget,QTreeWidgetItem)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from fus_spectrum_core import (discover_input,parse_geometry,parse_xd_parameters,parse_spectrum_dump,
 frequency_axis_hz,default_hydrophone_layout,analyze_frame)

class Worker(QThread):
    done=Signal(object); failed=Signal(str)
    def __init__(self,path): super().__init__(); self.path=path
    def run(self):
        try:
            study=discover_input(self.path)
            geom=parse_geometry(study.geometry_files[0]) if study.geometry_files else []
            xd=parse_xd_parameters(study.xd_files[0]) if study.xd_files else None
            parsed=[]
            son_by_path={p.resolve():s.name for s in study.sonications for p in s.spectrum_files}
            for p in study.spectrum_files:
                try:
                    d=parse_spectrum_dump(p); d.sonication_name=son_by_path.get(p.resolve(),'Unassigned'); parsed.append(d)
                except Exception as e: parsed.append((p,e))
            self.done.emit((study,geom,xd,parsed))
        except Exception: self.failed.emit(traceback.format_exc())

class PlotCanvas(FigureCanvas):
    def __init__(self):
        self.fig=Figure(figsize=(7,5),tight_layout=True); self.ax=self.fig.add_subplot(111); super().__init__(self.fig)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle('FUS Hydrophone Spectrum Analyzer v0.3'); self.resize(1500,920); self.setAcceptDrops(True)
        self.study=None; self.geom=[]; self.xd=None; self.current=None; self.dumps=[]; self._build()
    def _build(self):
        root=QWidget(); self.setCentralWidget(root); outer=QVBoxLayout(root)
        top=QHBoxLayout(); outer.addLayout(top)
        a=QPushButton('Open ZIP / File'); b=QPushButton('Open Folder'); a.clicked.connect(self.choose_file); b.clicked.connect(self.choose_folder)
        top.addWidget(a); top.addWidget(b); self.path_label=QLabel('Drop an export ZIP, SpectrumMsg dump, or hierarchical folder here'); self.path_label.setStyleSheet('padding:10px;border:1px dashed #777;'); top.addWidget(self.path_label,1)
        self.progress=QProgressBar(); self.progress.setRange(0,0); self.progress.hide(); top.addWidget(self.progress)
        split=QSplitter(); outer.addWidget(split,1)
        left=QWidget(); ll=QVBoxLayout(left); split.addWidget(left)
        ll.addWidget(QLabel('Export / Sonication structure')); self.tree=QTreeWidget(); self.tree.setHeaderLabels(['Item','Files']); self.tree.itemSelectionChanged.connect(self.select_tree); ll.addWidget(self.tree,2)
        self.info=QTableWidget(0,2); self.info.setHorizontalHeaderLabels(['Item','Value']); self.info.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeToContents); self.info.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch); ll.addWidget(self.info,2)
        self.log=QTextEdit(); self.log.setReadOnly(True); ll.addWidget(self.log,1)
        tabs=QTabWidget(); split.addWidget(tabs); split.setStretchFactor(1,1)
        # Spectrum
        w=QWidget(); v=QVBoxLayout(w); tabs.addTab(w,'Spectrum')
        row=QHBoxLayout(); v.addLayout(row); row.addWidget(QLabel('Frame')); self.frame=QSpinBox(); self.frame.valueChanged.connect(self.redraw_all); row.addWidget(self.frame)
        row.addWidget(QLabel('Sonication frequency (kHz)')); self.center=QDoubleSpinBox(); self.center.setRange(1,2000); self.center.setDecimals(3); self.center.setValue(650); self.center.valueChanged.connect(self.redraw_all); row.addWidget(self.center)
        row.addWidget(QLabel('Axis model')); self.axis_mode=QComboBox(); self.axis_mode.addItems(['Centered on f0 (offset ±span)','Raw 0-based bins']); self.axis_mode.currentIndexChanged.connect(self.redraw_all); row.addWidget(self.axis_mode)
        self.logscale=QCheckBox('dB'); self.logscale.stateChanged.connect(self.redraw_all); row.addWidget(self.logscale); row.addStretch(1)
        self.channel_checks=[]
        for i in range(8):
            cb=QCheckBox(f'CH{i}'); cb.setChecked(True); cb.stateChanged.connect(self.redraw_all); row.addWidget(cb); self.channel_checks.append(cb)
        self.plot=PlotCanvas(); v.addWidget(self.plot,1)
        # Analysis
        aw=QWidget(); av=QVBoxLayout(aw); tabs.addTab(aw,'Cavitation Analysis')
        self.metrics=QTableWidget(0,10); self.metrics.setHorizontalHeaderLabels(['CH','Class','Fund peak','Fund energy','Sub peak','Sub energy','Broad mean','Broad energy','Flatness','Elevated BW kHz']); self.metrics.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); av.addWidget(self.metrics)
        self.analysis_plot=PlotCanvas(); av.addWidget(self.analysis_plot,1)
        # Spectrogram
        sg=QWidget(); sgl=QVBoxLayout(sg); tabs.addTab(sg,'Spectrogram'); rr=QHBoxLayout(); sgl.addLayout(rr); rr.addWidget(QLabel('Channel')); self.sg_channel=QComboBox(); self.sg_channel.currentIndexChanged.connect(self.redraw_spectrogram); rr.addWidget(self.sg_channel); rr.addStretch(1); self.sg_plot=PlotCanvas(); sgl.addWidget(self.sg_plot,1)
        # Layout
        ly=QWidget(); lyl=QVBoxLayout(ly); tabs.addTab(ly,'XD Hydrophone Layout'); lr=QHBoxLayout(); lyl.addLayout(lr); lr.addWidget(QLabel('Layout')); self.layout_mode=QComboBox(); self.layout_mode.addItems(['Auto (Geometry preferred)','Default photo layout']); self.layout_mode.currentIndexChanged.connect(self.draw_layout); lr.addWidget(self.layout_mode); lr.addStretch(1); self.layout_plot=PlotCanvas(); lyl.addWidget(self.layout_plot,1)
    def dragEnterEvent(self,e:QDragEnterEvent):
        if e.mimeData().hasUrls(): e.acceptProposedAction()
    def dropEvent(self,e:QDropEvent):
        if e.mimeData().urls(): self.load_path(e.mimeData().urls()[0].toLocalFile())
    def choose_file(self):
        p,_=QFileDialog.getOpenFileName(self,'Open export ZIP or dump','','ZIP / dump (*.zip *.dmp *.dump *.gz);;All files (*)');
        if p:self.load_path(p)
    def choose_folder(self):
        p=QFileDialog.getExistingDirectory(self,'Open export or hierarchical folder');
        if p:self.load_path(p)
    def load_path(self,p):
        if self.study:self.study.cleanup()
        self.path_label.setText(p); self.progress.show(); self.setEnabled(False); self.worker=Worker(p); self.worker.done.connect(self.loaded); self.worker.failed.connect(self.failed); self.worker.start()
    def failed(self,t): self.progress.hide(); self.setEnabled(True); QMessageBox.critical(self,'Load failed',t)
    def loaded(self,result):
        self.progress.hide(); self.setEnabled(True); self.study,self.geom,self.xd,raw=result; self.dumps=[x for x in raw if not isinstance(x,tuple)]; self.tree.clear(); self.log.clear()
        study_item=QTreeWidgetItem(['Export Study','Export mode' if self.study.export_mode else 'Generic mode']); self.tree.addTopLevelItem(study_item)
        if self.study.cpc_root: QTreeWidgetItem(study_item,['CPCFiles',str(self.study.cpc_root)])
        ini=QTreeWidgetItem(study_item,['INI files',f'Geometry {len(self.study.geometry_files)}, XD {len(self.study.xd_files)}'])
        for s in self.study.sonications:
            si=QTreeWidgetItem(study_item,[s.name,f'{len(s.spectrum_files)} spectrum']);
            for d in self.dumps:
                if d.sonication_name==s.name:
                    di=QTreeWidgetItem(si,[d.source_file.name,f'{d.message_count} messages']); di.setData(0,Qt.UserRole,d)
        if self.study.unassigned_spectrum_files:
            ui=QTreeWidgetItem(study_item,['Unassigned',str(len(self.study.unassigned_spectrum_files))])
            for d in self.dumps:
                if d.sonication_name=='Unassigned':
                    di=QTreeWidgetItem(ui,[d.source_file.name,f'{d.message_count} messages']); di.setData(0,Qt.UserRole,d)
        study_item.setExpanded(True); self.tree.expandToDepth(1)
        for x in raw:
            if isinstance(x,tuple): self.log.append(f'FAILED: {x[0]}\n{x[1]}')
        self.log.append(f'Export mode: {self.study.export_mode}'); self.log.append(f'Sonications: {len(self.study.sonications)}'); self.log.append(f'Spectrum dumps: {len(self.study.spectrum_files)}'); self.log.append(f'Geometry: {len(self.study.geometry_files)}; XD parameters: {len(self.study.xd_files)}')
        if self.dumps:
            self.current=self.dumps[0]; self.configure_current();
        else: QMessageBox.warning(self,'No spectrum','No compatible SpectrumMsg dump was found.')
        self.draw_layout()
    def select_tree(self):
        items=self.tree.selectedItems();
        if items and items[0].data(0,Qt.UserRole): self.current=items[0].data(0,Qt.UserRole); self.configure_current()
    def configure_current(self):
        maxf=max((len(c.spectra) for c in self.current.channels),default=1)-1; self.frame.setRange(0,maxf); self.frame.setValue(0); self.sg_channel.clear(); self.sg_channel.addItems([f'CH{c.channel}' for c in self.current.channels])
        if self.xd and self.xd.preferred_frequency_hz:self.center.setValue(self.xd.preferred_frequency_hz/1000)
        self.fill_info(); self.redraw_all()
    def fill_info(self):
        d=self.current; rows=[('Sonication',d.sonication_name),('File',str(d.source_file)),('Messages',d.message_count),('Hydrophones',d.channel_count),('FFT bins',d.channels[0].bin_count),('Valid spectra',[int(c.valid_mask.sum()) for c in d.channels]),('Bin spacing',f'{d.channels[0].bin_spacing_hz:.3f} Hz'),('Offset span',f'±{d.channels[0].half_span_hz/1000:.3f} kHz'),('Geometry','Loaded' if self.geom else 'Default photo layout')]
        if self.xd: rows += [('XD serial',self.xd.serial_number or 'Unknown'),('XD type',self.xd.xd_type or 'Unknown'),('Enabled frequencies',', '.join(f'{x/1000:g}' for x in self.xd.enabled_frequencies_hz)+' kHz')]
        self.info.setRowCount(len(rows))
        for r,(a,b) in enumerate(rows): self.info.setItem(r,0,QTableWidgetItem(str(a))); self.info.setItem(r,1,QTableWidgetItem(str(b)))
    def redraw_all(self): self.redraw(); self.redraw_metrics(); self.redraw_spectrogram(); self.draw_layout()
    def redraw(self):
        if not self.current:return
        ax=self.plot.ax; ax.clear(); idx=self.frame.value(); center=self.center.value()*1000; zero_based=self.axis_mode.currentIndex()==1; xcenter=None if zero_based else center
        for c,cb in zip(self.current.channels,self.channel_checks):
            if not cb.isChecked() or idx>=len(c.spectra) or not c.valid_mask[idx]:continue
            y=np.abs(c.spectra[idx].astype(float)); y=20*np.log10(np.maximum(y,1e-12)) if self.logscale.isChecked() else y; x=(np.arange(c.bin_count)*c.bin_spacing_hz if zero_based else frequency_axis_hz(c,xcenter))/1000; ax.plot(x,y,label=f'CH{c.channel}')
        if True:
            for f,label in ((center/2,'Subharmonic f0/2'),(center,'Fundamental f0'),(center*1.5,'Ultraharmonic 1.5f0')):
                ax.axvline(f/1000,linestyle='--',linewidth=1); ax.text(f/1000,ax.get_ylim()[1] if ax.has_data() else 1,label,rotation=90,va='top',ha='right',fontsize=8)
        ax.set_xlabel('Frequency (kHz) — raw 0-based' if zero_based else 'Frequency (kHz) — centered on f0'); ax.set_ylabel('Magnitude (dB)' if self.logscale.isChecked() else 'Magnitude'); ax.grid(True,alpha=.25); ax.set_title(f'{self.current.sonication_name} — frame {idx}');
        if ax.has_data():ax.legend(loc='best',ncol=4)
        self.plot.draw_idle()
    def redraw_metrics(self):
        if not self.current:return
        center=self.center.value()*1000; idx=self.frame.value(); mode='zero_based' if self.axis_mode.currentIndex()==1 else 'centered'; vals=[analyze_frame(c,idx,center,axis_mode=mode) for c in self.current.channels]
        self.metrics.setRowCount(len(vals))
        for r,m in enumerate(vals):
            data=[m.channel,m.classification,m.fundamental_peak,m.fundamental_energy,m.subharmonic_peak,m.subharmonic_energy,m.broadband_mean,m.broadband_energy,m.spectral_flatness,m.elevated_bandwidth_hz/1000]
            for col,v in enumerate(data): self.metrics.setItem(r,col,QTableWidgetItem(f'{v:.6g}' if isinstance(v,float) else str(v)))
        ax=self.analysis_plot.ax; ax.clear(); ch=[m.channel for m in vals]; ax.plot(ch,[m.subharmonic_energy for m in vals],marker='o',label='Subharmonic energy'); ax.plot(ch,[m.broadband_energy for m in vals],marker='o',label='Broadband energy'); ax.set_xlabel('Hydrophone channel'); ax.set_ylabel('Integrated energy'); ax.grid(True,alpha=.25); ax.legend(); ax.set_title('Per-hydrophone cavitation signal candidates'); self.analysis_plot.draw_idle()
    def redraw_spectrogram(self):
        if not self.current or self.sg_channel.currentIndex()<0:return
        c=self.current.channels[self.sg_channel.currentIndex()]; arr=np.abs(c.spectra.astype(float)); arr[~c.valid_mask,:]=np.nan; z=20*np.log10(np.maximum(arr,1e-12)); f=((np.arange(c.bin_count)*c.bin_spacing_hz) if self.axis_mode.currentIndex()==1 else frequency_axis_hz(c,self.center.value()*1000))/1000; t=np.arange(len(arr))*c.frame_interval_s
        ax=self.sg_plot.ax; ax.clear(); ax.imshow(z.T,origin='lower',aspect='auto',extent=[t[0],t[-1] if len(t)>1 else 0,f[0],f[-1]]); ax.axhline(self.center.value(),linestyle='--',linewidth=1); ax.axhline(self.center.value()/2,linestyle='--',linewidth=1); ax.set_xlabel('Time (s)'); ax.set_ylabel('Absolute frequency (kHz)'); ax.set_title(f'CH{c.channel} spectrogram (dB)'); self.sg_plot.draw_idle()
    def draw_layout(self):
        ax=self.layout_plot.ax; ax.clear(); ax.set_aspect('equal'); ax.axis('off'); use_geom=self.layout_mode.currentIndex()==0 and bool(self.geom); positions={p.channel:p for p in (self.geom if use_geom else default_hydrophone_layout())}; strengths={}
        if self.current:
            idx=self.frame.value()
            for c in self.current.channels: strengths[c.channel]=float(np.nanmax(np.abs(c.spectra[idx]))) if idx<len(c.spectra) and c.valid_mask[idx] else 0
        vmax=max(strengths.values(),default=1) or 1
        for ch in range(8):
            p=positions.get(ch);
            if p and p.x is not None and p.y is not None and (abs(float(p.x))+abs(float(p.y))>1e-9):
                scale=max(abs(float(p.x)),abs(float(p.y)),1.0); x,y=float(p.x)/scale*0.82,float(p.y)/scale*0.82
            elif p and p.angle_deg is not None:
                radius=0.72 if p.label.lower().startswith('cap') else 1.0; x=radius*np.cos(np.deg2rad(p.angle_deg)); y=radius*np.sin(np.deg2rad(p.angle_deg))
            else: x,y=0,0
            s=650+2400*(strengths.get(ch,0)/vmax); ax.scatter([x],[y],s=s,alpha=.55); ax.text(x,y,f'CH{ch}\n{p.label if p else ""}',ha='center',va='center',fontsize=9)
        circ=np.linspace(0,2*np.pi,300); ax.plot(.62*np.cos(circ),.62*np.sin(circ),linewidth=1); ax.plot(.98*np.cos(circ),.98*np.sin(circ),linewidth=1); ax.text(0,0,'Cap RCV',ha='center',va='center'); ax.text(0,1.08,'Tile RCV',ha='center'); ax.text(-1.18,0,'Cable\noutlets',ha='center',va='center'); source='Geometry INI' if use_geom else 'Default supplied photo'; ax.set_title(f'Hydrophone layout — {source}\nMarker size = selected-frame maximum magnitude'); ax.set_xlim(-1.4,1.4); ax.set_ylim(-1.25,1.25); self.layout_plot.draw_idle()

def main():
    app=QApplication.instance() or QApplication(sys.argv); w=MainWindow(); w.show(); return app.exec()
if __name__=='__main__': sys.exit(main())
