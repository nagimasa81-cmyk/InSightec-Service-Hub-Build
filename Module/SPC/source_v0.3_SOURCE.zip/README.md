# FUS Hydrophone Spectrum Analyzer v0.3

Input: export ZIP, hierarchical folder, or standalone SpectrumMsg dump.

## Implemented
- Fast export discovery through `CPCFiles`.
- INI priority: `CPCFiles/Site/Ini`, then `CPCFiles/Ini`, then recursive fallback.
- Sonication1...N grouping and ordered display.
- Gzip SpectrumMsg parsing: 8 hydrophones, 256 FFT bins, 24 slots/message.
- XD-specific geometry when available; supplied standard photograph layout as fallback.
- Absolute frequency axis using actual sonication frequency.
- Fundamental f0, subharmonic f0/2 and 1.5f0 markers.
- Narrowband/subharmonic and broadband candidate metrics per hydrophone.
- Spectrogram and spatial hydrophone map.

Candidate labels describe signal patterns and are not medical diagnoses.

## Frequency-axis model
The dump header is internally consistent with 256 bins × ~1.953 kHz. Because a single file does not prove whether those bins are a centered band or a raw 0-based band, the UI provides both models. This avoids silently forcing the subharmonic outside the displayed range. The correct model can be selected after comparison with the system's known 650 kHz peak.
