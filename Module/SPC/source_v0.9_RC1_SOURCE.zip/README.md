# FUS Hydrophone Spectrum Analyzer RC1 v0.9

SPC analyzes hydrophone FFT SpectrumMsg dumps from FUS treatment export ZIP files or hierarchical folders.

## Standard export discovery

```text
Export root/
├─ CPCFiles/
│  └─ Site/Ini/
│     ├─ Xd_<XD serial>.ini
│     └─ XdGeometry_<XD serial>.ini
├─ Sonication1/
│  ├─ SpectrumMsg-1.dmp       # Replay spectrum
│  ├─ *.raw                   # Sonication image RAW
│  └─ Sonication1.act         # Metadata
├─ Sonication2/
└─ SonicationN/
```

Replay uses only `SpectrumMsg*.dmp` located in a numbered Sonication folder. CPCFiles `Spectrum*.dmp`, `_FFT`, and `_txt` files are kept separate for diagnostic analysis.

## RC1 behavior

- ZIP, folder, or dump drag and drop
- Recursive treatment export discovery
- Exact pairing of `Xd_<serial>.ini` and `XdGeometry_<serial>.ini`
- Default hydrophone layout if Geometry is unavailable
- CH0–CH7 individual stacked spectra and hydrophone layout
- Frame 0 only for each SpectrumMsg dump
- One fixed Y-axis based on the maximum Frame-0 magnitude across the whole Study
- Study-wide Replay in `Sonication1 → ... → SonicationN` order
- Fundamental, subharmonic, and broadband candidate analysis
- Image RAW files are inventoried for future synchronized image viewing

## GitHub placement

```text
Module/SPC/source.zip
```

Use Python 3.13 for the standard build workflow.
