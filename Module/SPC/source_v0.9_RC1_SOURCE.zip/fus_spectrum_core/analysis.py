from __future__ import annotations
import numpy as np
from .models import SpectrumChannel, BandMetrics
from .spectrum_parser import frequency_axis_hz
from .calibration import FrequencyPairCalibration, pair_calibrated_frequency_axis_hz, calibrated_frequency_axis_hz

def _band_mask(freq: np.ndarray, center: float, half_width: float) -> np.ndarray:
    return np.abs(freq-center) <= half_width

def _safe_energy(y: np.ndarray, mask: np.ndarray) -> tuple[float,float]:
    vals=np.abs(y[mask])
    if vals.size == 0 or not np.isfinite(vals).any(): return 0.0,0.0
    vals=np.nan_to_num(vals, nan=0.0, posinf=0.0, neginf=0.0)
    return float(vals.max(initial=0.0)), float(np.sum(vals*vals))

def analyze_frame(channel: SpectrumChannel, frame: int, center_hz: float, axis_mode: str='centered', anchor_bin: int | None = None,
                  pair_calibration: FrequencyPairCalibration | None = None,
                  fundamental_half_width_hz: float=15000.0,
                  subharmonic_half_width_hz: float=25000.0,
                  exclusion_half_width_hz: float=20000.0) -> BandMetrics:
    if frame >= len(channel.spectra) or not channel.valid_mask[frame]:
        return BandMetrics(channel.channel, frame, 0,0,0,0,0,0,0,0,'Invalid')
    y=np.abs(channel.spectra[frame].astype(float))
    if axis_mode == 'zero_based':
        f=np.arange(channel.bin_count,dtype=float)*channel.bin_spacing_hz
    elif axis_mode == 'pair' and pair_calibration is not None:
        f=pair_calibrated_frequency_axis_hz(channel, center_hz, pair_calibration)
    elif axis_mode == 'calibrated' and anchor_bin is not None:
        f=calibrated_frequency_axis_hz(channel, center_hz, anchor_bin)
    else:
        f=frequency_axis_hz(channel, center_hz)
    f0=center_hz; sub=f0/2.0
    fmask=_band_mask(f,f0,fundamental_half_width_hz)
    smask=_band_mask(f,sub,subharmonic_half_width_hz)
    fp,fe=_safe_energy(y,fmask); sp,se=_safe_energy(y,smask)
    valid=np.isfinite(y)
    exclude=_band_mask(f,f0,exclusion_half_width_hz)|_band_mask(f,sub,exclusion_half_width_hz)
    for mult in (1.5,2.0): exclude |= _band_mask(f,f0*mult,exclusion_half_width_hz)
    bmask=valid & ~exclude
    b=np.nan_to_num(y[bmask],nan=0.0)
    bmean=float(np.mean(b)) if b.size else 0.0
    benergy=float(np.sum(b*b)) if b.size else 0.0
    positive=b[b>0]
    flat=float(np.exp(np.mean(np.log(positive+1e-30)))/(np.mean(positive)+1e-30)) if positive.size else 0.0
    if b.size:
        med=float(np.median(b)); mad=float(np.median(np.abs(b-med)))+1e-30
        threshold=med+6.0*1.4826*mad
        elevated=int(np.count_nonzero(b>threshold))
    else: elevated=0
    bandwidth=elevated*(pair_calibration.spacing_hz if axis_mode=='pair' and pair_calibration else channel.bin_spacing_hz)
    local_noise=np.median(y[valid]) + 1e-30 if valid.any() else 1e-30
    sub_ratio=sp/local_noise; broad_ratio=bmean/local_noise
    if broad_ratio>4 and flat>0.25 and bandwidth>=8*(pair_calibration.spacing_hz if axis_mode=='pair' and pair_calibration else channel.bin_spacing_hz):
        cls='Broadband cavitation candidate'
    elif sub_ratio>6:
        cls='Subharmonic activity'
    elif fp/local_noise>8:
        cls='Fundamental dominant'
    else:
        cls='No strong candidate'
    return BandMetrics(channel.channel,frame,fp,fe,sp,se,bmean,benergy,flat,bandwidth,cls)
