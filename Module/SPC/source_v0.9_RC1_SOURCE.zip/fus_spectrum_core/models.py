from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
import numpy as np

@dataclass
class SpectrumChannel:
    channel: int
    window_s: float
    bin_spacing_hz: float
    half_span_hz: float
    frame_interval_s: float
    bin_count: int
    spectra: np.ndarray
    metadata: np.ndarray
    valid_mask: np.ndarray

@dataclass
class SpectrumDump:
    source_file: Path
    message_count: int
    channel_count: int
    channels: list[SpectrumChannel]
    footers: np.ndarray
    warnings: list[str] = field(default_factory=list)
    sonication_name: str = "Unassigned"

    @property
    def total_frames(self) -> int:
        return max((c.spectra.shape[0] for c in self.channels), default=0)

@dataclass
class HydrophonePosition:
    channel: int
    label: str
    x: Optional[float] = None
    y: Optional[float] = None
    z: Optional[float] = None
    area_mm2: Optional[float] = None
    clock_text: str = ""
    angle_deg: Optional[float] = None
    source: str = "default"

@dataclass
class XdParameters:
    source_file: Path
    serial_number: str = ""
    xd_type: str = ""
    preferred_frequency_hz: Optional[float] = None
    enabled_frequencies_hz: list[float] = field(default_factory=list)

@dataclass
class SonicationSet:
    name: str
    number: Optional[int]
    root: Path
    spectrum_files: list[Path] = field(default_factory=list)
    image_raw_files: list[Path] = field(default_factory=list)
    metadata_files: list[Path] = field(default_factory=list)
    other_files: list[Path] = field(default_factory=list)

    @property
    def related_files(self) -> list[Path]:
        """Backward-compatible aggregate used by existing integrations."""
        return [*self.image_raw_files, *self.metadata_files, *self.other_files]

@dataclass
class DiscoveredStudy:
    root: Path
    input_path: Path
    export_mode: bool
    cpc_root: Optional[Path]
    ini_roots: list[Path]
    geometry_files: list[Path]
    xd_files: list[Path]
    sonications: list[SonicationSet]
    unassigned_spectrum_files: list[Path]
    other_candidate_files: list[Path]
    cpc_spectrum_files: list[Path] = field(default_factory=list)
    selected_xd_serial: str = ""
    selected_geometry_file: Optional[Path] = None
    selected_xd_file: Optional[Path] = None
    temporary: bool = False

    @property
    def spectrum_files(self) -> list[Path]:
        result: list[Path] = []
        for s in self.sonications:
            result.extend(s.spectrum_files)
        result.extend(self.unassigned_spectrum_files)
        return result

    def cleanup(self) -> None:
        if self.temporary and self.root.exists():
            import shutil
            shutil.rmtree(self.root, ignore_errors=True)

@dataclass
class BandMetrics:
    channel: int
    frame: int
    fundamental_peak: float
    fundamental_energy: float
    subharmonic_peak: float
    subharmonic_energy: float
    broadband_mean: float
    broadband_energy: float
    spectral_flatness: float
    elevated_bandwidth_hz: float
    classification: str
