from __future__ import annotations
from pathlib import Path
import re, tempfile, zipfile
from .models import DiscoveredStudy, SonicationSet

SPECTRUM_EXTENSIONS = ('.dmp', '.dump', '.gz')
SONICATION_RE = re.compile(r'^sonication\s*[_-]?(\d+)$', re.I)
SERIAL_GEOMETRY_RE = re.compile(r'^xdgeometry_(.+)\.ini$', re.I)
SERIAL_XD_RE = re.compile(r'^xd_(.+)\.ini$', re.I)


def _safe_extract(zf: zipfile.ZipFile, destination: Path) -> None:
    base = destination.resolve()
    for info in zf.infolist():
        target = (destination / info.filename).resolve()
        if base not in target.parents and target != base:
            raise ValueError(f"Unsafe ZIP member: {info.filename}")
    zf.extractall(destination)


def _collapse_single_root(root: Path) -> Path:
    children = [p for p in root.iterdir() if p.name != '__MACOSX']
    return children[0] if len(children) == 1 and children[0].is_dir() else root


def _is_replay_spectrum(p: Path) -> bool:
    n = p.name.lower()
    return n.startswith('spectrummsg') and n.endswith(SPECTRUM_EXTENSIONS)


def _is_cpc_spectrum(p: Path) -> bool:
    n = p.name.lower()
    return n.startswith('spectrum') and not n.startswith('spectrummsg') and (
        n.endswith('.dmp') or n.endswith('.dmp_fft') or n.endswith('.dmp_txt')
    )


def _find_cpc_root(root: Path) -> Path | None:
    direct = root / 'CPCFiles'
    if direct.is_dir():
        return direct
    matches = [p for p in root.rglob('*') if p.is_dir() and p.name.lower() == 'cpcfiles']
    return sorted(matches, key=lambda p: (len(p.parts), str(p).lower()))[0] if matches else None


def _ini_roots(cpc: Path | None, root: Path) -> list[Path]:
    candidates: list[Path] = []
    if cpc:
        for rel in [('Site', 'Ini'), ('Ini',), ('App', 'Ini')]:
            p = cpc.joinpath(*rel)
            if p.is_dir():
                candidates.append(p)
    for p in root.rglob('*'):
        if p.is_dir() and p.name.lower() == 'ini' and p not in candidates:
            candidates.append(p)
    return candidates


def _serial_from_geometry(path: Path) -> str:
    match = SERIAL_GEOMETRY_RE.match(path.name)
    return match.group(1) if match else ''


def _serial_from_xd(path: Path) -> str:
    match = SERIAL_XD_RE.match(path.name)
    return match.group(1) if match else ''


def _choose_xd_pair(geometry: list[Path], xd_files: list[Path]) -> tuple[str, Path | None, Path | None]:
    """Select an exact serial-number pair, preferring real numeric serials over templates."""
    geometry_by_serial = {_serial_from_geometry(p).lower(): p for p in geometry}
    xd_by_serial = {_serial_from_xd(p).lower(): p for p in xd_files}
    common = sorted(set(geometry_by_serial) & set(xd_by_serial))
    if not common:
        return '', geometry[0] if geometry else None, xd_files[0] if xd_files else None

    def rank(serial: str) -> tuple[int, int, str]:
        numeric = serial.isdigit()
        nonzero_numeric = numeric and int(serial) != 0
        template = serial.startswith('0000') or 'version' in serial or 'neuro' in serial
        return (0 if nonzero_numeric else 1 if numeric else 2, 1 if template else 0, serial)

    selected = sorted(common, key=rank)[0]
    display_serial = _serial_from_xd(xd_by_serial[selected])
    return display_serial, geometry_by_serial[selected], xd_by_serial[selected]


def discover_input(path: str | Path) -> DiscoveredStudy:
    source = Path(path).expanduser().resolve()
    if not source.exists():
        raise FileNotFoundError(source)
    temporary = False
    if source.is_file() and zipfile.is_zipfile(source):
        extract = Path(tempfile.mkdtemp(prefix='fus_export_'))
        temporary = True
        with zipfile.ZipFile(source) as zf:
            _safe_extract(zf, extract)
        root = _collapse_single_root(extract)
    elif source.is_dir():
        root = source
    elif source.is_file():
        root = source.parent
    else:
        raise ValueError(f'Unsupported input: {source}')

    cpc = _find_cpc_root(root)
    ini_roots = _ini_roots(cpc, root)
    all_files = [p for p in root.rglob('*') if p.is_file()]
    if source.is_file() and not zipfile.is_zipfile(source) and source not in all_files:
        all_files.insert(0, source)

    geometry = sorted(
        {p for r in ini_roots for p in r.rglob('*.ini') if SERIAL_GEOMETRY_RE.match(p.name)},
        key=lambda p: str(p).lower(),
    )
    xd_files = sorted(
        {p for r in ini_roots for p in r.rglob('*.ini') if SERIAL_XD_RE.match(p.name)},
        key=lambda p: str(p).lower(),
    )
    if not geometry:
        geometry = sorted([p for p in all_files if SERIAL_GEOMETRY_RE.match(p.name)], key=lambda p: str(p).lower())
    if not xd_files:
        xd_files = sorted([p for p in all_files if SERIAL_XD_RE.match(p.name)], key=lambda p: str(p).lower())

    selected_serial, selected_geometry, selected_xd = _choose_xd_pair(geometry, xd_files)

    # Replay data is exclusively SpectrumMsg inside SonicationN folders.
    sonications: list[SonicationSet] = []
    candidates = [p for p in root.rglob('*') if p.is_dir() and SONICATION_RE.match(p.name)]
    unique_candidates = {p.resolve(): p for p in candidates}.values()
    for folder in sorted(unique_candidates, key=lambda p: (int(SONICATION_RE.match(p.name).group(1)), str(p).lower())):
        match = SONICATION_RE.match(folder.name)
        files = [f for f in folder.rglob('*') if f.is_file()]
        spectra = sorted([f for f in files if _is_replay_spectrum(f)], key=lambda p: str(p).lower())
        image_raw = sorted([f for f in files if f.suffix.lower() == '.raw'], key=lambda p: str(p).lower())
        metadata = sorted(
            [f for f in files if f.suffix.lower() in {'.act', '.xml', '.ini', '.txt', '.json', '.reply', '.replay'}],
            key=lambda p: str(p).lower(),
        )
        classified = {p.resolve() for p in [*spectra, *image_raw, *metadata]}
        others = sorted([f for f in files if f.resolve() not in classified], key=lambda p: str(p).lower())
        sonications.append(
            SonicationSet(folder.name, int(match.group(1)), folder, spectra, image_raw, metadata, others)
        )

    assigned = {p.resolve() for s in sonications for p in s.spectrum_files}
    unassigned = sorted(
        [p for p in all_files if _is_replay_spectrum(p) and p.resolve() not in assigned],
        key=lambda p: str(p).lower(),
    )
    cpc_spectra = sorted(
        [p for p in all_files if cpc and cpc.resolve() in p.resolve().parents and _is_cpc_spectrum(p)],
        key=lambda p: str(p).lower(),
    )
    others = sorted(
        [p for p in all_files if any(k in p.name.lower() for k in ('treatment', 'vimeasure', 'temperature', 'acquisition', 'replay', 'sonicationsummary'))],
        key=lambda p: str(p).lower(),
    )
    return DiscoveredStudy(
        root=root,
        input_path=source,
        export_mode=cpc is not None,
        cpc_root=cpc,
        ini_roots=ini_roots,
        geometry_files=geometry,
        xd_files=xd_files,
        sonications=sonications,
        unassigned_spectrum_files=unassigned,
        other_candidate_files=others,
        cpc_spectrum_files=cpc_spectra,
        selected_xd_serial=selected_serial,
        selected_geometry_file=selected_geometry,
        selected_xd_file=selected_xd,
        temporary=temporary,
    )
