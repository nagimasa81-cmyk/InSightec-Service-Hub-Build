from __future__ import annotations

from dataclasses import dataclass
import numpy as np

from .models import SpectrumDump, SpectrumChannel


@dataclass(frozen=True)
class FrequencyPairCalibration:
    """Two-point FFT-axis calibration using f0 and f0/2 spectral features."""

    fundamental_bin: int
    subharmonic_bin: int
    spacing_hz: float
    confidence: float
    used_pair: bool


def _aggregate_frame(dump: SpectrumDump, frame: int = 0) -> np.ndarray | None:
    rows: list[np.ndarray] = []
    for ch in dump.channels:
        if frame < len(ch.spectra) and ch.valid_mask[frame]:
            y = np.abs(ch.spectra[frame].astype(float))
            if not np.isfinite(y).any():
                continue
            y = np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)
            scale = float(np.percentile(y, 95)) or float(np.max(y)) or 1.0
            rows.append(y / scale)
    if not rows:
        return None
    # Median suppresses isolated single-hydrophone spikes while retaining common peaks.
    aggregate = np.median(np.vstack(rows), axis=0)
    if aggregate.size >= 5:
        aggregate = np.convolve(aggregate, np.ones(3) / 3.0, mode="same")
    return aggregate


def dominant_peak_bin(dump: SpectrumDump, frame: int = 0) -> int:
    """Return the high-frequency common peak, used as the f0 candidate."""
    aggregate = _aggregate_frame(dump, frame)
    if aggregate is None:
        return 0
    n = len(aggregate)
    # Fundamental is expected in the higher-frequency half; this avoids selecting
    # the strong f0/2 cavitation cluster as the sonication carrier.
    lo = max(1, int(n * 0.55))
    hi = max(lo + 1, n - 2)
    return int(lo + np.argmax(aggregate[lo:hi]))


def detect_frequency_pair(
    dump: SpectrumDump,
    fundamental_hz: float,
    frame: int = 0,
) -> FrequencyPairCalibration:
    """Detect the right-side f0 peak and left-side f0/2 peak cluster.

    The dump header's bin spacing is used only to predict the search region. The
    final axis spacing is solved from the detected f0 and f0/2 bins so both
    landmarks align exactly.
    """
    aggregate = _aggregate_frame(dump, frame)
    channel = dump.channels[0]
    nominal_spacing = float(channel.bin_spacing_hz or 1.0)
    fundamental_bin = dominant_peak_bin(dump, frame)
    if aggregate is None or fundamental_bin <= 0:
        sub_bin = max(0, int(round(fundamental_bin - (fundamental_hz / 2) / nominal_spacing)))
        return FrequencyPairCalibration(fundamental_bin, sub_bin, nominal_spacing, 0.0, False)

    expected_sub = fundamental_bin - (fundamental_hz / 2.0) / nominal_spacing
    # Wide enough to include the observed subharmonic peak cluster while
    # excluding the fundamental region.
    radius = max(10, int(round(35000.0 / nominal_spacing)))
    lo = max(2, int(round(expected_sub)) - radius)
    hi = min(fundamental_bin - 8, int(round(expected_sub)) + radius + 1)

    if hi <= lo:
        sub_bin = max(0, int(round(expected_sub)))
        return FrequencyPairCalibration(fundamental_bin, sub_bin, nominal_spacing, 0.0, False)

    sub_bin = int(lo + np.argmax(aggregate[lo:hi]))
    delta_bins = fundamental_bin - sub_bin
    if delta_bins <= 0:
        return FrequencyPairCalibration(fundamental_bin, sub_bin, nominal_spacing, 0.0, False)

    solved_spacing = (fundamental_hz / 2.0) / delta_bins
    spacing_ratio = solved_spacing / nominal_spacing
    pair_is_plausible = 0.80 <= spacing_ratio <= 1.20

    local = aggregate[max(0, sub_bin - 3): min(len(aggregate), sub_bin + 4)]
    background = aggregate[lo:hi]
    peak = float(np.max(local)) if local.size else 0.0
    median = float(np.median(background)) if background.size else 0.0
    contrast = peak / (median + 1e-12)
    confidence = float(np.clip((contrast - 1.0) / 4.0, 0.0, 1.0))
    if not pair_is_plausible:
        return FrequencyPairCalibration(fundamental_bin, sub_bin, nominal_spacing, confidence * 0.25, False)

    return FrequencyPairCalibration(fundamental_bin, sub_bin, solved_spacing, confidence, True)


def pair_calibrated_frequency_axis_hz(
    channel: SpectrumChannel,
    fundamental_hz: float,
    calibration: FrequencyPairCalibration,
) -> np.ndarray:
    """Map the detected right peak to f0 and left peak to f0/2."""
    return fundamental_hz + (
        np.arange(channel.bin_count, dtype=float) - calibration.fundamental_bin
    ) * calibration.spacing_hz


def calibrated_frequency_axis_hz(
    channel: SpectrumChannel,
    fundamental_hz: float,
    anchor_bin: int,
) -> np.ndarray:
    """Backward-compatible one-point calibration."""
    return fundamental_hz + (
        np.arange(channel.bin_count, dtype=float) - anchor_bin
    ) * channel.bin_spacing_hz


def top_peaks(
    channel: SpectrumChannel,
    frame: int = 0,
    count: int = 5,
    min_separation_bins: int = 3,
) -> list[tuple[int, float]]:
    if frame >= len(channel.spectra) or not channel.valid_mask[frame]:
        return []
    y = np.abs(channel.spectra[frame].astype(float))
    y = np.nan_to_num(y, nan=-np.inf, posinf=-np.inf, neginf=-np.inf)
    work = y.copy()
    result: list[tuple[int, float]] = []
    for _ in range(count):
        idx = int(np.argmax(work))
        if not np.isfinite(work[idx]):
            break
        result.append((idx, float(y[idx])))
        lo = max(0, idx - min_separation_bins)
        hi = min(len(work), idx + min_separation_bins + 1)
        work[lo:hi] = -np.inf
    return result
