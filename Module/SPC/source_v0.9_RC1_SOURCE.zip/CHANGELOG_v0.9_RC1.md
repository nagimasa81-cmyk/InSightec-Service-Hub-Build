# v0.9 RC1

- Correctly discovers all `Sonication1` through `SonicationN` folders in standard treatment export ZIPs.
- Replay accepts only `SonicationN/SpectrumMsg*.dmp` files.
- CPCFiles `Spectrum*.dmp`, `_FFT`, and `_txt` files are classified separately as analysis data and never added to Replay.
- `.raw` files inside Sonication folders are classified as image RAW data, not hydrophone data.
- `.act`, XML, INI, TXT, JSON, reply, and replay files are classified as Sonication metadata.
- Pairs `Xd_<serial>.ini` and `XdGeometry_<serial>.ini` by the exact XD serial number.
- Prefers the real non-zero numeric XD serial over `0000` template files.
- Study tree shows Spectrum, image RAW, and metadata counts for every Sonication.
- Study-wide Replay follows Sonication number order and displays Frame 0 of each SpectrumMsg dump.

## Validation against supplied exports

- `22-55-19_ANx(1).zip`: 5 Sonications, 5 Replay dumps, XD serial 7084, 0 unassigned dumps.
- `09-09-11_ANx(2).zip`: 13 Sonications, 13 Replay dumps, XD serial 7209, 0 unassigned dumps.
