# v0.8 changes

- Fixed normal export discovery so `Sonication1...N` folders located beside `CPCFiles` are assigned instead of appearing under Unassigned.
- Added Study-wide replay across all Sonications and dumps using Frame 0 only.
- Added replay speed selection: 0.25x, 0.5x, 1x, 2x, 5x, and 10x.
- Added repeat modes: No repeat, Current Sonication, and All Sonications.
- Added Study, Sonication, Dump, and Frame position indicators.
- Added Study Summary table and clickable normalized metric timeline.
- Added Sonication summary aggregation for Fundamental, Subharmonic, Broadband, maximum hydrophone, candidate events, and related files.
- Preserved fixed study-wide Frame-0 Y-axis and shared CH0-CH7 colors.
