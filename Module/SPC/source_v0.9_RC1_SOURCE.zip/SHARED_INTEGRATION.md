# Shared FUS Export Discovery Integration

The `fus_spectrum_core` package is UI-independent and can be reused by Log Explorer, Investigation Workspace, Sonication Replay, and Service Hub.

```python
from fus_spectrum_core import discover_input

study = discover_input(export_zip_or_folder)
print(study.selected_xd_serial)
for sonication in study.sonications:
    print(sonication.name)
    print(sonication.spectrum_files)   # Replay: SpectrumMsg only
    print(sonication.image_raw_files)  # Sonication images
    print(sonication.metadata_files)
print(study.cpc_spectrum_files)        # Diagnostic analysis only
```

Important classification rules:

- `SonicationN/SpectrumMsg*.dmp` = Hydrophone Replay
- `SonicationN/*.raw` = Image RAW
- `CPCFiles/Spectrum*.dmp*` = Separate analysis data
- `Xd_<serial>.ini` and `XdGeometry_<serial>.ini` are paired by exact serial
