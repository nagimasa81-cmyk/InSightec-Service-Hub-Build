from __future__ import annotations
import numpy as np
from .models import SpectrumDump, SpectrumChannel


def dominant_peak_bin(dump: SpectrumDump, frame: int = 0) -> int:
    """Return the consensus dominant FFT bin across valid hydrophones."""
    peaks: list[int] = []
    weights: list[float] = []
    for ch in dump.channels:
        if frame < len(ch.spectra) and ch.valid_mask[frame]:
            y = np.abs(ch.spectra[frame].astype(float))
            if np.isfinite(y).any():
                idx = int(np.nanargmax(y))
                peaks.append(idx)
                weights.append(float(np.nanmax(y)))
    if not peaks:
        return 0
    # Weighted median is robust to one noisy hydrophone.
    order = np.argsort(peaks)
    p = np.asarray(peaks)[order]
    w = np.asarray(weights)[order]
    c = np.cumsum(w)
    return int(p[np.searchsorted(c, c[-1] / 2.0)])


def calibrated_frequency_axis_hz(channel: SpectrumChannel, fundamental_hz: float,
                                 anchor_bin: int) -> np.ndarray:
    """Map anchor_bin to the known sonication fundamental frequency."""
    return fundamental_hz + (np.arange(channel.bin_count, dtype=float) - anchor_bin) * channel.bin_spacing_hz


def top_peaks(channel: SpectrumChannel, frame: int = 0, count: int = 5,
              min_separation_bins: int = 3) -> list[tuple[int, float]]:
    if frame >= len(channel.spectra) or not channel.valid_mask[frame]:
        return []
    y = np.abs(channel.spectra[frame].astype(float))
    y = np.nan_to_num(y, nan=-np.inf, posinf=-np.inf, neginf=-np.inf)
    work = y.copy()
    result: list[tuple[int, float]] = []
    for _ in range(count):
        idx = int(np.argmax(work))
        if not np.isfinite(work[idx]):
            break
        result.append((idx, float(y[idx])))
        lo = max(0, idx - min_separation_bins)
        hi = min(len(work), idx + min_separation_bins + 1)
        work[lo:hi] = -np.inf
    return result
