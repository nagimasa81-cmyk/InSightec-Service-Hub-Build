# FUS Hydrophone Spectrum Analyzer v0.8

SPC module for reviewing Frame-0 hydrophone FFT spectra from FUS treatment exports.

## Input
- Standard treatment export ZIP.
- Extracted treatment export folder.
- Any hierarchical folder containing `SpectrumMsg*.dmp` files.
- A standalone SpectrumMsg dump.

## Export discovery
The shared discovery engine searches the complete export root. This is important because the standard structure commonly places these folders as siblings:

```text
ExportRoot/
  CPCFiles/
    Site/Ini/
      Xd_<XD serial>.ini
      XdGeometry_<XD serial>.ini
  Sonication1/
  Sonication2/
  ...
```

`Xd_####.ini` and `XdGeometry_####.ini` are paired by XD serial number. Geometry is preferred when available; otherwise the supplied standard CH0-CH7 Cap/Tile RCV layout is used.

## Main display
- CH0-CH7 are shown as eight independent vertically stacked graphs.
- Only Frame 0 from each SpectrumMsg dump is used in the main replay.
- Every graph uses one fixed Y maximum calculated from Frame 0 across the entire loaded study.
- Channel colors are shared by spectra, analysis tables, and the hydrophone layout.
- The hydrophone layout remains visible at the right during replay.

## Study-wide replay
Replay order is:

```text
Sonication1 / Dump1 / Frame0
Sonication1 / Dump2 / Frame0
...
Sonication2 / Dump1 / Frame0
...
```

Controls include Previous, Play/Pause, Next, 0.25x-10x speed, and repeat modes for no repeat, current Sonication, or all Sonications. The tree, Study/Sonication/Dump counters, spectra, hydrophone markers, analysis, diagnostics, and timeline follow the replay position.

## Study Summary
The Study Summary tab provides one row per Sonication and a clickable replay timeline containing normalized Fundamental, Subharmonic, and Broadband metrics. Double-clicking a Sonication row or clicking the timeline jumps to that replay position.

## Frequency interpretation
The default mode uses a two-point pair calibration:
- Higher-frequency common peak = Fundamental `f0`.
- Lower-frequency peak cluster = Subharmonic `f0/2`.

Centered and raw-bin modes remain available for comparison. Pattern labels are analytical candidates, not medical diagnoses.

## Shared components
Reusable logic is under `fus_spectrum_core/`:
- export and folder discovery
- SpectrumMsg parsing
- XD parameter and geometry parsing
- frequency-pair calibration
- Fundamental/Subharmonic/Broadband metrics

Place this ZIP as:

```text
Module/SPC/source.zip
```
