# Shared integration

Reusable package: `fus_spectrum_core`.

```python
from fus_spectrum_core import discover_input, parse_spectrum_dump, parse_geometry, analyze_frame
study = discover_input(path)
for sonication in study.sonications:
    for dump_file in sonication.spectrum_files:
        dump = parse_spectrum_dump(dump_file)
        metrics = analyze_frame(dump.channels[0], frame=0, center_hz=650000)
```

Discovery supports ordinary export structure, alternative INI locations, standalone folders and ZIPs. Missing geometry/XD files do not prevent spectrum parsing.
