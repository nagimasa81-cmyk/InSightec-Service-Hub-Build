DO Analysis Qt - GitHub Build Source
Version: 2026.10.09.15

Main features
- Drag and drop WaterSystem files, folders, or ZIP archives.
- ZIP contents are searched recursively and only matching WaterSystem files are loaded.
- Import / Settings can be folded to maximize the chart area.
- Change the displayed file from the Chart tab with the combo box or previous/next buttons.
- Long-term Trend mode treats each WaterSystem file as one measurement date.
- Event DO Change defaults to Median; Mean/Median/Min/Max/P25/P75 representatives are selectable.
- Min-Max whiskers and P25-P75 spread show within-file variability without re-parsing files.

Build
1. Extract this source ZIP in the GitHub module folder.
2. Run build_exe.bat locally, or let the GitHub workflow detect do_analysis_qt_app.py/version.json.
3. Output: dist/DO Analysis Qt.exe

Fallback
- build_pyinstaller_fallback.bat
- build_debug.bat


2026.10.09.19
- Long-term Trend now also shows a per-file correlation scatter of Minimum DO Level vs Maximum Vacuum.
- Correlation scatter uses the current Scope / State / Trim settings and supports drag-zoom and double-click reset.


2026.10.16.20
- Long-term Trend adds Event DO Decrease Rate (ppm/min), derived from the dominant time-ordered DO decline within each event and summarized per file.
