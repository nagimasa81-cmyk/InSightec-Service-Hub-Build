# -*- coding: utf-8 -*-
"""
DO Analysis Qt Windows App
Python 3.13 / PySide6 / Nuitka friendly
No pandas, no matplotlib, no QtCharts.
"""
from __future__ import annotations

import bisect
import csv
import json
import math
import os
import re
import statistics
import sys
import shutil
import tempfile
import zipfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple, Dict, Any

from PySide6.QtCore import Qt, QRectF, QPointF, QThread, Signal, QTimer
from PySide6.QtGui import QAction, QPainter, QPen, QColor, QFont, QBrush
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QPushButton, QFileDialog, QLabel, QTableWidget, QTableWidgetItem,
    QTabWidget, QTextEdit, QLineEdit, QCheckBox, QDoubleSpinBox, QSpinBox,
    QMessageBox, QProgressBar, QSplitter, QGroupBox, QComboBox, QToolTip
)

RELEASE_MODE = os.environ.get("INSIGHTEC_RELEASE_MODE", "0").strip().lower() in {"1", "true", "yes", "on"}

from common_guide import GuideConfig, GuideManager, GuidePage

APP_NAME = "DO Analysis Qt"
APP_VERSION = "2026.10.22.22"

MIN_VALID_DO = 0.0
MAX_VALID_DO = 10.0
MIN_EVENT_DURATION_MIN = 3.0
EVENT_MERGE_GAP_MIN = 3.0
MIN_DO_CHANGE_FOR_VACUUM = 0.7
DO_AVG_BAND = 0.2
VACUUM_FLAT_TOLERANCE = 0.10
SECONDARY_FLOW_VALID_MIN = 2.0
SECONDARY_FLOW_VALID_MAX = 6.5
SECONDARY_FLOW_PLOT_MIN = 0.0
SECONDARY_FLOW_PLOT_MAX = 6.5

STATE_DEGAS = "DEGAS"
STATE_TREAT = "TREAT"
STATE_CLEAN_TANK = "CLEAN_TANK"
STATE_CLEAN_XD = "CLEAN_XD"

HEADER_RE = re.compile(r"MainState\s+CoolingState\s+Error", re.IGNORECASE)
TIME_RE = re.compile(r"^(\d{1,2}):(\d{2}):(\d{2}):(\d{1,3})")


def normalize_header(text: str) -> str:
    return re.sub(r"[^a-z0-9]", "", text.strip().lower())


def is_valid_do(v: float) -> bool:
    return MIN_VALID_DO <= v <= MAX_VALID_DO


def classify_state(state: str) -> Optional[str]:
    s = state.strip().upper()
    if "DEGAS" in s and "CIRCULATE" in s:
        return STATE_DEGAS
    if "TREAT" in s and "CIRCULATE" in s:
        return STATE_TREAT
    if "CLEAN" in s and "TANK" in s and "CIRCULATE" in s:
        return STATE_CLEAN_TANK
    if "CLEAN" in s and "XD" in s and "CIRCULATE" in s:
        return STATE_CLEAN_XD
    return None


def parse_time_minutes(text: str) -> Optional[float]:
    m = TIME_RE.match(text.strip())
    if not m:
        return None
    h, mi, sec, ms = [int(x) for x in m.groups()]
    return h * 60.0 + mi + sec / 60.0 + ms / 60000.0


def parse_measurement_datetime(file_path: str) -> Tuple[datetime, str]:
    """Return acquisition datetime, preferring the native WaterSystem filename timestamp."""
    name = Path(file_path).name
    months = {
        "Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4, "May": 5, "Jun": 6,
        "Jul": 7, "Aug": 8, "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12,
    }
    m = re.search(
        r"_(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)_(\d{1,2})_(\d{1,2})_(\d{1,2})_(\d{1,2})_(\d{4})(?:\D|$)",
        name, re.IGNORECASE,
    )
    if m:
        mon_txt, day, hour, minute, second, year = m.groups()
        mon = months[mon_txt[:1].upper() + mon_txt[1:3].lower()]
        return datetime(int(year), mon, int(day), int(hour), int(minute), int(second)), "filename"
    # Numeric YYYY_MM_DD[_HH_MM_SS] fallback for transformed exports.
    m = re.search(r"(20\d{2})[_-](\d{1,2})[_-](\d{1,2})(?:[_-](\d{1,2})[_-](\d{1,2})[_-](\d{1,2}))?", name)
    if m:
        year, mon, day, hour, minute, second = m.groups()
        return datetime(int(year), int(mon), int(day), int(hour or 0), int(minute or 0), int(second or 0)), "filename"
    return datetime.fromtimestamp(Path(file_path).stat().st_mtime), "file modified time"


@dataclass
class Sample:
    time_text: str
    time_min: float
    state: str
    do: Optional[float]
    vacuum: Optional[float]
    second_flow: Optional[float]
    primary_flow: Optional[float]
    chiller_temp: Optional[float]
    absolute_pressure: Optional[float]
    dynamic_pressure: Optional[float]
    xd_temperature: Optional[float]
    pressure_set_point: Optional[float]
    water_volume: Optional[float]
    calculated_water_volume: Optional[float] = None


@dataclass
class EventResult:
    file_name: str
    event_type: str
    event_no: int
    start_time: str
    end_time: str
    duration_min: float
    max_do: Optional[float]
    min_do: Optional[float]
    do_change: Optional[float]
    high_do_vac: Optional[float]
    low_do_vac: Optional[float]
    vac_diff: Optional[float]
    vacuum_trend: str
    second_flow_avg: Optional[float]
    note: str = ""
    source_path: str = ""  # Internal identity; display/CSV remain file-name based.
    do_decrease_rate: Optional[float] = None  # Largest sustained peak-to-trough DO decline, ppm/min.


@dataclass
class FileSummary:
    file_path: str
    file_name: str
    sample_count: int
    event_count: int
    up_count: int
    flat_count: int
    down_count: int
    na_count: int


class WaterSystemParser:
    def parse_file(self, file_path: str, should_stop=None, progress_cb=None) -> Tuple[List[Sample], Dict[str, int]]:
        """Parse once, streaming the file instead of materializing text + splitlines copies.

        should_stop/progress_cb are optional so existing callers keep the same contract.
        """
        path = Path(file_path)
        total_bytes = max(1, path.stat().st_size)
        with path.open("r", encoding="utf-8", errors="replace") as fh:
            header_line = None
            for line in fh:
                if should_stop is not None and should_stop():
                    raise InterruptedError("Parsing cancelled")
                if HEADER_RE.search(line):
                    header_line = line
                    break
            if header_line is None:
                raise ValueError("Header line was not found. Expected WaterSystem log format.")

            # WaterSystem logs are fixed-width records.  Derive the native column
            # boundaries from the header instead of using whitespace split() for
            # data rows.  split() collapses an empty field and can shift every
            # later value (notably WaterVolume/SecondaryFlowMeter) one column.
            header_matches = list(re.finditer(r"\S+", header_line.rstrip("\r\n")))
            if len(header_matches) < 2:
                raise ValueError("WaterSystem header does not contain usable columns.")
            column_starts = [m.start() for m in header_matches]
            raw_headers = [m.group(0) for m in header_matches]
            headers = [normalize_header(x) for x in raw_headers[1:]]
            idx_map = {h: i for i, h in enumerate(headers)}
            required = ["mainstate", "vacuumlevel", "dolevel"]
            for key in required:
                if key not in idx_map:
                    raise ValueError(f"Required column not found: {key}")

            samples: List[Sample] = []
            prev_t: Optional[float] = None
            day_offset = 0.0
            last_report = -1
            for line_no, line in enumerate(fh, start=1):
                if line_no % 1024 == 0:
                    if should_stop is not None and should_stop():
                        raise InterruptedError("Parsing cancelled")
                    if progress_cb is not None:
                        try:
                            pct = min(99, int(fh.buffer.tell() / total_bytes * 100))
                        except (OSError, ValueError):
                            pct = min(99, line_no // 1000)
                        if pct != last_report:
                            progress_cb(pct)
                            last_report = pct
                if not line.strip():
                    continue
                raw_line = line.rstrip("\r\n")

                # Primary path: preserve empty fixed-width fields by slicing at
                # the exact starts observed in the header.  This keeps every
                # sensor bound to its real source column.
                fields: List[str] = []
                for col_i, start in enumerate(column_starts):
                    end = column_starts[col_i + 1] if col_i + 1 < len(column_starts) else len(raw_line)
                    fields.append(raw_line[start:end].strip())

                # Some historical/export-transformed files may not retain fixed
                # padding.  Only in that case fall back to token parsing, and
                # only when the token count is exactly the expected schema so a
                # missing field can never silently shift later columns.
                time_text = fields[0] if fields else ""
                values = fields[1:]
                raw_t = parse_time_minutes(time_text)
                fixed_width_present = len(raw_line) >= column_starts[-1]
                if raw_t is None or len(values) != len(headers) or not fixed_width_present:
                    tokens = raw_line.split()
                    if len(tokens) != len(headers) + 1:
                        continue
                    time_text = tokens[0]
                    values = tokens[1:]
                    raw_t = parse_time_minutes(time_text)
                    if raw_t is None:
                        continue

                t = raw_t + day_offset
                if prev_t is not None and t < prev_t - 720.0:
                    day_offset += 1440.0
                    t = raw_t + day_offset
                prev_t = t
                def get_str(key: str) -> str:
                    i = idx_map.get(key, -1)
                    return values[i] if 0 <= i < len(values) else ""
                def get_float(key: str) -> Optional[float]:
                    v = get_str(key)
                    try:
                        return float(v)
                    except Exception:
                        return None
                samples.append(Sample(
                    time_text=time_text,
                    time_min=t,
                    state=get_str("mainstate"),
                    do=get_float("dolevel"),
                    vacuum=get_float("vacuumlevel"),
                    second_flow=get_float("secondaryflowmeter") if "secondaryflowmeter" in idx_map else None,
                    primary_flow=get_float("primaryflowmeter") if "primaryflowmeter" in idx_map else None,
                    chiller_temp=get_float("chillertemp") if "chillertemp" in idx_map else None,
                    absolute_pressure=get_float("absolutepressure") if "absolutepressure" in idx_map else None,
                    dynamic_pressure=get_float("dynamicpressure") if "dynamicpressure" in idx_map else None,
                    xd_temperature=get_float("xdtemperature") if "xdtemperature" in idx_map else None,
                    pressure_set_point=get_float("pressuresetpoint") if "pressuresetpoint" in idx_map else None,
                    water_volume=get_float("watervolume") if "watervolume" in idx_map else None,
                ))

        # Calculated Water Volume is intentionally separate from the native
        # WaterVolume field. It estimates water PRESENT IN THE SYSTEM rather than
        # total throughput. SecondaryFlowMeter is treated as L/min and the sign
        # comes from MainState:
        #   FILL  -> + flow (water enters the system)
        #   DRAIN -> - flow (water leaves the system)
        #   all other states, including *_CIRCULATE -> 0 net volume change
        # This prevents circulation flow from being incorrectly accumulated as
        # additional water volume. The signed endpoint flows are integrated over
        # real sample timestamps with the trapezoidal rule so state transitions
        # are handled smoothly. Invalid samples / large gaps hold the last value.
        # Physical system volume is clamped at zero; a drain cannot create a
        # negative amount of water.
        def volume_flow_direction(state: str) -> float:
            normalized = (state or "").strip().upper()
            if "DRAIN" in normalized:
                return -1.0
            if "FILL" in normalized:
                return 1.0
            return 0.0

        valid_dts = [
            samples[i].time_min - samples[i-1].time_min
            for i in range(1, len(samples))
            if 0 < samples[i].time_min - samples[i-1].time_min <= 1.0
        ]
        median_dt = statistics.median(valid_dts) if valid_dts else 0.01
        max_integrable_gap = max(0.1, median_dt * 10.0)  # minutes; minimum 6 s guard
        cumulative_l = 0.0
        if samples:
            samples[0].calculated_water_volume = 0.0
        for i in range(1, len(samples)):
            prev = samples[i-1]
            cur = samples[i]
            dt_min = cur.time_min - prev.time_min
            f0, f1 = prev.second_flow, cur.second_flow
            if (
                0.0 < dt_min <= max_integrable_gap
                and f0 is not None and f1 is not None
                and math.isfinite(f0) and math.isfinite(f1)
                and SECONDARY_FLOW_PLOT_MIN <= f0 <= SECONDARY_FLOW_PLOT_MAX
                and SECONDARY_FLOW_PLOT_MIN <= f1 <= SECONDARY_FLOW_PLOT_MAX
            ):
                signed_f0 = f0 * volume_flow_direction(prev.state)
                signed_f1 = f1 * volume_flow_direction(cur.state)
                cumulative_l = max(0.0, cumulative_l + 0.5 * (signed_f0 + signed_f1) * dt_min)
            cur.calculated_water_volume = cumulative_l
        if progress_cb is not None:
            progress_cb(100)
        return samples, idx_map


class DOAnalyzer:
    def __init__(self, min_do_change: float = MIN_DO_CHANGE_FOR_VACUUM,
                 do_band: float = DO_AVG_BAND,
                 flat_tol: float = VACUUM_FLAT_TOLERANCE):
        self.min_do_change = min_do_change
        self.do_band = do_band
        self.flat_tol = flat_tol

    def analyze_file(self, file_path: str, samples: List[Sample]) -> Tuple[List[EventResult], FileSummary]:
        file_name = Path(file_path).name
        events = self._detect_events(samples)
        results: List[EventResult] = []
        counters = {STATE_DEGAS: 0, STATE_TREAT: 0, STATE_CLEAN_TANK: 0, STATE_CLEAN_XD: 0}
        for s_idx, e_idx, etype in events:
            block = samples[s_idx:e_idx + 1]
            duration = block[-1].time_min - block[0].time_min
            if duration < MIN_EVENT_DURATION_MIN:
                continue
            counters[etype] += 1
            results.append(self._analyze_event(file_path, file_name, etype, counters[etype], block))
        up = sum(1 for r in results if r.vacuum_trend == "UP")
        down = sum(1 for r in results if r.vacuum_trend == "DOWN")
        flat = sum(1 for r in results if r.vacuum_trend == "FLAT")
        na = sum(1 for r in results if r.vacuum_trend.startswith("N/A"))
        summary = FileSummary(file_path, file_name, len(samples), len(results), up, flat, down, na)
        return results, summary

    def _detect_events(self, samples: List[Sample]) -> List[Tuple[int, int, str]]:
        raw: List[Tuple[int, int, str]] = []
        in_event = False
        cur_start = 0
        cur_type = ""
        for i, smp in enumerate(samples):
            target = None
            if smp.do is not None and is_valid_do(smp.do):
                target = classify_state(smp.state)
            if target:
                if not in_event:
                    in_event = True
                    cur_start = i
                    cur_type = target
                elif target != cur_type:
                    raw.append((cur_start, i - 1, cur_type))
                    cur_start = i
                    cur_type = target
            else:
                if in_event:
                    raw.append((cur_start, i - 1, cur_type))
                    in_event = False
        if in_event:
            raw.append((cur_start, len(samples) - 1, cur_type))

        if not raw:
            return []
        merged = [raw[0]]
        for s, e, typ in raw[1:]:
            ps, pe, ptyp = merged[-1]
            gap = samples[s].time_min - samples[pe].time_min
            if typ == ptyp and gap <= EVENT_MERGE_GAP_MIN:
                merged[-1] = (ps, e, ptyp)
            else:
                merged.append((s, e, typ))
        return merged

    def _do_decrease_rate(self, block: List[Sample]) -> Optional[float]:
        """Return the event's dominant DO decrease speed in ppm/min.

        Find the largest time-ordered peak-to-trough DO drawdown, then regress
        DO against real elapsed minutes across that full decline segment. This
        avoids treating a later recovery/second peak as part of the decline and
        is more stable than simply dividing global max-min by event duration.
        Events without a meaningful downward excursion are returned as N/A.
        """
        vals = [(s.time_min, float(s.do)) for s in block
                if s.do is not None and is_valid_do(float(s.do)) and math.isfinite(float(s.do))]
        if len(vals) < 3:
            return None
        max_so_far = vals[0][1]
        max_index = 0
        best_drop = 0.0
        best_pair: Optional[Tuple[int, int]] = None
        for j in range(1, len(vals)):
            do_now = vals[j][1]
            drop = max_so_far - do_now
            if drop > best_drop:
                best_drop = drop
                best_pair = (max_index, j)
            if do_now > max_so_far:
                max_so_far = do_now
                max_index = j
        # Reuse the existing clinically/operationally meaningful DO-change gate.
        if best_pair is None or best_drop < self.min_do_change:
            return None
        a, b = best_pair
        segment = vals[a:b + 1]
        if len(segment) < 3:
            return None
        t0 = segment[0][0]
        xs = [tm - t0 for tm, _ in segment]
        ys = [do for _, do in segment]
        # Require at least 3 seconds so a one-sample spike cannot become a rate.
        if xs[-1] < 0.05:
            return None
        xm = statistics.fmean(xs)
        ym = statistics.fmean(ys)
        denom = sum((x - xm) ** 2 for x in xs)
        if denom <= 0:
            return None
        slope = sum((x - xm) * (y - ym) for x, y in zip(xs, ys)) / denom
        if not math.isfinite(slope) or slope >= 0:
            return None
        return -slope

    def _analyze_event(self, file_path: str, file_name: str, etype: str, event_no: int, block: List[Sample]) -> EventResult:
        do_vals = [s.do for s in block if s.do is not None and is_valid_do(s.do)]
        max_do = max(do_vals) if do_vals else None
        min_do = min(do_vals) if do_vals else None
        do_change = (max_do - min_do) if max_do is not None and min_do is not None else None
        high_vac = low_vac = diff = None
        trend = "N/A"
        note = ""
        if etype in (STATE_CLEAN_TANK, STATE_CLEAN_XD):
            trend = "N/A Clean"
            note = "Clean event: vacuum trend is not judged."
        elif do_change is None:
            trend = "N/A No DO"
        elif do_change < self.min_do_change:
            trend = "N/A DO Change"
            note = f"DO change {do_change:.2f} ppm < {self.min_do_change:.2f} ppm"
        else:
            high_vacs = [s.vacuum for s in block if s.do is not None and s.vacuum is not None and s.do >= max_do - self.do_band]
            low_vacs = [s.vacuum for s in block if s.do is not None and s.vacuum is not None and s.do <= min_do + self.do_band]
            if not high_vacs or not low_vacs:
                trend = "N/A No Vacuum"
            else:
                high_vac = statistics.fmean(high_vacs)
                low_vac = statistics.fmean(low_vacs)
                diff = low_vac - high_vac
                if diff > self.flat_tol:
                    trend = "UP"
                elif diff < -self.flat_tol:
                    trend = "DOWN"
                else:
                    trend = "FLAT"
        sf_vals = [s.second_flow for s in block if s.second_flow is not None and SECONDARY_FLOW_VALID_MIN <= s.second_flow <= SECONDARY_FLOW_VALID_MAX]
        sf_avg = statistics.fmean(sf_vals) if sf_vals else None
        do_decrease_rate = self._do_decrease_rate(block)
        return EventResult(
            file_name=file_name, event_type=etype, event_no=event_no,
            start_time=block[0].time_text, end_time=block[-1].time_text,
            duration_min=max(0.0, block[-1].time_min - block[0].time_min),
            max_do=max_do, min_do=min_do, do_change=do_change,
            high_do_vac=high_vac, low_do_vac=low_vac, vac_diff=diff,
            vacuum_trend=trend, second_flow_avg=sf_avg, note=note, source_path=str(Path(file_path).resolve()),
            do_decrease_rate=do_decrease_rate
        )


class ImportWorker(QThread):
    progress = Signal(int, str)
    completed = Signal(list, list, list)
    failed = Signal(str)
    cancelled = Signal()

    def __init__(self, paths: List[str]):
        super().__init__()
        self.paths = list(paths)
        self._temp_roots: List[str] = []

    @staticmethod
    def _looks_like_file(path: Path) -> bool:
        if not path.is_file() or path.suffix.lower() not in {".txt", ".log", ".csv"}:
            return False
        try:
            with path.open("r", encoding="utf-8", errors="replace") as fh:
                for _ in range(250):
                    line = fh.readline()
                    if not line:
                        break
                    if HEADER_RE.search(line):
                        normalized = normalize_header(line)
                        return "mainstate" in normalized and "vacuumlevel" in normalized and "dolevel" in normalized
        except (OSError, UnicodeError):
            return False
        return False

    @staticmethod
    def _zip_entry_looks_like(zf: zipfile.ZipFile, info: zipfile.ZipInfo) -> bool:
        if Path(info.filename).suffix.lower() not in {".txt", ".log", ".csv"}:
            return False
        try:
            with zf.open(info, "r") as raw:
                for _ in range(250):
                    line = raw.readline()
                    if not line:
                        break
                    text = line.decode("utf-8", errors="replace")
                    if HEADER_RE.search(text):
                        normalized = normalize_header(text)
                        return "mainstate" in normalized and "vacuumlevel" in normalized and "dolevel" in normalized
        except (OSError, RuntimeError, zipfile.BadZipFile):
            return False
        return False

    def _discover_folder(self, root: Path) -> List[str]:
        found: List[str] = []
        seen = set()
        candidates = iter([root]) if root.is_file() else root.rglob("*")
        checked = 0
        for candidate in candidates:
            if self.isInterruptionRequested():
                raise InterruptedError
            if candidate.suffix.lower() not in {".txt", ".log", ".csv"}:
                continue
            checked += 1
            if checked % 200 == 0:
                self.progress.emit(-1, f"Scanning folder... {checked} candidate files")
            if self._looks_like_file(candidate):
                resolved = str(candidate.resolve())
                if resolved not in seen:
                    seen.add(resolved)
                    found.append(resolved)
        return sorted(found, key=lambda x: os.path.getmtime(x), reverse=True)

    def _extract_zip(self, zip_path: Path) -> List[str]:
        temp_root = Path(tempfile.mkdtemp(prefix="DO_Analysis_ZIP_"))
        self._temp_roots.append(str(temp_root))
        found: List[str] = []
        with zipfile.ZipFile(zip_path, "r") as zf:
            infos = [i for i in zf.infolist() if not i.is_dir() and Path(i.filename).suffix.lower() in {".txt", ".log", ".csv"}]
            total = max(1, len(infos))
            base = temp_root.resolve()
            for n, info in enumerate(infos, start=1):
                if self.isInterruptionRequested():
                    raise InterruptedError
                if n == 1 or n % 25 == 0:
                    self.progress.emit(int((n - 1) / total * 100), f"Inspecting {zip_path.name}: {n}/{total}")
                if not self._zip_entry_looks_like(zf, info):
                    continue
                target = (temp_root / info.filename).resolve()
                if base != target.parent and base not in target.parents:
                    raise ValueError(f"Unsafe ZIP entry was blocked: {info.filename}")
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info, "r") as src, target.open("wb") as dst:
                    shutil.copyfileobj(src, dst, length=1024 * 1024)
                found.append(str(target))
        return found

    def _cleanup_owned_temp(self) -> None:
        for root in self._temp_roots:
            shutil.rmtree(root, ignore_errors=True)
        self._temp_roots.clear()

    def run(self) -> None:
        discovered: List[str] = []
        messages: List[str] = []
        try:
            total = max(1, len(self.paths))
            for idx, raw in enumerate(self.paths, start=1):
                if self.isInterruptionRequested():
                    raise InterruptedError
                path = Path(raw)
                self.progress.emit(int((idx - 1) / total * 100), f"Discovering {path.name}")
                try:
                    if path.is_file() and path.suffix.lower() == ".zip":
                        items = self._extract_zip(path)
                        discovered.extend(items)
                        messages.append(f"ZIP: {path.name} -> {len(items)} matching file(s)")
                    elif path.is_dir():
                        items = self._discover_folder(path)
                        discovered.extend(items)
                        messages.append(f"Folder: {path.name} -> {len(items)} matching file(s)")
                    elif self._looks_like_file(path):
                        discovered.append(str(path.resolve()))
                    else:
                        messages.append(f"Skipped unsupported file: {path.name}")
                except (OSError, zipfile.BadZipFile, ValueError) as exc:
                    messages.append(f"Failed: {path.name}: {exc}")
            if self.isInterruptionRequested():
                raise InterruptedError
            unique = list(dict.fromkeys(discovered))
            self.progress.emit(100, "Discovery completed")
            roots = list(self._temp_roots)
            self._temp_roots.clear()  # Ownership transfers to MainWindow.
            self.completed.emit(unique, messages, roots)
        except InterruptedError:
            self._cleanup_owned_temp()
            self.cancelled.emit()
        except Exception as exc:
            self._cleanup_owned_temp()
            self.failed.emit(str(exc))


class AnalyzeWorker(QThread):
    progress = Signal(int, str)
    finished = Signal(list, list, dict, str)
    failed = Signal(str)
    cancelled = Signal()
    def __init__(self, files: List[str], min_do_change: float, do_band: float, flat_tol: float):
        super().__init__()
        self.files = list(files)
        self.min_do_change = min_do_change
        self.do_band = do_band
        self.flat_tol = flat_tol

    def run(self) -> None:
        try:
            parser = WaterSystemParser()
            analyzer = DOAnalyzer(self.min_do_change, self.do_band, self.flat_tol)
            all_results: List[EventResult] = []
            summaries: List[FileSummary] = []
            sample_cache: Dict[str, List[Sample]] = {}
            errors = []
            total = max(1, len(self.files))
            for idx, f in enumerate(self.files):
                if self.isInterruptionRequested():
                    self.cancelled.emit()
                    return
                base_pct = idx / total * 100.0
                span_pct = 1.0 / total * 100.0
                self.progress.emit(int(base_pct), f"Parsing {Path(f).name}")
                try:
                    def report_file(pct: int, base=base_pct, span=span_pct, name=Path(f).name):
                        overall = int(base + span * max(0, min(100, pct)) / 100.0)
                        self.progress.emit(min(99, overall), f"Parsing {name}: {pct}%")
                    samples, _ = parser.parse_file(
                        f,
                        should_stop=self.isInterruptionRequested,
                        progress_cb=report_file,
                    )
                    if self.isInterruptionRequested():
                        self.cancelled.emit()
                        return
                    sample_cache[str(Path(f).resolve())] = samples
                    self.progress.emit(min(99, int(base_pct + span_pct * 0.9)), f"Analyzing {Path(f).name}")
                    results, summary = analyzer.analyze_file(f, samples)
                    all_results.extend(results)
                    summaries.append(summary)
                except InterruptedError:
                    self.cancelled.emit()
                    return
                except Exception as exc:
                    errors.append(f"{Path(f).name}: {exc}")
            self.progress.emit(100, "Completed")
            self.finished.emit(all_results, summaries, sample_cache, "\n".join(errors))
        except Exception as exc:
            self.failed.emit(str(exc))


class ChartWidget(QWidget):
    zoomSelected = Signal(float, float)
    rangeSelected = Signal(float, float)

    """Native Qt chart with file title, hover crosshair and value readout.

    This intentionally avoids matplotlib/QtCharts so the application remains
    Nuitka/Python 3.13 friendly.  The chart supports the practical functions
    needed for log review: DO/Vacuum/2nd Flow overlay, hover value inspection,
    file switching from the Chart tab, and event start/end markers.
    """
    def __init__(self) -> None:
        super().__init__()
        self.samples: List[Sample] = []
        self._times: List[float] = []
        self._non_event_blocks_cache: List[Tuple[float, float, str]] = []
        self.events: List[EventResult] = []
        self.file_name: str = ""
        self.show_do = True
        self.show_vac = True
        self.show_sf = True
        self.show_primary_flow = False
        self.show_chiller_temp = False
        self.show_xd_temperature = False
        self.show_absolute_pressure = False
        self.show_dynamic_pressure = False
        self.show_pressure_setpoint_band = False
        self.show_water_volume = False
        self.show_calculated_water_volume = False
        self.show_event_markers = True
        self.show_non_event_labels = False
        self.show_value_popup = True
        self.range_analysis_enabled = False
        self.range_parameter = "DO Level"
        self.range_selection: Optional[Tuple[float, float]] = None
        self.range_result: Optional[Dict[str, Any]] = None
        self.show_range_overlay = True
        self.x_min_override: Optional[float] = None
        self.x_max_override: Optional[float] = None
        self._mouse_pos: Optional[QPointF] = None
        self._drag_start: Optional[QPointF] = None
        self._drag_current: Optional[QPointF] = None
        self._is_dragging = False
        self._plot_rect = QRectF()
        self.setMouseTracking(True)
        self.setMinimumHeight(360)

    def set_samples(self, samples: List[Sample], file_name: str = "", events: Optional[List[EventResult]] = None) -> None:
        self.samples = samples
        self._times = [s.time_min for s in samples]
        self.file_name = file_name
        self.events = events or []
        self._non_event_blocks_cache = self._build_non_event_blocks()
        self.x_min_override = None
        self.x_max_override = None
        self.range_selection = None
        self.range_result = None
        self.update()

    def set_range_analysis(self, enabled: bool, parameter: str, show_overlay: bool = True) -> None:
        self.range_analysis_enabled = enabled
        self.range_parameter = parameter
        self.show_range_overlay = show_overlay
        if not enabled:
            self._is_dragging = False
            self._drag_start = None
            self._drag_current = None
        self.update()

    def set_range_result(self, start: float, end: float, result: Dict[str, Any]) -> None:
        self.range_selection = (start, end)
        self.range_result = dict(result)
        self.update()

    def clear_range_analysis(self) -> None:
        self.range_selection = None
        self.range_result = None
        self.update()

    def set_zoom_range(self, xmin: Optional[float], xmax: Optional[float]) -> None:
        if xmin is None or xmax is None or xmax <= xmin:
            self.x_min_override = None
            self.x_max_override = None
        else:
            self.x_min_override = xmin
            self.x_max_override = xmax
        self.update()

    def reset_zoom(self) -> None:
        self.x_min_override = None
        self.x_max_override = None
        self.update()


    def _plot_x_to_time(self, px: float) -> Optional[float]:
        if not self.samples or self._plot_rect.width() <= 0:
            return None
        xmin, xmax = self._time_range()
        x = max(self._plot_rect.left(), min(px, self._plot_rect.right()))
        return xmin + (x - self._plot_rect.left()) / self._plot_rect.width() * (xmax - xmin)

    def mousePressEvent(self, event) -> None:  # type: ignore[override]
        pos = QPointF(event.position())
        if event.button() == Qt.LeftButton and self._plot_rect.contains(pos) and self.samples:
            self._drag_start = pos
            self._drag_current = pos
            self._is_dragging = True
            self._mouse_pos = pos
            self.update()
            return
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # type: ignore[override]
        pos = QPointF(event.position())
        if event.button() == Qt.LeftButton and self._is_dragging and self._drag_start is not None:
            t1 = self._plot_x_to_time(self._drag_start.x())
            t2 = self._plot_x_to_time(pos.x())
            self._is_dragging = False
            self._drag_current = None
            start = self._drag_start
            self._drag_start = None
            if t1 is not None and t2 is not None and abs(pos.x() - start.x()) >= 8:
                xmin, xmax = (t1, t2) if t1 <= t2 else (t2, t1)
                if self.range_analysis_enabled:
                    self.rangeSelected.emit(xmin, xmax)
                else:
                    self.set_zoom_range(xmin, xmax)
                    self.zoomSelected.emit(xmin, xmax)
            self.update()
            return
        super().mouseReleaseEvent(event)

    def leaveEvent(self, event) -> None:  # type: ignore[override]
        self._mouse_pos = None
        self.update()

    def mouseMoveEvent(self, event) -> None:  # type: ignore[override]
        pos = QPointF(event.position())
        self._mouse_pos = pos
        if self._is_dragging:
            # Keep the drag end inside the plot horizontally so the selected range is clear.
            x = max(self._plot_rect.left(), min(pos.x(), self._plot_rect.right())) if self._plot_rect.width() > 0 else pos.x()
            y = max(self._plot_rect.top(), min(pos.y(), self._plot_rect.bottom())) if self._plot_rect.height() > 0 else pos.y()
            self._drag_current = QPointF(x, y)
        self.update()

    def _time_range(self) -> Tuple[float, float]:
        if not self._times:
            return 0.0, 1.0
        data_min, data_max = self._times[0], self._times[-1]
        xmin = self.x_min_override if self.x_min_override is not None else data_min
        xmax = self.x_max_override if self.x_max_override is not None else data_max
        xmin = max(data_min, xmin)
        xmax = min(data_max, xmax)
        if xmax <= xmin:
            xmin, xmax = data_min, data_max
        if xmax <= xmin:
            xmax = xmin + 1.0
        return xmin, xmax

    def _visible_samples(self, xmin: float, xmax: float) -> List[Sample]:
        if not self._times:
            return []
        left = bisect.bisect_left(self._times, xmin)
        right = bisect.bisect_right(self._times, xmax)
        return self.samples[left:right]

    def _primary_range(self) -> Tuple[float, float]:
        xmin, xmax = self._time_range()
        visible = self._visible_samples(xmin, xmax)
        do_vals = [s.do for s in visible if s.do is not None and is_valid_do(s.do)] if self.show_do else []
        sf_vals = [s.second_flow for s in visible if s.second_flow is not None and SECONDARY_FLOW_PLOT_MIN <= s.second_flow <= SECONDARY_FLOW_PLOT_MAX] if self.show_sf else []
        pf_vals = [s.primary_flow for s in visible if s.primary_flow is not None] if self.show_primary_flow else []
        ct_vals = [s.chiller_temp for s in visible if s.chiller_temp is not None] if self.show_chiller_temp else []
        xdt_vals = [s.xd_temperature for s in visible if s.xd_temperature is not None] if self.show_xd_temperature else []
        ap_vals = [s.absolute_pressure for s in visible if s.absolute_pressure is not None] if self.show_absolute_pressure else []
        dp_vals = [s.dynamic_pressure for s in visible if s.dynamic_pressure is not None] if self.show_dynamic_pressure else []
        sp_vals = []
        if self.show_pressure_setpoint_band:
            for s in visible:
                if s.pressure_set_point is not None and math.isfinite(float(s.pressure_set_point)):
                    sp = float(s.pressure_set_point)
                    sp_vals.extend((sp - 5.0, sp, sp + 5.0))
        wv_vals = [s.water_volume for s in visible if s.water_volume is not None] if self.show_water_volume else []
        cwv_vals = [s.calculated_water_volume for s in visible if s.calculated_water_volume is not None] if self.show_calculated_water_volume else []
        values = do_vals + sf_vals + pf_vals + ct_vals + xdt_vals + ap_vals + dp_vals + sp_vals + wv_vals + cwv_vals
        if not values:
            return 0.0, 10.0
        ymin, ymax = min(values), max(values)
        if ymax <= ymin:
            return ymin - 1.0, ymax + 1.0
        pad = max(0.2, (ymax - ymin) * 0.12)
        return ymin - pad, ymax + pad

    def _vacuum_range(self) -> Tuple[float, float]:
        xmin, xmax = self._time_range()
        vac_vals = [s.vacuum for s in self._visible_samples(xmin, xmax) if s.vacuum is not None]
        if not vac_vals:
            return 85.0, 100.0
        vmin, vmax = min(vac_vals), max(vac_vals)
        pad = max(1.0, (vmax - vmin) * 0.08)
        return vmin - pad, vmax + pad

    def _format_minutes_as_time(self, minutes: float) -> str:
        total_ms = int(round((minutes % 1440.0) * 60000.0))
        h = total_ms // 3600000
        rem = total_ms % 3600000
        m = rem // 60000
        rem %= 60000
        sec = rem // 1000
        ms = rem % 1000
        return f"{h:02d}:{m:02d}:{sec:02d}.{ms:03d}"

    def _map_x(self, x: float, plot: QRectF, xmin: float, xmax: float) -> float:
        return plot.left() + (x - xmin) / (xmax - xmin) * plot.width()

    def _map_y(self, y: float, plot: QRectF, ymin: float, ymax: float) -> float:
        return plot.bottom() - (y - ymin) / (ymax - ymin) * plot.height()

    def _nearest_sample(self, t: float) -> Optional[Sample]:
        if not self._times:
            return None
        idx = bisect.bisect_left(self._times, t)
        if idx <= 0:
            return self.samples[0]
        if idx >= len(self._times):
            return self.samples[-1]
        before = idx - 1
        return self.samples[before] if abs(self._times[before] - t) <= abs(self._times[idx] - t) else self.samples[idx]

    def _draw_line_series(self, p: QPainter, plot: QRectF, values: List[Tuple[float, float]],
                          xmin: float, xmax: float, ymin: float, ymax: float,
                          color: QColor, width: float = 1.4, style=Qt.SolidLine) -> None:
        if len(values) < 2 or ymax <= ymin or xmax <= xmin:
            return
        p.setPen(QPen(color, width, style))
        # Decimate by pixel column for speed while preserving shape.
        max_points = max(400, int(plot.width() * 2))
        step = max(1, len(values) // max_points)
        last: Optional[QPointF] = None
        for x, y in values[::step]:
            px = self._map_x(x, plot, xmin, xmax)
            py = self._map_y(y, plot, ymin, ymax)
            pt = QPointF(px, py)
            if last is not None:
                p.drawLine(last, pt)
            last = pt

    def _draw_pressure_setpoint_series(self, p: QPainter, plot: QRectF, samples: List[Sample],
                                       xmin: float, xmax: float, ymin: float, ymax: float) -> None:
        """Draw PressureSetPoint and ±5 without bridging missing/invalid sections."""
        segments: List[List[Tuple[float, float]]] = []
        current: List[Tuple[float, float]] = []
        for smp in samples:
            value = smp.pressure_set_point
            if value is None:
                if current:
                    segments.append(current); current = []
                continue
            try:
                fv = float(value)
            except (TypeError, ValueError):
                if current:
                    segments.append(current); current = []
                continue
            if not math.isfinite(fv):
                if current:
                    segments.append(current); current = []
                continue
            current.append((smp.time_min, fv))
        if current:
            segments.append(current)
        for seg in segments:
            if len(seg) < 2:
                continue
            self._draw_line_series(p, plot, seg, xmin, xmax, ymin, ymax, QColor(35, 35, 35), 1.5, Qt.DashLine)
            self._draw_line_series(p, plot, [(x, y + 5.0) for x, y in seg], xmin, xmax, ymin, ymax, QColor(220, 70, 70), 1.2, Qt.DotLine)
            self._draw_line_series(p, plot, [(x, y - 5.0) for x, y in seg], xmin, xmax, ymin, ymax, QColor(220, 70, 70), 1.2, Qt.DotLine)

    def _draw_axes(self, p: QPainter, plot: QRectF, xmin: float, xmax: float,
                   pymin: float, pymax: float, vymin: float, vymax: float) -> None:
        p.setPen(QPen(QColor(215, 215, 215), 1))
        p.drawRect(plot)
        font = QFont(); font.setPointSize(8); p.setFont(font)
        # Horizontal grid and primary labels
        for i in range(6):
            y = plot.top() + plot.height() * i / 5
            p.setPen(QPen(QColor(235, 235, 235), 1))
            p.drawLine(QPointF(plot.left(), y), QPointF(plot.right(), y))
            pv = pymax - (pymax - pymin) * i / 5
            vv = vymax - (vymax - vymin) * i / 5
            p.setPen(QColor(80, 80, 80))
            p.drawText(4, int(y + 4), f"{pv:.1f}")
            p.drawText(int(plot.right() + 8), int(y + 4), f"{vv:.1f}")
        # Vertical grid and time labels
        for i in range(6):
            x = plot.left() + plot.width() * i / 5
            p.setPen(QPen(QColor(240, 240, 240), 1))
            p.drawLine(QPointF(x, plot.top()), QPointF(x, plot.bottom()))
            tv = xmin + (xmax - xmin) * i / 5
            p.setPen(QColor(80, 80, 80))
            p.drawText(int(x - 34), int(plot.bottom() + 18), self._format_minutes_as_time(tv))
        p.setPen(QColor(50, 50, 50))
        p.drawText(4, int(plot.top() - 8), "Primary axis")
        p.drawText(int(plot.right() - 84), int(plot.top() - 8), "Vacuum axis")

    def _short_non_event_label(self, state: str) -> str:
        s = state.strip().upper()
        if not s:
            return "NO STATE"
        if "ERROR" in s:
            return "ERROR"
        if "DEGAS" in s and "PAUSE" in s:
            return "DEGAS PAUSE"
        if "TREAT" in s and "PAUSE" in s:
            return "TREATMENT PAUSE"
        if "INITIAL" in s:
            return "INIT"
        if "WAIT" in s:
            return "WAIT"
        if "DRAIN" in s:
            return "DRAIN"
        if "FILL" in s:
            return "FILL"
        if "CLEAN" in s and "PAUSE" in s:
            return "CLEAN PAUSE"
        compact = re.sub(r"[_\s]+", " ", s).strip()
        return compact[:18]

    def _build_non_event_blocks(self) -> List[Tuple[float, float, str]]:
        if not self.samples:
            return []
        # Event ranges are fixed for a loaded data set, so build the gap labels once.
        time_by_text: Dict[str, float] = {s.time_text: s.time_min for s in self.samples}
        event_ranges: List[Tuple[float, float]] = []
        for ev in self.events:
            st = time_by_text.get(ev.start_time)
            en = time_by_text.get(ev.end_time)
            if st is not None and en is not None:
                event_ranges.append((min(st, en), max(st, en)))
        event_ranges.sort()
        blocks: List[Tuple[float, float, str]] = []
        cur_start: Optional[float] = None
        cur_end: Optional[float] = None
        cur_label = ""
        range_idx = 0
        for smp in self.samples:
            t = smp.time_min
            while range_idx < len(event_ranges) and event_ranges[range_idx][1] < t:
                range_idx += 1
            inside_event = range_idx < len(event_ranges) and event_ranges[range_idx][0] <= t <= event_ranges[range_idx][1]
            state_upper = smp.state.strip().upper()
            is_pause_state = "PAUSE" in state_upper and ("TREAT" in state_upper or "DEGAS" in state_upper)
            is_event_state = classify_state(smp.state) is not None and smp.do is not None and is_valid_do(smp.do)
            is_non_event = is_pause_state or ((not is_event_state) and (not inside_event))
            if is_non_event:
                label = self._short_non_event_label(smp.state)
                if cur_start is None:
                    cur_start = t; cur_end = t; cur_label = label
                elif label == cur_label and t - (cur_end if cur_end is not None else t) <= EVENT_MERGE_GAP_MIN:
                    cur_end = t
                else:
                    blocks.append((cur_start, cur_end if cur_end is not None else cur_start, cur_label))
                    cur_start = t; cur_end = t; cur_label = label
            elif cur_start is not None:
                blocks.append((cur_start, cur_end if cur_end is not None else cur_start, cur_label))
                cur_start = None; cur_end = None; cur_label = ""
        if cur_start is not None:
            blocks.append((cur_start, cur_end if cur_end is not None else cur_start, cur_label))
        return blocks

    def _draw_non_event_labels(self, p: QPainter, plot: QRectF, xmin: float, xmax: float) -> None:
        if not self.show_non_event_labels or not self.samples:
            return
        blocks = self._non_event_blocks_cache

        p.setFont(QFont("Arial", 7))
        base_colors = {
            "ERROR": QColor(220, 60, 60),
            "DEGAS PAUSE": QColor(230, 150, 70),
            "TREATMENT PAUSE": QColor(70, 170, 100),
            "INIT": QColor(140, 140, 140),
            "WAIT": QColor(120, 120, 180),
            "DRAIN": QColor(90, 140, 210),
            "FILL": QColor(80, 160, 200),
            "CLEAN PAUSE": QColor(150, 110, 190),
        }
        row = 0
        for st, en, label in blocks:
            x1 = self._map_x(max(st, xmin), plot, xmin, xmax)
            x2 = self._map_x(min(en, xmax), plot, xmin, xmax)
            width = max(1.0, x2 - x1)
            # Suppress tiny labels, but keep long non-event shaded areas visible.
            if width < 14:
                continue
            color = base_colors.get(label, QColor(150, 150, 150))
            fill = QColor(color); fill.setAlpha(12)
            p.fillRect(QRectF(x1, plot.top(), width, plot.height()), fill)
            p.setPen(QPen(color, 1, Qt.DotLine))
            p.drawLine(QPointF(x1, plot.top()), QPointF(x1, plot.bottom()))
            if width >= 48:
                y = int(plot.bottom() - 8 - (row % 3) * 13)
                row += 1
                max_chars = max(4, int(width / 6))
                txt = label if len(label) <= max_chars else label[:max_chars - 1] + "…"
                bg = QColor(255, 255, 255); bg.setAlpha(205)
                text_w = min(width - 4, max(28, 6 * len(txt) + 8))
                bx = max(plot.left() + 1, min(x1 + 3, plot.right() - text_w - 2))
                p.setPen(QPen(color, 1))
                p.setBrush(QBrush(bg))
                p.drawRoundedRect(QRectF(bx, y - 10, text_w, 12), 3, 3)
                p.drawText(int(bx + 4), y, txt)

    def _draw_event_markers(self, p: QPainter, plot: QRectF, xmin: float, xmax: float, pymin: float, pymax: float) -> None:
        if not self.show_event_markers or not self.events:
            return
        type_color = {
            STATE_DEGAS: QColor(237, 125, 49),
            STATE_TREAT: QColor(0, 150, 70),
            STATE_CLEAN_TANK: QColor(120, 70, 170),
            STATE_CLEAN_XD: QColor(0, 150, 200),
        }
        # Build time lookup by exact text.  This avoids changing EventResult dataclass.
        time_by_text: Dict[str, float] = {s.time_text: s.time_min for s in self.samples}
        p.setFont(QFont("Arial", 8))
        used_label_y = 0
        for ev in self.events:
            st = time_by_text.get(ev.start_time)
            en = time_by_text.get(ev.end_time)
            if st is None or en is None:
                continue
            x1 = self._map_x(st, plot, xmin, xmax)
            x2 = self._map_x(en, plot, xmin, xmax)
            color = type_color.get(ev.event_type, QColor(120, 120, 120))
            fill = QColor(color); fill.setAlpha(22)
            p.fillRect(QRectF(x1, plot.top(), max(1.0, x2 - x1), plot.height()), fill)
            p.setPen(QPen(color, 1, Qt.DashLine))
            p.drawLine(QPointF(x1, plot.top()), QPointF(x1, plot.bottom()))
            p.drawLine(QPointF(x2, plot.top()), QPointF(x2, plot.bottom()))
            prefix = {STATE_DEGAS: "D", STATE_TREAT: "T", STATE_CLEAN_TANK: "CT", STATE_CLEAN_XD: "CX"}.get(ev.event_type, ev.event_type[:2])
            label = f"{prefix}{ev.event_no}"
            if ev.vacuum_trend in ("UP", "DOWN", "FLAT"):
                label += f" {ev.vacuum_trend}"
            # Put labels in a reserved band above the plot so they do not cover curves.
            y = int(plot.top() - 24 + (used_label_y % 2) * 12)
            used_label_y += 1
            label_w = max(34, 7 * len(label) + 8)
            bx = max(plot.left() + 1, min(x1 + 3, plot.right() - label_w - 2))
            bg = QColor(255, 255, 255); bg.setAlpha(210)
            p.setPen(QPen(color, 1))
            p.setBrush(QBrush(bg))
            p.drawRoundedRect(QRectF(bx, y - 10, label_w, 12), 3, 3)
            p.setPen(color)
            p.drawText(int(bx + 4), y, label)

    def _draw_hover(self, p: QPainter, plot: QRectF, xmin: float, xmax: float,
                    pymin: float, pymax: float, vymin: float, vymax: float) -> None:
        if not self.show_value_popup or self._mouse_pos is None or not plot.contains(self._mouse_pos):
            return
        t = xmin + (self._mouse_pos.x() - plot.left()) / plot.width() * (xmax - xmin)
        smp = self._nearest_sample(t)
        if smp is None:
            return
        x = self._map_x(smp.time_min, plot, xmin, xmax)
        p.setPen(QPen(QColor(80, 80, 80), 1, Qt.DashLine))
        p.drawLine(QPointF(x, plot.top()), QPointF(x, plot.bottom()))
        lines = [f"Time: {smp.time_text}", f"State: {smp.state}"]
        # Keep popup semantics identical to the plotted DO series.  Raw WaterSystem
        # logs can contain sentinel/corrupt/non-finite DO values; the chart deliberately
        # excludes those with is_valid_do(), so never expose them only in the hover popup.
        if smp.do is not None and is_valid_do(smp.do):
            lines.append(f"DO: {smp.do:.3f} ppm")
        elif smp.do is not None:
            lines.append("DO: N/A")
        if smp.vacuum is not None: lines.append(f"Vacuum: {smp.vacuum:.3f}")
        if smp.second_flow is not None: lines.append(f"2nd Flow: {smp.second_flow:.3f}")
        if smp.primary_flow is not None: lines.append(f"Primary Flow: {smp.primary_flow:.3f}")
        if smp.chiller_temp is not None: lines.append(f"Chiller Temp: {smp.chiller_temp:.3f}")
        if smp.xd_temperature is not None: lines.append(f"XD Temperature: {smp.xd_temperature:.3f} °C")
        if smp.absolute_pressure is not None: lines.append(f"Absolute Pressure: {smp.absolute_pressure:.3f}")
        if smp.dynamic_pressure is not None: lines.append(f"Dynamic Pressure: {smp.dynamic_pressure:.3f}")
        if self.show_pressure_setpoint_band and smp.pressure_set_point is not None:
            sp = float(smp.pressure_set_point)
            if math.isfinite(sp):
                lines.append(f"Pressure SetPoint: {sp:.3f}")
                lines.append(f"SetPoint ±5: {sp-5.0:.3f} / {sp+5.0:.3f}")
        if smp.water_volume is not None: lines.append(f"WaterVolume (raw): {smp.water_volume:.3f}")
        if smp.calculated_water_volume is not None: lines.append(f"Calculated Water Volume: {smp.calculated_water_volume:.3f} L")
        box_w, line_h = 230, 17
        box_h = 10 + line_h * len(lines)
        bx = x + 12
        if bx + box_w > plot.right():
            bx = x - box_w - 12
        by = plot.top() + 8
        p.setPen(QPen(QColor(160, 160, 160), 1))
        p.setBrush(QBrush(QColor(255, 255, 245)))
        p.drawRoundedRect(QRectF(bx, by, box_w, box_h), 5, 5)
        p.setPen(QColor(40, 40, 40))
        for i, line in enumerate(lines):
            p.drawText(int(bx + 8), int(by + 18 + i * line_h), line)
        # Highlight actual points on visible series.
        if self.show_do and smp.do is not None and is_valid_do(smp.do):
            p.setBrush(QBrush(QColor(0, 80, 180)))
            p.setPen(Qt.NoPen)
            p.drawEllipse(QPointF(x, self._map_y(smp.do, plot, pymin, pymax)), 4, 4)
        if self.show_sf and smp.second_flow is not None and SECONDARY_FLOW_PLOT_MIN <= smp.second_flow <= SECONDARY_FLOW_PLOT_MAX:
            p.setBrush(QBrush(QColor(0, 140, 80)))
            p.setPen(Qt.NoPen)
            p.drawEllipse(QPointF(x, self._map_y(smp.second_flow, plot, pymin, pymax)), 4, 4)
        extra_points = [
            (self.show_primary_flow, smp.primary_flow, QColor(112, 48, 160)),
            (self.show_chiller_temp, smp.chiller_temp, QColor(0, 160, 160)),
            (self.show_xd_temperature, smp.xd_temperature, QColor(200, 80, 40)),
            (self.show_absolute_pressure, smp.absolute_pressure, QColor(220, 150, 0)),
            (self.show_dynamic_pressure, smp.dynamic_pressure, QColor(120, 120, 120)),
            (self.show_pressure_setpoint_band, smp.pressure_set_point, QColor(35, 35, 35)),
            (self.show_water_volume, smp.water_volume, QColor(170, 70, 170)),
            (self.show_calculated_water_volume, smp.calculated_water_volume, QColor(40, 100, 200)),
        ]
        for visible, value, color in extra_points:
            if visible and value is not None:
                p.setBrush(QBrush(color)); p.setPen(Qt.NoPen)
                p.drawEllipse(QPointF(x, self._map_y(value, plot, pymin, pymax)), 4, 4)
        if self.show_vac and smp.vacuum is not None:
            p.setBrush(QBrush(QColor(180, 0, 0)))
            p.setPen(Qt.NoPen)
            p.drawEllipse(QPointF(x, self._map_y(smp.vacuum, plot, vymin, vymax)), 4, 4)

    def _range_value_axis(self) -> str:
        return "vacuum" if self.range_parameter == "Vacuum" else "primary"

    def _draw_range_analysis(self, p: QPainter, plot: QRectF, xmin: float, xmax: float,
                             pymin: float, pymax: float, vymin: float, vymax: float) -> None:
        if not self.range_selection:
            return
        start, end = self.range_selection
        if end < xmin or start > xmax:
            return
        left_t, right_t = max(start, xmin), min(end, xmax)
        x1 = self._map_x(left_t, plot, xmin, xmax)
        x2 = self._map_x(right_t, plot, xmin, xmax)
        fill = QColor(70, 150, 90); fill.setAlpha(42)
        p.fillRect(QRectF(x1, plot.top(), max(1.0, x2-x1), plot.height()), fill)
        p.setPen(QPen(QColor(35, 125, 65), 1, Qt.DashLine))
        p.drawRect(QRectF(x1, plot.top(), max(1.0, x2-x1), plot.height()))
        if not self.range_result:
            return
        avg = self.range_result.get("average")
        if isinstance(avg, (int, float)) and math.isfinite(avg):
            ymin, ymax = (vymin, vymax) if self._range_value_axis() == "vacuum" else (pymin, pymax)
            if ymin <= avg <= ymax:
                y = self._map_y(avg, plot, ymin, ymax)
                p.setPen(QPen(QColor(35, 125, 65), 1.3, Qt.DashDotLine))
                p.drawLine(QPointF(x1, y), QPointF(x2, y))
        if not self.show_range_overlay:
            return
        r = self.range_result
        lines = [
            f"Range Analysis — {self.range_parameter}",
            f"{self._format_minutes_as_time(start)} - {self._format_minutes_as_time(end)}",
            f"Avg {r.get('average', 0):.4g}   Min {r.get('minimum', 0):.4g}   Max {r.get('maximum', 0):.4g}",
            f"P-P {r.get('peak_to_peak', 0):.4g}   StdDev {r.get('std_dev', 0):.4g}   CV {r.get('cv_percent', 0):.3g}%",
            f"RMS noise {r.get('rms_noise', 0):.4g}   Slope {r.get('slope_per_min', 0):.4g}/min",
            f"Duration {r.get('duration_min', 0):.3f} min   Samples {r.get('sample_count', 0)}",
        ]
        box_w, line_h = 390, 16
        box_h = 10 + line_h * len(lines)
        bx = max(plot.left()+5, min(x1+6, plot.right()-box_w-5))
        by = plot.top()+26
        p.setPen(QPen(QColor(35, 125, 65), 1))
        p.setBrush(QBrush(QColor(248, 255, 248, 235)))
        p.drawRoundedRect(QRectF(bx, by, box_w, box_h), 5, 5)
        p.setPen(QColor(30, 70, 40))
        for i, line in enumerate(lines):
            p.drawText(int(bx+8), int(by+17+i*line_h), line)

    def paintEvent(self, event) -> None:  # type: ignore[override]
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.fillRect(self.rect(), QColor(255, 255, 255))
        # Keep a dedicated header band for title, legend and event labels.
        margin_l, margin_r, margin_t, margin_b = 58, 58, 86, 42
        plot = QRectF(margin_l, margin_t, max(10, self.width() - margin_l - margin_r), max(10, self.height() - margin_t - margin_b))
        self._plot_rect = plot
        p.setPen(QColor(40, 40, 40))
        title = self.file_name or "No file selected"
        p.setFont(QFont("Arial", 10, QFont.Bold))
        p.drawText(8, 18, title)
        p.setFont(QFont("Arial", 8))
        p.drawText(8, 34, "Hover to inspect Time / State / DO / Vacuum / Flow / Pressure / Temperature / WaterVolume / Calculated Volume")
        if not self.samples:
            p.setPen(QColor(100, 100, 100)); p.drawText(self.rect(), Qt.AlignCenter, "No chart data")
            return
        xmin, xmax = self._time_range()
        pymin, pymax = self._primary_range()
        vymin, vymax = self._vacuum_range()
        self._draw_axes(p, plot, xmin, xmax, pymin, pymax, vymin, vymax)
        self._draw_non_event_labels(p, plot, xmin, xmax)
        self._draw_event_markers(p, plot, xmin, xmax, pymin, pymax)
        visible_samples = self._visible_samples(xmin, xmax)
        do_vals = [(s.time_min, s.do) for s in visible_samples if s.do is not None and is_valid_do(s.do)]
        vac_vals = [(s.time_min, s.vacuum) for s in visible_samples if s.vacuum is not None]
        sf_vals = [(s.time_min, s.second_flow) for s in visible_samples if s.second_flow is not None and SECONDARY_FLOW_PLOT_MIN <= s.second_flow <= SECONDARY_FLOW_PLOT_MAX]
        pf_vals = [(s.time_min, s.primary_flow) for s in visible_samples if s.primary_flow is not None]
        ct_vals = [(s.time_min, s.chiller_temp) for s in visible_samples if s.chiller_temp is not None]
        xdt_vals = [(s.time_min, s.xd_temperature) for s in visible_samples if s.xd_temperature is not None]
        ap_vals = [(s.time_min, s.absolute_pressure) for s in visible_samples if s.absolute_pressure is not None]
        dp_vals = [(s.time_min, s.dynamic_pressure) for s in visible_samples if s.dynamic_pressure is not None]
        wv_vals = [(s.time_min, s.water_volume) for s in visible_samples if s.water_volume is not None]
        cwv_vals = [(s.time_min, s.calculated_water_volume) for s in visible_samples if s.calculated_water_volume is not None]
        if self.show_do:
            self._draw_line_series(p, plot, do_vals, xmin, xmax, pymin, pymax, QColor(0, 80, 180), 1.6)
        if self.show_sf:
            self._draw_line_series(p, plot, sf_vals, xmin, xmax, pymin, pymax, QColor(0, 140, 80), 1.3)
        if self.show_primary_flow:
            self._draw_line_series(p, plot, pf_vals, xmin, xmax, pymin, pymax, QColor(112, 48, 160), 1.2)
        if self.show_chiller_temp:
            self._draw_line_series(p, plot, ct_vals, xmin, xmax, pymin, pymax, QColor(0, 160, 160), 1.2)
        if self.show_xd_temperature:
            self._draw_line_series(p, plot, xdt_vals, xmin, xmax, pymin, pymax, QColor(200, 80, 40), 1.2)
        if self.show_absolute_pressure:
            self._draw_line_series(p, plot, ap_vals, xmin, xmax, pymin, pymax, QColor(220, 150, 0), 1.2)
        if self.show_dynamic_pressure:
            self._draw_line_series(p, plot, dp_vals, xmin, xmax, pymin, pymax, QColor(120, 120, 120), 1.2)
        if self.show_pressure_setpoint_band:
            self._draw_pressure_setpoint_series(p, plot, visible_samples, xmin, xmax, pymin, pymax)
        if self.show_water_volume:
            self._draw_line_series(p, plot, wv_vals, xmin, xmax, pymin, pymax, QColor(170, 70, 170), 1.2)
        if self.show_calculated_water_volume:
            self._draw_line_series(p, plot, cwv_vals, xmin, xmax, pymin, pymax, QColor(40, 100, 200), 1.3)
        if self.show_vac:
            self._draw_line_series(p, plot, vac_vals, xmin, xmax, vymin, vymax, QColor(180, 0, 0), 1.4)
        # Legend. Wrap across rows to keep all active sensors visible.
        legend = [
            ("DO", QColor(0, 80, 180), self.show_do),
            ("Vacuum", QColor(180, 0, 0), self.show_vac),
            ("Secondary Flow", QColor(0, 140, 80), self.show_sf),
            ("Primary Flow", QColor(112, 48, 160), self.show_primary_flow),
            ("Chiller Temp", QColor(0, 160, 160), self.show_chiller_temp),
            ("XD Temperature", QColor(200, 80, 40), self.show_xd_temperature),
            ("Abs Pressure", QColor(220, 150, 0), self.show_absolute_pressure),
            ("Dyn Pressure", QColor(120, 120, 120), self.show_dynamic_pressure),
            ("Pressure SetPoint", QColor(35, 35, 35), self.show_pressure_setpoint_band),
            ("SetPoint ±5", QColor(220, 70, 70), self.show_pressure_setpoint_band),
            ("WaterVolume (raw)", QColor(170, 70, 170), self.show_water_volume),
            ("Calc Water Vol (L)", QColor(40, 100, 200), self.show_calculated_water_volume),
        ]
        lx = int(plot.left()); ly = 54
        for name, color, visible in legend:
            if not visible: continue
            if lx > plot.right() - 120:
                lx = int(plot.left()); ly += 16
            p.setPen(QPen(color, 2)); p.drawLine(lx, ly, lx + 22, ly)
            p.setPen(QColor(50, 50, 50)); p.drawText(lx + 28, ly + 4, name)
            lx += 110

        # Draw drag-to-zoom selection overlay after curves/legend so the target range is visible.
        if self._is_dragging and self._drag_start is not None and self._drag_current is not None:
            x1 = max(plot.left(), min(self._drag_start.x(), plot.right()))
            x2 = max(plot.left(), min(self._drag_current.x(), plot.right()))
            left = min(x1, x2); width = abs(x2 - x1)
            if width >= 1:
                fill = QColor(80, 130, 220); fill.setAlpha(45)
                p.fillRect(QRectF(left, plot.top(), width, plot.height()), fill)
                p.setPen(QPen(QColor(40, 90, 180), 1, Qt.DashLine))
                p.drawRect(QRectF(left, plot.top(), width, plot.height()))
                t1 = self._plot_x_to_time(left)
                t2 = self._plot_x_to_time(left + width)
                if t1 is not None and t2 is not None:
                    mode_name = "Analyze" if self.range_analysis_enabled else "Zoom"
                    txt = f"{mode_name}: {self._format_minutes_as_time(t1)} - {self._format_minutes_as_time(t2)}"
                    p.setPen(QColor(40, 40, 40))
                    p.setBrush(QBrush(QColor(255, 255, 255, 230)))
                    p.drawRoundedRect(QRectF(left + 4, plot.top() + 4, 220, 18), 3, 3)
                    p.drawText(int(left + 10), int(plot.top() + 18), txt)
        self._draw_range_analysis(p, plot, xmin, xmax, pymin, pymax, vymin, vymax)
        self._draw_hover(p, plot, xmin, xmax, pymin, pymax, vymin, vymax)


class LongTermTrendWidget(QWidget):
    """Lightweight time-proportional line chart for one metric across multiple files."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.points: List[Dict[str, Any]] = []
        self.metric_label = ""
        self.unit = ""
        self.show_spread = True
        self.zoom_ranges: Optional[Tuple[float, float, float, float]] = None
        self._drag_start: Optional[QPointF] = None
        self._drag_current: Optional[QPointF] = None
        self.setMinimumHeight(280)
        self.setMouseTracking(True)

    def set_data(self, points: List[Dict[str, Any]], metric_label: str, unit: str, show_spread: bool = True) -> None:
        self.points = [p for p in points if p.get("value") is not None and math.isfinite(float(p["value"]))]
        self.metric_label = metric_label
        self.unit = unit
        self.show_spread = show_spread
        # A new metric/data set always starts from the full extent.
        self.zoom_ranges = None
        self._drag_start = None
        self._drag_current = None
        self.update()

    def _plot_rect(self) -> QRectF:
        return QRectF(72, 28, max(40, self.width() - 96), max(60, self.height() - 86))

    def _ranges(self):
        if self.zoom_ranges is not None:
            return self.zoom_ranges
        if not self.points:
            return None
        epoch = datetime(1970, 1, 1)
        xs = [(p["dt"] - epoch).total_seconds() for p in self.points]
        ys = [float(p["value"]) for p in self.points]
        if self.show_spread:
            for p in self.points:
                for key in ("min", "max"):
                    v = p.get(key)
                    if v is not None and math.isfinite(float(v)):
                        ys.append(float(v))
        x0, x1 = min(xs), max(xs)
        if x1 <= x0:
            x0 -= 43200.0; x1 += 43200.0
        y0, y1 = min(ys), max(ys)
        if y1 <= y0:
            pad = max(1.0, abs(y0) * 0.1)
        else:
            pad = (y1 - y0) * 0.12
        return x0, x1, y0 - pad, y1 + pad

    def _xy(self, dt: datetime, value: float, rect: QRectF, ranges) -> QPointF:
        x0, x1, y0, y1 = ranges
        x = rect.left() + ((dt - datetime(1970, 1, 1)).total_seconds() - x0) / (x1 - x0) * rect.width()
        y = rect.bottom() - (value - y0) / (y1 - y0) * rect.height()
        return QPointF(x, y)

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.fillRect(self.rect(), self.palette().base())
        painter.setPen(self.palette().text().color())
        painter.drawText(12, 18, f"Long-term Trend — {self.metric_label}")
        rect = self._plot_rect()
        painter.setPen(QPen(QColor(190, 190, 190), 1))
        painter.drawRect(rect)
        ranges = self._ranges()
        if ranges is None:
            painter.drawText(rect, Qt.AlignCenter, "Load and analyze at least 2 WaterSystem files.")
            return
        x0, x1, y0, y1 = ranges
        # Horizontal guides / numeric labels.
        for i in range(5):
            frac = i / 4.0
            y = rect.bottom() - frac * rect.height()
            value = y0 + frac * (y1 - y0)
            painter.setPen(QPen(QColor(225, 225, 225), 1))
            painter.drawLine(QPointF(rect.left(), y), QPointF(rect.right(), y))
            painter.setPen(self.palette().text().color())
            painter.drawText(QRectF(4, y - 9, 64, 18), Qt.AlignRight | Qt.AlignVCenter, f"{value:.2f}")
        epoch = datetime(1970, 1, 1)
        visible_points = [
            p for p in self.points
            if x0 <= (p["dt"] - epoch).total_seconds() <= x1
        ]
        pts = [self._xy(p["dt"], float(p["value"]), rect, ranges) for p in visible_points]
        # Clip all data marks to the plot rectangle while zoomed (and at full extent).
        painter.save()
        painter.setClipRect(rect)
        # Within-file variability: thin whisker = Min–Max, thick bar = P25–P75.
        if self.show_spread:
            for p, q in zip(visible_points, pts):
                vmin, vmax, p25, p75 = p.get("min"), p.get("max"), p.get("p25"), p.get("p75")
                if vmin is not None and vmax is not None:
                    a = self._xy(p["dt"], float(vmin), rect, ranges)
                    b = self._xy(p["dt"], float(vmax), rect, ranges)
                    painter.setPen(QPen(QColor(135, 135, 135), 1))
                    painter.drawLine(a, b)
                    painter.drawLine(QPointF(a.x()-4, a.y()), QPointF(a.x()+4, a.y()))
                    painter.drawLine(QPointF(b.x()-4, b.y()), QPointF(b.x()+4, b.y()))
                if p25 is not None and p75 is not None:
                    a = self._xy(p["dt"], float(p25), rect, ranges)
                    b = self._xy(p["dt"], float(p75), rect, ranges)
                    painter.setPen(QPen(QColor(105, 105, 105), 5))
                    painter.drawLine(a, b)
        if len(pts) >= 2:
            painter.setPen(QPen(QColor(55, 105, 180), 2))
            for a, b in zip(pts, pts[1:]):
                painter.drawLine(a, b)
        for q in pts:
            painter.setPen(QPen(QColor(55, 105, 180), 2))
            painter.setBrush(QBrush(self.palette().base().color()))
            painter.drawEllipse(q, 4.5, 4.5)
        painter.restore()
        # Keep labels readable: first/last plus up to five evenly spaced interior labels.
        n = len(visible_points)
        label_idx = ({0, n - 1} if n else set())
        if n > 2:
            for i in range(1, min(6, n - 1)):
                label_idx.add(round(i * (n - 1) / min(6, n - 1)))
        painter.setPen(self.palette().text().color())
        for i in sorted(label_idx):
            p = visible_points[i]
            q = pts[i]
            txt = p["dt"].strftime("%Y-%m-%d")
            painter.save()
            painter.translate(q.x(), rect.bottom() + 10)
            painter.rotate(-35)
            painter.drawText(QRectF(-4, 0, 92, 18), Qt.AlignLeft | Qt.AlignVCenter, txt)
            painter.restore()
        painter.drawText(QRectF(rect.left(), self.height()-22, rect.width(), 18), Qt.AlignCenter, "Measurement date (actual spacing)")

        # Drag-to-zoom selection overlay. Selection is constrained to the plot area
        # and applies to both X (time) and Y (metric) axes on release.
        if self._drag_start is not None and self._drag_current is not None:
            a = QPointF(
                min(max(self._drag_start.x(), rect.left()), rect.right()),
                min(max(self._drag_start.y(), rect.top()), rect.bottom()),
            )
            b = QPointF(
                min(max(self._drag_current.x(), rect.left()), rect.right()),
                min(max(self._drag_current.y(), rect.top()), rect.bottom()),
            )
            sel = QRectF(a, b).normalized()
            if sel.width() >= 1 and sel.height() >= 1:
                fill = QColor(80, 130, 220); fill.setAlpha(45)
                painter.fillRect(sel, fill)
                painter.setPen(QPen(QColor(40, 90, 180), 1, Qt.DashLine))
                painter.drawRect(sel)

    def _pixel_to_data(self, pos: QPointF, rect: QRectF, ranges) -> Tuple[float, float]:
        x0, x1, y0, y1 = ranges
        px = min(max(pos.x(), rect.left()), rect.right())
        py = min(max(pos.y(), rect.top()), rect.bottom())
        x = x0 + (px - rect.left()) / max(1.0, rect.width()) * (x1 - x0)
        y = y0 + (rect.bottom() - py) / max(1.0, rect.height()) * (y1 - y0)
        return x, y

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.LeftButton and self._ranges() is not None:
            rect = self._plot_rect()
            if rect.contains(event.position()):
                self._drag_start = QPointF(event.position())
                self._drag_current = QPointF(event.position())
                QToolTip.hideText()
                self.update()
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.LeftButton and self._drag_start is not None:
            rect = self._plot_rect()
            ranges = self._ranges()
            start = self._drag_start
            end = QPointF(event.position())
            self._drag_start = None
            self._drag_current = None
            if ranges is not None:
                a = QPointF(
                    min(max(start.x(), rect.left()), rect.right()),
                    min(max(start.y(), rect.top()), rect.bottom()),
                )
                b = QPointF(
                    min(max(end.x(), rect.left()), rect.right()),
                    min(max(end.y(), rect.top()), rect.bottom()),
                )
                sel = QRectF(a, b).normalized()
                # Ignore a normal click / tiny accidental drag.
                if sel.width() >= 8 and sel.height() >= 8:
                    xa, ya = self._pixel_to_data(sel.topLeft(), rect, ranges)
                    xb, yb = self._pixel_to_data(sel.bottomRight(), rect, ranges)
                    nx0, nx1 = sorted((xa, xb))
                    ny0, ny1 = sorted((ya, yb))
                    # Guard against degenerate numeric ranges.
                    if nx1 > nx0 and ny1 > ny0:
                        self.zoom_ranges = (nx0, nx1, ny0, ny1)
            self.update()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event) -> None:
        if event.button() == Qt.LeftButton:
            self.zoom_ranges = None
            self._drag_start = None
            self._drag_current = None
            QToolTip.hideText()
            self.update()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def mouseMoveEvent(self, event) -> None:
        if self._drag_start is not None:
            self._drag_current = QPointF(event.position())
            QToolTip.hideText()
            self.update()
            event.accept()
            return
        ranges = self._ranges()
        if ranges is None:
            QToolTip.hideText(); return
        rect = self._plot_rect()
        if not rect.contains(event.position()):
            QToolTip.hideText(); return
        x0, x1, _, _ = ranges
        epoch = datetime(1970, 1, 1)
        nearest = None; best = 1e9
        for p in self.points:
            ts = (p["dt"] - epoch).total_seconds()
            if ts < x0 or ts > x1:
                continue
            q = self._xy(p["dt"], float(p["value"]), rect, ranges)
            d = abs(q.x() - event.position().x()) + abs(q.y() - event.position().y())
            if d < best:
                best, nearest = d, (p, q)
        if nearest and best < 35:
            p, q = nearest
            unit = f" {self.unit}" if self.unit else ""
            text = f"{p['dt'].strftime('%Y-%m-%d %H:%M:%S')}\n{Path(p['file']).name}\n{self.metric_label}: {float(p['value']):.3f}{unit}"
            if self.show_spread and p.get("p25") is not None:
                text += (f"\nP25–P75: {float(p['p25']):.3f}–{float(p['p75']):.3f}{unit}"
                         f"\nMin–Max: {float(p['min']):.3f}–{float(p['max']):.3f}{unit}")
            dur = float(p.get("valid_duration_sec") or 0.0)
            dur_text = f"{dur/60.0:.1f} min" if dur >= 60.0 else f"{dur:.1f} s"
            text += (f"\nN: {int(p.get('n') or 0)}"
                     f"\nValid time: {dur_text}"
                     f"\nScope: {p.get('scope', '')}"
                     f"\nState: {p.get('state', '')}")
            QToolTip.showText(self.mapToGlobal(event.position().toPoint()), text, self)
        else:
            QToolTip.hideText()


class CorrelationScatterWidget(QWidget):
    """Scatter plot for per-file correlation metrics in Long-term mode."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.points: List[Dict[str, Any]] = []
        self.x_label = ""
        self.y_label = ""
        self.zoom_ranges: Optional[Tuple[float, float, float, float]] = None
        self._drag_start: Optional[QPointF] = None
        self._drag_current: Optional[QPointF] = None
        self.setMinimumHeight(250)
        self.setMouseTracking(True)

    def set_data(self, points: List[Dict[str, Any]], x_label: str, y_label: str) -> None:
        self.points = []
        for p in points:
            xv, yv = p.get('x'), p.get('y')
            if xv is None or yv is None:
                continue
            try:
                xf, yf = float(xv), float(yv)
            except (TypeError, ValueError):
                continue
            if not (math.isfinite(xf) and math.isfinite(yf)):
                continue
            cp = dict(p)
            cp['x'] = xf
            cp['y'] = yf
            self.points.append(cp)
        self.x_label = x_label
        self.y_label = y_label
        self.zoom_ranges = None
        self._drag_start = None
        self._drag_current = None
        self.update()

    def _plot_rect(self) -> QRectF:
        return QRectF(72, 28, max(40, self.width() - 96), max(60, self.height() - 86))

    def _ranges(self):
        if self.zoom_ranges is not None:
            return self.zoom_ranges
        if not self.points:
            return None
        xs = [p['x'] for p in self.points]
        ys = [p['y'] for p in self.points]
        x0, x1 = min(xs), max(xs)
        y0, y1 = min(ys), max(ys)
        if x1 <= x0:
            pad = max(1.0, abs(x0) * 0.1 or 1.0)
            x0 -= pad; x1 += pad
        else:
            pad = (x1 - x0) * 0.12
            x0 -= pad; x1 += pad
        if y1 <= y0:
            pad = max(1.0, abs(y0) * 0.1 or 1.0)
            y0 -= pad; y1 += pad
        else:
            pad = (y1 - y0) * 0.12
            y0 -= pad; y1 += pad
        return x0, x1, y0, y1

    def _xy(self, xv: float, yv: float, rect: QRectF, ranges) -> QPointF:
        x0, x1, y0, y1 = ranges
        x = rect.left() + (xv - x0) / (x1 - x0) * rect.width()
        y = rect.bottom() - (yv - y0) / (y1 - y0) * rect.height()
        return QPointF(x, y)

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.fillRect(self.rect(), self.palette().base())
        painter.setPen(self.palette().text().color())
        painter.drawText(12, 18, f"Correlation — {self.x_label} vs {self.y_label}")
        rect = self._plot_rect()
        painter.setPen(QPen(QColor(190, 190, 190), 1))
        painter.drawRect(rect)
        ranges = self._ranges()
        if ranges is None:
            painter.drawText(rect, Qt.AlignCenter, "Load and analyze at least 2 WaterSystem files.")
            return
        x0, x1, y0, y1 = ranges
        # horizontal grid
        for i in range(5):
            frac = i / 4.0
            y = rect.bottom() - frac * rect.height()
            value = y0 + frac * (y1 - y0)
            painter.setPen(QPen(QColor(225, 225, 225), 1))
            painter.drawLine(QPointF(rect.left(), y), QPointF(rect.right(), y))
            painter.setPen(self.palette().text().color())
            painter.drawText(QRectF(4, y - 9, 64, 18), Qt.AlignRight | Qt.AlignVCenter, f"{value:.2f}")
        # vertical grid
        for i in range(5):
            frac = i / 4.0
            x = rect.left() + frac * rect.width()
            value = x0 + frac * (x1 - x0)
            painter.setPen(QPen(QColor(225, 225, 225), 1))
            painter.drawLine(QPointF(x, rect.top()), QPointF(x, rect.bottom()))
            painter.setPen(self.palette().text().color())
            painter.drawText(QRectF(x - 35, rect.bottom() + 6, 70, 18), Qt.AlignHCenter | Qt.AlignTop, f"{value:.2f}")
        visible = []
        for p in self.points:
            if x0 <= p['x'] <= x1 and y0 <= p['y'] <= y1:
                visible.append((p, self._xy(p['x'], p['y'], rect, ranges)))
        painter.save(); painter.setClipRect(rect)
        # regression line
        if len(visible) >= 2:
            xs = [p['x'] for p, _ in visible]
            ys = [p['y'] for p, _ in visible]
            xm = statistics.fmean(xs); ym = statistics.fmean(ys)
            denom = sum((x - xm) ** 2 for x in xs)
            if denom > 0:
                slope = sum((x - xm) * (y - ym) for x, y in zip(xs, ys)) / denom
                intercept = ym - slope * xm
                ya = slope * x0 + intercept
                yb = slope * x1 + intercept
                pa = self._xy(x0, ya, rect, ranges)
                pb = self._xy(x1, yb, rect, ranges)
                painter.setPen(QPen(QColor(180, 120, 40), 1.5, Qt.DashLine))
                painter.drawLine(pa, pb)
        for p, q in visible:
            painter.setPen(QPen(QColor(55, 105, 180), 2))
            painter.setBrush(QBrush(self.palette().base().color()))
            painter.drawEllipse(q, 4.5, 4.5)
        painter.restore()
        painter.setPen(self.palette().text().color())
        painter.drawText(QRectF(rect.left(), self.height()-22, rect.width(), 18), Qt.AlignCenter, self.x_label)
        painter.save()
        painter.translate(16, rect.top() + rect.height() / 2.0)
        painter.rotate(-90)
        painter.drawText(QRectF(-rect.height()/2.0, -28, rect.height(), 18), Qt.AlignCenter, self.y_label)
        painter.restore()

        if self._drag_start is not None and self._drag_current is not None:
            a = QPointF(min(max(self._drag_start.x(), rect.left()), rect.right()),
                        min(max(self._drag_start.y(), rect.top()), rect.bottom()))
            b = QPointF(min(max(self._drag_current.x(), rect.left()), rect.right()),
                        min(max(self._drag_current.y(), rect.top()), rect.bottom()))
            sel = QRectF(a, b).normalized()
            if sel.width() >= 1 and sel.height() >= 1:
                fill = QColor(80, 130, 220); fill.setAlpha(45)
                painter.fillRect(sel, fill)
                painter.setPen(QPen(QColor(40, 90, 180), 1, Qt.DashLine))
                painter.drawRect(sel)

    def _pixel_to_data(self, pos: QPointF, rect: QRectF, ranges) -> Tuple[float, float]:
        x0, x1, y0, y1 = ranges
        px = min(max(pos.x(), rect.left()), rect.right())
        py = min(max(pos.y(), rect.top()), rect.bottom())
        x = x0 + (px - rect.left()) / max(1.0, rect.width()) * (x1 - x0)
        y = y0 + (rect.bottom() - py) / max(1.0, rect.height()) * (y1 - y0)
        return x, y

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.LeftButton and self._ranges() is not None:
            rect = self._plot_rect()
            if rect.contains(event.position()):
                self._drag_start = QPointF(event.position())
                self._drag_current = QPointF(event.position())
                QToolTip.hideText()
                self.update()
                event.accept(); return
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.LeftButton and self._drag_start is not None:
            rect = self._plot_rect(); ranges = self._ranges()
            start = self._drag_start; end = QPointF(event.position())
            self._drag_start = None; self._drag_current = None
            if ranges is not None:
                a = QPointF(min(max(start.x(), rect.left()), rect.right()), min(max(start.y(), rect.top()), rect.bottom()))
                b = QPointF(min(max(end.x(), rect.left()), rect.right()), min(max(end.y(), rect.top()), rect.bottom()))
                sel = QRectF(a, b).normalized()
                if sel.width() >= 8 and sel.height() >= 8:
                    xa, ya = self._pixel_to_data(sel.topLeft(), rect, ranges)
                    xb, yb = self._pixel_to_data(sel.bottomRight(), rect, ranges)
                    nx0, nx1 = sorted((xa, xb)); ny0, ny1 = sorted((ya, yb))
                    if nx1 > nx0 and ny1 > ny0:
                        self.zoom_ranges = (nx0, nx1, ny0, ny1)
            self.update(); event.accept(); return
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event) -> None:
        if event.button() == Qt.LeftButton:
            self.zoom_ranges = None
            self._drag_start = None
            self._drag_current = None
            QToolTip.hideText()
            self.update(); event.accept(); return
        super().mouseDoubleClickEvent(event)

    def mouseMoveEvent(self, event) -> None:
        if self._drag_start is not None:
            self._drag_current = QPointF(event.position())
            QToolTip.hideText()
            self.update(); event.accept(); return
        ranges = self._ranges()
        if ranges is None:
            QToolTip.hideText(); return
        rect = self._plot_rect()
        if not rect.contains(event.position()):
            QToolTip.hideText(); return
        nearest = None; best = 1e9
        for p in self.points:
            q = self._xy(p['x'], p['y'], rect, ranges)
            d = abs(q.x() - event.position().x()) + abs(q.y() - event.position().y())
            if d < best:
                best, nearest = d, (p, q)
        if nearest and best < 35:
            p, _ = nearest
            xunit = f" {p.get('x_unit','')}" if p.get('x_unit') else ""
            yunit = f" {p.get('y_unit','')}" if p.get('y_unit') else ""
            text = (f"{p['dt'].strftime('%Y-%m-%d %H:%M:%S')}\n{Path(p['file']).name}\n"
                    f"{self.x_label}: {float(p['x']):.3f}{xunit}\n"
                    f"{self.y_label}: {float(p['y']):.3f}{yunit}\n"
                    f"Scope: {p.get('scope','')}\nState: {p.get('state','')}")
            QToolTip.showText(self.mapToGlobal(event.position().toPoint()), text, self)
        else:
            QToolTip.hideText()


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} - {APP_VERSION}")
        self.resize(1200, 780)
        self.files: List[str] = []
        self.results: List[EventResult] = []
        self.summaries: List[FileSummary] = []
        self.current_samples: List[Sample] = []
        self.current_range_result: Optional[Dict[str, Any]] = None
        self.sample_cache: Dict[str, List[Sample]] = {}
        self.worker: Optional[AnalyzeWorker] = None
        self._retired_workers: List[AnalyzeWorker] = []
        self.import_worker: Optional[ImportWorker] = None
        self._retired_import_workers: List[ImportWorker] = []
        self._analysis_generation = 0
        self._import_generation = 0
        self._temp_roots: List[str] = []
        self.setAcceptDrops(True)
        self._build_ui()
        self._setup_guide_system()


    def _setup_guide_system(self) -> None:
        pages = [
            GuidePage(
                "1. Import files and automatic analysis",
                "<p>Drop a WaterSystem log, folder, or ZIP archive onto the application, "
                "or use <b>Select Files / ZIP</b> and <b>Select Folder</b>.</p>"
                "<p>The application finds matching WaterSystem files inside folders and ZIP archives "
                "and starts analysis automatically. There is no separate Analyze button.</p>",
            ),
            GuidePage(
                "2. Import / Settings panel",
                "<p>Use <b>Show Import / Settings</b> to expand the upper control area. "
                "Collapse it again to maximize the chart.</p>"
                "<p>The judgment settings control minimum DO change, high/low DO averaging band, "
                "and Vacuum FLAT tolerance.</p>",
            ),
            GuidePage(
                "3. Review analysis results",
                "<p><b>Event Results</b> shows each detected event. "
                "<b>File Summary</b> shows totals for every loaded file.</p>"
                "<p>Select a result row to move directly to the corresponding file and event in the Chart tab.</p>",
            ),
            GuidePage(
                "4. Chart display controls",
                "<p>Use the checkboxes above the chart to show or hide DO, Vacuum, flow, pressure, "
                "temperature, and event labels.</p>"
                "<p><b>Non-event labels</b> shows actual Treatment Pause and Degas Pause states, plus labels outside detected Treat/Clean events. "
                "<b>Value popup</b> turns the mouse-over value display on or off.</p>",
            ),
            GuidePage(
                "5. Zoom and navigation",
                "<p>Use the collapsible <b>Range Analysis</b> panel to select a sensor and measure variation in a mouse-drawn interval. When disabled, horizontal dragging zooms the X-axis. "
                "You can also enter start and end times and press <b>Apply Zoom</b>.</p>"
                "<p>Use <b>Reset Zoom</b> to return to the complete time range. "
                "The left and right arrow buttons switch the displayed file.</p>",
            ),
            GuidePage(
                "6. Export and projects",
                "<p><b>Export CSV</b> saves analysis results. <b>Save Project</b> stores the current file list, "
                "settings, and chart options. <b>Load Project</b> restores them.</p>"
                "<p>ZIP extraction is temporary and is cleaned up when the application closes.</p>",
            ),
            GuidePage(
                "7. Guide settings",
                "<p>At startup, choose <b>Yes — Show Guide</b> to open this guide, or "
                "<b>No — Do Not Ask Again</b> to disable the startup question.</p>"
                "<p>The Help menu can open the guide at any time or restore the startup question. "
                "When closing the app, select <b>Show the guide and guided tour at the next startup</b> "
                "to display it once on the next launch.</p>",
            ),
        ]
        if RELEASE_MODE:
            self.guide_manager = None
            return

        self.guide_manager = GuideManager(
            self,
            GuideConfig(
                app_name=APP_NAME,
                settings_vendor="InSightec",
                settings_product="DO_Analysis_Qt",
                guide_title=f"{APP_NAME} — Quick Guide and Guided Tour",
            ),
            pages,
        )

        help_menu = self.menuBar().addMenu("Help")
        action_guide = QAction("Quick Guide and Guided Tour", self)
        action_guide.triggered.connect(self.guide_manager.show_guide)
        help_menu.addAction(action_guide)
        action_reset = QAction("Show startup guide question again", self)
        action_reset.triggered.connect(self._reset_guide_prompt)
        help_menu.addAction(action_reset)
        self.guide_manager.schedule_startup_check()

    def _reset_guide_prompt(self) -> None:
        if RELEASE_MODE or self.guide_manager is None:
            return
        self.guide_manager.reset_startup_prompt()
        QMessageBox.information(
            self,
            APP_NAME,
            "The Quick Guide question will be shown at the next startup.",
        )

    def _cleanup_before_close(self) -> None:
        workers = [w for w in ([self.worker] + self._retired_workers + [self.import_worker] + self._retired_import_workers) if w is not None and w.isRunning()]
        for worker in workers:
            worker.requestInterruption()
        for worker in workers:
            worker.wait(3000)
        # Never delete ZIP data that a still-running worker may have open.
        if not any(worker.isRunning() for worker in workers):
            for root in self._temp_roots:
                shutil.rmtree(root, ignore_errors=True)
            self._temp_roots.clear()

    def _build_ui(self) -> None:
        root = QWidget(); self.setCentralWidget(root)
        main = QVBoxLayout(root)
        main.setContentsMargins(6, 6, 6, 6)
        main.setSpacing(4)

        # Compact header remains visible while the import/settings area is folded.
        compact = QHBoxLayout()
        self.btn_toggle_controls = QPushButton("▼ Hide Import / Settings")
        self.btn_toggle_controls.setCheckable(True)
        self.btn_toggle_controls.setChecked(True)
        compact.addWidget(self.btn_toggle_controls)
        self.compact_file_status = QLabel("No files loaded")
        compact.addWidget(self.compact_file_status, 1)
        main.addLayout(compact)

        self.control_panel = QWidget()
        panel_layout = QVBoxLayout(self.control_panel)
        panel_layout.setContentsMargins(0, 0, 0, 0)
        panel_layout.setSpacing(4)

        top = QHBoxLayout()
        self.btn_files = QPushButton("Select Files / ZIP")
        self.btn_folder = QPushButton("Select Folder")
        self.btn_export = QPushButton("Export CSV")
        self.btn_save = QPushButton("Save Project")
        self.btn_load = QPushButton("Load Project")
        for b in [self.btn_files,self.btn_folder,self.btn_export,self.btn_save,self.btn_load]:
            top.addWidget(b)
        panel_layout.addLayout(top)

        self.drop_hint = QLabel("Drop WaterSystem files, folders, or ZIP archives here")
        self.drop_hint.setAlignment(Qt.AlignCenter)
        self.drop_hint.setMinimumHeight(42)
        self.drop_hint.setStyleSheet("QLabel { border: 2px dashed #8a9aaa; border-radius: 8px; background: #f5f8fb; color: #405060; font-weight: 600; padding: 6px; }")
        panel_layout.addWidget(self.drop_hint)

        opts = QGroupBox("Judgment settings")
        grid = QGridLayout(opts)
        self.sp_min_do = QDoubleSpinBox(); self.sp_min_do.setRange(0.0, 5.0); self.sp_min_do.setDecimals(2); self.sp_min_do.setValue(MIN_DO_CHANGE_FOR_VACUUM); self.sp_min_do.setSuffix(" ppm")
        self.sp_band = QDoubleSpinBox(); self.sp_band.setRange(0.01, 1.0); self.sp_band.setDecimals(2); self.sp_band.setValue(DO_AVG_BAND); self.sp_band.setSuffix(" ppm")
        self.sp_flat = QDoubleSpinBox(); self.sp_flat.setRange(0.0, 5.0); self.sp_flat.setDecimals(2); self.sp_flat.setValue(VACUUM_FLAT_TOLERANCE)
        grid.addWidget(QLabel("Min DO change for Vacuum judgment"),0,0); grid.addWidget(self.sp_min_do,0,1)
        grid.addWidget(QLabel("High/Low DO average band"),0,2); grid.addWidget(self.sp_band,0,3)
        grid.addWidget(QLabel("Vacuum FLAT tolerance"),0,4); grid.addWidget(self.sp_flat,0,5)
        panel_layout.addWidget(opts)

        self.progress = QProgressBar(); panel_layout.addWidget(self.progress)
        self.status = QLabel("Ready"); panel_layout.addWidget(self.status)
        self.log = QTextEdit(); self.log.setReadOnly(True); self.log.setMaximumHeight(80); panel_layout.addWidget(self.log)
        main.addWidget(self.control_panel)

        self.tabs = QTabWidget(); main.addWidget(self.tabs, 1)

        result_page = QWidget(); res_layout = QVBoxLayout(result_page)
        self.result_table = QTableWidget(0, 15)
        self.result_table.setHorizontalHeaderLabels(["File","Type","No","Start","End","Duration","Max DO","Min DO","DO Change","High DO Vac","Low DO Vac","Diff","Trend","2nd Flow Avg","Note"])
        res_layout.addWidget(self.result_table)
        self.tabs.addTab(result_page, "Event Results")

        summary_page = QWidget(); sum_layout = QVBoxLayout(summary_page)
        self.summary_table = QTableWidget(0, 8)
        self.summary_table.setHorizontalHeaderLabels(["File","Samples","Events","UP","FLAT","DOWN","N/A","Path"])
        sum_layout.addWidget(self.summary_table)
        self.tabs.addTab(summary_page, "File Summary")

        chart_page = QWidget(); chart_layout = QVBoxLayout(chart_page)
        chart_layout.setContentsMargins(4, 4, 4, 4)
        chart_layout.setSpacing(3)
        file_row = QHBoxLayout()
        file_row.addWidget(QLabel("Displayed file"))
        self.btn_prev_chart_file = QPushButton("◀")
        self.btn_prev_chart_file.setFixedWidth(34)
        file_row.addWidget(self.btn_prev_chart_file)
        self.chart_file_combo = QComboBox()
        self.chart_file_combo.setMinimumWidth(360)
        file_row.addWidget(self.chart_file_combo, 1)
        self.btn_next_chart_file = QPushButton("▶")
        self.btn_next_chart_file.setFixedWidth(34)
        file_row.addWidget(self.btn_next_chart_file)
        self.btn_reload_chart_file = QPushButton("Reload")
        file_row.addWidget(self.btn_reload_chart_file)
        chart_layout.addLayout(file_row)
        cbrow = QHBoxLayout()
        self.cb_all = QCheckBox("ALL"); self.cb_all.setChecked(False)
        self.cb_do = QCheckBox("DO"); self.cb_do.setChecked(True)
        self.cb_vac = QCheckBox("Vacuum"); self.cb_vac.setChecked(True)
        self.cb_sf = QCheckBox("Secondary Flow"); self.cb_sf.setChecked(True)
        self.cb_pf = QCheckBox("Primary Flow"); self.cb_pf.setChecked(False)
        self.cb_chiller = QCheckBox("Chiller Temp"); self.cb_chiller.setChecked(False)
        self.cb_xd_temp = QCheckBox("XD Temperature"); self.cb_xd_temp.setChecked(False)
        self.cb_abs = QCheckBox("AbsolutePressure"); self.cb_abs.setChecked(False)
        self.cb_dyn = QCheckBox("DynamicPressure"); self.cb_dyn.setChecked(False)
        self.cb_pressure_setpoint = QCheckBox("Pressure SetPoint ±5"); self.cb_pressure_setpoint.setChecked(False)
        self.cb_pressure_setpoint.setToolTip("Show PressureSetPoint with SetPoint -5 and SetPoint +5 limit lines.")
        self.cb_water_volume = QCheckBox("WaterVolume (raw)"); self.cb_water_volume.setChecked(False)
        self.cb_calc_water_volume = QCheckBox("Calculated Water Volume"); self.cb_calc_water_volume.setChecked(False)
        self.cb_calc_water_volume.setToolTip("State-aware system volume from SecondaryFlowMeter (L/min): FILL adds, DRAIN subtracts, circulation/other states hold; result shown in L.")
        self.cb_events = QCheckBox("Treat/Clean event labels"); self.cb_events.setChecked(True)
        self.cb_non_events = QCheckBox("Non-event labels"); self.cb_non_events.setChecked(False)
        self.cb_value_popup = QCheckBox("Value popup"); self.cb_value_popup.setChecked(True)
        self.cb_value_popup.setToolTip("Show or hide the chart value popup while moving the mouse over the chart.")
        for c in [self.cb_all,self.cb_do,self.cb_vac,self.cb_sf,self.cb_pf,self.cb_chiller,self.cb_xd_temp,self.cb_abs,self.cb_dyn,self.cb_pressure_setpoint,self.cb_water_volume,self.cb_calc_water_volume,self.cb_events,self.cb_non_events,self.cb_value_popup]: cbrow.addWidget(c)
        cbrow.addStretch(); chart_layout.addLayout(cbrow)
        note = QLabel("Checked items update immediately. Drag across the chart to zoom the X-axis.")
        chart_layout.addWidget(note)

        zoom_row = QHBoxLayout()
        zoom_row.addWidget(QLabel("X zoom start"))
        self.zoom_start = QLineEdit(); self.zoom_start.setPlaceholderText("HH:MM:SS.000")
        zoom_row.addWidget(self.zoom_start)
        zoom_row.addWidget(QLabel("X zoom end"))
        self.zoom_end = QLineEdit(); self.zoom_end.setPlaceholderText("HH:MM:SS.000")
        zoom_row.addWidget(self.zoom_end)
        self.btn_apply_zoom = QPushButton("Apply Zoom")
        self.btn_reset_zoom = QPushButton("Reset Zoom")
        zoom_row.addWidget(self.btn_apply_zoom)
        zoom_row.addWidget(self.btn_reset_zoom)
        chart_layout.addLayout(zoom_row)

        self.btn_toggle_range = QPushButton("▶ Range Analysis")
        self.btn_toggle_range.setCheckable(True)
        self.btn_toggle_range.setChecked(False)
        chart_layout.addWidget(self.btn_toggle_range)
        self.range_panel = QWidget()
        range_grid = QGridLayout(self.range_panel)
        range_grid.setContentsMargins(8, 2, 8, 4)
        self.cb_range_enable = QCheckBox("Enable Range Analysis")
        self.cb_range_overlay = QCheckBox("Show result on chart")
        self.cb_range_overlay.setChecked(True)
        self.range_parameter_combo = QComboBox()
        self.range_parameter_combo.addItems(["DO Level", "Vacuum", "Secondary Flow", "Primary Flow", "Chiller Temperature", "XD Temperature", "Absolute Pressure", "Dynamic Pressure", "Pressure Set Point", "WaterVolume (raw)", "Calculated Water Volume (L)"])
        self.range_result_label = QLabel("Enable Range Analysis, then drag horizontally across the chart.")
        self.range_result_label.setWordWrap(True)
        self.btn_range_copy = QPushButton("Copy Result")
        self.btn_range_export = QPushButton("Export Range CSV")
        self.btn_range_clear = QPushButton("Clear Range")
        range_grid.addWidget(self.cb_range_enable, 0, 0)
        range_grid.addWidget(QLabel("Parameter"), 0, 1)
        range_grid.addWidget(self.range_parameter_combo, 0, 2)
        range_grid.addWidget(self.cb_range_overlay, 0, 3)
        range_grid.addWidget(self.btn_range_copy, 0, 4)
        range_grid.addWidget(self.btn_range_export, 0, 5)
        range_grid.addWidget(self.btn_range_clear, 0, 6)
        range_grid.addWidget(self.range_result_label, 1, 0, 1, 7)
        self.range_panel.setVisible(False)
        chart_layout.addWidget(self.range_panel)

        chart_split = QSplitter(Qt.Vertical)
        self.chart = ChartWidget(); self.chart.zoomSelected.connect(self.on_chart_drag_zoom_selected); self.chart.rangeSelected.connect(self.on_chart_range_selected); chart_split.addWidget(self.chart)
        event_box = QWidget(); event_layout = QVBoxLayout(event_box); event_layout.setContentsMargins(0, 0, 0, 0)
        event_layout.addWidget(QLabel("Event Results for displayed file"))
        self.chart_event_table = QTableWidget(0, 11)
        self.chart_event_table.setHorizontalHeaderLabels(["Type","No","Start","End","Duration","Max DO","Min DO","DO Change","Trend","Diff","Note"])
        event_layout.addWidget(self.chart_event_table)
        chart_split.addWidget(event_box)
        chart_split.setSizes([560, 120])
        chart_split.setStretchFactor(0, 5)
        chart_split.setStretchFactor(1, 1)
        chart_layout.addWidget(chart_split, 1)
        self.tabs.addTab(chart_page, "Chart")

        trend_page = QWidget(); trend_layout = QVBoxLayout(trend_page)
        trend_top = QHBoxLayout()
        trend_top.addWidget(QLabel("Metric"))
        self.longterm_metric_combo = QComboBox()
        self.longterm_metric_combo.addItems([
            "Event DO Change", "Event DO Decrease Rate", "DO Level",
            "Vacuum Level", "Event Vacuum Difference", "Event High-DO Vacuum", "Event Low-DO Vacuum",
            "Secondary Flow", "Event Secondary Flow", "Primary Flow",
            "Chiller Temperature", "XD Temperature",
            "Absolute Pressure", "Dynamic Pressure", "Pressure Set Point",
            "WaterVolume (raw)", "Calculated Water Volume",
            "UP Rate", "DOWN Rate", "Event Count",
        ])
        trend_top.addWidget(self.longterm_metric_combo)
        trend_top.addWidget(QLabel("Representative"))
        self.longterm_stat_combo = QComboBox()
        self.longterm_stat_combo.addItems(["Median", "Mean", "Min", "Max", "P25", "P75"])
        self.longterm_stat_combo.setCurrentText("Median")
        trend_top.addWidget(self.longterm_stat_combo)
        trend_top.addWidget(QLabel("Scope"))
        self.longterm_scope_combo = QComboBox()
        self.longterm_scope_combo.addItems(["Steady-state (state-aware)", "Event-only", "Whole file"])
        self.longterm_scope_combo.setCurrentText("Steady-state (state-aware)")
        trend_top.addWidget(self.longterm_scope_combo)
        trend_top.addWidget(QLabel("State"))
        self.longterm_state_combo = QComboBox()
        self.longterm_state_combo.addItems(["Auto (recommended)", "All circulation states"])
        trend_top.addWidget(self.longterm_state_combo)
        trend_top.addWidget(QLabel("Trim edges"))
        self.longterm_trim_spin = QDoubleSpinBox()
        self.longterm_trim_spin.setRange(0.0, 120.0)
        self.longterm_trim_spin.setDecimals(1)
        self.longterm_trim_spin.setSingleStep(1.0)
        self.longterm_trim_spin.setValue(5.0)
        self.longterm_trim_spin.setSuffix(" s")
        self.longterm_trim_spin.setToolTip("Exclude this many seconds from the start and end of each contiguous operating-state block.")
        trend_top.addWidget(self.longterm_trim_spin)
        self.longterm_spread_check = QCheckBox("Show P25–P75 / Min–Max")
        self.longterm_spread_check.setChecked(True)
        trend_top.addWidget(self.longterm_spread_check)
        trend_top.addStretch()
        trend_layout.addLayout(trend_top)
        self.longterm_summary_label = QLabel("Load and analyze at least 2 files for long-term trend analysis.")
        self.longterm_summary_label.setWordWrap(True)
        trend_layout.addWidget(self.longterm_summary_label)
        self.longterm_chart = LongTermTrendWidget()
        trend_layout.addWidget(self.longterm_chart, 1)
        self.longterm_corr_label = QLabel("Min DO vs Max Vacuum correlation: load and analyze at least 2 files.")
        self.longterm_corr_label.setWordWrap(True)
        trend_layout.addWidget(self.longterm_corr_label)
        self.longterm_corr_chart = CorrelationScatterWidget()
        trend_layout.addWidget(self.longterm_corr_chart)
        self.longterm_table = QTableWidget(0, 16)
        self.longterm_table.setHorizontalHeaderLabels(["Date", "File", "Representative", "P25", "P75", "Min", "Max", "N", "Valid time", "Scope", "State", "Events", "UP", "FLAT", "DOWN", "Date source"])
        trend_layout.addWidget(self.longterm_table)
        self.tabs.addTab(trend_page, "Long-term Trend")

        # HP / Replacement and Forecast tabs were removed from the visible UI.
        self.hp_text = QTextEdit(); self.hp_text.hide()
        self.repl_text = QTextEdit(); self.repl_text.hide()
        self.forecast_btn = QPushButton("Create Simple Forecast"); self.forecast_btn.hide()
        self.forecast_text = QTextEdit(); self.forecast_text.hide(); self.forecast_text.setReadOnly(True)

        self.btn_toggle_controls.toggled.connect(self.set_control_panel_expanded)
        self.btn_files.clicked.connect(self.select_files)
        self.btn_folder.clicked.connect(self.select_folder)
        self.btn_export.clicked.connect(self.export_csv)
        self.btn_save.clicked.connect(self.save_project)
        self.btn_load.clicked.connect(self.load_project)
        self.forecast_btn.clicked.connect(self.create_forecast)
        self.cb_all.stateChanged.connect(self.set_all_chart_items)
        for cb in [self.cb_do,self.cb_vac,self.cb_sf,self.cb_pf,self.cb_chiller,self.cb_xd_temp,self.cb_abs,self.cb_dyn,self.cb_pressure_setpoint,self.cb_water_volume,self.cb_calc_water_volume,self.cb_events,self.cb_non_events,self.cb_value_popup]: cb.stateChanged.connect(self.refresh_chart_options)
        self.longterm_metric_combo.currentTextChanged.connect(self.refresh_longterm_trend)
        self.longterm_stat_combo.currentTextChanged.connect(self.refresh_longterm_trend)
        self.longterm_scope_combo.currentTextChanged.connect(self.refresh_longterm_trend)
        self.longterm_state_combo.currentTextChanged.connect(self.refresh_longterm_trend)
        self.longterm_trim_spin.valueChanged.connect(self.refresh_longterm_trend)
        self.longterm_spread_check.stateChanged.connect(self.refresh_longterm_trend)
        self.chart_file_combo.currentIndexChanged.connect(self.on_chart_file_changed)
        self.btn_prev_chart_file.clicked.connect(lambda: self.step_chart_file(-1))
        self.btn_next_chart_file.clicked.connect(lambda: self.step_chart_file(1))
        self.btn_reload_chart_file.clicked.connect(self.reload_current_chart_file)
        self.btn_apply_zoom.clicked.connect(self.apply_x_zoom)
        self.btn_reset_zoom.clicked.connect(self.reset_x_zoom)
        self.btn_toggle_range.toggled.connect(self.set_range_panel_expanded)
        self.cb_range_enable.toggled.connect(self.refresh_range_mode)
        self.cb_range_overlay.toggled.connect(self.refresh_range_mode)
        self.range_parameter_combo.currentTextChanged.connect(self.on_range_parameter_changed)
        self.btn_range_clear.clicked.connect(self.clear_range_analysis)
        self.btn_range_copy.clicked.connect(self.copy_range_result)
        self.btn_range_export.clicked.connect(self.export_range_csv)
        self.result_table.itemSelectionChanged.connect(self.on_result_selected)

        # Start compact so the chart receives the largest possible area.
        self.btn_toggle_controls.setChecked(False)
        self.set_control_panel_expanded(False)

    def set_control_panel_expanded(self, expanded: bool) -> None:
        self.control_panel.setVisible(expanded)
        self.btn_toggle_controls.setText("▼ Hide Import / Settings" if expanded else "▶ Show Import / Settings")

    def step_chart_file(self, delta: int) -> None:
        count = self.chart_file_combo.count()
        if count <= 0:
            return
        self.chart_file_combo.setCurrentIndex((self.chart_file_combo.currentIndex() + delta) % count)

    def log_msg(self, msg: str) -> None:
        self.log.append(msg)
        self.status.setText(msg)
        if hasattr(self, "compact_file_status"):
            count = len(self.files)
            self.compact_file_status.setText(f"{count} file(s) loaded — {msg}" if count else msg)

    def import_paths(self, paths: List[str]) -> None:
        if not paths:
            return
        # A new import defines a new data generation immediately. Any old analysis
        # can finish/cancel in the background, but its signals are ignored.
        self._analysis_generation += 1
        self._import_generation += 1
        generation = self._import_generation

        if self.worker is not None and self.worker.isRunning():
            self.worker.requestInterruption()
            self._retired_workers.append(self.worker)
            self.worker = None
        if self.import_worker is not None and self.import_worker.isRunning():
            self.import_worker.requestInterruption()
            self._retired_import_workers.append(self.import_worker)
            self.import_worker = None

        self.btn_files.setEnabled(False)
        self.btn_folder.setEnabled(False)
        self.progress.setValue(0)
        self.status.setText("Discovering WaterSystem files...")
        worker = ImportWorker(paths)
        self.import_worker = worker
        worker.progress.connect(lambda p, m, g=generation: self._import_progress(g, p, m))
        worker.completed.connect(lambda files, msgs, roots, g=generation, w=worker: self._import_finished(g, w, files, msgs, roots))
        worker.failed.connect(lambda msg, g=generation, w=worker: self._import_failed(g, w, msg))
        worker.cancelled.connect(lambda w=worker: self._import_cancelled(w))
        worker.start()

    def _import_progress(self, generation: int, percent: int, message: str) -> None:
        if generation != self._import_generation:
            return
        if percent >= 0:
            self.progress.setValue(percent)
        self.status.setText(message)

    def _release_import_worker(self, worker: ImportWorker) -> None:
        if self.import_worker is worker:
            self.import_worker = None
        if worker in self._retired_import_workers:
            self._retired_import_workers.remove(worker)

    def _import_cancelled(self, worker: ImportWorker) -> None:
        self._release_import_worker(worker)

    def _import_failed(self, generation: int, worker: ImportWorker, msg: str) -> None:
        self._release_import_worker(worker)
        if generation != self._import_generation:
            return
        self.btn_files.setEnabled(True)
        self.btn_folder.setEnabled(True)
        QMessageBox.critical(self, APP_NAME, msg)

    def _import_finished(self, generation: int, worker: ImportWorker, discovered: List[str], messages: List[str], temp_roots: List[str]) -> None:
        self._release_import_worker(worker)
        if generation != self._import_generation:
            for root in temp_roots:
                shutil.rmtree(root, ignore_errors=True)
            return
        if not discovered:
            for root in temp_roots:
                shutil.rmtree(root, ignore_errors=True)
            self.btn_files.setEnabled(True)
            self.btn_folder.setEnabled(True)
            QMessageBox.warning(self, APP_NAME, "No matching WaterSystem log files were found.")
            for msg in messages:
                self.log_msg(msg)
            return

        # New accepted ZIP roots belong to this session. Old roots can now be
        # removed only if no retired analysis still has them open.
        if not any(w.isRunning() for w in self._retired_workers):
            for root in self._temp_roots:
                shutil.rmtree(root, ignore_errors=True)
            self._temp_roots.clear()
        self._temp_roots.extend(temp_roots)
        self.files = list(dict.fromkeys(discovered))
        self.results = []
        self.summaries = []
        self.current_samples = []
        self.sample_cache.clear()
        self.refresh_longterm_trend()
        self.populate_chart_file_combo()
        self.chart.set_samples([], "Analyzing...", [])
        for msg in messages:
            self.log_msg(msg)
        self.log_msg(f"Ready: {len(self.files)} WaterSystem file(s). Starting analysis automatically...")
        self.status.setText("Starting analysis...")
        QTimer.singleShot(0, self.analyze)

    def dragEnterEvent(self, event) -> None:
        if event.mimeData().hasUrls() and any(url.isLocalFile() for url in event.mimeData().urls()):
            event.acceptProposedAction()
            self.drop_hint.setStyleSheet("QLabel { border: 2px solid #4b8bd8; border-radius: 8px; background: #eaf3ff; color: #204f80; font-weight: 700; padding: 8px; }")
        else:
            event.ignore()

    def dragLeaveEvent(self, event) -> None:
        self.drop_hint.setStyleSheet("QLabel { border: 2px dashed #8a9aaa; border-radius: 8px; background: #f5f8fb; color: #405060; font-weight: 600; padding: 8px; }")
        super().dragLeaveEvent(event)

    def dropEvent(self, event) -> None:
        self.drop_hint.setStyleSheet("QLabel { border: 2px dashed #8a9aaa; border-radius: 8px; background: #f5f8fb; color: #405060; font-weight: 600; padding: 8px; }")
        paths = [url.toLocalFile() for url in event.mimeData().urls() if url.isLocalFile()]
        if paths:
            event.acceptProposedAction()
            self.import_paths(paths)
        else:
            event.ignore()

    def closeEvent(self, event) -> None:
        if not RELEASE_MODE and getattr(self, "guide_manager", None) is not None:
            self.guide_manager.handle_close_event(event, self._cleanup_before_close)
        else:
            self._cleanup_before_close()
            event.accept()

    def select_files(self) -> None:
        files, _ = QFileDialog.getOpenFileNames(self, "Select WaterSystem logs or ZIP archives", "", "Supported files (*.txt *.log *.csv *.zip);;ZIP archives (*.zip);;Log files (*.txt *.log *.csv);;All files (*.*)")
        if files:
            self.import_paths(files)

    def select_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Select folder")
        if folder:
            self.import_paths([folder])

    def analyze(self) -> None:
        if not self.files:
            return
        if self.worker is not None and self.worker.isRunning():
            return
        generation = self._analysis_generation
        files_snapshot = list(self.files)
        self.btn_files.setEnabled(False)
        self.btn_folder.setEnabled(False)
        self.progress.setValue(0)
        worker = AnalyzeWorker(files_snapshot, self.sp_min_do.value(), self.sp_band.value(), self.sp_flat.value())
        self.worker = worker
        worker.progress.connect(lambda p, m, g=generation: self._analysis_progress(g, p, m))
        worker.finished.connect(lambda r, s, c, e, g=generation, w=worker: self.analysis_finished(g, w, r, s, c, e))
        worker.failed.connect(lambda m, g=generation, w=worker: self.analysis_failed(g, w, m))
        worker.cancelled.connect(lambda w=worker: self._release_worker(w))
        worker.start()

    def _analysis_progress(self, generation: int, percent: int, message: str) -> None:
        if generation != self._analysis_generation:
            return
        self.progress.setValue(percent)
        self.status.setText(message)

    def _release_worker(self, worker: AnalyzeWorker) -> None:
        if self.worker is worker:
            self.worker = None
        if worker in self._retired_workers:
            self._retired_workers.remove(worker)

    def analysis_finished(self, generation: int, worker: AnalyzeWorker, results: list, summaries: list, sample_cache: dict, errors: str) -> None:
        self._release_worker(worker)
        if generation != self._analysis_generation:
            return
        self.results = results
        self.summaries = summaries
        self.sample_cache = {str(Path(k).resolve()): v for k, v in sample_cache.items()}
        self.populate_tables()
        self.refresh_longterm_trend()
        self.btn_files.setEnabled(True)
        self.btn_folder.setEnabled(True)
        if self.files:
            self.load_chart_file(self.files[0])
        self.log_msg(f"Completed. Events: {len(results)} Files: {len(summaries)}")
        self.tabs.setCurrentIndex(2)
        self.btn_toggle_controls.setChecked(False)
        if errors:
            self.log_msg("Errors:\n" + errors)

    def analysis_failed(self, generation: int, worker: AnalyzeWorker, msg: str) -> None:
        self._release_worker(worker)
        if generation != self._analysis_generation:
            return
        self.btn_files.setEnabled(True)
        self.btn_folder.setEnabled(True)
        QMessageBox.critical(self, APP_NAME, msg)

    def fmt(self, v: Optional[float], nd: int = 2) -> str:
        return "" if v is None else f"{v:.{nd}f}"

    def populate_tables(self) -> None:
        self.result_table.setRowCount(len(self.results))
        for r, item in enumerate(self.results):
            vals = [item.file_name,item.event_type,str(item.event_no),item.start_time,item.end_time,self.fmt(item.duration_min,1),self.fmt(item.max_do),self.fmt(item.min_do),self.fmt(item.do_change),self.fmt(item.high_do_vac),self.fmt(item.low_do_vac),self.fmt(item.vac_diff),item.vacuum_trend,self.fmt(item.second_flow_avg),item.note]
            for c, v in enumerate(vals):
                cell = QTableWidgetItem(v)
                if c == 12:
                    if v == "UP": cell.setBackground(QColor(220, 255, 220))
                    elif v == "DOWN": cell.setBackground(QColor(255, 220, 220))
                    elif v == "FLAT": cell.setBackground(QColor(245, 245, 210))
                self.result_table.setItem(r, c, cell)
        self.result_table.resizeColumnsToContents()
        self.summary_table.setRowCount(len(self.summaries))
        for r, s in enumerate(self.summaries):
            vals = [s.file_name,str(s.sample_count),str(s.event_count),str(s.up_count),str(s.flat_count),str(s.down_count),str(s.na_count),s.file_path]
            for c, v in enumerate(vals): self.summary_table.setItem(r,c,QTableWidgetItem(v))
        self.summary_table.resizeColumnsToContents()

    @staticmethod
    def _percentile(values: List[float], pct: float) -> Optional[float]:
        """Linear-interpolated percentile for a finite numeric series."""
        vals = sorted(float(v) for v in values if v is not None and math.isfinite(float(v)))
        if not vals:
            return None
        if len(vals) == 1:
            return vals[0]
        pos = (len(vals) - 1) * pct
        lo = int(math.floor(pos)); hi = int(math.ceil(pos))
        if lo == hi:
            return vals[lo]
        frac = pos - lo
        return vals[lo] * (1.0 - frac) + vals[hi] * frac

    @staticmethod
    def _is_event_metric(metric: str) -> bool:
        return metric.startswith("Event ")

    def _update_longterm_state_choices(self) -> None:
        if not hasattr(self, "longterm_state_combo"):
            return
        current = self.longterm_state_combo.currentText() or "Auto (recommended)"
        states = sorted({
            (smp.state or "").strip().upper()
            for rows in self.sample_cache.values() for smp in rows
            if (smp.state or "").strip()
        })
        choices = ["Auto (recommended)", "All circulation states"] + states
        self.longterm_state_combo.blockSignals(True)
        self.longterm_state_combo.clear()
        self.longterm_state_combo.addItems(choices)
        self.longterm_state_combo.setCurrentText(current if current in choices else "Auto (recommended)")
        self.longterm_state_combo.blockSignals(False)

    @staticmethod
    def _recommended_longterm_state(metric: str, samples: List[Sample]) -> Optional[str]:
        present = {(s.state or "").strip().upper() for s in samples}
        # Volume is a fill/drain quantity; sensor performance is most comparable
        # in a stable circulation state. Prefer treatment circulation because it
        # is the normal operating condition, then degas, then cleaning circulation.
        if metric in {"WaterVolume (raw)", "Calculated Water Volume"}:
            for candidate in ("FILL", "DRAIN"):
                if candidate in present:
                    return candidate
            return None
        for candidate in ("TREAT_CIRCULATE", "DEGAS_CIRCULATE", "CLEAN_TANK_CIRCULATE", "CLEAN_XD_CIRCULATE"):
            if candidate in present:
                return candidate
        circulation = sorted(x for x in present if "CIRCULATE" in x)
        return circulation[0] if circulation else None

    @staticmethod
    def _event_type_for_state(state: str) -> Optional[str]:
        return classify_state(state or "")

    def _steady_state_samples(self, samples: List[Sample], metric: str, state_choice: str,
                              trim_seconds: float) -> Tuple[List[Sample], str, float]:
        """Select comparable stable samples from contiguous MainState blocks.

        The MainState is the primary gate. The first/last ``trim_seconds`` of
        every contiguous block are excluded so pump start/stop and state-transition
        transients do not dominate long-term comparisons. No arbitrary flow
        threshold is imposed, avoiding device-specific hard-coding.
        """
        if not samples:
            return [], "N/A", 0.0
        choice = (state_choice or "Auto (recommended)").strip()
        if choice == "Auto (recommended)":
            recommended = self._recommended_longterm_state(metric, samples)
            states = {recommended} if recommended else set()
            state_label = recommended or "N/A"
        elif choice == "All circulation states":
            states = {(s.state or "").strip().upper() for s in samples if "CIRCULATE" in (s.state or "").upper()}
            state_label = "All circulation states"
        else:
            states = {choice.upper()}
            state_label = choice.upper()
        if not states:
            return [], state_label, 0.0

        selected: List[Sample] = []
        valid_duration = 0.0
        i = 0
        n = len(samples)
        trim_min = max(0.0, float(trim_seconds)) / 60.0
        while i < n:
            state = (samples[i].state or "").strip().upper()
            j = i + 1
            while j < n and (samples[j].state or "").strip().upper() == state:
                j += 1
            if state in states:
                block = samples[i:j]
                if block:
                    start_t = block[0].time_min
                    end_t = block[-1].time_min
                    # WaterSystem logs can theoretically cross midnight.
                    if end_t < start_t:
                        end_t += 1440.0
                    kept: List[Sample] = []
                    for smp in block:
                        t = smp.time_min
                        if t < start_t:
                            t += 1440.0
                        if (t - start_t) + 1e-12 >= trim_min and (end_t - t) + 1e-12 >= trim_min:
                            kept.append(smp)
                    selected.extend(kept)
                    if len(kept) >= 2:
                        a, b = kept[0].time_min, kept[-1].time_min
                        if b < a:
                            b += 1440.0
                        valid_duration += max(0.0, (b - a) * 60.0)
            i = j
        return selected, state_label, valid_duration

    def _event_only_samples(self, samples: List[Sample], state_choice: str) -> Tuple[List[Sample], str, float]:
        choice = (state_choice or "Auto (recommended)").strip()
        if choice in {"Auto (recommended)", "All circulation states"}:
            selected = [s for s in samples if classify_state(s.state) is not None and s.do is not None and is_valid_do(s.do)]
            label = "All detected event states"
        else:
            wanted = choice.upper()
            selected = [s for s in samples if (s.state or "").strip().upper() == wanted and classify_state(s.state) is not None and s.do is not None and is_valid_do(s.do)]
            label = wanted
        duration = 0.0
        for a, b in zip(selected, selected[1:]):
            dt = b.time_min - a.time_min
            if dt < 0:
                dt += 1440.0
            # Do not bridge gaps between separate events/blocks.
            if 0 <= dt <= 0.05 and (a.state or "").strip().upper() == (b.state or "").strip().upper():
                duration += dt * 60.0
        return selected, label, duration

    def _longterm_distribution(self, file_path: str, metric: str, scope: str,
                               state_choice: str, trim_seconds: float) -> Tuple[List[float], str, Dict[str, Any]]:
        """Return the population behind one long-term point plus selection metadata."""
        key = str(Path(file_path).resolve())
        samples = self.sample_cache.get(key, [])
        events = self.events_for_file(file_path)
        event_metric = self._is_event_metric(metric)

        # Event-derived metrics retain the validated EventResult contract and are
        # never recomputed from raw samples. State selection can narrow them.
        if event_metric:
            selected_events = events
            choice = (state_choice or "Auto (recommended)").strip()
            event_state_label = "All event types"
            if metric == "Event DO Decrease Rate" and choice == "Auto (recommended)":
                # For longitudinal rate comparison, keep operating conditions comparable.
                # Prefer treatment events, then degas, then cleaning events.
                available = {e.event_type for e in events}
                preferred = next((x for x in (STATE_TREAT, STATE_DEGAS, STATE_CLEAN_TANK, STATE_CLEAN_XD) if x in available), None)
                if preferred is not None:
                    selected_events = [e for e in events if e.event_type == preferred]
                    event_state_label = f"{preferred} (auto)"
            elif choice not in {"Auto (recommended)", "All circulation states"}:
                etype = self._event_type_for_state(choice)
                if etype is not None:
                    selected_events = [e for e in events if e.event_type == etype]
                    event_state_label = choice.upper()
            valid_duration = sum(max(0.0, float(e.duration_min)) * 60.0 for e in selected_events)
            meta = {"scope": "Event-only", "state": event_state_label, "valid_duration_sec": valid_duration}
            if metric == "Event DO Change":
                return [float(e.do_change) for e in selected_events if e.do_change is not None and math.isfinite(float(e.do_change))], "ppm", meta
            if metric == "Event DO Decrease Rate":
                return [float(e.do_decrease_rate) for e in selected_events if e.do_decrease_rate is not None and math.isfinite(float(e.do_decrease_rate))], "ppm/min", meta
            if metric == "Event Vacuum Difference":
                return [float(e.vac_diff) for e in selected_events if e.vac_diff is not None and math.isfinite(float(e.vac_diff))], "", meta
            if metric == "Event High-DO Vacuum":
                return [float(e.high_do_vac) for e in selected_events if e.high_do_vac is not None and math.isfinite(float(e.high_do_vac))], "", meta
            if metric == "Event Low-DO Vacuum":
                return [float(e.low_do_vac) for e in selected_events if e.low_do_vac is not None and math.isfinite(float(e.low_do_vac))], "", meta
            if metric == "Event Secondary Flow":
                return [float(e.second_flow_avg) for e in selected_events if e.second_flow_avg is not None and math.isfinite(float(e.second_flow_avg))], "L/min", meta

        # Raw sensor metrics: choose a state-aware population before aggregating.
        effective_scope = scope or "Steady-state (state-aware)"
        if effective_scope == "Whole file":
            selected_samples = samples
            state_label = "All states"
            valid_duration = 0.0
            if len(samples) >= 2:
                a, b = samples[0].time_min, samples[-1].time_min
                if b < a:
                    b += 1440.0
                valid_duration = max(0.0, (b - a) * 60.0)
        elif effective_scope == "Event-only":
            selected_samples, state_label, valid_duration = self._event_only_samples(samples, state_choice)
        else:
            selected_samples, state_label, valid_duration = self._steady_state_samples(samples, metric, state_choice, trim_seconds)
            effective_scope = "Steady-state"

        def finite_samples(attr: str, predicate=None) -> List[float]:
            out: List[float] = []
            for smp in selected_samples:
                value = getattr(smp, attr, None)
                if value is None:
                    continue
                try:
                    fv = float(value)
                except (TypeError, ValueError):
                    continue
                if not math.isfinite(fv):
                    continue
                if predicate is not None and not predicate(fv):
                    continue
                out.append(fv)
            return out

        attr_unit = {
            "DO Level": ("do", "ppm", is_valid_do),
            "Vacuum Level": ("vacuum", "", None),
            "Secondary Flow": ("second_flow", "L/min", None),
            "Primary Flow": ("primary_flow", "L/min", None),
            "Chiller Temperature": ("chiller_temp", "°C", None),
            "XD Temperature": ("xd_temperature", "°C", None),
            "Absolute Pressure": ("absolute_pressure", "", None),
            "Dynamic Pressure": ("dynamic_pressure", "", None),
            "Pressure Set Point": ("pressure_set_point", "", None),
            "WaterVolume (raw)": ("water_volume", "", None),
            "Calculated Water Volume": ("calculated_water_volume", "L", None),
        }
        meta = {"scope": effective_scope, "state": state_label, "valid_duration_sec": valid_duration}
        if metric in attr_unit:
            attr, unit, predicate = attr_unit[metric]
            return finite_samples(attr, predicate), unit, meta
        return [], "", meta

    def _longterm_metric_point(self, file_path: str, metric: str, stat: str, scope: str,
                               state_choice: str, trim_seconds: float) -> Tuple[Dict[str, Any], str]:
        vals, unit, meta = self._longterm_distribution(file_path, metric, scope, state_choice, trim_seconds)
        if vals:
            ordered = sorted(vals)
            stats = {
                "mean": statistics.fmean(ordered),
                "median": statistics.median(ordered),
                "min": ordered[0],
                "max": ordered[-1],
                "p25": self._percentile(ordered, 0.25),
                "p75": self._percentile(ordered, 0.75),
                "n": float(len(ordered)),
            }
            key = stat.strip().lower()
            value = stats.get(key)
            return {"value": value, **stats, **meta}, unit

        # Metrics that already represent one file-level quantity do not need aggregation.
        key = str(Path(file_path).resolve())
        summary = next((x for x in self.summaries if str(Path(x.file_path).resolve()) == key), None)
        events = self.events_for_file(file_path)
        value: Optional[float] = None
        unit = ""
        if metric == "UP Rate":
            judged = (summary.up_count + summary.flat_count + summary.down_count) if summary else 0
            value = (summary.up_count / judged * 100.0) if judged else None
            unit = "%"
        elif metric == "DOWN Rate":
            judged = (summary.up_count + summary.flat_count + summary.down_count) if summary else 0
            value = (summary.down_count / judged * 100.0) if judged else None
            unit = "%"
        elif metric == "Event Count":
            value = float(summary.event_count) if summary else float(len(events))
            unit = "events"
        return {"value": value, "mean": value, "median": value, "min": value, "max": value,
                "p25": value, "p75": value, "n": 1.0 if value is not None else 0.0,
                "scope": "File summary", "state": "N/A", "valid_duration_sec": 0.0}, unit

    def refresh_longterm_correlation(self, scope: str, state_choice: str, trim_seconds: float) -> None:
        if not hasattr(self, "longterm_corr_chart"):
            return
        points: List[Dict[str, Any]] = []
        for f in self.files:
            key = str(Path(f).resolve())
            if key not in self.sample_cache:
                continue
            do_data, x_unit = self._longterm_metric_point(f, "DO Level", "Min", scope, state_choice, trim_seconds)
            vac_data, y_unit = self._longterm_metric_point(f, "Vacuum Level", "Max", scope, state_choice, trim_seconds)
            x = do_data.get("value")
            y = vac_data.get("value")
            if x is None or y is None:
                continue
            try:
                xf, yf = float(x), float(y)
            except (TypeError, ValueError):
                continue
            if not (math.isfinite(xf) and math.isfinite(yf)):
                continue
            dt, source = parse_measurement_datetime(f)
            points.append({
                "dt": dt, "file": f, "date_source": source,
                "x": xf, "y": yf, "x_unit": x_unit, "y_unit": y_unit,
                "scope": do_data.get("scope", vac_data.get("scope", "")),
                "state": do_data.get("state", vac_data.get("state", "")),
                "valid_duration_sec": min(float(do_data.get("valid_duration_sec") or 0.0), float(vac_data.get("valid_duration_sec") or 0.0)),
            })
        points.sort(key=lambda p: (p["dt"], p["file"]))
        self.longterm_corr_chart.set_data(points, "Minimum DO Level", "Maximum Vacuum")
        if len(points) < 2:
            self.longterm_corr_label.setText("Min DO vs Max Vacuum correlation: load and analyze at least 2 files with valid values.")
            return
        xs = [float(p['x']) for p in points]
        ys = [float(p['y']) for p in points]
        xm = statistics.fmean(xs); ym = statistics.fmean(ys)
        denom_x = sum((x - xm) ** 2 for x in xs)
        denom_y = sum((y - ym) ** 2 for y in ys)
        corr = None
        if denom_x > 0 and denom_y > 0:
            corr = sum((x - xm) * (y - ym) for x, y in zip(xs, ys)) / math.sqrt(denom_x * denom_y)
        slope = intercept = None
        if denom_x > 0:
            slope = sum((x - xm) * (y - ym) for x, y in zip(xs, ys)) / denom_x
            intercept = ym - slope * xm
        corr_text = "N/A" if corr is None else f"r = {corr:+.3f}"
        fit_text = "N/A" if slope is None else f"Vacuum ≈ {slope:+.3f} × Min DO {intercept:+.3f}"
        self.longterm_corr_label.setText(
            f"Min DO vs Max Vacuum correlation | {len(points)} files | Scope: {scope} | State: {state_choice} | "
            f"{corr_text} | Linear fit: {fit_text} | Each point = one file"
        )

    def refresh_longterm_trend(self) -> None:
        if not hasattr(self, "longterm_metric_combo"):
            return
        self._update_longterm_state_choices()
        metric = self.longterm_metric_combo.currentText() or "Event DO Change"
        stat = self.longterm_stat_combo.currentText() or "Median"
        scope = self.longterm_scope_combo.currentText() or "Steady-state (state-aware)"
        state_choice = self.longterm_state_combo.currentText() or "Auto (recommended)"
        trim_seconds = float(self.longterm_trim_spin.value())
        distribution_metric = metric not in {"UP Rate", "DOWN Rate", "Event Count"}
        event_metric = self._is_event_metric(metric)
        self.longterm_stat_combo.setEnabled(distribution_metric)
        self.longterm_spread_check.setEnabled(distribution_metric)
        self.longterm_scope_combo.setEnabled(not event_metric and distribution_metric)
        self.longterm_state_combo.setEnabled(distribution_metric)
        self.longterm_trim_spin.setEnabled(distribution_metric and not event_metric and scope == "Steady-state (state-aware)")
        self.refresh_longterm_correlation(scope if not event_metric else "Event-only", state_choice, trim_seconds)
        points: List[Dict[str, Any]] = []
        unit = ""
        summary_by_path = {str(Path(s.file_path).resolve()): s for s in self.summaries}
        for f in self.files:
            key = str(Path(f).resolve())
            if key not in self.sample_cache:
                continue
            metric_data, this_unit = self._longterm_metric_point(f, metric, stat, scope, state_choice, trim_seconds)
            unit = this_unit or unit
            dt, source = parse_measurement_datetime(f)
            sm = summary_by_path.get(key)
            points.append({
                "dt": dt, "file": f, "date_source": source,
                "events": sm.event_count if sm else len(self.events_for_file(f)),
                "up": sm.up_count if sm else 0, "flat": sm.flat_count if sm else 0,
                "down": sm.down_count if sm else 0,
                **metric_data,
            })
        points.sort(key=lambda p: (p["dt"], p["file"]))
        representative_label = f"{stat} {metric}" if distribution_metric else metric
        self.longterm_chart.set_data(points, representative_label, unit, self.longterm_spread_check.isChecked() and distribution_metric)
        self.longterm_table.setColumnCount(16)
        self.longterm_table.setHorizontalHeaderLabels([
            "Date", "File", "Representative", "P25", "P75", "Min", "Max", "N",
            "Valid time", "Scope", "State", "Events", "UP", "FLAT", "DOWN", "Date source"
        ])
        self.longterm_table.setRowCount(len(points))
        for r, p in enumerate(points):
            def num(v, nd=3):
                return "N/A" if v is None else f"{float(v):.{nd}f}"
            val_text = num(p.get("value"), 0 if metric == "Event Count" else 3)
            dur = float(p.get("valid_duration_sec") or 0.0)
            valid_time = f"{dur/60.0:.1f} min" if dur >= 60.0 else f"{dur:.1f} s"
            vals_row = [
                p["dt"].strftime("%Y-%m-%d %H:%M:%S"), Path(p["file"]).name, val_text,
                num(p.get("p25")), num(p.get("p75")), num(p.get("min")), num(p.get("max")),
                str(int(p.get("n") or 0)), valid_time, str(p.get("scope") or ""), str(p.get("state") or ""),
                str(p["events"]), str(p["up"]), str(p["flat"]), str(p["down"]), p["date_source"]
            ]
            for c, v in enumerate(vals_row):
                self.longterm_table.setItem(r, c, QTableWidgetItem(v))
        self.longterm_table.resizeColumnsToContents()
        valid = [p for p in points if p.get("value") is not None and math.isfinite(float(p["value"]))]
        if len(valid) < 2:
            self.longterm_summary_label.setText("Load and analyze at least 2 files with valid values for this metric.")
            return
        first, last = valid[0], valid[-1]
        first_v, last_v = float(first["value"]), float(last["value"])
        delta = last_v - first_v
        pct = (delta / abs(first_v) * 100.0) if abs(first_v) > 1e-12 else None
        base = valid[0]["dt"]
        xs = [(p["dt"] - base).total_seconds() / 86400.0 for p in valid]
        ys = [float(p["value"]) for p in valid]
        xm, ym = statistics.fmean(xs), statistics.fmean(ys)
        denom = sum((x - xm) ** 2 for x in xs)
        slope_year = (sum((x - xm) * (y - ym) for x, y in zip(xs, ys)) / denom * 365.2425) if denom > 0 else None
        span_days = (last["dt"] - first["dt"]).total_seconds() / 86400.0
        unit_text = f" {unit}" if unit else ""
        pct_text = "N/A" if pct is None else f"{pct:+.1f}%"
        slope_text = "N/A" if slope_year is None else f"{slope_year:+.3f}{unit_text}/year"
        spread_text = ""
        if distribution_metric:
            spread_text = " | Each point: selected representative; whiskers: Min–Max; thick bar: P25–P75"
        effective_scope_text = "Event-only" if event_metric else scope
        state_text = state_choice
        trim_text = f" | edge trim {trim_seconds:.1f}s" if (not event_metric and scope == "Steady-state (state-aware)") else ""
        self.longterm_summary_label.setText(
            f"{len(valid)} measurements | Representative: {representative_label} | Scope: {effective_scope_text} | State: {state_text}{trim_text} | "
            f"{first['dt'].strftime('%Y-%m-%d')} → {last['dt'].strftime('%Y-%m-%d')} ({span_days:.1f} days) | "
            f"First {first_v:.3f}{unit_text} → Latest {last_v:.3f}{unit_text} | "
            f"Δ {delta:+.3f}{unit_text} ({pct_text}) | Linear trend {slope_text}{spread_text}"
        )

    def populate_chart_file_combo(self) -> None:
        self.chart_file_combo.blockSignals(True)
        self.chart_file_combo.clear()
        for f in self.files:
            self.chart_file_combo.addItem(Path(f).name, f)
        self.chart_file_combo.blockSignals(False)
        self.compact_file_status.setText(f"{len(self.files)} file(s) loaded" if self.files else "No files loaded")

    def events_for_file(self, file_path: str) -> List[EventResult]:
        target = str(Path(file_path).resolve())
        return [r for r in self.results if r.source_path == target]

    def _time_text_to_visible_minutes(self, text: str) -> Optional[float]:
        base = parse_time_minutes(text.strip().replace(".", ":"))
        if base is None:
            # Accept HH:MM:SS.mmm as well.
            m = re.match(r"^(\d{1,2}):(\d{2}):(\d{2})(?:\.(\d{1,3}))?$", text.strip())
            if not m:
                return None
            h, mi, sec, ms = m.groups()
            base = int(h) * 60.0 + int(mi) + int(sec) / 60.0 + int(ms or 0) / 60000.0
        if not self.current_samples:
            return base
        data_min = min(s.time_min for s in self.current_samples)
        data_max = max(s.time_min for s in self.current_samples)
        candidates = [base + 1440.0 * k for k in range(-2, 4)]
        inside = [c for c in candidates if data_min - 0.01 <= c <= data_max + 0.01]
        if inside:
            return min(inside, key=lambda c: abs(c - data_min))
        return min(candidates, key=lambda c: min(abs(c - data_min), abs(c - data_max)))

    def populate_chart_event_table(self, file_path: str) -> None:
        events = self.events_for_file(file_path)
        self.chart_event_table.setRowCount(len(events))
        for r, item in enumerate(events):
            vals = [item.event_type, str(item.event_no), item.start_time, item.end_time,
                    self.fmt(item.duration_min, 1), self.fmt(item.max_do), self.fmt(item.min_do),
                    self.fmt(item.do_change), item.vacuum_trend, self.fmt(item.vac_diff), item.note]
            for c, v in enumerate(vals):
                cell = QTableWidgetItem(v)
                if c == 8:
                    if v == "UP": cell.setBackground(QColor(220, 255, 220))
                    elif v == "DOWN": cell.setBackground(QColor(255, 220, 220))
                    elif v == "FLAT": cell.setBackground(QColor(245, 245, 210))
                self.chart_event_table.setItem(r, c, cell)
        self.chart_event_table.resizeColumnsToContents()

    def update_zoom_text_from_samples(self) -> None:
        if not self.current_samples:
            self.zoom_start.clear(); self.zoom_end.clear(); return
        self.zoom_start.setText(self.chart._format_minutes_as_time(min(s.time_min for s in self.current_samples)))
        self.zoom_end.setText(self.chart._format_minutes_as_time(max(s.time_min for s in self.current_samples)))


    def set_range_panel_expanded(self, expanded: bool) -> None:
        self.range_panel.setVisible(expanded)
        self.btn_toggle_range.setText("▼ Range Analysis" if expanded else "▶ Range Analysis")

    def refresh_range_mode(self) -> None:
        self.chart.set_range_analysis(
            self.cb_range_enable.isChecked(),
            self.range_parameter_combo.currentText(),
            self.cb_range_overlay.isChecked(),
        )
        mode = "range analysis" if self.cb_range_enable.isChecked() else "zoom"
        self.status.setText(f"Chart drag mode: {mode}")

    def on_range_parameter_changed(self, _text: str) -> None:
        self.clear_range_analysis()
        self.refresh_range_mode()

    @staticmethod
    def _range_parameter_value(sample: Sample, parameter: str) -> Optional[float]:
        mapping = {
            "DO Level": sample.do,
            "Vacuum": sample.vacuum,
            "2nd Flow": sample.second_flow,
            "Secondary Flow": sample.second_flow,
            "Primary Flow": sample.primary_flow,
            "Chiller Temperature": sample.chiller_temp,
            "XD Temperature": sample.xd_temperature,
            "Absolute Pressure": sample.absolute_pressure,
            "Dynamic Pressure": sample.dynamic_pressure,
            "Pressure Set Point": sample.pressure_set_point,
            "WaterVolume": sample.water_volume,
            "WaterVolume (raw)": sample.water_volume,
            "Calculated Water Volume (L)": sample.calculated_water_volume,
        }
        value = mapping.get(parameter)
        if value is None or not math.isfinite(value):
            return None
        if parameter == "DO Level" and not is_valid_do(value):
            return None
        if parameter in {"2nd Flow", "Secondary Flow"} and not (SECONDARY_FLOW_PLOT_MIN <= value <= SECONDARY_FLOW_PLOT_MAX):
            return None
        return value

    def on_chart_range_selected(self, start: float, end: float) -> None:
        parameter = self.range_parameter_combo.currentText()
        points = [(s.time_min, self._range_parameter_value(s, parameter)) for s in self.current_samples if start <= s.time_min <= end]
        clean = [(t, v) for t, v in points if v is not None]
        if len(clean) < 2:
            self.current_range_result = None
            self.chart.clear_range_analysis()
            self.range_result_label.setText(f"No sufficient valid {parameter} samples in the selected range.")
            self.status.setText("Range analysis: insufficient samples")
            return
        times = [t for t, _ in clean]
        values = [float(v) for _, v in clean]
        avg = statistics.fmean(values)
        minimum, maximum = min(values), max(values)
        std_dev = statistics.pstdev(values) if len(values) > 1 else 0.0
        rms_noise = math.sqrt(statistics.fmean([(v-avg)**2 for v in values]))
        cv = abs(std_dev / avg * 100.0) if abs(avg) > 1e-12 else 0.0
        xavg = statistics.fmean(times)
        denom = sum((t-xavg)**2 for t in times)
        slope = sum((t-xavg)*(v-avg) for t, v in clean) / denom if denom > 0 else 0.0
        result = {
            "file": Path(str(self.chart_file_combo.currentData() or "")).name,
            "parameter": parameter,
            "start_min": start, "end_min": end,
            "start_time": self.chart._format_minutes_as_time(start),
            "end_time": self.chart._format_minutes_as_time(end),
            "duration_min": end-start, "sample_count": len(values),
            "average": avg, "minimum": minimum, "maximum": maximum,
            "peak_to_peak": maximum-minimum, "std_dev": std_dev,
            "cv_percent": cv, "rms_noise": rms_noise, "slope_per_min": slope,
        }
        self.current_range_result = result
        self.chart.set_range_result(start, end, result)
        self.range_result_label.setText(
            f"{parameter} | {result['start_time']} - {result['end_time']} | "
            f"Avg {avg:.6g}, Min {minimum:.6g}, Max {maximum:.6g}, P-P {maximum-minimum:.6g}, "
            f"StdDev {std_dev:.6g}, CV {cv:.4g}%, RMS noise {rms_noise:.6g}, "
            f"Slope {slope:.6g}/min, Duration {end-start:.3f} min, Samples {len(values)}"
        )
        self.status.setText(f"Range analyzed: {parameter}, {len(values)} samples")

    def clear_range_analysis(self) -> None:
        self.current_range_result = None
        self.chart.clear_range_analysis()
        self.range_result_label.setText("Enable Range Analysis, then drag horizontally across the chart.")

    def _range_result_rows(self) -> List[Tuple[str, Any]]:
        if not self.current_range_result:
            return []
        order = ["file", "parameter", "start_time", "end_time", "duration_min", "sample_count", "average", "minimum", "maximum", "peak_to_peak", "std_dev", "cv_percent", "rms_noise", "slope_per_min"]
        return [(key, self.current_range_result.get(key, "")) for key in order]

    def copy_range_result(self) -> None:
        rows = self._range_result_rows()
        if not rows:
            QMessageBox.information(self, APP_NAME, "Select and analyze a range first.")
            return
        QApplication.clipboard().setText("\n".join(f"{k}: {v}" for k, v in rows))
        self.status.setText("Range analysis result copied")

    def export_range_csv(self) -> None:
        rows = self._range_result_rows()
        if not rows:
            QMessageBox.information(self, APP_NAME, "Select and analyze a range first.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export Range Analysis", "RangeAnalysis.csv", "CSV Files (*.csv)")
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as fh:
            writer = csv.writer(fh)
            writer.writerow([k for k, _ in rows])
            writer.writerow([v for _, v in rows])
        self.status.setText(f"Range CSV exported: {Path(path).name}")

    def on_chart_drag_zoom_selected(self, start: float, end: float) -> None:
        self.zoom_start.setText(self.chart._format_minutes_as_time(start))
        self.zoom_end.setText(self.chart._format_minutes_as_time(end))
        self.status.setText(f"Drag zoom: {self.chart._format_minutes_as_time(start)} - {self.chart._format_minutes_as_time(end)}")

    def apply_x_zoom(self) -> None:
        start = self._time_text_to_visible_minutes(self.zoom_start.text())
        end = self._time_text_to_visible_minutes(self.zoom_end.text())
        if start is None or end is None:
            QMessageBox.warning(self, APP_NAME, "Use time format like HH:MM:SS.000 for zoom start/end.")
            return
        if end <= start:
            end += 1440.0
        self.chart.set_zoom_range(start, end)
        self.status.setText(f"Zoom: {self.chart._format_minutes_as_time(start)} - {self.chart._format_minutes_as_time(end)}")

    def reset_x_zoom(self) -> None:
        self.chart.reset_zoom()
        self.update_zoom_text_from_samples()
        self.status.setText("Zoom reset")

    def load_chart_file(self, file_path: str, force_reload: bool = False) -> None:
        if not file_path:
            return
        try:
            cache_key = str(Path(file_path).resolve())
            if (force_reload or cache_key not in self.sample_cache) and self.worker is not None and self.worker.isRunning():
                self.status.setText(f"Still analyzing {Path(file_path).name}; chart will use the analysis cache when ready.")
                return
            if force_reload or cache_key not in self.sample_cache:
                samples, _ = WaterSystemParser().parse_file(file_path)
                self.sample_cache[cache_key] = samples
            samples = self.sample_cache[cache_key]
            self.current_samples = samples
            fname = Path(file_path).name
            self.chart.set_samples(samples, fname, self.events_for_file(file_path))
            self.current_range_result = None
            self.range_result_label.setText("Enable Range Analysis, then drag horizontally across the chart.")
            self.refresh_range_mode()
            self.populate_chart_event_table(file_path)
            self.update_zoom_text_from_samples()
            # Keep the combo in sync without re-entering this function.
            for i in range(self.chart_file_combo.count()):
                if self.chart_file_combo.itemData(i) == file_path:
                    self.chart_file_combo.blockSignals(True)
                    self.chart_file_combo.setCurrentIndex(i)
                    self.chart_file_combo.blockSignals(False)
                    break
            self.status.setText(f"Chart: {fname}")
        except Exception as e:
            self.log_msg(str(e))

    def on_chart_file_changed(self, index: int = -1) -> None:
        file_path = self.chart_file_combo.currentData()
        if file_path:
            self.load_chart_file(str(file_path))

    def reload_current_chart_file(self) -> None:
        file_path = self.chart_file_combo.currentData()
        if file_path:
            self.load_chart_file(str(file_path), force_reload=True)

    def on_result_selected(self) -> None:
        row = self.result_table.currentRow()
        if row < 0 or row >= len(self.results): return
        item = self.results[row]
        target = item.source_path
        match = next((f for f in self.files if str(Path(f).resolve()) == target), None)
        if match:
            self.load_chart_file(match)
            self.tabs.setCurrentIndex(2)

    def set_all_chart_items(self) -> None:
        checked = self.cb_all.isChecked()
        boxes = [self.cb_do, self.cb_vac, self.cb_sf, self.cb_pf, self.cb_chiller, self.cb_xd_temp, self.cb_abs, self.cb_dyn, self.cb_pressure_setpoint, self.cb_water_volume, self.cb_calc_water_volume, self.cb_events, self.cb_non_events, self.cb_value_popup]
        for cb in boxes:
            cb.blockSignals(True)
            cb.setChecked(checked)
            cb.blockSignals(False)
        self.refresh_chart_options()

    def refresh_chart_options(self) -> None:
        self.chart.show_do = self.cb_do.isChecked()
        self.chart.show_vac = self.cb_vac.isChecked()
        self.chart.show_sf = self.cb_sf.isChecked()
        self.chart.show_primary_flow = self.cb_pf.isChecked()
        self.chart.show_chiller_temp = self.cb_chiller.isChecked()
        self.chart.show_xd_temperature = self.cb_xd_temp.isChecked()
        self.chart.show_absolute_pressure = self.cb_abs.isChecked()
        self.chart.show_dynamic_pressure = self.cb_dyn.isChecked()
        self.chart.show_pressure_setpoint_band = self.cb_pressure_setpoint.isChecked()
        self.chart.show_water_volume = self.cb_water_volume.isChecked()
        self.chart.show_calculated_water_volume = self.cb_calc_water_volume.isChecked()
        self.chart.show_event_markers = self.cb_events.isChecked()
        self.chart.show_non_event_labels = self.cb_non_events.isChecked()
        self.chart.show_value_popup = self.cb_value_popup.isChecked()
        self.chart.update()

    def export_csv(self) -> None:
        if not self.results:
            QMessageBox.information(self, APP_NAME, "No results to export.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export results", "DO_Analysis_Results.csv", "CSV (*.csv)")
        if not path: return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerow(["File","Type","No","Start","End","Duration","Max DO","Min DO","DO Change","High DO Vac","Low DO Vac","Diff","Trend","2nd Flow Avg","Note"])
            for item in self.results:
                writer.writerow([item.file_name,item.event_type,item.event_no,item.start_time,item.end_time,item.duration_min,item.max_do,item.min_do,item.do_change,item.high_do_vac,item.low_do_vac,item.vac_diff,item.vacuum_trend,item.second_flow_avg,item.note])
        self.log_msg(f"Exported: {path}")

    def save_project(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Save project", "DO_Analysis_Project.json", "JSON (*.json)")
        if not path: return
        data = {"version": APP_VERSION, "files": self.files, "hp_master": self.hp_text.toPlainText(), "replacement_history": self.repl_text.toPlainText(), "settings": {"min_do_change": self.sp_min_do.value(), "do_band": self.sp_band.value(), "flat_tol": self.sp_flat.value(), "show_do": self.cb_do.isChecked(), "show_vacuum": self.cb_vac.isChecked(), "show_second_flow": self.cb_sf.isChecked(), "show_primary_flow": self.cb_pf.isChecked(), "show_chiller_temp": self.cb_chiller.isChecked(), "show_xd_temperature": self.cb_xd_temp.isChecked(), "show_absolute_pressure": self.cb_abs.isChecked(), "show_dynamic_pressure": self.cb_dyn.isChecked(), "show_pressure_setpoint_band": self.cb_pressure_setpoint.isChecked(), "show_water_volume": self.cb_water_volume.isChecked(), "show_calculated_water_volume": self.cb_calc_water_volume.isChecked(), "show_events": self.cb_events.isChecked(), "show_non_events": self.cb_non_events.isChecked(), "show_value_popup": self.cb_value_popup.isChecked(), "longterm_metric": self.longterm_metric_combo.currentText(), "longterm_stat": self.longterm_stat_combo.currentText(), "longterm_scope": self.longterm_scope_combo.currentText(), "longterm_state": self.longterm_state_combo.currentText(), "longterm_trim_seconds": self.longterm_trim_spin.value(), "longterm_spread": self.longterm_spread_check.isChecked()}}
        Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        self.log_msg(f"Saved project: {path}")

    def load_project(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Load project", "", "JSON (*.json)")
        if not path: return
        self._analysis_generation += 1
        self._import_generation += 1
        if self.worker is not None and self.worker.isRunning():
            self.worker.requestInterruption()
            self._retired_workers.append(self.worker)
            self.worker = None
        if self.import_worker is not None and self.import_worker.isRunning():
            self.import_worker.requestInterruption()
            self._retired_import_workers.append(self.import_worker)
            self.import_worker = None
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        self.files = data.get("files", [])
        self.hp_text.setPlainText(data.get("hp_master", ""))
        self.repl_text.setPlainText(data.get("replacement_history", ""))
        st = data.get("settings", {})
        self.sp_min_do.setValue(float(st.get("min_do_change", MIN_DO_CHANGE_FOR_VACUUM)))
        self.sp_band.setValue(float(st.get("do_band", DO_AVG_BAND)))
        self.sp_flat.setValue(float(st.get("flat_tol", VACUUM_FLAT_TOLERANCE)))
        self.cb_do.setChecked(bool(st.get("show_do", True)))
        self.cb_vac.setChecked(bool(st.get("show_vacuum", True)))
        self.cb_sf.setChecked(bool(st.get("show_second_flow", True)))
        self.cb_pf.setChecked(bool(st.get("show_primary_flow", False)))
        self.cb_chiller.setChecked(bool(st.get("show_chiller_temp", False)))
        self.cb_xd_temp.setChecked(bool(st.get("show_xd_temperature", False)))
        self.cb_abs.setChecked(bool(st.get("show_absolute_pressure", False)))
        self.cb_dyn.setChecked(bool(st.get("show_dynamic_pressure", False)))
        self.cb_pressure_setpoint.setChecked(bool(st.get("show_pressure_setpoint_band", False)))
        self.cb_water_volume.setChecked(bool(st.get("show_water_volume", False)))
        self.cb_calc_water_volume.setChecked(bool(st.get("show_calculated_water_volume", False)))
        self.cb_events.setChecked(bool(st.get("show_events", True)))
        self.cb_non_events.setChecked(bool(st.get("show_non_events", False)))
        self.cb_value_popup.setChecked(bool(st.get("show_value_popup", True)))
        metric_text = str(st.get("longterm_metric", "Event DO Change"))
        stat_text = str(st.get("longterm_stat", "Median"))
        # Backward compatibility with projects saved by v14.
        legacy_metric_map = {
            "Mean DO": ("DO Level", "Mean"), "Minimum DO": ("DO Level", "Min"),
            "Maximum DO": ("DO Level", "Max"), "Mean Event DO Change": ("Event DO Change", "Mean"),
            "Mean Event Secondary Flow": ("Event Secondary Flow", "Mean"),
            "Max Calculated Water Volume": ("Calculated Water Volume", "Max"),
        }
        if metric_text in legacy_metric_map:
            metric_text, stat_text = legacy_metric_map[metric_text]
        metric_index = self.longterm_metric_combo.findText(metric_text)
        if metric_index >= 0: self.longterm_metric_combo.setCurrentIndex(metric_index)
        stat_index = self.longterm_stat_combo.findText(stat_text)
        if stat_index >= 0: self.longterm_stat_combo.setCurrentIndex(stat_index)
        scope_text = str(st.get("longterm_scope", "Steady-state (state-aware)"))
        scope_index = self.longterm_scope_combo.findText(scope_text)
        if scope_index >= 0: self.longterm_scope_combo.setCurrentIndex(scope_index)
        self._update_longterm_state_choices()
        state_text = str(st.get("longterm_state", "Auto (recommended)"))
        state_index = self.longterm_state_combo.findText(state_text)
        if state_index >= 0: self.longterm_state_combo.setCurrentIndex(state_index)
        self.longterm_trim_spin.setValue(float(st.get("longterm_trim_seconds", 5.0)))
        self.longterm_spread_check.setChecked(bool(st.get("longterm_spread", True)))
        self.cb_all.blockSignals(True)
        self.cb_all.setChecked(all([self.cb_do.isChecked(), self.cb_vac.isChecked(), self.cb_sf.isChecked(), self.cb_pf.isChecked(), self.cb_chiller.isChecked(), self.cb_xd_temp.isChecked(), self.cb_abs.isChecked(), self.cb_dyn.isChecked(), self.cb_water_volume.isChecked(), self.cb_calc_water_volume.isChecked(), self.cb_events.isChecked(), self.cb_non_events.isChecked(), self.cb_value_popup.isChecked()]))
        self.cb_all.blockSignals(False)
        self.results = []
        self.summaries = []
        self.current_samples = []
        self.sample_cache.clear()
        self.refresh_longterm_trend()
        self.populate_chart_file_combo()
        self.refresh_chart_options()
        self.log_msg(f"Loaded project: {path}")
        if self.files:
            self.chart.set_samples([], "Analyzing...", [])
            QTimer.singleShot(0, self.analyze)

    def create_forecast(self) -> None:
        text = self.repl_text.toPlainText().strip()
        if not text:
            self.forecast_text.setPlainText("No replacement history. Paste or import CSV text first.")
            return
        rows = list(csv.DictReader(text.splitlines()))
        failure = [r for r in rows if r.get("Type", "").strip().lower().startswith("fail")]
        preventive = [r for r in rows if r.get("Type", "").strip().lower().startswith("prev")]
        out = []
        out.append("Simple Forecast Summary")
        out.append(f"Failure replacements only: {len(failure)}")
        out.append(f"Failure + preventive replacements: {len(failure) + len(preventive)}")
        by_hp: Dict[str, int] = {}
        for r in failure:
            hp = r.get("HP", "Unknown") or "Unknown"
            by_hp[hp] = by_hp.get(hp, 0) + 1
        out.append("\nFailure count by HP:")
        for hp, cnt in sorted(by_hp.items(), key=lambda x: (-x[1], x[0])):
            out.append(f"  {hp}: {cnt}")
        self.forecast_text.setPlainText("\n".join(out))


def main() -> int:
    from insightec_handoff import load_handoff
    handoff = load_handoff("do_analysis")
    app = QApplication(sys.argv)
    w = MainWindow()
    w.show()
    if handoff and handoff.auto_load:
        paths = [str(path) for path in handoff.input_paths()]
        if not paths and handoff.workspace():
            paths = [str(handoff.workspace())]
        handoff.mark("do_analysis", "accepted", input_count=len(paths))
        if paths:
            QTimer.singleShot(0, lambda values=paths: w.import_paths(values))
    return app.exec()

if __name__ == "__main__":
    raise SystemExit(main())
