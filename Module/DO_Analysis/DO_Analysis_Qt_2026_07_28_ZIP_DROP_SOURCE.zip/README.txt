DO Analysis Qt Windows App - ZIP Drop Import
Version: 2026.07.28

Run from source:
  run_app.bat

Build EXE on Windows / GitHub Actions runner:
  build_exe.bat

Fallback build:
  build_pyinstaller_fallback.bat

ZIP / file import:
- Drop one or more ZIP archives, folders, or WaterSystem log files onto the dashed drop area or main window.
- ZIP archives are extracted to a temporary folder.
- The app recursively scans ZIP contents and loads only files that contain the required WaterSystem header/columns.
- Supported candidate extensions: .txt, .log, .csv.
- Temporary ZIP contents are removed when the app closes.
- ZIP path traversal entries are blocked.

Chart updates:
- Drag on chart to zoom X-axis.
- Reset Zoom returns to full range.
- Event Results for the displayed file are shown below the chart.
- ALL checkbox toggles all chart display items.
- Non-event labels checkbox shows PAUSE, INIT, WAIT, DRAIN, FILL, ERROR, etc.
- Treat/Clean event labels checkbox controls analyzed event ranges and labels.
