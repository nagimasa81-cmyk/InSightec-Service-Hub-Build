# GitHub Build Guide

1. Place this source folder in the target module directory.
2. Configure the Windows GitHub Actions job to run `01_BUILD_EXE_NUITKA.bat`.
3. Upload `dist/DO_Analysis_Qt_Ver1_0_1j.exe` as the build artifact.

The legacy entry point `build_exe.bat` remains available and calls the same build script.
