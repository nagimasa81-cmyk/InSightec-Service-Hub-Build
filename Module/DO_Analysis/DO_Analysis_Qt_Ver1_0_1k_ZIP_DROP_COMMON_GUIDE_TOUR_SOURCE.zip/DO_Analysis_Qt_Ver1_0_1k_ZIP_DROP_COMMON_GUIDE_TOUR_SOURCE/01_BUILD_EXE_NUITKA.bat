@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ============================================================
echo DO Analysis Qt Ver1.0.1k - Nuitka Build
echo ============================================================

where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python was not found in PATH.
  exit /b 1
)

python -m pip install --upgrade pip
if errorlevel 1 exit /b 1
python -m pip install -r requirements.txt
if errorlevel 1 exit /b 1

for %%D in (build dist main.build main.dist main.onefile-build) do (
  if exist "%%D" rmdir /s /q "%%D"
)

python -m nuitka ^
  --standalone ^
  --onefile ^
  --enable-plugin=pyside6 ^
  --windows-console-mode=disable ^
  --assume-yes-for-downloads ^
  --output-dir=dist ^
  --output-filename="DO_Analysis_Qt_Ver1_0_1k.exe" ^
  main.py
if errorlevel 1 (
  echo [ERROR] Build failed.
  exit /b 1
)

echo [SUCCESS] dist\DO_Analysis_Qt_Ver1_0_1k.exe
exit /b 0
