# DO Analysis Qt Ver1.0.1k — ZIP Drop + Common Guide/Tour

## Added in 1.0.1k

- Common `GuideManager` library.
- Startup prompt: **Yes — Show Guide** / **No — Do Not Ask Again**.
- Six-page DO Analysis Quick Guide and Guided Tour viewer.
- Help menu for opening the guide at any time.
- Help action to show the guide once at the next startup.
- Exit confirmation with **Show the guide and guided tour at the next startup**.
- Persistent settings stored under `%APPDATA%\InSightec\DO_Analysis\settings.json`.
- Cancel in the exit dialog keeps the application open.

## ZIP and file loading

- Drag and drop `.zip`, `.txt`, `.log`, `.csv`, or folders anywhere on the application window.
- ZIP archives and folders are searched recursively.
- Only WaterSystem-compatible files containing `MainState` and `DOLevel` are loaded.
- Unsupported and unrelated files are skipped with a clear message.
- ZIP path traversal protection and automatic temporary-folder cleanup.

## Run from source

Run `02_RUN_PYTHON_DEBUG.bat`.

## Build EXE locally or in GitHub Actions

Run `01_BUILD_EXE_NUITKA.bat` or `build_exe.bat`.

Expected local output:

`dist\DO_Analysis_Qt_Ver1_0_1k.exe`

The included `version.json` is compatible with the R4 GitHub Actions workflow using:

- Module folder: `Module/DO_Analysis`
- Build engine: `auto`
- Entry-point override: blank
