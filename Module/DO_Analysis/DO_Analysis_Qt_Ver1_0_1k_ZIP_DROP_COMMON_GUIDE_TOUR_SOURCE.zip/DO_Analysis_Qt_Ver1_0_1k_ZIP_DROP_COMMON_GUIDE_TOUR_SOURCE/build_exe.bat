@echo off
call "%~dp001_BUILD_EXE_NUITKA.bat"
exit /b %errorlevel%
