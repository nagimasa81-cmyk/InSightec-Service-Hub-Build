# FUS Treatment Replay Prototype v0.4.0

RC1 GitHub Actions compatible source package.

## Current prototype scope
- Direct import of a treatment ZIP
- Per-sonication DQA / Treatment classification
- Per-sonication MR plane and frequency-direction mapping
- Replay plane normalized to Axial / Sagittal / Coronal
- Oblique source geometry retained as evidence and mapped to the nearest basic plane
- DQA example phantom images for all three planes
- Treatment example T2 brain images for all three planes when patient DICOM is not linked
- External MR/DICOM folder mapping saved to a sidecar JSON
- Spectrum, hydrophone simulation, timeline, review.out, mrserver and timing evidence views

Example images are synthetic placeholders and are always labeled `EXAMPLE` / `NO PATIENT MR LOADED`.
This software is for review/research prototyping only and is not for clinical decisions.
