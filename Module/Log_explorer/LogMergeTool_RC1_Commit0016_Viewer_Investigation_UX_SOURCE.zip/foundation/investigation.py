"""RC1 Investigation Mode embedded in the existing Log Viewer.

The mode reuses the existing viewer parser interface. It provides synchronized
log tables plus a lightweight WaterSystem chart without launching another EXE.
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from PySide6.QtCore import Qt, Signal, QPointF, QRectF
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QFileDialog, QHBoxLayout, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QPushButton, QSplitter, QTableWidget,
    QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget, QHeaderView, QMessageBox,
    QTabWidget, QProgressDialog, QApplication,
)

TEMPLATES = {
    "Initial Investigation": ["WS", "CSA", "CGA"],
    "Water Investigation": ["WS", "CSA", "CGA", "WaterSystem"],
    "MR Investigation": ["WS", "MRSERVER", "GESYS"],
    "Sonication Investigation": ["WS", "CSA", "CGA", "MRSERVER", "GESYS", "VIMeasure"],
}

CRITICAL_WORDS = (
    "fatal", "error", "watchdog", "restart", "failed", "failure",
    "alarm", "exception", "critical", "timeout",
)
WARNING_WORDS = ("warning", "warn", "retry", "degraded")


def _record_timestamp(record: Any) -> datetime | None:
    return getattr(record, "timestamp", None) or getattr(record, "ts", None)


def _record_message(record: Any) -> str:
    return str(getattr(record, "message", "") or getattr(record, "raw", ""))


def _record_line(record: Any) -> int:
    try:
        return int(getattr(record, "line_number", 0) or getattr(record, "line_no", 0) or getattr(record, "line", 0))
    except Exception:
        return 0


def _level(message: str, existing: str = "") -> str:
    if existing:
        return existing
    lower = message.lower()
    if any(word in lower for word in CRITICAL_WORDS):
        return "Critical"
    if any(word in lower for word in WARNING_WORDS):
        return "Warning"
    return ""


def _structured_fields(record: Any) -> dict[str, Any]:
    raw = getattr(record, "raw", "")
    if not raw:
        return {}
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


class WaterSystemChart(QWidget):
    timeSelected = Signal(datetime)

    SERIES = [
        ("DOLevel", "DO Level"),
        ("VacuumLevel", "Vacuum"),
        ("PrimaryFlowMeter", "Primary Flow"),
        ("SecondaryFlowMeter", "Secondary Flow"),
        ("ChillerTemp", "Chiller Temp"),
        ("XdTemperature", "XD Temp"),
        ("4vI", "4vI"), ("4vV", "4vV"),
        ("-6vI", "-6vI"), ("-6vV", "-6vV"),
        ("6vI", "6vI"), ("6vV", "6vV"),
        ("FE_48vI", "FE 48vI"), ("FE_48vV", "FE 48vV"),
        ("ER_48vI", "ER 48vI"), ("ER_48vV", "ER 48vV"),
    ]

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.records: list[Any] = []
        self.visible_series: set[str] = set()
        self.cursor_time: datetime | None = None
        self.setMinimumHeight(260)
        self.setMouseTracking(True)

    def set_records(self, records: list[Any]) -> None:
        self.records = [r for r in records if _record_timestamp(r) is not None]
        self.update()

    def set_series_visible(self, key: str, visible: bool) -> None:
        if visible:
            self.visible_series.add(key)
        else:
            self.visible_series.discard(key)
        self.update()

    def set_cursor_time(self, timestamp: datetime | None) -> None:
        self.cursor_time = timestamp
        self.update()

    def available_series(self) -> list[tuple[str, str]]:
        return [(key, label) for key, label in self.SERIES if len(self._points(key)) >= 2]

    def _points(self, key: str) -> list[tuple[datetime, float]]:
        result: list[tuple[datetime, float]] = []
        for record in self.records:
            fields = _structured_fields(record)
            value = fields.get(key)
            try:
                result.append((_record_timestamp(record), float(value)))
            except Exception:
                continue
        return result

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.fillRect(self.rect(), QColor("#FFFFFF"))
        plot = self.rect().adjusted(58, 24, -18, -42)
        painter.setPen(QPen(QColor("#CBD5E1"), 1))
        painter.drawRect(plot)

        if not self.records:
            painter.setPen(QColor("#64748B"))
            painter.drawText(self.rect(), Qt.AlignCenter, "Load WaterSystem or VIMeasure data to display the chart.")
            return

        timestamps = [_record_timestamp(r) for r in self.records if _record_timestamp(r) is not None]
        if len(timestamps) < 2:
            return
        start, end = min(timestamps), max(timestamps)
        duration = max(0.001, (end - start).total_seconds())

        palette = [QColor("#005DAA"), QColor("#D97706"), QColor("#059669"), QColor("#7C3AED"), QColor("#DC2626"), QColor("#0891B2")]
        legend_x = plot.left()
        for series_index, (key, label) in enumerate(self.SERIES):
            if key not in self.visible_series:
                continue
            points = self._points(key)
            if len(points) < 2:
                continue
            values = [value for _, value in points]
            low, high = min(values), max(values)
            span = max(0.001, high - low)
            color = palette[series_index % len(palette)]
            painter.setPen(QPen(color, 1.6))
            poly: list[QPointF] = []
            for ts, value in points:
                x = plot.left() + ((ts - start).total_seconds() / duration) * plot.width()
                y = plot.bottom() - ((value - low) / span) * plot.height()
                poly.append(QPointF(x, y))
            for i in range(1, len(poly)):
                painter.drawLine(poly[i - 1], poly[i])
            painter.fillRect(QRectF(legend_x, 5, 12, 3), color)
            painter.setPen(QColor("#334155"))
            painter.drawText(int(legend_x + 16), 12, label)
            legend_x += 105

        if self.cursor_time is not None and start <= self.cursor_time <= end:
            x = plot.left() + ((self.cursor_time - start).total_seconds() / duration) * plot.width()
            painter.setPen(QPen(QColor("#EF4444"), 1.5, Qt.DashLine))
            painter.drawLine(QPointF(x, plot.top()), QPointF(x, plot.bottom()))

        painter.setPen(QColor("#64748B"))
        painter.drawText(plot.left(), self.height() - 15, start.strftime("%H:%M:%S"))
        end_text = end.strftime("%H:%M:%S")
        painter.drawText(plot.right() - 60, self.height() - 15, end_text)

    def mousePressEvent(self, event) -> None:
        if not self.records:
            return
        plot = self.rect().adjusted(58, 24, -18, -42)
        if not plot.contains(event.position().toPoint()):
            return
        timestamps = [_record_timestamp(r) for r in self.records if _record_timestamp(r) is not None]
        start, end = min(timestamps), max(timestamps)
        ratio = max(0.0, min(1.0, (event.position().x() - plot.left()) / max(1, plot.width())))
        selected = start + (end - start) * ratio
        self.cursor_time = selected
        self.update()
        self.timeSelected.emit(selected)


class InvestigationWorkspace(QWidget):
    returnRequested = Signal()

    def __init__(self, viewer: Any):
        super().__init__(viewer)
        self.viewer = viewer
        self.tables: dict[str, QTableWidget] = {}
        self.rows: dict[str, list[dict[str, Any]]] = {}
        self.source_records: dict[str, list[Any]] = {}
        self._syncing = False
        self._build_ui()
        self.load_template()

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(4, 4, 4, 4)

        top = QHBoxLayout()
        title = QLabel("Investigation Mode")
        title.setStyleSheet("font-size:20px;font-weight:700;color:#005DAA;")
        self.template = QComboBox()
        self.template.addItems(TEMPLATES.keys())
        self.template.currentTextChanged.connect(self.load_template)
        self.view_mode = QComboBox()
        self.view_mode.addItems(["Logs", "WaterSystem Chart", "Logs + Chart"])
        self.view_mode.setCurrentText("Logs + Chart")
        self.view_mode.currentTextChanged.connect(self.apply_view_mode)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search visible investigation logs...")
        self.search.textChanged.connect(self.apply_search)
        self.tolerance = QComboBox()
        for text, value in [("Exact", 0), ("±1 sec", 1), ("±5 sec", 5), ("±10 sec", 10), ("±30 sec", 30)]:
            self.tolerance.addItem(text, value)
        self.tolerance.setCurrentIndex(2)
        reload_btn = QPushButton("Reload")
        reload_btn.clicked.connect(self.load_template)
        close_btn = QPushButton("Return to Log Viewer")
        close_btn.clicked.connect(self.returnRequested.emit)
        top.addWidget(title)
        top.addWidget(QLabel("Profile:"))
        top.addWidget(self.template)
        top.addWidget(QLabel("View:"))
        top.addWidget(self.view_mode)
        top.addWidget(QLabel("Sync:"))
        top.addWidget(self.tolerance)
        top.addWidget(self.search, 1)
        top.addWidget(reload_btn)
        top.addWidget(close_btn)
        root.addLayout(top)

        self.main_vertical = QSplitter(Qt.Vertical)
        root.addWidget(self.main_vertical, 1)

        self.logs_host = QWidget()
        self.logs_layout = QHBoxLayout(self.logs_host)
        self.logs_layout.setContentsMargins(0, 0, 0, 0)
        self.main_vertical.addWidget(self.logs_host)

        chart_host = QWidget()
        chart_layout = QVBoxLayout(chart_host)
        chart_controls = QHBoxLayout()
        chart_controls.addWidget(QLabel("Structured Chart (WaterSystem / VIMeasure):"))
        self.chart_checks: dict[str, QCheckBox] = {}
        for key, label in WaterSystemChart.SERIES:
            check = QCheckBox(label)
            check.setChecked(False)
            check.setVisible(False)
            check.toggled.connect(lambda checked, k=key: self.chart.set_series_visible(k, checked))
            chart_controls.addWidget(check)
            self.chart_checks[key] = check
        chart_controls.addStretch(1)
        chart_layout.addLayout(chart_controls)
        self.chart = WaterSystemChart()
        self.chart.timeSelected.connect(self.sync_all_to_time)
        chart_layout.addWidget(self.chart, 1)
        self.main_vertical.addWidget(chart_host)
        self.chart_host = chart_host

        lower = QSplitter(Qt.Horizontal)
        self.main_vertical.addWidget(lower)
        self.main_vertical.setSizes([430, 300, 180])

        timeline_box = QWidget(); timeline_layout = QVBoxLayout(timeline_box)
        header = QHBoxLayout(); header.addWidget(QLabel("Critical Timeline"))
        self.show_critical = QCheckBox("Critical"); self.show_warning = QCheckBox("Warning")
        self.show_critical.setChecked(True); self.show_warning.setChecked(True)
        self.show_critical.toggled.connect(self.apply_search); self.show_warning.toggled.connect(self.apply_search)
        header.addStretch(); header.addWidget(self.show_critical); header.addWidget(self.show_warning)
        timeline_layout.addLayout(header)
        self.summary = QLabel("Critical: 0   Warning: 0   Restart: 0   Watchdog: 0   Timeout: 0")
        timeline_layout.addWidget(self.summary)
        self.timeline = QListWidget(); self.timeline.itemClicked.connect(self.timeline_jump)
        timeline_layout.addWidget(self.timeline)
        lower.addWidget(timeline_box)

        bookmark_box = QWidget(); bookmark_layout = QVBoxLayout(bookmark_box)
        bookmark_layout.addWidget(QLabel("Bookmarks"))
        buttons = QHBoxLayout(); add_btn = QPushButton("Add Selected"); export_btn = QPushButton("Export CSV")
        add_btn.clicked.connect(self.add_bookmark); export_btn.clicked.connect(self.export_bookmarks)
        buttons.addWidget(add_btn); buttons.addWidget(export_btn)
        bookmark_layout.addLayout(buttons)
        self.bookmarks = QListWidget(); self.bookmarks.itemClicked.connect(self.bookmark_jump)
        bookmark_layout.addWidget(self.bookmarks)
        lower.addWidget(bookmark_box)

        notes_box = QWidget(); notes_layout = QVBoxLayout(notes_box)
        notes_layout.addWidget(QLabel("Investigation Notes"))
        self.notes = QTextEdit(); self.notes.setPlaceholderText("Findings, actions, and next steps...")
        notes_layout.addWidget(self.notes)
        lower.addWidget(notes_box)

        self.setStyleSheet("""
            QWidget { background:#F4F7FB; font-family:Segoe UI; }
            QTableWidget, QListWidget, QTextEdit, QLineEdit, QComboBox {
                background:white; border:1px solid #CBD5E1; border-radius:4px;
            }
            QPushButton { background:#005DAA; color:white; border:0; border-radius:4px; padding:7px 11px; }
            QPushButton:hover { background:#0079C2; }
            QHeaderView::section { background:#EAF2F8; padding:5px; border:0; font-weight:600; }
        """)

    def apply_view_mode(self) -> None:
        mode = self.view_mode.currentText()
        has_chart = bool(self.chart.available_series())
        self.logs_host.setVisible(mode in {"Logs", "Logs + Chart"})
        self.chart_host.setVisible(has_chart and mode in {"Logs + Chart", "Chart Only"})

    def _clear_panes(self) -> None:
        while self.logs_layout.count():
            item = self.logs_layout.takeAt(0)
            if item.widget() is not None:
                item.widget().deleteLater()
        self.tables.clear(); self.rows.clear(); self.source_records.clear()

    def load_template(self) -> None:
        progress = QProgressDialog("Preparing Investigation Mode...", "Cancel", 0, 100, self)
        progress.setWindowTitle("Investigation Mode")
        progress.setWindowModality(Qt.ApplicationModal)
        progress.setMinimumDuration(0)
        progress.setAutoClose(False)
        progress.show()
        QApplication.processEvents()
        try:
            self._clear_panes()
            sources = TEMPLATES.get(self.template.currentText(), [])
            total = max(1, len(sources))
            for source_index, source in enumerate(sources):
                if progress.wasCanceled():
                    return
                progress.setValue(int(source_index * 65 / total))
                progress.setLabelText(f"Loading {source}... ({source_index+1}/{total})")
                QApplication.processEvents()
                try:
                    records = list(self.viewer.source_to_records(source, progress) or [])
                except Exception as exc:
                    records = []
                    QMessageBox.warning(self, "Investigation Mode", f"{source} could not be loaded.\n\n{exc}")
                # Do not show empty source panes or non-existent checklist items.
                if not records:
                    continue
                self.source_records[source] = records
                converted: list[dict[str, Any]] = []
                for record in records:
                    ts = _record_timestamp(record)
                    fields = _structured_fields(record)
                    if fields:
                        message = str(fields.get("MainState") or fields.get("Status") or fields.get("State") or "")
                        detail = str(fields.get("Error") or fields.get("SubStatus") or _record_message(record) or "")
                        message = (message + " " + detail).strip()
                    else:
                        message = _record_message(record)
                    converted.append({
                        "timestamp": ts,
                        "time": ts.strftime("%Y/%m/%d %H:%M:%S.%f")[:-3] if isinstance(ts, datetime) else "",
                        "message": message,
                        "level": _level(message, str(getattr(record, "level", "") or "")),
                        "line": _record_line(record),
                    })
                self.rows[source] = converted
                self.logs_layout.addWidget(self._make_pane(source), 1)

            progress.setValue(72); progress.setLabelText("Detecting chart series..."); QApplication.processEvents()
            chart_records = self.source_records.get("WaterSystem", []) + self.source_records.get("VIMeasure", [])
            self.chart.set_records(chart_records)
            available = dict(self.chart.available_series())
            default_keys = [k for k in ("DOLevel","VacuumLevel","PrimaryFlowMeter","SecondaryFlowMeter","4vI","4vV") if k in available]
            self.chart.visible_series = set(default_keys[:4])
            for key, check in self.chart_checks.items():
                check.blockSignals(True)
                check.setVisible(key in available)
                check.setChecked(key in self.chart.visible_series)
                check.blockSignals(False)

            has_chart = bool(available)
            self.chart_host.setVisible(has_chart)
            self.view_mode.blockSignals(True)
            current = self.view_mode.currentText()
            self.view_mode.clear()
            self.view_mode.addItem("Logs")
            if has_chart:
                self.view_mode.addItems(["Logs + Chart", "Chart Only"])
                self.view_mode.setCurrentText("Logs + Chart" if self.template.currentText() in {"Water Investigation","Sonication Investigation"} else "Logs")
            else:
                self.view_mode.setCurrentText("Logs")
            self.view_mode.blockSignals(False)
            progress.setValue(88); progress.setLabelText("Building timeline and visible rows..."); QApplication.processEvents()
            self.apply_search(); self.apply_view_mode()
            progress.setValue(100)
        finally:
            progress.close()

    def _make_pane(self, source: str) -> QWidget:
        box = QWidget(); layout = QVBoxLayout(box)
        label = QLabel(source); label.setStyleSheet("font-size:14px;font-weight:700;color:#005DAA;")
        table = QTableWidget(0, 4)
        table.setHorizontalHeaderLabels(["Timestamp", "Message / State", "Level", "Line"])
        table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        table.setSelectionBehavior(QTableWidget.SelectRows); table.setSelectionMode(QTableWidget.SingleSelection)
        table.setEditTriggers(QTableWidget.NoEditTriggers); table.setAlternatingRowColors(True)
        table.verticalHeader().setVisible(False); table.setMouseTracking(False); table.setToolTip("")
        table.itemSelectionChanged.connect(lambda s=source: self.sync_from(s))
        layout.addWidget(label); layout.addWidget(table, 1)
        self.tables[source] = table
        return box

    def apply_search(self) -> None:
        keyword = self.search.text().strip().lower()
        self.timeline.clear()
        counts = {"critical": 0, "warning": 0, "restart": 0, "watchdog": 0, "timeout": 0}
        for source, table in self.tables.items():
            data = [row for row in self.rows.get(source, []) if not keyword or keyword in row["message"].lower()]
            table.setRowCount(len(data)); table.setProperty("filtered_rows", data)
            for index, row in enumerate(data):
                for column, text in enumerate([row["time"], row["message"], row["level"], str(row["line"]) ]):
                    table.setItem(index, column, QTableWidgetItem(text))
                level = row["level"].lower(); msg = row["message"].lower()
                if "critical" in level or "error" in level:
                    counts["critical"] += 1
                if "warning" in level or "warn" in level:
                    counts["warning"] += 1
                for key in ("restart", "watchdog", "timeout"):
                    if key in msg: counts[key] += 1
                show = (self.show_critical.isChecked() and ("critical" in level or "error" in level)) or (self.show_warning.isChecked() and ("warning" in level or "warn" in level))
                if show and row["timestamp"] is not None:
                    item = QListWidgetItem(f"{row['time']} [{source}] {row['message'][:140]}")
                    item.setData(Qt.UserRole, (source, row["timestamp"]))
                    self.timeline.addItem(item)
        self.summary.setText(f"Critical: {counts['critical']}   Warning: {counts['warning']}   Restart: {counts['restart']}   Watchdog: {counts['watchdog']}   Timeout: {counts['timeout']}")

    def sync_from(self, source: str) -> None:
        if self._syncing: return
        table = self.tables.get(source)
        if table is None: return
        selected = table.selectionModel().selectedRows()
        if not selected: return
        rows = table.property("filtered_rows") or []
        index = selected[0].row()
        if not (0 <= index < len(rows)): return
        timestamp = rows[index].get("timestamp")
        if timestamp is not None:
            self.sync_all_to_time(timestamp, source)

    def sync_all_to_time(self, timestamp: datetime, source_to_skip: str = "") -> None:
        if self._syncing: return
        self._syncing = True
        try:
            tolerance = int(self.tolerance.currentData())
            for source, table in self.tables.items():
                if source == source_to_skip: continue
                rows = table.property("filtered_rows") or []
                best_index = -1; best_diff = None
                for index, row in enumerate(rows):
                    ts = row.get("timestamp")
                    if ts is None: continue
                    diff = abs((ts - timestamp).total_seconds())
                    if best_diff is None or diff < best_diff:
                        best_diff = diff; best_index = index
                if best_index >= 0 and (tolerance == 0 and best_diff == 0 or tolerance > 0 and best_diff <= tolerance):
                    table.selectRow(best_index); table.scrollToItem(table.item(best_index, 1), QTableWidget.PositionAtCenter)
            self.chart.set_cursor_time(timestamp)
        finally:
            self._syncing = False

    def timeline_jump(self, item: QListWidgetItem) -> None:
        _source, timestamp = item.data(Qt.UserRole)
        self.sync_all_to_time(timestamp)

    def add_bookmark(self) -> None:
        for source, table in self.tables.items():
            selected = table.selectionModel().selectedRows()
            if not selected: continue
            rows = table.property("filtered_rows") or []
            index = selected[0].row()
            if 0 <= index < len(rows):
                row = rows[index]
                item = QListWidgetItem(f"{row['time']} [{source}] {row['message'][:120]}")
                item.setData(Qt.UserRole, (source, row.get("timestamp")))
                self.bookmarks.addItem(item)
                return
        QMessageBox.information(self, "Bookmark", "Select a row first.")

    def bookmark_jump(self, item: QListWidgetItem) -> None:
        _source, timestamp = item.data(Qt.UserRole)
        if timestamp is not None: self.sync_all_to_time(timestamp)

    def export_bookmarks(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Export Bookmarks", "investigation_bookmarks.csv", "CSV (*.csv)")
        if not path: return
        with open(path, "w", encoding="utf-8-sig", newline="") as stream:
            stream.write("bookmark\n")
            for index in range(self.bookmarks.count()):
                stream.write('"' + self.bookmarks.item(index).text().replace('"', '""') + '"\n')
