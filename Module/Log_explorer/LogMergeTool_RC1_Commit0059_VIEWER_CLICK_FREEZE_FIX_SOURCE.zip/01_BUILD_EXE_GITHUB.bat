@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"

where py >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python launcher "py" was not found.
  exit /b 1
)

py -3.13 -c "import sys" >nul 2>nul
if not errorlevel 1 (
  set "PY=py -3.13"
) else (
  py -3.14 -c "import sys" >nul 2>nul
  if not errorlevel 1 (
    set "PY=py -3.14"
  ) else (
    set "PY=py -3"
  )
)

%PY% -m pip install --upgrade pip
if errorlevel 1 exit /b 1
%PY% -m pip install PySide6 openpyxl nuitka ordered-set zstandard
if errorlevel 1 exit /b 1

%PY% -m nuitka ^
  --standalone ^
  --onefile ^
  --enable-plugin=pyside6 ^
  --windows-console-mode=disable ^
  --assume-yes-for-downloads ^
  --output-dir=build_commit0059 ^
  --output-filename=LogMergeTool_RC1_Commit0059.exe ^
  LogMergeTool_NoExcel_Main.py
if errorlevel 1 exit /b 1

if not exist dist mkdir dist
copy /y "build_commit0059\LogMergeTool_RC1_Commit0059.exe" "dist\LogMergeTool_RC1_Commit0059.exe" >nul
if errorlevel 1 exit /b 1

echo [OK] dist\LogMergeTool_RC1_Commit0059.exe
endlocal
