from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "LogMergeTool_NoExcel_Main.py").read_text(encoding="utf-8-sig")
version = json.loads((ROOT / "version.json").read_text(encoding="utf-8-sig"))
github_bat = (ROOT / "01_BUILD_EXE_GITHUB.bat").read_text(encoding="utf-8-sig")
nuitka_bat = (ROOT / "01_BUILD_EXE_NUITKA.bat").read_text(encoding="utf-8-sig")

assert 'APP_VERSION = "2.0.0-rc1-commit0064"' in main
assert version["version"] == "2.0.0-rc1-commit0064"
assert version["commit"] == "Commit0064"
assert version["artifact_base_name"] == "LogMergeTool_RC1_Commit0064"
assert "LogMergeTool_RC1_Commit0064" in github_bat
assert "LogMergeTool_RC1_Commit0064" in nuitka_bat
assert "_c64_start_backend" in main
assert "MainWindow.start_import_clicked = _c64_start_import_clicked" in main
