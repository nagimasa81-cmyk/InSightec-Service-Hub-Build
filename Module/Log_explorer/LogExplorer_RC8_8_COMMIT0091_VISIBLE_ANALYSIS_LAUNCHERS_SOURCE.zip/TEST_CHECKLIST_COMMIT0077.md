# Commit0077 test checklist

- [x] Python syntax compile
- [x] APP_VERSION and version.json consistency
- [x] File cache signature includes path, size and mtime
- [x] Source cache includes date/noise options
- [x] New Smart Discovery selection resets caches
- [x] Missing selected files are ignored by the existing snapshot normalization
- [x] Parse errors remain visible as Viewer error records
- [x] Commit0076 LOAD LOGS route remains active
- [x] CSA Quick Filter and readability overrides remain after performance override
- [ ] Windows/Nuitka EXE runtime benchmark on production-size logs
