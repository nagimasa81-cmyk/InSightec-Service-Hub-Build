# Commit0088 — Dashboard through Timeline Compare

- Fixed startup order so Commit0087/0088 patches are active before main().
- Added Dashboard with session summary, Ready time, exit state, and health score.
- Retained WS Lifecycle tab and session timeline.
- Added System Health tab for warnings, retries, timeouts, recovery, failures, and score.
- Added Timeline Compare: baseline/current session comparison, missing/extra/order/latency differences, and Log Viewer jump.
- WS means Workstation only; WaterSystem is excluded.
