# Commit0076 — LOAD LOGS / CSA Quick Filter stabilization

## Fixes

- Preserves the Smart File Discovery approved-file list as a Viewer-local snapshot.
- LOAD LOGS uses the approved snapshot instead of rescanning the Source field.
- A pane with no matching selected files is reported explicitly instead of silently appearing loaded.
- One pane failure no longer prevents the remaining visible panes from loading.
- Restores and hardens the CSA `Err` Quick Filter using structured Type/Level fields first.
- CPC_CSA filters inspect the parsed Message/Description field, reducing false matches from filenames and unrelated metadata.
- Keeps the Commit0075 CSA readability layout, summary, row emphasis, and full-message tooltip.

## CSA Quick Filters

- Err
- Sonication: `Start Sonication` / `Sonication Done`
- CSA Status
- Fail: complete fail/failed/failure terms
- Reflection: Reflection/Reflections/Reflected
- HW Status
- Safety Status

## Regression scope

- Folder discovery
- ZIP discovery with delayed LOAD LOGS
- Existing Viewer reused for a new discovery session
- Two-pane WS + CSA loading
- WS `Err + code + True` filter
- CSA generic Err and CPC_CSA filters
