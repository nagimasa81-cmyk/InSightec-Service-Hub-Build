# Commit0084

- Added a `Modified` column to Smart File Discovery.
- Displays each candidate file's filesystem last-modified timestamp as `yyyy/MM/dd HH:mm:ss`.
- The `Modified` header supports ascending and descending sorting.
- Added earliest/latest modified timestamps for checked files currently shown.
- Parsed log Start/End timestamps remain the only values used for data-range filtering.
- Preserved Commit0083 INI family/search selection and structured INI viewer.
