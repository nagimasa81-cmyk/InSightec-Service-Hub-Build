# Commit0078 — WaterSystem Error Code Hover

- Added 945 Message ID descriptions from `Error_Code_Brain_7.0_MSG.xlsx`.
- Hovering a registered code in the WaterSystem `Error`/`Code` cell shows the matching message text.
- Button labels from the source workbook are shown when defined.
- Multiple registered codes in one cell are shown as separate tooltip sections.
- Other WaterSystem cells and non-WS logs keep their existing tooltip behavior.
- Commit0077 parallel loading and caches are retained.
