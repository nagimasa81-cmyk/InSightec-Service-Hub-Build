# Commit0078 Test Checklist

- [x] Message map contains 945 unique IDs.
- [x] Code 7000 resolves to the expected System logging message.
- [x] Code 7960 resolves and includes Yes/No button labels.
- [x] Unknown code returns no tooltip.
- [x] Multiple known codes create separated tooltip sections.
- [x] Tooltip applies only to WaterSystem Error/Code columns.
- [x] Python syntax compilation passes.
- [x] Both Nuitka BAT files bundle `ws_error_messages.json`.
- [x] ZIP CRC passes.
