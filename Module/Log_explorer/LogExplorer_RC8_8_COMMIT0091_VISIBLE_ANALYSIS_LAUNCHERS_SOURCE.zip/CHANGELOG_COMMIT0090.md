# Commit0090
- Added an independent `Open INI Viewer` button to the Log Explorer start screen.
- Standalone INI Viewer supports drag-and-drop of one or more INI files and folders.
- Added multi-select Browse INI Files and Clear Loaded Files controls.
- Loaded INI files remain individually selectable and two files can be compared.
- Smart File Discovery now treats INI as opt-in: INI type and INI files are unchecked by default.
- Replaced detected-type `All` with `All Logs`, added `INI Only`, and kept `Clear`.
- `All Files` does not select INI files.
