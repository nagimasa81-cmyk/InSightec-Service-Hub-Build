# Commit0083 Test Checklist

- [x] INI family normalization groups numbered variants.
- [x] Smart Discovery filters INI by family.
- [x] Smart Discovery searches INI filename/family/path.
- [x] Check shown / Uncheck shown affects filtered rows.
- [x] `item=value` maps to Category / Item / Value.
- [x] comments and non-equals lines map to Category / Message.
- [x] duplicate item values are retained.
- [x] Python syntax and source ZIP CRC pass.
