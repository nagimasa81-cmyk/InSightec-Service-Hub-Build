# Commit0087 — WS Lifecycle Timeline

- Adds a dedicated Workstation lifecycle tab to Log Explore.
- Extracts Workstation startup, logging start, application launch, initialization, ready, login/logout, patient/protocol load, treatment start/stop, application exit/crash, shutdown and restart events from WS logs only.
- Groups events into startup-to-shutdown sessions.
- Marks normal, unexpected, crash and incomplete exits.
- Adds clickable timeline, event list, session summary and filters.
- Uses Master Timeline navigation when a lifecycle event is activated.
- Keeps INI Explorer and all Commit0086 functions unchanged.
