# Commit0089 — INI Explorer 2.0

- Rebuilt INI display as structured Section / Key / Value / Type settings.
- Lines beginning with `;` or `#` are ignored as comments by default.
- Only the first ASCII/full-width equals sign separates Key and Value.
- Added two-file INI comparison with Same / Changed / Added / Removed states.
- Added changed-only default filter, search, swap, summaries, and color-coded rows.
- INI files remain individual and are never merged into the normal log timeline.
