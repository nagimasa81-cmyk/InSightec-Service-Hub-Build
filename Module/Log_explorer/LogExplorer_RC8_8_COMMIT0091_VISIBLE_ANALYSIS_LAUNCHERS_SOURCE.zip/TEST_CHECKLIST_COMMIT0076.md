# Commit0076 Test Checklist

## Static validation

- [x] All Python files compile
- [x] version.json matches APP_VERSION
- [x] Distribution ZIP CRC passes

## LOAD LOGS

- [x] Approved Smart Discovery file list is copied to a Viewer-local snapshot
- [x] Folder discovery uses selected files directly
- [x] ZIP discovery keeps extracted selected files available until LOAD LOGS
- [x] Reused Viewer refreshes its snapshot on LOAD LOGS
- [x] No matching files produces an explicit pane status
- [x] One pane error does not stop other visible panes

## CSA Quick Filters

- [x] Err recognizes structured Err/Error/Fatal/Severe levels
- [x] Sonication recognizes Start Sonication and Sonication Done
- [x] HW Status is not included in Sonication
- [x] CSA Status recognizes CSA Status
- [x] Fail uses complete fail-family words
- [x] Reflection rejects unrelated `ref` fragments such as prefetch
- [x] Reflection recognizes Reflection/Reflections/Reflected
- [x] HW Status recognizes Hw Server Status
- [x] Safety Status recognizes Safety Status

## Regression

- [x] Commit0075 CSA three-column readability view retained
- [x] CSA Summary retained
- [x] Full-message tooltip retained
- [x] WS Err + code + True route retained
