# Commit0086 — Dedicated INI Explorer

- Removed INI files from the normal timestamp/log Viewer source list.
- START opens selected INI files in a dedicated INI Explorer.
- Each INI remains an independent document selected from the File combo; files are never merged.
- Mixed selections open ordinary logs in Log Viewer and INIs separately in INI Explorer.
- INI assignments split at the first ASCII `=` or full-width `＝` into Item and Value.
- Lines without an equals sign are displayed in Message.
- Added Category filtering and field-specific search.
- Added selected-entry details and raw-line panes.
