# Commit0083

- Added INI family selector to Smart File Discovery.
- Added INI filename/family/path search.
- Added Check shown / Uncheck shown workflow after filtering.
- Changed INI viewer columns to Category, Item, Value, Message, File, Line.
- Lines containing `=` are split into Item and Value.
- Comments and free-form lines are shown in Message.
- Section headers define Category and are not repeated as data rows.
