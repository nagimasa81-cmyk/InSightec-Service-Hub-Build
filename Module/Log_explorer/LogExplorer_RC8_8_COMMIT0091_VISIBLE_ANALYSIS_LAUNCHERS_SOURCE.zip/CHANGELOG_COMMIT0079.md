# Commit0079

- Fixed WS error-code hover descriptions when the viewer SourceType is `WS` instead of `WATERSYSTEM`.
- Code descriptions now work when the code is embedded in Message, Original, Sub Original, or Raw columns.
- Registered code descriptions take priority over the generic full-row tooltip.
- Error/Code columns remain supported.
- The original visible cell text is appended below the registered code description for context.
