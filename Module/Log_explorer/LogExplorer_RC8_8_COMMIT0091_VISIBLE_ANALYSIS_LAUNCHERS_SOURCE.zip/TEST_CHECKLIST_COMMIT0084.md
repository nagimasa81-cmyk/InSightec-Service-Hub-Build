# Commit0084 Test Checklist

1. Open Smart File Discovery and confirm the `Modified` column is visible.
2. Confirm displayed values match Windows Explorer's modified timestamps.
3. Click `Modified` twice and confirm ascending/descending order changes.
4. Check/uncheck files and confirm `Checked file modified range` updates.
5. Confirm Start/End filtering still uses parsed log timestamps, not modified timestamps.
6. Confirm INI Family/Search/Check shown features remain operational.
7. Confirm START passes all checked files to Log Explore.
