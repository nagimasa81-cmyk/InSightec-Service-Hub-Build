# Commit0074 — LOAD LOGS and CPC_CSA Quick Filter Recovery

- `LOAD LOGS` now consumes the exact Smart File Discovery selection instead of re-scanning `source_edit`.
- ZIP discovery remains loadable after the Viewer shell opens, even when `source_edit` still points to the original ZIP.
- The LOAD LOGS signal is rebound after all historical UI wrappers to prevent stale handler regressions.
- CSA keeps the generic `Err` Quick Filter visible.
- CPC_CSA filters use structured CSA fields and corrected narrow matching:
  - Sonication: `Start Sonication` / `Sonication Done`
  - CSA Status: `CSA Status`
  - Fail: whole fail/failed/failure term
  - Reflection: full Reflection/Reflected term (not every `ref` substring)
  - HW Status: `Hw Server Status`
  - Safety Status: `Safety Status`
- Existing WS `Err + code + True` Quick Filter remains unchanged.
