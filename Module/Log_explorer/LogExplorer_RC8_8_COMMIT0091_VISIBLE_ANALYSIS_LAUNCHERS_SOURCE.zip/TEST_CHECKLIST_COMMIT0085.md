# Commit0085 Test Checklist

- [x] Two selected INIs appear as two independent source entries.
- [x] Selecting one INI loads rows only from that physical file.
- [x] Generic INI does not merge multiple files.
- [x] `Port=8080` => Item `Port`, Value `8080`, empty Message.
- [x] `Mode=test=value` => Item `Mode`, Value `test=value`.
- [x] `Mode＝test` full-width equals is supported.
- [x] Free-form/comment lines populate Message only.
- [x] Preview uses Category / Item / Value / Message.
- [x] Commit0084 Modified column remains.
