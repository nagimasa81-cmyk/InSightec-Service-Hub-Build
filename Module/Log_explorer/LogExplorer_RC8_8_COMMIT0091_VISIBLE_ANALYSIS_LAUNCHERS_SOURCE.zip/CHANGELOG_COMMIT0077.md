# Commit0077 — Log loading performance

- Parallel parsing for independent selected log files (up to 4 workers).
- Per-file session parse cache keyed by resolved path, size, modification time, and detected log type.
- Per-source processed-record cache for fast pane switching and repeated LOAD LOGS.
- Automatic cache invalidation when Smart File Discovery selection or file metadata changes.
- Cache key includes date filter and noise-filter state.
- Existing Commit0076 LOAD LOGS routing and CSA/WS Quick Filters are preserved.
- No persistent cache is written; memory is released when the Viewer session closes.
