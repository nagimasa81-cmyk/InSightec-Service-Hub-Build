# Commit0091 Test Checklist

- [x] Final production `MainWindow.build_ui` contains all three launchers.
- [x] Open INI Viewer calls standalone INI Explorer.
- [x] WS Lifecycle opens and selects the WS Lifecycle tab.
- [x] Timeline Compare opens and selects the Timeline Compare tab.
- [x] Buttons are inserted near the top of the start screen.
- [x] Python syntax compiles.
- [x] Commit0090 behavior remains present.
