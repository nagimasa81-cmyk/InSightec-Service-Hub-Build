# Commit0080 Test Checklist

- [x] Python syntax compile
- [x] Error-code tooltip source set is exactly `{WS}`
- [x] WATERSYSTEM/WaterSystem is excluded
- [x] CallID Quick Filter button is added to each pane
- [x] CallID mode matches structured `CallID` values
- [x] Compatibility extraction supports `CallID`, `Call ID`, and `Case ID`
- [x] Button reports matching rows and unique IDs
- [x] Existing same-CallID context-menu actions remain present
- [x] Existing WS Err, CSA filters, LOAD LOGS and fast cache code remain present
- [x] Version/build contract/BAT artifact name consistency
- [x] ZIP CRC
