# Commit0073 — CPC_CSA Quick Filters

- Imported the supplied Excel CPC_CSA macro criteria into the CSA Viewer Quick Filter.
- CSA-only presets: Sonication, CSA Status, Fail, Reflection, HW Status, Safety Status.
- The presets appear only when the pane source is CSA.
- Generic severity buttons are hidden for CSA to avoid overcrowding.
- Existing WS Err + code + True behavior remains WS-only.
- Filters are Viewer-only and do not alter imported files or merge output.
