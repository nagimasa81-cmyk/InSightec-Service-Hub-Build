# Commit0075 — CSA Readability View

- Added CSA event-class row emphasis for Err/Fail, Warning, Sonication, CSA Status, Reflection, HW Status and Safety Status.
- Added a compact per-pane CSA Summary with row and event counts.
- Changed the default CSA columns to Timestamp / Type / Message so the message receives most of the pane width.
- Added complete CSA event tooltips including timestamp, category/type and full message.
- Increased CSA row height slightly and kept long messages elided in-table to preserve scrolling performance.
- Preserved Commit0074 LOAD LOGS selected-file handoff and CPC_CSA Quick Filter behavior.
