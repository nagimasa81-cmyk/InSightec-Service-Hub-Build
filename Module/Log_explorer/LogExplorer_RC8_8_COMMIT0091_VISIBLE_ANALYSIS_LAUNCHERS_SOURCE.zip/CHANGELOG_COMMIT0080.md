# Commit0080 — WS-only Code Tooltip + CallID Quick Filter

## Changes
- Restrict Error_Code_Brain_7.0_MSG.xlsx tooltip mapping to SourceType exactly `WS`.
- Explicitly exclude `WATERSYSTEM`, `WaterSystem`, CSA, CGA, MRSERVER, GESYS, LAIS, VIMeasure and all other sources.
- Add a `CallID` Quick Filter to every Viewer pane.
- Recognize the existing structured CallID extraction for `CallID`, `Call ID`, and `Case ID`.
- Show both matching row count and unique CallID count on the button.
- Keep the existing row context-menu actions for filtering one specific CallID and linking the same CallID across panes.
- Avoid adding a duplicate specific-ID selector because the existing context menu already provides that workflow.

## Verified useful existing behavior
- CallID extraction already covers WS, CSA, CGA and MRSERVER records.
- A selected row can already isolate one CallID or link it across visible panes.
- The new Quick Filter therefore focuses on finding all rows with traceable IDs; the existing context menu handles detailed investigation.
