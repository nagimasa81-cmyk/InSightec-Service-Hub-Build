# Commit0082 Test Checklist

- [ ] Smart Discovery lists `.ini` files with Type `INI`.
- [ ] Double-clicking an INI discovery row opens the structured preview.
- [ ] Preview search filters Section, Key, Value, Type and Status.
- [ ] Checked INI files load from the Viewer `INI` source.
- [ ] Duplicate keys remain visible and are marked `Duplicate #N`.
- [ ] Comments, section headers and malformed/key-only lines remain visible.
- [ ] Long values expand in the Value column and show full tooltip/detail text.
- [ ] Other log types and Master Timeline synchronization still work.
