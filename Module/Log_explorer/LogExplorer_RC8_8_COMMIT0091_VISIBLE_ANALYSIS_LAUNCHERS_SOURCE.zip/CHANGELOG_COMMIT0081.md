# Commit0081 — Master Timeline Sync

- Synchronization now searches every loaded unfiltered row in each pane.
- Quick Filter, manual search, and Viewer Time Range no longer remove rows from synchronization lookup.
- A matching row hidden by a filter is temporarily injected into the current view and centered.
- Timestamp index is rebuilt from all rows after load and cache reuse.
- Status log reports master row count, timestamped row count, nearest delta, and temporary reveal state.
- Existing WS-only error-code tooltip, CallID Quick Filter, CSA filters, LOAD LOGS stabilization, and fast-load cache remain enabled.
