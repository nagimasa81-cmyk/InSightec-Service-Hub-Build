# Commit0082 — Structured INI Viewer

- Smart File Discovery now detects and lists `.ini` files as `INI`.
- Checked INI files can be loaded in any Log Viewer pane.
- INI content is shown as structured `Section / Key / Value / Value Type / Status / File / Line` rows.
- Duplicate keys, comments, section headers, key-only lines and malformed lines are preserved instead of discarded.
- Value types are classified as Boolean, Integer, Float, Hex, Path, List, Empty or Text.
- Double-clicking an INI row in Smart Discovery opens an immediate searchable preview with section/key/duplicate/issue counts.
- Existing log parsers, Master Timeline synchronization, WS tooltip and CallID behavior remain unchanged.
