# Commit0086 Test Checklist

- [x] Python syntax compilation.
- [x] INI Explorer class exists and has File selector.
- [x] Selected INI files are not passed to normal Log Viewer.
- [x] Mixed log/INI selection opens separate viewers.
- [x] Generic and individual INI sources are removed from normal Viewer.
- [x] ASCII equals split uses first delimiter only.
- [x] Full-width equals split supported.
- [x] Lines without equals use Message.
- [x] Category / Item / Value / Message columns present.
- [x] Existing Modified column and INI discovery filters retained.
