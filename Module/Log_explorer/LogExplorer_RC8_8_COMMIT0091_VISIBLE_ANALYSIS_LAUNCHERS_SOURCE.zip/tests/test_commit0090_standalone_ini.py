from pathlib import Path
src = (Path(__file__).parents[1] / "LogMergeTool_NoExcel_Main.py").read_text(encoding="utf-8")
assert 'QPushButton("Open INI Viewer")' in src
assert 'def open_ini_viewer_independent' in src
assert 'self.setAcceptDrops(True)' in src
assert 'def dragEnterEvent' in src and 'def dropEvent' in src
assert 'getOpenFileNames' in src
assert 'QPushButton("All Logs")' in src
assert 'QPushButton("INI Only")' in src
assert 'str(meta.log_type).upper() != "INI"' in src
assert 'commit0090' in src
