from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "LogMergeTool_NoExcel_Main.py"
TEXT = MAIN.read_text(encoding="utf-8")


def test_ws_lifecycle_symbols_and_tab():
    required = [
        "class WSLifecycleWidget",
        "class WSLifecycleTimelineWidget",
        "def _c87_ws_lifecycle_events",
        "def _c87_build_sessions",
        '"WS Lifecycle"',
    ]
    for token in required:
        assert token in TEXT


def test_ws_is_workstation_only():
    assert 'if _f44_type(source_type) != "WS"' in TEXT
    assert "WaterSystem" not in TEXT[TEXT.index("# Commit0087:"):]


def test_required_lifecycle_events():
    for token in (
        "Workstation start", "Application started", "Application ready",
        "Application exit", "Workstation shutdown", "Restart requested",
        "Application crash", "Unexpected / next startup detected",
    ):
        assert token in TEXT


def test_version_commit0087():
    assert '2.0.0-rc1-commit0087' in TEXT
