from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1] / "LogMergeTool_NoExcel_Main.py"
TEXT = SOURCE.read_text(encoding="utf-8")


def test_dedicated_ini_explorer_contract():
    required = [
        'class IniExplorerDialog(QDialog):',
        '_C86_INI_COLUMNS = ["Category", "Item", "Value", "Message"]',
        'Files are displayed individually and are not merged.',
        'ini_files = [p for p in selected',
        'log_files = [p for p in selected',
        'MainWindow.start_import_clicked = _c86_start_import_clicked',
        'not v.startswith(_C85_INI_SOURCE_PREFIX)',
        'APP_VERSION = "2.0.0-rc1-commit0086"',
    ]
    for token in required:
        assert token in TEXT


def test_first_equals_parser_retained():
    assert 'raw_line[:pos].strip()' in TEXT
    assert 'raw_line[pos + len(delimiter):].strip()' in TEXT
    assert '(raw_line.find("="), "=")' in TEXT
    assert '(raw_line.find("＝"), "＝")' in TEXT
