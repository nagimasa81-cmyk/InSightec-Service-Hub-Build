from pathlib import Path

src = (Path(__file__).resolve().parents[1] / 'LogMergeTool_NoExcel_Main.py').read_text(encoding='utf-8')

for text in (
    'QPushButton("Open INI Viewer")',
    'QPushButton("WS Lifecycle")',
    'QPushButton("Timeline Compare")',
    'MainWindow.open_ws_lifecycle = _c91_open_ws_lifecycle',
    'MainWindow.open_timeline_compare = _c91_open_timeline_compare',
    'MainWindow.build_ui = _c91_main_build_ui',
    'APP_VERSION = "2.0.0-rc1-commit0091"',
):
    assert text in src, text

assert 'self.open_ini_viewer_independent()' in src
assert 'self.open_ws_lifecycle()' in src
assert 'self.open_timeline_compare()' in src
