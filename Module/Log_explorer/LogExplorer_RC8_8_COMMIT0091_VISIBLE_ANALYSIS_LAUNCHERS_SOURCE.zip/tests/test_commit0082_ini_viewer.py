from pathlib import Path
import ast

root = Path(__file__).resolve().parents[1]
source = (root / 'LogMergeTool_NoExcel_Main.py').read_text(encoding='utf-8')
ast.parse(source)
required = [
    '_c82_parse_ini',
    'Path(path).suffix.casefold() == ".ini"',
    'MultiPaneLogViewer.SOURCES.insert',
    'class IniPreviewDialog',
    'Section", "Key", "Value", "Value Type", "Status", "File", "Line',
    'Duplicate #',
    'cellDoubleClicked.connect',
    'APP_VERSION = "2.0.0-rc1-commit0082"',
]
for token in required:
    assert token in source, token
version = (root / 'version.json').read_text(encoding='utf-8')
contract = (root / 'insightec_build_contract.json').read_text(encoding='utf-8')
assert 'commit0082' in version
assert 'commit0082' in contract
print('Commit0082 INI viewer static checks: PASS')
