from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / "LogMergeTool_NoExcel_Main.py"
TEXT = SRC.read_text(encoding="utf-8")


def test_macro_filter_modes_are_present():
    for token in (
        "CSA_SONICATION", "CSA_STATUS", "CSA_FAIL", "CSA_REFLECTION",
        "CSA_HW_STATUS", "CSA_SAFETY_STATUS",
    ):
        assert token in TEXT


def test_supplied_vba_criteria_are_preserved():
    for criterion in (
        "start sonication...", "sonication done", "csa status", "fail",
        "ref", "hw server status", "safety status",
    ):
        assert criterion in TEXT.lower()


def test_csa_buttons_are_source_scoped():
    assert "button.setVisible(is_csa)" in TEXT
    assert 'str(value or "").strip().upper() == "CSA"' in TEXT
    assert 'button.setVisible(not is_csa)' in TEXT


def test_ws_filter_remains_ws_only():
    assert "button.setVisible(is_ws)" in TEXT
    assert '_C70_WS_MODE if _c70_is_ws_source_name(source_name) else "ALL"' in TEXT
