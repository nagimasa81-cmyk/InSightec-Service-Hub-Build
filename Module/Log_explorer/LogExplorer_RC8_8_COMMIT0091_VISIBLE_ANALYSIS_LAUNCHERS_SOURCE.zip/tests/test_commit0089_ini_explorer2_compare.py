from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
TEXT = (ROOT / "LogMergeTool_NoExcel_Main.py").read_text(encoding="utf-8")

def test_ini_explorer2_structure():
    for token in (
        "class IniExplorerDialogV2",
        "def _c89_parse_ini_settings",
        "_C89_INI_COLUMNS = [\"Section\", \"Key\", \"Value\", \"Type\"]",
        "Changed / Added / Removed",
        "Added in B",
        "Removed from B",
    ):
        assert token in TEXT

def test_comments_are_ignored_and_first_equals_is_used():
    block = TEXT[TEXT.index("def _c89_parse_ini_settings"):TEXT.index("def _c89_settings_map")]
    assert "stripped.startswith((\";\", \"#\"))" in block
    assert "_c85_split_ini_assignment(raw_line)" in block

def test_version_commit0089():
    data = json.loads((ROOT / "version.json").read_text(encoding="utf-8"))
    assert int(data["commit"]) >= 89
    assert int(data["version"].rsplit("commit", 1)[-1]) >= 89
