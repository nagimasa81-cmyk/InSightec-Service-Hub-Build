from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
TEXT = (ROOT / 'LogMergeTool_NoExcel_Main.py').read_text(encoding='utf-8')


def test_commit0088_tabs_and_widgets():
    for token in (
        'class WSDashboardWidget',
        'class WSSystemHealthWidget',
        'class WSTimelineCompareWidget',
        '"Dashboard"',
        '"System Health"',
        '"Timeline Compare"',
        'def compare_sessions',
        '"Missing"',
        '"Delayed"',
        '"Order changed"',
    ):
        assert token in TEXT


def test_main_guard_is_last_and_patches_activate_before_main():
    guard = 'if __name__ == "__main__":\n    main()'
    assert TEXT.count(guard) == 1
    assert TEXT.rfind(guard) > TEXT.rfind('Commit0088')


def test_version_commit0088():
    data = json.loads((ROOT / 'version.json').read_text(encoding='utf-8'))
    assert int(data['commit']) >= 88
    assert data['version'].startswith('2.0.0-rc1-commit')
