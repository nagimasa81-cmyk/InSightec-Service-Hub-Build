from pathlib import Path
import ast

SOURCE = Path(__file__).resolve().parents[1] / 'LogMergeTool_NoExcel_Main.py'
text = SOURCE.read_text(encoding='utf-8')
ast.parse(text)

required = [
    '_C85_INI_SOURCE_PREFIX = "INI — "',
    'def _c85_split_ini_assignment',
    'def _c85_parse_ini',
    'def _c85_selected_ini_map',
    'def _c85_refresh_available_sources',
    'def _c85_source_to_records',
    'MultiPaneLogViewer.source_to_records = _c85_source_to_records',
    '_C85_INI_COLUMNS = ["Category", "Item", "Value", "Message"]',
]
for marker in required:
    assert marker in text, marker

commit = text.split('# Commit0085:', 1)[1]
assert 'raw_line.split("=", 1)' not in commit
assert 'raw_line.find("＝")' in commit
assert 'Generic INI source redirected to individual file' in commit
assert 'values = [value for value in values if value.strip().upper() != _C82_INI_TYPE]' in commit
print('Commit0085 INI individual/column static checks: PASS')
