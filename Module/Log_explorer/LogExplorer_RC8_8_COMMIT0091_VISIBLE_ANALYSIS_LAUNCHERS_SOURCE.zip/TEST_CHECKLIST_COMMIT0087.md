# Commit0087 Test Checklist

- [ ] WS means Workstation; WaterSystem is not included.
- [ ] WS Lifecycle initializes lazily without delaying Log Explore startup.
- [ ] Workstation startup and logging initialization are detected.
- [ ] Application start, initialization and ready events are detected.
- [ ] Application exit, shutdown, restart and crash events are classified separately.
- [ ] Consecutive startup records create separate sessions.
- [ ] Missing shutdown before next startup is marked unexpected.
- [ ] Timeline click and event-table double-click navigate to WS time.
- [ ] Refresh Data rebuilds initialized lifecycle data.
- [ ] INI Explorer remains separate and non-merged.
