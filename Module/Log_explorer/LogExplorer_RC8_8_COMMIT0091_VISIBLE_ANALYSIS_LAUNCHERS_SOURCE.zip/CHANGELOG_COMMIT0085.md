# Commit0085 — Individual INI Viewer and Strict Assignment Columns

- Each selected INI file is exposed as an independent Viewer source.
- Multiple INI files are never concatenated into one table.
- The generic INI source is hidden when individual files are available.
- ASCII `=` and full-width `＝` split at the first occurrence only.
- Left side is always `Item`; right side is always `Value`.
- Additional equals signs remain in `Value`.
- Non-assignment lines display in `Message`.
- INI columns are fixed to Category / Item / Value / Message.
- Commit0084 Modified column, INI Family search, and existing log features remain.
