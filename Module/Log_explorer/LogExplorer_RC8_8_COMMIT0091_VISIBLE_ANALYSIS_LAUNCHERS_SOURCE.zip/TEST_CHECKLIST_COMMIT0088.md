# Commit0088 Test Checklist

- [ ] Dashboard tab appears and initializes lazily.
- [ ] WS Lifecycle tab appears (startup-order regression fixed).
- [ ] System Health tab appears.
- [ ] Timeline Compare tab appears.
- [ ] Normal baseline and current sessions can be selected.
- [ ] Missing, Extra, Delayed, Earlier, and Order changed are shown.
- [ ] Double-click jumps to the current WS event in Log Viewer.
- [ ] INI Explorer remains separate from normal logs.
- [ ] WaterSystem is not treated as WS Workstation.
