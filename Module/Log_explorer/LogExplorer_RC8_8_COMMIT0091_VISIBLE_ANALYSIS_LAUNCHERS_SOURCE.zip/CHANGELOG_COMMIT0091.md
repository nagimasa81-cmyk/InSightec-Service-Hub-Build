# Commit0091 — Visible Analysis Tool Launchers

- Added visible `Open INI Viewer`, `WS Lifecycle`, and `Timeline Compare` buttons to the actual production start-screen layout.
- Buttons are placed immediately below the primary action bar for laptop visibility.
- `Open INI Viewer` launches the independent structured INI Explorer.
- `WS Lifecycle` opens Log Explore and selects the Workstation lifecycle tab.
- `Timeline Compare` opens Log Explore and selects the lifecycle comparison tab.
- Existing Smart File Discovery INI default-OFF behavior and Commit0090 functions are retained.
