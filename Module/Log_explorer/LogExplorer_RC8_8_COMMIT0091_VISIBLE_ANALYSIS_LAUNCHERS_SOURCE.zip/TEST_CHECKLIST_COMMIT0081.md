# Commit0081 Test Checklist

1. Load WS and CSA logs, apply a CSA Quick Filter hiding the nearest timestamp, click a WS row, verify the hidden CSA row is temporarily shown and centered.
2. Apply a manual filter and repeat synchronization.
3. Apply Viewer Time Range and confirm master lookup still finds the nearest event.
4. Reload the same data through cache and verify synchronization works.
5. Verify Exact and ±1/5/10/30 sec modes.
6. Verify no-match status reports master row count.
7. Verify CallID priority and message priority still affect best-match scoring.
8. Verify WS code tooltip remains WS-only.
