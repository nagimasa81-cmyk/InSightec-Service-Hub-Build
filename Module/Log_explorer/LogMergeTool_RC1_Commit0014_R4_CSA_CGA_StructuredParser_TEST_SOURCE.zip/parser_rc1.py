from __future__ import annotations

import json
import re
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Optional

# File-level metadata is intentionally kept outside normal viewer records.
# The first parsed row also carries it in Raw under _file_metadata so it remains
# available after records are transferred to the Viewer.
CSA_CGA_FILE_METADATA: dict[str, dict[str, Any]] = {}

ROW_RE = re.compile(
    r"^\s*(?P<time>\d{1,2}:\d{2}:\d{2}(?:[:.]\d{1,6})?)\s+"
    r"(?P<type>[A-Za-z]{3})\s+(?P<num>\d+)\s*(?P<message>.*)$"
)
TIME_RE = re.compile(r"^(?P<h>\d{1,2}):(?P<m>\d{2}):(?P<s>\d{2})(?:[:.](?P<f>\d{1,6}))?$")
HEADER_PROCESS_RE = re.compile(r"Process\s*<(?P<process>[^>]+)>\s*Version<(?P<version>[^>]+)>", re.I)
HEADER_RELEASE_RE = re.compile(r"(?P<release>.*?Release.*?)\[v\s*(?P<release_date>[^\]]+)\]", re.I)
BRACKET_ORIGINAL_RE = re.compile(r"^\[(?P<original>[^\]]+)\]\s*(?P<rest>.*)$")
# A single ':' delimiter, excluding C++ '::' and drive letters such as D:\\.
SINGLE_COLON_RE = re.compile(r"(?<!:):(?![:\\])")

MONTHS = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
}

FILENAME_PATTERNS = [
    re.compile(
        r"(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)[_-]+"
        r"(?P<mon>Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[_-]+"
        r"(?P<d>\d{1,2})[_-]+(?P<h>\d{1,2})[_-]+(?P<mi>\d{1,2})"
        r"(?:[_-]+(?P<s>\d{1,2}))?[_-]+(?P<y>20\d{2})",
        re.I,
    ),
    re.compile(
        r"(?P<y>20\d{2})[_-](?P<mon>Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
        r"[_-](?P<d>\d{1,2})(?:[_-](?P<h>\d{1,2})[_-](?P<mi>\d{1,2})(?:[_-](?P<s>\d{1,2}))?)?",
        re.I,
    ),
]


def filename_datetime(path: Path) -> Optional[datetime]:
    for pattern in FILENAME_PATTERNS:
        match = pattern.search(path.name)
        if not match:
            continue
        gd = match.groupdict()
        try:
            return datetime(
                int(gd["y"]), MONTHS[gd["mon"].lower()], int(gd["d"]),
                int(gd.get("h") or 0), int(gd.get("mi") or 0), int(gd.get("s") or 0),
            )
        except (KeyError, TypeError, ValueError):
            continue
    return None


def _parse_row_time(value: str, row_date: date, previous: Optional[datetime]) -> datetime:
    match = TIME_RE.match(value)
    if not match:
        raise ValueError(f"Invalid row time: {value}")
    fraction = match.group("f") or ""
    microsecond = int((fraction + "000000")[:6]) if fraction else 0
    ts = datetime(
        row_date.year, row_date.month, row_date.day,
        int(match.group("h")), int(match.group("m")), int(match.group("s")), microsecond,
    )
    if previous and ts < previous and (previous - ts) > timedelta(hours=12):
        ts += timedelta(days=1)
    return ts


def extract_header_metadata(path: Path, lines: list[str], source_type: str) -> dict[str, Any]:
    metadata: dict[str, Any] = {
        "source_type": source_type,
        "file": path.name,
        "header_lines_skipped": min(4, len(lines)),
    }
    # The first four physical lines are header rows and never become records.
    for line in lines[:4]:
        process_match = HEADER_PROCESS_RE.search(line)
        if process_match:
            metadata["process"] = process_match.group("process").strip()
            metadata["version"] = process_match.group("version").strip()
        release_match = HEADER_RELEASE_RE.search(line)
        if release_match:
            metadata["release"] = release_match.group("release").strip()
            metadata["release_date"] = release_match.group("release_date").strip()
    CSA_CGA_FILE_METADATA[str(path.resolve())] = metadata
    return metadata


def _split_single_colon(text: str) -> tuple[str, str]:
    match = SINGLE_COLON_RE.search(text)
    if not match:
        return "", text.strip()
    return text[:match.start()].strip(), text[match.end():].strip()


def _split_sub_original(text: str) -> tuple[str, str]:
    # Indented detail lines allow either ':' or '::' as their separator.
    double_index = text.find("::")
    single_match = SINGLE_COLON_RE.search(text)
    positions: list[tuple[int, int]] = []
    if double_index >= 0:
        positions.append((double_index, 2))
    if single_match:
        positions.append((single_match.start(), 1))
    if not positions:
        return "", text.strip()
    pos, length = min(positions, key=lambda item: item[0])
    return text[:pos].strip(), text[pos + length:].strip()


def split_origin(message: str, is_indented: bool) -> tuple[str, str, str]:
    """Return Original, Sub Original and remaining Message."""
    text = message.strip()
    if not text:
        return "", "", ""

    bracket = BRACKET_ORIGINAL_RE.match(text)
    if bracket:
        return bracket.group("original").strip(), "", bracket.group("rest").strip()

    if is_indented:
        sub_original, remainder = _split_sub_original(text)
        return "", sub_original, remainder

    original, remainder = _split_single_colon(text)
    return original, "", remainder


def parse_csa_cga(path: Path, source_type: str, lines: list[str]) -> list[dict[str, Any]]:
    source = source_type.upper()
    base_dt = filename_datetime(path)
    if base_dt is None:
        raise ValueError(f"CSA/CGA filename date not found: {path.name}")

    metadata = extract_header_metadata(path, lines, source)
    records: list[dict[str, Any]] = []
    previous_ts: Optional[datetime] = None
    previous_type = ""
    previous_num = ""

    # Exactly the first four physical lines are header and are not recorded.
    for physical_line_no, raw_line in enumerate(lines[4:], start=5):
        raw = raw_line.rstrip("\r\n")
        if not raw.strip():
            continue

        row_match = ROW_RE.match(raw)
        if row_match:
            ts = _parse_row_time(row_match.group("time"), base_dt.date(), previous_ts)
            previous_ts = ts
            type_raw = row_match.group("type")
            num = row_match.group("num")
            # Preserve indentation after the standard prefix. A larger gap than
            # the normal aligned message gap is treated as one indented level.
            prefix_end = row_match.start("message")
            raw_message = row_match.group("message")
            leading = len(raw_message) - len(raw_message.lstrip(" \t"))
            is_indented = leading > 0
            message_text = raw_message.lstrip(" \t")
            previous_type = type_raw
            previous_num = num
        else:
            # Multi-line details inherit the preceding Timestamp / Type / Num.
            if previous_ts is None:
                continue
            ts = previous_ts
            type_raw = previous_type
            num = previous_num
            is_indented = True
            message_text = raw.lstrip(" \t")

        original, sub_original, message = split_origin(message_text, is_indented)
        structured: dict[str, Any] = {
            "Type": type_raw,
            "Num": num,
            "Original": original,
            "Sub Original": sub_original,
        }
        if not records:
            structured["_file_metadata"] = metadata

        records.append({
            "timestamp": ts,
            "source_type": source,
            "filename": path.name,
            "line_no": physical_line_no,
            "level": type_raw,
            "category": original or sub_original,
            "message": message,
            "raw": json.dumps(structured, ensure_ascii=False),
            "parser": f"RC1_{source}_STRUCTURED_V1",
        })

    return records


def parse_rc1_file(path: Path, source_type: str, lines: list[str]) -> Optional[list[dict[str, Any]]]:
    source = str(source_type).upper()
    if source in {"CSA", "CGA"}:
        return parse_csa_cga(path, source, lines)
    return None
