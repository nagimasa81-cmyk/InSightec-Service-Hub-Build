from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QFileDialog, QFrame, QGridLayout, QHeaderView,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow,
    QMessageBox, QPushButton, QSplitter, QTableWidget, QTableWidgetItem,
    QTextEdit, QVBoxLayout, QWidget,
)

from dialogs import show_loaded_files, show_no_supported_logs
from filter import filter_rows
from loading import SUPPORTED_TYPES, read_log_file, scan_folder
from parser import LogRow

TEMPLATES = {
    "Initial Investigation": ["WS", "CSA", "CGA"],
    "Water Investigation": ["WS", "CSA", "CGA", "WaterSystem"],
    "MR Investigation": ["WS", "mrserver", "gesyslog"],
    "Custom Investigation": [],
}


class LogPanel(QFrame):
    row_selected = Signal(str, int, str)

    def __init__(self, log_type: str, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.log_type = log_type
        self.rows: List[LogRow] = []
        self.visible_rows: List[LogRow] = []

        self.setObjectName("logPanel")
        self.setMinimumWidth(330)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)

        header = QHBoxLayout()
        title = QLabel(log_type)
        title.setObjectName("panelTitle")
        self.file_label = QLabel("No data")
        self.file_label.setObjectName("muted")
        self.load_button = QPushButton("Load File")
        self.load_button.clicked.connect(self.load_file)

        header.addWidget(title)
        header.addWidget(self.file_label, 1)
        header.addWidget(self.load_button)
        layout.addLayout(header)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Time", "Message", "Level", "Line"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.setWordWrap(False)
        self.table.verticalHeader().setVisible(False)
        self.table.itemSelectionChanged.connect(self._emit_selected)

        # Value extraction views do not use mouse-over popups in RC1.
        self.table.setMouseTracking(False)
        self.table.setToolTip("")

        layout.addWidget(self.table, 1)

    def load_file(self) -> None:
        file_name, _ = QFileDialog.getOpenFileName(
            self,
            f"Load {self.log_type}",
            "",
            "Log/Text Files (*.log *.txt *.out *.ar);;All Files (*.*)",
        )
        if file_name:
            self.load_path(Path(file_name))

    def load_path(self, path: Path) -> None:
        try:
            self.rows = read_log_file(path)
        except OSError as exc:
            QMessageBox.critical(self, "Load Error", str(exc))
            return

        self.file_label.setText(path.name)
        self.refresh()

    def set_rows(self, rows: List[LogRow], source_name: str = "Log Merge session") -> None:
        self.rows = list(rows)
        self.file_label.setText(source_name)
        self.refresh()

    def refresh(self, keyword: str = "", critical_only: bool = False) -> None:
        self.visible_rows = filter_rows(self.rows, keyword, critical_only)
        self.table.setUpdatesEnabled(False)

        try:
            self.table.setRowCount(len(self.visible_rows))
            for row_index, row in enumerate(self.visible_rows):
                items = [
                    QTableWidgetItem(row.timestamp_text),
                    QTableWidgetItem(row.message),
                    QTableWidgetItem(row.level),
                    QTableWidgetItem(str(row.line_no)),
                ]
                items[0].setData(Qt.UserRole, row.timestamp_ms)

                if row.level == "Critical":
                    background = QColor("#FDE2E2")
                elif row.level == "Warning":
                    background = QColor("#FFF4CC")
                else:
                    background = None

                for column, item in enumerate(items):
                    if background is not None:
                        item.setBackground(background)
                    self.table.setItem(row_index, column, item)
        finally:
            self.table.setUpdatesEnabled(True)

    def selected_row(self) -> Optional[LogRow]:
        selected = self.table.selectionModel().selectedRows()
        if not selected:
            return None
        index = selected[0].row()
        return self.visible_rows[index] if 0 <= index < len(self.visible_rows) else None

    def jump_to_time(self, target_ms: int, tolerance_ms: int) -> bool:
        best_index = -1
        best_diff: Optional[int] = None

        for index, row in enumerate(self.visible_rows):
            if row.timestamp_ms is None:
                continue
            diff = abs(row.timestamp_ms - target_ms)
            if best_diff is None or diff < best_diff:
                best_diff = diff
                best_index = index

        if best_index < 0:
            return False
        if tolerance_ms >= 0 and best_diff is not None and best_diff > tolerance_ms:
            return False

        self.table.selectRow(best_index)
        self.table.scrollToItem(self.table.item(best_index, 1), QTableWidget.PositionAtCenter)
        return True

    def _emit_selected(self) -> None:
        row = self.selected_row()
        if row and row.timestamp_ms is not None:
            self.row_selected.emit(self.log_type, row.timestamp_ms, row.message)


class InvestigationWorkspace(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("LogMerge Investigation Workspace RC1")
        self.resize(1500, 900)

        self.panels: Dict[str, LogPanel] = {}
        self.bookmarks: List[dict] = []
        self._sync_guard = False

        self._build_ui()
        self._apply_style()
        self.apply_template("Initial Investigation")

    def _build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        header = QHBoxLayout()
        title = QLabel("Investigation Workspace")
        title.setObjectName("mainTitle")
        header.addWidget(title)
        header.addStretch()

        header.addWidget(QLabel("Template"))
        self.template_combo = QComboBox()
        self.template_combo.addItems(TEMPLATES)
        self.template_combo.currentTextChanged.connect(self.apply_template)
        header.addWidget(self.template_combo)

        header.addWidget(QLabel("Sync"))
        self.tolerance_combo = QComboBox()
        self.tolerance_combo.addItem("Exact", 0)
        self.tolerance_combo.addItem("±1 sec", 1000)
        self.tolerance_combo.addItem("±5 sec", 5000)
        self.tolerance_combo.addItem("±10 sec", 10000)
        self.tolerance_combo.addItem("±30 sec", 30000)
        self.tolerance_combo.setCurrentIndex(2)
        header.addWidget(self.tolerance_combo)

        self.sync_check = QCheckBox("Time Sync")
        self.sync_check.setChecked(True)
        header.addWidget(self.sync_check)

        load_folder_button = QPushButton("Load Folder")
        load_folder_button.clicked.connect(self.load_folder)
        header.addWidget(load_folder_button)

        return_button = QPushButton("Return to Viewer")
        return_button.clicked.connect(self.close)
        header.addWidget(return_button)
        layout.addLayout(header)

        controls = QHBoxLayout()
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Search across visible logs")
        self.search_edit.textChanged.connect(self.apply_filter)
        controls.addWidget(self.search_edit, 1)

        self.critical_only = QCheckBox("Critical only")
        self.critical_only.toggled.connect(self.apply_filter)
        controls.addWidget(self.critical_only)

        clear_button = QPushButton("Clear")
        clear_button.clicked.connect(self.clear_filter)
        controls.addWidget(clear_button)

        bookmark_button = QPushButton("Bookmark Selected")
        bookmark_button.clicked.connect(self.add_bookmark)
        controls.addWidget(bookmark_button)
        layout.addLayout(controls)

        splitter = QSplitter(Qt.Vertical)
        layout.addWidget(splitter, 1)

        self.grid_host = QWidget()
        self.grid = QGridLayout(self.grid_host)
        splitter.addWidget(self.grid_host)

        lower = QSplitter(Qt.Horizontal)
        splitter.addWidget(lower)
        splitter.setSizes([650, 220])

        timeline_frame = self._section("Investigation Timeline")
        self.timeline = QListWidget()
        self.timeline.itemClicked.connect(self.timeline_jump)
        timeline_frame.layout().addWidget(self.timeline)
        lower.addWidget(timeline_frame)

        bookmark_frame = self._section("Bookmarks")
        self.bookmark_list = QListWidget()
        self.bookmark_list.itemClicked.connect(self.bookmark_jump)
        bookmark_frame.layout().addWidget(self.bookmark_list)
        lower.addWidget(bookmark_frame)

        notes_frame = self._section("Investigation Notes")
        self.notes = QTextEdit()
        self.notes.setPlaceholderText("Findings, actions, next steps...")
        notes_frame.layout().addWidget(self.notes)
        lower.addWidget(notes_frame)

        for log_type in SUPPORTED_TYPES:
            panel = LogPanel(log_type)
            panel.row_selected.connect(self.on_row_selected)
            self.panels[log_type] = panel

        self.statusBar().showMessage("Ready")

    @staticmethod
    def _section(title_text: str) -> QFrame:
        frame = QFrame()
        frame.setObjectName("section")
        frame_layout = QVBoxLayout(frame)
        title = QLabel(title_text)
        title.setObjectName("sectionTitle")
        frame_layout.addWidget(title)
        return frame

    def _apply_style(self) -> None:
        self.setStyleSheet("""
            QMainWindow, QWidget {
                background: #F4F7FB;
                color: #1F2937;
                font-family: Segoe UI;
                font-size: 10pt;
            }
            #mainTitle { font-size: 23px; font-weight: 700; color: #005DAA; }
            #logPanel, #section { background: white; border: 1px solid #D8E2EC; border-radius: 7px; }
            #panelTitle, #sectionTitle { font-size: 14px; font-weight: 700; color: #005DAA; }
            #muted { color: #64748B; }
            QPushButton {
                background: #005DAA;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 7px 12px;
                font-weight: 600;
            }
            QPushButton:hover { background: #0079C2; }
            QComboBox, QLineEdit, QTextEdit, QListWidget, QTableWidget {
                background: white;
                border: 1px solid #CBD5E1;
                border-radius: 4px;
            }
            QHeaderView::section { background: #EAF2F8; border: none; padding: 6px; font-weight: 600; }
            QTableWidget::item:selected { background: #B9DDF5; color: #102A43; }
        """)

    def apply_template(self, template_name: str) -> None:
        wanted = list(TEMPLATES.get(template_name, []))
        if template_name == "Custom Investigation" and not wanted:
            wanted = ["WS", "CSA", "CGA"]

        while self.grid.count():
            item = self.grid.takeAt(0)
            if item.widget():
                item.widget().setParent(None)

        columns = 2 if len(wanted) == 4 else 3
        for index, log_type in enumerate(wanted):
            panel = self.panels[log_type]
            panel.setParent(self.grid_host)
            self.grid.addWidget(panel, index // columns, index % columns)

        self.rebuild_timeline()
        self.statusBar().showMessage(f"{template_name}: {', '.join(wanted)}")

    def visible_panels(self) -> List[LogPanel]:
        result: List[LogPanel] = []
        for index in range(self.grid.count()):
            widget = self.grid.itemAt(index).widget()
            if isinstance(widget, LogPanel):
                result.append(widget)
        return result

    def load_folder(self) -> None:
        folder_name = QFileDialog.getExistingDirectory(self, "Select log folder")
        if not folder_name:
            return

        detected = scan_folder(Path(folder_name))
        if not detected:
            show_no_supported_logs(self)
            return

        for log_type, path in detected.items():
            self.panels[log_type].load_path(path)

        self.apply_filter()
        show_loaded_files(self, detected)

    def set_session_rows(self, rows_by_type: Dict[str, List[LogRow]]) -> None:
        """Integration entry point for the existing Log Merge viewer."""
        for log_type, rows in rows_by_type.items():
            if log_type in self.panels:
                self.panels[log_type].set_rows(rows)
        self.apply_filter()

    def clear_filter(self) -> None:
        self.search_edit.clear()
        self.critical_only.setChecked(False)
        self.apply_filter()

    def apply_filter(self) -> None:
        keyword = self.search_edit.text()
        critical_only = self.critical_only.isChecked()
        for panel in self.visible_panels():
            panel.refresh(keyword, critical_only)
        self.rebuild_timeline()

    def on_row_selected(self, source_type: str, timestamp_ms: int, message: str) -> None:
        if self._sync_guard:
            return

        self.statusBar().showMessage(f"{source_type} @ {self.format_time(timestamp_ms)}")
        if not self.sync_check.isChecked():
            return

        self._sync_guard = True
        try:
            tolerance = int(self.tolerance_combo.currentData())
            for panel in self.visible_panels():
                if panel.log_type != source_type:
                    panel.jump_to_time(timestamp_ms, tolerance)
        finally:
            self._sync_guard = False

    def add_bookmark(self) -> None:
        for panel in self.visible_panels():
            row = panel.selected_row()
            if row and row.timestamp_ms is not None:
                entry = {"type": panel.log_type, "time_ms": row.timestamp_ms, "message": row.message}
                self.bookmarks.append(entry)
                item = QListWidgetItem(
                    f"{panel.log_type}  {self.format_time(row.timestamp_ms)}  {row.message[:100]}"
                )
                item.setData(Qt.UserRole, entry)
                self.bookmark_list.addItem(item)
                return

        QMessageBox.information(self, "Bookmark", "Select a timestamped row first.")

    def bookmark_jump(self, item: QListWidgetItem) -> None:
        entry = item.data(Qt.UserRole)
        panel = self.panels.get(entry["type"])
        if panel:
            panel.jump_to_time(entry["time_ms"], -1)

    def rebuild_timeline(self) -> None:
        self.timeline.clear()
        events = []

        for panel in self.visible_panels():
            for row in panel.visible_rows:
                if row.timestamp_ms is not None and row.level in {"Critical", "Warning"}:
                    events.append((row.timestamp_ms, panel.log_type, row.level, row.message))

        events.sort(key=lambda value: value[0])
        for timestamp_ms, log_type, level, message in events[:1000]:
            marker = "●" if level == "Critical" else "▲"
            item = QListWidgetItem(
                f"{marker} {self.format_time(timestamp_ms)}  [{log_type}]  {message[:150]}"
            )
            item.setData(Qt.UserRole, {"type": log_type, "time_ms": timestamp_ms})
            self.timeline.addItem(item)

    def timeline_jump(self, item: QListWidgetItem) -> None:
        entry = item.data(Qt.UserRole)
        panel = self.panels.get(entry["type"])
        if panel:
            panel.jump_to_time(entry["time_ms"], -1)
            self.on_row_selected(entry["type"], entry["time_ms"], "")

    @staticmethod
    def format_time(value: int) -> str:
        hour = value // 3_600_000
        value %= 3_600_000
        minute = value // 60_000
        value %= 60_000
        second = value // 1_000
        millis = value % 1_000
        return f"{hour:02d}:{minute:02d}:{second:02d}.{millis:03d}"
