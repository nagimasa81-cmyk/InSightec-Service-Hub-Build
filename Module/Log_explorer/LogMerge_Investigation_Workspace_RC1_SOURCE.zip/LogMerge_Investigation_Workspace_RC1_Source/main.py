import sys
from PySide6.QtWidgets import QApplication
from viewer import InvestigationWorkspace


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("LogMerge Investigation Workspace RC1")
    window = InvestigationWorkspace()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
