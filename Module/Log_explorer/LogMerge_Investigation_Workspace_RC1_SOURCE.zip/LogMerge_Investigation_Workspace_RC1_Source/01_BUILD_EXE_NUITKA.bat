@echo off
setlocal
cd /d "%~dp0"

set "PYEXE=python"

%PYEXE% -m pip install --upgrade pip
if errorlevel 1 exit /b 1

%PYEXE% -m pip install -r requirements.txt
if errorlevel 1 exit /b 1

%PYEXE% -m nuitka ^
  --mode=standalone ^
  --assume-yes-for-downloads ^
  --enable-plugin=pyside6 ^
  --windows-console-mode=disable ^
  --output-dir=build ^
  --output-filename=LogMerge_Investigation_Workspace_RC1.exe ^
  main.py

if errorlevel 1 exit /b 1

echo Build completed.
exit /b 0
