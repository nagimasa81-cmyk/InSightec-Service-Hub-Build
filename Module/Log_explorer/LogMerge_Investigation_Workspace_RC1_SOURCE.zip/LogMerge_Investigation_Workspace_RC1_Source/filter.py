from __future__ import annotations

from parser import LogRow


def filter_rows(rows: list[LogRow], keyword: str = "", critical_only: bool = False) -> list[LogRow]:
    key = keyword.lower().strip()
    result: list[LogRow] = []

    for row in rows:
        if key and key not in row.message.lower():
            continue
        if critical_only and row.level != "Critical":
            continue
        result.append(row)

    return result
