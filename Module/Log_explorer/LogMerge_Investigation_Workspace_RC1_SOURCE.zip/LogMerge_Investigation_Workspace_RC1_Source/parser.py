from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional, Tuple

TIME_RE = re.compile(
    r"(?P<h>\d{1,2}):(?P<m>\d{2}):(?P<s>\d{2})(?::(?P<ms>\d{1,3})|\.(?P<ms2>\d{1,3}))?"
)

CRITICAL_WORDS = (
    "fatal", "error", "watchdog", "restart", "failed", "failure",
    "alarm", "exception", "critical", "timeout",
)
WARNING_WORDS = ("warning", "warn", "retry", "degraded")


@dataclass(slots=True)
class LogRow:
    timestamp_ms: Optional[int]
    timestamp_text: str
    message: str
    source_file: str
    line_no: int
    level: str = ""


def parse_time_ms(text: str) -> Tuple[Optional[int], str]:
    match = TIME_RE.search(text)
    if not match:
        return None, ""

    hour = int(match.group("h"))
    minute = int(match.group("m"))
    second = int(match.group("s"))
    ms_text = match.group("ms") or match.group("ms2") or "0"
    millis = int(ms_text.ljust(3, "0")[:3])

    value = ((hour * 3600 + minute * 60 + second) * 1000) + millis
    display = f"{hour:02d}:{minute:02d}:{second:02d}.{millis:03d}"
    return value, display


def classify_level(message: str) -> str:
    lower = message.lower()
    if any(word in lower for word in CRITICAL_WORDS):
        return "Critical"
    if any(word in lower for word in WARNING_WORDS):
        return "Warning"
    return ""
