from __future__ import annotations

from pathlib import Path
from typing import Dict

from PySide6.QtWidgets import QMessageBox, QWidget


def show_loaded_files(parent: QWidget, detected: Dict[str, Path]) -> None:
    lines = [f"{log_type}: {path.name}" for log_type, path in detected.items()]
    QMessageBox.information(parent, "Load Folder", "Loaded:\n" + "\n".join(lines))


def show_no_supported_logs(parent: QWidget) -> None:
    QMessageBox.information(
        parent,
        "Load Folder",
        "No supported WS / CSA / CGA / WaterSystem / mrserver / gesyslog files were detected.",
    )
