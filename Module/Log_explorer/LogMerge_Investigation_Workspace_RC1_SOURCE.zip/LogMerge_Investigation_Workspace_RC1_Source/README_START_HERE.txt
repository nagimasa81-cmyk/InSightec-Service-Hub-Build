LogMerge Investigation Workspace RC1 Source

Purpose
- RC1 viewer-first investigation prototype.
- Intended for placement in Module/Log_explorer as the latest Source ZIP.
- Compatible with build_selected_module2.yml and build_all_modules_latest_zip.yml.

RC1 structure
- main.py
- viewer.py
- loading.py
- parser.py
- filter.py
- dialogs.py

Investigation templates
1. Initial Investigation: WS / CSA / CGA
2. Water Investigation: WS / CSA / CGA / WaterSystem
3. MR Investigation: WS / mrserver / gesyslog
4. Custom Investigation placeholder

Build
- Run 01_BUILD_EXE_NUITKA.bat locally, or build from GitHub Actions.
- Nuitka standalone output is created below build/.
- Distribute the entire generated .dist folder.

Integration
- Existing Log Merge can later call InvestigationWorkspace.set_session_rows(...).
- No Controller/Manager hierarchy was added for RC1.
