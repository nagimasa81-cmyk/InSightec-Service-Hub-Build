from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable

from parser import LogRow, classify_level, parse_time_ms

SUPPORTED_TYPES = ("WS", "CSA", "CGA", "WaterSystem", "mrserver", "gesyslog")
SUPPORTED_SUFFIXES = {".log", ".txt", ".out", ".ar"}


def read_log_file(path: Path) -> list[LogRow]:
    text = path.read_text(encoding="utf-8", errors="replace")
    rows: list[LogRow] = []

    for line_no, line in enumerate(text.splitlines(), 1):
        timestamp_ms, timestamp_text = parse_time_ms(line)
        rows.append(
            LogRow(
                timestamp_ms=timestamp_ms,
                timestamp_text=timestamp_text,
                message=line,
                source_file=path.name,
                line_no=line_no,
                level=classify_level(line),
            )
        )

    return rows


def detect_log_type(path: Path) -> str:
    name = path.name.lower()

    if "watersystem" in name:
        return "WaterSystem"
    if "mrserver" in name:
        return "mrserver"
    if "gesys" in name:
        return "gesyslog"
    if "csa" in name:
        return "CSA"
    if "cga" in name:
        return "CGA"
    if name.startswith("ws") or "_ws" in name or "ws." in name:
        return "WS"

    try:
        sample = path.read_text(encoding="utf-8", errors="replace")[:5000].lower()
    except OSError:
        return ""

    if "treat_circulate" in sample or "degas_circulate" in sample:
        return "WaterSystem"
    if "mrserver" in sample or "mr timestamp" in sample:
        return "mrserver"
    if "gesys" in sample:
        return "gesyslog"

    return ""


def scan_folder(folder: Path) -> Dict[str, Path]:
    detected: Dict[str, Path] = {}

    for path in sorted(folder.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in SUPPORTED_SUFFIXES:
            continue

        log_type = detect_log_type(path)
        if log_type and log_type not in detected:
            detected[log_type] = path

    return detected
