"""Spectrum Dump analysis for Sonication Investigation.

Spectrum_*.dmp_FFT files are gzip-compressed proprietary binary dumps.
This module:
- reads stable header fields confirmed from the supplied sample,
- extracts plausible contiguous float32 spectrum blocks conservatively,
- never exposes the dump as normal Log Viewer rows,
- links the dump to Acquisition log lines by dump filename/time.
"""
from __future__ import annotations

import gzip
import math
import re
import struct
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from PySide6.QtCore import Qt, QPointF, QRectF, QTimer
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFormLayout, QHBoxLayout, QLabel,
    QListWidget, QListWidgetItem, QMessageBox, QProgressDialog, QPushButton,
    QSplitter, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
    QSlider, QGroupBox,
    QHeaderView,
)

MONTHS = {
    "Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4, "May": 5, "Jun": 6,
    "Jul": 7, "Aug": 8, "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12,
}

SPECTRUM_NAME_RE = re.compile(
    r"^Spectrum_(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)_"
    r"(?P<mon>Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)_"
    r"(?P<day>\d{1,2})_(?P<hour>\d{1,2})_(?P<minute>\d{1,2})_"
    r"(?P<second>\d{1,2})_(?P<year>20\d{2})\.dmp_FFT$",
    re.I,
)

TIME_RE = re.compile(r"^(?P<h>\d{1,2}):(?P<m>\d{2}):(?P<s>\d{2}):(?P<ms>\d{3})")


@dataclass
class SpectrumDump:
    path: Path
    timestamp: datetime | None
    cycle_count: int = 0
    spectrum_count: int = 0
    hydrophone_count: int = 0
    fft_size: int = 0
    averaging_count: int = 0
    sample_rate_hz: int = 0
    reference_hydrophone: int = -1
    acoustic_power: float = 0.0
    main_frequency_hz: float = 0.0
    hydrophone_parameters: list[float] = field(default_factory=list)
    extra_scalar: float = 0.0
    blocks: list[list[float]] = field(default_factory=list)
    decode_mode: str = "Header only"
    acquisition_file: str = ""
    acquisition_line: int = 0
    acquisition_message: str = ""
    acquisition_start: datetime | None = None

    @property
    def nyquist_hz(self) -> float:
        return max(1.0, self.sample_rate_hz / 2.0)

    def peak(self, block_index: int) -> tuple[float, float]:
        if not (0 <= block_index < len(self.blocks)):
            return 0.0, 0.0
        values = self.blocks[block_index]
        if not values:
            return 0.0, 0.0
        peak_index = max(range(len(values)), key=lambda i: values[i])
        frequency = peak_index * self.nyquist_hz / max(1, len(values) - 1)
        return frequency, values[peak_index]



def is_spectrum_dump(path: Path) -> bool:
    """Case-insensitive and suffix-tolerant Spectrum Dump detection."""
    name = path.name.lower()
    return (
        name.startswith("spectrum_")
        and (
            name.endswith(".dmp_fft")
            or name.endswith(".dmp.fft")
            or name.endswith("_dmp_fft")
            or ".dmp_fft." in name
        )
    )


def find_spectrum_dumps(paths: list[Path]) -> list[Path]:
    """Recursively search arbitrary folder depth and accept direct file drops."""
    found: dict[str, Path] = {}

    for value in paths:
        path = Path(value)
        if not path.exists():
            continue

        if path.is_file():
            if is_spectrum_dump(path):
                found[str(path.resolve()).lower()] = path
            continue

        try:
            iterator = path.rglob("*")
            for candidate in iterator:
                try:
                    if candidate.is_file() and is_spectrum_dump(candidate):
                        found[str(candidate.resolve()).lower()] = candidate
                except OSError:
                    continue
        except OSError:
            continue

    return sorted(
        found.values(),
        key=lambda item: (
            spectrum_timestamp(item) or datetime.min,
            str(item).lower(),
        ),
    )


def spectrum_timestamp(path: Path) -> datetime | None:
    match = SPECTRUM_NAME_RE.match(path.name)
    if not match:
        return None
    try:
        return datetime(
            int(match.group("year")),
            MONTHS[match.group("mon").title()],
            int(match.group("day")),
            int(match.group("hour")),
            int(match.group("minute")),
            int(match.group("second")),
        )
    except Exception:
        return None


def _safe_int(data: bytes, offset: int, default: int = 0) -> int:
    try:
        return int(struct.unpack_from("<i", data, offset)[0])
    except Exception:
        return default


def _safe_double(data: bytes, offset: int, default: float = 0.0) -> float:
    try:
        value = float(struct.unpack_from("<d", data, offset)[0])
        return value if math.isfinite(value) else default
    except Exception:
        return default


def _float_runs(data: bytes, offset: int, maximum_blocks: int) -> list[list[float]]:
    """Extract conservative positive finite float32 runs.

    The supplied dump contains repeated contiguous numeric regions separated by
    proprietary metadata. Runs between 256 and 32768 points are candidates.
    The longest candidates are used as Hydrophone spectra.
    """
    usable = len(data) - ((len(data) - offset) % 4)
    candidates: list[list[float]] = []
    current: list[float] = []

    for position in range(offset, usable, 4):
        try:
            value = float(struct.unpack_from("<f", data, position)[0])
        except Exception:
            value = float("nan")

        plausible = (
            math.isfinite(value)
            and 0.0 <= value <= 1_000_000.0
        )

        if plausible:
            current.append(value)
        else:
            if 256 <= len(current) <= 32768:
                candidates.append(current)
            current = []

    if 256 <= len(current) <= 32768:
        candidates.append(current)

    # Prefer substantial repeated blocks. Similar-length blocks usually
    # represent the configured Hydrophones in the supplied format.
    candidates.sort(key=lambda block: len(block), reverse=True)
    selected = candidates[:maximum_blocks]

    # Avoid huge UI payloads while preserving the envelope.
    output: list[list[float]] = []
    for block in selected:
        if len(block) <= 4096:
            output.append(block)
            continue
        step = len(block) / 4096.0
        reduced = [
            block[min(len(block) - 1, int(index * step))]
            for index in range(4096)
        ]
        output.append(reduced)
    return output


def parse_spectrum_dump(path: Path) -> SpectrumDump:
    timestamp = spectrum_timestamp(path)
    result = SpectrumDump(path=path, timestamp=timestamp)

    try:
        raw = gzip.decompress(path.read_bytes())
    except Exception:
        raw = path.read_bytes()

    if len(raw) < 144:
        return result

    result.cycle_count = _safe_int(raw, 0)
    result.spectrum_count = _safe_int(raw, 4)
    result.hydrophone_count = max(0, _safe_int(raw, 8))
    result.fft_size = max(0, _safe_int(raw, 12))
    result.averaging_count = max(0, _safe_int(raw, 16))
    result.sample_rate_hz = max(0, _safe_int(raw, 20))
    result.reference_hydrophone = _safe_int(raw, 24)
    result.acoustic_power = _safe_double(raw, 24)
    result.main_frequency_hz = _safe_double(raw, 32)
    result.hydrophone_parameters = [
        _safe_double(raw, 40 + index * 8)
        for index in range(min(8, max(0, result.hydrophone_count)))
    ]
    result.extra_scalar = _safe_double(raw, 104)

    block_count = result.hydrophone_count if 1 <= result.hydrophone_count <= 16 else 8
    result.blocks = _float_runs(raw, 144, block_count)
    result.decode_mode = (
        "Header + heuristic spectrum blocks"
        if result.blocks
        else "Header only"
    )
    return result


def link_acquisition(dump: SpectrumDump, root: Path, recursive: bool) -> None:
    if dump.timestamp is None or not root.exists():
        return

    iterator = root.rglob("Acquisition_*.txt") if recursive else root.glob("Acquisition_*.txt")
    target_names = {
        dump.path.name.lower(),
        dump.path.name.replace(".dmp_FFT", ".dmp").lower(),
    }

    best: tuple[float, Path, int, str, datetime | None] | None = None
    for log_path in iterator:
        try:
            lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception:
            continue

        current_date = dump.timestamp.date()
        for line_number, line in enumerate(lines, 1):
            lower = line.lower()
            exact = any(name in lower for name in target_names)

            match = TIME_RE.match(line.strip())
            line_time = None
            if match:
                try:
                    line_time = datetime(
                        current_date.year, current_date.month, current_date.day,
                        int(match.group("h")), int(match.group("m")),
                        int(match.group("s")), int(match.group("ms")) * 1000,
                    )
                except Exception:
                    line_time = None

            if exact:
                diff = 0.0
            elif line_time is not None and "saving fft data" in lower:
                diff = abs((line_time - dump.timestamp).total_seconds())
                if diff > 10:
                    continue
            else:
                continue

            start_time = None
            for previous in range(max(0, line_number - 5000), line_number - 1):
                previous_line = lines[previous]
                if "StartSpectrumMeasurementA" in previous_line:
                    time_match = TIME_RE.match(previous_line.strip())
                    if time_match:
                        start_time = datetime(
                            current_date.year, current_date.month, current_date.day,
                            int(time_match.group("h")), int(time_match.group("m")),
                            int(time_match.group("s")), int(time_match.group("ms")) * 1000,
                        )

            candidate = (diff, log_path, line_number, line.strip(), start_time)
            if best is None or candidate[0] < best[0]:
                best = candidate

    if best:
        dump.acquisition_file = best[1].name
        dump.acquisition_line = best[2]
        dump.acquisition_message = best[3]
        dump.acquisition_start = best[4]


class SpectrumPlot(QWidget):
    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.dump: SpectrumDump | None = None
        self.visible: set[int] = set()
        self.log_scale = False
        self.mode = "Spectrum Overlay"
        self.compare_dump: SpectrumDump | None = None
        self.replay_fraction = 1.0
        self.setMinimumHeight(360)

    def set_dump(self, dump: SpectrumDump | None) -> None:
        self.dump = dump
        self.visible = set(range(len(dump.blocks))) if dump else set()
        self.update()

    def _converted_blocks(self, dump: SpectrumDump) -> list[tuple[int, list[float]]]:
        output = []
        for index in sorted(self.visible):
            if index >= len(dump.blocks):
                continue
            values = dump.blocks[index]
            if self.log_scale:
                plotted = [math.log10(max(value, 1e-12)) for value in values]
                baseline = min(plotted, default=0.0)
                plotted = [value - baseline for value in plotted]
            else:
                plotted = list(values)
            output.append((index, plotted))
        return output

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.fillRect(self.rect(), QColor("#FFFFFF"))
        plot = self.rect().adjusted(70, 30, -24, -55)
        painter.setPen(QPen(QColor("#CBD5E1"), 1))
        painter.drawRect(plot)

        if self.dump is None or not self.dump.blocks:
            painter.setPen(QColor("#64748B"))
            painter.drawText(
                self.rect(),
                Qt.AlignCenter,
                "Select a Spectrum Dump.\nSpectrum Dumps are not shown in Log Viewer.",
            )
            return

        palette = [
            QColor("#005DAA"), QColor("#D97706"), QColor("#059669"),
            QColor("#7C3AED"), QColor("#DC2626"), QColor("#0891B2"),
            QColor("#9333EA"), QColor("#4D7C0F"),
        ]
        converted = self._converted_blocks(self.dump)
        if not converted:
            return

        if self.mode in {"Heatmap", "Waterfall"}:
            row_height = plot.height() / max(1, len(converted))
            global_max = max(
                (max(values, default=0.0) for _, values in converted),
                default=1.0,
            ) or 1.0

            for row, (block_index, values) in enumerate(converted):
                if not values:
                    continue
                y_top = plot.top() + row * row_height

                if self.mode == "Heatmap":
                    columns = min(512, len(values))
                    for column in range(columns):
                        source_index = int(column * len(values) / columns)
                        ratio = max(0.0, min(1.0, values[source_index] / global_max))
                        color = QColor.fromHsvF(
                            max(0.0, 0.66 - ratio * 0.66),
                            0.85,
                            0.95,
                        )
                        x = plot.left() + column * plot.width() / columns
                        painter.fillRect(
                            QRectF(
                                x,
                                y_top,
                                plot.width() / columns + 1,
                                row_height + 1,
                            ),
                            color,
                        )
                else:
                    painter.setPen(QPen(palette[block_index % len(palette)], 1.0))
                    offset = row * row_height
                    maximum = max(values, default=1.0) or 1.0
                    previous = None
                    for point_index, value in enumerate(values):
                        x = (
                            plot.left()
                            + point_index * plot.width() / max(1, len(values) - 1)
                        )
                        y = (
                            plot.top()
                            + offset
                            + row_height
                            - (value / maximum) * row_height * 0.82
                        )
                        point = QPointF(x, y)
                        if previous is not None:
                            painter.drawLine(previous, point)
                        previous = point

                painter.setPen(QColor("#334155"))
                painter.drawText(
                    8,
                    int(y_top + min(row_height - 2, 16)),
                    f"H{block_index}",
                )

        else:
            all_series = list(converted)
            if self.mode == "FFT Compare" and self.compare_dump is not None:
                for block_index, values in enumerate(self.compare_dump.blocks[:2]):
                    all_series.append((block_index + 100, values))

            maximum = max(
                (max(values, default=0.0) for _, values in all_series),
                default=1.0,
            ) or 1.0

            replay_points = None
            if self.mode == "Sonication Replay":
                replay_points = max(
                    2,
                    int(
                        max(len(values) for _, values in all_series)
                        * max(0.01, self.replay_fraction)
                    ),
                )

            for series_index, (block_index, values) in enumerate(all_series):
                if replay_points is not None:
                    values = values[:replay_points]
                if len(values) < 2:
                    continue

                if block_index >= 100:
                    pen = QPen(QColor("#111827"), 1.0, Qt.DashLine)
                else:
                    pen = QPen(palette[block_index % len(palette)], 1.2)
                painter.setPen(pen)

                previous = None
                for point_index, value in enumerate(values):
                    x = (
                        plot.left()
                        + point_index * plot.width() / max(1, len(values) - 1)
                    )
                    y = plot.bottom() - (value / maximum) * plot.height()
                    point = QPointF(x, y)
                    if previous is not None:
                        painter.drawLine(previous, point)
                    previous = point

            if self.mode == "Harmonics":
                fundamental = self.dump.main_frequency_hz
                if fundamental > 0:
                    for harmonic in range(1, 7):
                        frequency = fundamental * harmonic
                        if frequency >= self.dump.nyquist_hz:
                            break
                        x = (
                            plot.left()
                            + frequency / self.dump.nyquist_hz * plot.width()
                        )
                        painter.setPen(
                            QPen(
                                QColor("#EF4444") if harmonic == 1 else QColor("#F59E0B"),
                                1.2,
                                Qt.DashLine,
                            )
                        )
                        painter.drawLine(
                            QPointF(x, plot.top()),
                            QPointF(x, plot.bottom()),
                        )
                        painter.drawText(
                            int(x + 3),
                            plot.top() + 14 + 13 * (harmonic % 2),
                            f"{harmonic}×",
                        )

        if 0 < self.dump.main_frequency_hz < self.dump.nyquist_hz:
            x = (
                plot.left()
                + self.dump.main_frequency_hz / self.dump.nyquist_hz
                * plot.width()
            )
            painter.setPen(QPen(QColor("#EF4444"), 1.2, Qt.DashLine))
            painter.drawLine(QPointF(x, plot.top()), QPointF(x, plot.bottom()))

        painter.setPen(QColor("#475569"))
        painter.drawText(plot.left(), self.height() - 18, "0 Hz")
        painter.drawText(
            plot.right() - 85,
            self.height() - 18,
            f"{self.dump.nyquist_hz / 1_000_000:.3f} MHz",
        )
        painter.drawText(8, plot.top() + 15, "Amplitude")
        painter.drawText(
            plot.left() + 8,
            plot.top() + 18,
            self.mode,
        )


class SpectrumAnalysisWidget(QWidget):
    def __init__(self, investigation: Any = None, standalone: bool = False):
        super().__init__(investigation)
        self.investigation = investigation
        self.standalone = standalone
        self.explicit_paths: list[Path] = []
        self.dumps: list[SpectrumDump] = []
        self.checks: list[QCheckBox] = []
        self.setAcceptDrops(True)
        self._build_ui()

    def source_root(self) -> Path:
        if self.explicit_paths:
            first = self.explicit_paths[0]
            return first if first.is_dir() else first.parent

        if self.investigation is None:
            return Path(".")

        viewer = getattr(self.investigation, "viewer", None)
        parent = getattr(viewer, "parent_window", None)
        edit = getattr(parent, "source_edit", None)
        value = edit.text().strip() if edit is not None else ""
        return Path(value or ".")

    def recursive(self) -> bool:
        # Spectrum search is always recursive in Commit0024.
        return True

    def load_paths(self, values) -> None:
        self.explicit_paths = [Path(value) for value in values]
        self.reload()

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        top = QHBoxLayout()
        title = QLabel("Spectrum Analysis")
        title.setStyleSheet("font-size:18px;font-weight:700;color:#005DAA;")
        reload_button = QPushButton("Scan Spectrum Dumps")
        reload_button.clicked.connect(self.reload)
        self.scale = QComboBox()
        self.scale.addItems(["Linear", "Log"])
        self.scale.currentTextChanged.connect(self._scale_changed)

        self.display_mode = QComboBox()
        self.display_mode.addItems([
            "Spectrum Overlay",
            "Waterfall",
            "Heatmap",
            "Harmonics",
            "FFT Compare",
            "Sonication Replay",
        ])
        self.display_mode.currentTextChanged.connect(self._mode_changed)

        top.addWidget(title)
        top.addStretch(1)
        top.addWidget(QLabel("Display:"))
        top.addWidget(self.display_mode)
        top.addWidget(QLabel("Scale:"))
        top.addWidget(self.scale)
        top.addWidget(reload_button)
        root.addLayout(top)

        splitter = QSplitter(Qt.Horizontal)
        root.addWidget(splitter, 1)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.addWidget(QLabel("Spectrum Dumps"))
        self.file_list = QListWidget()
        self.file_list.currentRowChanged.connect(self.select_dump)
        left_layout.addWidget(self.file_list, 1)
        splitter.addWidget(left)

        right = QWidget()
        right_layout = QVBoxLayout(right)

        self.summary = QLabel("No Spectrum Dump selected.")
        self.summary.setWordWrap(True)
        self.summary.setStyleSheet(
            "background:#EAF2F8;border:1px solid #CBD5E1;"
            "border-radius:4px;padding:8px;"
        )
        right_layout.addWidget(self.summary)

        self.hydro_controls = QHBoxLayout()
        self.hydro_controls.addWidget(QLabel("Hydrophone candidates:"))
        self.hydro_controls.addStretch(1)
        right_layout.addLayout(self.hydro_controls)

        analysis_controls = QHBoxLayout()
        self.compare_combo = QComboBox()
        self.compare_combo.setToolTip("Select another FFT Dump for dashed comparison.")
        self.compare_combo.currentIndexChanged.connect(self._compare_changed)
        self.replay_slider = QSlider(Qt.Horizontal)
        self.replay_slider.setRange(1, 100)
        self.replay_slider.setValue(100)
        self.replay_slider.valueChanged.connect(self._replay_changed)
        self.replay_play = QPushButton("Play Replay")
        self.replay_play.clicked.connect(self._toggle_replay)
        analysis_controls.addWidget(QLabel("Compare:"))
        analysis_controls.addWidget(self.compare_combo, 1)
        analysis_controls.addWidget(QLabel("Replay:"))
        analysis_controls.addWidget(self.replay_slider, 1)
        analysis_controls.addWidget(self.replay_play)
        right_layout.addLayout(analysis_controls)

        self.replay_timer = QTimer(self)
        self.replay_timer.setInterval(80)
        self.replay_timer.timeout.connect(self._replay_tick)

        self.plot = SpectrumPlot()
        right_layout.addWidget(self.plot, 1)

        self.peaks = QTableWidget(0, 4)
        self.peaks.setHorizontalHeaderLabels(
            ["Block", "Points", "Peak Frequency", "Peak Amplitude"]
        )
        self.peaks.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.peaks.setMaximumHeight(210)
        right_layout.addWidget(self.peaks)

        splitter.addWidget(right)
        splitter.setSizes([280, 1000])

    def reload(self) -> None:
        root = self.source_root()
        if not root.exists():
            QMessageBox.warning(self, "Spectrum Analysis", "Source folder does not exist.")
            return

        search_paths = self.explicit_paths or [root]
        paths = find_spectrum_dumps(search_paths)

        progress = QProgressDialog(
            "Scanning Spectrum Dumps...", "Cancel", 0, max(1, len(paths)), self
        )
        progress.setWindowTitle("Spectrum Analysis")
        progress.setMinimumDuration(0)
        progress.show()

        dumps: list[SpectrumDump] = []
        for index, path in enumerate(paths, 1):
            if progress.wasCanceled():
                break
            progress.setValue(index - 1)
            progress.setLabelText(f"Reading {index}/{len(paths)}\n{path.name}")
            QApplication.processEvents()
            try:
                dump = parse_spectrum_dump(path)
                link_acquisition(dump, root, self.recursive())
                dumps.append(dump)
            except Exception:
                continue

        progress.setValue(len(paths))
        progress.close()

        self.dumps = dumps
        self.file_list.clear()
        self.compare_combo.blockSignals(True)
        self.compare_combo.clear()
        self.compare_combo.addItem("None", -1)
        for compare_index, compare_dump in enumerate(dumps):
            self.compare_combo.addItem(compare_dump.path.name, compare_index)
        self.compare_combo.blockSignals(False)

        for dump in dumps:
            time_text = dump.timestamp.strftime("%Y/%m/%d %H:%M:%S") if dump.timestamp else ""
            item = QListWidgetItem(
                f"{time_text}\n{dump.path.name}\n"
                f"{dump.acoustic_power:g} W / "
                f"{dump.main_frequency_hz / 1_000_000:.3f} MHz"
            )
            self.file_list.addItem(item)

        if dumps:
            self.file_list.setCurrentRow(0)
        else:
            self.plot.set_dump(None)
            self.summary.setText(
    "No Spectrum Dump was found. Search is recursive and accepts "
    "*.dmp_FFT, *.dmp.fft and case variations."
)

    def _clear_checks(self) -> None:
        while self.hydro_controls.count() > 2:
            item = self.hydro_controls.takeAt(1)
            if item.widget() is not None:
                item.widget().deleteLater()
        self.checks.clear()

    def select_dump(self, index: int) -> None:
        if not (0 <= index < len(self.dumps)):
            return
        dump = self.dumps[index]
        self.plot.set_dump(dump)
        self._clear_checks()

        for block_index in range(len(dump.blocks)):
            check = QCheckBox(f"H{block_index}")
            check.setChecked(True)
            check.toggled.connect(
                lambda checked, i=block_index: self._toggle_block(i, checked)
            )
            self.hydro_controls.insertWidget(
                max(1, self.hydro_controls.count() - 1), check
            )
            self.checks.append(check)

        linked = (
            f"{dump.acquisition_file}, line {dump.acquisition_line}"
            if dump.acquisition_file
            else "Not linked"
        )
        start = (
            dump.acquisition_start.strftime("%H:%M:%S.%f")[:-3]
            if dump.acquisition_start else "Unknown"
        )
        self.summary.setText(
            f"<b>{dump.path.name}</b><br>"
            f"Timestamp: {dump.timestamp or 'Unknown'} &nbsp; "
            f"Acoustic Power: {dump.acoustic_power:g} W &nbsp; "
            f"Main Frequency: {dump.main_frequency_hz / 1_000_000:.3f} MHz<br>"
            f"Hydrophones: {dump.hydrophone_count} &nbsp; "
            f"FFT Size: {dump.fft_size:,} &nbsp; "
            f"Sample Rate: {dump.sample_rate_hz / 1_000_000:.3f} MHz &nbsp; "
            f"Spectra: {dump.spectrum_count:,}<br>"
            f"Decode: {dump.decode_mode}<br>"
            f"Acquisition link: {linked} &nbsp; Measurement start: {start}"
        )

        self.peaks.setRowCount(len(dump.blocks))
        for row, block in enumerate(dump.blocks):
            frequency, amplitude = dump.peak(row)
            values = [
                f"H{row}",
                f"{len(block):,}",
                f"{frequency / 1_000_000:.6f} MHz",
                f"{amplitude:.8g}",
            ]
            for column, value in enumerate(values):
                self.peaks.setItem(row, column, QTableWidgetItem(value))

    def _mode_changed(self, mode: str) -> None:
        self.plot.mode = mode
        replay_enabled = mode == "Sonication Replay"
        self.replay_slider.setEnabled(replay_enabled)
        self.replay_play.setEnabled(replay_enabled)
        self.plot.update()

    def _compare_changed(self, combo_index: int) -> None:
        dump_index = self.compare_combo.itemData(combo_index)
        if isinstance(dump_index, int) and 0 <= dump_index < len(self.dumps):
            self.plot.compare_dump = self.dumps[dump_index]
        else:
            self.plot.compare_dump = None
        self.plot.update()

    def _replay_changed(self, value: int) -> None:
        self.plot.replay_fraction = max(0.01, value / 100.0)
        self.plot.update()

    def _toggle_replay(self) -> None:
        if self.replay_timer.isActive():
            self.replay_timer.stop()
            self.replay_play.setText("Play Replay")
        else:
            if self.replay_slider.value() >= 100:
                self.replay_slider.setValue(1)
            self.replay_timer.start()
            self.replay_play.setText("Pause Replay")

    def _replay_tick(self) -> None:
        value = self.replay_slider.value() + 2
        if value >= 100:
            value = 100
            self.replay_timer.stop()
            self.replay_play.setText("Play Replay")
        self.replay_slider.setValue(value)

    def _toggle_block(self, index: int, checked: bool) -> None:
        if checked:
            self.plot.visible.add(index)
        else:
            self.plot.visible.discard(index)
        self.plot.update()

    def _scale_changed(self, text: str) -> None:
        self.plot.log_scale = text == "Log"
        self.plot.update()

    def dragEnterEvent(self, event) -> None:
        if any(url.isLocalFile() for url in event.mimeData().urls()):
            event.acceptProposedAction()

    def dropEvent(self, event) -> None:
        paths = [
            Path(url.toLocalFile())
            for url in event.mimeData().urls()
            if url.isLocalFile()
        ]
        if paths:
            self.load_paths(paths)
            event.acceptProposedAction()

