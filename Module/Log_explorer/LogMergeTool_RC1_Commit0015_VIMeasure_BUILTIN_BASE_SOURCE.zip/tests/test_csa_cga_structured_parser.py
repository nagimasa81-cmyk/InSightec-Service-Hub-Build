from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from parser_rc1 import CSA_CGA_FILE_METADATA, parse_csa_cga

SAMPLE_ROOT = ROOT / "tests" / "samples"


def find_row(rows, *, message_contains: str):
    for row in rows:
        if message_contains in str(row.get("message", "")):
            return row
    raise AssertionError(f"Row not found: {message_contains}")


def run_file(filename: str, source_type: str):
    path = SAMPLE_ROOT / filename
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    rows = parse_csa_cga(path, source_type, lines)
    assert rows, f"No records parsed from {filename}"
    assert rows[0]["line_no"] == 5, "First four physical header lines must be skipped"
    metadata = CSA_CGA_FILE_METADATA[str(path.resolve())]
    assert metadata.get("version") == "6.33.25.(00)"
    assert "Jun 14 2022" in metadata.get("release_date", "")
    assert all("Process <" not in row["message"] for row in rows)
    assert all("Neuro Release" not in row["message"] for row in rows)
    return rows, metadata


def main() -> int:
    csa_rows, csa_meta = run_file("Csa_Brain_650_Thu_Jun_18_20_35_48_2026.txt", "CSA")
    cga_rows, cga_meta = run_file("CGA_Brain_650_Thu_Jun_18_20_35_43_2026.txt", "CGA")

    # Basic prefix split: Timestamp / Type / Num / Message.
    first_csa = csa_rows[0]
    assert first_csa["timestamp"].year == 2026
    first_data = json.loads(first_csa["raw"])
    assert first_data["Type"] == "Inf"
    assert first_data["Num"] == "2088"

    # Bracketed source becomes Original.
    bracket = next(row for row in csa_rows if "IsWaterSystemControl = 1" in row["message"])
    bracket_data = json.loads(bracket["raw"])
    assert bracket_data["Original"] == "WATER_SYSTEM"
    assert bracket["message"] == "IsWaterSystemControl = 1"

    # Normal first colon splits Original and Message.
    server = next(row for row in csa_rows if json.loads(row["raw"])["Original"] == "SERVER" and "connected successfully" in row["message"])
    server_data = json.loads(server["raw"])
    assert server_data["Original"] == "SERVER"
    # Text after the first colon is retained as Message, including later colons.
    assert server["message"].endswith(": was connected successfully")

    # Warning type remains the original three-letter code.
    warning = next(row for row in csa_rows if json.loads(row["raw"])["Type"] == "Wrn")
    assert warning["level"] == "Wrn"

    # Indented continuation rows inherit prefix values and use Sub Original
    # when ':' or '::' is present.
    from parser_rc1 import parse_csa_cga as parse_small
    synthetic = [
        "00:00:00:000 Inf 1000 =====",
        "00:00:00:001 Inf 1000 Process <Csa> Version<1.0>",
        "00:00:00:002 Inf 1000 Release [v Jan 1 2026 00:00:00 ]",
        "00:00:00:003 Inf 1000 =====",
        "00:00:01:000 Inf 5556 Parent message",
        "    DetailField::Detail value",
    ]
    synthetic_path = SAMPLE_ROOT / "Csa_Test_Thu_Jun_18_20_35_48_2026.txt"
    detail_rows = parse_small(synthetic_path, "CSA", synthetic)
    detail = json.loads(detail_rows[-1]["raw"])
    assert detail["Type"] == "Inf"
    assert detail["Num"] == "5556"
    assert detail["Sub Original"] == "DetailField"
    assert detail_rows[-1]["message"] == "Detail value"

    # CGA uses the same prefix structure and source extraction rules.
    cga_bracket = next(row for row in cga_rows if "IsEnableAutoPause = 1" in row["message"])
    assert json.loads(cga_bracket["raw"])["Original"] == "WATER_SYSTEM"

    print(f"CSA rows: {len(csa_rows)} | release: {csa_meta.get('release_date')}")
    print(f"CGA rows: {len(cga_rows)} | release: {cga_meta.get('release_date')}")
    print("CSA/CGA structured parser tests: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
