# Log Merge Tool RC1 Release Notes

## Commit0009 RC1 Evaluation Build
This build integrates Investigation Workspace into the existing RC1 Foundation and corrects the WaterSystem viewer parser mapping issue reported during evaluation.

Primary evaluation focus:
1. Investigation templates and time synchronization.
2. WaterSystem Event / Level / Message extraction.
3. No regression in existing Viewer, Discovery and Merge behavior.
