# Commit0016 File Type Update ZIP Builder — Test Checklist

## Sample input
- [ ] Open Builder from `Run_FileType_Update_ZIP_Builder.bat`
- [ ] Add one sample file
- [ ] Add multiple samples of the same File Type
- [ ] Add samples from a folder
- [ ] Remove selected samples

## Automatic detection
- [ ] Display name and File Type ID are suggested
- [ ] File patterns are suggested
- [ ] Encoding is detected
- [ ] Delimiter is detected
- [ ] Header and first data line are detected
- [ ] Timestamp rule and timestamp column are detected
- [ ] Columns are detected

## Specification editing
- [ ] Parser settings can be edited
- [ ] Smart Discovery label is uppercase
- [ ] New checkbox is configured before UNKNOWN
- [ ] Import and Merge settings can be changed
- [ ] Visible and hidden columns can be changed
- [ ] Default filter can be set
- [ ] Investigation profile can be selected
- [ ] Numeric chart series can be selected

## Preview and validation
- [ ] Parsed preview is shown
- [ ] Full tests run against all samples
- [ ] Field-count errors are reported with line numbers
- [ ] ZIP build is blocked after failed tests
- [ ] ZIP build is enabled after all tests pass

## Generated ZIP
- [ ] Contains manifest.json
- [ ] Contains parser.json
- [ ] Contains discovery_profile.json
- [ ] Contains viewer_defaults.json
- [ ] Contains investigation_profile.json
- [ ] Contains tests/test_report.json
- [ ] Contains sample files

## Log Merge Tool integration
- [ ] Install through Update File Type
- [ ] Reload File Types
- [ ] Checkbox appears before UNKNOWN
- [ ] Smart Discovery label is uppercase
- [ ] Viewer list contains the new File Type
- [ ] Default columns and filter are applied
- [ ] Investigation Mode shows the configured profile
- [ ] Configured numeric series can be charted
- [ ] Installation persists after EXE restart
