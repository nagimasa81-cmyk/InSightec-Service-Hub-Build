# Commit0016 — File Type Update ZIP Builder

## Added
- Load one or multiple real sample files.
- Load all supported samples from a folder.
- Automatic format, delimiter, header, column, encoding, timestamp and filename-pattern suggestions.
- Editable parser definition before generation.
- Viewer defaults: visible/hidden columns, default filter, hover, import/merge and auto-fit.
- Smart File Discovery profile with uppercase display label and placement before UNKNOWN.
- Investigation profile and chart-series selection.
- Preview of parsed records.
- Full parser validation against every sample.
- Build is blocked until all sample tests pass.
- Installable File Type Update ZIP with parser, discovery, viewer, investigation and test metadata.
