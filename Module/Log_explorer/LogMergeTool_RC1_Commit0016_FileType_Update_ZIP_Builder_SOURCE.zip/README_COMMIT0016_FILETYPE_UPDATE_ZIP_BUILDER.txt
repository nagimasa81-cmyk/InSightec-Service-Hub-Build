FILE TYPE UPDATE ZIP BUILDER

1. Run Run_FileType_Update_ZIP_Builder.bat.
2. Add one or more real sample files.
3. Click Analyze Samples.
4. Review parser, viewer, discovery and investigation settings.
5. Preview and run full tests.
6. Build File Type Update ZIP after all tests pass.
7. Install the generated ZIP from Log Merge Tool > Update File Type.

The generated Smart File Discovery display label is uppercase and is placed before UNKNOWN.
