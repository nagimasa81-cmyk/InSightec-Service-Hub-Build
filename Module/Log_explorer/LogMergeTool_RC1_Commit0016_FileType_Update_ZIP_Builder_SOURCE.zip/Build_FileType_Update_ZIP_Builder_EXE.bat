@echo off
setlocal
cd /d "%~dp0"
python -m nuitka --standalone --onefile --windows-console-mode=disable --enable-plugin=pyside6 --output-filename=FileTypeUpdateZipBuilder.exe FileTypeUpdateZipBuilder.py
if errorlevel 1 pause
