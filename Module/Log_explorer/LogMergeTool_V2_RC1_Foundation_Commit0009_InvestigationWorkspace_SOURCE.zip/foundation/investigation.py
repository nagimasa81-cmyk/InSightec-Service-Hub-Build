"""RC1 Investigation Workspace integrated with the existing Log Viewer.

Keeps the implementation intentionally small for RC1. It consumes the existing
viewer source_to_records() interface and does not duplicate parser logic.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox, QDialog, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QPushButton, QSplitter, QTableWidget, QTableWidgetItem,
    QTextEdit, QVBoxLayout, QWidget, QHeaderView, QMessageBox,
)

TEMPLATES = {
    "Initial Investigation": ["WS", "CSA", "CGA"],
    "Water Investigation": ["WS", "CSA", "CGA", "WaterSystem"],
    "MR Investigation": ["WS", "MRSERVER", "GESYS"],
}

CRITICAL_WORDS = (
    "fatal", "error", "watchdog", "restart", "failed", "failure",
    "alarm", "exception", "critical", "timeout",
)
WARNING_WORDS = ("warning", "warn", "retry", "degraded")
VALUE_SOURCES = {"WATERSYSTEM", "REVIEW", "PSC"}


def _record_timestamp(record: Any) -> datetime | None:
    return getattr(record, "timestamp", None) or getattr(record, "ts", None)


def _record_message(record: Any) -> str:
    return str(getattr(record, "message", "") or getattr(record, "raw", ""))


def _record_file(record: Any) -> str:
    return str(getattr(record, "source_file", "") or getattr(record, "file", ""))


def _record_line(record: Any) -> int:
    try:
        return int(getattr(record, "line_number", 0) or getattr(record, "line", 0))
    except Exception:
        return 0


def _level(message: str, existing: str = "") -> str:
    if existing:
        return existing
    lower = message.lower()
    if any(word in lower for word in CRITICAL_WORDS):
        return "Critical"
    if any(word in lower for word in WARNING_WORDS):
        return "Warning"
    return ""


class InvestigationWorkspace(QDialog):
    """Small RC1 workspace for synchronized multi-log investigation."""

    def __init__(self, viewer: Any):
        super().__init__(viewer)
        self.viewer = viewer
        self.setWindowTitle("Investigation Workspace")
        self.resize(1450, 850)
        self.tables: dict[str, QTableWidget] = {}
        self.rows: dict[str, list[dict[str, Any]]] = {}
        self._syncing = False
        self._build_ui()
        self.load_template()

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)

        top = QHBoxLayout()
        title = QLabel("Investigation Workspace")
        title.setStyleSheet("font-size:20px;font-weight:700;color:#005DAA;")
        self.template = QComboBox()
        self.template.addItems(TEMPLATES.keys())
        self.template.currentTextChanged.connect(self.load_template)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search visible investigation logs...")
        self.search.textChanged.connect(self.apply_search)
        self.tolerance = QComboBox()
        for text, value in [("Exact", 0), ("±1 sec", 1), ("±5 sec", 5), ("±10 sec", 10), ("±30 sec", 30)]:
            self.tolerance.addItem(text, value)
        self.tolerance.setCurrentIndex(2)
        reload_btn = QPushButton("Reload Template")
        reload_btn.clicked.connect(self.load_template)
        close_btn = QPushButton("Return to Viewer")
        close_btn.clicked.connect(self.close)
        top.addWidget(title)
        top.addSpacing(15)
        top.addWidget(QLabel("Template:"))
        top.addWidget(self.template)
        top.addWidget(QLabel("Sync:"))
        top.addWidget(self.tolerance)
        top.addWidget(self.search, 1)
        top.addWidget(reload_btn)
        top.addWidget(close_btn)
        root.addLayout(top)

        vertical = QSplitter(Qt.Vertical)
        root.addWidget(vertical, 1)

        self.pane_host = QWidget()
        self.pane_layout = QHBoxLayout(self.pane_host)
        self.pane_layout.setContentsMargins(0, 0, 0, 0)
        vertical.addWidget(self.pane_host)

        lower = QSplitter(Qt.Horizontal)
        vertical.addWidget(lower)
        vertical.setSizes([650, 190])

        timeline_box = QWidget()
        timeline_layout = QVBoxLayout(timeline_box)
        timeline_layout.addWidget(QLabel("Critical Timeline"))
        self.timeline = QListWidget()
        self.timeline.itemClicked.connect(self.timeline_jump)
        timeline_layout.addWidget(self.timeline)
        lower.addWidget(timeline_box)

        bookmark_box = QWidget()
        bookmark_layout = QVBoxLayout(bookmark_box)
        bookmark_layout.addWidget(QLabel("Bookmarks"))
        add_bookmark = QPushButton("Add Selected")
        add_bookmark.clicked.connect(self.add_bookmark)
        self.bookmarks = QListWidget()
        self.bookmarks.itemClicked.connect(self.bookmark_jump)
        bookmark_layout.addWidget(add_bookmark)
        bookmark_layout.addWidget(self.bookmarks)
        lower.addWidget(bookmark_box)

        notes_box = QWidget()
        notes_layout = QVBoxLayout(notes_box)
        notes_layout.addWidget(QLabel("Investigation Notes"))
        self.notes = QTextEdit()
        self.notes.setPlaceholderText("Findings, actions, and next steps...")
        notes_layout.addWidget(self.notes)
        lower.addWidget(notes_box)

        self.setStyleSheet("""
            QDialog, QWidget { background:#F4F7FB; font-family:Segoe UI; }
            QTableWidget, QListWidget, QTextEdit, QLineEdit, QComboBox {
                background:white; border:1px solid #CBD5E1; border-radius:4px;
            }
            QPushButton { background:#005DAA; color:white; border:0; border-radius:4px; padding:7px 11px; }
            QPushButton:hover { background:#0079C2; }
            QHeaderView::section { background:#EAF2F8; padding:5px; border:0; font-weight:600; }
        """)

    def _clear_panes(self) -> None:
        while self.pane_layout.count():
            item = self.pane_layout.takeAt(0)
            if item.widget() is not None:
                item.widget().deleteLater()
        self.tables.clear()
        self.rows.clear()

    def load_template(self) -> None:
        self._clear_panes()
        sources = TEMPLATES.get(self.template.currentText(), [])
        errors: list[str] = []
        for source in sources:
            try:
                records = list(self.viewer.source_to_records(source) or [])
            except Exception as exc:
                records = []
                errors.append(f"{source}: {exc}")
            converted: list[dict[str, Any]] = []
            for record in records:
                message = _record_message(record)
                ts = _record_timestamp(record)
                converted.append({
                    "timestamp": ts,
                    "time": ts.strftime("%Y/%m/%d %H:%M:%S.%f")[:-3] if isinstance(ts, datetime) else "",
                    "message": message,
                    "level": _level(message, str(getattr(record, "level", "") or "")),
                    "file": _record_file(record),
                    "line": _record_line(record),
                })
            self.rows[source] = converted
            self.pane_layout.addWidget(self._make_pane(source), 1)
        self.apply_search()
        if errors:
            QMessageBox.warning(self, "Investigation Workspace", "Some sources could not be loaded:\n" + "\n".join(errors))

    def _make_pane(self, source: str) -> QWidget:
        box = QWidget()
        layout = QVBoxLayout(box)
        label = QLabel(source)
        label.setStyleSheet("font-size:14px;font-weight:700;color:#005DAA;")
        table = QTableWidget(0, 4)
        table.setHorizontalHeaderLabels(["Timestamp", "Message", "Level", "Line"])
        table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        table.setSelectionBehavior(QTableWidget.SelectRows)
        table.setSelectionMode(QTableWidget.SingleSelection)
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        table.setAlternatingRowColors(True)
        table.verticalHeader().setVisible(False)
        table.itemSelectionChanged.connect(lambda s=source: self.sync_from(s))
        # Explicitly no hover popup for value-oriented sources.
        table.setMouseTracking(False)
        table.setToolTip("")
        layout.addWidget(label)
        layout.addWidget(table, 1)
        self.tables[source] = table
        return box

    def apply_search(self) -> None:
        keyword = self.search.text().strip().lower()
        self.timeline.clear()
        for source, table in self.tables.items():
            data = [row for row in self.rows.get(source, []) if not keyword or keyword in row["message"].lower()]
            table.blockSignals(True)
            table.setRowCount(len(data))
            for i, row in enumerate(data):
                time_item = QTableWidgetItem(row["time"])
                time_item.setData(Qt.UserRole, row["timestamp"])
                msg_item = QTableWidgetItem(row["message"])
                level_item = QTableWidgetItem(row["level"])
                line_item = QTableWidgetItem(str(row["line"]))
                table.setItem(i, 0, time_item)
                table.setItem(i, 1, msg_item)
                table.setItem(i, 2, level_item)
                table.setItem(i, 3, line_item)
                if row["level"].lower() in {"critical", "error", "fatal"}:
                    item = QListWidgetItem(f'{row["time"]} [{source}] {row["message"][:140]}')
                    item.setData(Qt.UserRole, (source, row["timestamp"]))
                    self.timeline.addItem(item)
            table.blockSignals(False)

    def sync_from(self, source: str) -> None:
        if self._syncing:
            return
        table = self.tables.get(source)
        if table is None:
            return
        selected = table.selectionModel().selectedRows()
        if not selected:
            return
        ts = table.item(selected[0].row(), 0).data(Qt.UserRole)
        if not isinstance(ts, datetime):
            return
        tolerance = int(self.tolerance.currentData())
        self._syncing = True
        try:
            for other_source, other_table in self.tables.items():
                if other_source == source:
                    continue
                best_row = -1
                best_diff = None
                for row in range(other_table.rowCount()):
                    other_ts = other_table.item(row, 0).data(Qt.UserRole)
                    if not isinstance(other_ts, datetime):
                        continue
                    diff = abs((other_ts - ts).total_seconds())
                    if best_diff is None or diff < best_diff:
                        best_diff = diff
                        best_row = row
                if best_row >= 0 and best_diff is not None and best_diff <= tolerance:
                    other_table.selectRow(best_row)
                    other_table.scrollToItem(other_table.item(best_row, 1), QTableWidget.PositionAtCenter)
        finally:
            self._syncing = False

    def add_bookmark(self) -> None:
        for source, table in self.tables.items():
            selected = table.selectionModel().selectedRows()
            if not selected:
                continue
            row = selected[0].row()
            text = f"{table.item(row,0).text()} [{source}] {table.item(row,1).text()[:120]}"
            item = QListWidgetItem(text)
            item.setData(Qt.UserRole, (source, table.item(row, 0).data(Qt.UserRole)))
            self.bookmarks.addItem(item)
            return
        QMessageBox.information(self, "Bookmark", "Select a row first.")

    def timeline_jump(self, item: QListWidgetItem) -> None:
        source, ts = item.data(Qt.UserRole)
        self._jump(source, ts)

    def bookmark_jump(self, item: QListWidgetItem) -> None:
        source, ts = item.data(Qt.UserRole)
        self._jump(source, ts)

    def _jump(self, source: str, ts: datetime) -> None:
        table = self.tables.get(source)
        if table is None:
            return
        for row in range(table.rowCount()):
            if table.item(row, 0).data(Qt.UserRole) == ts:
                table.selectRow(row)
                table.scrollToItem(table.item(row, 1), QTableWidget.PositionAtCenter)
                return
