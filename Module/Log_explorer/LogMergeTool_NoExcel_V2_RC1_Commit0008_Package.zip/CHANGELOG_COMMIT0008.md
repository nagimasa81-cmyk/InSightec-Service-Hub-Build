# Commit 0008 — Log Viewer Feature Freeze

Version: 2.0.0-rc1-commit0008

## Implemented

- Added pane-local column filters for Timestamp, Level, Category, Message, and any visible dynamic column.
- Added header context menu:
  - Filter `<column>`
  - Clear `<column>` Filter
  - Clear All Filters
- Active filters are indicated by `▼` in the column header.
- Added WS prefix parsing for rows such as:
  - `Ent Dbg 1432 [CCalibrationLogic::PerformAcPcScan]`
- WS Viewer rows now expose:
  - Entry
  - Level
  - Code
  - Message
- `Err` can be selected from the Level filter.
- Changed Viewer table selection to cell selection so right-clicking Message does not select the full row.
- Added cell context menu:
  - Copy Cell
  - Copy Message
  - Copy Row
  - Copy Rule Text...
  - Create Noise Rule...
  - Set Viewer Start
  - Set Viewer End
- Restored editable Copy Rule Text popup before copying.
- Kept columns resizable through interactive headers.
- Review rows continue to display extracted parameters as columns.
- Bottom detail window remains hidden.

## Internal

- Added `ColumnFilterDialog`.
- Added pane-local filter state and filter header indication.
- Updated current-row logic for cell selection.
- Version string updated to `2.0.0-rc1-commit0008`.
