# Commit 0008 Regression Report

## Static checks completed

- Python syntax compilation: PASS
- Existing build BAT files retained: PASS
- Existing Plugin Builder retained: PASS
- Existing Project export/import code retained: PASS
- Existing START/MERGE workflow override blocks retained: PASS
- Existing Smart File Discovery code retained: PASS
- Existing Viewer Time Range code retained: PASS
- Existing Noise Rule database code retained: PASS

## Targeted source review

- Filter state is pane-local and does not modify original loaded rows.
- Time range is applied before column filters.
- Clear filter restores rows from the original pane data.
- WS parsing preserves Raw data.
- Copy Rule Text requires operator confirmation/editing.
- Right-click acts on the clicked cell/current row.

## Runtime validation status

Windows 11 / PySide6 runtime validation is required by the operator after building the EXE. PySide6 is not installed in the packaging environment, so GUI smoke testing was not performed here.

## Required operator regression

1. START → Viewer first launch
2. MERGE → Viewer first launch
3. Viewer close → reopen
4. Show panes 1–4
5. Timestamp/Level/Category/Message filters
6. Level = Err filter on WS rows
7. Right-click Message → Copy Message
8. Copy Rule Text popup edit → clipboard
9. Viewer Time Range after cell-selection change
10. Noise Rule creation from selected cell row
