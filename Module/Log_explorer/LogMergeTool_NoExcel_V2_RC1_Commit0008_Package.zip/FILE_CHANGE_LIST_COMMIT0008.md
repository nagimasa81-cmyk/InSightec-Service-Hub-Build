# File Change List — Commit 0008

## Modified
- `LogMergeTool_NoExcel_Main.py`

## Added
- `CHANGELOG_COMMIT0008.md`
- `REGRESSION_REPORT_COMMIT0008.md`
- `README_COMMIT0008_JP.txt`
- `FILE_CHANGE_LIST_COMMIT0008.md`
- `Commit0008_RC1_Test_Checklist.xlsx`

## Retained unchanged
- Build BAT files
- PluginBuilder.py
- Plugin sample ZIP
- Core update sample ZIP
- JSON master files
- Reference VBA files
