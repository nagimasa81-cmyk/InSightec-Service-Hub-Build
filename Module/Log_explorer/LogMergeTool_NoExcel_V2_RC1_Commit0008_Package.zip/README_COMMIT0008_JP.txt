Commit0008 RC1 Log Viewer Feature Freeze

主な追加:
- Timestamp / Level / Category / Message の列フィルター
- 列見出し右クリックでフィルター設定・解除
- WSの Ent Dbg 1432 を Entry / Level / Code / Message に分離
- LevelでErrのみ抽出可能
- Messageセル右クリックで Copy Cell / Copy Message / Copy Row
- Copy Rule Textは編集ポップアップ後にコピー
- 列幅は従来どおりドラッグ変更可能

テスト:
1. Build_DEBUG_Console_EXE.batで先にビルド
2. STARTでログをImport
3. Viewerの列見出しを右クリック
4. Level FilterでErrを選択
5. Messageセルを右クリックしてCopy Messageを確認
6. Copy Rule Textで編集後クリップボードを確認
