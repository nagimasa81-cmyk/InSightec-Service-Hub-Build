@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================================
echo LogMergeTool RC1 Commit0055 - GitHub/Nuitka Build
echo ============================================================

where py >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python launcher "py" was not found.
  exit /b 1
)

set "PYVER="
py -3.13 -c "import sys" >nul 2>&1 && set "PYVER=-3.13"
if not defined PYVER py -3.14 -c "import sys" >nul 2>&1 && set "PYVER=-3.14"
if not defined PYVER py -3 -c "import sys" >nul 2>&1 && set "PYVER=-3"
if not defined PYVER (
  echo [ERROR] Python 3.13 or 3.14 is required.
  exit /b 1
)

py %PYVER% -m pip install --upgrade pip
if errorlevel 1 exit /b 1
py %PYVER% -m pip install --upgrade nuitka ordered-set zstandard PySide6 openpyxl
if errorlevel 1 exit /b 1

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
mkdir dist

set "PLUGIN_OPT="
if exist plugins set "PLUGIN_OPT=--include-data-dir=plugins=plugins"

py %PYVER% -m nuitka ^
  --standalone ^
  --onefile ^
  --enable-plugin=pyside6 ^
  --windows-console-mode=disable ^
  --output-dir=dist ^
  --output-filename=LogMergeTool_RC1_Commit0055.exe ^
  %PLUGIN_OPT% ^
  --include-data-file=csa_error_rules.json=csa_error_rules.json ^
  --assume-yes-for-downloads ^
  LogMergeTool_NoExcel_Main.py

if errorlevel 1 (
  echo [ERROR] Nuitka build failed.
  exit /b 1
)

echo [OK] dist\LogMergeTool_RC1_Commit0055.exe
exit /b 0
