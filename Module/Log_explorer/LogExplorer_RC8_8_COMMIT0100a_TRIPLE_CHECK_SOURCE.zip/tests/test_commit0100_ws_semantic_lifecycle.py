from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]
TEXT = (ROOT / "LogMergeTool_NoExcel_Main.py").read_text(encoding="utf-8")
RULES = json.loads((ROOT / "ws_lifecycle_rules.json").read_text(encoding="utf-8"))
META = json.loads((ROOT / "version.json").read_text(encoding="utf-8"))


def test_version_and_semantic_parser_symbols():
    assert META["version"] == "2.0.0-rc1-commit0100a"
    for token in (
        "def _c100_ws_lifecycle_events",
        "def _c100_boundary_match",
        "_c87_ws_lifecycle_events = _c100_ws_lifecycle_events",
        '"Parser Audit"',
        '"Rule Coverage"',
    ):
        assert token in TEXT


def test_rule_ids_are_unique_and_required_states_exist():
    all_rules = RULES["state_rules"] + RULES["action_rules"]
    ids = [rule["id"] for rule in all_rules]
    assert len(ids) == len(set(ids))
    states = {rule["state"] for rule in RULES["state_rules"]}
    assert {"Patient Information", "Planning", "Scan", "Thermometry", "Tracking", "Treatment", "Cooling", "Review"} <= states


def _matches(rule, text):
    return any(re.search(pattern, text, re.I) for pattern in rule["include"]) and not any(
        re.search(pattern, text, re.I) for pattern in rule.get("exclude", [])
    )


def test_specific_state_positive_and_noise_negative_examples():
    planning = next(rule for rule in RULES["state_rules"] if rule["state"] == "Planning")
    assert _matches(planning, "REVIEW PLANNING SCREEN - Rx Level EXAM")
    assert not _matches(planning, "Planning image loaded successfully")
    assert not _matches(planning, "Planning parameter: Gradient Power Level")


def test_zero_error_suppression_contract():
    for token in ("error count: 0", "errors=0", "warning count: 0", "error code: 0"):
        assert token in TEXT
    assert "_c100_is_negative_or_summary" in TEXT


def test_timeline_compare_reuses_semantic_stream():
    assert "_c87_build_sessions(_c87_ws_lifecycle_events(cache))" in TEXT
