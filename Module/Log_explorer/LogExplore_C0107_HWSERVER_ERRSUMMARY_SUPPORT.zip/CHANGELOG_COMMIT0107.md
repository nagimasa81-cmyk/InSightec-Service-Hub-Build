# Commit0107 — HwServer_Brain_*.txt and Err_*.txt file support

- Added two FILE_TYPE_PATTERNS entries so Smart File Discovery / the Viewer
  classify these filenames automatically:
  - `HWSERVER`: `^hwserver_brain.*\.(?:log|txt)$`
    (e.g. `HwServer_Brain_650_Wed_Oct_21_12_41_58_2026.txt`)
  - `ERRSUMMARY`: `^err[_-].*\.(?:log|txt)$`
    (e.g. `Err_Wed_Oct_21_12_37_51_2026.txt`)
- `Csa_Brain_650_Wed_Oct_21_12_40_50_2026.txt` already matched the existing
  `CSA` pattern and required no change.
- `parser_rc1.py`:
  - HWSERVER reuses `parse_csa_cga()` as-is: the file's 4-line
    `Process <HwServer> Version<...>` / `Neuro Release ...` header and its
    `HH:MM:SS:mmm <Lvl> <Num> <message>` rows are byte-for-byte the same
    shape already used by CSA/CGA.
  - Added `ERR_ROW_RE` and `parse_err_summary()` for ERRSUMMARY. These files
    use a 4-token row (`HH:MM:SS:mmm <Lvl> <State> <Id> <message>`) where
    `<Id>` is a free-form module/thread token (`202:`, `7202:7824`, `IL_:`)
    rather than plain digits, so the existing `WS_ROW_RE` (which requires
    `\d+`) would truncate it mid-token. `ERR_ROW_RE` captures the whole
    token instead. The trailing untimestamped "Total sammary report" block
    at the end of these files is skipped, the same way `parse_ws()` already
    skips lines that don't match its row pattern.
  - `parse_rc1_file()` dispatches `HWSERVER` to `parse_csa_cga()` and
    `ERRSUMMARY` to the new `parse_err_summary()`.
- Verified against the three real uploaded sample files: Csa_Brain (18,552
  rows), HwServer_Brain (259,527 rows), Err_ (5,042 rows) all parse without
  error through `classify_file` + `parse_rc1_file`.
- Scope note: the Excel/CSV MERGE pipeline has been fully disabled since
  Commit0021 (`MainWindow.run_clicked` is `_c21_disable_merge_workflow`), so
  no `RunOptions.include_*` flag or merge-type checkbox was added for these
  two types. Only the live path — Smart File Discovery → Log Viewer
  (`classify_file` → `parse_file`/`parse_rc1_file` → `records_by_type`) —
  was in scope, and that path is already generic/dynamic (confirmed by
  reading `discover_one_file`, `SmartFileDiscoveryDialog.apply_filter`, and
  `_c93_start_import_clicked`), so no further hardcoded type lists needed
  updating for the data to load and display correctly. The handful of
  cosmetic `preferred`/`order` type-ordering lists used only for display
  sequencing were intentionally left untouched; HWSERVER/ERRSUMMARY still
  appear (alphabetically, after the preferred types) via the existing
  `sorted(t for t in counts if t not in preferred)` fallback in both
  `populate_type_checks()` implementations.
- Added `tests/test_commit0107_hwserver_errsummary_support.py` (9 cases):
  pattern matching for both new filenames, dispatcher wiring, and two parser
  tests using representative sample lines (including the `7202:7824`
  compound-id case) run against `parser_rc1.parse_rc1_file()` directly.
- Updated application/build metadata to Commit0107 / LogExplorer_C0107
  (`version.json`, `01_BUILD_EXE_NUITKA.bat`, `insightec_build_contract.json`).
