from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN_SOURCE = (ROOT / "LogMergeTool_NoExcel_Main.py").read_text(encoding="utf-8")
PARSER_SOURCE = (ROOT / "parser_rc1.py").read_text(encoding="utf-8")

import sys
sys.path.insert(0, str(ROOT))
import parser_rc1 as rc1  # noqa: E402


def test_file_type_patterns_recognize_hwserver_and_errsummary():
    assert '("HWSERVER", re.compile(r"^hwserver_brain.*\\.(?:log|txt)$", re.I))' in MAIN_SOURCE
    assert '("ERRSUMMARY", re.compile(r"^err[_-].*\\.(?:log|txt)$", re.I))' in MAIN_SOURCE


def test_hwserver_filename_pattern_matches_real_sample_name():
    import re
    pat = re.compile(r"^hwserver_brain.*\.(?:log|txt)$", re.I)
    assert pat.match("HwServer_Brain_650_Wed_Oct_21_12_41_58_2026.txt")


def test_errsummary_filename_pattern_matches_real_sample_name():
    import re
    pat = re.compile(r"^err[_-].*\.(?:log|txt)$", re.I)
    assert pat.match("Err_Wed_Oct_21_12_37_51_2026.txt")


def test_csa_filename_pattern_already_covers_csa_brain_sample():
    # Confirms Csa_Brain_650_... needed no change; guards against regressing it.
    import re
    pat = re.compile(r"^csa_brain.*\.(?:log|txt)$", re.I)
    assert pat.match("Csa_Brain_650_Wed_Oct_21_12_40_50_2026.txt")


def test_parse_rc1_file_dispatches_hwserver_to_csa_cga_parser():
    assert "if source=='HWSERVER': return parse_csa_cga(path,source,lines)" in PARSER_SOURCE


def test_parse_rc1_file_dispatches_errsummary_to_dedicated_parser():
    assert "if source=='ERRSUMMARY': return parse_err_summary(path,lines)" in PARSER_SOURCE


def test_parse_csa_cga_on_hwserver_like_sample(tmp_path):
    path = tmp_path / "HwServer_Brain_650_Wed_Oct_21_12_41_58_2026.txt"
    lines = [
        "==================================================================\r\n",
        "Process <HwServer> Version<6.33.25.(00)>\r\n",
        "Neuro Release Reg _6.33 [v Jun 14 2022 14:25:36 ]\r\n",
        "==================================================================\r\n",
        "12:41:58:622 Inf 10672        Finish waiting loop after 0 seconds\r\n",
        "12:41:58:642 Err 1268        Server HAL connection failed\r\n",
    ]
    rows = rc1.parse_rc1_file(path, "HWSERVER", lines)
    assert rows is not None
    assert len(rows) == 2
    assert rows[0]["source_type"] == "HWSERVER"
    assert rows[0]["level"] == "Inf"
    assert "Finish waiting loop" in rows[0]["message"]
    assert rows[1]["level"] == "Err"


def test_parse_err_summary_on_err_like_sample(tmp_path):
    path = tmp_path / "Err_Wed_Oct_21_12_37_51_2026.txt"
    lines = [
        "12:37:51:933 Inf ---- 202: \t  Connected: Thread <2924>\r\n",
        "12:37:53:176 Err Dbg 7202:7824 \tfailed to insert inikey value - missing SEPERATOR\r\n",
        "\r\n",
        "******** Total sammary report ***************\r\n",
        "\tmodule : 202: Was Started: 1 Times \r\n",
    ]
    rows = rc1.parse_rc1_file(path, "ERRSUMMARY", lines)
    assert rows is not None
    # The trailing untimestamped summary block is skipped, same as parse_ws()
    # skips its own non-row lines.
    assert len(rows) == 2
    assert rows[0]["source_type"] == "ERRSUMMARY"
    assert rows[0]["category"] == "----"
    assert rows[1]["level"] == "Err"
    assert rows[1]["category"] == "Dbg"
    assert "missing SEPERATOR" in rows[1]["message"]


def test_err_row_re_captures_full_id_token_not_truncated_at_colon():
    m = rc1.ERR_ROW_RE.match("12:37:53:176 Err Dbg 7202:7824 \tfailed to insert")
    assert m is not None
    assert m.group("id") == "7202:7824"
    assert m.group("message") == "failed to insert"
