# Test Checklist — Commit0107

- [x] Python syntax compilation passes (`LogMergeTool_NoExcel_Main.py`,
      `parser_rc1.py`).
- [x] AST parse passes.
- [x] `HwServer_Brain_650_Wed_Oct_21_12_41_58_2026.txt` classifies as
      HWSERVER and parses via `parse_csa_cga()` with no exceptions
      (259,527 rows from the real uploaded sample; last row reflects the
      file being truncated mid-line at the ~16 MB upload size, not a parser
      defect).
- [x] `Err_Wed_Oct_21_12_37_51_2026.txt` classifies as ERRSUMMARY and parses
      via the new `parse_err_summary()` with no exceptions (5,042 rows from
      the real uploaded sample).
- [x] `Csa_Brain_650_Wed_Oct_21_12_40_50_2026.txt` still classifies as CSA
      and parses unchanged (18,552 rows) — confirms no regression from the
      new patterns.
- [x] `ERR_ROW_RE` captures the full module/thread id token (e.g.
      `7202:7824`, `IL_:`) instead of truncating at the first non-digit
      character the way `WS_ROW_RE`'s `\d+` would.
- [x] New regression test file
      (`tests/test_commit0107_hwserver_errsummary_support.py`, 9 cases) —
      all pass.
- [x] Full existing test suite re-run: no new failures beyond the
      pre-existing, already-stale per-commit version-literal snapshot tests
      (e.g. `test_commit0100c_version_is_last_assignment`,
      `test_commit0100ia_...cumulative_build`) that go stale every time
      `APP_VERSION` advances, independent of this change.
- [x] `classify_file()`'s Commit0023/33/34/82 wrapper chain confirmed not to
      intercept `hwserver_brain...` / `err_...` filenames (those layers only
      special-case `csa`/`cga`/`review`/`gesys`/`lais`/`psc`/`.ini`).
- [x] version.json / build bat / build contract report Commit0107.
- [ ] Manual GUI test: drop all three real sample files into Smart File
      Discovery and confirm HWSERVER/ERRSUMMARY rows display correctly in
      the Log Viewer alongside CSA.
- [ ] GitHub Windows Nuitka build verification required.
