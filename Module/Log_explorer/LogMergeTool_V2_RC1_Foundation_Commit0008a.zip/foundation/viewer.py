"""Single-entry Viewer foundation.

This module deliberately contains no application-specific imports.  The main
application passes the original MultiPaneLogViewer initializer into
``initialize_viewer_foundation``.  That removes the v41/v41.1/v41.2 chained
initializer path while preserving the existing UI and behavior.
"""
from __future__ import annotations

from typing import Any, Callable

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication, QLabel, QPushButton, QHeaderView


def _hide_legacy_view_mode(viewer: Any) -> None:
    combo = getattr(viewer, "mode_combo", None)
    if combo is not None:
        combo.hide()
    for label in viewer.findChildren(QLabel):
        if label.text().strip().lower().startswith("view mode"):
            label.hide()


def _configure_window(viewer: Any) -> None:
    screen = QApplication.primaryScreen()
    if screen is None:
        viewer.resize(1100, 650)
        return
    geo = screen.availableGeometry()
    width = min(max(860, int(geo.width() * 0.58)), max(860, geo.width() - 80))
    height = min(max(520, int(geo.height() * 0.52)), max(520, geo.height() - 80))
    viewer.resize(width, height)
    frame = viewer.frameGeometry()
    frame.moveCenter(geo.center())
    viewer.move(frame.topLeft())


def _configure_tables(viewer: Any) -> None:
    """Keep all columns operator-resizable.

    Initial widths remain compact, but no column is permanently Fixed or
    Stretch.  This is the Foundation baseline for the later layout/settings
    manager.
    """
    for table in getattr(viewer, "tables", []):
        header = table.horizontalHeader()
        header.setStretchLastSection(False)
        header.setSectionsMovable(False)
        header.setSectionResizeMode(QHeaderView.Interactive)
        # Use safe initial widths only when those columns exist.
        model = table.model()
        count = model.columnCount() if model is not None else 0
        defaults = [175, 620, 75, 95, 180, 65, 110]
        for column, width in enumerate(defaults[:count]):
            table.setColumnWidth(column, width)


def _connect_time_double_click_once(viewer: Any) -> None:
    for pane, table in enumerate(getattr(viewer, "tables", [])):
        if table.property("foundation_time_connected"):
            continue
        table.doubleClicked.connect(
            lambda _index, idx=pane: viewer.set_time_from_clicked_row(idx)
        )
        table.setProperty("foundation_time_connected", True)


def _polish_buttons(viewer: Any) -> None:
    for button in viewer.findChildren(QPushButton):
        label = button.text().strip().lower()
        if label in {"load visible logs", "load all visible", "load logs"} or "load visible" in label:
            button.setText("LOAD LOGS")
            button.setMinimumHeight(34)
            button.setMinimumWidth(110)


def _post_initialize(viewer: Any) -> None:
    _hide_legacy_view_mode(viewer)
    detail = getattr(viewer, "detail", None)
    if detail is not None:
        detail.hide()
        detail.setMaximumHeight(0)

    checks = getattr(viewer, "pane_visible_checks", [])
    for index, checkbox in enumerate(checks):
        checkbox.setChecked(index < 2)

    refresh = getattr(viewer, "refresh_available_sources", None)
    if callable(refresh):
        refresh()

    _configure_tables(viewer)
    _connect_time_double_click_once(viewer)
    _polish_buttons(viewer)
    _configure_window(viewer)

    update = getattr(viewer, "update_view_mode", None)
    if callable(update):
        update()


def initialize_viewer_foundation(
    viewer: Any,
    parent_window: Any,
    base_initializer: Callable[[Any, Any], None],
) -> None:
    """Create MultiPaneLogViewer through one deterministic initializer."""
    base_initializer(viewer, parent_window)
    _post_initialize(viewer)
