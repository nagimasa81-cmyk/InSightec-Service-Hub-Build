# Commit0054a Test Checklist

- [ ] Application starts from `Run_Source_Debug.bat`.
- [ ] Nuitka build succeeds using existing BAT.
- [ ] Quick Filter All/Error/Warning/Info/Critical updates displayed rows.
- [ ] Global text search is case-insensitive.
- [ ] Header Contains (`Column~value`) works.
- [ ] Header Exact (`Column=value`) works and does not behave as Contains.
- [ ] Column names match case-insensitively.
- [ ] Viewer start/end time combines with Quick and text filters.
- [ ] Clearing the pane filter restores rows subject to time/Quick filters.
- [ ] Pane 1–4 filters remain independent.
- [ ] Event synchronization still selects the nearest displayed timestamp.
- [ ] File label shows `Displayed x/y`.
- [ ] Startup log records filter pipeline time without exceptions.
