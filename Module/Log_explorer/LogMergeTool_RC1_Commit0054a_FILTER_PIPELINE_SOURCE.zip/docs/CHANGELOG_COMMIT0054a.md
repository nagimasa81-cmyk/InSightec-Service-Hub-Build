# Commit0054a — Shared Filter Pipeline

- Added `foundation/filter_engine.py` with Qt-independent `FilterState`, expression parsing and one-pass filtering.
- Unified Viewer time range, Quick Filter, global text, column Contains (`Column~value`) and Exact (`Column=value`) behavior.
- Added case-insensitive column-name resolution and whitespace-normalized comparisons.
- Added per-pane filter diagnostics: loaded/displayed rows and pipeline execution time.
- Updated application version to `2.0.0-rc1-commit0054a`.
- Preserved source rows, pane synchronization indexes, existing UI and GitHub/Nuitka build workflow.
