from datetime import datetime, timedelta
import importlib.util
from pathlib import Path

module_path = Path(__file__).resolve().parents[1] / "foundation" / "filter_engine.py"
spec = importlib.util.spec_from_file_location("filter_engine_under_test", module_path)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
import sys
sys.modules[spec.name] = module
spec.loader.exec_module(module)
FilterState = module.FilterState
apply_filter_pipeline = module.apply_filter_pipeline


def severity(row):
    return row.get("Severity", "OTHER")


def run_tests():
    t0 = datetime(2026, 1, 1, 10, 0, 0)
    rows = [
        {"_ts": t0, "Type": "Err", "Message": "Pump Failed", "Severity": "ERROR"},
        {"_ts": t0 + timedelta(seconds=1), "Type": "Inf", "Message": "Pump ready", "Severity": "INFO"},
        {"_ts": t0 + timedelta(seconds=2), "Type": "Wrn", "Message": "High Temp", "Severity": "WARNING"},
    ]

    assert len(apply_filter_pipeline(rows, FilterState(), severity).rows) == 3
    assert len(apply_filter_pipeline(rows, FilterState(quick_mode="ERR"), severity).rows) == 1
    assert len(apply_filter_pipeline(rows, FilterState(expression="pump"), severity).rows) == 2
    assert len(apply_filter_pipeline(rows, FilterState(expression="Message~PUMP"), severity).rows) == 2
    assert len(apply_filter_pipeline(rows, FilterState(expression="Type=err"), severity).rows) == 1
    assert len(apply_filter_pipeline(rows, FilterState(expression="Type=er"), severity).rows) == 0
    assert len(apply_filter_pipeline(rows, FilterState(start=t0 + timedelta(seconds=1)), severity).rows) == 2
    assert len(apply_filter_pipeline(rows, FilterState(quick_mode="WARNING", expression="temp"), severity).rows) == 1

    try:
        apply_filter_pipeline(rows, FilterState(start=t0 + timedelta(seconds=1), end=t0), severity)
    except ValueError:
        pass
    else:
        raise AssertionError("Invalid time range must raise ValueError")


if __name__ == "__main__":
    run_tests()
    print("Commit0054a filter engine tests: PASS")
