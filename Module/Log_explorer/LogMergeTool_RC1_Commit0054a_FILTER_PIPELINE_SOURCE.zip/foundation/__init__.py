"""Foundation modules for the Version 2.0 RC1 refactor.

Imports are intentionally lazy so non-UI shared modules (for example the
filter engine) do not require PySide6 merely by importing this package.
"""
from __future__ import annotations

from typing import Any

__all__ = ["initialize_viewer_foundation"]


def initialize_viewer_foundation(*args: Any, **kwargs: Any):
    from .viewer import initialize_viewer_foundation as implementation

    return implementation(*args, **kwargs)
