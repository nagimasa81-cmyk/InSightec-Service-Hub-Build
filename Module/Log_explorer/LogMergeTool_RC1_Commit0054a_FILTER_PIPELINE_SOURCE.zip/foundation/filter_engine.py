# -*- coding: utf-8 -*-
"""Shared in-memory filtering for Log Merge Tool viewers.

Commit0054a centralizes Quick, text/column and time-range filtering so every
viewer pane follows the same deterministic pipeline without mutating source rows.
This module intentionally has no Qt dependency and can be reused by other tools.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from time import perf_counter
from typing import Any, Callable, Iterable, Mapping, Sequence


class FilterMode(str, Enum):
    GLOBAL = "global"
    CONTAINS = "contains"
    EXACT = "exact"


@dataclass(frozen=True, slots=True)
class TextFilter:
    mode: FilterMode = FilterMode.GLOBAL
    value: str = ""
    column: str | None = None

    @property
    def active(self) -> bool:
        return bool(self.value)


@dataclass(slots=True)
class FilterState:
    quick_mode: str = "ALL"
    expression: str = ""
    start: datetime | None = None
    end: datetime | None = None
    timestamp_key: str = "_ts"


@dataclass(frozen=True, slots=True)
class FilterDiagnostics:
    loaded_rows: int
    displayed_rows: int
    elapsed_ms: float
    quick_mode: str
    expression: str


@dataclass(frozen=True, slots=True)
class FilterResult:
    rows: list[Mapping[str, Any]]
    diagnostics: FilterDiagnostics


def normalize_text(value: Any) -> str:
    return " ".join(str(value or "").split()).casefold()


def normalize_quick_mode(value: Any) -> str:
    mode = str(value or "ALL").strip().upper()
    aliases = {
        "WARN": "WARNING",
        "WRN": "WARNING",
        "ERR": "ERROR",
        "SEVERE": "CRITICAL",
        "FATAL": "CRITICAL",
        "FTL": "CRITICAL",
        "INF": "INFO",
    }
    mode = aliases.get(mode, mode)
    return mode if mode in {"ALL", "ERROR", "WARNING", "INFO", "CRITICAL", "OTHER"} else "ALL"


def parse_expression(expression: Any) -> TextFilter:
    raw = str(expression or "").strip()
    if not raw:
        return TextFilter()

    # Column~value is a case-insensitive partial match.
    if "~" in raw:
        column, value = raw.split("~", 1)
        column = column.strip()
        if column:
            return TextFilter(FilterMode.CONTAINS, normalize_text(value), column)

    # Column=value is a case-insensitive exact match.
    if "=" in raw:
        column, value = raw.split("=", 1)
        column = column.strip()
        if column:
            return TextFilter(FilterMode.EXACT, normalize_text(value), column)

    return TextFilter(FilterMode.GLOBAL, normalize_text(raw), None)


def row_value(row: Mapping[str, Any], column: str | None) -> Any:
    if not column:
        return ""
    wanted = normalize_text(column)
    for key, value in row.items():
        if normalize_text(key) == wanted:
            return value
    return ""


def text_filter_matches(row: Mapping[str, Any], text_filter: TextFilter) -> bool:
    if not text_filter.active:
        return True

    if text_filter.mode is FilterMode.CONTAINS:
        return text_filter.value in normalize_text(row_value(row, text_filter.column))

    if text_filter.mode is FilterMode.EXACT:
        return normalize_text(row_value(row, text_filter.column)) == text_filter.value

    searchable = " ".join(
        normalize_text(value)
        for key, value in row.items()
        if str(key) != "_ts"
    )
    return text_filter.value in searchable


def apply_filter_pipeline(
    rows: Sequence[Mapping[str, Any]] | Iterable[Mapping[str, Any]],
    state: FilterState,
    severity_resolver: Callable[[Mapping[str, Any]], str],
) -> FilterResult:
    """Apply time -> quick severity -> text/column filters in one pass."""
    started = perf_counter()
    source_rows = rows if isinstance(rows, Sequence) else list(rows)
    quick_mode = normalize_quick_mode(state.quick_mode)
    text_filter = parse_expression(state.expression)

    if state.start and state.end and state.start > state.end:
        raise ValueError("Viewer start time must not be later than end time.")

    output: list[Mapping[str, Any]] = []
    for row in source_rows:
        timestamp = row.get(state.timestamp_key)
        if state.start or state.end:
            if not isinstance(timestamp, datetime):
                continue
            if state.start and timestamp < state.start:
                continue
            if state.end and timestamp > state.end:
                continue

        if quick_mode != "ALL":
            severity = normalize_quick_mode(severity_resolver(row))
            if severity != quick_mode:
                continue

        if not text_filter_matches(row, text_filter):
            continue

        output.append(row)

    elapsed_ms = (perf_counter() - started) * 1000.0
    return FilterResult(
        rows=output,
        diagnostics=FilterDiagnostics(
            loaded_rows=len(source_rows),
            displayed_rows=len(output),
            elapsed_ms=elapsed_ms,
            quick_mode=quick_mode,
            expression=str(state.expression or "").strip(),
        ),
    )
