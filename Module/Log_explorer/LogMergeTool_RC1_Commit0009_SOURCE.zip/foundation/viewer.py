"""Viewer Foundation fixes for RC1.

Provides a single deterministic viewer initialization path and keeps layout
recovery controls in one place.  No application-specific parser logic lives
here.
"""
from __future__ import annotations

from types import MethodType
from typing import Any, Callable

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication,
    QLabel,
    QPushButton,
    QHeaderView,
    QAbstractItemView,
    QHBoxLayout,
    QMessageBox,
    QInputDialog,
)


def _hide_legacy_view_mode(viewer: Any) -> None:
    combo = getattr(viewer, "mode_combo", None)
    if combo is not None:
        combo.hide()
    for label in viewer.findChildren(QLabel):
        if label.text().strip().lower().startswith("view mode"):
            label.hide()


def _available_geometry(viewer: Any):
    screen = None
    try:
        screen = viewer.screen()
    except Exception:
        pass
    if screen is None:
        screen = QApplication.primaryScreen()
    return screen.availableGeometry() if screen is not None else None


def _configure_window(viewer: Any) -> None:
    """Keep the Viewer completely inside the active screen."""
    geo = _available_geometry(viewer)
    if geo is None:
        viewer.resize(1100, 650)
        return
    width = min(max(900, int(geo.width() * 0.82)), max(900, geo.width() - 40))
    height = min(max(560, int(geo.height() * 0.78)), max(560, geo.height() - 40))
    viewer.resize(width, height)
    x = geo.x() + max(0, (geo.width() - width) // 2)
    y = geo.y() + max(0, (geo.height() - height) // 2)
    viewer.move(x, y)


def _interactive_widths(viewer: Any, pane_index: int) -> None:
    tables = getattr(viewer, "tables", [])
    models = getattr(viewer, "models", [])
    if not (0 <= pane_index < len(tables)):
        return
    table = tables[pane_index]
    header = table.horizontalHeader()
    header.setStretchLastSection(False)
    header.setSectionsMovable(False)
    header.setSectionResizeMode(QHeaderView.Interactive)
    model = models[pane_index] if pane_index < len(models) else table.model()
    columns = list(getattr(model, "columns", []) or [])
    default_by_name = {
        "Timestamp": 165,
        "Entry": 60,
        "Level": 65,
        "Code": 75,
        "Category": 105,
        "Message": 520,
        "SourceType": 105,
        "File": 180,
        "Line": 65,
        "Parameter": 180,
        "Value": 180,
    }
    count = model.columnCount() if model is not None else 0
    for col in range(count):
        name = columns[col] if col < len(columns) else ""
        width = default_by_name.get(name, 135)
        # Do not overwrite a width the operator already adjusted.
        if table.columnWidth(col) <= 0 or table.columnWidth(col) > 1400:
            table.setColumnWidth(col, width)
        elif name in default_by_name and not table.property("foundation_widths_initialized"):
            table.setColumnWidth(col, width)
        header.setSectionResizeMode(col, QHeaderView.Interactive)
    table.setProperty("foundation_widths_initialized", True)


def _configure_tables(viewer: Any) -> None:
    for idx, table in enumerate(getattr(viewer, "tables", [])):
        table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        table.setTextElideMode(Qt.ElideRight)
        _interactive_widths(viewer, idx)


def _install_interactive_width_override(viewer: Any) -> None:
    """Prevent legacy code from restoring Fixed/Stretch modes after a load."""
    def apply_table_column_widths(self: Any, idx: int) -> None:
        _interactive_widths(self, idx)

    viewer.apply_table_column_widths = MethodType(apply_table_column_widths, viewer)


def _connect_time_double_click_once(viewer: Any) -> None:
    for pane, table in enumerate(getattr(viewer, "tables", [])):
        if table.property("foundation_time_connected"):
            continue
        table.doubleClicked.connect(
            lambda _index, idx=pane: viewer.set_time_from_clicked_row(idx)
        )
        table.setProperty("foundation_time_connected", True)


def _polish_buttons(viewer: Any) -> None:
    for button in viewer.findChildren(QPushButton):
        label = button.text().strip().lower()
        if label in {"load visible logs", "load all visible", "load logs"} or "load visible" in label:
            button.setText("LOAD LOGS")
            button.setMinimumHeight(34)
            button.setMinimumWidth(110)


def _reset_layout(viewer: Any) -> None:
    _configure_window(viewer)
    checks = getattr(viewer, "pane_visible_checks", [])
    for index, checkbox in enumerate(checks):
        checkbox.blockSignals(True)
        checkbox.setChecked(index < 2)
        checkbox.blockSignals(False)
    update = getattr(viewer, "update_view_mode", None)
    if callable(update):
        update()
    splitter = getattr(viewer, "main_splitter", None)
    if splitter is not None:
        visible = getattr(viewer, "visible_indices", lambda: [0, 1])()
        each = 1000 // max(1, len(visible))
        splitter.setSizes([each if i in visible else 0 for i in range(len(getattr(viewer, "panes", [])))])
    for idx, table in enumerate(getattr(viewer, "tables", [])):
        table.setProperty("foundation_widths_initialized", False)
        _interactive_widths(viewer, idx)
    status = getattr(viewer, "status", None)
    if status is not None:
        status.setText("Viewer layout reset.")


def _fit_columns(viewer: Any) -> None:
    for idx, table in enumerate(getattr(viewer, "tables", [])):
        table.resizeColumnsToContents()
        # Keep Message practical and every column interactive after auto-fit.
        model = getattr(viewer, "models", [])[idx]
        for col, name in enumerate(getattr(model, "columns", []) or []):
            if name == "Message":
                table.setColumnWidth(col, min(700, max(320, table.columnWidth(col))))
            else:
                table.setColumnWidth(col, min(320, max(55, table.columnWidth(col))))
        _interactive_widths(viewer, idx)
    status = getattr(viewer, "status", None)
    if status is not None:
        status.setText("Columns fitted. Drag any header boundary to adjust further.")


def _install_layout_buttons(viewer: Any) -> None:
    if getattr(viewer, "foundation_reset_layout_btn", None) is not None:
        return
    root = viewer.layout()
    if root is None:
        return
    bar = QHBoxLayout()
    bar.addStretch(1)
    reset_btn = QPushButton("Reset Layout")
    fit_btn = QPushButton("Fit Columns")
    reset_btn.setToolTip("Restore window position, pane sizes, and default column widths.")
    fit_btn.setToolTip("Fit visible column contents, then keep every column manually resizable.")
    reset_btn.clicked.connect(lambda: _reset_layout(viewer))
    fit_btn.clicked.connect(lambda: _fit_columns(viewer))
    bar.addWidget(fit_btn)
    bar.addWidget(reset_btn)
    # Put controls above the status line and below the tables.
    insert_at = max(0, root.count() - 1)
    root.insertLayout(insert_at, bar)
    viewer.foundation_reset_layout_btn = reset_btn
    viewer.foundation_fit_columns_btn = fit_btn


def _install_copy_rule_editor(viewer: Any) -> None:
    """Restore editable popup before copying rule text."""
    def copy_rule_text(self: Any, side: Any) -> None:
        idx = self.side_index(side)
        rec = self.selected_record_from_pane(idx)
        if rec is None:
            QMessageBox.information(self, "Copy Rule Text", "Select a row first.")
            return
        # _compact_pattern is resolved from the original method's module globals.
        original = getattr(self, "_foundation_original_copy_rule", None)
        compact = None
        if original is not None:
            func = getattr(original, "__func__", original)
            compact_fn = getattr(func, "__globals__", {}).get("_compact_pattern")
            if callable(compact_fn):
                compact = compact_fn(rec.message or rec.raw)
        suggested = compact if compact is not None else str(rec.message or rec.raw).strip()
        edited, ok = QInputDialog.getMultiLineText(
            self,
            "Copy Rule Text",
            "Edit the rule text, then select OK to copy it:",
            suggested,
        )
        if not ok:
            return
        text = edited.strip()
        if not text:
            QMessageBox.information(self, "Copy Rule Text", "Nothing was copied because the text is empty.")
            return
        QApplication.clipboard().setText(text)
        self.log(f"Copied edited {self.pane_name(idx)} rule text to clipboard: {text}")

    viewer._foundation_original_copy_rule = getattr(viewer, "copy_rule_text", None)
    viewer.copy_rule_text = MethodType(copy_rule_text, viewer)




def _install_investigation_button(viewer: Any) -> None:
    if getattr(viewer, "foundation_investigation_btn", None) is not None:
        return
    root = viewer.layout()
    if root is None:
        return
    button = QPushButton("Investigation Workspace")
    button.setToolTip("Open synchronized investigation views: Initial, Water, or MR Investigation.")

    def open_workspace() -> None:
        try:
            from foundation.investigation import InvestigationWorkspace
            window = InvestigationWorkspace(viewer)
            viewer._investigation_workspace = window
            window.show()
            window.raise_()
            window.activateWindow()
        except Exception as exc:
            QMessageBox.critical(viewer, "Investigation Workspace", f"Failed to open Investigation Workspace.\n\n{exc}")

    button.clicked.connect(open_workspace)
    bar = QHBoxLayout()
    bar.addWidget(button)
    bar.addStretch(1)
    root.insertLayout(1, bar)
    viewer.foundation_investigation_btn = button

def _post_initialize(viewer: Any) -> None:
    _hide_legacy_view_mode(viewer)
    detail = getattr(viewer, "detail", None)
    if detail is not None:
        detail.hide()
        detail.setMaximumHeight(0)

    checks = getattr(viewer, "pane_visible_checks", [])
    for index, checkbox in enumerate(checks):
        checkbox.setChecked(index < 2)

    refresh = getattr(viewer, "refresh_available_sources", None)
    if callable(refresh):
        refresh()

    _install_interactive_width_override(viewer)
    _install_copy_rule_editor(viewer)
    _configure_tables(viewer)
    _connect_time_double_click_once(viewer)
    _polish_buttons(viewer)
    _install_layout_buttons(viewer)
    _install_investigation_button(viewer)
    _configure_window(viewer)

    update = getattr(viewer, "update_view_mode", None)
    if callable(update):
        update()


def initialize_viewer_foundation(
    viewer: Any,
    parent_window: Any,
    base_initializer: Callable[[Any, Any], None],
) -> None:
    """Create MultiPaneLogViewer through one deterministic initializer."""
    base_initializer(viewer, parent_window)
    _post_initialize(viewer)
