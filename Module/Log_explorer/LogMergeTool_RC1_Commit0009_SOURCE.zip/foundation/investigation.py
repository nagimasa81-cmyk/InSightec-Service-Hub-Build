"""RC1 Investigation Workspace integrated with the existing Log Viewer.

Keeps the implementation intentionally small for RC1. It consumes the existing
viewer source_to_records() interface and does not duplicate parser logic.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QFileDialog, QHBoxLayout, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QPushButton, QSplitter, QTableWidget,
    QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget, QHeaderView, QMessageBox,
)

TEMPLATES = {
    "Initial Investigation": ["WS", "CSA", "CGA"],
    "Water Investigation": ["WS", "CSA", "CGA", "WaterSystem"],
    "MR Investigation": ["WS", "MRSERVER", "GESYS"],
}

CRITICAL_WORDS = (
    "fatal", "error", "watchdog", "restart", "failed", "failure",
    "alarm", "exception", "critical", "timeout",
)
WARNING_WORDS = ("warning", "warn", "retry", "degraded")
VALUE_SOURCES = {"WATERSYSTEM", "REVIEW", "PSC"}


def _record_timestamp(record: Any) -> datetime | None:
    return getattr(record, "timestamp", None) or getattr(record, "ts", None)


def _record_message(record: Any) -> str:
    return str(getattr(record, "message", "") or getattr(record, "raw", ""))


def _record_file(record: Any) -> str:
    return str(getattr(record, "source_file", "") or getattr(record, "file", ""))


def _record_line(record: Any) -> int:
    try:
        return int(getattr(record, "line_number", 0) or getattr(record, "line", 0))
    except Exception:
        return 0


def _level(message: str, existing: str = "") -> str:
    if existing:
        return existing
    lower = message.lower()
    if any(word in lower for word in CRITICAL_WORDS):
        return "Critical"
    if any(word in lower for word in WARNING_WORDS):
        return "Warning"
    return ""


class InvestigationWorkspace(QDialog):
    """Small RC1 workspace for synchronized multi-log investigation."""

    def __init__(self, viewer: Any):
        super().__init__(viewer)
        self.viewer = viewer
        self.setWindowTitle("Investigation Workspace")
        self.resize(1450, 850)
        self.tables: dict[str, QTableWidget] = {}
        self.rows: dict[str, list[dict[str, Any]]] = {}
        self._syncing = False
        self._build_ui()
        self.load_template()

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)

        top = QHBoxLayout()
        title = QLabel("Investigation Workspace")
        title.setStyleSheet("font-size:20px;font-weight:700;color:#005DAA;")
        self.template = QComboBox()
        self.template.addItems(TEMPLATES.keys())
        self.template.currentTextChanged.connect(self.load_template)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search visible investigation logs...")
        self.search.textChanged.connect(self.apply_search)
        self.tolerance = QComboBox()
        for text, value in [("Exact", 0), ("±1 sec", 1), ("±5 sec", 5), ("±10 sec", 10), ("±30 sec", 30)]:
            self.tolerance.addItem(text, value)
        self.tolerance.setCurrentIndex(2)
        reload_btn = QPushButton("Reload Template")
        reload_btn.clicked.connect(self.load_template)
        close_btn = QPushButton("Return to Viewer")
        close_btn.clicked.connect(self.close)
        top.addWidget(title)
        top.addSpacing(15)
        top.addWidget(QLabel("Template:"))
        top.addWidget(self.template)
        top.addWidget(QLabel("Sync:"))
        top.addWidget(self.tolerance)
        top.addWidget(self.search, 1)
        top.addWidget(reload_btn)
        top.addWidget(close_btn)
        root.addLayout(top)

        vertical = QSplitter(Qt.Vertical)
        root.addWidget(vertical, 1)

        self.pane_host = QWidget()
        self.pane_layout = QHBoxLayout(self.pane_host)
        self.pane_layout.setContentsMargins(0, 0, 0, 0)
        vertical.addWidget(self.pane_host)

        lower = QSplitter(Qt.Horizontal)
        vertical.addWidget(lower)
        vertical.setSizes([650, 190])

        timeline_box = QWidget()
        timeline_layout = QVBoxLayout(timeline_box)
        timeline_header = QHBoxLayout()
        timeline_header.addWidget(QLabel("Critical Timeline"))
        self.show_critical = QCheckBox("Critical")
        self.show_warning = QCheckBox("Warning")
        self.show_critical.setChecked(True)
        self.show_warning.setChecked(True)
        self.show_critical.toggled.connect(self.apply_search)
        self.show_warning.toggled.connect(self.apply_search)
        timeline_header.addStretch()
        timeline_header.addWidget(self.show_critical)
        timeline_header.addWidget(self.show_warning)
        timeline_layout.addLayout(timeline_header)
        self.summary = QLabel("Critical: 0   Warning: 0   Restart: 0   Watchdog: 0   Timeout: 0")
        self.summary.setStyleSheet("font-weight:600;color:#334155;")
        timeline_layout.addWidget(self.summary)
        self.timeline = QListWidget()
        self.timeline.itemClicked.connect(self.timeline_jump)
        timeline_layout.addWidget(self.timeline)
        lower.addWidget(timeline_box)

        bookmark_box = QWidget()
        bookmark_layout = QVBoxLayout(bookmark_box)
        bookmark_layout.addWidget(QLabel("Bookmarks"))
        bookmark_buttons = QHBoxLayout()
        add_bookmark = QPushButton("Add Selected")
        add_bookmark.clicked.connect(self.add_bookmark)
        export_bookmark = QPushButton("Export CSV")
        export_bookmark.clicked.connect(self.export_bookmarks)
        bookmark_buttons.addWidget(add_bookmark)
        bookmark_buttons.addWidget(export_bookmark)
        self.bookmarks = QListWidget()
        self.bookmarks.itemClicked.connect(self.bookmark_jump)
        bookmark_layout.addLayout(bookmark_buttons)
        bookmark_layout.addWidget(self.bookmarks)
        lower.addWidget(bookmark_box)

        notes_box = QWidget()
        notes_layout = QVBoxLayout(notes_box)
        notes_layout.addWidget(QLabel("Investigation Notes"))
        self.notes = QTextEdit()
        self.notes.setPlaceholderText("Findings, actions, and next steps...")
        notes_layout.addWidget(self.notes)
        lower.addWidget(notes_box)

        self.setStyleSheet("""
            QDialog, QWidget { background:#F4F7FB; font-family:Segoe UI; }
            QTableWidget, QListWidget, QTextEdit, QLineEdit, QComboBox {
                background:white; border:1px solid #CBD5E1; border-radius:4px;
            }
            QPushButton { background:#005DAA; color:white; border:0; border-radius:4px; padding:7px 11px; }
            QPushButton:hover { background:#0079C2; }
            QHeaderView::section { background:#EAF2F8; padding:5px; border:0; font-weight:600; }
        """)

    def _clear_panes(self) -> None:
        while self.pane_layout.count():
            item = self.pane_layout.takeAt(0)
            if item.widget() is not None:
                item.widget().deleteLater()
        self.tables.clear()
        self.rows.clear()

    def load_template(self) -> None:
        self._clear_panes()
        sources = TEMPLATES.get(self.template.currentText(), [])
        errors: list[str] = []
        for source in sources:
            try:
                records = list(self.viewer.source_to_records(source) or [])
            except Exception as exc:
                records = []
                errors.append(f"{source}: {exc}")
            converted: list[dict[str, Any]] = []
            for record in records:
                message = _record_message(record)
                ts = _record_timestamp(record)
                converted.append({
                    "timestamp": ts,
                    "time": ts.strftime("%Y/%m/%d %H:%M:%S.%f")[:-3] if isinstance(ts, datetime) else "",
                    "message": message,
                    "level": _level(message, str(getattr(record, "level", "") or "")),
                    "file": _record_file(record),
                    "line": _record_line(record),
                })
            self.rows[source] = converted
            self.pane_layout.addWidget(self._make_pane(source), 1)
        self.apply_search()
        if errors:
            QMessageBox.warning(self, "Investigation Workspace", "Some sources could not be loaded:\n" + "\n".join(errors))

    def _make_pane(self, source: str) -> QWidget:
        box = QWidget()
        layout = QVBoxLayout(box)
        label = QLabel(source)
        label.setStyleSheet("font-size:14px;font-weight:700;color:#005DAA;")
        table = QTableWidget(0, 4)
        table.setHorizontalHeaderLabels(["Timestamp", "Message", "Level", "Line"])
        table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        table.setSelectionBehavior(QTableWidget.SelectRows)
        table.setSelectionMode(QTableWidget.SingleSelection)
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        table.setAlternatingRowColors(True)
        table.verticalHeader().setVisible(False)
        table.itemSelectionChanged.connect(lambda s=source: self.sync_from(s))
        # Explicitly no hover popup for value-oriented sources.
        table.setMouseTracking(False)
        table.setToolTip("")
        layout.addWidget(label)
        layout.addWidget(table, 1)
        self.tables[source] = table
        return box

    def apply_search(self) -> None:
        keyword = self.search.text().strip().lower()
        self.timeline.clear()
        counts = {"critical": 0, "warning": 0, "restart": 0, "watchdog": 0, "timeout": 0}
        for source, table in self.tables.items():
            data = [row for row in self.rows.get(source, []) if not keyword or keyword in row["message"].lower()]
            table.blockSignals(True)
            table.setRowCount(len(data))
            for i, row in enumerate(data):
                time_item = QTableWidgetItem(row["time"])
                time_item.setData(Qt.UserRole, row["timestamp"])
                msg_item = QTableWidgetItem(row["message"])
                level_item = QTableWidgetItem(row["level"])
                line_item = QTableWidgetItem(str(row["line"]))
                table.setItem(i, 0, time_item)
                table.setItem(i, 1, msg_item)
                table.setItem(i, 2, level_item)
                table.setItem(i, 3, line_item)

                level = row["level"].lower()
                message_lower = row["message"].lower()
                is_critical = level in {"critical", "error", "fatal", "alarm"}
                is_warning = level in {"warning", "warn"}
                if is_critical:
                    counts["critical"] += 1
                if is_warning:
                    counts["warning"] += 1
                if "restart" in message_lower:
                    counts["restart"] += 1
                if "watchdog" in message_lower or "watch dog" in message_lower:
                    counts["watchdog"] += 1
                if "timeout" in message_lower:
                    counts["timeout"] += 1

                show_event = (is_critical and self.show_critical.isChecked()) or (is_warning and self.show_warning.isChecked())
                if show_event:
                    item = QListWidgetItem(f'{row["time"]} [{source}] {row["message"][:140]}')
                    item.setData(Qt.UserRole, (source, row["timestamp"]))
                    self.timeline.addItem(item)
            table.blockSignals(False)

        self.summary.setText(
            f'Critical: {counts["critical"]}   Warning: {counts["warning"]}   '
            f'Restart: {counts["restart"]}   Watchdog: {counts["watchdog"]}   '
            f'Timeout: {counts["timeout"]}'
        )

    def sync_from(self, source: str) -> None:
        if self._syncing:
            return
        table = self.tables.get(source)
        if table is None:
            return
        selected = table.selectionModel().selectedRows()
        if not selected:
            return
        ts = table.item(selected[0].row(), 0).data(Qt.UserRole)
        if not isinstance(ts, datetime):
            return
        tolerance = int(self.tolerance.currentData())
        self._syncing = True
        try:
            for other_source, other_table in self.tables.items():
                if other_source == source:
                    continue
                best_row = -1
                best_diff = None
                for row in range(other_table.rowCount()):
                    other_ts = other_table.item(row, 0).data(Qt.UserRole)
                    if not isinstance(other_ts, datetime):
                        continue
                    diff = abs((other_ts - ts).total_seconds())
                    if best_diff is None or diff < best_diff:
                        best_diff = diff
                        best_row = row
                if best_row >= 0 and best_diff is not None and best_diff <= tolerance:
                    other_table.selectRow(best_row)
                    other_table.scrollToItem(other_table.item(best_row, 1), QTableWidget.PositionAtCenter)
        finally:
            self._syncing = False

    def add_bookmark(self) -> None:
        for source, table in self.tables.items():
            selected = table.selectionModel().selectedRows()
            if not selected:
                continue
            row = selected[0].row()
            text = f"{table.item(row,0).text()} [{source}] {table.item(row,1).text()[:120]}"
            item = QListWidgetItem(text)
            item.setData(Qt.UserRole, (source, table.item(row, 0).data(Qt.UserRole)))
            self.bookmarks.addItem(item)
            return
        QMessageBox.information(self, "Bookmark", "Select a row first.")


    def export_bookmarks(self) -> None:
        if self.bookmarks.count() == 0:
            QMessageBox.information(self, "Bookmarks", "No bookmarks to export.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Bookmarks", "investigation_bookmarks.csv", "CSV Files (*.csv)"
        )
        if not path:
            return
        import csv
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as handle:
                writer = csv.writer(handle)
                writer.writerow(["Timestamp", "Source", "Message"])
                for index in range(self.bookmarks.count()):
                    item = self.bookmarks.item(index)
                    source, ts = item.data(Qt.UserRole)
                    text = item.text()
                    timestamp = ts.strftime("%Y/%m/%d %H:%M:%S.%f")[:-3] if isinstance(ts, datetime) else ""
                    message = text.split("] ", 1)[1] if "] " in text else text
                    writer.writerow([timestamp, source, message])
        except Exception as exc:
            QMessageBox.critical(self, "Export Bookmarks", str(exc))
            return
        QMessageBox.information(self, "Export Bookmarks", f"Saved:\n{path}")

    def timeline_jump(self, item: QListWidgetItem) -> None:
        source, ts = item.data(Qt.UserRole)
        self._jump(source, ts)

    def bookmark_jump(self, item: QListWidgetItem) -> None:
        source, ts = item.data(Qt.UserRole)
        self._jump(source, ts)

    def _jump(self, source: str, ts: datetime) -> None:
        table = self.tables.get(source)
        if table is None:
            return
        for row in range(table.rowCount()):
            if table.item(row, 0).data(Qt.UserRole) == ts:
                table.selectRow(row)
                table.scrollToItem(table.item(row, 1), QTableWidget.PositionAtCenter)
                return
