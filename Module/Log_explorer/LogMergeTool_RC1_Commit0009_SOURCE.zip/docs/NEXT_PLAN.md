# Next Plan

## Commit0010 — Viewer RC1 Completion
- Time Range completion
- Context Menu completion
- Filter and Search verification
- Reset Layout
- Fit Columns
- Layout persistence
- Timestamp fixed column verification
- Message-priority default verification
- Show1–Show4 stability

No RC2 Dashboard, Reliability, Forecast or AI functionality will be added.
