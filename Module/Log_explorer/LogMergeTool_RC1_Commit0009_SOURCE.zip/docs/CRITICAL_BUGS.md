# Log Merge Tool RC1 Critical Bugs

## LM-001 — WaterSystem ERROR duplicated across columns
Priority: Critical
Status: Fixed in Commit0009; verification required

Expected:
- Level: ERROR only when the Error State is not NO_ERROR
- Category: WaterSystem event name
- Message: labelled Event / Cooling / Error values

## LM-002 — WaterSystem message extraction incomplete
Priority: Critical
Status: Fixed in Commit0009; verification required

## LM-003 — WaterSystem category mapped to ERROR
Priority: High
Status: Fixed in Commit0009; verification required

## RC1 exit criteria
- Critical open bugs: 0
- High open bugs: 0
- No startup, Viewer or Merge crash
