Commit0056 - Startup and Viewer Click Path Fix

Fixed defects
-------------
1. Startup NameError
   Commit0055 accidentally assigned MultiPaneLogViewer.row_selected to the undefined name _f54_ro.
   It now correctly assigns _f54_row_selected.

2. Stray module-level identifier
   Removed the accidental standalone identifier w_selected near the end of the main module.

3. Hardened first-click path
   Normal row selection updates only the selected-row detail. Event Sync remains OFF by default.
   Cross-pane synchronization is deferred with QTimer and only runs when Enable Event Sync is checked.

4. Diagnostic trace
   Viewer selection steps are written to:
       LogMergeTool_Commit0056_click_trace.log
   The file is created in the EXE current working directory.

GitHub build
------------
Run:
    01_BUILD_EXE_GITHUB.bat

Output:
    dist\LogMergeTool_RC1_Commit0056.exe

Validation performed
--------------------
- Python syntax compilation
- AST parse
- check for accidental standalone module-level names
- build BAT target/name verification
- ZIP integrity test

Note
----
The Linux preparation environment cannot execute the final Windows GUI EXE.
