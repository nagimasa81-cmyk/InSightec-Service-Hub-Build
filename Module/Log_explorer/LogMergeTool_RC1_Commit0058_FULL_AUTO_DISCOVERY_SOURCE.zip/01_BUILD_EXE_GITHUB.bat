@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
py -3.13 -m pip install --upgrade pip
py -3.13 -m pip install nuitka ordered-set zstandard PySide6 openpyxl
py -3.13 -m nuitka --standalone --onefile --enable-plugin=pyside6 --assume-yes-for-downloads --windows-console-mode=disable --output-dir=dist --output-filename=LogMergeTool_RC1_Commit0058.exe LogMergeTool_NoExcel_Main.py
if errorlevel 1 exit /b 1
exit /b 0
