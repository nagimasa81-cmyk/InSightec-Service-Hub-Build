Commit0055 - Viewer First-Click Hang Fix

Observed symptom:
Log Viewer opens, then the first mouse interaction causes Windows to show
"Not Responding" and the busy cursor continues.

Fix:
- A normal row click now performs local detail display only.
- Event Sync has an explicit master checkbox and is OFF by default.
- Optional cross-pane synchronization runs on the next Qt event-loop turn.
- Candidate evaluation is limited to the nearest 120 entries per pane.
- Only the best synchronized row is selected.
- Message/Raw detail display is capped to prevent huge text blocking the UI.
- Re-entry protection remains active.

Build:
Run 01_BUILD_EXE_GITHUB.bat in GitHub Actions / Windows.
