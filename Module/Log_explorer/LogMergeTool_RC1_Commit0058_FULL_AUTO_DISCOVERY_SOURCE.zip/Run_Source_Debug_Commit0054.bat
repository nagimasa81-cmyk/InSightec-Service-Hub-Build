@echo off
setlocal
cd /d "%~dp0"
set "PYTHONFAULTHANDLER=1"
set "QT_LOGGING_RULES=qt.qpa.*=false"
py -3.13 LogMergeTool_NoExcel_Main.py
if errorlevel 1 py -3.14 LogMergeTool_NoExcel_Main.py
pause
