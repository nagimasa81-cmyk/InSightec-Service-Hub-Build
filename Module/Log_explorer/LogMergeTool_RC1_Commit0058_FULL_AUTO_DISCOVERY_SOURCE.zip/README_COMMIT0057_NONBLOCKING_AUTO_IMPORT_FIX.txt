Commit0057

- Selection/drop automatically starts import.
- Smart Discovery default selection is automatically accepted.
- Main window minimizes when Viewer opens.
- Viewer parsing runs in QThread.
- selectionChanged removed; detail updates only on actual click.

Build: 01_BUILD_EXE_GITHUB.bat
