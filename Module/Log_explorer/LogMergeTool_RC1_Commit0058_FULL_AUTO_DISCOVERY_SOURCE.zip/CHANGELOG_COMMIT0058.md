# Commit0058 — Fully Automatic Discovery Import

- Folder, file, ZIP and drag-and-drop inputs continue directly into import.
- Smart File Discovery no longer requires Use checkboxes or START.
- Every supported detected file is selected automatically.
- The obsolete "No file is checked" path is bypassed.
- Unsupported/UNKNOWN files and discovery-error entries are excluded.
- Main window is minimized when Log Viewer opens.
