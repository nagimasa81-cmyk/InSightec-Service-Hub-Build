# Commit0054 — Click Freeze / Event Sync Stabilization

## Fixed call path

`QTableView.selectionChanged` → `MultiPaneLogViewer.row_selected` → `_f53_sync_other_panes` → `_f53_select_rows`

Commit0053 selected up to 2,000 synchronized rows by calling `selectionModel.select()` once per row. Each call could emit selection notifications and trigger repaint/selection work. In a one-file Nuitka EXE this appeared as **click → freeze**.

## Changes

- Replaced per-row selection with one batched `QItemSelection` operation.
- Blocked selection-model signals and table updates during synchronized selection.
- Added click re-entry guard for compiled Qt behavior.
- Limited sync candidates to 1,000 and highlighted rows to 500.
- Preserved primary-row selection and auto-scroll.
- Added `01_BUILD_EXE_GITHUB.bat` for Python 3.13/3.14 + Nuitka builds.
- Added `Run_Source_Debug_Commit0054.bat` with Python fault handler enabled.
