# Commit0095b — WS Lifecycle triple-check stabilization

- Preserves the Commit0095a `_show_selected_details` class ownership fix.
- Restores numeric `version.json.commit` compatibility (`0095`) and records patch revision separately (`b`).
- Re-runs WS Lifecycle, Operation Timeline, Timeline Compare and INI regression tests.
