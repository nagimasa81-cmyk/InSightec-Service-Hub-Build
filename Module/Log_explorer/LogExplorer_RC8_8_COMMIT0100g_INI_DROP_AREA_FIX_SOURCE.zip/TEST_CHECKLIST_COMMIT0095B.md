# Commit0095b Test Checklist

- [x] Python compile passes
- [x] `WSLifecycleWidget._show_selected_details` exists in the correct class
- [x] signal connection resolves statically
- [x] empty selection path is safe
- [x] Event Details fields are present
- [x] `version.json.commit` remains numeric-compatible
- [x] Timeline Compare regression passes
- [x] INI Explorer regression passes
- [x] ZIP CRC passes
