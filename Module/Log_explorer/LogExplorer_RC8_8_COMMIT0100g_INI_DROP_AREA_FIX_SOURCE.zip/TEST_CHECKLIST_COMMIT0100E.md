# Commit0100e Test Checklist

1. Start Log Explore: INI Viewer does not open.
2. Open INI Viewer from MAIN before discovery: viewer opens empty and waits for selection.
3. Run Smart File Discovery with multiple INIs while viewer is open: list refreshes, viewer remains open, no INI is auto-selected.
4. Run discovery first, then press MAIN Open INI Viewer: all selected INIs appear and no INI is auto-selected.
5. Select each INI from the File combo and confirm content changes correctly.
6. Confirm Compare requires explicit File A and File B selections.
7. Run discovery again and confirm old session INIs are replaced.
