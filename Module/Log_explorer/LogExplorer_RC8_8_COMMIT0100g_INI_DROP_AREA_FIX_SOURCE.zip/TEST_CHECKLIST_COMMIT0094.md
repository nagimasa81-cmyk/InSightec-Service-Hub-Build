# Commit0094 Test Checklist

- [x] File A can be loaded independently through Browse A.
- [x] File B can be loaded independently through Browse B.
- [x] File A drop target accepts one INI file.
- [x] File B drop target accepts one INI file.
- [x] Newly selected files are added to Loaded Files.
- [x] Comparison rejects identical A/B selection.
- [x] Compare filters remain operational.
- [x] Difference double-click opens Browse at the selected key.
- [x] Python syntax compilation passes.
- [x] ZIP integrity passes.
