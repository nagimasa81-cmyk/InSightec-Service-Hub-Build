# Commit0095 — WS Operation Timeline

- Expanded WS Lifecycle from startup/shutdown events to an operation timeline.
- Added Session events: login, logout, lock, unlock.
- Added Application events: start, ready, activate, minimize, restore, quit, crash.
- Added Workflow events: patient/protocol/planning/treatment/review transitions.
- Added User Action extraction for Continue, Pause, Resume, Retry, Cancel, Abort, Save, Apply, Accept, Confirm, Next, Previous, Export, Import and Quit when operator/UI evidence exists.
- Added System events for warning, error, timeout, recovery and communication loss/restoration.
- Added Operation, Code and CallID columns.
- Added Operation Summary and Event Details tabs with nearby-event context.
- Preserved Unified Import Engine, Master Timeline jump, INI Compare and Timeline Compare.
