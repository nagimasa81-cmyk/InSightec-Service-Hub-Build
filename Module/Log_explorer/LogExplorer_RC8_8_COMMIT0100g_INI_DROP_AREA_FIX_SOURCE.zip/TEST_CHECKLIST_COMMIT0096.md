# Commit0096 Test Checklist

- [x] Smart File Discovery passes session.ini_files to IniExplorerDialogV2.
- [x] Legacy IniExplorerDialog is not used by Unified Import handoff.
- [x] Existing standalone INI Viewer receives additional imported INIs.
- [x] Standalone INI Viewer preloads current Unified Import INIs.
- [x] Duplicate full paths are ignored by _add_ini_paths.
- [x] INI Compare File A/File B remains available.
- [x] Python source compiles.
