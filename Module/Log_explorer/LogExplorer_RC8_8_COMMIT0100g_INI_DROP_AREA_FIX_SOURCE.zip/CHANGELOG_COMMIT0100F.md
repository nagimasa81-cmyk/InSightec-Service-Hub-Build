# Commit0100f

- Reworked Spectrum Analysis upper chart into true Band Energy Analysis.
- Band Energy now integrates squared FFT magnitude by physical-frequency bands.
- Added selectable 5/10/20/50 kHz band width.
- Upper chart uses band-center frequency and independent energy scaling.
- Lower Raw FFT chart remains individual FFT-bin amplitude versus frequency.
- Packet table Band Energy now reports the selected-width energy around each channel peak.
