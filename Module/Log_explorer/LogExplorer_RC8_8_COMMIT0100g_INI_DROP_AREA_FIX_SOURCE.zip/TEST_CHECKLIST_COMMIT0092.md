# Commit0092 Test Checklist

- [x] WS Lifecycle reuses already loaded WS records.
- [x] WS Lifecycle opens Smart File Discovery when WS cache is empty.
- [x] Timeline Compare opens Smart File Discovery when WS cache is empty.
- [x] Selected files are parsed immediately; manual LOAD LOGS is not required.
- [x] Non-WS selection produces a clear warning.
- [x] INI files are excluded from lifecycle parsing.
- [x] Timeline Compare warns when fewer than two sessions exist.
- [x] ZIP extraction remains alive after successful loading.
