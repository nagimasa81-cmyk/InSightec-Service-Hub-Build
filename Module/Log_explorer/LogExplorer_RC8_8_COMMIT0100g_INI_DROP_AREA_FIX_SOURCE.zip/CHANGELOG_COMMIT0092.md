# Commit0092 — WS analysis Smart Discovery handoff

- Fixed WS Lifecycle and Timeline Compare launchers opening empty analysis tabs.
- Both launchers now reuse Smart File Discovery.
- If no WS data is loaded, the launcher asks for a folder/ZIP, opens discovery, parses the selected logs immediately, stores them in the common cache, and then opens the requested analysis tab.
- INI files are ignored for WS analysis.
- Timeline Compare warns when fewer than two lifecycle sessions are available.
- Existing loaded WS cache is reused without selecting files again.
