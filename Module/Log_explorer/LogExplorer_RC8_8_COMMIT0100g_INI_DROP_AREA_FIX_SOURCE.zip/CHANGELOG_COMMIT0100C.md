# Commit0100c

- CSA default columns changed to Timestamp, Status, Message.
- Added derived CSA Status display while preserving raw parsed fields.
- CSA panes apply the Err quick filter on first load.
- Event Sync default changed from ±5 sec to ±30 sec.
- Custom/legacy sync controls initialize to 30 seconds for consistency.
