from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'LogMergeTool_NoExcel_Main.py').read_text(encoding='utf-8')


def test_csa_default_columns_are_timestamp_status_message():
    assert 'return ["Timestamp", "Status", "Message"]' in SOURCE


def test_csa_default_quick_filter_is_error():
    assert 'modes[pane_index] = "ERROR"' in SOURCE


def test_event_sync_default_is_30_seconds():
    assert 'self.sync_mode_combo.setCurrentText("±30 sec")' in SOURCE
    assert 'self.sync_custom_spin.setValue(30)' in SOURCE


def test_commit0100c_version_is_last_assignment():
    assert SOURCE.rstrip().endswith('APP_VERSION = "2.0.0-rc1-commit0100c"')
