from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / 'LogMergeTool_NoExcel_Main.py'
TEXT = SRC.read_text(encoding='utf-8')

def test_commit0095_version_and_categories():
    assert '2.0.0-rc1-commit0095' in TEXT
    for token in ['"User Action"', '"System"', '"Session lock"', '"Session unlock"']:
        assert token in TEXT

def test_user_action_dictionary():
    for action in ['Continue', 'Pause', 'Resume', 'Retry', 'Cancel', 'Abort', 'Save', 'Apply', 'Accept', 'Confirm', 'Next', 'Previous', 'Export', 'Import', 'Quit']:
        assert f'("{action}",' in TEXT
    assert '_C95_ACTION_CONTEXT' in TEXT

def test_operation_details_ui():
    for token in ['"Operation Summary"', '"Event Details"', '"Operation"', '"Code"', '"CallID"', 'Nearby lifecycle events']:
        assert token in TEXT

def test_ws_only_restriction_preserved():
    assert 'if _f44_type(source_type) != "WS":' in TEXT
