from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "LogMergeTool_NoExcel_Main.py").read_text(encoding="utf-8")
META = json.loads((ROOT / "version.json").read_text(encoding="utf-8"))


def test_version_consistency():
    # Commit0097a is a retained-feature regression test. Newer commits must not
    # fail merely because the application version legitimately advanced.
    assert META["version"].startswith("2.0.0-rc1-commit")
    assert str(META["commit"]).lower() in META["version"].lower()
    assert f'APP_VERSION = "{META["version"]}"' in SOURCE
    assert "2.0.0-rc1-commit0097a" in SOURCE


def test_operation_chart_table_sync_contract():
    assert "eventClicked = Signal(int)" in SOURCE
    assert "self.timeline.eventClicked.connect(self._select_timeline_event)" in SOURCE
    assert "self.table.itemSelectionChanged.connect(self._sync_timeline_from_table)" in SOURCE
    assert "self.table.selectRow(index)" in SOURCE
    assert "QAbstractItemView.PositionAtCenter" in SOURCE


def test_requested_columns_only_filter_contract():
    assert "if column in (0, 9) or column < 0:" in SOURCE
    for label in (
        '"Category"', '"Actor"', '"Severity"', '"Sonication"',
        '"Phase"', '"Confidence"', '"CorrelationID"', '"Source"',
    ):
        assert label in SOURCE
    assert "header.customContextMenuRequested.connect(self._show_column_filter_menu)" in SOURCE


def test_ini_session_handoff_is_exact_and_reusable():
    assert "def set_session_ini_paths(self, candidates):" in SOURCE
    assert "viewer.set_session_ini_paths(initial_paths)" in SOURCE
    assert "explorer.set_session_ini_paths(session.ini_files)" in SOURCE
    assert "Current Smart File Discovery session" in SOURCE


def test_operation_timeline_handles_midnight():
    assert "seconds=timestamp.timestamp()" in SOURCE
    assert 'label_time.strftime("%H:%M:%S")' in SOURCE
