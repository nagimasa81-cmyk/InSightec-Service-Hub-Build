from pathlib import Path
import ast

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "LogMergeTool_NoExcel_Main.py"


def test_c100_wrapper_delegates_with_supported_legacy_arguments():
    tree = ast.parse(MAIN.read_text(encoding="utf-8"))
    wrapper = next(
        node for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == "_c100_ws_init"
    )
    calls = [
        node for node in ast.walk(wrapper)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "_c100_original_ws_init"
    ]
    assert len(calls) == 1
    call = calls[0]
    assert len(call.args) == 3, "legacy constructor must receive self, parent_window, event_viewer only"
    assert not call.keywords


def test_commit0100b_version_is_consistent():
    source = MAIN.read_text(encoding="utf-8")
    assert 'APP_VERSION = "2.0.0-rc1-commit0100b"' in source
