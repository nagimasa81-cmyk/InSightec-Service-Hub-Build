from pathlib import Path
import ast

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "LogMergeTool_NoExcel_Main.py"

def test_ws_lifecycle_details_method_belongs_to_widget():
    tree = ast.parse(MAIN.read_text(encoding="utf-8"))
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "WSLifecycleWidget")
    methods = {n.name for n in cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
    assert "_show_selected_details" in methods

def test_patch_version():
    text = MAIN.read_text(encoding="utf-8")
    assert "2.0.0-rc1-commit0095" in text
