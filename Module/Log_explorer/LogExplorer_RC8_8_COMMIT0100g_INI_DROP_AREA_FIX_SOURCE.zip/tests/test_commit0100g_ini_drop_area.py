from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1] / "LogMergeTool_NoExcel_Main.py"
text = SOURCE.read_text(encoding="utf-8")


def test_dedicated_main_ini_drop_target_exists():
    assert "class _IniImportDropTarget(QLabel):" in text
    assert "self.setAcceptDrops(True)" in text
    assert "def dragMoveEvent(self, event):" in text
    assert "def dragLeaveEvent(self, event):" in text


def test_main_drop_area_uses_dedicated_target():
    assert "self.drop_hint = _IniImportDropTarget(self._handle_main_drop, self)" in text


def test_main_drop_supports_files_and_recursive_folders():
    assert "def _handle_main_drop(self, dropped_paths):" in text
    assert 'path.rglob("*")' in text
    assert 'item.suffix.casefold() == ".ini"' in text
    assert "self._add_ini_paths(candidates)" in text


def test_dialog_background_drop_routes_to_same_handler():
    class_start = text.index("class IniExplorerDialogV2(QDialog):")
    dialog = text[class_start:]
    assert "self._handle_main_drop(paths)" in dialog
    assert "event.acceptProposedAction()" in dialog
