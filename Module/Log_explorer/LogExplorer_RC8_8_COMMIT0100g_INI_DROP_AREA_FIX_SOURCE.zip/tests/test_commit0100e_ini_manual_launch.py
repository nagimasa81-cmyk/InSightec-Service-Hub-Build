from pathlib import Path

SOURCE = (Path(__file__).resolve().parents[1] / "LogMergeTool_NoExcel_Main.py").read_text(encoding="utf-8")


def test_discovery_does_not_create_or_show_ini_viewer():
    start = SOURCE.index("def _c93_start_import_clicked")
    end = SOURCE.index("def _c93_open_ws_lifecycle", start)
    block = SOURCE[start:end]
    assert 'explorer = IniExplorerDialogV2(session.ini_files, self)' not in block
    assert 'explorer.show(); explorer.raise_(); explorer.activateWindow()' not in block
    assert 'if explorer is not None:' in block
    assert 'explorer.set_session_ini_paths(session.ini_files)' in block


def test_browse_requires_explicit_file_selection():
    assert 'self.file_combo.addItem("Select an INI file...", None)' in SOURCE
    assert 'no file is opened automatically' in SOURCE
    load_start = SOURCE.index("    def _load_files(self):", SOURCE.index("class IniExplorerDialogV2"))
    load_end = SOURCE.index("    def _data(self, path):", load_start)
    block = SOURCE[load_start:load_end]
    assert 'self.file_combo.setCurrentIndex(0)' in block
    assert 'self._file_changed()' not in block


def test_compare_requires_explicit_selection():
    assert '"Select File A..."' in SOURCE
    assert '"Select File B..."' in SOURCE


def test_version():
    assert 'commit0100' in SOURCE
