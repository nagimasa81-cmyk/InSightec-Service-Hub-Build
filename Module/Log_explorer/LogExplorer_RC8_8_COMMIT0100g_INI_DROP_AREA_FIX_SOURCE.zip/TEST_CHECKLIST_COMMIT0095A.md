# Commit0095a Test Checklist

- [x] WSLifecycleWidget defines `_show_selected_details`
- [x] Signal connection resolves at widget initialization
- [x] Empty selection is safe
- [x] Event Details content path is present
- [x] Python compile passes
- [x] Existing tests pass after version-aware test update
