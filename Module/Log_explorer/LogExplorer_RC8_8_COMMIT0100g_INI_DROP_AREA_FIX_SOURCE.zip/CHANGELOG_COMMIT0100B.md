# Commit0100b — WS Lifecycle startup fix

- Fixed the Commit0100 semantic lifecycle wrapper passing an unsupported fourth positional argument to the legacy `WSLifecycleWidget.__init__` implementation.
- Preserved the existing parent-window and event-viewer handoff.
- Added a regression test that verifies the wrapper delegates with the legacy constructor's supported argument count.
- Updated application version to `2.0.0-rc1-commit0100b`.
