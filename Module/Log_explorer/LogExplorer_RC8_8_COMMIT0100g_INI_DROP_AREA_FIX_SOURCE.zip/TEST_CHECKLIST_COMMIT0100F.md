# Commit0100f Test Checklist

- Open Spectrum Analysis and select a Spectrum Dump.
- Confirm upper chart title/axis identifies integrated Band Energy.
- Confirm lower chart remains Raw FFT amplitude.
- Change band width among 5/10/20/50 kHz and verify upper chart updates.
- Confirm upper and lower charts use independent vertical scaling.
- Confirm packet table Band Energy updates with band width.
