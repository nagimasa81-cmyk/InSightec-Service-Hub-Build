# Commit0100c Test Checklist

- [ ] Open CSA in a viewer pane: columns are Timestamp / Status / Message.
- [ ] CSA opens with Err selected and only error-class rows displayed.
- [ ] Clear/All restores all CSA rows.
- [ ] User-selected Columns preferences still override the default layout.
- [ ] Event Sync initially shows ±30 sec.
- [ ] Selecting another Event Sync range remains possible.
- [ ] WS and non-CSA pane layouts are unchanged.
