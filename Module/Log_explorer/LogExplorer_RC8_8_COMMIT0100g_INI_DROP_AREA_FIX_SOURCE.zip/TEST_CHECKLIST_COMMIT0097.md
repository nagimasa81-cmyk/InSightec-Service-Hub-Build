# Commit0097 Test Checklist

1. Load logs through Smart File Discovery and open Log Explore > Operation.
2. Click a visible chart marker; verify the corresponding table row is selected and scrolled to the center.
3. Select a table row; verify the corresponding chart marker receives a dark selection ring.
4. Right-click each header except Time and Operation / software event; verify a dropdown value filter appears.
5. Toggle values and verify chart, summary, and table update together.
6. Click Reset and verify all header filters are cleared.
7. Open INI Viewer from the main screen and verify Commit0096 session handoff remains functional.
