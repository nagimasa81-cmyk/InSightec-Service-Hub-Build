# Commit0100d

- Dashboard/WS lifecycle chart marker click synchronizes the corresponding event list row.
- Event list selection requests timeline marker highlighting when supported.
- Adds Semantic, Legacy, and Combined WS analysis modes.
- Semantic remains the default; selected mode is saved with QSettings.
- Combined mode merges duplicate evidence and marks parser origin internally.
- Dashboard session rows synchronize to the first event of the selected session.
