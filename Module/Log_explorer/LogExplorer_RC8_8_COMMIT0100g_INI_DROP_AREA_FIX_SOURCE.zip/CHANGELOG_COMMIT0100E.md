# Commit0100e

- INI Viewer is never opened automatically by Smart File Discovery or application startup.
- MAIN `Open INI Viewer` is the only application-controlled viewer launch route.
- If INI Viewer is already open, Smart File Discovery refreshes the complete current-session INI list without selecting or opening the first file.
- If discovery finishes first, MAIN `Open INI Viewer` loads the same current-session list.
- Browse starts with `Select an INI file...`; no file content is displayed until the operator selects one.
- Compare starts with blank File A / File B selections.
- Multi-file Browse and drag/drop remain available.
