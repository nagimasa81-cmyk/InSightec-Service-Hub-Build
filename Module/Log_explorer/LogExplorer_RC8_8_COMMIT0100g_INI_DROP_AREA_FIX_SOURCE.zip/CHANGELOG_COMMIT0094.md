# Commit0094 — INI Compare File A/B Loading

- Added independent Browse A and Browse B actions.
- Added dedicated File A and File B drag-and-drop targets.
- Loaded Files remain available through both comparison selectors.
- Added an explicit Compare button and validation that A and B are different files.
- Double-clicking a difference opens the matching setting in the Browse tab.
- Preserved Unified Import Engine, WS Lifecycle, Timeline Compare, and standalone INI Viewer.
