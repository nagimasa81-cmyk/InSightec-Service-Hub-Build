# Commit0100g Test Checklist

- [ ] Start Log Explore: INI Viewer does not auto-open.
- [ ] Open INI Viewer from MAIN: drop area is visible.
- [ ] Drop one `.ini` file: it appears in the File list but is not auto-opened.
- [ ] Drop multiple `.ini` files: all valid unique files appear.
- [ ] Drop a folder: nested `.ini` files are discovered recursively.
- [ ] Drag unsupported files: drop is rejected.
- [ ] Drop duplicate files: no duplicate list entries are created.
- [ ] Drop onto the dialog background: same import behavior occurs.
- [ ] Smart File Discovery before/after opening INI Viewer still synchronizes the session list.
- [ ] Compare File A and File B drop areas still work.
