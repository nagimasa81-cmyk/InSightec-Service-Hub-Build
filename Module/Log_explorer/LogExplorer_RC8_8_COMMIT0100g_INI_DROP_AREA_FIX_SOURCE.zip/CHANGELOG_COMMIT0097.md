# Commit0097 — Operation Chart/List Synchronization and Column Filters

- Clicking an Operation timeline marker now selects and centers the corresponding row in the table.
- Selecting a table row highlights the corresponding timeline marker.
- Added right-click dropdown filters to table headers for Category, Actor, Severity, Sonication, Phase, Confidence, CorrelationID, and Source.
- Time and Operation / software event columns intentionally remain without header dropdown filters.
- Reset now clears both the top controls and all column filters.
- Preserved Commit0096 shared INI Viewer handoff behavior.
