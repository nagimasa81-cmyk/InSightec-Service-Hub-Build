# Commit0097a — Triple-check stabilization

- Rechecked Operation chart-to-table and table-to-chart synchronization.
- Rechecked right-click value filters for all requested columns except Time and Operation / software event.
- Changed Operation timeline coordinates to full timestamps so sessions crossing midnight remain correctly ordered.
- Added exact current-session INI replacement when reopening the main INI Viewer after Smart File Discovery.
- Updated the INI Viewer tooltip to describe shared-session behavior.
- Removed an unreachable legacy detail handler that referenced fields not present in OperationIntelligenceWidget.
- Added focused Commit0097a regression tests.
