# Commit0097a Test Checklist

1. Load a folder or ZIP with Smart File Discovery and select INI files.
2. Close and reopen INI Viewer from the main screen; confirm exactly the current session INIs appear.
3. Open Log Explore > Operation and press Rebuild Operation Analysis.
4. Click chart marks; confirm the matching table row is selected and centered.
5. Select table rows; confirm the matching chart mark is outlined.
6. Right-click Category, Actor, Severity, Sonication, Phase, Confidence, CorrelationID, and Source headers and confirm filters work.
7. Confirm Time and Operation / software event headers do not open column filters.
8. Confirm Reset clears all top and column filters.
9. Confirm a data set crossing midnight remains ordered on the Operation timeline.
