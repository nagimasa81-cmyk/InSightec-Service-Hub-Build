# Commit0093 — Unified Import Engine

- Smart File Discovery is the single file-selection entry point.
- One UnifiedImportSession owns approved files, parsed records, warnings, source metadata, and generation state.
- Normal Log Viewer, Investigation, WS Lifecycle, Timeline Compare, Dashboard, and INI Explorer consume the same model.
- Removed the Commit0092 analysis-only FileDialog/parser route.
- START parses the approved selection once and shares the resulting cache with every view.
- Analysis launchers reuse the current model; when empty they open the same Smart File Discovery flow.
- INI files remain individually managed and are never merged into log records.
