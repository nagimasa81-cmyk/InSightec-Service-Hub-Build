# Commit0095 Test Checklist

- [x] Python syntax compile
- [x] WS-only source restriction preserved
- [x] Login/logout/lock/unlock rules present
- [x] Application start/ready/quit/crash rules present
- [x] Continue/Pause/Resume/Retry/Cancel/Abort user actions present
- [x] User actions require explicit UI/operator evidence or concise action records
- [x] Warning/error/timeout/recovery/communication rules present
- [x] Operation, Code and CallID columns present
- [x] Operation Summary tab present
- [x] Event Details and nearby evidence present
- [x] Timeline lanes include User Action and System
- [x] Unified Import Engine remains active
