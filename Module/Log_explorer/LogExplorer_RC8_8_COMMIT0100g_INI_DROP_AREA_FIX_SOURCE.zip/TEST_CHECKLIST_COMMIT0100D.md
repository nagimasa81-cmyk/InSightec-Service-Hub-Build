# Commit0100d Test Checklist

- [x] Python compilation
- [x] Legacy parser captured before semantic replacement
- [x] Semantic/Legacy/Combined mode selector wiring
- [x] Mode persistence key and valid mode guard
- [x] Timeline marker to event-list selection wiring
- [x] Event-list to timeline highlight compatibility path
- [x] Dashboard mode selector and session-row synchronization wiring
- [x] ZIP integrity

Windows UI confirmation required after GitHub build for actual marker hit testing.
