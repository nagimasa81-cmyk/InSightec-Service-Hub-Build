# Commit0096 — Shared INI Viewer Handoff

- Smart File Discovery now opens `IniExplorerDialogV2` instead of the legacy INI dialog.
- INI files selected by Unified Import are added to the same Loaded Files collection used by the standalone INI Viewer.
- If the standalone INI Viewer is already open, newly selected INIs are appended without opening a duplicate window.
- Opening INI Viewer after Smart File Discovery preloads the current Unified Import session INIs.
- INI files remain independent from normal log records and are not merged.
