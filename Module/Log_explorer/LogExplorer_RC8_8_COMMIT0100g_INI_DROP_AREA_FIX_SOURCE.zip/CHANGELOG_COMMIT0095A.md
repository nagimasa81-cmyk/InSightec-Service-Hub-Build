# Commit0095a — WS Lifecycle startup crash fix

- Moved `_show_selected_details()` into `WSLifecycleWidget`.
- Added safe no-selection handling.
- Event Details now shows operation, code, CallID, raw message and nearby lifecycle evidence.
- Preserved Unified Import Engine, Timeline Compare and INI Compare.
