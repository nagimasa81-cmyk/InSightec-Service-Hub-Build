# Commit0100 — Workstation Semantic Lifecycle

- Replaced broad WS keyword extraction with ordered semantic rules and a state machine.
- Emits workflow entries only when the Workstation actually changes state.
- Separates state transitions, operator actions, session boundaries and system faults.
- Suppresses repeated/no-change records and common false positives such as `error count: 0`.
- Added external `ws_lifecycle_rules.json` for controlled rule tuning without editing parser code.
- Added Parser Audit and Rule Coverage tabs to show likely missed lifecycle records and rule usage.
- Timeline Compare and existing lifecycle consumers now reuse the same semantic event stream.
