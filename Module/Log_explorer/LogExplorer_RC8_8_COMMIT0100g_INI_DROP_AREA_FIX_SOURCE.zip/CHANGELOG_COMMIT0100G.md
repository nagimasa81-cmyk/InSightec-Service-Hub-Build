# Commit0100g — INI Drop Area Runtime Fix

- Kept the main INI drag-and-drop area and enlarged it into a dedicated drop target.
- The drop widget now owns drag enter, drag move, drag leave, and drop handling instead of relying only on the parent dialog.
- Accepts one or more `.ini` files and folders.
- Folder drops recursively discover `.ini` files.
- Shows a visible active state while a supported item is dragged over the drop area.
- Routes drops on the dialog background through the same import handler.
- Preserves explicit file selection after import; no INI is opened automatically.
- Duplicate and unsupported files remain filtered.
