# Commit0106 — Main drop zone Windows Explorer drag/drop hardening

- Root cause: Commit0100hA hardened the INI Viewer's drag/drop targets
  against a Windows Explorer quirk (some shell drag sources do not populate
  a normal URL list, and/or the widget must force `Qt.CopyAction` and
  explicitly `accept()` the event or the drop is silently rejected). That
  hardening was applied only to `_IniImportDropTarget` and
  `IniExplorerDialogV2`, and was never backported to the original
  Commit0018 main drop zone ("Drop Folder / ZIP / Log Files Here") or to the
  main-window-level drop handlers.
- Added `_c106_event_paths()`, mirroring Commit0100hA's `_c100ha_event_paths`
  (URL list first, text/uri-list fallback second), but without the
  `.ini`/`.zip` suffix restriction — the main drop zone must still accept a
  folder, one ZIP archive, or multiple log files of any extension.
- `Commit0018DropZone.dragEnterEvent` / `dragMoveEvent` / `dropEvent` now
  force `Qt.CopyAction` and explicitly accept the event via
  `_c100ha_accept_copy()`, reusing the same helper Commit0100hA introduced.
- `MainWindow.dragEnterEvent` / `dropEvent` (the whole-window drop handlers
  set up by Commit0018) received the same treatment.
- No change to accepted input types, staging behavior, or downstream
  handling in `_commit0018_handle_drop()` — this is purely an event-level
  drag/drop reliability fix, same scope as Commit0100hA.
- Added `tests/test_commit0106_main_dropzone_hardening.py` (static
  regression test, same style as `test_commit0100ha_ini_drop_triple_check.py`).
- Updated application/build metadata to Commit0106 / LogExplorer_C0106
  (`version.json`, `01_BUILD_EXE_NUITKA.bat`, `insightec_build_contract.json`
  — the build contract was already stale at C0104 before this commit; it is
  now synchronized to C0106).
