# Commit0105 — Nuitka-safe deferred synchronization build fix

- Fixes GitHub Actions run 93 failure under Python 3.13.15 + Nuitka 4.1.3.
- Root cause: a list comprehension in the `finally` condition of the C0104 deferred auto-load scheduler triggered Nuitka internal assertion `listcomp_2__.0_clone`.
- Replaced both list comprehensions in the C0104 scheduler `run_next()` with explicit loops.
- Runtime behavior is unchanged: latest pending sync is retained, unloaded panes auto-load, and queued synchronization replays when all visible panes are ready.
- Updated application/build metadata to Commit0105 / LogExplorer_C0105.
