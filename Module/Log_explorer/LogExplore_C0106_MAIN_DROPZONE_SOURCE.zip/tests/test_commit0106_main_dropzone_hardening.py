from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1] / "LogMergeTool_NoExcel_Main.py"
TEXT = SOURCE.read_text(encoding="utf-8")


def test_main_dropzone_uses_copy_action_and_accept():
    assert "def _c106_event_paths(event):" in TEXT
    assert "_c100ha_accept_copy(event)" in TEXT.split("def _c106_event_paths")[1]


def test_main_dropzone_has_uri_list_fallback():
    section = TEXT.split("def _c106_event_paths(event):", 1)[1]
    section = section.split("def _c106_dropzone_drag_enter", 1)[0]
    assert "mime.hasUrls()" in section
    assert "mime.text()" in section


def test_commit0018_dropzone_patched_with_c106_handlers():
    assert "Commit0018DropZone.dragEnterEvent = _c106_dropzone_drag_enter" in TEXT
    assert "Commit0018DropZone.dragMoveEvent = _c106_dropzone_drag_move" in TEXT
    assert "Commit0018DropZone.dropEvent = _c106_dropzone_drop" in TEXT


def test_mainwindow_level_drop_patched_with_c106_handlers():
    assert "MainWindow.dragEnterEvent = _c106_window_drag_enter" in TEXT
    assert "MainWindow.dropEvent = _c106_window_drop" in TEXT


def test_main_dropzone_still_accepts_any_file_not_only_ini_zip():
    # Unlike the INI-only Commit0100hA fallback, the main drop zone must keep
    # accepting arbitrary log files, not just .ini/.zip. Check the actual
    # filter predicate, not the explanatory docstring text.
    section = TEXT.split("def _c106_event_paths(event):", 1)[1]
    section = section.split("def _c106_dropzone_drag_enter", 1)[0]
    assert '.suffix.casefold() in {".ini", ".zip"}' not in section
    assert "path.is_dir() or path.is_file()" in section


def test_no_list_comprehension_in_c106_new_code():
    # Commit0105 avoided list comprehensions to stay Nuitka-safe; keep the
    # same discipline in the new Commit0106 code.
    section = TEXT.split("# Commit0106:", 1)[1]
    section = section.split('APP_VERSION = "2.0.0-rc1-commit0106"', 1)[0]
    import re
    assert re.search(r"\[[^\[\]]*\bfor\b[^\[\]]*\]", section) is None


def test_version_updated():
    assert 'APP_VERSION = "2.0.0-rc1-commit0106"' in TEXT
