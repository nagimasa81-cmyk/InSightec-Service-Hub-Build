# Commit0103 Processing / Stability Audit

## High priority findings

1. The direct `main()` call appeared before later Commit0100c/0100d/0100j patch code. During a normal GUI session the Qt event loop blocked module execution, so code below that point was not installed until after the application exited.
2. `MultiPaneLogViewer.load_pane` had accumulated 13 historical replacements before C0103. Several wrappers call the previous implementation and then re-apply filters or presentation updates, causing repeated model resets and redraws from one Load operation.
3. Viewer source loading still applied Noise rules in `_c74_apply_record_options`, destructively removing rows before `all_rows` was populated. That contradicted the C0102 memory-only design and could prevent Noise OFF from restoring rows without a reload.
4. `_c77_option_signature` included the Noise checkbox state, unnecessarily invalidating source-level cache entries when Noise was toggled.
5. Viewer parsing used worker threads but waited with `as_completed()` on the GUI thread. If the next file took a long time, UI repaint/cancel handling could stall until a future completed.
6. Repeated filtering could call `beginResetModel()/endResetModel()` multiple times with effectively identical row objects and columns. This is expensive for large views and can invalidate header geometry/scroll state.
7. Timestamp is configured as fixed-width, but repeated model reset + splitter resize + header geometry updates can retain a stale horizontal scroll offset. A later maximize/restore forces Qt geometry recalculation, explaining the reported temporary disappearance.
8. Merge selected-file inputs were not explicitly deduplicated by resolved path before parser futures were submitted.
9. Merge and import workers had button disabling, but no final worker-state guard against a second invocation from alternate signal/event paths.

## C0103 actions

- Moved the only `__main__` invocation to physical EOF.
- Removed destructive Viewer Noise filtering from source loading and cache signatures.
- Added path deduplication before merge parsing.
- Changed Viewer future waiting to short polling intervals with Qt event processing and cancel checks.
- Suppressed redundant table model resets for identical row-object/column presentations.
- Added deferred Timestamp visibility/width/scroll repair after model reset and pane layout changes.
- Added busy guards for pane load, LOAD LOGS, merge, import/export task, and Log Explore refresh.

## Remaining architectural debt

The main module still contains many historical monkey-patch layers. C0103 reduces duplicate work without deleting legacy behavior, but a later controlled refactor should fold the final implementations into canonical class methods and remove obsolete wrapper layers. That should be done with regression fixtures for WS/CSA/CGA/MRSERVER/PSC/Review before deleting compatibility code.
