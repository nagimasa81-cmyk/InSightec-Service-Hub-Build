# Commit0102 test checklist

1. Load two or more panes with Noise Filter OFF; record row counts.
2. Toggle Noise Filter ON and confirm rows are hidden without a file-loading progress scan.
3. Toggle OFF and confirm all loaded rows return immediately.
4. Add a Viewer-scope rule and confirm it filters Viewer but not Merge output.
5. Add a Merge-scope rule and confirm it does not hide Viewer rows but filters Merge output.
6. Select a hidden-rule matching row with filter OFF, choose Mark Selected Not Noise, turn filter ON, and confirm that exact row remains visible.
7. Apply a Viewer time range with Noise Filter ON and confirm both filters are combined.
8. Open Manage Rules, disable/delete a rule, close, and confirm current rows refresh without source reload.
9. Build with `01_BUILD_EXE_NUITKA.bat`; expected EXE: `dist/LogExplorer_C0102.exe`.
