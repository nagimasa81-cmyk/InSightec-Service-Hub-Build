# Commit0104 — Deferred synchronization readiness gate

- Event Sync no longer treats an unrequested/unloaded pane as an empty log.
- Visible panes are tracked as idle / queued / loading / ready.
- During LOAD LOGS, the newest sync request is queued until every visible target pane is ready.
- If a visible target pane has never been loaded, Event Sync automatically loads that pane before applying the sync.
- Only the latest queued timestamp is retained, preventing stale queued sync operations from firing later.
- A completed zero-row source is still considered ready, so empty logs do not create an infinite wait.
- Master Timeline Sync remains the actual matching engine after the readiness gate.
- Investigation Mode also queues a timestamp selected while analysis is loading and replays it after loading completes.
