# Commit0104 Test Checklist

1. Open 2/3/4-pane Log Viewer with panes visible but not loaded.
2. Load only pane 1 and select a timestamped row.
   - Missing visible panes should auto-load.
   - Sync should run after all target panes report ready.
3. Press LOAD LOGS and select/change rows while later panes are still loading.
   - No early `no match` should be finalized for not-yet-loaded panes.
   - The latest selected timestamp should apply after loading finishes.
4. Change the selected row multiple times during loading.
   - Only the newest queued request should replay.
5. Target log contains zero rows.
   - Pane becomes ready and sync completes with a real `no match`, not an endless wait.
6. Use Exact / ±1 / ±5 / ±10 / ±30 sec.
   - Existing Master Timeline matching semantics remain unchanged.
7. In Investigation Mode, request synchronization while Start/Reload Analysis is running.
   - The timestamp is queued and applied once analysis completes.
8. Cancel/fail a load.
   - Pane state must return to idle/previous-ready and not remain permanently queued.
