# Commit0103 — Viewer Stability / Duplicate Work Audit

- Moved the direct `main()` entry point to the physical end of the module so every later compatibility patch is active before the Qt event loop starts.
- Made Viewer Noise Filter presentation-only during source loading; turning Noise Filter OFF can now restore the complete loaded source without re-parsing.
- Removed Noise Filter state from the parsed/source cache key.
- Added deterministic duplicate-path suppression for Smart File Discovery merge inputs.
- Reworked Viewer parallel parse waiting to poll futures while processing Qt events, improving responsiveness and cancellation behavior when one file is slow.
- Added redundant `QAbstractTableModel` reset suppression when identical rows/columns are applied repeatedly by historical wrapper chains.
- Added deferred Timestamp-column geometry repair after model reset and pane layout changes; stale horizontal offsets are corrected only when Timestamp is fully off-screen.
- Added duplicate-operation guards for pane load, LOAD LOGS, merge, import/export task, and Log Explore refresh.
- Preserved the existing build contract and Module folder name `Log_explorer`.
