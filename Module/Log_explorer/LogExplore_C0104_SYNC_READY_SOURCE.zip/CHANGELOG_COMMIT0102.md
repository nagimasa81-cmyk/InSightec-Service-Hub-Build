# Commit0102 — Noise Filter reliability and usability

- Viewer Noise Filter now re-evaluates already loaded rows in memory; toggling no longer re-scans source files.
- Noise rule `scope` is enforced (`viewer` / `merge` / `both`).
- Non-filter actions are no longer treated as hide rules.
- `Mark Selected Not Noise` now creates an exact-row exception and refreshes the current view immediately.
- Time-range and Noise filtering are composed in one display pipeline.
- Viewer status reports shown/hidden row counts.
- Noise rule timing UI is simplified to immediate application; `Refresh Filter` explicitly reloads rules without reloading logs.
- Build metadata/version updated to C0102.
