# Commit0101 — FUS Export Core foundation
- Preserves Commit0100jA behavior.
- Adds shared semantic inspection of Sonication Export folders.
- Adds COMPLETE/PARTIAL/INCOMPLETE capability model; partial data is never discarded.
- Adds TMAP vs TMAP-ME (Multi Echo) and 3D/2D/Hybrid workflow detection.
- Spectrum analyzer recognizes SpectrumMsg-N.dmp and validates exact frame_count/frame_size/channel_count by file-size equation.
- Legacy Spectrum_*.dmp_FFT heuristic remains available as fallback.
- Core is available to Smart Discovery / Investigation without forcing binary assets into normal log rows.
