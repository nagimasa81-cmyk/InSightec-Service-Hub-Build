# Commit0103 Test Checklist

1. Launch source/EXE and verify the late Commit0100c/d/j UI patches are active during the session (not only after window close).
2. Load WS/CSA panes, toggle Noise Filter ON then OFF, and confirm the OFF state restores the original row count without reloading files.
3. Toggle Noise Filter repeatedly and confirm no physical file parsing occurs and cached source data remains reusable.
4. Apply filters repeatedly and confirm Timestamp remains visible; resize/maximize/restore and switch pane count to confirm it stays visible.
5. Start LOAD LOGS and immediately click it again; confirm the duplicate request is ignored.
6. Start a pane load and click the same pane Load button again; confirm duplicate request is ignored.
7. Start Merge twice; confirm only one MergeWorker runs.
8. Use Smart File Discovery with the same resolved path repeated and confirm merge logs a deduplicated count and parses the file once.
9. Load multiple large files and verify the UI continues repainting while waiting for a slow parser future; Cancel should return control without waiting for queued tasks.
10. Run `python -m py_compile LogMergeTool_NoExcel_Main.py`.
11. Build with `01_BUILD_EXE_NUITKA.bat`; expected EXE: `dist/LogExplorer_C0103.exe`.
