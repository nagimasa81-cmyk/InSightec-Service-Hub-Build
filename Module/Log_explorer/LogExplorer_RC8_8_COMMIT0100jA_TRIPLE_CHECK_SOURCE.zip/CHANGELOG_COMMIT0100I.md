# Commit0100i
- Added time-based horizontal axis for Raw / Reconstructed Data.
- Uses original sample rate and displays microseconds; magnitude-only dumps are clearly identified as zero-phase reconstructed previews.
- Added compact Channel All and Clear buttons.
- Preserves selected channels when changing Spectrum Dumps.
- Preserves domain, display mode, scale, band width, replay setting and comparison controls while navigating dumps.
