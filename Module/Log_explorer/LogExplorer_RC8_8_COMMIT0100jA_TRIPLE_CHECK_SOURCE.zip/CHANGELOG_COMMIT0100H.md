# Commit0100h

- Fixed INI Viewer session handoff to use `unified_import_session` instead of the obsolete `_c93_import_model` attribute.
- Smart File Discovery now hands every discovered INI file to INI Viewer, while keeping INI files out of normal log parsing unless selected.
- Main INI drop area now accepts `.ini`, folders, and ZIP archives.
- Dropped ZIP archives are extracted with the existing safe ZIP extraction routine and retained while INI Viewer remains open.
- No INI file is opened automatically after drop or discovery.
