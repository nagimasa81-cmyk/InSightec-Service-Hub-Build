# Commit0100iA Test Checklist

- [x] Python compileall
- [x] Full reconstructed time duration retained after display decimation
- [x] Time reconstruction uses linear spectral magnitude
- [x] Band energy uses linear magnitude before optional log display
- [x] Channel All/Clear controls present
- [x] Channel selection retained across dump changes
- [x] Version metadata synchronized
- [x] ZIP integrity verified
