# Commit0100iA

Triple-check corrections for Spectrum Analysis:

- Preserve the full reconstructed waveform duration on the time axis even when display samples are decimated.
- Reconstruct time-domain data from linear FFT magnitudes, never from logarithmically transformed display values.
- Integrate band energy from linear magnitudes and apply logarithmic scaling only after integration.
- Reconfirm All/Clear channel controls and channel-selection persistence across dump changes.
- Synchronize application and package version metadata.
