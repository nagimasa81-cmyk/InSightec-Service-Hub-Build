# Commit0100j Test Checklist

1. Open WS Lifecycle and confirm the dedicated analysis-mode row is visible below Event/Search controls.
2. Select Semantic and confirm semantic state-aware events are shown.
3. Select Legacy and confirm previous keyword events are shown.
4. Select Combined and confirm merged/de-duplicated events are shown.
5. Confirm the selection persists after restart.
6. Confirm changing mode in WS Lifecycle updates an open Dashboard.
7. Confirm changing mode in Dashboard updates an open WS Lifecycle.
8. Confirm System Health and Timeline Compare rebuild using the selected mode.
