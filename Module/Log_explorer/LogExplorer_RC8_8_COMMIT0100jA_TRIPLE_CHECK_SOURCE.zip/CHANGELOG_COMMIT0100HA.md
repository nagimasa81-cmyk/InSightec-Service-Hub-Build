# Commit0100hA

Triple-check hardening for INI Viewer import.

- Forces Windows Explorer drops to Qt CopyAction and explicitly accepts the event.
- Uses one parser for INI, ZIP and folder drops on both the drop area and dialog background.
- Adds text/uri-list fallback for shell drag sources that do not expose a normal URL list.
- Collects INIs from the complete Smart File Discovery inventory, not only the current filtered rows.
- Scans the active extracted ZIP workspace for INIs before handing the shared session to INI Viewer.
