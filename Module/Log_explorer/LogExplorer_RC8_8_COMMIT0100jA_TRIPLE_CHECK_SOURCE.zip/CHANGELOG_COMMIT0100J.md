# Commit0100j — Visible WS Lifecycle Analysis Mode

- Added a dedicated, clearly visible `WS Lifecycle analysis mode` row inside the WS Lifecycle tab.
- Reuses the existing Semantic / Legacy / Combined parser implementation and saved setting.
- Added an inline explanation of the selected mode.
- WS Lifecycle mode changes now synchronize an already-open Dashboard and rebuild System Health / Timeline Compare.
- Dashboard mode changes continue to synchronize WS Lifecycle.
