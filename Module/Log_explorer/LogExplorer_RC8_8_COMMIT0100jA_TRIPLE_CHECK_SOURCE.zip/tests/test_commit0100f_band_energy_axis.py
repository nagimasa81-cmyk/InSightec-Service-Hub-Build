from pathlib import Path

SOURCE = (Path(__file__).parents[1] / 'foundation' / 'spectrum_analysis.py').read_text(encoding='utf-8')
MAIN = (Path(__file__).parents[1] / 'LogMergeTool_NoExcel_Main.py').read_text(encoding='utf-8')


def test_true_band_energy_integration():
    assert 'sum(float(value) ** 2 for value in chunk) * bin_width_hz' in SOURCE
    assert 'Band center frequency' in SOURCE
    assert 'Integrated Energy' in SOURCE


def test_band_width_control():
    for width in ('5, 10, 20, 50', 'self.band_width_combo', '_band_width_changed'):
        assert width in SOURCE


def test_raw_fft_remains_separate():
    assert 'self.plot.mode = "Raw Data from A2D"' in SOURCE
    assert 'self.energy_plot.mode = "Energy per Band"' in SOURCE


def test_version():
    assert 'commit0100' in MAIN
