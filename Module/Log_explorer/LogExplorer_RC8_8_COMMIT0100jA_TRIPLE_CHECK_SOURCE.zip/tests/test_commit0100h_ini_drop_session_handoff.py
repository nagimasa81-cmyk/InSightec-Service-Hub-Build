from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1] / "LogMergeTool_NoExcel_Main.py"
TEXT = SOURCE.read_text(encoding="utf-8")


def test_ini_viewer_uses_real_unified_session():
    assert 'session = getattr(self, "unified_import_session", None)' in TEXT
    assert 'session = getattr(self, "_c93_import_model", None)' not in TEXT


def test_drop_accepts_ini_zip_and_folder():
    assert 'path.suffix.casefold() in {".ini", ".zip"}' in TEXT
    assert '_safe_extract_zip_for_discovery(path)' in TEXT
    assert 'self._drop_temp_holders.append(holder)' in TEXT


def test_discovery_hands_all_discovered_ini_to_session():
    assert 'self._c100h_discovered_ini_files' in TEXT
    assert 'selected + self._c100h_discovered_ini_files' in TEXT


def test_no_automatic_ini_selection_remains():
    assert 'self.file_combo.addItem("Select an INI file...", None)' in TEXT
    assert 'self.file_combo.setCurrentIndex(0)' in TEXT
