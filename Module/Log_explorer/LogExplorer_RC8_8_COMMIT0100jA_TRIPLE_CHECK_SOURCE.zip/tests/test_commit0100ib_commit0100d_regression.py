from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "LogMergeTool_NoExcel_Main.py").read_text(encoding="utf-8")
SPECTRUM = (ROOT / "foundation" / "spectrum_analysis.py").read_text(encoding="utf-8")
META = json.loads((ROOT / "version.json").read_text(encoding="utf-8"))


def test_commit0100d_modes_are_still_present():
    assert '_C100D_VALID_MODES = ("Semantic", "Legacy", "Combined")' in MAIN
    assert 'self.parser_mode.addItems(list(_C100D_VALID_MODES))' in MAIN
    assert '_c100d_save_mode(mode)' in MAIN


def test_ws_lifecycle_marker_and_list_sync_are_still_connected():
    assert 'self.timeline.eventActivated.connect(self._c100d_select_event)' in MAIN
    assert 'self.event_table.itemSelectionChanged.connect(self._c100d_highlight_selected_marker)' in MAIN
    assert 'self.event_table.scrollToItem(item, QAbstractItemView.PositionAtCenter)' in MAIN


def test_dashboard_session_row_sync_is_still_connected():
    assert 'self.table.cellClicked.connect(self._c100d_activate_session_row)' in MAIN
    assert 'lifecycle._c100d_select_event(event)' in MAIN


def test_mode_is_extended_to_related_ws_tabs():
    assert 'WSSystemHealthWidget.rebuild = _c100ib_health_rebuild' in MAIN
    assert 'WSTimelineCompareWidget.rebuild = _c100ib_compare_rebuild' in MAIN
    assert '_c100d_events_for_mode(cache, mode)' in MAIN
    assert '("ws_system_health", "ws_timeline_compare")' in MAIN


def test_latest_spectrum_and_ini_features_remain_present():
    assert 'APP_VERSION = "2.0.0-rc1-commit0100iA"' in MAIN
    assert '_c100ha_event_paths' in MAIN
    for token in (
        'Band center frequency',
        'self.time_duration_s',
        'def _select_all_hydrophones',
        'def _select_no_hydrophones',
        'QLabel("Channels:")',
    ):
        assert token in SPECTRUM


def test_version_is_commit0100ib():
    assert META["version"].startswith("2.0.0-rc1-commit0100")
    assert str(META["commit"]).lower().startswith("0100")
    assert 'APP_VERSION = "2.0.0-rc1-commit0100iB"' in MAIN
