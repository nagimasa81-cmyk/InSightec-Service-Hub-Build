from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "foundation" / "spectrum_analysis.py").read_text(encoding="utf-8")
MAIN = (ROOT / "LogMergeTool_NoExcel_Main.py").read_text(encoding="utf-8")
META = json.loads((ROOT / "version.json").read_text(encoding="utf-8"))


def test_time_axis_preserves_full_reconstructed_duration_after_decimation():
    assert "self.time_duration_s" in SOURCE
    assert "(int(waveform.size) - 1)" in SOURCE
    assert "tick_us = ratio * max(0.0, self.time_duration_s)" in SOURCE
    assert "x_us = x_ratio * max(0.0, self.time_duration_s)" in SOURCE


def test_time_and_energy_math_use_linear_magnitudes_before_log_display():
    assert "if (time_domain or energy_mode)" in SOURCE
    assert "self._visible_raw_blocks(self.dump)" in SOURCE
    assert "math.log10(max(energy, 1e-30)) if self.log_scale else energy" in SOURCE


def test_channel_controls_and_state_persistence_are_present():
    assert "def _select_all_hydrophones" in SOURCE
    assert "def _select_no_hydrophones" in SOURCE
    assert "self.selected_channels = {i for i, check in enumerate(self.checks) if check.isChecked()}" in SOURCE
    assert "checked = True if self.selected_channels is None else block_index in self.selected_channels" in SOURCE


def test_version_metadata_is_current_or_later_cumulative_build():
    assert META["commit"].casefold() in {"0100i", "0100ia", "0100ib", "0100j", "0100ja"}
    assert META["version"].startswith("2.0.0-rc1-commit0100")
    assert f'APP_VERSION = "{META["version"]}"' in MAIN
