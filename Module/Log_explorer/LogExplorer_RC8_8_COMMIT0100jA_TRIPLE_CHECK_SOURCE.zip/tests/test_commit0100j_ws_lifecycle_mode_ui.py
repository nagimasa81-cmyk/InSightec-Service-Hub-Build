from pathlib import Path

MAIN = (Path(__file__).resolve().parents[1] / "LogMergeTool_NoExcel_Main.py").read_text(encoding="utf-8")


def test_ws_lifecycle_has_visible_dedicated_mode_row():
    assert 'WS Lifecycle analysis mode' in MAIN
    assert 'wsLifecycleAnalysisModeCombo' in MAIN
    assert 'root.insertLayout(1, mode_row)' in MAIN


def test_all_three_modes_remain_available():
    assert '_C100D_VALID_MODES = ("Semantic", "Legacy", "Combined")' in MAIN
    assert '_c100d_events_for_mode' in MAIN


def test_ws_lifecycle_mode_syncs_other_tabs():
    assert 'WSLifecycleWidget._c100d_mode_changed = _c100j_ws_mode_changed' in MAIN
    assert '("ws_system_health", "ws_timeline_compare")' in MAIN
    assert 'dashboard.parser_mode.setCurrentText(mode)' in MAIN


def test_version_is_commit0100j():
    assert 'APP_VERSION = "2.0.0-rc1-commit0100j' in MAIN
