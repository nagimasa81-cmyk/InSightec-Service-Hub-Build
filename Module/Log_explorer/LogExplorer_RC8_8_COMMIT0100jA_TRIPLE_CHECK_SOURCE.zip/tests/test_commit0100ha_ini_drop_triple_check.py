from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1] / "LogMergeTool_NoExcel_Main.py"
TEXT = SOURCE.read_text(encoding="utf-8")


def test_windows_drop_uses_copy_action_and_accept():
    assert "event.setDropAction(Qt.CopyAction)" in TEXT
    assert "def _c100ha_event_paths(event):" in TEXT
    assert "mime.hasUrls()" in TEXT
    assert "mime.text()" in TEXT


def test_main_surface_and_dialog_share_same_drop_parser():
    assert "_IniImportDropTarget.dragEnterEvent = _c100ha_drop_drag_enter" in TEXT
    assert "_IniImportDropTarget.dropEvent = _c100ha_drop_drop" in TEXT
    assert "IniExplorerDialogV2.dragEnterEvent = _c100ha_dialog_drag_enter" in TEXT
    assert "IniExplorerDialogV2.dropEvent = _c100ha_dialog_drop" in TEXT


def test_discovery_collects_from_unfiltered_inventory_and_zip_root():
    assert '("discovered", "filtered")' in TEXT
    assert 'root.rglob("*.ini")' in TEXT
    assert "_c100ha_collect_discovered_ini(discovery, self)" in TEXT


def test_version_updated():
    assert 'APP_VERSION = "2.0.0-rc1-commit0100hA"' in TEXT
