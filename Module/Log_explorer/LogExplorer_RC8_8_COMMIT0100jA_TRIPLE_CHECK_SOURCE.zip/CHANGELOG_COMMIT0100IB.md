# Commit0100iB

- Verified that Commit0100d Semantic / Legacy / Combined mode support remains in the cumulative source.
- Verified Dashboard row-to-WS Lifecycle list synchronization remains connected.
- Verified WS Lifecycle timeline marker-to-event-list synchronization remains connected.
- Extended the selected parser mode to System Health and Timeline Compare.
- Dashboard mode changes now refresh initialized System Health and Timeline Compare tabs.
- Preserved Commit0100e through Commit0100iA functionality, including manual INI Viewer flow, drag/drop handoff, Band Energy, time-domain waveform, channel All/Clear, and state retention.
