# Commit0100i Test Checklist
- [ ] Select Raw / Reconstructed Data and confirm x-axis uses microseconds.
- [ ] Confirm summary states reconstructed preview when complex phase/raw samples are unavailable.
- [ ] Select H1/H3 only, switch dump, and confirm H1/H3 remain selected when available.
- [ ] Test All and Clear buttons.
- [ ] Confirm scale, display mode, band width and replay setting remain unchanged after dump navigation.
