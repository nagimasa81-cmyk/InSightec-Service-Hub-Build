# Commit0100h Test Checklist

- [ ] Open INI Viewer before Smart File Discovery; complete discovery; confirm all discovered INIs appear without auto-opening one.
- [ ] Complete Smart File Discovery first; then open INI Viewer; confirm the same INI list appears.
- [ ] Drop one `.ini` file into the main drop area.
- [ ] Drop multiple `.ini` files into the main drop area.
- [ ] Drop a folder containing nested INIs.
- [ ] Drop a ZIP containing INIs; confirm files appear and remain readable while the viewer is open.
- [ ] Confirm duplicate files are not added.
- [ ] Confirm unsupported files are rejected.
