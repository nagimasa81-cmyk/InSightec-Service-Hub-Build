from pathlib import Path
import json

root = Path(__file__).resolve().parents[1]
main = (root / "LogMergeTool_NoExcel_Main.py").read_text(encoding="utf-8-sig")
version = json.loads((root / "version.json").read_text(encoding="utf-8-sig"))
github_bat = (root / "01_BUILD_EXE_GITHUB.bat").read_text(encoding="utf-8-sig")
nuitka_bat = (root / "01_BUILD_EXE_NUITKA.bat").read_text(encoding="utf-8-sig")

assert 'APP_VERSION = "2.0.0-rc1-commit0067"' in main
assert version["version"] == "2.0.0-rc1-commit0067"
assert version["commit"] == "Commit0067"
assert version["artifact_base_name"] == "LogMergeTool_RC1_Commit0067"
assert "LogMergeTool_RC1_Commit0067" in github_bat
assert "LogMergeTool_RC1_Commit0067" in nuitka_bat
assert "def _c67_prepare_discovery_options" in main
assert "_safe_extract_zip_for_discovery(source)" in main
assert "MainWindow.start_import_clicked = _c67_start_import_clicked" in main
assert "opt.source_folder = str(extract_root)" in main
assert "Configure the Viewer and press LOAD LOGS" in main
print("Commit0067 ZIP discovery handoff checks passed")
