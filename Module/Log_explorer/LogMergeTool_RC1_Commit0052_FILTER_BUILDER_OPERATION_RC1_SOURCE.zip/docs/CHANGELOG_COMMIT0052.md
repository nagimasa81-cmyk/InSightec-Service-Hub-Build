# Commit0052 — Filter Builder and Operation RC1

## Event Viewer filters
- Contains: `Column~value`
- Exact: `Column=value`
- Not equal: `Column!=value`
- Starts with: `Column^value`
- Ends with: `Column$value`
- Regex: `Column REGEX pattern`
- Multiple conditions:
  - `Condition AND Condition`
  - `Condition OR Condition`
- Header menu appends new conditions with AND.
- Pane displays filtered rows / total rows and the active expression.
- Existing-value dropdown still appears only when there are at most 10 values.

## Operation
- Existing operation classification retained.
- Phase counts are added to the Operation summary.
- Operation analysis remains manual.
