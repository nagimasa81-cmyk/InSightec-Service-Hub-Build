"""WaterSystem Analyzer integration helpers for ISAP."""
