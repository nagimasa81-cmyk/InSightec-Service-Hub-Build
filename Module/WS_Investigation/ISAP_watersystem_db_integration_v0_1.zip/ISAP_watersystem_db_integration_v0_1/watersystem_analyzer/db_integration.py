"""
WaterSystem Analyzer DB Integration v0.1

This adapter converts WaterSystem Analyzer results into the ISAP Shared Data Layer
parsed_result format, then saves them to SQLite through shared.db_manager.

Code language: English only.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable

from shared.db_manager import import_watersystem_result, initialize_database

PARSER_NAME = "WaterSystemParser"
PARSER_VERSION = "0.1.0"
ALGORITHM_VERSION = "0.1.0"
UNKNOWN = "Unknown"


@dataclass
class WaterSystemMetric:
    metric_key: str
    event_name: str | None = None
    event_index: int | None = None
    section_start: str | None = None
    section_end: str | None = None
    value_real: float | None = None
    value_text: str | None = None
    unit: str | None = None
    quality_flag: str = "normal"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def build_parsed_result(
    *,
    site_name: str | None,
    serial_number: str | None,
    log_datetime: str | None,
    metrics: Iterable[WaterSystemMetric | dict[str, Any]],
    country: str | None = None,
    parser_name: str = PARSER_NAME,
    parser_version: str = PARSER_VERSION,
    algorithm_version: str = ALGORITHM_VERSION,
    notes: str | None = None,
) -> dict[str, Any]:
    """Build the standard parsed_result dictionary required by ISAP shared DB."""
    metric_list: list[dict[str, Any]] = []
    for metric in metrics:
        if isinstance(metric, WaterSystemMetric):
            metric_list.append(metric.to_dict())
        else:
            metric_list.append(dict(metric))

    return {
        "site_name": site_name or UNKNOWN,
        "country": country,
        "serial_number": serial_number or UNKNOWN,
        "log_datetime": log_datetime,
        "parser_name": parser_name,
        "parser_version": parser_version,
        "algorithm_version": algorithm_version,
        "metrics": metric_list,
        "notes": notes,
    }


def save_watersystem_analysis_to_db(
    *,
    db_path: str | Path,
    source_log_path: str | Path,
    site_name: str | None,
    serial_number: str | None,
    log_datetime: str | None,
    metrics: Iterable[WaterSystemMetric | dict[str, Any]],
    country: str | None = None,
    force_reparse: bool = False,
    notes: str | None = None,
) -> dict[str, Any]:
    """
    High-level function for WaterSystem Analyzer.

    Existing Analyzer code should call this function after parsing one log file.
    """
    initialize_database(db_path)
    parsed_result = build_parsed_result(
        site_name=site_name,
        country=country,
        serial_number=serial_number,
        log_datetime=log_datetime,
        metrics=metrics,
        notes=notes,
    )
    return import_watersystem_result(
        db_path=db_path,
        source_log_path=source_log_path,
        parsed_result=parsed_result,
        force_reparse=force_reparse,
    )


def metrics_from_section_result(section: dict[str, Any]) -> list[WaterSystemMetric]:
    """
    Convert one WaterSystem section result into ISAP metric rows.

    Expected flexible keys from existing Analyzer:
      event_name, event_index, section_start, section_end,
      min_do, to_min_do_min, to_1_5_min, to_1_0_min,
      saturated, vacuum_max, vacuum_min, vacuum_avg,
      vacuum_at_do_decrease_start, vacuum_at_section_end, vacuum_direction,
      secondary_flow_avg, secondary_flow_min, secondary_flow_under_2_5,
      duration_min
    """
    event_name = section.get("event_name")
    event_index = section.get("event_index")
    section_start = section.get("section_start")
    section_end = section.get("section_end")

    def row(key: str, value: Any, unit: str | None = None, flag: str = "normal") -> WaterSystemMetric | None:
        if value is None:
            return None
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return WaterSystemMetric(
                metric_key=key,
                event_name=event_name,
                event_index=event_index,
                section_start=section_start,
                section_end=section_end,
                value_real=float(value),
                unit=unit,
                quality_flag=flag,
            )
        return WaterSystemMetric(
            metric_key=key,
            event_name=event_name,
            event_index=event_index,
            section_start=section_start,
            section_end=section_end,
            value_text=str(value),
            unit=unit,
            quality_flag=flag,
        )

    candidates = [
        row("do_min", section.get("min_do"), "mg/L"),
        row("do_to_min_time_min", section.get("to_min_do_min"), "min"),
        row("do_to_1_5_time_min", section.get("to_1_5_min"), "min"),
        row("do_to_1_0_time_min", section.get("to_1_0_min"), "min"),
        row("do_saturated_flag", section.get("saturated"), None),
        row("do_decrease_start_time", section.get("do_decrease_start_time"), None),
        row("vacuum_max", section.get("vacuum_max"), "kPa"),
        row("vacuum_min", section.get("vacuum_min"), "kPa"),
        row("vacuum_avg", section.get("vacuum_avg"), "kPa"),
        row("vacuum_at_do_decrease_start", section.get("vacuum_at_do_decrease_start"), "kPa"),
        row("vacuum_at_section_end", section.get("vacuum_at_section_end"), "kPa"),
        row("vacuum_direction", section.get("vacuum_direction"), None),
        row("secondary_flow_avg", section.get("secondary_flow_avg"), "L/min", "warning" if _is_under_or_equal(section.get("secondary_flow_avg"), 2.5) else "normal"),
        row("secondary_flow_min", section.get("secondary_flow_min"), "L/min", "warning" if _is_under_or_equal(section.get("secondary_flow_min"), 2.5) else "normal"),
        row("secondary_flow_under_2_5_flag", section.get("secondary_flow_under_2_5"), None),
        row("event_duration_min", section.get("duration_min"), "min"),
    ]
    return [m for m in candidates if m is not None]


def metrics_from_section_results(sections: Iterable[dict[str, Any]]) -> list[WaterSystemMetric]:
    """Convert many section dictionaries into flat metric rows."""
    metrics: list[WaterSystemMetric] = []
    for section in sections:
        metrics.extend(metrics_from_section_result(section))
    return metrics


def _is_under_or_equal(value: Any, threshold: float) -> bool:
    try:
        return float(value) <= threshold
    except (TypeError, ValueError):
        return False
