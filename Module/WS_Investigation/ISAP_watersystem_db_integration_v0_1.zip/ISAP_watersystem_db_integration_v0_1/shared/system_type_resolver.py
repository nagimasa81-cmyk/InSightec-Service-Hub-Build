"""
ISAP Shared Data Layer - System Type Resolver v0.1
Resolves time-dependent system type and software version.
"""

from __future__ import annotations

import sqlite3

UNKNOWN = "Unknown"


def resolve_system_type(conn: sqlite3.Connection, system_id: int, target_datetime: str | None) -> str:
    if not target_datetime:
        return UNKNOWN
    row = conn.execute(
        """
        SELECT system_type
        FROM system_type_history
        WHERE system_id = ?
          AND valid_from <= ?
          AND (valid_to IS NULL OR valid_to > ?)
        ORDER BY valid_from DESC
        LIMIT 1
        """,
        (system_id, target_datetime, target_datetime),
    ).fetchone()
    return row[0] if row else UNKNOWN


def resolve_software_version(conn: sqlite3.Connection, system_id: int, target_datetime: str | None) -> str:
    if not target_datetime:
        return UNKNOWN
    row = conn.execute(
        """
        SELECT software_version
        FROM software_version_history
        WHERE system_id = ?
          AND valid_from <= ?
          AND (valid_to IS NULL OR valid_to > ?)
        ORDER BY valid_from DESC
        LIMIT 1
        """,
        (system_id, target_datetime, target_datetime),
    ).fetchone()
    return row[0] if row else UNKNOWN
