"""
ISAP Shared Data Layer - Schema Manager v0.1
Creates and upgrades the SQLite database schema.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime

SCHEMA_NAME = "ISAP Shared Data Layer"
SCHEMA_VERSION = "0.1.0"


def utc_now() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def initialize_schema(conn: sqlite3.Connection) -> None:
    """Create all v0.1 tables and indexes if they do not exist."""
    conn.execute("PRAGMA foreign_keys = ON;")

    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS schema_info (
            id INTEGER PRIMARY KEY,
            schema_name TEXT NOT NULL,
            schema_version TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS sites (
            site_id INTEGER PRIMARY KEY AUTOINCREMENT,
            site_name TEXT NOT NULL UNIQUE,
            country TEXT,
            region TEXT,
            notes TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS systems (
            system_id INTEGER PRIMARY KEY AUTOINCREMENT,
            serial_number TEXT NOT NULL UNIQUE,
            site_id INTEGER,
            current_system_type TEXT,
            current_software_version TEXT,
            status TEXT DEFAULT 'active',
            notes TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(site_id) REFERENCES sites(site_id)
        );

        CREATE TABLE IF NOT EXISTS system_type_history (
            history_id INTEGER PRIMARY KEY AUTOINCREMENT,
            system_id INTEGER NOT NULL,
            system_type TEXT NOT NULL,
            valid_from TEXT NOT NULL,
            valid_to TEXT,
            reason TEXT,
            source TEXT,
            notes TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(system_id) REFERENCES systems(system_id)
        );

        CREATE TABLE IF NOT EXISTS software_version_history (
            version_id INTEGER PRIMARY KEY AUTOINCREMENT,
            system_id INTEGER NOT NULL,
            software_version TEXT NOT NULL,
            valid_from TEXT NOT NULL,
            valid_to TEXT,
            reason TEXT,
            source TEXT,
            notes TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(system_id) REFERENCES systems(system_id)
        );

        CREATE TABLE IF NOT EXISTS log_files (
            log_id INTEGER PRIMARY KEY AUTOINCREMENT,
            system_id INTEGER,
            site_id INTEGER,
            file_name TEXT NOT NULL,
            file_path TEXT,
            file_hash TEXT NOT NULL UNIQUE,
            log_datetime TEXT,
            imported_at TEXT NOT NULL,
            parser_name TEXT NOT NULL,
            parser_version TEXT NOT NULL,
            parse_status TEXT NOT NULL,
            system_type_at_log_time TEXT,
            software_version_at_log_time TEXT,
            raw_json_path TEXT,
            parsed_json_path TEXT,
            error_message TEXT,
            notes TEXT,
            FOREIGN KEY(system_id) REFERENCES systems(system_id),
            FOREIGN KEY(site_id) REFERENCES sites(site_id)
        );

        CREATE TABLE IF NOT EXISTS metric_dictionary (
            metric_id INTEGER PRIMARY KEY AUTOINCREMENT,
            metric_key TEXT NOT NULL UNIQUE,
            metric_name TEXT NOT NULL,
            unit TEXT,
            category TEXT,
            description TEXT,
            added_schema_version TEXT,
            retired_schema_version TEXT,
            is_active INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS parsed_log_metrics (
            parsed_metric_id INTEGER PRIMARY KEY AUTOINCREMENT,
            log_id INTEGER NOT NULL,
            metric_key TEXT NOT NULL,
            event_name TEXT,
            event_index INTEGER,
            section_start TEXT,
            section_end TEXT,
            value_real REAL,
            value_text TEXT,
            unit TEXT,
            quality_flag TEXT,
            algorithm_version TEXT NOT NULL,
            calculated_at TEXT NOT NULL,
            FOREIGN KEY(log_id) REFERENCES log_files(log_id),
            FOREIGN KEY(metric_key) REFERENCES metric_dictionary(metric_key)
        );

        CREATE TABLE IF NOT EXISTS replacement_events (
            replacement_id INTEGER PRIMARY KEY AUTOINCREMENT,
            system_id INTEGER NOT NULL,
            site_id INTEGER,
            event_date TEXT NOT NULL,
            part_category TEXT,
            part_name TEXT NOT NULL,
            part_number TEXT,
            serial_number_removed TEXT,
            serial_number_installed TEXT,
            reason TEXT,
            symptom TEXT,
            service_engineer TEXT,
            system_type_at_event_time TEXT,
            software_version_at_event_time TEXT,
            source TEXT,
            notes TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(system_id) REFERENCES systems(system_id),
            FOREIGN KEY(site_id) REFERENCES sites(site_id)
        );

        CREATE TABLE IF NOT EXISTS analysis_runs (
            analysis_run_id INTEGER PRIMARY KEY AUTOINCREMENT,
            analysis_name TEXT NOT NULL,
            analysis_type TEXT NOT NULL,
            target_scope TEXT,
            algorithm_version TEXT NOT NULL,
            parameters_json TEXT,
            started_at TEXT NOT NULL,
            finished_at TEXT,
            status TEXT NOT NULL,
            result_json_path TEXT,
            notes TEXT
        );

        CREATE TABLE IF NOT EXISTS reliability_results (
            result_id INTEGER PRIMARY KEY AUTOINCREMENT,
            analysis_run_id INTEGER NOT NULL,
            system_id INTEGER,
            log_id INTEGER,
            result_datetime TEXT NOT NULL,
            risk_score REAL,
            risk_level TEXT,
            suspected_part TEXT,
            confidence REAL,
            summary TEXT,
            result_json TEXT,
            FOREIGN KEY(analysis_run_id) REFERENCES analysis_runs(analysis_run_id),
            FOREIGN KEY(system_id) REFERENCES systems(system_id),
            FOREIGN KEY(log_id) REFERENCES log_files(log_id)
        );

        CREATE TABLE IF NOT EXISTS timeline_events (
            timeline_id INTEGER PRIMARY KEY AUTOINCREMENT,
            system_id INTEGER,
            site_id INTEGER,
            event_datetime TEXT NOT NULL,
            event_type TEXT NOT NULL,
            event_title TEXT NOT NULL,
            event_source TEXT,
            related_log_id INTEGER,
            related_replacement_id INTEGER,
            related_analysis_run_id INTEGER,
            details_json TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(system_id) REFERENCES systems(system_id),
            FOREIGN KEY(site_id) REFERENCES sites(site_id),
            FOREIGN KEY(related_log_id) REFERENCES log_files(log_id),
            FOREIGN KEY(related_replacement_id) REFERENCES replacement_events(replacement_id),
            FOREIGN KEY(related_analysis_run_id) REFERENCES analysis_runs(analysis_run_id)
        );

        CREATE TABLE IF NOT EXISTS data_provenance (
            provenance_id INTEGER PRIMARY KEY AUTOINCREMENT,
            object_type TEXT NOT NULL,
            object_id INTEGER NOT NULL,
            source_type TEXT,
            source_path TEXT,
            source_hash TEXT,
            parser_name TEXT,
            parser_version TEXT,
            algorithm_version TEXT,
            schema_version TEXT,
            created_at TEXT NOT NULL,
            notes TEXT
        );

        CREATE INDEX IF NOT EXISTS idx_log_files_system_time
        ON log_files(system_id, log_datetime);

        CREATE INDEX IF NOT EXISTS idx_metrics_log_key
        ON parsed_log_metrics(log_id, metric_key);

        CREATE INDEX IF NOT EXISTS idx_metrics_key_time
        ON parsed_log_metrics(metric_key, section_start);

        CREATE INDEX IF NOT EXISTS idx_replacement_system_date
        ON replacement_events(system_id, event_date);

        CREATE INDEX IF NOT EXISTS idx_system_type_history
        ON system_type_history(system_id, valid_from, valid_to);

        CREATE INDEX IF NOT EXISTS idx_software_version_history
        ON software_version_history(system_id, valid_from, valid_to);

        CREATE INDEX IF NOT EXISTS idx_timeline_system_time
        ON timeline_events(system_id, event_datetime);
        """
    )

    now = utc_now()
    row = conn.execute("SELECT id FROM schema_info WHERE id = 1").fetchone()
    if row:
        conn.execute(
            "UPDATE schema_info SET schema_name=?, schema_version=?, updated_at=? WHERE id=1",
            (SCHEMA_NAME, SCHEMA_VERSION, now),
        )
    else:
        conn.execute(
            "INSERT INTO schema_info (id, schema_name, schema_version, created_at, updated_at) VALUES (1, ?, ?, ?, ?)",
            (SCHEMA_NAME, SCHEMA_VERSION, now, now),
        )
    conn.commit()
