"""
ISAP Shared Data Layer - Metric Dictionary v0.1
Registers standard metric keys used by WaterSystem Analyzer.
"""

from __future__ import annotations

import sqlite3

DEFAULT_METRICS = [
    ("do_min", "DO Minimum", "mg/L", "DO", "Minimum DO value in section"),
    ("do_to_min_time_min", "Time to Min DO", "min", "DO", "Time from section start to minimum DO"),
    ("do_to_1_5_time_min", "Time to DO 1.5", "min", "DO", "Time from section start to DO 1.5"),
    ("do_to_1_0_time_min", "Time to DO 1.0", "min", "DO", "Time from section start to DO 1.0"),
    ("do_saturated_flag", "DO Saturated Flag", "flag", "DO", "Whether DO appears saturated"),
    ("do_decrease_start_time", "DO Decrease Start Time", "datetime", "DO", "Detected stable DO decrease start time"),
    ("vacuum_max", "Vacuum Maximum", "kPa", "Vacuum", "Maximum vacuum value in section"),
    ("vacuum_min", "Vacuum Minimum", "kPa", "Vacuum", "Minimum vacuum value in section"),
    ("vacuum_avg", "Vacuum Average", "kPa", "Vacuum", "Average vacuum value in section"),
    ("vacuum_at_do_decrease_start", "Vacuum at DO Decrease Start", "kPa", "Vacuum", "Vacuum at detected DO decrease start"),
    ("vacuum_at_section_end", "Vacuum at Section End", "kPa", "Vacuum", "Vacuum at section end"),
    ("vacuum_direction", "Vacuum Direction", "text", "Vacuum", "Vacuum trend direction, UP or DOWN"),
    ("secondary_flow_avg", "Secondary Flow Average", "L/min", "Flow", "Average secondary flow in section"),
    ("secondary_flow_min", "Secondary Flow Minimum", "L/min", "Flow", "Minimum secondary flow in section"),
    ("secondary_flow_under_2_5_flag", "Secondary Flow Under 2.5 Flag", "flag", "Flow", "Whether secondary flow is under or equal to 2.5"),
    ("event_duration_min", "Event Duration", "min", "Event", "Duration of event section"),
    ("pause_total_min", "Pause Total", "min", "Event", "Total pause time"),
    ("error_total_min", "Error Total", "min", "Event", "Total error time"),
    ("clean_tank_duration_min", "Clean Tank Duration", "min", "Runtime", "Clean Tank circulation duration"),
    ("clean_xd_duration_min", "Clean XD Duration", "min", "Runtime", "Clean XD circulation duration"),
    ("drain_duration_min", "Drain Duration", "min", "Runtime", "Drain duration"),
    ("fill_duration_min", "Fill Duration", "min", "Runtime", "Fill duration"),
]


def register_default_metrics(conn: sqlite3.Connection, schema_version: str = "0.1.0") -> None:
    """Insert default metrics. Existing metric keys are not overwritten."""
    conn.executemany(
        """
        INSERT OR IGNORE INTO metric_dictionary
        (metric_key, metric_name, unit, category, description, added_schema_version, is_active)
        VALUES (?, ?, ?, ?, ?, ?, 1)
        """,
        [(key, name, unit, category, desc, schema_version) for key, name, unit, category, desc in DEFAULT_METRICS],
    )
    conn.commit()
