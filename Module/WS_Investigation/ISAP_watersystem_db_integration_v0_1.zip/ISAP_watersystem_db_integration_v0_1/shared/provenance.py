"""
ISAP Shared Data Layer - Data Provenance v0.1
Stores traceability information for logs, metrics, replacements, and analysis results.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime

SCHEMA_VERSION = "0.1.0"


def utc_now() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def save_provenance(
    conn: sqlite3.Connection,
    object_type: str,
    object_id: int,
    source_type: str | None = None,
    source_path: str | None = None,
    source_hash: str | None = None,
    parser_name: str | None = None,
    parser_version: str | None = None,
    algorithm_version: str | None = None,
    schema_version: str = SCHEMA_VERSION,
    notes: str | None = None,
) -> int:
    cur = conn.execute(
        """
        INSERT INTO data_provenance
        (object_type, object_id, source_type, source_path, source_hash,
         parser_name, parser_version, algorithm_version, schema_version, created_at, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            object_type,
            object_id,
            source_type,
            source_path,
            source_hash,
            parser_name,
            parser_version,
            algorithm_version,
            schema_version,
            utc_now(),
            notes,
        ),
    )
    return int(cur.lastrowid)
