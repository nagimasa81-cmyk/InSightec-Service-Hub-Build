"""
ISAP Shared Data Layer - DB Manager v0.1
High-level API for WaterSystem Analyzer and Reliability Engine.
"""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

from .metric_dictionary import register_default_metrics
from .provenance import save_provenance
from .schema_manager import initialize_schema
from .system_type_resolver import resolve_software_version, resolve_system_type

PARSER_DEFAULT = "WaterSystemParser"
VERSION_DEFAULT = "0.1.0"
UNKNOWN = "Unknown"


def utc_now() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def connect(db_path: str | os.PathLike[str]) -> sqlite3.Connection:
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def initialize_database(db_path: str | os.PathLike[str]) -> None:
    """Create or update the shared SQLite database."""
    with connect(db_path) as conn:
        initialize_schema(conn)
        register_default_metrics(conn)


def calculate_file_hash(file_path: str | os.PathLike[str]) -> str:
    """Return SHA256 hash of a file."""
    sha = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            sha.update(chunk)
    return sha.hexdigest()


def is_log_already_imported(conn: sqlite3.Connection, file_hash: str) -> bool:
    row = conn.execute("SELECT log_id FROM log_files WHERE file_hash = ?", (file_hash,)).fetchone()
    return row is not None


def get_or_create_site(conn: sqlite3.Connection, site_name: str | None, country: str | None = None) -> int:
    site_name = site_name or UNKNOWN
    now = utc_now()
    row = conn.execute("SELECT site_id FROM sites WHERE site_name = ?", (site_name,)).fetchone()
    if row:
        return int(row[0])
    cur = conn.execute(
        """
        INSERT INTO sites (site_name, country, created_at, updated_at)
        VALUES (?, ?, ?, ?)
        """,
        (site_name, country, now, now),
    )
    return int(cur.lastrowid)


def get_or_create_system(conn: sqlite3.Connection, serial_number: str | None, site_id: int | None = None) -> int:
    serial_number = serial_number or UNKNOWN
    now = utc_now()
    row = conn.execute("SELECT system_id FROM systems WHERE serial_number = ?", (serial_number,)).fetchone()
    if row:
        system_id = int(row[0])
        if site_id:
            conn.execute("UPDATE systems SET site_id = COALESCE(site_id, ?), updated_at = ? WHERE system_id = ?", (site_id, now, system_id))
        return system_id
    cur = conn.execute(
        """
        INSERT INTO systems
        (serial_number, site_id, current_system_type, current_software_version, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, 'active', ?, ?)
        """,
        (serial_number, site_id, UNKNOWN, UNKNOWN, now, now),
    )
    return int(cur.lastrowid)


def add_system_type_history(
    db_path: str | os.PathLike[str],
    serial_number: str,
    system_type: str,
    valid_from: str,
    valid_to: str | None = None,
    site_name: str | None = None,
    reason: str | None = "manual",
    source: str | None = "manual",
    notes: str | None = None,
) -> int:
    """Add a system type history record such as V1, V2, or Prime."""
    with connect(db_path) as conn:
        site_id = get_or_create_site(conn, site_name) if site_name else None
        system_id = get_or_create_system(conn, serial_number, site_id)
        now = utc_now()
        cur = conn.execute(
            """
            INSERT INTO system_type_history
            (system_id, system_type, valid_from, valid_to, reason, source, notes, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (system_id, system_type, valid_from, valid_to, reason, source, notes, now, now),
        )
        conn.execute(
            "UPDATE systems SET current_system_type = ?, updated_at = ? WHERE system_id = ?",
            (system_type, now, system_id),
        )
        conn.commit()
        return int(cur.lastrowid)


def add_software_version_history(
    db_path: str | os.PathLike[str],
    serial_number: str,
    software_version: str,
    valid_from: str,
    valid_to: str | None = None,
    site_name: str | None = None,
    reason: str | None = "manual",
    source: str | None = "manual",
    notes: str | None = None,
) -> int:
    """Add software version history."""
    with connect(db_path) as conn:
        site_id = get_or_create_site(conn, site_name) if site_name else None
        system_id = get_or_create_system(conn, serial_number, site_id)
        now = utc_now()
        cur = conn.execute(
            """
            INSERT INTO software_version_history
            (system_id, software_version, valid_from, valid_to, reason, source, notes, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (system_id, software_version, valid_from, valid_to, reason, source, notes, now, now),
        )
        conn.execute(
            "UPDATE systems SET current_software_version = ?, updated_at = ? WHERE system_id = ?",
            (software_version, now, system_id),
        )
        conn.commit()
        return int(cur.lastrowid)


def _save_json_archive(db_path: str | os.PathLike[str], subfolder: str, file_hash: str, data: dict[str, Any]) -> str:
    base = Path(db_path).parent
    target_dir = base / subfolder
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / f"{file_hash}.json"
    with open(target, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return str(target)


def import_watersystem_result(
    db_path: str | os.PathLike[str],
    source_log_path: str | os.PathLike[str],
    parsed_result: dict[str, Any],
    force_reparse: bool = False,
) -> dict[str, Any]:
    """
    Import one parsed WaterSystem result into the shared database.

    parsed_result expected keys:
      site_name, serial_number, log_datetime, parser_name, parser_version,
      algorithm_version, metrics(list)
    """
    initialize_database(db_path)
    source_path = Path(source_log_path)
    file_hash = calculate_file_hash(source_path)

    with connect(db_path) as conn:
        if is_log_already_imported(conn, file_hash) and not force_reparse:
            row = conn.execute("SELECT log_id FROM log_files WHERE file_hash = ?", (file_hash,)).fetchone()
            return {"status": "skipped", "reason": "duplicate", "log_id": int(row[0]), "file_hash": file_hash}

        site_name = parsed_result.get("site_name") or UNKNOWN
        country = parsed_result.get("country")
        serial_number = parsed_result.get("serial_number") or UNKNOWN
        log_datetime = parsed_result.get("log_datetime")
        parser_name = parsed_result.get("parser_name") or PARSER_DEFAULT
        parser_version = parsed_result.get("parser_version") or VERSION_DEFAULT
        algorithm_version = parsed_result.get("algorithm_version") or VERSION_DEFAULT
        metrics = parsed_result.get("metrics") or []

        site_id = get_or_create_site(conn, site_name, country)
        system_id = get_or_create_system(conn, serial_number, site_id)
        system_type = resolve_system_type(conn, system_id, log_datetime)
        software_version = resolve_software_version(conn, system_id, log_datetime)

        parsed_json_path = _save_json_archive(db_path, "parsed_json", file_hash, parsed_result)
        parse_status = "success" if metrics else "warning"
        now = utc_now()

        cur = conn.execute(
            """
            INSERT INTO log_files
            (system_id, site_id, file_name, file_path, file_hash, log_datetime, imported_at,
             parser_name, parser_version, parse_status, system_type_at_log_time,
             software_version_at_log_time, parsed_json_path, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                system_id,
                site_id,
                source_path.name,
                str(source_path),
                file_hash,
                log_datetime,
                now,
                parser_name,
                parser_version,
                parse_status,
                system_type,
                software_version,
                parsed_json_path,
                parsed_result.get("notes"),
            ),
        )
        log_id = int(cur.lastrowid)

        metric_rows = []
        for m in metrics:
            metric_rows.append(
                (
                    log_id,
                    m.get("metric_key"),
                    m.get("event_name"),
                    m.get("event_index"),
                    m.get("section_start"),
                    m.get("section_end"),
                    m.get("value_real"),
                    m.get("value_text"),
                    m.get("unit"),
                    m.get("quality_flag") or "normal",
                    algorithm_version,
                    now,
                )
            )

        if metric_rows:
            conn.executemany(
                """
                INSERT INTO parsed_log_metrics
                (log_id, metric_key, event_name, event_index, section_start, section_end,
                 value_real, value_text, unit, quality_flag, algorithm_version, calculated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                metric_rows,
            )

        conn.execute(
            """
            INSERT INTO timeline_events
            (system_id, site_id, event_datetime, event_type, event_title, event_source,
             related_log_id, details_json, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                system_id,
                site_id,
                log_datetime or now,
                "log_imported",
                f"WaterSystem log imported: {source_path.name}",
                "WaterSystem Analyzer",
                log_id,
                json.dumps({"file_hash": file_hash, "metric_count": len(metric_rows)}, ensure_ascii=False),
                now,
            ),
        )

        save_provenance(
            conn,
            object_type="log",
            object_id=log_id,
            source_type="file",
            source_path=str(source_path),
            source_hash=file_hash,
            parser_name=parser_name,
            parser_version=parser_version,
            algorithm_version=algorithm_version,
            notes="Imported by import_watersystem_result",
        )

        conn.commit()
        return {
            "status": parse_status,
            "log_id": log_id,
            "site_id": site_id,
            "system_id": system_id,
            "file_hash": file_hash,
            "metric_count": len(metric_rows),
            "system_type_at_log_time": system_type,
            "software_version_at_log_time": software_version,
            "parsed_json_path": parsed_json_path,
        }
