# ISAP WaterSystem DB Integration v0.1

This package connects WaterSystem Analyzer results to the ISAP Shared Data Layer.

## Purpose

Existing WaterSystem Analyzer code should not write SQL directly.
It should convert parsed section results into standard ISAP metric rows and call one save function.

## Main file

```text
watersystem_analyzer/db_integration.py
```

## Main functions

```python
metrics_from_section_results(section_results)
save_watersystem_analysis_to_db(...)
```

## Integration point

After one log is parsed by WaterSystem Analyzer:

```python
metrics = metrics_from_section_results(section_results)

result = save_watersystem_analysis_to_db(
    db_path="SharedData/watersystem_history.sqlite",
    source_log_path=log_path,
    site_name=site_name,
    serial_number=serial_number,
    log_datetime=log_datetime,
    metrics=metrics,
)
```

## Important rule

Unknown values should be saved as `Unknown` or `None`.
Do not guess site, serial, system type, or software version.

## Requires

Copy the `shared/` folder from `ISAP_shared_module_v0_1` into the same project root.
