# WaterSystem Analyzer DB Integration Spec v0.1

## Goal

Connect WaterSystem Analyzer to ISAP Shared SQLite without changing the analyzer core too much.

## Analyzer responsibility

The Analyzer should continue to parse logs and create chart data.
It only needs to produce section result dictionaries.

## Shared DB responsibility

The Shared Data Layer handles:

- database creation
- duplicate file check
- system/site registration
- system type resolution
- software version resolution
- metric storage
- timeline event storage
- provenance storage

## Recommended Analyzer Output

Each section result should use these keys when possible:

```text
event_name
event_index
section_start
section_end
duration_min
min_do
to_min_do_min
to_1_5_min
to_1_0_min
saturated
do_decrease_start_time
vacuum_max
vacuum_min
vacuum_avg
vacuum_at_do_decrease_start
vacuum_at_section_end
vacuum_direction
secondary_flow_avg
secondary_flow_min
secondary_flow_under_2_5
```

## First target

Add a `Save to DB` option after parsing/importing WaterSystem logs.

## Later target

Add automatic DB save when batch import is completed.
