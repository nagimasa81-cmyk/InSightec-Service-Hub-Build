"""
Example: save existing WaterSystem Analyzer section results to ISAP SQLite.

Folder assumption:
  ISAP/
    shared/
    watersystem_analyzer/
    examples/
    SharedData/
"""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# In a real project, shared/ comes from ISAP_shared_module_v0_1.
from shared.db_manager import add_software_version_history, add_system_type_history, initialize_database
from watersystem_analyzer.db_integration import metrics_from_section_results, save_watersystem_analysis_to_db

DB_PATH = ROOT / "SharedData" / "watersystem_history.sqlite"
SAMPLE_LOG = ROOT / "examples" / "sample_watersystem.log"


def main() -> None:
    initialize_database(DB_PATH)
    SAMPLE_LOG.write_text("Sample WaterSystem log content.\n", encoding="utf-8")

    add_system_type_history(DB_PATH, "WS12345", "Prime", "2026-01-01T00:00:00", site_name="Hospital A")
    add_software_version_history(DB_PATH, "WS12345", "5.4.0", "2026-01-01T00:00:00", site_name="Hospital A")

    section_results = [
        {
            "event_name": "TREAT_CIRCULATE",
            "event_index": 1,
            "section_start": "2026-07-08T10:30:00",
            "section_end": "2026-07-08T10:45:00",
            "duration_min": 15.0,
            "min_do": 1.23,
            "to_min_do_min": 8.4,
            "to_1_5_min": 5.2,
            "to_1_0_min": None,
            "saturated": False,
            "vacuum_max": 96.2,
            "vacuum_min": 91.1,
            "vacuum_avg": 94.5,
            "vacuum_at_do_decrease_start": 95.1,
            "vacuum_at_section_end": 92.4,
            "vacuum_direction": "DOWN",
            "secondary_flow_avg": 2.41,
            "secondary_flow_min": 2.31,
            "secondary_flow_under_2_5": True,
        }
    ]

    metrics = metrics_from_section_results(section_results)

    result = save_watersystem_analysis_to_db(
        db_path=DB_PATH,
        source_log_path=SAMPLE_LOG,
        site_name="Hospital A",
        serial_number="WS12345",
        log_datetime="2026-07-08T10:30:00",
        metrics=metrics,
        notes="Example import from WaterSystem Analyzer integration v0.1",
    )

    print(result)


if __name__ == "__main__":
    main()
