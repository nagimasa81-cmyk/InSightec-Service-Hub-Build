@echo off
setlocal
cd /d "%~dp0"
set PYEXE=py -3.13
%PYEXE% -c "import sys; print(sys.version)" >nul 2>&1
if errorlevel 1 set PYEXE=py -3.14

%PYEXE% -m pip install --upgrade pip
%PYEXE% -m pip install -r requirements.txt
%PYEXE% -m nuitka ^
  --mode=standalone ^
  --enable-plugin=pyside6 ^
  --windows-console-mode=disable ^
  --output-filename=LogMerge_Investigation_Workspace.exe ^
  main.py
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo Build completed.
pause
