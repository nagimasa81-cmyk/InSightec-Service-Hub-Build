
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QPushButton,
    QComboBox, QLabel, QFileDialog, QTableWidget, QTableWidgetItem, QTextEdit,
    QSplitter, QMessageBox, QHeaderView, QListWidget, QListWidgetItem, QFrame,
    QSpinBox, QCheckBox
)

SUPPORTED_TYPES = ["WS", "CSA", "CGA", "WaterSystem", "mrserver", "gesyslog"]

TEMPLATES = {
    "Initial Investigation": ["WS", "CSA", "CGA"],
    "Water Investigation": ["WS", "CSA", "CGA", "WaterSystem"],
    "MR Investigation": ["WS", "mrserver", "gesyslog"],
    "Custom Investigation": []
}

TIME_RE = re.compile(
    r"(?P<h>\d{1,2}):(?P<m>\d{2}):(?P<s>\d{2})(?::(?P<ms>\d{1,3})|\.(?P<ms2>\d{1,3}))?"
)

@dataclass
class LogRow:
    timestamp_ms: Optional[int]
    timestamp_text: str
    message: str
    source_file: str
    line_no: int

def parse_time_ms(text: str) -> Tuple[Optional[int], str]:
    m = TIME_RE.search(text)
    if not m:
        return None, ""
    h = int(m.group("h"))
    mi = int(m.group("m"))
    s = int(m.group("s"))
    ms_text = m.group("ms") or m.group("ms2") or "0"
    ms = int(ms_text.ljust(3, "0")[:3])
    return ((h * 3600 + mi * 60 + s) * 1000 + ms,
            f"{h:02d}:{mi:02d}:{s:02d}.{ms:03d}")

class LogPanel(QFrame):
    rowSelected = Signal(str, int, str)

    def __init__(self, log_type: str, parent=None):
        super().__init__(parent)
        self.log_type = log_type
        self.rows: List[LogRow] = []
        self.setObjectName("logPanel")
        layout = QVBoxLayout(self)
        head = QHBoxLayout()
        self.title = QLabel(log_type)
        self.title.setObjectName("panelTitle")
        self.file_label = QLabel("No file loaded")
        self.file_label.setObjectName("muted")
        self.load_btn = QPushButton("Load")
        self.load_btn.clicked.connect(self.load_file)
        head.addWidget(self.title)
        head.addWidget(self.file_label, 1)
        head.addWidget(self.load_btn)
        layout.addLayout(head)

        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Time", "Message", "Line"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.itemSelectionChanged.connect(self._emit_selected)
        self.table.setAlternatingRowColors(True)
        layout.addWidget(self.table)

    def load_file(self):
        path, _ = QFileDialog.getOpenFileName(self, f"Load {self.log_type}", "", "Log/Text Files (*.log *.txt *.out *.ar);;All Files (*.*)")
        if path:
            self.load_path(Path(path))

    def load_path(self, path: Path):
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            QMessageBox.critical(self, "Load Error", str(exc))
            return
        self.rows.clear()
        for n, line in enumerate(text.splitlines(), 1):
            ts_ms, ts_text = parse_time_ms(line)
            self.rows.append(LogRow(ts_ms, ts_text, line, path.name, n))
        self.file_label.setText(path.name)
        self.refresh()

    def refresh(self, keyword: str = ""):
        key = keyword.lower().strip()
        visible = [r for r in self.rows if not key or key in r.message.lower()]
        self.table.setRowCount(len(visible))
        for i, row in enumerate(visible):
            self.table.setItem(i, 0, QTableWidgetItem(row.timestamp_text))
            self.table.setItem(i, 1, QTableWidgetItem(row.message))
            self.table.setItem(i, 2, QTableWidgetItem(str(row.line_no)))
            self.table.item(i, 0).setData(Qt.UserRole, row.timestamp_ms)
        self.table.resizeRowsToContents()

    def jump_to_time(self, target_ms: int, tolerance_ms: int):
        best_row = -1
        best_diff = None
        for i in range(self.table.rowCount()):
            ts = self.table.item(i, 0).data(Qt.UserRole)
            if ts is None:
                continue
            diff = abs(ts - target_ms)
            if best_diff is None or diff < best_diff:
                best_diff = diff
                best_row = i
        if best_row >= 0 and (best_diff is None or best_diff <= tolerance_ms):
            self.table.selectRow(best_row)
            self.table.scrollToItem(self.table.item(best_row, 1), QTableWidget.PositionAtCenter)

    def _emit_selected(self):
        items = self.table.selectedItems()
        if not items:
            return
        row = items[0].row()
        ts = self.table.item(row, 0).data(Qt.UserRole)
        msg = self.table.item(row, 1).text()
        if ts is not None:
            self.rowSelected.emit(self.log_type, int(ts), msg)

class InvestigationWorkspace(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("LogMerge Investigation Workspace Prototype v0.1")
        self.resize(1500, 900)
        self.bookmarks: List[dict] = []
        self.panels: Dict[str, LogPanel] = {}
        self._sync_guard = False
        self._build_ui()
        self._apply_style()
        self.apply_template("Initial Investigation")

    def _build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        main = QVBoxLayout(root)

        top = QHBoxLayout()
        title = QLabel("Investigation Workspace")
        title.setObjectName("mainTitle")
        top.addWidget(title)
        top.addStretch()

        top.addWidget(QLabel("Template"))
        self.template_combo = QComboBox()
        self.template_combo.addItems(TEMPLATES.keys())
        self.template_combo.currentTextChanged.connect(self.apply_template)
        top.addWidget(self.template_combo)

        top.addWidget(QLabel("Sync Window"))
        self.tolerance = QComboBox()
        self.tolerance.addItem("Exact", 0)
        self.tolerance.addItem("±1 sec", 1000)
        self.tolerance.addItem("±5 sec", 5000)
        self.tolerance.addItem("±10 sec", 10000)
        self.tolerance.addItem("±30 sec", 30000)
        self.tolerance.setCurrentIndex(2)
        top.addWidget(self.tolerance)

        self.sync_check = QCheckBox("Time Sync")
        self.sync_check.setChecked(True)
        top.addWidget(self.sync_check)

        self.exit_btn = QPushButton("Return to Viewer")
        self.exit_btn.clicked.connect(self.close)
        top.addWidget(self.exit_btn)
        main.addLayout(top)

        controls = QHBoxLayout()
        self.search_edit = QTextEdit()
        self.search_edit.setFixedHeight(36)
        self.search_edit.setPlaceholderText("Search across visible logs...")
        self.search_edit.textChanged.connect(self.apply_search)
        controls.addWidget(self.search_edit, 1)
        clear_btn = QPushButton("Clear Search")
        clear_btn.clicked.connect(lambda: self.search_edit.clear())
        controls.addWidget(clear_btn)
        bookmark_btn = QPushButton("Add Bookmark")
        bookmark_btn.clicked.connect(self.add_bookmark)
        controls.addWidget(bookmark_btn)
        main.addLayout(controls)

        splitter = QSplitter(Qt.Vertical)
        main.addWidget(splitter, 1)

        self.grid_container = QWidget()
        self.grid = QGridLayout(self.grid_container)
        splitter.addWidget(self.grid_container)

        bottom = QSplitter(Qt.Horizontal)
        splitter.addWidget(bottom)
        splitter.setSizes([650, 220])

        timeline_box = QWidget()
        tl = QVBoxLayout(timeline_box)
        tl.addWidget(QLabel("Investigation Timeline"))
        self.timeline = QListWidget()
        self.timeline.itemClicked.connect(self.timeline_jump)
        tl.addWidget(self.timeline)
        bottom.addWidget(timeline_box)

        bookmark_box = QWidget()
        bl = QVBoxLayout(bookmark_box)
        bl.addWidget(QLabel("Bookmarks"))
        self.bookmark_list = QListWidget()
        self.bookmark_list.itemClicked.connect(self.bookmark_jump)
        bl.addWidget(self.bookmark_list)
        bottom.addWidget(bookmark_box)

        notes_box = QWidget()
        nl = QVBoxLayout(notes_box)
        nl.addWidget(QLabel("Investigation Notes"))
        self.notes = QTextEdit()
        self.notes.setPlaceholderText("Record findings, actions, and next steps...")
        nl.addWidget(self.notes)
        bottom.addWidget(notes_box)

        for log_type in SUPPORTED_TYPES:
            panel = LogPanel(log_type)
            panel.rowSelected.connect(self.on_row_selected)
            self.panels[log_type] = panel

        self.statusBar().showMessage("Ready")

    def _apply_style(self):
        self.setStyleSheet("""
            QMainWindow, QWidget { background: #f4f7fb; color: #1f2937; font-family: Segoe UI; }
            #mainTitle { font-size: 24px; font-weight: 700; color: #005DAA; }
            #logPanel { background: white; border: 1px solid #d9e2ec; border-radius: 8px; }
            #panelTitle { font-size: 16px; font-weight: 700; color: #005DAA; }
            #muted { color: #64748b; }
            QPushButton { background: #005DAA; color: white; border: 0; border-radius: 5px; padding: 7px 12px; font-weight: 600; }
            QPushButton:hover { background: #0079C2; }
            QComboBox, QTextEdit, QListWidget, QTableWidget {
                background: white; border: 1px solid #cbd5e1; border-radius: 4px;
            }
            QHeaderView::section { background: #eaf2f8; padding: 6px; border: 0; font-weight: 600; }
            QTableWidget::item:selected { background: #b9ddf5; color: #102a43; }
        """)

    def apply_template(self, template_name: str):
        wanted = TEMPLATES.get(template_name, [])
        if template_name == "Custom Investigation":
            wanted = SUPPORTED_TYPES[:4]
        while self.grid.count():
            item = self.grid.takeAt(0)
            if item.widget():
                item.widget().setParent(None)
        for idx, log_type in enumerate(wanted):
            panel = self.panels[log_type]
            panel.setParent(self.grid_container)
            self.grid.addWidget(panel, idx // 3, idx % 3)
        self.statusBar().showMessage(f"Template: {template_name} ({', '.join(wanted)})")
        self.rebuild_timeline()

    def visible_panels(self) -> List[LogPanel]:
        result = []
        for i in range(self.grid.count()):
            w = self.grid.itemAt(i).widget()
            if isinstance(w, LogPanel):
                result.append(w)
        return result

    def apply_search(self):
        key = self.search_edit.toPlainText()
        for panel in self.visible_panels():
            panel.refresh(key)

    def on_row_selected(self, source_type: str, ts_ms: int, message: str):
        if self._sync_guard:
            return
        self.statusBar().showMessage(f"{source_type} @ {self._format_ms(ts_ms)}")
        if not self.sync_check.isChecked():
            return
        self._sync_guard = True
        try:
            tolerance = int(self.tolerance.currentData())
            for panel in self.visible_panels():
                if panel.log_type != source_type:
                    panel.jump_to_time(ts_ms, tolerance)
        finally:
            self._sync_guard = False

    def add_bookmark(self):
        for panel in self.visible_panels():
            items = panel.table.selectedItems()
            if not items:
                continue
            row = items[0].row()
            ts = panel.table.item(row, 0).data(Qt.UserRole)
            msg = panel.table.item(row, 1).text()
            if ts is None:
                continue
            entry = {"type": panel.log_type, "time_ms": int(ts), "message": msg}
            self.bookmarks.append(entry)
            item = QListWidgetItem(f"{panel.log_type}  {self._format_ms(int(ts))}  {msg[:100]}")
            item.setData(Qt.UserRole, entry)
            self.bookmark_list.addItem(item)
            return
        QMessageBox.information(self, "Bookmark", "Select a timestamped log row first.")

    def bookmark_jump(self, item: QListWidgetItem):
        entry = item.data(Qt.UserRole)
        panel = self.panels.get(entry["type"])
        if panel:
            panel.jump_to_time(entry["time_ms"], 10**9)

    def rebuild_timeline(self):
        self.timeline.clear()
        candidates = []
        critical = ("error", "fatal", "watchdog", "restart", "warning", "fail", "alarm")
        for panel in self.visible_panels():
            for row in panel.rows:
                if row.timestamp_ms is not None and any(k in row.message.lower() for k in critical):
                    candidates.append((row.timestamp_ms, panel.log_type, row.message))
        candidates.sort(key=lambda x: x[0])
        for ts, log_type, msg in candidates[:500]:
            item = QListWidgetItem(f"{self._format_ms(ts)}  [{log_type}]  {msg[:140]}")
            item.setData(Qt.UserRole, {"type": log_type, "time_ms": ts})
            self.timeline.addItem(item)

    def timeline_jump(self, item: QListWidgetItem):
        entry = item.data(Qt.UserRole)
        panel = self.panels.get(entry["type"])
        if panel:
            panel.jump_to_time(entry["time_ms"], 10**9)
            self.on_row_selected(entry["type"], entry["time_ms"], "")

    @staticmethod
    def _format_ms(value: int) -> str:
        h = value // 3600000
        value %= 3600000
        m = value // 60000
        value %= 60000
        s = value // 1000
        ms = value % 1000
        return f"{h:02d}:{m:02d}:{s:02d}.{ms:03d}"
