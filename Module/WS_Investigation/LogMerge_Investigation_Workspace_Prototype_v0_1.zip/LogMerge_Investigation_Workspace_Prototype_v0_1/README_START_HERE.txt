LogMerge Investigation Workspace Prototype v0.1

Purpose
-------
Standalone prototype designed for later integration into
LogMergeTool_NoExcel_PSC_Review_FINAL_v41_2_CleanIntegrated.

Implemented
-----------
- Initial Investigation: WS / CSA / CGA
- Water Investigation: WS / CSA / CGA / WaterSystem
- MR Investigation: WS / mrserver / gesyslog
- Custom Investigation placeholder
- Load logs independently per panel
- Click a timestamped row to synchronize visible logs
- Sync windows: Exact, ±1s, ±5s, ±10s, ±30s
- Search across visible logs
- Critical-event timeline (error/fatal/watchdog/restart/warning/fail/alarm)
- Bookmarks
- Investigation notes
- Return to Viewer button placeholder
- No hover popup for value-oriented logs

Run
---
1. Install Python 3.13 or 3.14
2. Run 00_RUN_PYTHON.bat

Build EXE
---------
Run 01_BUILD_EXE_NUITKA.bat

Integration target
------------------
modules/investigation/
    workspace.py
The module is intentionally isolated so it can later be called from Log Merge.
