
import sys
from pathlib import Path
from PySide6.QtWidgets import QApplication
from modules.investigation.workspace import InvestigationWorkspace

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("LogMerge Investigation Workspace Prototype")
    win = InvestigationWorkspace()
    win.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
