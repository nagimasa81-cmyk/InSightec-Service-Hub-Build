LogMerge Investigation Workspace Prototype v0.2

New in v0.2
- Load Folder with automatic WS / CSA / CGA / WaterSystem / mrserver / gesyslog detection
- Critical and Warning row highlighting
- Critical-only filter
- Faster compact table layout
- No hover popup in value-oriented views
- Future Log Merge integration entry point: set_session_rows(rows_by_type)
- Existing templates, time sync, timeline, bookmarks, notes, and cross-log search retained

Run: 00_RUN_PYTHON.bat
Build: 01_BUILD_EXE_NUITKA.bat
For standalone distribution, keep the generated .dist folder together.
