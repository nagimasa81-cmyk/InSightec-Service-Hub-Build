@echo off
setlocal
cd /d "%~dp0"
py -3.13 -m pip install -r requirements.txt
if errorlevel 1 py -3.14 -m pip install -r requirements.txt
py -3.13 main.py
if errorlevel 1 py -3.14 main.py
pause
