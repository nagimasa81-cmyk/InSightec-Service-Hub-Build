
from pathlib import Path

def test_sonication_phase_display_keeps_absolute_wrapped_reference():
    src=(Path(__file__).parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'plotted = np.angle(np.exp(1j * phase_arr))' in src
    assert "phase_label = 'wrapped sonication phase'" in src

def test_phase_phasor_uses_phase_angle_and_amplitude_radius():
    src=(Path(__file__).parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'theta=np.deg2rad(float(rel_deg))' in src
    assert 'radius=max_radius*(0.35+0.60*amp_norm)' in src
