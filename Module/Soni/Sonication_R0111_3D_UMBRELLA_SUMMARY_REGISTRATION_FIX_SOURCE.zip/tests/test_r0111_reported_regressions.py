
from pathlib import Path
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")
HYD=(Path(__file__).parents[1]/"src/ui/hydrophone_window.py").read_text(encoding="utf-8")

def test_summary_uses_direct_model_numbers():
    assert 'getattr(son,"actual_power_w",None)' in MAIN
    assert 'getattr(son,"actual_energy_j",None)' in MAIN
    assert 're.search(r"[-+]?' in MAIN

def test_ct_volume_lazy_decodes():
    b=MAIN.split("def _ct_volume_for_registration",1)[1].split("\n    def ",1)[0]
    assert "arr=self._planning_array_for_asset(a)" in b
    assert "arr is not None" in b

def test_reference_thumbnail_preview_exists():
    assert "preview budget per category" in MAIN
    assert "preview=self._decode_planning_image(asset)" in MAIN

def test_increase_hidden_from_chart_and_list():
    b=HYD.split("def _draw_observed_cavitation_timeline",1)[1].split("\n    def ",1)[0]
    assert '=="Increase" and not show_increase' in b
    assert "Show Increase events (chart + list)" in HYD

def test_umbrella_is_interactive_3d():
    assert "def _umbrella_project" in MAIN
    assert "def wheelEvent" in MAIN
    assert "Top XY" in MAIN and "Front XZ" in MAIN and "Side YZ" in MAIN
    assert "def _element_channel_filter_changed" in MAIN

def test_phase_does_not_force_phase_dedicated():
    b=MAIN.split("def _element_parameter_changed",1)[1].split("def _element_layout_changed",1)[0]
    assert "setCurrentText('Phase dedicated')" not in b
