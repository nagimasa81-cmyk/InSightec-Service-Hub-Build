
from pathlib import Path
REG=(Path(__file__).parents[1]/"src/services/registration_overlay_service.py").read_text(encoding="utf-8")
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")
def test_compatibility_ranker_retained(): assert "def diagnose_reference_candidates" in REG
def test_candidate_specific_chain():
    b=REG.split("def diagnose_reference_series",1)[1].split("def format_reference_diagnostic",1)[0]
    assert "_registration_recipe(Path(workspace),int(sonication_index),asset)" in b
    assert 'category.startswith("PLANNING_MR")' in b and 'category.startswith("PREPLANNING_MR")' in b
def test_report_active_and_leading():
    b=REG.split("def format_reference_diagnostic",1)[1].split("def _trace_ct_voxel_to_mr_pixel",1)[0]
    assert "<ACTIVE>" in b and "LEADING REFERENCE:" in b
def test_main_runs_reference_diagnostic():
    assert "def _update_registration_reference_report" in MAIN
    b=MAIN.split("def _apply_registration_overlay",1)[1].split("def _activate_replay_mode_for_navigation",1)[0]
    assert "_update_registration_reference_report(ct_asset,ct_volume)" in b
def test_trace_dialog_has_reference_report():
    b=MAIN.split("def _show_registration_trace",1)[1].split("def _registration_toggled",1)[0]
    assert "_registration_reference_report" in b
