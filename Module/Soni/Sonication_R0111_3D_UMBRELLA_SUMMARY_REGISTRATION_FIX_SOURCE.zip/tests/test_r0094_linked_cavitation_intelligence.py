
from pathlib import Path
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")
HYD=(Path(__file__).parents[1]/"src/ui/hydrophone_window.py").read_text(encoding="utf-8")

def test_ci_has_linked_dropdown_and_toggle():
    assert 'QCheckBox("Show linked cavitation analysis")' in MAIN
    assert '"Vendor band energy reproduction"' in MAIN
    assert '"Cavitation control response + CGA / Acquisition Display Rule"' in MAIN
    assert "QStackedWidget" in MAIN

def test_ci_linked_events_have_persistent_marker():
    assert "def _ci_linked_event_selected" in MAIN
    assert "def _ci_linked_focus_time" in MAIN
    assert 'label="Selected event"' in MAIN
    assert "force_visible=True" in MAIN
    assert "_update_ci_linked_panel()" in MAIN

def test_ci_scrolls_to_prevent_lower_panel_clipping():
    block=MAIN.split("def _build_cavitation_intelligence_tab",1)[1].split("def _ci_linked_mode_changed",1)[0]
    assert "QScrollArea()" in block
    assert "setWidgetResizable(True)" in block

def test_spectrum_analyzer_why_popup_default_off():
    assert 'QCheckBox("Why popup")' in HYD
    assert "self.vendor_why_popup_check.setChecked(False)" in HYD
    assert "def _show_event_why_popup" in HYD
    assert "Why — Cavitation Event" in HYD

def test_chart_clicks_wire_to_why_popup():
    assert HYD.count("_show_event_why_popup(") >= 3
