from pathlib import Path

TEXT=(Path(__file__).resolve().parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')

def test_secondary_image_dropdowns_removed_from_replay_navigator():
    assert 'self.planning_image_combo = QComboBox()' not in TEXT
    assert 'self.anatomy_image_combo = QComboBox()' not in TEXT
    assert 'self.thermal_image_combo = QComboBox()' not in TEXT
    assert 'def _image_combo_selected' not in TEXT

def test_thumbnail_strips_are_full_series_horizontal_scrollers():
    assert 'widget.setWrapping(False)' in TEXT
    assert 'ScrollBarAlwaysOn' in TEXT
    assert 'ScrollPerPixel' in TEXT
    assert 'slide horizontally to browse all' in TEXT
    assert 'strip.horizontalScrollBar().setValue(0)' in TEXT

def test_planning_mr_ax_remains_default_reference_series():
    assert 'self.planning_type_combo.setCurrentText("Planning MR Ax")' in TEXT
