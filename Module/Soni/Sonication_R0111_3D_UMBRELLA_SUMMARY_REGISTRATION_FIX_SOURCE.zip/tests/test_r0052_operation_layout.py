from pathlib import Path
import numpy as np
from src.services.registration_overlay_service import RegistrationOverlayService


def test_registration_is_main_image_gated():
    text=Path('src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'enabled = bool(main_is_mr)' in text
    assert 'Never change\n        # the displayed image implicitly' in text


def test_treatment_mr_keeps_replay_view_separate_from_reference_view():
    text=Path('src/ui/main_window.py').read_text(encoding='utf-8')
    assert '_planning_overlay_view' in text
    assert 'self._fit_overlay_next = self._overlay_session_view is None' in text
    assert 'Planning/Registration and Replay keep independent ViewBox ranges' in text


def test_vendor_chart_product_layout_and_receiver_selector():
    text=Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'vendor_receiver_combo' in text
    assert '["Both", "Control response", "CGA Display Rule"]' in text
    assert 'vendor_rule_view = pg.ViewBox()' in text
    assert 'Cavitation control response + CGA / Acquisition Display Rule' in text


def test_preplanning_registration_has_mrmr_chain_hypotheses(tmp_path):
    son=tmp_path/'Sonication1'; son.mkdir()
    (son/'MrMr_mat.txt').write_text('\n'.join(['1 0 0 1','0 1 0 2','0 0 1 3','0 0 0 1']))
    svc=RegistrationOverlayService()
    class A: category='PREPLANNING_MR_AX'
    c=np.eye(4)
    hs=svc._registration_hypotheses(tmp_path,1,A(),c)
    names=[n for n,_ in hs]
    assert 'inv(MrMr) × CtMr' in names
    assert any(np.asarray(m).shape==(4,4) for _,m in hs)
