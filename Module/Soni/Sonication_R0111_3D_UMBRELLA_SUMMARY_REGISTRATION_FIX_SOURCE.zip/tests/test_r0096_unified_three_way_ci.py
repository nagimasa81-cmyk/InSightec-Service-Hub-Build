
from pathlib import Path
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_upper_ci_image_area_removed():
    build=MAIN.split("def _build_cavitation_intelligence_tab",1)[1].split("def _ci_linked_mode_changed",1)[0]
    assert "ci_image_view_combo" not in build
    assert "ci_image_stack" not in build
    assert "R0095: one image viewport only" not in build

def test_lower_selector_has_three_choices_and_defaults_cga():
    build=MAIN.split("def _build_cavitation_intelligence_tab",1)[1].split("def _ci_linked_mode_changed",1)[0]
    linked=build.split("self.ci_linked_mode.addItems([",1)[1].split("])",1)[0]
    assert "RCV Contribution + probable cavitation region" in linked
    assert "Vendor band energy reproduction" in linked
    assert "Cavitation control response + CGA / Acquisition Display Rule" in linked
    assert "self.ci_linked_mode.setCurrentIndex(2)" in build

def test_rcv_and_probable_are_side_by_side():
    build=MAIN.split("def _build_cavitation_intelligence_tab",1)[1].split("def _ci_linked_mode_changed",1)[0]
    assert "rcv_l = QHBoxLayout(rcv_page)" in build
    assert 'QLabel("RCV contribution")' in build
    assert 'QLabel("Probable cavitation region")' in build
    assert "ci_linked_rcv_plot" in build
    assert "ci_linked_probable_plot" in build

def test_three_way_switch_remains_lightweight():
    block=MAIN.split("def _ci_linked_mode_changed",1)[1].split("def _ci_event_time",1)[0]
    assert "_update_ci_linked_panel()" not in block
    assert "min(2, int(index))" in block
