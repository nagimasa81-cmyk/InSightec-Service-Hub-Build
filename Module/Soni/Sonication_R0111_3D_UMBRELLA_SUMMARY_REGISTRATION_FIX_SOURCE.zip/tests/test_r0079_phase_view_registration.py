from pathlib import Path
import numpy as np
from src.services.sonication_log_receiver_service import SonicationLogReceiverService
from src.services.registration_overlay_service import RegistrationOverlayService


def _skull_row(ch, total_phase_deg):
    vals=[0.0]*47
    vals[0]=float(ch); vals[1]=1.0; vals[5]=float(total_phase_deg)
    return ' '.join(str(x) for x in vals)


def test_sonication_phase_uses_skullmeasures_and_logical_anchor(tmp_path: Path):
    log=tmp_path/'Sonication_Brain_test.txt'
    # Base Skull phase CH0=0°, CH1=90°. Observed logical adds a common +30°.
    log.write_text('''12:00:00.000 CLoadSonicationData fields:\nNumber Of Channels <1024>\nChannel <0>\nLogical Amplitude <1>\nLogical Phase <0.5235987756>\nChannel <1>\nLogical Amplitude <1>\nLogical Phase <2.0943951024>\n''',encoding='utf-8')
    skull=tmp_path/'SkullMeasures_sonic1_cue1.log'
    skull.write_text(_skull_row(0,0)+'\n'+_skull_row(1,90)+'\n'+_skull_row(2,180)+'\n',encoding='utf-8')
    snaps=SonicationLogReceiverService().read_snapshots(tmp_path,sonication_number=1)
    assert snaps
    by={v.channel:v for v in snaps[0].values}
    assert np.isclose(by[0].sonication_phase_rad,np.deg2rad(30),atol=1e-5)
    assert np.isclose(by[1].sonication_phase_rad,np.deg2rad(120),atol=1e-5)
    assert np.isclose(abs(by[2].sonication_phase_rad),np.deg2rad(150),atol=1e-5)
    assert 'Logical common-phase anchor' in by[0].sonication_phase_method


def test_outer_shell_metric_penalizes_inward_contour():
    yy,xx=np.mgrid[0:256,0:256]
    rr=np.hypot(xx-128,yy-128)
    mr=np.zeros((256,256),float)
    mr[rr<95]=100.0
    good=np.full((256,256),np.nan,float); good[(rr>90)&(rr<94)]=1.0
    bad=np.full((256,256),np.nan,float); bad[(rr>68)&(rr<72)]=1.0
    svc=RegistrationOverlayService()
    rg,bg,cg=svc._outer_shell_metrics(mr,good)
    rb,bb,cb=svc._outer_shell_metrics(mr,bad)
    assert rg < rb
    assert bg > bb
    assert cg > 0.5 and cb > 0.5


def test_view_state_is_separated_in_source():
    text=(Path(__file__).parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert '_planning_overlay_view' in text
    assert 'Planning/Registration and Replay keep independent ViewBox ranges' in text
    assert 'Sonication Phase (1024 reconstructed)' in text
    assert 'Channel Calibration Phase (1024)' in text
