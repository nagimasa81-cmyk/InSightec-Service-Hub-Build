
from pathlib import Path
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_thermal_checkbox_default_off():
    assert 'QCheckBox("Show Thermal Images")' in MAIN
    assert 'self.show_thermal_images_check.setChecked(False)' in MAIN
    assert 'widget.setVisible(False)' in MAIN

def test_background_worker_is_used():
    assert 'class ThermalThumbnailWorker(QObject)' in MAIN
    assert 'worker.moveToThread(thread)' in MAIN
    assert 'thread.started.connect(worker.run)' in MAIN

def test_navigator_does_not_decode_all_thermal_synchronously():
    b=MAIN.split('def _build_frame_navigator',1)[1].split('def _rebuild_all_image_strips',1)[0]
    assert 'for row, frame in enumerate(self.current.temperature_frames)' not in b
    assert '_start_thermal_thumbnail_background()' in b

def test_strip_rebuild_uses_cache_not_raw_io():
    b=MAIN.split('def _all_image_entries',1)[1].split('def _rebuild_all_image_strips',1)[0]
    thermal=b.split('R0106: thumbnail rebuilds',1)[1]
    assert 'read_temperature' not in thermal
    assert '_thermal_thumbnail_cache' in thermal

def test_hidden_thermal_row_does_not_populate_items():
    b=MAIN.split('def _rebuild_all_image_strips',1)[1].split('def _planning_reference_type_changed',1)[0]
    assert 'role == "thermal"' in b
    assert 'not self.show_thermal_images_check.isChecked()' in b
