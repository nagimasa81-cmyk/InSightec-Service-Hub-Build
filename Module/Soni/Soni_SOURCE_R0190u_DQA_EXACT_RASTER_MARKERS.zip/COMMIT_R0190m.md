# R0190m — DQA phantom physical-reference hardening

- Sagittal AP phantom reference now comes from the detected phantom physical AP extent; raster/image centre is forbidden as a DQA reference.
- Axial same-raster candidate cannot override cross-slice consensus when it is identified as an internal-edge outlier.
- No expected RL/AP/SI values, fixture IDs, or numeric clipping are used.
- R0190l chart double-click RESET hardening is preserved.
