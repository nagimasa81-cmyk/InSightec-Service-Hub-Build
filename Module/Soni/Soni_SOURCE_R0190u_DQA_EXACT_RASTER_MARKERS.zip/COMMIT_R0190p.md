# R0190p — DQA observed-focus estimator audit

- Adds an independent sub-pixel quadratic local-peak estimate beside the authoritative masked thermometry weighted centroid.
- Records centroid vs quadratic-peak pixels/RAS and separation in DQA diagnostic overlays.
- Does not calibrate Phantom reference or focus coordinates to expected 4267 values.
- Preserves R0190n/o physical phantom-reference and chart double-click RESET hardening.
