from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
I=(ROOT/'src/ui/image_panel.py').read_text(encoding='utf-8')
M=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')

def test_distance_signal_keeps_measurement_entry_not_emitted_roi():
    assert 'lambda *_args, e=entry: self._distance_changed(e)' in I
    assert 'lambda *_args, e=entry: self._select_distance_measurement(e)' in I
    assert 'lambda e=entry: self._distance_changed(e)' not in I

def test_distance_uses_axis_specific_physical_spacing():
    assert 'self._mm_per_pixel_x' in I and 'self._mm_per_pixel_y' in I
    assert 'np.hypot(dx*sx,dy*sy)' in I
    assert 'def _current_pixel_spacing_xy_mm' in M
    assert 'self.overlay.set_pixel_spacing(_sx,_sy)' in M

def test_each_distance_has_own_label_and_result():
    assert 'entry={"line":line,"label":label,"result":None}' in I
    assert 'entry["result"]=r' in I
    assert 'prefix=f"D{r[\'index\']} "' in I
