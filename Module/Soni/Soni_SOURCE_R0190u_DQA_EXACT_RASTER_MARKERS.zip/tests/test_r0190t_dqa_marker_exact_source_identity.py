from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_overlay_cache_is_keyed_by_sonication_and_frame():
    s=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text()
    assert 'source_sonication_number' in s
    assert '::' in s
    assert "diagnostic_overlays[str(axial.get('frame') or '')]" not in s
    assert "diagnostic_overlays[str(sagittal.get('frame') or '')]" not in s

def test_replay_lookup_cannot_cross_sonication_on_repeated_basename():
    s=(ROOT/'src/ui/main_window.py').read_text()
    assert 'overlay_key=f"S{son_no}::{frame_name}"' in s
    assert "get(frame_name)" not in s[s.find('R0190t: frame basenames'):s.find('R0190t: frame basenames')+900]
    assert "source_sonication_number" in s

def test_target_is_available_in_both_dqa_orientations():
    s=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text()
    assert s.count("'planned_pixel':display_planned") >= 2
    assert s.count("_project_ras_to_exact_row_pixel") >= 5
    assert s.count("'planned_ras': None if planned is None") >= 2
