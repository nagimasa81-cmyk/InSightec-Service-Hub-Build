import numpy as np
from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService

def _bar_image(top=118,bottom=125):
    a=np.zeros((256,256),dtype=np.uint16)
    a[top:bottom,70:186]=50000
    return a

def test_baseline_pair_recovers_two_edges():
    edges=DqaFocusAlignmentService._baseline_edge_pair(_bar_image())
    assert len(edges)==2
    ys=sorted(e[0]*128+e[1] for e in edges)
    assert ys[1]-ys[0] > 3

def test_si_contract_is_physical_ras_not_pixel_top():
    import inspect
    src=inspect.getsource(DqaFocusAlignmentService._dqa_reference_geometry)
    assert 'max(edge_phys,key=lambda q:q[0])' in src
    assert 'physically SUPERIOR edge' in src
    assert 'Pixel-up is not reliably' in src
