from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
M=(ROOT/"src/ui/main_window.py").read_text(encoding="utf-8")
I=(ROOT/"src/ui/image_panel.py").read_text(encoding="utf-8")

def test_observed_vs_target_is_per_sonication_not_spanned():
    assert "table.setSpan(0,18,rows,1)" not in M
    assert "dqa_focus_alignment_service.analyze(self.package,r)" in M
    assert "table.setItem(r,18,cell)" in M

def test_distance_is_additive_and_view_centered():
    assert "self._distance_measurements = []" in I
    assert "self.view.plotItem.vb.viewRange()" in I
    assert "self._distance_measurements.append(entry)" in I

def test_clear_removes_only_selected_distance():
    assert "entry=self._active_distance_measurement" in I
    assert "self._distance_measurements.remove(entry)" in I
    assert "for item in self._distance_measurements" in I
