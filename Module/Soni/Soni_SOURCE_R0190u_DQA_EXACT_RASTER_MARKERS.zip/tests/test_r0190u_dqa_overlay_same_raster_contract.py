from pathlib import Path
import numpy as np
from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService


def row(origin=(0,0,0), sx=2.0, sy=3.0):
    return {
        'topleftcoordr':origin[0],'topleftcoorda':origin[1],'topleftcoords':origin[2],
        'rowdirectcosrasx':0,'rowdirectcosrasy':1,'rowdirectcosrasz':0,
        'coldirectcosrasx':1,'coldirectcosrasy':0,'coldirectcosrasz':0,
        'pixsizex':sx,'pixsizey':sy,
    }


def test_exact_row_projection_changes_when_raster_origin_changes():
    p=np.array([20.0,30.0,0.0])
    assert DqaFocusAlignmentService._project_ras_to_exact_row_pixel(row(),p)==(10.0,10.0)
    assert DqaFocusAlignmentService._project_ras_to_exact_row_pixel(row((4.0,6.0,0.0)),p)==(8.0,8.0)


def test_overlay_payload_uses_thermal_hotspot_and_reprojects_physical_points():
    s=Path('src/services/dqa_focus_alignment_service.py').read_text(encoding='utf-8')
    assert "display_focus=(float(axial['hotspot_pixel'][0]),float(axial['hotspot_pixel'][1]))" in s
    assert "display_circle=self._project_ras_to_exact_row_pixel(axial['row'],circle)" in s
    assert "display_planned=None if planned is None else self._project_ras_to_exact_row_pixel(axial['row'],planned)" in s
    assert "display_focus=(float(sagittal['hotspot_pixel'][0]),float(sagittal['hotspot_pixel'][1]))" in s
    assert "display_baseline=self._project_ras_to_exact_row_pixel(sagittal['row'],baseline)" in s
    assert "display_reference=self._project_ras_to_exact_row_pixel(sagittal['row'],ref_plane)" in s
    assert "'calculator_focus_pixel'" in s
