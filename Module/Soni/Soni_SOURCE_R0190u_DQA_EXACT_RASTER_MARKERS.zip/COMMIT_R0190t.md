# R0190t — DQA marker exact-source identity hardening

- Fixes a cross-Sonication marker overlay defect: thermal RAW basenames can repeat in different Sonication folders, while the old diagnostic overlay cache was keyed by basename only.
- DQA diagnostic overlays are now keyed by Sonication number + thermal frame basename and carry explicit source_sonication_number/source_frame provenance.
- Replay draws Observed focus / Sonication target center / Phantom reference only when both Sonication and exact source thermal raster match the DQA payload. It fails closed otherwise.
- Adds planned target marker payload for Sagittal as well as Axial.
- Does not change DQA numeric alignment definitions or Distance geometry.
