# R0190u — DQA overlay exact-raster coordinate hardening

- Calculator geometry remains unchanged.
- Observed focus display uses the exact thermal hotspot pixel.
- Phantom reference, lower-line reference and Sonication target are projected from physical RAS into the exact thermal source raster before drawing.
- Reference-raster calculator pixels are retained only as calculator_* audit fields and are never rendered on the thermal raster.
- Sonication + frame exact-source identity gate from R0190t remains mandatory.
- Final X/Y/Z/Tilt values are copied into each overlay payload only after series resolution, preventing stale/NaN overlay labels.
- Version metadata is RC7.10-R0190u / 7.10.0.195.
