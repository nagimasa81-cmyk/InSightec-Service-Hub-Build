from __future__ import annotations

from dataclasses import dataclass
from types import SimpleNamespace
from typing import Iterable


@dataclass(frozen=True)
class CanonicalCavitationEvidence:
    detected: bool | None
    observed_events: tuple
    vendor_rule_events: tuple
    candidate_events: tuple
    status: str
    evidence_complete: bool = True
    unavailable_reason: str | None = None

    @property
    def vendor_exceedance_severity(self) -> float | None:
        """Transparent 0–100 threshold-exceedance score for vendor Rule Triggers.

        score = 100 * (1 - threshold / measured), so a just-crossed threshold is
        near 0, 2× threshold is 50, and stronger exceedance approaches 100.
        This is an engineering evidence score, not a clinical cavitation grade.
        """
        scores=[]
        for ev in self.vendor_rule_events:
            try:
                measured=float(getattr(ev,"energy",float("nan")))
                threshold=float(getattr(ev,"baseline",float("nan")))
                if measured>threshold>0:
                    scores.append(max(0.0,min(100.0,100.0*(1.0-threshold/measured))))
            except Exception:
                continue
        return max(scores) if scores else None

    @property
    def rca_events(self) -> tuple:
        """Events normalized for the existing RCA event-strength contract."""
        rows = list(self.observed_events)
        for ev in self.vendor_rule_events:
            rule = str(getattr(ev, "rule", "") or "")
            family = "Dynamic"
            for candidate in ("Decrease", "Safety", "Dynamic"):
                if rule.lower().startswith(candidate.lower()):
                    family = candidate
                    break
            rows.append(SimpleNamespace(
                family=family,
                result="CAVITATION · Vendor Rule Trigger",
                weighted_energy=getattr(ev, "energy", None),
                threshold=getattr(ev, "baseline", None),
                critical_threshold=None,
                counts_as_cavitation=True,
                source="Spectrum Dump Analyzer vendor-rule reproduction",
            ))
        return tuple(rows)


class CanonicalCavitationEvidenceService:
    """One detection contract shared by Replay, CI and Sonication Summary.

    Confirmed cavitation is either an observed control event explicitly classified
    as cavitation, or a reproduced vendor INI Rule Trigger from the same decoded
    Spectrum dump. Dump-only robust-z candidates remain warnings and never promote
    the Summary to confirmed cavitation.
    """

    @staticmethod
    def combine(
        timeline_events: Iterable | None = None,
        standalone_analysis=None,
        *,
        timeline_available: bool = True,
        spectrum_available: bool = True,
        unavailable_reason: str | None = None,
    ) -> CanonicalCavitationEvidence:
        observed=[]
        for ev in list(timeline_events or []):
            family=str(getattr(ev,"family","") or "")
            if family.lower()=="increase":
                continue
            counts=getattr(ev,"counts_as_cavitation",None)
            if counts is True:
                observed.append(ev)
                continue
            # Legacy event objects can lack the explicit flag. Only then use the
            # historical Decrease/Safety fallback; a present False is respected.
            if counts is None and family in {"Decrease","Safety"}:
                observed.append(ev)

        rule=[]; candidates=[]
        for ev in list(getattr(standalone_analysis,"events",[]) or []):
            severity=str(getattr(ev,"severity","") or "")
            if severity=="Rule Trigger": rule.append(ev)
            elif severity=="Candidate": candidates.append(ev)

        confirmed=bool(observed or rule)
        complete=bool(timeline_available and spectrum_available)
        detected = True if confirmed else (False if complete else None)
        parts=[]
        if observed: parts.append(f"Observed control cavitation ×{len(observed)}")
        if rule: parts.append(f"Vendor rule trigger ×{len(rule)}")
        if not confirmed:
            if complete:
                parts.append("No confirmed cavitation")
            else:
                parts.append("Evidence incomplete — Needs attention")
            if candidates: parts.append(f"dump candidate ×{len(candidates)}")
        return CanonicalCavitationEvidence(
            detected=detected,
            observed_events=tuple(observed),
            vendor_rule_events=tuple(rule),
            candidate_events=tuple(candidates),
            status=" · ".join(parts),
            evidence_complete=complete,
            unavailable_reason=(None if complete else (unavailable_reason or "One or more cavitation evidence sources were unavailable")),
        )
