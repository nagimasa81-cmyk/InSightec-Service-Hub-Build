# R0127 — Direct mouse FFT range selection repair

- Fixes R0126 range-selection regression caused by `plot.clear()` deleting the active `LinearRegionItem` during replay/data redraw.
- FFT range selection mode now accepts a left-button drag anywhere in the Measurement Timeline / Raw A/D chart to define Start/End directly.
- Normal pyqtgraph pan/zoom is disabled only while range-selection mode is ON and restored when OFF.
- Selection overlay survives data redraws and can still be fine-tuned by dragging the region or either edge.
- `FFT + Band0 selected range` enables only after a non-zero interval is selected.
- R0126 CPC-history temporal FFT + Band0 analysis behavior is preserved.
