from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_ci_vendor_band_duplicate_is_not_user_selectable():
    text=(ROOT/'src/ui/main_window.py').read_text()
    block=text.split('self.ci_linked_mode.addItems([',1)[1].split('])',1)[0]
    assert 'Vendor band energy reproduction' not in block
    assert 'RCV Contribution + probable cavitation region' in block
    assert 'Cavitation control response + CGA / Acquisition Display Rule' in block

def test_dqa_z_reference_is_lower_line_plus_20mm():
    text=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text()
    block=text.split('def analyze_series',1)[1].split('def clear_cache',1)[0]
    assert 'ref_ras[2]+=20.0' in block
    assert '_observed_dqa_focus_by_orientation' in block

def test_ci_vendor_band_duplicate_is_not_recomputed_in_refresh():
    text=(ROOT/'src/ui/main_window.py').read_text()
    block=text.split('def _update_ci_linked_panel',1)[1].split('def _apply_ci_screen_fit',1)[0]
    assert '_draw_ci_linked_vendor_energy(replay)' not in block
    assert '_draw_ci_linked_control(replay)' in block
