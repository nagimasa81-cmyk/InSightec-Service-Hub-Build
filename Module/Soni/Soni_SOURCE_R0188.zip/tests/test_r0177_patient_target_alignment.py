from pathlib import Path

from src.services.transducer_location_service import TransducerLocationService


def _write(tmp_path: Path, protocol: str, xyz: str):
    ws=tmp_path/'WSFiles'; ws.mkdir()
    text = (
        f"10:00:00:000 Inf Dbg x protocol data - name: {protocol}, Planer type: Brain\n"
        "10:00:01:000 Inf Dbg x Home position read from section [PatientInfo]. UVW = (10.000000, 20.000000, 30.000000), Transducer Direction: UVW = (0,0,-1)\n"
        "10:00:10:000 Inf Srv x TRACKERS SELECTION: Xd location was decoded from the trackers with high reliability\n"
        f"10:00:10:001 Inf Dbg x New XD pos. in CSA coords. according to trackers - X: {xyz.split(', ')[0]}, Y: {xyz.split(', ')[1]}, Z: {xyz.split(', ')[2]}, Roll: 0, Pitch: 0\n"
        "10:00:10:001 Ent Dbg x [CGeneralSonicationLogic::CompareTrackerAndCalibXd]\n"
    )
    (ws/'2026_Sep_05_10_00_00.Log').write_text(text, encoding='utf-8')


def test_patient_treatment_reconstructs_target_transducer_and_axis_pass(tmp_path: Path):
    _write(tmp_path, 'Brain-Treatment', '0.250000, -0.500000, 0.999000')
    r=TransducerLocationService().parse(tmp_path)[0]
    assert r.patient_target_xyz == (10.0,20.0,30.0)  # calibration reference evidence only
    assert r.patient_delta_xyz == (0.25,-0.5,0.999)
    assert r.patient_transducer_xyz is None  # R0180: no global absolute reconstruction from tracker residual
    assert r.patient_axis_pass == (True,True,True)
    assert r.patient_alignment_pass is True


def test_one_mm_exactly_is_fail(tmp_path: Path):
    _write(tmp_path, 'Brain-Treatment', '1.000000, 0.000000, 0.000000')
    r=TransducerLocationService().parse(tmp_path)[0]
    assert r.patient_axis_pass == (False,True,True)
    assert r.patient_alignment_pass is False


def test_dqa_is_excluded_from_patient_alignment(tmp_path: Path):
    _write(tmp_path, 'Brain-DQA', '0.100000, 0.100000, 0.100000')
    r=TransducerLocationService().parse(tmp_path)[0]
    assert r.patient_target_xyz is None
    assert r.patient_transducer_xyz is None
    assert r.patient_delta_xyz is None
    assert r.patient_axis_pass is None
    assert r.patient_alignment_pass is None
