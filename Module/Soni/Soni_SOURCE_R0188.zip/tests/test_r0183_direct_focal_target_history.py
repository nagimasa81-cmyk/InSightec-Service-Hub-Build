from pathlib import Path
from src.services.transducer_location_service import TransducerLocationService


def _write_summary(root: Path, protocol: str, start: str):
    (root / 'SonicationSummary.xml').write_text(
        f'<root><z:row xmlns:z="urn:schemas-microsoft-com:rowset" treatprotocol="{protocol}" treattime="{start}" '
        'focalrasx="11.1" focalrasy="7.5" focalrasz="14" /></root>',
        encoding='utf-8',
    )


def test_treatment_uses_same_block_pos_and_focal_and_filters_pre_session(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir(); _write_summary(tmp_path,'Brain-Treat','10:10:48')
    (ws/'2026_Sep_04_07_58_39.Log').write_text('''
08:19:20:592 Inf Dbg 1 New home position: (0.4, -31.0, 147.5) New XD tilt: (0.0, 0.02, -1.0)
08:19:20:596 Inf Dbg 1 focal position: L0.4 A28.6 I2.5
10:14:05:708 Inf Dbg 1 New home position: (-13.8, 13.8, 157.9) New XD tilt: (0.0, -0.17, -0.98)
10:14:05:712 Inf Dbg 1 focal position: R13.8 A12.4 S10.2
10:45:31:093 Inf Dbg 1 New home position: (-10.4, 19.2, 154.2) New XD tilt: (0.0, -0.17, -0.98)
10:45:31:097 Inf Dbg 1 Pos = 11.1,7.5,14
10:45:31:098 Inf Dbg 1 focal position: R10.2 A7.2 S6.5
10:51:33:399 Inf Dbg 1 New home position: (-10.3, 18.9, 160.7) New XD tilt: (0.0, -0.17, -0.98)
10:51:33:400 Inf Dbg 1 Pos = 11.1,7.5,14
10:51:33:401 Inf Dbg 1 focal position: R10.1 A7.3 S13.0
11:01:15:753 Inf Dbg 1 New home position: (-11.4, 18.8, 160.8) New XD tilt: (0.0, -0.17, -0.98)
11:01:15:754 Inf Dbg 1 Pos = 11.1,7.5,14
11:01:15:755 Inf Dbg 1 focal position: R11.3 A7.3 S13.1
''',encoding='utf-8')
    svc=TransducerLocationService()
    locs=svc.locate_focal_history(tmp_path)
    assert [round(q.clock_s,3) for q in locs] == [36845.708,38731.093,39093.399,39675.753]
    assert locs[0].target_xyz is None and locs[0].focal_xyz == (13.8,12.4,10.2)
    assert locs[1].target_xyz == (11.1,7.5,14.0)
    assert locs[1].focal_xyz == (10.2,7.2,6.5)
    rows=svc.patient_alignment_workflow(tmp_path)
    physical=[r for r in rows if r.change_mode in ('Initial physical Locate','Physical re-Locate')]
    assert len(physical)==4
    assert physical[1].delta_xyz == (-0.9000000000000004,-0.2999999999999998,-7.5)
    assert physical[1].overall_pass is False
    assert all(abs(a-b)<1e-9 for a,b in zip(physical[-1].delta_xyz,(0.2,-0.2,-0.9)))
    assert physical[-1].overall_pass is True


def test_dqa_lists_each_focal_and_never_applies_target_delta(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir(); _write_summary(tmp_path,'Brain-DQA','20:05:30')
    (ws/'2026_Sep_04_20_00_00.Log').write_text('''
20:04:00:000 Inf Dbg 1 New home position: (-9,9,159) New XD tilt: (0,0,-1)
20:04:00:001 Inf Dbg 1 focal position: R9.0 A9.0 S9.0
20:34:00:030 Inf Dbg 1 protocol data - name: Brain-DQA
20:34:00:034 Inf Dbg 1 New home position: (-2.9, 18.2, 151.7) New XD tilt: (0,0,-1)
20:34:00:035 Inf Dbg 1 Pos = 99,99,99
20:34:00:036 Inf Dbg 1 focal position: R2.9 A18.2 S1.7
20:38:09:313 Inf Dbg 1 New home position: (-2.8, 18.3, 150.3) New XD tilt: (0,0,-1)
20:38:09:314 Inf Dbg 1 Pos = 88,88,88
20:38:09:315 Inf Dbg 1 focal position: R2.8 A18.3 S0.3
20:39:54:770 Inf Dbg 1 New home position: (-2.7, 18.4, 146.9) New XD tilt: (0,0,-1)
20:39:54:771 Inf Dbg 1 focal position: R2.7 A18.4 I3.1
''',encoding='utf-8')
    svc=TransducerLocationService()
    locs=svc.locate_focal_history(tmp_path)
    assert [q.focal_xyz for q in locs] == [(2.9,18.2,1.7),(2.8,18.3,0.3),(2.7,18.4,-3.1)]
    assert all(q.target_xyz is None for q in locs)
    rows=svc.patient_alignment_workflow(tmp_path)
    assert len(rows)==3
    assert all(r.change_mode=='DQA Locate' for r in rows)
    assert all(r.target_xyz is None and r.delta_xyz is None and r.overall_pass is None for r in rows)


def test_target_change_opens_new_epoch_and_steering_does_not_create_locate(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir(); _write_summary(tmp_path,'Brain-Treat','10:10:48')
    (ws/'2026_Sep_04_07_58_39.Log').write_text('''
10:45:31:093 Inf Dbg 1 New home position: (-10, 10, 150) New XD tilt: (0,0,-1)
10:45:31:097 Inf Dbg 1 Pos = 11.1,7.5,14
10:45:31:098 Inf Dbg 1 focal position: R11.2 A7.4 S13.5
11:20:00:000 Ent Dbg 1 [CGeneralSonicationLogic::StartSonicate] Sonication Counter:3
11:20:00:001 Inf Dbg 1 cpFocalPointUVW: (-10.6558, -8.34335, 14.0259)
11:30:00:000 Inf Dbg 1 New home position: (-15, 15, 150) New XD tilt: (0,0,-1)
11:30:00:001 Inf Dbg 1 Pos = 15,8,14
11:30:00:002 Inf Dbg 1 focal position: R15.1 A8.2 S13.8
''',encoding='utf-8')
    rows=TransducerLocationService().patient_alignment_workflow(tmp_path)
    loc=[r for r in rows if r.change_mode=='Physical re-Locate']
    assert [r.target_epoch for r in loc] == [1,2]
    steering=[r for r in rows if r.change_mode=='Electronic steering']
    assert len(steering)==1
    assert steering[0].target_epoch==1
    assert steering[0].effective_target_xyz==(10.6558,8.34335,14.0259)
