from pathlib import Path
import numpy as np
from src.services.transducer_location_service import TransducerLocationService

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')


def test_umbrella_family_contract_is_explicit_and_single_ingress_transform():
    block=MAIN[MAIN.index('def _umbrella_z_sign'):MAIN.index('def _named_projection')]
    assert '180000.0 <= hz <= 320000.0' in block
    assert '550000.0 <= hz <= 750000.0' in block
    assert 'return -1.0' in block
    assert 'return +1.0' in block
    assert 'q[:,2]*=self._umbrella_z_sign()' in block
    assert 'q[:,2]*=-1.0' not in block


def test_initial_treatment_locate_backbinds_first_target(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir()
    (ws/'2026_Sep_04.Log').write_text(
        '10:10:48:000 Inf Dbg 1 Protocol data - name: Brain-Treat\n'
        '10:14:04:900 Inf Dbg 1 New home position: (0,0,0), New XD tilt: (0,0,1)\n'
        '10:14:05:708 Inf Dbg 1 focal position: R13.8 A12.4 S10.2\n'
        '10:45:30:900 Inf Dbg 1 New home position: (0,0,0), New XD tilt: (0,0,1)\n'
        '10:45:31:000 Inf Dbg 1 Pos = 11.1,7.5,14\n'
        '10:45:31:093 Inf Dbg 1 focal position: R10.2 A7.2 S6.5\n'
    )
    rows=TransducerLocationService().patient_alignment_workflow(tmp_path)
    assert len(rows) >= 2
    first=rows[0]
    assert first.change_mode == 'Initial physical Locate'
    assert first.target_xyz == (11.1,7.5,14.0)
    assert first.transducer_xyz == (13.8,12.4,10.2)
    np.testing.assert_allclose(first.delta_xyz,(2.7,4.9,-3.8),atol=1e-9)
    assert first.overall_pass is False
