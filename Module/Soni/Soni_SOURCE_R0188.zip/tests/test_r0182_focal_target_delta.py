from pathlib import Path
from src.services.transducer_location_service import TransducerLocationService

LOG = """08:00:00:000 Inf Dbg 1 Protocol data - name: Brain Treatment
08:00:01:000 Inf Dbg 1 Home position read from section [PatientInfo]. UVW = (0.0, 0.0, 150.0), Transducer Direction: UVW = (0.0, 0.0, -1.0)
08:00:02:000 Inf Dbg 1 focal position: L0.0 A0.0 S0.0
08:01:00:000 Inf Dbg 1 Set new home position: orig: 0.0 0.0 0.5 xDir: 1 0 0 yDir: 0 1 0 zDir: 0 0 1
08:01:10:000 Inf Dbg 1 Locate Transducer
08:01:11:000 Inf Dbg 1 New home position: (0.2, -0.3, 150.4), New XD tilt: (0.0, 0.0, -1.0)
08:01:11:500 Inf Dbg 1 Pos = -0.2,-0.3,0.5
08:01:12:000 Inf Dbg 1 focal position: L0.2 P0.3 S0.4
08:01:13:000 Inf Dbg 1 New XD pos. in CSA coords. according to trackers - X: 0.01, Y: 0.02, Z: -0.03
"""

def test_manual_locate_uses_absolute_focal_minus_target(tmp_path: Path):
    ws=tmp_path/"WSFiles"; ws.mkdir()
    (ws/"2026_Sep_05.Log").write_text(LOG)
    rows=TransducerLocationService().patient_alignment_workflow(tmp_path)
    loc=[r for r in rows if r.change_mode=="Physical re-Locate"][0]
    assert all(abs(a-b)<1e-6 for a,b in zip(loc.transducer_xyz,(-0.2,-0.3,0.4)))
    assert loc.target_xyz == (-0.2,-0.3,0.5)
    assert all(abs(a-b)<1e-6 for a,b in zip(loc.delta_xyz,(0.0,0.0,-0.1)))
    assert loc.overall_pass is True
