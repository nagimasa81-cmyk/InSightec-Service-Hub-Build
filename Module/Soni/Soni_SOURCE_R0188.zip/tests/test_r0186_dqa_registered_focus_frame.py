from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_dqa_never_subtracts_locate_or_planned_focal_directly_from_phantom_reference():
    text=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text()
    block=text.split('def analyze_series',1)[1].split('def clear_cache',1)[0]
    assert 'locate_focal[0]' not in block
    assert 'registered_focal[0]-ref_xyz[0]' not in block
    assert '_observed_dqa_focus_by_orientation' in block

def test_dqa_reports_sagittal_lowerline_crosscheck_before_plus20_reference():
    text=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text()
    block=text.split('def analyze_series',1)[1].split('def clear_cache',1)[0]
    assert 'baseline_to_focal' in block
    assert 'lower-line→focus' in block
    assert 'ref_ras[2]+=20.0' in block
