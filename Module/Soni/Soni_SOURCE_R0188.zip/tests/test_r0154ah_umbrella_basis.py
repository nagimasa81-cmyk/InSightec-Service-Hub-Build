from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')


def test_brain220_and_brain650_have_explicit_opposite_native_z_contract():
    block=MAIN[MAIN.index('def _umbrella_z_sign'):MAIN.index('def _canonical_umbrella_points')]
    assert '180000.0 <= hz <= 320000.0' in block
    assert '550000.0 <= hz <= 750000.0' in block
    # Brain220 is the validated reference and keeps historical inversion.
    assert 'if 180000.0 <= hz <= 320000.0:\n                return -1.0' in block
    # Brain650 must not receive the Brain220 inversion.
    assert 'if 550000.0 <= hz <= 750000.0:\n                return +1.0' in block
