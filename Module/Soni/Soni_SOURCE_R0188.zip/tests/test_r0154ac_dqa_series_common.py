from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_series_common_r0188_is_observed_focus_same_raster_contract():
    text=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text()
    block=text.split('def analyze_series',1)[1].split('def clear_cache',1)[0]
    assert '_observed_dqa_focus_by_orientation' in block
    assert "reference.get('axial_candidates'" in block
    assert "reference.get('sagittal_candidates'" in block
    assert 'ref_ras[2]+=20.0' in block
    assert '_series_fixed_focus_ras' not in block

def test_series_common_no_longer_requires_locate_coordinates_for_numeric_subtraction():
    text=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text()
    block=text.split('def analyze_series',1)[1].split('def clear_cache',1)[0]
    assert '_dqa_common_locate_focal_ras' in block
    assert 'locate_focal[0]' not in block
    assert 'hotspot_ras' in block
