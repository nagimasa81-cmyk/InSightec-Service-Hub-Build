from pathlib import Path
from src.services.transducer_location_service import TransducerLocationService

LOG = """08:00:00:000 Inf Dbg 1 Protocol data - name: Brain Treatment
08:01:20:000 Inf Dbg 1 Locate Transducer
08:01:25:000 Inf Dbg 1 New XD pos. in CSA coords. according to trackers - X: 0.2, Y: -0.1, Z: 0.3
08:01:25:001 Inf Dbg 1 New home position: (-1.1,-2.0,159.2) New XD tilt: (0,0,-1)
08:01:25:002 Inf Dbg 1 Pos = 1.0,2.0,9.0
08:01:25:003 Inf Dbg 1 focal position: R1.1 A2.0 S9.2
08:02:50:000 Inf Dbg 1 New XD pos. in CSA coords. according to trackers - X: 0.21, Y: -0.11, Z: 0.31
08:03:00:000 Inf Dbg 1 [CGeneralSonicationLogic::StartSonicate] Sonication Counter: 0
08:03:00:001 Inf Dbg 1 Steering: 1.0 2.0 9.0
"""

def test_manual_locate_and_pre_sonication_verification_are_separate(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir(); (ws/'2026_Sep_05.Log').write_text(LOG)
    svc=TransducerLocationService(); recs=svc.parse(tmp_path)
    assert [r.localization_kind for r in recs] == ['manual-locate','pre-sonication-verification']
    rows=svc.patient_alignment_workflow(tmp_path)
    loc=[r for r in rows if r.change_mode=='Physical re-Locate']
    assert len(loc)==1
    assert loc[0].target_xyz==(1.0,2.0,9.0)
    assert loc[0].transducer_xyz==(1.1,2.0,9.2)
    assert loc[0].overall_pass is True
    assert not any(r.clock_s == 8*3600+2*60+50 for r in rows)

def test_automatic_tracker_scan_never_becomes_physical_move(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir(); text=LOG.replace('08:01:20:000 Inf Dbg 1 Locate Transducer\n','')
    (ws/'2026_Sep_05.Log').write_text(text)
    rows=TransducerLocationService().patient_alignment_workflow(tmp_path)
    # The focal display row is still a physical focal record; the automatic residual alone creates no second Locate.
    assert len([r for r in rows if r.change_mode=='Physical re-Locate'])==1
