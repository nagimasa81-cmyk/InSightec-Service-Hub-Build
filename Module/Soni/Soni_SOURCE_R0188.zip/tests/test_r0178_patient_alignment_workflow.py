from pathlib import Path
from src.services.transducer_location_service import TransducerLocationService

LOG = """08:00:00:000 Inf Dbg 1 Protocol data - name: Brain Treatment
08:01:00:000 Inf Dbg 1 New home position: (-11.0, -20.0, 180.0) New XD tilt: (0,0,-1)
08:01:00:001 Inf Dbg 1 Pos = 11.0,20.0,30.0
08:01:00:002 Inf Dbg 1 focal position: R13.0 A18.5 S30.5
08:02:00:000 Inf Dbg 1 New home position: (-11.0, -20.0, 180.0) New XD tilt: (0,0,-1)
08:02:00:001 Inf Dbg 1 Pos = 11.0,20.0,30.0
08:02:00:002 Inf Dbg 1 focal position: R11.9 A19.2 S30.7
08:03:00:000 Inf Dbg 1 New home position: (-11.0, -20.0, 180.0) New XD tilt: (0,0,-1)
08:03:00:001 Inf Dbg 1 Pos = 11.0,20.0,30.0
08:03:00:002 Inf Dbg 1 focal position: R11.4 A19.8 S30.3
"""

def test_patient_workflow_preserves_repeat_after_pass(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir(); (ws/'2026_Sep_05.Log').write_text(LOG)
    rows=TransducerLocationService().patient_alignment_workflow(tmp_path)
    loc=[r for r in rows if r.change_mode=='Physical re-Locate']
    assert len(loc)==3
    assert loc[0].overall_pass is False
    assert loc[1].overall_pass is True
    assert loc[2].overall_pass is True  # repeat Locate remains visible after PASS

def test_dqa_creates_focal_only_workflow(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir(); (ws/'2026_Sep_05.Log').write_text(LOG.replace('Brain Treatment','Brain DQA'))
    rows=TransducerLocationService().patient_alignment_workflow(tmp_path)
    assert len(rows)==3
    assert all(r.change_mode=='DQA Locate' for r in rows)
    assert all(r.target_xyz is None and r.delta_xyz is None for r in rows)
