from pathlib import Path
import numpy as np
from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')


def test_umbrella_z_is_not_double_inverted():
    block=MAIN[MAIN.index('def _named_projection'):MAIN.index('def _umbrella_project', MAIN.index('def _named_projection'))]
    canonical=MAIN[MAIN.index('def _canonical_umbrella_points'):MAIN.index('def _named_projection')]
    assert 'q[:,2]*=self._umbrella_z_sign()' in canonical
    assert 'return points[:,0], points[:,2], -points[:,1]' in block
    assert 'return points[:,1], points[:,2], points[:,0]' in block
    assert 'sy_screen=q[:,2]' in block
    assert 'sy_screen=-q[:,2]' not in block


def test_t2star_field5_is_rejected_even_if_numeric_values_look_temperature_like():
    svc=DqaFocusAlignmentService()
    image=np.full((16,16),37.0,float)
    out=svc._thermometry_evidence({'seriesdiscription':'T2_Star_ME_1SL'},image)
    assert out['valid'] is False
    assert 'non-thermometry' in out['reason']


def test_tmap_absolute_temperature_is_accepted():
    svc=DqaFocusAlignmentService()
    image=np.full((16,16),37.0,float)
    image[8,8]=52.0
    out=svc._thermometry_evidence({'seriesdiscription':'TMAP-ME Axial'},image)
    assert out['valid'] is True
    assert out['mode']=='absolute'


def test_large_field5_values_are_rejected_even_without_protocol_name():
    svc=DqaFocusAlignmentService()
    image=np.full((16,16),12000.0,float)
    out=svc._thermometry_evidence({},image)
    assert out['valid'] is False
    assert 'outside validated' in out['reason']
