from pathlib import Path
import math
from src.services.transducer_location_service import TransducerLocationService

LOG = """08:17:31:367 Inf Dbg 8364 Home position read from section [PatientInfo]. UVW = (0.489600, -31.067017, 148.330109), Transducer Direction: UVW = (-0.000447, 0.015182, -0.999885)
08:19:20:591 Inf Srv 8364 TRACKERS SELECTION: Xd location was decoded from the trackers with high reliability (e.g. all trackers gave good signals)
08:19:20:591 Inf Dbg 8364 New home position: (0.455313, -30.9918, 147.471) New XD tilt: (-0.000123638, 0.0157638, -0.999876)
08:19:20:596 Inf Dbg 8364 focal position:  L0.4 A28.6 I2.5
08:21:53:717 Inf Dbg 8364 New XD pos. in CSA coords. according to trackers - X: 0.019591, Y: 0.035643, Z: -0.016206, Roll: 0.000000, Pitch: 0.000000
"""

def test_absolute_pose_uses_new_home_not_tracker_residual(tmp_path: Path):
    ws=tmp_path/"WSFiles"; ws.mkdir()
    (ws/"2026_Sep_04_07_58_39.Log").write_text(LOG)
    poses=TransducerLocationService().physical_pose_history(tmp_path)
    assert len(poses)==2
    assert poses[0].event_kind=="initial-home"
    assert poses[1].event_kind=="tracker-updated-home"
    assert poses[1].home_xyz==(0.455313,-30.9918,147.471)
    assert math.isclose(poses[1].home_displacement_mm,0.8630767459,rel_tol=0,abs_tol=1e-6)
    assert poses[1].focus_displacement_mm is not None
    assert 0.86 < poses[1].focus_displacement_mm < 0.89
    # Direct focal display validates ~150 mm focus geometry.
    assert poses[1].focal_distance_mm is not None
    assert 149.8 < poses[1].focal_distance_mm < 150.2
    assert poses[1].focal_validation_error_mm is not None
    assert poses[1].focal_validation_error_mm < 0.1

def test_residual_only_does_not_create_physical_pose(tmp_path: Path):
    ws=tmp_path/"WSFiles"; ws.mkdir()
    (ws/"x.Log").write_text("08:00:00:000 Inf Dbg 1 New XD pos. in CSA coords. according to trackers - X: 12, Y: 0, Z: 0")
    assert TransducerLocationService().physical_pose_history(tmp_path)==[]
