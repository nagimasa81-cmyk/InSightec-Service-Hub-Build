from pathlib import Path
import numpy as np
from src.services.import_diagnostics_service import ImportDiagnosticsService
from src.services.transducer_location_service import TransducerLocationRecord


def test_import_diagnostics_contract_contains_transducer_location_history_source():
    text=Path('src/services/import_diagnostics_service.py').read_text(encoding='utf-8')
    assert 'transducer_service.parse(root)' in text
    assert '"transducer_location_history"' in text
    assert '"confirmed_locate_result_count"' in text
    assert '"raw_xd_report_count"' in text
    assert '"locate_workflow_evidence"' in text
    assert '"max_displacement_from_first_confirmed"' not in text
    assert '"steering_xyz"' in text
    assert '"line_number"' in text


def test_transducer_parser_keeps_physical_and_steering_xyz_separate(tmp_path):
    ws=tmp_path/'WSFiles'; ws.mkdir()
    log=ws/'Workstation_2026_Apr_01.Log'
    log.write_text(
        '18:40:00:000 Inf Dbg 1 Locate Transducer started\n'
        '18:40:01:250 Inf Dbg 1 Xd loc XYZ: 1.0 -2.0 3.5, roll: 0.25, pitch: -0.5, Steering: 10.0 20.0 30.0\n'
        '18:50:00:000 Inf Dbg 1 Xd loc XYZ: 2.0 -1.0 5.5, roll: 0.5, pitch: -0.25, Steering: 11.0 21.0 31.0\n',
        encoding='utf-8'
    )
    from src.services.transducer_location_service import TransducerLocationService
    svc=TransducerLocationService()
    assert svc.parse(tmp_path)==[]
    rows=svc.raw_xd_reports(tmp_path)
    assert len(rows)==2
    assert (rows[0].x, rows[0].y, rows[0].z)==(1.0,-2.0,3.5)
    assert (rows[0].steering_x, rows[0].steering_y, rows[0].steering_z)==(10.0,20.0,30.0)
