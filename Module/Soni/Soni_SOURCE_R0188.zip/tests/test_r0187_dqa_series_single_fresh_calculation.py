from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_dqa_not_calculated_inside_each_summary_row():
    text=(ROOT/'src/ui/main_window.py').read_text()
    block=text.split('def _build_one_sonication_summary',1)[1].split('def _build_one_sonication_temperature_summary',1)[0]
    assert 'dqa_focus_alignment_service.analyze_series' not in block
    assert 'SERIES-COMMON' in block

def test_series_common_cell_forces_fresh_dqa_recalculation():
    text=(ROOT/'src/ui/main_window.py').read_text()
    block=text.split('def _apply_series_common_dqa_cell',1)[1].split('def _sonication_summary_finished',1)[0]
    assert 'dqa_focus_alignment_service.clear_cache()' in block
    assert 'dqa_focus_alignment_service.analyze_series(self.package)' in block
    assert block.index('clear_cache()') < block.index('analyze_series(self.package)')

def test_dqa_cache_key_is_contract_versioned():
    text=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text()
    block=text.split('def analyze_series',1)[1].split('def clear_cache',1)[0]
    assert 'r0188::series::' in block
    assert "calculator_contract='R0188'" in block
