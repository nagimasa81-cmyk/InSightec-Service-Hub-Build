from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'src/ui/main_window.py').read_text(encoding='utf-8')


def test_r0011_version():
    assert (ROOT / 'VERSION').read_text().strip() == 'RC2-R0011'


def test_xd_uses_fixed_sdr_scale_and_pitch_aware_markers():
    assert 'if self.parameter == "Element SDR"' in SOURCE
    assert 'pitch = float(np.median(nearest))' in SOURCE
    assert 'radius = max(1.8, min(4.4' in SOURCE


def test_xd_workstation_lut_and_hot_locator_present():
    assert '(1.00, (235, 35, 175))' in SOURCE
    assert 'Workstation-like hot-element locator' in SOURCE
    assert 'concentric guides' in SOURCE
