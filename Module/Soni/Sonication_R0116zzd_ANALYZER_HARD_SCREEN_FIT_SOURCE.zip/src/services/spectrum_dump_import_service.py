from __future__ import annotations

from dataclasses import dataclass
import re
from pathlib import Path, PurePosixPath
import shutil
import tempfile
import zipfile


@dataclass(slots=True)
class SpectrumDumpCandidate:
    label: str
    raw_path: Path | None
    fft_path: Path | None
    relative_path: str
    family: str
    acquisition_session_index: int | None = None
    acquisition_session_end_error_s: float | None = None
    mapping_evidence: str = "Unresolved"
    mapping_confidence: str = "Unknown"

    @property
    def primary_path(self) -> Path:
        return self.fft_path or self.raw_path  # type: ignore[return-value]

    @property
    def completeness(self) -> str:
        if self.raw_path is not None and self.fft_path is not None:
            return "RAW + FFT"
        if self.fft_path is not None:
            return "FFT only"
        return "RAW only"


@dataclass(slots=True)
class SpectrumDumpSource:
    source: Path
    workspace: Path
    candidates: list[SpectrumDumpCandidate]
    temporary: bool = False


class SpectrumDumpImportService:
    """Discover CPC/Spectrum dump pairs from a ZIP, folder, or one file.

    The browser deliberately stays file-family based.  A candidate is a logical
    measurement containing Spectrum_*.dmp and, when present, its matching
    Spectrum_*.dmp_FFT companion.  SpectrumMsg*.dmp is also surfaced as a
    distinct message-stream family but is never relabelled as physical 8CH CPC.
    """

    def __init__(self) -> None:
        self._temp_dirs: list[Path] = []

    @staticmethod
    def _validate_zip_member(name: str) -> None:
        normalized = name.replace("\\", "/")
        member = PurePosixPath(normalized)
        if member.is_absolute() or ".." in member.parts:
            raise ValueError(f"Unsafe ZIP entry rejected: {name}")
        if member.parts and ":" in member.parts[0]:
            raise ValueError(f"Unsafe ZIP entry rejected: {name}")

    def open_source(self, source: Path) -> SpectrumDumpSource:
        source = source.expanduser().resolve()
        temporary = False
        if source.is_dir():
            workspace = source
        elif source.is_file() and source.suffix.lower() == ".zip":
            workspace = Path(tempfile.mkdtemp(prefix="SpectrumDump_"))
            temporary = True
            try:
                with zipfile.ZipFile(source) as archive:
                    bad = archive.testzip()
                    if bad:
                        raise ValueError(f"Corrupted ZIP member: {bad}")
                    for info in archive.infolist():
                        self._validate_zip_member(info.filename)
                    archive.extractall(workspace)
            except Exception:
                shutil.rmtree(workspace, ignore_errors=True)
                raise
            self._temp_dirs.append(workspace)
        elif source.is_file():
            workspace = source.parent
        else:
            raise FileNotFoundError(f"Source not found: {source}")

        candidates = self.discover(workspace, selected_file=source if source.is_file() and source.suffix.lower() != ".zip" else None)
        return SpectrumDumpSource(source=source, workspace=workspace, candidates=candidates, temporary=temporary)

    @staticmethod
    def _is_spectrum_file(path: Path) -> bool:
        low = path.name.lower()
        return (
            (low.endswith(".dmp") or low.endswith(".dmp_fft"))
            and "spectrum" in low
        )

    @staticmethod
    def _key_for(path: Path) -> str:
        low = path.name.lower()
        if low.endswith(".dmp_fft"):
            return path.name[:-4]  # remove _FFT, keep .dmp stem identity
        return path.name

    def discover_from_files(self, workspace: Path, files_in: list[Path]) -> list[SpectrumDumpCandidate]:
        """Build Spectrum candidates from an already-discovered file list.

        Main Sonication Analysis already discovers CPCFiles while building the
        treatment package. Re-walking the entire extracted Export with rglob()
        when Spectrum Dump Analyzer is opened can be very expensive on large
        studies. This helper reuses that authoritative package file inventory.
        """
        workspace = Path(workspace)
        files = sorted(
            (Path(p) for p in files_in if Path(p).is_file() and self._is_spectrum_file(Path(p))),
            key=lambda p: str(p).lower(),
        )
        return self._candidates_from_files(workspace, files)

    def _candidates_from_files(self, workspace: Path, files: list[Path]) -> list[SpectrumDumpCandidate]:
        groups: dict[tuple[str, str], dict[str, Path]] = {}
        for path in files:
            low = path.name.lower()
            family = "SpectrumMsg" if "spectrummsg" in low else "CPC Spectrum"
            key_name = self._key_for(path).lower()
            group_key = (str(path.parent.resolve()).lower() + "::" + key_name, family)
            bucket = groups.setdefault(group_key, {})
            if low.endswith(".dmp_fft"):
                bucket["fft"] = path
            else:
                bucket["raw"] = path

        out: list[SpectrumDumpCandidate] = []
        for (_, family), bucket in groups.items():
            raw = bucket.get("raw")
            fft = bucket.get("fft")
            primary = fft or raw
            if primary is None:
                continue
            try:
                rel = str(primary.relative_to(workspace))
            except ValueError:
                rel = primary.name
            base = (raw or fft).name if (raw or fft) is not None else primary.name
            if base.lower().endswith(".dmp_fft"):
                base = base[:-4]
            out.append(SpectrumDumpCandidate(
                label=base, raw_path=raw, fft_path=fft, relative_path=rel, family=family,
            ))
        out.sort(key=lambda c: (0 if c.family == "CPC Spectrum" else 1, c.relative_path.lower()))
        return out

    def discover(self, workspace: Path, selected_file: Path | None = None) -> list[SpectrumDumpCandidate]:
        if selected_file is not None:
            if not self._is_spectrum_file(selected_file):
                raise ValueError("Selected file is not a Spectrum dump (*.dmp / *.dmp_FFT).")
            files = [selected_file]
            # A single-file selection is deterministic, but still bring in the
            # exact same-directory companion automatically when it exists.
            low = selected_file.name.lower()
            if low.endswith(".dmp_fft"):
                companion = selected_file.with_name(selected_file.name[:-4])
            else:
                companion = selected_file.with_name(selected_file.name + "_FFT")
            if companion.exists():
                files.append(companion)
        else:
            files = sorted(
                (p for p in workspace.rglob("*") if p.is_file() and self._is_spectrum_file(p)),
                key=lambda p: str(p).lower(),
            )

        return self._candidates_from_files(workspace, files)


    @staticmethod
    def _explicit_sonication_number(candidate: SpectrumDumpCandidate) -> int | None:
        """Return SonicationN encoded in the candidate path, if present."""
        for part in reversed(Path(candidate.relative_path).parts):
            compact = str(part).lower().replace("_", "").replace("-", "").replace(" ", "")
            if compact.startswith("sonication"):
                suffix = compact[len("sonication"): ]
                if suffix.isdigit():
                    return int(suffix)
        return None

    _CLOCK_RE = re.compile(r"_(\d{2})_(\d{2})_(\d{2})_\d{4}", re.I)

    @classmethod
    def _candidate_clock_s(cls, candidate: SpectrumDumpCandidate) -> float | None:
        m = cls._CLOCK_RE.search(candidate.primary_path.name)
        if not m:
            return None
        h, mm, s = (int(v) for v in m.groups())
        return float(h*3600 + mm*60 + s)

    @staticmethod
    def _clock_delta_s(a: float, b: float) -> float:
        d=float(a)-float(b)
        if d>43200: d-=86400
        elif d<-43200: d+=86400
        return d

    def bind_candidates_to_acquisition_sessions(self, candidates: list[SpectrumDumpCandidate]) -> None:
        physical=[c for c in candidates if c.family=="CPC Spectrum"]
        if not physical: return
        try:
            from src.services.acoustic_control_service import AcousticControlService
            service=AcousticControlService()
            log=service.find_log(physical[0].primary_path.parent)
            if log is None: return
            sessions=service.parse_segments(log)
        except Exception:
            return
        ends=[]
        for idx,seg in enumerate(sessions):
            vals=[float(x.elapsed_s) for x in seg.samples]
            if vals: ends.append((idx,float(seg.start_clock_s)+max(vals)))
        for c in physical:
            clock=self._candidate_clock_s(c)
            if clock is None or not ends: continue
            err,idx=min((abs(self._clock_delta_s(clock,end)),idx) for idx,end in ends)
            if err<=3.0:
                c.acquisition_session_index=int(idx)
                c.acquisition_session_end_error_s=float(err)
                c.mapping_evidence=f"Acquisition_Brain session {idx+1}; end-clock error {err:.3f}s"
                c.mapping_confidence="Exact" if err<=1.5 else "High"

    def _validated_treatment_suffix(self, physical: list[SpectrumDumpCandidate], needed: int) -> list[SpectrumDumpCandidate] | None:
        if needed<=0 or len(physical)<needed: return None
        self.bind_candidates_to_acquisition_sessions(physical)
        ordered=sorted(physical,key=lambda c:(c.acquisition_session_index if c.acquisition_session_index is not None else 10**9,self._candidate_clock_s(c) or 10**9,c.relative_path.lower()))
        if len(ordered)==needed: return ordered
        suffix=ordered[-needed:]
        if all(c.acquisition_session_index is not None for c in ordered):
            idx=[int(c.acquisition_session_index) for c in suffix]
            prev=ordered[-needed-1] if len(ordered)>needed else None
            if idx==list(range(idx[0],idx[0]+needed)):
                if prev is None: return suffix
                pc=self._candidate_clock_s(prev); fc=self._candidate_clock_s(suffix[0])
                if pc is not None and fc is not None and self._clock_delta_s(fc,pc)>=60.0:
                    return suffix
        timed=[(self._candidate_clock_s(c),c) for c in physical]
        if all(x[0] is not None for x in timed):
            timed.sort(key=lambda x:float(x[0]))
            gaps=[float(timed[i+1][0])-float(timed[i][0]) for i in range(len(timed)-1)]
            if gaps:
                split=max(range(len(gaps)),key=lambda i:gaps[i])+1
                out=[c for _,c in timed[split:]]
                if len(out)==needed and gaps[split-1]>=60.0: return out
        return None

    def map_candidates_to_sonications(self, candidates: list[SpectrumDumpCandidate], sonications: list[object]) -> dict[int, SpectrumDumpCandidate]:
        """Build one deterministic Sonication -> physical CPC SpectrumDumps mapping.

        Explicit ``SonicationN`` directory identity wins.  Remaining CPC
        candidates are assigned positionally only when that mapping is
        unambiguous.  SpectrumMsg entries are intentionally excluded because
        they are not the physical 8-channel CPC source used by this analyzer.
        """
        physical = [c for c in candidates if c.family == "CPC Spectrum"]
        mapping: dict[int, SpectrumDumpCandidate] = {}
        used: set[int] = set()
        self.bind_candidates_to_acquisition_sessions(physical)

        # 0) Canonical Sonication evidence is strongest: Sonication folder ->
        # SpectrumMsg/PowerGraph -> Type6 Sonication_Brain setup -> Acquisition session.
        # Bind CPC only when its independently-derived Acquisition session agrees.
        for si, son in enumerate(sonications):
            session = getattr(son, "canonical_acquisition_session_index", None)
            if session is None:
                continue
            matches = [(ci, c) for ci, c in enumerate(physical)
                       if ci not in used and c.acquisition_session_index is not None
                       and int(c.acquisition_session_index) == int(session)]
            if len(matches) == 1:
                ci, candidate = matches[0]
                mapping[si] = candidate
                used.add(ci)
                local_evidence = list(getattr(son, "canonical_mapping_evidence", []) or [])
                candidate.mapping_evidence = (candidate.mapping_evidence + "; " if candidate.mapping_evidence else "") + \
                    f"Sonication{si+1} canonical session {int(session)+1}"
                if local_evidence:
                    candidate.mapping_evidence += "; " + "; ".join(local_evidence[:3])
                candidate.mapping_confidence = "Exact"

        # 1) Explicit treatment-export folder identity is authoritative.
        for ci, candidate in enumerate(physical):
            number = self._explicit_sonication_number(candidate)
            if number is None:
                continue
            index = number - 1
            if 0 <= index < len(sonications) and index not in mapping:
                mapping[index] = candidate
                used.add(ci)

        # 2) Match the actual Sonication folder/name when it appears in path.
        for si, son in enumerate(sonications):
            if si in mapping:
                continue
            tokens = []
            name = getattr(son, "name", "")
            folder = getattr(son, "folder", None)
            if name:
                tokens.append(str(name).lower().replace(" ", ""))
            if folder is not None:
                tokens.append(Path(folder).name.lower().replace(" ", ""))
            matches = []
            for ci, candidate in enumerate(physical):
                if ci in used:
                    continue
                rel = candidate.relative_path.lower().replace(" ", "")
                if any(token and token in rel for token in tokens):
                    matches.append((ci, candidate))
            if len(matches) == 1:
                ci, candidate = matches[0]
                mapping[si] = candidate
                used.add(ci)

        # 3) Evidence-based treatment block mapping. Never blindly assign latest N.
        remaining_s=[i for i in range(len(sonications)) if i not in mapping]
        remaining_c=[c for ci,c in enumerate(physical) if ci not in used]
        selected=self._validated_treatment_suffix(remaining_c,len(remaining_s))
        if remaining_s and selected is not None:
            for si,candidate in zip(remaining_s,selected):
                mapping[si]=candidate
                candidate.mapping_evidence=(candidate.mapping_evidence+"; treatment block boundary validated")
                candidate.mapping_confidence="Exact" if candidate.acquisition_session_index is not None else "High"

        return mapping

    def cleanup(self) -> None:
        for path in self._temp_dirs:
            shutil.rmtree(path, ignore_errors=True)
        self._temp_dirs.clear()
