from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class RawFrame:
    path: Path
    index: int
    prefix: str


@dataclass(slots=True)
class SonicationModel:
    name: str
    folder: Path
    temperature_frames: list[RawFrame] = field(default_factory=list)
    magnitude_frames: list[RawFrame] = field(default_factory=list)
    spectrum_files: list[Path] = field(default_factory=list)
    act_files: list[Path] = field(default_factory=list)
    other_files: list[Path] = field(default_factory=list)
    main_frequency_hz: float | None = None
    main_frequency_source: Path | None = None
    main_frequency_raw_line: str | None = None
    planned_duration_s: float | None = None
    actual_duration_s: float | None = None
    planned_power_w: float | None = None
    actual_power_w: float | None = None
    planned_energy_j: float | None = None
    actual_energy_j: float | None = None
    timing_source: Path | None = None
    completeness_status: str = "UNKNOWN"
    completeness_score: int = 0
    missing_required: list[str] = field(default_factory=list)
    missing_optional: list[str] = field(default_factory=list)
    degraded_items: list[str] = field(default_factory=list)
    capabilities: dict = field(default_factory=dict)
    thermometry_mode: str = "Unknown"
    canonical_acquisition_session_index: int | None = None
    canonical_setup_clock_s: float | None = None
    canonical_time_zero_offset_s: float = 0.0
    canonical_mapping_confidence: str = "Unknown"
    canonical_mapping_evidence: list[str] = field(default_factory=list)
    spectrummsg_frame_count: int | None = None
    powergraph_size: int | None = None
    sonication_file_inventory: dict[str, int] = field(default_factory=dict)
    # Canonical MR-owned timebase. All Replay/Spectrum/Cavitation views use
    # MR scanning start as t=0 and MR scanning end as the common end point.
    mr_timeline_duration_s: float | None = None
    mr_sonication_start_s: float | None = None
    mr_sonication_end_s: float | None = None
    mr_frame_interval_s: float | None = None
    mr_timeline_source: str = "Unavailable"
    mr_timeline_confidence: str = "Unknown"
    mr_timeline_evidence: list[str] = field(default_factory=list)

    @property
    def replay_frame_count(self) -> int:
        # Replay navigation is owned by the MR acquisition timeline.
        # SpectrumMsg files are a separately sampled stream and must be mapped
        # onto the MR cursor; including them here produced dozens of cursor
        # positions that reused the same MR image, making the arrow buttons
        # appear non-functional.
        return max(
            len(self.temperature_frames),
            len(self.magnitude_frames),
            1,
        )


@dataclass(slots=True)
class ReplayPackage:
    source: Path
    workspace: Path
    sonications: list[SonicationModel] = field(default_factory=list)
    main_frequency_hz: float | None = None
    main_frequency_source: Path | None = None
    main_frequency_raw_line: str | None = None
    main_frequency_confidence: float = 0.0
    main_frequency_interpretation: str = "Unavailable"
    cpc_spectrum_files: list[Path] = field(default_factory=list)
    planning_assets: list[object] = field(default_factory=list)
    xd_reference_files: list[Path] = field(default_factory=list)
    xd_geometry_files: list[Path] = field(default_factory=list)
    workflow_mode: str = "Unknown"
    thermometry_mode: str = "Unknown"
    canonical_acquisition_session_index: int | None = None
    canonical_setup_clock_s: float | None = None
    canonical_time_zero_offset_s: float = 0.0
    canonical_mapping_confidence: str = "Unknown"
    canonical_mapping_evidence: list[str] = field(default_factory=list)
    spectrummsg_frame_count: int | None = None
    powergraph_size: int | None = None
    sonication_file_inventory: dict[str, int] = field(default_factory=dict)
