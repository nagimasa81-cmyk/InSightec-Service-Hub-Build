# R0116zzb — Screen-fit / checkbox / spectrogram / regression hardening

## Loading responsiveness inherited from R0116zza
- CPC/cavitation decode no longer blocks the exclusive 61% Replay load stage.
- Detailed MR/Sonication metadata no longer blocks the 91% GUI stage.
- Background workers reject stale workspace/selection results.

## Screen-fit and access
- Spectrum Dump Analyzer defaults to no main vertical or horizontal scrollbar.
- Analysis Details alone may enable the main vertical scrollbar.
- Cavitation Events tables keep vertical scrolling but disable horizontal scrolling and optimize columns to viewport width.
- Plot/table minimum heights are dynamically reduced on laptop viewports.
- Removed the legacy Vendor 280/245 px minimum-height override that could re-expand the Analyzer after compact fitting.
- Cavitation Intelligence default view shrinks linked plots/tables to fit the visible viewport before scrolling is considered. Optional expanded sections may scroll.

## Collapsible UI cleanup
- Evidence chain, Root Cause Analysis, and Treatment Outcome Science are one horizontal checkbox row.
- Removed the unused legacy triangular _make_ci_collapsible_section implementation to prevent regression.
- Replay Images/Registration, Temperature/Spectrum, and Power/Score/Cavitation remain one horizontal checkbox row.

## Spectrogram
- Spectrogram is color mapped and X range remains limited to finite CPC/FFT sample time.
- Hover explanation is localized for all seven supported languages.
- Hover remains visible while the pointer remains over the plot and is hidden on Leave/Hide.

## CGA readability
- Linked CGA view shows 100% threshold and 80% threshold guidance plus per-rule peak percentage labels.

## Regression audit
- No duplicate Python method/class definitions in key UI files.
- No exact duplicate signal connections inside the same UI method.
- No legacy last-N CPC mapping fallback found.
- Legacy regression test that required tall Vendor minimums was updated to the screen-fit requirement.

## Validation
- R0116 tests: 238/238 PASS before release metadata bump.
- Full suite excluding the known PySide6 ROI GUI test: 544/544 PASS before release metadata bump.
- VERIFY_SOURCE_OK.
- compileall PASS.
