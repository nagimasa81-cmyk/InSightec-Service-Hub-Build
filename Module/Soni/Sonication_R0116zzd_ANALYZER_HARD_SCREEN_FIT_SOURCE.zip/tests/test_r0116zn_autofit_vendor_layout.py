from pathlib import Path
from types import SimpleNamespace
from src.services.mr_timeline_service import MRTimelineService


def test_mrserver_step_open_closes_exact_scan(tmp_path):
    (tmp_path/'2026_Aug_13_09_05_51.Log').write_text(
        '12:26:02:512 Main status changed from: Sonication to Sonication power on\n'
        '12:26:16:590 Main status changed from: Sonication power on to Post sonication\n'
    )
    (tmp_path/'mrserver_test.log').write_text(
        '12:25:53:461 Status changed from Preparing to Scanning.\n'
        '12:26:36:409 Status changed from Scanning to Step is open.\n'
    )
    son=SimpleNamespace(replay_frame_count=11, canonical_acquisition_session_index=0)
    row=MRTimelineService().resolve_all(tmp_path,[son])[0]
    assert row.confidence == 'Exact'
    assert abs(row.duration_s-42.948)<1e-3
    assert abs(row.sonication_start_s-9.051)<1e-3


def test_mr_mapping_uses_authoritative_acquisition_session_not_latest_n(tmp_path):
    log=[]
    for i in range(4):
        minute=10+i
        log.append(f'12:{minute:02d}:10:000 Main status changed from: Sonication to Sonication power on\n')
        log.append(f'12:{minute:02d}:20:000 Main status changed from: Sonication power on to Post sonication\n')
    (tmp_path/'2026_Aug_13_09_05_51.Log').write_text(''.join(log))
    mr=[]
    for i in range(4):
        minute=10+i
        mr.append(f'12:{minute:02d}:00:000 Status changed from Preparing to Scanning.\n')
        mr.append(f'12:{minute:02d}:30:000 Status changed from Scanning to Idle.\n')
    (tmp_path/'mrserver_test.log').write_text(''.join(mr))
    sons=[SimpleNamespace(replay_frame_count=5, canonical_acquisition_session_index=1),
          SimpleNamespace(replay_frame_count=5, canonical_acquisition_session_index=3)]
    rows=MRTimelineService().resolve_all(tmp_path,sons)
    assert [round(r.sonication_start_s,3) for r in rows] == [10.0,10.0]
    assert 'Exact' == rows[0].confidence == rows[1].confidence


def test_analyzer_autofits_after_open_load_and_tab_change():
    text=Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'self.tabs.currentChanged.connect(self._analyzer_tab_changed)' in text
    assert 'QTimer.singleShot(0, lambda: self._fit_all_data_views(force=True))' in text
    assert 'self._fit_all_data_views(force=True) if self.replay is r else None' in text
    assert 'def _fit_current_tab' in text
    assert 'def _fit_all_data_views' in text


def test_vendor_tab_restores_requested_default_composition():
    text=Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'def _apply_vendor_tab_default_layout' in text
    assert '"All 8 receivers"' in text
    assert '"Both"' in text
    assert 'self.vendor_details_btn.setChecked(False)' in text
    # R0116zzc: legacy tall minimums caused lower controls to be clipped on laptops.
    assert 'self.vendor_energy_plot.setMinimumHeight(280)' not in text
    assert 'self.vendor_power_plot.setMinimumHeight(245)' not in text
    assert 'def _apply_compact_screen_layout' in text


def test_spectrogram_is_resampled_to_mr_time_not_sequence_axis():
    text=Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    block=text[text.index('def _draw_spectrogram'):text.index('def _selected_bands')]
    assert 'np.interp(target_t, source_t, row' in block
    assert '"Acquisition time"' in block
    assert 'x_min=float(source_t[0]); x_max=float(source_t[-1])' in block
    assert 'FFT snapshot sequence' not in block


def test_main_relative_spectrum_is_embedded_inside_mr_window():
    renderer=Path('src/core/relative_spectrum_renderer.py').read_text(encoding='utf-8')
    main=Path('src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'timeline_offset_s: float = 0.0' in renderer
    assert 'full_timeline_duration_s: float = 0.0' in renderer
    assert 'plot.setXRange(0.0,float(full_timeline_duration_s)' in renderer
    assert 'timeline_offset_s=float(getattr(self.current, "mr_sonication_start_s"' in main
    assert 'full_timeline_duration_s=float(getattr(self.current, "mr_timeline_duration_s"' in main
