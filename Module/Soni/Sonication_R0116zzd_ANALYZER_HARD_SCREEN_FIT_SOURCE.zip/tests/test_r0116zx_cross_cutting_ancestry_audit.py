from pathlib import Path


def test_no_latest_n_cpc_positional_selector_survives():
    text=Path("src/services/hydrophone_replay_service.py").read_text(encoding="utf-8")
    block=text[text.index("def select_files"):text.index("def build(", text.index("def select_files"))]
    assert "candidates[-sonication_count:]" not in block
    assert "return None,None" in block


def test_preload_does_not_substitute_unresolved_physical_cpc():
    text=Path("src/ui/main_window.py").read_text(encoding="utf-8")
    start=text.index("class SpectrumPreloadWorker")
    end=text.index("class ImageThumbnailWorker",start)
    block=text[start:end]
    assert "CPC binding unresolved" in block
    assert "No positional substitution was made" in block


def test_legacy_mr_xrange_name_is_payload_fit_only():
    text=Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    start=text.index("def _set_mr_xrange")
    end=text.index("def _apply_mr_timeline_window",start)
    block=text[start:end]
    assert "mr_timeline_duration_s" not in block
    assert "_plot_data_x_range" in block
    assert "_fit_plot" in block


def test_controller_ratio_not_called_actual_power_in_ci_linked_plot():
    text=Path("src/ui/main_window.py").read_text(encoding="utf-8")
    start=text.index("def _draw_ci_linked_control")
    end=text.index("def _update_ci_linked_panel",start)
    block=text[start:end]
    assert 'name="Actual power ratio"' not in block
    assert 'Controller ExPowerRatio' in block
    assert 'mr_timeline_duration_s' not in block

def test_ci_linked_plots_fit_to_payload_helper():
    text=Path("src/ui/main_window.py").read_text(encoding="utf-8")
    assert "def _fit_plot_x_to_payload" in text
    assert text.count("self._fit_plot_x_to_payload(plot)") >= 2
