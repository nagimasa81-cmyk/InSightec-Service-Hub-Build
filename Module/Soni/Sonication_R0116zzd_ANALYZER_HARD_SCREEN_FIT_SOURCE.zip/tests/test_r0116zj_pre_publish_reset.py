from pathlib import Path

def test_load_sonication_does_not_full_reset_before_primary_publish():
    text=Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    a=text.index("def load_sonication")
    b=text.index("def _finish_secondary_replay_publish",a)
    block=text[a:b]
    assert "self._reset_replay_state_fast()" in block
    assert "self._reset_replay_analysis_state()" not in block
    assert "Adopting decoded Spectrum replay" in block
    assert "Publishing first FFT frame" in block

def test_secondary_widget_clear_is_deferred_until_after_primary_publish():
    text=Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    a=text.index("def _finish_secondary_replay_publish")
    block=text[a:a+3000]
    assert "self._clear_secondary_analysis_views()" in block
    assert block.index("self._clear_secondary_analysis_views()") < block.index("self._draw_spectrogram()")
