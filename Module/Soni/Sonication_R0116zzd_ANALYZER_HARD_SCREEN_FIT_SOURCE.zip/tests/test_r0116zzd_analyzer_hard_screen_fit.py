from pathlib import Path

SRC = Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')


def test_top_level_is_hard_clamped_to_available_screen():
    assert 'self.setMaximumSize(max(560, area.width() - margin * 2), max(420, area.height() - margin * 2))' in SRC
    assert 'self.setMaximumSize(max(560, area.width()-24), max(420, area.height()-24))' in SRC


def test_main_content_and_tabs_can_shrink_vertically():
    assert 'content.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Ignored)' in SRC
    assert 'self.tabs.setMinimumHeight(0)' in SRC
    assert 'self.tabs.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Ignored)' in SRC
    assert 'page.setMinimumSize(0, 0)' in SRC


def test_basic_plots_yield_height_to_bottom_controls():
    assert 'plot.setMinimumSize(0, 0)' in SRC
    assert 'plot.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Ignored)' in SRC
    assert 'basic_plots.extend(getattr(self, "raw_plots", []))' in SRC
    assert 'basic_plots.extend(getattr(self, "spectrum_plots", []))' in SRC
    assert 'plot.setMinimumHeight(0)' in SRC
