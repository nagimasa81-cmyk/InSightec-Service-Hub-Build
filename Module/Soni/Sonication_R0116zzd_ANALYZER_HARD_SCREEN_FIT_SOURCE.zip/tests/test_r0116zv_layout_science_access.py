from pathlib import Path


def test_replay_collapsing_rebalances_vertical_space():
    text=Path("src/ui/main_window.py").read_text(encoding="utf-8")
    assert "def _rebalance_replay_right_sections" in text
    assert "QTimer.singleShot(0, self._rebalance_replay_right_sections)" in text


def test_power_score_column_and_x_axis_follow_temperature():
    text=Path("src/ui/main_window.py").read_text(encoding="utf-8")
    assert "def _sync_replay_chart_columns" in text
    assert "self.acoustic_control_plot.setXRange(0.0, axis_end, padding=0.0)" in text
    assert "self.acoustic_control_plot.setXLink(self.temperature_plot)" in text


def test_treatment_science_has_direct_access_button():
    text=Path("src/ui/main_window.py").read_text(encoding="utf-8")
    assert 'QPushButton("Treatment Outcome Science")' in text
    assert "def _show_treatment_outcome_science" in text


def test_analyzer_has_no_main_horizontal_scrollbar():
    text=Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    assert "self._main_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)" in text
    assert "self._main_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)" in text
    assert "Qt.ScrollBarPolicy.ScrollBarAsNeeded if checked else Qt.ScrollBarPolicy.ScrollBarAlwaysOff" in text
