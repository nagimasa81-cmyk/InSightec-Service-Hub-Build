# R0116zzd — Analyzer hard screen fit

- Hard-clamp Spectrum Dump Analyzer top-level size to the active monitor availableGeometry.
- Make content/QTabWidget/tab pages vertically shrinkable instead of clipping bottom controls.
- Make Raw/Spectrum/Spectrogram/Band plots yield height before controls are clipped.
- Keep main horizontal scrollbar disabled and normal main vertical scrollbar disabled.
- Preserve expanded Analysis Details as the only main vertical-scroll case.
