from __future__ import annotations
import shutil, tempfile, zipfile
from pathlib import Path

class ImportService:
    def __init__(self): self.temp_dirs=[]
    def open(self, source: Path) -> Path:
        source=source.expanduser().resolve()
        if source.is_dir(): return source
        if source.suffix.lower()!='.zip': raise ValueError('Select a ZIP file or folder.')
        temp=Path(tempfile.mkdtemp(prefix='SonicationReplay_')); self.temp_dirs.append(temp)
        with zipfile.ZipFile(source) as z: z.extractall(temp)
        return temp
    def cleanup(self):
        for p in self.temp_dirs: shutil.rmtree(p,ignore_errors=True)
        self.temp_dirs.clear()
