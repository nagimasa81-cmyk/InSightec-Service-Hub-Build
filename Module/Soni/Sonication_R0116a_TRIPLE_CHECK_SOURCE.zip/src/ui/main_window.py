from __future__ import annotations

import logging
import re
from pathlib import Path

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import QSettings, Qt, QTimer, QSize, QRectF, QPointF, QEvent, QObject, QThread, Signal
from PySide6.QtGui import QAction, QImage, QPixmap, QIcon, QCursor, QPainter, QColor, QPen, QBrush, QShortcut, QKeySequence
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QFileDialog, QFrame, QGroupBox, QHeaderView,
    QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QMainWindow,
    QMessageBox, QPushButton, QSlider, QScrollBar, QSpinBox, QDoubleSpinBox, QSplitter, QTableWidget, QProgressBar,
    QTableWidgetItem, QTabWidget, QTreeWidget, QTreeWidgetItem, QVBoxLayout,
    QWidget, QDialog, QGridLayout, QToolButton, QMenu, QFormLayout, QScrollArea, QToolTip, QApplication,
    QTextEdit, QAbstractItemView, QStackedWidget,
)

from src.common.constants import APP_NAME, APP_VERSION, ORGANIZATION
from src.domain.models import SonicationModel
from src.integration.spectrum_provider import SpectrumMsgAnalyzerAdapter
from src.services.phase_focus_service import PhaseFocusService
from src.services.discovery_service import DiscoveryService
from src.services.import_service import ImportService
from src.services.replay_service import ReplayService
from src.services.raw_service import RawService
from src.services.acoustic_control_service import AcousticControlService
from src.services.sonication_channel_service import SonicationChannelService
from src.services.sonication_log_receiver_service import SonicationLogReceiverService
from src.services.sonication_metadata_service import SonicationMetadataService
from src.services.skull_measures_service import SkullMeasuresService
from src.services.engineering_analysis_service import EngineeringAnalysisService
from src.services.hydrophone_replay_service import HydrophoneReplayService
from src.services.hydrophone_calibration_service import HydrophoneCalibrationService
from src.services.cavitation_visualization_service import CavitationVisualizationService
from src.services.cavitation_control_timeline_service import CavitationControlTimelineService
from src.services.cavitation_likelihood_service import CavitationLikelihoodService
from src.services.cavitation_mr_correlation_service import CavitationMrCorrelationService
from src.services.cavitation_root_cause_service import CavitationRootCauseService
from src.services.registration_overlay_service import RegistrationOverlayService
from src.integration.spectrum_provider import SpectrumFrame
from src.core.chart_state import ChartState
from src.core.replay_context import ReplayContext, ReplaySelection
from src.core.replay_snapshot import ReplayFrameSnapshot, ReplaySnapshotProvider
from src.ui.replay_view_coordinator import ReplayViewCoordinator
from src.core.relative_spectrum_renderer import RelativeSpectrumRenderer
from src.core.current_spectrum_renderer import CurrentSpectrumRenderer
from src.core.fus_export_core import FIELD_SEMANTICS, RAW_RE as EXPORT_RAW_RE, decode_spectrum_structure
from src.ui.image_panel import OverlayPanel
from src.ui.diagnostics import DiagnosticsTab
from src.ui.hydrophone_window import EightHydrophoneWindow
from src.ui.i18n import LANGUAGES, tr, confidence as tr_confidence, factor_label as tr_factor_label, factor_improvement as tr_factor_improvement, localize_evidence

LOG = logging.getLogger(__name__)


class WwWlViewBox(pg.ViewBox):
    """MR correlation view: left-drag adjusts WW/WL; wheel/right-drag keep zoom/pan."""
    wwlDragged = Signal(float, float)

    def mouseDragEvent(self, ev, axis=None):
        if ev.button() == Qt.MouseButton.LeftButton:
            try:
                delta = ev.screenPos() - ev.lastScreenPos()
                self.wwlDragged.emit(float(delta.x()), float(delta.y()))
            except Exception:
                pass
            ev.accept()
            return
        super().mouseDragEvent(ev, axis=axis)


class PackageLoadWorker(QObject):
    progress = Signal(int, str)
    finished = Signal(object, object, object, object)
    failed = Signal(str)

    def __init__(self, source: Path):
        super().__init__()
        self.source = Path(source)

    def run(self):
        importer = ImportService()
        try:
            self.progress.emit(3, "Opening source...")
            def cb(value, message):
                self.progress.emit(int(value), str(message))
            workspace = importer.open(self.source, progress_callback=cb)
            self.progress.emit(76, "Discovering Sonications and treatment resources...")
            discovery = DiscoveryService()
            package = discovery.discover(self.source, workspace)
            self.progress.emit(94, f"Found {len(package.sonications)} sonication(s); preparing interface...")
            self.finished.emit(self.source, workspace, package, importer.temp_dirs)
        except Exception as exc:
            importer.cleanup()
            self.failed.emit(str(exc))


class ImageThumbnailWorker(QObject):
    """Decode Reference or Treatment-MR thumbnails off the GUI thread."""
    frameReady = Signal(str, int, object, str, int)
    finished = Signal(str, int)

    def __init__(self, role, sources, generation):
        super().__init__(); self.role=str(role); self.sources=list(sources); self.generation=int(generation); self._cancelled=False

    def cancel(self):
        self._cancelled=True

    @staticmethod
    def _decode_planning(asset):
        path=Path(asset.path)
        try:
            width=getattr(asset,'width',None); height=getattr(asset,'height',None); dtype_name=getattr(asset,'dtype',None)
            if path.suffix.lower()!='.raw' or not (width and height and dtype_name): return None
            dtype=np.dtype(dtype_name)
            if path.stat().st_size != int(width)*int(height)*dtype.itemsize: return None
            arr=np.fromfile(path,dtype=dtype).reshape(int(height),int(width)).astype(np.float32)
            finite=arr[np.isfinite(arr)]
            return arr if finite.size and float(np.nanstd(finite))>1e-8 else None
        except Exception:
            return None

    def run(self):
        raw=RawService()
        for default_row,record in enumerate(self.sources):
            if self._cancelled: break
            try:
                if isinstance(record,tuple) and len(record)==2 and isinstance(record[0],int):
                    row,source=record
                else:
                    row,source=default_row,record
                if self.role=='reference':
                    arr=self._decode_planning(source); name=Path(source.path).name
                else:
                    arr=raw.read_magnitude(Path(source.path)); name=Path(source.path).name
                if arr is None: continue
                finite=np.asarray(arr,float); finite=finite[np.isfinite(finite)]
                if not finite.size or float(np.nanstd(finite))<=1e-8: continue
                self.frameReady.emit(self.role,row,np.asarray(arr,np.float32),name,self.generation)
            except Exception:
                continue
        self.finished.emit(self.role,self.generation)


class ThermalThumbnailWorker(QObject):
    """Decode treatment-thermal thumbnails off the UI thread.

    Only numeric RAW decoding happens here. QPixmap/QIcon creation stays on the
    GUI thread when `frameReady` is received.
    """
    frameReady = Signal(int, object, str, int)
    finished = Signal(int)

    def __init__(self, frames, generation: int):
        super().__init__()
        self.frames = list(frames)
        self.generation = int(generation)
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        raw = RawService()
        for row, frame in enumerate(self.frames):
            if self._cancelled:
                break
            try:
                array = raw.read_temperature(Path(frame.path))
                finite = np.asarray(array, float)
                finite = finite[np.isfinite(finite)]
                if not finite.size or float(np.nanstd(finite)) <= 1e-8:
                    continue
                self.frameReady.emit(row, array, Path(frame.path).name, self.generation)
            except Exception:
                continue
        self.finished.emit(self.generation)


class SonicationSummaryDetailWorker(QObject):
    """Build expensive Sonication Summary details away from the GUI thread."""
    rowReady = Signal(int, object, int)
    finished = Signal(int)

    def __init__(self, count: int, generation: int, builder):
        super().__init__()
        self.count = int(count)
        self.generation = int(generation)
        self.builder = builder
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        for row in range(self.count):
            if self._cancelled:
                break
            try:
                data = self.builder(row)
            except Exception as exc:
                data = {"_error": str(exc), "number": row + 1}
            if self._cancelled:
                break
            self.rowReady.emit(row, data, self.generation)
        self.finished.emit(self.generation)


class ChartHoverPopup(QLabel):
    """Persistent chart-local hover popup that works in packaged Qt builds.

    QToolTip can be suppressed by Windows timing/style behavior when it is
    repeatedly refreshed from a high-frequency pyqtgraph mouse signal. This
    QLabel remains parented to the chart widget and is moved beside the cursor.
    """
    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.setTextFormat(Qt.TextFormat.PlainText)
        self.setStyleSheet(
            "QLabel { background: rgba(18, 22, 30, 235); color: white; "
            "border: 1px solid #8da2b8; border-radius: 4px; padding: 5px 7px; }"
        )
        self.setWordWrap(False)
        self.hide()

    def show_lines(self, lines) -> None:
        text = "\n".join(str(line) for line in lines if str(line))
        if not text:
            self.hide()
            return
        # Only one chart popup is visible at a time; multiple floating labels
        # made the compact laptop view difficult to read.
        window = self.window()
        if window is not None:
            for other in window.findChildren(ChartHoverPopup):
                if other is not self:
                    other.hide()
        self.setText(text)
        self.adjustSize()
        parent = self.parentWidget()
        pos = parent.mapFromGlobal(QCursor.pos())
        # Place the label in the opposite half of the plot so it does not cover
        # the point currently being inspected.
        margin = 6
        x = margin if pos.x() > parent.width()/2 else max(margin, parent.width()-self.width()-margin)
        y = margin if pos.y() > parent.height()/2 else max(margin, parent.height()-self.height()-margin)
        self.move(int(x), int(y))
        self.raise_()
        self.show()


class InfoWindow(QDialog):
    """Non-modal, movable, minimizable information window kept above the replay UI."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Sonication Information")
        self.setWindowFlags(
            Qt.WindowType.Window | Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowCloseButtonHint
        )
        self.setModal(False)
        self.resize(540, 360)
        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["Item", "Value"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout = QVBoxLayout(self)
        layout.addWidget(self.table)
        progress_row = QHBoxLayout()
        self.progress_label = QLabel("Ready")
        self.progress_bar = QProgressBar(); self.progress_bar.setRange(0,100); self.progress_bar.setValue(0); self.progress_bar.setMaximumWidth(220)
        self.progress_label.setVisible(False); self.progress_bar.setVisible(False)
        progress_row.addWidget(self.progress_label); progress_row.addWidget(self.progress_bar); progress_row.addStretch(1)
        layout.addLayout(progress_row)

    def _set_progress(self, value: int | None, text: str = ""):
        if value is None:
            self.progress_label.setVisible(False); self.progress_bar.setVisible(False); return
        self.progress_label.setVisible(True); self.progress_bar.setVisible(True)
        self.progress_label.setText(text or "Updating…"); self.progress_bar.setValue(max(0,min(100,int(value))))
        QApplication.processEvents()

    def update_rows(self, rows):
        rows=list(rows)
        self._set_progress(10, "Updating details…")
        self.table.setRowCount(len(rows))
        count=max(1,len(rows))
        for r, (key, value) in enumerate(rows):
            self.table.setItem(r, 0, QTableWidgetItem(str(key)))
            self.table.setItem(r, 1, QTableWidgetItem(str(value)))
            if r and r % 50 == 0: self._set_progress(10 + int(85*r/count), "Updating details…")
        self._set_progress(100, "Ready")
        QTimer.singleShot(300, lambda: self._set_progress(None))


class DetailWindow(InfoWindow):
    """Reusable single-instance non-modal detail table."""
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(620, 430)


class TransducerMapWidget(QWidget):
    """Workstation-style transducer element map. This is deliberately not a chart."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(650, 520)
        self.data = None
        self.parameter = "Element SDR"
        self.show_enabled = True
        self.show_disabled = True
        self._screen_points = []
        self.setMouseTracking(True)
        self.tooltip = ""
        self.display_max = None
        self.display_min = None
        self.scale_mode = "Adaptive"
        self.gamma = 1.0
        self._lut = [self._interpolate_lut(i / 255.0) for i in range(256)]

    def configure(self, data, parameter, show_enabled, show_disabled, display_min=None, display_max=None, scale_mode="Adaptive", gamma=1.0):
        self.data = data
        self.parameter = parameter
        self.show_enabled = show_enabled
        self.show_disabled = show_disabled
        self.display_min = float(display_min) if display_min is not None else None
        self.display_max = float(display_max) if display_max is not None else None
        self.scale_mode = str(scale_mode or "Adaptive")
        self.gamma = max(0.25, min(4.0, float(gamma)))
        self.update()

    @staticmethod
    def _interpolate_lut(level):
        """Workstation-like SDR LUT: deep blue → cyan → green → yellow → red → magenta."""
        level = max(0.0, min(1.0, float(level)))
        stops = [
            (0.00, (20, 38, 170)),
            (0.16, (20, 82, 222)),
            (0.34, (18, 190, 220)),
            (0.52, (40, 205, 102)),
            (0.68, (205, 220, 42)),
            (0.82, (250, 170, 28)),
            (0.94, (238, 58, 38)),
            (0.985, (232, 40, 120)),
            (1.00, (235, 35, 175)),
        ]
        for (x0,c0),(x1,c1) in zip(stops,stops[1:]):
            if level <= x1:
                t=(level-x0)/(x1-x0) if x1>x0 else 0.0
                return QColor(*[round(a+(b-a)*t) for a,b in zip(c0,c1)])
        return QColor(*stops[-1][1])

    def _color(self, level):
        index = max(0, min(255, int(round(float(level) * 255.0))))
        return self._lut[index]

    def _display_color(self, normalized_level):
        """Return the exact colour used by both elements and the legend.

        Keeping gamma and LUT lookup in one function prevents the element map
        and colour bar from drifting apart when display settings change.
        """
        level = min(1.0, max(0.0, float(normalized_level)))
        return self._color(level ** self.gamma)

    def _draw_color_bar(self, painter, bar, lo, hi):
        """Draw a true scan-line gradient from the shared display LUT.

        A one-pixel-wide QImage stretched by QPainter was rendered as a nearly
        solid colour on some Windows/Qt raster backends.  Drawing every screen
        row explicitly avoids that backend-specific scaling path and guarantees
        that the legend matches the element colours exactly.
        """
        top = int(round(bar.top()))
        bottom = int(round(bar.bottom()))
        left = int(round(bar.left()))
        right = int(round(bar.right()))
        height = max(1, bottom - top)
        for y in range(top, bottom + 1):
            normalized = 1.0 - ((y - top) / height)
            painter.setPen(QPen(self._display_color(normalized), 1.0))
            painter.drawLine(left, y, right, y)

        painter.setPen(QPen(QColor(70, 70, 68), 1.0))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(bar)
        painter.setPen(QColor(45, 45, 43))
        for i in range(11):
            normalized = i / 10.0
            y = bar.bottom() - normalized * bar.height()
            value = lo + normalized * (hi - lo)
            painter.drawLine(int(bar.right()), int(y), int(bar.right() + 5), int(y))
            painter.drawText(
                QRectF(bar.right() + 8, y - 9, 48, 18),
                Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
                f"{value:.2f}",
            )

    @staticmethod
    def _robust_limits(values, requested_lo, requested_hi, mode):
        finite = np.asarray(values, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            return 0.0, 1.0
        mode = str(mode or "Adaptive")
        if mode == "Manual":
            lo = float(requested_lo) if requested_lo is not None else float(np.min(finite))
            hi = float(requested_hi) if requested_hi is not None else float(np.max(finite))
        elif mode == "Normalized":
            lo, hi = float(np.percentile(finite, 2.0)), float(np.percentile(finite, 98.0))
        else:  # Adaptive: preserve physical values but suppress isolated extremes.
            lo, hi = float(np.percentile(finite, 1.0)), float(np.percentile(finite, 99.0))
        if not np.isfinite(lo): lo = float(np.min(finite))
        if not np.isfinite(hi): hi = float(np.max(finite))
        if hi <= lo:
            hi = lo + max(abs(lo) * 1e-6, 1e-6)
        return lo, hi

    @staticmethod
    def _ring_radii(xs, ys, cx, cy):
        radii = np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2)
        if radii.size < 8:
            return []
        ordered = np.sort(radii)
        gaps = np.diff(ordered)
        threshold = max(float(np.median(gaps) * 5.0), float((ordered[-1] - ordered[0]) / 80.0))
        split = np.where(gaps > threshold)[0] + 1
        groups = np.split(ordered, split)
        centers = [float(np.median(g)) for g in groups if len(g) >= 3]
        # Avoid drawing every element row as a ring; retain the major radial bands only.
        if len(centers) > 8:
            idx = np.linspace(0, len(centers) - 1, 6).round().astype(int)
            centers = [centers[i] for i in sorted(set(idx.tolist()))]
        return centers

    @staticmethod
    def _sector_angles(xs, ys, cx, cy):
        angles = np.mod(np.arctan2(ys - cy, xs - cx), 2 * np.pi)
        if angles.size < 12:
            return []
        ordered = np.sort(angles)
        wrapped = np.concatenate([ordered, [ordered[0] + 2 * np.pi]])
        gaps = np.diff(wrapped)
        # The six physical sector gaps are the largest angular gaps in the actual cloud.
        count = min(6, len(gaps))
        candidates = np.argsort(gaps)[-count:]
        return sorted(float((wrapped[i] + gaps[i] / 2.0) % (2 * np.pi)) for i in candidates)

    def _phase_dedicated_limits(self):
        values = np.asarray(list(self._phase_relative_by_channel.values()), float)
        values = values[np.isfinite(values)]
        if not values.size:
            return -180.0, 180.0
        peak = max(30.0, float(np.nanpercentile(np.abs(values), 98.0)))
        peak = min(180.0, peak)
        return -peak, peak

    def _phase_color(self, deg: float) -> QColor:
        if not np.isfinite(deg):
            return QColor(150, 150, 150)
        mag = min(1.0, abs(float(deg)) / 180.0)
        if deg >= 0.0:
            return QColor(180 + int(60 * mag), 52 + int(40 * (1.0 - mag)), 52 + int(40 * (1.0 - mag)))
        return QColor(52 + int(40 * (1.0 - mag)), 70 + int(40 * (1.0 - mag)), 180 + int(60 * mag))

    def _draw_phase_dedicated(self, painter: QPainter, map_rect: QRectF):
        center = QPointF(map_rect.left() + map_rect.width() * 0.28, map_rect.center().y())
        max_radius = min(map_rect.width() * 0.55, map_rect.height() * 0.43)
        grid_pen = QPen(QColor(120, 180, 110), 0.9)
        painter.setPen(grid_pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        for frac in (0.2, 0.4, 0.6, 0.8, 1.0):
            rr = max_radius * frac
            painter.drawEllipse(center, rr, rr)
        for offset in range(-5, 6):
            x = center.x() + (offset / 5.0) * max_radius
            painter.drawLine(int(x), int(center.y() - max_radius), int(x), int(center.y() + max_radius))
        for offset in range(-5, 6):
            y = center.y() + (offset / 5.0) * max_radius
            painter.drawLine(int(center.x() - max_radius), int(y), int(center.x() + max_radius), int(y))
        painter.setPen(QPen(QColor(60, 140, 60), 1.6))
        painter.drawLine(int(center.x() - max_radius), int(center.y()), int(center.x() + max_radius), int(center.y()))
        painter.drawLine(int(center.x()), int(center.y() - max_radius), int(center.x()), int(center.y() + max_radius))

        points = []
        for ch in range(1024):
            blade = ch // 64
            if blade not in self.visible_blades:
                continue
            blade_ch = ch % 64
            radius = max_radius * (0.18 + 0.74 * (blade_ch / 63.0))
            rel_deg = self._phase_relative_by_channel.get(ch)
            if rel_deg is None:
                # Keep a full 1024-slot scaffold visible even when the source log only
                # emitted a partial subset (for example CH0-CH3 only).
                sector_theta = np.deg2rad((ch / 1024.0) * 360.0)
                px = center.x() + np.cos(sector_theta) * radius
                py = center.y() - np.sin(sector_theta) * radius
                points.append((px, py, ch, None))
                continue
            mag = min(1.0, abs(rel_deg) / 180.0)
            if rel_deg >= 0.0:
                theta = np.deg2rad(12.0 + 78.0 * mag)
            else:
                theta = np.deg2rad(192.0 + 78.0 * mag)
            theta += (blade - 7.5) * np.deg2rad(0.55)
            px = center.x() + np.cos(theta) * radius
            py = center.y() - np.sin(theta) * radius
            points.append((px, py, ch, rel_deg))

        dot_r = max(2.0, min(3.5, max_radius / 40.0))
        for px, py, ch, rel_deg in points:
            painter.setPen(QPen(QColor(40, 40, 40, 120), 0.4))
            if rel_deg is None:
                painter.setBrush(QBrush(self._missing_color()))
                painter.drawEllipse(QRectF(px - dot_r * 0.55, py - dot_r * 0.55, dot_r * 1.1, dot_r * 1.1))
                continue
            painter.setBrush(QBrush(self._phase_color(rel_deg)))
            painter.drawEllipse(QRectF(px - dot_r, py - dot_r, dot_r * 2.0, dot_r * 2.0))
            self._screen_points.append((px, py, dot_r + 1.0, ch, rel_deg))
            if self.selected_channel == ch:
                painter.setPen(QPen(QColor(10, 10, 10), 2.0))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawEllipse(QRectF(px - dot_r - 3, py - dot_r - 3, 2 * dot_r + 6, 2 * dot_r + 6))

        painter.setPen(QColor(45, 45, 43))
        phase_label = 'wrapped sonication phase' if self.parameter.startswith('Sonication Phase') else 'relative phase'
        painter.drawText(QRectF(map_rect.left(), map_rect.bottom() + 4, map_rect.width(), 18), Qt.AlignmentFlag.AlignCenter, f'Phase phasor · {self._phase_source_kind} · {phase_label} · red +phase / blue -phase')
        legend = QRectF(map_rect.right() - 190, map_rect.top() + 8, 180, 66)
        painter.setPen(QPen(QColor(130,130,128), 0.8))
        painter.setBrush(QColor(248,248,246,235))
        painter.drawRoundedRect(legend, 6, 6)
        painter.setPen(QColor(45,45,43))
        painter.drawText(QRectF(legend.left() + 8, legend.top() + 6, legend.width() - 16, 16), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, 'Phase phasor display')
        painter.drawText(QRectF(legend.left() + 26, legend.top() + 24, legend.width() - 32, 14), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, 'Positive relative phase')
        painter.drawText(QRectF(legend.left() + 26, legend.top() + 42, legend.width() - 32, 14), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, 'Negative relative phase')
        painter.setPen(QPen(QColor(40,40,40,120), 0.5))
        painter.setBrush(QBrush(self._phase_color(+135.0)))
        painter.drawEllipse(QRectF(legend.left() + 8, legend.top() + 26, 10, 10))
        painter.setBrush(QBrush(self._phase_color(-135.0)))
        painter.drawEllipse(QRectF(legend.left() + 8, legend.top() + 44, 10, 10))

    def paintEvent(self, _event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        # The treatment workstation uses a neutral light canvas around the element field.
        painter.fillRect(self.rect(), QColor(226, 226, 224))
        self._screen_points = []
        if not self.data or not self.data.elements:
            painter.setPen(QColor(45, 45, 45))
            msg = self.data.error if self.data and self.data.error else "No SkullMeasures data"
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, msg)
            return

        rows = []
        for el in self.data.elements:
            if el.enabled and not self.show_enabled:
                continue
            if not el.enabled and not self.show_disabled:
                continue
            x = el.values.get("Element X", float("nan"))
            y = el.values.get("Element Y", float("nan"))
            value = el.values.get(self.parameter, float("nan"))
            if np.isfinite(x) and np.isfinite(y):
                rows.append((el, float(x), float(y), float(value)))
        if not rows:
            painter.setPen(QColor(45, 45, 45))
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "No elements match the display filters")
            return

        vals = np.asarray([r[3] for r in rows if np.isfinite(r[3])], float)
        lo, hi = self._robust_limits(vals, self.display_min, self.display_max, self.scale_mode)
        if self.parameter == "Element SDR" and self.scale_mode != "Manual":
            lo, hi = 0.0, 1.0

        # Reserve a compact lower-right strip for the vertical colour legend.
        map_rect = QRectF(26, 18, max(120, self.width() - 150), max(120, self.height() - 42))
        xs = np.asarray([r[1] for r in rows], float)
        ys = np.asarray([r[2] for r in rows], float)
        xmin, xmax = float(xs.min()), float(xs.max())
        ymin, ymax = float(ys.min()), float(ys.max())
        span = max(xmax - xmin, ymax - ymin, 1.0)
        scale = min(map_rect.width(), map_rect.height()) / span * 0.94
        cx, cy = (xmin + xmax) / 2.0, (ymin + ymax) / 2.0
        sx, sy = map_rect.center().x(), map_rect.center().y()

        # Estimate element pitch from the real coordinate cloud, then size the markers
        # to match the dense dot field of the treatment workstation.
        nearest = []
        if len(rows) > 1:
            sample = np.column_stack((xs, ys))
            stride = max(1, len(sample) // 180)
            for pt in sample[::stride]:
                d2 = np.sum((sample - pt) ** 2, axis=1)
                d2[d2 == 0] = np.inf
                nearest.append(float(np.sqrt(np.min(d2))))
        pitch = float(np.median(nearest)) if nearest else span / 40.0
        radius = max(1.8, min(4.4, pitch * scale * 0.31))

        # Geometry-derived guides: use the real radial bands and physical sector gaps.
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(QColor(178, 178, 174), 0.65))
        ring_radii = self._ring_radii(xs, ys, cx, cy)
        for physical_radius in ring_radii:
            rr = physical_radius * scale
            painter.drawEllipse(map_rect.center(), rr, rr)
        outer_physical = float(np.max(np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2)))
        outer = outer_physical * scale
        painter.setPen(QPen(QColor(190, 190, 186), 0.55))
        for angle in self._sector_angles(xs, ys, cx, cy):
            x2 = sx + np.cos(angle) * outer
            y2 = sy - np.sin(angle) * outer
            painter.drawLine(int(sx), int(sy), int(x2), int(y2))

        finite_rows = [r for r in rows if np.isfinite(r[3]) and r[0].enabled]
        max_element = max(finite_rows, key=lambda r: r[3]) if finite_rows else None
        for el, x, y, value in rows:
            px = sx + (x - cx) * scale
            py = sy - (y - cy) * scale
            radial_fraction = min(1.0, max(0.0, np.hypot(x - cx, y - cy) / max(outer_physical, 1e-9)))
            point_radius = radius * (1.12 - 0.24 * radial_fraction)
            if el.enabled:
                level = (value - lo) / (hi - lo) if np.isfinite(value) else 0.0
                level = min(1.0, max(0.0, level))
                color = self._display_color(level)
            else:
                color = QColor(145, 145, 142)
            painter.setPen(QPen(QColor(95, 95, 92), 0.30))
            painter.setBrush(QBrush(color))
            painter.drawEllipse(QRectF(px - point_radius, py - point_radius, 2 * point_radius, 2 * point_radius))
            self._screen_points.append((px, py, point_radius, el, value))

            # Workstation-like hot-element locator: a compact magenta square over max SDR.
            if max_element is not None and el.number == max_element[0].number:
                painter.setPen(QPen(QColor(245, 210, 235), 0.9))
                painter.setBrush(QBrush(QColor(236, 22, 166)))
                side = max(4.0, radius * 1.55)
                painter.drawRect(QRectF(px - side / 2, py - side / 2, side, side))

        # Vertical workstation-style colour scale.
        bar_h = min(260.0, max(150.0, self.height() * 0.46))
        bar = QRectF(self.width() - 77, self.height() - bar_h - 48, 22, bar_h)
        self._draw_color_bar(painter, bar, lo, hi)

        # Small selector/value boxes mimic the reference console without pretending to
        # reproduce proprietary controls.
        badge = QRectF(bar.left() - 3, bar.top() - 34, bar.width() + 8, 25)
        painter.setPen(QPen(QColor(95, 95, 90), 1.0))
        painter.setBrush(QBrush(QColor(245, 230, 205)))
        painter.drawRect(badge)
        painter.drawText(badge, Qt.AlignmentFlag.AlignCenter, "1")
        zero_badge = QRectF(bar.left() - 3, bar.bottom() + 8, bar.width() + 8, 25)
        painter.drawRect(zero_badge)
        painter.drawText(zero_badge, Qt.AlignmentFlag.AlignCenter, f"{lo:.0f}")

        painter.setPen(QColor(45, 45, 43))
        painter.drawText(QRectF(8, 8, 190, 24), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                         self.parameter)
    def mouseMoveEvent(self, event):
        x,y=event.position().x(),event.position().y()
        hit=None
        for px,py,r,el,value in self._screen_points:
            if (px-x)**2+(py-y)**2 <= (r+4)**2:
                hit=(el,value); break
        if hit:
            el,value=hit
            self.setToolTip(f"Element {el.number}\n{self.parameter}: {value:.5g}\nEnabled: {'Yes' if el.enabled else 'No'}\nFailure reason: {el.failure_reason}")
        else:
            self.setToolTip("")
        super().mouseMoveEvent(event)


class SonicationElementMapWidget(QWidget):
    """Workstation-inspired 1024-element sonication map (tile or interactive 3-D umbrella)."""
    elementClicked = Signal(int)
    viewChanged = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(680, 460)
        self.snapshot = None
        self.parameter = "Amplitude (1024 measured)"
        self.layout_mode = "Tile 16×64"
        self._phase_relative_by_channel = {}
        self._phase_amplitude_by_channel = {}
        self._phase_source_kind = "none"
        self._screen_points = []
        self._value_by_channel = {}
        # R0107 channel-state semantics:
        # ACT amplitude=0 is a sonication-specific zero-amplitude state and is NOT
        # classified as disabled/defect. Disabled and defect are INI-defined only.
        self.act_zero_channels = set()
        self.act_zero_reasons = {}
        self.disabled_channels = set()
        self.defect_channels = set()
        self.channel_state_sources = {}
        # Physical channel geometry from SkullMeasures Element X/Y/Z.
        # Phase-dedicated uses the X-Z projection because the transducer bowl
        # appears as the expected ellipse in side projection; no synthetic circle.
        self.channel_geometry_xyz = {}
        self.geometry_source = ""
        self.phase_focus_result = None
        self.visible_blades = set(range(16))
        self.visible_channels = set(range(1024))
        self.selected_channel = None
        self.umbrella_yaw_deg = 0.0
        self.umbrella_pitch_deg = 18.0
        self.umbrella_zoom = 1.0
        self.umbrella_projection = "Perspective"
        self._umbrella_drag_last = None
        self._umbrella_press_pos = None
        self._umbrella_press_channel = None
        self._umbrella_dragged = False
        self._lut = [TransducerMapWidget._interpolate_lut(i / 255.0) for i in range(256)]
        self.setMouseTracking(True)

    def configure(self, snapshot, parameter: str, layout_mode: str):
        self.snapshot = snapshot
        self.parameter = str(parameter or "Amplitude (1024 measured)")
        self.layout_mode = str(layout_mode or "Tile 16×64")
        value_by_channel = {}
        phase_rad_by_channel = {}
        phase_amp_by_channel = {}
        phase_source_kind = "none"
        if snapshot is not None:
            for value in getattr(snapshot, 'values', []) or []:
                ch = int(getattr(value, 'channel', -1))
                logical_phase = getattr(value, 'logical_phase_rad', None)
                measured_phase = getattr(value, 'measured_phase_rad', None)
                sonication_phase = getattr(value, 'sonication_phase_rad', None)
                if self.parameter.startswith("Amplitude (1024"):
                    raw = getattr(value, 'measured_amplitude', None)
                elif self.parameter.startswith("Sonication Phase"):
                    raw = sonication_phase
                elif self.parameter.startswith("Channel Calibration Phase"):
                    raw = measured_phase
                elif self.parameter.startswith("Logical amplitude"):
                    raw = getattr(value, 'logical_amplitude', None)
                else:
                    raw = logical_phase
                if self.parameter.startswith("Sonication Phase"):
                    phase_for_map = sonication_phase
                elif self.parameter.startswith("Channel Calibration Phase"):
                    phase_for_map = measured_phase
                else:
                    phase_for_map = logical_phase
                if phase_for_map is not None:
                    try:
                        phase_rad_by_channel[ch] = float(phase_for_map)
                        if self.parameter.startswith("Sonication Phase"):
                            phase_source_kind = getattr(value,'sonication_phase_method',None) or "1024-channel sonication phase"
                            amp_for_phase = getattr(value, 'logical_amplitude', None) or getattr(value,'measured_amplitude',None)
                        elif self.parameter.startswith("Channel Calibration Phase"):
                            phase_source_kind = "1024-channel ChannelMeasure calibration phase"
                            amp_for_phase = getattr(value, 'measured_amplitude', None)
                        else:
                            phase_source_kind = "Observed Sonication_Brain logical phase"
                            amp_for_phase = getattr(value, 'logical_amplitude', None)
                        if amp_for_phase is not None:
                            phase_amp_by_channel[ch] = float(amp_for_phase)
                    except Exception: pass
                if raw is not None:
                    try: value_by_channel[ch] = float(raw)
                    except Exception: pass
        self._value_by_channel = value_by_channel
        self._phase_relative_by_channel = {}
        self._phase_amplitude_by_channel = phase_amp_by_channel
        self._phase_source_kind = phase_source_kind
        if phase_rad_by_channel:
            ordered_channels = sorted(phase_rad_by_channel)
            phase_arr = np.asarray([phase_rad_by_channel[ch] for ch in ordered_channels], float)
            if phase_arr.size:
                if self.parameter.startswith("Sonication Phase"):
                    # R0088: this phase is already reconstructed from SkullMeasures
                    # Total Phase Shift and aligned to the observed logical-phase
                    # reference. Preserve that reference for the phasor display.
                    plotted = np.angle(np.exp(1j * phase_arr))
                else:
                    ref = float(np.angle(np.nanmean(np.exp(1j * phase_arr))))
                    plotted = np.angle(np.exp(1j * (phase_arr - ref)))
                self._phase_relative_by_channel = {
                    int(ch): float(val) * 180.0 / np.pi
                    for ch, val in zip(ordered_channels, plotted)
                }
        self.update()

    def set_channel_states(self, *, act_zero=None, act_reasons=None, disabled=None, defect=None, sources=None):
        self.act_zero_channels = {int(v) for v in (act_zero or []) if 0 <= int(v) < 1024}
        self.act_zero_reasons = dict(act_reasons or {})
        self.disabled_channels = {int(v) for v in (disabled or []) if 0 <= int(v) < 1024}
        self.defect_channels = {int(v) for v in (defect or []) if 0 <= int(v) < 1024}
        self.channel_state_sources = dict(sources or {})
        self.update()

    def channel_state(self, channel: int) -> str:
        ch = int(channel)
        states = []
        if ch in self.defect_channels:
            states.append("DEFECT")
        if ch in self.disabled_channels:
            states.append("DISABLED")
        if ch in self.act_zero_channels:
            states.append("ACT AMPLITUDE=0")
        return " + ".join(states) if states else "ACTIVE"

    def set_channel_geometry(self, xyz_by_channel=None, source=""):
        clean={}
        for ch,xyz in dict(xyz_by_channel or {}).items():
            try:
                vals=tuple(float(v) for v in xyz)
                if len(vals)==3 and all(np.isfinite(v) for v in vals):
                    clean[int(ch)]=vals
            except Exception:
                pass
        self.channel_geometry_xyz=clean
        self.geometry_source=str(source or "")
        self.update()

    def set_phase_focus_result(self, result):
        self.phase_focus_result = result
        self.update()

    def set_visible_blades(self, blades):
        self.visible_blades = {int(b) for b in blades if 0 <= int(b) < 16}
        self.update()

    def set_visible_channels(self, channels):
        self.visible_channels={int(ch) for ch in channels if 0<=int(ch)<1024}
        self.update()

    def set_umbrella_projection(self, projection: str):
        projection=str(projection or "Perspective")
        if projection not in {"Perspective","Top XY","Front XZ","Side YZ"}:
            projection="Perspective"
        self.umbrella_projection=projection
        # Named views are exact orthographic anatomical/transducer-axis projections.
        # Perspective keeps the free yaw/pitch camera.
        self.setToolTip(
            f"3-D projection: {self.umbrella_projection} · left-drag to rotate · wheel to zoom · click to select"
        )
        self.update()

    def reset_umbrella_view(self):
        self.umbrella_yaw_deg=35.0
        self.umbrella_pitch_deg=24.0
        self.umbrella_zoom=1.0
        self.umbrella_projection="Perspective"
        self._umbrella_drag_last=None
        self._umbrella_press_pos=None
        self._umbrella_press_channel=None
        self._umbrella_dragged=False
        self.viewChanged.emit("Perspective")
        self.update()

    @staticmethod
    def _named_projection(points: np.ndarray, projection: str):
        """Return screen-X, screen-Y and depth for exact named views.

        Exported element coordinates are kept in their native X/Y/Z axes:
          Top XY   -> screen X/Y, depth Z
          Front XZ -> screen X/Z, depth -Y
          Side YZ  -> screen Y/Z, depth X
        """
        if projection=="Top XY":
            return points[:,0], points[:,1], points[:,2]
        if projection=="Front XZ":
            return points[:,0], points[:,2], -points[:,1]
        if projection=="Side YZ":
            return points[:,1], points[:,2], points[:,0]
        raise ValueError(projection)

    def _perspective_projection(self, points: np.ndarray):
        # Free camera: yaw around transducer Z, then pitch around camera X.
        yaw=np.deg2rad(self.umbrella_yaw_deg)
        pitch=np.deg2rad(self.umbrella_pitch_deg)
        cy,sy=np.cos(yaw),np.sin(yaw)
        cp,sp=np.cos(pitch),np.sin(pitch)
        rz=np.asarray([[cy,-sy,0.0],[sy,cy,0.0],[0.0,0.0,1.0]],float)
        rx=np.asarray([[1.0,0.0,0.0],[0.0,cp,-sp],[0.0,sp,cp]],float)
        q=points@rz.T@rx.T
        # Camera looks along -Y after rotation; screen is X/Z.
        sx=q[:,0]
        sy_screen=q[:,2]
        depth=-q[:,1]
        span=max(float(np.ptp(depth)),1e-6)
        d0=float(np.nanmean(depth))
        perspective=1.0+0.18*((depth-d0)/span)
        return sx*perspective, sy_screen*perspective, depth

    def _umbrella_project(self, channels, map_rect):
        """Project exported Element X/Y/Z with correct named planes and a free 3-D camera."""
        geom=self.channel_geometry_xyz
        valid=[ch for ch in channels if ch in geom]
        if len(valid)<32:
            return None
        pts=np.asarray([geom[ch] for ch in valid],float)
        center=np.nanmean(pts,axis=0)
        centered=pts-center
        if self.umbrella_projection in {"Top XY","Front XZ","Side YZ"}:
            x,y,depth=self._named_projection(centered,self.umbrella_projection)
            projection_kind="Orthographic"
        else:
            x,y,depth=self._perspective_projection(centered)
            projection_kind="Perspective"
        xspan=max(float(np.ptp(x)),1e-9)
        yspan=max(float(np.ptp(y)),1e-9)
        # One common scale preserves the true aspect ratio of the chosen projection.
        scale=min(map_rect.width()/xspan,map_rect.height()/yspan)*0.84*max(0.20,min(6.0,self.umbrella_zoom))
        px=map_rect.center().x()+(x-float(np.nanmean(x)))*scale
        py=map_rect.center().y()-(y-float(np.nanmean(y)))*scale
        return valid,px,py,np.asarray(depth,float),scale,projection_kind,center


    def _umbrella_project_points(self, points_xyz, map_rect):
        """Project arbitrary physical XYZ through the exact active 3-D camera."""
        geom=self.channel_geometry_xyz
        ref=np.asarray(list(geom.values()),float) if geom else np.empty((0,3),float)
        pts=np.asarray(points_xyz,float)
        if ref.ndim!=2 or ref.shape[0]<32 or ref.shape[1]!=3 or pts.ndim!=2 or pts.shape[1]!=3:
            return None
        center=np.nanmean(ref,axis=0); refc=ref-center; q=pts-center
        if self.umbrella_projection in {"Top XY","Front XZ","Side YZ"}:
            rx,ry,_=self._named_projection(refc,self.umbrella_projection)
            qx,qy,qd=self._named_projection(q,self.umbrella_projection)
        else:
            rx,ry,_=self._perspective_projection(refc)
            qx,qy,qd=self._perspective_projection(q)
        xspan=max(float(np.ptp(rx)),1e-9); yspan=max(float(np.ptp(ry)),1e-9)
        scale=min(map_rect.width()/xspan,map_rect.height()/yspan)*0.84*max(0.20,min(6.0,self.umbrella_zoom))
        px=map_rect.center().x()+(qx-float(np.nanmean(rx)))*scale
        py=map_rect.center().y()-(qy-float(np.nanmean(ry)))*scale
        return np.asarray(px,float),np.asarray(py,float),np.asarray(qd,float)

    def set_selected_channel(self, channel):
        try:
            ch = int(channel)
        except Exception:
            ch = -1
        self.selected_channel = ch if 0 <= ch < 1024 else None
        self.update()

    def _color(self, level: float) -> QColor:
        index = max(0, min(255, int(round(float(level) * 255.0))))
        return self._lut[index]

    @staticmethod
    def _missing_color() -> QColor:
        # Neutral workstation-like placeholder for declared-but-unlogged element slots.
        return QColor(212, 212, 210)

    def _phase_dedicated_limits(self):
        values = np.asarray(list(self._phase_relative_by_channel.values()), float)
        values = values[np.isfinite(values)]
        if not values.size:
            return -180.0, 180.0
        peak = max(30.0, float(np.nanpercentile(np.abs(values), 98.0)))
        peak = min(180.0, peak)
        return -peak, peak

    def _phase_color(self, deg: float) -> QColor:
        if not np.isfinite(deg):
            return QColor(150, 150, 150)
        mag = min(1.0, abs(float(deg)) / 180.0)
        if deg >= 0.0:
            return QColor(180 + int(60 * mag), 52 + int(40 * (1.0 - mag)), 52 + int(40 * (1.0 - mag)))
        return QColor(52 + int(40 * (1.0 - mag)), 70 + int(40 * (1.0 - mag)), 180 + int(60 * mag))

    def _draw_phase_dedicated(self, painter: QPainter, map_rect: QRectF):
        """Geometry-derived phase view using real SkullMeasures Element X/Y/Z.

        The transducer is a curved 3-D bowl.  A front X-Y projection is nearly
        circular; the workstation-style side projection is X-Z and therefore
        elliptical.  Channel position comes only from exported geometry.
        Phase controls colour only.
        """
        geom=self.channel_geometry_xyz
        if len(geom) < 32:
            painter.setPen(QColor(45,45,43))
            painter.drawText(
                map_rect,Qt.AlignmentFlag.AlignCenter,
                "Physical geometry unavailable\nSkullMeasures Element X/Y/Z required"
            )
            return

        channels=[ch for ch in sorted(geom) if (ch//64) in self.visible_blades]
        if not channels:
            painter.setPen(QColor(45,45,43))
            painter.drawText(map_rect,Qt.AlignmentFlag.AlignCenter,"No visible blades")
            return

        # X-Z is the physically meaningful side projection of the bowl.
        xs=np.asarray([geom[ch][0] for ch in channels],float)
        zs=np.asarray([geom[ch][2] for ch in channels],float)
        xmin,xmax=float(np.min(xs)),float(np.max(xs))
        zmin,zmax=float(np.min(zs)),float(np.max(zs))
        xspan=max(xmax-xmin,1e-9); zspan=max(zmax-zmin,1e-9)

        plot=QRectF(map_rect.left()+28,map_rect.top()+22,
                    max(100.0,map_rect.width()-56),max(100.0,map_rect.height()-62))
        # One common mm->pixel scale is essential: it preserves the true ellipse
        # aspect ratio instead of stretching X and Z independently.
        scale=min(plot.width()/xspan,plot.height()/zspan)*0.92
        cx=(xmin+xmax)/2.0; cz=(zmin+zmax)/2.0
        sx=plot.center().x(); sz=plot.center().y()

        pxs=sx+(xs-cx)*scale
        pzs=sz-(zs-cz)*scale

        # Geometry envelope / center axes.
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(QColor(150,175,145),0.8))
        envelope=QRectF(
            sx-xspan*scale/2.0, sz-zspan*scale/2.0,
            xspan*scale, zspan*scale
        )
        painter.drawEllipse(envelope)
        painter.setPen(QPen(QColor(175,175,172),0.55))
        painter.drawLine(int(envelope.left()),int(sz),int(envelope.right()),int(sz))
        painter.drawLine(int(sx),int(envelope.top()),int(sx),int(envelope.bottom()))

        # Major/minor guide ellipses use the same physical X/Z ratio.
        painter.setPen(QPen(QColor(185,185,181),0.45))
        for frac in (0.25,0.5,0.75):
            painter.drawEllipse(QRectF(
                sx-envelope.width()*frac/2.0,
                sz-envelope.height()*frac/2.0,
                envelope.width()*frac,
                envelope.height()*frac
            ))

        # Marker size from nearest physical spacing in X-Z.
        pts=np.column_stack([xs,zs])
        nearest=[]
        stride=max(1,len(pts)//160)
        for pt in pts[::stride]:
            d2=np.sum((pts-pt)**2,axis=1); d2[d2==0]=np.inf
            nearest.append(float(np.sqrt(np.min(d2))))
        pitch=float(np.median(nearest)) if nearest else min(xspan,zspan)/32.0
        dot_r=max(1.8,min(4.2,pitch*scale*0.34))

        self._screen_points=[]
        for ch,x,z,px,pz in zip(channels,xs,zs,pxs,pzs):
            rel_deg=self._phase_relative_by_channel.get(ch)
            ini_black=ch in self.disabled_channels or ch in self.defect_channels
            act_zero=ch in self.act_zero_channels

            painter.setPen(QPen(QColor(40,40,40,120),0.35))
            if ini_black:
                painter.setBrush(QBrush(QColor(0,0,0)))
            elif rel_deg is None:
                painter.setBrush(QBrush(self._missing_color()))
            else:
                painter.setBrush(QBrush(self._phase_color(rel_deg)))
            painter.drawEllipse(QRectF(px-dot_r,pz-dot_r,2*dot_r,2*dot_r))

            if act_zero and not ini_black:
                painter.setPen(QPen(QColor(248,248,248),1.2))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                rr=max(1.0,dot_r*0.45)
                painter.drawEllipse(QRectF(px-rr,pz-rr,2*rr,2*rr))

            self._screen_points.append((float(px),float(pz),dot_r+1.5,ch,
                                        rel_deg if rel_deg is not None else np.nan))
            if self.selected_channel==ch:
                painter.setPen(QPen(QColor(255,255,255) if ini_black else QColor(10,10,10),2.0))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawEllipse(QRectF(px-dot_r-3,pz-dot_r-3,2*dot_r+6,2*dot_r+6))

        # Geometric focus and phase-derived focus are overlaid in the same
        # physical X-Z coordinate system as the element geometry.
        focus_result=getattr(self,"phase_focus_result",None)
        if focus_result is not None:
            gf=getattr(focus_result,"geometric_focus_xyz_mm",None)
            pf=getattr(focus_result,"phase_focus_xyz_mm",None)
            if gf is not None:
                gx=sx+(float(gf[0])-cx)*scale
                gz=sz-(float(gf[2])-cz)*scale
                painter.setPen(QPen(QColor(40,180,235),2.0))
                painter.drawLine(int(gx-7),int(gz),int(gx+7),int(gz))
                painter.drawLine(int(gx),int(gz-7),int(gx),int(gz+7))
                painter.drawText(QRectF(gx+8,gz-10,145,18),Qt.AlignmentFlag.AlignLeft,"Geometric focus")
            if pf is not None:
                fx=sx+(float(pf[0])-cx)*scale
                fz=sz-(float(pf[2])-cz)*scale
                painter.setPen(QPen(QColor(220,70,55),2.2))
                painter.setBrush(QBrush(QColor(220,70,55)))
                painter.drawEllipse(QRectF(fx-4,fz-4,8,8))
                painter.drawText(QRectF(fx+8,fz-10,175,18),Qt.AlignmentFlag.AlignLeft,"Phase-derived focus")
                if gf is not None:
                    painter.setPen(QPen(QColor(220,70,55),1.5))
                    painter.drawLine(int(gx),int(gz),int(fx),int(fz))

        painter.setPen(QColor(45,45,43))
        source=self.geometry_source or "SkullMeasures"
        ratio=xspan/zspan if zspan>1e-9 else float("nan")
        painter.drawText(
            QRectF(map_rect.left(),map_rect.bottom()-22,map_rect.width(),20),
            Qt.AlignmentFlag.AlignCenter,
            f"Physical X-Z projection · geometry={source} · X/Z span={ratio:.2f}:1 · "
            f"black=INI disabled/defect · white center=ACT amplitude=0"
        )


    def _limits(self):
        values = np.asarray(list(self._value_by_channel.values()), float)
        values = values[np.isfinite(values)]
        if not values.size:
            return 0.0, 1.0
        if 'phase' in self.parameter.lower():
            peak = float(np.nanpercentile(np.abs(values), 99.0))
            peak = max(peak, 1e-6)
            return -peak, peak
        lo = float(np.nanpercentile(values, 1.0))
        hi = float(np.nanpercentile(values, 99.0))
        if not np.isfinite(lo):
            lo = float(np.nanmin(values))
        if not np.isfinite(hi):
            hi = float(np.nanmax(values))
        if hi <= lo:
            hi = lo + max(abs(lo) * 1e-6, 1e-6)
        return lo, hi

    def _draw_color_bar(self, painter: QPainter, bar: QRectF, lo: float, hi: float):
        top = int(round(bar.top()))
        bottom = int(round(bar.bottom()))
        left = int(round(bar.left()))
        right = int(round(bar.right()))
        height = max(1, bottom - top)
        for y in range(top, bottom + 1):
            normalized = 1.0 - ((y - top) / height)
            painter.setPen(QPen(self._color(normalized), 1.0))
            painter.drawLine(left, y, right, y)
        painter.setPen(QPen(QColor(80, 80, 78), 1.0))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(bar)
        painter.setPen(QColor(45, 45, 43))
        for i in range(11):
            normalized = i / 10.0
            y = bar.bottom() - normalized * bar.height()
            value = lo + normalized * (hi - lo)
            painter.drawLine(int(bar.right()), int(y), int(bar.right() + 5), int(y))
            painter.drawText(QRectF(bar.right() + 8, y - 9, 72, 18), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, f"{value:.3g}")

    def paintEvent(self, _event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.fillRect(self.rect(), QColor(226, 226, 224))
        self._screen_points = []
        if self.snapshot is None or not self._value_by_channel:
            painter.setPen(QColor(45, 45, 45))
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, 'No sonication element values loaded')
            return
        lo, hi = self._limits()
        phase_mode = self.layout_mode.startswith('Phase dedicated')
        if phase_mode:
            lo, hi = self._phase_dedicated_limits()
        map_rect = QRectF(24, 18, max(120, self.width() - 140), max(120, self.height() - 42))
        bar_h = min(260.0, max(150.0, self.height() * 0.46))
        bar = QRectF(self.width() - 82, self.height() - bar_h - 48, 22, bar_h)
        title = f"{self.parameter} — {self.layout_mode}"
        painter.setPen(QColor(45, 45, 43))
        painter.drawText(QRectF(8, 6, self.width() - 96, 22), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, title)

        if phase_mode:
            self._draw_phase_dedicated(painter, map_rect)
        elif self.layout_mode.startswith('Tile'):
            cols, rows = 16, 64
            cell_w = map_rect.width() / cols
            cell_h = map_rect.height() / rows
            painter.setPen(QPen(QColor(180, 180, 176), 0.5))
            for blade in range(cols + 1):
                x = map_rect.left() + blade * cell_w
                painter.drawLine(int(x), int(map_rect.top()), int(x), int(map_rect.bottom()))
            for row in range(rows + 1):
                y = map_rect.top() + row * cell_h
                painter.drawLine(int(map_rect.left()), int(y), int(map_rect.right()), int(y))
            for ch in range(1024):
                blade = ch // 64
                if blade not in self.visible_blades:
                    continue
                blade_ch = ch % 64
                x = map_rect.left() + blade * cell_w
                y = map_rect.top() + blade_ch * cell_h
                value = self._value_by_channel.get(ch)
                ini_black = ch in self.disabled_channels or ch in self.defect_channels
                if ini_black:
                    painter.fillRect(QRectF(x + 0.5, y + 0.5, max(1.0, cell_w - 1.0), max(1.0, cell_h - 1.0)), QBrush(QColor(0,0,0)))
                elif value is None:
                    painter.fillRect(QRectF(x + 0.5, y + 0.5, max(1.0, cell_w - 1.0), max(1.0, cell_h - 1.0)), QBrush(self._missing_color()))
                else:
                    level = min(1.0, max(0.0, (value - lo) / (hi - lo)))
                    painter.fillRect(QRectF(x + 0.5, y + 0.5, max(1.0, cell_w - 1.0), max(1.0, cell_h - 1.0)), QBrush(self._color(level)))
                cx = x + cell_w * 0.5
                cy = y + cell_h * 0.5
                if value is not None or ini_black or ch in self.act_zero_channels:
                    self._screen_points.append((cx, cy, max(3.0, min(cell_w, cell_h) * 0.45), ch, value if value is not None else np.nan))
                if ch in self.act_zero_channels and not ini_black:
                    painter.setPen(QPen(QColor(245,245,245),1.0))
                    painter.drawEllipse(QRectF(cx-1.5,cy-1.5,3,3))
                if self.selected_channel == ch:
                    painter.setPen(QPen(QColor(20, 20, 20), 2.0))
                    painter.setBrush(Qt.BrushStyle.NoBrush)
                    painter.drawRect(QRectF(x + 0.5, y + 0.5, max(1.0, cell_w - 1.0), max(1.0, cell_h - 1.0)))
                    painter.setPen(QPen(QColor(180, 180, 176), 0.5))
            painter.setPen(QColor(55, 55, 53))
            for blade in range(cols):
                x = map_rect.left() + blade * cell_w + cell_w * 0.5
                painter.drawText(QRectF(x - 16, map_rect.top() - 16, 32, 14), Qt.AlignmentFlag.AlignCenter, str(blade + 1))
            for row in range(0, rows, 8):
                y = map_rect.top() + row * cell_h
                painter.drawText(QRectF(map_rect.left() - 22, y - 8, 20, 16), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, str(row))
            painter.drawText(QRectF(map_rect.left(), map_rect.bottom() + 4, map_rect.width(), 18), Qt.AlignmentFlag.AlignCenter, 'Blade 1–16 (columns) · Blade CH 0–63 (rows)')
        else:
            channels=[ch for ch in range(1024) if (ch//64) in self.visible_blades and ch in self.visible_channels]
            projected=self._umbrella_project(channels,map_rect)
            if projected is None:
                painter.setPen(QColor(45,45,43))
                painter.drawText(map_rect,Qt.AlignmentFlag.AlignCenter,
                    "3-D element geometry unavailable\nSkullMeasures Element X/Y/Z required")
            else:
                channels,pxs,pys,depths,scale,projection_kind,center_xyz=projected
                idx_by_ch={ch:i for i,ch in enumerate(channels)}
                dmin=float(np.nanmin(depths)); dmax=float(np.nanmax(depths)); dspan=max(dmax-dmin,1e-9)

                # Wire each physical blade in channel order.  This provides actual 3-D
                # shape/depth cues; dots alone made rotations of the bowl look unchanged.
                for blade in sorted(self.visible_blades):
                    blade_channels=[ch for ch in range(blade*64,(blade+1)*64) if ch in idx_by_ch]
                    if len(blade_channels)<2:
                        continue
                    painter.setPen(QPen(QColor(95,105,112,95),0.75))
                    for ca,cb in zip(blade_channels[:-1],blade_channels[1:]):
                        ia=idx_by_ch[ca]; ib=idx_by_ch[cb]
                        painter.drawLine(int(pxs[ia]),int(pys[ia]),int(pxs[ib]),int(pys[ib]))

                # Depth order and depth-dependent point size make rotation visible.
                order=np.argsort(depths)
                self._screen_points=[]
                for oi in order:
                    oi=int(oi); ch=channels[oi]
                    px=float(pxs[oi]); py=float(pys[oi])
                    value=self._value_by_channel.get(ch)
                    ini_black=ch in self.disabled_channels or ch in self.defect_channels
                    depth_norm=(float(depths[oi])-dmin)/dspan
                    dot_r=max(1.5,min(6.5,(1.8+2.0*depth_norm)*self.umbrella_zoom))
                    alpha=int(115+140*depth_norm)
                    painter.setPen(QPen(QColor(40,40,38,max(70,alpha)),0.45))
                    if ini_black:
                        color=QColor(0,0,0,alpha)
                    elif value is None:
                        color=self._missing_color(); color.setAlpha(alpha)
                    else:
                        level=min(1.0,max(0.0,(value-lo)/(hi-lo)))
                        color=self._color(level); color.setAlpha(alpha)
                    painter.setBrush(QBrush(color))
                    painter.drawEllipse(QRectF(px-dot_r,py-dot_r,2*dot_r,2*dot_r))
                    self._screen_points.append((px,py,max(4.0,dot_r+2.5),ch,value if value is not None else np.nan))
                    if ch in self.act_zero_channels and not ini_black:
                        painter.setPen(QPen(QColor(250,250,250,alpha),1.1)); painter.setBrush(Qt.BrushStyle.NoBrush)
                        rr=max(1.0,dot_r*0.45); painter.drawEllipse(QRectF(px-rr,py-rr,2*rr,2*rr))
                    if self.selected_channel==ch:
                        painter.setPen(QPen(QColor(20,20,20),2.2)); painter.setBrush(Qt.BrushStyle.NoBrush)
                        painter.drawEllipse(QRectF(px-dot_r-4,py-dot_r-4,2*dot_r+8,2*dot_r+8))

                # Focus uses the identical physical camera as the 1024 elements.
                # This prevents a 2-D focus marker from appearing stationary while
                # the umbrella is rotated or switched between orthographic planes.
                focus_result=getattr(self,"phase_focus_result",None)
                if focus_result is not None:
                    pts=[]; names=[]
                    gf=getattr(focus_result,"geometric_focus_xyz_mm",None)
                    pf=getattr(focus_result,"phase_focus_xyz_mm",None)
                    if gf is not None:
                        pts.append(tuple(float(v) for v in gf)); names.append("reference")
                    if pf is not None:
                        pts.append(tuple(float(v) for v in pf)); names.append("phase")
                    projected_focus=self._umbrella_project_points(np.asarray(pts,float),map_rect) if pts else None
                    if projected_focus is not None:
                        fxp,fyp,_=projected_focus
                        coords={name:(float(fxp[i]),float(fyp[i])) for i,name in enumerate(names)}
                        if "reference" in coords:
                            gx,gy=coords["reference"]
                            painter.setPen(QPen(QColor(30,180,235),2.2))
                            painter.drawLine(int(gx-8),int(gy),int(gx+8),int(gy)); painter.drawLine(int(gx),int(gy-8),int(gx),int(gy+8))
                            painter.drawText(QRectF(gx+9,gy-11,150,20),Qt.AlignmentFlag.AlignLeft,"Reference focus")
                        if "phase" in coords:
                            px,py=coords["phase"]
                            painter.setPen(QPen(QColor(220,65,55),2.2)); painter.setBrush(QBrush(QColor(220,65,55)))
                            painter.drawEllipse(QRectF(px-4,py-4,8,8))
                            painter.drawText(QRectF(px+9,py-11,145,20),Qt.AlignmentFlag.AlignLeft,"Phase focus")
                            if "reference" in coords:
                                gx,gy=coords["reference"]
                                painter.setPen(QPen(QColor(220,65,55),1.4)); painter.drawLine(int(gx),int(gy),int(px),int(py))

                # Compact orientation triad. Named views now correspond exactly to their labels.
                ax0=map_rect.left()+44; ay0=map_rect.bottom()-42; axis_len=28
                painter.setPen(QPen(QColor(185,55,55),2.0)); painter.drawLine(int(ax0),int(ay0),int(ax0+axis_len),int(ay0)); painter.drawText(int(ax0+axis_len+3),int(ay0+4),'X')
                painter.setPen(QPen(QColor(55,150,70),2.0)); painter.drawLine(int(ax0),int(ay0),int(ax0),int(ay0-axis_len)); painter.drawText(int(ax0-4),int(ay0-axis_len-4),'Y/Z')
                painter.setPen(QColor(55,55,53))
                if self.umbrella_projection=="Perspective":
                    camera_text=f"yaw {self.umbrella_yaw_deg:.0f}° · pitch {self.umbrella_pitch_deg:.0f}°"
                else:
                    camera_text="exact orthographic plane"
                painter.drawText(QRectF(map_rect.left(),map_rect.bottom()+4,map_rect.width(),18),
                    Qt.AlignmentFlag.AlignCenter,
                    f"3-D Umbrella · {self.umbrella_projection} ({projection_kind}) · {camera_text} · zoom {self.umbrella_zoom:.2f}×")


        if not phase_mode:
            self._draw_color_bar(painter, bar, lo, hi)
            painter.setPen(QColor(55, 55, 53))
            painter.drawText(QRectF(bar.left() - 4, bar.top() - 18, 78, 16), Qt.AlignmentFlag.AlignCenter, 'High')
            painter.drawText(QRectF(bar.left() - 4, bar.bottom() + 10, 78, 16), Qt.AlignmentFlag.AlignCenter, 'Low')

    def wheelEvent(self,event):
        if self.layout_mode.startswith("Umbrella"):
            delta=event.angleDelta().y()
            if delta:
                factor=1.13 if delta>0 else (1.0/1.13)
                self.umbrella_zoom=max(0.20,min(6.0,self.umbrella_zoom*factor))
                self.update()
                event.accept()
                return
        super().wheelEvent(event)

    def _nearest_screen_channel(self,pos,max_extra=6.0):
        x=pos.x(); y=pos.y(); nearest=None
        for px,py,radius,ch,value in self._screen_points:
            d2=(px-x)**2+(py-y)**2
            if d2 <= (radius+max_extra)**2 and (nearest is None or d2<nearest[0]):
                nearest=(d2,int(ch))
        return None if nearest is None else nearest[1]

    def mousePressEvent(self,event):
        if self.layout_mode.startswith("Umbrella") and event.button()==Qt.MouseButton.LeftButton:
            # Always start a possible drag, even when the cursor is over an element.
            # The old code immediately selected dense points and returned, so rotation
            # was practically impossible with 1024 elements.
            self._umbrella_press_pos=event.position()
            self._umbrella_drag_last=event.position()
            self._umbrella_press_channel=self._nearest_screen_channel(event.position())
            self._umbrella_dragged=False
            event.accept(); return

        ch=self._nearest_screen_channel(event.position())
        if ch is not None:
            self.selected_channel=ch; self.elementClicked.emit(ch); self.update(); event.accept(); return
        super().mousePressEvent(event)

    def mouseMoveEvent(self,event):
        if self.layout_mode.startswith("Umbrella") and (event.buttons() & Qt.MouseButton.LeftButton) and self._umbrella_drag_last is not None:
            pos=event.position()
            dx=pos.x()-self._umbrella_drag_last.x(); dy=pos.y()-self._umbrella_drag_last.y()
            if self._umbrella_press_pos is not None:
                total=abs(pos.x()-self._umbrella_press_pos.x())+abs(pos.y()-self._umbrella_press_pos.y())
                if total>=3.0:
                    self._umbrella_dragged=True
            if self._umbrella_dragged:
                if self.umbrella_projection!="Perspective":
                    self.umbrella_projection="Perspective"
                    self.viewChanged.emit("Perspective")
                self.umbrella_yaw_deg=(self.umbrella_yaw_deg+dx*0.55)%360.0
                self.umbrella_pitch_deg=max(-89.0,min(89.0,self.umbrella_pitch_deg-dy*0.55))
                self.update()
            self._umbrella_drag_last=pos
            event.accept(); return

        x=event.position().x(); y=event.position().y()
        ch=self._nearest_screen_channel(event.position(),3.0)
        if ch is not None:
            value=self._value_by_channel.get(ch,float('nan'))
            blade=ch//64; blade_ch=ch%64; state=self.channel_state(ch)
            source=self.channel_state_sources.get(ch,""); act_reason=self.act_zero_reasons.get(ch,"")
            value_text="--" if not np.isfinite(value) else f"{value:.6g}"
            detail=f"Element CH {ch}\nBlade {blade+1} / Blade CH {blade_ch}\nState: {state}"
            if source: detail+=f"\nINI source: {source}"
            if act_reason: detail+=f"\nACT: {act_reason}"
            detail+=f"\nValue: {value_text}"
            QToolTip.showText(event.globalPosition().toPoint(),detail,self); return
        QToolTip.hideText()

    def mouseReleaseEvent(self,event):
        if self.layout_mode.startswith("Umbrella") and event.button()==Qt.MouseButton.LeftButton and self._umbrella_press_pos is not None:
            if not self._umbrella_dragged:
                ch=self._umbrella_press_channel
                if ch is not None:
                    self.selected_channel=ch
                    self.elementClicked.emit(ch)
                    self.update()
            self._umbrella_drag_last=None
            self._umbrella_press_pos=None
            self._umbrella_press_channel=None
            self._umbrella_dragged=False
            event.accept(); return
        self._umbrella_drag_last=None
        super().mouseReleaseEvent(event)



class SkullElementWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("XD - Skull Element Map — RC2-R0016")
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowStaysOnTopHint |
                            Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowMaximizeButtonHint |
                            Qt.WindowType.WindowCloseButtonHint)
        self.setModal(False)
        self.resize(920, 720)
        self.data = None
        self.parameter = QComboBox()
        self.parameter.addItems(list(SkullMeasuresService.PARAMETERS.keys()))
        self.parameter.setCurrentText("Element SDR")
        self.show_enabled = QCheckBox("Enable Elements"); self.show_enabled.setChecked(True)
        self.show_disabled = QCheckBox("Disable Elements"); self.show_disabled.setChecked(True)
        self.scale_mode = QComboBox(); self.scale_mode.addItems(["Adaptive", "Manual", "Normalized"]); self.scale_mode.setCurrentText("Adaptive")
        self.gamma = QDoubleSpinBox(); self.gamma.setDecimals(2); self.gamma.setRange(0.25, 4.0); self.gamma.setSingleStep(0.05); self.gamma.setValue(1.15); self.gamma.setKeyboardTracking(False)
        self.scale_min = QDoubleSpinBox(); self.scale_min.setDecimals(3); self.scale_min.setRange(-999999.0,999999.0); self.scale_min.setKeyboardTracking(False)
        self.scale_max = QDoubleSpinBox()
        self.scale_max.setDecimals(3); self.scale_max.setRange(0.001, 999999.0); self.scale_max.setValue(1.0)
        self.scale_max.setKeyboardTracking(False); self.scale_max.setToolTip("Upper value of the colour scale")
        self.source_label = QLabel("No SkullMeasures data")
        self.source_label.setWordWrap(True)
        self.summary_label = QLabel("Elements: -")
        self.map = TransducerMapWidget(self)
        self.parameter.currentTextChanged.connect(self._redraw)
        self.show_enabled.toggled.connect(self._redraw)
        self.show_disabled.toggled.connect(self._redraw)
        self.scale_mode.currentTextChanged.connect(self._redraw)
        self.gamma.valueChanged.connect(self._redraw)
        self.scale_min.valueChanged.connect(self._redraw)
        self.scale_max.valueChanged.connect(self._redraw)
        controls=QHBoxLayout()
        controls.addWidget(QLabel("Parameter")); controls.addWidget(self.parameter,1)
        controls.addWidget(QLabel("Scale")); controls.addWidget(self.scale_mode)
        controls.addWidget(QLabel("Min")); controls.addWidget(self.scale_min)
        controls.addWidget(QLabel("Max")); controls.addWidget(self.scale_max)
        controls.addWidget(QLabel("Gamma")); controls.addWidget(self.gamma)
        controls.addWidget(self.show_enabled); controls.addWidget(self.show_disabled)
        layout=QVBoxLayout(self)
        layout.addLayout(controls); layout.addWidget(self.source_label)
        layout.addWidget(self.map,1); layout.addWidget(self.summary_label)
        progress_row=QHBoxLayout(); self.progress_label=QLabel("Ready"); self.progress_bar=QProgressBar(); self.progress_bar.setRange(0,100); self.progress_bar.setValue(0); self.progress_bar.setMaximumWidth(240); self.progress_label.setVisible(False); self.progress_bar.setVisible(False); progress_row.addWidget(self.progress_label); progress_row.addWidget(self.progress_bar); progress_row.addStretch(1); layout.addLayout(progress_row)

    def _set_progress(self, value: int | None, text: str = ""):
        if value is None:
            self.progress_label.setVisible(False); self.progress_bar.setVisible(False); return
        self.progress_label.setVisible(True); self.progress_bar.setVisible(True); self.progress_label.setText(text or "Updating…"); self.progress_bar.setValue(max(0,min(100,int(value)))); QApplication.processEvents()

    def set_data(self, data):
        self._set_progress(10, "Loading element data…")
        self.data=data
        if data and data.source:
            self.source_label.setText(f"Source: {data.source.name}")
        else:
            self.source_label.setText(data.error if data else "SkullMeasures log not found")
        if data and data.elements:
            values=[el.values.get(self.parameter.currentText(), float("nan")) for el in data.elements]
            values=np.asarray(values,float); values=values[np.isfinite(values)]
            if values.size:
                self.scale_min.blockSignals(True); self.scale_min.setValue(float(np.nanmin(values))); self.scale_min.blockSignals(False)
                self.scale_max.blockSignals(True); self.scale_max.setValue(float(np.nanmax(values))); self.scale_max.blockSignals(False)
        self._set_progress(70, "Rendering element map…")
        self._redraw()
        self._set_progress(100, "Ready")
        QTimer.singleShot(350, lambda: self._set_progress(None))

    def _redraw(self, *_):
        self.map.configure(self.data,self.parameter.currentText(),self.show_enabled.isChecked(),self.show_disabled.isChecked(),self.scale_min.value(),self.scale_max.value(),self.scale_mode.currentText(),self.gamma.value())
        if not self.data or not self.data.elements:
            self.summary_label.setText("Elements: 0")
            return
        enabled=sum(1 for e in self.data.elements if e.enabled)
        vals=[e.values.get(self.parameter.currentText(),float("nan")) for e in self.data.elements]
        finite=np.asarray([v for v in vals if np.isfinite(v)],float)
        value_text=f"{float(np.min(finite)):.4g} to {float(np.max(finite)):.4g}" if finite.size else "Unavailable"
        self.summary_label.setText(f"{self.parameter.currentText()}: {value_text}    Scale: {self.scale_mode.currentText()}    Gamma: {self.gamma.value():.2f}    Elements: {len(self.data.elements)}    On: {enabled}    Off: {len(self.data.elements)-enabled}")


class HoldInfoButton(QPushButton):
    """Shows a temporary popup only while the right mouse button is held."""
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.popup = QLabel()
        self.popup.setWindowFlags(Qt.WindowType.ToolTip)
        self.popup.setStyleSheet("QLabel { background:#152536; color:white; border:1px solid #4c789d; padding:10px; }")

    def set_popup_text(self, text):
        self.popup.setText(text)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.RightButton:
            self.popup.adjustSize()
            self.popup.move(QCursor.pos())
            self.popup.show()
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.RightButton:
            self.popup.hide()
            event.accept()
            return
        super().mouseReleaseEvent(event)



class ChartPopup(QDialog):
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowCloseButtonHint)
        self.setModal(False); self.resize(1000,650)
        self.plot = pg.PlotWidget(title=title); self.plot.showGrid(x=True,y=True,alpha=.2)
        self.hover_series = []
        self.hover_text = pg.TextItem(anchor=(0, 1), color="#ffffff", fill=pg.mkBrush(0, 0, 0, 210))
        self.hover_text.setZValue(100); self.hover_text.hide(); self.plot.addItem(self.hover_text)
        self.hover_proxy = pg.SignalProxy(self.plot.scene().sigMouseMoved, rateLimit=45, slot=self._hovered)
        layout=QVBoxLayout(self); layout.addWidget(self.plot)
        progress_row=QHBoxLayout(); self.progress_label=QLabel("Ready"); self.progress_bar=QProgressBar(); self.progress_bar.setRange(0,100); self.progress_bar.setValue(0); self.progress_bar.setMaximumWidth(220); self.progress_label.setVisible(False); self.progress_bar.setVisible(False); progress_row.addWidget(self.progress_label); progress_row.addWidget(self.progress_bar); progress_row.addStretch(1); layout.addLayout(progress_row)

    def set_progress(self, value: int | None, text: str = ""):
        if value is None:
            self.progress_label.setVisible(False); self.progress_bar.setVisible(False); return
        self.progress_label.setVisible(True); self.progress_bar.setVisible(True); self.progress_label.setText(text or "Updating chart…"); self.progress_bar.setValue(max(0,min(100,int(value)))); QApplication.processEvents()

    def set_hover_series(self, series):
        """series: [(label, x-array, y-array, unit), ...]."""
        self.hover_series = series or []
        if not self.hover_series:
            self.hover_text.hide()

    def _hovered(self, event):
        scene_pos = event[0] if isinstance(event, (tuple, list)) else event
        if not self.hover_series or not self.plot.sceneBoundingRect().contains(scene_pos):
            self.hover_text.hide(); return
        point = self.plot.plotItem.vb.mapSceneToView(scene_pos)
        lines=[]; best_x=None
        for label, x_values, y_values, unit in self.hover_series:
            x=np.asarray(x_values,float); y=np.asarray(y_values,float)
            valid=np.isfinite(x)&np.isfinite(y)
            if not valid.any(): continue
            xv=x[valid]; yv=y[valid]; i=int(np.argmin(np.abs(xv-point.x())))
            if best_x is None: best_x=float(xv[i]); lines.append(f"{best_x:.2f} sec")
            lines.append(f"{label}: {float(yv[i]):.2f}{unit}")
        if not lines:
            self.hover_text.hide(); return
        self.hover_text.setText("\n".join(lines)); self.hover_text.setPos(point.x(),point.y()); self.hover_text.show()


class MainWindow(QMainWindow):
    """FUS workstation-inspired Sonication-folder replay UI.

    The RC1 replay UI deliberately prioritizes replay-first behavior. The
    partially developed acoustic-analysis controls remain available on the
    Analysis tab, but they no longer reduce the size of the replay image.
    """

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} - {APP_VERSION}")
        self.resize(1760, 1040)
        self.setMinimumSize(1180, 720)
        self.setAcceptDrops(True)

        self.settings = QSettings(ORGANIZATION, APP_NAME)
        self.language = str(self.settings.value("language", "en") or "en")
        if self.language not in LANGUAGES:
            self.language = "en"
        self.importer = ImportService()
        self.discovery = DiscoveryService()
        self.replay = ReplayService()
        self.registration_overlay_service = RegistrationOverlayService()
        self.sonication_log_receiver_service = SonicationLogReceiverService()
        self.registration_overlay_enabled = False
        self._registration_reference_report = "REFERENCE CANDIDATES: not evaluated"
        self._registration_ct_volume_cache = None
        self._registration_overlay_cache = {}
        self._active_planning_asset = None
        self._active_planning_array = None
        self.acoustic_control_service = AcousticControlService()
        self.package = None
        self.current: SonicationModel | None = None
        self.frame_index = 0
        # Runtime render diagnostics.  These counters deliberately live in the
        # real GUI path (not only tests) so packaged EXEs can prove that a click
        # or arrow reached the image renderer.
        self._render_serial = 0
        self._last_render_signature = None
        self.replay_context = ReplayContext(self)
        self.replay_views = ReplayViewCoordinator(self.replay_context)
        self.snapshot_provider = ReplaySnapshotProvider(
            self.replay.frame, self._index_to_seconds, self._map_replay_to_data
        )
        # R0010: RC1 direct rendering is the authoritative runtime path.
        # Do not register the removed RC2 callback; doing so caused the packaged
        # EXE to fail in MainWindow.__init__ before the window could appear.
        self.max_temperature_trend: list[float] = []
        self.mean_temperature_trend: list[float] = []
        self.delta_trend: list[float] = []
        self.temperature_display_mode = "Absolute Temperature"
        self.spectrum_channels: dict[str, list] = {}
        self.chart_state = ChartState()
        self.cpc_enabled = self.chart_state.cpc_enabled
        self.sonication_channel_service = SonicationChannelService()
        self.metadata_service = SonicationMetadataService()
        self.skull_measures_service = SkullMeasuresService()
        self.engineering_analysis_service = EngineeringAnalysisService()
        self.current_engineering_analysis = None
        self.hydrophone_replay_service = HydrophoneReplayService()
        self.hydrophone_calibration_service = HydrophoneCalibrationService()
        self.cavitation_service = CavitationVisualizationService()
        self.cavitation_control_timeline_service = CavitationControlTimelineService()
        self.cavitation_likelihood_service = CavitationLikelihoodService()
        self.cavitation_mr_correlation_service = CavitationMrCorrelationService()
        self.cavitation_root_cause_service = CavitationRootCauseService()
        self.current_cavitation_root_cause = None
        self._rca_temperature_cache = {}
        self._rca_previous_cavitation_cache = {}
        self.default_cavitation_mr_correlation = None
        self.hydrophone_calibration = None
        self.hydrophone_window = None
        self.current_metadata = None
        self._displayed_plane_override = None
        self._cavitation_trend = None
        self.default_cpc_replay = None
        self.default_cavitation_timeline = None
        self.default_cavitation_likelihood = None
        self.relative_spectrum_renderer = RelativeSpectrumRenderer()
        self.current_spectrum_renderer = CurrentSpectrumRenderer()
        self._active_spectrum_channel = "CH0"
        self._channel_colors = {
            "CH0":"#ff3b30", "CH1":"#ff9500", "CH2":"#ffd60a", "CH3":"#9ef01a",
            "CH4":"#30d158", "CH5":"#32d7ff", "CH6":"#0a84ff", "CH7":"#bf5af2",
        }
        self.spectrum_provider = SpectrumMsgAnalyzerAdapter()
        self._spectrum_frame = None
        self._spectrum_status = "No SpectrumMsg"
        self.sonication_index = -1
        self.cursor_temperature_trend: list[float] = []
        self._overlay_session_view = None
        self._planning_overlay_view = None
        self._overlay_session_levels = None
        self._restore_overlay_session = False

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.next_frame)
        # R0014: vendor-workstation replay behavior.  In this mode the charts
        # reveal only acquired data, the thumbnail rows follow the live frame,
        # and playback stops at the end instead of wrapping silently.
        self.workstation_replay_enabled = True
        self._workstation_phase = "Ready"
        self._package_load_thread = None
        self._package_load_worker = None
        self._thermal_thumbnail_thread = None
        self._thermal_thumbnail_worker = None
        self._thermal_thumbnail_cache = {}
        self._thermal_thumbnail_generation = 0
        self._thermal_thumbnails_complete = False
        self._image_thumbnail_threads = {}
        self._image_thumbnail_workers = {}
        self._image_thumbnail_generation = 0
        self._reference_thumbnail_cache = {}
        self._treatment_mr_thumbnail_cache = {}
        self._sonication_summary_thread = None
        self._sonication_summary_worker = None
        self._sonication_summary_generation = 0
        self._selection_generation = 0
        self._load_progress_hide_timer = QTimer(self)
        self._load_progress_hide_timer.setSingleShot(True)
        self._load_progress_hide_timer.timeout.connect(lambda: self._set_load_progress(None, ""))

        pg.setConfigOption("background", "k")
        pg.setConfigOption("foreground", "w")

        self._build_actions()
        self._build_ui()
        self._install_navigation_shortcuts()
        self._install_global_readability()
        QApplication.instance().installEventFilter(self)
        self._restore()

    def _install_global_readability(self) -> None:
        """Install common long-text navigation on all analysis tables."""
        for table in self.findChildren(QTableWidget):
            self._install_table_readability(table)
        for label in self.findChildren(QLabel):
            if label.wordWrap() or label.objectName() == "CurrentValue":
                label.setProperty("r0093_full_text_label", True)

    def _install_table_readability(self, table: QTableWidget) -> None:
        if bool(table.property("r0093_readability_installed")):
            return
        table.setProperty("r0093_readability_installed", True)
        table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        table.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        table.setTextElideMode(Qt.TextElideMode.ElideRight)
        table.setWordWrap(False)
        try:
            table.horizontalHeader().setStretchLastSection(False)
        except Exception:
            pass
        table.cellEntered.connect(lambda row, col, t=table: self._table_cell_hovered(t, row, col))
        table.cellDoubleClicked.connect(lambda row, col, t=table: self._show_table_cell_popup(t, row, col))

    def _table_cell_hovered(self, table: QTableWidget, row: int, column: int) -> None:
        item = table.item(row, column)
        if item is None:
            return
        text = str(item.text() or "")
        if text:
            item.setToolTip(text)

    def _show_table_cell_popup(self, table: QTableWidget, row: int, column: int) -> None:
        item = table.item(row, column)
        if item is None:
            return
        text = str(item.text() or "")
        if not text:
            return
        header_item = table.horizontalHeaderItem(column)
        title = header_item.text() if header_item is not None else "Detail"
        dlg = QDialog(self)
        dlg.setWindowTitle(title)
        dlg.resize(760, 360)
        layout = QVBoxLayout(dlg)
        editor = QTextEdit(); editor.setReadOnly(True); editor.setPlainText(text)
        editor.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth)
        layout.addWidget(editor, 1)
        close_btn = QPushButton("Close"); close_btn.clicked.connect(dlg.accept)
        row_layout = QHBoxLayout(); row_layout.addStretch(1); row_layout.addWidget(close_btn); layout.addLayout(row_layout)
        dlg.exec()

    def _install_navigation_shortcuts(self):
        """Make replay navigation work regardless of which child widget owns focus.

        Qt child controls such as tables, tabs and spin boxes can consume arrow-key
        events before MainWindow.keyPressEvent sees them. WindowWithChildrenShortcut
        keeps the replay navigation consistent across the entire tool.
        """
        self._nav_shortcuts = []
        bindings = [
            (Qt.Key.Key_Left, self.previous_frame),
            (Qt.Key.Key_Up, self.previous_frame),
            (Qt.Key.Key_Right, self.next_frame),
            (Qt.Key.Key_Down, self.next_frame),
            (Qt.Key.Key_PageUp, lambda: self._change_sonication(-1)),
            (Qt.Key.Key_PageDown, lambda: self._change_sonication(1)),
        ]
        for key, slot in bindings:
            shortcut = QShortcut(QKeySequence(key), self)
            shortcut.setContext(Qt.ShortcutContext.WindowShortcut)
            shortcut.activated.connect(slot)
            self._nav_shortcuts.append(shortcut)

    def eventFilter(self, obj, event):
        if isinstance(obj, QLabel) and bool(obj.property("r0093_full_text_label")):
            if event.type() in (QEvent.Type.ToolTip, QEvent.Type.Enter):
                text = str(obj.text() or "")
                if text:
                    obj.setToolTip(text)
        # Global replay navigation: tables, combo boxes, spin boxes and plots often
        # consume arrow keys before QMainWindow.keyPressEvent. Intercept them at
        # the application level while this window is active.
        if event.type() == QEvent.Type.KeyPress:
            active = QApplication.activeWindow()
            belongs = active is self or (active is not None and self.isAncestorOf(active))
            if belongs and event.modifiers() == Qt.KeyboardModifier.NoModifier:
                key = event.key()
                if key in (Qt.Key.Key_Up, Qt.Key.Key_Left):
                    self.previous_frame(); event.accept(); return True
                if key in (Qt.Key.Key_Down, Qt.Key.Key_Right):
                    self.next_frame(); event.accept(); return True
                if key == Qt.Key.Key_PageUp:
                    self._change_sonication(-1); event.accept(); return True
                if key == Qt.Key.Key_PageDown:
                    self._change_sonication(1); event.accept(); return True
        return super().eventFilter(obj, event)

    # ------------------------------------------------------------------ UI
    def _build_actions(self):
        menu = self.menuBar().addMenu("&File")
        open_zip = QAction("Open ZIP...", self)
        open_zip.triggered.connect(self.open_zip)
        menu.addAction(open_zip)
        open_folder = QAction("Open Folder...", self)
        open_folder.triggered.connect(self.open_folder)
        menu.addAction(open_folder)

        toolbar = self.addToolBar("Main")
        toolbar.setObjectName("MainToolbar")
        toolbar.setMovable(False)
        toolbar.addAction(open_zip)
        toolbar.addAction(open_folder)
        toolbar.addSeparator()
        self.open_hydrophone_action = QAction("Spectrum Dump Analyzer", self)
        self.open_hydrophone_action.setToolTip("Open Spectrum dump analyzer; accepts Export ZIP, folder, or Spectrum file")
        self.open_hydrophone_action.triggered.connect(self._open_hydrophone_window)
        toolbar.addAction(self.open_hydrophone_action)
        self.open_cavitation_intelligence_action = QAction("Cavitation Intelligence", self)
        self.open_cavitation_intelligence_action.setToolTip("Open the Replay cavitation evidence workspace")
        self.open_cavitation_intelligence_action.triggered.connect(self._open_cavitation_intelligence)
        toolbar.addAction(self.open_cavitation_intelligence_action)

        # R0089: expose language selection in two always-visible/reliable places.
        # QMenuBar.setCornerWidget() was not reliably visible in the packaged
        # Windows build, so the selector now lives on the Main toolbar and a
        # normal Language menu mirrors it.
        toolbar.addSeparator()
        self.language_label = QLabel("Language:")
        self.language_label.setObjectName("LanguageLabel")
        toolbar.addWidget(self.language_label)
        self.language_combo = QComboBox()
        self.language_combo.setObjectName("LanguageCombo")
        for code, label in LANGUAGES.items():
            self.language_combo.addItem(label, code)
        idx = self.language_combo.findData(self.language)
        if idx >= 0:
            self.language_combo.setCurrentIndex(idx)
        self.language_combo.setMinimumWidth(150)
        self.language_combo.setToolTip("Select display language / 表示言語")
        self.language_combo.currentIndexChanged.connect(self._language_changed)
        toolbar.addWidget(self.language_combo)

        self.language_menu = self.menuBar().addMenu("&Language")
        self.language_actions = {}
        for code, label in LANGUAGES.items():
            action = QAction(label, self)
            action.setCheckable(True)
            action.setChecked(code == self.language)
            action.triggered.connect(lambda checked=False, c=code: self._set_language(c))
            self.language_menu.addAction(action)
            self.language_actions[code] = action

    def _build_ui(self):
        self.tabs = QTabWidget()
        self.replay_tab = self._build_replay_tab()
        self.tabs.addTab(self.replay_tab, "Replay")
        self.cavitation_intelligence_tab = self._build_cavitation_intelligence_tab()
        self.tabs.addTab(self.cavitation_intelligence_tab, "Cavitation Intelligence")
        self.sonication_summary_tab = self._build_sonication_summary_tab()
        self.tabs.addTab(self.sonication_summary_tab, "Sonication Summary")
        self.sonication_elements_tab = self._build_sonication_elements_tab()
        self.tabs.addTab(self.sonication_elements_tab, "Sonication Elements")
        self.tabs.addTab(self._build_analysis_tab(), "Analysis (preserved)")
        self.tabs.addTab(self._build_planning_tab(), "Planning / Reference")
        self.tabs.addTab(self._build_export_status_tab(), "Export / Replay Status")
        self.tabs.addTab(self._build_thermometry_data_tab(), "Thermometry Data")
        self.tabs.addTab(self._build_elements_skull_tab(), "Elements & Skull")
        self.tabs.addTab(self._build_comparison_tab(), "Comparison")
        self.tabs.addTab(self._build_engineering_analysis_tab(), "Engineering Analysis")
        self.diagnostics_tab = DiagnosticsTab(self)
        self.diagnostics_tab.sonicationRequested.connect(self._select_sonication_index)
        self.tabs.addTab(self.diagnostics_tab, "Diagnostics")
        self.tabs.currentChanged.connect(self._main_tab_changed)
        self.setCentralWidget(self.tabs)
        self.load_progress_label = QLabel("")
        self.load_progress_bar = QProgressBar()
        self.load_progress_bar.setRange(0, 100)
        self.load_progress_bar.setTextVisible(True)
        self.load_progress_bar.setFixedWidth(220)
        self.load_progress_label.hide(); self.load_progress_bar.hide()
        self.statusBar().addPermanentWidget(self.load_progress_label)
        self.statusBar().addPermanentWidget(self.load_progress_bar)
        self.statusBar().showMessage(self._tr("ready"))


    def _tr(self, key: str, **kwargs) -> str:
        return tr(getattr(self, "language", "en"), key, **kwargs)

    def _set_language(self, code: str) -> None:
        if code not in LANGUAGES:
            return
        code = str(code)
        self.language = code
        self.settings.setValue("language", code)

        if hasattr(self, "language_combo"):
            idx = self.language_combo.findData(code)
            if idx >= 0 and self.language_combo.currentIndex() != idx:
                self.language_combo.blockSignals(True)
                self.language_combo.setCurrentIndex(idx)
                self.language_combo.blockSignals(False)

        if hasattr(self, "language_actions"):
            for action_code, action in self.language_actions.items():
                action.blockSignals(True)
                action.setChecked(action_code == code)
                action.blockSignals(False)

        self._refresh_localized_messages()

    def _language_changed(self, index: int) -> None:
        if not hasattr(self, "language_combo"):
            return
        code = self.language_combo.itemData(index)
        self._set_language(code)

    def _refresh_localized_messages(self) -> None:
        # Keep the UI geometry and scientific control labels stable. Only narrative
        # text, messages and analysis explanations are refreshed.
        if hasattr(self, "ci_explanatory_note"):
            self.ci_explanatory_note.setText(self._tr("note"))
        if hasattr(self, "statusBar"):
            self.statusBar().showMessage(self._tr("ready"), 2500)
        # Refresh scientific state once. The default-cavitation refresh already
        # updates the Cavitation Intelligence page and RCA.
        if hasattr(self, "replay_cavitation_status") and self.current is not None:
            self._update_default_cavitation_intelligence()
        elif hasattr(self, "ci_summary"):
            self._update_cavitation_intelligence_page()
        if self.hydrophone_window is not None:
            try:
                self.hydrophone_window.set_language(self.language)
            except Exception:
                pass

    def _localized_rca_summary(self, result) -> str:
        if result is None:
            return self._tr("root_unavailable")
        ranked = list(getattr(result, "ranked_factors", []) or [])
        names = ", ".join(tr_factor_label(self.language, f.key, f.label) for f in ranked[:3])
        if not names:
            names = "--"
        state = self._tr("rca_detected") if bool(getattr(result, "cavitation_detected", False)) else self._tr("rca_not_detected")
        conf = tr_confidence(self.language, str(getattr(result, "confidence", "Low")))
        text = self._tr("rca_summary", state=state, names=names, score=float(getattr(result, "root_cause_score", 0.0) or 0.0), confidence=conf)
        if not bool(getattr(result, "cavitation_detected", False)) and ranked and float(getattr(ranked[0], "contribution", 0.0) or 0.0) >= 65:
            label = tr_factor_label(self.language, ranked[0].key, ranked[0].label)
            text += "  " + self._tr("rca_warning", label=label)
        return text


    def _open_cavitation_intelligence(self) -> None:
        """Open the dedicated cavitation workspace without changing Replay state."""
        if hasattr(self, "tabs") and hasattr(self, "cavitation_intelligence_tab"):
            self.tabs.setCurrentWidget(self.cavitation_intelligence_tab)
        self._update_cavitation_intelligence_page()

    def _build_cavitation_intelligence_tab(self) -> QWidget:
        # R0094: scrollable workspace prevents linked evidence from being pushed
        # off-screen on laptop / 1080p displays.
        page = QScrollArea()
        page.setWidgetResizable(True)
        page.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        page.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        content = QWidget()
        page.setWidget(content)
        root = QVBoxLayout(content)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)

        header = QHBoxLayout()
        title = QLabel("Cavitation Intelligence")
        title.setObjectName("SectionTitle")
        header.addWidget(title)
        self.ci_summary = QLabel(self._tr("load_sonication"))
        self.ci_summary.setObjectName("CurrentValue")
        self.ci_summary.setWordWrap(True)
        header.addWidget(self.ci_summary, 1)
        back = QPushButton("Show in Replay")
        back.setToolTip("Return to Replay at the currently synchronized Sonication/frame.")
        back.clicked.connect(lambda: self.tabs.setCurrentWidget(self.replay_tab) if hasattr(self, "replay_tab") else None)
        header.addWidget(back)
        analyzer = QPushButton("Open Spectrum Dump Analyzer")
        analyzer.clicked.connect(self._open_hydrophone_window)
        header.addWidget(analyzer)
        root.addLayout(header)

        replay_bar = QHBoxLayout()
        replay_bar.addWidget(QLabel("Replay position"))
        self.ci_replay_position = QLabel("--")
        self.ci_replay_position.setObjectName("CurrentValue")
        self.ci_replay_position.setStyleSheet("QLabel { font-weight: 600; padding: 3px 8px; background: #eef4f8; border: 1px solid #c6d1da; }")
        replay_bar.addWidget(self.ci_replay_position, 1)
        prev_btn = QPushButton("◀ Previous")
        prev_btn.clicked.connect(self.previous_frame)
        replay_bar.addWidget(prev_btn)
        next_btn = QPushButton("Next ▶")
        next_btn.clicked.connect(self.next_frame)
        replay_bar.addWidget(next_btn)
        root.addLayout(replay_bar)

        visibility_row = QHBoxLayout()
        self.ci_details_toggle = QCheckBox("Show event / element lists")
        self.ci_details_toggle.setChecked(False)
        self.ci_details_toggle.setToolTip("Expand the synchronized event list and sonication-element log only when needed.")
        visibility_row.addWidget(self.ci_details_toggle)
        visibility_row.addStretch(1)
        root.addLayout(visibility_row)

        self.ci_chain_labels = {}
        steps = [
            ("Event", "Event"), ("RCV", "Receiver"), ("Band", "Band / Energy"),
            ("MR", "MR Signal"), ("Location", "Probable Location"),
            ("Skull", "Skull Class"), ("Power", "Power Response"),
        ]
        chain = QGridLayout(); chain.setHorizontalSpacing(5); chain.setVerticalSpacing(2)
        for col, (key, caption) in enumerate(steps):
            grid_col = col * 2
            cap = QLabel(caption); cap.setAlignment(Qt.AlignmentFlag.AlignCenter)
            val = QLabel("--"); val.setAlignment(Qt.AlignmentFlag.AlignCenter); val.setWordWrap(True)
            val.setObjectName("CurrentValue")
            chain.addWidget(cap, 0, grid_col); chain.addWidget(val, 1, grid_col)
            self.ci_chain_labels[key] = val
            if col < len(steps) - 1:
                arrow = QLabel("→"); arrow.setAlignment(Qt.AlignmentFlag.AlignCenter)
                chain.addWidget(arrow, 1, grid_col + 1)
        chain_host = QWidget(); chain_host_layout = QVBoxLayout(chain_host)
        chain_host_layout.setContentsMargins(0, 0, 0, 0)
        chain_host_layout.addLayout(chain)
        chain_host_layout.addStretch(1)
        chain_header = QLabel("Evidence chain — Time → RCV → Band → MR → Location → Skull → Power")
        self.ci_chain_container, self.ci_chain_content = self._make_ci_collapsible_section(chain_header.text(), chain_host, expanded=False)
        root.addWidget(self.ci_chain_container)

        self.ci_rca_summary = QLabel(self._tr("root_unavailable"))
        self.ci_rca_summary.setWordWrap(True); self.ci_rca_summary.setObjectName("CurrentValue")
        self.ci_rca_table = QTableWidget(0, 5)
        self.ci_rca_table.setHorizontalHeaderLabels(["Rank / Contributor", "Contribution", "Evidence", "Confidence", "Improvement direction"])
        self.ci_rca_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.ci_rca_table.horizontalHeader().setStretchLastSection(False)
        self.ci_rca_table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.ci_rca_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.ci_rca_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.ci_rca_table.setMinimumHeight(130); self.ci_rca_table.setMaximumHeight(220)
        self.ci_rca_table.cellClicked.connect(self._ci_rca_row_selected)
        rca_host = QWidget(); rca_layout = QVBoxLayout(rca_host)
        rca_layout.setContentsMargins(0, 0, 0, 0)
        rca_layout.setSpacing(4)
        rca_layout.addWidget(self.ci_rca_summary)
        rca_layout.addWidget(self.ci_rca_table)
        self.ci_rca_container, self.ci_rca_content = self._make_ci_collapsible_section(
            "Cavitation Root Cause Analysis — why did this Sonication cavitate?", rca_host, expanded=False
        )
        root.addWidget(self.ci_rca_container)


        # R0112a: restore the R0054 MR signal-loss correlation controls.
        # The handlers survived later refactors but the widgets were dropped,
        # leaving drag WW/WL and Auto/Fit paths disconnected.
        ci_mr_controls = QHBoxLayout()
        ci_mr_controls.addWidget(QLabel("MR WW"))
        self.ci_mr_ww = QDoubleSpinBox(); self.ci_mr_ww.setRange(1e-6, 1e9); self.ci_mr_ww.setDecimals(3); self.ci_mr_ww.setValue(1.0); self.ci_mr_ww.setKeyboardTracking(False)
        ci_mr_controls.addWidget(self.ci_mr_ww)
        ci_mr_controls.addWidget(QLabel("WL"))
        self.ci_mr_wl = QDoubleSpinBox(); self.ci_mr_wl.setRange(-1e9, 1e9); self.ci_mr_wl.setDecimals(3); self.ci_mr_wl.setValue(0.5); self.ci_mr_wl.setKeyboardTracking(False)
        ci_mr_controls.addWidget(self.ci_mr_wl)
        ci_auto = QPushButton("Auto WW/WL"); ci_auto.clicked.connect(self._ci_mr_auto_levels); ci_mr_controls.addWidget(ci_auto)
        ci_fit = QPushButton("Fit MR"); ci_fit.clicked.connect(self._ci_mr_fit); ci_mr_controls.addWidget(ci_fit)
        ci_mr_controls.addStretch(1)
        self.ci_mr_ww.valueChanged.connect(self._ci_apply_mr_levels)
        self.ci_mr_wl.valueChanged.connect(self._ci_apply_mr_levels)
        root.addLayout(ci_mr_controls)

        # MR magnitude signal-loss correlation controls / evidence.
        self.ci_details_host = QWidget()
        details_layout = QHBoxLayout(self.ci_details_host)
        details_layout.setContentsMargins(0, 0, 0, 0)
        details_layout.setSpacing(6)

        event_box = QGroupBox("Observed / reconstructed cavitation events")
        event_layout = QVBoxLayout(event_box)
        self.ci_event_table = QTableWidget(0, 8)
        self.ci_event_table.setHorizontalHeaderLabels(["Time", "State", "Rule", "RCV", "Weighted", "Threshold", "Power", "Evidence"])
        self.ci_event_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.ci_event_table.horizontalHeader().setStretchLastSection(True)
        self.ci_event_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.ci_event_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        # One selection signal is authoritative. A double-click also emits
        # cellClicked, so connecting both caused the same historical-event
        # analysis to run twice.
        self.ci_event_table.cellClicked.connect(self._ci_event_selected)
        event_layout.addWidget(self.ci_event_table)
        details_layout.addWidget(event_box, 1)

        element_box = QGroupBox("Related sonication-element log")
        element_layout = QVBoxLayout(element_box)
        sr = QHBoxLayout(); sr.addWidget(QLabel("Snapshot")); self.ci_sonic_snapshot_combo = QComboBox(); self.ci_sonic_snapshot_combo.currentIndexChanged.connect(self._ci_sonic_snapshot_changed); sr.addWidget(self.ci_sonic_snapshot_combo, 1); self.ci_sonic_declared = QLabel("--"); sr.addWidget(self.ci_sonic_declared); element_layout.addLayout(sr)
        # sonic channel phase / amplitude (separate from RCV0–RCV7)
        self.ci_receiver_log_table = QTableWidget(0, 8)
        self.ci_receiver_log_table.setHorizontalHeaderLabels(["Channel", "Blade", "Blade CH", "Sonication phase", "Calibration phase", "Logical phase", "Amplitude", "Source"])
        self.ci_receiver_log_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.ci_receiver_log_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        element_layout.addWidget(self.ci_receiver_log_table)
        details_layout.addWidget(element_box, 1)

        self.ci_details_host.setVisible(False)
        self.ci_details_host.setMinimumHeight(210)
        self.ci_details_toggle.toggled.connect(self.ci_details_host.setVisible)
        root.addWidget(self.ci_details_host, 0)


        self.ci_linked_toggle = QCheckBox("Show linked cavitation analysis")
        self.ci_linked_toggle.setChecked(True)
        self.ci_linked_toggle.setToolTip("Show/hide the synchronized lower analysis panel.")
        self.ci_linked_mode = QComboBox()
        self.ci_linked_mode.addItems([
            "RCV Contribution + probable cavitation region",
            "Vendor band energy reproduction",
            "Cavitation control response + CGA / Acquisition Display Rule",
        ])
        # R0096: CGA/control view is the operational default.
        self.ci_linked_mode.setCurrentIndex(2)
        self.ci_linked_mode.setToolTip("Choose the synchronized lower display. RCV contribution → probable cavitation region is shown side-by-side.")
        linked_toolbar = QHBoxLayout()
        linked_toolbar.addWidget(self.ci_linked_toggle)
        linked_toolbar.addWidget(QLabel("Lower display"))
        linked_toolbar.addWidget(self.ci_linked_mode, 1)
        linked_toolbar.addStretch(1)
        root.addLayout(linked_toolbar)

        self.ci_linked_host = QGroupBox("Linked Cavitation Analysis")
        linked_root = QVBoxLayout(self.ci_linked_host)
        linked_root.setContentsMargins(5, 5, 5, 5)
        linked_root.setSpacing(4)
        self.ci_linked_stack = QStackedWidget()

        # RCV + probable region are one combined view, shown side-by-side.
        rcv_page = QWidget()
        rcv_l = QHBoxLayout(rcv_page)
        rcv_l.setContentsMargins(0, 0, 0, 0)
        rcv_l.setSpacing(6)

        self.ci_linked_rcv_plot = pg.PlotWidget()
        self.ci_linked_rcv_plot.setAspectLocked(True)
        self.ci_linked_rcv_plot.hideAxis("left"); self.ci_linked_rcv_plot.hideAxis("bottom")
        self.ci_linked_rcv_plot.setMouseEnabled(x=False, y=False)
        self.ci_linked_rcv_image = pg.ImageItem(axisOrder="row-major")
        self.ci_linked_rcv_plot.addItem(self.ci_linked_rcv_image)
        self.ci_linked_rcv_plot.setMinimumHeight(260)

        self.ci_linked_probable_plot = pg.PlotWidget()
        self.ci_linked_probable_plot.setAspectLocked(True)
        self.ci_linked_probable_plot.hideAxis("left"); self.ci_linked_probable_plot.hideAxis("bottom")
        self.ci_linked_probable_plot.setMouseEnabled(x=True, y=True)
        self.ci_linked_probable_image = pg.ImageItem(axisOrder="row-major")
        self.ci_linked_probable_plot.addItem(self.ci_linked_probable_image)
        self.ci_linked_probable_plot.setMinimumHeight(260)

        rcv_left = QVBoxLayout()
        rcv_left.addWidget(QLabel("RCV contribution → probable cavitation region"))
        rcv_left.addWidget(self.ci_linked_rcv_plot, 1)
        rcv_right = QVBoxLayout()
        rcv_right.addWidget(QLabel("Probable cavitation region"))
        rcv_right.addWidget(self.ci_linked_probable_plot, 1)
        rcv_l.addLayout(rcv_left, 1)
        rcv_l.addLayout(rcv_right, 1)
        self.ci_linked_stack.addWidget(rcv_page)

        vendor_page = QWidget(); vendor_l = QVBoxLayout(vendor_page); vendor_l.setContentsMargins(0,0,0,0)
        self.ci_linked_vendor_plot = pg.PlotWidget()
        self.ci_linked_vendor_plot.setLabel("bottom", "Acquisition time", units="s")
        self.ci_linked_vendor_plot.setLabel("left", "Vendor band energy")
        self.ci_linked_vendor_plot.showGrid(x=True, y=True, alpha=0.18)
        self.ci_linked_vendor_plot.setMinimumHeight(250)
        vendor_l.addWidget(self.ci_linked_vendor_plot)
        self.ci_linked_stack.addWidget(vendor_page)

        control_page = QWidget(); control_l = QVBoxLayout(control_page); control_l.setContentsMargins(0,0,0,0)
        self.ci_linked_control_plot = pg.PlotWidget()
        self.ci_linked_control_plot.setLabel("bottom", "Acquisition time", units="s")
        self.ci_linked_control_plot.setLabel("left", "Normalized response / rule")
        self.ci_linked_control_plot.showGrid(x=True, y=True, alpha=0.18)
        self.ci_linked_control_plot.setMinimumHeight(250)
        control_l.addWidget(self.ci_linked_control_plot)
        self.ci_linked_stack.addWidget(control_page)
        linked_root.addWidget(self.ci_linked_stack, 1)

        event_options=QHBoxLayout()
        self.ci_show_increase_events_check=QCheckBox("Show Increase events")
        self.ci_show_increase_events_check.setChecked(False)
        self.ci_show_increase_events_check.setToolTip("Increase control events are hidden from this list by default. Enable only for Increase-rule review.")
        self.ci_show_increase_events_check.toggled.connect(self._ci_increase_filter_changed)
        event_options.addWidget(self.ci_show_increase_events_check)
        event_options.addStretch(1)
        linked_root.addLayout(event_options)

        self.ci_linked_event_table = QTableWidget(0, 5)
        self.ci_linked_event_table.setHorizontalHeaderLabels(["Time", "Rule / state", "RCV / Band", "Power", "Why / evidence"])
        self.ci_linked_event_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.ci_linked_event_table.horizontalHeader().setStretchLastSection(True)
        self.ci_linked_event_table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.ci_linked_event_table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.ci_linked_event_table.setWordWrap(False)
        self.ci_linked_event_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.ci_linked_event_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.ci_linked_event_table.setMinimumHeight(115)
        self.ci_linked_event_table.setMaximumHeight(175)
        self.ci_linked_event_table.cellClicked.connect(self._ci_linked_event_selected)
        self.ci_linked_event_table.cellDoubleClicked.connect(self._ci_linked_event_detail_popup)
        linked_root.addWidget(self.ci_linked_event_table, 0)

        self._ci_linked_selected_time = None
        self._ci_linked_vendor_marker = None
        self._ci_linked_control_marker = None
        self.ci_linked_mode.currentIndexChanged.connect(self._ci_linked_mode_changed)
        self.ci_linked_toggle.toggled.connect(self.ci_linked_host.setVisible)
        root.addWidget(self.ci_linked_host, 0)

        self.ci_explanatory_note = QLabel(self._tr("note") + " · Probable cavitation location is a probable region, not a single-point localization.")
        self.ci_explanatory_note.setWordWrap(True)
        root.addWidget(self.ci_explanatory_note)
        return page


    def _ci_increase_filter_changed(self, _checked=False) -> None:
        self._ci_linked_data_key=None
        self._update_ci_linked_panel()

    def _ci_linked_event_detail_popup(self, row: int, _column: int) -> None:
        events=list(getattr(self,"_ci_linked_events",[]) or [])
        if not (0 <= int(row) < len(events)): return
        ev=events[int(row)]
        event_time=self._ci_event_time(ev)
        lines=[
            f"Time: {'--' if event_time is None else f'{event_time:.3f} s'}",
            f"Family / state: {getattr(ev,'family','--')}",
            f"Rule: {getattr(ev,'rule_index','--')}",
            f"RCV: {getattr(ev,'dominant_channel','--')}",
            f"Band: {getattr(ev,'dominant_band','--')}",
            f"Power ratio: {getattr(ev,'before_power_ratio','--')} → {getattr(ev,'after_power_ratio','--')}",
            "",
            "Why / evidence:",
            self._ci_event_why(ev),
        ]
        detail=DetailWindow("Cavitation event detail","\n".join(str(x) for x in lines),self)
        detail.resize(760,440); detail.show()
        self._ci_event_detail_window=detail

    def _ci_linked_mode_changed(self, index: int) -> None:
        # R0095: dropdown interaction must stay instant. Heavy curve/table rebuild
        # is performed only when the underlying Sonication/CPC data changes.
        if hasattr(self, "ci_linked_stack"):
            self.ci_linked_stack.setCurrentIndex(max(0, min(2, int(index))))
        if self._ci_linked_selected_time is not None:
            self._ci_linked_focus_time(float(self._ci_linked_selected_time), force_visible=True)

    @staticmethod
    def _ci_event_time(event) -> float | None:
        value = getattr(event, "timestamp_s", None)
        if value is not None:
            try:
                value = float(value)
                if np.isfinite(value):
                    return value
            except Exception:
                pass
        cycle = getattr(event, "cycle", None)
        return None if cycle is None else (float(cycle) - 1.0) * 0.010

    @staticmethod
    def _ci_event_why(event) -> str:
        parts = []
        family = str(getattr(event, "family", "") or "")
        rule = getattr(event, "rule_index", None)
        if family:
            parts.append(f"{family}" + (f" rule {rule}" if rule is not None else ""))
        weighted = getattr(event, "weighted_energy", None)
        threshold = getattr(event, "threshold", None)
        try:
            if weighted is not None and np.isfinite(float(weighted)):
                parts.append(f"weighted={float(weighted):.5g}")
        except Exception:
            pass
        try:
            if threshold is not None and np.isfinite(float(threshold)):
                parts.append(f"threshold={float(threshold):.5g}")
        except Exception:
            pass
        evidence = str(getattr(event, "evidence", "") or "")
        result = str(getattr(event, "result", "") or getattr(event, "action", "") or "")
        if evidence:
            parts.append(evidence)
        if result and result not in evidence:
            parts.append(result)
        return " · ".join(parts) if parts else "Observed/reconstructed cavitation event"

    def _ci_rca_row_selected(self, row: int, _column: int = 0) -> None:
        if hasattr(self, "ci_linked_host") and self.ci_linked_toggle.isChecked():
            self.ci_linked_host.setVisible(True)
            if self._ci_linked_selected_time is not None:
                self._ci_linked_focus_time(float(self._ci_linked_selected_time), force_visible=True)

    def _ci_linked_event_selected(self, row: int, _column: int = 0) -> None:
        events = getattr(self, "_ci_linked_events", [])
        if not (0 <= row < len(events)):
            return
        event = events[row]
        t = self._ci_event_time(event)
        if t is None:
            return
        self._ci_linked_selected_time = float(t)
        self._ci_linked_focus_time(float(t), force_visible=True)

        if self.current is not None:
            count = max(1, int(self.current.replay_frame_count))
            times = np.asarray([self._index_to_seconds(i, count) for i in range(count)], float)
            if times.size:
                self.set_frame(int(np.nanargmin(np.abs(times - float(t)))))

        replay = self.default_cpc_replay
        if replay is not None and replay.frames:
            times = replay.frame_times_s
            if times.size:
                idx = int(np.nanargmin(np.abs(times - float(t))))
                try:
                    result = self.cavitation_likelihood_service.estimate(replay, idx, event)
                    self._ci_event_preview_result = result
                    self._draw_ci_likelihood(result)
                    if hasattr(self, "ci_linked_mode") and self.ci_linked_mode.currentIndex() == 0:
                        self._draw_ci_linked_rcv_probable(result)
                except Exception as exc:
                    LOG.debug("Linked cavitation-event preview unavailable: %s", exc)

    def _ci_linked_focus_time(self, time_s: float, *, force_visible: bool = False) -> None:
        self._ci_linked_selected_time = float(time_s)
        for plot_name, marker_name in (
            ("ci_linked_vendor_plot", "_ci_linked_vendor_marker"),
            ("ci_linked_control_plot", "_ci_linked_control_marker"),
        ):
            plot = getattr(self, plot_name, None)
            if plot is None:
                continue
            marker = getattr(self, marker_name, None)
            if marker is None:
                marker = pg.InfiniteLine(
                    pos=float(time_s), angle=90, movable=False,
                    pen=pg.mkPen("#ffd166", width=3),
                    label="Selected event", labelOpts={"position": 0.92, "color": "#ffd166"},
                )
                plot.addItem(marker)
                setattr(self, marker_name, marker)
            else:
                marker.setPos(float(time_s))
                if marker.scene() is None:
                    plot.addItem(marker)
            if force_visible:
                try:
                    xr = plot.plotItem.vb.viewRange()[0]
                    if not (float(xr[0]) <= float(time_s) <= float(xr[1])):
                        span = max(1.0, float(xr[1]) - float(xr[0]))
                        plot.setXRange(float(time_s) - span * 0.45, float(time_s) + span * 0.55, padding=0.02)
                except Exception:
                    pass


    def _draw_ci_linked_rcv_probable(self, result) -> None:
        """Draw RCV contribution and probable cavitation region together."""
        if not hasattr(self, "ci_linked_rcv_plot"):
            return
        self.ci_linked_rcv_plot.clear()
        self.ci_linked_rcv_plot.addItem(self.ci_linked_rcv_image)
        if result is None or np.asarray(getattr(result, "likelihood_map", [])).size == 0:
            self.ci_linked_rcv_image.setImage(np.empty((0, 0)))
        else:
            arr = np.asarray(result.likelihood_map, float)
            self.ci_linked_rcv_image.setImage(arr, autoLevels=False, levels=(0, 1))
            self.ci_linked_rcv_image.setRect(QRectF(-1.05, -1.05, 2.10, 2.10))
            theta = np.linspace(0, 2*np.pi, 160)
            self.ci_linked_rcv_plot.plot(np.cos(theta), np.sin(theta), pen=pg.mkPen("#8a98a5", width=1))
            pos = np.asarray(getattr(result, "hydrophone_positions", []), float)
            scores = np.asarray(getattr(result, "per_channel_scores", []), float)
            for ch in range(min(8, len(pos))):
                dominant = getattr(result, "dominant_channel", None) is not None and ch == result.dominant_channel
                score = float(scores[ch]) if ch < len(scores) else 0.0
                brush = "#f72585" if dominant else "#ffd166" if score > 0.01 else "#4cc9f0"
                self.ci_linked_rcv_plot.plot([pos[ch,0]], [pos[ch,1]], pen=None, symbol="o",
                                             symbolSize=11 if dominant else 7, symbolBrush=brush)
            if getattr(result, "centroid_xy", None) is not None:
                self.ci_linked_rcv_plot.plot([result.centroid_xy[0]], [result.centroid_xy[1]],
                                             pen=None, symbol="x", symbolSize=12,
                                             symbolPen=pg.mkPen("#06d6a0", width=2))
            self.ci_linked_rcv_plot.setRange(xRange=(-1.12,1.12), yRange=(-1.12,1.12), padding=0.01)

        self.ci_linked_probable_plot.clear()
        self.ci_linked_probable_plot.addItem(self.ci_linked_probable_image)
        corr = getattr(self, "default_cavitation_mr_correlation", None)
        mr = np.asarray(getattr(corr, "current_image", []), float) if corr is not None else np.empty((0,0))
        if mr.size == 0 and self.current is not None and getattr(self.current, "magnitude_frames", None):
            try:
                count = max(1, int(self.current.replay_frame_count))
                idx = self.replay.raw.normalize_index(self.frame_index, count, len(self.current.magnitude_frames))
                mr = np.asarray(self.replay.raw.read_magnitude(self.current.magnitude_frames[idx].path), float)
            except Exception as exc:
                LOG.debug("Probable-region MR fallback unavailable: %s", exc)
                mr = np.empty((0,0))
        if mr.ndim == 2 and mr.size:
            finite = mr[np.isfinite(mr)]
            if finite.size:
                lo, hi = np.percentile(finite, [2,99])
                if hi <= lo: hi = lo + 1.0
                self.ci_linked_probable_image.setImage(mr, autoLevels=False, levels=(float(lo), float(hi)))
            else:
                self.ci_linked_probable_image.setImage(mr)
            h, w = mr.shape
            self.ci_linked_probable_image.setRect(QRectF(0,0,w,h))
            norm_xy = getattr(corr, "likelihood_centroid_xy", None) if corr is not None else None
            if norm_xy is None and result is not None:
                norm_xy = getattr(result, "centroid_xy", None)
            if norm_xy is not None:
                nx, ny = float(norm_xy[0]), float(norm_xy[1])
                px = (nx + 1.0)*0.5*max(1,w-1)
                py = (1.0 - ny)*0.5*max(1,h-1)
                self.ci_linked_probable_plot.plot([px],[py], pen=None, symbol="x", symbolSize=14,
                                                  symbolPen=pg.mkPen("#ff6b35", width=3))
                radius = max(8.0, min(h,w)*0.08)
                th = np.linspace(0,2*np.pi,120)
                self.ci_linked_probable_plot.plot(px + radius*np.cos(th), py + radius*np.sin(th),
                                                  pen=pg.mkPen("#ff6b35", width=2, style=Qt.PenStyle.DashLine))
            if corr is not None and getattr(corr, "loss_centroid_xy", None) is not None:
                lnx, lny = corr.loss_centroid_xy
                lx = (float(lnx)+1.0)*0.5*max(1,w-1)
                ly = (1.0-float(lny))*0.5*max(1,h-1)
                self.ci_linked_probable_plot.plot([lx],[ly], pen=None, symbol="+", symbolSize=12,
                                                  symbolPen=pg.mkPen("#f72585", width=2))
            self.ci_linked_probable_plot.setRange(xRange=(0,w), yRange=(0,h), padding=0.02)
        else:
            self.ci_linked_probable_image.setImage(np.empty((0,0)))

    def _draw_ci_linked_vendor_energy(self, replay) -> None:
        plot = self.ci_linked_vendor_plot
        plot.clear(); plot.addLegend(offset=(8,8))
        self._ci_linked_vendor_marker = None
        if replay is None:
            return
        time = np.asarray(getattr(replay,"raw_timeline_time_s",[]),float)
        for name, values, color in (
            ("Combined Band0 / control input", np.asarray(getattr(replay,"vendor_band0_weighted",[]),float), "#ffffff"),
            ("Combined Band1 / Rule 2", np.asarray(getattr(replay,"vendor_band1_log_exact",[]),float), "#4cc9f0"),
        ):
            if values.size and time.size and np.isfinite(values).any():
                n=min(len(time),len(values))
                plot.plot(time[:n],values[:n],pen=pg.mkPen(color,width=2.2),name=name)
        band2=np.asarray(getattr(replay,"vendor_band2_log_events",[]),float)
        if band2.size and time.size:
            n=min(len(time),len(band2)); mask=np.isfinite(band2[:n])
            if np.any(mask):
                plot.plot(time[:n][mask],band2[:n][mask],pen=None,symbol="o",symbolSize=7,
                          symbolBrush="#f72585",name="Band2 threshold events")
        profile=getattr(replay,"vendor_profile",None)
        inc=getattr(profile,"increase_rule0",None) if profile is not None else None
        if inc is not None and getattr(inc,"limit",None) is not None:
            plot.addItem(pg.InfiniteLine(pos=float(inc.limit),angle=0,movable=False,
                                         pen=pg.mkPen("#ffd166",width=1.5,style=Qt.PenStyle.DashLine)))
        plot.enableAutoRange(axis=pg.ViewBox.XYAxes,enable=True); plot.autoRange(padding=0.04)

    def _draw_ci_linked_control(self, replay) -> None:
        plot=self.ci_linked_control_plot
        plot.clear(); plot.addLegend(offset=(8,8))
        self._ci_linked_control_marker=None
        if replay is None:
            return
        time=np.asarray(getattr(replay,"raw_timeline_time_s",[]),float)
        rule1=np.asarray(getattr(replay,"vendor_display_rule1",[]),float)
        rule2=np.asarray(getattr(replay,"vendor_display_rule2",[]),float)
        for name,values,color in (
            ("CGA Rule 1 / Band0",rule1,"#60cf72"),
            ("CGA Rule 2 / Band1",rule2,"#39c5d5"),
        ):
            if values.size and time.size and np.isfinite(values).any():
                n=min(len(time),len(values))
                plot.plot(time[:n],values[:n],pen=pg.mkPen(color,width=2.2),name=name)
        if rule1.size or rule2.size:
            plot.addItem(pg.InfiniteLine(pos=1.0,angle=0,movable=False,
                                         pen=pg.mkPen("#ffd166",width=1.5,style=Qt.PenStyle.DashLine),
                                         label="CGA threshold 1.0"))
        validation=getattr(replay,"vendor_control_validation",None)
        if validation is not None and np.asarray(getattr(validation,"event_cycles",[])).size:
            tx=(np.asarray(validation.event_cycles,float)-1.0)*float(replay.acquisition_interval_s)
            actual=np.asarray(validation.actual_power_ratio,float)
            predicted=np.asarray(validation.predicted_power_ratio,float)
            n=min(len(tx),len(actual))
            if n: plot.plot(tx[:n],actual[:n],pen=pg.mkPen("#ffffff",width=2.4),name="Actual power ratio")
            n=min(len(tx),len(predicted))
            if n: plot.plot(tx[:n],predicted[:n],pen=pg.mkPen("#06d6a0",width=1.8,style=Qt.PenStyle.DashLine),name="Reconstructed control")
        ymax=1.05
        if rule1.size and np.isfinite(rule1).any(): ymax=max(ymax,float(np.nanmax(rule1)))
        if rule2.size and np.isfinite(rule2).any(): ymax=max(ymax,float(np.nanmax(rule2)))
        plot.setYRange(0.0,ymax,padding=0.04)
        plot.enableAutoRange(axis=pg.ViewBox.XAxis,enable=True); plot.autoRange(padding=0.04)

    def _update_ci_linked_panel(self) -> None:
        if not hasattr(self, "ci_linked_host"):
            return
        replay = self.default_cpc_replay
        timeline = self.default_cavitation_timeline
        all_events = list(getattr(timeline, "events", []) or []) if timeline is not None else []
        show_increase=bool(getattr(self,"ci_show_increase_events_check",None) and self.ci_show_increase_events_check.isChecked())
        events=[ev for ev in all_events if show_increase or str(getattr(ev,"family","") or "").lower()!="increase"]

        # Cache by data identity and filter state, not by dropdown selection.
        # expensive vendor/CGA traces and event table from being rebuilt every
        # time the user changes the dropdown.
        key = (
            id(replay),
            id(timeline),
            len(all_events),
            bool(show_increase),
            int(len(getattr(replay, "frames", []) or [])) if replay is not None else 0,
        )
        if getattr(self, "_ci_linked_data_key", None) != key:
            self._ci_linked_data_key = key
            self._draw_ci_linked_vendor_energy(replay)
            self._draw_ci_linked_control(replay)

            self._ci_linked_events = events
            self.ci_linked_event_table.setUpdatesEnabled(False)
            try:
                self.ci_linked_event_table.setRowCount(len(events))
                for row, ev in enumerate(events):
                    t = self._ci_event_time(ev)
                    family = str(getattr(ev, "family", "") or "")
                    rule = getattr(ev, "rule_index", None)
                    dominant = getattr(ev, "dominant_channel", None)
                    band = getattr(ev, "dominant_band", None)
                    rcv_band = ("--" if dominant is None else f"RCV{dominant}") + ("" if band is None else f" / B{band}")
                    before = getattr(ev, "before_power_ratio", None)
                    after = getattr(ev, "after_power_ratio", None)
                    power = "--"
                    if before is not None or after is not None:
                        b = "?" if before is None else f"{float(before):.3f}"
                        a = "?" if after is None else f"{float(after):.3f}"
                        power = f"{b} → {a}"
                    severity=str(getattr(ev,"severity","") or "").strip()
                    result_text=str(getattr(ev,"result","") or getattr(ev,"action","") or "").strip()
                    state_parts=[family + (f" R{rule}" if rule is not None else "")]
                    if severity and severity.lower()!=family.lower(): state_parts.append(severity)
                    if result_text and result_text.lower() not in {p.lower() for p in state_parts}: state_parts.append(result_text)
                    vals = [
                        "--" if t is None else f"{t:.3f} s",
                        " · ".join(p for p in state_parts if p),
                        rcv_band,
                        power,
                        self._ci_event_why(ev),
                    ]
                    for col, value in enumerate(vals):
                        item = QTableWidgetItem(str(value))
                        item.setToolTip(str(value))
                        self.ci_linked_event_table.setItem(row, col, item)
            finally:
                self.ci_linked_event_table.setUpdatesEnabled(True)

        mode = self.ci_linked_mode.currentIndex()
        self.ci_linked_stack.setCurrentIndex(max(0, min(2, int(mode))))
        if mode == 0:
            self._draw_ci_linked_rcv_probable(self._ci_event_preview_result or self.default_cavitation_likelihood)
        if self._ci_linked_selected_time is not None and mode in (1, 2):
            self._ci_linked_focus_time(float(self._ci_linked_selected_time), force_visible=False)

    def _make_ci_collapsible_section(self, title: str, content: QWidget, expanded: bool = False):
        host = QWidget()
        layout = QVBoxLayout(host)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(3)
        toggle = QToolButton()
        toggle.setText(title)
        toggle.setCheckable(True)
        toggle.setChecked(expanded)
        toggle.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        toggle.setArrowType(Qt.ArrowType.DownArrow if expanded else Qt.ArrowType.RightArrow)
        toggle.setStyleSheet("QToolButton { font-weight: 600; text-align: left; padding: 4px 6px; border: 1px solid #c6d1da; background: #f5f8fb; }")
        layout.addWidget(toggle)
        content.setVisible(expanded)
        layout.addWidget(content)
        def _on_toggled(checked: bool):
            toggle.setArrowType(Qt.ArrowType.DownArrow if checked else Qt.ArrowType.RightArrow)
            content.setVisible(checked)
        toggle.toggled.connect(_on_toggled)
        return host, content

    def _ci_toggle_images(self, checked: bool):
        if hasattr(self, "ci_images_host"):
            self.ci_images_host.setVisible(bool(checked))
        if checked:
            QTimer.singleShot(0, self._ci_fit_all_visuals)

    def _ci_likelihood_fit(self):
        if hasattr(self, "ci_likelihood_plot"):
            self.ci_likelihood_plot.autoRange(padding=0.02)

    def _ci_fit_all_visuals(self):
        self._ci_likelihood_fit()
        self._ci_mr_fit()



    def _main_tab_changed(self, _index: int) -> None:
        if not hasattr(self,"tabs") or not hasattr(self,"sonication_summary_tab"): return
        if self.tabs.currentWidget() is self.sonication_summary_tab and getattr(self,"_sonication_summary_needs_detail",False):
            self._sonication_summary_needs_detail=False
            self._refresh_sonication_summary()

    def _seed_sonication_summary_fast(self) -> None:
        """Populate cheap exported values without CPC/RCA analysis during ZIP load."""
        if not hasattr(self,"sonication_summary_table"): return
        count=len(self.package.sonications) if self.package else 0
        self._sonication_summary_rows=[]
        self.sonication_summary_table.setRowCount(count)
        for row,son in enumerate(self.package.sonications if self.package else []):
            power=self._summary_finite(getattr(son,"actual_power_w",None))
            duration=self._summary_finite(getattr(son,"actual_duration_s",None))
            energy=self._summary_finite(getattr(son,"actual_energy_j",None))
            basic={"number":row+1,"name":getattr(son,"name",f"Sonication {row+1}"),
                   "cavitation_status":"Cavitation detail pending","cavitation":False,"rca_score":None,
                   "power":power,"duration":duration,"energy":energy,"start_temp":None,"peak_temp":None,"delta_temp":None,
                   "frames":int(getattr(son,"replay_frame_count",0) or 0)}
            self._sonication_summary_rows.append(basic)
            vals=[basic["number"],basic["name"],basic["cavitation_status"],"-",
                  "-" if power is None else f"{power:.1f}","-" if duration is None else f"{duration:.2f}",
                  "-" if energy is None else f"{energy:.1f}","-","-","-",basic["frames"]]
            for col,val in enumerate(vals):
                item=QTableWidgetItem(str(val)); item.setToolTip(str(val)); self.sonication_summary_table.setItem(row,col,item)
        self._draw_sonication_summary_chart()

    def _build_sonication_summary_tab(self) -> QWidget:
        page=QWidget(); layout=QVBoxLayout(page); controls=QHBoxLayout()
        controls.addWidget(QLabel("Chart:"))
        self.sonication_summary_metric=QComboBox()
        self.sonication_summary_metric.addItems([
            "Cavitation status","Cavitation RCA score","Power (W)","Duration (s)",
            "Energy (J)","Start temperature (°C)","Peak temperature (°C)","ΔT (°C)"
        ])
        self.sonication_summary_metric.currentIndexChanged.connect(self._draw_sonication_summary_chart)
        controls.addWidget(self.sonication_summary_metric)
        self.sonication_summary_cav_overlay=QCheckBox("Cavitation marker overlay")
        self.sonication_summary_cav_overlay.setChecked(True)
        self.sonication_summary_cav_overlay.toggled.connect(self._draw_sonication_summary_chart)
        controls.addWidget(self.sonication_summary_cav_overlay); controls.addStretch(1); layout.addLayout(controls)
        self.sonication_summary_table=QTableWidget(0,11)
        self.sonication_summary_table.setHorizontalHeaderLabels([
            "Sonication No.","Name","Cavitation status","RCA score","Power","Duration","Energy",
            "Start temperature","Peak temperature","ΔT","Replay frames"
        ])
        self.sonication_summary_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.sonication_summary_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.sonication_summary_table.setAlternatingRowColors(True)
        self.sonication_summary_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.sonication_summary_table.horizontalHeader().setStretchLastSection(True)
        self.sonication_summary_table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.sonication_summary_table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.sonication_summary_table.setWordWrap(False)
        self.sonication_summary_table.setColumnWidth(2,300)
        self.sonication_summary_table.cellDoubleClicked.connect(self._sonication_summary_jump)
        layout.addWidget(self.sonication_summary_table,3)
        self.sonication_summary_plot=pg.PlotWidget(); self.sonication_summary_plot.showGrid(x=True,y=True,alpha=0.18)
        self.sonication_summary_plot.setLabel("bottom","Sonication No.")
        self.sonication_summary_current_line=pg.InfiniteLine(angle=90,movable=False,pen=pg.mkPen("#00b4d8",width=2))
        self.sonication_summary_plot.addItem(self.sonication_summary_current_line); layout.addWidget(self.sonication_summary_plot,2)
        self._sonication_summary_rows=[]
        return page

    def _sonication_summary_jump(self, row: int, _column: int = 0) -> None:
        if not self.package or not (0 <= int(row) < len(self.package.sonications)):
            return
        self._select_sonication_index(int(row))
        if hasattr(self, "tabs") and hasattr(self, "replay_tab"):
            self.tabs.setCurrentWidget(self.replay_tab)

    @staticmethod
    def _summary_finite(value):
        """Parse summary numbers even when UI metadata includes units (e.g. '429.8 W')."""
        try:
            if isinstance(value,str):
                match=re.search(r"[-+]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][-+]?\\d+)?",value)
                if not match:
                    return None
                value=float(match.group(0))
            else:
                value=float(value)
            return value if np.isfinite(value) else None
        except (TypeError,ValueError): return None

    def _summary_metadata_value(self,meta,*keys):
        summary=getattr(meta,"summary",{}) or {}
        for key in keys:
            if key in summary:
                value=self._summary_finite(summary.get(key))
                if value is not None: return value
        return None

    def _build_one_sonication_summary(self,index:int)->dict:
        son=self.package.sonications[index]
        meta=self.metadata_service.read(son,self.package,index+1)
        # DiscoveryService already maps SonicationSummary.xml into the model.
        # Use those numeric fields first; formatted metadata strings are fallback only.
        power=self._summary_finite(getattr(son,"actual_power_w",None))
        if power is None: power=self._summary_metadata_value(meta,"Actual Power","Power")
        duration=self._summary_finite(getattr(son,"actual_duration_s",None))
        if duration is None: duration=self._summary_metadata_value(meta,"Actual Duration","Duration")
        energy=self._summary_finite(getattr(son,"actual_energy_j",None))
        if energy is None: energy=self._summary_metadata_value(meta,"Actual Energy","Energy")
        if duration is None:
            duration=self.acoustic_control_service.measured_duration_for_sonication(self.package.workspace,index)
        if energy is None and power is not None and duration is not None:
            energy=float(power)*float(duration)
        max_values=[]
        for fi in range(max(0,int(son.replay_frame_count))):
            try:
                fd=self.replay.frame(son,fi); v=self._summary_finite(fd.maximum_temperature)
                if v is not None: max_values.append(v)
            except Exception: continue
        start_temp=float(max_values[0]) if max_values else None
        peak_temp=float(max(max_values)) if max_values else None
        delta_temp=float(peak_temp-start_temp) if peak_temp is not None and start_temp is not None else None
        cav_status="Unavailable"; rca_score=None; cav_detected=False
        try:
            cpc=self.hydrophone_replay_service.build(self.package.cpc_spectrum_files,index,len(self.package.sonications))
            if cpc is not None and cpc.frames:
                validation=getattr(cpc,"vendor_control_validation",None); history=getattr(cpc,"vendor_history_validation",None)
                preferred=getattr(history,"log_session_index",None) if history is not None else None
                cycles=getattr(validation,"event_cycles",np.asarray([],int)) if validation is not None else np.asarray([],int)
                predicted=getattr(validation,"predicted_power_ratio",np.asarray([],float)) if validation is not None else np.asarray([],float)
                timeline=self.cavitation_control_timeline_service.parse(cpc.source_fft or cpc.source_raw or self.package.workspace,
                    getattr(cpc,"vendor_profile",None),preferred,cycles,predicted)
                events=list(getattr(timeline,"events",[]) or [])
                families={}; rules={}
                for ev in events:
                    fam=str(getattr(ev,"family","") or "Unknown")
                    families[fam]=families.get(fam,0)+1
                    key=(fam,getattr(ev,"rule_index",None)); rules[key]=rules.get(key,0)+1
                # Increase is a recovery/control state; it does not by itself mean
                # that cavitation requiring intervention was detected.
                non_increase=[ev for ev in events if str(getattr(ev,"family","") or "").lower()!="increase"]
                cav_detected=bool(non_increase)
                if non_increase:
                    parts=[]
                    for (fam,rule),count in sorted(rules.items(),key=lambda kv:(kv[0][0],-kv[1])):
                        if fam.lower()=="increase": continue
                        label=f"{fam}" + (f" R{rule}" if rule is not None else "")
                        parts.append(f"{label}×{count}")
                    cav_status=" / ".join(parts[:4]) or "Control event detected"
                    inc=families.get("Increase",0)
                    if inc: cav_status+=f" · Increase×{inc}"
                elif families.get("Increase",0):
                    cav_status=f"Increase only×{families['Increase']} · no decrease/safety event"
                else:
                    cav_status="No cavitation-control event"
                rca=self.cavitation_root_cause_service.analyze(sonication_number=index+1,events=events,replay=cpc,
                    power=power,energy=energy,duration=duration,start_temp=start_temp,peak_temp=peak_temp,delta_temp=delta_temp)
                rca_score=self._summary_finite(getattr(rca,"root_cause_score",None))
        except Exception as exc:
            LOG.debug("Summary cavitation unavailable for Sonication %s: %s",index+1,exc)
        return {"number":index+1,"name":getattr(son,"name",f"Sonication {index+1}"),
            "cavitation_status":cav_status,"cavitation":cav_detected,"rca_score":rca_score,
            "power":power,"duration":duration,"energy":energy,"start_temp":start_temp,
            "peak_temp":peak_temp,"delta_temp":delta_temp,"frames":int(getattr(son,"replay_frame_count",0) or 0)}

    def _cancel_sonication_summary_worker(self) -> None:
        worker=getattr(self,"_sonication_summary_worker",None)
        thread=getattr(self,"_sonication_summary_thread",None)
        try:
            if worker is not None: worker.cancel()
        except Exception:
            pass
        try:
            if thread is not None and thread.isRunning():
                thread.quit(); thread.wait(120)
        except Exception:
            pass
        self._sonication_summary_worker=None; self._sonication_summary_thread=None

    def _refresh_sonication_summary(self)->None:
        if not hasattr(self,"sonication_summary_table"):
            return
        self._cancel_sonication_summary_worker()
        count=len(self.package.sonications) if self.package else 0
        # Always show cheap exported values immediately. The UI must never sit on
        # detailed CPC/RCA/Thermal analysis continues in the worker.
        self._seed_sonication_summary_fast()
        self._sonication_summary_generation=getattr(self,"_sonication_summary_generation",0)+1
        generation=self._sonication_summary_generation
        if not count:
            self._draw_sonication_summary_chart(); return
        thread=QThread(self)
        worker=SonicationSummaryDetailWorker(count,generation,self._build_one_sonication_summary)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.rowReady.connect(self._sonication_summary_row_ready)
        worker.finished.connect(self._sonication_summary_finished)
        worker.finished.connect(thread.quit)
        thread.finished.connect(worker.deleteLater); thread.finished.connect(thread.deleteLater)
        self._sonication_summary_thread=thread; self._sonication_summary_worker=worker
        thread.start()

    def _sonication_summary_row_ready(self,row:int,data,generation:int)->None:
        if generation!=getattr(self,"_sonication_summary_generation",0) or not isinstance(data,dict):
            return
        if data.get("_error"):
            item=QTableWidgetItem(f"Detail unavailable: {data['_error']}"); item.setToolTip(str(data['_error']))
            self.sonication_summary_table.setItem(int(row),2,item); return
        while len(self._sonication_summary_rows)<=int(row): self._sonication_summary_rows.append(None)
        self._sonication_summary_rows[int(row)]=data
        vals=[data["number"],data["name"],data["cavitation_status"],
            "-" if data["rca_score"] is None else f'{data["rca_score"]:.0f}',
            "-" if data["power"] is None else f'{data["power"]:.1f}',
            "-" if data["duration"] is None else f'{data["duration"]:.2f}',
            "-" if data["energy"] is None else f'{data["energy"]:.1f}',
            "-" if data["start_temp"] is None else f'{data["start_temp"]:.1f}',
            "-" if data["peak_temp"] is None else f'{data["peak_temp"]:.1f}',
            "-" if data["delta_temp"] is None else f'{data["delta_temp"]:.1f}',data["frames"]]
        for col,val in enumerate(vals):
            item=QTableWidgetItem(str(val)); item.setToolTip(str(val)); self.sonication_summary_table.setItem(int(row),col,item)
        self._draw_sonication_summary_chart()

    def _sonication_summary_finished(self,generation:int)->None:
        if generation!=getattr(self,"_sonication_summary_generation",0):
            return
        self._sonication_summary_worker=None; self._sonication_summary_thread=None
        self._draw_sonication_summary_chart()
        self.statusBar().showMessage("Sonication Summary detail ready",1800)

    def _draw_sonication_summary_chart(self)->None:
        if not hasattr(self,"sonication_summary_plot"):return
        plot=self.sonication_summary_plot
        for item in list(plot.listDataItems()):plot.removeItem(item)
        rows=[r for r in getattr(self,"_sonication_summary_rows",[]) if r]
        metric=self.sonication_summary_metric.currentText()
        key={"Cavitation status":"cavitation","Cavitation RCA score":"rca_score","Power (W)":"power",
             "Duration (s)":"duration","Energy (J)":"energy","Start temperature (°C)":"start_temp",
             "Peak temperature (°C)":"peak_temp","ΔT (°C)":"delta_temp"}.get(metric,"cavitation")
        x=[];y=[]
        for r in rows:
            value=(1.0 if r["cavitation"] else 0.0) if key=="cavitation" else r.get(key)
            if value is not None:x.append(r["number"]);y.append(float(value))
        if x:plot.plot(x,y,pen=pg.mkPen(width=2),symbol="o",symbolSize=7)
        if self.sonication_summary_cav_overlay.isChecked():
            cx=[r["number"] for r in rows if r.get("cavitation")]
            if cx:
                top=max(y) if y else 1.0; plot.plot(cx,[top]*len(cx),pen=None,symbol="t",symbolSize=12)
        plot.setLabel("left",metric);plot.setLabel("bottom","Sonication No.")
        self.sonication_summary_current_line.setPos(self.sonication_index+1)

    def _build_sonication_elements_tab(self) -> QWidget:
        page = QWidget()
        root = QVBoxLayout(page)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(5)

        # Workstation-style compact control area. The element map remains the dominant view.
        top = QGroupBox("Sonication element parameters")
        top_grid = QGridLayout(top)
        top_grid.setHorizontalSpacing(8); top_grid.setVerticalSpacing(4)
        top_grid.addWidget(QLabel("Snapshot"), 0, 0)
        self.element_snapshot_combo = QComboBox()
        self.element_snapshot_combo.currentIndexChanged.connect(self._element_snapshot_changed)
        top_grid.addWidget(self.element_snapshot_combo, 0, 1, 1, 2)
        self.element_open_log_btn = QPushButton("Open Sonication Log")
        self.element_open_log_btn.setToolTip("Directly load one or more Sonication .txt/.log files. Loaded files are preferred over Smart Discovery.")
        self.element_open_log_btn.clicked.connect(self._open_sonication_element_logs)
        top_grid.addWidget(self.element_open_log_btn, 0, 3)
        self.element_rescan_btn = QPushButton("Rescan")
        self.element_rescan_btn.setToolTip("Rescan the current Sonication folder first, then the loaded Export workspace.")
        self.element_rescan_btn.clicked.connect(self._rescan_sonication_element_logs)
        top_grid.addWidget(self.element_rescan_btn, 0, 4)
        top_grid.addWidget(QLabel("Display"), 1, 0)
        self.element_parameter_combo = QComboBox()
        self.element_parameter_combo.addItems(["Sonication Phase (1024 reconstructed)", "Logical Phase (observed log)", "Channel Calibration Phase (1024)", "Amplitude (1024 measured)", "Logical amplitude (log)"])
        self.element_parameter_combo.setCurrentText("Sonication Phase (1024 reconstructed)")
        self.element_parameter_combo.currentTextChanged.connect(self._element_parameter_changed)
        top_grid.addWidget(self.element_parameter_combo, 1, 1)
        top_grid.addWidget(QLabel("Layout"), 1, 2)
        self.element_layout_combo = QComboBox()
        self.element_layout_combo.addItems(["Umbrella 16-blade", "Tile 16×64", "Phase dedicated"])
        self.element_layout_combo.setCurrentText("Umbrella 16-blade")
        self.element_layout_combo.currentTextChanged.connect(self._element_layout_changed)
        top_grid.addWidget(self.element_layout_combo, 1, 3)
        self.element_single_sonic_check = QCheckBox("Single Sonication")
        self.element_single_sonic_check.setChecked(True)
        top_grid.addWidget(self.element_single_sonic_check, 1, 4)
        self.element_summary = QLabel("No sonication element log loaded")
        self.element_summary.setWordWrap(True)
        top_grid.addWidget(self.element_summary, 2, 0, 1, 5)
        root.addWidget(top, 0)

        middle = QSplitter(Qt.Orientation.Horizontal)
        map_box = QGroupBox("1024 sonication elements — 16 Blades × 64 channels")
        map_layout = QVBoxLayout(map_box)
        self.element_map = SonicationElementMapWidget()
        self.element_map.elementClicked.connect(self._element_map_clicked)
        map_layout.addWidget(self.element_map, 1)
        self.element_selected_label = QLabel("Selected element: --")
        self.element_selected_label.setObjectName("CurrentValue")
        map_layout.addWidget(self.element_selected_label)
        self.element_focus_label = QLabel("Electronic steering: --")
        self.element_focus_label.setWordWrap(True)
        self.element_focus_label.setObjectName("CurrentValue")
        map_layout.addWidget(self.element_focus_label)
        middle.addWidget(map_box)

        side = QWidget(); side_layout = QVBoxLayout(side); side_layout.setContentsMargins(2,2,2,2); side_layout.setSpacing(4)
        blade_box = QGroupBox("Show Blade")
        blade_grid = QGridLayout(blade_box); blade_grid.setSpacing(2)
        self.element_blade_checks = []
        for blade in range(16):
            cb = QCheckBox(f"Blade {blade + 1}"); cb.setChecked(True)
            cb.toggled.connect(self._element_blade_visibility_changed)
            self.element_blade_checks.append(cb)
            blade_grid.addWidget(cb, blade % 8, blade // 8)
        side_layout.addWidget(blade_box)
        blade_buttons = QHBoxLayout()
        all_btn = QPushButton("All"); all_btn.clicked.connect(lambda: self._set_all_element_blades(True))
        clear_btn = QPushButton("Clear"); clear_btn.clicked.connect(lambda: self._set_all_element_blades(False))
        blade_buttons.addWidget(all_btn); blade_buttons.addWidget(clear_btn)
        side_layout.addLayout(blade_buttons)

        view_box=QGroupBox("3-D view / projection")
        vg=QGridLayout(view_box)
        self.element_projection_combo=QComboBox()
        self.element_projection_combo.addItems(["Perspective","Top XY","Front XZ","Side YZ"])
        self.element_projection_combo.currentTextChanged.connect(self.element_map.set_umbrella_projection)
        self.element_map.viewChanged.connect(self._sync_element_projection_combo)
        reset_view=QPushButton("Reset view"); reset_view.clicked.connect(self._reset_element_3d_view)
        vg.addWidget(QLabel("Projection"),0,0); vg.addWidget(self.element_projection_combo,0,1); vg.addWidget(reset_view,1,0,1,2)
        side_layout.addWidget(view_box)

        channel_box=QGroupBox("Channel selection")
        cg=QGridLayout(channel_box)
        self.element_channel_filter=QComboBox()
        self.element_channel_filter.addItems(["All channels","Active only","ACT amplitude = 0","INI disabled/defect","Blade CH 0–15","Blade CH 16–31","Blade CH 32–47","Blade CH 48–63"])
        self.element_channel_filter.currentTextChanged.connect(self._element_channel_filter_changed)
        self.element_channel_from=QSpinBox(); self.element_channel_from.setRange(0,1023); self.element_channel_from.setValue(0)
        self.element_channel_to=QSpinBox(); self.element_channel_to.setRange(0,1023); self.element_channel_to.setValue(1023)
        apply_range=QPushButton("Apply CH range"); apply_range.clicked.connect(self._element_channel_filter_changed)
        cg.addWidget(self.element_channel_filter,0,0,1,2)
        cg.addWidget(QLabel("CH"),1,0); rg=QHBoxLayout(); rg.addWidget(self.element_channel_from); rg.addWidget(QLabel("–")); rg.addWidget(self.element_channel_to); cg.addLayout(rg,1,1)
        cg.addWidget(apply_range,2,0,1,2)
        side_layout.addWidget(channel_box)

        selected_box = QGroupBox("Selected element")
        sg = QFormLayout(selected_box)
        self.element_selected_ch = QLabel("--"); self.element_selected_blade = QLabel("--"); self.element_selected_amp = QLabel("--"); self.element_selected_phase = QLabel("--")
        sg.addRow("Element CH", self.element_selected_ch); sg.addRow("Blade / CH", self.element_selected_blade); sg.addRow("Amplitude", self.element_selected_amp); sg.addRow("Phase", self.element_selected_phase)
        side_layout.addWidget(selected_box)
        self.element_table_toggle = QCheckBox("Show element table")
        self.element_table_toggle.setChecked(False)
        side_layout.addWidget(self.element_table_toggle)
        side_layout.addStretch(1)
        middle.addWidget(side)
        middle.setSizes([900, 230]); middle.setStretchFactor(0, 1); middle.setStretchFactor(1, 0)
        root.addWidget(middle, 1)

        self.element_table = QTableWidget(0, 8)
        self.element_table.setHorizontalHeaderLabels(["Channel", "Blade", "Blade CH", "Sonication phase", "Calibration phase", "Logical phase", "Amplitude", "Source"])
        self.element_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.element_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.element_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.element_table.cellClicked.connect(self._element_table_clicked)
        self.element_table.setMaximumHeight(220)
        self.element_table.setVisible(False)
        self.element_table_toggle.toggled.connect(self.element_table.setVisible)
        root.addWidget(self.element_table, 0)
        return page

    def _element_parameter_changed(self, _text: str):
        # Geometry layout and phase-value interpretation are independent.
        # Umbrella remains available for any parameter; Phase dedicated is a
        # separate diagnostic view rather than an automatic replacement.
        self._element_snapshot_changed(self.element_snapshot_combo.currentIndex())


    def _element_layout_changed(self, _text: str):
        self._element_snapshot_changed(self.element_snapshot_combo.currentIndex())


    def _open_sonication_element_logs(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Open Sonication element log", "", "Sonication logs (*.txt *.log);;All files (*.*)")
        if not files:
            return
        self._element_direct_log_files = [Path(f) for f in files]
        self._ci_sonic_cache_key = None
        self._update_sonication_elements_page()
        if hasattr(self, 'statusBar'):
            self.statusBar().showMessage(f"Sonication Elements: direct log source loaded ({len(files)} file(s))")

    def _rescan_sonication_element_logs(self):
        self._element_direct_log_files = []
        self._ci_sonic_cache_key = None
        self._update_sonication_elements_page()
        if hasattr(self, 'statusBar'):
            self.statusBar().showMessage("Sonication Elements: Smart Discovery rescanned current Sonication and Export workspace")

    def _set_all_element_blades(self, checked: bool):
        if not hasattr(self, 'element_blade_checks'):
            return
        for cb in self.element_blade_checks:
            cb.blockSignals(True); cb.setChecked(bool(checked)); cb.blockSignals(False)
        self._element_blade_visibility_changed()

    def _element_blade_visibility_changed(self, *_):
        if not hasattr(self, 'element_blade_checks') or not hasattr(self, 'element_map'):
            return
        visible = [i for i, cb in enumerate(self.element_blade_checks) if cb.isChecked()]
        self.element_map.set_visible_blades(visible)

    def _sync_element_projection_combo(self, mode: str):
        if not hasattr(self,"element_projection_combo"):
            return
        self.element_projection_combo.blockSignals(True)
        self.element_projection_combo.setCurrentText(str(mode))
        self.element_projection_combo.blockSignals(False)

    def _reset_element_3d_view(self):
        if not hasattr(self,"element_map"):
            return
        self.element_map.reset_umbrella_view()
        self._sync_element_projection_combo("Perspective")

    def _element_channel_filter_changed(self, *_):
        if not hasattr(self,"element_map"): return
        lo=getattr(self,"element_channel_from",None).value() if hasattr(self,"element_channel_from") else 0
        hi=getattr(self,"element_channel_to",None).value() if hasattr(self,"element_channel_to") else 1023
        if lo>hi: lo,hi=hi,lo
        channels=set(range(lo,hi+1))
        mode=self.element_channel_filter.currentText() if hasattr(self,"element_channel_filter") else "All channels"
        if mode=="Active only":
            channels={ch for ch in channels if ch not in self.element_map.disabled_channels and ch not in self.element_map.defect_channels and ch not in self.element_map.act_zero_channels}
        elif mode=="ACT amplitude = 0":
            channels &= set(self.element_map.act_zero_channels)
        elif mode=="INI disabled/defect":
            channels &= (set(self.element_map.disabled_channels)|set(self.element_map.defect_channels))
        elif mode.startswith("Blade CH "):
            a,b=map(int,re.findall(r"\\d+",mode)[-2:])
            channels={ch for ch in channels if a <= (ch%64) <= b}
        self.element_map.set_visible_channels(channels)

    def _element_map_clicked(self, channel: int):
        self._select_element_channel(int(channel))

    def _element_table_clicked(self, row: int, _column: int = 0):
        item = self.element_table.item(row, 0)
        if item is None:
            return
        try:
            self._select_element_channel(int(item.text()))
        except ValueError:
            return

    @staticmethod
    def _read_ini_zero_channels(path: Path, section_name: str) -> set[int]:
        out=set()
        try:
            text=Path(path).read_text(encoding="utf-8",errors="ignore")
        except Exception:
            return out
        current=""
        for raw in text.splitlines():
            line=raw.split(";",1)[0].strip()
            if not line:
                continue
            if line.startswith("[") and line.endswith("]"):
                current=line[1:-1].strip().upper()
                continue
            if current != section_name.upper():
                continue
            m=re.match(r"CH(\d+)\s*=\s*([-+0-9.eE]+)",line,re.I)
            if m:
                try:
                    if abs(float(m.group(2))) <= 1e-12:
                        out.add(int(m.group(1)))
                except ValueError:
                    pass
        return out

    def _sonication_act_channel_values(self):
        """Read ACT commanded amplitude/phase without changing status semantics."""
        amplitude={}; phase={}
        if self.current is None:
            return amplitude,phase
        for path in list(getattr(self.current,"act_files",[]) or []):
            try:
                text=Path(path).read_text(encoding="utf-8",errors="ignore")
            except Exception:
                continue
            for m in re.finditer(r"^Element(\d+)\s*=\s*([-+0-9.eE]+)\s+([-+0-9.eE]+)",text,re.M):
                try:
                    ch=int(m.group(1))-1
                    if 0 <= ch < 1024:
                        amplitude[ch]=float(m.group(2))
                        phase[ch]=float(m.group(3))
                except Exception:
                    pass
            if amplitude:
                break
        return amplitude,phase

    def _exported_requested_steering(self):
        """Return an exported steering vector only when the workspace is unambiguous.

        SpotValidation CLCC logs express X/Y/Z steering in transducer coordinates.
        If multiple distinct vectors exist in the export, time matching is required
        and this helper deliberately returns None instead of guessing.
        """
        if not self.package:
            return None
        found=[]
        pattern=re.compile(
            r"CLCC Burn Spot fields:.*?X <([-+0-9.]+)>\s+Y <([-+0-9.]+)>\s+Z <([-+0-9.]+)>",
            re.I
        )
        for path in Path(self.package.workspace).rglob("*SpotValidation*.txt"):
            try:
                text=path.read_text(encoding="utf-8",errors="ignore")
            except Exception:
                continue
            for m in pattern.finditer(text):
                try:
                    found.append(tuple(float(v) for v in m.groups()))
                except Exception:
                    pass
        unique=[]
        for item in found:
            if not any(np.linalg.norm(np.asarray(item)-np.asarray(old)) < 1e-6 for old in unique):
                unique.append(item)
        return unique[0] if len(unique)==1 else None

    @staticmethod
    def _parse_xyz_header_value(value):
        if value is None:return None
        nums=re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?",str(value))
        if len(nums)<3:return None
        try:return tuple(float(v) for v in nums[-3:])
        except Exception:return None

    def _skullmeasures_focus_evidence(self):
        if not self.current or not self.package:return {}
        data=self.skull_measures_service.find_and_read(
            self.current.folder,self.sonication_index+1,self.package.workspace
        )
        header=dict(getattr(data,"header",{}) or {})
        focal=None; frequency=None; vwater=None
        for key,value in header.items():
            kl=str(key).strip().lower()
            if "focalpointpos" in kl:
                focal=self._parse_xyz_header_value(value)
            elif kl=="frequency":
                try:frequency=float(re.findall(r"[-+0-9.eE]+",str(value))[0])*1e6
                except Exception:pass
            elif kl=="vwater":
                try:vwater=float(re.findall(r"[-+0-9.eE]+",str(value))[0])
                except Exception:pass
        return {"data":data,"focal_point_xyz_mm":focal,"frequency_hz":frequency,
                "water_speed_m_s":vwater,"source":getattr(data,"source",None)}

    def _phase_focus_for_snapshot(self, snap, geometry_xyz, act_zero, disabled, defect):
        steering_phase={}; total_phase={}; measured_amp={}
        for value in list(getattr(snap,"values",[]) or []):
            ch=int(getattr(value,"channel",-1))
            sp=getattr(value,"steering_phase_rad",None)
            tp=getattr(value,"sonication_phase_rad",None)
            if sp is not None:
                try:steering_phase[ch]=float(sp)
                except Exception:pass
            if tp is not None:
                try:total_phase[ch]=float(tp)
                except Exception:pass
            a=getattr(value,"measured_amplitude",None)
            if a is not None:
                try:measured_amp[ch]=float(a)
                except Exception:pass

        act_amp,_act_phase=self._sonication_act_channel_values()
        amplitude=dict(measured_amp)
        # ACT amplitude is the preferred weighting when available.
        amplitude.update(act_amp)

        evidence=self._skullmeasures_focus_evidence()
        frequency=evidence.get("frequency_hz") or getattr(snap,"measured_frequency_hz",None)
        sound_speed=evidence.get("water_speed_m_s") or 1500.0
        excluded=set(act_zero)|set(disabled)|set(defect)

        sphere=PhaseFocusService._robust_sphere_center(
            np.asarray([geometry_xyz[ch] for ch in sorted(geometry_xyz)],float)
        ) if geometry_xyz else None
        fitted_focus=tuple(map(float,sphere[0])) if sphere is not None else None
        exported_focal=evidence.get("focal_point_xyz_mm")
        # R0116: the exported SkullMeasures focal point is the primary reference
        # whenever present. A sphere-fit center is retained only as geometry QA;
        # it must not silently become the displayed treatment focus.
        reference_focus=exported_focal if exported_focal is not None else fitted_focus
        requested=self._exported_requested_steering()

        phase_for_steering=steering_phase if len(steering_phase)>=64 else total_phase
        result=PhaseFocusService.estimate(
            geometry_xyz,phase_for_steering,amplitude,frequency,
            excluded_channels=excluded,
            requested_steering_xyz_mm=requested,
            geometric_focus_xyz_mm=reference_focus,
            sound_speed_m_s=sound_speed,
        )
        ref_text=("Exported SkullMeasures FocalPointPos" if exported_focal is not None else "geometry sphere-fit fallback")
        qa_text=""
        if exported_focal is not None and fitted_focus is not None:
            qa_error=float(np.linalg.norm(np.asarray(exported_focal,float)-np.asarray(fitted_focus,float)))
            qa_text=f" Geometry-fit reference differs by {qa_error:.2f} mm."
        result.note += (
            f" Reference focus: {ref_text}." + qa_text +
            (" Phase input: wrap(Total Phase Shift - Phase Correction)."
             if len(steering_phase)>=64
             else " Phase Correction unavailable; total phase fallback includes skull correction.")
        )
        return result


    def _sonication_element_geometry(self):
        """Map exported SkullMeasures Element X/Y/Z to zero-based transmit channels."""
        if not self.current or not self.package:
            return {}, ""
        data=self.skull_measures_service.find_and_read(
            self.current.folder,self.sonication_index+1,self.package.workspace
        )
        out={}
        for el in list(getattr(data,"elements",[]) or []):
            try:
                ch=int(el.number)-1
                x=float(el.values.get("Element X"))
                y=float(el.values.get("Element Y"))
                z=float(el.values.get("Element Z"))
            except Exception:
                continue
            if 0 <= ch < 1024 and np.isfinite(x) and np.isfinite(y) and np.isfinite(z):
                out[ch]=(x,y,z)
        source=getattr(data,"source",None)
        return out,(source.name if source is not None else "")

    def _sonication_element_channel_states(self):
        """Return distinct channel-state layers without conflating their semantics.

        ACT amplitude=0:
            Sonication-specific commanded zero amplitude.
            Log evidence comes from SkullHeating OffReason when available.
        DISABLED:
            DisabledReflectionChannels.ini only.
        DEFECT:
            DisconnectedChannels.ini only.
        """
        act_zero=set(); act_reasons={}; disabled=set(); defect=set(); sources={}
        if self.current is not None:
            for path in list(getattr(self.current,"act_files",[]) or []):
                try:
                    text=Path(path).read_text(encoding="utf-8",errors="ignore")
                except Exception:
                    continue
                for m in re.finditer(r"^Element(\d+)\s*=\s*([-+0-9.eE]+)",text,re.M):
                    try:
                        if abs(float(m.group(2))) <= 1e-12:
                            ch=int(m.group(1))-1  # ACT Element numbering is 1-based.
                            if 0 <= ch < 1024:
                                act_zero.add(ch)
                    except ValueError:
                        pass

            # SkullHeating explicitly documents:
            # ErrType=-1 => turned OFF
            # OffReason 0=OffByAlgorithm, 2=OffByNPR, 3=OffManually, 4=OffByApod, 5=OffByCPC
            reason_names={0:"OffByAlgorithm",2:"OffByNPR",3:"OffManually",4:"OffByApod",5:"OffByCPC"}
            folder=Path(getattr(self.current,"folder","") or "")
            if folder.is_dir():
                for path in folder.glob("SkullHeating_sonic*.log"):
                    try:
                        text=path.read_text(encoding="utf-8",errors="ignore")
                    except Exception:
                        continue
                    for raw in text.splitlines():
                        parts=raw.split()
                        if len(parts) < 3 or not parts[0].isdigit():
                            continue
                        try:
                            element_no=int(parts[0]); err=int(parts[1]); off=int(parts[2])
                        except ValueError:
                            continue
                        ch=element_no-1
                        if ch in act_zero and err == -1:
                            reason=reason_names.get(off,f"OffReason={off}")
                            act_reasons[ch]=f"{reason} · {path.name}"

        if self.package:
            workspace=Path(self.package.workspace)
            disabled_paths=list(workspace.rglob("DisabledReflectionChannels.ini"))
            defect_paths=list(workspace.rglob("DisconnectedChannels.ini"))
            if disabled_paths:
                disabled=self._read_ini_zero_channels(disabled_paths[0],"AMPLITUDE_AND_PHASE_CORRECTIONS")
                for ch in disabled: sources[ch]=disabled_paths[0].name
            if defect_paths:
                defect=self._read_ini_zero_channels(defect_paths[0],"AMPLITUDE_AND_PHASE_CORRECTIONS")
                for ch in defect:
                    prev=sources.get(ch)
                    sources[ch]=(prev+" + " if prev else "")+defect_paths[0].name

        return act_zero,act_reasons,disabled,defect,sources

    def _select_element_channel(self, channel: int):
        snaps = getattr(self, '_ci_sonic_snapshots', [])
        idx = self.element_snapshot_combo.currentIndex() if hasattr(self, 'element_snapshot_combo') else -1
        if not (0 <= idx < len(snaps)):
            return
        snap = snaps[idx]
        value = next((v for v in snap.values if int(v.channel) == int(channel)), None)
        if value is None:
            return
        self.element_map.set_selected_channel(channel)
        blade = int(channel) // 64 + 1; blade_ch = int(channel) % 64
        mamp = '--' if value.measured_amplitude is None else f"{value.measured_amplitude:.6g}"
        mphase = '--' if value.measured_phase_rad is None else f"{value.measured_phase_rad:.6f} rad / {float(value.measured_phase_rad) * 180.0 / np.pi:.3f}°"
        sphase = '--' if getattr(value,'sonication_phase_rad',None) is None else f"{value.sonication_phase_rad:.6f} rad / {float(value.sonication_phase_rad) * 180.0 / np.pi:.3f}°"
        corrphase = '--' if getattr(value,'phase_correction_rad',None) is None else f"{value.phase_correction_rad:.6f} rad"
        steerphase = '--' if getattr(value,'steering_phase_rad',None) is None else f"{value.steering_phase_rad:.6f} rad"
        lamp = '--' if value.logical_amplitude is None else f"{value.logical_amplitude:.6g}"
        lphase = '--' if value.logical_phase_rad is None else f"{value.logical_phase_rad:.6f} rad / {float(value.logical_phase_rad) * 180.0 / np.pi:.3f}°"
        state=self.element_map.channel_state(channel)
        state_source=self.element_map.channel_state_sources.get(channel,"")
        act_reason=self.element_map.act_zero_reasons.get(channel,"")
        state_detail=state
        if state_source: state_detail+=f" · INI: {state_source}"
        if act_reason: state_detail+=f" · {act_reason}"
        self.element_selected_label.setText(
            f"Selected Channel {channel} · Blade {blade} / CH {blade_ch} · {state_detail} · "
            f"Sonication phase {sphase} · Calibration {mphase} · Logical {lphase}"
        )
        self.element_selected_ch.setText(f"{channel} · {state}")
        self.element_selected_blade.setText(f"Blade {blade} / CH {blade_ch}")
        self.element_selected_amp.setText(f"Measured {mamp} / Logical {lamp}")
        self.element_selected_phase.setText(
            f"Total {sphase} / Skull correction {corrphase} / Steering residual {steerphase} / "
            f"Calibration {mphase} / Logical {lphase}"
        )
        for row in range(self.element_table.rowCount()):
            item = self.element_table.item(row, 0)
            if item is not None and item.text() == str(channel):
                self.element_table.selectRow(row); break

    def _load_sonic_snapshots_if_needed(self):
        direct = tuple(str(Path(p)) for p in getattr(self, '_element_direct_log_files', []) if Path(p).is_file())
        if not self.package and not direct:
            self._ci_sonic_snapshots = []
            return []
        workspace = Path(self.package.workspace) if self.package else Path(direct[0]).parent
        preferred = Path(self.current.folder) if self.current is not None and getattr(self.current, 'folder', None) else None
        target_hz = ((self.current.main_frequency_hz if self.current else None) or (self.package.main_frequency_hz if self.package else None) or 650000.0)
        key = (str(workspace), self.sonication_index, direct, float(target_hz))
        if getattr(self, "_ci_sonic_cache_key", None) != key:
            self._ci_sonic_cache_key = key
            self._ci_sonic_snapshots = self.sonication_log_receiver_service.read_snapshots(
                workspace, preferred_folder=preferred, sonication_number=(self.sonication_index + 1 if self.sonication_index >= 0 else None),
                direct_files=[Path(p) for p in direct] if direct else None,
                target_frequency_hz=float(target_hz),
            )
        return getattr(self, "_ci_sonic_snapshots", [])

    def _element_snapshot_changed(self, index: int):
        if not hasattr(self, 'element_table'):
            return
        snaps = getattr(self, '_ci_sonic_snapshots', [])
        self.element_table.setRowCount(0)
        if not (0 <= index < len(snaps)):
            self.element_summary.setText('No sonication element log loaded')
            self.element_map.configure(None, self.element_parameter_combo.currentText(), self.element_layout_combo.currentText())
            return
        snap = snaps[index]
        measured_amps = [float(v.measured_amplitude) for v in snap.values if v.measured_amplitude is not None]
        measured_phases = [float(v.measured_phase_rad) for v in snap.values if v.measured_phase_rad is not None]
        declared = '?' if snap.declared_channels is None else str(snap.declared_channels)
        mfreq = '--' if snap.measured_frequency_hz is None else f"{snap.measured_frequency_hz/1e6:.3f} MHz"
        msource = snap.measured_source.name if snap.measured_source is not None else 'not found'
        son_phase_count=sum(1 for v in snap.values if getattr(v,'sonication_phase_rad',None) is not None)
        son_phase_source=next((getattr(v,'sonication_phase_source',None) for v in snap.values if getattr(v,'sonication_phase_source',None) is not None),None)
        son_phase_name=son_phase_source.name if son_phase_source is not None else 'not found'
        self.element_summary.setText(f"Snapshot {index + 1} · declared {declared} · Sonication Phase {son_phase_count}/1024 ({son_phase_name}) · Calibration {snap.measured_decoded_channels}/1024 @ {mfreq} ({msource}) · Logical observed {snap.logical_decoded_channels}/1024 · sonication log {snap.source.name}")
        for value in snap.values:
            r = self.element_table.rowCount(); self.element_table.insertRow(r)
            mamp = '--' if value.measured_amplitude is None else f"{value.measured_amplitude:.6g}"
            mphase = '--' if value.measured_phase_rad is None else f"{value.measured_phase_rad:.6f}"
            sphase = '--' if getattr(value,'sonication_phase_rad',None) is None else f"{value.sonication_phase_rad:.6f}"
            lamp = '--' if value.logical_amplitude is None else f"{value.logical_amplitude:.6g}"
            lphase = '--' if value.logical_phase_rad is None else f"{value.logical_phase_rad:.6f}"
            source_obj=getattr(value,'sonication_phase_source',None) or value.measured_source
            source = source_obj.name if source_obj is not None else snap.source.name
            vals = [str(value.channel), f"Blade {value.blade_number}", str(value.blade_channel), sphase, mphase, lphase, mamp, source]
            for c, v in enumerate(vals): self.element_table.setItem(r, c, QTableWidgetItem(v))
        self.element_map.configure(snap, self.element_parameter_combo.currentText(), self.element_layout_combo.currentText())
        geometry_xyz,geometry_source=self._sonication_element_geometry()
        self.element_map.set_channel_geometry(geometry_xyz,geometry_source)
        act_zero,act_reasons,disabled,defect,sources=self._sonication_element_channel_states()
        self.element_map.set_channel_states(
            act_zero=act_zero,act_reasons=act_reasons,disabled=disabled,defect=defect,sources=sources
        )
        focus_result=self._phase_focus_for_snapshot(snap,geometry_xyz,act_zero,disabled,defect)
        self.element_map.set_phase_focus_result(focus_result)
        if getattr(focus_result,"steering_xyz_mm",None) is not None:
            dx,dy,dz=focus_result.steering_xyz_mm
            req=getattr(focus_result,"requested_steering_xyz_mm",None)
            req_text="" if req is None else f" · Exported request=({req[0]:+.2f},{req[1]:+.2f},{req[2]:+.2f}) mm"
            err=getattr(focus_result,"requested_error_mm",None)
            err_text="" if err is None else f" · request error={err:.2f} mm"
            self.element_focus_label.setText(
                f"Electronic steering estimate: ΔX {dx:+.2f} mm · ΔY {dy:+.2f} mm · ΔZ {dz:+.2f} mm · "
                f"|Δr| {focus_result.steering_distance_mm:.2f} mm · coherence {focus_result.coherence:.3f} · "
                f"{focus_result.phase_sign} · {focus_result.confidence}{req_text}{err_text}\n"
                "Steering estimate uses wrap(Total Phase Shift − Phase Correction); map color shows applied Total Phase Shift."
            )
        else:
            self.element_focus_label.setText(f"Electronic steering: {getattr(focus_result,'note','Unavailable')}")
        self.element_summary.setText(
            self.element_summary.text()
            + f" · Geometry XYZ {len(geometry_xyz)}/1024 · ACT amplitude=0 {len(act_zero)} "
            + f"· INI disabled {len(disabled)} · INI defect/disconnected {len(defect)}"
            + ("" if getattr(focus_result,"steering_xyz_mm",None) is None
               else f" · Phase focus Δ=({focus_result.steering_xyz_mm[0]:+.2f},"
                    f"{focus_result.steering_xyz_mm[1]:+.2f},{focus_result.steering_xyz_mm[2]:+.2f}) mm")
        )
        self._element_blade_visibility_changed()
        selected = getattr(self.element_map, 'selected_channel', None)
        if selected is not None:
            self._select_element_channel(selected)

    def _update_sonication_elements_page(self):
        if not hasattr(self, 'element_snapshot_combo'):
            return
        snaps = self._load_sonic_snapshots_if_needed()
        current = self.element_snapshot_combo.currentIndex()
        self.element_snapshot_combo.blockSignals(True)
        self.element_snapshot_combo.clear()
        for i, snap in enumerate(snaps):
            tm = snap.timestamp or 'time --'
            self.element_snapshot_combo.addItem(f"{i + 1}: {tm} · {snap.source.name}")
        self.element_snapshot_combo.blockSignals(False)
        if snaps:
            current = len(snaps) - 1 if current < 0 else min(current, len(snaps) - 1)
            self.element_snapshot_combo.setCurrentIndex(current)
            self._element_snapshot_changed(current)
        else:
            self._element_snapshot_changed(-1)
            if hasattr(self, 'element_summary'):
                scope = str(self.current.folder) if self.current is not None else (str(self.package.workspace) if self.package else 'No Export')
                self.element_summary.setText(f"No 1024-element phase/amplitude block found · Smart Discovery scope: {scope} · use Open Sonication Log for direct loading")

    def _ci_mr_drag_wwl(self, dx: float, dy: float):
        """Workstation-style image drag: horizontal changes WL, vertical changes WW."""
        if not hasattr(self, "ci_mr_ww"):
            return
        ww = max(float(self.ci_mr_ww.value()), 1e-9)
        wl = float(self.ci_mr_wl.value())
        # Scale against the current window so the gesture remains useful across raw ranges.
        new_wl = wl + float(dx) * ww / 280.0
        new_ww = ww * float(np.exp(-float(dy) / 220.0))
        new_ww = min(max(new_ww, 1e-6), 1e9)
        self.ci_mr_ww.blockSignals(True); self.ci_mr_wl.blockSignals(True)
        self.ci_mr_ww.setValue(new_ww); self.ci_mr_wl.setValue(new_wl)
        self.ci_mr_ww.blockSignals(False); self.ci_mr_wl.blockSignals(False)
        self._ci_apply_mr_levels()

    def _ci_apply_mr_levels(self, *_):
        if not hasattr(self, "ci_mr_image") or not hasattr(self, "ci_mr_ww"): return
        ww=max(float(self.ci_mr_ww.value()),1e-9); wl=float(self.ci_mr_wl.value())
        self.ci_mr_image.setLevels((wl-ww/2.0, wl+ww/2.0))

    def _ci_mr_auto_levels(self):
        arr=getattr(self, "_ci_mr_last_array", None)
        if arr is None: return
        vals=np.asarray(arr,float); vals=vals[np.isfinite(vals)]
        if not vals.size: return
        lo,hi=map(float,np.percentile(vals,[1,99.5])); ww=max(hi-lo,1e-9); wl=(hi+lo)/2.0
        self.ci_mr_ww.blockSignals(True); self.ci_mr_wl.blockSignals(True)
        self.ci_mr_ww.setValue(ww); self.ci_mr_wl.setValue(wl)
        self.ci_mr_ww.blockSignals(False); self.ci_mr_wl.blockSignals(False); self._ci_apply_mr_levels()

    def _ci_mr_fit(self):
        if hasattr(self,"ci_mr_plot"): self.ci_mr_plot.autoRange(padding=0.01)

    def _ci_event_selected(self, row: int, _column: int = 0):
        events=getattr(self,"_ci_visible_events",[])
        if not (0 <= row < len(events)) or self.default_cpc_replay is None: return
        event=events[row]; replay=self.default_cpc_replay
        idx=None
        cycle=getattr(event,"cycle",None)
        if cycle is not None:
            exact=[i for i,f in enumerate(replay.frames) if getattr(f,"acquisition_cycle",None)==cycle]
            if exact: idx=exact[0]
        if idx is None and getattr(event,"timestamp_s",None) is not None:
            times=np.asarray([float(getattr(f,"acquisition_time_s",np.nan)) for f in replay.frames],float)
            if np.isfinite(times).any(): idx=int(np.nanargmin(np.abs(times-float(event.timestamp_s))))
        if idx is None: return
        try:
            result=self.cavitation_likelihood_service.estimate(replay,idx,event)
        except Exception as exc:
            LOG.debug("Historical cavitation-event preview unavailable: %s", exc)
            return
        # Historical event selection is preview-only. The authoritative
        # default_cavitation_likelihood belongs to the current Replay cursor.
        self._ci_event_preview_result=result
        self._draw_ci_likelihood(result)
        dom=getattr(result,"dominant_channel",None); self.ci_chain_labels["RCV"].setText(f"RCV{dom}" if dom is not None else "--")
        if result.centroid_xy is not None: self.ci_chain_labels["Location"].setText(self._tr("probable", x=result.centroid_xy[0], y=result.centroid_xy[1]))
        family=str(getattr(event,"family","Observed")); ri=getattr(event,"rule_index",None); self.ci_chain_labels["Event"].setText(f"{family} R{ri}" if ri is not None else family)
        event_time=self._ci_event_time(event)
        if event_time is not None:
            self._ci_linked_selected_time=float(event_time)
            self._ci_linked_focus_time(float(event_time),force_visible=True)

    def _ci_sonic_snapshot_changed(self, index: int):
        snaps=getattr(self,"_ci_sonic_snapshots",[])
        self.ci_receiver_log_table.setRowCount(0)
        if not (0 <= index < len(snaps)):
            if hasattr(self,"ci_sonic_declared"): self.ci_sonic_declared.setText("--")
            return
        snap=snaps[index]
        declared='?' if snap.declared_channels is None else str(snap.declared_channels)
        mfreq='--' if snap.measured_frequency_hz is None else f"{snap.measured_frequency_hz/1e6:.3f} MHz"
        self.ci_sonic_declared.setText(f"Declared: {declared} · 16 Blades × 64 CH · measured {snap.measured_decoded_channels}/1024 @ {mfreq} · logical log {snap.logical_decoded_channels}/1024")
        for value in snap.values:
            r=self.ci_receiver_log_table.rowCount(); self.ci_receiver_log_table.insertRow(r)
            mamp='--' if value.measured_amplitude is None else f"{value.measured_amplitude:.6g}"
            mphase='--' if value.measured_phase_rad is None else f"{value.measured_phase_rad:.6f}"
            sphase='--' if getattr(value,'sonication_phase_rad',None) is None else f"{value.sonication_phase_rad:.6f}"
            lphase='--' if value.logical_phase_rad is None else f"{value.logical_phase_rad:.6f}"
            source_obj=getattr(value,'sonication_phase_source',None) or value.measured_source
            source=source_obj.name if source_obj is not None else snap.source.name
            vals=[str(value.channel),f"Blade {value.blade_number}",str(value.blade_channel),sphase,mphase,lphase,('--' if value.measured_amplitude is None else f"{value.measured_amplitude:.6g}"),source]
            for c,v in enumerate(vals): self.ci_receiver_log_table.setItem(r,c,QTableWidgetItem(v))

    def _update_ci_receiver_log(self):
        if not hasattr(self,"ci_receiver_log_table"):
            return
        snaps = self._load_sonic_snapshots_if_needed()
        current = self.ci_sonic_snapshot_combo.currentIndex()
        self.ci_sonic_snapshot_combo.blockSignals(True); self.ci_sonic_snapshot_combo.clear()
        for i,snap in enumerate(snaps):
            tm=snap.timestamp or 'time --'; self.ci_sonic_snapshot_combo.addItem(f"{i+1}: {tm} · {snap.source.name}")
        self.ci_sonic_snapshot_combo.blockSignals(False)
        if snaps:
            current = len(snaps) - 1 if current < 0 else min(current, len(snaps) - 1)
            self.ci_sonic_snapshot_combo.setCurrentIndex(current); self._ci_sonic_snapshot_changed(current)
        else:
            self._ci_sonic_snapshot_changed(-1)


    def _draw_ci_likelihood(self, result) -> None:
        if not hasattr(self, "ci_likelihood_plot"):
            return
        self.ci_likelihood_plot.clear(); self.ci_likelihood_plot.addItem(self.ci_likelihood_image)
        if result is None or np.asarray(result.likelihood_map).size == 0:
            self.ci_likelihood_image.setImage(np.empty((0,0))); return
        arr=np.asarray(result.likelihood_map,float)
        self.ci_likelihood_image.setImage(arr,autoLevels=False,levels=(0,1))
        self.ci_likelihood_image.setRect(QRectF(-1.05,-1.05,2.10,2.10))
        theta=np.linspace(0,2*np.pi,160)
        self.ci_likelihood_plot.plot(np.cos(theta),np.sin(theta),pen=pg.mkPen("#aaaaaa",width=1))
        pos=np.asarray(result.hydrophone_positions,float)
        for ch in range(min(8,len(pos))):
            dominant=(result.dominant_channel is not None and ch==result.dominant_channel)
            active=float(result.per_channel_scores[ch])>0.01
            brush="#f72585" if dominant else "#ffd166" if active else "#4cc9f0"
            self.ci_likelihood_plot.plot([pos[ch,0]],[pos[ch,1]],pen=None,symbol="o",symbolSize=11 if dominant else 7,symbolBrush=brush)
            label=pg.TextItem(f"RCV{ch}",color="#ffffff",anchor=(0.5,1.3)); label.setPos(pos[ch,0],pos[ch,1]); self.ci_likelihood_plot.addItem(label)
        self.ci_likelihood_plot.plot([0],[0],pen=None,symbol="+",symbolSize=12,symbolPen=pg.mkPen("#ffffff",width=2))
        if result.centroid_xy is not None:
            self.ci_likelihood_plot.plot([result.centroid_xy[0]],[result.centroid_xy[1]],pen=None,symbol="x",symbolSize=12,symbolPen=pg.mkPen("#06d6a0",width=2))
        self._ci_likelihood_fit()

    def _draw_ci_mr(self, result, likelihood_result=None) -> None:
        """Show the real treatment MR with a red dashed probable-cavitation region.

        The location is not clipped to the skull; intracranial/extracranial
        classification is a later interpretation step when registered skull
        geometry is trustworthy.
        """
        if not hasattr(self,"ci_mr_plot"):
            return
        self.ci_mr_plot.clear(); self.ci_mr_plot.addItem(self.ci_mr_image)
        if result is None:
            self.ci_mr_image.setImage(np.empty((0,0))); return
        source=np.asarray(getattr(result,"current_image",[]),float)
        if source.ndim!=2 or not source.size:
            source=np.asarray(getattr(result,"correlated_map",[]),float)
        if source.ndim!=2 or not source.size:
            self.ci_mr_image.setImage(np.empty((0,0))); return
        arr=source
        self._ci_mr_last_array=arr
        first=not bool(getattr(self,"_ci_mr_levels_initialized",False))
        self.ci_mr_image.setImage(arr,autoLevels=False)
        if first:
            self._ci_mr_levels_initialized=True; self._ci_mr_auto_levels()
        else: self._ci_apply_mr_levels()
        h,w=arr.shape; self.ci_mr_image.setRect(QRectF(0,0,w,h))

        # Integrated acoustic + MR candidate. A dashed region communicates
        # uncertainty better than the old single X marker.
        point=getattr(likelihood_result,"centroid_xy",None) if likelihood_result is not None else None
        if point is None:
            point=getattr(result,"loss_centroid_xy",None)
        if point is not None:
            nx,ny=point; x=(nx+1)*0.5*(w-1); y=(1-ny)*0.5*(h-1)
            strong=float(getattr(result,"strong_loss_fraction_percent",0.0) or 0.0)
            radius=max(14.0,min(w,h)*(0.045+min(strong,4.0)*0.008))
            theta=np.linspace(0,2*np.pi,160)
            ex=x+radius*np.cos(theta); ey=y+radius*np.sin(theta)
            pen=pg.mkPen("#ff2d2d",width=2.4,style=Qt.PenStyle.DashLine)
            self.ci_mr_plot.plot(ex,ey,pen=pen)
            self.ci_mr_plot.plot([x],[y],pen=None,symbol="o",symbolSize=5,symbolBrush="#ff2d2d",symbolPen="#ff2d2d")
        if first:
            self.ci_mr_plot.setRange(xRange=(0,w),yRange=(0,h),padding=0.01)
        self._ci_mr_fit()

    def _rca_temperature_metrics(self, sonication_index: int) -> dict:
        if not self.package or not (0 <= sonication_index < len(self.package.sonications)):
            return {}
        if sonication_index in self._rca_temperature_cache:
            return dict(self._rca_temperature_cache[sonication_index])
        son=self.package.sonications[sonication_index]
        starts=[]; peaks=[]; deltas=[]
        for i in range(max(1,son.replay_frame_count)):
            try:
                fd=self.replay.frame(son,i)
            except Exception:
                continue
            if fd.mean_temperature is not None and np.isfinite(fd.mean_temperature): starts.append(float(fd.mean_temperature))
            if fd.maximum_temperature is not None and np.isfinite(fd.maximum_temperature): peaks.append(float(fd.maximum_temperature))
            if fd.maximum_delta_temperature is not None and np.isfinite(fd.maximum_delta_temperature): deltas.append(float(fd.maximum_delta_temperature))
        out={
            "start_temp": starts[0] if starts else None,
            "peak_temp": max(peaks) if peaks else None,
            "delta_temp": max(deltas) if deltas else None,
        }
        self._rca_temperature_cache[sonication_index]=dict(out)
        return out

    def _rca_build_timeline_for_index(self, index: int, replay):
        if not self.package or replay is None:
            return None
        try:
            validation=getattr(replay,"vendor_control_validation",None)
            history=getattr(replay,"vendor_history_validation",None)
            preferred=getattr(history,"log_session_index",None) if history is not None else None
            cycles=getattr(validation,"event_cycles",np.asarray([],int)) if validation is not None else np.asarray([],int)
            predicted=getattr(validation,"predicted_power_ratio",np.asarray([],float)) if validation is not None else np.asarray([],float)
            source_path=replay.source_fft or replay.source_raw or self.package.workspace
            return self.cavitation_control_timeline_service.parse(source_path,getattr(replay,"vendor_profile",None),preferred,cycles,predicted)
        except Exception:
            return None

    def _build_current_cavitation_root_cause(self):
        if not self.package or not self.current or self.sonication_index < 0:
            return None
        idx=self.sonication_index
        powers=[]
        for son in self.package.sonications:
            p=son.actual_power_w if son.actual_power_w is not None else son.planned_power_w
            if p is not None and np.isfinite(float(p)): powers.append(float(p))
        treatment_median=float(np.median(powers)) if powers else None
        power=self.current.actual_power_w if self.current.actual_power_w is not None else self.current.planned_power_w
        energy=self.current.actual_energy_j if self.current.actual_energy_j is not None else self.current.planned_energy_j
        duration=self.current.actual_duration_s if self.current.actual_duration_s is not None else self.current.planned_duration_s
        previous_power=None; previous_peak=None; previous_cav=None
        if idx>0:
            prev=self.package.sonications[idx-1]
            previous_power=prev.actual_power_w if prev.actual_power_w is not None else prev.planned_power_w
            previous_peak=self._rca_temperature_metrics(idx-1).get("peak_temp")
            if idx-1 in self._rca_previous_cavitation_cache:
                previous_cav=self._rca_previous_cavitation_cache[idx-1]
            else:
                try:
                    prev_replay=self.hydrophone_replay_service.build(self.package.cpc_spectrum_files,idx-1,len(self.package.sonications))
                    prev_timeline=self._rca_build_timeline_for_index(idx-1,prev_replay)
                    prev_events=list(getattr(prev_timeline,"events",[]) or []) if prev_timeline is not None else []
                    previous_cav=any(str(getattr(ev,"family","")) in {"Decrease","Safety","Dynamic"} or "CAVITATION" in str(getattr(ev,"result","")).upper() or "HALT" in str(getattr(ev,"result","")).upper() for ev in prev_events)
                    self._rca_previous_cavitation_cache[idx-1]=previous_cav
                except Exception:
                    previous_cav=None
        tm=self._rca_temperature_metrics(idx)
        timeline=self.default_cavitation_timeline
        events=list(getattr(timeline,"events",[]) or []) if timeline is not None else None
        corr=getattr(self,"default_cavitation_mr_correlation",None)
        return self.cavitation_root_cause_service.analyze(
            sonication_number=idx+1,events=events,replay=self.default_cpc_replay,power=power,
            treatment_power_median=treatment_median,previous_power=previous_power,energy=energy,duration=duration,
            start_temp=tm.get("start_temp"),peak_temp=tm.get("peak_temp"),delta_temp=tm.get("delta_temp"),
            previous_peak_temp=previous_peak,previous_cavitation=previous_cav,
            mr_correlation_score=getattr(corr,"correlation_score",None) if corr is not None else None)

    def _update_ci_root_cause(self) -> None:
        if not hasattr(self,"ci_rca_table"):
            return
        result=self._build_current_cavitation_root_cause()
        self.current_cavitation_root_cause=result
        self.ci_rca_table.setRowCount(0)
        if result is None:
            self.ci_rca_summary.setText(self._tr("root_unavailable")); return
        self.ci_rca_summary.setText(self._localized_rca_summary(result))
        for rank,factor in enumerate(result.ranked_factors,1):
            r=self.ci_rca_table.rowCount(); self.ci_rca_table.insertRow(r)
            label = tr_factor_label(self.language, factor.key, factor.label)
            evidence = localize_evidence(self.language, factor.key, factor.evidence)
            conf = tr_confidence(self.language, factor.confidence)
            improvement = tr_factor_improvement(self.language, factor.key, factor.improvement)
            vals=[f"#{rank} {label}",f"{factor.contribution:.0f}/100",evidence,conf,improvement]
            for c,v in enumerate(vals):
                item=QTableWidgetItem(str(v)); item.setToolTip(str(v)); self.ci_rca_table.setItem(r,c,item)
        unavailable=[f for f in result.factors if not f.available]
        if unavailable:
            r=self.ci_rca_table.rowCount(); self.ci_rca_table.insertRow(r)
            missing = ", ".join(tr_factor_label(self.language, f.key, f.label) for f in unavailable)
            vals=[self._tr("unavailable_evidence"),"--",missing,tr_confidence(self.language,"Unavailable"),self._tr("not_inferred")]
            for c,v in enumerate(vals):
                item=QTableWidgetItem(str(v)); item.setToolTip(str(v)); self.ci_rca_table.setItem(r,c,item)

    def _update_cavitation_intelligence_page(self) -> None:
        if not hasattr(self,"ci_summary"):
            return
        if not self.current:
            self.ci_summary.setText(self._tr("load_sonication"))
            return
        result=getattr(self,"default_cavitation_likelihood",None)
        corr=getattr(self,"default_cavitation_mr_correlation",None)
        replay=self.default_cpc_replay
        replay_time=self._index_to_seconds(self.frame_index,self.current.replay_frame_count) if self.current else 0.0
        event=self._nearest_observed_cavitation_event(replay_time, tolerance_s=0.25)
        self.ci_summary.setText(self._tr("sync_evidence", son=self.sonication_index+1, time=replay_time))
        total=max(1,int(getattr(self.current,"replay_frame_count",1) or 1))
        cpc_idx=self._synchronized_cpc_frame_index(replay_time) if replay is not None else None
        cpc_txt="CPC --"
        cycle_txt="cycle --"
        if cpc_idx is not None and replay is not None and 0 <= cpc_idx < len(replay.frames):
            cpc_txt=f"CPC {cpc_idx+1}/{len(replay.frames)}"
            cyc=getattr(replay.frames[cpc_idx],"acquisition_cycle",None)
            if cyc is not None: cycle_txt=f"cycle {cyc}"
        self.ci_replay_position.setText(f"Sonication {self.sonication_index+1}  •  Replay frame {self.frame_index+1}/{total}  •  {replay_time:.3f} s  •  {cpc_txt}  •  {cycle_txt}")

        self._update_ci_linked_panel()

    def _build_export_status_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        note = QLabel(
            "Best-effort replay never rejects a PARTIAL sonication. Available streams remain enabled; "
            "missing or degraded assets are listed below with their functional impact."
        )
        note.setWordWrap(True); layout.addWidget(note)
        detail = QLabel("* Container ch bytes is frame_size/channel_count arithmetic from the validated header. It does not claim that SpectrumMsg channel FFT payload boundaries are fully decoded.")
        detail.setWordWrap(True); layout.addWidget(detail)
        self.export_status_summary = QLabel("No Export loaded")
        self.export_status_summary.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(self.export_status_summary)
        self.capability_table = QTableWidget(0, 5)
        self.capability_table.setHorizontalHeaderLabels(["Capability", "State", "Replay behavior", "Reason", "Evidence"])
        self.capability_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.capability_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.capability_table, 1)
        self.spectrum_structure_table = QTableWidget(0, 8)
        self.spectrum_structure_table.setHorizontalHeaderLabels([
            "SpectrumMsg", "Mode", "Frames", "Frame bytes", "Channels", "Header bytes", "Container ch bytes*", "Confidence"
        ])
        self.spectrum_structure_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.spectrum_structure_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.spectrum_structure_table, 1)
        return page

    def _build_thermometry_data_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        self.thermometry_status_label = QLabel("No Sonication selected")
        self.thermometry_status_label.setWordWrap(True); layout.addWidget(self.thermometry_status_label)
        self.thermometry_field_table = QTableWidget(0, 5)
        self.thermometry_field_table.setHorizontalHeaderLabels(["Field", "Semantic", "Files", "Storage", "Replay use"])
        self.thermometry_field_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.thermometry_field_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.thermometry_field_table, 1)
        return page

    def _build_elements_skull_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        self.elements_skull_label = QLabel("No Sonication selected")
        self.elements_skull_label.setWordWrap(True); layout.addWidget(self.elements_skull_label)
        self.elements_skull_table = QTableWidget(0, 4)
        self.elements_skull_table.setHorizontalHeaderLabels(["Data", "Available", "Source count", "Analysis / limitation"])
        self.elements_skull_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.elements_skull_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.elements_skull_table, 1)
        return page

    def _build_comparison_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        label = QLabel("Treatment-level Sonication comparison. PARTIAL rows remain in the table and are never silently dropped.")
        label.setWordWrap(True); layout.addWidget(label)
        self.comparison_table = QTableWidget(0, 10)
        self.comparison_table.setHorizontalHeaderLabels([
            "Sonication", "Status", "Replay %", "Power W", "Duration s", "Energy J",
            "Temp", "Spectrum", "ACT", "Skull"
        ])
        self.comparison_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.comparison_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.comparison_table.cellDoubleClicked.connect(lambda row, _col: self._select_sonication_index(row))
        layout.addWidget(self.comparison_table, 1)
        return page

    def _build_engineering_analysis_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        intro = QLabel(
            "Evidence-first engineering analysis derived from the Export. Values are source-labelled and do not replace "
            "Workstation Sonication information. Missing streams reduce only the dependent analysis."
        )
        intro.setWordWrap(True); layout.addWidget(intro)
        self.engineering_summary_label = QLabel("No Sonication selected")
        self.engineering_summary_label.setWordWrap(True); layout.addWidget(self.engineering_summary_label)

        self.engineering_tabs = QTabWidget()
        self.engineering_metrics_table = QTableWidget(0, 5)
        self.engineering_metrics_table.setHorizontalHeaderLabels(["Metric", "Value", "Source", "Confidence", "Note"])
        self.engineering_metrics_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.engineering_metrics_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.engineering_tabs.addTab(self.engineering_metrics_table, "Metrics")

        self.dependency_table = QTableWidget(0, 5)
        self.dependency_table.setHorizontalHeaderLabels(["Feature", "State", "Depends on", "Source", "Impact / fallback"])
        self.dependency_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.dependency_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.engineering_tabs.addTab(self.dependency_table, "Dependency Graph")

        def make_detail(headers):
            table = QTableWidget(0, len(headers))
            table.setHorizontalHeaderLabels(headers)
            table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
            table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
            return table
        self.engineering_act_table = make_detail(["ACT metric", "Value", "Evidence / note"])
        self.engineering_skull_table = make_detail(["Skull metric", "Value", "Evidence / note"])
        self.engineering_spectrum_table = make_detail(["Spectrum source", "Structure", "Evidence / note"])
        self.engineering_thermo_table = make_detail(["Thermometry metric", "Value", "Evidence / note"])
        self.engineering_tabs.addTab(self.engineering_act_table, "ACT / Elements")
        self.engineering_tabs.addTab(self.engineering_skull_table, "Skull / SDR")
        self.engineering_tabs.addTab(self.engineering_spectrum_table, "Spectrum Structure")
        self.engineering_tabs.addTab(self.engineering_thermo_table, "Thermometry")
        layout.addWidget(self.engineering_tabs, 1)
        return page

    @staticmethod
    def _fill_three_column_table(table: QTableWidget, rows) -> None:
        table.setRowCount(len(rows))
        for row, values in enumerate(rows):
            for col, value in enumerate(values):
                table.setItem(row, col, QTableWidgetItem(str(value)))

    def _refresh_engineering_analysis(self) -> None:
        if not self.current or not self.package:
            return
        analysis = self.engineering_analysis_service.analyze(
            self.current, self.package.workspace, self.sonication_index + 1
        )
        self.current_engineering_analysis = analysis
        self.engineering_summary_label.setText(
            f"{self.current.name} | {self.current.completeness_status} {self.current.completeness_score}% | "
            f"Workflow: {self.package.workflow_mode} | Thermometry: {self.current.thermometry_mode} | "
            "Replay frequency source: Sonication information when available"
        )
        self.engineering_metrics_table.setRowCount(len(analysis.metrics))
        for row, metric in enumerate(analysis.metrics):
            values = [metric.name, metric.value, metric.source, metric.confidence, metric.note]
            for col, value in enumerate(values):
                self.engineering_metrics_table.setItem(row, col, QTableWidgetItem(str(value)))
        self.dependency_table.setRowCount(len(analysis.dependencies))
        for row, item in enumerate(analysis.dependencies):
            values = [item.feature, item.state, item.depends_on, item.source, item.impact]
            for col, value in enumerate(values):
                self.dependency_table.setItem(row, col, QTableWidgetItem(str(value)))
        self._fill_three_column_table(self.engineering_act_table, analysis.act_rows)
        self._fill_three_column_table(self.engineering_skull_table, analysis.skull_rows)
        self._fill_three_column_table(self.engineering_spectrum_table, analysis.spectrum_rows)
        self._fill_three_column_table(self.engineering_thermo_table, analysis.thermometry_rows)

    @staticmethod
    def _capability_replay_behavior(key: str, cap: dict) -> str:
        if cap.get("available") and not cap.get("degraded"):
            return "Full feature enabled"
        if cap.get("available"):
            return "Best-effort / limited feature enabled"
        return {
            "thermometry": "Replay anatomy/spectrum without temperature overlay",
            "spectrum": "Replay MR/thermal without acoustic spectrum",
            "elements": "Replay without element amplitude/phase analysis",
            "skull": "Replay without skull propagation/heating analysis",
            "motion": "Replay without reference/current 3-plane comparison",
            "dose": "Temperature replay available; dose maps unavailable",
            "registration": "Images remain viewable; fusion geometry unavailable",
            "geometry": "2D replay available; mesh overlays unavailable",
            "planning": "Sonication replay available; planning workspace limited",
        }.get(key, "Feature unavailable")

    def _refresh_export_workspaces(self) -> None:
        if not self.current or not self.package:
            return
        status = self.current.completeness_status
        missing = self.current.missing_required + self.current.missing_optional
        self.export_status_summary.setText(
            f"{self.current.name}: {status} ({self.current.completeness_score}%)  |  "
            f"Workflow: {self.package.workflow_mode}  |  Thermometry: {self.current.thermometry_mode}  |  "
            f"Missing: {', '.join(missing) if missing else 'None'}"
        )
        caps = self.current.capabilities or {}
        self.capability_table.setRowCount(len(caps))
        for row, (key, cap) in enumerate(caps.items()):
            state = "AVAILABLE" if cap.get("available") else "MISSING"
            if cap.get("available") and cap.get("degraded"):
                state = "DEGRADED"
            evidence = cap.get("evidence") or []
            vals = [key, state, self._capability_replay_behavior(key, cap), cap.get("reason", ""), "; ".join(map(str, evidence[:3]))]
            for col, val in enumerate(vals):
                self.capability_table.setItem(row, col, QTableWidgetItem(str(val)))

        structures=[]
        for path in self.current.spectrum_files:
            try:
                structures.append(decode_spectrum_structure(path))
            except Exception:
                continue
        self.spectrum_structure_table.setRowCount(len(structures))
        for row, spec in enumerate(structures):
            vals=[Path(spec.path).name, "Exact" if spec.exact_structure else "Legacy fallback", spec.frame_count, spec.frame_size,
                  spec.channel_count, spec.header_size, spec.bytes_per_channel, spec.format_confidence]
            for col,val in enumerate(vals): self.spectrum_structure_table.setItem(row,col,QTableWidgetItem(str(val)))

        counts = {}
        for path in [f.path for f in self.current.temperature_frames] + [f.path for f in self.current.magnitude_frames] + list(self.current.other_files):
            m = EXPORT_RAW_RE.match(path.name)
            if m:
                fid=int(m.group("field")); counts[fid]=counts.get(fid,0)+1
        thermo_ids=[5,6,23,28,33,2,34]
        self.thermometry_field_table.setRowCount(len(thermo_ids))
        uses={5:"Temperature replay",6:"Anatomy / thermometry magnitude",23:"Dynamic validity mask",28:"37 °C reference",33:"Background mask",2:"Local derived map A",34:"Local derived map B"}
        for row,fid in enumerate(thermo_ids):
            semantic,storage=FIELD_SEMANTICS[fid]
            vals=[fid,semantic,counts.get(fid,0),storage,uses[fid] if counts.get(fid,0) else "Unavailable — other streams still replay"]
            for col,val in enumerate(vals): self.thermometry_field_table.setItem(row,col,QTableWidgetItem(str(val)))
        self.thermometry_status_label.setText(
            f"{self.current.thermometry_mode}. Magnitude={counts.get(6,0)}, Temperature={counts.get(5,0)}. "
            "TMAP and TMAP-ME (Multi Echo) share the same Export field semantics; acquisition mode is reported separately."
        )

        acts=list(self.current.act_files)
        skull_measures=list(self.current.folder.rglob("SkullMeasures*.log"))
        skull_heating=list(self.current.folder.rglob("SkullHeating*.log"))
        meshes=list(self.current.folder.rglob("*.mesh"))
        if not meshes and self.package.workspace != self.current.folder:
            meshes=list(self.package.workspace.rglob("*.mesh"))
        rows=[
            ("ACT / 1024-element control", bool(acts), len(acts), "Amplitude/phase and element-state analysis" if acts else "Element replay unavailable"),
            ("SkullMeasures", bool(skull_measures), len(skull_measures), "Per-element skull path / SDR analysis" if skull_measures else "Skull path metrics unavailable"),
            ("SkullHeating", bool(skull_heating), len(skull_heating), "Predicted skull heating / power distribution" if skull_heating else "Heating prediction unavailable"),
            ("Meshes", bool(meshes), len(meshes), "Skull / sinus / calcification / spot geometry" if meshes else "3D geometry unavailable"),
        ]
        self.elements_skull_table.setRowCount(len(rows))
        for row,vals in enumerate(rows):
            for col,val in enumerate(vals): self.elements_skull_table.setItem(row,col,QTableWidgetItem(str(val)))
        self.elements_skull_label.setText(
            "This workspace separates element control, skull propagation/heating, and mesh geometry so a missing component does not disable the others."
        )

        sons=self.package.sonications
        self.comparison_table.setRowCount(len(sons))
        for row,son in enumerate(sons):
            c=son.capabilities or {}
            def yn(k):
                x=c.get(k,{})
                return "Limited" if x.get("available") and x.get("degraded") else ("Yes" if x.get("available") else "No")
            vals=[son.name,son.completeness_status,son.completeness_score,
                  f"{son.actual_power_w:.1f}" if son.actual_power_w is not None else "-",
                  f"{son.actual_duration_s:.2f}" if son.actual_duration_s is not None else "-",
                  f"{son.actual_energy_j:.1f}" if son.actual_energy_j is not None else "-",
                  yn("thermometry"),yn("spectrum"),yn("elements"),yn("skull")]
            for col,val in enumerate(vals): self.comparison_table.setItem(row,col,QTableWidgetItem(str(val)))

    def _chart_panel(self, title: str, plot: pg.PlotWidget, key: str) -> QWidget:
        panel=QGroupBox(title); lay=QVBoxLayout(panel); lay.setContentsMargins(3,3,3,3); lay.setSpacing(1)
        header=QHBoxLayout(); header.setContentsMargins(0,0,0,0)
        expand=QToolButton(); expand.setText("↗"); expand.setToolTip("Open enlarged chart")
        expand.setFixedSize(20,20); expand.setStyleSheet("QToolButton{padding:0;font-size:10px;}")
        expand.clicked.connect(lambda: self._open_chart_popup(key))
        header.addStretch(1); header.addWidget(expand); lay.addLayout(header); lay.addWidget(plot,1)
        return panel

    def _make_image_strip(self, role: str) -> QListWidget:
        widget = QListWidget()
        widget.setProperty("imageRole", role)
        widget.setViewMode(QListWidget.ViewMode.IconMode)
        widget.setIconSize(QSize(88, 70)); widget.setGridSize(QSize(98, 88))
        widget.setResizeMode(QListWidget.ResizeMode.Adjust)
        widget.setMovement(QListWidget.Movement.Static)
        widget.setFlow(QListWidget.Flow.LeftToRight)
        widget.setWrapping(False)
        widget.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        widget.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        widget.setHorizontalScrollMode(QListWidget.ScrollMode.ScrollPerPixel)
        widget.setMaximumHeight(94); widget.setMinimumHeight(90)
        widget.setUniformItemSizes(True)
        return widget

    def _clear_replay_display(self) -> None:
        """Remove Sonication-scoped visuals while retaining study references."""
        self.timer.stop()
        if hasattr(self, "play_btn"): self.play_btn.setText("▶")
        if hasattr(self, "overlay"):
            self.overlay.set_hover_temperature(None)
            self.overlay.set_roi(None, None)
            self.overlay.set_overlay(None, None, fit=False)
        for name in ("planning_frame_list", "anatomy_frame_list", "thermal_frame_list"):
            widget = getattr(self, name, None)
            if widget is not None:
                widget.blockSignals(True); widget.clear(); widget.blockSignals(False)
        for curve_name in ("max_temperature_curve", "mean_temperature_curve", "cursor_temperature_curve", "acoustic_power_curve", "acoustic_score_curve"):
            curve = getattr(self, curve_name, None)
            if curve is not None:
                try: curve.setData([], [])
                except Exception: pass
        if hasattr(self, "spectrum_plot"): self.spectrum_plot.clear()
        if hasattr(self, "frame_label"): self.frame_label.setText("Frame -/-")
        if hasattr(self, "sync_label"): self.sync_label.setText("Loading selected sonication...")
        self._cancel_thermal_thumbnail_worker()
        self._cancel_image_thumbnail_workers()
        self._cancel_sonication_summary_worker()
        self._thermal_thumbnail_cache = {}
        self._treatment_mr_thumbnail_cache = {}
        self._thermal_thumbnails_complete = False
        self._planning_display_arrays = []
        # Preplanning CT/MR and Planning MR belong to the loaded study, not to
        # one Sonication.  Their decoded arrays, thumbnails, CT volume, skull
        # mask and completed registration renders survive Sonication switching.
        self._anatomy_row_map = []
        self._thermal_row_map = []
        self._main_image_mode = "thermal"
        self._active_planning_asset = None
        self._active_planning_array = None
        self.registration_overlay_enabled = False
        # R0092: clear every sonication-scoped Cavitation Intelligence object
        # before the new Sonication becomes active.
        self.default_cpc_replay = None
        self.default_cavitation_timeline = None
        self.default_cavitation_likelihood = None
        self.default_cavitation_mr_correlation = None
        self.current_cavitation_root_cause = None
        self._ci_event_preview_result = None
        self._ci_linked_data_key = None
        self._ci_visible_events = []
        self._cavitation_trend = None
        if hasattr(self, "ci_event_table"):
            self.ci_event_table.setRowCount(0)
        if hasattr(self, "ci_rca_table"):
            self.ci_rca_table.setRowCount(0)
        if hasattr(self, "ci_summary"):
            self.ci_summary.setText(self._tr("load_sonication"))
        if hasattr(self, "registration_toggle_btn"):
            self.registration_toggle_btn.blockSignals(True); self.registration_toggle_btn.setChecked(False); self.registration_toggle_btn.setText("Registration"); self.registration_toggle_btn.setEnabled(False); self.registration_toggle_btn.blockSignals(False)

    def _clear_study_reference_cache(self) -> None:
        """Invalidate reference data only when a different package is loaded."""
        self._cancel_image_thumbnail_workers()
        self._reference_thumbnail_cache = {}
        self._planning_display_arrays = []
        self._planning_assets_all = []
        self._planning_array_cache = {}
        self._registration_ct_volume_cache = None
        self._registration_overlay_cache = {}
        self.registration_overlay_service.clear_runtime_cache()

    @staticmethod
    def _decode_planning_image(asset):
        """Decode a planning image with CtImage metadata; never guess CT dtype."""
        path = Path(asset.path)
        try:
            suffix = path.suffix.lower()
            if suffix in {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}:
                image = QImage(str(path))
                if image.isNull(): return None
                image = image.convertToFormat(QImage.Format.Format_Grayscale8)
                ptr = image.bits(); arr = np.frombuffer(ptr, np.uint8, image.width()*image.height())
                return arr.reshape(image.height(), image.width()).astype(np.float32)
            if suffix != ".raw": return None
            width = getattr(asset, "width", None); height = getattr(asset, "height", None)
            dtype_name = getattr(asset, "dtype", None)
            if width and height and dtype_name:
                dtype = np.dtype(dtype_name)
                expected = int(width) * int(height) * dtype.itemsize
                if path.stat().st_size != expected:
                    return None
                values = np.fromfile(path, dtype=dtype).reshape(int(height), int(width)).astype(np.float32)
                finite = values[np.isfinite(values)]
                return values if finite.size and float(np.nanstd(finite)) > 1e-8 else None
            # Non-CT planning MR fallback remains conservative.
            size = path.stat().st_size
            for dtype in (np.dtype('<u2'), np.dtype('<i2'), np.dtype('<f4')):
                count = size // dtype.itemsize; side = int(round(count ** 0.5))
                if side >= 32 and side * side == count:
                    values = np.fromfile(path, dtype=dtype).reshape(side, side).astype(np.float32)
                    finite = values[np.isfinite(values)]
                    if finite.size and float(np.nanstd(finite)) > 1e-8:
                        return values
            return None
        except (OSError, ValueError, TypeError):
            return None

    def _planning_type_changed(self, _text: str) -> None:
        # Legacy compatibility entry point; unified navigator is authoritative.
        self._rebuild_all_image_strips()

    def _planning_category(self, asset) -> str:
        category=str(getattr(asset, "category", "") or "").upper()
        mapping={
            "PLANNING_CT":"Preplanning CT",
            "PREPLANNING_MR_AX":"Preplanning MR Ax",
            "PREPLANNING_MR_SAG":"Preplanning MR Sag",
            "PREPLANNING_MR_COR":"Preplanning MR Cor",
            "PLANNING_MR_AX":"Planning MR Ax",
            "PLANNING_MR_SAG":"Planning MR Sag",
            "PLANNING_MR_COR":"Planning MR Cor",
        }
        if category in mapping:
            return mapping[category]
        text = " ".join(str(getattr(asset, name, "")) for name in ("category", "role", "path")).lower()
        if "ct" in text or "skull" in text:
            return "Preplanning CT"
        if "mr" in text or "mri" in text or "dicom" in text:
            return "Preplanning MR"
        return "Planning Other"

    def _rebuild_planning_strip(self) -> None:
        if not hasattr(self, "planning_frame_list"):
            return
        selected = self.planning_type_combo.currentText() if hasattr(self, "planning_type_combo") else "All Planning"
        self.planning_frame_list.blockSignals(True); self.planning_frame_list.clear()
        self._planning_display_arrays = []
        for asset, array, label, category in getattr(self, "_planning_assets_all", []):
            if selected not in ("", "All Planning") and category != selected:
                continue
            icon = self._array_icon(array) if array is not None else QIcon()
            item = QListWidgetItem(icon, label); item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
            item.setToolTip(f"{getattr(asset, 'role', category)}\n{getattr(asset, 'path', '')}")
            self.planning_frame_list.addItem(item)
            self._planning_display_arrays.append((array, label))
        self.planning_frame_list.blockSignals(False)

    def _first_valid_replay_frame(self) -> int:
        """Return the first frame that can actually render an anatomy image."""
        if not self.current:
            return 0
        count = max(1, int(self.current.replay_frame_count))
        for index in range(count):
            try:
                data = self.replay.frame(self.current, index)
                magnitude = getattr(data, "magnitude", None)
                if magnitude is not None:
                    arr = np.asarray(magnitude, float)
                    finite = arr[np.isfinite(arr)]
                    if finite.size and float(np.nanstd(finite)) > 1e-8:
                        return index
            except Exception:
                continue
        return 0

    def _planning_frame_selected(self, row: int) -> None:
        if row < 0 or row >= len(getattr(self, "_planning_display_arrays", [])): return
        array, label = self._planning_display_arrays[row]
        if array is None:
            self.statusBar().showMessage(f"Planning resource is metadata only: {label}")
            return
        self._main_image_mode = "planning"
        self.overlay.set_hover_temperature(None); self.overlay.set_roi(None, None)
        self.overlay.set_overlay(array, None, fit=True)
        self.frame_label.setText(f"Planning image: {label}")
        self.sync_label.setText("Planning CT / MR selected")

    def _anatomy_frame_selected(self, row: int) -> None:
        if not self.current or row < 0 or not self.current.magnitude_frames: return
        source_row = self._anatomy_row_map[row] if row < len(self._anatomy_row_map) else row
        replay_index = self._map_replay_to_data(source_row, len(self.current.magnitude_frames), self.current.replay_frame_count)
        self._main_image_mode = "anatomy"
        self.set_frame(replay_index, display_mode="anatomy")

    def _thermal_frame_selected(self, row: int) -> None:
        if not self.current or row < 0: return
        source_row = self._thermal_row_map[row] if row < len(self._thermal_row_map) else row
        series_count = max(1, len(self.current.temperature_frames))
        replay_index = self._map_replay_to_data(source_row, series_count, self.current.replay_frame_count)
        self._main_image_mode = "thermal"
        self.set_frame(replay_index, display_mode="thermal")

    def _build_replay_tab(self) -> QWidget:
        # Compact top strip: Sonication can be changed either sequentially or directly
        # from the loaded-study list. Both paths use _select_sonication_index so every
        # synchronized Replay/Analysis view receives the same selection event.
        self.son_prev_btn = QPushButton("≪")
        self.son_next_btn = QPushButton("≫")
        self.sonication_combo = QComboBox()
        self.sonication_combo.setMinimumWidth(118)
        self.sonication_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)
        self.sonication_combo.setToolTip("Select a Sonication directly from the loaded Export")
        self.sonication_combo.currentIndexChanged.connect(self._sonication_combo_changed)
        self.son_prev_btn.clicked.connect(lambda: self._change_sonication(-1))
        self.son_next_btn.clicked.connect(lambda: self._change_sonication(1))
        self.info_btn = QPushButton("Info")
        self.mr_btn = QPushButton("MR")
        self.scan_btn = QPushButton("Scan")
        self.xd_btn = QPushButton("XD")
        self.info_btn.clicked.connect(self._show_info_window)
        self.mr_btn.clicked.connect(self._show_mr_window)
        self.scan_btn.clicked.connect(self._show_scan_window)
        self.xd_btn.clicked.connect(self._show_xd_window)
        self.info_window = InfoWindow(self)
        self.mr_window = DetailWindow("MR Information", self)
        self.scan_window = DetailWindow("Scan Protocol Information", self)
        self.xd_window = SkullElementWindow(self)

        top_bar = QHBoxLayout()
        top_bar.addWidget(QLabel("Sonication No."))
        top_bar.addWidget(self.son_prev_btn)
        top_bar.addWidget(self.sonication_combo)
        top_bar.addWidget(self.son_next_btn)
        top_bar.addStretch(1)

        # Left controls: temperature scale and a true slider for red threshold.
        self.temperature_mode_combo = QComboBox()
        self.temperature_mode_combo.addItems(["Absolute Temperature", "ΔTemperature (Investigation)"])
        self.temperature_mode_combo.currentTextChanged.connect(self._temperature_mode_changed)
        self.range_combo = QComboBox()
        self.range_combo.addItems(["40–60 °C", "35–60 °C", "30–90 °C", "0–60 °C", "Auto"])
        self.range_combo.currentIndexChanged.connect(self._temperature_range_changed)
        self.overlay_opacity = QSlider(Qt.Orientation.Horizontal)
        self.overlay_opacity.setRange(0, 100); self.overlay_opacity.setValue(55)
        self.overlay_opacity.valueChanged.connect(lambda _: self.set_frame(self.frame_index))
        self.threshold_slider = QSlider(Qt.Orientation.Horizontal)
        self.threshold_slider.setRange(30, 90); self.threshold_slider.setValue(48)
        self.threshold_minus = QPushButton("◀"); self.threshold_plus = QPushButton("▶")
        for button in (self.threshold_minus, self.threshold_plus): button.setFixedWidth(28)
        self.threshold_minus.clicked.connect(lambda: self.threshold_slider.setValue(self.threshold_slider.value()-1))
        self.threshold_plus.clicked.connect(lambda: self.threshold_slider.setValue(self.threshold_slider.value()+1))
        self.threshold_value = QLabel("Red starts at 48 °C")
        self.threshold_slider.valueChanged.connect(self._threshold_changed)
        self.baseline_label = QLabel("Temperature source: waiting")
        self.baseline_label.setWordWrap(True); self.baseline_label.setObjectName("CurrentValue")
        self.cursor_temperature_label = QLabel("Cursor Temperature: --")
        self.cursor_temperature_label.setWordWrap(True); self.cursor_temperature_label.setObjectName("CurrentValue")

        # Responsive left information panel.  The previous fixed 190-245 px panel
        # compressed wrapped labels on 125/150% Windows DPI and made Sonication
        # values unreadable.  Keep the content in a scroll area and size rows from
        # the active font instead of relying on fixed label heights.
        left_content = QWidget()
        ll = QVBoxLayout(left_content)
        ll.setContentsMargins(8, 8, 8, 8)
        ll.setSpacing(10)

        display_box = QGroupBox("Temperature Display")
        display_layout = QVBoxLayout(display_box)
        display_layout.setContentsMargins(8, 12, 8, 8)
        display_layout.setSpacing(6)
        display_layout.addWidget(QLabel("Mode")); display_layout.addWidget(self.temperature_mode_combo)
        display_layout.addWidget(QLabel("Overlay opacity")); display_layout.addWidget(self.overlay_opacity)
        display_layout.addWidget(QLabel("Temperature range")); display_layout.addWidget(self.range_combo)
        display_layout.addWidget(QLabel("Red threshold"))
        threshold_row = QHBoxLayout(); threshold_row.setContentsMargins(0,0,0,0); threshold_row.setSpacing(6)
        threshold_row.addWidget(self.threshold_minus); threshold_row.addWidget(self.threshold_slider, 1); threshold_row.addWidget(self.threshold_plus)
        display_layout.addLayout(threshold_row); display_layout.addWidget(self.threshold_value)
        ll.addWidget(display_box)

        roi_box = QGroupBox("Temperature ROI")
        roi_layout = QVBoxLayout(roi_box)
        roi_layout.setContentsMargins(8, 12, 8, 8)
        roi_layout.setSpacing(7)
        self.voxel_label = QLabel("Voxel (ROI): 3 pixels × 3 pixels")
        self.voxel_label.setObjectName("CurrentValue")
        self.voxel_label.setWordWrap(True)
        roi_layout.addWidget(self.voxel_label)
        self.measurement_summary_label = QLabel("ROI is hidden")
        self.measurement_summary_label.setWordWrap(True)
        self.measurement_summary_label.setObjectName("CurrentValue")
        self.measurement_summary_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        roi_layout.addWidget(self.measurement_summary_label)
        measure_row = QHBoxLayout(); measure_row.setSpacing(6)
        self.measure_roi_btn = QPushButton("Show ROI")
        self.copy_measure_btn = QPushButton("Copy")
        self.clear_measure_btn = QPushButton("Clear")
        for button in (self.measure_roi_btn, self.copy_measure_btn, self.clear_measure_btn):
            button.setMinimumHeight(40)
            button.setMinimumWidth(68)
            measure_row.addWidget(button, 1)
        roi_layout.addLayout(measure_row)
        ll.addWidget(roi_box)

        cursor_box = QGroupBox("Cursor Temperature")
        cursor_layout = QVBoxLayout(cursor_box)
        cursor_layout.setContentsMargins(8, 12, 8, 8)
        cursor_layout.setSpacing(6)
        self.cursor_temperature_label.setWordWrap(True)
        self.cursor_temperature_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        cursor_layout.addWidget(self.cursor_temperature_label)
        self.baseline_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        cursor_layout.addWidget(self.baseline_label)
        ll.addWidget(cursor_box)

        self.sonication_summary_box = QGroupBox("Sonication")
        summary_layout = QGridLayout(self.sonication_summary_box)
        summary_layout.setContentsMargins(8, 14, 8, 8)
        summary_layout.setHorizontalSpacing(10)
        summary_layout.setVerticalSpacing(7)
        summary_layout.setColumnStretch(0, 0)
        summary_layout.setColumnStretch(1, 1)
        self.summary_value_labels = {}
        for row, key in enumerate(("Orientation", "Displayed Plane", "Orientation Status", "Frequency Dir", "Target Energy", "Actual Energy", "Target Power", "Actual Power", "Target Duration", "Actual Duration", "Frequency")):
            key_label = QLabel(key)
            key_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
            value_label = QLabel("-")
            value_label.setObjectName("CurrentValue")
            value_label.setWordWrap(True)
            value_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            self.summary_value_labels[key] = value_label
            summary_layout.addWidget(key_label, row, 0)
            summary_layout.addWidget(value_label, row, 1)
        ll.addWidget(self.sonication_summary_box)

        info_buttons = QHBoxLayout(); info_buttons.setSpacing(6)
        for button in (self.info_btn, self.mr_btn, self.scan_btn, self.xd_btn):
            button.setMinimumHeight(42)
            button.setMinimumWidth(58)
            info_buttons.addWidget(button, 1)
        ll.addLayout(info_buttons)
        ll.addStretch(1)

        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setFrameShape(QFrame.Shape.NoFrame)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        left_scroll.setWidget(left_content)
        left_scroll.setMinimumWidth(265)
        left_scroll.setMaximumWidth(340)
        left = left_scroll

        # Dominant workstation image. Click moves the crosshair and updates temperature.
        self.overlay = OverlayPanel("Thermal Replay - Workstation Temperature Map")
        self.overlay.cursorMoved.connect(self._overlay_cursor_moved)
        self.overlay.viewStateChanged.connect(self._capture_overlay_state_debounced)
        self.overlay.levelsChanged.connect(self._capture_overlay_levels)
        self.overlay.measurementChanged.connect(self._overlay_measurement_changed)
        self.measure_roi_btn.clicked.connect(self.overlay.show_measure_roi)
        self.copy_measure_btn.clicked.connect(self.overlay.copy_measurement)
        self.clear_measure_btn.clicked.connect(self._clear_overlay_measurement)
        self._overlay_save_timer=QTimer(self); self._overlay_save_timer.setSingleShot(True); self._overlay_save_timer.timeout.connect(self._save_overlay_state)
        self._fit_overlay_next = True
        self.cursor_x = None; self.cursor_y = None

        # Product-style three independent image rows.  Each row scrolls
        # horizontally and selects what is shown in the main image viewer.
        self.planning_frame_list = self._make_image_strip("planning")
        self.anatomy_frame_list = self._make_image_strip("anatomy")
        self.thermal_frame_list = self._make_image_strip("thermal")
        self.planning_type_combo = QComboBox()
        self.planning_type_combo.setMinimumWidth(135)
        image_row_options = [
            "Preplanning CT", "Preplanning MR All",
            "Preplanning MR Ax", "Preplanning MR Sag", "Preplanning MR Cor",
            "Planning MR All", "Planning MR Ax", "Planning MR Sag", "Planning MR Cor",
            "Treatment MR", "Treatment Thermal", "All images",
        ]
        self.planning_type_combo.addItems(image_row_options)
        self.anatomy_type_combo = QComboBox(); self.anatomy_type_combo.addItems(image_row_options)
        self.thermal_type_combo = QComboBox(); self.thermal_type_combo.addItems(image_row_options)
        self.planning_type_combo.setCurrentText("Planning MR All")
        self.anatomy_type_combo.setCurrentText("Treatment MR")
        self.thermal_type_combo.setCurrentText("Treatment Thermal")
        for combo in (self.planning_type_combo,self.anatomy_type_combo,self.thermal_type_combo): combo.setMinimumWidth(135)
        # R0075: the image-number drop-downs remain removed.  The thumbnail strip is
        # the authoritative selector and always contains the complete filtered
        # series.  Its horizontal scrollbar provides access to every off-screen
        # image without duplicating navigation controls.
        self.planning_type_combo.currentTextChanged.connect(self._planning_reference_type_changed)
        self.anatomy_type_combo.currentTextChanged.connect(self._rebuild_all_image_strips)
        self.thermal_type_combo.currentTextChanged.connect(self._rebuild_all_image_strips)
        # Compatibility alias used by older navigation code.
        self.frame_list = self.thermal_frame_list
        # itemClicked is required because Replay rendering automatically tracks
        # the current thumbnail.  Clicking that already-selected thumbnail does
        # not emit currentRowChanged, which previously made Anatomy/Thermal look
        # dead.  currentRowChanged is retained for keyboard navigation.
        for strip in (self.planning_frame_list, self.anatomy_frame_list, self.thermal_frame_list):
            # itemPressed fires before selection bookkeeping and is the most
            # reliable mouse path in packaged Qt builds. itemActivated keeps
            # keyboard/double-click access. Do not depend on currentRowChanged:
            # the replay renderer changes current rows programmatically.
            # Mouse uses itemPressed (works even for an already-selected item);
            # keyboard activation uses itemActivated. Do not also connect
            # itemClicked: a normal mouse click would execute the same payload twice.
            strip.itemPressed.connect(lambda item, owner=strip: self._unified_image_item_selected(owner, item))
            strip.itemActivated.connect(lambda item, owner=strip: self._unified_image_item_selected(owner, item))
        navigator_box = QGroupBox("Preplanning / Planning / Treatment Images")
        nav_layout = QGridLayout(navigator_box); nav_layout.setContentsMargins(3,8,3,3); nav_layout.setSpacing(2)
        self.image_strip_scrollbars = {}
        for row,(label,combo,strip) in enumerate((("Reference",self.planning_type_combo,self.planning_frame_list),("Treatment MR",self.anatomy_type_combo,self.anatomy_frame_list),("Treatment Thermal",self.thermal_type_combo,self.thermal_frame_list))):
            box=QWidget(); bl=QVBoxLayout(box); bl.setContentsMargins(0,0,0,0); bl.setSpacing(2)
            bl.addWidget(QLabel(label)); bl.addWidget(combo); bl.addStretch(1)
            strip.setToolTip("All images in the selected series. Use the horizontal scrollbar below the thumbnails to browse every image.")
            strip_box=QWidget(); sl=QVBoxLayout(strip_box); sl.setContentsMargins(0,0,0,0); sl.setSpacing(1)
            sl.addWidget(strip)
            # R0116: use an image-index QSlider. The old mirrored QListWidget
            # pixel scrollbar could report a stale 0..0 range until Qt completed
            # layout, leaving an oversized/ungrabbable thumb and only the first
            # few thumbnails practically reachable.
            scroll=QSlider(Qt.Orientation.Horizontal)
            scroll.setVisible(True)
            scroll.setMinimumHeight(24); scroll.setMaximumHeight(26)
            scroll.setTracking(True)
            scroll.setRange(0,0)
            scroll.setSingleStep(1); scroll.setPageStep(4)
            scroll.setStyleSheet("QSlider::handle:horizontal { min-width: 20px; width: 20px; }")
            scroll.setToolTip("Drag to browse all images in this row")
            scroll.valueChanged.connect(lambda index,owner=strip: self._scroll_image_strip_to_index(owner,index))
            self.image_strip_scrollbars[strip.property("imageRole")]=scroll
            sl.addWidget(scroll)
            nav_layout.addWidget(box,row,0); nav_layout.addWidget(strip_box,row,1)
        # Reference, Treatment MR and Treatment Thermal rows are always visible.
        # R0113 intentionally removes all Show/Hide image-row checkboxes and the
        # associated visibility state so later refactors cannot hide these rows.
        # R0063: Registration is a persistent top-right checkbox, matching the
        # requested workstation-like operation.  The checked state is preserved
        # while browsing other image classes and the overlay resumes on an MR
        # reference as soon as one is displayed again.
        self.registration_toggle_btn = QCheckBox("Registration")
        self.registration_toggle_btn.setChecked(False)
        self.registration_toggle_btn.setEnabled(False)
        self.registration_toggle_btn.setToolTip("Overlay preplanning CT skull/bone using the treatment-adopted CtMr registration while a preplanning/planning MR image is displayed.")
        self.registration_toggle_btn.toggled.connect(self._registration_toggled)
        nav_layout.addWidget(self.registration_toggle_btn, 0, 2, 1, 1, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop)
        self.registration_trace_btn = QPushButton("Registration Trace")
        self.registration_trace_btn.setToolTip("Show CT voxel → CT RAS → CtMr/MrMr → MR RAS → displayed MR pixel diagnostics.")
        self.registration_trace_btn.clicked.connect(self._show_registration_trace)
        nav_layout.addWidget(self.registration_trace_btn, 0, 3, 1, 1, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop)
        navigator_box.setMinimumHeight(180)
        nav_layout.setColumnStretch(1, 1)
        self._main_image_mode = "thermal"
        self._planning_display_arrays = []

        self.temperature_plot = pg.PlotWidget()
        self.temperature_plot.setLabel("left", "Temperature", units="°C")
        self.temperature_plot.setLabel("bottom", "MR acquisition time", units="sec")
        self.temperature_plot.showGrid(x=True, y=True, alpha=.28)
        self.temperature_plot.setYRange(40, 60, padding=0)
        self.temperature_plot.getAxis("left").setTickSpacing(major=2, minor=1)
        # Workstation-style temperature bands remain behind every curve.
        self.temperature_bands = []
        for low, high, rgba in (
            (40, 44, (70, 105, 150, 35)),
            (44, 48, (70, 145, 120, 35)),
            (48, 52, (205, 170, 35, 38)),
            (52, 56, (220, 105, 25, 42)),
            (56, 60, (190, 30, 30, 46)),
        ):
            band = pg.LinearRegionItem(values=(low, high), orientation="horizontal", movable=False, brush=pg.mkBrush(*rgba), pen=pg.mkPen(None))
            band.setZValue(-20)
            self.temperature_plot.addItem(band)
            self.temperature_bands.append(band)
        self.max_temperature_curve = self.temperature_plot.plot(pen=pg.mkPen("#ff3b30", width=3), name="Max")
        self.mean_temperature_curve = self.temperature_plot.plot(pen=pg.mkPen("#49e36b", width=2.5), name="ROI Average")
        self.cursor_temperature_curve = self.temperature_plot.plot(pen=pg.mkPen("#b98cff", width=1.6, style=Qt.PenStyle.DashLine), name="Cursor")
        self.temperature_cursor = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen("#00bfff", width=1.5))
        self.temperature_plot.addItem(self.temperature_cursor)
        self.temperature_plot.scene().sigMouseClicked.connect(self._temperature_plot_clicked)
        self.temperature_hover_text = pg.TextItem(anchor=(0, 1), color="#ffffff", fill=pg.mkBrush(0, 0, 0, 190))
        self.temperature_hover_text.setZValue(50); self.temperature_hover_text.hide(); self.temperature_plot.addItem(self.temperature_hover_text)
        self.temperature_hover_proxy = pg.SignalProxy(self.temperature_plot.scene().sigMouseMoved, rateLimit=45, slot=self._temperature_plot_hovered)
        self.temperature_hover_popup = ChartHoverPopup(self.temperature_plot)
        self._updating_temperature_range = False
        self.temperature_plot.plotItem.vb.sigRangeChanged.connect(self._temperature_range_changed_by_user)

        self.spectrum_plot = pg.PlotWidget()
        self.spectrum_plot.setLabel("left", "Relative Amplitude")
        self.spectrum_plot.setLabel("bottom", "Frequency", units="MHz")
        self.spectrum_plot.showGrid(x=True, y=True, alpha=.24)
        self.spectrum_plot.setXRange(0.2, 0.8, padding=0)
        self.spectrum_plot.setYRange(0.0, 4.0, padding=0)
        self.spectrum_hover_text = pg.TextItem(anchor=(0, 1), color="#ffffff", fill=pg.mkBrush(0, 0, 0, 205))
        self.spectrum_hover_text.setZValue(100); self.spectrum_hover_text.hide(); self.spectrum_plot.addItem(self.spectrum_hover_text)
        self.spectrum_hover_series = []
        self.spectrum_hover_proxy = pg.SignalProxy(self.spectrum_plot.scene().sigMouseMoved, rateLimit=45, slot=self._spectrum_plot_hovered)
        self.spectrum_hover_popup = ChartHoverPopup(self.spectrum_plot)
        self.spectrum_plot.plotItem.vb.sigRangeChanged.connect(lambda *_: self._remember_chart_range("spectrum", self.spectrum_plot))

        self.graph_split = QSplitter(Qt.Orientation.Horizontal)
        self.temperature_panel=self._chart_panel("Temperature Trend (ROI)",self.temperature_plot,"temperature")
        self.spectrum_panel=self._chart_panel("Acoustic Spectrum (Current Frame)",self.spectrum_plot,"spectrum")
        self.graph_split.addWidget(self.temperature_panel); self.graph_split.addWidget(self.spectrum_panel)
        # Temperature is the primary replay trend; spectrum is contextual data
        # for the selected frame.  C0045 incorrectly made spectrum wider (3:4).
        self.graph_split.setStretchFactor(0, 65); self.graph_split.setStretchFactor(1, 35)
        self.graph_split.setChildrenCollapsible(False)
        self.temperature_panel.setMinimumWidth(420)
        self.spectrum_panel.setMinimumWidth(280)
        self.graph_split.setSizes([650, 350])
        self.graph_split.setMinimumHeight(155)

        # FUS workstation-style Power and Score trend. Current values are drawn inside the chart.
        self.acoustic_control_plot = pg.PlotWidget()
        self.acoustic_control_plot.setMinimumHeight(150)
        self.acoustic_control_plot.setLabel("left", "Power / Score", units="%")
        self.acoustic_control_plot.setLabel("bottom", "MR acquisition time", units="sec")
        self.acoustic_control_plot.setYRange(0.0, 110.0, padding=0)
        self.acoustic_control_plot.showGrid(x=True, y=True, alpha=.22)
        self.acoustic_power_curve = self.acoustic_control_plot.plot(pen=pg.mkPen("#58f26a", width=2.3), name="Power %")
        self.acoustic_score_curve = self.acoustic_control_plot.plot(pen=pg.mkPen("#ff9d22", width=2.3), name="Score")
        self.acoustic_control_cursor = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen("#00bfff", width=1.3))
        self.acoustic_control_plot.addItem(self.acoustic_control_cursor)
        self.acoustic_control_plot.scene().sigMouseClicked.connect(self._acoustic_plot_clicked)
        self.acoustic_hover_text = pg.TextItem(anchor=(0, 1), color="#ffffff", fill=pg.mkBrush(0, 0, 0, 205))
        self.acoustic_hover_text.setZValue(80); self.acoustic_hover_text.hide(); self.acoustic_control_plot.addItem(self.acoustic_hover_text)
        self.acoustic_hover_proxy = pg.SignalProxy(self.acoustic_control_plot.scene().sigMouseMoved, rateLimit=45, slot=self._acoustic_plot_hovered)
        self.acoustic_hover_popup = ChartHoverPopup(self.acoustic_control_plot)
        self.acoustic_power_text = pg.TextItem("Power: --", color="#58f26a", anchor=(1, 1), fill=pg.mkBrush(0, 0, 0, 150))
        self.acoustic_score_text = pg.TextItem("Score: --", color="#ff9d22", anchor=(1, 0), fill=pg.mkBrush(0, 0, 0, 150))
        self.acoustic_power_text.setZValue(20); self.acoustic_score_text.setZValue(20)
        self.acoustic_control_plot.addItem(self.acoustic_power_text); self.acoustic_control_plot.addItem(self.acoustic_score_text)
        self.acoustic_power_value = QLabel("Unavailable")
        self.acoustic_score_value = QLabel("Unavailable")
        self.acoustic_cavitation_value = QLabel("Unavailable")
        for w in (self.acoustic_power_value, self.acoustic_score_value, self.acoustic_cavitation_value):
            w.hide()

        self.waterfall_replay_plot = pg.PlotWidget()
        self.waterfall_replay_plot.setLabel("left", "Frequency", units="MHz")
        self.waterfall_replay_plot.setLabel("bottom", "Replay time", units="sec")
        self.waterfall_replay_plot.setTitle("")
        self.waterfall_replay_image = pg.ImageItem(axisOrder="row-major")
        self.waterfall_replay_plot.addItem(self.waterfall_replay_image)
        waterfall_colors = np.array([[0,0,25,255],[0,55,170,255],[0,210,255,255],[255,235,0,255],[255,75,0,255],[255,255,255,255]], dtype=np.ubyte)
        waterfall_positions = np.linspace(0.0, 1.0, len(waterfall_colors))
        self.waterfall_replay_image.setLookupTable(pg.ColorMap(waterfall_positions, waterfall_colors).getLookupTable(0.0, 1.0, 256))
        self.waterfall_replay_cursor = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen("w", width=1.5))
        self.waterfall_replay_plot.addItem(self.waterfall_replay_cursor)

        # Compact CH popup: single, multiple, or all channels without wasting chart height.
        self.channel_actions = {}
        self.channel_button = QToolButton()
        self.channel_button.setText("CH")
        self.channel_button.setToolTip("Select one, multiple, or all hydrophone channels")
        self.channel_button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.channel_menu = QMenu(self.channel_button)
        self.all_channels_action = QAction("All Channels", self.channel_menu)
        self.all_channels_action.setCheckable(True); self.all_channels_action.setChecked(False)
        self.all_channels_action.toggled.connect(self._toggle_all_channels)
        self.channel_menu.addAction(self.all_channels_action)
        self.show_disabled_rcv_action = QAction("Show disabled RCV", self.channel_menu)
        self.show_disabled_rcv_action.setCheckable(True); self.show_disabled_rcv_action.setChecked(False)
        self.show_disabled_rcv_action.setToolTip("calibration.ini IsEnabled=0 receivers are hidden by default")
        self.show_disabled_rcv_action.toggled.connect(self._main_disabled_rcv_visibility_changed)
        self.channel_menu.addAction(self.show_disabled_rcv_action)
        self.channel_menu.addSeparator()
        self.channel_button.setMenu(self.channel_menu)
        self.current_spectrum_label = QLabel("Spectrum: waiting")
        self.current_spectrum_label.setObjectName("CurrentValue")
        self.current_spectrum_label.setMaximumHeight(20)
        spectrum_layout = self.spectrum_panel.layout()
        channel_row = QHBoxLayout(); channel_row.setContentsMargins(0,0,0,0); channel_row.setSpacing(4)
        self.cpc_button = QPushButton("CPC OFF")
        self.cpc_button.setCheckable(True)
        self.cpc_button.setChecked(False)
        self.cpc_button.setToolTip("Switch the main Acoustic Spectrum between Sonication SpectrumMsg and mapped CPC 8CH FFT data")
        self.cpc_button.show()
        self.cpc_button.toggled.connect(self._cpc_toggled)
        self.spectrum_mode_combo = QComboBox()
        self.spectrum_mode_combo.addItems(["Current", "Average", "Max Hold", "Baseline Δ"])
        self.spectrum_mode_combo.setCurrentText(self.chart_state.spectrum_mode)
        self.spectrum_mode_combo.setToolTip("Current frame, score-window average, max hold, or fixed-baseline delta")
        self.spectrum_mode_combo.currentTextChanged.connect(self._spectrum_mode_changed)
        channel_row.addWidget(self.channel_button); channel_row.addWidget(self.cpc_button); channel_row.addWidget(self.spectrum_mode_combo); channel_row.addWidget(self.current_spectrum_label); channel_row.addStretch(1)
        spectrum_layout.insertLayout(0, channel_row)
        acoustic_box = self._chart_panel("Power % / Score", self.acoustic_control_plot, "acoustic")
        self.waterfall_panel = self._chart_panel("Relative Acoustic Spectrum vs Replay Time", self.waterfall_replay_plot, "waterfall")

        # R0038: Cavitation intelligence is part of the default Sonication Replay.
        # It is decoded in the background from the mapped CPC SpectrumDumps and
        # Acquisition_Brain evidence; the main acoustic spectrum source does not
        # need to be switched to CPC for this panel to work.
        self.replay_cavitation_box = QGroupBox("Cavitation Intelligence")
        cav_layout = QVBoxLayout(self.replay_cavitation_box)
        cav_layout.setContentsMargins(7, 12, 7, 7); cav_layout.setSpacing(4)
        self.replay_cavitation_status = QLabel("Waiting for Sonication data")
        self.replay_cavitation_status.setWordWrap(True); self.replay_cavitation_status.setObjectName("CurrentValue")
        cav_layout.addWidget(self.replay_cavitation_status)
        band_row = QHBoxLayout(); band_row.setSpacing(6)
        self.replay_band_labels = []
        for band in range(4):
            label = QLabel(f"B{band}: --")
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            label.setToolTip(f"Vendor cavitation Band{band} energy at the nearest CPC FFT snapshot")
            self.replay_band_labels.append(label); band_row.addWidget(label, 1)
        cav_layout.addLayout(band_row)
        self.replay_cavitation_tabs = QTabWidget()
        self.replay_cavitation_tabs.setDocumentMode(True)
        self.replay_cavitation_map = pg.PlotWidget()
        self.replay_cavitation_map.setMinimumHeight(105)
        self.replay_cavitation_map.setAspectLocked(True)
        self.replay_cavitation_map.hideAxis("left"); self.replay_cavitation_map.hideAxis("bottom")
        self.replay_cavitation_map.setMouseEnabled(x=False, y=False)
        self.replay_cavitation_image = pg.ImageItem(axisOrder="row-major")
        self.replay_cavitation_map.addItem(self.replay_cavitation_image)
        self.replay_cavitation_tabs.addTab(self.replay_cavitation_map, "RCV likelihood")
        self.replay_mr_corr_plot = pg.PlotWidget()
        self.replay_mr_corr_plot.setMinimumHeight(105)
        self.replay_mr_corr_plot.setAspectLocked(True)
        self.replay_mr_corr_plot.hideAxis("left"); self.replay_mr_corr_plot.hideAxis("bottom")
        self.replay_mr_corr_plot.setMouseEnabled(x=False, y=False)
        self.replay_mr_corr_image = pg.ImageItem(axisOrder="row-major")
        self.replay_mr_corr_plot.addItem(self.replay_mr_corr_image)
        self.replay_cavitation_tabs.addTab(self.replay_mr_corr_plot, "MR correlation")
        cav_layout.addWidget(self.replay_cavitation_tabs, 1)
        self.replay_cavitation_detail = QLabel("Dominant RCV: -- | MR correlation: --")
        self.replay_cavitation_detail.setWordWrap(True)
        cav_layout.addWidget(self.replay_cavitation_detail)

        right = QWidget(); rl = QVBoxLayout(right); rl.setContentsMargins(0,0,0,0)
        # A vertical splitter guarantees a real plotting viewport for Power/Score
        # on 1366x768 laptops; fixed minimums previously exceeded screen height.
        self.waterfall_panel.setVisible(False)
        self.lower_split=QSplitter(Qt.Orientation.Horizontal)
        self.lower_split.addWidget(acoustic_box); self.lower_split.addWidget(self.replay_cavitation_box); self.lower_split.setMinimumHeight(150)
        self.lower_split.setStretchFactor(0, 3); self.lower_split.setStretchFactor(1, 2)
        self.lower_split.setSizes([560, 360])
        self.right_vertical_split = QSplitter(Qt.Orientation.Vertical)
        self.right_vertical_split.addWidget(navigator_box)
        self.right_vertical_split.addWidget(self.graph_split)
        self.right_vertical_split.addWidget(self.lower_split)
        for i in range(3): self.right_vertical_split.setCollapsible(i, False)
        self.right_vertical_split.setStretchFactor(0, 3)
        self.right_vertical_split.setStretchFactor(1, 4)
        self.right_vertical_split.setStretchFactor(2, 4)
        self.right_vertical_split.setSizes([190, 230, 210])
        rl.addWidget(self.right_vertical_split,1)

        self.top_split = QSplitter(Qt.Orientation.Horizontal)
        self.top_split.addWidget(left); self.top_split.addWidget(self.overlay); self.top_split.addWidget(right)
        self.top_split.setSizes([285,735,760]); self.top_split.setStretchFactor(1,5); self.top_split.setStretchFactor(2,4)

        self.first_btn=QPushButton("|<"); self.prev_btn=QPushButton("<"); self.play_btn=QPushButton("▶")
        self.next_btn=QPushButton(">"); self.last_btn=QPushButton(">|")
        self.first_btn.clicked.connect(lambda:self.set_frame(0)); self.prev_btn.clicked.connect(self.previous_frame)
        self.play_btn.clicked.connect(self.toggle_play); self.next_btn.clicked.connect(self.next_frame)
        self.last_btn.clicked.connect(lambda:self.set_frame(max(0,self.current.replay_frame_count-1) if self.current else 0))
        self.speed=QComboBox()
        self.speed.addItem("0.25×", 0.25)
        self.speed.addItem("0.5×", 0.5)
        self.speed.addItem("1× Actual", 1.0)
        self.speed.addItem("2×", 2.0)
        self.speed.addItem("4×", 4.0)
        self.speed.addItem("8×", 8.0)
        self.speed.setCurrentIndex(2)
        self.speed.setToolTip("1× Actual replays each MR frame using the treatment acquisition timeline. Faster/slower settings multiply that real timing.")
        self.speed.currentIndexChanged.connect(self.speed_changed)
        self.workstation_replay_check = QCheckBox("Workstation replay")
        self.workstation_replay_check.setChecked(True)
        self.workstation_replay_check.setToolTip("Reveal acquired images and trends progressively, matching the treatment workstation recording")
        self.workstation_replay_check.toggled.connect(self._workstation_replay_toggled)
        self.frame_label=QLabel("Frame -/-"); self.frame_label.setObjectName("CurrentValue")
        self.sync_label=QLabel("Image / Temperature / Spectrum: waiting"); self.sync_label.setObjectName("CurrentValue")
        self.timeline=QSlider(Qt.Orientation.Horizontal); self.timeline.valueChanged.connect(self.slider_changed)
        controls=QHBoxLayout()
        for w in (self.first_btn,self.prev_btn,self.play_btn,self.next_btn,self.last_btn,QLabel("Replay speed"),self.speed,self.workstation_replay_check,self.frame_label): controls.addWidget(w)
        controls.addStretch(1); controls.addWidget(self.sync_label)
        bottom=QWidget(); bl=QVBoxLayout(bottom); bl.setContentsMargins(5,1,5,3); bl.addLayout(controls); bl.addWidget(self.timeline)

        page=QWidget(); layout=QVBoxLayout(page); layout.setContentsMargins(2,2,2,2)
        layout.addLayout(top_bar); layout.addWidget(self.top_split,1); layout.addWidget(bottom,0)
        return page

    def _build_analysis_tab(self) -> QWidget:
        """Preserve earlier analysis work without allowing it to dominate Replay."""
        self.hydro_view = QComboBox()
        self.hydro_view.addItems(["Both", "Spectrum", "Waterfall"])
        self.hydro_view.currentIndexChanged.connect(self._hydro_layout_changed)
        self.hydro_arrangement = QComboBox()
        self.hydro_arrangement.addItems(["Overlay", "Stacked"])
        self.hydro_arrangement.currentIndexChanged.connect(lambda _: self._update_analysis_hydrophone())

        controls = QHBoxLayout()
        controls.addWidget(QLabel("View"))
        controls.addWidget(self.hydro_view)
        controls.addWidget(QLabel("Spectrum layout"))
        controls.addWidget(self.hydro_arrangement)
        controls.addStretch(1)

        self.analysis_spectrum_plot = pg.PlotWidget(title="Hydrophone Spectrum Analysis")
        self.analysis_spectrum_plot.setLabel("bottom", "Frequency", units="kHz")
        self.analysis_spectrum_plot.showGrid(x=True, y=True, alpha=.2)
        self.waterfall_plot = pg.PlotWidget(title="Hydrophone Waterfall")
        self.waterfall_plot.setLabel("left", "Spectrum frame / channel")
        self.waterfall_plot.setLabel("bottom", "Frequency", units="kHz")
        self.waterfall_image = pg.ImageItem()
        self.waterfall_plot.addItem(self.waterfall_image)
        self.waterfall_cursor = pg.InfiniteLine(angle=0, movable=False, pen=pg.mkPen("y", width=2))
        self.waterfall_plot.addItem(self.waterfall_cursor)

        self.hydro_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.hydro_splitter.addWidget(self.analysis_spectrum_plot)
        self.hydro_splitter.addWidget(self.waterfall_plot)
        self.hydro_splitter.setSizes([800, 800])

        info = QLabel(
            "The earlier acoustic-analysis work is preserved here. "
            "Replay-first synchronization is completed before further analysis expansion."
        )
        info.setWordWrap(True)

        self.cavitation_summary = QLabel("Spectrum-derived cavitation indicators are not available until a sonication is loaded.")
        self.cavitation_summary.setWordWrap(True)
        self.cavitation_plot = pg.PlotWidget(title="Cavitation Visualization")
        self.cavitation_plot.setLabel("left", "Relative level", units="dB")
        self.cavitation_plot.setLabel("bottom", "MR acquisition time", units="sec")
        self.cavitation_plot.showGrid(x=True, y=True, alpha=.2)
        self.cavitation_plot.addLegend(offset=(12,8))
        self.cavitation_sub_curve=self.cavitation_plot.plot(pen=pg.mkPen("#4cc9f0",width=2),name="Subharmonic")
        self.cavitation_ultra_curve=self.cavitation_plot.plot(pen=pg.mkPen("#f72585",width=2),name="Ultraharmonic")
        self.cavitation_broad_curve=self.cavitation_plot.plot(pen=pg.mkPen("#ffd166",width=2),name="Broadband")
        self.cavitation_total_curve=self.cavitation_plot.plot(pen=pg.mkPen("#06d6a0",width=2.5),name="Cavitation index")
        self.cavitation_cursor=pg.InfiniteLine(angle=90,movable=False,pen=pg.mkPen("#ffffff",width=1.5,style=Qt.PenStyle.DashLine))
        self.cavitation_plot.addItem(self.cavitation_cursor)

        page = QWidget()
        layout = QVBoxLayout(page)
        layout.addWidget(info)
        layout.addLayout(controls)
        layout.addWidget(self.hydro_splitter, 1)
        layout.addWidget(self.cavitation_summary)
        layout.addWidget(self.cavitation_plot, 0)
        return page

    def _build_planning_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        note = QLabel("Planning resources are extracted separately from Sonication replay frames. CT/SDR, pre-treatment MR, and registration data remain traceable to their source files.")
        note.setWordWrap(True); layout.addWidget(note)
        self.planning_table = QTableWidget(0, 5)
        self.planning_table.setHorizontalHeaderLabels(["Category", "Role", "Confidence", "File", "Notes"])
        self.planning_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.planning_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.planning_table, 1)
        return page

    def _build_hydrophone_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        self.hydrophone_note = QLabel("No sonication loaded")
        self.hydrophone_note.setWordWrap(True); layout.addWidget(self.hydrophone_note)
        self.hydrophone_table = QTableWidget(8, 4)
        self.hydrophone_table.setHorizontalHeaderLabels(["Hydrophone", "Decoded Frames", "Peak Amplitude", "Status"])
        self.hydrophone_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.hydrophone_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.hydrophone_table, 1)
        return page

    def _update_planning_view(self):
        assets = list(getattr(self.package, "planning_assets", []) or []) if self.package else []
        self.planning_table.setRowCount(len(assets))
        for row, asset in enumerate(assets):
            values = [asset.category, asset.role, f"{asset.confidence:.0%}", str(asset.path.relative_to(self.package.workspace)), asset.notes]
            for col, value in enumerate(values):
                self.planning_table.setItem(row, col, QTableWidgetItem(str(value)))

    def _update_hydrophone_view(self):
        if not self.current or not self.package:
            return
        replay = self.hydrophone_replay_service.build(self.current, self.current.main_frequency_hz or self.package.main_frequency_hz or 650000.0)
        self.hydrophone_note.setText(replay.decoder_note)
        for row, channel in enumerate(replay.channels):
            peak = "-" if channel.peak_amplitude is None else f"{channel.peak_amplitude:.6g}"
            values = [channel.label, len(channel.frames), peak, "Available" if channel.frames else "No decoded record"]
            for col, value in enumerate(values):
                self.hydrophone_table.setItem(row, col, QTableWidgetItem(str(value)))

    def _open_hydrophone_window(self):
        if self.hydrophone_window is None:
            self.hydrophone_window = EightHydrophoneWindow(self)
            self.hydrophone_window.sonicationRequested.connect(self._select_sonication_index)
        if self.package:
            self.hydrophone_window.load_package(
                self.package, max(0, self.sonication_index), select_from_loaded_export=True
            )
        self.hydrophone_window.show(); self.hydrophone_window.raise_(); self.hydrophone_window.activateWindow()

    # --------------------------------------------------------------- Loading
    def _set_load_progress(self, value, message: str = ""):
        if not hasattr(self, "load_progress_bar"):
            return
        if value is None:
            self.load_progress_bar.hide(); self.load_progress_label.hide()
            return
        self.load_progress_bar.show(); self.load_progress_label.show()
        self.load_progress_bar.setValue(max(0, min(100, int(value))))
        self.load_progress_label.setText(message)
        self.statusBar().showMessage(message)

    def _inline_notice(self, message: str, *, error: bool = False):
        self.statusBar().showMessage(message, 10000)
        if hasattr(self, "sync_label"):
            self.sync_label.setText(message)
            self.sync_label.setStyleSheet("color:#c0392b;" if error else "")

    def open_zip(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "Open treatment or Sonication ZIP", "", "ZIP files (*.zip)")
        if file_name:
            self.load(Path(file_name))

    def open_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Open treatment or Sonication folder")
        if folder:
            self.load(Path(folder))

    def load(self, source: Path):
        # Package extraction/discovery is intentionally asynchronous.  The current
        # replay remains interactive until the new package is ready.
        if self._package_load_thread is not None and self._package_load_thread.isRunning():
            self._inline_notice("Another source is still loading. Finish or select within the current study while it completes.")
            return
        self._set_load_progress(1, f"Loading {Path(source).name}...")
        thread = QThread(self)
        worker = PackageLoadWorker(Path(source))
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._set_load_progress)
        worker.finished.connect(self._package_load_finished)
        worker.failed.connect(self._package_load_failed)
        worker.finished.connect(thread.quit); worker.failed.connect(thread.quit)
        thread.finished.connect(worker.deleteLater); thread.finished.connect(thread.deleteLater)
        self._package_load_thread = thread; self._package_load_worker = worker
        thread.start()

    def _package_load_failed(self, message: str):
        LOG.error("Import failed: %s", message)
        self._set_load_progress(100, "Load failed")
        self._inline_notice(f"Load failed: {message}", error=True)
        self._load_progress_hide_timer.start(5000)

    def _package_load_finished(self, source, workspace, package, temp_dirs):
        previous_workspace = self.package.workspace if self.package else None
        if not package.sonications:
            # Adopt the worker temp dir only long enough to release it cleanly.
            for temp in list(temp_dirs or []):
                if temp not in self.importer.temp_dirs: self.importer.temp_dirs.append(temp)
            self.importer.release(workspace)
            self._set_load_progress(100, "No compatible Sonication data found")
            self._inline_notice("No compatible Sonication data found.", error=True)
            self._load_progress_hide_timer.start(4000)
            return
        for temp in list(temp_dirs or []):
            if temp not in self.importer.temp_dirs: self.importer.temp_dirs.append(temp)
        self._clear_study_reference_cache()
        self.package = package
        if self.hydrophone_window is not None:
            try:self.hydrophone_window.load_package(self.package,0,select_from_loaded_export=False)
            except Exception as exc:LOG.warning("Spectrum Dump Analyzer context synchronization failed: %s",exc)
        self._rca_temperature_cache.clear()
        self._rca_previous_cavitation_cache.clear()
        self.current_cavitation_root_cause = None
        if previous_workspace is not None and previous_workspace != workspace:
            self.importer.release(previous_workspace)
        self._clear_replay_display()
        self.hydrophone_calibration = self.hydrophone_calibration_service.read(self.package.workspace)
        self.spectrum_provider = SpectrumMsgAnalyzerAdapter(self.package.main_frequency_hz, self.hydrophone_calibration)
        self.sonication_index = 0
        self.replay_context.configure_study(len(self.package.sonications))
        self._populate_sonication_combo()
        self._seed_sonication_summary_fast()
        self._sonication_summary_needs_detail=True
        self._set_load_progress(96, "Package ready; loading first Sonication...")
        # Heavy study panels are deferred so the Replay selector becomes usable first.
        self._select_sonication_index(0)
        workspace_token = Path(self.package.workspace)
        QTimer.singleShot(0, lambda w=workspace_token: self._deferred_study_load(w))

    def _deferred_study_load(self, workspace_token: Path):
        if not self.package or Path(self.package.workspace) != Path(workspace_token):
            return
        try:
            self._set_load_progress(97, "Loading diagnostics...")
            self.diagnostics_tab.load_study(self.package.workspace, self.package)
            self._update_planning_view()
        except Exception as exc:
            LOG.exception("Deferred study load failed")
            self._inline_notice(f"Some study details could not be loaded: {exc}", error=True)
        self._set_load_progress(100, f"Loaded {len(self.package.sonications)} sonication(s)")
        self._load_progress_hide_timer.start(2200)

    def _populate_sonication_combo(self) -> None:
        if not hasattr(self, "sonication_combo"):
            return
        current = self.sonication_index
        self.sonication_combo.blockSignals(True)
        self.sonication_combo.clear()
        if self.package and self.package.sonications:
            for i, son in enumerate(self.package.sonications):
                # Keep labels compact while still exposing useful identity when the
                # underlying folder name carries a timestamp/protocol hint.
                folder = getattr(son, "folder", None)
                name = Path(folder).name if folder else ""
                label = f"Sonication {i + 1}"
                if name and name.lower() not in {f"sonication{i+1}", f"sonication_{i+1}"}:
                    label += f" · {name}"
                self.sonication_combo.addItem(label, i)
        if self.sonication_combo.count():
            self.sonication_combo.setCurrentIndex(max(0, min(current, self.sonication_combo.count()-1)))
        self.sonication_combo.blockSignals(False)

    def _sonication_combo_changed(self, combo_index: int) -> None:
        if combo_index < 0 or not self.package or not self.package.sonications:
            return
        data = self.sonication_combo.itemData(combo_index) if hasattr(self, "sonication_combo") else None
        try:
            index = int(data) if data is not None else int(combo_index)
        except (TypeError, ValueError):
            index = int(combo_index)
        if index != self.sonication_index:
            self._select_sonication_index(index)

    def _change_sonication(self, step: int):
        if not self.package or not self.package.sonications:
            return
        self._select_sonication_index((self.sonication_index + step) % len(self.package.sonications))

    def _select_sonication_index(self, index: int):
        if not self.package or not self.package.sonications:
            return
        self._selection_generation += 1
        generation = self._selection_generation
        self._clear_replay_display()
        self.sonication_index = max(0, min(index, len(self.package.sonications)-1))
        self.current = self.package.sonications[self.sonication_index]
        if hasattr(self,"sonication_summary_current_line"):
            self.sonication_summary_current_line.setPos(self.sonication_index+1)
        son_freq = self.current.main_frequency_hz or self.package.main_frequency_hz
        channel_info = self.sonication_channel_service.read(self.current.folder) if getattr(self.current, "folder", None) else None
        self.spectrum_provider = SpectrumMsgAnalyzerAdapter(
            son_freq, self.hydrophone_calibration,
            channel_hint=(channel_info.channel if channel_info else None),
            channel_source=(str(channel_info.source) if channel_info and channel_info.source else None),
        )
        self.timer.stop(); self.play_btn.setText("▶")
        self.replay.clear_cache()
        self.cursor_x = self.cursor_y = None
        self._overlay_session_view = None; self._overlay_session_levels = None
        self._restore_overlay_session = False; self._fit_overlay_next = True
        if hasattr(self, "sonication_combo"):
            self.sonication_combo.blockSignals(True)
            # Combo entries carry the authoritative Sonication index as itemData.
            target = self.sonication_combo.findData(self.sonication_index)
            self.sonication_combo.setCurrentIndex(target if target >= 0 else self.sonication_index)
            self.sonication_combo.setToolTip(self._sonication_popup_text())
            self.sonication_combo.blockSignals(False)
        self.frame_index = 0
        initial_mode = "thermal" if self.current.temperature_frames else "anatomy"
        self._main_image_mode = initial_mode
        self.replay_context.select_sonication(self.sonication_index, self.current.replay_frame_count, self.frame_index)
        try:
            self.set_frame(self.frame_index, display_mode=initial_mode)
        except Exception as exc:
            LOG.debug("Initial frame deferred: %s", exc)
        self._set_load_progress(8, f"Sonication {self.sonication_index+1}: loading streams...")
        QTimer.singleShot(0, lambda g=generation: self._load_selected_stage(g, 0))

    def _load_selected_stage(self, generation: int, stage: int):
        if generation != self._selection_generation or not self.current or not self.package:
            return
        stages = [
            (22, "Spectrum and timing", self._selected_stage_spectrum),
            (42, "Temperature / power trends", self._selected_stage_trends),
            (61, "Cavitation evidence", self._selected_stage_cavitation),
            (78, "Image thumbnails", self._selected_stage_navigator),
            (91, "Metadata and analysis panels", self._selected_stage_metadata),
        ]
        if stage >= len(stages):
            self._set_load_progress(100, f"Sonication {self.sonication_index+1} ready")
            self.statusBar().showMessage(f"Sonication {self.sonication_index+1} ready; selection remains active during background-style staged loading")
            self._load_progress_hide_timer.start(1800)
            return
        value, label, fn = stages[stage]
        self._set_load_progress(value, f"Sonication {self.sonication_index+1}: {label}...")
        try:
            fn()
        except Exception as exc:
            LOG.exception("Sonication load stage failed: %s", label)
            self._inline_notice(f"{label} partially unavailable: {exc}", error=True)
        QTimer.singleShot(0, lambda g=generation, s=stage+1: self._load_selected_stage(g, s))

    def _selected_stage_spectrum(self):
        self._load_spectrum_channels()
        spectrum_counts = {name: len(frames) for name, frames in self.spectrum_channels.items() if frames}
        self.snapshot_provider.bind_sonication(self.sonication_index, self.current, spectrum_counts)
        self._prepare_common_timeline()

    def _selected_stage_trends(self):
        self._build_temperature_trends()
        self._build_acoustic_trends()

    def _selected_stage_cavitation(self):
        self._prepare_default_cavitation_intelligence()
        # Initial set_frame() runs before staged Cavitation decoding. Publish the
        # prepared evidence immediately instead of waiting for a Replay action.
        self._update_default_cavitation_intelligence()

    def _selected_stage_navigator(self):
        self._build_frame_navigator()
        first = self._first_valid_replay_frame()
        if first != self.frame_index:
            self.frame_index = first
            self.set_frame(first, display_mode=self._main_image_mode)

    def _selected_stage_metadata(self):
        self._update_sonication_metadata()
        # R0106a: Sonication Elements depends on the selected Sonication.  It was
        # not refreshed by the staged loader, leaving the page blank until a
        # manual Rescan/Open Log even though ChannelMeasure.ini and SkullMeasures
        # were already present in the export.
        self._ci_sonic_cache_key = None
        self._update_sonication_elements_page()
        self._update_cavitation_intelligence_page()
        self._refresh_export_workspaces()
        self._refresh_engineering_analysis()
        try:
            self.diagnostics_tab.select_sonication(self.sonication_index)
        except Exception:
            pass
        if self.hydrophone_window is not None:
            try:self.hydrophone_window.sync_sonication(self.sonication_index)
            except Exception as exc:LOG.debug("Spectrum Dump Analyzer Sonication sync deferred: %s",exc)

    def _highest_average_frame(self):
        if not self.mean_temperature_trend:
            return 0
        values=np.asarray(self.mean_temperature_trend,float)
        return int(np.nanargmax(values)) if np.isfinite(values).any() else 0

    def select_sonication(self):
        return

    def _sonication_popup_text(self):
        if not self.current or not self.package:
            return "No sonication loaded"
        return (f"Sonication {self.sonication_index+1} / {len(self.package.sonications)}\n"
                f"Name: {self.current.name}\nFrames: {self.current.replay_frame_count}\n"
                f"Duration: {self._replay_duration_s():.3f} sec\n"
                f"Temperature RAW: {len(self.current.temperature_frames)}\n"
                f"Magnitude RAW: {len(self.current.magnitude_frames)}\n"
                f"SpectrumMsg: {len(self.current.spectrum_files)}\nACT: {len(self.current.act_files)}")

    # ---------------------------------------------------------- Synchronization
    def _prepare_common_timeline(self) -> None:
        self.current_timeline_duration_s = 0.0
        if not self.current or not self.package:
            return
        if self.current.replay_frame_count > 1:
            # Product Replay shows the complete MR acquisition window.  Exported
            # thermometry frames are approximately 3.4 s apart in this platform.
            self.current_timeline_duration_s = float(self.current.replay_frame_count - 1) * 3.4
        else:
            measured = self.acoustic_control_service.measured_duration_for_sonication(
                self.package.workspace, self.sonication_index
            )
            self.current_timeline_duration_s = float(measured or 0.0)

    def _build_temperature_trends(self):
        self.max_temperature_trend = []
        self.mean_temperature_trend = []
        self.delta_trend = []
        if not self.current:
            return
        for index in range(self.current.replay_frame_count):
            try:
                data = self.replay.frame(self.current, index)
                self.max_temperature_trend.append(data.maximum_temperature if data.maximum_temperature is not None else np.nan)
                self.mean_temperature_trend.append(data.mean_temperature if data.mean_temperature is not None else np.nan)
                self.delta_trend.append(data.maximum_delta_temperature if data.maximum_delta_temperature is not None else np.nan)
            except Exception:
                self.max_temperature_trend.append(np.nan)
                self.mean_temperature_trend.append(np.nan)
                self.delta_trend.append(np.nan)
        x = self._frame_time_axis(self.current.replay_frame_count)
        self.max_temperature_curve.setData(x, np.asarray(self.max_temperature_trend, float), connect="finite")
        self.mean_temperature_curve.setData(x, np.asarray(self.mean_temperature_trend, float), connect="finite")
        if len(x):
            self._fit_temperature_trend(force=not self.chart_state.temperature_user_zoomed)

    def _build_acoustic_trends(self):
        count = self.current.replay_frame_count if self.current else 0
        if not self.current or not self.package or count <= 0:
            self.acoustic_peaks = np.asarray([], dtype=float)
            self.acoustic_scores = np.asarray([], dtype=float)
            self.acoustic_control_trend = None
            self.acoustic_power_curve.setData([], [])
            self.acoustic_score_curve.setData([], [])
            return
        duration = self._index_to_seconds(max(count - 1, 0), count)
        trend = self.acoustic_control_service.trend_for_sonication(
            self.package.workspace, self.sonication_index, count, duration
        )
        self.acoustic_control_trend = trend
        self.acoustic_peaks = trend.power_percent
        self.acoustic_scores = trend.score_percent
        tx=np.asarray(trend.time_s,float); py=np.asarray(trend.power_percent,float); sy=np.asarray(trend.score_percent,float)
        if not np.isfinite(py).any() and self.current.planned_power_w is not None:
            # planned_power_w is an absolute Watt value, never a percentage.
            # Keep the percentage plot empty and expose the Watt value as annotation.
            py=np.full(tx.shape, np.nan, dtype=float)
            trend.power_percent=py
            trend.status=f"Measured Power % unavailable; planned power {float(self.current.planned_power_w):.1f} W"
        plot_tx=np.asarray(trend.plot_time_s if getattr(trend,"plot_time_s",None) is not None else trend.time_s,float)
        plot_py=np.asarray(trend.plot_power_percent if getattr(trend,"plot_power_percent",None) is not None else trend.power_percent,float)
        plot_sy=np.asarray(trend.plot_score_percent if getattr(trend,"plot_score_percent",None) is not None else trend.score_percent,float)
        self.acoustic_power_curve.setData(plot_tx, plot_py, connect="finite")
        self.acoustic_score_curve.setData(plot_tx, plot_sy, connect="finite")
        finite = np.concatenate((trend.power_percent[np.isfinite(trend.power_percent)], trend.score_percent[np.isfinite(trend.score_percent)]))
        # Power and Score are percentages: keep a stable 0-110 % viewport.
        self.acoustic_control_plot.setYRange(0.0, 110.0, padding=0.0)
        if not np.isfinite(py).any() and self.current.planned_power_w is not None:
            self.acoustic_power_text.setText(f"Planned: {float(self.current.planned_power_w):.1f} W\nMeasured Power % unavailable")
        replay_axis_end = self._index_to_seconds(max(count - 1, 0), count)
        self._update_acoustic_replay_view(replay_axis_end, progressive=False)
        if trend.source:
            self.acoustic_control_plot.setTitle("")
        else:
            self.acoustic_control_plot.setTitle("")

    def _update_acoustic_replay_view(self, current_s: float | None = None, *, progressive: bool = True) -> None:
        """Curve ends at acoustic exposure; X axis follows Replay/MR acquisition time."""
        trend = getattr(self, "acoustic_control_trend", None)
        if trend is None or not hasattr(self, "acoustic_control_plot"):
            return
        plot_tx = np.asarray(trend.plot_time_s if getattr(trend, "plot_time_s", None) is not None else trend.time_s, float)
        plot_py = np.asarray(trend.plot_power_percent if getattr(trend, "plot_power_percent", None) is not None else trend.power_percent, float)
        plot_sy = np.asarray(trend.plot_score_percent if getattr(trend, "plot_score_percent", None) is not None else trend.score_percent, float)
        exposure_end = getattr(trend, "acoustic_end_s", None)
        keep = np.isfinite(plot_tx)
        if exposure_end is not None and np.isfinite(exposure_end):
            keep &= plot_tx <= float(exposure_end) + 1e-6
        if progressive and current_s is not None and np.isfinite(current_s):
            keep &= plot_tx <= float(current_s) + 1e-6
        self.acoustic_power_curve.setData(plot_tx[keep], plot_py[keep], connect="finite")
        self.acoustic_score_curve.setData(plot_tx[keep], plot_sy[keep], connect="finite")
        if current_s is None or not np.isfinite(current_s):
            count = self.current.replay_frame_count if self.current is not None else 0
            current_s = self._index_to_seconds(max(count - 1, 0), count) if count else 0.0
        axis_end = max(1.0, float(current_s))
        self.acoustic_control_plot.setXRange(0.0, axis_end, padding=0.01)
        self.acoustic_control_plot.enableAutoRange(axis="x", enable=False)

    def _ensure_acoustic_curve_items(self):
        """Recreate embedded Power/Score PlotDataItems when Qt loses them.

        Recreating the curves is more reliable than re-adding stale PlotDataItems
        after a popup has been opened or a sonication has changed.
        """
        for attr in ("acoustic_power_curve", "acoustic_score_curve"):
            item=getattr(self,attr,None)
            if item is not None:
                try: self.acoustic_control_plot.removeItem(item)
                except Exception: pass
        self.acoustic_power_curve=self.acoustic_control_plot.plot(pen=pg.mkPen("#58f26a",width=2.5),name="Power %")
        self.acoustic_score_curve=self.acoustic_control_plot.plot(pen=pg.mkPen("#ff9d22",width=2.5),name="Score")
        for item in (self.acoustic_control_cursor,self.acoustic_hover_text,self.acoustic_power_text,self.acoustic_score_text):
            try:
                if item not in self.acoustic_control_plot.items(): self.acoustic_control_plot.addItem(item)
            except Exception:
                try: self.acoustic_control_plot.addItem(item)
                except Exception: pass

    def _set_thermal_images_visible(self, checked: bool) -> None:
        visible = bool(checked)
        for widget in getattr(self, "_thermal_nav_widgets", []):
            widget.setVisible(visible)
        if visible:
            self._rebuild_all_image_strips()
            count = len(getattr(self, "_thermal_thumbnail_cache", {}))
            suffix = "ready" if getattr(self, "_thermal_thumbnails_complete", False) else "loading in background"
            self.statusBar().showMessage(f"Thermal Images: {count} thumbnail(s) {suffix}", 2500)

    def _cancel_thermal_thumbnail_worker(self) -> None:
        worker = getattr(self, "_thermal_thumbnail_worker", None)
        thread = getattr(self, "_thermal_thumbnail_thread", None)
        if worker is not None:
            try: worker.cancel()
            except Exception: pass
        if thread is not None and thread.isRunning():
            try:
                thread.quit()
                thread.wait(120)
            except Exception:
                pass
        self._thermal_thumbnail_worker = None
        self._thermal_thumbnail_thread = None

    def _start_thermal_thumbnail_background(self) -> None:
        self._cancel_thermal_thumbnail_worker()
        self._thermal_thumbnail_generation += 1
        generation = self._thermal_thumbnail_generation
        self._thermal_thumbnail_cache = {}
        self._thermal_thumbnails_complete = False
        frames = list(getattr(self.current, "temperature_frames", []) or []) if self.current else []
        if not frames:
            self._thermal_thumbnails_complete = True
            return
        thread = QThread(self)
        worker = ThermalThumbnailWorker(frames, generation)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.frameReady.connect(self._thermal_thumbnail_ready)
        worker.finished.connect(self._thermal_thumbnail_finished)
        worker.finished.connect(thread.quit)
        thread.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        self._thermal_thumbnail_thread = thread
        self._thermal_thumbnail_worker = worker
        thread.start()

    def _thermal_thumbnail_ready(self, row: int, array, filename: str, generation: int) -> None:
        if int(generation) != int(getattr(self, "_thermal_thumbnail_generation", -1)):
            return
        arr = np.asarray(array, np.float32)
        self._thermal_thumbnail_cache[int(row)] = (arr, str(filename))
        # Thermal row is visible by default. Rebuild in batches as the
        # background cache fills; no obsolete Show-Thermal checkbox gate.
        if len(self._thermal_thumbnail_cache) <= 3 or len(self._thermal_thumbnail_cache) % 8 == 0:
            self._rebuild_all_image_strips()

    def _thermal_thumbnail_finished(self, generation: int) -> None:
        if int(generation) != int(getattr(self, "_thermal_thumbnail_generation", -1)):
            return
        self._thermal_thumbnails_complete = True
        self._thermal_thumbnail_worker = None
        self._thermal_thumbnail_thread = None
        self._rebuild_all_image_strips()
        self.statusBar().showMessage(f"Thermal thumbnails ready: {len(self._thermal_thumbnail_cache)}", 2200)

    def _build_frame_navigator(self):
        for widget in (self.planning_frame_list, self.anatomy_frame_list, self.thermal_frame_list):
            widget.blockSignals(True); widget.clear()
        self._planning_display_arrays = []
        self._anatomy_row_map = []
        self._thermal_row_map = []
        if not self.current:
            for widget in (self.planning_frame_list, self.anatomy_frame_list, self.thermal_frame_list): widget.blockSignals(False)
            return

        if not self._planning_assets_all:
            assets = list(getattr(self.package, "planning_assets", []) or []) if self.package else []
            for asset in assets:
                category=self._planning_category(asset)
                if category not in {
                    "Preplanning CT","Preplanning MR Ax","Preplanning MR Sag","Preplanning MR Cor",
                    "Planning MR Ax","Planning MR Sag","Planning MR Cor",
                }:
                    continue
                source_kind=getattr(asset,"source_kind",None)
                suffix=f" · {source_kind}" if source_kind else ""
                label=f"{category.replace('Planning ','')}\n{asset.path.name}{suffix}"
                self._planning_assets_all.append((asset,None,label,category))
        # Row selectors are fixed and identical for all three rows.  Do not
        # repopulate the first combo from discovered categories because that
        # would remove the requested cross-row choices.

        # All thumbnail slots exist immediately. A background worker decodes
        # only after the first interactive paint so ZIP/Sonication loading is not
        # competing with hundreds of RAW thumbnail reads on the UI critical path.
        # Compatibility contract: self._start_image_thumbnail_background() remains
        # the worker entry point; it is deliberately invoked through QTimer below.
        QTimer.singleShot(220,self._start_image_thumbnail_background)
        QTimer.singleShot(420,self._start_thermal_thumbnail_background)

        for widget in (self.planning_frame_list, self.anatomy_frame_list, self.thermal_frame_list): widget.blockSignals(False)
        self._rebuild_all_image_strips()

    def _cancel_image_thumbnail_workers(self) -> None:
        for worker in list(getattr(self,"_image_thumbnail_workers",{}).values()):
            try: worker.cancel()
            except Exception: pass
        for thread in list(getattr(self,"_image_thumbnail_threads",{}).values()):
            try:
                if thread.isRunning():
                    thread.quit(); thread.wait(80)
            except Exception: pass
        self._image_thumbnail_workers={}; self._image_thumbnail_threads={}

    def _start_image_thumbnail_background(self) -> None:
        self._cancel_image_thumbnail_workers()
        self._image_thumbnail_generation += 1
        generation=self._image_thumbnail_generation
        self._treatment_mr_thumbnail_cache={}
        reference_assets=[a for a,_arr,_label,cat in getattr(self,"_planning_assets_all",[]) if cat!="Preplanning CT"]
        treatment_frames=list(getattr(self.current,"magnitude_frames",[]) or []) if self.current else []
        reference_sources=[]
        for row,asset in enumerate(reference_assets):
            key=(str(getattr(asset,"path","")),getattr(asset,"array_index",None),getattr(asset,"field_index",None))
            if key not in self._reference_thumbnail_cache:
                reference_sources.append((row,asset))
        for role,sources in (("reference",reference_sources),("treatment_mr",treatment_frames)):
            if not sources: continue
            thread=QThread(self); worker=ImageThumbnailWorker(role,sources,generation)
            worker.moveToThread(thread); thread.started.connect(worker.run)
            worker.frameReady.connect(self._image_thumbnail_ready)
            worker.finished.connect(self._image_thumbnail_finished)
            worker.finished.connect(thread.quit); thread.finished.connect(worker.deleteLater); thread.finished.connect(thread.deleteLater)
            self._image_thumbnail_threads[role]=thread; self._image_thumbnail_workers[role]=worker
            thread.start(QThread.Priority.LowPriority)

    def _image_thumbnail_ready(self, role: str, row: int, array, filename: str, generation: int) -> None:
        if int(generation)!=int(getattr(self,"_image_thumbnail_generation",-1)): return
        arr=np.asarray(array,np.float32)
        if role=="reference":
            assets=[a for a,_arr,_label,cat in getattr(self,"_planning_assets_all",[]) if cat!="Preplanning CT"]
            if 0 <= int(row) < len(assets):
                asset=assets[int(row)]
                key=(str(getattr(asset,"path","")),getattr(asset,"array_index",None),getattr(asset,"field_index",None))
                self._reference_thumbnail_cache[key]=arr
                self._planning_array_cache[key]=arr
        elif role=="treatment_mr":
            self._treatment_mr_thumbnail_cache[int(row)]=arr
        self._apply_ready_thumbnail_to_visible_items(role, int(row), arr)

    def _apply_ready_thumbnail_to_visible_items(self, role: str, row: int, array) -> None:
        """Update only the matching visible list item; never rebuild/cancel the worker."""
        icon=self._array_icon(array)
        if role=="reference":
            assets=[a for a,_arr,_label,cat in getattr(self,"_planning_assets_all",[]) if cat!="Preplanning CT"]
            if not (0 <= int(row) < len(assets)):
                return
            target=assets[int(row)]
            target_key=(str(getattr(target,"path","")),getattr(target,"array_index",None),getattr(target,"field_index",None))
            strip=self.planning_frame_list
            for i in range(strip.count()):
                item=strip.item(i); payload=item.data(Qt.ItemDataRole.UserRole)
                if not payload or len(payload)<2:
                    continue
                source=payload[1]
                if not hasattr(source,"path"):
                    continue
                key=(str(getattr(source,"path","")),getattr(source,"array_index",None),getattr(source,"field_index",None))
                if key==target_key:
                    item.setIcon(icon)
        elif role=="treatment_mr":
            strip=self.anatomy_frame_list
            for i in range(strip.count()):
                item=strip.item(i); payload=item.data(Qt.ItemDataRole.UserRole)
                if payload and payload[0]=="treatment_mr" and int(payload[1])==int(row):
                    item.setIcon(icon)

    def _image_thumbnail_finished(self, role: str, generation: int) -> None:
        if int(generation)!=int(getattr(self,"_image_thumbnail_generation",-1)): return
        self._image_thumbnail_workers.pop(str(role),None); self._image_thumbnail_threads.pop(str(role),None)
        self._sync_all_image_scrollbars()
        self.statusBar().showMessage(f"Reference/Treatment MR thumbnails ready: {len(self._reference_thumbnail_cache)} / {len(self._treatment_mr_thumbnail_cache)}",2200)

    def _scroll_image_strip_to_index(self, strip, index: int) -> None:
        """Browse the thumbnail strip by image number without decoding/rebuilding it."""
        if strip is None or strip.count() <= 0:
            return
        row=max(0,min(int(index),strip.count()-1))
        item=strip.item(row)
        if item is not None:
            strip.scrollToItem(item,QAbstractItemView.ScrollHint.PositionAtCenter)

    def _sync_one_image_slider(self, strip) -> None:
        slider=getattr(self,"image_strip_scrollbars",{}).get(strip.property("imageRole"))
        if slider is None:
            return
        count=max(0,strip.count())
        slider.blockSignals(True)
        slider.setRange(0,max(0,count-1))
        slider.setSingleStep(1); slider.setPageStep(max(1,min(6,count if count else 1)))
        slider.setValue(0 if count==0 else max(0,min(slider.value(),count-1)))
        slider.blockSignals(False)
        slider.setEnabled(count>1)
        slider.setToolTip(f"{count} image(s) · drag to browse all images")

    def _sync_all_image_scrollbars(self) -> None:
        for strip in (self.planning_frame_list,self.anatomy_frame_list,self.thermal_frame_list):
            self._sync_one_image_slider(strip)


    def _planning_array_for_asset(self, asset):
        cache=getattr(self,"_planning_array_cache",None)
        if cache is None:
            cache={}; self._planning_array_cache=cache
        key=(str(getattr(asset,"path","")),getattr(asset,"array_index",None),getattr(asset,"field_index",None))
        if key in cache:
            return cache[key]
        array=self._decode_planning_image(asset)
        if array is not None:
            cache[key]=array
        return array

    def _all_image_entries(self):
        entries=[]
        planning_assets=list(getattr(self,"_planning_assets_all",[]))
        verified_ct_available=any(category=="Preplanning CT" and getattr(asset,"field_index",None)==16 for asset,_array,_label,category in planning_assets)
        category_to_mode={
            "Preplanning CT":"preplanning_ct",
            "Preplanning MR Ax":"preplanning_mr_ax", "Preplanning MR Sag":"preplanning_mr_sag", "Preplanning MR Cor":"preplanning_mr_cor",
            "Planning MR Ax":"planning_mr_ax", "Planning MR Sag":"planning_mr_sag", "Planning MR Cor":"planning_mr_cor",
        }
        ref_cache=getattr(self,"_reference_thumbnail_cache",{})
        for asset,array,label,category in planning_assets:
            mode=category_to_mode.get(category)
            if mode is None: continue
            if category=="Preplanning CT":
                if verified_ct_available and getattr(asset,"field_index",None)!=16: continue
                slice_no=getattr(asset,"array_index",None); label=f"CT {slice_no+1 if isinstance(slice_no,int) else '?'}\n{asset.path.name}"
            else:
                slice_no=getattr(asset,"array_index",None)
                desc=getattr(asset,"series_description",None) or getattr(asset,"role",category)
                source_kind=getattr(asset,"source_kind",None)
                source_text=f" · {source_kind}" if source_kind else ""
                label=f"{category.replace('Preplanning MR ','').replace('Planning MR ','')} {slice_no+1 if isinstance(slice_no,int) else '?'}\n{desc}{source_text}"
            key=(str(getattr(asset,"path","")),getattr(asset,"array_index",None),getattr(asset,"field_index",None))
            if key in ref_cache: array=ref_cache[key]
            entries.append((mode,array,label,asset))
        if self.current:
            mr_cache=getattr(self,"_treatment_mr_thumbnail_cache",{})
            for row,frame in enumerate(self.current.magnitude_frames):
                entries.append(("treatment_mr",mr_cache.get(int(row)),f"Treatment MR {row+1}\n{frame.path.name}",row))
            # R0106: thumbnail rebuilds must never re-read Thermal RAW files.
            # They consume the background cache only.
            for row,(arr,filename) in sorted(getattr(self, "_thermal_thumbnail_cache", {}).items()):
                entries.append(("treatment_thermal",arr,f"Thermal {row+1}\n{filename}",row))
        return entries

    def _rebuild_all_image_strips(self, *_):
        mapping={
            "Preplanning CT":{"preplanning_ct"},
            "Preplanning MR All":{"preplanning_mr_ax","preplanning_mr_sag","preplanning_mr_cor"},
            "Preplanning MR Ax":{"preplanning_mr_ax"}, "Preplanning MR Sag":{"preplanning_mr_sag"}, "Preplanning MR Cor":{"preplanning_mr_cor"},
            "Planning MR All":{"planning_mr_ax","planning_mr_sag","planning_mr_cor"},
            "Planning MR Ax":{"planning_mr_ax"}, "Planning MR Sag":{"planning_mr_sag"}, "Planning MR Cor":{"planning_mr_cor"},
            "Treatment MR":{"treatment_mr"}, "Treatment Thermal":{"treatment_thermal"},
            "All images":{"preplanning_ct","preplanning_mr_ax","preplanning_mr_sag","preplanning_mr_cor","planning_mr_ax","planning_mr_sag","planning_mr_cor","treatment_mr","treatment_thermal"},
        }
        entries=self._all_image_entries()
        rows=(("planning",self.planning_frame_list,self.planning_type_combo),("anatomy",self.anatomy_frame_list,self.anatomy_type_combo),("thermal",self.thermal_frame_list,self.thermal_type_combo))
        self._image_strip_payloads={}
        for role,strip,combo in rows:
            strip.blockSignals(True); strip.clear()
            payloads=[]
            allowed=mapping.get(combo.currentText(),{"planning","anatomy","thermal"})
            for mode,array,label,source_index in entries:
                if mode not in allowed:
                    continue
                payload=(mode,source_index,array,label)
                icon=self._array_icon(array) if array is not None else QIcon()
                item=QListWidgetItem(icon,label); item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
                item.setData(Qt.ItemDataRole.UserRole,payload); strip.addItem(item)
                payloads.append(payload)
            self._image_strip_payloads[role]=payloads
            # Keep the horizontal scrollbar at the left when a newly selected
            # series is populated, so image 1 is immediately visible while all
            # remaining images stay accessible by sliding right.
            strip.horizontalScrollBar().setValue(0)
            self._sync_one_image_slider(strip)
            strip.setToolTip(f"{len(payloads)} image(s) in {combo.currentText()} · slide horizontally to browse all")
            strip.blockSignals(False)
        # Planning rows are reference selectors only.  Rebuilding thumbnails must
        # never replace the live replay image with a CT/MR planning slice.
        # The main viewer remains owned by ReplayContext until the user explicitly
        # clicks a planning thumbnail.
        self._sync_registration_button_state()

    def _is_registration_reference_mode(self, mode: str | None = None) -> bool:
        mode = self._main_image_mode if mode is None else str(mode)
        return mode.startswith("preplanning_mr_") or mode.startswith("planning_mr_")

    def _reference_combo_is_mr(self) -> bool:
        if not hasattr(self, "planning_type_combo"):
            return False
        return self.planning_type_combo.currentText().startswith("Preplanning MR") or self.planning_type_combo.currentText().startswith("Planning MR")

    def _sync_registration_button_state(self) -> None:
        if not hasattr(self, "registration_toggle_btn"):
            return
        main_is_mr = self._is_registration_reference_mode() and self._active_planning_asset is not None and self._active_planning_array is not None
        enabled = bool(main_is_mr)
        self.registration_toggle_btn.setEnabled(enabled)
        if enabled:
            if main_is_mr:
                self.registration_toggle_btn.setToolTip("Overlay preplanning CT skull/bone on the displayed MR using the treatment-adopted CtMr registration.")
            else:
                self.registration_toggle_btn.setToolTip("Display a Preplanning MR or Planning MR in the main Replay image first, then turn Registration ON.")
        else:
            self.registration_toggle_btn.setToolTip("Display a Preplanning MR or Planning MR in the main Replay image first to enable Registration.")
        # Preserve the user's Registration ON request while browsing other images.
        # The overlay is only rendered on a planning/preplanning MR reference, but
        # selecting another image must not silently clear the registration state.
        if self.registration_overlay_enabled:
            self.registration_toggle_btn.blockSignals(True)
            self.registration_toggle_btn.setChecked(True)
            self.registration_toggle_btn.setText("Registration")
            self.registration_toggle_btn.blockSignals(False)

    def _planning_reference_type_changed(self, *_):
        # Reference selector filters the hidden/optional reference row only.
        # The dominant main viewer stays on live Thermal until a thumbnail is
        # explicitly clicked by the user.
        self._rebuild_all_image_strips()
        self._sync_registration_button_state()


    def _activate_reference_for_registration(self) -> bool:
        if not hasattr(self, "planning_frame_list") or self.planning_frame_list.count() <= 0:
            return False
        row = self.planning_frame_list.currentRow()
        if row < 0:
            row = 0
        item = self.planning_frame_list.item(row)
        if item is None:
            return False
        payload = item.data(Qt.ItemDataRole.UserRole)
        if not payload or not self._is_registration_reference_mode(payload[0]):
            # Find the first MR reference in the visible list.
            for i in range(self.planning_frame_list.count()):
                candidate = self.planning_frame_list.item(i)
                cp = candidate.data(Qt.ItemDataRole.UserRole) if candidate is not None else None
                if cp and self._is_registration_reference_mode(cp[0]):
                    item = candidate; row = i; payload = cp; break
            else:
                return False
        self.planning_frame_list.blockSignals(True)
        self.planning_frame_list.setCurrentRow(row)
        self.planning_frame_list.blockSignals(False)
        self._activate_image_payload(payload)
        return self._is_registration_reference_mode()

    def _unified_image_item_selected(self, strip, item) -> None:
        """Activate a thumbnail even when it is already the current item."""
        if item is None:
            return
        self._activate_image_payload(item.data(Qt.ItemDataRole.UserRole))

    def _unified_image_selected(self, strip, row):
        if row < 0:
            return
        item = strip.item(row)
        if item is not None:
            self._activate_image_payload(item.data(Qt.ItemDataRole.UserRole))

    def _activate_image_payload(self, payload) -> None:
        """Display one thumbnail using explicit preplanning/planning/treatment semantics."""
        if not payload: return
        mode, source_index, array, label = payload
        planning_mr_modes={"preplanning_mr_ax","preplanning_mr_sag","preplanning_mr_cor","planning_mr_ax","planning_mr_sag","planning_mr_cor"}
        if mode == "preplanning_ct" or mode in planning_mr_modes:
            if array is None:
                array=self._planning_array_for_asset(source_index)
                if array is None:
                    self._inline_notice(f"Unable to decode selected exported reference image: {label}",error=True)
                    return
            # Preserve the live Replay zoom before entering a planning/reference view.
            if hasattr(self,"overlay") and not self._main_image_mode.startswith("preplanning_") and not self._main_image_mode.startswith("planning_mr_"):
                try: self._overlay_session_view = self.overlay.view_range()
                except Exception: pass
            self._main_image_mode = mode
            self._active_planning_asset = source_index
            self._active_planning_array = np.asarray(array,float) if array is not None else None
            self._displayed_plane_override = self._infer_asset_plane(source_index)
            self.overlay.set_hover_temperature(None); self.overlay.set_roi(None,None)
            # Always display the newly selected MR first. Registration must not
            # leave the previous image visible while CT reslicing is evaluated.
            self.overlay.set_overlay(array,None,fit=self._planning_overlay_view is None)
            if mode in planning_mr_modes and self.registration_overlay_enabled:
                self._apply_registration_overlay()
            if self._planning_overlay_view is not None:
                try: self.overlay.set_view_range(self._planning_overlay_view)
                except Exception: pass
            is_mr=mode in planning_mr_modes
            if hasattr(self,"registration_toggle_btn"):
                self._sync_registration_button_state()
            kind="Preplanning CT" if mode=="preplanning_ct" else self._planning_category(source_index)
            self.frame_label.setText(f"{kind}: {label}")
            if not (is_mr and self.registration_overlay_enabled):
                suffix = " · Registration ON retained; overlay resumes on MR reference" if self.registration_overlay_enabled else " · Registration available on MR reference images"
                self.sync_label.setText(f"{kind} selected{suffix}")
            self._update_orientation_alignment_labels(); return
        if not self.current or source_index is None: return
        replay_mode="anatomy" if mode=="treatment_mr" else "thermal"
        series_count=len(self.current.magnitude_frames) if replay_mode=="anatomy" else len(self.current.temperature_frames)
        replay_index=self._map_data_to_replay(int(source_index),max(1,series_count),max(1,self.current.replay_frame_count))
        # Save planning/reference zoom separately; never feed it into Thermal Replay.
        if self._main_image_mode.startswith("preplanning_") or self._main_image_mode.startswith("planning_mr_"):
            try: self._planning_overlay_view = self.overlay.view_range()
            except Exception: pass
        self._main_image_mode=replay_mode
        self._active_planning_asset=None; self._active_planning_array=None
        if hasattr(self,"registration_toggle_btn"):
            self._sync_registration_button_state()
        # Planning/Registration and Replay keep independent ViewBox ranges.
        self._fit_overlay_next = self._overlay_session_view is None
        self._restore_overlay_session = self._overlay_session_view is not None
        if replay_mode=="anatomy":
            self.overlay.set_hover_temperature(None); self.overlay.set_roi(None,None)
        self.set_frame(replay_index,display_mode=replay_mode)

    def _show_registration_trace(self) -> None:
        # Full reference-series diagnostics are expensive and are needed only
        # when the operator explicitly opens this diagnostic window.
        if self._active_planning_asset is not None and self._active_planning_array is not None and self.package:
            ct_asset,ct_volume=self._ct_volume_for_registration()
            if ct_volume is not None:
                self._update_registration_reference_report(ct_asset,ct_volume)
        text = self.sync_label.text() if hasattr(self, "sync_label") else "Registration trace unavailable"
        dlg = QDialog(self)
        dlg.setWindowTitle("Registration Trace")
        dlg.resize(940, 400)
        layout = QVBoxLayout(dlg)
        editor = QTextEdit()
        editor.setReadOnly(True)
        editor.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth)
        editor.setPlainText(
            text
            + "\n\n"
            + str(getattr(self,"_registration_reference_report","REFERENCE CANDIDATES: not evaluated"))
            + "\n\nDiagnostic interpretation:\n"
            + "• forward outside / inverse inside → matrix direction is the leading suspect\n"
            + "• forward outside / inverse outside → displayed MR geometry or reference MR/plane is the leading suspect\n"
            + "• forward inside but overlay suppressed → inspect 3D landmark slice correspondence and 2D skull QA separately\n"
            + "• high landmark match with low 2D skull QA → matrix/reference chain is likely valid; displayed slice/image QA is the leading issue\n"
            + "• low landmark match across Ax/Sag/Cor → CT/MR patient geometry or registration chain remains suspect\n"
            + "• CURRENT SLICE QA excludes 3-D skull points outside the displayed slice (NOT_APPLICABLE_TO_SLICE)\n"
            + "• high direct/render overlap → DICOM patient→pixel projection and reslice renderer agree\n"
            + "• best display hypothesis not identity → transpose/flip in the display path is a diagnostic suspect only\n"
            + "This diagnostic does not modify the treatment registration matrix or auto-apply a display transform."
        )
        layout.addWidget(editor, 1)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(dlg.accept)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(close_btn)
        layout.addLayout(row)
        dlg.exec()

    def _registration_toggled(self, checked: bool) -> None:
        # Match treatment-workstation operation: Registration is a review overlay
        # on the MR that is already visible in the main Replay image. Never change
        # the displayed image implicitly when the button is pressed.
        if checked and not self._is_registration_reference_mode():
            self.registration_toggle_btn.blockSignals(True)
            self.registration_toggle_btn.setChecked(False)
            self.registration_toggle_btn.setText("Registration")
            self.registration_toggle_btn.blockSignals(False)
            self.registration_overlay_enabled=False
            self._inline_notice("Display a Preplanning MR or Planning MR in the main Replay image first.", error=False)
            self._sync_registration_button_state()
            return
        self.registration_overlay_enabled=bool(checked)
        self.registration_toggle_btn.setText("Registration")
        planning_mr=self._is_registration_reference_mode()
        if checked and planning_mr:
            self._apply_registration_overlay()
        elif self._active_planning_array is not None and planning_mr:
            self.overlay.set_overlay(self._active_planning_array,None,fit=False)
            self.sync_label.setText("Registration OFF · MR reference image only")
        self._sync_registration_button_state()

    def _ct_volume_for_registration(self):
        # R0111: R0110 made planning assets lazy but the registration path still
        # required pre-decoded CT arrays, making the bone overlay silently empty.
        if self._registration_ct_volume_cache is not None:
            return self._registration_ct_volume_cache
        ct_items=[]
        for a,arr,_label,cat in getattr(self,"_planning_assets_all",[]):
            if cat!="Preplanning CT" or getattr(a,"field_index",None)!=16:
                continue
            if arr is None:
                arr=self._planning_array_for_asset(a)
            if arr is not None:
                ct_items.append((a,np.asarray(arr,float)))
        if not ct_items:
            return None,None
        groups={}
        for a,arr in ct_items:
            key=(getattr(a,"sonication_index",None),arr.shape)
            groups.setdefault(key,[]).append((a,arr))
        key=max(groups,key=lambda k:(len({getattr(a,"array_index",None) for a,_ in groups[k]}),-(k[0] or 999)))
        selected=groups[key]
        unique={}
        for a,arr in selected:
            unique[getattr(a,"array_index",len(unique))]=(a,arr)
        selected=[unique[k] for k in sorted(unique,key=lambda x:(x is None,x if x is not None else 0))]
        if len(selected)<2:
            return None,None
        self._registration_ct_volume_cache=(selected[0][0],np.stack([arr for _a,arr in selected],axis=0))
        return self._registration_ct_volume_cache


    def _registration_reference_candidates(self):
        candidates=[]
        for asset,_array,_label,category in getattr(self,"_planning_assets_all",[]):
            if category.startswith("Preplanning MR") or category.startswith("Planning MR"):
                candidates.append(asset)
        return candidates

    def _update_registration_reference_report(self,ct_asset,ct_volume)->None:
        if not self.package:
            self._registration_reference_report="REFERENCE CANDIDATES: package unavailable"; return
        try:
            rows=self.registration_overlay_service.diagnose_reference_series(
                Path(self.package.workspace),self.sonication_index+1,ct_asset,ct_volume,
                self._registration_reference_candidates(),active_asset=self._active_planning_asset
            )
            self._registration_reference_report=self.registration_overlay_service.format_reference_diagnostic(rows,self._active_planning_asset,limit=16)
        except Exception as exc:
            LOG.exception("Registration reference-series diagnostic failed")
            self._registration_reference_report=f"REFERENCE CANDIDATES: diagnostic failed: {exc}"

    def _apply_registration_overlay(self) -> None:
        if self._active_planning_asset is None or self._active_planning_array is None or not self.package:
            return
        ct_asset,ct_volume=self._ct_volume_for_registration()
        if ct_volume is None:
            self.sync_label.setText("Registration ON requested · preplanning CT volume unavailable"); return
        plane=getattr(self._active_planning_asset,"plane",None) or self._infer_asset_plane(self._active_planning_asset) or "Ax"
        asset=self._active_planning_asset
        cache_key=(str(getattr(asset,"path","") or ""),getattr(asset,"array_index",None),
                   tuple(np.asarray(self._active_planning_array).shape),plane,self.sonication_index)
        try:
            result=self._registration_overlay_cache.get(cache_key)
            if result is None:
                result=self.registration_overlay_service.render_volume(Path(self.package.workspace),self.sonication_index+1,self._active_planning_array,plane,ct_asset,ct_volume,self._active_planning_asset)
                self._registration_overlay_cache[cache_key]=result
        except Exception as exc:
            LOG.exception("Registration overlay failed for %s",getattr(self._active_planning_asset,"path",None))
            self.overlay.set_overlay(self._active_planning_array,None,fit=False)
            self.sync_label.setText(f"Registration overlay error · MR image remains active · {type(exc).__name__}: {exc}")
            return
        if result.overlay is None or not np.isfinite(result.overlay).any():
            self.overlay.set_overlay(self._active_planning_array,None,fit=False)
            concise=""; report=str(getattr(self,"_registration_reference_report","") or "")
            for line in report.splitlines():
                if line.startswith("LEADING REFERENCE SERIES:"):
                    concise=" · "+line; break
            self.sync_label.setText(result.status+concise); return
        vals=result.overlay[np.isfinite(result.overlay)]; levels=tuple(map(float,np.percentile(vals,[5,99]))) if vals.size else None
        self.overlay.set_overlay(self._active_planning_array,result.overlay,None,levels,self._bone_overlay_lut(),0.64,fit=False)
        self.frame_label.setText(f"REGISTRATION ON · {self._planning_category(self._active_planning_asset)}")
        self.sync_label.setText(result.status + " · verify skull alignment on MR")

    def _activate_replay_mode_for_navigation(self) -> None:
        """Return the main viewer from a planning reference to live replay.

        Planning thumbnails are intentionally static references.  Timeline,
        arrows, wheel and playback always control the sonication replay and must
        therefore restore Thermal (or Anatomy when thermometry is unavailable).
        """
        if self._main_image_mode.startswith("preplanning_") or self._main_image_mode.startswith("planning_mr_") or self._main_image_mode in {"planning", "planning_ct", "planning_mr", "fusion"}:
            self._main_image_mode = "thermal" if self.current and self.current.temperature_frames else "anatomy"
            if hasattr(self, "planning_frame_list"):
                self.planning_frame_list.blockSignals(True)
                self.planning_frame_list.setCurrentRow(-1)
                self.planning_frame_list.blockSignals(False)
            self._fit_overlay_next = True
            self._sync_registration_button_state()

    @staticmethod
    def _resample_to_shape(array, shape):
        arr=np.asarray(array,float)
        if arr.shape[:2] == tuple(shape): return arr
        yi=np.linspace(0,arr.shape[0]-1,int(shape[0])).astype(int); xi=np.linspace(0,arr.shape[1]-1,int(shape[1])).astype(int)
        return arr[np.ix_(yi,xi)]

    @staticmethod
    def _bone_overlay_lut():
        """Bright light-green, semi-transparent LUT for registered skull only."""
        lut=np.zeros((256,4),dtype=np.ubyte)
        for i in range(256):
            t=i/255.0
            # High-visibility light green: skull body stays translucent, rim is bright.
            r=int(120 + 55*t)
            g=int(238 + 17*t)
            b=int(125 + 45*t)
            a=int(np.clip(80 + (t**1.05)*115,0,195))
            lut[i]=[r,g,b,a]
        lut[:24,3]=0
        return lut

    def _infer_asset_plane(self, asset):
        if asset is None: return None
        explicit=str(getattr(asset,'plane','') or '').strip()
        if explicit:
            return {'AX':'Axial','SAG':'Sagittal','COR':'Coronal'}.get(explicit.upper(), explicit.title())
        rd=np.asarray(getattr(asset,'row_direction',None),float)
        cd=np.asarray(getattr(asset,'col_direction',None),float)
        if rd.size==3 and cd.size==3 and np.linalg.norm(rd)>1e-6 and np.linalg.norm(cd)>1e-6:
            normal=np.cross(rd,cd)
            axis=int(np.argmax(np.abs(normal)))
            return ('Sagittal','Coronal','Axial')[axis]
        text=' '.join(str(getattr(asset,n,'')) for n in ('role','notes','path')).lower()
        if 'sag' in text: return 'Sagittal'
        if 'cor' in text: return 'Coronal'
        if 'ax' in text or 'axial' in text: return 'Axial'
        return None

    def _displayed_plane(self):
        if self._displayed_plane_override: return self._displayed_plane_override
        return self.current_metadata.summary.get('Orientation','Unavailable') if self.current_metadata else 'Unavailable'

    def _update_orientation_alignment_labels(self):
        if not hasattr(self,'summary_value_labels'): return
        if self._active_planning_asset is not None and (self._main_image_mode.startswith('preplanning_') or self._main_image_mode.startswith('planning_mr_')):
            meta=self._infer_asset_plane(self._active_planning_asset) or 'Unavailable'
        else:
            meta=self.current_metadata.summary.get('Orientation','Unavailable') if self.current_metadata else 'Unavailable'
        displayed=self._displayed_plane()
        status='Unavailable' if 'Unavailable' in (meta,displayed) else ('Aligned' if meta==displayed else f'Metadata {meta} / Display {displayed}')
        if 'Orientation' in self.summary_value_labels: self.summary_value_labels['Orientation'].setText(meta)
        if 'Displayed Plane' in self.summary_value_labels: self.summary_value_labels['Displayed Plane'].setText(displayed)
        if 'Orientation Status' in self.summary_value_labels: self.summary_value_labels['Orientation Status'].setText(status)

    @staticmethod
    def _gradient_signature(array):
        arr=np.asarray(array,float)
        finite=arr[np.isfinite(arr)]
        if finite.size < 16:
            return None
        lo,hi=np.percentile(finite,[2,98])
        scale=max(float(hi-lo),1e-6)
        norm=np.clip((arr-lo)/scale,0,1)
        gy,gx=np.gradient(np.nan_to_num(norm,nan=0.0))
        return np.hypot(gx,gy)

    def _best_ct_for_fusion(self, mr, preferred=None):
        candidates=[]
        for asset,array,_label,category in getattr(self,"_planning_assets_all",[]):
            if category != "Planning CT" or array is None:
                continue
            if getattr(asset,"field_index",None) not in (None,16):
                continue
            candidates.append((asset,array))
        if preferred is not None:
            candidates.sort(key=lambda pair: 0 if pair[0] is preferred else 1)
        if not candidates:
            return None,None,None
        mr_arr=np.asarray(mr,float)
        mr_sig=self._gradient_signature(mr_arr)
        best=None
        for asset,ct in candidates[:160]:
            ct_r=self._resample_to_shape(ct,mr_arr.shape[:2])
            ct_sig=self._gradient_signature(ct_r)
            if mr_sig is None or ct_sig is None:
                score=-1.0
            else:
                a=mr_sig.ravel(); b=ct_sig.ravel()
                valid=np.isfinite(a)&np.isfinite(b)
                if np.count_nonzero(valid)<100 or np.std(a[valid])<1e-8 or np.std(b[valid])<1e-8:
                    score=-1.0
                else:
                    score=float(np.corrcoef(a[valid],b[valid])[0,1])
            if best is None or score>best[0]:
                best=(score,asset,ct_r)
        return (best[1],best[2],best[0]) if best else (None,None,None)

    @staticmethod
    def _ct_edge_overlay(ct):
        arr=np.asarray(ct,float)
        finite=arr[np.isfinite(arr)]
        if finite.size < 16:
            return None
        bone_lo=float(np.percentile(finite,82))
        bone=np.where(arr>=bone_lo,arr,np.nan)
        # Edge-only overlay prevents a mismatched CT slice from obscuring MR anatomy.
        mask=np.isfinite(bone).astype(float)
        gy,gx=np.gradient(mask)
        edge=np.hypot(gx,gy)>0.05
        return np.where(edge,arr,np.nan)

    def _show_fusion_preview(self,payload,label):
        """Registration reference view.

        Do not fabricate a fusion by resizing CT to MR. A valid registration image
        requires a decoded transform. Until the transform matrix is decoded, show
        the Planning MR as the registered reference and report the CT/registration
        sources explicitly. This is safer and much closer to workstation behavior
        than a visually convincing but geometrically false overlay.
        """
        payload=payload or {}; mr=payload.get('mr')
        if mr is None:
            self.frame_label.setText('REGISTRATION | unavailable')
            self.sync_label.setText('Planning MR reference is required for registration review')
            return
        mr=np.asarray(mr,float)
        mf=mr[np.isfinite(mr)]
        ml=tuple(map(float,np.percentile(mf,[2,98.5]))) if mf.size else None
        self.overlay.set_hover_temperature(None); self.overlay.set_roi(None,None)
        self.overlay.set_overlay(mr,None,ml,None,None,0.0,fit=True)
        registrations=list(payload.get('registration_assets') or [])
        ct_asset=payload.get('ct_asset')
        ct_txt=f"CT source: {getattr(getattr(ct_asset,'path',None),'name','available')}" if ct_asset is not None else 'CT source unavailable'
        if registrations:
            reg_name=getattr(getattr(registrations[0],'path',None),'name','registration data')
            status=f"Registration source: {reg_name}; transform decoding pending"
        else:
            status='Registration transform not found'
        self.frame_label.setText(f'REGISTRATION REFERENCE | {label}')
        self.sync_label.setText(f'MR reference displayed | {ct_txt} | {status} | no synthetic CT/MR overlay')

    def _prepare_default_cavitation_intelligence(self) -> None:
        """Decode CPC cavitation evidence for the default Replay without changing source mode."""
        self.default_cpc_replay = None
        self.default_cavitation_timeline = None
        self.default_cavitation_likelihood = None
        self.default_cavitation_mr_correlation = None
        self._ci_event_preview_result = None
        if not self.package or not self.current:
            return
        try:
            replay = self.hydrophone_replay_service.build(
                self.package.cpc_spectrum_files, self.sonication_index, len(self.package.sonications)
            )
            self.default_cpc_replay = replay
            validation = getattr(replay, "vendor_control_validation", None)
            history = getattr(replay, "vendor_history_validation", None)
            preferred = getattr(history, "log_session_index", None) if history is not None else None
            cycles = getattr(validation, "event_cycles", np.asarray([], int)) if validation is not None else np.asarray([], int)
            predicted = getattr(validation, "predicted_power_ratio", np.asarray([], float)) if validation is not None else np.asarray([], float)
            source_path = replay.source_fft or replay.source_raw or self.package.workspace
            self.default_cavitation_timeline = self.cavitation_control_timeline_service.parse(
                source_path, getattr(replay, "vendor_profile", None), preferred, cycles, predicted
            )
        except Exception as exc:
            LOG.warning("Default cavitation intelligence unavailable: %s", exc)
            self.default_cpc_replay = None
            self.default_cavitation_timeline = None

    def _synchronized_cpc_frame_index(self, replay_time_s: float, tolerance_s: float | None = None) -> int | None:
        """Return only a CPC measurement genuinely close to the Replay cursor.

        Power delivery can finish before MR acquisition finishes, while the CPC/RCV
        acquisition may continue and record gradient/background noise.  Do not gate
        CPC data by acoustic power.  Also do not reuse the final CPC frame when no
        measurement exists at the requested MR time.
        """
        replay = self.default_cpc_replay
        if replay is None or not replay.frames:
            return None
        times = np.asarray([
            float(f.acquisition_time_s) if getattr(f, "acquisition_time_s", None) is not None else np.nan
            for f in replay.frames
        ], float)
        valid = np.isfinite(times)
        if not valid.any():
            return None
        idxs = np.flatnonzero(valid)
        local = int(np.argmin(np.abs(times[valid] - float(replay_time_s))))
        idx = int(idxs[local])
        if tolerance_s is None:
            diffs = np.diff(np.sort(times[valid]))
            diffs = diffs[np.isfinite(diffs) & (diffs > 0)]
            interval = float(np.median(diffs)) if diffs.size else float(getattr(replay, "frame_interval_s", 0.01) or 0.01)
            tolerance_s = max(0.06, min(0.35, interval * 2.5))
        if abs(float(times[idx]) - float(replay_time_s)) > float(tolerance_s):
            return None
        return idx

    def _spectrum_indices_at_time(self, replay_time_s: float, fallback: dict[str, int] | None = None) -> dict[str, int]:
        """Resolve displayed spectrum frames by measurement time when available."""
        out = {}
        fallback = fallback or {}
        for channel, frames in self.spectrum_channels.items():
            if not frames:
                continue
            times = np.asarray([
                float(getattr(f, "timestamp_seconds", np.nan)) if getattr(f, "timestamp_seconds", None) is not None else np.nan
                for f in frames
            ], float)
            valid = np.isfinite(times)
            if valid.any():
                idxs = np.flatnonzero(valid)
                j = int(idxs[int(np.argmin(np.abs(times[valid] - float(replay_time_s))))])
                diffs = np.diff(np.sort(times[valid])); diffs = diffs[np.isfinite(diffs) & (diffs > 0)]
                interval = float(np.median(diffs)) if diffs.size else 0.01
                tolerance = max(0.06, min(0.35, interval * 2.5))
                if abs(float(times[j]) - float(replay_time_s)) <= tolerance:
                    out[channel] = j
            elif channel in fallback:
                # Legacy SpectrumMsg contains no decoded absolute timestamp. Keep its
                # existing index mapping, but label it as index-synchronized in the UI.
                out[channel] = int(fallback[channel])
        return out

    def _nearest_observed_cavitation_event(self, replay_time_s: float, tolerance_s: float = 0.12):
        timeline = self.default_cavitation_timeline
        if timeline is None or not timeline.events:
            return None
        candidates=[]
        for event in timeline.events:
            t = getattr(event, "timestamp_s", None)
            if t is None or not np.isfinite(float(t)):
                continue
            candidates.append((abs(float(t)-float(replay_time_s)), event))
        if not candidates:
            return None
        distance,event=min(candidates,key=lambda item:item[0])
        return event if distance <= tolerance_s else None

    def _current_magnitude_signal_loss(self) -> tuple[float | None, str]:
        """Return robust central-ROI magnitude loss vs prior magnitude frame."""
        if not self.current or len(self.current.magnitude_frames) < 2:
            return None, "MR signal loss unavailable"
        count=max(1,int(self.current.replay_frame_count))
        idx=self.replay.raw.normalize_index(self.frame_index,count,len(self.current.magnitude_frames))
        if idx <= 0:
            return None, "MR baseline frame"
        try:
            prev=np.asarray(self.replay.raw.read_magnitude(self.current.magnitude_frames[idx-1].path),float)
            curr=np.asarray(self.replay.raw.read_magnitude(self.current.magnitude_frames[idx].path),float)
        except Exception:
            return None, "MR signal loss unavailable"
        if prev.shape != curr.shape or prev.ndim != 2 or not prev.size:
            return None, "MR signal loss unavailable"
        h,w=prev.shape; radius=max(4,min(h,w)//10); cy=h//2; cx=w//2
        y0,y1=max(0,cy-radius),min(h,cy+radius+1); x0,x1=max(0,cx-radius),min(w,cx+radius+1)
        p=prev[y0:y1,x0:x1]; c=curr[y0:y1,x0:x1]
        valid=np.isfinite(p)&np.isfinite(c)&(p>0)
        if np.count_nonzero(valid)<16:
            return None, "MR signal loss unavailable"
        # Remove global receive-gain drift by normalizing the current image to
        # the previous image using the whole-image positive median.
        gvalid=np.isfinite(prev)&np.isfinite(curr)&(prev>0)&(curr>0)
        if np.count_nonzero(gvalid)>64:
            gain=float(np.nanmedian(prev[gvalid])/max(np.nanmedian(curr[gvalid]),1e-9))
        else:
            gain=1.0
        ratio=np.asarray(c*gain,float)[valid]/np.asarray(p,float)[valid]
        median_ratio=float(np.nanmedian(ratio))
        loss=max(0.0,100.0*(1.0-median_ratio))
        local_fraction=float(np.mean(ratio<0.75))*100.0
        return loss, f"central ROI loss {loss:.1f}% · pixels <75% baseline {local_fraction:.1f}%"

    def _current_magnitude_correlation(self, likelihood_result):
        if not self.current or not self.current.magnitude_frames:
            return None
        count=max(1,int(self.current.replay_frame_count))
        idx=self.replay.raw.normalize_index(self.frame_index,count,len(self.current.magnitude_frames))
        if idx <= 0:
            return None
        try:
            current=np.asarray(self.replay.raw.read_magnitude(self.current.magnitude_frames[idx].path),float)
            baseline=[]
            for j in range(max(0,idx-3),idx):
                baseline.append(np.asarray(self.replay.raw.read_magnitude(self.current.magnitude_frames[j].path),float))
        except Exception:
            return None
        hp=None if likelihood_result is None else np.asarray(likelihood_result.likelihood_map,float)
        try:
            return self.cavitation_mr_correlation_service.analyze(baseline,current,hp)
        except Exception as exc:
            LOG.debug("MR cavitation correlation unavailable: %s",exc)
            return None

    def _draw_replay_mr_correlation(self, result) -> None:
        if not hasattr(self,"replay_mr_corr_plot"):
            return
        self.replay_mr_corr_plot.clear(); self.replay_mr_corr_plot.addItem(self.replay_mr_corr_image)
        if result is None or np.asarray(result.correlated_map).size==0:
            self.replay_mr_corr_image.setImage(np.empty((0,0))); return
        arr=np.asarray(result.correlated_map,float)
        maxv=float(np.nanmax(arr)) if np.isfinite(arr).any() else 0.0
        self.replay_mr_corr_image.setImage(arr,autoLevels=False,levels=(0,max(maxv,1e-6)))
        h,w=arr.shape
        self.replay_mr_corr_image.setRect(QRectF(0,0,w,h))
        if result.loss_centroid_xy is not None:
            nx,ny=result.loss_centroid_xy
            x=(nx+1)*0.5*(w-1); y=(1-ny)*0.5*(h-1)
            self.replay_mr_corr_plot.plot([x],[y],pen=None,symbol="x",symbolSize=10,symbolPen=pg.mkPen("#f72585",width=2))
        self.replay_mr_corr_plot.setRange(xRange=(0,w),yRange=(0,h),padding=0.01)

    def _draw_replay_cavitation_map(self, result) -> None:
        if not hasattr(self, "replay_cavitation_map"):
            return
        self.replay_cavitation_map.clear()
        self.replay_cavitation_map.addItem(self.replay_cavitation_image)
        if result is None or np.asarray(result.likelihood_map).size == 0:
            self.replay_cavitation_image.setImage(np.empty((0,0)))
            return
        arr=np.asarray(result.likelihood_map,float)
        self.replay_cavitation_image.setImage(arr,autoLevels=False,levels=(0,1))
        self.replay_cavitation_image.setRect(QRectF(-1.05,-1.05,2.10,2.10))
        theta=np.linspace(0,2*np.pi,160)
        self.replay_cavitation_map.plot(np.cos(theta),np.sin(theta),pen=pg.mkPen("#aaaaaa",width=1))
        self.replay_cavitation_map.plot([0],[0],pen=None,symbol="+",symbolSize=11,symbolPen=pg.mkPen("#ffffff",width=2))
        pos=np.asarray(result.hydrophone_positions,float)
        show_disabled=bool(getattr(self,"show_disabled_rcv_action",None) and self.show_disabled_rcv_action.isChecked())
        for ch in range(min(8,len(pos))):
            if not show_disabled and not self._rcv_enabled_from_calibration(ch):
                continue
            dominant=(result.dominant_channel is not None and ch==result.dominant_channel)
            active=float(result.per_channel_scores[ch])>0.01
            brush="#f72585" if dominant else "#ffd166" if active else "#4cc9f0"
            self.replay_cavitation_map.plot([pos[ch,0]],[pos[ch,1]],pen=None,symbol="o",symbolSize=9 if dominant else 6,symbolBrush=brush)
        if result.centroid_xy is not None:
            self.replay_cavitation_map.plot([result.centroid_xy[0]],[result.centroid_xy[1]],pen=None,symbol="x",symbolSize=10,symbolPen=pg.mkPen("#06d6a0",width=2))

    def _update_default_cavitation_intelligence(self) -> None:
        if not hasattr(self, "replay_cavitation_status"):
            return
        replay=self.default_cpc_replay
        if replay is None or not replay.frames:
            self.default_cavitation_likelihood = None
            self.default_cavitation_mr_correlation = None
            self._ci_event_preview_result = None
            self.replay_cavitation_status.setText(self._tr("replay_cpc_unavailable"))
            self.replay_cavitation_detail.setText(self._tr("dominant_rcv_unavailable"))
            for label in self.replay_band_labels: label.setText(label.text().split(':')[0]+": --")
            self._draw_replay_cavitation_map(None)
            self._draw_replay_mr_correlation(None)
            self._update_cavitation_intelligence_page()
            return
        replay_time=self._index_to_seconds(self.frame_index,self.current.replay_frame_count) if self.current else 0.0
        cpc_index=self._synchronized_cpc_frame_index(replay_time)
        if cpc_index is None:
            self.default_cavitation_likelihood = None
            self._ci_event_preview_result = None
            self.replay_cavitation_status.setText(self._tr("no_sync_cpc", time=replay_time))
            self.replay_cavitation_detail.setText("Dominant RCV: -- | stale CPC frames are not reused")
            for band,label in enumerate(self.replay_band_labels): label.setText(f"B{band}: --")
            self._draw_replay_cavitation_map(None)
            corr=self._current_magnitude_correlation(None)
            self.default_cavitation_mr_correlation=corr
            self._draw_replay_mr_correlation(corr)
            self._update_cavitation_intelligence_page()
            return
        frame=replay.frames[cpc_index]
        event=self._nearest_observed_cavitation_event(float(getattr(frame,"acquisition_time_s",replay_time) or 0.0))
        try:
            result=self.cavitation_likelihood_service.estimate(replay,cpc_index,event)
        except Exception as exc:
            LOG.debug("Likelihood map unavailable: %s",exc); result=None
        self.default_cavitation_likelihood=result
        energies=np.asarray(getattr(frame,"vendor_band_energies",[]),float)
        dominant=result.dominant_channel if result is not None else None
        for band,label in enumerate(self.replay_band_labels):
            if energies.shape==(8,4) and dominant is not None:
                label.setText(f"B{band}: {energies[dominant,band]:.4g}")
            elif energies.shape==(8,4):
                enabled=[ch for ch in range(8) if self._rcv_enabled_from_calibration(ch)]
                values=energies[enabled,band] if enabled else energies[:,band]
                label.setText(f"B{band}: {np.nanmax(values):.4g}")
            else:
                label.setText(f"B{band}: --")
        if event is not None:
            state=f"OBSERVED {event.family} Rule {event.rule_index}"
            if getattr(event,"result",""):
                state += f" · {event.result}"
        else:
            state="CPC Band0–3 monitoring"
        timing="exact cycle" if getattr(replay,"snapshot_cycle_mapping_validated",False) else "snapshot timing"
        power_state = "post-power monitoring" if self._post_sonication_acoustic_period(replay_time) else "acoustic power active/window"
        measured_t = float(getattr(frame, "acquisition_time_s", replay_time) or replay_time)
        self.replay_cavitation_status.setText(f"{state} | FFT #{cpc_index+1} @ {measured_t:.3f} s | {timing} | {power_state}")
        loss,loss_text=self._current_magnitude_signal_loss()
        corr=self._current_magnitude_correlation(result)
        self.default_cavitation_mr_correlation=corr
        if result is not None and corr is not None:
            try:
                result=self.cavitation_likelihood_service.refine_with_mr(result,corr)
                self.default_cavitation_likelihood=result
                dominant=result.dominant_channel
            except Exception as exc:
                LOG.debug("Integrated cavitation-location fusion unavailable: %s",exc)
        dom_txt=f"RCV{dominant}" if dominant is not None else "--"
        contrib=""
        if result is not None:
            active=[f"RCV{i} {100*v:.0f}%" for i,v in enumerate(result.per_channel_scores) if v>0.05]
            contrib=" | "+", ".join(active) if active else ""
        corr_text=corr.summary if corr is not None else loss_text
        fusion_txt=""
        if result is not None and getattr(result,"fusion_confidence",None) is not None:
            fusion_txt=(f" | Integrated location score {float(result.fusion_confidence):.0f}/100"
                        f" · acoustic {float(getattr(result,'acoustic_weight',1.0))*100:.0f}%"
                        f" / MR {float(getattr(result,'mr_weight',0.0))*100:.0f}%")
        self.replay_cavitation_detail.setText(f"Dominant RCV: {dom_txt}{contrib} | MR {corr_text}{fusion_txt}")
        self._draw_replay_cavitation_map(result)
        self._draw_replay_mr_correlation(corr)
        self._update_cavitation_intelligence_page()

    def _update_cavitation_visualization(self):
        if not hasattr(self,'cavitation_plot') or not self.current or not self.package: return
        main_hz=self.current.main_frequency_hz or self.package.main_frequency_hz
        trend=self.cavitation_service.compute(self.spectrum_channels,self._selected_channels(),main_hz,max(1,self.current.replay_frame_count),self._index_to_seconds(max(0,self.current.replay_frame_count-1),self.current.replay_frame_count))
        self._cavitation_trend=trend
        if trend is None:
            for curve in (self.cavitation_sub_curve,self.cavitation_ultra_curve,self.cavitation_broad_curve,self.cavitation_total_curve): curve.setData([],[])
            self.cavitation_summary.setText('Spectrum-derived cavitation indicators are unavailable for this sonication.')
            return
        x=np.asarray(trend.time_s,float)
        self.cavitation_sub_curve.setData(x,trend.subharmonic_db,connect='finite'); self.cavitation_ultra_curve.setData(x,trend.ultraharmonic_db,connect='finite'); self.cavitation_broad_curve.setData(x,trend.broadband_db,connect='finite'); self.cavitation_total_curve.setData(x,trend.cavitation_index_db,connect='finite')
        current_s=self._index_to_seconds(self.frame_index,self.current.replay_frame_count)
        self.cavitation_cursor.setPos(current_s)
        i=max(0,min(self.frame_index,len(trend.cavitation_index_db)-1)); fmt=lambda v:'N/A' if not np.isfinite(v) else f'{v:.1f} dB'
        phase = "post-power measured background" if self._post_sonication_acoustic_period(current_s) else "acoustic-power window"
        self.cavitation_summary.setText(f"{phase} | Channels: {', '.join(trend.selected_channels)} | f0 {trend.main_frequency_hz/1e6:.3f} MHz | Sub {fmt(trend.subharmonic_db[i])} | Ultra {fmt(trend.ultraharmonic_db[i])} | Broadband {fmt(trend.broadband_db[i])} | Index {fmt(trend.cavitation_index_db[i])}")

    def set_frame(self, index: int, display_mode: str | None = None):
        """Synchronously decode and render one live replay frame.

        This restores the direct RC1 behavior that previously worked. The
        central image, thumbnails, temperature cursor, acoustic spectrum and
        cards are updated in one call. ReplayContext is only a state mirror.
        """
        if not self.current:
            return
        if display_mode is None:
            self._activate_replay_mode_for_navigation()
        else:
            self._main_image_mode = display_mode
        if self._main_image_mode in {"thermal", "anatomy"}:
            self._displayed_plane_override = None
        count = max(1, int(self.current.replay_frame_count))
        target = max(0, min(int(index), count - 1))
        try:
            data = self.replay.frame(self.current, target)
        except Exception as exc:
            self._inline_notice(f"Unable to decode frame: {exc}", error=True)
            return

        self.frame_index = int(data.replay_index)
        try:
            self.replay_context.select_frame(self.frame_index)
            snapshot = self.snapshot_provider.resolve(self.replay_context.selection)
        except Exception:
            snapshot = None
        seconds = self._index_to_seconds(self.frame_index, count)

        self.timeline.blockSignals(True)
        self.timeline.setRange(0, count - 1)
        self.timeline.setValue(self.frame_index)
        self.timeline.blockSignals(False)

        if self.current.temperature_frames:
            ti_source = self.replay.raw.normalize_index(self.frame_index, count, len(self.current.temperature_frames))
            ti = min(range(len(self._thermal_row_map)), key=lambda i: abs(self._thermal_row_map[i] - ti_source)) if self._thermal_row_map else -1
            self.thermal_frame_list.blockSignals(True)
            self.thermal_frame_list.setCurrentRow(ti)
            self.thermal_frame_list.blockSignals(False)
        if self.current.magnitude_frames:
            mi_source = self.replay.raw.normalize_index(self.frame_index, count, len(self.current.magnitude_frames))
            mi = min(range(len(self._anatomy_row_map)), key=lambda i: abs(self._anatomy_row_map[i] - mi_source)) if self._anatomy_row_map else -1
            self.anatomy_frame_list.blockSignals(True)
            self.anatomy_frame_list.setCurrentRow(mi)
            self.anatomy_frame_list.blockSignals(False)

        self.frame_label.setText(
            f"{self._main_image_mode.upper()} | MR acquisition: {seconds:.2f} sec | "
            f"Frame {self.frame_index + 1}/{count} | "
            f"MR {data.magnitude_index + 1 if data.magnitude_index is not None else '-'} | "
            f"Temp {data.temperature_index + 1 if data.temperature_index is not None else '-'}"
        )
        self.temperature_cursor.setPos(seconds)
        if not self.chart_state.temperature_user_zoomed:
            self._fit_temperature_trend(force=True)

        magnitude_levels = self._overlay_session_levels
        if magnitude_levels is None and data.magnitude is not None:
            finite_mag = np.asarray(data.magnitude, float)
            finite_mag = finite_mag[np.isfinite(finite_mag)]
            if finite_mag.size:
                low, high = np.percentile(finite_mag, [2.0, 98.5])
                if high <= low:
                    high = low + 1.0
                magnitude_levels = (float(low), float(high))

        hotspot = (data.hotspot_x, data.hotspot_y) if data.hotspot_x is not None else None
        hotspot_text = None
        if data.maximum_temperature is not None:
            hotspot_text = f"Max = {data.maximum_temperature:.1f} °C\nAvg = {data.mean_temperature:.1f} °C"
        investigation = self.temperature_display_mode.startswith("Δ")
        shown = data.temperature_delta if investigation else data.temperature
        levels = self._delta_levels(shown) if investigation else self._temperature_levels(shown)
        if investigation:
            lut = pg.colormap.get("CET-L4").getLookupTable(0, 1, 256)
        else:
            low, high = levels if levels is not None else (40.0, 60.0)
            lut = self._temperature_lut_with_red_threshold(low, high)

        if self._main_image_mode == "anatomy":
            shown = None
            self.overlay.set_roi(None, None)
            self.overlay.set_hover_temperature(None)
        else:
            self.overlay.set_roi(data.roi_center_x, data.roi_center_y, data.roi_radius, data.roi_width, data.roi_height)
            self.overlay.set_hover_temperature(shown)

        self.overlay.set_overlay(
            data.magnitude, shown, magnitude_levels, levels, lut,
            self.overlay_opacity.value() / 100.0,
            hotspot, hotspot_text, None, fit=self._fit_overlay_next,
        )
        self._fit_overlay_next = False
        if self._restore_overlay_session and self._overlay_session_view:
            self.overlay.set_view_range(self._overlay_session_view)
        if self._restore_overlay_session and self._overlay_session_levels:
            self.overlay.set_magnitude_levels(self._overlay_session_levels)
        self._restore_overlay_session = True
        self.baseline_label.setText(
            f"Source: {data.temperature_source}\nReference: {data.reference_temperature:.1f} °C\nROI: {data.roi_source}"
        )

        if snapshot is not None:
            spectrum_index, spectrum_count = self._update_replay_spectrum(snapshot)
        else:
            spectrum_index, spectrum_count = None, 0
        self._update_analysis_hydrophone()
        self._update_info_window(data, count, spectrum_index, spectrum_count)
        self._update_acoustic_cards(data)
        self._update_cursor_for_frame(data)
        self._apply_workstation_replay_behavior(data, count)
        self._update_orientation_alignment_labels()
        self._update_cavitation_visualization()
        self._update_default_cavitation_intelligence()
        self._refresh_chart_popups()
        self.sync_label.setText(
            f"Image {self.frame_index + 1}/{count} | "
            f"Temperature {data.temperature_index + 1 if data.temperature_index is not None else '-'} | "
            f"Spectrum {spectrum_index + 1 if spectrum_index is not None else '-'}/{spectrum_count or '-'} | "
            f"Phase: {self._workstation_phase}"
        )

    def _workstation_replay_toggled(self, checked: bool) -> None:
        self.workstation_replay_enabled = bool(checked)
        if self.current:
            self.set_frame(self.frame_index, display_mode=self._main_image_mode)

    def _workstation_phase_for_frame(self, data, count: int) -> str:
        """Derive a stable acquisition/heating/cooling phase for replay UI.

        The export does not always contain explicit workstation state markers,
        so the phase is inferred conservatively from measured power and the
        temperature trend.  It is display metadata only and never changes the
        decoded data.
        """
        index = int(getattr(data, "replay_index", self.frame_index) or 0)
        if index <= 0:
            return "MR acquisition"
        power = np.nan
        if getattr(self, "acoustic_control_trend", None) is not None:
            arr = np.asarray(self.acoustic_control_trend.power_percent, float)
            if arr.size:
                power = arr[min(index, arr.size - 1)]
        values = np.asarray(self.max_temperature_trend, float)
        current = values[min(index, values.size - 1)] if values.size else np.nan
        previous = values[min(max(index - 1, 0), values.size - 1)] if values.size else np.nan
        if np.isfinite(power) and power > 3.0:
            return "Sonication"
        if np.isfinite(current) and np.isfinite(previous):
            if current > previous + 0.15:
                return "Heating"
            if current < previous - 0.15:
                return "Cooling"
        if index >= max(0, count - 1):
            return "Complete"
        return "Post acquisition"

    def _apply_workstation_replay_behavior(self, data, count: int) -> None:
        """Mirror the time-progressive behavior seen in the reference video.

        * Temperature trends reveal samples up to the selected replay frame.
        * Power/Score keeps the complete native sonication curve visible; replay moves its cursor only.
        * Current Anatomy/Thermal thumbnails remain visible and auto-scroll.
        * Main image stays in live Anatomy/Thermal replay while navigating.
        * Status reports the current acquisition/heating/cooling phase.
        """
        self._workstation_phase = self._workstation_phase_for_frame(data, count)
        if not getattr(self, "workstation_replay_enabled", True):
            # Restore complete trends when progressive replay is disabled.
            tx = self._frame_time_axis(count)
            self.max_temperature_curve.setData(tx, np.asarray(self.max_temperature_trend, float), connect="finite")
            self.mean_temperature_curve.setData(tx, np.asarray(self.mean_temperature_trend, float), connect="finite")
            current_s = self._index_to_seconds(max(count - 1, 0), count)
            self._update_acoustic_replay_view(current_s, progressive=False)
            return

        end = min(max(0, self.frame_index) + 1, count)
        tx = self._frame_time_axis(count)[:end]
        self.max_temperature_curve.setData(tx, np.asarray(self.max_temperature_trend, float)[:end], connect="finite")
        self.mean_temperature_curve.setData(tx, np.asarray(self.mean_temperature_trend, float)[:end], connect="finite")
        if self.cursor_temperature_trend:
            self.cursor_temperature_curve.setData(tx, np.asarray(self.cursor_temperature_trend, float)[:end], connect="finite")

        current_s = self._index_to_seconds(self.frame_index, count)
        self._update_acoustic_replay_view(current_s, progressive=True)

        for strip in (getattr(self, "anatomy_frame_list", None), getattr(self, "thermal_frame_list", None)):
            if strip is None or strip.count() <= 0:
                continue
            row = strip.currentRow()
            if row >= 0:
                item = strip.item(row)
                if item is not None:
                    strip.scrollToItem(item, QListWidget.ScrollHint.PositionAtCenter)

        self.statusBar().showMessage(
            f"Replay {self.frame_index + 1}/{count} · {self._workstation_phase} · "
            f"{self._index_to_seconds(self.frame_index, count):.1f} sec"
        )

    def _post_sonication_acoustic_period(self, replay_seconds: float) -> bool:
        """True after measured acoustic *power/control* delivery has ended.

        This must not be used to disable CPC/RCV measurement: hydrophone acquisition
        can continue during the later MR frames and must be displayed at its real time.
        """
        trend = getattr(self, "acoustic_control_trend", None)
        end_s = getattr(trend, "acoustic_end_s", None) if trend is not None else None
        return end_s is not None and np.isfinite(end_s) and float(replay_seconds) > float(end_s) + 0.05

    def _draw_post_sonication_spectrum_state(self, replay_seconds: float) -> None:
        self.spectrum_plot.clear()
        self.spectrum_plot.showGrid(x=True, y=True, alpha=.22)
        self.spectrum_plot.setLabel("left", "Relative Amplitude")
        self.spectrum_plot.setLabel("bottom", "Frequency", units="MHz")
        self.spectrum_plot.setXRange(0.20, 0.80, padding=0)
        self.spectrum_plot.setYRange(0.0, 4.0, padding=0)
        main_frequency = ((self.current.main_frequency_hz if self.current else None) or
                          (self.package.main_frequency_hz if self.package else None))
        self._add_spectrum_reference_lines(self.spectrum_plot, mhz=True)
        note = pg.TextItem(
            text=f"Post-sonication MR · acoustic control inactive · {replay_seconds:.2f} s\nCavitation evaluation OFF (MR-gradient noise excluded)",
            color="#dddddd", anchor=(0.5, 0.5), fill=pg.mkBrush(20,20,20,175),
        )
        note.setPos(0.50, 2.0); note.setZValue(100); self.spectrum_plot.addItem(note)
        self.spectrum_hover_series = []
        self._spectrum_frame = None
        self._spectrum_status = "Post-sonication MR — no stale acoustic frame mapped"
        self.current_spectrum_label.setText("Spectrum: post-sonication MR · cavitation evaluation OFF")

    def _update_replay_spectrum(self, snapshot: ReplayFrameSnapshot):
        replay_count = snapshot.selection.frame_count
        selected = self._selected_channels()
        seconds = snapshot.elapsed_seconds
        main_frequency = ((self.current.main_frequency_hz if self.current else None) or
                          (self.package.main_frequency_hz if self.package else None))
        saved_x = self.chart_state.x_ranges.get("spectrum")
        saved_y = self.chart_state.y_ranges.get("spectrum")
        result = self.current_spectrum_renderer.render(
            self.spectrum_plot, self.spectrum_channels, selected,
            self.frame_index, replay_count, self._channel_colors,
            main_frequency, self._map_replay_to_data, seconds,
            mode=self.chart_state.spectrum_mode,
            average_window=self.chart_state.spectrum_average_window,
            frame_indices=self._spectrum_indices_at_time(seconds, dict(snapshot.spectrum_indices)),
        )
        self.spectrum_plot.addItem(self.spectrum_hover_text)
        if saved_x is not None:
            self.spectrum_plot.setXRange(*saved_x, padding=0)
        if saved_y is not None:
            self.spectrum_plot.setYRange(*saved_y, padding=0)
        self.spectrum_hover_series = result.series
        first_index = None
        first_count = 0
        statuses = []
        self._spectrum_frame = None
        for channel in selected:
            frames = self.spectrum_channels.get(channel, [])
            if not frames or channel not in result.frame_indices:
                continue
            idx = result.frame_indices[channel]
            statuses.append(f"{channel}:{idx + 1}/{len(frames)}")
            if first_index is None:
                first_index, first_count = idx, len(frames)
                self._spectrum_frame = frames[idx]
        self._spectrum_status = "; ".join(statuses) if statuses else f"No synchronized spectrum at {seconds:.3f} s"
        metric_text = ""
        if result.metrics:
            metric_text = (f" | Sub {result.metrics.get('subharmonic',0.0):.3f}"
                           f" Ultra {result.metrics.get('ultraharmonic',0.0):.3f}"
                           f" BB {result.metrics.get('broadband',0.0):.3f}")
        calibration_text = "CAL ON" if self.hydrophone_calibration is not None and self.hydrophone_calibration.available else "CAL OFF"
        source_text = "CPC" if self.cpc_enabled else "SpectrumMsg"
        axis_text = ""
        if self._spectrum_frame is not None:
            axis_source = getattr(self._spectrum_frame, "frequency_axis_source", "Unknown")
            spacing = getattr(self._spectrum_frame, "frequency_spacing_hz", None)
            if spacing is None:
                freq = np.asarray(getattr(self._spectrum_frame, "frequency", []), float)
                spacing = float(np.median(np.diff(freq))) if freq.size > 1 else None
            if axis_source != "Unknown" or spacing is not None:
                axis_text = f" | Axis: {axis_source}" + (f" Δf={spacing:.3f} Hz" if spacing is not None else "")
        self.current_spectrum_label.setText(f"Spectrum [{source_text} / {calibration_text}]: {self._spectrum_status}{metric_text}{axis_text}")
        return first_index, first_count

    def _update_analysis_hydrophone(self):
        if not hasattr(self, "analysis_spectrum_plot"):
            return
        self.analysis_spectrum_plot.clear()
        selected = self._selected_channels()
        replay_count = self.current.replay_frame_count if self.current else 1
        colors = ["#00bfff", "#ffcc00", "#ff66cc", "#66ff66", "#ff8844", "#cccccc"]
        stacked = self.hydro_arrangement.currentText() == "Stacked"
        for channel_index, channel in enumerate(selected):
            frames = self.spectrum_channels.get(channel, [])
            if not frames:
                continue
            spectrum_index = self._map_replay_to_data(self.frame_index, replay_count, len(frames))
            frame = frames[spectrum_index]
            x = np.asarray(frame.frequency, float) / 1000.0
            y = np.asarray(frame.amplitude, float)
            if stacked and y.size:
                span = max(1.0, float(np.nanmax(y) - np.nanmin(y)))
                y = y - channel_index * span * 1.2
            self.analysis_spectrum_plot.plot(x, y, pen=pg.mkPen(colors[channel_index % len(colors)], width=1.5))
        self._add_spectrum_reference_lines(self.analysis_spectrum_plot, mhz=False)
        self._update_waterfall()

    def _update_waterfall(self):
        selected = self._selected_channels()
        blocks = []
        max_columns = 0
        x_max = 1.0
        current_row = 0
        row_offset = 0
        replay_count = self.current.replay_frame_count if self.current else 1
        for channel in selected:
            frames = self.spectrum_channels.get(channel, [])
            rows = []
            for frame in frames:
                amplitude = np.asarray(frame.amplitude, float)
                if amplitude.size:
                    rows.append(amplitude)
                    max_columns = max(max_columns, amplitude.size)
                    if frame.frequency:
                        x_max = max(x_max, float(frame.frequency[-1]) / 1000.0)
            if rows:
                if not blocks:
                    current_row = row_offset + self._map_replay_to_data(self.frame_index, replay_count, len(rows))
                blocks.append(rows)
                row_offset += len(rows) + 2
        if not blocks or max_columns == 0:
            self.waterfall_image.setImage(np.empty((0, 0)))
            return
        bands = []
        for rows in blocks:
            padded = np.full((len(rows), max_columns), np.nan)
            for row_index, row in enumerate(rows):
                padded[row_index, : len(row)] = row
            bands.append(padded)
            bands.append(np.full((2, max_columns), np.nan))
        image = np.vstack(bands[:-1])
        finite = image[np.isfinite(image)]
        if finite.size:
            low, high = np.percentile(finite, [2, 98])
            self.waterfall_image.setImage(image, autoLevels=False, levels=(float(low), float(high)))
        else:
            self.waterfall_image.setImage(image)
        self.waterfall_image.setRect(QRectF(0, 0, x_max, image.shape[0]))
        self.waterfall_plot.setYRange(0, image.shape[0], padding=0)
        self.waterfall_cursor.setPos(current_row)

    def _threshold_changed(self, value: int):
        self.threshold_value.setText(f"Red starts at {value} °C")
        self.set_frame(self.frame_index)

    def _overlay_cursor_moved(self, x: float, y: float):
        self.cursor_x, self.cursor_y = x, y
        self._rebuild_cursor_temperature_trend()
        self.set_frame(self.frame_index)

    def _overlay_measurement_changed(self, result: dict):
        if not result:
            self.measurement_summary_label.setText("ROI is hidden")
            return
        source = str(result.get("source", "Image"))
        unit = "°C" if source.lower().startswith("temperature") else "a.u."
        self.measurement_summary_label.setText(
            f"Source      {source}\n"
            f"Diameter    {float(result.get('diameter_px', 0.0)):.1f} px\n"
            f"Pixels      {int(result.get('pixels', 0))}\n"
            f"Mean        {float(result.get('mean', 0.0)):.2f} {unit}\n"
            f"Maximum     {float(result.get('max', 0.0)):.2f} {unit}"
        )

    def _clear_overlay_measurement(self):
        self.overlay.hide_measure_roi()
        self.measurement_summary_label.setText("ROI is hidden")

    def _rebuild_cursor_temperature_trend(self):
        self.cursor_temperature_trend = []
        if not self.current or self.cursor_x is None or self.cursor_y is None:
            self.cursor_temperature_curve.setData([], [])
            return
        for i in range(self.current.replay_frame_count):
            try:
                data = self.replay.frame(self.current, i)
                arr = data.temperature
                if arr is None:
                    self.cursor_temperature_trend.append(np.nan); continue
                xi = int(np.clip(round(self.cursor_x), 0, arr.shape[1]-1))
                yi = int(np.clip(round(self.cursor_y), 0, arr.shape[0]-1))
                self.cursor_temperature_trend.append(float(arr[yi, xi]))
            except Exception:
                self.cursor_temperature_trend.append(np.nan)
        self.cursor_temperature_curve.setData(self._frame_time_axis(len(self.cursor_temperature_trend)), np.asarray(self.cursor_temperature_trend,float))

    def _update_cursor_for_frame(self, data):
        arr = data.temperature
        if arr is None:
            self.cursor_temperature_label.setText("Temperature   --\nX             --\nY             --")
            return
        if self.cursor_x is None or self.cursor_y is None:
            self.cursor_temperature_label.setText("Click or drag the small cyan target to inspect temperature.")
            return
        xi = int(np.clip(round(self.cursor_x),0,arr.shape[1]-1)); yi = int(np.clip(round(self.cursor_y),0,arr.shape[0]-1))
        value=float(arr[yi,xi])
        self.overlay.set_cursor(self.cursor_x,self.cursor_y,f"T {value:.1f} °C\nX {xi}  Y {yi}")
        self.cursor_temperature_label.setText(f"Temperature   {value:.1f} °C\nX             {xi} px\nY             {yi} px")

    def _show_info_window(self):
        if self.info_window.isVisible(): return
        self.info_window.show(); self.info_window.raise_(); self.info_window.activateWindow()

    def _show_mr_window(self):
        if self.mr_window.isVisible(): return
        self.mr_window.show(); self.mr_window.raise_(); self.mr_window.activateWindow()

    def _show_scan_window(self):
        if self.scan_window.isVisible(): return
        self.scan_window.show(); self.scan_window.raise_(); self.scan_window.activateWindow()

    def _show_xd_window(self):
        if self.current is not None and self.package is not None:
            self.xd_window.set_data(self.skull_measures_service.find_and_read(
                self.current.folder, self.sonication_index + 1, self.package.workspace
            ))
        if self.xd_window.isVisible():
            self.xd_window.raise_(); self.xd_window.activateWindow(); return
        self.xd_window.show(); self.xd_window.raise_(); self.xd_window.activateWindow()

    def _update_sonication_metadata(self):
        if not self.current or not self.package: return
        self.current_metadata=self.metadata_service.read(self.current,self.package,self.sonication_index+1)
        for key,label in self.summary_value_labels.items():
            if key in ("Displayed Plane", "Orientation Status"):
                continue
            label.setText(self.current_metadata.summary.get(key,"Unavailable"))
        self._update_orientation_alignment_labels()
        mr_rows = list(self.current_metadata.mr or [])
        scan_rows = list(self.current_metadata.scan or [])
        if not mr_rows:
            mr_rows = [
                ("Sonication", self.current.name),
                ("Magnitude RAW files", len(self.current.magnitude_frames)),
                ("Temperature RAW files", len(self.current.temperature_frames)),
                ("Main frequency", f"{((self.current.main_frequency_hz or self.package.main_frequency_hz or 0)/1_000_000):.3f} MHz"),
                ("Source folder", str(self.current.folder)),
            ]
        if not scan_rows:
            scan_rows = [
                ("Replay frames", self.current.replay_frame_count),
                ("Magnitude frames", len(self.current.magnitude_frames)),
                ("Temperature frames", len(self.current.temperature_frames)),
                ("Spectrum files", len(self.current.spectrum_files)),
                ("ACT files", len(self.current.act_files)),
            ]
        self.mr_window.update_rows(mr_rows)
        self.scan_window.update_rows(scan_rows)
        self.xd_window.set_data(self.skull_measures_service.find_and_read(self.current.folder, self.sonication_index + 1, self.package.workspace))

    def _update_info_window(self, data, count, spectrum_index, spectrum_count):
        frequency = ((self.current.main_frequency_hz if self.current else None) or (self.package.main_frequency_hz if self.package else 0.0)) / 1_000_000.0
        summary = self.current_metadata.summary if self.current_metadata else {}
        rows=[
            ("Sonication No.", f"{self.sonication_index+1} / {len(self.package.sonications) if self.package else '-'}"),
            ("Orientation", summary.get("Orientation", "Unavailable")),
            ("Displayed Plane", self._displayed_plane()),
            ("Orientation Status", self.summary_value_labels["Orientation Status"].text() if "Orientation Status" in self.summary_value_labels else "Unavailable"),
            ("Frequency Direction", summary.get("Frequency Dir", "Unavailable")),
            ("Target Power", summary.get("Target Power", "Unavailable")),
            ("Actual Power", summary.get("Actual Power", "Unavailable")),
            ("Target Duration", summary.get("Target Duration", "Unavailable")),
            ("Actual Duration", summary.get("Actual Duration", "Unavailable")),
            ("Target Energy", summary.get("Target Energy", "Unavailable")),
            ("Actual Energy", summary.get("Actual Energy", "Unavailable")),
            ("Hotspot Check", summary.get("Hotspot Check", "Unavailable")),
            ("Name", self.current.name if self.current else "-"),
            ("Replay Completeness", f"{self.current.completeness_status} ({self.current.completeness_score}%)" if self.current else "-"),
            ("Replay Available", "Yes — best-effort reconstruction" if self.current and self.current.replay_frame_count > 0 else "No"),
            ("Missing for Full Replay", "; ".join(self.current.missing_required) if self.current and self.current.missing_required else "None"),
            ("Missing Optional", "; ".join(self.current.missing_optional) if self.current and self.current.missing_optional else "None"),
            ("Degraded / Limited", "; ".join(self.current.degraded_items) if self.current and self.current.degraded_items else "None"),
            ("Workflow", getattr(self.package, "workflow_mode", "Unknown") if self.package else "Unknown"),
            ("Thermometry", getattr(self.current, "thermometry_mode", "Unknown") if self.current else "Unknown"),
            ("Frequency", summary.get("Frequency", "Unavailable")),
            ("Replay Frame", f"{self.frame_index+1}/{count}"),
            ("Temperature RAW", data.temperature_index+1 if data.temperature_index is not None else "-"),
            ("SpectrumMsg", f"{spectrum_index+1 if spectrum_index is not None else '-'}/{spectrum_count or '-'}"),
            ("Temperature Source", data.temperature_source),
            ("Reference Temperature", f"{data.reference_temperature:.1f} °C"),
            ("ROI Source", data.roi_source),
            ("Max Temperature (ROI)", f"{data.maximum_temperature:.1f} °C" if data.maximum_temperature is not None else "-"),
            ("Average Temperature (ROI)", f"{data.mean_temperature:.1f} °C" if data.mean_temperature is not None else "-"),
            ("Loaded Folder", str(self.package.source_path) if self.package and hasattr(self.package,'source_path') else "-"),
        ]
        self.info_window.update_rows(rows)

    def _update_acoustic_cards(self, data):
        trend = getattr(self, "acoustic_control_trend", None)
        if trend is not None:
            tx=np.asarray(trend.plot_time_s if getattr(trend,"plot_time_s",None) is not None else trend.time_s,float)
            py=np.asarray(trend.plot_power_percent if getattr(trend,"plot_power_percent",None) is not None else trend.power_percent,float)
            sy=np.asarray(trend.plot_score_percent if getattr(trend,"plot_score_percent",None) is not None else trend.score_percent,float)
            self.acoustic_power_curve.setData(tx, py, connect="finite")
            self.acoustic_score_curve.setData(tx, sy, connect="finite")
        self.acoustic_control_cursor.setPos(self._index_to_seconds(self.frame_index,self.current.replay_frame_count) if self.current else 0)
        if trend is None or self.frame_index >= len(trend.power_percent):
            self.acoustic_power_value.setText("Unavailable")
            self.acoustic_score_value.setText("Unavailable")
            self.acoustic_cavitation_value.setText("Unavailable")
            self.acoustic_power_text.setText("Power: --")
            self.acoustic_score_text.setText("Score: --")
            return
        power = trend.power_percent[self.frame_index]
        score = trend.score_percent[self.frame_index]
        energy = trend.energy[self.frame_index]
        limit = trend.harmless_limit[self.frame_index]
        power_text = f"{power:.1f} %" if np.isfinite(power) else "--"
        score_text = f"{score:.1f} %" if np.isfinite(score) else "--"
        self.acoustic_power_value.setText(power_text)
        self.acoustic_score_value.setText(score_text)
        self.acoustic_power_text.setText(f"Power: {power_text}")
        self.acoustic_score_text.setText(f"Score: {score_text}")
        x_max = self._index_to_seconds(max(0, self.current.replay_frame_count - 1), self.current.replay_frame_count) if self.current else 0.0
        self.acoustic_power_text.setPos(x_max, 106.0)
        self.acoustic_score_text.setPos(x_max, 88.0)
        if np.isfinite(energy) and np.isfinite(limit):
            self.acoustic_cavitation_value.setText(f"{energy:.5f} / {limit:.5f}")
        else:
            self.acoustic_cavitation_value.setText("Unavailable")

    def _update_replay_waterfall(self, replay_count: int):
        """Render the true all-bin Time × Frequency spectrogram.

        Coloured overlay lines are selected channels' current-frame FFT curves,
        not peak-frequency or ridge histories. The popup uses this same renderer.
        """
        selected = self._selected_channels()
        source = "Sonication SpectrumMsg"
        result = self.relative_spectrum_renderer.render(
            self.waterfall_replay_plot, self.spectrum_channels, selected,
            self.frame_index, replay_count, self._channel_colors,
            (self.current.main_frequency_hz if self.current else None) or
            (self.package.main_frequency_hz if self.package else None),
            f"Relative Acoustic Spectrum · {source} · {', '.join(selected)}",
        )
        self.waterfall_replay_image = result.image_item

    # ------------------------------------------------------------- Helpers
    def _load_spectrum_channels(self):
        channels = {f"CH{i}": [] for i in range(8)}
        configured = self.sonication_channel_service.read(self.current.folder) if self.current else None
        configured_index = configured.channel if configured and configured.channel is not None else 0
        self._active_spectrum_channel = f"CH{configured_index}"

        son_frames = [] if self.cpc_enabled else self.spectrum_provider.load(list(self.current.spectrum_files), source_kind="Sonication")
        for frame in son_frames:
            explicit = self._channel_name(Path(frame.source), default=None)
            channel = explicit if explicit is not None else self._active_spectrum_channel
            frame.channel = int(channel[2:]); channels[channel].append(frame)

        # CPC mode is a real source switch.  It uses the validated independent
        # 8CH decoder and maps only the CPC file belonging to this sonication.
        if self.cpc_enabled and self.package is not None and self.current is not None:
            replay = self.hydrophone_replay_service.build(
                self.package.cpc_spectrum_files, self.sonication_index, len(self.package.sonications)
            )
            for frame in replay.frames:
                frequency = np.asarray(frame.frequency_hz, dtype=float)
                for channel_index, amplitude in enumerate(frame.channels[:8]):
                    calibrated = np.asarray(amplitude, dtype=float)
                    channels[f"CH{channel_index}"].append(SpectrumFrame(
                        index=frame.index,
                        frequency=[float(v) for v in frequency],
                        amplitude=[float(v) for v in calibrated],
                        timestamp_seconds=(float(frame.acquisition_time_s) if getattr(frame, "acquisition_time_s", None) is not None else frame.index * replay.frame_interval_s),
                        confidence=1.0,
                        source=str(replay.source_fft or "CPC FFT"),
                        channel=channel_index,
                        source_kind="CPCFiles mapped",
                        frequency_axis_source=replay.frequency_axis_source,
                        frequency_start_hz=replay.frequency_start_hz,
                        frequency_spacing_hz=replay.frequency_spacing_hz,
                        frequency_end_hz=replay.frequency_end_hz,
                    ))
            if replay.frames:
                son_frames = []

        self.spectrum_channels = channels
        self._rebuild_channel_controls()

    def _rcv_enabled_from_calibration(self, ch: int) -> bool:
        calibration=getattr(self,"hydrophone_calibration",None)
        values=getattr(calibration,"is_enabled",None) if calibration is not None else None
        if values is None:
            replay=getattr(self,"hydrophone_replay",None) or getattr(self,"cpc_replay",None)
            values=getattr(replay,"receiver_enabled",(True,)*8) if replay is not None else (True,)*8
        return bool(values[ch]) if 0 <= int(ch) < len(values) else True

    def _rebuild_channel_controls(self):
        previous = set(self.chart_state.selected_channels)
        for action in self.channel_actions.values():
            self.channel_menu.removeAction(action); action.deleteLater()
        self.channel_actions.clear()
        if not self.chart_state.user_selected_channels:
            previous = {self._active_spectrum_channel}
            self.chart_state.selected_channels = set(previous)
        show_disabled=bool(getattr(self,"show_disabled_rcv_action",None) and self.show_disabled_rcv_action.isChecked())
        for name in [f"CH{i}" for i in range(8)]:
            ch=int(name[2:]); enabled=self._rcv_enabled_from_calibration(ch)
            if not enabled and not show_disabled:
                previous.discard(name); continue
            action = QAction(name + (" (disabled)" if not enabled else ""), self.channel_menu)
            action.setData(name)
            action.setCheckable(True); action.setChecked(name in previous)
            action.toggled.connect(self._channel_selection_changed)
            self.channel_actions[name] = action; self.channel_menu.addAction(action)
        # R0116a: the visible action set is the source of truth. Do not leave
        # calibration-disabled channels in chart_state after the menu hides them.
        visible_names=set(self.channel_actions)
        previous=set(previous) & visible_names
        self.chart_state.selected_channels=set(previous)
        self.all_channels_action.blockSignals(True)
        self.all_channels_action.setChecked(bool(visible_names) and previous == visible_names)
        self.all_channels_action.blockSignals(False)
        self._update_channel_button_text()

    def _main_disabled_rcv_visibility_changed(self, _checked=False):
        """Rebuild all main-window RCV selectors from calibration.ini IsEnabled."""
        self._rebuild_channel_controls()
        if self.current is not None:
            self.set_frame(self.frame_index)
        self._update_default_cavitation_intelligence()

    def _cpc_toggled(self, checked: bool):
        self.cpc_enabled = bool(checked); self.chart_state.cpc_enabled = self.cpc_enabled
        self.cpc_button.setText("CPC ON" if checked else "CPC OFF")
        if self.current is not None:
            self._load_spectrum_channels(); self.set_frame(self.frame_index)
        count = len(self.package.cpc_spectrum_files) if self.package is not None else 0
        self.statusBar().showMessage(f"CPCFiles {'enabled' if checked else 'disabled'} ({count} candidate DMP file(s))")

    def _toggle_all_channels(self, checked: bool):
        self.chart_state.user_selected_channels = True
        for action in self.channel_actions.values():
            action.blockSignals(True); action.setChecked(checked); action.blockSignals(False)
        self.chart_state.selected_channels = set(self.channel_actions) if checked else set()
        self._update_channel_button_text(); self.set_frame(self.frame_index)

    def _channel_selection_changed(self):
        self.chart_state.user_selected_channels = True
        selected={name for name,action in self.channel_actions.items() if action.isChecked()}
        self.chart_state.selected_channels=set(selected)
        self.all_channels_action.blockSignals(True)
        self.all_channels_action.setChecked(len(selected)==len(self.channel_actions) and bool(selected))
        self.all_channels_action.blockSignals(False)
        self._update_channel_button_text(); self.set_frame(self.frame_index)

    def _update_channel_button_text(self):
        selected = [name for name, action in self.channel_actions.items() if action.isChecked()]
        if selected and len(selected) == len(self.channel_actions): self.channel_button.setText("CH: All")
        elif len(selected) == 1: self.channel_button.setText(f"CH: {selected[0]}")
        elif selected: self.channel_button.setText(f"CH: {len(selected)}")
        else: self.channel_button.setText("CH: None")

    def _selected_channels(self):
        selected=[name for name,action in self.channel_actions.items() if action.isChecked()]
        if selected:
            return selected
        enabled=[name for name in self.channel_actions if self._rcv_enabled_from_calibration(int(name[2:]))]
        if enabled:
            return [enabled[0]]
        return []

    def _hydro_layout_changed(self):
        mode = self.hydro_view.currentText()
        self.analysis_spectrum_plot.setVisible(mode in ("Both", "Spectrum"))
        self.waterfall_plot.setVisible(mode in ("Both", "Waterfall"))
        if mode == "Spectrum":
            self.hydro_splitter.setSizes([1000, 0])
        elif mode == "Waterfall":
            self.hydro_splitter.setSizes([0, 1000])
        else:
            self.hydro_splitter.setSizes([600, 600])
        self._update_analysis_hydrophone()

    def _update_parameter_table(self, data, count: int, spectrum_index, spectrum_count):
        frequency_mhz = ((self.current.main_frequency_hz if self.current else None) or self.package.main_frequency_hz) / 1_000_000.0
        rows = [
            ("Energy", "From ACT when available", "Sonication", self.current.name),
            ("Power", "From ACT when available", "Replay Frame", f"{self.frame_index + 1}/{count}"),
            ("Duration", f"{self._index_to_seconds(count - 1, count):.1f} sec", "Temperature RAW", f"{data.temperature_index + 1 if data.temperature_index is not None else '-'}"),
            ("Frequency", f"{frequency_mhz:.3f} MHz", "SpectrumMsg", f"{spectrum_index + 1 if spectrum_index is not None else '-'}/{spectrum_count or '-'}"),
            ("Temperature Source", data.temperature_source, "Max Temperature (ROI)", f"{data.maximum_temperature:.1f} °C" if data.maximum_temperature is not None else "-"),
            ("Reference Temperature", f"{data.reference_temperature:.1f} °C", "Average Temperature (ROI)", f"{data.mean_temperature:.1f} °C" if data.mean_temperature is not None else "-"),
            ("ROI Source", data.roi_source, "Max ΔTemperature", f"{data.maximum_delta_temperature:.1f} °C" if data.maximum_delta_temperature is not None else "-"),
        ]
        self.parameter_table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            for column_index, value in enumerate(row):
                self.parameter_table.setItem(row_index, column_index, QTableWidgetItem(str(value)))

    def _add_spectrum_reference_lines(self, plot, mhz: bool):
        if not self.package:
            return
        divisor = 1_000_000.0 if mhz else 1000.0
        main = self.package.main_frequency_hz / divisor
        for frequency, label in ((main / 2, "Sub"), (main, "Main"), (main * 2, "2nd"), (main * 3, "3rd")):
            plot.addItem(pg.InfiniteLine(pos=frequency, angle=90, movable=False, label=label))

    def _current_temperature_range(self):
        levels=self._temperature_levels(None)
        return levels if levels is not None else (40.0,60.0)

    def _temperature_range_changed(self, _index):
        lo,hi=self._current_temperature_range()
        self.temperature_plot.setYRange(lo,hi,padding=0)
        self.settings.setValue("temperature_range", self.range_combo.currentText())
        self.set_frame(self.frame_index)

    def _capture_overlay_state_debounced(self):
        if hasattr(self,"_overlay_save_timer"):
            self._overlay_save_timer.start(120)

    def _save_overlay_state(self):
        if not hasattr(self,"overlay"):
            return
        try:
            view=self.overlay.view_range()
        except Exception:
            return
        if self._main_image_mode.startswith("preplanning_") or self._main_image_mode.startswith("planning_mr_"):
            self._planning_overlay_view=view
        elif self._restore_overlay_session:
            self._overlay_session_view=view

    def _capture_overlay_levels(self, low, high):
        if self._restore_overlay_session:
            self._overlay_session_levels = (float(low), float(high))

    @staticmethod
    def _amplitude_db(values):
        amplitude=np.abs(np.nan_to_num(np.asarray(values,float),nan=0.0,posinf=0.0,neginf=0.0))
        if amplitude.size == 0:
            return amplitude
        reference=max(float(np.nanmax(amplitude)),1e-30)
        return np.clip(20.0*np.log10(np.maximum(amplitude,reference*1e-5)/reference),-100.0,0.0)

    @staticmethod
    def _relative_spectrum(values):
        """Scale one spectrum onto the workstation-like 0..4 relative axis."""
        amplitude = np.abs(np.nan_to_num(np.asarray(values, float), nan=0.0, posinf=0.0, neginf=0.0))
        if amplitude.size == 0:
            return amplitude
        baseline = float(np.percentile(amplitude, 10))
        signal = np.maximum(amplitude - baseline, 0.0)
        reference = float(np.percentile(signal, 99.5))
        if not np.isfinite(reference) or reference <= 1e-30:
            reference = max(float(np.nanmax(signal)), 1e-30)
        normalized = signal / reference
        # Keep quiet frames slightly above zero so the noise floor is visible,
        # while cavitation peaks retain enough headroom to stand out clearly.
        return np.clip(0.08 + normalized * 7.2, 0.0, 8.0)

    def _temperature_lut_with_red_threshold(self, low: float, high: float):
        """Keep all temperature colors visible and move the red transition only."""
        low, high = float(low), float(high)
        if high <= low:
            high = low + 1.0
        red = float(np.clip(self.threshold_slider.value(), low, high))
        split = float(np.clip((red - low) / (high - low), 0.02, 0.98))
        positions = np.asarray([0.0, max(0.0, split * 0.55), max(0.0, split * 0.85), split, 1.0], float)
        positions = np.maximum.accumulate(positions)
        colors = np.asarray([
            (0, 0, 0, 0),
            (255, 235, 45, 180),
            (255, 145, 20, 215),
            (255, 0, 0, 240),
            (255, 0, 0, 255),
        ], dtype=np.ubyte)
        cmap = pg.ColorMap(positions, colors)
        return cmap.getLookupTable(0.0, 1.0, 256)

    def _temperature_mode_changed(self, text: str):
        self.temperature_display_mode = text
        self.range_combo.setEnabled(not text.startswith("Δ"))
        self.threshold_slider.setEnabled(not text.startswith("Δ"))
        self.set_frame(self.frame_index)

    def _temperature_levels(self, temperature):
        index = self.range_combo.currentIndex()
        if index == 0:
            return 40.0, 60.0
        if index == 1:
            return 35.0, 60.0
        if index == 2:
            return 30.0, 90.0
        if index == 3:
            return 0.0, 60.0
        finite = temperature[np.isfinite(temperature)] if temperature is not None else np.array([])
        if not finite.size:
            return None
        lo, hi = np.percentile(finite, [1, 99.5])
        return float(lo), max(float(lo) + 1.0, float(hi))

    def _delta_levels(self, delta):
        finite = delta[np.isfinite(delta)] if delta is not None else np.array([])
        return (0.0, max(1.0, float(np.percentile(finite, 99)))) if finite.size else None

    @staticmethod
    def _channel_name(path: Path, default: str | None = "CH0") -> str | None:
        text = f"{path.parent.name}_{path.stem}"
        for pattern in (r"(?:^|[_\- ])(?:CH|HP)[_\- ]?(\d+)", r"hydrophone[_\- ]?(\d+)"):
            match = re.search(pattern, text, re.I)
            if match:
                return f"CH{int(match.group(1))}"
        return default

    @staticmethod
    def _map_replay_to_data(index: int, replay_count: int, data_count: int) -> int:
        """Map one replay position to another stream with endpoint-safe ratio.

        This is the explicit fallback when timestamps are absent. It guarantees
        frame movement changes Spectrum/Waterfall position instead of leaving a
        static first record.
        """
        if data_count <= 1 or replay_count <= 1:
            return 0
        ratio = index / float(replay_count - 1)
        return max(0, min(data_count - 1, int(round(ratio * (data_count - 1)))))

    @staticmethod
    def _map_data_to_replay(index: int, data_count: int, replay_count: int) -> int:
        """Inverse endpoint-safe mapping used by thumbnail selection."""
        if replay_count <= 1 or data_count <= 1:
            return 0
        ratio = max(0, min(data_count - 1, int(index))) / float(data_count - 1)
        return max(0, min(replay_count - 1, int(round(ratio * (replay_count - 1)))))


    def _index_to_seconds(self, index: int, count: int) -> float:
        if count <= 1:
            return 0.0
        duration = float(getattr(self, "current_timeline_duration_s", 0.0) or 0.0)
        if duration <= 0:
            duration = float(count - 1)
        ratio = max(0.0, min(1.0, float(index) / float(count - 1)))
        return ratio * duration

    def _replay_duration_s(self) -> float:
        """Return the active replay duration without assuming metadata exists."""
        count = int(getattr(self.current, "replay_frame_count", 0) or 0) if self.current else 0
        duration = float(getattr(self, "current_timeline_duration_s", 0.0) or 0.0)
        if duration > 0.0:
            return duration
        return float(max(0, count - 1))

    def _seconds_to_index(self, seconds: float, count: int) -> int:
        """Map a chart time back to a replay index, clamped to valid bounds."""
        count = max(1, int(count or 1))
        if count <= 1:
            return 0
        duration = self._replay_duration_s()
        if duration <= 0.0:
            return max(0, min(count - 1, int(round(float(seconds)))))
        ratio = max(0.0, min(1.0, float(seconds) / duration))
        return max(0, min(count - 1, int(round(ratio * (count - 1)))))

    def _frame_time_axis(self, count: int):
        return np.asarray([self._index_to_seconds(index, count) for index in range(count)], float)

    @staticmethod
    def _array_icon(array):
        if array is None:
            return QIcon()
        values = np.nan_to_num(np.asarray(array, float))
        low, high = np.percentile(values, [2, 98]) if values.size else (0, 1)
        if high <= low:
            high = low + 1
        gray = np.clip((values - low) / (high - low) * 255, 0, 255).astype(np.uint8)
        rgb = np.stack([gray, gray, gray], axis=2)
        height, width = rgb.shape[:2]
        image = QImage(rgb.data, width, height, 3 * width, QImage.Format.Format_RGB888).copy()
        return QIcon(QPixmap.fromImage(image).scaled(110, 100, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    def _open_chart_popup(self,key: str):
        popup=ChartPopup({"temperature":"Temperature Trend (ROI)","spectrum":"Acoustic Spectrum","acoustic":"Power % / Score","waterfall":"Relative Acoustic Spectrum (disabled)"}.get(key,key),self)
        if not hasattr(self,"_chart_popups"): self._chart_popups=[]
        popup.chart_key=key; self._chart_popups.append(popup)
        self._render_chart_popup(popup)
        popup.show(); popup.raise_()

    def _render_chart_popup(self,popup):
        key=getattr(popup,"chart_key",""); plot=popup.plot; plot.clear(); popup.hover_text=pg.TextItem(anchor=(0,1),color="#ffffff",fill=pg.mkBrush(0,0,0,210)); popup.hover_text.setZValue(100); popup.hover_text.hide(); plot.addItem(popup.hover_text)
        popup.hover_series=[]
        if key=="temperature":
            x=self._frame_time_axis(len(self.max_temperature_trend)); lo,hi=self._temperature_data_range(); plot.setYRange(lo,hi,padding=0.05); plot.setLabel("left","Temperature",units="°C"); plot.setLabel("bottom","Replay time",units="sec")
            if len(x): plot.setXRange(float(x[0]), float(x[-1]), padding=0.02)
            plot.plot(x,self.max_temperature_trend,pen=pg.mkPen("#ff3b30",width=3),connect="finite"); plot.plot(x,self.mean_temperature_trend,pen=pg.mkPen("#49e36b",width=2.5),connect="finite")
            if self.cursor_temperature_trend: plot.plot(x,self.cursor_temperature_trend,pen=pg.mkPen("#b98cff",width=1.6,style=Qt.PenStyle.DashLine))
            plot.addLine(x=self._index_to_seconds(self.frame_index,len(x)),pen=pg.mkPen("#00bfff",width=1.3))
            popup.set_hover_series([("Max",x,self.max_temperature_trend," °C"),("ROI Avg",x,self.mean_temperature_trend," °C"),("Cursor",x,self.cursor_temperature_trend," °C")])
        elif key=="acoustic":
            trend=getattr(self,"acoustic_control_trend",None); plot.setYRange(0,110,padding=0); plot.setLabel("left","Power / Score",units="%"); plot.setLabel("bottom","Replay time",units="sec")
            if trend is not None:
                tx=np.asarray(trend.plot_time_s if getattr(trend,"plot_time_s",None) is not None else trend.time_s,float)
                py=np.asarray(trend.plot_power_percent if getattr(trend,"plot_power_percent",None) is not None else trend.power_percent,float)
                sy=np.asarray(trend.plot_score_percent if getattr(trend,"plot_score_percent",None) is not None else trend.score_percent,float)
                plot.plot(tx,py,pen=pg.mkPen("#58f26a",width=2.5),connect="finite"); plot.plot(tx,sy,pen=pg.mkPen("#ff9d22",width=2.5),connect="finite"); plot.addLine(x=self._index_to_seconds(self.frame_index,self.current.replay_frame_count),pen=pg.mkPen("#00bfff",width=1.3))
                popup.set_hover_series([("Power",tx,py," %"),("Score",tx,sy," %")])
        elif key=="spectrum":
            selected=self._selected_channels()
            replay_count=self.current.replay_frame_count if self.current else 1
            main_frequency=((self.current.main_frequency_hz if self.current else None) or
                            (self.package.main_frequency_hz if self.package else None))
            result=self.current_spectrum_renderer.render(
                plot, self.spectrum_channels, selected, self.frame_index,
                replay_count, self._channel_colors, main_frequency,
                self._map_replay_to_data,
                self._index_to_seconds(self.frame_index,replay_count),
                mode=self.chart_state.spectrum_mode,
                average_window=self.chart_state.spectrum_average_window,
            )
            plot.addItem(popup.hover_text)
            saved_x=self.chart_state.x_ranges.get("spectrum")
            saved_y=self.chart_state.y_ranges.get("spectrum")
            if saved_x is not None: plot.setXRange(*saved_x,padding=0)
            if saved_y is not None: plot.setYRange(*saved_y,padding=0)
            popup.set_hover_series(result.series)
        elif key=="waterfall":
            self._render_waterfall_popup(plot)

    def _render_waterfall_popup(self,plot):
        selected=self._selected_channels()
        source="Sonication SpectrumMsg"
        self.relative_spectrum_renderer.render(
            plot, self.spectrum_channels, selected, self.frame_index,
            self.current.replay_frame_count if self.current else 1,
            self._channel_colors,
            (self.current.main_frequency_hz if self.current else None) or
            (self.package.main_frequency_hz if self.package else None),
            f"Relative Acoustic Spectrum · {source} · {', '.join(selected)}",
        )

    def _refresh_chart_popups(self):
        for popup in list(getattr(self,"_chart_popups",[])):
            if popup.isVisible(): self._render_chart_popup(popup)

    # -------------------------------------------------------------- Controls
    def _spectrum_mode_changed(self, text: str) -> None:
        self.chart_state.spectrum_mode = text or "Average"
        if self.current:
            self.set_frame(self.frame_index)

    def _temperature_data_range(self) -> tuple[float, float]:
        arrays = [self.max_temperature_trend, self.mean_temperature_trend, self.cursor_temperature_trend]
        finite = []
        for values in arrays:
            arr = np.asarray(values, float)
            if arr.size:
                finite.append(arr[np.isfinite(arr)])
        finite = [v for v in finite if v.size]
        if not finite:
            return self._current_temperature_range()
        values = np.concatenate(finite)
        low = float(np.nanmin(values)); high = float(np.nanmax(values))
        pad = max(1.0, (high-low)*0.10)
        return low-pad, high+pad

    def _fit_temperature_trend(self, force: bool = False) -> None:
        if not self.current or (self.chart_state.temperature_user_zoomed and not force):
            return
        x = self._frame_time_axis(self.current.replay_frame_count)
        if not len(x):
            return
        lo, hi = self._temperature_data_range()
        self._updating_temperature_range = True
        try:
            self.temperature_plot.setXRange(float(x[0]), float(x[-1]), padding=0.02)
            self.temperature_plot.setYRange(lo, hi, padding=0.02)
        finally:
            self._updating_temperature_range = False

    def _temperature_range_changed_by_user(self, *_args) -> None:
        if self._updating_temperature_range:
            return
        self.chart_state.temperature_user_zoomed = True
        try:
            xr, yr = self.temperature_plot.plotItem.vb.viewRange()
            self.chart_state.remember_range("temperature", xr, yr)
        except Exception:
            pass

    def _remember_chart_range(self, key: str, plot) -> None:
        try:
            x_range, y_range = plot.plotItem.vb.viewRange()
            self.chart_state.remember_range(key, x_range, y_range)
        except Exception:
            return

    def _show_chart_tooltip(self, widget, lines) -> None:
        popup = None
        if widget is self.spectrum_plot:
            popup = getattr(self, "spectrum_hover_popup", None)
        elif widget is self.acoustic_control_plot:
            popup = getattr(self, "acoustic_hover_popup", None)
        elif widget is self.temperature_plot:
            popup = getattr(self, "temperature_hover_popup", None)
        if popup is not None:
            popup.show_lines(lines)
        # Keep native tooltip as a secondary accessibility fallback.
        text = "\n".join(str(line) for line in lines if str(line))
        if text:
            QToolTip.showText(QCursor.pos(), text, widget, widget.rect(), 1200)
        else:
            QToolTip.hideText()

    def _hide_chart_tooltip(self, widget) -> None:
        if widget is self.spectrum_plot:
            popup = getattr(self, "spectrum_hover_popup", None)
        elif widget is self.acoustic_control_plot:
            popup = getattr(self, "acoustic_hover_popup", None)
        else:
            popup = getattr(self, "temperature_hover_popup", None)
        if popup is not None:
            popup.hide()
        QToolTip.hideText()

    def _spectrum_plot_hovered(self, event):
        scene_pos = event[0] if isinstance(event, (tuple, list)) else event
        if not self.spectrum_hover_series or not self.spectrum_plot.sceneBoundingRect().contains(scene_pos):
            self.spectrum_hover_text.hide(); self._hide_chart_tooltip(self.spectrum_plot); return
        point = self.spectrum_plot.plotItem.vb.mapSceneToView(scene_pos)
        lines = [f"Frequency: {point.x():.4f} MHz"]
        best_y = None
        for label, x_values, y_values, _unit in self.spectrum_hover_series:
            x=np.asarray(x_values,float); y=np.asarray(y_values,float)
            valid=np.isfinite(x)&np.isfinite(y)
            if not valid.any(): continue
            xv=x[valid]; yv=y[valid]; i=int(np.argmin(np.abs(xv-point.x())))
            value=float(yv[i]); lines.append(f"{label}: {value:.3f}")
            if best_y is None: best_y=value
        if best_y is None:
            self.spectrum_hover_text.hide(); self._hide_chart_tooltip(self.spectrum_plot); return
        self.spectrum_hover_text.setText("\n".join(lines))
        self.spectrum_hover_text.setPos(point.x(), best_y)
        self.spectrum_hover_text.show()
        self._show_chart_tooltip(self.spectrum_plot, lines)

    def _acoustic_plot_hovered(self, event):
        scene_pos=event[0] if isinstance(event,(tuple,list)) else event
        trend=getattr(self,"acoustic_control_trend",None)
        if trend is None or not self.acoustic_control_plot.sceneBoundingRect().contains(scene_pos):
            self.acoustic_hover_text.hide(); self._hide_chart_tooltip(self.acoustic_control_plot); return
        point=self.acoustic_control_plot.plotItem.vb.mapSceneToView(scene_pos)
        x=np.asarray(trend.plot_time_s if getattr(trend,"plot_time_s",None) is not None else trend.time_s,float)
        power=np.asarray(trend.plot_power_percent if getattr(trend,"plot_power_percent",None) is not None else trend.power_percent,float)
        score=np.asarray(trend.plot_score_percent if getattr(trend,"plot_score_percent",None) is not None else trend.score_percent,float)
        if not x.size: self.acoustic_hover_text.hide(); return
        i=int(np.argmin(np.abs(x-point.x())))
        lines=[f"{x[i]:.2f} sec"]
        if i < len(power) and np.isfinite(power[i]): lines.append(f"Power: {power[i]:.1f} %")
        if i < len(score) and np.isfinite(score[i]): lines.append(f"Score: {score[i]:.1f} %")
        self.acoustic_hover_text.setText("\n".join(lines)); self.acoustic_hover_text.setPos(point.x(),point.y()); self.acoustic_hover_text.show()
        self._show_chart_tooltip(self.acoustic_control_plot, lines)

    def _temperature_plot_clicked(self, event):
        if not self.current:
            return
        point = self.temperature_plot.plotItem.vb.mapSceneToView(event.scenePos())
        self.set_frame(self._seconds_to_index(point.x(), self.current.replay_frame_count))

    def _temperature_plot_hovered(self, event):
        if not self.current or not self.max_temperature_trend:
            self.temperature_hover_text.hide(); self._hide_chart_tooltip(self.temperature_plot); return
        scene_pos = event[0] if isinstance(event, (tuple, list)) else event
        if not self.temperature_plot.sceneBoundingRect().contains(scene_pos):
            self.temperature_hover_text.hide(); self._hide_chart_tooltip(self.temperature_plot); return
        point = self.temperature_plot.plotItem.vb.mapSceneToView(scene_pos)
        index = self._seconds_to_index(point.x(), len(self.max_temperature_trend))
        max_t = self.max_temperature_trend[index]
        avg_t = self.mean_temperature_trend[index] if index < len(self.mean_temperature_trend) else np.nan
        cursor_t = self.cursor_temperature_trend[index] if index < len(self.cursor_temperature_trend) else np.nan
        lines = [f"{self._index_to_seconds(index, len(self.max_temperature_trend)):.1f} sec"]
        if np.isfinite(max_t): lines.append(f"Max {max_t:.1f} °C")
        if np.isfinite(avg_t): lines.append(f"Avg {avg_t:.1f} °C")
        if np.isfinite(cursor_t): lines.append(f"Cursor {cursor_t:.1f} °C")
        self.temperature_hover_text.setText("\n".join(lines))
        self.temperature_hover_text.setPos(point.x(), point.y())
        self.temperature_hover_text.show()
        self._show_chart_tooltip(self.temperature_plot, lines)

    def _acoustic_plot_clicked(self, event):
        if not self.current:
            return
        point = self.acoustic_control_plot.plotItem.vb.mapSceneToView(event.scenePos())
        self.set_frame(self._seconds_to_index(point.x(), self.current.replay_frame_count))

    def slider_changed(self, value):
        self._activate_replay_mode_for_navigation()
        self.set_frame(value)

    def previous_frame(self):
        if not self.current:
            return
        self._activate_replay_mode_for_navigation()
        self.set_frame(self.frame_index - 1)

    def next_frame(self):
        if not self.current:
            return
        self._activate_replay_mode_for_navigation()
        current = self.frame_index
        count = max(1, self.current.replay_frame_count)
        target = current + 1
        if target >= count:
            if self.timer.isActive() and getattr(self, "workstation_replay_enabled", True):
                self.timer.stop()
                self.play_btn.setText("▶")
                target = count - 1
            elif self.timer.isActive():
                target = 0
            else:
                target = count - 1
        self.set_frame(target)

    def _playback_speed_multiplier(self) -> float:
        if not hasattr(self, "speed"):
            return 1.0
        value = self.speed.currentData()
        try:
            multiplier = float(value)
        except (TypeError, ValueError):
            multiplier = 1.0
        return max(0.05, multiplier)

    def _actual_replay_frame_interval_s(self) -> float:
        """Replay interval derived from the active treatment acquisition timeline."""
        if not self.current:
            return 1.0
        count = max(1, int(self.current.replay_frame_count or 1))
        if count <= 1:
            return max(0.020, float(self._replay_duration_s() or 1.0))
        t0 = self._index_to_seconds(self.frame_index, count)
        t1 = self._index_to_seconds(min(self.frame_index + 1, count - 1), count)
        delta = float(t1 - t0)
        if delta <= 0.0:
            duration = float(self._replay_duration_s())
            delta = duration / float(count - 1) if duration > 0 else 1.0
        return max(0.020, delta)

    def _playback_timer_interval_ms(self) -> int:
        actual = self._actual_replay_frame_interval_s()
        return max(20, int(round(1000.0 * actual / self._playback_speed_multiplier())))

    def toggle_play(self):
        if self.timer.isActive():
            self.timer.stop()
            self.play_btn.setText("▶")
        else:
            self.timer.start(self._playback_timer_interval_ms())
            self.play_btn.setText("Ⅱ")

    def speed_changed(self, _index=None):
        if self.timer.isActive():
            self.timer.start(self._playback_timer_interval_ms())

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Left, Qt.Key.Key_Up):
            self.previous_frame()
            return
        if event.key() in (Qt.Key.Key_Right, Qt.Key.Key_Down):
            self.next_frame()
            return
        if event.key() == Qt.Key.Key_Space:
            self.toggle_play()
            return
        super().keyPressEvent(event)

    def wheelEvent(self, event):
        if self.current:
            self._activate_replay_mode_for_navigation()
            delta = 1 if event.angleDelta().y() < 0 else -1
            self.set_frame(self.frame_index + delta)
            event.accept()
            return
        super().wheelEvent(event)

    def dragEnterEvent(self, event):
        if any(url.isLocalFile() for url in event.mimeData().urls()):
            event.acceptProposedAction()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            if url.isLocalFile():
                path = Path(url.toLocalFile())
                if path.is_dir() or path.suffix.lower() == ".zip":
                    self.load(path)
                    event.acceptProposedAction()
                    break

    def _restore(self):
        try:
            geometry = self.settings.value("geometry")
            if geometry:
                self.restoreGeometry(geometry)
            layout_version = int(self.settings.value("layout/version", 0) or 0)
            for key, splitter in (("top_split", getattr(self,"top_split",None)),("graph_split",getattr(self,"graph_split",None)),("lower_split",getattr(self,"lower_split",None))):
                # Do not restore the pre-C0046 graph ratio, which encoded the
                # incorrect 3:4 temperature/spectrum split.
                if key == "graph_split" and layout_version < 46:
                    continue
                state=self.settings.value(key)
                if state and splitter is not None: splitter.restoreState(state)
            if getattr(self, "graph_split", None) is not None and layout_version < 46:
                self.graph_split.setSizes([650, 350])
            saved_range=self.settings.value("temperature_range", "40–60 °C")
            self.chart_state.cpc_enabled = str(self.settings.value("chart/cpc_enabled", "false")).lower() == "true"
            self.cpc_enabled = False
            self.chart_state.cpc_enabled = False
            saved_channels = self.settings.value("chart/selected_channels", []) or []
            if isinstance(saved_channels, str): saved_channels=[saved_channels]
            self.chart_state.selected_channels=set(map(str,saved_channels))
            self.chart_state.user_selected_channels=bool(saved_channels)
            self.cpc_button.blockSignals(True); self.cpc_button.setChecked(self.cpc_enabled); self.cpc_button.setText("CPC ON" if self.cpc_enabled else "CPC OFF"); self.cpc_button.blockSignals(False)
            idx=self.range_combo.findText(str(saved_range)); self.range_combo.setCurrentIndex(idx if idx>=0 else 0)
        except Exception:
            pass

    def closeEvent(self, event):
        self.settings.setValue("geometry", self.saveGeometry())
        for key, splitter in (("top_split", getattr(self,"top_split",None)),("graph_split",getattr(self,"graph_split",None)),("lower_split",getattr(self,"lower_split",None))):
            if splitter is not None: self.settings.setValue(key, splitter.saveState())
        self.settings.setValue("layout/version", 46)
        self.settings.setValue("chart/cpc_enabled", self.cpc_enabled)
        self.settings.setValue("chart/selected_channels", sorted(self.chart_state.selected_channels))
        super().closeEvent(event)
