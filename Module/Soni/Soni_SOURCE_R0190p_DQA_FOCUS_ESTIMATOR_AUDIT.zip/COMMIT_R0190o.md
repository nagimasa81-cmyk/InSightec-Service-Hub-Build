# R0190o — DQA RL physical decomposition audit

- Keeps Focus alignment = Observed focus minus Phantom reference.
- Records observed-focus RAS R, phantom-reference RAS R, pixel delta, circle support and stack residual.
- No expected-value calibration or fixture-specific correction.
- Preserves R0190n sagittal physical reference and chart double-click RESET hardening.
