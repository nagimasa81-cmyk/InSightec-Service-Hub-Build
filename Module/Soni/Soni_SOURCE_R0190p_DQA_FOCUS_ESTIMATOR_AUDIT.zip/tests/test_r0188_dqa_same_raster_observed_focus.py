from types import SimpleNamespace
import numpy as np
from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService


def _row_axial():
    return {
        'topleftcoordr':0,'topleftcoorda':0,'topleftcoords':0,
        'rowdirectcosrasx':0,'rowdirectcosrasy':1,'rowdirectcosrasz':0,
        'coldirectcosrasx':1,'coldirectcosrasy':0,'coldirectcosrasz':0,
        'pixsizex':1,'pixsizey':1,
        'seriesdiscription':'DQA-Axial',
    }


def _row_sagittal():
    return {
        'topleftcoordr':0,'topleftcoorda':0,'topleftcoords':0,
        'rowdirectcosrasx':0,'rowdirectcosrasy':0,'rowdirectcosrasz':1,
        'coldirectcosrasx':1,'coldirectcosrasy':0,'coldirectcosrasz':0,
        'pixsizex':1,'pixsizey':1,
        'seriesdiscription':'DQA-Sagittal',
    }


def test_series_uses_observed_focus_and_same_raster_reference(monkeypatch,tmp_path):
    svc=DqaFocusAlignmentService(); pkg=SimpleNamespace(workspace=tmp_path,sonications=[])
    monkeypatch.setattr(svc,'is_dqa',lambda _p: True)
    monkeypatch.setattr(svc,'_summary_focal_ras',lambda _p:{1:(999.,999.,999.)})
    monkeypatch.setattr(svc,'_dqa_common_locate_focal_ras',lambda _p:((100.,200.,300.),['Locate evidence only'],None))
    monkeypatch.setattr(svc,'_observed_dqa_focus_by_orientation',lambda _p,_f:({
        'Axial':{'hotspot_ras':(14.,27.,0.)},
        'Sagittal':{'hotspot_ras':(50.,0.,38.)},
    },['observed focus']))
    ar=_row_axial(); sr=_row_sagittal()
    monkeypatch.setattr(svc,'_dqa_reference_geometry',lambda _p:{
        'evidence':['phantom'],
        'axial_candidates':[{'row':ar,'label':'AX','circle_pixel':(10.,20.),'circle_ras':(10.,20.,0.),'support':1.0}],
        'sagittal_candidates':[{'row':sr,'label':'SAG','baseline_pixel':(50.,10.),'baseline_ras':(50.,0.,10.),'tilt_deg':-2.0,'support':1.0}],
    })
    r=svc.analyze_series(pkg)
    assert (round(r.x_mm,2),round(r.y_mm,2),round(r.z_mm,2)) == (4.0,7.0,8.0)
    assert r.baseline_to_focal_mm == 28.0
    assert r.tilt_deg == -2.0
    assert r.calculator_contract == 'R0190'
    assert all(abs(v) < 100 for v in (r.x_mm,r.y_mm,r.z_mm))
    assert any('hotspot-search seed only' in e for e in r.evidence)
    assert any('lower-line→focus S=+28.00 mm' in e for e in r.evidence)


def test_planned_focalras_is_not_used_as_displacement_zero_point():
    from pathlib import Path
    p=Path(__file__).resolve().parents[1]/'src/services/dqa_focus_alignment_service.py'
    text=p.read_text()
    block=text.split('def analyze_series',1)[1].split('def clear_cache',1)[0]
    assert '_series_fixed_focus_ras' not in block
    assert 'registered_focal[0]-ref_xyz[0]' not in block
    assert "observed.get('Axial')" in block
    assert "observed.get('Sagittal')" in block
    assert 'hotspot-search seed only' in block


def test_same_raster_failure_is_fail_closed(monkeypatch,tmp_path):
    svc=DqaFocusAlignmentService(); pkg=SimpleNamespace(workspace=tmp_path,sonications=[])
    monkeypatch.setattr(svc,'is_dqa',lambda _p: True)
    monkeypatch.setattr(svc,'_summary_focal_ras',lambda _p:{})
    monkeypatch.setattr(svc,'_dqa_common_locate_focal_ras',lambda _p:(None,[],None))
    monkeypatch.setattr(svc,'_observed_dqa_focus_by_orientation',lambda _p,_f:({},['no thermal focus']))
    monkeypatch.setattr(svc,'_dqa_reference_geometry',lambda _p:{'evidence':[],'axial_candidates':[],'sagittal_candidates':[]})
    r=svc.analyze_series(pkg)
    assert r.excluded_reason is not None
    assert r.x_mm is None and r.y_mm is None and r.z_mm is None
    assert r.calculator_contract == 'R0190'
