from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CH=(ROOT/'src/ui/chart_interaction.py').read_text()
MAIN=(ROOT/'src/ui/main_window.py').read_text()
HYD=(ROOT/'src/ui/hydrophone_window.py').read_text()
DQA=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text()

def test_doubleclick_handler_can_be_upgraded_not_stuck_on_ancestor_reset():
    assert 'filt.double_click_callback = double_click_callback' in CH

def test_replay_r0190f_reset_owner_supersedes_popup_owner():
    assert 'if bool(getattr(plot, "_soni_x_axis_range_zoom_installed", False)):' in MAIN
    block=MAIN[MAIN.index('def _chart_panel'):MAIN.index('def _make_image_strip')]
    assert 'install_horizontal_axis_range_zoom(plot)' in block
    assert 'double_click_callback' not in block

def test_analyzer_doubleclick_resets_all_plotwidgets():
    assert 'open_enlarged_plot' not in HYD
    assert 'reset_callback=lambda p=_plot_widget: self._clear_manual_view_overrides(p)' in HYD

def test_generic_analysis_charts_use_reset_not_enlarge():
    assert 'open_enlarged_plot' not in MAIN

def test_dqa_does_not_require_magnitude_pair_to_recover_observed_thermal_focus():
    assert 'validated same-raster thermal hotspot' in DQA
    assert "_planned_focus_native_measurement(son,rows,planned)" in DQA
    assert "'paired_reference':None" in DQA
