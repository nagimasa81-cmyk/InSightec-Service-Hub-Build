from pathlib import Path
ROOT=Path(__file__).parents[1]
D=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text(); M=(ROOT/'src/ui/main_window.py').read_text(); H=(ROOT/'src/ui/hydrophone_window.py').read_text()
def test_axial_reference_requires_stack_consensus():
 assert 'stack_consistent' in D and 'stack_residual_mm' in D and "if candidate.get('stack_consistent') is False" in D
def test_all_semantic_plot_click_handlers_reject_double_click():
 for name in ['_temperature_plot_clicked','_acoustic_plot_clicked','_waterfall_plot_clicked','_cavitation_plot_clicked']:
  b=M.split('def '+name,1)[1].split('\n    def ',1)[0]; assert 'event.double()' in b
 for name in ['_cavitation_control_plot_clicked','_vendor_chart_clicked']:
  b=H.split('def '+name,1)[1].split('\n    def ',1)[0]; assert 'event.double()' in b
