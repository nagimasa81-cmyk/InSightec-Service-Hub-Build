from pathlib import Path

SRC=Path("src/services/dqa_focus_alignment_service.py").read_text(encoding="utf-8")

def test_lower_reference_is_physical_upper_bar_edge():
    assert "Detect the *upper* edge of the DQA sagittal lower reference bar" in SRC
    assert "baseline_edge_contract" in SRC

def test_sagittal_reference_uses_stack_consensus():
    assert "Sagittal lower-reference consensus rejected" in SRC
    assert "candidate.get('stack_consistent') is False" in SRC
    assert "if c.get('stack_consistent',True)" in SRC

def test_lower_line_is_evaluated_at_observed_focus_x():
    assert "bx=float(diag['x_px'])" in SRC
    assert "by=float(candidate['slope']*bx+candidate['intercept'])" in SRC

def test_no_expected_displacement_calibration_in_detector():
    block=SRC[SRC.index('def _baseline_line'):SRC.index('def _geometric_lr_center')]
    assert '6.9' not in block and '12.4' not in block and '3.8' not in block
