from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def _text(rel):
    return (ROOT / rel).read_text(encoding='utf-8')

def test_no_chart_double_click_popup_wiring_remains():
    combined = '\n'.join(_text(p) for p in [
        'src/ui/main_window.py', 'src/ui/hydrophone_window.py', 'src/ui/chart_interaction.py'
    ])
    assert 'double_click_callback=lambda' not in combined
    assert 'open_enlarged_plot' not in combined
    assert 'Double-click the chart to enlarge it.' not in combined

def test_replay_chart_panel_installs_reset_contract():
    s=_text('src/ui/main_window.py')
    block=s[s.index('def _chart_panel'):s.index('def _make_image_strip')]
    assert 'install_horizontal_axis_range_zoom(plot)' in block
    assert '_open_chart_popup' not in block

def test_analyzer_reset_callback_preserved():
    s=_text('src/ui/hydrophone_window.py')
    assert 'reset_callback=lambda p=_plot_widget: self._clear_manual_view_overrides(p)' in s
    assert 'reset_callback=lambda p=plot: self._clear_manual_view_overrides(p)' in s

def test_reinstall_actively_clears_stale_callback():
    s=_text('src/ui/chart_interaction.py')
    assert 'filt.double_click_callback = double_click_callback' in s
    assert 'if double_click_callback is not None:\n                filt.double_click_callback' not in s
    assert 'Double-click the chart to reset zoom.' in s
