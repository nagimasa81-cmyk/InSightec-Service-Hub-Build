from pathlib import Path
SRC=(Path(__file__).parents[1]/'src/services/dqa_focus_alignment_service.py').read_text(encoding='utf-8')
def test_independent_focus_estimators_are_recorded_without_replacing_centroid():
    assert "'centroid_pixel':(float(fx),float(fy))" in SRC
    assert "'quadratic_peak_pixel':(float(qx),float(qy))" in SRC
    assert "hotspot_ras=self._absolute_ras(row,fx,fy)" in SRC
    assert "'pixel_separation':float(np.hypot(fx-qx,fy-qy))" in SRC
def test_no_gold_sample_calibration():
    block=SRC.split('# R0190p focus-estimator audit.',1)[-1].split("exact_identity",1)[0]
    for forbidden in ('3.8','12.4','6.9'):
        assert forbidden not in block
