from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CH=(ROOT/'src/ui/chart_interaction.py').read_text()
MAIN=(ROOT/'src/ui/main_window.py').read_text()
HYD=(ROOT/'src/ui/hydrophone_window.py').read_text()

def test_common_installer_clears_stale_reset_owner_even_with_none():
    assert 'filt.reset_callback = reset_callback' in CH
    assert 'if reset_callback is not None:\n                filt.reset_callback' not in CH

def test_global_plot_sweep_does_not_skip_preinstalled_plots():
    block=MAIN.split('def _install_horizontal_chart_zoom',1)[1].split('def _install_global_readability',1)[0]
    assert '_soni_x_axis_range_zoom_installed' not in block
    assert 'install_horizontal_axis_range_zoom(plot)' in block

def test_semantic_scene_click_handlers_ignore_double_clicks():
    for name in ('_temperature_plot_clicked','_acoustic_plot_clicked','_waterfall_plot_clicked','_cavitation_plot_clicked'):
        block=MAIN.split(f'def {name}',1)[1].split('\n    def ',1)[0]
        assert 'event.double()' in block
    for name in ('_cavitation_control_plot_clicked','_vendor_chart_clicked'):
        block=HYD.split(f'def {name}',1)[1].split('\n    def ',1)[0]
        assert 'event.double()' in block
