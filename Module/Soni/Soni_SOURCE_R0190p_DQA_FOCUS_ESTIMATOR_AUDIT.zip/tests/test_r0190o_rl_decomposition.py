from pathlib import Path
SRC=(Path(__file__).parents[1]/'src/services/dqa_focus_alignment_service.py').read_text(encoding='utf-8')

def test_rl_decomposition_is_explicit_and_auditable():
    assert 'focus R=' in SRC and 'phantom R=' in SRC
    assert "'focus_rl_ras_mm':float(focus_plane[0])" in SRC
    assert "'phantom_rl_ras_mm':float(circle[0])" in SRC
    assert "'rl_pixel_delta_px':float(diag['x_px'])-float(cp[0])" in SRC
    assert "'circle_stack_residual_mm':candidate.get('stack_residual_mm')" in SRC

def test_rl_remains_physical_difference_not_expected_value_calibration():
    assert 'x=float(direct_delta[0])' in SRC
    forbidden=('3.8','12.4','6.9')
    block=SRC.split('def _series_common_r0188',1)[-1] if 'def _series_common_r0188' in SRC else SRC
    # no gold-sample numeric correction may be introduced in the new audit fields
    line='RL={x:+.2f} mm (focus R={float(focus_plane[0]):+.3f} - phantom R={float(circle[0]):+.3f})'
    assert line in SRC
