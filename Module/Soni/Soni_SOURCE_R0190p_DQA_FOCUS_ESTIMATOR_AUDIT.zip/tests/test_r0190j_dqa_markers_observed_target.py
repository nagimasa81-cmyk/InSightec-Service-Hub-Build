from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
D=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text(encoding='utf-8')
I=(ROOT/'src/ui/image_panel.py').read_text(encoding='utf-8')
M=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
def test_observed_target_is_independent_from_phantom_alignment():
    assert 'observed_target_x_mm' in D and 'planned_pixel' in D
    assert 'focus_plane-np.asarray(planned_plane,float)' in D
    assert 'focus_plane-circle' in D
def test_three_marker_switches_are_display_only():
    assert 'set_dqa_marker_visibility' in I
    assert "'observed':bool(observed)" in I and "'target':bool(target)" in I and "'phantom':bool(phantom)" in I
    assert "QCheckBox('Observed focus')" in M
    assert "QCheckBox('Sonication target center')" in M
    assert "QCheckBox('Phantom reference')" in M
def test_phase_cell_is_dedicated_and_bold_only_when_resolved():
    assert 'Observed vs Target (Phase)' in M
    assert 'ot_item.font(); f.setBold(True)' in M
    assert "phase in axis_to_value and pv is not None" in M
