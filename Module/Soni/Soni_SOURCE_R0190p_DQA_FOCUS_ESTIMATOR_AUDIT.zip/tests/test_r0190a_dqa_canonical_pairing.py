from pathlib import Path
from types import SimpleNamespace
from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService


def row(field, array=None, img=None):
    d={
        'fieldindex':str(field),'sonicationindex':'1','zoneindex':'0',
        'seriesdiscription':'MEMP','pixsizex':'1','pixsizey':'1',
        'rowdirectcosrasx':'1','rowdirectcosrasy':'0','rowdirectcosrasz':'0',
        'coldirectcosrasx':'0','coldirectcosrasy':'1','coldirectcosrasz':'0',
        'topleftcoordr':'0','topleftcoorda':'0','topleftcoords':'0',
    }
    if array is not None: d['arrayindex']=str(array)
    if img is not None: d['imgnum']=str(img)
    return d


def test_row_for_raw_prefers_zero_based_arrayindex_over_one_based_imgnum_alias():
    rows=[row(5,0,1),row(5,1,2),row(5,2,3)]
    got=DqaFocusAlignmentService._row_for_raw_frame(rows,Path('5-1-0-1.raw'))
    assert got is rows[1]


def test_row_for_raw_uses_imgnum_minus_one_when_arrayindex_absent():
    rows=[row(5,None,1),row(5,None,2),row(5,None,3)]
    got=DqaFocusAlignmentService._row_for_raw_frame(rows,Path('5-1-0-1.raw'))
    assert got is rows[1]


def test_exact_pair_does_not_make_adjacent_acquisitions_ambiguous():
    rows=[]; mags=[]
    for i in range(3):
        rows += [row(5,i,i+1),row(6,i,i+1)]
        mags.append(SimpleNamespace(path=Path(f'6-1-0-{i}.raw')))
    pair=DqaFocusAlignmentService._exact_magnitude_pair(rows,Path('5-1-0-1.raw'),mags)
    assert pair is not None
    mf,mrow=pair
    assert mf.path.name=='6-1-0-1.raw'
    assert DqaFocusAlignmentService._row_acquisition_identity(mrow)==(1,0,1)


def test_exact_pair_fails_closed_when_exact_acquisition_missing():
    rows=[row(5,1,2),row(6,0,1),row(6,2,3)]
    mags=[SimpleNamespace(path=Path('6-1-0-0.raw')),SimpleNamespace(path=Path('6-1-0-2.raw'))]
    assert DqaFocusAlignmentService._exact_magnitude_pair(rows,Path('5-1-0-1.raw'),mags) is None
