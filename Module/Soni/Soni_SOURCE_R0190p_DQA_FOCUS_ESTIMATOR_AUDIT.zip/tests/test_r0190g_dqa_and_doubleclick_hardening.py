
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CH=(ROOT/"src/ui/chart_interaction.py").read_text()
MW=(ROOT/"src/ui/main_window.py").read_text()
DQA=(ROOT/"src/services/dqa_focus_alignment_service.py").read_text()
def test_doubleclick_is_reset_only():
    assert "double_click_callback" not in CH
    assert "vb.mouseDoubleClickEvent = types.MethodType(_viewbox_double, vb)" in CH
    assert "_open_chart_popup" not in MW
def test_dqa_registered_stack_fallback():
    assert "sagittal_ap_center_mm" in DQA
    assert "R0190g registered-stack fallback" in DQA
    assert "focus R=" in DQA and "phantom R=" in DQA
    assert "lower line S=" in DQA
