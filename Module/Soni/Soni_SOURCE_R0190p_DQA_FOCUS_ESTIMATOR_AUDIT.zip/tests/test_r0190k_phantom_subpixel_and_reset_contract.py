from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
D=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text()
C=(ROOT/'src/ui/chart_interaction.py').read_text()
def test_axial_reference_is_subpixel_and_not_expected_fit():
    assert 'def subpeak(idx):' in D
    assert 'np.clip(off,-0.5,0.5)' in D
    assert 'expected DQA displacement' in D
    assert "'contract':'R0190k'" in D
def test_chart_doubleclick_remains_reset_contract():
    assert 'double' in C.lower() and 'reset' in C.lower()
