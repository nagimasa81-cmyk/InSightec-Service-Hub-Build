from pathlib import Path
ROOT=Path(__file__).parents[1]
CH=(ROOT/'src/ui/chart_interaction.py').read_text()
DQA=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text()
def test_doubleclick_has_scene_and_viewport_routes():
    assert 'plot.viewport().installEventFilter(filt)' in CH
    assert 'plot.scene().sigMouseClicked.connect(_scene_double)' in CH
    assert '_soni_last_double_dispatch' in CH
    assert 'ev.double()' in CH
def test_dqa_fallback_preserves_real_thermal_score():
    assert '"hotspot_score_c":float(_score)' in DQA
    assert "'score':float(m.get('hotspot_score_c',0.0) or 0.0)" in DQA
def test_steered_shot_is_excluded_individually_not_whole_series():
    assert 'Electronic-steering DQA shot(s) excluded individually' in DQA
    assert 'Default-centre DQA steering stable after per-shot exclusions' in DQA
    assert 'electronic steering changes across the DQA series' not in DQA
