from pathlib import Path

from src.core.spectrum_decoder import SharedSpectrumDecoder

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'src' / 'ui' / 'main_window.py').read_text(encoding='utf-8')
DEC = (ROOT / 'src' / 'core' / 'spectrum_decoder.py').read_text(encoding='utf-8')


def _block(start: str, end: str) -> str:
    a = MAIN.index(start)
    b = MAIN.index(end, a)
    return MAIN[a:b]


def test_initial_summary_gate_requires_terminal_preload():
    block = _block('    def _sonication_summary_initial_data_busy', '    def _request_sonication_summary_detail')
    assert 'preload_complete' in block
    assert '_spectrum_preload_failed_workspace' in block
    assert 'ready_indices' not in block

def test_authoritative_partial_handoff_does_not_retry_summary():
    request = _block('    def _request_sonication_summary_detail', '    def _resume_sonication_summary_after_initial_data')
    assert '_sonication_summary_completed_workspace' in request
    finished = _block('    def _sonication_summary_finished', '    def _start_sonication_summary_temperature_background')
    assert 'QTimer.singleShot(0,self._request_sonication_summary_detail)' not in finished

def test_preload_terminal_paths_release_initial_gate_and_resume_summary():
    ready = _block('    def _spectrum_preload_ready', '    def _spectrum_preload_failed')
    failed = _block('    def _spectrum_preload_failed', '    def _open_hydrophone_window')
    for block in (ready, failed):
        assert '_initial_spectrum_handoff_pending=False' in block
        assert '_resume_sonication_summary_after_initial_data' in block


def test_summary_worker_error_cannot_leave_dqa_cell_saying_analyzing():
    block = _block('    def _sonication_summary_row_ready', '    def _sonication_summary_finished')
    error = block.split('if data.get("_error"):', 1)[1].split('while len(', 1)[0]
    assert 'QTableWidgetItem("Unavailable")' in error
    assert 'setItem(int(row),17,dqa_item)' in error


def test_brain220_legacy_search_band_includes_subharmonic_region():
    lo, hi = SharedSpectrumDecoder._heuristic_analysis_band(230_000.0)
    assert lo < 115_000.0 < hi
    assert lo < 230_000.0 < hi
    assert SharedSpectrumDecoder._heuristic_analysis_band(670_000.0) == (200_000.0, 800_000.0)


def test_valid_structural_header_does_not_fall_back_to_global_hardcoded_8_record_grouping():
    assert 'explicit_groups = [] if structural_header_valid else self._explicit_graph_groups(full_data)' in DEC
