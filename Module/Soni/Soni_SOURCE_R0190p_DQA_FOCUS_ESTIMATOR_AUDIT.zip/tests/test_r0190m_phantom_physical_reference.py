from pathlib import Path
S=(Path(__file__).parents[1]/"src/services/dqa_focus_alignment_service.py").read_text()

def test_sagittal_ap_uses_detected_phantom_not_raster_center():
    b=S.split("def _sagittal_ap_center_from_image",1)[1].split("def _native_measurement_for_sonication",1)[0]
    assert "_phantom_mask_from_magnitude" in b
    assert "_sagittal_ap_center_from_mask" in b
    assert "(a.shape[1]-1)/2.0" not in b

def test_axial_outlier_exact_pair_cannot_override_stack_consensus():
    b=S.split("def analyze_series",1)[1].split("def cached_series",1)[0]
    assert "candidate.get('stack_consistent') is False" in b
    assert "if c.get('stack_consistent',True)" in b
