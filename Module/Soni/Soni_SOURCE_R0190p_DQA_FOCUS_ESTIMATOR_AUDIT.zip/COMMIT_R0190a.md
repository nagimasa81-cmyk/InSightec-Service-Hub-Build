# COMMIT R0190a — DQA canonical acquisition pairing repair

## Trigger
Real Windows validation on 4267 DQA export showed `N/A — missing observed Axial thermal focus` in Sonication Summary even though Replay visibly contained axial and sagittal MEMP thermometry.

## Root cause
R0190 canonical row/pair matching mixed zero-based `arrayindex` with one-based `imgnum` and then allowed a +/-1 acquisition-token neighbourhood. In a normal sequential MEMP acquisition this made adjacent magnitude frames simultaneously eligible for one thermal frame. `_exact_magnitude_pair()` correctly fails closed on ambiguity, so no observed Axial/Sagittal focus survived.

## Fix
- Canonical RAW acquisition suffix as zero-based index.
- Prefer `arrayindex` when present; otherwise canonicalize `imgnum - 1`.
- `_row_for_raw_frame()` now binds exact field/sonication/zone/canonical-array only.
- `_row_acquisition_identity()` returns canonical zero-based acquisition identity.
- `_exact_magnitude_pair()` requires exact canonical S/Z/acquisition equality plus existing physical-geometry compatibility.
- No index-ratio mapping, expected-value fitting, clipping, fixture/SHA branching, or planned-focus hard gate was introduced.

## Expected effect
Thermal field 5 frame N pairs uniquely with magnitude field 6 frame N when their physical geometry matches, instead of becoming ambiguous with N-1/N/N+1.
