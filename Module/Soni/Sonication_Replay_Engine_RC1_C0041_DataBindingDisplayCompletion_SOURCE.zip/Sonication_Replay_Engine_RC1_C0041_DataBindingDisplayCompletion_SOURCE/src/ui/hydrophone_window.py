from __future__ import annotations

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import Qt, Signal, QTimer
from PySide6.QtWidgets import (
    QComboBox, QDialog, QGridLayout, QHBoxLayout, QLabel, QPushButton,
    QSlider, QSpinBox, QVBoxLayout, QWidget
)

from src.services.hydrophone_replay_service import HydrophoneReplayService, CpcHydrophoneReplay


class EightHydrophoneWindow(QDialog):
    sonicationRequested = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('CPC 8CH Hydrophone Analyzer')
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinMaxButtonsHint)
        self.resize(1450, 900)
        self.service = HydrophoneReplayService()
        self.package = None
        self.replay: CpcHydrophoneReplay | None = None
        self.frame_index = 0
        self.frame_interval_s = 0.010
        self.timer=QTimer(self); self.timer.timeout.connect(lambda: self.set_frame(self.frame_index+1))

        top = QHBoxLayout()
        self.sonication_combo = QComboBox(); self.sonication_combo.currentIndexChanged.connect(self._sonication_changed)
        self.mode_combo = QComboBox(); self.mode_combo.addItems(['8 Panel', 'Overlay', 'Single CH']); self.mode_combo.currentIndexChanged.connect(self._rebuild_plots)
        self.channel_spin = QSpinBox(); self.channel_spin.setRange(0, 7); self.channel_spin.valueChanged.connect(self._draw)
        self.source_label = QLabel('No CPC source loaded'); self.source_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        top.addWidget(QLabel('Sonication')); top.addWidget(self.sonication_combo)
        top.addWidget(QLabel('Display')); top.addWidget(self.mode_combo)
        top.addWidget(QLabel('CH')); top.addWidget(self.channel_spin); top.addWidget(self.source_label, 1)

        self.note = QLabel('No data'); self.note.setWordWrap(True)
        self.plot_host = QWidget(); self.plot_layout = QGridLayout(self.plot_host); self.plot_layout.setContentsMargins(0,0,0,0)
        self.plots=[]

        controls=QHBoxLayout()
        self.prev_btn=QPushButton('◀'); self.play_btn=QPushButton('▶'); self.next_btn=QPushButton('▶|')
        self.prev_btn.clicked.connect(lambda: self.set_frame(self.frame_index-1)); self.next_btn.clicked.connect(lambda: self.set_frame(self.frame_index+1)); self.play_btn.clicked.connect(self._toggle_play)
        self.slider=QSlider(Qt.Orientation.Horizontal); self.slider.valueChanged.connect(self.set_frame)
        self.frame_label=QLabel('Frame - / - · Time -')
        controls.addWidget(self.prev_btn); controls.addWidget(self.play_btn); controls.addWidget(self.next_btn); controls.addWidget(self.slider,1); controls.addWidget(self.frame_label)

        layout=QVBoxLayout(self); layout.addLayout(top); layout.addWidget(self.note); layout.addWidget(self.plot_host,1); layout.addLayout(controls)
        self._rebuild_plots()

    def load_package(self, package, sonication_index: int):
        self.package=package
        self.sonication_combo.blockSignals(True); self.sonication_combo.clear()
        for i, son in enumerate(package.sonications): self.sonication_combo.addItem(son.name, i)
        self.sonication_combo.setCurrentIndex(max(0, sonication_index)); self.sonication_combo.blockSignals(False)
        self.load_sonication(sonication_index)

    def load_sonication(self, index: int):
        if self.package is None: return
        self.replay=self.service.build(self.package.cpc_spectrum_files, index, len(self.package.sonications))
        src=self.replay.source_fft.name if self.replay.source_fft else 'No mapped Spectrum_*.dmp_FFT'
        self.source_label.setText(src); self.note.setText(self.replay.note + '  Replay advances through decoded CPC acoustic frames; default interval 10 ms from Acquisition configuration.')
        count=len(self.replay.frames); self.slider.setRange(0,max(0,count-1)); self.set_frame(0)

    def sync_sonication(self, index: int):
        if self.sonication_combo.count() and self.sonication_combo.currentIndex()!=index:
            self.sonication_combo.blockSignals(True); self.sonication_combo.setCurrentIndex(index); self.sonication_combo.blockSignals(False)
        self.load_sonication(index)

    def _sonication_changed(self, index: int):
        if index < 0: return
        self.load_sonication(index); self.sonicationRequested.emit(index)

    def _clear_plots(self):
        while self.plot_layout.count():
            item=self.plot_layout.takeAt(0); w=item.widget()
            if w: w.deleteLater()
        self.plots=[]

    def _rebuild_plots(self):
        self._clear_plots(); mode=self.mode_combo.currentText() if hasattr(self,'mode_combo') else '8 Panel'
        count=8 if mode=='8 Panel' else 1
        for i in range(count):
            plot=pg.PlotWidget(); plot.showGrid(x=True,y=True,alpha=.2); plot.setLabel('bottom','Frequency','MHz'); plot.setLabel('left','Relative level','dB'); plot.setXRange(0.0,1.0,padding=0.0); plot.setYRange(-60.0,0.0,padding=0.0); plot.setLimits(xMin=0.0,xMax=1.0,yMin=-60.0,yMax=0.0)
            if mode=='8 Panel': plot.setTitle(f'CH{i} · physical position unknown'); self.plot_layout.addWidget(plot,i//4,i%4)
            else: self.plot_layout.addWidget(plot,0,0)
            self.plots.append(plot)
        self._draw()

    def set_frame(self, index: int):
        count=len(self.replay.frames) if self.replay else 0
        self.frame_index=max(0,min(int(index),max(0,count-1)))
        self.slider.blockSignals(True); self.slider.setValue(self.frame_index); self.slider.blockSignals(False)
        self.frame_label.setText(f'Frame {self.frame_index+1 if count else "-"} / {count or "-"} · Time {self.frame_index*self.frame_interval_s:.3f} s')
        self._draw()

    def _toggle_play(self):
        if self.timer.isActive():
            self.timer.stop(); self.play_btn.setText("▶")
        else:
            if self.replay and self.replay.frames and self.frame_index >= len(self.replay.frames)-1: self.set_frame(0)
            self.timer.start(max(10,int(self.frame_interval_s*1000))); self.play_btn.setText("Ⅱ")

    def _draw(self):
        for plot in self.plots: plot.clear()
        if not self.replay or not self.replay.frames or not self.plots: return
        frame=self.replay.frames[self.frame_index]; x=frame.frequency_hz/1e6; mode=self.mode_combo.currentText()

        def display_db(ch: int) -> np.ndarray:
            amplitude=np.asarray(frame.channels[ch],dtype=float)
            reference=max(float(self.replay.channel_reference_levels[ch]),np.finfo(float).tiny)
            floor=reference*(10.0**(self.replay.display_db_min/20.0))
            safe=np.maximum(np.where(np.isfinite(amplitude),np.abs(amplitude),0.0),floor)
            values=20.0*np.log10(safe/reference)
            return np.clip(values,self.replay.display_db_min,self.replay.display_db_max)

        if mode=='8 Panel':
            for ch,plot in enumerate(self.plots):
                plot.plot(x,display_db(ch),pen=pg.intColor(ch,8),clear=True)
                plot.setXRange(0.0,1.0,padding=0.0); plot.setYRange(-60.0,0.0,padding=0.0)
        elif mode=='Overlay':
            plot=self.plots[0]
            for ch in range(8): plot.plot(x,display_db(ch),pen=pg.intColor(ch,8),name=f'CH{ch}')
            plot.setTitle('CH0–CH7 overlay · relative dB · physical positions unknown')
            plot.setXRange(0.0,1.0,padding=0.0); plot.setYRange(-60.0,0.0,padding=0.0)
        else:
            ch=self.channel_spin.value(); self.plots[0].plot(x,display_db(ch),pen=pg.intColor(ch,8),clear=True); self.plots[0].setTitle(f'CH{ch} · relative dB · physical position unknown'); self.plots[0].setXRange(0.0,1.0,padding=0.0); self.plots[0].setYRange(-60.0,0.0,padding=0.0)
