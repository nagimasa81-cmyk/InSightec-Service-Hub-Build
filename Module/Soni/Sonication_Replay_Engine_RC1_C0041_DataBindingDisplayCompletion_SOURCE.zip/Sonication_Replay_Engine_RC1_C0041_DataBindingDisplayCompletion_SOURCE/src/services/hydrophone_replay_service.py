from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import gzip
import struct
import numpy as np


@dataclass(slots=True)
class CpcHydrophoneFrame:
    index: int
    frequency_hz: np.ndarray
    channels: list[np.ndarray]


@dataclass(slots=True)
class CpcHydrophoneReplay:
    source_fft: Path | None
    source_raw: Path | None
    channel_count: int = 8
    sampling_frequency_hz: float = 0.0
    main_frequency_hz: float = 0.0
    declared_frame_count: int = 0
    total_samples: int = 0
    frames: list[CpcHydrophoneFrame] = field(default_factory=list)
    channel_reference_levels: list[float] = field(default_factory=lambda: [1.0] * 8)
    display_db_min: float = -60.0
    display_db_max: float = 0.0
    note: str = ""


class HydrophoneReplayService:
    """Read CPCFiles as a source independent from Sonication SpectrumMsg.

    The CPC container header is verified.  Payload layout remains proprietary;
    the decoder therefore splits each declared frame into eight equal channel
    blocks and exposes the result as CH0..CH7 with an explicit diagnostic note.
    No Sonication SpectrumMsg data is used here.
    """

    def select_files(self, cpc_files: list[Path], sonication_index: int, sonication_count: int) -> tuple[Path | None, Path | None]:
        fft_files = sorted([p for p in cpc_files if p.name.lower().endswith('.dmp_fft')])
        raw_files = sorted([p for p in cpc_files if p.name.lower().endswith('.dmp') and not p.name.lower().endswith('.dmp_fft')])
        def select(items):
            if not items:
                return None
            mapped = items[-sonication_count:] if sonication_count and len(items) >= sonication_count else items
            return mapped[min(max(sonication_index, 0), len(mapped)-1)]
        return select(fft_files), select(raw_files)

    def build(self, cpc_files: list[Path], sonication_index: int, sonication_count: int) -> CpcHydrophoneReplay:
        fft_path, raw_path = self.select_files(cpc_files, sonication_index, sonication_count)
        result = CpcHydrophoneReplay(source_fft=fft_path, source_raw=raw_path)
        if fft_path is None:
            result.note = 'No CPCFiles Spectrum_*.dmp_FFT file mapped to this sonication.'
            return result
        try:
            with gzip.open(fft_path, 'rb') as stream:
                blob = stream.read()
        except OSError:
            blob = fft_path.read_bytes()
        if len(blob) < 40:
            result.note = 'CPC FFT container is too short.'
            return result
        h0, frame_count, channel_count, total_samples, processing, sample_rate = struct.unpack('<6I', blob[:24])
        main_frequency = struct.unpack('<d', blob[32:40])[0]
        result.channel_count = int(channel_count)
        result.sampling_frequency_hz = float(sample_rate)
        result.main_frequency_hz = float(main_frequency)
        result.declared_frame_count = int(frame_count)
        result.total_samples = int(total_samples)
        if channel_count != 8 or frame_count <= 0:
            result.note = f'Unsupported CPC header: channels={channel_count}, frames={frame_count}.'
            return result

        payload = blob[40:]
        # Equal frame slicing is deliberately isolated here so the exact vendor
        # record layout can replace it without changing the popup or timeline API.
        frame_bytes = len(payload) // frame_count
        for frame_index in range(frame_count):
            chunk = payload[frame_index*frame_bytes:(frame_index+1)*frame_bytes]
            usable = len(chunk) - (len(chunk) % 4)
            values32 = np.frombuffer(chunk[:usable], dtype='<f4')
            values = values32[np.isfinite(values32)].astype(np.float64, copy=False)
            usable_values = (len(values) // 8) * 8
            if usable_values < 8 * 16:
                continue
            # Channel-major diagnostic interpretation.  Keep the final power-of-two-ish
            # region bounded to avoid metadata at the head dominating the chart.
            values = values[:usable_values].reshape(8, -1)
            bins = values.shape[1]
            freq = np.linspace(0.0, sample_rate/2.0, bins, endpoint=False, dtype=float)
            channels = [np.abs(values[ch]).astype(float, copy=True) for ch in range(8)]
            result.frames.append(CpcHydrophoneFrame(frame_index, freq, channels))

        # Build one stable reference per channel across the complete sonication.
        # The raw CPC amplitude scale is still proprietary and can differ by many
        # orders of magnitude between diagnostic channel interpretations.  For the
        # popup we therefore preserve raw values internally, but display every CH
        # as relative dB using its own sonication-wide reference.  This gives all
        # eight panels the same fixed -60..0 dB scale while retaining temporal and
        # spectral shape changes needed to see sub/ultra-harmonic and broadband
        # cavitation components.
        references: list[float] = []
        for ch in range(8):
            frame_levels: list[float] = []
            for frame in result.frames:
                amplitude = np.asarray(frame.channels[ch], dtype=float)
                frequency = np.asarray(frame.frequency_hz, dtype=float)
                mask = (
                    np.isfinite(amplitude)
                    & (amplitude > 0.0)
                    & np.isfinite(frequency)
                    & (frequency >= 50_000.0)
                    & (frequency <= 1_000_000.0)
                )
                selected = amplitude[mask]
                if selected.size:
                    frame_levels.append(float(np.percentile(selected, 99.5)))
            valid = np.asarray([v for v in frame_levels if np.isfinite(v) and v > 0.0], dtype=float)
            reference = float(np.median(valid)) if valid.size else 1.0
            references.append(max(reference, np.finfo(float).tiny))
        result.channel_reference_levels = references
        result.note = (
            'CPCFiles independent 8-channel view. Header-confirmed CH count=8. '
            'Payload channel order/amplitude scaling are diagnostic until the proprietary record schema is fully verified; '
            'physical hydrophone position is not assigned. Display uses a fixed common -60..0 dB range; each CH is normalized to a stable sonication-wide reference so cavitation components remain visible.'
        )
        return result
