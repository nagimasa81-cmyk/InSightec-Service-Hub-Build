from pathlib import Path


def test_vendor_tab_protects_chart_visibility_and_usability():
    text = Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    assert "chart_row = QHBoxLayout()" in text
    assert "self.vendor_energy_plot.setMinimumHeight(220)" in text
    assert "self.vendor_rule_plot.setMinimumHeight(220)" in text
    assert "self.vendor_power_plot.setMinimumHeight(250)" in text
    assert "Control overview" in text
    assert "Selected hydrophone" in text
    assert "All 8 hydrophones" in text
    assert "Smooth 100 ms" in text
    assert "Sync cursor" in text
