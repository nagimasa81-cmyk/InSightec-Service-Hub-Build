from pathlib import Path


def test_main_window_arrow_shortcuts_are_child_focus_safe():
    text = Path("src/ui/main_window.py").read_text(encoding="utf-8")
    assert "WidgetWithChildrenShortcut" in text
    assert "Qt.Key.Key_Up" in text
    assert "Qt.Key.Key_Down" in text
    assert "self.previous_frame" in text
    assert "self.next_frame" in text


def test_hydrophone_window_arrow_shortcuts_are_child_focus_safe():
    text = Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    assert "WidgetWithChildrenShortcut" in text
    assert "Qt.Key.Key_Up" in text
    assert "Qt.Key.Key_Down" in text
    assert "self.set_frame(self.frame_index + d)" in text
