import numpy as np
from src.services.cavitation_likelihood_service import CavitationLikelihoodService


def test_default_hydrophone_clock_geometry():
    p = CavitationLikelihoodService.DEFAULT_POSITIONS
    assert p.shape == (8, 2)
    # CH0 1:00, CH1 4:00, CH2 7:00, CH3 11:00
    assert p[0,0] > 0 and p[0,1] > 0
    assert p[1,0] > 0 and p[1,1] < 0
    assert p[2,0] < 0 and p[2,1] < 0
    assert p[3,0] < 0 and p[3,1] > 0
    # CH4 2:00, CH5 3:30, CH6 8:00, CH7 10:00
    assert p[4,0] > 0 and p[4,1] > 0
    assert p[5,0] > 0 and p[5,1] < 0
    assert p[6,0] < 0 and p[6,1] < 0
    assert p[7,0] < 0 and p[7,1] > 0
    assert np.allclose(np.linalg.norm(p, axis=1), 1.0, atol=1e-6)
