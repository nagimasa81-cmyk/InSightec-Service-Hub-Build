from pathlib import Path


def test_vendor_tab_protects_chart_visibility():
    text = Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    assert "chart_row = QHBoxLayout()" in text
    assert "self.vendor_energy_plot.setMinimumHeight(175)" in text
    assert "self.vendor_rule_plot.setMinimumHeight(175)" in text
    assert "self.vendor_power_plot.setMinimumHeight(180)" in text
    assert "self.vendor_band_table.setMaximumHeight(112)" in text
    assert "self.vendor_control_table.setMaximumHeight(112)" in text
