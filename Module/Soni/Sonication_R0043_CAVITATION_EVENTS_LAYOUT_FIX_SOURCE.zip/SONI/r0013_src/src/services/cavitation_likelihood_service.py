from __future__ import annotations

from dataclasses import dataclass
import math
import numpy as np

from src.services.hydrophone_replay_service import CpcHydrophoneReplay


@dataclass(slots=True)
class CavitationLikelihoodResult:
    likelihood_map: np.ndarray
    x_coords: np.ndarray
    y_coords: np.ndarray
    hydrophone_positions: np.ndarray
    focus_xy: tuple[float, float]
    per_channel_scores: np.ndarray
    dominant_channel: int | None
    centroid_xy: tuple[float, float] | None
    summary: str
    evidence: str


class CavitationLikelihoodService:
    """Estimate a probable cavitation region from hydrophone contributions.

    This is an evidence-first visualization aid, not a deterministic locator.
    It creates a 2D likelihood field from the dominant/contributing hydrophone
    pattern, biases the field toward the focus, and reports the probable region
    relative to the focus.
    """

    # Schematic 8CH receiver ring around the sonication focus.  The exact site
    # geometry can be swapped later without changing the UI contract.
    # Default physical angular layout previously supplied for XD 7029.
    # Clock positions: CH0=1:00, CH1=4:00, CH2=7:00, CH3=11:00,
    # CH4=2:00, CH5=3:30, CH6=8:00, CH7=10:00.
    # Coordinates are normalized to the receiver ring and are intended for
    # directional likelihood visualization; patient-space registration is
    # applied separately when real image/world transforms are available.
    DEFAULT_POSITIONS = np.asarray([
        ( 0.50,  0.8660254),   # CH0 / H1 — 1:00
        ( 0.8660254, -0.50),   # CH1 / H2 — 4:00
        (-0.50, -0.8660254),   # CH2 / H3 — 7:00
        (-0.50,  0.8660254),   # CH3 / H4 — 11:00
        ( 0.8660254,  0.50),   # CH4 / H5 — 2:00
        ( 0.9659258, -0.2588190), # CH5 / H6 — 3:30
        (-0.8660254, -0.50),   # CH6 / H7 — 8:00
        (-0.8660254,  0.50),   # CH7 / H8 — 10:00
    ], dtype=float)
    FOCUS_XY = (0.0, 0.0)

    def _rule_weights(self, replay: CpcHydrophoneReplay, family: str, rule_index: int) -> np.ndarray | None:
        profile = getattr(replay, 'vendor_profile', None)
        if profile is None:
            return None
        if family == 'Increase' and rule_index == 0 and profile.increase_rule0 is not None:
            return np.asarray(profile.increase_rule0.weights, float)
        if family == 'Decrease':
            rule = profile.decrease_rules.get(rule_index)
            return None if rule is None else np.asarray(rule.weights, float)
        if family == 'Safety':
            rule = profile.safety_rules.get(rule_index)
            return None if rule is None else np.asarray(rule.weights, float)
        if family == 'Dynamic':
            rule = profile.dynamic_rules.get(rule_index)
            return None if rule is None else np.asarray(rule.weights, float)
        return None

    def _frame_by_cycle(self, replay: CpcHydrophoneReplay, cycle: int | None):
        if cycle is None:
            return None
        for frame in replay.frames:
            if getattr(frame, 'acquisition_cycle', None) == cycle:
                return frame
        return None

    def _scores_from_event(self, replay: CpcHydrophoneReplay, event) -> tuple[np.ndarray, str]:
        frame = self._frame_by_cycle(replay, getattr(event, 'cycle', None))
        if frame is None or np.asarray(frame.vendor_band_energies).shape != (8, 4):
            return np.zeros(8, float), 'No matching FFT snapshot for the observed event.'
        energies = np.asarray(frame.vendor_band_energies, float)
        weights = self._rule_weights(replay, getattr(event, 'family', ''), int(getattr(event, 'rule_index', -1)))
        if weights is not None and weights.shape == (8, 4):
            scores = np.sum(energies * np.maximum(weights, 0.0), axis=1)
            evidence = f"Observed {event.family} rule {event.rule_index} at cycle {event.cycle}; weighted by vendor rule coefficients."
            return scores, evidence
        channels = tuple(getattr(event, 'contributing_channels', ()) or ())
        bands = tuple(getattr(event, 'contributing_bands', ()) or ())
        if channels and bands:
            scores = np.zeros(8, float)
            for ch in channels:
                scores[ch] = float(np.sum(energies[ch, list(bands)]))
            evidence = f"Observed {event.family} rule {event.rule_index} at cycle {event.cycle}; summed across contributing hydrophones/bands."
            return scores, evidence
        # fallback to dominant hydrophone only
        scores = np.zeros(8, float)
        dom = getattr(event, 'dominant_channel', None)
        if dom is not None:
            scores[int(dom)] = float(getattr(event, 'dominant_energy', 1.0) or 1.0)
            evidence = f"Observed {event.family} rule {event.rule_index}; dominant hydrophone emphasis fallback."
            return scores, evidence
        return np.sum(energies, axis=1), 'Observed event could not be matched to rule weights; using summed per-channel energy.'

    def _scores_from_frame(self, replay: CpcHydrophoneReplay, frame_index: int) -> tuple[np.ndarray, str]:
        if not replay.frames or not (0 <= frame_index < len(replay.frames)):
            return np.zeros(8, float), 'No current FFT snapshot.'
        frame = replay.frames[frame_index]
        if np.asarray(frame.vendor_band_energies).shape == (8, 4):
            scores = np.max(np.asarray(frame.vendor_band_energies, float), axis=1)
            cyc = getattr(frame, 'acquisition_cycle', None)
            cyc_txt = f' (cycle {cyc})' if cyc is not None else ''
            return scores, f'Dump-only estimate from FFT snapshot {frame_index+1}{cyc_txt}; per-channel maximum Band0–3 energy.'
        return np.zeros(8, float), 'Vendor Band0–3 energies are unavailable in this FFT snapshot.'

    @staticmethod
    def _normalize_scores(scores: np.ndarray) -> np.ndarray:
        scores = np.asarray(scores, float)
        scores = np.where(np.isfinite(scores) & (scores > 0), scores, 0.0)
        total = float(np.sum(scores))
        return (scores / total) if total > 0 else scores

    @staticmethod
    def _region_text(point: tuple[float, float] | None) -> str:
        if point is None:
            return 'undetermined'
        x, y = point
        horiz = 'right' if x > 0.12 else 'left' if x < -0.12 else 'central'
        vert = 'anterior' if y > 0.12 else 'posterior' if y < -0.12 else 'central'
        if horiz == 'central' and vert == 'central':
            return 'central near focus'
        if horiz == 'central':
            return vert
        if vert == 'central':
            return horiz
        return f'{vert}-{horiz}'

    def _build_map(self, norm_scores: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, tuple[float, float] | None]:
        n = 220
        xs = np.linspace(-1.05, 1.05, n)
        ys = np.linspace(-1.05, 1.05, n)
        xx, yy = np.meshgrid(xs, ys)
        field = np.zeros_like(xx, dtype=float)
        focus = np.asarray(self.FOCUS_XY, float)
        positions = np.asarray(self.DEFAULT_POSITIONS, float)
        for ch, weight in enumerate(norm_scores):
            if weight <= 0:
                continue
            p = positions[ch]
            v = focus - p
            length = float(np.linalg.norm(v))
            if length <= 1e-8:
                continue
            u = v / length
            dx = xx - p[0]
            dy = yy - p[1]
            proj = (dx * u[0] + dy * u[1]) / length
            perp = np.abs(dx * u[1] - dy * u[0])
            longitudinal = np.exp(-0.5 * ((proj - 0.72) / 0.26) ** 2)
            radial = np.exp(-0.5 * (perp / 0.12) ** 2)
            gate = (proj >= 0.0) & (proj <= 1.20)
            field += weight * longitudinal * radial * gate
        focus_prior = np.exp(-0.5 * (((xx - focus[0]) ** 2 + (yy - focus[1]) ** 2) / (0.18 ** 2)))
        field += 0.35 * focus_prior * float(np.sum(norm_scores > 0)) / max(1, len(norm_scores))
        maxv = float(np.max(field)) if field.size else 0.0
        if maxv > 0:
            field /= maxv
        total = float(np.sum(field))
        centroid = None
        if total > 0:
            centroid = (float(np.sum(field * xx) / total), float(np.sum(field * yy) / total))
        return field, xs, ys, centroid

    def estimate(self, replay: CpcHydrophoneReplay, frame_index: int, observed_event=None) -> CavitationLikelihoodResult:
        if observed_event is not None:
            scores, evidence = self._scores_from_event(replay, observed_event)
        else:
            scores, evidence = self._scores_from_frame(replay, frame_index)
        norm_scores = self._normalize_scores(scores)
        field, xs, ys, centroid = self._build_map(norm_scores)
        dominant = int(np.argmax(norm_scores)) if np.any(norm_scores > 0) else None
        contrib_txt = ', '.join(f"H{idx+1} {100*v:.1f}%" for idx, v in enumerate(norm_scores) if v > 0.01)
        dom_txt = f"H{dominant+1}" if dominant is not None else 'none'
        region = self._region_text(centroid)
        summary = f"Dominant hydrophone: {dom_txt}. Probable cavitation region: {region}. Contributors: {contrib_txt or 'none'}"
        return CavitationLikelihoodResult(
            likelihood_map=field,
            x_coords=xs,
            y_coords=ys,
            hydrophone_positions=np.asarray(self.DEFAULT_POSITIONS, float),
            focus_xy=self.FOCUS_XY,
            per_channel_scores=norm_scores,
            dominant_channel=dominant,
            centroid_xy=centroid,
            summary=summary,
            evidence=evidence,
        )
