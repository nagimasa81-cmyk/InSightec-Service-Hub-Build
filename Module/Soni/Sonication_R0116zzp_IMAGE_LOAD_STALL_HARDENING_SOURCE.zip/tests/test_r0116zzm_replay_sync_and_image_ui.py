from pathlib import Path
ROOT=Path(__file__).parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYD=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
IMG=(ROOT/'src/ui/image_panel.py').read_text(encoding='utf-8')

def test_temperature_progressive_uses_irradiation_relative_axis():
    assert 'temp_axis = np.asarray(getattr(self, "_temperature_time_axis_s", []), float)' in MAIN
    assert 'temp_src = np.asarray(getattr(self, "_temperature_source_indices", []), int)' in MAIN
    assert 'current_rel_s = max(0.0, current_abs_s - irradiation_start)' in MAIN

def test_spectrum_time_origin_distinguishes_cpc_and_spectrummsg():
    assert 'if "cpc" not in source_kind:' in MAIN
    assert 'target_time = float(replay_time_s) - irradiation_start' in MAIN

def test_time_charts_click_back_to_replay():
    assert 'sigMouseClicked.connect(self._temperature_plot_clicked)' in MAIN
    assert 'sigMouseClicked.connect(self._acoustic_plot_clicked)' in MAIN
    assert 'sigMouseClicked.connect(self._waterfall_plot_clicked)' in MAIN
    assert 'sigMouseClicked.connect(self._cavitation_plot_clicked)' in MAIN

def test_analyzer_dynamic_vertical_budget_and_replay_access():
    assert 'def _fit_tab_vertical_budget' in HYD
    assert 'outer.addLayout(controls)' in HYD
    assert 'self.cavitation_control_plot.setMinimumHeight(0)' in HYD
    assert 'self.band_plot.setMaximumHeight(16777215)' in HYD

def test_probable_location_projects_on_nearest_treatment_mr():
    assert 'def _probable_reference_image' in HYD
    assert 'nearest Treatment MR' in HYD
    assert 'self.cavitation_likelihood_overlay' in HYD

def test_main_image_two_visible_rows_red_fill_ruler_and_4mm_roi():
    assert 'visible_rows=(("Thermal + red region"' in MAIN
    assert '("Selected image",self.anatomy_type_combo,self.anatomy_frame_list)' in MAIN
    assert 'solid_red_fill=True' not in MAIN  # call is conditional, not hard-coded
    assert 'solid_red_fill=bool(shown is not None and not investigation)' in MAIN
    assert 'def set_mm_per_pixel' in IMG
    assert '4.0/self._mm_per_pixel' in IMG
    assert '1 mm ticks' in IMG
    assert '#7CFC00' in IMG

def test_red_threshold_refreshes_main_and_thermal_thumbnails():
    block=MAIN.split('def _threshold_changed',1)[1].split('def _overlay_cursor_moved',1)[0]
    assert '_apply_ready_thumbnail_to_visible_items("treatment_thermal"' in block
    assert 'self.set_frame(self.frame_index)' in block
