from pathlib import Path
import ast

ROOT=Path(__file__).parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
REPLAY=(ROOT/'src/services/replay_service.py').read_text(encoding='utf-8')
TREE=ast.parse(MAIN)
MW=next(n for n in TREE.body if isinstance(n,ast.ClassDef) and n.name=='MainWindow')
METHODS={n.name:n for n in MW.body if isinstance(n,ast.FunctionDef)}

def method_source(name):
    fn=METHODS[name]
    lines=MAIN.splitlines()
    return '\n'.join(lines[fn.lineno-1:fn.end_lineno])

def test_control_is_load_images_and_default_off():
    assert 'QCheckBox("Load images")' in MAIN
    assert 'self.load_images_toggle.setChecked(False)' in MAIN
    assert 'self.no_image_toggle' not in MAIN

def test_gate_semantics_are_not_inverted():
    src=method_source('_image_loading_enabled')
    assert 'getattr(self,"load_images_toggle",None)' in src
    assert 'toggle.isChecked()' in src

def test_both_thumbnail_starters_return_when_off():
    for name in ('_start_image_thumbnail_background','_start_thermal_thumbnail_background'):
        src=method_source(name)
        assert 'if not self._image_loading_enabled()' in src
        assert 'return' in src

def test_stale_worker_results_are_rejected_when_off():
    for name in ('_image_thumbnail_ready','_image_thumbnail_finished',
                 '_thermal_thumbnail_ready','_thermal_thumbnail_finished'):
        src=method_source(name)
        first='\n'.join(src.splitlines()[:6])
        assert 'if not self._image_loading_enabled()' in first

def test_off_invalidates_worker_generations_and_clears():
    src=method_source('_clear_image_ui_for_load_images_off')
    assert '_thermal_thumbnail_generation' in src
    assert '_image_thumbnail_generation' in src
    assert '_cancel_thermal_thumbnail_worker()' in src
    assert '_cancel_image_thumbnail_workers()' in src
    assert '_thermal_thumbnail_cache={}' in src
    assert '_treatment_mr_thumbnail_cache={}' in src
    assert 'strip.clear()' in src

def test_build_navigator_does_not_schedule_when_off():
    src=method_source('_build_frame_navigator')
    assert 'if self._image_loading_enabled()' in src
    assert '_start_image_thumbnail_background' in src
    assert '_start_thermal_thumbnail_background' in src
    assert '_rebuild_all_image_strips()' not in src

def test_replay_off_path_has_no_image_raw_reads():
    assert 'decode_images=False' in MAIN
    block=REPLAY.split('if not decode_images:',1)[1].split('source, reference_temp',1)[0]
    assert 'read_magnitude' not in block
    assert 'read_temperature' not in block
    assert '_baseline(' not in block

def test_registration_requires_images():
    assert 'main_is_mr and self._image_loading_enabled()' in MAIN

def test_no_duplicate_mainwindow_methods():
    seen=set()
    for n in MW.body:
        if isinstance(n,ast.FunctionDef):
            assert n.name not in seen, n.name
            seen.add(n.name)
