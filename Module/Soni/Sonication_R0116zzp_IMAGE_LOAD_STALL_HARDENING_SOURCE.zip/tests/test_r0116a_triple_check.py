from pathlib import Path
import ast, json
ROOT=Path(__file__).parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYD=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
LIKE=(ROOT/'src/services/cavitation_likelihood_service.py').read_text(encoding='utf-8')
CAL=(ROOT/'src/services/hydrophone_calibration_service.py').read_text(encoding='utf-8')

def test_versions_agree():
    v=json.loads((ROOT/'version.json').read_text(encoding='utf-8'))['version']
    assert (ROOT/'VERSION').read_text().strip()==v
    assert f'APP_VERSION = "{v}"' in (ROOT/'src/common/constants.py').read_text(encoding='utf-8')

def test_main_rcv_optin_exists_and_defaults_off():
    assert 'self.show_disabled_rcv_action = QAction("Show disabled RCV"' in MAIN
    assert 'self.show_disabled_rcv_action.setCheckable(True); self.show_disabled_rcv_action.setChecked(False)' in MAIN
    assert 'self.show_disabled_rcv_action.toggled.connect(self._main_disabled_rcv_visibility_changed)' in MAIN

def test_main_selected_channel_state_cannot_keep_hidden_disabled_rcv():
    assert 'visible_names=set(self.channel_actions)' in MAIN
    assert 'self.chart_state.selected_channels=set(previous)' in MAIN

def test_hydro_rcv_optin_exists_and_defaults_off():
    assert 'QCheckBox("Show disabled RCV")' in HYD
    assert 'self.show_disabled_receivers_check.setChecked(False)' in HYD
    assert 'def _visible_receivers' in HYD

def test_calibration_is_enabled_is_authoritative():
    assert 'IsEnabled' in CAL
    assert 'result.is_enabled=tuple(vals)' in CAL
    assert 'receiver_enabled' in LIKE
    assert 'calibration.ini disabled receivers excluded' in LIKE

def test_likelihood_ui_hides_disabled_markers_and_rows():
    assert 'visible=set(self._visible_receivers())' in HYD
    assert 'if ch not in visible:' in HYD
    assert 'filled = [ch for ch in range(8) if ch in visible]' in HYD

def test_thumbnail_is_index_slider_not_native_scrollbar_mirror():
    assert 'scroll=QSlider(Qt.Orientation.Horizontal)' in MAIN
    assert 'def _scroll_image_strip_to_index' in MAIN
    assert 'slider.setRange(0,max(0,count-1))' in MAIN
    assert 'QScrollBar(Qt.Orientation.Horizontal)' not in MAIN

def test_reference_cache_reuses_decoded_items():
    assert 'reference_sources=[]' in MAIN
    assert 'if key not in self._reference_thumbnail_cache' in MAIN
    assert 'QThread.Priority.LowPriority' in MAIN

def test_no_duplicate_methods_or_stale_backups():
    assert not list((ROOT/'src').rglob('*.py.bak'))
    for f in (ROOT/'src').rglob('*.py'):
        tree=ast.parse(f.read_text(encoding='utf-8'))
        for node in ast.walk(tree):
            if isinstance(node,ast.ClassDef):
                seen=set()
                for item in node.body:
                    if isinstance(item,(ast.FunctionDef,ast.AsyncFunctionDef)):
                        assert item.name not in seen, f'duplicate {f}:{node.name}.{item.name}'
                        seen.add(item.name)
