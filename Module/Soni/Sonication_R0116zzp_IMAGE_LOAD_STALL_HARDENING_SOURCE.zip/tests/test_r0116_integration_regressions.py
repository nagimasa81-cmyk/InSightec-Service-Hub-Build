
from pathlib import Path
ROOT=Path(__file__).parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYD=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
STAND=(ROOT/'src/services/standalone_cavitation_service.py').read_text(encoding='utf-8')
REG=(ROOT/'src/services/registration_overlay_service.py').read_text(encoding='utf-8')

def test_real_index_slider_replaces_mirrored_scrollbar():
    block=MAIN.split('Treatment Images',1)[1].split('registration_toggle_btn',1)[0]
    assert 'scroll=QSlider(Qt.Orientation.Horizontal)' in block
    assert 'QScrollBar(Qt.Orientation.Horizontal)' not in block
    assert 'def _scroll_image_strip_to_index' in MAIN
    assert 'slider.setRange(0,max(0,count-1))' in MAIN

def test_thumbnail_cache_and_low_priority():
    assert 'reference_sources=[]' in MAIN
    assert 'if key not in self._reference_thumbnail_cache' in MAIN
    assert 'QThread.Priority.LowPriority' in MAIN
    assert '_start_image_thumbnail_background' in MAIN
    assert '_start_incremental_image_strip_build' in MAIN

def test_calibration_is_authoritative_disable():
    assert 'HydrophoneCalibrationService().read(Path(self.package.workspace))' in HYD
    assert 'self.replay.receiver_enabled=tuple(bool(v) for v in calibration.is_enabled)' in HYD
    assert 'visible_receivers=set(self._visible_receivers())' in HYD
    assert 'if ch not in visible_receivers' in HYD
    assert 'cube[:,~enabled[:8],:]=np.nan' in STAND
    assert 'calibration=getattr(self,"hydrophone_calibration",None)' in MAIN

def test_3d_focus_uses_same_camera():
    assert 'def _umbrella_project_points' in MAIN
    assert 'Focus uses the identical physical camera' in MAIN
    assert 'Reference focus' in MAIN and 'Phase focus' in MAIN
    assert 'reference_focus=exported_focal if exported_focal is not None else fitted_focus' in MAIN

def test_registration_display_is_outer_shell_only_but_qa_full():
    assert 'def _outer_skull_display_overlay' in REG
    assert 'display=outer skull envelope' in REG
    # QA is computed before the display-only filter.
    assert REG.index('edge_score=self._alignment_score(mr,overlay)') < REG.index('display_overlay=self._outer_skull_display_overlay')
