# COMMIT R0187 — Fresh series-common DQA alignment

- DQA focus alignment is calculated once per completed Summary series, never inside individual Sonication row workers.
- The DQA alignment service cache is explicitly cleared immediately before the final series-common calculation.
- Cache key is contract-versioned (`r0187::series::...`).
- Result carries calculator contract and explicit reference/focal geometry evidence.
- Coordinate contract remains: registered unsteered focalRAS minus Axial phantom-circle XY / Sagittal lower-line +20 mm Z.
- Screenshot/version provenance can now distinguish R0187 from older R0185/R0186 builds.
