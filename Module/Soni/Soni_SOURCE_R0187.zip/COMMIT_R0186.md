# COMMIT R0186 — DQA registered-focus coordinate-frame correction

- DQA Locate Transducer focal remains the physical common-focus evidence.
- Workstation Locate focal XYZ is not directly subtracted from MR phantom RAS geometry.
- For unsteered DQA centre shots, SonicationSummary focalRAS is used as the registered MR-RAS representation of the common focus.
- Reference X/Y = DQA-Axial phantom circle center.
- Reference Z = DQA-Sagittal lower phantom line +20.0 mm.
- Delta XYZ = registered common focal RAS - reference RAS.
- Added image-stack geometry compatibility gate using per-slice MriImageParams rows.
- Added sagittal cross-check evidence: lower-line to registered focal distance and residual after +20 mm reference offset.
- Locate XYZ and MR-RAS are kept as separate coordinate domains.
