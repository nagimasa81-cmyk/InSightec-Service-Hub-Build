# TRIPLE CHECK R0186

1. Coordinate-domain separation
   - Locate focal XYZ = physical/workstation evidence only.
   - registered focalRAS = MR-RAS value used for DQA image comparison.
   - direct cross-frame subtraction is prohibited.

2. DQA reference
   - X/Y = Axial phantom-circle center.
   - Z = Sagittal lower phantom line +20.0 mm.
   - Delta = registered focalRAS - reference.

3. Geometry validation
   - focalRAS must project compatibly into both Axial and Sagittal DQA stacks.
   - validation checks all per-slice MriImageParams rows, not one arbitrary slice.
   - mismatch fails closed.

4. Regression
   - R0154 DQA + R0167-R0186 related regression suite PASS.
   - compileall and verify_source run before packaging.
