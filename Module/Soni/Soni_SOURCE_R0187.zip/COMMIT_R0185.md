# COMMIT R0185 — DQA fixed-focus reference + duplicate Spectrum mode cleanup

## DQA focus alignment
- DQA mechanical focal point is the last Locate Transducer focal point before the first DQA sonication.
- Reference point:
  - X/Y = DQA-Axial phantom circle center
  - Z = DQA-Sagittal lower phantom line + 20.0 mm inward
- DQA displacement = Focal - Reference independently for X/Y/Z.
- Tilt remains the Sagittal lower-line angle.
- Per-sonication thermal hotspot/planned focalRAS medians are no longer the DQA series zero point.
- Material electronic steering changes exclude the center-alignment judgement rather than changing the physical focal point.

## Duplicate/empty display cleanup
- Removed user-selectable Main-window `Vendor band energy reproduction` mode.
- Stopped its duplicate redraw/computation path.
- Spectrum Dump Analyzer remains authoritative for band-energy reproduction.
- Cross-cutting mode audit: all QComboBox display selectors in Main and Spectrum Dump Analyzer have signal handlers; no other orphan selector was found.
- Source-domain unavailable panels (e.g. physical RCV/raw A/D absent in SpectrumMsg aggregate) remain fail-closed by design.
