# TRIPLE CHECK R0185

1. DQA semantics
   - Focal = Locate Transducer focal point.
   - Reference XY = Axial phantom-circle center.
   - Reference Z = Sagittal lower line +20.0 mm.
   - Delta = Focal - Reference.
   - Tilt independent.
   - Steering changes => not judged.

2. Display-mode ownership
   - Main-window Vendor band energy mode removed.
   - Main-window duplicate vendor-band redraw disabled.
   - Spectrum Dump Analyzer remains authoritative.

3. Orphan-mode audit
   - Main QComboBox selectors checked for items, signal binding, and references.
   - Spectrum Dump Analyzer QComboBox selectors checked likewise.
   - No unbound/low-reference selectable display mode found.

4. Regression
   - DQA/CI focused suite and R0167-R0185 related suite pass.
   - compileall PASS.
   - verify_source.py PASS.
