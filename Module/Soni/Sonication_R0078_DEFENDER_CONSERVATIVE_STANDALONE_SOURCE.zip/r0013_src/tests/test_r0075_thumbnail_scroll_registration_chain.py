from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
REG=(ROOT/'src/services/registration_overlay_service.py').read_text(encoding='utf-8')

def test_explicit_thumbnail_scrollbar_present():
    assert 'QScrollBar(Qt.Orientation.Horizontal)' in MAIN
    assert 'self.image_strip_scrollbars' in MAIN
    assert 'scroll.valueChanged.connect(native.setValue)' in MAIN

def test_preplanning_registration_hypotheses_are_used():
    assert 'hypotheses=self._registration_hypotheses' in REG
    assert "target_kind='Preplanning MR chain'" in REG
    assert 'inv(MrMr) × CtMr' in REG
