from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HYDRO = (ROOT / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')


def test_current_control_time_defines_cycle_and_cycles_before_use():
    """Regression guard for a real bug introduced by R0159 itself (found
    via an independent triple-check, not by this session): replacing the
    old physical-frame clamp with self._physical_frame_index() accidentally
    deleted the `cycle=...`/`cycles=...` assignment lines that used to sit
    right after the frame lookup, while the code below that still reads
    both names (`if cycle is not None and cycles.size ...`). This produced
    an uncaught NameError the first time this function actually ran (any
    time an observed cavitation timeline exists), not merely a domain
    mismatch."""
    block = HYDRO.split('def _current_control_time', 1)[1].split('\n\n    def ', 1)[0]
    assert 'cycle=getattr(frame,"acquisition_cycle",None)' in block
    assert 'cycles=np.asarray(getattr(timeline,"actual_power_cycles"' in block
    # The assignments must appear before the first use of either name.
    frame_pos = block.index('frame=self.replay.frames[self._physical_frame_index()]')
    cycle_def_pos = block.index('cycle=getattr(frame,"acquisition_cycle",None)')
    first_use_pos = block.index('if cycle is not None and cycles.size')
    assert frame_pos < cycle_def_pos < first_use_pos


def test_observed_event_highlight_defines_cycle_before_use():
    block = HYDRO.split('self.observed_cavitation_timeline = cache.get("observed_cavitation_timeline")', 1)[1][:600]
    assert 'cycle = getattr(frame, "acquisition_cycle", None)' in block
    cycle_def_pos = block.index('cycle = getattr(frame, "acquisition_cycle", None)')
    first_use_pos = block.index('if cycle is not None:')
    assert cycle_def_pos < first_use_pos


def test_cursor_to_physical_mapping_remains_time_based():
    """Cross-check against an independently-authored triple-check of the
    same R0159 regression: _physical_frame_index() itself must stay a
    genuine nearest-time lookup (st[self.frame_index] against the
    spectral/aggregate replay's own time axis), not regress back to a
    linear clamp."""
    block = HYDRO.split('def _physical_frame_index', 1)[1].split('\n\n    def ', 1)[0]
    assert 'mr_frame_times_s' in block
    assert 'np.argmin' in block
    assert 'st[self.frame_index]' in block
