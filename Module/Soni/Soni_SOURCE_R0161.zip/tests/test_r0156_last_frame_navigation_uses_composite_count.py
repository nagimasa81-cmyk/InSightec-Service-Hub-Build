from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HYDRO = (ROOT / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')


def test_last_button_and_end_key_use_cursor_frame_count_not_physical_frames():
    """Regression guard for a real bug found against 220/230 kHz (Brain220)
    data: a composite Sonication has a short physical CPC replay (e.g. 18
    frames covering ~0.17 s, limited by the CPC's own ~15 s dump rollover)
    alongside a much longer Sonication-owned SpectrumMsg spectral replay
    (e.g. 75-192 frames covering the full Sonication). The Analyzer's frame
    cursor/slider is correctly driven by _cursor_frame_count() (which
    prefers the spectral/aggregate replay -- see _spectral_replay()), but
    the "Last" button and the End key jumped straight to
    `len(self.replay.frames)-1` (the *physical* replay's short frame
    count) instead. set_frame() clamps whatever index it receives to
    _cursor_frame_count()-1, so on 650 kHz data (no spectral_replay,
    physical IS the cursor source) this was harmless -- but on 220/230 kHz
    composite data it meant "Last"/End could only ever reach frame 17 of
    74, stranding the user inside the first ~0.17 s of a much longer
    Sonication with no way to jump to its actual end.
    """
    assert 'self.last_btn.clicked.connect(lambda: self.set_frame(self._cursor_frame_count()-1))' in HYDRO
    assert 'last.activated.connect(lambda: self.set_frame(self._cursor_frame_count()-1))' in HYDRO
    end_key_block = HYDRO.split('if key == Qt.Key.Key_End:', 1)[1][:200]
    assert 'self.set_frame(self._cursor_frame_count()-1)' in end_key_block
    # The old physical-only pattern must be gone from all three sites.
    assert 'self.set_frame(len(self.replay.frames)-1' not in HYDRO


def test_cursor_frame_count_prefers_the_spectral_aggregate_replay():
    block = HYDRO.split('def _cursor_frame_count', 1)[1].split('\n\n    def ', 1)[0]
    assert 'self._spectral_replay()' in block
    spectral_block = HYDRO.split('def _spectral_replay', 1)[1].split('\n\n    def ', 1)[0]
    assert 'spectral_replay' in spectral_block
