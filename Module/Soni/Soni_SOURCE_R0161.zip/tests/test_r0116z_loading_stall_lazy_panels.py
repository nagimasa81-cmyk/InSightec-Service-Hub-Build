from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SRC=(ROOT/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_91_percent_stage_is_cheap():
    block=SRC.split("def _selected_stage_metadata(self):",1)[1].split("def _highest_average_frame",1)[0]
    assert ("_update_sonication_metadata_fast()" in block or "_update_sonication_metadata()" in block)
    assert "_update_sonication_elements_page()" not in block
    assert "_update_cavitation_intelligence_page()" not in block
    assert "_refresh_engineering_analysis()" not in block
    assert "diagnostics_tab.select_sonication" not in block

def test_heavy_panels_are_lazy_tab_refreshes():
    block=SRC.split("def _main_tab_changed",1)[1].split("def _seed_sonication_summary_fast",1)[0]
    assert "_update_cavitation_intelligence_page()" in block
    assert "_update_sonication_elements_page()" in block
    assert "_refresh_engineering_analysis()" in block
    assert "diagnostics_tab.select_sonication" in block

def test_combo_change_does_not_double_refresh():
    block=SRC.split("def _sonication_combo_changed",1)[1].split("def _change_sonication",1)[0]
    assert "_select_sonication_index(index)" in block
    assert "_refresh_all_sonication_dependent_views()" not in block
