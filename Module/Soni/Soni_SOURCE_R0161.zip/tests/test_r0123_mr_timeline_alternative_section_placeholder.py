import configparser
from pathlib import Path
from types import SimpleNamespace

from src.services.mr_timeline_service import MRTimelineService


def _protocol_ini_with_placeholder_alternative_section(tmp_path: Path) -> Path:
    """Mirrors the real BrainSVATProtocolSiemens.ini structure that exposed
    this bug: the selected protocol section has no PreSonicateNum of its
    own and instead points at [PSD@$PSDType], a template that must be
    resolved using PSDType from the *same* section before it becomes a
    real, lookup-able section name."""
    ini_path = tmp_path / "BrainSVATProtocolSiemens.ini"
    ini_path.write_text(
        "[TMAP3-ME]\n"
        "AlternativeSection = PSD@$PSDType\n"
        "ScanTime = 3.8\n"
        "PSDType = SingleEcho\n"
        "\n"
        "[PSD@SingleEcho]\n"
        "PreSonicateNum = 2\n"
        "PostSonicateNum = 5\n",
        encoding="utf-8",
    )
    return ini_path


def test_placeholder_in_alternative_section_is_substituted_before_lookup(tmp_path):
    """Regression guard for the exact bug reported against real Brain650
    export data: AlternativeSection = PSD@$PSDType was being used as a
    literal, unresolved section name, so PreSonicateNum was never found and
    silently defaulted to 0 -- making every Sonication line up with MR
    acquisition start (t=0) instead of the true multi-second pre-sonication
    scan delay."""
    ini_path = _protocol_ini_with_placeholder_alternative_section(tmp_path)
    cp = configparser.ConfigParser(interpolation=None, strict=False)
    cp.optionxform = str
    cp.read(ini_path, encoding="utf-8")

    service = MRTimelineService()
    pre = service._protocol_pre_frames({"protocol": "TMAP3-ME"}, cp)
    assert pre == 2, "PreSonicateNum must resolve through the substituted alternative section"


def test_resolve_alternative_section_substitutes_dollar_placeholders():
    cp = configparser.ConfigParser(interpolation=None, strict=False)
    cp.optionxform = str
    cp.read_string("[TMAP3-ME]\nPSDType = SingleEcho\n")
    resolved = MRTimelineService._resolve_alternative_section(cp, "TMAP3-ME", "PSD@$PSDType")
    assert resolved == "PSD@SingleEcho"


def test_resolve_alternative_section_leaves_unresolvable_placeholder_untouched():
    """If the referenced key doesn't exist in the section, the template
    must be left as-is (so the subsequent has_section() check correctly
    reports "not found") rather than silently producing a wrong guess."""
    cp = configparser.ConfigParser(interpolation=None, strict=False)
    cp.optionxform = str
    cp.read_string("[TMAP3-ME]\n")
    resolved = MRTimelineService._resolve_alternative_section(cp, "TMAP3-ME", "PSD@$PSDType")
    assert resolved == "PSD@$PSDType"


def test_end_to_end_reconstructed_fallback_uses_the_resolved_pre_sonicate_count(tmp_path):
    """End-to-end through resolve_all(): with no WS/MRServer exact-clock
    logs present, the Reconstructed fallback must place Sonication start at
    PreSonicateNum * ScanTime seconds after MR acquisition start, not at
    t=0."""
    site_dir = tmp_path / "WSFiles" / "Site" / "SiteInifiles" / "SVATProtocols"
    site_dir.mkdir(parents=True)
    _protocol_ini_with_placeholder_alternative_section(site_dir)
    (tmp_path / "SonicationSummary.xml").write_text(
        '<?xml version="1.0"?><root>'
        '<row sonicationindex="1" protocol="TMAP3-ME" actualduration="12.99"/>'
        "</root>",
        encoding="utf-8",
    )
    son = SimpleNamespace(replay_frame_count=11, canonical_acquisition_session_index=None)
    timeline = MRTimelineService().resolve_all(tmp_path, [son])[0]
    assert timeline.confidence == "Reconstructed"
    assert abs(timeline.sonication_start_s - 7.6) < 1e-6, timeline.sonication_start_s
