from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HYDRO = (ROOT / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')


def test_all_frame_index_physical_lookups_use_physical_frame_index_helper():
    """Regression guard for a real bug found against 220/230 kHz composite
    Sonications: self.frame_index is a cursor/spectral-domain index (see
    R0156/R0157), sampled at the spectral replay's own interval (e.g.
    ~266 ms for a 75-frame SpectrumMsg spanning ~20 s). The physical CPC
    replay is sampled at ~10 ms and typically only covers a short window
    near Sonication start (limited by the CPC's own dump-rollover cadence).

    Several vendor/control-timeline cursor features used to index
    self.replay.frames directly with self.frame_index (clamped to the
    physical array's bounds), silently treating "spectral sample number N"
    as if it were "physical sample number N" -- these are sampled at very
    different rates, so this produced physical frames off by up to several
    seconds even for in-range indices, not just a frozen cursor past the
    physical array's short length. _physical_frame_index() (already used
    correctly by set_frame(), per R0156) finds the physical frame nearest
    the cursor's actual MR time and must be used everywhere a frame_index
    is translated into a physical replay.frames[] index.
    """
    stale_patterns = [
        'self.replay.frames[min(max(int(self.frame_index),0),len(self.replay.frames)-1)]',
        'self.replay.frames[min(max(self.frame_index, 0), len(self.replay.frames)-1)]',
        'self.replay.frames[min(max(self.frame_index,0),len(self.replay.frames)-1)]',
        'self.replay.frames[min(self.frame_index, len(self.replay.frames)-1)]',
        'self.replay.frames[self.frame_index] if self.replay.frames and self.frame_index < len(self.replay.frames) else None',
    ]
    for pattern in stale_patterns:
        assert pattern not in HYDRO, f"stale physical-index-by-frame_index pattern still present: {pattern!r}"

    # All five fixed call sites must now go through the shared helper.
    assert HYDRO.count('self.replay.frames[self._physical_frame_index()]') >= 4
    assert 'physical_index = self._physical_frame_index()' in HYDRO


def test_physical_frame_index_helper_is_time_based_not_a_linear_clamp():
    block = HYDRO.split('def _physical_frame_index', 1)[1].split('\n\n    def ', 1)[0]
    assert 'mr_frame_times_s' in block
    assert 'np.argmin' in block
