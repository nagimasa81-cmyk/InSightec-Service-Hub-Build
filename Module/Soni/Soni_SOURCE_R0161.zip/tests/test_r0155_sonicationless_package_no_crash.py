from pathlib import Path
from types import SimpleNamespace

from src.services.spectrum_evidence_repository import SpectrumEvidenceRepository


def test_replay_raises_clear_indexerror_for_sonicationless_package():
    """Real DQA/phantom 220 kHz Exports can have zero completed Sonications
    (SonicationSummary.xml/TreatSummary.csv have no data rows, only raw CPC
    Spectrum candidates). Any caller asking for the default Sonication index
    0 used to hit a bare `IndexError: list index out of range` from
    `list(...)[index]` with no explanation. It must now raise the same
    IndexError type (existing callers already catch/handle IndexError-class
    failures) but with a message that explains *why*."""
    package = SimpleNamespace(sonications=[], workspace=".")
    repo = SpectrumEvidenceRepository()
    try:
        repo.replay(package, 0)
    except IndexError as exc:
        message = str(exc)
        assert "0 completed Sonication" in message
        assert "DQA" in message
    else:
        raise AssertionError("expected IndexError for an out-of-range Sonication index")


def test_replay_still_raises_indexerror_when_index_exceeds_a_nonempty_list():
    package = SimpleNamespace(sonications=[SimpleNamespace(name="Sonication1")], workspace=".")
    repo = SpectrumEvidenceRepository()
    try:
        repo.replay(package, 5)
    except IndexError as exc:
        assert "1 completed Sonication" in str(exc)
    else:
        raise AssertionError("expected IndexError for index 5 with only 1 Sonication present")


def test_hydrophone_window_worker_guards_direct_sonication_indexing():
    """The SpectrumDecodeWorker.run() dual-source and CPC-only branches used
    to index self.package.sonications[self.sonication_index] directly,
    one line *before* ever reaching SpectrumEvidenceRepository.replay()'s
    own guard -- fixing only the repository method would have left this
    earlier, identical crash in place."""
    src = Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    block = src.split("class SpectrumDecodeWorker", 1)[1].split("\nclass ", 1)[0]
    assert "def _resolve_sonication(index: int):" in block
    assert "son=_resolve_sonication(self.sonication_index)" in block
    assert "son = _resolve_sonication(self.sonication_index)" in block
    # The old unguarded direct-index pattern must be gone from this class.
    assert "self.package.sonications[self.sonication_index]" not in block
