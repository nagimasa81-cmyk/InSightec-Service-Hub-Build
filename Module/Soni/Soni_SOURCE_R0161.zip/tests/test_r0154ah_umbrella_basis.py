import numpy as np

from src.ui.main_window import TransducerMapWidget


def test_native_positive_z_is_displayed_as_negative_z_once():
    points=np.asarray([[1.0,2.0,3.0],[-1.0,-2.0,-4.0]])
    converted=TransducerMapWidget._canonical_umbrella_points(points)
    np.testing.assert_allclose(converted,[[1.0,2.0,-3.0],[-1.0,-2.0,4.0]])
    np.testing.assert_allclose(points,[[1.0,2.0,3.0],[-1.0,-2.0,-4.0]])
