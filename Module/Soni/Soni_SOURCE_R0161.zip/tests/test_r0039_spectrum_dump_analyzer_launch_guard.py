from pathlib import Path
import ast


def test_hydrophone_window_has_no_placeholder_runtime_name():
    path = Path(__file__).parents[1] / "src" / "ui" / "hydrophone_window.py"
    source = path.read_text(encoding="utf-8")
    assert "PLACEHOLDER" not in source
    ast.parse(source)


def test_likelihood_label_is_populated():
    path = Path(__file__).parents[1] / "src" / "ui" / "hydrophone_window.py"
    source = path.read_text(encoding="utf-8")
    assert "self.cavitation_likelihood_label.setText(" in source
    assert "probable region, not a single-point localization" in source
