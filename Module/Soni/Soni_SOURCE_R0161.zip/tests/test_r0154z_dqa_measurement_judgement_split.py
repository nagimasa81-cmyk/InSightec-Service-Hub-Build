from pathlib import Path
from types import SimpleNamespace

from src.services.dqa_focus_alignment_service import DqaFocusAlignment, DqaFocusAlignmentService


def _pkg(tmp_path):
    return SimpleNamespace(
        workspace=tmp_path,
        source=tmp_path/'case.zip',
        main_frequency_hz=230000.0,
        sonications=[SimpleNamespace(sonication_number=1, canonical_steering_xyz=(4.0, 0.0, 0.0))],
    )


def test_220_steered_shot_keeps_numeric_measurement_but_is_not_judged(tmp_path: Path, monkeypatch):
    pkg=_pkg(tmp_path)
    svc=DqaFocusAlignmentService()
    monkeypatch.setattr(svc, 'is_dqa', lambda _p: True)
    monkeypatch.setattr(svc, '_dqa_reference_geometry', lambda _p: {'evidence': []})
    monkeypatch.setattr(svc, '_summary_focal_ras', lambda _p: {1:(0.0,0.0,0.0)})
    monkeypatch.setattr(svc, '_dqa_exclusion_reason', lambda _p,_n,_f: 'electronic steering')
    monkeypatch.setattr(svc, '_image_native_alignment', lambda _p,_f,_n: DqaFocusAlignment(x_mm=0.8,y_mm=-0.4,z_mm=0.2,tilt_deg=0.1,confidence='High'))

    out=svc.analyze(pkg,0)
    assert out.x_mm == 0.8 and out.y_mm == -0.4 and out.z_mm == 0.2
    assert out.judgement_excluded_reason == 'electronic steering'
    assert out.excluded_reason is None
    assert 'Not judged' in out.display
    assert not out.alert


def test_planned_focal_minus_phantom_is_never_a_dqa_measurement(tmp_path: Path, monkeypatch):
    pkg=_pkg(tmp_path)
    pkg.sonications[0].canonical_steering_xyz=(0.0,0.0,0.0)
    svc=DqaFocusAlignmentService()
    monkeypatch.setattr(svc, 'is_dqa', lambda _p: True)
    monkeypatch.setattr(svc, '_dqa_reference_geometry', lambda _p: {'center_ras':(10.0,20.0,30.0),'tilt_deg':0.3,'evidence':[]})
    monkeypatch.setattr(svc, '_summary_focal_ras', lambda _p: {1:(11.0,19.0,30.5)})
    monkeypatch.setattr(svc, '_dqa_exclusion_reason', lambda _p,_n,_f: None)
    monkeypatch.setattr(svc, '_image_native_alignment', lambda *_a,**_k: None)

    out=svc.analyze(pkg,0)
    assert out.excluded_reason == 'observed focus vs planned focus unavailable'
    assert out.x_mm is None and out.y_mm is None and out.z_mm is None
    assert 'planned-target evidence only' in ' '.join(out.evidence)
