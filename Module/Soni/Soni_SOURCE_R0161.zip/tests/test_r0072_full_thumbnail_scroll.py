from pathlib import Path
TEXT=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_secondary_image_dropdowns_removed_from_replay_navigator():
    assert 'planning_frame_combo' not in TEXT
    assert 'anatomy_frame_combo' not in TEXT
    assert 'thermal_frame_combo' not in TEXT

def test_thumbnail_strips_are_full_series_horizontal_scrollers():
    assert 'widget.setWrapping(False)' in TEXT
    assert 'QSlider(Qt.Orientation.Horizontal)' in TEXT
    assert 'def _scroll_image_strip_to_index' in TEXT
    assert 'scroll.setVisible(True)' in TEXT
    assert 'ScrollPerPixel' in TEXT
    assert 'image_strip_scrollbars' in TEXT

def test_planning_mr_ax_default_reference():
    assert 'self.planning_type_combo.setCurrentText("Planning MR All")' in TEXT
