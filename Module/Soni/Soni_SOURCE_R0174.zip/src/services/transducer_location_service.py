from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
import math
import re


_CLOCK_RE = re.compile(r"(?P<h>\d{2}):(?P<m>\d{2}):(?P<s>\d{2}):(?P<ms>\d{3})")
_FLOAT = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"
_XD_RE = re.compile(
    rf"Xd\s*loc\s*XYZ\s*:\s*\(?\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*\)?"
    rf"(?:\s*,?\s*roll\s*:\s*({_FLOAT}))?"
    rf"(?:\s*,?\s*pitch\s*:\s*({_FLOAT}))?"
    rf"(?:\s*,?\s*Steering\s*:\s*\(?\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*\)?)?",
    re.I,
)
_START_RE = re.compile(r"\[CGeneralSonicationLogic::StartSonicate\]\s*Sonication Counter\s*:\s*(\d+)", re.I)
# R0174: an ordinary 'Xd loc XYZ' state report is NOT itself a Locate Transducer
# event.  Only explicit operator/workflow phrases may open an association window.
_LOCATE_EVENT_RE = re.compile(
    r"(?:\blocate\s+transducer\b|\btransducer\s+locat(?:e|ion|ing)\b|"
    r"\blocat(?:e|ing)\s+(?:the\s+)?xd\b|\bxd\s+transducer\s+locat(?:e|ion|ing)\b)",
    re.I,
)
_FILE_DATE_RE = re.compile(r"(?P<year>20\d{2})[_-](?P<mon>[A-Za-z]{3}|\d{1,2})[_-](?P<day>\d{1,2})", re.I)
_MONTHS = {m.lower(): i for i, m in enumerate(("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"), 1)}


@dataclass(slots=True)
class TransducerLocationRecord:
    timestamp: datetime | None
    clock_s: float
    x: float
    y: float
    z: float
    roll: float | None
    pitch: float | None
    steering_x: float | None
    steering_y: float | None
    steering_z: float | None
    source: Path
    line_number: int
    trigger: str = "Locate Transducer"
    related_sonication: int | None = None
    related_delta_s: float | None = None
    delta_x: float = 0.0
    delta_y: float = 0.0
    delta_z: float = 0.0
    displacement: float = 0.0
    locate_event_line: int | None = None
    locate_event_clock_s: float | None = None
    locate_event_text: str | None = None


@dataclass(slots=True)
class LocateTransducerEvidence:
    source: Path
    line_number: int
    clock_s: float | None
    text: str
    context: tuple[str, ...]


class TransducerLocationService:
    """Extract *confirmed/associated* Locate Transducer position results.

    Workstation logs also emit recurring ``Xd loc XYZ`` state lines during normal
    operation.  R0173 incorrectly presented every one of those rows as a physical
    location history.  R0174 keeps those raw reports as diagnostic evidence only
    and publishes a location record only when an explicit Locate Transducer
    workflow/event precedes the report inside a bounded time window.

    ``Steering XYZ`` remains a separate electronic-steering field; it is never
    substituted for physical X/Y/Z.
    """

    LOCATE_ASSOCIATION_WINDOW_S = 30.0
    LOCATE_ASSOCIATION_MAX_LINES = 120

    @staticmethod
    def _clock_s(line: str) -> float | None:
        m = _CLOCK_RE.search(line)
        if not m:
            return None
        return (int(m.group("h"))*3600.0 + int(m.group("m"))*60.0 + int(m.group("s")) + int(m.group("ms"))/1000.0)

    @staticmethod
    def _date_from_name(path: Path) -> datetime | None:
        m = _FILE_DATE_RE.search(path.name)
        if not m:
            return None
        mon_raw=m.group("mon")
        try:
            mon=int(mon_raw) if mon_raw.isdigit() else _MONTHS[mon_raw.lower()]
            return datetime(int(m.group("year")), mon, int(m.group("day")))
        except Exception:
            return None

    @staticmethod
    def _candidate_logs(workspace: Path) -> list[Path]:
        logs=[]
        for pattern in ("*.Log", "*.log"):
            logs.extend(Path(workspace).rglob(pattern))
        return sorted(set(logs), key=lambda p: (0 if "wsfiles" in str(p.parent).lower() else 1, len(p.parts), str(p).lower()))

    @staticmethod
    def _is_nonzero_location(x: float, y: float, z: float) -> bool:
        # (0,0,0) is common as an unpopulated/default state in real exports.  It
        # must never become the displacement baseline without an independently
        # confirmed Locate workflow result.
        return bool(abs(float(x)) > 1e-9 or abs(float(y)) > 1e-9 or abs(float(z)) > 1e-9)

    def locate_evidence(self, workspace: Path, context_radius: int = 5) -> list[LocateTransducerEvidence]:
        """Return explicit Locate/Transducer workflow lines plus nearby raw context.

        This is intentionally diagnostic evidence, not a location parser.  It lets
        the next real export reveal the workstation's exact success/result wording
        without hard-coding an unobserved vendor signature.
        """
        out=[]
        seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            for i,line in enumerate(lines):
                if not _LOCATE_EVENT_RE.search(line):
                    continue
                key=(str(path.resolve()), i)
                if key in seen:
                    continue
                seen.add(key)
                lo=max(0,i-int(context_radius)); hi=min(len(lines),i+int(context_radius)+1)
                out.append(LocateTransducerEvidence(
                    source=path, line_number=i+1, clock_s=self._clock_s(line), text=line.strip(),
                    context=tuple(lines[lo:hi]),
                ))
        return out

    def raw_xd_reports(self, workspace: Path) -> list[TransducerLocationRecord]:
        """Return all recurring Xd state reports for diagnostics only."""
        records=[]; seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            base_date=self._date_from_name(path)
            starts=[]
            for i,line in enumerate(lines):
                sm=_START_RE.search(line); cs=self._clock_s(line)
                if sm and cs is not None:
                    starts.append((cs, int(sm.group(1))+1, i))
            locate_events=[]
            for i,line in enumerate(lines):
                if _LOCATE_EVENT_RE.search(line):
                    locate_events.append((self._clock_s(line), i, line.strip()))
            for i,line in enumerate(lines):
                m=_XD_RE.search(line)
                if not m:
                    continue
                cs=self._clock_s(line)
                if cs is None:
                    continue
                vals=[float(m.group(j)) if m.group(j) is not None else None for j in range(1,9)]
                x,y,z=vals[:3]
                key=(round(cs,3), round(x,6), round(y,6), round(z,6), str(path.resolve()), i)
                if key in seen:
                    continue
                seen.add(key)
                timestamp=(base_date + timedelta(seconds=cs)) if base_date is not None else None
                assoc=None
                # Causal association only: an explicit Locate event must precede
                # the Xd report.  A later event cannot retroactively label it.
                candidates=[]
                for ev_cs, ev_i, ev_text in locate_events:
                    if ev_i >= i or i-ev_i > self.LOCATE_ASSOCIATION_MAX_LINES:
                        continue
                    if ev_cs is not None:
                        dt=cs-ev_cs
                        if dt < 0 or dt > self.LOCATE_ASSOCIATION_WINDOW_S:
                            continue
                    else:
                        dt=None
                    candidates.append((ev_i, ev_cs, ev_text, dt))
                if candidates:
                    assoc=max(candidates,key=lambda q:q[0])
                related=None; related_delta=None
                if starts:
                    best=min(starts, key=lambda row: abs(row[0]-cs)); delta=best[0]-cs
                    if abs(delta) <= 180.0:
                        related=best[1]; related_delta=float(delta)
                records.append(TransducerLocationRecord(
                    timestamp=timestamp, clock_s=float(cs), x=float(x), y=float(y), z=float(z),
                    roll=vals[3], pitch=vals[4], steering_x=vals[5], steering_y=vals[6], steering_z=vals[7],
                    source=path, line_number=i+1,
                    trigger="Locate Transducer" if assoc is not None else "XD state report",
                    related_sonication=related, related_delta_s=related_delta,
                    locate_event_line=(assoc[0]+1 if assoc is not None else None),
                    locate_event_clock_s=(assoc[1] if assoc is not None else None),
                    locate_event_text=(assoc[2] if assoc is not None else None),
                ))
        records.sort(key=lambda r: ((r.timestamp or datetime.min), r.clock_s, str(r.source).lower(), r.line_number))
        return records

    def parse(self, workspace: Path) -> list[TransducerLocationRecord]:
        """Return only Locate-associated, non-zero physical location results."""
        raw=self.raw_xd_reports(workspace)
        records=[r for r in raw if r.trigger=="Locate Transducer" and self._is_nonzero_location(r.x,r.y,r.z)]
        if records:
            bx,by,bz=records[0].x,records[0].y,records[0].z
            for r in records:
                r.delta_x=r.x-bx; r.delta_y=r.y-by; r.delta_z=r.z-bz
                r.displacement=math.sqrt(r.delta_x*r.delta_x+r.delta_y*r.delta_y+r.delta_z*r.delta_z)
        return records
