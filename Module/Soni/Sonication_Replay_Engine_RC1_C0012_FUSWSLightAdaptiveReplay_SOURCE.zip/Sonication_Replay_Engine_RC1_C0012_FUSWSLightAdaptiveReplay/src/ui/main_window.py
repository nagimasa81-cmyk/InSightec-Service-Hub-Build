from __future__ import annotations

import logging
import re
from pathlib import Path

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import QSettings, Qt, QTimer, QSize, QRectF, QEvent
from PySide6.QtGui import QAction, QImage, QPixmap, QIcon, QCursor
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QFileDialog, QFrame, QGroupBox, QHeaderView,
    QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QMainWindow,
    QMessageBox, QPushButton, QSlider, QSpinBox, QSplitter, QTableWidget,
    QTableWidgetItem, QTabWidget, QTreeWidget, QTreeWidgetItem, QVBoxLayout,
    QWidget, QDialog, QGridLayout, QToolButton,
)

from src.common.constants import APP_NAME, APP_VERSION, ORGANIZATION
from src.domain.models import SonicationModel
from src.integration.spectrum_provider import SpectrumMsgAnalyzerAdapter
from src.services.discovery_service import DiscoveryService
from src.services.import_service import ImportService
from src.services.replay_service import ReplayService
from src.ui.image_panel import OverlayPanel

LOG = logging.getLogger(__name__)


class InfoWindow(QDialog):
    """Non-modal, movable, minimizable information window kept above the replay UI."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Sonication Information")
        self.setWindowFlags(
            Qt.WindowType.Window | Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowCloseButtonHint
        )
        self.setModal(False)
        self.resize(540, 360)
        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["Item", "Value"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout = QVBoxLayout(self)
        layout.addWidget(self.table)

    def update_rows(self, rows):
        self.table.setRowCount(len(rows))
        for r, (key, value) in enumerate(rows):
            self.table.setItem(r, 0, QTableWidgetItem(str(key)))
            self.table.setItem(r, 1, QTableWidgetItem(str(value)))


class HoldInfoButton(QPushButton):
    """Shows a temporary popup only while the right mouse button is held."""
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.popup = QLabel()
        self.popup.setWindowFlags(Qt.WindowType.ToolTip)
        self.popup.setStyleSheet("QLabel { background:#152536; color:white; border:1px solid #4c789d; padding:10px; }")

    def set_popup_text(self, text):
        self.popup.setText(text)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.RightButton:
            self.popup.adjustSize()
            self.popup.move(QCursor.pos())
            self.popup.show()
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.RightButton:
            self.popup.hide()
            event.accept()
            return
        super().mouseReleaseEvent(event)



class ChartPopup(QDialog):
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowCloseButtonHint)
        self.setModal(False); self.resize(1000,650)
        self.plot = pg.PlotWidget(title=title); self.plot.showGrid(x=True,y=True,alpha=.2)
        layout=QVBoxLayout(self); layout.addWidget(self.plot)


class MainWindow(QMainWindow):
    """FUS workstation-inspired Sonication-folder replay UI.

    C0006 deliberately returns the application to replay-first behavior. The
    partially developed acoustic-analysis controls remain available on the
    Analysis tab, but they no longer reduce the size of the replay image.
    """

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} - {APP_VERSION}")
        self.resize(1760, 1040)
        self.setMinimumSize(1180, 720)
        self.setAcceptDrops(True)

        self.settings = QSettings(ORGANIZATION, APP_NAME)
        self.importer = ImportService()
        self.discovery = DiscoveryService()
        self.replay = ReplayService()
        self.package = None
        self.current: SonicationModel | None = None
        self.frame_index = 0
        self.max_temperature_trend: list[float] = []
        self.mean_temperature_trend: list[float] = []
        self.delta_trend: list[float] = []
        self.temperature_display_mode = "Absolute Temperature"
        self.spectrum_channels: dict[str, list] = {}
        self.channel_checks: dict[str, QCheckBox] = {}
        self.spectrum_provider = SpectrumMsgAnalyzerAdapter()
        self._spectrum_frame = None
        self._spectrum_status = "No SpectrumMsg"
        self.sonication_index = -1
        self.cursor_temperature_trend: list[float] = []

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.next_frame)

        pg.setConfigOption("background", "k")
        pg.setConfigOption("foreground", "w")

        self._build_actions()
        self._build_ui()
        self._restore()

    # ------------------------------------------------------------------ UI
    def _build_actions(self):
        menu = self.menuBar().addMenu("&File")
        open_zip = QAction("Open ZIP...", self)
        open_zip.triggered.connect(self.open_zip)
        menu.addAction(open_zip)
        open_folder = QAction("Open Folder...", self)
        open_folder.triggered.connect(self.open_folder)
        menu.addAction(open_folder)

        toolbar = self.addToolBar("Main")
        toolbar.setObjectName("MainToolbar")
        toolbar.setMovable(False)
        toolbar.addAction(open_zip)
        toolbar.addAction(open_folder)

    def _build_ui(self):
        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_replay_tab(), "Replay")
        self.tabs.addTab(self._build_analysis_tab(), "Analysis (preserved)")
        self.setCentralWidget(self.tabs)
        self.statusBar().showMessage("Ready")

    def _chart_panel(self, title: str, plot: pg.PlotWidget, key: str) -> QWidget:
        panel=QGroupBox(title); lay=QVBoxLayout(panel); lay.setContentsMargins(4,12,4,4)
        header=QHBoxLayout(); header.setContentsMargins(0,0,0,0)
        expand=QToolButton(); expand.setText("↗"); expand.setToolTip("Open enlarged chart")
        expand.setFixedSize(20,20); expand.setStyleSheet("QToolButton{padding:0;font-size:10px;}")
        expand.clicked.connect(lambda: self._open_chart_popup(key))
        header.addStretch(1); header.addWidget(expand); lay.addLayout(header); lay.addWidget(plot,1)
        return panel

    def _build_replay_tab(self) -> QWidget:
        # Compact top strip: Sonication number is intentionally not a list.
        self.son_prev_btn = QPushButton("≪")
        self.son_next_btn = QPushButton("≫")
        self.son_number_btn = HoldInfoButton("-")
        self.son_number_btn.setMinimumWidth(64)
        self.son_prev_btn.clicked.connect(lambda: self._change_sonication(-1))
        self.son_next_btn.clicked.connect(lambda: self._change_sonication(1))
        self.info_btn = QPushButton("ⓘ Info")
        self.info_btn.clicked.connect(self._show_info_window)
        self.info_window = InfoWindow(self)

        top_bar = QHBoxLayout()
        top_bar.addWidget(QLabel("Sonication No."))
        top_bar.addWidget(self.son_prev_btn)
        top_bar.addWidget(self.son_number_btn)
        top_bar.addWidget(self.son_next_btn)
        top_bar.addWidget(QLabel("Right-click and hold for details"))
        top_bar.addStretch(1)
        top_bar.addWidget(self.info_btn)

        # Left controls: temperature scale and a true slider for red threshold.
        self.temperature_mode_combo = QComboBox()
        self.temperature_mode_combo.addItems(["Absolute Temperature", "ΔTemperature (Investigation)"])
        self.temperature_mode_combo.currentTextChanged.connect(self._temperature_mode_changed)
        self.range_combo = QComboBox()
        self.range_combo.addItems(["0–60 °C", "30–90 °C", "35–60 °C", "40–60 °C", "Auto"])
        self.range_combo.currentIndexChanged.connect(lambda _: self.set_frame(self.frame_index))
        self.overlay_opacity = QSlider(Qt.Orientation.Horizontal)
        self.overlay_opacity.setRange(0, 100); self.overlay_opacity.setValue(55)
        self.overlay_opacity.valueChanged.connect(lambda _: self.set_frame(self.frame_index))
        self.threshold_slider = QSlider(Qt.Orientation.Horizontal)
        self.threshold_slider.setRange(30, 90); self.threshold_slider.setValue(48)
        self.threshold_value = QLabel("48 °C")
        self.threshold_slider.valueChanged.connect(self._threshold_changed)
        self.baseline_label = QLabel("Temperature source: waiting")
        self.baseline_label.setWordWrap(True); self.baseline_label.setObjectName("CurrentValue")
        self.cursor_temperature_label = QLabel("Cursor Temperature: --")
        self.cursor_temperature_label.setWordWrap(True); self.cursor_temperature_label.setObjectName("CurrentValue")

        left = QWidget(); ll = QVBoxLayout(left); ll.setContentsMargins(3,3,3,3)
        ll.addWidget(QLabel("Temperature display")); ll.addWidget(self.temperature_mode_combo)
        ll.addWidget(QLabel("Overlay opacity")); ll.addWidget(self.overlay_opacity)
        ll.addWidget(QLabel("Temperature range")); ll.addWidget(self.range_combo)
        ll.addWidget(QLabel("Red Threshold")); ll.addWidget(self.threshold_slider); ll.addWidget(self.threshold_value)
        ll.addWidget(self.cursor_temperature_label)
        ll.addWidget(self.baseline_label); ll.addStretch(1)
        left.setMinimumWidth(145); left.setMaximumWidth(190)

        # Dominant workstation image. Click moves the crosshair and updates temperature.
        self.overlay = OverlayPanel("Thermal Replay - Workstation Temperature Map")
        self.overlay.cursorMoved.connect(self._overlay_cursor_moved)
        self._fit_overlay_next = True
        self.cursor_x = None; self.cursor_y = None

        # Frame strip.
        self.frame_list = QListWidget()
        self.frame_list.setViewMode(QListWidget.ViewMode.IconMode)
        self.frame_list.setIconSize(QSize(100, 84)); self.frame_list.setGridSize(QSize(110, 108))
        self.frame_list.setResizeMode(QListWidget.ResizeMode.Adjust)
        self.frame_list.setMovement(QListWidget.Movement.Static)
        self.frame_list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.frame_list.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.frame_list.currentRowChanged.connect(lambda i: self.set_frame(i) if i >= 0 else None)
        navigator_box = QGroupBox("Thermal / Anatomy Frames")
        nav_layout = QVBoxLayout(navigator_box); nav_layout.setContentsMargins(3,10,3,3); nav_layout.addWidget(self.frame_list)
        navigator_box.setMaximumHeight(180)

        self.temperature_plot = pg.PlotWidget()
        self.temperature_plot.setLabel("left", "°C"); self.temperature_plot.setLabel("bottom", "Time", units="sec")
        self.temperature_plot.showGrid(x=True, y=True, alpha=.20); self.temperature_plot.setYRange(0,60,padding=0)
        self.max_temperature_curve = self.temperature_plot.plot(pen=pg.mkPen("r", width=2), name="Max")
        self.mean_temperature_curve = self.temperature_plot.plot(pen=pg.mkPen("g", width=2), name="Avg")
        self.cursor_temperature_curve = self.temperature_plot.plot(pen=pg.mkPen("#c789ff", width=1.5, style=Qt.PenStyle.DashLine), name="Cursor")
        self.temperature_cursor = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen("#00aaff", width=1))
        self.temperature_plot.addItem(self.temperature_cursor)
        self.temperature_plot.scene().sigMouseClicked.connect(self._temperature_plot_clicked)

        self.spectrum_plot = pg.PlotWidget()
        self.spectrum_plot.setLabel("left", "Amplitude"); self.spectrum_plot.setLabel("bottom", "Frequency", units="MHz")
        self.spectrum_plot.showGrid(x=True, y=True, alpha=.20)

        self.graph_split = QSplitter(Qt.Orientation.Horizontal)
        self.temperature_panel=self._chart_panel("Temperature (ROI)",self.temperature_plot,"temperature")
        self.spectrum_panel=self._chart_panel("Acoustic Spectrum (Current Frame)",self.spectrum_plot,"spectrum")
        self.graph_split.addWidget(self.temperature_panel); self.graph_split.addWidget(self.spectrum_panel); self.graph_split.setSizes([500,500])
        self.graph_split.setMaximumHeight(260)
        self.graph_split.setMinimumHeight(170)

        # FUS workstation-style Acoustic Controls: Power % and Score on one chart.
        self.acoustic_control_plot = pg.PlotWidget(); self.acoustic_control_plot.setLabel("left","Normalized"); self.acoustic_control_plot.setLabel("bottom","Time",units="sec")
        self.acoustic_control_plot.setYRange(0.0,1.67,padding=0); self.acoustic_control_plot.showGrid(x=True,y=True,alpha=.18)
        self.acoustic_power_curve=self.acoustic_control_plot.plot(pen=pg.mkPen("#58f26a",width=2),name="Power %")
        self.acoustic_score_curve=self.acoustic_control_plot.plot(pen=pg.mkPen("#ff9d22",width=2),name="Score")
        self.acoustic_control_cursor=pg.InfiniteLine(angle=90,movable=False,pen=pg.mkPen("#00bfff",width=1)); self.acoustic_control_plot.addItem(self.acoustic_control_cursor)
        self.acoustic_control_plot.scene().sigMouseClicked.connect(self._acoustic_plot_clicked)
        self.acoustic_power_value=QLabel("--"); self.acoustic_score_value=QLabel("--"); self.acoustic_cavitation_value=QLabel("--")
        for w in (self.acoustic_power_value,self.acoustic_score_value,self.acoustic_cavitation_value): w.setAlignment(Qt.AlignmentFlag.AlignCenter); w.setObjectName("CurrentValue")
        cards=QGridLayout()
        for col,(title,value) in enumerate((("Power %",self.acoustic_power_value),("Score",self.acoustic_score_value),("Cavitation Index",self.acoustic_cavitation_value))):
            box=QGroupBox(title); bl=QVBoxLayout(box); bl.addWidget(value); cards.addWidget(box,0,col)

        self.waterfall_replay_plot = pg.PlotWidget()
        self.waterfall_replay_plot.setLabel("left", "Frequency", units="MHz"); self.waterfall_replay_plot.setLabel("bottom", "Time", units="sec")
        self.waterfall_replay_image = pg.ImageItem(axisOrder="row-major")
        self.waterfall_replay_plot.addItem(self.waterfall_replay_image)
        self.waterfall_replay_cursor = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen("w", width=1.5))
        self.waterfall_replay_plot.addItem(self.waterfall_replay_cursor)

        self.all_channels = QCheckBox("All"); self.all_channels.setChecked(True); self.all_channels.toggled.connect(self._toggle_all_channels)
        self.channel_bar = QHBoxLayout(); self.channel_bar.addWidget(QLabel("Hydrophone")); self.channel_bar.addWidget(self.all_channels); self.channel_bar.addStretch(1)
        self.current_spectrum_label = QLabel("Spectrum: no synchronized frame"); self.current_spectrum_label.setObjectName("CurrentValue")
        acoustic_box = self._chart_panel("Acoustic Controls", self.acoustic_control_plot, "acoustic")
        al = acoustic_box.layout(); al.addLayout(cards); al.addLayout(self.channel_bar); al.addWidget(self.current_spectrum_label)
        self.waterfall_panel=self._chart_panel("Waterfall",self.waterfall_replay_plot,"waterfall")

        right = QWidget(); rl = QVBoxLayout(right); rl.setContentsMargins(0,0,0,0)
        self.lower_split=QSplitter(Qt.Orientation.Horizontal); self.lower_split.addWidget(acoustic_box); self.lower_split.addWidget(self.waterfall_panel); self.lower_split.setSizes([500,500])
        rl.addWidget(navigator_box,0); rl.addWidget(self.graph_split,1); rl.addWidget(self.lower_split,2)

        self.top_split = QSplitter(Qt.Orientation.Horizontal)
        self.top_split.addWidget(left); self.top_split.addWidget(self.overlay); self.top_split.addWidget(right)
        self.top_split.setSizes([155,760,760]); self.top_split.setStretchFactor(1,5); self.top_split.setStretchFactor(2,4)

        self.first_btn=QPushButton("|<"); self.prev_btn=QPushButton("<"); self.play_btn=QPushButton("▶")
        self.next_btn=QPushButton(">"); self.last_btn=QPushButton(">|")
        self.first_btn.clicked.connect(lambda:self.set_frame(0)); self.prev_btn.clicked.connect(self.previous_frame)
        self.play_btn.clicked.connect(self.toggle_play); self.next_btn.clicked.connect(self.next_frame)
        self.last_btn.clicked.connect(lambda:self.set_frame(max(0,self.current.replay_frame_count-1) if self.current else 0))
        self.speed=QSpinBox(); self.speed.setRange(1,20); self.speed.setValue(5); self.speed.setSuffix(" fps"); self.speed.valueChanged.connect(self.speed_changed)
        self.frame_label=QLabel("Frame -/-"); self.frame_label.setObjectName("CurrentValue")
        self.sync_label=QLabel("Image / Temperature / Spectrum: waiting"); self.sync_label.setObjectName("CurrentValue")
        self.timeline=QSlider(Qt.Orientation.Horizontal); self.timeline.valueChanged.connect(self.slider_changed)
        controls=QHBoxLayout()
        for w in (self.first_btn,self.prev_btn,self.play_btn,self.next_btn,self.last_btn,QLabel("Speed"),self.speed,self.frame_label): controls.addWidget(w)
        controls.addStretch(1); controls.addWidget(self.sync_label)
        bottom=QWidget(); bl=QVBoxLayout(bottom); bl.setContentsMargins(5,1,5,3); bl.addLayout(controls); bl.addWidget(self.timeline)

        page=QWidget(); layout=QVBoxLayout(page); layout.setContentsMargins(2,2,2,2)
        layout.addLayout(top_bar); layout.addWidget(self.top_split,1); layout.addWidget(bottom,0)
        return page

    def _build_analysis_tab(self) -> QWidget:
        """Preserve C0005 analysis work without allowing it to dominate Replay."""
        self.hydro_view = QComboBox()
        self.hydro_view.addItems(["Both", "Spectrum", "Waterfall"])
        self.hydro_view.currentIndexChanged.connect(self._hydro_layout_changed)
        self.hydro_arrangement = QComboBox()
        self.hydro_arrangement.addItems(["Overlay", "Stacked"])
        self.hydro_arrangement.currentIndexChanged.connect(lambda _: self._update_analysis_hydrophone())

        controls = QHBoxLayout()
        controls.addWidget(QLabel("View"))
        controls.addWidget(self.hydro_view)
        controls.addWidget(QLabel("Spectrum layout"))
        controls.addWidget(self.hydro_arrangement)
        controls.addStretch(1)

        self.analysis_spectrum_plot = pg.PlotWidget(title="Hydrophone Spectrum Analysis")
        self.analysis_spectrum_plot.setLabel("bottom", "Frequency", units="kHz")
        self.analysis_spectrum_plot.showGrid(x=True, y=True, alpha=.2)
        self.waterfall_plot = pg.PlotWidget(title="Hydrophone Waterfall")
        self.waterfall_plot.setLabel("left", "Spectrum frame / channel")
        self.waterfall_plot.setLabel("bottom", "Frequency", units="kHz")
        self.waterfall_image = pg.ImageItem()
        self.waterfall_plot.addItem(self.waterfall_image)
        self.waterfall_cursor = pg.InfiniteLine(angle=0, movable=False, pen=pg.mkPen("y", width=2))
        self.waterfall_plot.addItem(self.waterfall_cursor)

        self.hydro_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.hydro_splitter.addWidget(self.analysis_spectrum_plot)
        self.hydro_splitter.addWidget(self.waterfall_plot)
        self.hydro_splitter.setSizes([800, 800])

        info = QLabel(
            "The acoustic-analysis work from C0005 is preserved here. "
            "Replay-first synchronization is completed before further analysis expansion."
        )
        info.setWordWrap(True)

        page = QWidget()
        layout = QVBoxLayout(page)
        layout.addWidget(info)
        layout.addLayout(controls)
        layout.addWidget(self.hydro_splitter, 1)
        return page

    # --------------------------------------------------------------- Loading
    def open_zip(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "Open treatment or Sonication ZIP", "", "ZIP files (*.zip)")
        if file_name:
            self.load(Path(file_name))

    def open_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Open treatment or Sonication folder")
        if folder:
            self.load(Path(folder))

    def load(self, source: Path):
        try:
            workspace = self.importer.open(source)
            self.package = self.discovery.discover(source, workspace)
        except Exception as exc:
            LOG.exception("Import failed")
            QMessageBox.critical(self, APP_NAME, str(exc))
            return
        self.spectrum_provider = SpectrumMsgAnalyzerAdapter(self.package.main_frequency_hz)
        if not self.package.sonications:
            QMessageBox.information(self, APP_NAME, "No compatible Sonication data found.")
            return
        self.sonication_index = 0
        self._select_sonication_index(0)
        self.statusBar().showMessage(f"Loaded {len(self.package.sonications)} sonication(s)")

    def _change_sonication(self, step: int):
        if not self.package or not self.package.sonications:
            return
        self._select_sonication_index((self.sonication_index + step) % len(self.package.sonications))

    def _select_sonication_index(self, index: int):
        if not self.package or not self.package.sonications:
            return
        self.sonication_index = max(0, min(index, len(self.package.sonications)-1))
        self.current = self.package.sonications[self.sonication_index]
        self.timer.stop(); self.play_btn.setText("▶")
        self.replay.clear_cache()
        self._load_spectrum_channels()
        self.cursor_x = self.cursor_y = None
        self._build_temperature_trends()
        self._build_acoustic_trends()
        self._build_frame_navigator()
        self._fit_overlay_next = True
        self.son_number_btn.setText(str(self.sonication_index + 1))
        self.son_number_btn.set_popup_text(self._sonication_popup_text())
        self.set_frame(self._highest_average_frame())

    def _highest_average_frame(self):
        if not self.mean_temperature_trend:
            return 0
        values=np.asarray(self.mean_temperature_trend,float)
        return int(np.nanargmax(values)) if np.isfinite(values).any() else 0

    def select_sonication(self):
        return

    def _sonication_popup_text(self):
        if not self.current or not self.package:
            return "No sonication loaded"
        return (f"Sonication {self.sonication_index+1} / {len(self.package.sonications)}\n"
                f"Name: {self.current.name}\nFrames: {self.current.replay_frame_count}\n"
                f"Temperature RAW: {len(self.current.temperature_frames)}\n"
                f"Magnitude RAW: {len(self.current.magnitude_frames)}\n"
                f"SpectrumMsg: {len(self.current.spectrum_files)}\nACT: {len(self.current.act_files)}")

    # ---------------------------------------------------------- Synchronization
    def _build_temperature_trends(self):
        self.max_temperature_trend = []
        self.mean_temperature_trend = []
        self.delta_trend = []
        if not self.current:
            return
        for index in range(self.current.replay_frame_count):
            try:
                data = self.replay.frame(self.current, index)
                self.max_temperature_trend.append(data.maximum_temperature if data.maximum_temperature is not None else np.nan)
                self.mean_temperature_trend.append(data.mean_temperature if data.mean_temperature is not None else np.nan)
                self.delta_trend.append(data.maximum_delta_temperature if data.maximum_delta_temperature is not None else np.nan)
            except Exception:
                self.max_temperature_trend.append(np.nan)
                self.mean_temperature_trend.append(np.nan)
                self.delta_trend.append(np.nan)
        x = self._frame_time_axis(self.current.replay_frame_count)
        self.max_temperature_curve.setData(x, np.asarray(self.max_temperature_trend, float))
        self.mean_temperature_curve.setData(x, np.asarray(self.mean_temperature_trend, float))

    def _build_acoustic_trends(self):
        self.acoustic_peaks = np.array([])
        self.acoustic_scores = np.array([])
        if not self.current:
            return
        count = self.current.replay_frame_count
        peaks = np.full(count, np.nan); scores = np.full(count, np.nan)
        selected_frames = next(iter(self.spectrum_channels.values()), [])
        if selected_frames:
            raw_peak = np.asarray([float(np.nanmax(np.asarray(f.amplitude,float))) if f.amplitude else np.nan for f in selected_frames])
            raw_score = np.asarray([float(f.confidence) for f in selected_frames])
            for i in range(count):
                si = self._map_replay_to_data(i, count, len(selected_frames))
                peaks[i] = raw_peak[si]; scores[i] = raw_score[si]
            finite = peaks[np.isfinite(peaks)]
            if finite.size and np.nanmax(finite)>np.nanmin(finite):
                peaks=(peaks-np.nanmin(finite))/(np.nanmax(finite)-np.nanmin(finite))
            scores=scores/100.0
        self.acoustic_peaks=peaks; self.acoustic_scores=scores
        x=self._frame_time_axis(count)
        self.acoustic_power_curve.setData(x,peaks)
        self.acoustic_score_curve.setData(x,scores)

    def _build_frame_navigator(self):
        self.frame_list.blockSignals(True)
        self.frame_list.clear()
        if not self.current:
            self.frame_list.blockSignals(False)
            return
        count = self.current.replay_frame_count
        for index in range(count):
            try:
                data = self.replay.frame(self.current, index)
                source = data.magnitude if data.magnitude is not None else data.temperature
                icon = self._array_icon(source)
                seconds = self._index_to_seconds(index, count)
                text = f"{seconds:.1f} Sec\nFrame {index + 1}"
            except Exception:
                icon = QIcon()
                text = f"Frame {index + 1}"
            item = QListWidgetItem(icon, text)
            item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
            self.frame_list.addItem(item)
        self.frame_list.blockSignals(False)

    def set_frame(self, index: int):
        if not self.current:
            return
        try:
            data = self.replay.frame(self.current, index)
        except Exception as exc:
            QMessageBox.warning(self, APP_NAME, f"Unable to decode frame\n{exc}")
            return

        self.frame_index = data.replay_index
        count = self.current.replay_frame_count
        seconds = self._index_to_seconds(self.frame_index, count)

        self.timeline.blockSignals(True)
        self.timeline.setRange(0, max(0, count - 1))
        self.timeline.setValue(self.frame_index)
        self.timeline.blockSignals(False)
        self.frame_list.blockSignals(True)
        self.frame_list.setCurrentRow(self.frame_index)
        self.frame_list.blockSignals(False)
        self.frame_list.scrollToItem(self.frame_list.currentItem())

        self.frame_label.setText(f"Frame {self.frame_index + 1}/{count}   {seconds:.2f} sec")
        self.temperature_cursor.setPos(seconds)

        magnitude_levels = None
        if data.magnitude is not None:
            magnitude_levels = (float(np.percentile(data.magnitude, 1)), float(np.percentile(data.magnitude, 99)))
        lut = pg.colormap.get("CET-L4").getLookupTable(0, 1, 256)
        hotspot = (data.hotspot_x, data.hotspot_y) if data.hotspot_x is not None else None
        hotspot_text = None
        if data.maximum_temperature is not None:
            hotspot_text = (
                f"Max = {data.maximum_temperature:.1f} °C\n"
                f"Avg = {data.mean_temperature:.1f} °C"
            )
        investigation = self.temperature_display_mode.startswith("Δ")
        shown = data.temperature_delta if investigation else data.temperature
        levels = self._delta_levels(shown) if investigation else self._temperature_levels(shown)
        self.overlay.set_roi(data.roi_center_x, data.roi_center_y, data.roi_radius, data.roi_width, data.roi_height)
        self.overlay.set_overlay(
            data.magnitude,
            shown,
            magnitude_levels,
            levels,
            lut,
            self.overlay_opacity.value() / 100.0,
            hotspot,
            hotspot_text,
            None if investigation else float(self.threshold_slider.value()),
            fit=self._fit_overlay_next,
        )
        self._fit_overlay_next = False
        self.baseline_label.setText(
            f"Source: {data.temperature_source}\n"
            f"Reference: {data.reference_temperature:.1f} °C\n"
            f"ROI: {data.roi_source}"
        )

        spectrum_index, spectrum_count = self._update_replay_spectrum(count)
        self._update_analysis_hydrophone()
        self._update_info_window(data, count, spectrum_index, spectrum_count)
        self._update_acoustic_cards(data)
        self._update_replay_waterfall(count)
        self._update_cursor_for_frame(data)
        self.sync_label.setText(
            f"Image {self.frame_index + 1}/{count} | "
            f"Temperature {data.temperature_index + 1 if data.temperature_index is not None else '-'} | "
            f"Spectrum {spectrum_index + 1 if spectrum_index is not None else '-'}/{spectrum_count or '-'}"
        )

    def _update_replay_spectrum(self, replay_count: int):
        self.spectrum_plot.clear()
        selected = self._selected_channels()
        colors = ["#ff9a22", "#00e0ff", "#ff66cc", "#66ff66", "#f4ef5b", "#ffffff"]
        first_index = None
        first_count = 0
        statuses = []
        self._spectrum_frame = None
        for channel_index, channel in enumerate(selected):
            frames = self.spectrum_channels.get(channel, [])
            if not frames:
                continue
            spectrum_index = self._map_replay_to_data(self.frame_index, replay_count, len(frames))
            frame = frames[spectrum_index]
            x = np.asarray(frame.frequency, float) / 1_000_000.0
            y = np.asarray(frame.amplitude, float)
            self.spectrum_plot.plot(x, y, pen=pg.mkPen(colors[channel_index % len(colors)], width=1.6))
            statuses.append(f"{channel}:{spectrum_index + 1}/{len(frames)}")
            if first_index is None:
                first_index = spectrum_index
                first_count = len(frames)
                self._spectrum_frame = frame
        self._add_spectrum_reference_lines(self.spectrum_plot, mhz=True)
        self._spectrum_status = "; ".join(statuses) if statuses else "No SpectrumMsg"
        self.current_spectrum_label.setText(f"Spectrum: {self._spectrum_status}")
        return first_index, first_count

    def _update_analysis_hydrophone(self):
        if not hasattr(self, "analysis_spectrum_plot"):
            return
        self.analysis_spectrum_plot.clear()
        selected = self._selected_channels()
        replay_count = self.current.replay_frame_count if self.current else 1
        colors = ["#00bfff", "#ffcc00", "#ff66cc", "#66ff66", "#ff8844", "#cccccc"]
        stacked = self.hydro_arrangement.currentText() == "Stacked"
        for channel_index, channel in enumerate(selected):
            frames = self.spectrum_channels.get(channel, [])
            if not frames:
                continue
            spectrum_index = self._map_replay_to_data(self.frame_index, replay_count, len(frames))
            frame = frames[spectrum_index]
            x = np.asarray(frame.frequency, float) / 1000.0
            y = np.asarray(frame.amplitude, float)
            if stacked and y.size:
                span = max(1.0, float(np.nanmax(y) - np.nanmin(y)))
                y = y - channel_index * span * 1.2
            self.analysis_spectrum_plot.plot(x, y, pen=pg.mkPen(colors[channel_index % len(colors)], width=1.5))
        self._add_spectrum_reference_lines(self.analysis_spectrum_plot, mhz=False)
        self._update_waterfall()

    def _update_waterfall(self):
        selected = self._selected_channels()
        blocks = []
        max_columns = 0
        x_max = 1.0
        current_row = 0
        row_offset = 0
        replay_count = self.current.replay_frame_count if self.current else 1
        for channel in selected:
            frames = self.spectrum_channels.get(channel, [])
            rows = []
            for frame in frames:
                amplitude = np.asarray(frame.amplitude, float)
                if amplitude.size:
                    rows.append(amplitude)
                    max_columns = max(max_columns, amplitude.size)
                    if frame.frequency:
                        x_max = max(x_max, float(frame.frequency[-1]) / 1000.0)
            if rows:
                if not blocks:
                    current_row = row_offset + self._map_replay_to_data(self.frame_index, replay_count, len(rows))
                blocks.append(rows)
                row_offset += len(rows) + 2
        if not blocks or max_columns == 0:
            self.waterfall_image.setImage(np.empty((0, 0)))
            return
        bands = []
        for rows in blocks:
            padded = np.full((len(rows), max_columns), np.nan)
            for row_index, row in enumerate(rows):
                padded[row_index, : len(row)] = row
            bands.append(padded)
            bands.append(np.full((2, max_columns), np.nan))
        image = np.vstack(bands[:-1])
        finite = image[np.isfinite(image)]
        if finite.size:
            low, high = np.percentile(finite, [2, 98])
            self.waterfall_image.setImage(image, autoLevels=False, levels=(float(low), float(high)))
        else:
            self.waterfall_image.setImage(image)
        self.waterfall_image.setRect(QRectF(0, 0, x_max, image.shape[0]))
        self.waterfall_plot.setYRange(0, image.shape[0], padding=0)
        self.waterfall_cursor.setPos(current_row)

    def _threshold_changed(self, value: int):
        self.threshold_value.setText(f"{value} °C")
        self.set_frame(self.frame_index)

    def _overlay_cursor_moved(self, x: float, y: float):
        self.cursor_x, self.cursor_y = x, y
        self._rebuild_cursor_temperature_trend()
        self.set_frame(self.frame_index)

    def _rebuild_cursor_temperature_trend(self):
        self.cursor_temperature_trend = []
        if not self.current or self.cursor_x is None or self.cursor_y is None:
            self.cursor_temperature_curve.setData([], [])
            return
        for i in range(self.current.replay_frame_count):
            try:
                data = self.replay.frame(self.current, i)
                arr = data.temperature
                if arr is None:
                    self.cursor_temperature_trend.append(np.nan); continue
                xi = int(np.clip(round(self.cursor_x), 0, arr.shape[1]-1))
                yi = int(np.clip(round(self.cursor_y), 0, arr.shape[0]-1))
                self.cursor_temperature_trend.append(float(arr[yi, xi]))
            except Exception:
                self.cursor_temperature_trend.append(np.nan)
        self.cursor_temperature_curve.setData(self._frame_time_axis(len(self.cursor_temperature_trend)), np.asarray(self.cursor_temperature_trend,float))

    def _update_cursor_for_frame(self, data):
        arr = data.temperature
        if arr is None:
            self.cursor_temperature_label.setText("Cursor Temperature: --")
            return
        if self.cursor_x is None or self.cursor_y is None:
            self.cursor_temperature_label.setText("Cursor Temperature: click or drag the small cyan target")
            return
        xi = int(np.clip(round(self.cursor_x),0,arr.shape[1]-1)); yi = int(np.clip(round(self.cursor_y),0,arr.shape[0]-1))
        value=float(arr[yi,xi])
        self.overlay.set_cursor(self.cursor_x,self.cursor_y,f"T {value:.1f} °C\nX {xi}  Y {yi}")
        self.cursor_temperature_label.setText(f"Cursor Temperature\nT: {value:.1f} °C\nX: {xi} px\nY: {yi} px")

    def _show_info_window(self):
        self.info_window.show(); self.info_window.raise_(); self.info_window.activateWindow()

    def _update_info_window(self, data, count, spectrum_index, spectrum_count):
        frequency = self.package.main_frequency_hz / 1_000_000.0 if self.package else 0.0
        rows=[
            ("Sonication No.", f"{self.sonication_index+1} / {len(self.package.sonications) if self.package else '-'}"),
            ("Name", self.current.name if self.current else "-"),
            ("Frequency", f"{frequency:.3f} MHz"),
            ("Replay Frame", f"{self.frame_index+1}/{count}"),
            ("Temperature RAW", data.temperature_index+1 if data.temperature_index is not None else "-"),
            ("SpectrumMsg", f"{spectrum_index+1 if spectrum_index is not None else '-'}/{spectrum_count or '-'}"),
            ("Temperature Source", data.temperature_source),
            ("Reference Temperature", f"{data.reference_temperature:.1f} °C"),
            ("ROI Source", data.roi_source),
            ("Max Temperature (ROI)", f"{data.maximum_temperature:.1f} °C" if data.maximum_temperature is not None else "-"),
            ("Average Temperature (ROI)", f"{data.mean_temperature:.1f} °C" if data.mean_temperature is not None else "-"),
            ("Loaded Folder", str(self.package.source_path) if self.package and hasattr(self.package,'source_path') else "-"),
        ]
        self.info_window.update_rows(rows)

    def _update_acoustic_cards(self, data):
        self.acoustic_control_cursor.setPos(self._index_to_seconds(self.frame_index,self.current.replay_frame_count) if self.current else 0)
        power=float(self.acoustic_peaks[self.frame_index]) if getattr(self,"acoustic_peaks",np.array([])).size>self.frame_index and np.isfinite(self.acoustic_peaks[self.frame_index]) else np.nan
        self.acoustic_power_value.setText(f"{power:.2f}" if np.isfinite(power) else "--")
        if self._spectrum_frame is None:
            self.acoustic_score_value.setText("--"); self.acoustic_cavitation_value.setText("--"); return
        confidence=float(getattr(self._spectrum_frame,'confidence',0.0))
        self.acoustic_score_value.setText(f"{confidence/100.0:.2f}" if confidence>1 else f"{confidence:.2f}")
        amp=np.asarray(getattr(self._spectrum_frame,'amplitude',[]),float)
        self.acoustic_cavitation_value.setText(f"{np.nanmax(amp):.3g}" if amp.size else "--")

    def _update_replay_waterfall(self, replay_count: int):
        selected=self._selected_channels()
        frames = self.spectrum_channels.get(selected[0], []) if selected else []
        rows=[]; max_cols=0
        for frame in frames:
            a=np.asarray(frame.amplitude,float)
            if a.size:
                rows.append(a); max_cols=max(max_cols,a.size)
        if not rows or max_cols==0:
            self.waterfall_replay_image.setImage(np.empty((0,0))); return
        matrix=np.full((len(rows),max_cols),np.nan)
        for i,row in enumerate(rows): matrix[i,:len(row)]=row
        finite=matrix[np.isfinite(matrix)]
        levels=tuple(map(float,np.percentile(finite,[2,98]))) if finite.size else None
        # x=time, y=frequency. Transpose so the white line moves with replay time.
        image=matrix.T
        self.waterfall_replay_image.setImage(image,autoLevels=levels is None,levels=levels)
        duration=max(0.001,self._index_to_seconds(max(0,replay_count-1),replay_count))
        self.waterfall_replay_image.setRect(QRectF(0,0,duration,2.0))
        self.waterfall_replay_cursor.setPos(self._index_to_seconds(self.frame_index,replay_count))
        self.waterfall_replay_plot.setXRange(0,duration,padding=0)
        self.waterfall_replay_plot.setYRange(0,2.0,padding=0)

    # ------------------------------------------------------------- Helpers
    def _load_spectrum_channels(self):
        grouped: dict[str, list[Path]] = {}
        for path in self.current.spectrum_files:
            grouped.setdefault(self._channel_name(path), []).append(path)
        self.spectrum_channels = {
            name: self.spectrum_provider.load(files)
            for name, files in sorted(grouped.items())
        }
        self._rebuild_channel_controls()

    def _rebuild_channel_controls(self):
        for check_box in self.channel_checks.values():
            self.channel_bar.removeWidget(check_box)
            check_box.deleteLater()
        self.channel_checks.clear()
        insert_at = 2
        for name in self.spectrum_channels:
            check_box = QCheckBox(name)
            check_box.setChecked(True)
            check_box.toggled.connect(self._channel_selection_changed)
            self.channel_checks[name] = check_box
            self.channel_bar.insertWidget(insert_at, check_box)
            insert_at += 1
        self.all_channels.blockSignals(True)
        self.all_channels.setChecked(bool(self.channel_checks))
        self.all_channels.blockSignals(False)

    def _toggle_all_channels(self, checked: bool):
        for check_box in self.channel_checks.values():
            check_box.blockSignals(True)
            check_box.setChecked(checked)
            check_box.blockSignals(False)
        self.set_frame(self.frame_index)

    def _channel_selection_changed(self):
        states = [check_box.isChecked() for check_box in self.channel_checks.values()]
        self.all_channels.blockSignals(True)
        self.all_channels.setChecked(bool(states) and all(states))
        self.all_channels.blockSignals(False)
        self.set_frame(self.frame_index)

    def _selected_channels(self):
        selected = [name for name, check_box in self.channel_checks.items() if check_box.isChecked()]
        return selected or list(self.spectrum_channels)[:1]

    def _hydro_layout_changed(self):
        mode = self.hydro_view.currentText()
        self.analysis_spectrum_plot.setVisible(mode in ("Both", "Spectrum"))
        self.waterfall_plot.setVisible(mode in ("Both", "Waterfall"))
        if mode == "Spectrum":
            self.hydro_splitter.setSizes([1000, 0])
        elif mode == "Waterfall":
            self.hydro_splitter.setSizes([0, 1000])
        else:
            self.hydro_splitter.setSizes([600, 600])
        self._update_analysis_hydrophone()

    def _update_parameter_table(self, data, count: int, spectrum_index, spectrum_count):
        frequency_mhz = self.package.main_frequency_hz / 1_000_000.0
        rows = [
            ("Energy", "From ACT when available", "Sonication", self.current.name),
            ("Power", "From ACT when available", "Replay Frame", f"{self.frame_index + 1}/{count}"),
            ("Duration", f"{self._index_to_seconds(count - 1, count):.1f} sec", "Temperature RAW", f"{data.temperature_index + 1 if data.temperature_index is not None else '-'}"),
            ("Frequency", f"{frequency_mhz:.3f} MHz", "SpectrumMsg", f"{spectrum_index + 1 if spectrum_index is not None else '-'}/{spectrum_count or '-'}"),
            ("Temperature Source", data.temperature_source, "Max Temperature (ROI)", f"{data.maximum_temperature:.1f} °C" if data.maximum_temperature is not None else "-"),
            ("Reference Temperature", f"{data.reference_temperature:.1f} °C", "Average Temperature (ROI)", f"{data.mean_temperature:.1f} °C" if data.mean_temperature is not None else "-"),
            ("ROI Source", data.roi_source, "Max ΔTemperature", f"{data.maximum_delta_temperature:.1f} °C" if data.maximum_delta_temperature is not None else "-"),
        ]
        self.parameter_table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            for column_index, value in enumerate(row):
                self.parameter_table.setItem(row_index, column_index, QTableWidgetItem(str(value)))

    def _add_spectrum_reference_lines(self, plot, mhz: bool):
        if not self.package:
            return
        divisor = 1_000_000.0 if mhz else 1000.0
        main = self.package.main_frequency_hz / divisor
        for frequency, label in ((main / 2, "Sub"), (main, "Main"), (main * 2, "2nd"), (main * 3, "3rd")):
            plot.addItem(pg.InfiniteLine(pos=frequency, angle=90, movable=False, label=label))

    def _temperature_mode_changed(self, text: str):
        self.temperature_display_mode = text
        self.range_combo.setEnabled(not text.startswith("Δ"))
        self.threshold_slider.setEnabled(not text.startswith("Δ"))
        self.set_frame(self.frame_index)

    def _temperature_levels(self, temperature):
        index = self.range_combo.currentIndex()
        if index == 0:
            return 0.0, 60.0
        if index == 1:
            return 30.0, 90.0
        if index == 2:
            return 35.0, 60.0
        if index == 3:
            return 40.0, 60.0
        finite = temperature[np.isfinite(temperature)] if temperature is not None else np.array([])
        if not finite.size:
            return None
        lo, hi = np.percentile(finite, [1, 99.5])
        return float(lo), max(float(lo) + 1.0, float(hi))

    def _delta_levels(self, delta):
        finite = delta[np.isfinite(delta)] if delta is not None else np.array([])
        return (0.0, max(1.0, float(np.percentile(finite, 99)))) if finite.size else None

    @staticmethod
    def _channel_name(path: Path) -> str:
        text = f"{path.parent.name}_{path.stem}"
        for pattern in (r"(?:^|[_\- ])(?:CH|HP)[_\- ]?(\d+)", r"hydrophone[_\- ]?(\d+)"):
            match = re.search(pattern, text, re.I)
            if match:
                return f"CH{int(match.group(1))}"
        return "CH1"

    @staticmethod
    def _map_replay_to_data(index: int, replay_count: int, data_count: int) -> int:
        """Map one replay position to another stream with endpoint-safe ratio.

        This is the explicit fallback when timestamps are absent. It guarantees
        frame movement changes Spectrum/Waterfall position instead of leaving a
        static first record.
        """
        if data_count <= 1 or replay_count <= 1:
            return 0
        ratio = index / float(replay_count - 1)
        return max(0, min(data_count - 1, int(round(ratio * (data_count - 1)))))

    @staticmethod
    def _index_to_seconds(index: int, count: int) -> float:
        # 4 s is the typical thermometry cadence; actual timestamp integration
        # remains isolated for the next data-validation commit.
        return max(0.0, float(index) * 4.0)

    def _frame_time_axis(self, count: int):
        return np.asarray([self._index_to_seconds(index, count) for index in range(count)], float)

    @staticmethod
    def _array_icon(array):
        if array is None:
            return QIcon()
        values = np.nan_to_num(np.asarray(array, float))
        low, high = np.percentile(values, [2, 98]) if values.size else (0, 1)
        if high <= low:
            high = low + 1
        gray = np.clip((values - low) / (high - low) * 255, 0, 255).astype(np.uint8)
        rgb = np.stack([gray, gray, gray], axis=2)
        height, width = rgb.shape[:2]
        image = QImage(rgb.data, width, height, 3 * width, QImage.Format.Format_RGB888).copy()
        return QIcon(QPixmap.fromImage(image).scaled(110, 100, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    def _open_chart_popup(self,key: str):
        popup=ChartPopup({"temperature":"Temperature (ROI)","spectrum":"Acoustic Spectrum","acoustic":"Acoustic Controls","waterfall":"Waterfall"}.get(key,key),self)
        if not hasattr(self,"_chart_popups"): self._chart_popups=[]
        self._chart_popups.append(popup)
        plot=popup.plot
        if key=="temperature":
            x=self._frame_time_axis(len(self.max_temperature_trend)); plot.setYRange(0,60,padding=0); plot.plot(x,self.max_temperature_trend,pen=pg.mkPen("r",width=2)); plot.plot(x,self.mean_temperature_trend,pen=pg.mkPen("g",width=2));
            if self.cursor_temperature_trend: plot.plot(x,self.cursor_temperature_trend,pen=pg.mkPen("#00d9ff",width=1.5,style=Qt.PenStyle.DashLine))
        elif key=="spectrum" and self._spectrum_frame is not None:
            plot.plot(np.asarray(self._spectrum_frame.frequency,float)/1_000_000.0,np.asarray(self._spectrum_frame.amplitude,float),pen=pg.mkPen("#00aaff",width=1.5))
        elif key=="acoustic":
            x=self._frame_time_axis(len(self.acoustic_peaks)); plot.setYRange(0,1.67,padding=0); plot.plot(x,self.acoustic_peaks,pen=pg.mkPen("#58f26a",width=2)); plot.plot(x,self.acoustic_scores,pen=pg.mkPen("#ff9d22",width=2))
        elif key=="waterfall":
            selected=self._selected_channels(); rows=[]
            for ch in selected:
                for frame in self.spectrum_channels.get(ch,[]):
                    a=np.asarray(frame.amplitude,float)
                    if a.size: rows.append(a)
            if rows:
                m=max(map(len,rows)); image=np.full((len(rows),m),np.nan)
                for i,row in enumerate(rows): image[i,:len(row)]=row
                item=pg.ImageItem(axisOrder="row-major"); item.setImage(image); plot.addItem(item)
        popup.show(); popup.raise_()

    # -------------------------------------------------------------- Controls
    def _temperature_plot_clicked(self, event):
        if not self.current:
            return
        point = self.temperature_plot.plotItem.vb.mapSceneToView(event.scenePos())
        self.set_frame(int(round(point.x() / 4.0)))

    def _acoustic_plot_clicked(self, event):
        if not self.current:
            return
        point = self.acoustic_control_plot.plotItem.vb.mapSceneToView(event.scenePos())
        self.set_frame(int(round(point.x() / 4.0)))

    def slider_changed(self, value):
        self.set_frame(value)

    def previous_frame(self):
        self.set_frame(max(0, self.frame_index - 1))

    def next_frame(self):
        if not self.current:
            return
        next_index = self.frame_index + 1
        if next_index >= self.current.replay_frame_count:
            next_index = 0 if self.timer.isActive() else self.current.replay_frame_count - 1
        self.set_frame(next_index)

    def toggle_play(self):
        if self.timer.isActive():
            self.timer.stop()
            self.play_btn.setText("▶")
        else:
            self.timer.start(max(20, int(1000 / self.speed.value())))
            self.play_btn.setText("Ⅱ")

    def speed_changed(self, value):
        if self.timer.isActive():
            self.timer.start(max(20, int(1000 / value)))

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Left:
            self.previous_frame()
            return
        if event.key() == Qt.Key.Key_Right:
            self.next_frame()
            return
        if event.key() == Qt.Key.Key_Space:
            self.toggle_play()
            return
        super().keyPressEvent(event)

    def wheelEvent(self, event):
        if self.current:
            self.set_frame(self.frame_index + (1 if event.angleDelta().y() < 0 else -1))
            event.accept()
            return
        super().wheelEvent(event)

    def dragEnterEvent(self, event):
        if any(url.isLocalFile() for url in event.mimeData().urls()):
            event.acceptProposedAction()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            if url.isLocalFile():
                path = Path(url.toLocalFile())
                if path.is_dir() or path.suffix.lower() == ".zip":
                    self.load(path)
                    event.acceptProposedAction()
                    break

    def _restore(self):
        try:
            geometry = self.settings.value("geometry")
            if geometry:
                self.restoreGeometry(geometry)
            for key, splitter in (("top_split", getattr(self,"top_split",None)),("graph_split",getattr(self,"graph_split",None)),("lower_split",getattr(self,"lower_split",None))):
                state=self.settings.value(key)
                if state and splitter is not None: splitter.restoreState(state)
            ranges=self.settings.value("overlay_view_range")
            if ranges and hasattr(self,"overlay"): self.overlay.set_view_range(ranges)
        except Exception:
            pass

    def closeEvent(self, event):
        self.settings.setValue("geometry", self.saveGeometry())
        for key, splitter in (("top_split", getattr(self,"top_split",None)),("graph_split",getattr(self,"graph_split",None)),("lower_split",getattr(self,"lower_split",None))):
            if splitter is not None: self.settings.setValue(key, splitter.saveState())
        if hasattr(self,"overlay"): self.settings.setValue("overlay_view_range", self.overlay.view_range())
        super().closeEvent(event)
