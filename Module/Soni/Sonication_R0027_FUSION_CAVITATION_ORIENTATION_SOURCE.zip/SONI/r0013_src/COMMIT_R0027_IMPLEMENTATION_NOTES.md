# R0027 Implementation Notes

Implemented features requested for replay expansion:

1. **Fusion registration image display**
   - Added `Fusion` to the three image-row selectors.
   - When both Planning CT and Planning MR assets are available, the main viewer can show a fusion preview using MR as the grayscale base and CT as a semi-transparent bone-style overlay.
   - Registration-data presence is surfaced in the sync/status text.

2. **Cavitation visualization**
   - Added `CavitationVisualizationService`.
   - Computes replay-synchronized subharmonic, ultraharmonic, broadband, and combined cavitation index trends from the currently selected spectrum channels.
   - Added a dedicated plot and summary in the Analysis tab.

3. **Orientation alignment correction**
   - `SonicationMetadataService` now prefers MRIImageParams row/column direction cosines over ambiguous text mentions when both are present.
   - Replay summary now shows `Displayed Plane` and `Orientation Status`.

4. **Regression tests**
   - `tests/test_r0027_orientation_prefers_cosines.py`
   - `tests/test_r0027_cavitation_visualization_service.py`
