import numpy as np

from src.services.cavitation_visualization_service import CavitationVisualizationService
from src.integration.spectrum_provider import SpectrumFrame


def _frame(index, main_hz, sub_scale=0.2, broad_scale=0.1):
    freq = np.linspace(100_000.0, 1_100_000.0, 2048)
    main = np.exp(-0.5 * ((freq - main_hz) / 12_000.0) ** 2)
    sub = sub_scale * np.exp(-0.5 * ((freq - 0.5 * main_hz) / 10_000.0) ** 2)
    ultra = 0.15 * np.exp(-0.5 * ((freq - 1.5 * main_hz) / 10_000.0) ** 2)
    broadband = broad_scale * np.maximum(0.0, np.sin(freq / 55_000.0))
    amp = main + sub + ultra + broadband
    return SpectrumFrame(index=index, frequency=[float(v) for v in freq], amplitude=[float(v) for v in amp])


def test_cavitation_visualization_service_returns_trend():
    service = CavitationVisualizationService()
    main_hz = 650_000.0
    spectrum_channels = {
        'CH0': [_frame(0, main_hz, 0.1, 0.05), _frame(1, main_hz, 0.35, 0.12)],
        'CH1': [_frame(0, main_hz, 0.08, 0.04), _frame(1, main_hz, 0.30, 0.10)],
    }
    trend = service.compute(spectrum_channels, ['CH0', 'CH1'], main_hz, replay_count=2, duration_s=3.4)
    assert trend is not None
    assert len(trend.time_s) == 2
    assert np.isfinite(trend.subharmonic_db[0])
    assert np.isfinite(trend.cavitation_index_db[1])
