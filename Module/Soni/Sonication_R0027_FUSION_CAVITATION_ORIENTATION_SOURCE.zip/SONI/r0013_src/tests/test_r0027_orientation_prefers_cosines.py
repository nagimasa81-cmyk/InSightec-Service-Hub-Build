from pathlib import Path

from src.services.sonication_metadata_service import SonicationMetadataService


def test_orientation_prefers_cosines_over_free_text(monkeypatch, tmp_path):
    service = SonicationMetadataService()
    workspace = tmp_path
    (workspace / 'review.out').write_text('Orientation: Coronal\n', encoding='utf-8')
    (workspace / 'MriImageParams.xml').write_text('<xml />', encoding='utf-8')
    (workspace / 'ProtocolData.xml').write_text('<xml />', encoding='utf-8')

    rows = {
        'mriimageparams.xml': [{
            'sonicationindex': '1',
            'rowdirectcosrasx': '0', 'rowdirectcosrasy': '1', 'rowdirectcosrasz': '0',
            'coldirectcosrasx': '0', 'coldirectcosrasy': '0', 'coldirectcosrasz': '1',
            'freqdirection': 'A/P',
        }],
        'protocoldata.xml': [{'sonicationindex': '1'}],
    }

    def fake_parse(path):
        return rows.get(path.name.lower(), [])

    monkeypatch.setattr('src.services.sonication_metadata_service.parse_ado_rowset', fake_parse)

    model = type('Model', (), {
        'planned_power_w': None, 'actual_power_w': None, 'planned_duration_s': None, 'actual_duration_s': None,
        'planned_energy_j': None, 'actual_energy_j': None, 'main_frequency_hz': None, 'temperature_frames': [], 'magnitude_frames': [], 'spectrum_files': [], 'act_files': [],
    })()
    package = type('Package', (), {'workspace': workspace})()
    meta = service.read(model, package, 1)
    assert meta.summary['Orientation'] == 'Sagittal'
