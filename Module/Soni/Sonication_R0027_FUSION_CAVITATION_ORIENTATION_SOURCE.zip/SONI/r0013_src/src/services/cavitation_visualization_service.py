from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np


@dataclass(slots=True)
class CavitationTrend:
    time_s: np.ndarray
    subharmonic_db: np.ndarray
    ultraharmonic_db: np.ndarray
    broadband_db: np.ndarray
    cavitation_index_db: np.ndarray
    main_frequency_hz: float
    selected_channels: tuple[str, ...]


class CavitationVisualizationService:
    """Compute replay-synchronised cavitation indicators from spectrum frames.

    The export does not provide a single authoritative cavitation scalar for the
    SpectrumMsg stream, so this service derives conservative relative indices:
    - subharmonic energy around 0.5 * f0
    - ultraharmonic energy around 1.5 * f0
    - broadband energy in 0.2..0.9 * f0 with harmonic neighbourhoods removed
    All values are expressed relative to the main-frequency band energy.
    """

    @staticmethod
    def _band_energy(freq_hz: np.ndarray, amp: np.ndarray, low_hz: float, high_hz: float) -> float:
        if freq_hz.size == 0 or amp.size == 0 or high_hz <= low_hz:
            return float('nan')
        mask = (freq_hz >= low_hz) & (freq_hz <= high_hz)
        if not np.any(mask):
            return float('nan')
        values = np.asarray(amp[mask], float)
        values = values[np.isfinite(values)]
        if values.size == 0:
            return float('nan')
        return float(np.trapezoid(np.maximum(values, 0.0), freq_hz[mask]))

    @staticmethod
    def _broadband_energy(freq_hz: np.ndarray, amp: np.ndarray, main_hz: float) -> float:
        if freq_hz.size == 0 or amp.size == 0 or main_hz <= 0:
            return float('nan')
        low = max(float(freq_hz[0]), 0.20 * main_hz)
        high = min(float(freq_hz[-1]), 0.90 * main_hz)
        if high <= low:
            return float('nan')
        mask = (freq_hz >= low) & (freq_hz <= high)
        harmonic_width = max(4000.0, 0.03 * main_hz)
        for center in (0.5 * main_hz, 1.0 * main_hz):
            mask &= np.abs(freq_hz - center) > harmonic_width
        if not np.any(mask):
            return float('nan')
        values = np.asarray(amp[mask], float)
        values = values[np.isfinite(values)]
        if values.size == 0:
            return float('nan')
        return float(np.trapezoid(np.maximum(values, 0.0), freq_hz[mask]))

    @staticmethod
    def _to_db(value: float, reference: float) -> float:
        if not (math.isfinite(value) and math.isfinite(reference)) or value <= 0 or reference <= 0:
            return float('nan')
        return float(10.0 * np.log10(value / reference))

    @staticmethod
    def _map_index(index: int, replay_count: int, data_count: int) -> int:
        if data_count <= 0:
            return 0
        if replay_count <= 1 or data_count <= 1:
            return 0
        return max(0, min(int(round(index * (data_count - 1) / max(replay_count - 1, 1))), data_count - 1))

    def compute(self, spectrum_channels: dict[str, list], selected_channels: list[str], main_frequency_hz: float | None, replay_count: int, duration_s: float) -> CavitationTrend | None:
        if not spectrum_channels or replay_count <= 0:
            return None
        main_hz = float(main_frequency_hz or 0.0)
        if main_hz <= 0:
            return None
        channels = [str(ch) for ch in selected_channels if spectrum_channels.get(str(ch))]
        if not channels:
            return None
        sub = np.full(replay_count, np.nan, dtype=float)
        ultra = np.full(replay_count, np.nan, dtype=float)
        broad = np.full(replay_count, np.nan, dtype=float)
        total = np.full(replay_count, np.nan, dtype=float)
        main_width = max(5000.0, 0.04 * main_hz)
        side_width = max(4000.0, 0.035 * main_hz)
        for replay_index in range(replay_count):
            main_vals = []
            sub_vals = []
            ultra_vals = []
            broad_vals = []
            for channel in channels:
                frames = spectrum_channels.get(channel) or []
                if not frames:
                    continue
                data_index = self._map_index(replay_index, replay_count, len(frames))
                frame = frames[data_index]
                freq = np.asarray(getattr(frame, 'frequency', []), float)
                amp = np.asarray(getattr(frame, 'amplitude', []), float)
                if freq.size == 0 or amp.size == 0:
                    continue
                main_energy = self._band_energy(freq, amp, main_hz - main_width, main_hz + main_width)
                sub_energy = self._band_energy(freq, amp, 0.5 * main_hz - side_width, 0.5 * main_hz + side_width)
                ultra_energy = self._band_energy(freq, amp, 1.5 * main_hz - side_width, 1.5 * main_hz + side_width)
                broadband_energy = self._broadband_energy(freq, amp, main_hz)
                if math.isfinite(main_energy):
                    main_vals.append(main_energy)
                if math.isfinite(sub_energy):
                    sub_vals.append(sub_energy)
                if math.isfinite(ultra_energy):
                    ultra_vals.append(ultra_energy)
                if math.isfinite(broadband_energy):
                    broad_vals.append(broadband_energy)
            main_ref = float(np.nanmean(main_vals)) if main_vals else float('nan')
            sub_mean = float(np.nanmean(sub_vals)) if sub_vals else float('nan')
            ultra_mean = float(np.nanmean(ultra_vals)) if ultra_vals else float('nan')
            broad_mean = float(np.nanmean(broad_vals)) if broad_vals else float('nan')
            sub[replay_index] = self._to_db(sub_mean, main_ref)
            ultra[replay_index] = self._to_db(ultra_mean, main_ref)
            broad[replay_index] = self._to_db(broad_mean, main_ref)
            combined = sum(v for v in (sub_mean, ultra_mean, broad_mean) if math.isfinite(v))
            total[replay_index] = self._to_db(combined, main_ref)
        time_s = np.linspace(0.0, float(max(duration_s, 0.0)), replay_count) if replay_count > 1 else np.asarray([0.0], float)
        return CavitationTrend(
            time_s=time_s,
            subharmonic_db=sub,
            ultraharmonic_db=ultra,
            broadband_db=broad,
            cavitation_index_db=total,
            main_frequency_hz=main_hz,
            selected_channels=tuple(channels),
        )
