from pathlib import Path
import ast

ROOT=Path(__file__).parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
REPLAY=(ROOT/'src/services/replay_service.py').read_text(encoding='utf-8')

def test_no_image_checkbox_default_off():
    assert 'self.no_image_toggle = QCheckBox("No image")' in MAIN
    assert 'self.no_image_toggle.setChecked(False)' in MAIN

def test_background_thumbnail_loaders_are_gated():
    assert 'def _image_loading_enabled' in MAIN
    assert 'if not self._image_loading_enabled()' in MAIN
    assert 'def _start_image_thumbnail_background' in MAIN
    assert 'def _start_thermal_thumbnail_background' in MAIN

def test_replay_has_zero_image_io_path():
    assert 'decode_images: bool = True' in REPLAY
    assert 'if not decode_images:' in REPLAY
    block=REPLAY.split('if not decode_images:',1)[1].split('source, reference_temp',1)[0]
    assert 'read_magnitude' not in block
    assert 'read_temperature' not in block
    assert '_baseline(' not in block

def test_set_frame_uses_metadata_only_when_off():
    assert 'data = self.replay.frame(self.current, target, decode_images=False)' in MAIN

def test_registration_requires_image_loading():
    assert 'enabled = bool(main_is_mr and self._image_loading_enabled())' in MAIN

def test_no_duplicate_mainwindow_methods():
    tree=ast.parse(MAIN)
    mw=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='MainWindow')
    seen=set()
    for n in mw.body:
        if isinstance(n,ast.FunctionDef):
            assert n.name not in seen, n.name
            seen.add(n.name)
