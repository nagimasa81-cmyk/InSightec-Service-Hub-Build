from __future__ import annotations

import numpy as np
import pyqtgraph as pg
from PySide6.QtWidgets import QGroupBox, QLabel, QVBoxLayout


class ImagePanel(QGroupBox):
    def __init__(self, title, parent=None):
        super().__init__(title, parent)
        self.view = pg.PlotWidget()
        self.view.setAspectLocked(True)
        self.view.hideAxis("left")
        self.view.hideAxis("bottom")

        self.image = pg.ImageItem()
        self.view.addItem(self.image)

        self.hotspot = pg.ScatterPlotItem(
            size=18,
            symbol="+",
            pen=pg.mkPen(width=3),
        )
        self.view.addItem(self.hotspot)

        self.hotspot_label = pg.TextItem(anchor=(0, 1))
        self.hotspot_label.setVisible(False)
        self.view.addItem(self.hotspot_label)

        layout = QVBoxLayout(self)
        layout.addWidget(self.view)

    def set_image(
        self,
        array: np.ndarray | None,
        levels=None,
        lut=None,
        hotspot=None,
        hotspot_text: str | None = None,
    ):
        if array is None:
            self.image.clear()
            self.hotspot.setData([])
            self.hotspot_label.setVisible(False)
            return

        self.image.setImage(
            array.T,
            autoLevels=levels is None,
            levels=levels,
        )
        if lut is not None:
            self.image.setLookupTable(lut)
        else:
            self.image.setLookupTable(None)

        if hotspot is not None:
            self.hotspot.setData([hotspot[0]], [hotspot[1]])
            if hotspot_text:
                self.hotspot_label.setText(hotspot_text)
                self.hotspot_label.setPos(hotspot[0] + 4, hotspot[1] - 4)
                self.hotspot_label.setVisible(True)
            else:
                self.hotspot_label.setVisible(False)
        else:
            self.hotspot.setData([])
            self.hotspot_label.setVisible(False)


class OverlayPanel(QGroupBox):
    def __init__(self, title="Magnitude + Temperature Overlay", parent=None):
        super().__init__(title, parent)
        self.view = pg.PlotWidget()
        self.view.setAspectLocked(True)
        self.view.hideAxis("left")
        self.view.hideAxis("bottom")

        self.magnitude_item = pg.ImageItem()
        self.temperature_item = pg.ImageItem()
        self.view.addItem(self.magnitude_item)
        self.view.addItem(self.temperature_item)

        self.hotspot = pg.ScatterPlotItem(
            size=22,
            symbol="+",
            pen=pg.mkPen(width=4),
        )
        self.view.addItem(self.hotspot)

        self.hotspot_label = pg.TextItem(anchor=(0, 1))
        self.hotspot_label.setVisible(False)
        self.view.addItem(self.hotspot_label)

        layout = QVBoxLayout(self)
        layout.addWidget(self.view)

    def set_overlay(
        self,
        magnitude: np.ndarray | None,
        temperature: np.ndarray | None,
        magnitude_levels=None,
        temperature_levels=None,
        temperature_lut=None,
        opacity: float = 0.55,
        hotspot=None,
        hotspot_text: str | None = None,
        temperature_threshold: float | None = None,
    ) -> None:
        if magnitude is None:
            self.magnitude_item.clear()
        else:
            self.magnitude_item.setLookupTable(None)
            self.magnitude_item.setImage(
                magnitude.T,
                autoLevels=magnitude_levels is None,
                levels=magnitude_levels,
            )

        if temperature is None:
            self.temperature_item.clear()
        else:
            shown_temperature = temperature
            if temperature_threshold is not None:
                shown_temperature = np.where(temperature >= temperature_threshold, temperature, np.nan)
            self.temperature_item.setImage(
                shown_temperature.T,
                autoLevels=temperature_levels is None,
                levels=temperature_levels,
            )
            if temperature_lut is not None:
                self.temperature_item.setLookupTable(temperature_lut)
            self.temperature_item.setOpacity(max(0.0, min(1.0, opacity)))

        if hotspot is not None:
            self.hotspot.setData([hotspot[0]], [hotspot[1]])
            if hotspot_text:
                self.hotspot_label.setText(hotspot_text)
                self.hotspot_label.setPos(hotspot[0] + 4, hotspot[1] - 4)
                self.hotspot_label.setVisible(True)
            else:
                self.hotspot_label.setVisible(False)
        else:
            self.hotspot.setData([])
            self.hotspot_label.setVisible(False)
