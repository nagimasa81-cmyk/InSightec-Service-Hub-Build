# Sonication Replay Engine — RC1 C0007 FUSWSThermometry

Replay-first FUS workstation-style viewer.

## C0007 thermometry
- Absolute-temperature map is the default display.
- RAW data is classified as absolute temperature or delta temperature.
- Delta RAW is converted to absolute temperature with an explicit 37.0 C fallback reference.
- Max and Average temperatures are calculated inside an explicit ROI.
- The current fallback ROI is shown as `Default center ROI (ACT/Protocol pending)`; it is never hidden.
- Workstation-style temperature scale presets: 30–90, 35–60, and 40–60 C.
- Red-threshold overlay and investigation-only ΔTemperature mode.
- Temperature chart, image, spectrum, acoustic controls, and frame navigator remain replay-synchronized.

The next thermometry step is reading the exact target/ROI and reference temperature from ACT/Protocol metadata when present.
