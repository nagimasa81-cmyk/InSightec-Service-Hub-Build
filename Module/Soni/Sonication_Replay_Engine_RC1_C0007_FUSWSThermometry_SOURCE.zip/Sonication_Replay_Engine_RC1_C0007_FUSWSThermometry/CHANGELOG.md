# Changelog

## RC1 C0007 FUSWSThermometry
- Changed default thermal display from Frame0 delta to workstation-style absolute temperature.
- Added automatic Absolute RAW / Delta RAW classification.
- Added explicit reference-temperature and ROI-source reporting.
- Max/Avg now use ROI values instead of whole-image values.
- Added 30–90, 35–60, 40–60 C scales and red threshold.
- Preserved ΔTemperature as investigation mode.
- Preserved synchronized Replay/Spectrum/Temperature behavior.
