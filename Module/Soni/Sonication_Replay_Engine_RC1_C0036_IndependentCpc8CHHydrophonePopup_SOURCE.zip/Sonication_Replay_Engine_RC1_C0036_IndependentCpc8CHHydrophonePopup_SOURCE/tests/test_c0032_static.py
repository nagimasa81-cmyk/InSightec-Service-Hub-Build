from pathlib import Path
TEXT=Path('src/ui/main_window.py').read_text(encoding='utf-8')

def test_first_valid_frame_is_computed_and_auto_displayed():
    assert 'self.frame_index = self._first_valid_replay_frame()' in TEXT
    assert 'self.set_frame(self.frame_index, display_mode=initial_mode)' in TEXT
