from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re


@dataclass(slots=True)
class PlanningAsset:
    category: str
    path: Path
    role: str
    confidence: float
    notes: str = ""


@dataclass(slots=True)
class PlanningDataSummary:
    assets: list[PlanningAsset] = field(default_factory=list)

    def by_category(self, category: str) -> list[PlanningAsset]:
        return [item for item in self.assets if item.category == category]

    @property
    def counts(self) -> dict[str, int]:
        result: dict[str, int] = {}
        for item in self.assets:
            result[item.category] = result.get(item.category, 0) + 1
        return result


class PlanningDataService:
    """Classify planning/reference resources without treating them as replay frames."""

    _RAW_RE = re.compile(r"^(\d+)-.*-(\d+)\.raw$", re.I)

    def discover(self, workspace: Path) -> PlanningDataSummary:
        assets: list[PlanningAsset] = []
        son1 = next((p for p in workspace.rglob("*") if p.is_dir() and p.name.lower().replace("_", "") == "sonication1"), None)

        for path in workspace.rglob("*"):
            if not path.is_file():
                continue
            low_name = path.name.lower()
            low_path = str(path).lower().replace("\\", "/")
            category = role = notes = ""
            confidence = 0.0

            if low_name in {"ctimage.xml", "ctvolumedata.xml"}:
                category, role, confidence = "PLANNING_CT", "CT volume metadata used by skull/SDR planning", 1.0
            elif "skullmeasure" in low_name or "bonespot" in low_name or "sdr" in low_name:
                category, role, confidence = "SDR_DATA", "Skull/SDR calculation input or result", 0.95
            elif low_name.startswith("ctmr") or "ctmrregistration" in low_name:
                category, role, confidence = "REGISTRATION_DATA", "CT-to-MR registration", 0.98
            elif low_name.startswith("mrmr") or "mrmrregistration" in low_name:
                category, role, confidence = "REGISTRATION_DATA", "MR-to-MR registration", 0.98
            elif low_name == "mriimageparams.xml" or "mi_params" in low_name or low_name.startswith("miparams"):
                category, role, confidence = "PRE_TREATMENT_MR", "MR acquisition/reference metadata", 0.90
            elif "/sonication1/" in low_path and self._RAW_RE.match(path.name):
                prefix = self._RAW_RE.match(path.name).group(1)
                if prefix not in {"5", "6"}:
                    category, role, confidence = "PRE_TREATMENT_MR", f"Sonication1 non-replay RAW series (prefix {prefix})", 0.85
                    notes = "Kept separate from thermometry/magnitude replay until image semantics are verified."
            elif son1 is not None and path.parent == son1 and path.suffix.lower() in {".rgs", ".txt"} and ("fid" in low_name or "mat" in low_name):
                category, role, confidence = "REGISTRATION_DATA", "Planning registration matrix/fiducials", 0.90

            if category:
                assets.append(PlanningAsset(category, path, role, confidence, notes))

        assets.sort(key=lambda item: (item.category, str(item.path).lower()))
        return PlanningDataSummary(assets)
