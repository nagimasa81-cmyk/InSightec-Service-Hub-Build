# R0116zo — Replay time restore + Spectrum data-fit + thermometry frame alignment

- Main Replay time presentation restored to the pre-MR-global behavior: 3.4 s per Replay frame.
- Main Replay chart labels restored to Replay time.
- Spectrum Dump Analyzer auto-fit now uses the actual measured Spectrum/CPC/control data extent rather than extending to MR scan end.
- Thermometry 10->11 frame proportional stretching removed. Temperature frames stay sequential and only trailing MR-only frames hold the final available temperature.
- This removes the artificial Replay frame 5/6 duplicated temperature frame observed in 11-MR/10-temperature exports.
- Canonical Sonication/CPC/Acquisition source binding remains intact; only presentation/time-fit ownership is separated between Main Replay and Spectrum Analyzer.
