from pathlib import Path

def test_main_replay_restores_legacy_34s_timebase():
    text=Path("src/ui/main_window.py").read_text(encoding="utf-8")
    start=text.index("def _prepare_common_timeline")
    end=text.index("def _apply_main_mr_timeline_guides",start)
    block=text[start:end]
    assert "* 3.4" in block
    assert "mr_timeline_duration_s" not in block

def test_thermometry_not_stretched_through_middle():
    text=Path("src/services/replay_service.py").read_text(encoding="utf-8")
    assert "src_index=min(max(int(replay_index),0), max(0,src_count-1))" in text
    assert "ti = min(index, len(son.temperature_frames) - 1)" in text

def test_spectrum_fit_uses_measured_data_extent():
    text=Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    assert "def _data_fit_range" in text
    assert "post-irradiation MR tail" in text
