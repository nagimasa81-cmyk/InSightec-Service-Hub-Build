# Sonication Replay Engine - RC1 C0006

This commit resets the application around its original purpose: reproducing a Sonication folder as a synchronized replay.

## Replay-first design

The Replay tab is based on the visual hierarchy of the FUS workstation:

- Large Magnitude + delta-temperature overlay
- Thermal/Anatomy frame navigator
- Temperature Max/Average trend
- Current Acoustic Spectrum
- Acoustic Controls trend
- Read-only Sonication parameters
- Replay controls and timeline

The Hydrophone analysis work from C0005 is preserved under **Analysis (preserved)** and can be resumed after replay synchronization is validated.

## Delta-temperature reference

The current implementation uses the first decoded Temperature RAW frame as the reference:

`Delta T = Current Temperature RAW - Reference Temperature RAW Frame 1`

The baseline source is shown directly in the UI.

## Synchronization

Changing the replay frame updates:

- Magnitude image
- Delta-temperature overlay
- Temperature graph cursor
- Acoustic spectrum
- Acoustic controls cursor
- Waterfall cursor
- Frame navigator selection
- Metadata/parameter values

When timestamps are unavailable, SpectrumMsg is mapped to replay position by endpoint-safe ratio. The current mapping is shown in the UI rather than silently displaying a static spectrum.

## Build

Run:

- `build/00_VERIFY_SOURCE.bat`
- `build/01_BUILD_EXE.bat`

Python debug:

- `build/03_RUN_DEBUG.bat`
