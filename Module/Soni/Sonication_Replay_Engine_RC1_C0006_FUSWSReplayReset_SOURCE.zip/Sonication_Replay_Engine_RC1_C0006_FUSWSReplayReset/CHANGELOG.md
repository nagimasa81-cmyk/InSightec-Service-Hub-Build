# Changelog

## RC1 C0006 - FUS WS Replay Reset

- Returned the product to Sonication-folder replay as the primary purpose.
- Rebuilt the Replay tab using a FUS workstation-inspired layout.
- Enlarged the Magnitude + delta-temperature overlay and made it the dominant view.
- Moved the partially developed Hydrophone analysis UI to a preserved Analysis tab.
- Added explicit baseline display: first decoded Temperature RAW / Frame 1.
- Delta temperature is calculated as Current Temperature minus Reference Temperature.
- Added synchronized replay mapping for image, temperature, spectrum, waterfall cursor, and trend cursors.
- Added WS-like Temperature Max/Average chart and Acoustic Controls trend.
- Added compact Hydrophone All/single/multiple channel selection.
- Added replay time slider, frame navigator, play/pause, speed, and graph-click navigation.
- Retained ZIP/folder import and BAT-based build flow.
