from __future__ import annotations

import logging
import re
from pathlib import Path

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import QSettings, Qt, QTimer, QSize, QRectF
from PySide6.QtGui import QAction, QImage, QPixmap, QIcon
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QFileDialog, QFrame, QGroupBox, QHeaderView,
    QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QMainWindow,
    QMessageBox, QPushButton, QSlider, QSpinBox, QSplitter, QTableWidget,
    QTableWidgetItem, QTabWidget, QTreeWidget, QTreeWidgetItem, QVBoxLayout,
    QWidget,
)

from src.common.constants import APP_NAME, APP_VERSION, ORGANIZATION
from src.domain.models import SonicationModel
from src.integration.spectrum_provider import SpectrumMsgAnalyzerAdapter
from src.services.discovery_service import DiscoveryService
from src.services.import_service import ImportService
from src.services.replay_service import ReplayService
from src.ui.image_panel import OverlayPanel

LOG = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    """FUS workstation-inspired Sonication-folder replay UI.

    C0006 deliberately returns the application to replay-first behavior. The
    partially developed acoustic-analysis controls remain available on the
    Analysis tab, but they no longer reduce the size of the replay image.
    """

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} - {APP_VERSION}")
        self.resize(1760, 1040)
        self.setMinimumSize(1180, 720)
        self.setAcceptDrops(True)

        self.settings = QSettings(ORGANIZATION, APP_NAME)
        self.importer = ImportService()
        self.discovery = DiscoveryService()
        self.replay = ReplayService()
        self.package = None
        self.current: SonicationModel | None = None
        self.frame_index = 0
        self.max_temperature_trend: list[float] = []
        self.mean_temperature_trend: list[float] = []
        self.delta_trend: list[float] = []
        self.spectrum_channels: dict[str, list] = {}
        self.channel_checks: dict[str, QCheckBox] = {}
        self.spectrum_provider = SpectrumMsgAnalyzerAdapter()
        self._spectrum_frame = None
        self._spectrum_status = "No SpectrumMsg"

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.next_frame)

        pg.setConfigOption("background", "k")
        pg.setConfigOption("foreground", "w")

        self._build_actions()
        self._build_ui()
        self._restore()

    # ------------------------------------------------------------------ UI
    def _build_actions(self):
        menu = self.menuBar().addMenu("&File")
        open_zip = QAction("Open ZIP...", self)
        open_zip.triggered.connect(self.open_zip)
        menu.addAction(open_zip)
        open_folder = QAction("Open Folder...", self)
        open_folder.triggered.connect(self.open_folder)
        menu.addAction(open_folder)

        toolbar = self.addToolBar("Main")
        toolbar.setObjectName("MainToolbar")
        toolbar.setMovable(False)
        toolbar.addAction(open_zip)
        toolbar.addAction(open_folder)

    def _build_ui(self):
        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_replay_tab(), "Replay")
        self.tabs.addTab(self._build_analysis_tab(), "Analysis (preserved)")
        self.setCentralWidget(self.tabs)
        self.statusBar().showMessage("Ready")

    def _build_replay_tab(self) -> QWidget:
        # Left: WS-like tools and sonication selection.
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Sonication / Data", "Count"])
        self.tree.itemSelectionChanged.connect(self.select_sonication)

        open_folder_btn = QPushButton("Open Folder / ZIP")
        open_folder_btn.clicked.connect(self.open_folder)

        self.overlay_opacity = QSlider(Qt.Orientation.Horizontal)
        self.overlay_opacity.setRange(0, 100)
        self.overlay_opacity.setValue(55)
        self.overlay_opacity.valueChanged.connect(lambda _: self.set_frame(self.frame_index))

        self.range_combo = QComboBox()
        self.range_combo.addItems(["Auto", "0–5 °C", "0–10 °C", "0–20 °C", "0–30 °C"])
        self.range_combo.currentIndexChanged.connect(lambda _: self.set_frame(self.frame_index))

        self.baseline_label = QLabel("Reference: Temperature Frame 1")
        self.baseline_label.setWordWrap(True)
        self.baseline_label.setObjectName("CurrentValue")

        tools_box = QGroupBox("Tools / Overlays")
        tools_layout = QVBoxLayout(tools_box)
        tools_layout.addWidget(open_folder_btn)
        tools_layout.addWidget(QLabel("ΔTemperature opacity"))
        tools_layout.addWidget(self.overlay_opacity)
        tools_layout.addWidget(QLabel("ΔTemperature range"))
        tools_layout.addWidget(self.range_combo)
        tools_layout.addWidget(self.baseline_label)
        tools_layout.addStretch(1)

        sonication_box = QGroupBox("Sonication No.")
        sonication_layout = QVBoxLayout(sonication_box)
        sonication_layout.addWidget(self.tree)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(3, 3, 3, 3)
        left_layout.addWidget(tools_box, 1)
        left_layout.addWidget(sonication_box, 3)
        left.setMinimumWidth(235)
        left.setMaximumWidth(330)

        # Center: the main replay image. This is intentionally dominant.
        self.overlay = OverlayPanel("Thermal Replay - Magnitude + ΔTemperature")

        # Right top: two-row frame navigator, matching the WS visual language.
        self.frame_list = QListWidget()
        self.frame_list.setViewMode(QListWidget.ViewMode.IconMode)
        self.frame_list.setIconSize(QSize(110, 100))
        self.frame_list.setGridSize(QSize(122, 128))
        self.frame_list.setResizeMode(QListWidget.ResizeMode.Adjust)
        self.frame_list.setMovement(QListWidget.Movement.Static)
        self.frame_list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.frame_list.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.frame_list.currentRowChanged.connect(lambda i: self.set_frame(i) if i >= 0 else None)
        navigator_box = QGroupBox("Thermal / Anatomy Frames")
        nav_layout = QVBoxLayout(navigator_box)
        nav_layout.setContentsMargins(3, 10, 3, 3)
        nav_layout.addWidget(self.frame_list)

        # Right middle: WS Temperature and Acoustic Spectrum panels.
        self.temperature_plot = pg.PlotWidget(title="Temperature")
        self.temperature_plot.setLabel("left", "°C")
        self.temperature_plot.setLabel("bottom", "sec")
        self.temperature_plot.showGrid(x=True, y=True, alpha=.20)
        self.max_temperature_curve = self.temperature_plot.plot(pen=pg.mkPen("r", width=2), name="Max")
        self.mean_temperature_curve = self.temperature_plot.plot(pen=pg.mkPen("g", width=2), name="Avg")
        self.temperature_cursor = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen("y", width=1))
        self.temperature_plot.addItem(self.temperature_cursor)
        self.temperature_plot.scene().sigMouseClicked.connect(self._temperature_plot_clicked)

        self.spectrum_plot = pg.PlotWidget(title="Acoustic Spectrum")
        self.spectrum_plot.setLabel("left", "Amplitude")
        self.spectrum_plot.setLabel("bottom", "Frequency", units="MHz")
        self.spectrum_plot.showGrid(x=True, y=True, alpha=.20)

        graph_split = QSplitter(Qt.Orientation.Horizontal)
        graph_split.addWidget(self.temperature_plot)
        graph_split.addWidget(self.spectrum_plot)
        graph_split.setSizes([540, 540])

        # Acoustic controls: synchronized time trend, not a disconnected chart.
        self.acoustic_control_plot = pg.PlotWidget(title="Acoustic Controls")
        self.acoustic_control_plot.setLabel("left", "Normalized")
        self.acoustic_control_plot.setLabel("bottom", "sec")
        self.acoustic_control_plot.showGrid(x=True, y=True, alpha=.20)
        self.acoustic_peak_curve = self.acoustic_control_plot.plot(pen=pg.mkPen("g", width=2), name="Peak %")
        self.acoustic_score_curve = self.acoustic_control_plot.plot(pen=pg.mkPen("#ff9a22", width=2), name="Score")
        self.acoustic_cursor = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen("y", width=1))
        self.acoustic_control_plot.addItem(self.acoustic_cursor)
        self.acoustic_control_plot.scene().sigMouseClicked.connect(self._acoustic_plot_clicked)

        # CH controls are compact and WS-like. Analysis layouts live on Analysis tab.
        self.all_channels = QCheckBox("All")
        self.all_channels.setChecked(True)
        self.all_channels.toggled.connect(self._toggle_all_channels)
        self.channel_bar = QHBoxLayout()
        self.channel_bar.addWidget(QLabel("Hydrophone"))
        self.channel_bar.addWidget(self.all_channels)
        self.channel_bar.addStretch(1)
        self.current_spectrum_label = QLabel("Spectrum: no synchronized frame")
        self.current_spectrum_label.setObjectName("CurrentValue")

        acoustic_box = QGroupBox("Acoustic Controls")
        acoustic_layout = QVBoxLayout(acoustic_box)
        acoustic_layout.addLayout(self.channel_bar)
        acoustic_layout.addWidget(self.current_spectrum_label)
        acoustic_layout.addWidget(self.acoustic_control_plot)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.addWidget(navigator_box, 3)
        right_layout.addWidget(graph_split, 2)
        right_layout.addWidget(acoustic_box, 2)

        top_split = QSplitter(Qt.Orientation.Horizontal)
        top_split.addWidget(left)
        top_split.addWidget(self.overlay)
        top_split.addWidget(right)
        top_split.setSizes([255, 900, 650])
        top_split.setStretchFactor(1, 5)
        top_split.setStretchFactor(2, 3)

        # Bottom parameter area, based on WS. Values are read-only in Replay.
        self.parameter_table = QTableWidget(0, 4)
        self.parameter_table.setHorizontalHeaderLabels(["Replay Parameter", "Value", "Sonication", "Value"])
        self.parameter_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.parameter_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.parameter_table.setMaximumHeight(180)

        # Replay controls are placed where WS has its lower status/control strip.
        self.first_btn = QPushButton("|<")
        self.prev_btn = QPushButton("<")
        self.play_btn = QPushButton("▶")
        self.play_btn.setObjectName("ReplayButton")
        self.next_btn = QPushButton(">")
        self.last_btn = QPushButton(">|")
        self.first_btn.clicked.connect(lambda: self.set_frame(0))
        self.prev_btn.clicked.connect(self.previous_frame)
        self.play_btn.clicked.connect(self.toggle_play)
        self.next_btn.clicked.connect(self.next_frame)
        self.last_btn.clicked.connect(lambda: self.set_frame(max(0, self.current.replay_frame_count - 1) if self.current else 0))

        self.speed = QSpinBox()
        self.speed.setRange(1, 20)
        self.speed.setValue(5)
        self.speed.setSuffix(" fps")
        self.speed.valueChanged.connect(self.speed_changed)
        self.frame_label = QLabel("Frame -/-")
        self.frame_label.setObjectName("CurrentValue")
        self.sync_label = QLabel("Image / Temperature / Spectrum: waiting")
        self.sync_label.setObjectName("CurrentValue")
        self.timeline = QSlider(Qt.Orientation.Horizontal)
        self.timeline.valueChanged.connect(self.slider_changed)

        replay_controls = QHBoxLayout()
        for widget in (self.first_btn, self.prev_btn, self.play_btn, self.next_btn, self.last_btn,
                       self.frame_label, QLabel("Speed"), self.speed, self.sync_label):
            replay_controls.addWidget(widget)
        replay_controls.addStretch(1)

        bottom = QWidget()
        bottom_layout = QVBoxLayout(bottom)
        bottom_layout.setContentsMargins(5, 1, 5, 3)
        bottom_layout.addWidget(self.parameter_table)
        bottom_layout.addLayout(replay_controls)
        bottom_layout.addWidget(self.timeline)

        replay_page = QWidget()
        replay_layout = QVBoxLayout(replay_page)
        replay_layout.setContentsMargins(2, 2, 2, 2)
        replay_layout.addWidget(top_split, 1)
        replay_layout.addWidget(bottom, 0)
        return replay_page

    def _build_analysis_tab(self) -> QWidget:
        """Preserve C0005 analysis work without allowing it to dominate Replay."""
        self.hydro_view = QComboBox()
        self.hydro_view.addItems(["Both", "Spectrum", "Waterfall"])
        self.hydro_view.currentIndexChanged.connect(self._hydro_layout_changed)
        self.hydro_arrangement = QComboBox()
        self.hydro_arrangement.addItems(["Overlay", "Stacked"])
        self.hydro_arrangement.currentIndexChanged.connect(lambda _: self._update_analysis_hydrophone())

        controls = QHBoxLayout()
        controls.addWidget(QLabel("View"))
        controls.addWidget(self.hydro_view)
        controls.addWidget(QLabel("Spectrum layout"))
        controls.addWidget(self.hydro_arrangement)
        controls.addStretch(1)

        self.analysis_spectrum_plot = pg.PlotWidget(title="Hydrophone Spectrum Analysis")
        self.analysis_spectrum_plot.setLabel("bottom", "Frequency", units="kHz")
        self.analysis_spectrum_plot.showGrid(x=True, y=True, alpha=.2)
        self.waterfall_plot = pg.PlotWidget(title="Hydrophone Waterfall")
        self.waterfall_plot.setLabel("left", "Spectrum frame / channel")
        self.waterfall_plot.setLabel("bottom", "Frequency", units="kHz")
        self.waterfall_image = pg.ImageItem()
        self.waterfall_plot.addItem(self.waterfall_image)
        self.waterfall_cursor = pg.InfiniteLine(angle=0, movable=False, pen=pg.mkPen("y", width=2))
        self.waterfall_plot.addItem(self.waterfall_cursor)

        self.hydro_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.hydro_splitter.addWidget(self.analysis_spectrum_plot)
        self.hydro_splitter.addWidget(self.waterfall_plot)
        self.hydro_splitter.setSizes([800, 800])

        info = QLabel(
            "The acoustic-analysis work from C0005 is preserved here. "
            "Replay-first synchronization is completed before further analysis expansion."
        )
        info.setWordWrap(True)

        page = QWidget()
        layout = QVBoxLayout(page)
        layout.addWidget(info)
        layout.addLayout(controls)
        layout.addWidget(self.hydro_splitter, 1)
        return page

    # --------------------------------------------------------------- Loading
    def open_zip(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "Open treatment or Sonication ZIP", "", "ZIP files (*.zip)")
        if file_name:
            self.load(Path(file_name))

    def open_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Open treatment or Sonication folder")
        if folder:
            self.load(Path(folder))

    def load(self, source: Path):
        try:
            workspace = self.importer.open(source)
            self.package = self.discovery.discover(source, workspace)
        except Exception as exc:
            LOG.exception("Import failed")
            QMessageBox.critical(self, APP_NAME, str(exc))
            return

        self.spectrum_provider = SpectrumMsgAnalyzerAdapter(self.package.main_frequency_hz)
        self.tree.clear()
        if not self.package.sonications:
            QMessageBox.information(self, APP_NAME, "No compatible Sonication data found.")
            return

        frequency = self.package.main_frequency_hz / 1_000_000.0
        frequency_item = QTreeWidgetItem(["Main Frequency", f"{frequency:.3f} MHz"])
        self.tree.addTopLevelItem(frequency_item)
        for sonication in self.package.sonications:
            item = QTreeWidgetItem([sonication.name, f"{sonication.replay_frame_count} frames"])
            item.setData(0, Qt.ItemDataRole.UserRole, sonication.name)
            for name, count in (
                ("Temperature RAW", len(sonication.temperature_frames)),
                ("Magnitude RAW", len(sonication.magnitude_frames)),
                ("SpectrumMsg", len(sonication.spectrum_files)),
                ("ACT", len(sonication.act_files)),
            ):
                item.addChild(QTreeWidgetItem([name, str(count)]))
            item.setExpanded(True)
            self.tree.addTopLevelItem(item)
        self.tree.setCurrentItem(self.tree.topLevelItem(1 if self.tree.topLevelItemCount() > 1 else 0))
        self.statusBar().showMessage(f"Loaded {len(self.package.sonications)} sonication(s)")

    def select_sonication(self):
        items = self.tree.selectedItems()
        if not items or items[0].parent() is not None:
            return
        name = items[0].data(0, Qt.ItemDataRole.UserRole)
        if not name:
            return
        self.current = next((son for son in self.package.sonications if son.name == name), None)
        if not self.current:
            return
        self.timer.stop()
        self.play_btn.setText("▶")
        self.replay.clear_cache()
        self._load_spectrum_channels()
        self._build_temperature_trends()
        self._build_acoustic_trends()
        self._build_frame_navigator()
        self.baseline_label.setText("Reference: first decoded Temperature RAW (Frame 1 / pre-sonication baseline)")
        self.set_frame(0)

    # ---------------------------------------------------------- Synchronization
    def _build_temperature_trends(self):
        self.max_temperature_trend = []
        self.mean_temperature_trend = []
        self.delta_trend = []
        if not self.current:
            return
        for index in range(self.current.replay_frame_count):
            try:
                data = self.replay.frame(self.current, index)
                self.max_temperature_trend.append(data.maximum_temperature if data.maximum_temperature is not None else np.nan)
                self.mean_temperature_trend.append(data.mean_temperature if data.mean_temperature is not None else np.nan)
                self.delta_trend.append(data.maximum_delta_temperature if data.maximum_delta_temperature is not None else np.nan)
            except Exception:
                self.max_temperature_trend.append(np.nan)
                self.mean_temperature_trend.append(np.nan)
                self.delta_trend.append(np.nan)
        x = self._frame_time_axis(self.current.replay_frame_count)
        self.max_temperature_curve.setData(x, np.asarray(self.max_temperature_trend, float))
        self.mean_temperature_curve.setData(x, np.asarray(self.mean_temperature_trend, float))

    def _build_acoustic_trends(self):
        if not self.current:
            return
        count = self.current.replay_frame_count
        peaks = np.full(count, np.nan)
        scores = np.full(count, np.nan)
        selected_frames = next(iter(self.spectrum_channels.values()), [])
        if selected_frames:
            raw_peak = np.asarray([
                float(np.nanmax(np.asarray(frame.amplitude, float))) if frame.amplitude else np.nan
                for frame in selected_frames
            ])
            raw_score = np.asarray([float(frame.confidence) for frame in selected_frames])
            for index in range(count):
                spectrum_index = self._map_replay_to_data(index, count, len(selected_frames))
                peaks[index] = raw_peak[spectrum_index]
                scores[index] = raw_score[spectrum_index]
            finite_peak = peaks[np.isfinite(peaks)]
            if finite_peak.size and np.nanmax(finite_peak) > np.nanmin(finite_peak):
                peaks = (peaks - np.nanmin(finite_peak)) / (np.nanmax(finite_peak) - np.nanmin(finite_peak))
            scores = scores / 100.0
        x = self._frame_time_axis(count)
        self.acoustic_peak_curve.setData(x, peaks)
        self.acoustic_score_curve.setData(x, scores)

    def _build_frame_navigator(self):
        self.frame_list.blockSignals(True)
        self.frame_list.clear()
        if not self.current:
            self.frame_list.blockSignals(False)
            return
        count = self.current.replay_frame_count
        for index in range(count):
            try:
                data = self.replay.frame(self.current, index)
                source = data.magnitude if data.magnitude is not None else data.temperature_delta
                icon = self._array_icon(source)
                seconds = self._index_to_seconds(index, count)
                text = f"{seconds:.1f} Sec\nFrame {index + 1}"
            except Exception:
                icon = QIcon()
                text = f"Frame {index + 1}"
            item = QListWidgetItem(icon, text)
            item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
            self.frame_list.addItem(item)
        self.frame_list.blockSignals(False)

    def set_frame(self, index: int):
        if not self.current:
            return
        try:
            data = self.replay.frame(self.current, index)
        except Exception as exc:
            QMessageBox.warning(self, APP_NAME, f"Unable to decode frame\n{exc}")
            return

        self.frame_index = data.replay_index
        count = self.current.replay_frame_count
        seconds = self._index_to_seconds(self.frame_index, count)

        self.timeline.blockSignals(True)
        self.timeline.setRange(0, max(0, count - 1))
        self.timeline.setValue(self.frame_index)
        self.timeline.blockSignals(False)
        self.frame_list.blockSignals(True)
        self.frame_list.setCurrentRow(self.frame_index)
        self.frame_list.blockSignals(False)
        self.frame_list.scrollToItem(self.frame_list.currentItem())

        self.frame_label.setText(f"Frame {self.frame_index + 1}/{count}   {seconds:.2f} sec")
        self.temperature_cursor.setPos(seconds)
        self.acoustic_cursor.setPos(seconds)

        magnitude_levels = None
        if data.magnitude is not None:
            magnitude_levels = (float(np.percentile(data.magnitude, 1)), float(np.percentile(data.magnitude, 99)))
        lut = pg.colormap.get("CET-L4").getLookupTable(0, 1, 256)
        hotspot = (data.hotspot_x, data.hotspot_y) if data.hotspot_x is not None else None
        hotspot_text = None
        if data.maximum_delta_temperature is not None:
            hotspot_text = (
                f"Max T {data.maximum_temperature:.1f} °C\n"
                f"Avg T {data.mean_temperature:.1f} °C\n"
                f"ΔT {data.maximum_delta_temperature:.1f} °C"
            )
        self.overlay.set_overlay(
            data.magnitude,
            data.temperature_delta,
            magnitude_levels,
            self._delta_levels(data.temperature_delta),
            lut,
            self.overlay_opacity.value() / 100.0,
            hotspot,
            hotspot_text,
        )

        spectrum_index, spectrum_count = self._update_replay_spectrum(count)
        self._update_analysis_hydrophone()
        self._update_parameter_table(data, count, spectrum_index, spectrum_count)
        self.sync_label.setText(
            f"Synchronized: Image {self.frame_index + 1}/{count} | "
            f"Temperature {data.temperature_index + 1 if data.temperature_index is not None else '-'} | "
            f"Spectrum {spectrum_index + 1 if spectrum_index is not None else '-'}/{spectrum_count or '-'}"
        )

    def _update_replay_spectrum(self, replay_count: int):
        self.spectrum_plot.clear()
        selected = self._selected_channels()
        colors = ["#ff9a22", "#00e0ff", "#ff66cc", "#66ff66", "#f4ef5b", "#ffffff"]
        first_index = None
        first_count = 0
        statuses = []
        self._spectrum_frame = None
        for channel_index, channel in enumerate(selected):
            frames = self.spectrum_channels.get(channel, [])
            if not frames:
                continue
            spectrum_index = self._map_replay_to_data(self.frame_index, replay_count, len(frames))
            frame = frames[spectrum_index]
            x = np.asarray(frame.frequency, float) / 1_000_000.0
            y = np.asarray(frame.amplitude, float)
            self.spectrum_plot.plot(x, y, pen=pg.mkPen(colors[channel_index % len(colors)], width=1.6))
            statuses.append(f"{channel}:{spectrum_index + 1}/{len(frames)}")
            if first_index is None:
                first_index = spectrum_index
                first_count = len(frames)
                self._spectrum_frame = frame
        self._add_spectrum_reference_lines(self.spectrum_plot, mhz=True)
        self._spectrum_status = "; ".join(statuses) if statuses else "No SpectrumMsg"
        self.current_spectrum_label.setText(
            f"Current replay frame → {self._spectrum_status} (ratio/time mapped fallback)"
        )
        return first_index, first_count

    def _update_analysis_hydrophone(self):
        if not hasattr(self, "analysis_spectrum_plot"):
            return
        self.analysis_spectrum_plot.clear()
        selected = self._selected_channels()
        replay_count = self.current.replay_frame_count if self.current else 1
        colors = ["#00bfff", "#ffcc00", "#ff66cc", "#66ff66", "#ff8844", "#cccccc"]
        stacked = self.hydro_arrangement.currentText() == "Stacked"
        for channel_index, channel in enumerate(selected):
            frames = self.spectrum_channels.get(channel, [])
            if not frames:
                continue
            spectrum_index = self._map_replay_to_data(self.frame_index, replay_count, len(frames))
            frame = frames[spectrum_index]
            x = np.asarray(frame.frequency, float) / 1000.0
            y = np.asarray(frame.amplitude, float)
            if stacked and y.size:
                span = max(1.0, float(np.nanmax(y) - np.nanmin(y)))
                y = y - channel_index * span * 1.2
            self.analysis_spectrum_plot.plot(x, y, pen=pg.mkPen(colors[channel_index % len(colors)], width=1.5))
        self._add_spectrum_reference_lines(self.analysis_spectrum_plot, mhz=False)
        self._update_waterfall()

    def _update_waterfall(self):
        selected = self._selected_channels()
        blocks = []
        max_columns = 0
        x_max = 1.0
        current_row = 0
        row_offset = 0
        replay_count = self.current.replay_frame_count if self.current else 1
        for channel in selected:
            frames = self.spectrum_channels.get(channel, [])
            rows = []
            for frame in frames:
                amplitude = np.asarray(frame.amplitude, float)
                if amplitude.size:
                    rows.append(amplitude)
                    max_columns = max(max_columns, amplitude.size)
                    if frame.frequency:
                        x_max = max(x_max, float(frame.frequency[-1]) / 1000.0)
            if rows:
                if not blocks:
                    current_row = row_offset + self._map_replay_to_data(self.frame_index, replay_count, len(rows))
                blocks.append(rows)
                row_offset += len(rows) + 2
        if not blocks or max_columns == 0:
            self.waterfall_image.setImage(np.empty((0, 0)))
            return
        bands = []
        for rows in blocks:
            padded = np.full((len(rows), max_columns), np.nan)
            for row_index, row in enumerate(rows):
                padded[row_index, : len(row)] = row
            bands.append(padded)
            bands.append(np.full((2, max_columns), np.nan))
        image = np.vstack(bands[:-1])
        finite = image[np.isfinite(image)]
        if finite.size:
            low, high = np.percentile(finite, [2, 98])
            self.waterfall_image.setImage(image, autoLevels=False, levels=(float(low), float(high)))
        else:
            self.waterfall_image.setImage(image)
        self.waterfall_image.setRect(QRectF(0, 0, x_max, image.shape[0]))
        self.waterfall_plot.setYRange(0, image.shape[0], padding=0)
        self.waterfall_cursor.setPos(current_row)

    # ------------------------------------------------------------- Helpers
    def _load_spectrum_channels(self):
        grouped: dict[str, list[Path]] = {}
        for path in self.current.spectrum_files:
            grouped.setdefault(self._channel_name(path), []).append(path)
        self.spectrum_channels = {
            name: self.spectrum_provider.load(files)
            for name, files in sorted(grouped.items())
        }
        self._rebuild_channel_controls()

    def _rebuild_channel_controls(self):
        for check_box in self.channel_checks.values():
            self.channel_bar.removeWidget(check_box)
            check_box.deleteLater()
        self.channel_checks.clear()
        insert_at = 2
        for name in self.spectrum_channels:
            check_box = QCheckBox(name)
            check_box.setChecked(True)
            check_box.toggled.connect(self._channel_selection_changed)
            self.channel_checks[name] = check_box
            self.channel_bar.insertWidget(insert_at, check_box)
            insert_at += 1
        self.all_channels.blockSignals(True)
        self.all_channels.setChecked(bool(self.channel_checks))
        self.all_channels.blockSignals(False)

    def _toggle_all_channels(self, checked: bool):
        for check_box in self.channel_checks.values():
            check_box.blockSignals(True)
            check_box.setChecked(checked)
            check_box.blockSignals(False)
        self.set_frame(self.frame_index)

    def _channel_selection_changed(self):
        states = [check_box.isChecked() for check_box in self.channel_checks.values()]
        self.all_channels.blockSignals(True)
        self.all_channels.setChecked(bool(states) and all(states))
        self.all_channels.blockSignals(False)
        self.set_frame(self.frame_index)

    def _selected_channels(self):
        selected = [name for name, check_box in self.channel_checks.items() if check_box.isChecked()]
        return selected or list(self.spectrum_channels)[:1]

    def _hydro_layout_changed(self):
        mode = self.hydro_view.currentText()
        self.analysis_spectrum_plot.setVisible(mode in ("Both", "Spectrum"))
        self.waterfall_plot.setVisible(mode in ("Both", "Waterfall"))
        if mode == "Spectrum":
            self.hydro_splitter.setSizes([1000, 0])
        elif mode == "Waterfall":
            self.hydro_splitter.setSizes([0, 1000])
        else:
            self.hydro_splitter.setSizes([600, 600])
        self._update_analysis_hydrophone()

    def _update_parameter_table(self, data, count: int, spectrum_index, spectrum_count):
        frequency_mhz = self.package.main_frequency_hz / 1_000_000.0
        rows = [
            ("Energy", "From ACT when available", "Sonication", self.current.name),
            ("Power", "From ACT when available", "Replay Frame", f"{self.frame_index + 1}/{count}"),
            ("Duration", f"{self._index_to_seconds(count - 1, count):.1f} sec", "Temperature RAW", f"{data.temperature_index + 1 if data.temperature_index is not None else '-'}"),
            ("Frequency", f"{frequency_mhz:.3f} MHz", "SpectrumMsg", f"{spectrum_index + 1 if spectrum_index is not None else '-'}/{spectrum_count or '-'}"),
            ("Reference", "Temperature RAW Frame 1", "Max Temperature", f"{data.maximum_temperature:.1f} °C" if data.maximum_temperature is not None else "-"),
            ("ΔT Formula", "Current Temperature - Reference", "Max ΔTemperature", f"{data.maximum_delta_temperature:.1f} °C" if data.maximum_delta_temperature is not None else "-"),
        ]
        self.parameter_table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            for column_index, value in enumerate(row):
                self.parameter_table.setItem(row_index, column_index, QTableWidgetItem(str(value)))

    def _add_spectrum_reference_lines(self, plot, mhz: bool):
        if not self.package:
            return
        divisor = 1_000_000.0 if mhz else 1000.0
        main = self.package.main_frequency_hz / divisor
        for frequency, label in ((main / 2, "Sub"), (main, "Main"), (main * 2, "2nd"), (main * 3, "3rd")):
            plot.addItem(pg.InfiniteLine(pos=frequency, angle=90, movable=False, label=label))

    def _delta_levels(self, delta):
        index = self.range_combo.currentIndex()
        if index == 1:
            return 0.0, 5.0
        if index == 2:
            return 0.0, 10.0
        if index == 3:
            return 0.0, 20.0
        if index == 4:
            return 0.0, 30.0
        finite = delta[np.isfinite(delta)] if delta is not None else np.array([])
        return (0.0, max(1.0, float(np.percentile(finite, 99)))) if finite.size else None

    @staticmethod
    def _channel_name(path: Path) -> str:
        text = f"{path.parent.name}_{path.stem}"
        for pattern in (r"(?:^|[_\- ])(?:CH|HP)[_\- ]?(\d+)", r"hydrophone[_\- ]?(\d+)"):
            match = re.search(pattern, text, re.I)
            if match:
                return f"CH{int(match.group(1))}"
        return "CH1"

    @staticmethod
    def _map_replay_to_data(index: int, replay_count: int, data_count: int) -> int:
        """Map one replay position to another stream with endpoint-safe ratio.

        This is the explicit fallback when timestamps are absent. It guarantees
        frame movement changes Spectrum/Waterfall position instead of leaving a
        static first record.
        """
        if data_count <= 1 or replay_count <= 1:
            return 0
        ratio = index / float(replay_count - 1)
        return max(0, min(data_count - 1, int(round(ratio * (data_count - 1)))))

    @staticmethod
    def _index_to_seconds(index: int, count: int) -> float:
        # 4 s is the typical thermometry cadence; actual timestamp integration
        # remains isolated for the next data-validation commit.
        return max(0.0, float(index) * 4.0)

    def _frame_time_axis(self, count: int):
        return np.asarray([self._index_to_seconds(index, count) for index in range(count)], float)

    @staticmethod
    def _array_icon(array):
        if array is None:
            return QIcon()
        values = np.nan_to_num(np.asarray(array, float))
        low, high = np.percentile(values, [2, 98]) if values.size else (0, 1)
        if high <= low:
            high = low + 1
        gray = np.clip((values - low) / (high - low) * 255, 0, 255).astype(np.uint8)
        rgb = np.stack([gray, gray, gray], axis=2)
        height, width = rgb.shape[:2]
        image = QImage(rgb.data, width, height, 3 * width, QImage.Format.Format_RGB888).copy()
        return QIcon(QPixmap.fromImage(image).scaled(110, 100, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    # -------------------------------------------------------------- Controls
    def _temperature_plot_clicked(self, event):
        if not self.current:
            return
        point = self.temperature_plot.plotItem.vb.mapSceneToView(event.scenePos())
        self.set_frame(int(round(point.x() / 4.0)))

    def _acoustic_plot_clicked(self, event):
        if not self.current:
            return
        point = self.acoustic_control_plot.plotItem.vb.mapSceneToView(event.scenePos())
        self.set_frame(int(round(point.x() / 4.0)))

    def slider_changed(self, value):
        self.set_frame(value)

    def previous_frame(self):
        self.set_frame(max(0, self.frame_index - 1))

    def next_frame(self):
        if not self.current:
            return
        next_index = self.frame_index + 1
        if next_index >= self.current.replay_frame_count:
            next_index = 0 if self.timer.isActive() else self.current.replay_frame_count - 1
        self.set_frame(next_index)

    def toggle_play(self):
        if self.timer.isActive():
            self.timer.stop()
            self.play_btn.setText("▶")
        else:
            self.timer.start(max(20, int(1000 / self.speed.value())))
            self.play_btn.setText("Ⅱ")

    def speed_changed(self, value):
        if self.timer.isActive():
            self.timer.start(max(20, int(1000 / value)))

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Left:
            self.previous_frame()
            return
        if event.key() == Qt.Key.Key_Right:
            self.next_frame()
            return
        if event.key() == Qt.Key.Key_Space:
            self.toggle_play()
            return
        super().keyPressEvent(event)

    def wheelEvent(self, event):
        if self.current:
            self.set_frame(self.frame_index + (1 if event.angleDelta().y() < 0 else -1))
            event.accept()
            return
        super().wheelEvent(event)

    def dragEnterEvent(self, event):
        if any(url.isLocalFile() for url in event.mimeData().urls()):
            event.acceptProposedAction()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            if url.isLocalFile():
                path = Path(url.toLocalFile())
                if path.is_dir() or path.suffix.lower() == ".zip":
                    self.load(path)
                    event.acceptProposedAction()
                    break

    def _restore(self):
        try:
            geometry = self.settings.value("geometry")
            if geometry:
                self.restoreGeometry(geometry)
        except Exception:
            pass

    def closeEvent(self, event):
        self.settings.setValue("geometry", self.saveGeometry())
        super().closeEvent(event)
