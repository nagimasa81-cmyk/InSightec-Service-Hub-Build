from __future__ import annotations

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import Signal, QPointF, Qt
from PySide6.QtWidgets import QGroupBox, QVBoxLayout


class ImagePanel(QGroupBox):
    def __init__(self, title, parent=None):
        super().__init__(title, parent)
        self.view = pg.PlotWidget(); self.view.setAspectLocked(True); self.view.invertY(False)
        self.view.hideAxis("left"); self.view.hideAxis("bottom")
        self.image = pg.ImageItem(axisOrder="row-major"); self.view.addItem(self.image)
        layout = QVBoxLayout(self); layout.setContentsMargins(2,4,2,2); layout.addWidget(self.view)

    def set_image(self, array, levels=None, lut=None, hotspot=None, hotspot_text=None):
        if array is None: self.image.clear(); return
        self.image.setImage(np.flipud(np.asarray(array)), autoLevels=levels is None, levels=levels)
        self.image.setLookupTable(lut); self.view.autoRange(padding=0.01)


class OverlayPanel(QGroupBox):
    cursorMoved = Signal(float, float)

    def __init__(self, title="Magnitude + Temperature Overlay", parent=None):
        super().__init__(title, parent)
        self.view = pg.PlotWidget(); self.view.setAspectLocked(True); self.view.invertY(False)
        self.view.hideAxis("left"); self.view.hideAxis("bottom"); self.view.setMouseEnabled(x=True,y=True)
        self.magnitude_item = pg.ImageItem(axisOrder="row-major")
        self.temperature_item = pg.ImageItem(axisOrder="row-major")
        self.view.addItem(self.magnitude_item); self.view.addItem(self.temperature_item)
        self.cursor_target = pg.TargetItem(movable=True,size=18,symbol="+",pen=pg.mkPen("#00d9ff",width=2),hoverPen=pg.mkPen("#ffffff",width=2))
        self.cursor_target.setVisible(False); self.view.addItem(self.cursor_target)
        self.cursor_target.sigPositionChanged.connect(self._target_dragged)
        self.cursor_label = pg.TextItem(anchor=(0,1),color="#f5f5f5",fill=pg.mkBrush(0,0,0,160)); self.cursor_label.setVisible(False); self.view.addItem(self.cursor_label)
        self.roi_box = pg.RectROI((0,0),(3,3),movable=False,pen=pg.mkPen("#00a8ff",width=2))
        self.roi_box.setAcceptedMouseButtons(Qt.MouseButton.NoButton); self.roi_box.setVisible(False); self.view.addItem(self.roi_box)
        self._shape=None; self._updating_target=False
        self.view.scene().sigMouseClicked.connect(self._clicked)
        layout=QVBoxLayout(self); layout.setContentsMargins(2,4,2,2); layout.addWidget(self.view)

    def _display_to_data_y(self, y):
        return float(self._shape[0]-1-y) if self._shape is not None else float(y)
    def _data_to_display_y(self, y):
        return float(self._shape[0]-1-y) if self._shape is not None else float(y)

    def _clicked(self,event):
        if self._shape is None or event.button()!=Qt.MouseButton.LeftButton: return
        point=self.view.plotItem.vb.mapSceneToView(event.scenePos())
        x=float(np.clip(point.x(),0,self._shape[1]-1)); yd=float(np.clip(point.y(),0,self._shape[0]-1))
        self.cursorMoved.emit(x,self._display_to_data_y(yd))

    def _target_dragged(self):
        if self._updating_target or self._shape is None: return
        pos=self.cursor_target.pos(); x=float(np.clip(pos.x(),0,self._shape[1]-1)); yd=float(np.clip(pos.y(),0,self._shape[0]-1))
        self.cursorMoved.emit(x,self._display_to_data_y(yd))

    def set_cursor(self,x,y,text=""):
        yd=self._data_to_display_y(y); self._updating_target=True; self.cursor_target.setPos(QPointF(x,yd)); self._updating_target=False
        self.cursor_label.setPos(x+4,yd-4); self.cursor_label.setText(text); self.cursor_target.setVisible(True); self.cursor_label.setVisible(bool(text))

    def set_roi(self,center_x,center_y,radius=None,width=None,height=None):
        if center_x is None or center_y is None: self.roi_box.setVisible(False); return
        width=float(width or (radius or 1)*2); height=float(height or (radius or 1)*2); yd=self._data_to_display_y(center_y)
        self.roi_box.setPos((center_x-width/2.0,yd-height/2.0),update=False); self.roi_box.setSize((width,height),update=False); self.roi_box.setVisible(True)

    def fit_image(self): self.view.autoRange(padding=0.01)

    def set_overlay(self,magnitude,temperature,magnitude_levels=None,temperature_levels=None,temperature_lut=None,opacity=0.55,hotspot=None,hotspot_text=None,temperature_threshold=None,fit=False):
        if magnitude is None: self.magnitude_item.clear()
        else:
            mag=np.asarray(magnitude); self._shape=mag.shape[:2]; self.magnitude_item.setLookupTable(None)
            self.magnitude_item.setImage(np.flipud(mag),autoLevels=magnitude_levels is None,levels=magnitude_levels)
        if temperature is None: self.temperature_item.clear()
        else:
            temp=np.asarray(temperature); self._shape=temp.shape[:2]; shown=temp if temperature_threshold is None else np.where(temp>=temperature_threshold,temp,np.nan)
            self.temperature_item.setImage(np.flipud(shown),autoLevels=temperature_levels is None,levels=temperature_levels)
            self.temperature_item.setLookupTable(temperature_lut); self.temperature_item.setOpacity(max(0.0,min(1.0,opacity)))
        if fit: self.fit_image()
