# COMMIT R0190b — Replay chart double-click enlarge restoration

- Restores double-click on Replay chart bodies as the compact replacement for the removed chart-local enlarge buttons.
- Reuses the existing synchronized `ChartPopup` path for Temperature, Spectrum, Power/Score, and Waterfall charts.
- Preserves R0131 bottom-axis drag X zoom.
- Preserves generic double-click reset for non-Replay analysis charts and Spectrum Dump Analyzer charts.
- Uses the existing installation guard so a Replay chart never receives both enlarge and reset handlers.
