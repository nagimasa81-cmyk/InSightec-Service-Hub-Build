# COMMIT R0190c — chart double-click ancestry repair + DQA observed-focus recovery

- Double-click contract audited across Replay, generic analysis charts, and CPC Spectrum / 8CH Hydrophone Analyzer.
- Replay keeps its synchronized domain-specific enlarged popup. Generic Main charts and every Analyzer PlotWidget now enlarge on double-click instead of inheriting the R0131 reset-only behavior.
- The common installer can upgrade an already-installed legacy reset handler, eliminating the idempotence trap that could preserve an ancestor action.
- DQA keeps strict exact Thermal→Magnitude pairing as the preferred path, but no longer loses all observed thermal-focus evidence when the magnitude pair/mask is unavailable. A validated MEMP same-raster local thermal hotspot may recover the observed focus; X/Y/Z zero points remain the independently detected DQA phantom circle/lower-line geometry.
- Import Diagnostics schema v3 now exports the complete DQA focus result/evidence so a future N/A can be diagnosed from the diagnostics ZIP without guessing.
