from pathlib import Path

MAIN = (Path(__file__).resolve().parents[1] / 'src' / 'ui' / 'main_window.py').read_text(encoding='utf-8')


def _block(start: str, end: str) -> str:
    a = MAIN.index(start)
    b = MAIN.index(end, a)
    return MAIN[a:b]


def test_summary_tab_uses_canonical_initial_data_gate():
    tab = _block('    def _main_tab_changed', '    def _sonication_summary_initial_data_busy')
    assert 'self._request_sonication_summary_detail()' in tab
    assert 'self._refresh_sonication_summary()' not in tab.split('if widget is self.sonication_summary_tab:',1)[1].split('elif widget is',1)[0]


def test_summary_gate_waits_for_whole_study_terminal_preload():
    gate = _block('    def _sonication_summary_initial_data_busy', '    def _seed_sonication_summary_fast')
    assert 'preload_complete' in gate
    assert '_spectrum_preload_failed_workspace' in gate
    assert 'ready_indices' not in gate
    assert '_selected_data_thread' not in gate
    assert 'QTimer.singleShot' not in gate

def test_source_switch_invalidates_previous_summary_generation_and_workers():
    switch = _block('    def _prepare_source_switch', '    def _run_pending_source_load')
    assert '_sonication_summary_generation=int(getattr(self,"_sonication_summary_generation",0))+1' in switch
    assert '_cancel_sonication_summary_worker()' in switch
    assert '_sonication_summary_pending_refresh=False' in switch
    assert '_sonication_summary_waiting_for_initial_data=False' in switch


def test_worker_completion_resumes_summary_event_driven():
    preload = _block('    def _spectrum_preload_thread_finished', '    def _spectrum_preload_progressed')
    selected = _block('    def _selected_replay_data_thread_finished', '    def _selected_replay_data_progressed')
    assert '_resume_sonication_summary_after_initial_data' in preload
    assert '_resume_sonication_summary_after_initial_data' in selected
    assert 'return' in preload and 'return' in selected


def test_package_adoption_marks_summary_waiting_until_binding_finishes():
    load = _block('    def _package_load_finished', '    def _start_initial_spectrum_preload_after_images')
    assert '_seed_sonication_summary_fast()' in load
    assert '_sonication_summary_needs_detail=True' in load
    assert '_sonication_summary_waiting_for_initial_data=True' in load
