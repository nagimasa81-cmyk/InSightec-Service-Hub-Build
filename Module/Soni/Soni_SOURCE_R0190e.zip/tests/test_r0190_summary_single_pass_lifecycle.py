from pathlib import Path

MAIN=(Path(__file__).parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')

def block(a,b):
    return MAIN[MAIN.index(a):MAIN.index(b, MAIN.index(a)+1)]

def test_summary_gate_requires_terminal_whole_study_preload():
    b=block('    def _sonication_summary_initial_data_busy','    def _request_sonication_summary_detail')
    assert 'preload_complete' in b
    assert '_spectrum_preload_failed_workspace' in b
    assert 'ready_indices' not in b
    assert '_selected_data_thread' not in b

def test_partial_sonication_ready_never_releases_summary():
    b=block('    def _spectrum_preload_sonication_ready','    def _adopt_authoritative_spectrum_context')
    assert '_resume_sonication_summary_after_initial_data' not in b
    assert '_request_sonication_summary_detail' not in b

def test_context_adoption_does_not_dirty_or_restart_summary():
    b=block('    def _adopt_authoritative_spectrum_context','    def _spectrum_preload_ready')
    assert '_sonication_summary_needs_detail=True' not in b
    assert '_request_sonication_summary_detail' not in b
    assert '_refresh_sonication_summary' not in b

def test_terminal_ready_and_failed_are_release_owners():
    ready=block('    def _spectrum_preload_ready','    def _spectrum_preload_failed')
    failed=block('    def _spectrum_preload_failed','    def _open_hydrophone_window')
    assert '_resume_sonication_summary_after_initial_data' in ready
    assert '_resume_sonication_summary_after_initial_data' in failed

def test_one_full_detail_pass_per_workspace_generation_token():
    req=block('    def _request_sonication_summary_detail','    def _resume_sonication_summary_after_initial_data')
    assert '_sonication_summary_completed_workspace' in req
    assert '_sonication_summary_running_workspace' in req
    assert 'self._refresh_sonication_summary()' in req
    fin=block('    def _sonication_summary_finished','    def _start_sonication_summary_temperature_background')
    assert '_sonication_summary_completed_workspace=token' in fin
    assert 'QTimer.singleShot(0,self._request_sonication_summary_detail)' not in fin
    assert 'QTimer.singleShot(0,self._refresh_sonication_summary)' not in fin

def test_source_switch_resets_once_token():
    b=block('    def _prepare_source_switch','    def _open_zip_password_settings') if False else block('    def _prepare_source_switch','    def _run_pending_source_load')
    assert '_sonication_summary_completed_workspace=None' in b
    assert '_sonication_summary_running_workspace=None' in b
