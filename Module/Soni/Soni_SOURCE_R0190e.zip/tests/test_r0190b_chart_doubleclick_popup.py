from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "src/ui/main_window.py").read_text(encoding="utf-8")
HELPER = (ROOT / "src/ui/chart_interaction.py").read_text(encoding="utf-8")

def test_replay_chart_panel_restores_doubleclick_enlarge():
    assert "double_click_callback=lambda k=key: self._open_chart_popup(k)" in MAIN
    assert "def _open_chart_popup(self,key: str):" in MAIN

def test_generic_doubleclick_reset_is_preserved():
    assert "if self.double_click_callback is not None:" in HELPER
    assert "reset_plot_zoom(self.plot, self.reset_callback)" in HELPER

def test_installer_remains_idempotent():
    assert "_soni_x_axis_range_zoom_installed" in HELPER

def test_replay_chart_keys_all_use_chart_panel():
    for key in ("temperature", "spectrum", "acoustic", "waterfall"):
        assert f'"{key}"' in MAIN
