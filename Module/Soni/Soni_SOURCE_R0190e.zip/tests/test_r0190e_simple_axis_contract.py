from pathlib import Path
S=(Path(__file__).parents[1]/'src/services/dqa_focus_alignment_service.py').read_text(encoding='utf-8')

def test_x_is_axial_only_and_y_is_sagittal_ap_only():
    b=S.split('def analyze_series',1)[1].split('def cached_series',1)[0]
    axial=b.split("sagittal=observed.get('Sagittal')",1)[0]
    sagittal=b.split("sagittal=observed.get('Sagittal')",1)[1]
    assert 'x=float(direct_delta[0])' in axial
    assert 'y=float(direct_delta[1])' not in axial
    assert "ap_center=candidate.get('phantom_ap_center_ras')" in sagittal
    assert "y=float(focus_plane[1]-float(ap_center))" in sagittal

def test_z_keeps_lower_line_plus_20mm_contract():
    b=S.split('def analyze_series',1)[1].split('def cached_series',1)[0]
    assert 'ref_ras=baseline.copy(); ref_ras[2]+=20.0' in b
    assert 'z=float(direct_delta[2])' in b
