from pathlib import Path
import ast
ROOT=Path(__file__).parents[1]
H=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
C=(ROOT/'src/services/cavitation_control_timeline_service.py').read_text(encoding='utf-8')

def test_exciter_onset_classification():
    assert 'exciter_power_times_s' in C
    assert 'irradiation_onset_s' in C
    assert 'Pre-irradiation' in C
    assert 'counts_as_cavitation' in C
    assert 'exciter_power_w' in C
    assert 'exciter_token=re.search' in C

def test_single_event_source_for_plot_and_table():
    m=H.split('def _draw_observed_cavitation_timeline',1)[1].split('\n    def ',1)[0]
    assert 'self._visible_observed_events = [' in m
    assert 'for original_index,ev in self._visible_observed_events' in m
    assert 'setRowCount(len(self._visible_observed_events))' in m
    assert 'DISPLAY INTEGRITY ERROR' in m

def test_filtered_row_mapping():
    assert 'visible_row=next((i for i,(orig,_ev) in enumerate(visible) if orig==original_row),None)' in H

def test_view_lock():
    assert 'self.cavitation_lock_view_check.setChecked(True)' in H
    assert 'setMouseEnabled(x=not locked,y=not locked)' in H
    assert 'def _reset_cavitation_views' in H

def test_why_phase_and_classification():
    assert 'Irradiation phase:' in H
    assert 'PRE-IRRADIATION CONTROL EVALUATION' in H
    assert 'TREATMENT CAVITATION' in H
    assert 'Exciter power at event:' in H

def test_table_click_opens_why():
    m=H.split('def _observed_cavitation_event_selected',1)[1].split('\n    def ',1)[0]
    assert 'self._show_event_why_popup(event)' in m

def test_ast():
    ast.parse(H); ast.parse(C)
