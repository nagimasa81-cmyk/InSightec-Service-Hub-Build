from pathlib import Path
import ast
ROOT=Path(__file__).parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
REPLAY=(ROOT/'src/services/replay_service.py').read_text(encoding='utf-8')
TREE=ast.parse(MAIN)
MW=next(n for n in TREE.body if isinstance(n,ast.ClassDef) and n.name=='MainWindow')
METHODS={n.name:n for n in MW.body if isinstance(n,ast.FunctionDef)}
def src(name):
    fn=METHODS[name]; lines=MAIN.splitlines(); return '\n'.join(lines[fn.lineno-1:fn.end_lineno])

def test_temperature_trend_independent_from_load_images():
    s=src('_build_temperature_trends')
    assert 'temperature_trend(self.current)' in s
    assert 'if not self._image_loading_enabled()' not in s
    assert 'Numerical thermometry' in s

def test_metadata_frame_contains_temperature_numbers():
    assert 'temperature_frame_metrics' in REPLAY
    assert 'metrics.get("maximum_temperature")' in REPLAY
    assert '_temperature_trend_cache' in REPLAY

def test_set_frame_no_longer_returns_for_images_off():
    s=src('set_frame')
    off=s.split('if not images_enabled:',1)[1].split('magnitude_levels',1)[0]
    assert 'return' not in off
    assert '_update_power_score_for_frame' in s
    assert '_update_replay_spectrum' in s
    assert '_apply_workstation_replay_behavior' in s
    assert '_update_default_cavitation_intelligence' in s

def test_image_rendering_still_gated():
    s=src('set_frame')
    assert 'if images_enabled:' in s
    gated=s.split('if images_enabled:',1)[1]
    assert 'self.overlay.set_overlay(' in gated

def test_spectrum_analyzer_shows_before_heavy_load():
    s=src('_open_hydrophone_window')
    assert s.index('self.hydrophone_window.show()') < s.index('load_package(package,index')
    assert 'QTimer.singleShot(0,load_context)' in s

def test_hidden_analyzer_not_eagerly_synced():
    assert 'self.hydrophone_window is not None and self.hydrophone_window.isVisible()' in MAIN
