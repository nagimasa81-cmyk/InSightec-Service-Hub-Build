from pathlib import Path
import ast
ROOT=Path(__file__).parents[1]
H=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
M=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
R=(ROOT/'src/services/registration_overlay_service.py').read_text(encoding='utf-8')

def test_control_timeline_click_is_connected():
    assert 'self.cavitation_control_plot.scene().sigMouseClicked.connect(self._cavitation_control_plot_clicked)' in H

def test_probable_location_follows_replay_after_point_inspection():
    assert 'self.cavitation_observed_table.clearSelection()' in H
    assert 'self._event_navigation_in_progress' in H
    assert 'self._sync_cavitation_dynamic_views()' in H

def test_hydrophone_band_has_current_frame_cursor():
    assert 'self.cavitation_heatmap_cursor = pg.InfiniteLine' in H
    assert 'self.cavitation_heatmap_cursor.setPos' in H

def test_display_change_pauses_replay_to_prevent_loop():
    assert 'def _pause_replay_for_view_change' in H
    assert 'def _resume_replay_after_view_change' in H
    assert 'self._view_change_guard' in H

def test_new_source_latest_open_wins_and_clears_old_context():
    assert 'self._pending_load_source=source' in M
    assert 'def _prepare_source_switch' in M
    assert 'self.hydrophone_window.reset_source_context()' in M
    assert 'discard this stale result' in M

def test_registration_display_contour_not_inflated():
    assert 'r>=ro-2.0' in R
    assert 'for _ in range(1):' in R

def test_ast():
    ast.parse(H); ast.parse(M); ast.parse(R)
