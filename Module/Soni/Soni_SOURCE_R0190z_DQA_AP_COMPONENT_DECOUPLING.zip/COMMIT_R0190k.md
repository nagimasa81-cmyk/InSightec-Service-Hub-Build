# R0190k

- DQA axial phantom RL reference now uses sub-pixel interpolation of opposing structural edges; no expected-offset fitting.
- Keeps R0190j Observed/Target/Phantom marker visibility controls and Observed-vs-Target phase-direction emphasis.
- Keeps uniform chart double-click RESET contract and suppression of ordinary-click popup/jump handlers on double-click.
- 4267 remains a geometry validation sample; measured values are not hard-coded.
