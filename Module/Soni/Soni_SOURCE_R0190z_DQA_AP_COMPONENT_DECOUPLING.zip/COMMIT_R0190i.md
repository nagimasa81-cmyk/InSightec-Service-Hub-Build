# R0190j

- Audited chart double-click handling across Replay, Cavitation, Hydrophone and Spectrum Analyzer plot widgets.
- Double-left-click is globally reserved for RESET; semantic single-click handlers explicitly ignore double-click events.
- Common chart installer now revisits already-installed PlotWidgets and clears stale legacy reset/popup callback ownership.
- Preserves R0190h DQA geometry correction while continuing fail-closed phantom-reference behavior.
