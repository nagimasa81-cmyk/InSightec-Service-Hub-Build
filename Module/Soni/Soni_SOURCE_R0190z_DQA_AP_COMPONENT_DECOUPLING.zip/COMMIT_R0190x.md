# R0190x — exact-raster DQA calculator hardening

Trigger: 4267 R0190v diagnostics + workstation screenshots showed the displayed reference/focus separation near 11 mm while Summary reported X=-4.9 mm / Y=-3.1 mm.

Root cause confirmed in diagnostics:
- Observed Axial focus is owned by S1 thermal 5-1-3-4.raw, but calculator X borrowed `DQA-Axial S1 field 7 image 12`.
- Observed Sagittal focus is owned by S2 thermal 5-2-3-4.raw, but calculator Y/Z borrowed `DQA-Sagittal S1 field 12 image 13`; the focus was +8.39 mm out of that reference plane.
- Exact thermal↔magnitude pairing had already failed closed, but a later registered-stack fallback silently reintroduced cross-acquisition phantom geometry and emitted numeric X/Y/Z anyway.

Fix:
- Remove registered-stack numeric fallback completely.
- `analyze_series()` accepts only phantom geometry from the exact magnitude/geometry pair attached to the selected observed thermal focus.
- Do not substitute nearest DQA Axial/Sagittal stack slices.
- If exact pairing is unavailable, the affected DQA component is Unavailable rather than a plausible but physically different number.
- No expected-value fitting, screenshot calibration, clipping, fixture/SHA branching, or target pull.
- R0190v weighted-centroid observed focus, per-sonication Phase, R0190w component marker display, and Distance fixes are preserved.

4267 consequence with Diagnostics(10) alone:
The previous -4.9/-3.1 values are explicitly invalidated. Diagnostics(10) does not contain the RAW payload needed to recompute the exact paired phantom centres, so R0190x must fail closed for those components until the original export is loaded.
