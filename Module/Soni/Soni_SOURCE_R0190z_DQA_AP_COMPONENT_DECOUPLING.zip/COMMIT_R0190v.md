# R0190v — per-Sonication phase + thermal centroid observed focus
- Observed focus is now the sub-pixel, temperature-rise-weighted centroid of the coherent local hotspot selected in the exact thermometry raster, not the 3x3-smoothed hottest pixel.
- Centroiding uses only local thermometry signal above local median; planned target remains a search-window seed and cannot pull the centroid.
- Observed-vs-Target phase axis is resolved independently from the exact thermometry raster's `freqdirection` and row/column RAS direction cosines for each Sonication.
- Removed UI inheritance of one series phase axis into every Summary row.
- R0190u exact-raster marker/source guards and R0190s Distance fixes retained.
