# R0190z — AP/SI component decoupling

Real Windows validation of 4267 on R0190y produced X=-3.8 mm but Y/Z unavailable.
Root cause: Y/AP calculation was nested inside the Sagittal lower-line/SI reference
success branch. Therefore a missing SI reference incorrectly erased an otherwise
valid AP measurement.

R0190z resolves Y independently from:
- exact-paired Axial phantom circle physical A coordinate, and
- observed Sagittal thermal focus physical A coordinate.

Z/Tilt remain fail-closed when the Sagittal lower-line reference is unavailable.
No expected-value fitting, fixture branching, or 11 mm constant is used.
