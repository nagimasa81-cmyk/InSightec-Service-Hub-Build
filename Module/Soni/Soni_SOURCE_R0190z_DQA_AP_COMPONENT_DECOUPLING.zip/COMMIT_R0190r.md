# R0190r — DQA SI physical-edge orientation hardening

- Detect both edges of the finite-thickness sagittal DQA lower reference bar.
- Convert both edge candidates into MR-RAS before selecting the reference edge.
- Select anatomical superior (+S RAS), never raster/pixel "upper", so flipped sagittal exports do not invert the SI reference.
- Add sub-pixel y interpolation and per-column robust line fitting for both edges.
- Preserve stack consensus and same-raster focus/reference geometry.
- Record both edge candidate S coordinates in diagnostics for audit.
- No expected DQA displacement, fixture name, or export-specific correction is used.
