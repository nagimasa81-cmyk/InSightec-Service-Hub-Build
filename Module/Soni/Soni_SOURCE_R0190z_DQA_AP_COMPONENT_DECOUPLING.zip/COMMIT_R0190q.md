# R0190q

- Sonication Summary Observed vs Target is now Sonication-local (one row per Sonication), while DQA Focus alignment remains series-common.
- Phase-encoding displacement remains the bold visible value; full RL/AP/SI observed-vs-target vector is in each row tooltip.
- Distance tool is additive: each Distance press creates a new ruler centered in the current visible ViewBox and sized to the current zoom.
- The newest/moved ruler is selected; Clear removes only that selected ruler. Existing rulers remain.
- Distance labels use physical mm spacing when available and show D1/D2/... identifiers.
