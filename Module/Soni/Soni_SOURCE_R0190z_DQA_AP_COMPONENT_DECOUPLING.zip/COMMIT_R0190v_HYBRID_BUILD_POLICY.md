R0190v Hybrid build-policy hardening: declare pytest because 00_VERIFY_SOURCE.bat invokes it; add INSIGHTEC_HUB_PYTEST_GUARD_V2 before BAT pytest invocation. No runtime/DQA algorithm changes.
