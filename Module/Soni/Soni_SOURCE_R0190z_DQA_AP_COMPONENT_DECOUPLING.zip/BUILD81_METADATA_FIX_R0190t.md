# R0190t Build 81 metadata consistency fix

Build 81 stopped in verify_source.py because release metadata still identified RC7.10-R0190s while runtime constants/version.json identified RC7.10-R0190t.

Corrected without changing R0190t functional logic:
- VERSION -> RC7.10-R0190t
- insightec_build_contract.json source_version -> rc7.10-r0190t
- Nuitka CI/local file descriptions -> RC7.10-R0190t
- corrected COMMIT_R0190s.md heading typo only

Validation:
- stale RC7.10-R0190s metadata grep: none
- python compileall: PASS
- python verify_source.py: VERIFY_SOURCE_OK
- R0190s Distance + R0190t DQA marker regression tests: 6 passed
- full pytest cannot collect in this Linux container because PySide6 is not installed; Build 81 diagnostics show Windows CI installs PySide6 successfully before verification.
