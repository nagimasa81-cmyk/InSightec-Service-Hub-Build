# R0190w — component-exact DQA reference overlay

- Axial phantom display reference is RL-only: phantom R at observed-focus A/S.
- Sagittal display references are decomposed: AP reference for Y; lower/+20 mm SI references for Z.
- Prevents unrelated coordinates from a different registered reference slice from making markers look displaced.
- Calculator X/Y/Z values and R0190v hotspot-centroid/phase logic are unchanged.
- Distance tool hardening remains intact.
