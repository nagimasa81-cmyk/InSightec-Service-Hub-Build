# R0190n — DQA sagittal physical-reference consensus hardening

- Treat the sagittal SI reference as the physical **upper edge** of the finite-thickness lower reference bar.
- Evaluate that fitted line at the Observed-focus X coordinate.
- Add cross-slice physical-S consensus and reject sagittal baseline outliers before same-raster selection.
- Compute aggregate SI/AP only from consensus-consistent sagittal candidates.
- Record baseline edge contract, support and stack residual in diagnostic overlays.
- Preserve R0190m phantom AP physical-centre logic and R0190i–m chart double-click RESET hardening.
- No expected RL/AP/SI value, fixture identity, or numeric clipping is used by the detector.
