from types import SimpleNamespace
from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService


def test_series_common_uses_axial_xy_sagittal_z_and_tilt(monkeypatch, tmp_path):
    svc=DqaFocusAlignmentService()
    sons=[SimpleNamespace(sonication_number=i) for i in range(1,6)]
    pkg=SimpleNamespace(workspace=tmp_path, sonications=sons)
    monkeypatch.setattr(svc,'is_dqa',lambda _p: True)
    monkeypatch.setattr(svc,'_summary_focal_ras',lambda _p:{i:(0.,0.,0.) for i in range(1,6)})
    monkeypatch.setattr(svc,'_find_mri_params',lambda _w: None)
    measurements={
        1:{'orientation':'Axial','x_mm':0.0,'y_mm':-0.1,'z_mm':None,'evidence':'a1'},
        2:{'orientation':'Sagittal','x_mm':None,'y_mm':1.0,'z_mm':1.1,'evidence':'s2'},
        3:{'orientation':'Axial','x_mm':0.0,'y_mm':-0.1,'z_mm':None,'evidence':'a3'},
        4:{'orientation':'Axial','x_mm':1.1,'y_mm':0.0,'z_mm':None,'evidence':'a4'},
        5:{'orientation':'Axial','x_mm':1.1,'y_mm':-0.1,'z_mm':None,'evidence':'a5'},
    }
    monkeypatch.setattr(svc,'_planned_focus_native_measurement',lambda son,_rows,_planned:measurements[son.sonication_number])
    monkeypatch.setattr(svc,'_dqa_reference_geometry',lambda _p:{'tilt_deg':-0.7,'evidence':['tilt']})
    r=svc.analyze_series(pkg)
    assert r.x_mm == 0.55
    assert r.y_mm == -0.1
    assert r.z_mm == 1.1
    assert r.tilt_deg == -0.7
    assert r.confidence == 'High'


def test_series_common_does_not_use_sagittal_y_for_summary_y(monkeypatch, tmp_path):
    svc=DqaFocusAlignmentService()
    sons=[SimpleNamespace(sonication_number=1),SimpleNamespace(sonication_number=2)]
    pkg=SimpleNamespace(workspace=tmp_path, sonications=sons)
    monkeypatch.setattr(svc,'is_dqa',lambda _p: True)
    monkeypatch.setattr(svc,'_summary_focal_ras',lambda _p:{1:(0.,0.,0.),2:(0.,0.,0.)})
    monkeypatch.setattr(svc,'_find_mri_params',lambda _w: None)
    monkeypatch.setattr(svc,'_planned_focus_native_measurement',lambda son,_rows,_planned: (
        {'orientation':'Axial','x_mm':0.2,'y_mm':0.3,'z_mm':None,'evidence':'ax'} if son.sonication_number==1
        else {'orientation':'Sagittal','x_mm':None,'y_mm':9.9,'z_mm':-0.4,'evidence':'sag'}))
    monkeypatch.setattr(svc,'_dqa_reference_geometry',lambda _p:{'tilt_deg':0.2,'evidence':[]})
    r=svc.analyze_series(pkg)
    assert r.y_mm == 0.3
    assert r.z_mm == -0.4
