from pathlib import Path
import tempfile
import numpy as np

from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService
from src.services.treatment_spot_geometry_service import TreatmentSpotGeometryService


def test_bbb_subsonication_is_not_target_voxel_proxy():
    src=Path('src/services/dqa_focus_alignment_service.py').read_text()
    assert 'multi-target voxel / {int(setup.subsonication_count)} sub-sonications' not in src
    assert 'bbbnumsubsonicuvw' in src.lower()
    assert 'SpotSonicationData' in src


def test_spectrum_history_is_named_bbb_not_target_voxel():
    provider=Path('src/integration/spectrum_provider.py').read_text()
    renderer=Path('src/core/current_spectrum_renderer.py').read_text()
    assert 'WS-validated BBB sub-sonication index' in provider
    assert 'BBB sub-sonication' in renderer
    assert 'Target voxel {int(state)+1}' not in renderer


def test_umbrella_vertical_axis_is_not_mirrored():
    src=Path('src/ui/main_window.py').read_text()
    assert 'return points[:,0], -points[:,2], -points[:,1]' in src
    assert 'return points[:,1], -points[:,2], points[:,0]' in src
    assert 'sy_screen=-q[:,2]' in src


def test_spot_mesh_parser_and_uvw_to_ras():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/'a.mesh'
        p.write_text('dummy={};\ndummy{1}.Vertices = [\n1 -2 3;\n3 -2 3;\n1 -4 7;\n3 -4 7;\n];\n')
        vertices=TreatmentSpotGeometryService._mesh_vertices(p)
        assert vertices is not None and vertices.shape==(4,3)
        ras=TreatmentSpotGeometryService._uvw_to_ras(vertices)
        np.testing.assert_allclose(ras[0],[-1,2,3])
        np.testing.assert_allclose(np.ptp(ras,axis=0),[2,2,4])


def test_dqa_spot_count_uses_explicit_spot_ownership_only(tmp_path):
    (tmp_path/'spotsonicationdata.xml').write_text("""<?xml version='1.0'?><xml xmlns:s='urn:schemas-microsoft-com:xml-data' xmlns:rs='urn:schemas-microsoft-com:rowset' xmlns:z='#RowsetSchema'><rs:data><z:row sonicationindex='5' spotcue='20000007'/></rs:data></xml>""")
    class P: workspace=tmp_path
    assert DqaFocusAlignmentService._treatment_spot_count(P(),5)[0]==1


def test_spectrummsg_analyzer_has_aggregate_path_without_fake_rcv():
    src=Path('src/services/spectrummsg_aggregate_service.py').read_text()
    ui=Path('src/ui/hydrophone_window.py').read_text()
    assert 'channel_count=1' in src
    assert 'no physical RCV0–RCV7 channel identity' in src
    assert 'SpectrumMsg aggregate' in ui
    assert 'physical RCV/raw A/D unavailable' in ui


def test_replay_temperature_defaults_to_first_exported_target():
    src=Path('src/services/replay_service.py').read_text()
    assert 'primary=projected[0] if projected else None' in src
    assert 'primary_target=projected_targets[0] if projected_targets else None' in src
    assert 'Target 1 physical SpotMesh footprint' in src


def test_dqa_production_contract_is_same_sonication_observed_minus_planned_only():
    src=Path('src/services/dqa_focus_alignment_service.py').read_text()
    analyze=src[src.index('    def analyze('):src.index('    def clear_cache(')]
    assert '_image_native_alignment(package,focal_by_number,number)' in analyze
    assert '_thermal_focus_ras_alignment(' not in analyze
    assert '_focal_reference_frame_compatibility(' not in analyze
    assert 'planned focalRAS, phantom centre, image centre, steering coordinates and target voxel coordinates are never subtracted' in analyze


def test_dqa_default_center_single_target_gate_does_not_use_bbb_count():
    src=Path('src/services/dqa_focus_alignment_service.py').read_text().lower()
    assert 'bbb internal sub-sonications are never' in src
    assert 'explicit sonication->spotcue ownership' in src
    assert 'multi-target / {int(spot_count)} treatment spots' in src


def test_repository_fast_universe_keeps_spectrummsg_even_when_physical_cpc_maps_all():
    src=Path('src/services/spectrum_evidence_repository.py').read_text()
    assert 'inventory.extend(list(getattr(son,"spectrum_files",[]) or []))' in src
    assert 'physical RCV and aggregate 220 evidence' in src
