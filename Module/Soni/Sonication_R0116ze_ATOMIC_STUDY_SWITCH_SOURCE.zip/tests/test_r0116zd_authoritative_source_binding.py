
from pathlib import Path
from types import SimpleNamespace
import json

from src.services.spectrum_dump_import_service import SpectrumDumpImportService, SpectrumDumpCandidate


def _candidate(name: str) -> SpectrumDumpCandidate:
    raw = Path("CPCFiles") / name
    return SpectrumDumpCandidate(
        label=name,
        raw_path=raw,
        fft_path=Path(str(raw) + "_FFT"),
        relative_path=str(raw),
        family="CPC Spectrum",
    )


def test_real_export_manifest_13_pairs_maps_last_8_to_treatment_sonications():
    fixture = Path(__file__).parent / "fixtures" / "golden_10_00_09_spectrum_manifest.json"
    data = json.loads(fixture.read_text(encoding="utf-8"))
    candidates = [_candidate(n) for n in data["physical_cpc_pairs"]]
    sons = [SimpleNamespace(name=f"Sonication{i+1}", folder=Path(f"Sonication/Sonication{i+1}")) for i in range(8)]
    mapping = SpectrumDumpImportService().map_candidates_to_sonications(candidates, sons)
    assert sorted(mapping) == list(range(8))
    actual = [mapping[i].raw_path.name for i in range(8)]
    assert actual == data["expected_treatment_pairs"]


def test_extra_early_cpc_pairs_are_not_mapped_as_treatment():
    candidates = [_candidate(f"Spectrum_2026_06_12_{i:02d}.dmp") for i in range(13)]
    sons = [SimpleNamespace(name=f"Sonication{i+1}", folder=Path(f"S{i+1}")) for i in range(8)]
    mapping = SpectrumDumpImportService().map_candidates_to_sonications(candidates, sons)
    assert [mapping[i].raw_path.name for i in range(8)] == [c.raw_path.name for c in candidates[-8:]]


def test_exact_cardinality_still_maps_all():
    candidates = [_candidate(f"Spectrum_{i:02d}.dmp") for i in range(2)]
    sons = [SimpleNamespace(name="Sonication1", folder=Path("A")), SimpleNamespace(name="Sonication2", folder=Path("B"))]
    mapping = SpectrumDumpImportService().map_candidates_to_sonications(candidates, sons)
    assert mapping[0] is candidates[0]
    assert mapping[1] is candidates[1]


def test_spectrummsg_never_enters_physical_treatment_mapping():
    physical = [_candidate(f"Spectrum_{i:02d}.dmp") for i in range(8)]
    msg = SpectrumDumpCandidate(
        label="SpectrumMsg-1.dmp", raw_path=Path("SpectrumMsg-1.dmp"), fft_path=None,
        relative_path="SpectrumMsg-1.dmp", family="SpectrumMsg"
    )
    sons = [SimpleNamespace(name=f"Sonication{i+1}", folder=Path(f"S{i+1}")) for i in range(8)]
    mapping = SpectrumDumpImportService().map_candidates_to_sonications([msg] + physical, sons)
    assert len(mapping) == 8
    assert all(c.family == "CPC Spectrum" for c in mapping.values())


def test_main_window_has_no_legacy_direct_package_cpc_build_calls():
    source = (Path(__file__).parents[1] / "src" / "ui" / "main_window.py").read_text(encoding="utf-8")
    forbidden = "hydrophone_replay_service.build(self.package.cpc_spectrum_files"
    assert forbidden not in source
    assert "def _build_cpc_replay" in source
    assert "def _resolve_cpc_pair" in source


def test_same_export_zip_reuse_is_present_in_analyzer():
    source = (Path(__file__).parents[1] / "src" / "ui" / "hydrophone_window.py").read_text(encoding="utf-8")
    assert "source == package_source" in source
    assert "temporary=False" in source
    assert "progress_callback=_decode_progress" in source
