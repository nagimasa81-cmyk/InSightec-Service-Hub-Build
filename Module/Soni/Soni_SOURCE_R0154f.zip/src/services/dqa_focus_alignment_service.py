from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import math

import numpy as np

from src.parsers.ado_rowset import parse_ado_rowset
from src.services.raw_service import RawService


@dataclass(slots=True)
class DqaFocusAlignment:
    x_mm: float | None = None
    y_mm: float | None = None
    z_mm: float | None = None
    tilt_deg: float | None = None
    confidence: str = "Unavailable"
    evidence: list[str] = field(default_factory=list)

    @property
    def alert(self) -> bool:
        return bool(
            (self.x_mm is not None and abs(float(self.x_mm)) >= 15.0)
            or (self.y_mm is not None and abs(float(self.y_mm)) >= 15.0)
            or (self.z_mm is not None and abs(float(self.z_mm)) >= 20.0)
        )

    @property
    def display(self) -> str:
        def f(name: str, value: float | None, unit: str = "mm") -> str:
            return f"{name} {value:+.1f} {unit}" if value is not None and np.isfinite(value) else f"{name} —"
        return "  ".join((f("X", self.x_mm), f("Y", self.y_mm), f("Z", self.z_mm), f("Tilt", self.tilt_deg, "°")))


class DqaFocusAlignmentService:
    """Measure DQA phantom focus alignment from exported MR RAW evidence.

    DQA convention used by this application:
      * X = R/L displacement from the phantom circle centre.
      * Y = A/P displacement from the phantom circle centre.
      * Z = S/I distance from the phantom lower straight reference line.
      * Tilt = angle of that straight reference line; image horizontal is 0 deg.

    The service is deliberately DQA-only and fail-closed. If the phantom geometry
    cannot be measured confidently from the exported magnitude RAW, no value is
    invented and the Summary reports an unavailable component.
    """

    def __init__(self) -> None:
        self.raw = RawService()
        self._cache: dict[str, DqaFocusAlignment] = {}

    @staticmethod
    def is_dqa(package) -> bool:
        names = [str(getattr(package, "source", "")), str(getattr(package, "workspace", ""))]
        for son in list(getattr(package, "sonications", []) or []):
            names.append(str(getattr(son, "folder", "")))
            names.extend(str(p) for p in list(getattr(son, "other_files", []) or [])[:96])
        return any("dqa" in name.lower() for name in names)

    @staticmethod
    def _find_mri_params(workspace: Path) -> Path | None:
        for name in ("MriImageParams.xml", "MRIImageParams.xml"):
            items = sorted(Path(workspace).rglob(name), key=lambda p: (len(p.parts), str(p).lower()))
            if items:
                return items[0]
        return None

    @staticmethod
    def _row_by_number(path: Path | None) -> dict[int, dict[str, object]]:
        if path is None:
            return {}
        try:
            rows = parse_ado_rowset(path)
        except Exception:
            return {}
        out: dict[int, list[dict[str, object]]] = {}
        for row in rows:
            try:
                n = int(float(row.get("sonicationindex", "")))
            except (TypeError, ValueError):
                continue
            out.setdefault(n, []).append(row)
        best: dict[int, dict[str, object]] = {}
        for n, candidates in out.items():
            def quality(row):
                series = str(row.get("seriesdiscription") or row.get("seriesdescription") or "").upper()
                treatment = int(any(t in series for t in ("MEMP", "TMAP", "THERM")))
                try:
                    sx = float(row.get("pixsizex") or 0); sy = float(row.get("pixsizey") or 0)
                    pixels = int(sx > 0 and sy > 0)
                except Exception:
                    pixels = 0
                try:
                    rv = np.asarray([float(row.get(k, 0)) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")])
                    cv = np.asarray([float(row.get(k, 0)) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")])
                    cos = int(np.linalg.norm(rv) > .5 and np.linalg.norm(cv) > .5)
                except Exception:
                    cos = 0
                return treatment, pixels, cos
            best[n] = max(candidates, key=quality)
        return best

    @staticmethod
    def _orientation(row: dict[str, object]) -> str | None:
        try:
            rv = np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")], float)
            cv = np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")], float)
            normal = np.cross(rv, cv)
            axis = int(np.argmax(np.abs(normal)))
            return ("Sagittal", "Coronal", "Axial")[axis]
        except Exception:
            return None

    @staticmethod
    def _pixel_sizes(row: dict[str, object]) -> tuple[float, float] | None:
        try:
            sx = float(row.get("pixsizex")); sy = float(row.get("pixsizey"))
            if sx <= 0 or sy <= 0 or not np.isfinite([sx, sy]).all():
                return None
            return sx, sy
        except Exception:
            return None

    @staticmethod
    def _ras_delta(row: dict[str, object], dx: float, dy: float) -> np.ndarray | None:
        sizes = DqaFocusAlignmentService._pixel_sizes(row)
        if sizes is None:
            return None
        try:
            rv = np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")], float)
            cv = np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")], float)
        except Exception:
            return None
        # The displayed RAW raster uses exported COLUMN direction on screen X
        # and exported ROW direction on screen Y (same convention as metadata UI).
        sx, sy = sizes
        return cv * (float(dx) * sx) + rv * (float(dy) * sy)

    def _hotspot(self, son) -> tuple[float, float, int] | None:
        frames = list(getattr(son, "temperature_frames", []) or [])
        if not frames:
            return None
        try:
            baseline = self.raw.read_temperature(frames[0].path)
        except Exception:
            return None
        finite = baseline[np.isfinite(baseline)]
        absolute = bool(finite.size and 15.0 <= float(np.nanmedian(finite)) <= 80.0)
        best = None
        h, w = baseline.shape
        y0, y1 = int(.10*h), int(.90*h); x0, x1 = int(.10*w), int(.90*w)
        for i, frame in enumerate(frames):
            try:
                arr = self.raw.read_temperature(frame.path)
            except Exception:
                continue
            delta = arr - baseline if absolute else arr
            roi = np.asarray(delta[y0:y1, x0:x1], float)
            if not np.isfinite(roi).any():
                continue
            flat = int(np.nanargmax(roi)); yy, xx = np.unravel_index(flat, roi.shape)
            yy += y0; xx += x0
            peak = float(delta[yy, xx])
            if best is None or peak > best[0]:
                # Local weighted centroid reduces single-pixel noise without
                # changing the measured focus to a global threshold centroid.
                r = 6
                ya, yb = max(0, yy-r), min(h, yy+r+1); xa, xb = max(0, xx-r), min(w, xx+r+1)
                patch = np.asarray(delta[ya:yb, xa:xb], float)
                floor = float(np.nanpercentile(patch[np.isfinite(patch)], 50)) if np.isfinite(patch).any() else 0.0
                weights = np.maximum(patch - floor, 0.0)
                if np.isfinite(weights).all() and float(weights.sum()) > 0:
                    gy, gx = np.indices(weights.shape)
                    cx = xa + float((weights * gx).sum() / weights.sum())
                    cy = ya + float((weights * gy).sum() / weights.sum())
                else:
                    cx, cy = float(xx), float(yy)
                best = (peak, cx, cy, i)
        return (best[1], best[2], best[3]) if best is not None else None

    def _magnitude_for(self, son, temp_index: int) -> np.ndarray | None:
        mags = list(getattr(son, "magnitude_frames", []) or [])
        temps = list(getattr(son, "temperature_frames", []) or [])
        if not mags:
            return None
        if len(mags) <= 1 or len(temps) <= 1:
            mi = 0
        else:
            mi = min(len(mags)-1, round(float(temp_index) * (len(mags)-1) / max(1, len(temps)-1)))
        try:
            return self.raw.read_magnitude(mags[mi].path)
        except Exception:
            return None

    @staticmethod
    def _norm(image: np.ndarray) -> np.ndarray:
        arr = np.asarray(image, float)
        finite = arr[np.isfinite(arr)]
        if not finite.size:
            return np.zeros_like(arr)
        lo, hi = np.nanpercentile(finite, [2, 98])
        if hi <= lo:
            return np.zeros_like(arr)
        return np.clip((arr-lo)/(hi-lo), 0.0, 1.0)

    @classmethod
    def _baseline_line(cls, image: np.ndarray) -> tuple[float, float, float] | None:
        """Return y = slope*x + intercept and a 0..1 support score."""
        a = cls._norm(image); h, w = a.shape
        # Strong horizontal structural boundary in the lower half of the DQA phantom.
        gy = np.abs(a[2:, :] - a[:-2, :])
        xa, xb = int(.18*w), int(.82*w); ya, yb = int(.48*h), int(.88*h)
        if xb-xa < 20 or yb-ya < 20:
            return None
        score = np.nanmean(gy[ya:yb, xa:xb], axis=1)
        if not np.isfinite(score).any():
            return None
        yc = ya + int(np.nanargmax(score)) + 1
        xs=[]; ys=[]; strengths=[]
        for x in range(xa, xb):
            ylo=max(1,yc-6); yhi=min(h-2,yc+7)
            col=gy[ylo-1:yhi-1,x]
            if not col.size or not np.isfinite(col).any():
                continue
            j=int(np.nanargmax(col)); y=ylo+j
            xs.append(float(x)); ys.append(float(y)); strengths.append(float(col[j]))
        if len(xs) < 24:
            return None
        x=np.asarray(xs); y=np.asarray(ys); st=np.asarray(strengths)
        keep=st >= np.nanpercentile(st,40)
        x=x[keep]; y=y[keep]
        if x.size < 20:
            return None
        for _ in range(3):
            slope, intercept=np.polyfit(x,y,1)
            resid=y-(slope*x+intercept); mad=float(np.nanmedian(np.abs(resid-np.nanmedian(resid))))
            tol=max(1.5,3.5*mad)
            keep=np.abs(resid)<=tol
            if keep.sum()<20: break
            x=x[keep]; y=y[keep]
        slope,intercept=np.polyfit(x,y,1)
        support=min(1.0,float(x.size)/max(1,(xb-xa)*.55))
        if abs(float(slope)) > .35:
            return None
        return float(slope),float(intercept),support

    @classmethod
    def _circle_center(cls, image: np.ndarray, baseline_y: float | None = None) -> tuple[float, float, float] | None:
        a=cls._norm(image); h,w=a.shape
        gx=np.zeros_like(a); gy=np.zeros_like(a)
        gx[:,1:-1]=a[:,2:]-a[:,:-2]; gy[1:-1,:]=a[2:,:]-a[:-2,:]
        g=np.hypot(gx,gy)
        cx0=w/2.0; cy0=min(h*.50,(baseline_y-h*.18) if baseline_y is not None else h*.50)
        yy,xx=np.indices(a.shape)
        radius=np.hypot(xx-cx0,yy-cy0)
        mask=(xx>.14*w)&(xx<.86*w)&(yy>.14*h)&(yy<(.76*h if baseline_y is None else baseline_y-3))
        mask &= (radius>.11*w)&(radius<.34*w)
        vals=g[mask]
        vals=vals[np.isfinite(vals) & (vals > 1e-6)]
        if vals.size < 80:
            return None
        # Percentiles over the whole mostly-zero search ROI would yield a zero
        # threshold and make every interior pixel a false circle edge. Rank only
        # real gradient pixels, then fit the strongest structural boundary points.
        thr=float(np.nanpercentile(vals,55))
        ys,xs=np.nonzero(mask & (g>=thr) & (g>1e-6))
        if xs.size < 60:
            return None
        x=xs.astype(float); y=ys.astype(float)
        # Robust algebraic circle fit with radial-residual trimming.
        for _ in range(4):
            A=np.column_stack((x,y,np.ones_like(x))); b=-(x*x+y*y)
            try:
                aa,bb,cc=np.linalg.lstsq(A,b,rcond=None)[0]
            except np.linalg.LinAlgError:
                return None
            cx=-aa/2.0; cy=-bb/2.0; r2=cx*cx+cy*cy-cc
            if r2<=0: return None
            r=math.sqrt(r2); resid=np.abs(np.hypot(x-cx,y-cy)-r)
            med=float(np.nanmedian(resid)); mad=float(np.nanmedian(np.abs(resid-med)))
            keep=resid<=max(2.0,med+2.5*mad)
            if keep.sum()<40: break
            x=x[keep]; y=y[keep]
        if not (.20*w < cx < .80*w and .15*h < cy < .70*h and .10*w < r < .36*w):
            return None
        support=min(1.0,float(x.size)/180.0)
        return float(cx),float(cy),support

    def _measure_one(self, son, row: dict[str, object]) -> dict[str, float | str | None]:
        hs=self._hotspot(son)
        if hs is None:
            return {"orientation": self._orientation(row), "error":"temperature hotspot unavailable"}
        hx,hy,ti=hs
        mag=self._magnitude_for(son,ti)
        if mag is None:
            return {"orientation": self._orientation(row), "error":"magnitude RAW unavailable"}
        orientation=self._orientation(row)
        line=self._baseline_line(mag)
        line_y=(line[0]*(mag.shape[1]/2.0)+line[1]) if line is not None else None
        circle=self._circle_center(mag,line_y)
        out={"orientation":orientation,"hotspot_x":hx,"hotspot_y":hy}
        if circle is not None:
            cx,cy,cscore=circle; out.update(circle_x=cx,circle_y=cy,circle_support=cscore)
            ras=self._ras_delta(row,hx-cx,hy-cy)
            if ras is not None:
                out["x_mm"]=float(ras[0]); out["y_mm"]=float(ras[1])
        if line is not None:
            slope,intercept,lscore=line; yline=slope*hx+intercept
            sizes=self._pixel_sizes(row)
            if sizes is not None:
                sx,sy=sizes
                # Z is the S/I phantom reference measurement shown by the DQA
                # vertical arrow: upward from the lower line is positive.
                out["z_mm"]=float((yline-hy)*sy)
                out["tilt_deg"]=float(math.degrees(math.atan2(slope*sy,sx)))
            out["line_support"]=lscore
        return out

    def analyze(self, package) -> DqaFocusAlignment:
        key=str(Path(getattr(package,"workspace",".")).resolve())
        if key in self._cache:
            return self._cache[key]
        if not self.is_dqa(package):
            result=DqaFocusAlignment(confidence="Not DQA",evidence=["DQA-only analysis not applicable"])
            self._cache[key]=result; return result
        rows=self._row_by_number(self._find_mri_params(Path(package.workspace)))
        measured={}
        for pos,son in enumerate(list(getattr(package,"sonications",[]) or []),start=1):
            n=int(getattr(son,"sonication_number",0) or pos)
            measured[n]=self._measure_one(son,rows.get(n,{}))
        # Established DQA acquisition convention in this code base:
        # S1 checks R/L (X), S2 checks S/I (Z), S3 checks A/P (Y).
        x=measured.get(1,{}).get("x_mm")
        z=measured.get(2,{}).get("z_mm")
        tilt=measured.get(2,{}).get("tilt_deg")
        y=measured.get(3,{}).get("y_mm")
        # Structural fallback for variants with a different ordering.
        if x is None or y is None:
            for row in measured.values():
                if row.get("orientation")=="Axial":
                    if x is None and row.get("x_mm") is not None: x=row.get("x_mm")
                    if y is None and row.get("y_mm") is not None: y=row.get("y_mm")
        if z is None or tilt is None:
            for row in measured.values():
                if row.get("orientation")=="Sagittal":
                    if z is None and row.get("z_mm") is not None: z=row.get("z_mm")
                    if tilt is None and row.get("tilt_deg") is not None: tilt=row.get("tilt_deg")
        values=[v for v in (x,y,z,tilt) if v is not None and np.isfinite(v)]
        confidence="High" if len(values)==4 else ("Partial" if values else "Unavailable")
        evidence=[]
        for n in sorted(measured):
            m=measured[n]
            parts=[f"S{n} {m.get('orientation') or 'Unknown'}"]
            for k in ("x_mm","y_mm","z_mm","tilt_deg"):
                if m.get(k) is not None: parts.append(f"{k}={float(m[k]):.3f}")
            if m.get("error"): parts.append(str(m["error"]))
            evidence.append("; ".join(parts))
        result=DqaFocusAlignment(
            x_mm=float(x) if x is not None else None,
            y_mm=float(y) if y is not None else None,
            z_mm=float(z) if z is not None else None,
            tilt_deg=float(tilt) if tilt is not None else None,
            confidence=confidence,evidence=evidence,
        )
        self._cache[key]=result
        return result

    def clear_cache(self) -> None:
        self._cache.clear()
