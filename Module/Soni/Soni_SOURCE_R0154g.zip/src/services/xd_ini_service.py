from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class MainFrequencyMetadata:
    frequency_hz: float | None
    source_path: Path | None
    raw_line: str | None
    confidence: float
    unit_interpretation: str


@dataclass(slots=True)
class XdReferenceFiles:
    xd_files: list[Path]
    geometry_files: list[Path]


class XdIniService:
    """Discover and parse valid transducer XD configuration files.

    Only serial-specific files are valid references:
      * Xd_####.ini
      * XdGometry_####.ini (field spelling)
      * XdGeometry_####.ini (supported compatibility spelling)

    Serial 0000 is the vendor/default template and is deliberately ignored.
    Broad names such as Xd.ini, Xd_test.ini, or Xd_ABC123.ini are not accepted.
    """

    NUMBER_RE = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?")
    VALID_FREQUENCY_BANDS_HZ = ((180_000.0, 320_000.0), (550_000.0, 750_000.0))

    @classmethod
    def _is_valid_frequency(cls, hz: float) -> bool:
        return any(low <= float(hz) <= high for low, high in cls.VALID_FREQUENCY_BANDS_HZ)

    XD_RE = re.compile(r"^xd_(\d{4})\.ini$", re.IGNORECASE)
    XD_GEOMETRY_RE = re.compile(r"^xd(?:gometry|geometry)_(\d{4})\.ini$", re.IGNORECASE)

    @staticmethod
    def _non_default_serial(match: re.Match[str] | None) -> bool:
        return bool(match and match.group(1) != "0000")

    def discover_references(self, workspace: Path) -> XdReferenceFiles:
        xd_files: list[Path] = []
        geometry_files: list[Path] = []
        for path in workspace.rglob("*.ini"):
            xd_match = self.XD_RE.fullmatch(path.name)
            if self._non_default_serial(xd_match):
                xd_files.append(path)
                continue
            geometry_match = self.XD_GEOMETRY_RE.fullmatch(path.name)
            if self._non_default_serial(geometry_match):
                geometry_files.append(path)

        key = lambda p: str(p).lower()
        xd_files.sort(key=key)
        geometry_files.sort(key=key)
        return XdReferenceFiles(xd_files=xd_files, geometry_files=geometry_files)

    def discover(self, workspace: Path) -> list[Path]:
        """Return only valid Xd_####.ini files used for frequency parsing."""
        return self.discover_references(workspace).xd_files

    def discover_geometry(self, workspace: Path) -> list[Path]:
        """Return valid non-default XdGometry/XdGeometry files."""
        return self.discover_references(workspace).geometry_files

    def read_main_frequency(self, workspace: Path) -> MainFrequencyMetadata:
        files = self.discover(workspace)
        if not files:
            return MainFrequencyMetadata(
                frequency_hz=None,
                source_path=None,
                raw_line=None,
                confidence=0.0,
                unit_interpretation="Valid non-default Xd_####.ini not found",
            )

        best: MainFrequencyMetadata | None = None
        for path in files:
            metadata = self._parse_file(path)
            if metadata.frequency_hz is not None:
                if best is None or metadata.confidence > best.confidence:
                    best = metadata

        if best is not None:
            return best

        return MainFrequencyMetadata(
            frequency_hz=None,
            source_path=files[-1],
            raw_line=None,
            confidence=10.0,
            unit_interpretation="No numeric value found on final data line",
        )

    @classmethod
    def _interpret_frequency_value(cls, raw_value: str, raw_line: str) -> tuple[float | None, str, float]:
        numbers = cls.NUMBER_RE.findall(str(raw_value))
        if not numbers:
            return None, "No numeric token", 0.0
        value = float(numbers[0])
        lower = str(raw_value).lower()
        if "mhz" in lower:
            frequency_hz = value * 1_000_000.0
            interpretation = "Explicit MHz"
            confidence = 100.0
        elif "khz" in lower:
            frequency_hz = value * 1_000.0
            interpretation = "Explicit kHz"
            confidence = 100.0
        elif re.search(r"(?<![kKmM])\bhz\b", str(raw_value), re.IGNORECASE):
            frequency_hz = value
            interpretation = "Explicit Hz"
            confidence = 100.0
        elif abs(value) < 10.0:
            frequency_hz = value * 1_000_000.0
            interpretation = "Unit inferred as MHz"
            confidence = 80.0
        elif abs(value) < 10_000.0:
            frequency_hz = value * 1_000.0
            interpretation = "Unit inferred as kHz"
            confidence = 75.0
        else:
            frequency_hz = value
            interpretation = "Unit inferred as Hz"
            confidence = 75.0
        if not cls._is_valid_frequency(frequency_hz):
            return None, (
                f"Rejected {frequency_hz/1_000_000.0:.3f} MHz: outside supported "
                "Brain220/Brain650 sonication transmit bands"
            ), 0.0
        return float(frequency_hz), interpretation, confidence

    def _parse_file(self, path: Path) -> MainFrequencyMetadata:
        text = path.read_text(encoding="utf-8", errors="ignore")
        raw_lines = [line.rstrip() for line in text.splitlines() if line.strip()]
        if not raw_lines:
            return MainFrequencyMetadata(None, path, None, 5.0, "Empty INI")

        # R0154g: serial XD files contain human comments with unrelated MHz
        # values (for example "Brain: 0.8MHz") after the actual assignment.
        # Parsing the final numeric token therefore rejected valid 230/670 kHz
        # files. Parse only the assignment RHS before ';'/'#' comments.
        section = ""
        preferred: list[tuple[str, str, str]] = []
        generic: list[tuple[str, str, str]] = []
        for raw_line in raw_lines:
            stripped = raw_line.strip()
            if stripped.startswith((";", "#", "//")):
                continue
            if stripped.startswith("[") and "]" in stripped:
                section = stripped[1:stripped.index("]")].strip().upper()
                continue
            code = stripped.split(";", 1)[0].split("#", 1)[0].strip()
            if "=" not in code:
                continue
            key, rhs = [part.strip() for part in code.split("=", 1)]
            if not rhs:
                continue
            row = (raw_line, key, rhs)
            if section == "PREFERRED_FREQUENCIES" and re.fullmatch(r"FREQ\d+", key, re.I):
                preferred.append(row)
            if "freq" in key.lower() or "frequency" in key.lower():
                generic.append(row)

        candidates = preferred or generic
        if not candidates:
            return MainFrequencyMetadata(None, path, None, 10.0, "No frequency assignment found")

        # In vendor XD files FREQ3 is the Brain preferred entry and its comment
        # explicitly says Brain. Prefer that assignment when present; otherwise
        # choose the last valid preferred/generic assignment for compatibility.
        ordered = sorted(
            candidates,
            key=lambda row: (0 if "brain" not in row[0].lower() else 1),
        )
        last_rejection: tuple[str, str] | None = None
        for raw_line, _key, rhs in reversed(ordered):
            hz, interpretation, confidence = self._interpret_frequency_value(rhs, raw_line)
            if hz is not None:
                if preferred:
                    interpretation = f"Preferred-frequency assignment; {interpretation}"
                    confidence = max(confidence, 95.0)
                return MainFrequencyMetadata(hz, path, raw_line.strip(), confidence, interpretation)
            last_rejection = (raw_line.strip(), interpretation)

        raw, why = last_rejection if last_rejection is not None else (None, "No valid frequency assignment")
        return MainFrequencyMetadata(None, path, raw, 0.0, why)
