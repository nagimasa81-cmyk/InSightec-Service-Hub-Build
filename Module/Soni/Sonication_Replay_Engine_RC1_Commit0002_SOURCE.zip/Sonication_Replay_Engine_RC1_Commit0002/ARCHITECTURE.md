# Architecture

The application now uses a shared core that can be reused by SpectrumMsg Analyzer.

## Core

- `core/image`
- `core/temperature`
- `core/spectrum`
- `core/replay`
- `core/timeline`

## Applications

- SpectrumMsg Analyzer
- Sonication Replay Engine
- Future Treatment Replay Studio
- Future FUS Investigation Studio

## Integration boundary

Spectrum data is supplied through `SpectrumProvider`.

The Replay UI does not parse SpectrumMsg directly. A future
`SpectrumMsgAnalyzerAdapter` will implement the provider and convert the
analyzer output into common `SpectrumFrame` objects.
