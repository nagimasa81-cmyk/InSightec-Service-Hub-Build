# Roadmap

- Commit0001: Prototype viewer
- Commit0002: Common Core + replay-oriented layout
- Commit0003: SpectrumMsg Analyzer adapter and live spectrum panel
- Commit0004: Hotspot tracking, ROI and temperature curves
- Commit0005: Treatment-level replay
- Commit0006: MR/temperature/spectrum/ACT synchronization
- Commit0007: Log synchronization
- Commit0008: Replay Studio RC1
