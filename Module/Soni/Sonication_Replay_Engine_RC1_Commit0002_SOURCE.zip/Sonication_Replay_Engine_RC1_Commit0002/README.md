# Sonication Replay Engine RC1 Commit0002

## Main changes

- Replay-oriented layout
- Timeline at the top
- Large magnitude/temperature overlay
- Separate magnitude and temperature reference views
- Spectrum integration placeholder
- Maximum-temperature trend
- Hotspot marker and temperature label
- Overlay opacity control
- Shared `src/core` package for future SpectrumMsg Analyzer integration

## SpectrumMsg Analyzer integration

The Replay Engine now expects spectrum data through a shared provider interface.

```text
src/core/spectrum_provider.py
```

Commit0003 will implement an adapter using the SpectrumMsg Analyzer decoder.

## Run

1. `build\00_VERIFY_SOURCE.bat`
2. `build\03_RUN_DEBUG.bat`
