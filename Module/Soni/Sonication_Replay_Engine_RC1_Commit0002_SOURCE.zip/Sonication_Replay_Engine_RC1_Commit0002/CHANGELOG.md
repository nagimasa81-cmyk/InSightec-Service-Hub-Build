# Changelog

## RC1 Commit0002

- Introduced shared `src/core` architecture for future integration with SpectrumMsg Analyzer.
- Added core image, temperature, spectrum, replay and timeline models.
- Added common `SpectrumProvider` interface and placeholder provider.
- Reworked the main screen around replay workflow:
  - top timeline
  - large overlay view
  - smaller magnitude and temperature views
  - spectrum placeholder
  - temperature trend chart
  - metrics panel
- Added hotspot marker and temperature label on the overlay.
- Added frame-normalized timeline synchronization.
- Added per-frame maximum-temperature trend.
- Added play, pause, previous, next, first and last controls.
- Added overlay opacity control.
- Preserved ZIP/folder import and Sonication discovery.
- Added verification script for core models and GUI startup.

## RC1 Prototype

- Initial Sonication replay viewer.
