from __future__ import annotations

import tempfile
from pathlib import Path

import numpy as np

from src.core.models import (
    ImageFrame,
    SpectrumFrame,
    TemperatureFrame,
)
from src.core.replay_builder import ReplayBuilder
from src.core.spectrum_provider import NullSpectrumProvider


def main() -> int:
    with tempfile.TemporaryDirectory(
        prefix="SonicationReplayVerify_"
    ) as temp:
        root = Path(temp)

        magnitude = [
            ImageFrame(
                index=0,
                source=root / "6-0.raw",
                pixels=np.zeros((256, 256), dtype=np.float32),
            ),
            ImageFrame(
                index=1,
                source=root / "6-1.raw",
                pixels=np.ones((256, 256), dtype=np.float32),
            ),
        ]

        temperature_array = np.full(
            (256, 256),
            37.0,
            dtype=np.float32,
        )
        temperature_array[100, 120] = 45.5
        temperature = [
            TemperatureFrame(
                index=0,
                source=root / "5-0.raw",
                temperature=temperature_array,
                maximum=45.5,
                mean=float(np.mean(temperature_array)),
                hotspot_x=120,
                hotspot_y=100,
            )
        ]

        replay = ReplayBuilder(
            NullSpectrumProvider()
        ).build(
            name="Sonication1",
            folder=root,
            magnitude_frames=magnitude,
            temperature_frames=temperature,
            act_files=[],
            spectrum_files=[],
        )

        assert len(replay.frames) == 2
        assert replay.frames[0].magnitude is not None
        assert replay.frames[0].temperature is not None
        assert replay.frames[1].temperature is not None
        assert replay.frames[0].spectrum is None

    print("VERIFY_SOURCE_OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
