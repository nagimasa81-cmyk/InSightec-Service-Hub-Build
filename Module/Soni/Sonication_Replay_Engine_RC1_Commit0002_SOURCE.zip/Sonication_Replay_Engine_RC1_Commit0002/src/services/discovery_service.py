from __future__ import annotations
import re
from pathlib import Path
from src.domain.models import ReplayPackage, SonicationModel, RawFrame
from src.common.constants import TEMPERATURE_PREFIX, MAGNITUDE_PREFIX

SON_RE=re.compile(r'^sonication\s*[_-]?\s*(\d+)$',re.I)
RAW_RE=re.compile(r'^(\d+)-.*-(\d+)\.raw$',re.I)

def natural_key(text):
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r'(\d+)',text)]

class DiscoveryService:
    def discover(self, source:Path, workspace:Path)->ReplayPackage:
        dirs=[]
        for p in workspace.rglob('*'):
            if p.is_dir() and SON_RE.match(p.name): dirs.append(p)
        if SON_RE.match(workspace.name): dirs.append(workspace)
        # A Sonication-only ZIP may contain the files at archive root.
        if not dirs and any(p.is_file() and ('spectrummsg' in p.name.lower() or p.suffix.lower()=='.raw') for p in workspace.iterdir()):
            dirs=[workspace]
        unique={p.resolve():p for p in dirs}; dirs=sorted(unique.values(),key=lambda p:natural_key(p.name))
        models=[self._build(p,idx+1) for idx,p in enumerate(dirs)]
        return ReplayPackage(source=source,workspace=workspace,sonications=models)
    def _build(self,folder:Path,fallback:int)->SonicationModel:
        m=SON_RE.match(folder.name); name=f'Sonication{int(m.group(1))}' if m else f'Sonication{fallback}'
        model=SonicationModel(name=name,folder=folder)
        for p in folder.rglob('*'):
            if not p.is_file(): continue
            low=p.name.lower(); rm=RAW_RE.match(p.name)
            if rm:
                frame=RawFrame(path=p,index=int(rm.group(2)),prefix=rm.group(1))
                if frame.prefix==TEMPERATURE_PREFIX: model.temperature_frames.append(frame)
                elif frame.prefix==MAGNITUDE_PREFIX: model.magnitude_frames.append(frame)
                else: model.other_files.append(p)
            elif 'spectrummsg' in low and p.suffix.lower()=='.dmp': model.spectrum_files.append(p)
            elif p.suffix.lower()=='.act': model.act_files.append(p)
            else: model.other_files.append(p)
        model.temperature_frames.sort(key=lambda f:f.index); model.magnitude_frames.sort(key=lambda f:f.index)
        model.spectrum_files.sort(key=lambda p:natural_key(p.name)); model.act_files.sort(key=lambda p:natural_key(p.name))
        return model
