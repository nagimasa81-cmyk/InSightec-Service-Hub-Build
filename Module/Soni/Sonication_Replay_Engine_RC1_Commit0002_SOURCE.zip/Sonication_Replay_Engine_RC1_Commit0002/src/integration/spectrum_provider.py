from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

@dataclass(slots=True)
class SpectrumFrame:
    index: int
    frequency: list[float] = field(default_factory=list)
    amplitude: list[float] = field(default_factory=list)
    timestamp_seconds: float | None = None
    confidence: float = 0.0
    source: str = "unavailable"

class SpectrumProvider(Protocol):
    provider_name: str
    def supports(self, files: list[Path]) -> bool: ...
    def load(self, files: list[Path]) -> list[SpectrumFrame]: ...

class NullSpectrumProvider:
    provider_name = "Not connected"
    def supports(self, files: list[Path]) -> bool:
        return False
    def load(self, files: list[Path]) -> list[SpectrumFrame]:
        return []

class SpectrumMsgAnalyzerAdapter:
    """Future adapter boundary.

    Commit0003 will connect this class to SpectrumMsg Analyzer's exported shared
    package or JSON/CSV decoder output. Keeping this adapter here prevents the
    Replay UI from depending directly on Analyzer internals.
    """
    provider_name = "SpectrumMsg Analyzer Adapter (planned)"
    def supports(self, files: list[Path]) -> bool:
        return any("spectrummsg" in path.name.lower() for path in files)
    def load(self, files: list[Path]) -> list[SpectrumFrame]:
        return []
