from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from src.domain.models import SonicationModel
from src.services.raw_service import RawService

@dataclass(slots=True)
class ReplayFrameData:
    replay_index: int
    magnitude_index: int | None
    temperature_index: int | None
    magnitude: np.ndarray | None
    temperature: np.ndarray | None
    temperature_delta: np.ndarray | None
    hotspot_x: int | None = None
    hotspot_y: int | None = None
    maximum_temperature: float | None = None
    mean_temperature: float | None = None
    maximum_delta_temperature: float | None = None
    mean_delta_temperature: float | None = None
    temperature_source: str = "Unavailable"
    reference_temperature: float | None = None
    roi_source: str = "Default center ROI"
    roi_center_x: float | None = None
    roi_center_y: float | None = None
    roi_radius: float | None = None
    roi_width: float | None = None
    roi_height: float | None = None

class ReplayService:
    """Decode thermometry into workstation-style absolute-temperature data.

    The RAW format is inferred conservatively:
    * plausible 15..100 C values => absolute temperature
    * values centered near zero => delta-temperature, converted with a 37 C
      reference until an ACT/protocol-derived reference becomes available.
    """
    def __init__(self):
        self.raw = RawService()
        self._baseline_cache: dict[str, np.ndarray] = {}
        self._mode_cache: dict[str, tuple[str, float]] = {}

    def _baseline(self, son: SonicationModel) -> np.ndarray | None:
        if not son.temperature_frames:
            return None
        key = str(son.folder.resolve())
        if key not in self._baseline_cache:
            self._baseline_cache[key] = self.raw.read_temperature(son.temperature_frames[0].path)
        return self._baseline_cache[key]

    def _temperature_mode(self, son: SonicationModel) -> tuple[str, float]:
        key = str(son.folder.resolve())
        if key in self._mode_cache:
            return self._mode_cache[key]
        baseline = self._baseline(son)
        if baseline is None:
            result = ("Unavailable", 37.0)
        else:
            finite = baseline[np.isfinite(baseline)]
            if not finite.size:
                result = ("Unavailable", 37.0)
            else:
                median = float(np.nanmedian(finite))
                p01, p99 = np.nanpercentile(finite, [1, 99])
                # FUS workstation thermometry typically starts around body temp.
                if 15.0 <= median <= 80.0 and -10.0 <= p01 and p99 <= 120.0:
                    result = ("Absolute RAW", median)
                else:
                    result = ("Delta RAW + 37.0 C reference", 37.0)
        self._mode_cache[key] = result
        return result

    def clear_cache(self) -> None:
        self._baseline_cache.clear()
        self._mode_cache.clear()

    @staticmethod
    def _roi_geometry(shape: tuple[int, int]) -> tuple[float, float, float, float]:
        """Fallback target-centred 50 mm x 50 mm ROI.

        Pixel spacing metadata is not yet decoded in RC1, therefore one pixel is
        conservatively treated as 1 mm and the fallback is explicitly labelled.
        """
        h, w = shape
        cy, cx = (h - 1) / 2.0, (w - 1) / 2.0
        return cx, cy, 50.0, 50.0

    @classmethod
    def _roi_mask(cls, shape: tuple[int, int]) -> np.ndarray:
        h, w = shape
        cx, cy, width, height = cls._roi_geometry(shape)
        x0 = max(0, int(round(cx - width / 2.0)))
        x1 = min(w, max(x0 + 1, int(round(cx + width / 2.0))))
        y0 = max(0, int(round(cy - height / 2.0)))
        y1 = min(h, max(y0 + 1, int(round(cy + height / 2.0))))
        mask = np.zeros(shape, dtype=bool)
        mask[y0:y1, x0:x1] = True
        return mask

    def frame(self, son: SonicationModel, index: int) -> ReplayFrameData:
        count = son.replay_frame_count
        index = max(0, min(index, count - 1))
        mag = raw_temp = abs_temp = delta = None
        mi = ti = None
        source, reference_temp = self._temperature_mode(son)
        baseline = self._baseline(son)

        if son.magnitude_frames:
            mi = self.raw.normalize_index(index, count, len(son.magnitude_frames))
            mag = self.raw.read_magnitude(son.magnitude_frames[mi].path)
        if son.temperature_frames:
            ti = self.raw.normalize_index(index, count, len(son.temperature_frames))
            raw_temp = self.raw.read_temperature(son.temperature_frames[ti].path)
            if source == "Absolute RAW":
                abs_temp = raw_temp
                if baseline is not None and baseline.shape == raw_temp.shape:
                    delta = raw_temp - baseline
            else:
                # A delta RAW is already relative to the scanner reference.
                delta = raw_temp
                abs_temp = raw_temp + reference_temp

        hx = hy = None
        mx = mean = md = meand = None
        if abs_temp is not None and np.isfinite(abs_temp).any():
            roi = self._roi_mask(abs_temp.shape)
            roi_values = np.where(roi, abs_temp, np.nan)
            safe = np.nan_to_num(roi_values, nan=-np.inf)
            flat = int(np.argmax(safe))
            hy, hx = np.unravel_index(flat, abs_temp.shape)
            mx = float(np.nanmax(roi_values))
            mean = float(np.nanmean(roi_values))
        if delta is not None and np.isfinite(delta).any():
            roi = self._roi_mask(delta.shape)
            roi_delta = np.where(roi, delta, np.nan)
            md = float(np.nanmax(roi_delta))
            meand = float(np.nanmean(roi_delta))

        roi_x = roi_y = roi_radius = roi_width = roi_height = None
        roi_shape = abs_temp.shape if abs_temp is not None else (delta.shape if delta is not None else None)
        if roi_shape is not None:
            roi_x, roi_y, roi_width, roi_height = self._roi_geometry(roi_shape)
            roi_radius = max(roi_width, roi_height) / 2.0

        return ReplayFrameData(
            index, mi, ti, mag, abs_temp, delta, hx, hy, mx, mean, md, meand,
            source, reference_temp, "Target center 50 mm x 50 mm ROI (pixel spacing pending)",
            roi_x, roi_y, roi_radius, roi_width, roi_height
        )
