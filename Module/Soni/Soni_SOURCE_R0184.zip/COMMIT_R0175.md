# R0175 — Locate Transducer vendor-signature discovery

- Keeps R0174 confirmed-history filtering unchanged.
- Adds diagnostics-only broad workflow evidence for transducer/localization/registration/position/pose/detector/XD-loc wording.
- Adds bounded first/middle/last raw Xd context samples so the actual vendor success/result signature can be identified from the next export.
- Broad evidence never promotes a location result and Steering XYZ is never substituted for physical XYZ.
