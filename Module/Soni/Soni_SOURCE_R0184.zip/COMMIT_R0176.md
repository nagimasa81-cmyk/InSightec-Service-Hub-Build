# R0176 — Tracker-derived Transducer Localization History

- Uses the observed workstation vendor result line `New XD pos. in CSA coords. according to trackers` as authoritative physical transducer XYZ.
- Attaches `TRACKERS SELECTION` reliability, `CalculateXdPosition` return code, Transducer tilt, tracker PQR/iniPQR, `Found TrackerPos` coordinates, and nearest preceding Home UVW from the same bounded causal localization block.
- Prevents evidence from consecutive tracker-localization blocks from crossing the previous authoritative result boundary.
- Keeps recurring `Xd loc XYZ` and `Location sent on MoveTo` rows diagnostic-only; Steering XYZ is never substituted for physical XYZ.
- Transducer Location History UI now lists CSA XYZ, reliability, tilt, Home UVW, delta XYZ and 3D displacement from the first tracker localization.
- Diagnostics serialize tracker-localization metadata and retain R0175 discovery evidence for auditability.
- Version/build contract advanced to RC7.10-R0176 / 7.10.0.176.
