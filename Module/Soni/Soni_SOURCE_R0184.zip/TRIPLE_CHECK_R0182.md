# TRIPLE CHECK R0182

1. Display contract
   - Focal position XYZ, Treatment Target XYZ, Focal-Target ΔXYZ.
   - No 3D displacement/movement metric in UI or diagnostics.
2. Semantics
   - ΔXYZ = Focal - Target.
   - Physical/manual Locate uses validated absolute focal evidence.
   - Unvalidated 150 mm fallback does not produce a focal-target judgement.
3. Verification
   - R0167-R0182 related regression suite passed.
   - compileall PASS.
   - verify_source.py PASS.
