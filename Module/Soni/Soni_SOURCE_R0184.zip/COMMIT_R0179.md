# COMMIT R0179 — Multi-target Patient Treatment / Steering epochs

- Patient treatment no longer assumes one fixed treatment target.
- Physical target re-entry opens a new Target epoch and restarts mechanical XYZ alignment / Locate verification.
- Per-Sonication StartSonicate Steering XYZ is tracked as an electronic target stream inside the current physical target epoch.
- Electronic steering never changes the physical <1 mm alignment result and never fabricates a Locate event.
- Repeated identical Steering is suppressed as a change; only actual Steering-target transitions are surfaced.
- A PASS does not close a target epoch; later physician-directed re-position / re-Locate remains visible.
- DQA remains excluded from Patient treatment alignment.
