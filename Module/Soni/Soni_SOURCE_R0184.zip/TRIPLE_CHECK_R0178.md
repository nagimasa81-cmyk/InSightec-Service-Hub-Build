# TRIPLE CHECK R0178

1. Semantic: initial Locate is not mislabeled as post-target; target entry reuses latest Locate without inventing a tracker acquisition.
2. Clinical: every later re-Locate is retained, including repeats after a PASS; 1.000 mm is not PASS.
3. Regression/build: R0167–R0178 related suite 36 passed; compileall PASS; VERIFY_SOURCE_OK.
