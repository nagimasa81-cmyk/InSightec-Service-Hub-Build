# TRIPLE CHECK R0181

1. Absolute-vs-residual semantics
   - `New home position` = absolute physical pose evidence.
   - `New XD pos` = residual only; cannot create physical motion.

2. Focus geometry
   - Home + unit direction * inferred focal distance reproduces direct focal display.
   - Real fixture focal distance ~149.99 mm; validation residual <0.1 mm.

3. Regression
   - R0167-R0181 related suite executed.
   - compileall and verify_source executed before packaging.
