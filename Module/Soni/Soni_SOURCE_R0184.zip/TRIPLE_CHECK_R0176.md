# Triple Check R0176

1. Semantic check
   - Authoritative physical XYZ comes only from `New XD pos. in CSA coords. according to trackers`.
   - Recurring `Xd loc XYZ`, MoveTo zero-state, and Steering XYZ are not promoted to physical transducer position.

2. Binding check
   - Reliability, return code, tilt, tracker PQR/iniPQR/TrackerPos and Home UVW are causally bound with bounded look-back.
   - Parser stops look-back at the previous authoritative tracker result to prevent consecutive-event contamination.
   - Delta XYZ and 3D displacement use the first tracker-derived result as baseline.

3. Regression / packaging check
   - R0167–R0176 focused non-UI regression: 31 passed.
   - `python -m compileall -q src main.py`: PASS.
   - `python verify_source.py`: VERIFY_SOURCE_OK.
   - Full pytest collection in this container is blocked by missing PySide6/pyqtgraph dependencies; this is an environment limitation, not an R0176 failure.
   - Final source package audited for one build contract, no duplicate entries, and no cache/tmp artifacts.
