# Triple Check R0175

1. History semantics: only explicit Locate-associated non-zero physical XYZ can enter the user history.
2. Diagnostic discovery: broad candidate wording and Xd contexts are serialized separately and never affect parse().
3. Packaging/regression: compile, verify_source, focused R0167-R0175 regression, single contract, no cache/tmp artifacts.
