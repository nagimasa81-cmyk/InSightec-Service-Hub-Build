# COMMIT R0184 — Initial Target back-binding + Focal 0.1 mm display + Umbrella family orientation

- Focal point X/Y/Z in Focal / Target History display with one decimal place.
- The first authoritative Treatment Target is back-bound to the first Treatment Locate that occurred before target entry, so the initial gap is calculated as Focal - first Target.
- Brain220 remains the validated umbrella orientation reference.
- Brain650 no longer receives the historical Brain220 native-Z inversion.
- Canonical family orientation is applied once at geometry ingress and shared by perspective/named views and focus/reference point projection.
- Historical tests that encoded unconditional Z inversion were replaced with explicit Brain220/Brain650 family tests.
