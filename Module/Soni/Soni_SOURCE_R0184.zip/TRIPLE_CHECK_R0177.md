# Triple Check R0177

1. Semantic separation
   - DQA does not receive Patient target-alignment judgement.
   - Tracker CSA result is not labelled absolute XYZ; it is retained as residual evidence.
   - Target and reconstructed Transducer XYZ are only emitted when a non-DQA protocol and preceding Home/target reference are both present.
2. Threshold contract
   - Per-axis judgement is `abs(delta) < 1.000 mm`.
   - 0.999 mm PASS; 1.000 mm FAIL.
3. Regression/package
   - R0176 tracker parsing retained, including bounded localization-block binding.
   - Steering, recurring Xd state and MoveTo zero-state are not substituted.
   - Build metadata advanced to RC7.10-R0177 / 7.10.0.177.
