# TRIPLE CHECK R0179

1. Semantic separation
   - Physical target epoch, electronic Steering target, and tracker/Locate alignment are separate state domains.
   - Steering XYZ is never substituted for physical Transducer XYZ or physical target-vs-transducer delta.
2. Clinical sequence
   - Initial Locate -> target entry -> physical gap check -> mechanical move/re-Locate.
   - Mid-treatment Steering remains same physical epoch.
   - Mid-treatment physical target re-entry creates Target #2/#3 and restarts alignment.
   - Re-Locate after an already passing result remains in history.
3. Validation
   - R0167-R0179 relevant suite: 39 passed.
   - compileall: PASS.
   - VERIFY_SOURCE_OK after metadata update.
