# COMMIT R0178 — Patient Treatment Transducer Alignment Workflow

- Patient treatment timeline now follows the clinical workflow:
  1. Initial Locate Transducer before registration/target entry.
  2. Same-day MRI + preplanning registration / AC-PC / treatment target entry, then first gap check using the latest initial Locate result (no fabricated second Locate).
  3. Mechanical XYZ adjustment followed by re-Locate and recheck.
  4. Additional physician-directed adjustment/re-Locate remains visible even after a <1 mm PASS.
- DQA remains excluded.
- Per-axis acceptance is strict abs(delta) < 1.000 mm.
- Diagnostics and CSV export preserve the workflow stage.
