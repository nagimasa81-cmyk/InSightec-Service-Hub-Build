# COMMIT R0183 — Direct Locate Focal / Target History

- Treatment Locate rows bind `Pos = X,Y,Z` and `focal position:` from the same workstation calibration block.
- ΔXYZ = Focal - Target; PASS requires every axis strictly <1.000 mm.
- Target-free initial Treatment Locate remains Focal-only.
- DQA Locate Transducer is included: every DQA focal point is listed; Target/Δ/PASS are N/A.
- SonicationSummary session start filters stale pre-session DQA/calibration history from a Treatment export.
- Electronic Steering is bound only to a physical Target that already existed at the event clock; future Target borrowing is prohibited.
- UI is reduced to Focal point / Target / ΔXYZ / per-axis judgement / Effective Target. Tracker residual/Home/tilt details remain diagnostics-only.
