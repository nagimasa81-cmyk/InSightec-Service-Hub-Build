# COMMIT R0180 — Manual Locate vs Automatic Tracker Verification

- Corrected R0177-R0179 semantic error: tracker residuals are not global absolute Transducer XYZ.
- Initial transducer/focal reference comes from PatientInfo/Home.
- Physical Target epochs are driven by changed Home/Set-new-home target reference events; immediate same-value initialization mirrors are ignored.
- Manual/physical Locate is separated from automatic pre-sonication tracker verification.
- Automatic tracker verification never updates physical Transducer XYZ or the <1 mm physical alignment verdict.
- Unclassified tracker localization remains visible as evidence but is not promoted to a physical Locate.
- Electronic Steering remains independent from physical target alignment.
