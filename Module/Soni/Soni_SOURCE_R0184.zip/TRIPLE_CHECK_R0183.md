# TRIPLE CHECK R0183

## 1. Treatment direct evidence
- Locate block authority: `Pos = X,Y,Z` + same-block `focal position:`.
- Delta is strictly `Focal - Target` per axis.
- PASS requires |dX|, |dY|, |dZ| each < 1.000 mm.
- Target-free initial Treatment Locate is Focal-only.
- Session start from SonicationSummary filters stale pre-session DQA/calibration history.
- Real anonymized Treatment export validation:
  - Initial Focal: (13.8, 12.4, 10.2)
  - Target: (11.1, 7.5, 14.0)
  - First paired Focal: (10.2, 7.2, 6.5), Delta=(-0.9,-0.3,-7.5), FAIL
  - Final paired Focal: (11.3, 7.3, 13.1), Delta=(+0.2,-0.2,-0.9), PASS

## 2. DQA
- DQA Locate Transducer focal points are retained and listed.
- DQA Target/Delta/PASS are intentionally N/A.
- Tracker residual never substitutes for focal point.

## 3. Steering
- Electronic Steering is separate from physical Locate.
- It binds only to a Target that existed before the event clock.
- Future Target borrowing is prohibited.

## 4. UI / CSV / Diagnostics
- Primary table reduced to Target XYZ, Focal point XYZ, Focal-Target Delta XYZ, axis verdict, Alignment, Effective Target.
- Tracker residual/Home/tilt remain diagnostics-only.
- No 3D displacement metric in this Focal/Target workflow.
- Diagnostics emit `locate_focal_history` plus `focal_xyz`, `target_xyz`, `delta_xyz`.

## 5. Verification
- R0167-R0183 related regression suite: 47 passed.
- Wider non-UI suite: 1157 passed, 11 historical-contract failures, 1 skipped.
- Full collection additionally requires PySide6/pyqtgraph in this environment.
- compileall: PASS.
- verify_source.py: VERIFY_SOURCE_OK.
