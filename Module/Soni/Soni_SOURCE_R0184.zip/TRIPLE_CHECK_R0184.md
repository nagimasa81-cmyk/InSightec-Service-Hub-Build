# TRIPLE CHECK R0184

## 1. Focal / Target history
- Focal point X/Y/Z UI formatting is one decimal place.
- First authoritative Treatment Target is back-bound to the first pre-target Treatment Locate.
- Real anonymized Treatment export validation:
  - first Focal = (13.8, 12.4, 10.2)
  - first Target = (11.1, 7.5, 14.0)
  - Delta = (+2.7, +4.9, -3.8) mm => FAIL
  - later final checks remain (+0.2, -0.2, -0.9) mm => PASS.
- DQA semantics remain Focal-only, Target/Delta/PASS N/A.

## 2. Umbrella orientation
- Root regression: unconditional q[:,2] *= -1.0 had returned.
- Brain220 (180-320 kHz): canonical Z sign = -1.0 (validated reference orientation).
- Brain650 (550-750 kHz): canonical Z sign = +1.0 (no Brain220 inversion).
- Canonical transform occurs once at geometry ingress and is shared by perspective, named projections, reference points and focus/phase points.
- Historical unconditional-Z tests were replaced with explicit Brain220/Brain650 family assertions.

## 3. Verification
- R0167-R0184 + Umbrella focused regression: 64 passed.
- compileall src: PASS.
- verify_source.py: VERIFY_SOURCE_OK.
- One unrelated historical R0154ah thermometry test still expects pre-R0164 top-3-pixel logic; current spatial 3x3 robust thermometry logic was intentionally not regressed to satisfy it.
