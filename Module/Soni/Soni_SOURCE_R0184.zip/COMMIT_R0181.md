# COMMIT R0181 — Absolute Physical Transducer Pose / Movement

- Added authoritative physical pose history from:
  - `Home position read ... Transducer Direction`
  - `New home position ... New XD tilt`
- `New XD pos...` remains residual-only evidence and never creates a physical movement event.
- Natural focus is reconstructed from absolute Home + normalized transducer direction.
- Focal distance is inferred/validated against nearby direct `focal position:` workstation output when available.
- Per-pose movement now reports:
  - Home ΔX/ΔY/ΔZ + 3D displacement
  - Natural-focus ΔX/ΔY/ΔZ + 3D displacement
- Diagnostics include full physical pose history, max Home movement, and max natural-focus movement.
- Current real-log fixture validates ~150 mm natural-focus geometry and ~0.863 mm Home movement.
