# R0177 — Patient Treatment Target / Transducer Alignment

- Separates Patient treatment alignment from DQA.
- Reinterprets `New XD pos. in CSA coords. according to trackers` as tracker-vs-calibrated-XD residual, consistent with the immediately following `CompareTrackerAndCalibXd` call.
- For non-DQA treatment, binds the latest preceding PatientInfo Home UVW target/reference and reconstructs tracker-derived Transducer XYZ = Target XYZ + residual.
- Displays Target XYZ, Transducer XYZ, per-axis delta, per-axis <1.000 mm PASS/FAIL and overall alignment.
- Exactly 1.000 mm is FAIL because the user requirement is strictly less than 1 mm.
- DQA rows remain N/A for this Patient alignment semantic.
- Recurring `Xd loc XYZ`, MoveTo zero-state and Steering XYZ remain excluded from physical-location reconstruction.
- Import Diagnostics records protocol, target, transducer, delta and per-axis judgement for real-export validation.
