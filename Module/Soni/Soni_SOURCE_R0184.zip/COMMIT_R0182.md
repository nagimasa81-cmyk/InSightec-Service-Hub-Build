# COMMIT R0182 — Focal position vs Treatment Target

- Main Patient-treatment alignment display now centers on:
  - Focal position X/Y/Z
  - Treatment Target X/Y/Z
  - Focal-Target ΔX/ΔY/ΔZ
- ΔXYZ = Focal - Target.
- Physical/manual Locate rows use absolute focal position reconstructed from absolute transducer pose.
- Tracker residual is not used as displayed Focal position.
- 3D displacement/movement values removed from UI/CSV/Diagnostics.
- Acceptance remains per-axis only: |ΔX|, |ΔY|, |ΔZ| < 1.000 mm.
