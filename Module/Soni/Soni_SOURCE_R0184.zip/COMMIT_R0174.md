# R0174 — Locate Transducer result filtering and diagnostic workflow capture

## Problem
R0173 treated every recurring `Xd loc XYZ` workstation state line as a transducer-location history record. Real R0173 evidence showed 167 rows, all physical XYZ = 0, while Steering varied and no row was actually associated with a Locate Transducer workflow.

## Fix
- `TransducerLocationService.parse()` now publishes only non-zero Xd location reports causally associated with an explicit Locate Transducer workflow event.
- Ordinary recurring Xd state reports remain available through `raw_xd_reports()` for diagnostics only.
- `(0,0,0)` cannot become a physical-location baseline.
- Locate association is causal and bounded: explicit event must precede the Xd report within 30 s and 120 log lines.
- Diagnostics now include raw Xd report count, zero-XYZ count, confirmed result count, and explicit Locate/Transducer workflow lines with nearby context.
- Steering XYZ remains separate electronic steering and is never substituted for physical transducer XYZ.

## Validation
R0173/R0174 focused tests plus R0167–R0171 regression selection pass.
