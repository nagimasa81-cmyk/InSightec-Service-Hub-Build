# TRIPLE CHECK R0180

1. Semantic separation
   - manual/physical Locate != automatic pre-sonication tracker verification
   - tracker residual != absolute Transducer XYZ
   - Steering != physical Transducer movement

2. Clinical workflow
   - Initial PatientInfo/Home -> Target entry -> physical gap
   - mechanical move -> confirmed Locate -> <1 mm check
   - repeated Locate after PASS remains supported
   - target re-entry opens a new physical target epoch

3. Verification
   - R0167-R0180 related regression suite: 41 passed
   - compileall: PASS
   - verify_source.py: VERIFY_SOURCE_OK
