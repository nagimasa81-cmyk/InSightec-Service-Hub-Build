from __future__ import annotations

import math
import struct
import gzip
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass(slots=True)
class DecodedSpectrum:
    offset: int
    frequency_hz: np.ndarray
    amplitude: np.ndarray
    confidence: float
    main_peak_hz: float | None
    source: Path
    frequency_axis_source: str = "Unknown"
    frequency_start_hz: float | None = None
    frequency_spacing_hz: float | None = None
    frequency_end_hz: float | None = None
    channel_count: int | None = None
    timestamp_seconds: float | None = None
    record_index: int | None = None


class SharedSpectrumDecoder:
    """
    Lightweight shared decoder for Replay integration.

    SpectrumMsg Analyzer remains the detailed reverse-engineering application.
    This decoder evaluates a bounded set of Float32/Little-Endian offsets and
    selects the candidate whose strongest peak is closest to the Xd INI main
    frequency.
    """

    SAMPLE_COUNT = 2048
    MAX_READ_BYTES = 8 * 1024 * 1024

    @staticmethod
    def _graph_frequency_range(path: Path, main_frequency_hz: float) -> tuple[float, float]:
        """Read the CPC GUI spectrum presentation window from Acquisition.ini.

        SpectrumMsg is exported under SonicationN while Acquisition.ini normally
        lives at CPCFiles/App/Ini. Search only nearby export roots and fall back
        conservatively when the file is absent.
        """
        candidates = []
        for parent in [path.parent, *path.parents[:5]]:
            candidates.extend([
                parent / "CPCFiles" / "App" / "Ini" / "Acquisition.ini",
                parent / "App" / "Ini" / "Acquisition.ini",
                parent / "Acquisition.ini",
            ])
        for ini in candidates:
            if not ini.exists():
                continue
            low = high = None
            try:
                for raw_line in ini.read_text(encoding="utf-8", errors="ignore").splitlines():
                    line = raw_line.split(";", 1)[0].strip()
                    if "=" not in line:
                        continue
                    key, value = [part.strip() for part in line.split("=", 1)]
                    if key.lower() == "f1forgraph":
                        low = float(value)
                    elif key.lower() == "f2forgraph":
                        high = float(value)
                if low is not None and high is not None and 0 <= low < high:
                    return float(low), float(high)
            except (OSError, ValueError):
                continue
        # Family-aware fallback only when Acquisition.ini is absent. Brain220
        # exports use a much lower GUI window (observed 50-250 kHz for f0=230
        # kHz) than Brain650 (observed 250-750 kHz for f0=670 kHz).
        if 180_000.0 <= float(main_frequency_hz) <= 320_000.0:
            return max(0.0, 0.20 * main_frequency_hz), 1.15 * main_frequency_hz
        return max(0.0, 0.35 * main_frequency_hz), 1.15 * main_frequency_hz

    @classmethod
    def _axis_for_graph_values(cls, path: Path, main_frequency_hz: float, embedded_freq: np.ndarray) -> tuple[np.ndarray, str]:
        """Validate embedded graph axis against the actual Sonication family.

        Some Brain220 exports carry graph containers whose embedded presentation
        metadata is inherited from a Brain650-style 250-750 kHz window.  When the
        actual main frequency does not even lie on that axis, treating it as real
        disconnects the 220-kHz Sonication from its spectrum.  Preserve the stored
        amplitudes but rebuild only the presentation axis from Acquisition.ini (or
        the family-aware fallback) when the embedded axis is physically incompatible.
        """
        freq=np.asarray(embedded_freq,float)
        valid=freq[np.isfinite(freq)]
        if valid.size >= 2:
            lo=float(np.nanmin(valid)); hi=float(np.nanmax(valid))
            # Small half-bin tolerance avoids rejecting a main peak at an edge.
            spacing=float(np.nanmedian(np.diff(valid))) if valid.size > 1 else 0.0
            if lo-abs(spacing) <= float(main_frequency_hz) <= hi+abs(spacing):
                return freq, "Embedded SpectrumMsg graph metadata (family validated)"
        low,high=cls._graph_frequency_range(path,float(main_frequency_hz))
        rebuilt=np.linspace(float(low),float(high),len(freq),endpoint=False,dtype=float)
        return rebuilt, "Family-aware graph axis fallback (embedded axis excludes actual main frequency)"

    @staticmethod
    def _graph_blocks(frame: bytes) -> list[np.ndarray]:
        """Return the eight explicit graph arrays stored in one SpectrumMsg frame.

        In validated CPC 6.33 exports each frame contains eight uint32 markers
        whose value is the graph-bin count (256), followed by that many float32
        graph values. Requiring exactly eight stable blocks prevents the previous
        arbitrary 2048-float window from being interpreted as a spectrum.
        """
        blocks: list[np.ndarray] = []
        marker = struct.pack("<I", 256)
        start = 0
        while True:
            pos = frame.find(marker, start)
            if pos < 0:
                break
            start = pos + 1
            if pos % 4 != 0 or pos + 4 + 256 * 4 > len(frame):
                continue
            values = np.frombuffer(frame, dtype="<f4", count=256, offset=pos + 4).astype(np.float64)
            if np.mean(np.isfinite(values)) < 0.995 or np.nanmax(np.abs(values)) >= 1e6:
                continue
            blocks.append(np.abs(np.nan_to_num(values, nan=0.0, posinf=0.0, neginf=0.0)))
        return blocks if len(blocks) == 8 else []

    @staticmethod
    def _explicit_graph_records(data: bytes, base_offset: int = 0) -> list[tuple[int, float, float, np.ndarray]]:
        """Return validated 256-bin graph records with their embedded axis metadata.

        Two vendor representations have been observed:
        * SpectrumMsg stores start/spacing in Hz (250000 / 1953)
        * CPC FFT stores the same values in MHz (0.25 / 0.001953)
        The units are selected from value magnitude, never from the filename.
        """
        marker = struct.pack("<I", 256)
        records: list[tuple[int, float, float, np.ndarray]] = []
        start = 0
        while True:
            pos = data.find(marker, start)
            if pos < 0:
                break
            start = pos + 1
            if pos % 4 != 0 or pos < 16 or pos + 4 + 256 * 4 > len(data):
                continue
            try:
                _yscale, spacing_raw, start_raw, _danger = struct.unpack_from("<4f", data, pos - 16)
            except struct.error:
                continue
            # Convert only after validating a known physical range.
            if 100.0 <= spacing_raw <= 20_000.0 and 50_000.0 <= start_raw <= 1_500_000.0:
                spacing_hz, start_hz = float(spacing_raw), float(start_raw)
            elif 0.0001 <= spacing_raw <= 0.020 and 0.05 <= start_raw <= 1.5:
                spacing_hz, start_hz = float(spacing_raw) * 1e6, float(start_raw) * 1e6
            else:
                continue
            values = np.frombuffer(data, dtype="<f4", count=256, offset=pos + 4).astype(np.float64)
            if np.mean(np.isfinite(values)) < 0.995 or np.nanmax(np.abs(values)) >= 1e6:
                continue
            records.append((base_offset + pos, start_hz, spacing_hz, np.abs(values)))
        return records

    @classmethod
    def _explicit_graph_groups(cls, data: bytes, base_offset: int = 0) -> list[tuple[np.ndarray, list[np.ndarray], int]]:
        """Decode the explicit CPC GUI graph records embedded in SpectrumMsg.

        Validated exports carry one uint32 bin-count marker (256) per channel.
        Immediately before it are graph metadata including bin spacing (~1953 Hz)
        and start frequency (250000 Hz). Eight consecutive records are one GUI
        spectrum sample. This provides a direct frequency axis and is preferred
        over all heuristic Float32-window decoding.
        """
        records = cls._explicit_graph_records(data, base_offset=base_offset)
        groups: list[tuple[np.ndarray, list[np.ndarray], int]] = []
        for i in range(0, len(records) - 7, 8):
            group = records[i:i + 8]
            starts = np.asarray([r[1] for r in group], float)
            spacings = np.asarray([r[2] for r in group], float)
            if np.nanmax(starts) - np.nanmin(starts) > 1.0 or np.nanmax(spacings) - np.nanmin(spacings) > 1.0:
                continue
            freq = float(np.nanmedian(starts)) + np.arange(256, dtype=float) * float(np.nanmedian(spacings))
            groups.append((freq, [r[3] for r in group], group[0][0]))
        return groups


    @staticmethod
    def _wordswapped_float64(data: bytes, offset: int) -> float:
        """Decode the mixed-endian Float64 used by the Brain220 SpectrumMsg stream.

        The 220-kHz export writes each IEEE754 double as two little-endian uint32
        words in high-word/low-word order.  Treating those bytes as normal LE
        float32/float64 creates the characteristic 0/-2/3.69e19 pseudo-values and
        was the reason R0154l could only recover one heuristic spectrum.
        """
        high, low = struct.unpack_from("<II", data, offset)
        return float(struct.unpack("<d", struct.pack("<II", low, high))[0])

    @classmethod
    def _size_table_records(cls, data: bytes) -> list[tuple[int, bytes]]:
        """Return exact records for the vendor size-table SpectrumMsg container.

        Brain220 data in the supplied 2026-04-01 export is not the Brain650
        <frame_count, frame_size, channel_count> container.  It is:

            uint32 record_count
            uint32 record_size[record_count]
            record bytes concatenated exactly

        This parser is structure-driven: the complete size equation must close and
        every record must pass its own internal length equation.  No filename,
        serial number, fixture hash, or expected record count is used.
        """
        if len(data) < 12:
            return []
        try:
            count = int(struct.unpack_from("<I", data, 0)[0])
        except struct.error:
            return []
        if not (1 <= count <= 200000):
            return []
        header_bytes = 4 + count * 4
        if header_bytes > len(data):
            return []
        try:
            sizes = [int(v) for v in struct.unpack_from(f"<{count}I", data, 4)]
        except struct.error:
            return []
        if any(size < 128 or size > len(data) for size in sizes):
            return []
        if header_bytes + sum(sizes) != len(data):
            return []
        out: list[tuple[int, bytes]] = []
        pos = header_bytes
        for size in sizes:
            record = data[pos:pos + size]
            if len(record) != size:
                return []
            # First record field is 48 + 8*N where N is the FFT bin count.
            try:
                spectral_extent = int(struct.unpack_from("<I", record, 0)[0])
            except struct.error:
                return []
            if spectral_extent < 48 or (spectral_extent - 48) % 8 != 0:
                return []
            bins = (spectral_extent - 48) // 8
            spectral_end = 56 + bins * 8
            if not (64 <= bins <= 16384) or spectral_end + 16 > len(record):
                return []
            # Following the FFT vector is a uint32 history-count, 20 bytes per
            # history sample, then a fixed 12-byte trailer.  This exact equation
            # distinguishes the format from arbitrary binary data.
            history_count = int(struct.unpack_from("<I", record, spectral_end)[0])
            if history_count > 100000:
                return []
            if spectral_end + 4 + history_count * 20 + 12 != len(record):
                return []
            out.append((pos, record))
            pos += size
        return out

    @classmethod
    def _decode_size_table_spectrum(cls, data: bytes, path: Path, main_frequency_hz: float) -> list[DecodedSpectrum]:
        """Decode the exact Brain220-style variable-record SpectrumMsg stream.

        Each record contains a complete FFT vector plus short measurement-history
        entries.  The embedded bin spacing and upper-frequency metadata are used
        directly.  The last valid history time is carried forward as the spectrum
        timestamp so Replay can synchronize by evidence instead of proportional
        frame index.
        """
        records = cls._size_table_records(data)
        if not records:
            return []
        decoded: list[DecodedSpectrum] = []
        for record_index, (absolute_offset, record) in enumerate(records):
            spectral_extent = int(struct.unpack_from("<I", record, 0)[0])
            bins = (spectral_extent - 48) // 8
            try:
                spacing_hz = cls._wordswapped_float64(record, 24)
                zero_hz = cls._wordswapped_float64(record, 32)
                upper_hz = cls._wordswapped_float64(record, 40)
            except (struct.error, ValueError):
                return []
            if not (math.isfinite(spacing_hz) and 0.1 <= spacing_hz <= 100000.0):
                return []
            if not math.isfinite(zero_hz) or abs(zero_hz) > max(10.0, spacing_hz * 0.1):
                return []
            expected_upper = bins * spacing_hz
            # The observed metadata is stored at Float64 precision but generated
            # from a Float32-like value (e.g. 250000.046875).  Allow one bin.
            if not (math.isfinite(upper_hz) and abs(upper_hz - expected_upper) <= max(spacing_hz, expected_upper * 5e-4)):
                return []
            amplitude = np.empty(bins, dtype=np.float64)
            for i in range(bins):
                amplitude[i] = cls._wordswapped_float64(record, 56 + i * 8)
            if np.mean(np.isfinite(amplitude)) < 0.995:
                return []
            amplitude = np.abs(np.nan_to_num(amplitude, nan=0.0, posinf=0.0, neginf=0.0))
            if not np.any(amplitude > 0):
                return []
            frequency_hz = zero_hz + np.arange(bins, dtype=float) * spacing_hz

            history_pos = 56 + bins * 8
            history_count = int(struct.unpack_from("<I", record, history_pos)[0])
            timestamps: list[float] = []
            for j in range(history_count):
                # The fourth float32 in each 20-byte history entry is its elapsed
                # acquisition time.  Negative sentinel values are not timestamps.
                t = float(struct.unpack_from("<f", record, history_pos + 4 + j * 20 + 12)[0])
                if math.isfinite(t) and t >= 0.0:
                    timestamps.append(t)
            timestamp_seconds = max(timestamps) if timestamps else None

            peak_i = int(np.argmax(amplitude))
            peak_hz = float(frequency_hz[peak_i])
            decoded.append(DecodedSpectrum(
                offset=int(absolute_offset),
                frequency_hz=frequency_hz,
                amplitude=amplitude,
                confidence=100.0,
                main_peak_hz=peak_hz,
                source=path,
                frequency_axis_source="Embedded SpectrumMsg size-table FFT metadata",
                frequency_start_hz=float(frequency_hz[0]),
                frequency_spacing_hz=float(spacing_hz),
                frequency_end_hz=float(frequency_hz[-1]),
                channel_count=None,
                timestamp_seconds=timestamp_seconds,
                record_index=record_index,
            ))
        # Time evidence should be monotonic for a valid acquisition stream.  A
        # malformed candidate fails closed rather than silently falling back to a
        # misleading partial size-table decode.
        finite_times = [f.timestamp_seconds for f in decoded if f.timestamp_seconds is not None]
        if len(finite_times) >= 3 and any(b + 1e-4 < a for a, b in zip(finite_times, finite_times[1:])):
            return []
        return decoded

    @staticmethod
    def _heuristic_analysis_band(main_frequency_hz: float) -> tuple[float, float]:
        """Physics-aware band used only by legacy Float32 heuristics.

        Brain220 fallback must include the subharmonic/low graph region instead
        of inheriting the historical 200-800 kHz Brain650 search window.
        Exact embedded graph metadata still wins whenever it is structurally valid.
        """
        f0=float(main_frequency_hz)
        if 180_000.0 <= f0 <= 320_000.0:
            return max(20_000.0, 0.18*f0), 1.30*f0
        return 200_000.0, 800_000.0

    def decode_frames(
        self,
        path: Path,
        main_frequency_hz: float,
        channel_index: int | None = None,
    ) -> list[DecodedSpectrum]:
        """Decode every plausible spectrum block in one SpectrumMsg file.

        Many exported SpectrumMsg files contain more than one spectrum record.
        The previous integration returned only one best block, which made the
        chart static (1/1) and prevented frame synchronization.  This method
        scans aligned Float32 windows, keeps high-quality non-duplicate blocks,
        and falls back to the legacy single-frame decoder when needed.
        """
        raw_bytes = path.read_bytes()
        try:
            data = gzip.decompress(raw_bytes)
        except Exception:
            data = raw_bytes
        # Keep the complete payload for structural validation. The legacy
        # heuristic is capped later, only after an exact frame layout fails.
        full_data = data
        block_bytes = self.SAMPLE_COUNT * 4
        if len(full_data) < 64:
            return []

        # R0154m: Brain220 uses a variable-record size-table container, not the
        # Brain650 three-int frame header. Decode that exact structure first.
        size_table_frames = self._decode_size_table_spectrum(full_data, path, float(main_frequency_hz))
        if size_table_frames:
            return size_table_frames

        max_frequency_hz = max(
            main_frequency_hz * (3.2 if main_frequency_hz <= 320_000.0 else 2.2),
            main_frequency_hz + 200_000.0,
        )

        # R0030: validate the vendor container count against the explicit GUI
        # graph records before using them.  In the validated 6.33 layout, the
        # first CH graph starts in the global envelope and the remaining seven
        # records continue through the declared frame region, so simple byte
        # slicing at frame_size is not the channel boundary.  The invariant that
        # *is* exact is frame_count × channel_count graph records.
        try:
            frame_count, frame_size, channel_count = struct.unpack_from("<iii", full_data, 0)
        except Exception:
            frame_count = frame_size = channel_count = 0
        exact_header = len(full_data) - frame_count * frame_size if frame_count > 0 and frame_size > 0 else -1
        structural_header_valid = bool(
            1 <= frame_count <= 100000 and 1024 <= frame_size <= len(full_data)
            and 1 <= channel_count <= 64 and 0 <= exact_header <= 65536
        )
        if structural_header_valid:
            records = self._explicit_graph_records(full_data)
            if len(records) == frame_count * channel_count:
                exact_frames: list[DecodedSpectrum] = []
                structurally_valid = True
                for frame_no in range(frame_count):
                    group = records[frame_no * channel_count:(frame_no + 1) * channel_count]
                    starts = np.asarray([r[1] for r in group], float)
                    spacings = np.asarray([r[2] for r in group], float)
                    offsets = np.asarray([r[0] for r in group], int)
                    if (
                        len(group) != channel_count or np.ptp(starts) > 1.0
                        or np.ptp(spacings) > 1.0 or np.any(np.diff(offsets) <= 0)
                    ):
                        structurally_valid = False
                        break
                    embedded_freq = float(np.median(starts)) + np.arange(256, dtype=float) * float(np.median(spacings))
                    freq, axis_source = self._axis_for_graph_values(path, main_frequency_hz, embedded_freq)
                    channels = [r[3] for r in group]
                    if channel_index is not None and 0 <= int(channel_index) < len(channels):
                        amp = channels[int(channel_index)]
                    else:
                        amp = np.nanmean(np.vstack(channels), axis=0)
                    peak_i = int(np.argmax(amp))
                    peak_hz = float(freq[peak_i])
                    distance = abs(peak_hz - main_frequency_hz) / max(main_frequency_hz, 1.0)
                    exact_frames.append(DecodedSpectrum(
                        offset=int(offsets[0]), frequency_hz=freq, amplitude=amp,
                        confidence=100.0 if distance <= 0.08 else 95.0,
                        main_peak_hz=peak_hz, source=path,
                        frequency_axis_source=axis_source,
                        frequency_start_hz=float(freq[0]),
                        frequency_spacing_hz=float(np.median(np.diff(freq))),
                        frequency_end_hz=float(freq[-1]), channel_count=int(channel_count),
                    ))
                if structurally_valid and len(exact_frames) == frame_count:
                    return exact_frames

        # Legacy/non-structural files can still contain explicit GUI graph records.
        # Never let the legacy global 8-record grouper override a valid vendor
        # frame header.  If a declared frame/channel set is only partially
        # recognized, grouping the surviving records globally can silently shrink
        # N declared frames to N-1 (or worse) and makes a 220-kHz file look "fully
        # decoded" when it is not.  A structurally declared file is recovered by
        # the frame-boundary path below instead.
        explicit_groups = [] if structural_header_valid else self._explicit_graph_groups(full_data)
        if explicit_groups:
            exact_frames: list[DecodedSpectrum] = []
            for embedded_freq, channels, offset in explicit_groups:
                freq, axis_source = self._axis_for_graph_values(path, main_frequency_hz, embedded_freq)
                if channel_index is not None and 0 <= int(channel_index) < len(channels):
                    amp = channels[int(channel_index)]
                else:
                    amp = np.nanmean(np.vstack(channels), axis=0)
                peak_i = int(np.argmax(amp))
                peak_hz = float(freq[peak_i])
                distance = abs(peak_hz - main_frequency_hz) / max(main_frequency_hz, 1.0)
                spacing = float(np.median(np.diff(freq))) if len(freq) > 1 else None
                exact_frames.append(DecodedSpectrum(
                    offset=offset, frequency_hz=freq, amplitude=amp,
                    confidence=100.0 if distance <= 0.08 else 95.0,
                    main_peak_hz=peak_hz, source=path,
                    frequency_axis_source=axis_source,
                    frequency_start_hz=float(freq[0]), frequency_spacing_hz=spacing,
                    frequency_end_hz=float(freq[-1]), channel_count=len(channels),
                ))
            return exact_frames

        # R0022: SpectrumMsg exact structural mode.
        # Validated exports store <frame_count, frame_size, channel_count> at
        # offsets 0/4/8. The global-header size is solved from total bytes.
        # We honor those frame boundaries first and only fall back to the
        # historical whole-file heuristic when the size equation fails.
        try:
            frame_count, frame_size, channel_count = struct.unpack_from("<iii", full_data, 0)
        except Exception:
            frame_count = frame_size = channel_count = 0
        exact_header = len(full_data) - frame_count * frame_size if frame_count > 0 and frame_size > 0 else -1
        if (
            1 <= frame_count <= 100000
            and 1024 <= frame_size <= len(full_data)
            and 1 <= channel_count <= 64
            and 0 <= exact_header <= 65536
        ):
            exact_frames: list[DecodedSpectrum] = []
            block_bytes = self.SAMPLE_COUNT * 4
            for frame_no in range(frame_count):
                start = exact_header + frame_no * frame_size
                frame = full_data[start:start + frame_size]
                graph_blocks = self._graph_blocks(frame)
                if graph_blocks:
                    graph_low_hz, graph_high_hz = self._graph_frequency_range(path, main_frequency_hz)
                    freqs = np.linspace(graph_low_hz, graph_high_hz, 256, endpoint=False, dtype=float)
                    if channel_index is not None and 0 <= int(channel_index) < len(graph_blocks):
                        amp = graph_blocks[int(channel_index)]
                    else:
                        # Unknown channel identity: average all explicit CPC graph
                        # channels rather than inventing a physical channel.
                        amp = np.nanmean(np.vstack(graph_blocks), axis=0)
                    peak_i = int(np.argmax(amp))
                    peak_hz = float(freqs[peak_i])
                    distance = abs(peak_hz-main_frequency_hz)/max(main_frequency_hz,1.0)
                    exact_frames.append(DecodedSpectrum(
                        offset=start, frequency_hz=freqs, amplitude=amp,
                        confidence=100.0 if distance <= 0.08 else 95.0,
                        main_peak_hz=peak_hz, source=path,
                    ))
                    continue
                best = None
                best_score = -1.0
                # Keep all candidates inside the validated frame. This prevents
                # windows from crossing proprietary frame boundaries.
                strides = sorted(set(
                    list(range(0, max(1, len(frame) - block_bytes + 1), block_bytes))
                    + list(range(block_bytes // 2, max(1, len(frame) - block_bytes + 1), block_bytes))
                ))
                # Channel-aligned candidates are also tested when divisible.
                if frame_size % channel_count == 0:
                    channel_bytes = frame_size // channel_count
                    for ch in range(channel_count):
                        base = ch * channel_bytes
                        strides.extend([base, base + max(0, (channel_bytes - block_bytes)//2)])
                for local_offset in sorted(set(o for o in strides if 0 <= o <= len(frame)-1024)):
                    count = min(self.SAMPLE_COUNT, (len(frame)-local_offset)//4)
                    if count < 256:
                        continue
                    values = np.frombuffer(frame, dtype="<f4", count=count, offset=local_offset).astype(np.float64)
                    if float(np.mean(np.isfinite(values))) < .95:
                        continue
                    amp = np.abs(np.nan_to_num(values, nan=0.0, posinf=0.0, neginf=0.0))
                    if not np.any(amp > 0):
                        continue
                    freqs = np.linspace(0.0, max_frequency_hz, num=count, endpoint=False)
                    band_low, band_high = self._heuristic_analysis_band(main_frequency_hz)
                    band = (freqs >= band_low) & (freqs <= band_high)
                    if not np.any(band):
                        continue
                    band_amp = amp[band]
                    median = max(float(np.nanmedian(band_amp)), 1e-12)
                    dynamic = float(np.nanmax(band_amp) / median)
                    peak_i = int(np.argmax(amp))
                    peak_hz = float(freqs[peak_i])
                    distance = abs(peak_hz-main_frequency_hz)/max(main_frequency_hz,1.0)
                    non_negative = float(np.mean(values >= 0))
                    continuity = 1.0 - min(1.0, float(np.std(np.diff(amp))) / max(float(np.std(amp))*2.0,1e-12))
                    score = (
                        max(0.0,1.0-distance)*0.55
                        + non_negative*0.15
                        + min(1.0,dynamic/20.0)*0.20
                        + continuity*0.10
                    )*100.0
                    if distance <= 0.35 and score > best_score:
                        best_score = score
                        best = DecodedSpectrum(
                            offset=start + local_offset,
                            frequency_hz=freqs,
                            amplitude=amp,
                            confidence=round(min(100.0, score + 10.0),1),
                            main_peak_hz=peak_hz,
                            source=path,
                        )
                if best is not None:
                    exact_frames.append(best)
            if exact_frames:
                return exact_frames
        # Unknown/legacy layout: cap only the fallback scan.
        data = full_data[: self.MAX_READ_BYTES]
        frames: list[DecodedSpectrum] = []
        # Use 2048-float blocks first; also test a half-block stride so headers
        # and interleaved records do not force all frames off alignment.
        offsets = list(range(0, max(1, len(data)-256), block_bytes))
        offsets += list(range(block_bytes//2, max(1, len(data)-256), block_bytes))
        seen: list[np.ndarray] = []
        for offset in sorted(set(offsets)):
            count=min(self.SAMPLE_COUNT,(len(data)-offset)//4)
            if count < 256:
                continue
            values=np.frombuffer(data,dtype='<f4',count=count,offset=offset).astype(np.float64)
            if float(np.mean(np.isfinite(values))) < .95:
                continue
            amp=np.abs(np.nan_to_num(values,nan=0.0,posinf=0.0,neginf=0.0))
            if not np.any(amp>0):
                continue
            freqs=np.linspace(0.0,max_frequency_hz,num=count,endpoint=False)
            band_low, band_high = self._heuristic_analysis_band(main_frequency_hz)
            band=(freqs>=band_low)&(freqs<=band_high)
            if not np.any(band):
                continue
            band_amp=amp[band]
            dynamic=float(np.nanmax(band_amp)/max(float(np.nanmedian(band_amp)),1e-12))
            if not np.isfinite(dynamic) or dynamic < 1.2:
                continue
            # Reject near-identical overlapping candidates.
            signature=np.interp(np.linspace(0,len(band_amp)-1,64),np.arange(len(band_amp)),band_amp)
            signature=signature/max(float(np.nanmax(signature)),1e-12)
            if any(float(np.nanmean(np.abs(signature-prev))) < 0.01 for prev in seen):
                continue
            seen.append(signature)
            peak_i=int(np.argmax(amp))
            peak_hz=float(freqs[peak_i])
            distance=abs(peak_hz-main_frequency_hz)/max(main_frequency_hz,1.0)
            if distance > 0.35:
                continue
            confidence=min(100.0, 35.0 + min(45.0, dynamic*3.0) + max(0.0,20.0*(1.0-distance/0.35)))
            frames.append(DecodedSpectrum(offset=offset,frequency_hz=freqs,amplitude=amp,confidence=round(confidence,1),main_peak_hz=peak_hz,source=path))
        if frames:
            frames.sort(key=lambda f:f.offset)
            return frames
        single=self.decode_file(path,main_frequency_hz)
        return [single] if single is not None else []

    def decode_file(
        self,
        path: Path,
        main_frequency_hz: float,
    ) -> DecodedSpectrum | None:
        raw_bytes = path.read_bytes()
        try:
            data = gzip.decompress(raw_bytes)
        except Exception:
            data = raw_bytes
        data = data[: self.MAX_READ_BYTES]
        sample_bytes = self.SAMPLE_COUNT * 4
        if len(data) < 64:
            return None

        max_frequency_hz = max(
            main_frequency_hz * (3.2 if main_frequency_hz <= 320_000.0 else 2.2),
            main_frequency_hz + 200_000.0,
        )

        candidate_offsets = {0, 16, 32, 64, 128, 256, 512, 1024}
        for divisor in range(1, 17):
            candidate_offsets.add(
                max(0, (len(data) // divisor) // 4 * 4)
            )
        for offset in range(
            0,
            min(len(data), sample_bytes * 4),
            max(256, sample_bytes // 4),
        ):
            candidate_offsets.add(offset)

        best = None
        best_score = -1.0

        for offset in sorted(candidate_offsets):
            if offset + 16 > len(data):
                continue

            count = min(
                self.SAMPLE_COUNT,
                (len(data) - offset) // 4,
            )
            if count < 64:
                continue

            values = np.frombuffer(
                data,
                dtype="<f4",
                count=count,
                offset=offset,
            ).astype(np.float64)

            finite = np.isfinite(values)
            if float(np.mean(finite)) < 0.95:
                continue

            amplitude = np.abs(
                np.nan_to_num(
                    values,
                    nan=0.0,
                    posinf=0.0,
                    neginf=0.0,
                )
            )

            if not np.any(amplitude > 0):
                continue

            frequencies = np.linspace(
                0.0,
                max_frequency_hz,
                num=count,
                endpoint=False,
            )

            peak_index = int(np.argmax(amplitude))
            peak_frequency = float(frequencies[peak_index])
            distance = abs(
                peak_frequency - main_frequency_hz
            ) / max(main_frequency_hz, 1.0)

            non_negative = float(np.mean(values >= 0))
            dynamic = float(
                np.max(amplitude)
                / max(np.mean(amplitude), 1e-12)
            )
            continuity = 1.0 - min(
                1.0,
                float(np.std(np.diff(amplitude)))
                / max(float(np.std(amplitude)) * 2.0, 1e-12),
            )

            frequency_score = max(0.0, 1.0 - distance)
            dynamic_score = min(1.0, dynamic / 20.0)
            score = (
                frequency_score * 0.55
                + non_negative * 0.15
                + dynamic_score * 0.20
                + continuity * 0.10
            ) * 100.0

            if score > best_score:
                best_score = score
                best = DecodedSpectrum(
                    offset=offset,
                    frequency_hz=frequencies,
                    amplitude=amplitude,
                    confidence=round(score, 1),
                    main_peak_hz=peak_frequency,
                    source=path,
                )

        return best
