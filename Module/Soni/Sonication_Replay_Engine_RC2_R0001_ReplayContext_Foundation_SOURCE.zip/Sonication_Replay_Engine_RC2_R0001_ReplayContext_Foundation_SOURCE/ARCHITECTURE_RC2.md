# Sonication Replay RC2 architecture

RC2 stops extending the RC1 widget-owned navigation model.

## Non-negotiable rule

`ReplayContext` is the only owner of:

- current sonication
- current replay frame
- current hydrophone channel
- valid index ranges

Buttons, keyboard, mouse wheel, timeline clicks and future thumbnail selection all request changes through this context. Views receive the complete `ReplaySelection` and redraw from the same state.

## Migration sequence

R0001 introduces and wires the central context without deleting proven decoders.
R0002 moves temperature, image, spectrum and power/score refresh into independent context subscribers.
R0003 replaces the RC1 layout with the treatment-analysis console layout.
R0004 binds planning CT/MR/thermal sources through a typed PlanningImageManager.

No RC2 milestone is considered complete from static source checks alone. Windows runtime screenshots and state diagnostics are required.
