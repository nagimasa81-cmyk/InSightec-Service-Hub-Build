from __future__ import annotations

import threading
from pathlib import Path

from src.services.spectrum_dump_import_service import SpectrumDumpImportService
from src.services.hydrophone_replay_service import HydrophoneReplayService
from src.services.standalone_cavitation_service import StandaloneCavitationService


class SpectrumEvidenceRepository:
    """Study-scoped shared Spectrum decode/evidence cache.

    Multiple background consumers (preload, Summary, Treatment Outcome) can ask for
    the same Sonication.  Exactly one decoder owns a Sonication at a time; peers wait
    for that result rather than performing duplicate FFT/vendor-rule work.
    """

    def __init__(self, hydrophone_service=None, acoustic_control_service=None, standalone_service=None):
        self.hydrophone = hydrophone_service or HydrophoneReplayService()
        self.acoustic = acoustic_control_service
        self.standalone = standalone_service or StandaloneCavitationService()
        self._condition = threading.Condition()
        self._workspace_token = None
        self._mapping = None
        self._replays = {}
        self._standalone = {}
        self._errors = {}
        self._inflight = set()

    @staticmethod
    def _token(package) -> str:
        try:
            return str(Path(package.workspace).resolve())
        except Exception:
            return str(getattr(package, "workspace", ""))

    def clear(self) -> None:
        with self._condition:
            self._workspace_token = None
            self._mapping = None
            self._replays.clear(); self._standalone.clear(); self._errors.clear(); self._inflight.clear()
            self._condition.notify_all()

    def _ensure_workspace(self, package) -> str:
        token = self._token(package)
        with self._condition:
            if self._workspace_token != token:
                self._workspace_token = token
                self._mapping = None
                self._replays.clear(); self._standalone.clear(); self._errors.clear(); self._inflight.clear()
        return token

    def candidate_mapping(self, package):
        self._ensure_workspace(package)
        with self._condition:
            if self._mapping is not None:
                return self._mapping
            # Hold the repository lock while building the index. Discovery is worker-
            # thread owned, and serializing it prevents duplicate recursive scans.
            importer = SpectrumDumpImportService()
            workspace = Path(package.workspace)
            inventory = list(getattr(package, "cpc_spectrum_files", []) or [])
            candidates = importer.discover_from_files(workspace, inventory)
            if not any(getattr(c, "family", "") == "CPC Spectrum" for c in candidates):
                candidates = importer.discover(workspace)
            self._mapping = importer.map_candidates_to_sonications(candidates, list(getattr(package, "sonications", []) or []))
            return self._mapping

    def _configure_replay(self, package, index: int, son, replay, candidate):
        preferred = getattr(getattr(replay, "vendor_history_validation", None), "log_session_index", None)
        if preferred is None and candidate is not None:
            preferred = getattr(candidate, "acquisition_session_index", None)
        if preferred is None:
            preferred = getattr(son, "canonical_acquisition_session_index", None)
        replay.acquisition_session_index = int(preferred) if preferred is not None else None
        if self.acoustic is not None:
            replay.sonication_time_zero_offset_s = self.acoustic.sonication_time_zero_offset(
                Path(package.workspace), int(index), replay.acquisition_session_index
            )
        replay.mr_timeline_duration_s = float(getattr(son, "mr_timeline_duration_s", 0.0) or 0.0)
        replay.mr_sonication_start_s = float(getattr(son, "mr_sonication_start_s", 0.0) or 0.0)
        replay.mr_sonication_end_s = float(getattr(son, "mr_sonication_end_s", 0.0) or 0.0)
        replay.mr_timeline_source = str(getattr(son, "mr_timeline_source", "Unavailable"))
        replay.mr_timeline_confidence = str(getattr(son, "mr_timeline_confidence", "Unknown"))
        return replay

    def replay(self, package, index: int, son=None, progress_callback=None):
        token = self._ensure_workspace(package)
        index = int(index)
        if son is None:
            son = list(getattr(package, "sonications", []) or [])[index]
        with self._condition:
            if index in self._replays:
                return self._replays[index]
            while index in self._inflight:
                self._condition.wait(timeout=0.25)
                if self._workspace_token != token:
                    raise RuntimeError("Spectrum repository study changed during decode")
                if index in self._replays:
                    return self._replays[index]
                if index in self._errors:
                    raise RuntimeError(self._errors[index])
            self._inflight.add(index)
        try:
            candidate = self.candidate_mapping(package).get(index)
            if candidate is None:
                raise RuntimeError(f"No authoritative CPC Spectrum source for Sonication {index+1}.")
            replay = self.hydrophone.build_direct(
                candidate.fft_path, candidate.raw_path,
                progress_callback=progress_callback, include_vendor_validation=True,
            )
            if replay is None or not getattr(replay, "frames", None):
                raise RuntimeError(f"Spectrum decode returned zero frames for Sonication {index+1}.")
            replay = self._configure_replay(package, index, son, replay, candidate)
            with self._condition:
                if self._workspace_token == token:
                    self._replays[index] = replay
                    self._errors.pop(index, None)
            return replay
        except Exception as exc:
            with self._condition:
                if self._workspace_token == token:
                    self._errors[index] = str(exc)
            raise
        finally:
            with self._condition:
                self._inflight.discard(index)
                self._condition.notify_all()

    def standalone_analysis(self, package, index: int, son=None, progress_callback=None):
        token = self._ensure_workspace(package)
        index = int(index)
        with self._condition:
            if index in self._standalone:
                return self._standalone[index]
        replay = self.replay(package, index, son, progress_callback)
        analysis = self.standalone.analyze(replay, "Auto Evidence-First", 6.0)
        with self._condition:
            if self._workspace_token == token:
                self._standalone[index] = analysis
        return analysis

    def cached_replay(self, package, index: int):
        token = self._ensure_workspace(package)
        with self._condition:
            if self._workspace_token != token:
                return None
            return self._replays.get(int(index))
