from pathlib import Path
import numpy as np

from src.services.hydrophone_calibration_service import HydrophoneCalibrationService
from src.services.planning_data_service import PlanningDataService


def test_calibration_parses_and_applies_channel_factors(tmp_path: Path):
    ini = tmp_path / "Calibration.ini"
    ini.write_text("""
[SPECTRUM]
SpectrumFactor = 0.024 0.020 0.025 0.020 0.020 0.024 0.024 0.024
[HYDROPHONES_CALIBRATION]
SpectrumCoef = 2.0
""")
    response = tmp_path / "HydrophonesResponseCalibration.ini"
    response.write_text("""
[HYDROPHONES_RESPONSE_COEFFICIENTS]
FREQ0 = 0.0 1 1 1 1 1 1 1 1
FREQ1 = 1.0 2 3 4 5 6 7 8 9
""")
    calibration = HydrophoneCalibrationService().read(tmp_path)
    actual = calibration.apply(np.array([0.0, 1_000_000.0]), np.ones(2), 1)
    assert np.allclose(actual, [0.04, 0.12])


def test_planning_ct_xml_is_found_below_wrapper_directory(tmp_path: Path, monkeypatch):
    wrapper = tmp_path / "export"; wrapper.mkdir()
    (wrapper / "CtImage.xml").write_text("placeholder")
    son = wrapper / "Sonication1"; son.mkdir()
    raw = son / "16-1-0-0.raw"; raw.write_bytes(b"\x00" * (512 * 512 * 2))
    monkeypatch.setattr("src.parsers.ado_rowset.parse_ado_rowset", lambda _path: [{
        "fieldindex": 16, "sonicationindex": 1, "zoneindex": 0, "arrayindex": 0,
        "imagesize_x": 512, "imagesize_y": 512,
    }])
    assets = PlanningDataService()._ct_linked_raws(tmp_path)
    assert len(assets) == 1
    assert assets[0].path == raw
    assert assets[0].dtype == "<i2"


def test_main_window_no_longer_disables_cpc_path():
    text = Path("src/ui/main_window.py").read_text(encoding="utf-8")
    assert "if False and self.current" not in text
    assert "self.cpc_button.hide()" not in text
    assert "CPCFiles mapped" in text
    assert "CAL ON" in text


def test_initial_render_has_direct_deterministic_pass():
    text = Path("src/ui/main_window.py").read_text(encoding="utf-8")
    assert "self._render_replay_selection(self.replay_context.selection)" in text
