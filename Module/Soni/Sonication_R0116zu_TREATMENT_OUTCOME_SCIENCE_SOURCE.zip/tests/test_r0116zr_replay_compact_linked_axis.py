from pathlib import Path


def _source():
    return Path("src/ui/main_window.py").read_text(encoding="utf-8")

def test_power_score_x_axis_links_temperature():
    s=_source()
    assert "self.acoustic_control_plot.setXLink(self.temperature_plot)" in s
    block=s[s.index("def _update_acoustic_replay_view"):s.index("def _ensure_acoustic_curve_items")]
    assert "full_axis_end" in block
    assert "float(current_s)" not in block.split("axis_end =",1)[-1]

def test_registration_controls_are_vertical_stack():
    s=_source()
    assert "self.image_action_stack = QWidget()" in s
    assert "image_action_layout.addWidget(self.registration_toggle_btn)" in s
    assert "image_action_layout.addWidget(self.registration_trace_btn)" in s
    assert "image_action_layout.addWidget(self.load_images_toggle)" in s

def test_right_sections_and_chart_panels_are_collapsible():
    s=_source()
    for name in ("right_images_section","right_trends_section","right_analysis_section"):
        assert name in s
    assert "def _collapsible_section" in s
    chart=s[s.index("def _chart_panel"):s.index("def _make_image_strip")]
    assert "Collapse / show this chart" in chart
    assert "body.setVisible(bool(checked))" in chart
