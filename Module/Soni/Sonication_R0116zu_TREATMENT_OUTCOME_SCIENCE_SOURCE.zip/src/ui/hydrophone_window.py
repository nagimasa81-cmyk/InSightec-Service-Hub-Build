from __future__ import annotations

from pathlib import Path
import time

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import Qt, Signal, QTimer, QRectF, QEvent, QPointF, QObject, QThread
from PySide6.QtGui import QBrush, QColor, QShortcut, QKeySequence
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QGridLayout, QHBoxLayout,
    QHeaderView, QLabel, QPushButton, QSlider, QSpinBox, QTabWidget,
    QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget, QFileDialog,
    QMessageBox, QAbstractItemView, QSizePolicy, QApplication, QProgressBar, QScrollArea
)

from src.services.hydrophone_replay_service import HydrophoneReplayService, CpcHydrophoneReplay
from src.services.hydrophone_calibration_service import HydrophoneCalibrationService
from src.services.spectrum_dump_import_service import SpectrumDumpImportService, SpectrumDumpCandidate
from src.services.standalone_cavitation_service import StandaloneCavitationService
from src.services.cavitation_control_timeline_service import CavitationControlTimelineService
from src.services.acoustic_control_service import AcousticControlService
from src.services.cavitation_likelihood_service import CavitationLikelihoodService
from src.ui.i18n import tr, localize_qt_tree
from src.ui.progress_window import BusyProgressDialog


class SpectrumDecodeWorker(QObject):
    """Decode one CPC Spectrum pair off the GUI thread.

    The previous standalone Analyzer called HydrophoneReplayService.build_direct()
    synchronously from the Qt GUI thread. Large FFT containers therefore froze
    the event loop at the last painted value (typically 55%) and could not
    repaint progress or surface decode errors until the whole operation ended.
    """
    progress = Signal(int, int, str)
    ready = Signal(int, object)
    failed = Signal(int, str)

    def __init__(self, request_id: int, fft_path: Path | None, raw_path: Path | None):
        super().__init__()
        self.request_id = int(request_id)
        self.fft_path = Path(fft_path) if fft_path is not None else None
        self.raw_path = Path(raw_path) if raw_path is not None else None

    def run(self):
        try:
            service = HydrophoneReplayService()
            def relay(value: int, message: str):
                self.progress.emit(self.request_id, int(value), str(message))
            replay = service.build_direct(self.fft_path, self.raw_path, progress_callback=relay, include_vendor_validation=True)
            if replay is None or not getattr(replay, "frames", None):
                note = str(getattr(replay, "note", "") or "No decoded 8-channel FFT frames.")
                fft_name = self.fft_path.name if self.fft_path is not None else "none"
                raw_name = self.raw_path.name if self.raw_path is not None else "none"
                raise RuntimeError(f"Spectrum decode produced zero frames (FFT={fft_name}, RAW={raw_name}). {note}")
            self.ready.emit(self.request_id, replay)
        except Exception as exc:
            self.failed.emit(self.request_id, f"{type(exc).__name__}: {exc}")


class SpectrumDumpPickerDialog(QDialog):
    """Choose one logical Spectrum measurement after ZIP/folder discovery."""
    def __init__(self, candidates: list[SpectrumDumpCandidate], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Select Spectrum dump")
        self.resize(980, 520)
        self.candidates = candidates
        layout = QVBoxLayout(self)
        info = QLabel(
            "Compatible Spectrum dumps were found. Select one measurement. "
            "RAW and _FFT companions are paired automatically when both are present."
        )
        info.setWordWrap(True); layout.addWidget(info)
        self.table = QTableWidget(len(candidates), 5)
        self.table.setHorizontalHeaderLabels(["Type", "File / measurement", "Available", "Location", "Size"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        for row, candidate in enumerate(candidates):
            size = sum(p.stat().st_size for p in (candidate.raw_path, candidate.fft_path) if p is not None and p.exists())
            values = [candidate.family, candidate.label, candidate.completeness, candidate.relative_path, f"{size/1024:.1f} KB"]
            for col, value in enumerate(values): self.table.setItem(row, col, QTableWidgetItem(str(value)))
        if candidates: self.table.selectRow(0)
        self.table.doubleClicked.connect(lambda _: self.accept())
        layout.addWidget(self.table, 1)
        buttons = QHBoxLayout(); buttons.addStretch(1)
        cancel = QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        use = QPushButton("Open selected"); use.setDefault(True); use.clicked.connect(self.accept)
        buttons.addWidget(cancel); buttons.addWidget(use); layout.addLayout(buttons)

    def selected_candidate(self) -> SpectrumDumpCandidate | None:
        row = self.table.currentRow()
        return self.candidates[row] if 0 <= row < len(self.candidates) else None


class EightHydrophoneWindow(QDialog):
    sonicationRequested = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.language = str(getattr(parent, "language", "en") or "en")
        self.setWindowTitle("CPC Spectrum / 8CH Hydrophone Analyzer — R0044")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinMaxButtonsHint)
        # R0116zs: the analyzer must always be usable on laptop displays.  The
        # scroll shell below isolates the dialog geometry from large child
        # minimumSizeHints, so toggles/list selections cannot make the top-level
        # window grow beyond the available desktop.
        self.resize(1280, 780)
        self.setMinimumSize(720, 480)
        self._screen_fit_done = False
        self.service = HydrophoneReplayService()
        self.dump_importer = SpectrumDumpImportService()
        self.standalone_cavitation_service = StandaloneCavitationService()
        self.control_timeline_service = CavitationControlTimelineService()
        self.likelihood_service = CavitationLikelihoodService()
        self.dump_source = None
        self.package = None
        self._loaded_sonication_index = None
        self.source_entries = []
        self._preloaded_replays = {}
        self._awaiting_background_preload = False
        self.replay: CpcHydrophoneReplay | None = None
        self.frame_index = 0
        self.timer = QTimer(self)
        self.cavitation_analysis = None
        self.observed_cavitation_timeline = None
        self.cavitation_likelihood = None
        self._view_change_guard = False
        self._event_navigation_in_progress = False
        self._selected_observed_event_index = None
        self._last_dynamic_frame_index = -1
        self.timer.timeout.connect(lambda: self.set_frame(self.frame_index + 1))
        self._decode_thread = None
        self._decode_worker = None
        self._decode_request_id = 0
        self._decode_context = None
        self._decode_started_monotonic = None
        self._decode_last_progress = 0
        self._decode_last_message = ""
        self._decode_heartbeat = QTimer(self)
        self._decode_heartbeat.setInterval(1000)
        self._decode_heartbeat.timeout.connect(self._update_decode_heartbeat)

        import_row = QHBoxLayout()
        self.open_loaded_export_btn = QPushButton("Select From Loaded Export")
        self.open_export_zip_btn = QPushButton("Open Export ZIP")
        self.open_dump_folder_btn = QPushButton("Open Folder")
        self.open_dump_file_btn = QPushButton("Open Spectrum File")
        self.analysis_mode_combo = QComboBox()
        self.analysis_mode_combo.addItems(["Auto Evidence-First", "SpectrumDumps Only", "Vendor Rule + Dump"])
        self.analysis_mode_combo.setToolTip("SpectrumDumps Only never requires the treatment Export. Vendor actions are shown only when the matching INI is available.")
        self.candidate_z = QDoubleSpinBox(); self.candidate_z.setRange(2.0, 20.0); self.candidate_z.setDecimals(1); self.candidate_z.setValue(6.0); self.candidate_z.setSuffix(" σ")
        self.analysis_mode_combo.currentIndexChanged.connect(self._refresh_cavitation_analysis)
        self.candidate_z.valueChanged.connect(self._refresh_cavitation_analysis)
        self.open_loaded_export_btn.clicked.connect(self._open_loaded_export)
        self.open_export_zip_btn.clicked.connect(self._open_export_zip)
        self.open_dump_folder_btn.clicked.connect(self._open_dump_folder)
        self.open_dump_file_btn.clicked.connect(self._open_dump_file)
        self.open_loaded_export_btn.setEnabled(False)
        self.open_loaded_export_btn.setToolTip("Choose a Spectrum dump already extracted from the Export loaded in Sonication Analysis")
        import_row.addWidget(self.open_loaded_export_btn)
        import_row.addWidget(self.open_export_zip_btn); import_row.addWidget(self.open_dump_folder_btn); import_row.addWidget(self.open_dump_file_btn)
        import_row.addWidget(QLabel("Cavitation mode")); import_row.addWidget(self.analysis_mode_combo)
        import_row.addWidget(QLabel("Candidate threshold")); import_row.addWidget(self.candidate_z)
        import_row.addStretch(1)

        self.subwindow_progress_label = QLabel("Ready")
        self._exclusive_progress = BusyProgressDialog(self)
        self.subwindow_progress_bar = QProgressBar()
        self.subwindow_progress_bar.setRange(0, 100)
        self.subwindow_progress_bar.setValue(0)
        self.subwindow_progress_bar.setMaximumWidth(260)
        self.subwindow_progress_bar.setTextVisible(True)
        self.subwindow_progress_bar.setVisible(False)
        self.subwindow_progress_label.setVisible(False)

        top = QHBoxLayout()
        self.sonication_combo = QComboBox()
        self.sonication_combo.setMinimumWidth(260)
        self.sonication_combo.setMaximumWidth(380)
        self.sonication_combo.setMinimumContentsLength(24)
        self.sonication_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.sonication_combo.view().setMinimumWidth(520)
        self.sonication_combo.view().setMaximumWidth(760)
        self.sonication_combo.view().setTextElideMode(Qt.TextElideMode.ElideNone)
        self.sonication_combo.setToolTip("Select Sonication or SpectrumDumps source. Popup shows the full source name.")
        self.sonication_combo.currentIndexChanged.connect(self._sonication_changed)
        self.channel_spin = QSpinBox(); self.channel_spin.setRange(0, 7)
        self.channel_spin.setPrefix("RCV")
        self.channel_spin.setToolTip("Receiver selector used by Selected receiver views and exact FFT snapshot readouts (RCV0–RCV7).")
        self.channel_spin.valueChanged.connect(self._refresh_all)
        self.source_label = QLabel("No CPC source loaded")
        self.source_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.source_details_btn = QPushButton("Source details")
        self.source_details_btn.setCheckable(True)
        self.source_details_btn.setChecked(False)
        top.addWidget(QLabel("Sonication")); top.addWidget(self.sonication_combo)
        top.addWidget(QLabel("Receiver")); top.addWidget(self.channel_spin)
        self.show_disabled_receivers_check=QCheckBox("Show disabled RCV")
        self.show_disabled_receivers_check.setChecked(False)
        self.show_disabled_receivers_check.setToolTip("calibration.ini IsEnabled=0 receivers are hidden by default")
        self.show_disabled_receivers_check.toggled.connect(self._disabled_receiver_visibility_changed)
        top.addWidget(self.show_disabled_receivers_check)
        top.addWidget(self.source_label, 1)
        top.addWidget(self.source_details_btn)

        self.note = QLabel("No data")
        self.note.setWordWrap(True)
        self.note.setVisible(False)
        self.note.setMaximumHeight(96)
        self.source_details_btn.toggled.connect(self.note.setVisible)

        self.tabs = QTabWidget()
        self.raw_tab = self._build_raw_tab()
        self.spectrum_tab = self._build_spectrum_tab()
        self.spectrogram_tab = self._build_spectrogram_tab()
        self.band_tab = self._build_band_tab()
        self.vendor_cavitation_tab = self._build_vendor_cavitation_tab()
        self.cavitation_events_tab = self._build_cavitation_events_tab()
        self.navigator_tab = self._build_navigator_tab()
        self.tabs.addTab(self.raw_tab, "Measurement Timeline / Raw A/D")
        self.tabs.addTab(self.spectrum_tab, "Spectrum")
        self.tabs.addTab(self.spectrogram_tab, "Spectrogram")
        self.tabs.addTab(self.band_tab, "Band Energy")
        self.tabs.addTab(self.vendor_cavitation_tab, "CGA Cavitation / Vendor Rules")
        self.tabs.addTab(self.cavitation_events_tab, "Cavitation Events")
        self.tabs.addTab(self.navigator_tab, "Measure / Statistics")
        self.tabs.currentChanged.connect(self._analyzer_tab_changed)
        self._vendor_layout_token = None

        controls = QHBoxLayout()
        self.first_btn = QPushButton("|◀")
        self.prev_btn = QPushButton("◀")
        self.play_btn = QPushButton("▶")
        self.next_btn = QPushButton("▶")
        self.last_btn = QPushButton("▶|")
        self.first_btn.clicked.connect(lambda: self.set_frame(0))
        self.prev_btn.clicked.connect(lambda: self.set_frame(self.frame_index - 1))
        self.next_btn.clicked.connect(lambda: self.set_frame(self.frame_index + 1))
        self.last_btn.clicked.connect(lambda: self.set_frame(len(self.replay.frames)-1 if self.replay else 0))
        self.play_btn.clicked.connect(self._toggle_play)
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.valueChanged.connect(self.set_frame)
        self.measure_spin = QSpinBox(); self.measure_spin.setRange(1, 1)
        self.measure_spin.valueChanged.connect(lambda v: self.set_frame(v - 1))
        self.frame_label = QLabel("Measure - / - · Time -")
        controls.addWidget(self.first_btn); controls.addWidget(self.prev_btn)
        controls.addWidget(self.play_btn); controls.addWidget(self.next_btn); controls.addWidget(self.last_btn)
        controls.addWidget(self.slider, 1)
        controls.addWidget(QLabel("Measure #")); controls.addWidget(self.measure_spin)
        controls.addWidget(self.frame_label)

        # R0116zs: put the complete analyzer UI inside a scroll shell.  This is
        # deliberate: QTabWidget/table/plot minimum hints used to propagate to
        # the QDialog, so checking a legend item or selecting a long source could
        # silently enlarge the entire window.  Now only the interior scrolls.
        content = QWidget(self)
        content.setMinimumSize(0, 0)
        layout = QVBoxLayout(content)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.addLayout(import_row)
        progress_row = QHBoxLayout(); progress_row.addWidget(self.subwindow_progress_label); progress_row.addWidget(self.subwindow_progress_bar); progress_row.addStretch(1)
        layout.addLayout(progress_row)
        layout.addLayout(top)
        layout.addWidget(self.note)
        layout.addWidget(self.tabs, 1)
        layout.addLayout(controls)

        self._main_scroll = QScrollArea(self)
        self._main_scroll.setWidgetResizable(True)
        self._main_scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        self._main_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self._main_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self._main_scroll.setWidget(content)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(self._main_scroll)
        self.setAcceptDrops(True)
        self._install_navigation_shortcuts()
        self._install_table_readability()
        QApplication.instance().installEventFilter(self)
        self._stable_window_geometry = None

    def _install_table_readability(self):
        """Make long event/evidence cells inspectable in the Spectrum Dump Analyzer."""
        for table in self.findChildren(QTableWidget):
            table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
            table.setTextElideMode(Qt.TextElideMode.ElideRight)
            table.setWordWrap(False)
            table.cellEntered.connect(lambda row,col,t=table: self._table_cell_hovered(t,row,col))
            table.cellDoubleClicked.connect(lambda row,col,t=table: self._show_table_cell_detail(t,row,col))

    @staticmethod
    def _table_cell_hovered(table, row, column):
        item=table.item(int(row),int(column))
        if item is not None and item.text(): item.setToolTip(item.text())

    def _show_table_cell_detail(self, table, row, column):
        item=table.item(int(row),int(column))
        if item is None or not item.text(): return
        dlg=QDialog(self); header=table.horizontalHeaderItem(int(column))
        dlg.setWindowTitle(header.text() if header is not None else "Detail"); dlg.resize(760,420)
        lay=QVBoxLayout(dlg); edit=QTextEdit(); edit.setReadOnly(True); edit.setPlainText(item.text()); edit.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth); lay.addWidget(edit,1)
        close=QPushButton("Close"); close.clicked.connect(dlg.accept); rowlay=QHBoxLayout(); rowlay.addStretch(1); rowlay.addWidget(close); lay.addLayout(rowlay); dlg.exec()

    def _install_navigation_shortcuts(self):
        self._nav_shortcuts = []
        for key, delta in ((Qt.Key.Key_Left, -1), (Qt.Key.Key_Up, -1), (Qt.Key.Key_Right, 1), (Qt.Key.Key_Down, 1)):
            shortcut = QShortcut(QKeySequence(key), self)
            shortcut.setContext(Qt.ShortcutContext.WindowShortcut)
            shortcut.activated.connect(lambda d=delta: self.set_frame(self.frame_index + d))
            self._nav_shortcuts.append(shortcut)
        first = QShortcut(QKeySequence(Qt.Key.Key_Home), self); first.setContext(Qt.ShortcutContext.WindowShortcut); first.activated.connect(lambda: self.set_frame(0)); self._nav_shortcuts.append(first)
        last = QShortcut(QKeySequence(Qt.Key.Key_End), self); last.setContext(Qt.ShortcutContext.WindowShortcut); last.activated.connect(lambda: self.set_frame(len(self.replay.frames)-1 if self.replay else 0)); self._nav_shortcuts.append(last)

    def eventFilter(self, obj, event):
        if event.type() == QEvent.Type.KeyPress:
            active = QApplication.activeWindow()
            belongs = active is self or (active is not None and self.isAncestorOf(active))
            if belongs and event.modifiers() == Qt.KeyboardModifier.NoModifier:
                key = event.key()
                if key in (Qt.Key.Key_Up, Qt.Key.Key_Left):
                    self.set_frame(self.frame_index - 1); event.accept(); return True
                if key in (Qt.Key.Key_Down, Qt.Key.Key_Right):
                    self.set_frame(self.frame_index + 1); event.accept(); return True
                if key == Qt.Key.Key_Home:
                    self.set_frame(0); event.accept(); return True
                if key == Qt.Key.Key_End:
                    self.set_frame(len(self.replay.frames)-1 if self.replay else 0); event.accept(); return True
        return super().eventFilter(obj, event)

    def _plot(self, bottom: str, left: str) -> pg.PlotWidget:
        plot = pg.PlotWidget()
        plot.showGrid(x=True, y=True, alpha=.25)
        plot.setLabel("bottom", bottom)
        plot.setLabel("left", left)
        return plot

    def _build_raw_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout()
        self.raw_mode = QComboBox(); self.raw_mode.addItems(["Overlay 8CH", "Single CH", "8 Panels"])
        self.raw_mode.currentIndexChanged.connect(self._rebuild_raw_plots)
        self.raw_scale = QComboBox(); self.raw_scale.addItems(["Auto", "Common symmetric"])
        self.raw_scale.currentIndexChanged.connect(self._draw_raw)
        row.addWidget(QLabel("Display")); row.addWidget(self.raw_mode)
        row.addWidget(QLabel("Y scale")); row.addWidget(self.raw_scale); row.addStretch(1)
        layout.addLayout(row)
        self.raw_host = QWidget(); self.raw_layout = QGridLayout(self.raw_host); self.raw_layout.setContentsMargins(0,0,0,0)
        layout.addWidget(self.raw_host, 1)
        self.raw_plots: list[pg.PlotWidget] = []
        self._rebuild_raw_plots()
        return page

    def _build_spectrum_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout()
        self.spectrum_mode = QComboBox(); self.spectrum_mode.addItems(["Overlay 8CH", "Single CH", "8 Panels"])
        self.spectrum_mode.currentIndexChanged.connect(self._rebuild_spectrum_plots)
        self.spectrum_value_mode = QComboBox()
        self.spectrum_value_mode.addItems(["Calibrated absolute", "Raw absolute", "Raw + calibrated", "Relative dB"])
        self.spectrum_value_mode.currentIndexChanged.connect(self._draw_spectrum)
        self.db_floor = QSpinBox(); self.db_floor.setRange(-180, -20); self.db_floor.setValue(-100)
        self.db_floor.valueChanged.connect(self._draw_spectrum)
        row.addWidget(QLabel("Display")); row.addWidget(self.spectrum_mode)
        row.addWidget(QLabel("Values")); row.addWidget(self.spectrum_value_mode)
        row.addWidget(QLabel("Floor")); row.addWidget(self.db_floor); row.addWidget(QLabel("dB")); row.addStretch(1)
        layout.addLayout(row)
        self.spectrum_host = QWidget(); self.spectrum_layout = QGridLayout(self.spectrum_host); self.spectrum_layout.setContentsMargins(0,0,0,0)
        layout.addWidget(self.spectrum_host, 1)
        self.spectrum_plots: list[pg.PlotWidget] = []
        self._rebuild_spectrum_plots()
        return page

    def _build_spectrogram_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout()
        self.spec_min = QDoubleSpinBox(); self.spec_min.setRange(0.0, 10.0); self.spec_min.setDecimals(3); self.spec_min.setValue(0.20); self.spec_min.setSuffix(" MHz")
        self.spec_max = QDoubleSpinBox(); self.spec_max.setRange(0.0, 10.0); self.spec_max.setDecimals(3); self.spec_max.setValue(1.00); self.spec_max.setSuffix(" MHz")
        self.spec_min.valueChanged.connect(self._draw_spectrogram); self.spec_max.valueChanged.connect(self._draw_spectrogram)
        row.addWidget(QLabel("Frequency range")); row.addWidget(self.spec_min); row.addWidget(QLabel("to")); row.addWidget(self.spec_max); row.addStretch(1)
        layout.addLayout(row)
        self.spectrogram_plot = pg.PlotWidget()
        self.spectrogram_plot.setLabel("bottom", "Time", "s")
        self.spectrogram_plot.setLabel("left", "Frequency", "MHz")
        self.spectrogram_image = pg.ImageItem(axisOrder="row-major")
        self.spectrogram_plot.addItem(self.spectrogram_image)
        self.spectrogram_plot.setMouseEnabled(x=True, y=True)
        layout.addWidget(self.spectrogram_plot, 1)
        return page

    def _build_band_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        controls = QGridLayout()
        self.band_enabled: list[QCheckBox] = []
        self.band_low: list[QDoubleSpinBox] = []
        self.band_high: list[QDoubleSpinBox] = []
        for i, (low, high) in enumerate(self.service.DEFAULT_BANDS_MHZ):
            enabled = QCheckBox(f"Band {i}"); enabled.setChecked(i == 0)
            lo = QDoubleSpinBox(); lo.setRange(0.0, 10.0); lo.setDecimals(3); lo.setValue(low); lo.setSuffix(" MHz")
            hi = QDoubleSpinBox(); hi.setRange(0.0, 10.0); hi.setDecimals(3); hi.setValue(high); hi.setSuffix(" MHz")
            enabled.toggled.connect(self._draw_band_energy); lo.valueChanged.connect(self._draw_band_energy); hi.valueChanged.connect(self._draw_band_energy)
            controls.addWidget(enabled, i//3, (i%3)*3)
            controls.addWidget(lo, i//3, (i%3)*3+1)
            controls.addWidget(hi, i//3, (i%3)*3+2)
            self.band_enabled.append(enabled); self.band_low.append(lo); self.band_high.append(hi)
        layout.addLayout(controls)
        self.band_plot = self._plot("Time (s)", "Relative band energy (dB)")
        layout.addWidget(self.band_plot, 1)
        return page

    def _build_vendor_cavitation_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)

        # R0042: charts are the primary view. Rule/configuration text and tables
        # are available on demand but are collapsed by default so they cannot
        # consume the chart area on 1080p/laptop displays.
        detail_row = QHBoxLayout()
        self.vendor_details_btn = QPushButton("Show rule / band details")
        self.vendor_details_btn.setCheckable(True)
        self.vendor_details_btn.setChecked(False)
        detail_row.addWidget(self.vendor_details_btn)
        self.vendor_why_popup_check = QCheckBox("Why popup")
        self.vendor_why_popup_check.setChecked(False)
        self.vendor_why_popup_check.setToolTip(
            "OFF by default. Turn ON, then click an event marker/point on the Vendor or Control chart to show Why/evidence."
        )
        detail_row.addWidget(self.vendor_why_popup_check)
        self.vendor_why_popup_hint = QLabel("Why popup: OFF")
        self.vendor_why_popup_hint.setStyleSheet("QLabel { color: #6c757d; }")
        detail_row.addWidget(self.vendor_why_popup_hint)
        self.vendor_why_popup_check.toggled.connect(
            lambda checked: self.vendor_why_popup_hint.setText("Why popup: ON · click an event point" if checked else "Why popup: OFF")
        )
        detail_row.addStretch(1)
        layout.addLayout(detail_row)

        view_row = QHBoxLayout()
        self.vendor_view_combo = QComboBox()
        self.vendor_view_combo.addItems(["All 8 receivers", "Control overview", "Selected receiver"])
        self.vendor_view_combo.setCurrentText("All 8 receivers")
        self.vendor_view_combo.setToolTip("Default shows the full measurement. Use Control overview to emphasize combined rule inputs, or Selected receiver for one RCV.")
        self.vendor_view_combo.currentIndexChanged.connect(self._draw_vendor_cavitation)
        self.vendor_smooth_check = QCheckBox("Smooth 100 ms")
        self.vendor_smooth_check.setChecked(True)
        self.vendor_smooth_check.setToolTip("Display-only moving average. Exact points and calculations are unchanged.")
        self.vendor_smooth_check.toggled.connect(self._draw_vendor_cavitation)
        self.vendor_cursor_check = QCheckBox("Sync cursor")
        self.vendor_cursor_check.setChecked(True)
        self.vendor_cursor_check.toggled.connect(self._draw_vendor_cavitation)
        self.vendor_receiver_combo = QComboBox()
        self.vendor_receiver_combo.addItems([f"RCV{i}" for i in range(8)])
        self.vendor_receiver_combo.setCurrentIndex(int(self.channel_spin.value()))
        self.vendor_receiver_combo.setToolTip("Receiver used when View = Selected receiver.")
        self.vendor_receiver_combo.currentIndexChanged.connect(lambda i: self.channel_spin.setValue(int(i)))
        self.channel_spin.valueChanged.connect(lambda i: self.vendor_receiver_combo.setCurrentIndex(int(i)) if self.vendor_receiver_combo.currentIndex()!=int(i) else None)
        self.vendor_view_combo.currentTextChanged.connect(lambda text: self.vendor_receiver_combo.setEnabled(text == "Selected receiver"))
        self.vendor_receiver_combo.setEnabled(False)
        self.vendor_lower_mode_combo = QComboBox()
        self.vendor_lower_mode_combo.addItems(["Both", "Control response", "CGA Display Rule"])
        self.vendor_lower_mode_combo.setCurrentText("Both")
        self.vendor_lower_mode_combo.setToolTip("Lower chart: show power/control response, CGA display rules, or both with independent left/right Y axes.")
        self.vendor_lower_mode_combo.currentIndexChanged.connect(self._draw_vendor_cavitation)
        view_row.addWidget(QLabel("View")); view_row.addWidget(self.vendor_view_combo)
        view_row.addWidget(QLabel("Receiver")); view_row.addWidget(self.vendor_receiver_combo)
        view_row.addWidget(QLabel("Lower chart")); view_row.addWidget(self.vendor_lower_mode_combo)
        view_row.addWidget(self.vendor_smooth_check); view_row.addWidget(self.vendor_cursor_check)
        self.vendor_legend_check = QCheckBox("Legend")
        self.vendor_legend_check.setChecked(True)
        self.vendor_legend_check.setToolTip("Show/hide the chart line and marker explanation.")
        view_row.addWidget(self.vendor_legend_check)
        self.vendor_legend_all_on_btn = QPushButton("All ON")
        self.vendor_legend_all_on_btn.setToolTip("Enable every Legend series.")
        self.vendor_legend_all_clear_btn = QPushButton("All Clear")
        self.vendor_legend_all_clear_btn.setToolTip("Disable every Legend series.")
        view_row.addWidget(self.vendor_legend_all_on_btn)
        view_row.addWidget(self.vendor_legend_all_clear_btn)
        view_row.addStretch(1)
        layout.addLayout(view_row)
        self.vendor_legend_host = QWidget()
        self.vendor_legend_host.setStyleSheet("QWidget { background: #f4f6f8; border: 1px solid #c7ccd1; } QLabel { border: none; background: transparent; }")
        legend_grid = QGridLayout(self.vendor_legend_host)
        legend_grid.setContentsMargins(6, 3, 6, 3); legend_grid.setHorizontalSpacing(12); legend_grid.setVerticalSpacing(2)
        legend_items = [
            ("weighted_b0", "━", "#d8d8d8", "Weighted B0"),
            ("band1", "━", "#22c7d6", "Band1"),
            ("band2", "●", "#ff5c9a", "Band2 event"),
            ("increase_limit", "┄", "#e6c84a", "Increase limit"),
            ("actual_power", "━", "#ffffff", "Actual power (Workstation)"),
            ("reconstructed", "┄", "#28c98b", "Reconstructed"),
            ("rule1", "━", "#60cf72", "CGA Rule 1"),
            ("rule2", "━", "#39c5d5", "CGA Rule 2"),
            ("rule_threshold", "┄", "#e6c84a", "Rule threshold"),
            ("current_time", "│", "#ffffff", "Current time"),
            ("rcv0", "━", "#e6194b", "RCV0 curve"),
            ("rcv1", "━", "#3cb44b", "RCV1 curve"),
            ("rcv2", "━", "#ffe119", "RCV2 curve"),
            ("rcv3", "━", "#4363d8", "RCV3 curve"),
            ("rcv4", "━", "#f58231", "RCV4 curve"),
            ("rcv5", "━", "#911eb4", "RCV5 curve"),
            ("rcv6", "━", "#42d4f4", "RCV6 curve"),
            ("rcv7", "━", "#f032e6", "RCV7 curve"),
            ("snapshot_b0", "●", "#ffffff", "Band0 exact FFT snapshots"),
            ("snapshot_b1", "▲", "#60cf72", "Band1 exact FFT snapshots"),
            ("snapshot_b2", "■", "#ff5c5c", "Band2 exact FFT snapshots"),
            ("snapshot_b3", "◆", "#f4a261", "Band3 exact FFT snapshots"),
        ]
        self.vendor_series_checks = {}
        self.vendor_series_cells = {}
        for i, (key, symbol, color, desc) in enumerate(legend_items):
            cell = QWidget(); row = QHBoxLayout(cell); row.setContentsMargins(0,0,0,0); row.setSpacing(4)
            check = QCheckBox(); check.setChecked(True); check.setToolTip(f"Show/hide {desc} on the graph")
            check.toggled.connect(lambda _checked, self=self: self._draw_vendor_cavitation(preserve_view=True))
            self.vendor_series_checks[key] = check
            self.vendor_series_cells[key] = cell
            icon = QLabel(symbol); icon.setFixedWidth(22); icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
            icon.setStyleSheet(f"QLabel {{ color: {color}; background: #26323b; font-weight: 700; font-size: 15px; border: none; }}")
            label = QLabel(desc)
            row.addWidget(check); row.addWidget(icon); row.addWidget(label)
            legend_grid.addWidget(cell, i // 6, i % 6)
        self.vendor_legend_host.setMaximumHeight(136)
        self.vendor_legend_all_on_btn.clicked.connect(lambda: self._set_all_vendor_legend_series(True))
        self.vendor_legend_all_clear_btn.clicked.connect(lambda: self._set_all_vendor_legend_series(False))
        # Compatibility alias retained for older source-contract tests and plugins.
        self.vendor_legend_label = self.vendor_legend_host
        self.vendor_legend_check.toggled.connect(self.vendor_legend_label.setVisible)
        layout.addWidget(self.vendor_legend_host, 0)

        self.vendor_details_host = QWidget()
        details = QVBoxLayout(self.vendor_details_host)
        details.setContentsMargins(0, 0, 0, 0)
        details.setSpacing(3)

        self.vendor_profile_label = QLabel("Vendor cavitation rules are not loaded")
        self.vendor_profile_label.setWordWrap(True)
        self.vendor_profile_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.vendor_profile_label.setMaximumHeight(76)
        self.vendor_profile_label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Maximum)
        details.addWidget(self.vendor_profile_label, 0)

        tables_row = QHBoxLayout()
        tables_row.setSpacing(5)
        self.vendor_band_table = QTableWidget(4, 5)
        self.vendor_band_table.setHorizontalHeaderLabels(["Band", "Ratio × f0", "± Δ", "Frequency range", "Meaning / evidence"])
        self.vendor_band_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.vendor_band_table.verticalHeader().setVisible(False)
        self.vendor_band_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.vendor_band_table.setMaximumHeight(118)
        tables_row.addWidget(self.vendor_band_table, 1)

        self.vendor_control_table = QTableWidget(0, 6)
        self.vendor_control_table.setHorizontalHeaderLabels(["Family", "Rule", "Weighted input", "Threshold", "Action / persistence", "Runtime evidence"])
        self.vendor_control_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.vendor_control_table.verticalHeader().setVisible(False)
        self.vendor_control_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.vendor_control_table.setMaximumHeight(118)
        tables_row.addWidget(self.vendor_control_table, 1)
        details.addLayout(tables_row)
        self.vendor_details_host.setVisible(False)
        self.vendor_details_btn.toggled.connect(self.vendor_details_host.setVisible)
        self.vendor_details_btn.toggled.connect(lambda checked: self.vendor_details_btn.setText("Hide rule / band details" if checked else "Show rule / band details"))
        layout.addWidget(self.vendor_details_host, 0)

        # Product-style chart hierarchy: band energy on top; power response and
        # CGA display rule share one lower time axis with independent Y scales.
        self.vendor_energy_plot = self._plot("MR acquisition time (s)", "Vendor energy")
        self.vendor_energy_plot.setTitle("Vendor band energy reproduction")
        self.vendor_energy_plot.setMinimumHeight(260)
        self.vendor_energy_plot.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        layout.addWidget(self.vendor_energy_plot, 1)

        self.vendor_power_plot = self._plot("MR acquisition time (s)", "Power ratio")
        # Fixed axis geometry prevents checkbox/list changes from resizing plots.
        self.vendor_power_plot.getAxis("left").setWidth(52)
        self.vendor_power_plot.getAxis("right").setWidth(52)
        self.vendor_power_plot.setTitle("Cavitation control response + CGA / Acquisition Display Rule")
        self.vendor_power_plot.setMinimumHeight(290)
        self.vendor_power_plot.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.vendor_power_plot.showAxis("right")
        self.vendor_power_plot.getAxis("right").setLabel("CGA Display Rule")
        self.vendor_rule_view = pg.ViewBox()
        self.vendor_power_plot.scene().addItem(self.vendor_rule_view)
        self.vendor_power_plot.getAxis("right").linkToView(self.vendor_rule_view)
        self.vendor_rule_view.setXLink(self.vendor_power_plot.plotItem.vb)
        self.vendor_power_plot.plotItem.vb.sigResized.connect(self._sync_vendor_rule_view_geometry)
        self._sync_vendor_rule_view_geometry()
        # compatibility alias for chart-click/range code; rule curves themselves
        # are added to vendor_rule_view, not to this PlotWidget.
        self.vendor_rule_plot = self.vendor_power_plot
        layout.addWidget(self.vendor_power_plot, 1)
        for plot in (self.vendor_energy_plot, self.vendor_power_plot):
            plot.scene().sigMouseClicked.connect(lambda ev, owner=plot: self._vendor_chart_clicked(owner, ev))
        return page

    def _build_cavitation_events_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)

        details_row = QHBoxLayout()
        self.cavitation_details_btn = QPushButton("Show analysis details")
        self.cavitation_details_btn.setCheckable(True)
        self.cavitation_details_btn.setChecked(False)
        details_row.addWidget(self.cavitation_details_btn)
        details_row.addStretch(1)
        layout.addLayout(details_row)

        self.cavitation_details_panel = QWidget()
        details_layout = QVBoxLayout(self.cavitation_details_panel)
        details_layout.setContentsMargins(4, 0, 4, 4)
        details_layout.setSpacing(2)
        self.cavitation_evidence_label = QLabel(
            "SpectrumDumps-only analysis uses the embedded 8CH × 4-band energy table. "
            "Without CavitationSafetyAndControl.ini, detections are labelled Candidate and no vendor power/stop action is inferred."
        )
        self.cavitation_evidence_label.setWordWrap(True)
        self.cavitation_observed_label = QLabel("Observed cavitation-control timeline is not loaded yet.")
        self.cavitation_observed_label.setWordWrap(True)
        self.cavitation_likelihood_label = QLabel("Cavitation likelihood map not calculated yet.")
        self.cavitation_likelihood_label.setWordWrap(True)
        details_layout.addWidget(self.cavitation_evidence_label)
        details_layout.addWidget(self.cavitation_observed_label)
        details_layout.addWidget(self.cavitation_likelihood_label)
        self.cavitation_details_panel.setVisible(False)
        self.cavitation_details_panel.setMaximumHeight(170)
        self.cavitation_details_btn.toggled.connect(self.cavitation_details_panel.setVisible)
        layout.addWidget(self.cavitation_details_panel)

        # Keep the three visual tasks separate so no plot can be squeezed to a few pixels
        # on a laptop display. Tables remain available below their associated plot.
        self.cavitation_visual_tabs = QTabWidget()
        layout.addWidget(self.cavitation_visual_tabs, 1)

        # 1) Control timeline
        timeline_page = QWidget()
        timeline_layout = QVBoxLayout(timeline_page)
        timeline_layout.setContentsMargins(2, 2, 2, 2)
        timeline_layout.setSpacing(4)
        self.cavitation_analysis_summary = QLabel("Cavitation analysis: waiting")
        self.cavitation_analysis_summary.setWordWrap(True)
        self.cavitation_analysis_summary.setObjectName("CurrentValue")
        timeline_layout.addWidget(self.cavitation_analysis_summary)

        self.cavitation_control_plot = self._plot("MR acquisition time (s)", "Power ratio / event")
        self.cavitation_control_plot.setTitle("Cavitation control timeline — observed actions and power response")
        self.cavitation_control_plot.addLegend(offset=(8, 8))
        self.cavitation_control_plot.setMinimumHeight(340)
        self.cavitation_control_plot.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        # R0116o: this connection was missing, leaving Control Timeline visibly
        # populated but inert.  Keep one click handler for event selection/Why.
        self.cavitation_control_plot.scene().sigMouseClicked.connect(self._cavitation_control_plot_clicked)
        self._control_replay_cursor = None
        timeline_layout.addWidget(self.cavitation_control_plot, 3)
        event_filter_row = QHBoxLayout()
        event_filter_row.addWidget(QLabel("Event list"))
        self.control_why_popup_check = QCheckBox("Why popup")
        self.control_why_popup_check.setChecked(False)
        self.control_why_popup_check.setToolTip(
            "OFF by default. When ON, clicking a Control Timeline event marker or Event list row always shows the exact Why/evidence popup."
        )
        event_filter_row.addWidget(self.control_why_popup_check)

        self.show_increase_events_check = QCheckBox("Show Increase events")
        self.show_increase_events_check.setChecked(False)
        self.show_increase_events_check.setToolTip("Increase events are hidden from both the chart and event list by default. Enable only for Increase-rule review.")
        self.show_increase_events_check.toggled.connect(self._draw_observed_cavitation_timeline)
        event_filter_row.addWidget(self.show_increase_events_check)

        self.show_preirradiation_events_check = QCheckBox("Show pre-irradiation control")
        self.show_preirradiation_events_check.setChecked(True)
        self.show_preirradiation_events_check.setToolTip(
            "Shows Acquisition_Brain rule evaluations before ExciterPower becomes positive. "
            "They are real control events but are not counted as treatment cavitation."
        )
        self.show_preirradiation_events_check.toggled.connect(self._draw_observed_cavitation_timeline)
        event_filter_row.addWidget(self.show_preirradiation_events_check)

        self.sync_replay_to_event_check = QCheckBox("Sync replay to selected event")
        self.sync_replay_to_event_check.setChecked(False)
        self.sync_replay_to_event_check.setToolTip(
            "OFF: red selected-event cursor and white replay cursor remain independent. "
            "ON: selecting an event also jumps replay to the nearest FFT snapshot."
        )
        event_filter_row.addWidget(self.sync_replay_to_event_check)

        self.cavitation_lock_view_check=QCheckBox("Lock plot view")
        self.cavitation_lock_view_check.setChecked(True)
        self.cavitation_lock_view_check.setToolTip("Prevents accidental wheel zoom / drag pan from changing the chart scale.")
        self.cavitation_lock_view_check.toggled.connect(self._apply_cavitation_view_lock)
        event_filter_row.addWidget(self.cavitation_lock_view_check)

        self.cavitation_reset_view_btn=QPushButton("Reset view")
        self.cavitation_reset_view_btn.clicked.connect(self._reset_cavitation_views)
        event_filter_row.addWidget(self.cavitation_reset_view_btn)
        event_filter_row.addStretch(1)
        timeline_layout.addLayout(event_filter_row)
        self.cavitation_observed_table = QTableWidget(0, 12)
        self.cavitation_observed_table.setHorizontalHeaderLabels(["Time", "Cycle", "Rule", "Irradiation phase", "State", "Weighted", "Threshold", "Dominant", "Contributors", "Power", "Result", "Evidence"])
        self.cavitation_observed_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.cavitation_observed_table.horizontalHeader().setStretchLastSection(True)
        for col,width in enumerate((90,70,100,135,100,95,120,115,230,105,190,135)):
            self.cavitation_observed_table.setColumnWidth(col,width)
        self.cavitation_observed_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.cavitation_observed_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.cavitation_observed_table.cellClicked.connect(self._observed_cavitation_event_selected)
        self.cavitation_observed_table.itemSelectionChanged.connect(self._update_cavitation_likelihood)
        self.cavitation_observed_table.setMinimumHeight(175)
        self.cavitation_observed_table.setMaximumHeight(270)
        timeline_layout.addWidget(self.cavitation_observed_table, 1)
        self.cavitation_visual_tabs.addTab(timeline_page, "Control Timeline")

        # 2) Location likelihood
        location_page = QWidget()
        location_layout = QHBoxLayout(location_page)
        location_layout.setContentsMargins(2, 2, 2, 2)
        location_layout.setSpacing(4)
        location_controls = QHBoxLayout()
        location_controls.addWidget(QLabel("Replay speed"))
        self.probable_speed_combo = QComboBox()
        self.probable_speed_combo.addItems(["0.25×", "0.5×", "1× Actual", "2×", "4×", "8×"])
        self.probable_speed_combo.setCurrentText("1× Actual")
        self.probable_speed_combo.currentTextChanged.connect(self._probable_speed_changed)
        location_controls.addWidget(self.probable_speed_combo)
        location_controls.addStretch(1)
        location_layout.addLayout(location_controls)
        self.cavitation_likelihood_plot = pg.PlotWidget(title="Probable cavitation region from hydrophone contribution pattern")
        self.cavitation_likelihood_plot.setLabel("bottom", "RCV reference X")
        self.cavitation_likelihood_plot.setLabel("left", "RCV reference Y")
        self.cavitation_likelihood_plot.setAspectLocked(True)
        self.cavitation_likelihood_plot.setMinimumHeight(420)
        self.cavitation_likelihood_plot.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.cavitation_likelihood_image = pg.ImageItem(axisOrder="row-major")
        self.cavitation_likelihood_plot.addItem(self.cavitation_likelihood_image)
        self.cavitation_likelihood_plot.showGrid(x=True, y=True, alpha=0.25)
        location_layout.addWidget(self.cavitation_likelihood_plot, 4)
        self.cavitation_likelihood_table = QTableWidget(0, 4)
        self.cavitation_likelihood_table.setHorizontalHeaderLabels(["Receiver", "Family", "Contribution", "Role"])
        self.cavitation_likelihood_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.cavitation_likelihood_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.cavitation_likelihood_table.setMinimumWidth(310)
        self.cavitation_likelihood_table.setMaximumWidth(430)
        location_layout.addWidget(self.cavitation_likelihood_table, 1)
        self.cavitation_visual_tabs.addTab(location_page, "Probable Location")

        # 3) Hydrophone × Band activity
        activity_page = QWidget()
        activity_layout = QVBoxLayout(activity_page)
        activity_layout.setContentsMargins(2, 2, 2, 2)
        activity_layout.setSpacing(4)
        self.cavitation_heatmap_plot = pg.PlotWidget(title="Cavitation activity — Hydrophone × Band over FFT snapshots")
        self.cavitation_heatmap_plot.setLabel("bottom", "FFT snapshot")
        self.cavitation_heatmap_plot.setLabel("left", "CH/Band row")
        self.cavitation_heatmap_plot.setMinimumHeight(340)
        self.cavitation_heatmap_plot.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.cavitation_heatmap_image = pg.ImageItem(axisOrder="row-major")
        self.cavitation_heatmap_plot.addItem(self.cavitation_heatmap_image)
        self.cavitation_heatmap_cursor = pg.InfiniteLine(pos=0.0, angle=90, movable=False,
                                                         pen=pg.mkPen("#ffffff", width=1.5, style=Qt.PenStyle.DashLine))
        self.cavitation_heatmap_plot.addItem(self.cavitation_heatmap_cursor)
        activity_layout.addWidget(self.cavitation_heatmap_plot, 3)
        self.cavitation_heatmap_status = QLabel("FFT/Band link: waiting for replay")
        self.cavitation_heatmap_status.setWordWrap(True)
        activity_layout.addWidget(self.cavitation_heatmap_status)
        self.cavitation_event_table = QTableWidget(0, 10)
        self.cavitation_event_table.setHorizontalHeaderLabels(["Snapshot", "Cycle", "Time", "Hydrophone", "Band", "Energy", "Baseline/Limit", "Score", "Detection", "Processing / Result"])
        self.cavitation_event_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.cavitation_event_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.cavitation_event_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.cavitation_event_table.cellClicked.connect(self._cavitation_event_selected)
        self.cavitation_event_table.itemSelectionChanged.connect(self._update_cavitation_likelihood)
        self.cavitation_event_table.setMinimumHeight(120)
        self.cavitation_event_table.setMaximumHeight(210)
        activity_layout.addWidget(self.cavitation_event_table, 1)
        self.cavitation_visual_tabs.addTab(activity_page, "Hydrophone × Band")
        self._apply_cavitation_view_lock()
        return page

    def _cavitation_event_selected(self,row:int,_column:int):
        item=self.cavitation_event_table.item(row,0)
        if item is None: return
        try: self.set_frame(max(0,int(item.text())-1))
        except ValueError: pass

    def _observed_cavitation_event_selected(self,row:int,_column:int):
        visible = getattr(self, "_visible_observed_events", [])
        if self.observed_cavitation_timeline is None or not (0 <= row < len(visible)):
            return
        original_index, event = visible[row]
        self._selected_observed_event_index = int(original_index)
        self._probable_location_pinned_to_event=True
        if getattr(self, "control_why_popup_check", None) is not None and self.control_why_popup_check.isChecked():
            self._show_event_why_popup(event, force=True)
        else:
            self._highlight_why_event(event)
        self._update_cavitation_likelihood()
        if not self.replay or not (hasattr(self, "sync_replay_to_event_check") and self.sync_replay_to_event_check.isChecked()):
            return
        target=self._nearest_replay_frame_for_event(event)
        if target is not None:
            self._event_navigation_in_progress=True
            try: self.set_frame(target)
            finally: self._event_navigation_in_progress=False
            self._selected_observed_event_index = int(original_index)
            self._update_cavitation_likelihood()

    def _nearest_replay_frame_for_event(self,event):
        if not self.replay or not self.replay.frames:
            return None
        cycle=getattr(event,"cycle",None)
        if cycle is not None:
            candidates=[]
            for idx,frame in enumerate(self.replay.frames):
                fc=getattr(frame,"acquisition_cycle",None)
                if fc is not None:
                    candidates.append((abs(int(fc)-int(cycle)),idx))
            if candidates:
                return min(candidates,key=lambda x:x[0])[1]
        t=getattr(event,"timestamp_s",None)
        if t is not None:
            vals=[]
            for idx,frame in enumerate(self.replay.frames):
                ft=getattr(frame,"acquisition_time_s",None)
                if ft is not None:
                    try: vals.append((abs(float(ft)-float(t)),idx))
                    except Exception: pass
            if vals:
                return min(vals,key=lambda x:x[0])[1]
        return None

    def _apply_cavitation_view_lock(self,*_):
        locked=bool(getattr(self,"cavitation_lock_view_check",None) and self.cavitation_lock_view_check.isChecked())
        for plot in (
            getattr(self,"cavitation_control_plot",None),
            getattr(self,"vendor_energy_plot",None),
            getattr(self,"vendor_control_plot",None),
            getattr(self,"cavitation_heatmap_plot",None),
            getattr(self,"cavitation_likelihood_plot",None),
        ):
            if plot is None:
                continue
            try:
                plot.getViewBox().setMouseEnabled(x=not locked,y=not locked)
                plot.setMenuEnabled(not locked)
            except Exception:
                pass

    def _reset_cavitation_views(self,*_):
        for plot in (
            getattr(self,"cavitation_control_plot",None),
            getattr(self,"vendor_energy_plot",None),
            getattr(self,"vendor_control_plot",None),
            getattr(self,"cavitation_heatmap_plot",None),
            getattr(self,"cavitation_likelihood_plot",None),
        ):
            if plot is None:
                continue
            try:
                xr=self._plot_data_x_range(plot)
                self._fit_plot(plot,x_range=xr)
            except Exception:
                pass
        self._apply_cavitation_view_lock()

    def _draw_observed_cavitation_timeline(self):
        if not hasattr(self, "cavitation_control_plot"):
            return
        self.cavitation_control_plot.clear()
        self.cavitation_control_plot.addLegend(offset=(8, 8))
        timeline=self.observed_cavitation_timeline
        self.cavitation_observed_table.setRowCount(0)
        self._visible_observed_events=[]
        self._plotted_observed_events=[]
        if timeline is None:
            self.cavitation_observed_label.setText("Observed cavitation-control timeline is unavailable.")
            if hasattr(self,"cavitation_analysis_summary"):
                self.cavitation_analysis_summary.setText("Cavitation analysis: observed control log unavailable")
            return

        show_increase=bool(getattr(self,"show_increase_events_check",None) and self.show_increase_events_check.isChecked())
        show_pre=bool(getattr(self,"show_preirradiation_events_check",None) and self.show_preirradiation_events_check.isChecked())

        def visible(ev):
            if str(getattr(ev, "family", "")).lower() == "increase" and not show_increase:
                return False
            if str(getattr(ev, "irradiation_state", "") or "") == "Pre-irradiation" and not show_pre:
                return False
            return True

        # Compatibility-visible form retained intentionally: this is also the contract
        # exercised by the older Increase-hidden regression tests.
        self._visible_observed_events = [
            (i, ev) for i, ev in enumerate(timeline.events)
            if show_increase or str(getattr(ev, "family", "")) != "Increase"
        ]
        if not show_pre:
            self._visible_observed_events = [
                (i, ev) for i, ev in self._visible_observed_events
                if str(getattr(ev, "irradiation_state", "") or "") != "Pre-irradiation"
            ]

        if timeline.actual_power_times_s.size and timeline.actual_power_ratio.size:
            self.cavitation_control_plot.plot(timeline.actual_power_times_s,timeline.actual_power_ratio,
                pen=pg.mkPen("#ffffff",width=2.5),symbol="o",symbolSize=4,name="Observed ExPowerRatio")
        if timeline.predicted_power_times_s.size and timeline.predicted_power_ratio.size:
            self.cavitation_control_plot.plot(timeline.predicted_power_times_s,timeline.predicted_power_ratio,
                pen=pg.mkPen("#06d6a0",width=1.5,style=Qt.PenStyle.DashLine),name="Reconstructed ExPowerRatio")

        if getattr(timeline,"irradiation_onset_s",None) is not None:
            onset=float(timeline.irradiation_onset_s)
            self.cavitation_control_plot.addItem(pg.InfiniteLine(pos=onset,angle=90,pen=pg.mkPen("#00b4d8",width=2,style=Qt.PenStyle.DashLine)))
            txt=pg.TextItem("Irradiation ON",color="#00b4d8",anchor=(0,1))
            txt.setPos(onset,1.02); self.cavitation_control_plot.addItem(txt)

        family_points={}
        pre_points=[[],[]]
        for original_index,ev in self._visible_observed_events:
            t=self._event_time_seconds(ev)
            if t is None or not np.isfinite(t):
                continue
            y=1.0
            if ev.after_power_ratio is not None and np.isfinite(ev.after_power_ratio):
                y=float(ev.after_power_ratio)
            elif ev.before_power_ratio is not None and np.isfinite(ev.before_power_ratio):
                y=float(ev.before_power_ratio)
            if getattr(ev,"irradiation_state","")=="Pre-irradiation":
                pre_points[0].append(t); pre_points[1].append(y)
            else:
                family_points.setdefault(ev.family,[[],[]])
                family_points[ev.family][0].append(t); family_points[ev.family][1].append(y)
            self._plotted_observed_events.append((original_index,ev))

        style={"Increase":("t","#06d6a0"),"Decrease":("o","#ffd166"),"Safety":("s","#f72585")}
        for family,(xs,ys) in family_points.items():
            symbol,color=style.get(family,("d","#4cc9f0"))
            self.cavitation_control_plot.plot(xs,ys,pen=None,symbol=symbol,symbolSize=9,symbolBrush=color,name=f"{family} event")
        if pre_points[0]:
            self.cavitation_control_plot.plot(pre_points[0],pre_points[1],pen=None,symbol="x",symbolSize=10,
                symbolPen=pg.mkPen("#9aa0a6",width=2),name="Pre-irradiation control")

        hidden_increase=sum(1 for ev in timeline.events if str(getattr(ev,"family",""))=="Increase") if not show_increase else 0
        hidden_pre=sum(1 for ev in timeline.events if getattr(ev,"irradiation_state","")=="Pre-irradiation") if not show_pre else 0
        msg=timeline.summary
        if hidden_increase: msg+=f" · Increase hidden: {hidden_increase}"
        if hidden_pre: msg+=f" · Pre-irradiation hidden: {hidden_pre}"
        self.cavitation_observed_label.setText(msg)

        candidates=sum(1 for _i,e in self._visible_observed_events if e.family in ("Decrease","Safety"))
        qualified=0
        for _i,e in self._visible_observed_events:
            try:
                if e.weighted_energy is None or e.threshold is None: continue
                ok=(float(e.weighted_energy)<float(e.threshold)) if e.family=="Increase" else (float(e.weighted_energy)>float(e.threshold))
                qualified+=1 if ok else 0
            except Exception:
                pass
        true_cav=sum(1 for _i,e in self._visible_observed_events if getattr(e,"counts_as_cavitation",False))
        pre=sum(1 for _i,e in self._visible_observed_events if getattr(e,"irradiation_state","")=="Pre-irradiation")
        if hasattr(self,"cavitation_analysis_summary"):
            self.cavitation_analysis_summary.setText(
                f"Analysis funnel — visible control events {len(self._visible_observed_events)} · "
                f"Decrease/Safety candidates {candidates} · rule-qualified {qualified} · treatment cavitation {true_cav} · "
                f"pre-irradiation control {pre}. Click any marker or row for exact Why evidence. "
                "Control time 0 is the Acquisition_Brain control-session origin, not MR acquisition time 0."
            )

        self.cavitation_observed_table.setRowCount(len(self._visible_observed_events))
        for r,(_original_index,ev) in enumerate(self._visible_observed_events):
            t='-' if ev.timestamp_s is None else f"{ev.timestamp_s:.3f} s"
            cycle='-' if ev.cycle is None else str(ev.cycle)
            rule=f"{ev.family} {ev.rule_index}"
            phase=str(getattr(ev,"irradiation_state","Unknown") or "Unknown")
            event_w=getattr(ev,"exciter_power_w",None)
            phase_display=phase + (f" ({float(event_w):.2f} W)" if event_w is not None and np.isfinite(event_w) else "")
            state=ev.severity + (" · CAVITATION" if getattr(ev,"counts_as_cavitation",False) else "")
            weighted='-' if ev.weighted_energy is None or not np.isfinite(ev.weighted_energy) else f"{ev.weighted_energy:.6g}"
            thr_parts=[]
            if ev.threshold is not None and np.isfinite(ev.threshold): thr_parts.append(f"max {ev.threshold:.6g}")
            if ev.critical_threshold is not None and np.isfinite(ev.critical_threshold): thr_parts.append(f"critical {ev.critical_threshold:.6g}")
            threshold=' / '.join(thr_parts) if thr_parts else '-'
            dominant='-'
            if ev.dominant_channel is not None:
                band_txt=f"/B{ev.dominant_band}" if ev.dominant_band is not None else ''
                val_txt='' if ev.dominant_energy is None or not np.isfinite(ev.dominant_energy) else f" ({ev.dominant_energy:.4g})"
                dominant=f"RCV{ev.dominant_channel}{band_txt}{val_txt}"
            rule_channels=tuple(getattr(ev,"rule_channels",()) or ())
            rule_bands=tuple(getattr(ev,"rule_bands",()) or ())
            observed_channels=tuple(getattr(ev,"observed_channels",()) or ())
            observed_bands=tuple(getattr(ev,"observed_bands",()) or ())
            if observed_channels or observed_bands:
                contributors=(f"Observed RCV{','.join(map(str,observed_channels)) if observed_channels else '-'} / "
                              f"B{','.join(map(str,observed_bands)) if observed_bands else '-'}")
                if rule_channels or rule_bands:
                    contributors+=(f" · Rule RCV{','.join(map(str,rule_channels)) if rule_channels else '-'} / "
                                   f"B{','.join(map(str,rule_bands)) if rule_bands else '-'}")
            elif rule_channels or rule_bands:
                contributors=(f"Rule RCV{','.join(map(str,rule_channels)) if rule_channels else '-'} / "
                              f"B{','.join(map(str,rule_bands)) if rule_bands else '-'}")
            else:
                contributors='-'
            power='-'
            if ev.before_power_ratio is not None or ev.after_power_ratio is not None:
                before='?' if ev.before_power_ratio is None or not np.isfinite(ev.before_power_ratio) else f"{ev.before_power_ratio:.3f}"
                after='?' if ev.after_power_ratio is None or not np.isfinite(ev.after_power_ratio) else f"{ev.after_power_ratio:.3f}"
                power=f"{before} → {after}"
            result=ev.result or ev.action or '-'
            values=[t,cycle,rule,phase_display,state,weighted,threshold,dominant,contributors,power,result,ev.evidence or '-']
            try:
                full_detail=self._why_text_for_event(ev)
            except Exception as exc:
                # Never let tooltip/Why formatting abort the Event list population.
                # The timeline is a primary diagnostic surface and must stay usable
                # even when one optional evidence field is malformed.
                full_detail=(f"Event detail formatting warning: {type(exc).__name__}: {exc}\n"
                             f"Event: {getattr(ev,'family','?')} rule {getattr(ev,'rule_index','?')} ")
            for c,value in enumerate(values):
                try:
                    item=QTableWidgetItem(str(value)); item.setToolTip(full_detail)
                    if phase=="Pre-irradiation":
                        item.setForeground(QBrush(QColor("#6c757d")))
                    self.cavitation_observed_table.setItem(r,c,item)
                except Exception as exc:
                    fallback=QTableWidgetItem(f"<display error: {type(exc).__name__}>")
                    fallback.setToolTip(full_detail)
                    self.cavitation_observed_table.setItem(r,c,fallback)

        plotted=len(self._plotted_observed_events); rows=self.cavitation_observed_table.rowCount()
        if plotted != rows:
            self.cavitation_observed_label.setText(self.cavitation_observed_label.text()+f" · DISPLAY INTEGRITY ERROR: plotted={plotted}, table={rows}")

        self.cavitation_control_plot.enableAutoRange(axis=pg.ViewBox.XYAxes,enable=True)
        self.cavitation_control_plot.autoRange(padding=0.04)
        self._apply_mr_timeline_window(self.cavitation_control_plot)
        for r in range(self.cavitation_observed_table.rowCount()):
            self.cavitation_observed_table.setRowHeight(r,24)
        self._install_control_replay_cursor()
        QTimer.singleShot(0, self._ensure_observed_event_table_integrity)
        self._apply_cavitation_view_lock()

    def _set_mr_xrange(self, *plots) -> None:
        if self.replay is None:
            return
        end=float(getattr(self.replay, "mr_timeline_duration_s", 0.0) or 0.0)
        if end <= 0:
            return
        for plot in plots:
            if plot is not None:
                try: plot.setXRange(0.0, end, padding=0.0)
                except Exception: pass

    def _apply_mr_timeline_window(self, *plots) -> None:
        """Compatibility name; fit each plot to payload data, not MR duration.

        Negative time is retained only when CPC/Acquisition payload genuinely
        exists before MR time zero.  Empty pre/post-MR space is never forced into
        view.
        """
        if self.replay is None:
            return
        irradiation=(float(getattr(self.replay, "mr_sonication_start_s", 0.0) or 0.0),
                     float(getattr(self.replay, "mr_sonication_end_s", 0.0) or 0.0))
        for plot in plots:
            if plot is None:
                continue
            xr=self._plot_data_x_range(plot)
            if xr is not None:
                self._fit_plot(plot,x_range=xr)
                for x,label in ((irradiation[0],"Irradiation start"),(irradiation[1],"Irradiation end")):
                    if xr[0] <= x <= xr[1]:
                        try:
                            plot.addItem(pg.InfiniteLine(pos=x, angle=90, movable=False,
                                pen=pg.mkPen("#ffffff", width=1.3, style=Qt.PenStyle.DashLine), label=label))
                        except Exception:
                            pass

    def _current_control_time(self) -> float | None:
        """Map the current FFT frame to the Acquisition_Brain control-session time axis.

        Control Timeline time zero and FFT acquisition time zero are not guaranteed to
        share an origin.  Prefer cycle-to-cycle mapping against the observed power
        timeline; only fall back to the frame acquisition time when no cycle mapping
        exists.
        """
        timeline=getattr(self,"observed_cavitation_timeline",None)
        if timeline is None or not self.replay or not self.replay.frames:
            return None
        frame=self.replay.frames[min(max(int(self.frame_index),0),len(self.replay.frames)-1)]
        cycle=getattr(frame,"acquisition_cycle",None)
        cycles=np.asarray(getattr(timeline,"actual_power_cycles",np.asarray([],dtype=int)))
        times=np.asarray(getattr(timeline,"actual_power_times_s",np.asarray([],dtype=float)),float)
        if cycle is not None and cycles.size and times.size and cycles.size==times.size:
            try:
                idx=int(np.nanargmin(np.abs(cycles.astype(float)-float(cycle))))
                value=float(times[idx])
                if np.isfinite(value):
                    return value
            except Exception:
                pass
        value=getattr(frame,"acquisition_time_s",None)
        try:
            value=float(value)
            return self.replay.acquisition_to_mr_time_s(value) if np.isfinite(value) else None
        except Exception:
            return None

    def _install_control_replay_cursor(self) -> None:
        """Create the independent white replay cursor on Control Timeline."""
        if not hasattr(self,"cavitation_control_plot"):
            return
        self._control_replay_cursor=None
        t=self._current_control_time()
        if t is None:
            return
        line=pg.InfiniteLine(pos=float(t),angle=90,movable=False,
                             pen=pg.mkPen("#ffffff",width=2.0,style=Qt.PenStyle.DashLine))
        try:
            line.setZValue(1000)
        except Exception:
            pass
        self.cavitation_control_plot.addItem(line)
        self._control_replay_cursor=line

    def _update_control_replay_cursor(self) -> None:
        t=self._current_control_time()
        if t is None:
            return
        line=getattr(self,"_control_replay_cursor",None)
        if line is None:
            self._install_control_replay_cursor()
            line=getattr(self,"_control_replay_cursor",None)
        if line is not None:
            try: line.setPos(float(t))
            except Exception: pass

    def _ensure_observed_event_table_integrity(self):
        if not hasattr(self,"cavitation_observed_table") or self.observed_cavitation_timeline is None:
            return
        expected=len(getattr(self,"_visible_observed_events",[]) or [])
        actual=self.cavitation_observed_table.rowCount()
        if expected and actual != expected:
            self._draw_observed_cavitation_timeline()
            actual=self.cavitation_observed_table.rowCount()
        if expected:
            for r in range(min(expected,actual)):
                self.cavitation_observed_table.setRowHeight(r,24)
        if hasattr(self,"cavitation_analysis_summary"):
            base=self.cavitation_analysis_summary.text().split(" · Event list rows",1)[0]
            self.cavitation_analysis_summary.setText(base+f" · Event list rows {actual}/{expected}")

    def _selected_observed_cavitation_event(self):
        # Keep the red selected-event cursor independent from the white replay cursor.
        # Probable Location is pinned to the event only immediately after explicit
        # event selection; ordinary replay navigation releases the location pin
        # without destroying the selected-event highlight.
        if not bool(getattr(self,"_probable_location_pinned_to_event",False)):
            return None
        timeline=self.observed_cavitation_timeline
        idx=getattr(self,"_selected_observed_event_index",None)
        if timeline is None or idx is None or not (0 <= int(idx) < len(timeline.events)):
            return None
        return timeline.events[int(idx)]


    def _select_observed_event_row(self, row: int):
        if self.observed_cavitation_timeline is None or not (0 <= row < len(self.observed_cavitation_timeline.events)):
            return
        self._selected_observed_event_index=int(row)
        self._probable_location_pinned_to_event=True
        ev = self.observed_cavitation_timeline.events[row]
        visible = getattr(self, "_visible_observed_events", [])
        visible_row = next((i for i, (original_index, _ev) in enumerate(visible) if original_index == row), None)
        if visible_row is not None:
            self.cavitation_observed_table.blockSignals(True)
            self.cavitation_observed_table.selectRow(visible_row)
            self.cavitation_observed_table.blockSignals(False)
        if self.replay and hasattr(self,"sync_replay_to_event_check") and self.sync_replay_to_event_check.isChecked():
            target=self._nearest_replay_frame_for_event(ev)
            if target is not None:
                self._event_navigation_in_progress=True
                try: self.set_frame(target)
                finally: self._event_navigation_in_progress=False
                self._selected_observed_event_index=int(row)
        self._update_cavitation_likelihood()



    def _event_time_seconds(self, ev) -> float | None:
        value = getattr(ev, "timestamp_s", None)
        if value is not None:
            try:
                value = float(value)
                if np.isfinite(value):
                    return value
            except Exception:
                pass
        cycle = getattr(ev, "cycle", None)
        if cycle is not None and self.replay is not None:
            try:
                interval = float(getattr(self.replay, "acquisition_interval_s", 0.010) or 0.010)
                raw_time = (float(cycle) - 1.0) * interval
                return self.replay.acquisition_to_mr_time_s(raw_time)
            except Exception:
                pass
        return None

    def _why_click_tolerance_s(self) -> float:
        # 100 ms was too strict in the UI and failed for events represented only
        # by acquisition-cycle timing. Use at least 350 ms and scale with sample
        # interval so clicking the visible event point is reliable.
        interval = 0.010
        if self.replay is not None:
            try:
                interval = float(getattr(self.replay, "acquisition_interval_s", interval) or interval)
            except Exception:
                pass
        return max(0.35, interval * 3.0)

    @staticmethod
    def _event_time_for_text(ev) -> float | None:
        value=getattr(ev,"timestamp_s",None)
        try:
            value=float(value)
            return value if np.isfinite(value) else None
        except Exception:
            return None

    @staticmethod
    def _why_text_for_event(ev) -> str:
        family=str(getattr(ev,"family","") or "Cavitation event")
        rule=getattr(ev,"rule_index",None)
        severity=str(getattr(ev,"severity","") or "")
        evidence=str(getattr(ev,"evidence","") or "")
        result=str(getattr(ev,"result","") or getattr(ev,"action","") or "")
        dominant=getattr(ev,"dominant_channel",None); band=getattr(ev,"dominant_band",None)
        weighted=getattr(ev,"weighted_energy",None); threshold=getattr(ev,"threshold",None)
        event_time=EightHydrophoneWindow._event_time_for_text(ev)
        cycle=getattr(ev,"cycle",None)
        where=[]
        if event_time is not None: where.append(f"t={event_time:.3f} s")
        if cycle is not None: where.append(f"cycle={cycle}")
        lines=[f"Selected point: {' · '.join(where) if where else 'time unavailable'}",
               f"Event type: {family}" + (f" · rule {rule}" if rule is not None else "")]
        if severity: lines.append(f"State: {severity}")
        phase=str(getattr(ev,"irradiation_state","Unknown") or "Unknown")
        lines.append(f"Irradiation phase: {phase}")
        exciter=getattr(ev,"exciter_power_w",None)
        if exciter is not None and np.isfinite(exciter):
            lines.append(f"Exciter power at event: {float(exciter):.3f} W")
        lines.append("Final classification: " + (
            "TREATMENT CAVITATION" if getattr(ev,"counts_as_cavitation",False)
            else ("PRE-IRRADIATION CONTROL EVALUATION (not counted as treatment cavitation)"
                  if phase=="Pre-irradiation" else "CONTROL EVENT / candidate")
        ))
        if dominant is not None: lines.append(f"Dominant: RCV{dominant}"+(f" / Band{band}" if band is not None else ""))
        try:
            if weighted is not None and np.isfinite(float(weighted)): lines.append(f"Weighted energy: {float(weighted):.6g}")
        except Exception: pass
        try:
            if threshold is not None and np.isfinite(float(threshold)): lines.append(f"Threshold: {float(threshold):.6g}")
        except Exception: pass
        try:
            if weighted is not None and threshold is not None and np.isfinite(float(weighted)) and np.isfinite(float(threshold)):
                w=float(weighted); th=float(threshold)
                if family.lower()=="increase":
                    fired=w < th; relation="<"
                else:
                    fired=w > th; relation=">"
                margin=(abs(w-th)/abs(th)*100.0) if abs(th)>1e-12 else float("nan")
                lines.append(f"Trigger check: {w:.6g} {relation} {th:.6g} = {'YES' if fired else 'NO'}" +
                             (f" ({margin:.1f}% from threshold)" if np.isfinite(margin) else ""))
                lines.append("Graph link: the highlighted large point is this exact Acquisition_Brain event value; "
                             "the continuous curves may represent a different receiver/band/rule weighting.")
        except Exception:
            pass
        observed_channels=tuple(getattr(ev,"observed_channels",()) or ())
        observed_bands=tuple(getattr(ev,"observed_bands",()) or ())
        rule_channels=tuple(getattr(ev,"rule_channels",()) or ())
        rule_bands=tuple(getattr(ev,"rule_bands",()) or ())
        if observed_channels or observed_bands:
            lines.append("Observed contributors: RCV" + (",".join(str(x) for x in observed_channels) if observed_channels else "-") +
                         " / B" + (",".join(str(x) for x in observed_bands) if observed_bands else "-"))
        if rule_channels or rule_bands:
            lines.append("Configured rule inputs: RCV" + (",".join(str(x) for x in rule_channels) if rule_channels else "-") +
                         " / B" + (",".join(str(x) for x in rule_bands) if rule_bands else "-"))
        if evidence: lines.append(f"Evidence source: {evidence}")
        if result and result not in evidence: lines.append(f"Result / response: {result}")
        raw_message=str(getattr(ev,"source_message","") or "")
        if raw_message: lines.append(f"Source line: {raw_message}")
        return "\n".join(lines)

    def _clear_why_event_highlight(self) -> None:
        for item in list(getattr(self,"_why_event_highlight_items",[]) or []):
            for plot in (getattr(self,"vendor_energy_plot",None),getattr(self,"vendor_power_plot",None),getattr(self,"cavitation_control_plot",None)):
                if plot is not None:
                    try: plot.removeItem(item)
                    except Exception: pass
        self._why_event_highlight_items=[]

    def _highlight_why_event(self, ev) -> None:
        self._clear_why_event_highlight()
        items=[]
        t=self._event_time_seconds(ev)
        if t is None: return
        # Vertical cursor on all event-related charts makes the selected point unambiguous.
        for plot in (getattr(self,"vendor_energy_plot",None),getattr(self,"vendor_power_plot",None),getattr(self,"cavitation_control_plot",None)):
            if plot is None: continue
            line=pg.InfiniteLine(pos=float(t),angle=90,movable=False,
                                 pen=pg.mkPen("#ff2d55",width=2.5,style=Qt.PenStyle.DashLine))
            plot.addItem(line); items.append(line)
        weighted=getattr(ev,"weighted_energy",None); threshold=getattr(ev,"threshold",None)
        try:
            if weighted is not None and np.isfinite(float(weighted)) and hasattr(self,"vendor_energy_plot"):
                dot=pg.ScatterPlotItem([float(t)],[float(weighted)],size=15,
                                       brush=pg.mkBrush("#ff2d55"),pen=pg.mkPen("#ffffff",width=2))
                self.vendor_energy_plot.addItem(dot); items.append(dot)
            if threshold is not None and np.isfinite(float(threshold)) and hasattr(self,"vendor_energy_plot"):
                thline=pg.InfiniteLine(pos=float(threshold),angle=0,movable=False,
                                       pen=pg.mkPen("#ff2d55",width=1.8,style=Qt.PenStyle.DotLine),
                                       label=f"Selected rule threshold {float(threshold):.6g}")
                self.vendor_energy_plot.addItem(thline); items.append(thline)
        except Exception:
            pass
        self._why_event_highlight_items=items

    def _show_event_why_popup(self, ev, force: bool = False) -> None:
        self._highlight_why_event(ev)
        if not force and (not getattr(self,"vendor_why_popup_check",None) or not self.vendor_why_popup_check.isChecked()):
            return
        t=self._event_time_seconds(ev)
        family=str(getattr(ev,"family","") or "Event")
        rule=getattr(ev,"rule_index",None)
        title=f"Why — {family}" + (f" R{rule}" if rule is not None else "")
        if t is not None: title+=f" @ {t:.3f} s"
        try:
            detail=self._why_text_for_event(ev)
        except Exception as exc:
            detail=(f"Why detail formatting failed: {type(exc).__name__}: {exc}\n"
                    f"Event family={getattr(ev,'family','?')} rule={getattr(ev,'rule_index','?')}")
        QMessageBox.information(self,title,detail)

    def _cavitation_control_plot_clicked(self, event):
        if self.observed_cavitation_timeline is None or not self.observed_cavitation_timeline.events:
            return
        try:
            if hasattr(event,'button') and event.button() != Qt.MouseButton.LeftButton:
                return
        except Exception:
            pass
        scene_pos=event.scenePos()
        # Select by screen-space distance to the actual marker, not by a fixed
        # time tolerance.  This remains reliable after zooming and for dense events.
        candidates=[]
        vb=self.cavitation_control_plot.plotItem.vb
        for original_index, ev in list(getattr(self,"_visible_observed_events",[]) or []):
            t=self._event_time_seconds(ev)
            if t is None or not np.isfinite(t):
                continue
            y=1.0
            try:
                if ev.after_power_ratio is not None and np.isfinite(float(ev.after_power_ratio)):
                    y=float(ev.after_power_ratio)
                elif ev.before_power_ratio is not None and np.isfinite(float(ev.before_power_ratio)):
                    y=float(ev.before_power_ratio)
            except Exception:
                pass
            try:
                sp=vb.mapViewToScene(QPointF(float(t),float(y)))
                dx=float(sp.x()-scene_pos.x()); dy=float(sp.y()-scene_pos.y())
                candidates.append((dx*dx+dy*dy,original_index))
            except Exception:
                continue
        if not candidates:
            return
        dist2,chosen_index=min(candidates,key=lambda z:z[0])
        # 18 px hit radius: large enough for photographed/laptop operation,
        # still small enough to avoid selecting unrelated points.
        if dist2 > 18.0*18.0:
            return
        self._select_observed_event_row(int(chosen_index))
        ev=self.observed_cavitation_timeline.events[int(chosen_index)]
        if getattr(self,"control_why_popup_check",None) is not None and self.control_why_popup_check.isChecked():
            self._show_event_why_popup(ev, force=True)
        else:
            self._highlight_why_event(ev)

    def _vendor_chart_clicked(self, plot, event):
        if not self.replay or not self.replay.frames:
            return
        point = plot.plotItem.vb.mapSceneToView(event.scenePos())
        x = float(point.x())
        times = self.replay.sonication_frame_times_s
        if times.size:
            idx = int(np.nanargmin(np.abs(times - x)))
            self.set_frame(idx)
        if self.observed_cavitation_timeline is not None and self.observed_cavitation_timeline.events:
            candidates = []
            for original_index, ev in list(getattr(self,"_visible_observed_events",[]) or []):
                event_time = self._event_time_seconds(ev)
                if event_time is not None:
                    candidates.append((original_index, abs(float(event_time) - x)))
            if candidates:
                chosen = min(candidates, key=lambda z: z[1])
                if chosen[1] <= self._why_click_tolerance_s():
                    self._select_observed_event_row(chosen[0])
                    self._show_event_why_popup(self.observed_cavitation_timeline.events[chosen[0]])

    def set_language(self, language: str) -> None:
        self.language = str(language or "en")
        localize_qt_tree(self, self.language)
        if hasattr(self, "cavitation_likelihood_plot"):
            self._draw_cavitation_likelihood()
        if hasattr(self, "subwindow_progress_label") and not self.subwindow_progress_label.isVisible():
            self.subwindow_progress_label.setText(tr(self.language, "ready"))

    def _draw_cavitation_likelihood(self):
        if not hasattr(self, "cavitation_likelihood_plot"):
            return
        self.cavitation_likelihood_plot.clear()
        self.cavitation_likelihood_plot.addItem(self.cavitation_likelihood_image)
        self.cavitation_likelihood_table.setRowCount(0)
        result = self.cavitation_likelihood
        # Cavitation location is a probable region, not a single-point localization.
        if result is None or result.likelihood_map.size == 0:
            self.cavitation_likelihood_label.setText(tr(self.language, "likelihood_unavailable"))
            self.cavitation_likelihood_image.setImage(np.empty((0, 0)))
            return
        self.cavitation_likelihood_label.setText(
            result.summary + "\n" + result.evidence +
            "\n" + tr(self.language, "probable_region_note")
        )
        shown = np.asarray(result.likelihood_map, float)
        self.cavitation_likelihood_image.setImage(shown, autoLevels=False, levels=(0, 1))
        self.cavitation_likelihood_image.setRect(QRectF(float(result.x_coords[0]), float(result.y_coords[0]), float(result.x_coords[-1] - result.x_coords[0]), float(result.y_coords[-1] - result.y_coords[0])))
        # Outline schematic head/focus area
        theta = np.linspace(0, 2*np.pi, 240)
        self.cavitation_likelihood_plot.plot(np.cos(theta), np.sin(theta), pen=pg.mkPen("#aaaaaa", width=1.0), name="Receiver ring")
        fx, fy = result.focus_xy
        self.cavitation_likelihood_plot.plot([fx], [fy], pen=None, symbol="+", symbolSize=14, symbolPen=pg.mkPen("#ffffff", width=2), name="Focus")
        pos = np.asarray(result.hydrophone_positions, float)
        dom = result.dominant_channel
        visible=set(self._visible_receivers())
        for ch in range(pos.shape[0]):
            if ch not in visible:
                continue
            color = "#f72585" if dom is not None and ch == dom else "#ffd166" if result.per_channel_scores[ch] > 0 else "#4cc9f0"
            size = 12 if dom is not None and ch == dom else 9
            self.cavitation_likelihood_plot.plot([pos[ch,0]], [pos[ch,1]], pen=None, symbol="o", symbolSize=size, symbolBrush=color, symbolPen=pg.mkPen("#000000", width=1.0))
            txt = pg.TextItem(f"RCV{ch}", color="#ffffff", anchor=(0.5, 1.2))
            txt.setPos(float(pos[ch,0]), float(pos[ch,1]))
            self.cavitation_likelihood_plot.addItem(txt)
        if result.centroid_xy is not None:
            cx, cy = result.centroid_xy
            self.cavitation_likelihood_plot.plot([cx], [cy], pen=None, symbol="x", symbolSize=14, symbolPen=pg.mkPen("#06d6a0", width=3), name="Likelihood centroid")
        rows = np.argsort(-result.per_channel_scores)
        visible=set(self._visible_receivers())
        positive = [int(r) for r in rows if int(r) in visible and result.per_channel_scores[int(r)] > 0]
        filled = positive if positive else sorted(visible)
        self.cavitation_likelihood_table.setRowCount(len(filled))
        for r, ch in enumerate(filled):
            role = "Dominant" if dom is not None and ch == dom else "Contributing" if result.per_channel_scores[ch] > 0.01 else "Low"
            family = self.likelihood_service.RECEIVER_FAMILY[ch] if ch < len(self.likelihood_service.RECEIVER_FAMILY) else "-"
            vals = [f"RCV{ch}", f"{family}", f"{100*result.per_channel_scores[ch]:.1f}%", role]
            for c, v in enumerate(vals):
                self.cavitation_likelihood_table.setItem(r, c, QTableWidgetItem(v))

    def _update_cavitation_likelihood(self):
        if not self.replay or not hasattr(self, "cavitation_likelihood_plot"):
            return
        observed_event = self._selected_observed_cavitation_event()
        self.cavitation_likelihood = self.likelihood_service.estimate(self.replay, self.frame_index, observed_event)
        self._draw_cavitation_likelihood()

    def _load_observed_cavitation_timeline(self):
        if not self.replay:
            self.observed_cavitation_timeline = None
            return
        validation = getattr(self.replay, "vendor_control_validation", None)
        predicted_cycles = validation.event_cycles if validation is not None else np.asarray([], dtype=int)
        predicted_ratio = validation.predicted_power_ratio if validation is not None else np.asarray([], dtype=float)
        history_validation = getattr(self.replay, "vendor_history_validation", None)
        preferred_session = history_validation.log_session_index if history_validation is not None else getattr(self.replay,"acquisition_session_index",None)
        source_path = self.replay.source_fft or self.replay.source_raw
        anchor = next((f for f in self.replay.frames if getattr(f,"acquisition_cycle",None) is not None and getattr(f,"acquisition_time_s",None) is not None), None)
        self.observed_cavitation_timeline = self.control_timeline_service.parse(
            source_path,
            getattr(self.replay, "vendor_profile", None),
            preferred_session,
            predicted_cycles,
            predicted_ratio,
            getattr(self.replay, "sonication_time_zero_offset_s", 0.0),
            getattr(self.replay, "mr_sonication_start_s", 0.0),
            getattr(self.replay, "mr_sonication_end_s", 0.0),
            getattr(self.replay, "mr_timeline_duration_s", 0.0),
            getattr(anchor, "acquisition_cycle", None) if anchor is not None else None,
            getattr(anchor, "acquisition_time_s", None) if anchor is not None else None,
            getattr(self.replay, "acquisition_interval_s", 0.010),
        )
        if self.observed_cavitation_timeline is not None and self.observed_cavitation_timeline.events and self.replay.frames:
            frame = self.replay.frames[min(max(self.frame_index, 0), len(self.replay.frames)-1)]
            cycle = getattr(frame, "acquisition_cycle", None)
            if cycle is not None:
                candidates = [(abs(int(ev.cycle)-int(cycle)), idx) for idx, ev in enumerate(self.observed_cavitation_timeline.events) if ev.cycle is not None]
                if candidates:
                    _distance, original_row = min(candidates)
                    visible=list(getattr(self,"_visible_observed_events",[]) or [])
                    visible_row=next((i for i,(orig,_ev) in enumerate(visible) if orig==original_row),None)
                    if visible_row is not None:
                        self.cavitation_observed_table.selectRow(int(visible_row))

    def _direct_replay_band_cube(self):
        """Build the authoritative snapshot × RCV × Band cube from replay.frames.

        This intentionally does not depend on candidate/event detection.  If the
        Spectrum dump decoded Band0-3, Hydrophone × Band must remain visible even
        when zero cavitation events were classified.
        """
        if not self.replay or not self.replay.frames:
            return np.empty((0,8,4),float), 0
        rows=[]; valid=0
        for frame in self.replay.frames:
            arr=np.asarray(getattr(frame,'vendor_band_energies',np.empty((0,0))),float)
            if arr.shape==(8,4):
                rows.append(arr); valid+=1
            else:
                rows.append(np.full((8,4),np.nan,float))
        return np.stack(rows,axis=0), valid

    def _render_direct_band_heatmap(self):
        cube,valid=self._direct_replay_band_cube()
        if cube.size==0:
            self.cavitation_heatmap_image.setImage(np.empty((0,0)))
            if hasattr(self,'cavitation_heatmap_status'):
                self.cavitation_heatmap_status.setText('FFT/Band link: no replay frames')
            return
        img=np.transpose(cube,(1,2,0)).reshape(32,cube.shape[0])
        finite=img[np.isfinite(img)]
        if finite.size:
            lo=float(np.nanpercentile(finite,2)); hi=float(np.nanpercentile(finite,98))
            if not np.isfinite(hi) or hi<=lo: hi=lo+1.0
            shown=np.where(np.isfinite(img),img,lo)
            self.cavitation_heatmap_image.setImage(shown,autoLevels=False,levels=(lo,hi))
            current=self.replay.frames[min(max(self.frame_index,0),len(self.replay.frames)-1)]
            current_arr=np.asarray(getattr(current,'vendor_band_energies',np.empty((0,0))),float)
            current_max=float(np.nanmax(current_arr)) if current_arr.shape==(8,4) and np.isfinite(current_arr).any() else float('nan')
        else:
            self.cavitation_heatmap_image.setImage(np.zeros((32,cube.shape[0]),float),autoLevels=False,levels=(0,1)); current_max=float('nan')
        self.cavitation_heatmap_image.setRect(QRectF(0,0,max(cube.shape[0],1),32))
        if hasattr(self,'cavitation_heatmap_status'):
            max_txt='n/a' if not np.isfinite(current_max) else f'{current_max:.6g}'
            self.cavitation_heatmap_status.setText(
                f'FFT/Band link: snapshot {self.frame_index+1}/{len(self.replay.frames)} · '
                f'valid 8×4 matrices {valid}/{len(self.replay.frames)} · current max energy {max_txt}'
            )

    def _refresh_cavitation_analysis(self,*_):
        if not hasattr(self,"cavitation_event_table"):
            return
        self.cavitation_event_table.setRowCount(0)
        if hasattr(self, "cavitation_observed_table"):
            self.cavitation_observed_table.setRowCount(0)
        if not self.replay:
            self.cavitation_evidence_label.setText("No Spectrum dump loaded.")
            if hasattr(self, "cavitation_observed_label"):
                self.cavitation_observed_label.setText("Observed cavitation-control timeline is unavailable.")
            self.cavitation_heatmap_image.setImage(np.empty((0,0)))
            self.cavitation_likelihood = None
            self._draw_cavitation_likelihood()
            return
        requested=self.analysis_mode_combo.currentText() if hasattr(self,"analysis_mode_combo") else "Auto Evidence-First"
        analysis=self.standalone_cavitation_service.analyze(self.replay,requested,float(self.candidate_z.value()))
        self.cavitation_analysis=analysis
        self.cavitation_evidence_label.setText(
            f"Mode: {analysis.mode}\nTiming: {analysis.timing_status}\nBands: {analysis.band_status}\nRules: {analysis.rule_status}\n{analysis.summary}"
        )
        self._load_observed_cavitation_timeline()
        self._draw_observed_cavitation_timeline()
        self._update_cavitation_likelihood()
        self._render_direct_band_heatmap()
        self.cavitation_event_table.setRowCount(len(analysis.events))
        for r,event in enumerate(analysis.events):
            hydro="Combined" if event.channel < 0 else f"RCV{event.channel}"
            band="Combined" if event.band < 0 else f"Band{event.band}"
            time="-" if event.time_s is None else f"{event.time_s:.3f} s"
            cycle="-" if event.acquisition_cycle is None else str(event.acquisition_cycle)
            base="-" if event.baseline is None or not np.isfinite(event.baseline) else f"{event.baseline:.6g}"
            score="-" if event.robust_z is None or not np.isfinite(event.robust_z) else f"{event.robust_z:.1f} σ"
            detection=event.severity if not event.rule else f"{event.severity}: {event.rule}"
            result=event.evidence if not event.action else f"{event.evidence} → {event.action}"
            values=[str(event.snapshot_index+1),cycle,time,hydro,band,f"{event.energy:.6g}",base,score,detection,result]
            detail=f"Snapshot {event.snapshot_index+1}\n{detection}\n{result}"
            for c,value in enumerate(values):
                item=QTableWidgetItem(value); item.setToolTip(detail)
                self.cavitation_event_table.setItem(r,c,item)
        QTimer.singleShot(0, self._ensure_observed_event_table_integrity)

    def _build_navigator_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        self.packet_label = QLabel("No measure selected")
        layout.addWidget(self.packet_label)
        self.stats_table = QTableWidget(8, 9)
        self.stats_table.setHorizontalHeaderLabels(["CH", "Raw A/D peak", "Raw A/D RMS", "Dominant MHz", "Peak dB", "Band energy", "Raw spectrum peak", "Cal spectrum peak", "Coef @ f0"])
        self.stats_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.stats_table.verticalHeader().setVisible(False)
        layout.addWidget(self.stats_table, 1)
        return page

    def _clear_layout(self, layout: QGridLayout) -> None:
        while layout.count():
            item = layout.takeAt(0); widget = item.widget()
            if widget: widget.deleteLater()

    def _pause_replay_for_view_change(self):
        """Stop timer while rebuilding plots; return whether playback must resume."""
        was_active=bool(self.timer.isActive())
        if was_active:
            self.timer.stop()
        return was_active

    def _resume_replay_after_view_change(self, was_active: bool):
        if not was_active or not self.replay or not self.replay.frames:
            return
        interval=float(getattr(self.replay,"frame_interval_s",0.010) or 0.010)
        factor=self._speed_factor_from_text(self.probable_speed_combo.currentText()) if hasattr(self,'probable_speed_combo') else 1.0
        self.timer.start(max(10,int(interval*1000/max(factor,0.01))))

    def _reset_replay_state_fast(self):
        """Reset replay ownership without touching expensive secondary Qt widgets.

        R0116zj: this is the only reset allowed before the first FFT frame is
        published.  The older reset synchronously cleared large Cavitation tables
        and ImageItems here, which stranded the progress dialog at 58% before the
        Spectrum publish path was even entered.
        """
        self.timer.stop()
        self.frame_index=0
        self.cavitation_analysis=None
        self.observed_cavitation_timeline=None
        self.cavitation_likelihood=None
        self._visible_observed_events=[]
        self._plotted_observed_events=[]
        self._selected_observed_event_index=None
        self._probable_location_pinned_to_event=False
        self._last_dynamic_frame_index=None
        self._event_navigation_in_progress=False

    def _clear_secondary_analysis_views(self):
        """Clear stale Cavitation/Vendor UI after primary Spectrum is visible."""
        self._clear_why_event_highlight()
        for table_name in ('cavitation_observed_table','cavitation_event_table','cavitation_likelihood_table'):
            table=getattr(self,table_name,None)
            if table is not None:
                table.blockSignals(True)
                table.setRowCount(0)
                table.clearSelection()
                table.blockSignals(False)
        if hasattr(self,'cavitation_analysis_summary'):
            self.cavitation_analysis_summary.setText('Cavitation analysis: waiting for current replay')
        if hasattr(self,'cavitation_observed_label'):
            self.cavitation_observed_label.setText('Observed cavitation-control timeline is unavailable.')
        if hasattr(self,'cavitation_likelihood_image'):
            self.cavitation_likelihood_image.setImage(np.empty((0,0)))
        if hasattr(self,'cavitation_heatmap_image'):
            self.cavitation_heatmap_image.setImage(np.empty((0,0)))
        if hasattr(self,'cavitation_heatmap_status'):
            self.cavitation_heatmap_status.setText('FFT/Band link: waiting for current replay')

    def _reset_replay_analysis_state(self):
        """Full reset for explicit source teardown; not used in the 58% publish path."""
        self._reset_replay_state_fast()
        self._clear_secondary_analysis_views()

    def _set_background_wait_mode(self, waiting: bool) -> None:
        self._awaiting_background_preload = bool(waiting)
        try:
            # R0116zc: preload is non-modal. Keep Analyzer navigation usable;
            # only data-dependent rendering waits for the handoff.
            self.tabs.setEnabled(True)
            self.sonication_combo.setEnabled(True)
        except Exception:
            pass
        dlg=getattr(self, "_exclusive_progress", None)
        if dlg is not None:
            # Background Spectrum preload must never block the main Replay window.
            dlg.setWindowModality(Qt.WindowModality.NonModal if waiting else Qt.WindowModality.ApplicationModal)

    def prepare_for_background_preload(self, package, sonication_index: int, progress: int = 0, message: str = "") -> None:
        """Show Analyzer immediately while main-window preload continues in a worker."""
        self.package=package
        self.open_loaded_export_btn.setEnabled(True)
        self._set_background_wait_mode(True)
        if hasattr(self, "source_label"):
            self.source_label.setText(f"Spectrum preload: {int(progress or 0)}% — {message or 'waiting for background source discovery'}")
        self.source_entries=[]
        self.sonication_combo.blockSignals(True); self.sonication_combo.clear()
        for i, son in enumerate(package.sonications):
            self.source_entries.append(("sonication", i))
            label=f"Sonication / {son.name}"
            self.sonication_combo.addItem(label)
            self.sonication_combo.setItemData(self.sonication_combo.count()-1,label,Qt.ItemDataRole.ToolTipRole)
        target=max(0,min(int(sonication_index),max(0,len(package.sonications)-1)))
        if self.sonication_combo.count(): self.sonication_combo.setCurrentIndex(target)
        self.sonication_combo.blockSignals(False)
        shown=max(2,min(95,int(progress or 2)))
        self._set_subwindow_progress(shown, message or "Spectrum data are preloading in background. You may return to the main Replay window.")

    def update_background_preload_progress(self, value: int, message: str) -> None:
        if not self._awaiting_background_preload:
            return
        if int(value) >= 100:
            return
        if hasattr(self, "source_label"):
            self.source_label.setText(f"Spectrum preload: {int(value)}% — {message}")
        self._set_subwindow_progress(max(2,min(95,int(value))), message)

    def accept_preloaded_context(self, package, context, sonication_index: int) -> None:
        """Adopt worker-produced candidates/mapping/replay without decoding again."""
        if context is None or Path(context.get("workspace")) != Path(package.workspace):
            return
        self.package=package
        candidates=list(context.get("candidates", []) or [])
        from src.services.spectrum_dump_import_service import SpectrumDumpSource
        self.dump_source=SpectrumDumpSource(source=Path(package.workspace), workspace=Path(package.workspace), candidates=candidates, temporary=False) if candidates else None
        self._sonication_dump_map=dict(context.get("mapping", {}) or {})
        self._preloaded_replays.update(dict(context.get("replays", {}) or {}))
        self.source_entries=[]
        self.sonication_combo.blockSignals(True); self.sonication_combo.clear()
        for i, son in enumerate(package.sonications):
            self.source_entries.append(("sonication", i))
            label=f"Sonication / {son.name}"; self.sonication_combo.addItem(label)
            self.sonication_combo.setItemData(self.sonication_combo.count()-1,label,Qt.ItemDataRole.ToolTipRole)
        for i, candidate in enumerate(candidates):
            if candidate.family == "SpectrumMsg": continue
            self.source_entries.append(("dump", i))
            label=f"SpectrumDumps / {candidate.label} [{candidate.completeness}]"; self.sonication_combo.addItem(label)
            self.sonication_combo.setItemData(self.sonication_combo.count()-1,label,Qt.ItemDataRole.ToolTipRole)
        target_index=max(0,min(int(sonication_index),max(0,len(package.sonications)-1)))
        target_row=next((r for r,e in enumerate(self.source_entries) if e == ("sonication",target_index)),0)
        self.sonication_combo.setCurrentIndex(target_row); self.sonication_combo.blockSignals(False)
        self._set_background_wait_mode(False)
        # R0116zh: keep a visible progress popup through the handoff.  The old
        # code closed it here and then performed the expensive plot publishing,
        # so opening the Analyzer looked idle even though work was still running.
        self._set_subwindow_progress(58, "Spectrum preload ready; scheduling decoded-data publish…", pump_events=False)
        if hasattr(self, "note"):
            self.note.setText("Spectrum preload ready; scheduling decoded-data publish…")
        # R0116zk: return to the Qt event loop before beginning the publish chain.
        # Calling load_sonication() inline from the preload-ready signal allowed
        # nested processEvents()/modal progress updates to re-enter this handoff
        # and strand the UI at the last painted 58% value.
        workspace_token = Path(package.workspace)
        QTimer.singleShot(0, lambda idx=target_index, ws=workspace_token: self._continue_preloaded_publish(ws, idx))

    def _continue_preloaded_publish(self, workspace_token: Path, target_index: int) -> None:
        """Continue a preload handoff only if the same study is still authoritative."""
        if self.package is None or Path(self.package.workspace) != Path(workspace_token):
            return
        self._set_subwindow_progress(60, "Starting decoded Spectrum publish…")
        self.load_sonication(int(target_index))

    def reset_source_context(self):
        """Hard-clear old Export/Spectrum context before a different source is adopted."""
        # Invalidate any older decoder before clearing ownership. A worker is
        # allowed to finish naturally, but its queued ready/failed signals must
        # never repopulate a newly opened study.
        self._decode_request_id += 1
        self._decode_context = None
        self._decode_heartbeat.stop()
        self._reset_replay_analysis_state()
        self.replay=None
        self.package=None
        self.dump_source=None
        self.source_entries=[]
        self._loaded_sonication_index=None
        self._preloaded_replays={}
        self._awaiting_background_preload=False
        if hasattr(self,'sonication_combo'):
            self.sonication_combo.blockSignals(True); self.sonication_combo.clear(); self.sonication_combo.blockSignals(False)
        if hasattr(self,'source_label'): self.source_label.setText('No CPC source loaded')
        for plot_name in ('cavitation_control_plot','vendor_energy_plot','vendor_power_plot','band_plot','spectrogram_plot'):
            plot=getattr(self,plot_name,None)
            if plot is not None:
                try: plot.clear()
                except Exception: pass
        if hasattr(self,'cavitation_heatmap_status'): self.cavitation_heatmap_status.setText('FFT/Band link: source reset')
        self._refresh_frame_views()

    def _rebuild_raw_plots(self) -> None:
        if not hasattr(self, "raw_layout") or self._view_change_guard: return
        self._view_change_guard=True
        was_active=self._pause_replay_for_view_change()
        try:
            self._clear_layout(self.raw_layout); self.raw_plots = []
            mode = self.raw_mode.currentText()
            count = 8 if mode == "8 Panels" else 1
            for i in range(count):
                plot = self._plot("MR acquisition time (s)", "History value")
                if count == 8:
                    plot.setTitle(f"RCV{i}"); self.raw_layout.addWidget(plot, i//4, i%4)
                else:
                    self.raw_layout.addWidget(plot, 0, 0)
                self.raw_plots.append(plot)
            self._draw_raw()
        finally:
            self._view_change_guard=False
            QTimer.singleShot(60, lambda active=was_active: self._resume_replay_after_view_change(active))

    def _rebuild_spectrum_plots(self) -> None:
        if not hasattr(self, "spectrum_layout") or self._view_change_guard: return
        self._view_change_guard=True
        was_active=self._pause_replay_for_view_change()
        try:
            self._clear_layout(self.spectrum_layout); self.spectrum_plots = []
            mode = self.spectrum_mode.currentText()
            count = 8 if mode == "8 Panels" else 1
            for i in range(count):
                plot = self._plot("Frequency (MHz)", "Relative level (dB)")
                plot.setXRange(0.0, 1.0, padding=0.0)
                if count == 8:
                    plot.setTitle(f"RCV{i}"); self.spectrum_layout.addWidget(plot, i//4, i%4)
                else:
                    self.spectrum_layout.addWidget(plot, 0, 0)
                self.spectrum_plots.append(plot)
            self._draw_spectrum()
        finally:
            self._view_change_guard=False
            QTimer.singleShot(60, lambda active=was_active: self._resume_replay_after_view_change(active))

    def _set_subwindow_progress(self, value: int | None, text: str = "", *, pump_events: bool = True) -> None:
        """Progress for exclusive Spectrum source/load/rebuild operations."""
        if not hasattr(self, "subwindow_progress_bar"):
            return
        if value is None:
            self.subwindow_progress_bar.setVisible(False)
            self.subwindow_progress_label.setVisible(False)
            dlg=getattr(self,"_exclusive_progress",None)
            if dlg is not None: dlg.finish()
            return
        self.subwindow_progress_bar.setVisible(True)
        self.subwindow_progress_label.setVisible(True)
        self.subwindow_progress_label.setText(text or "Processing…")
        self.subwindow_progress_bar.setRange(0, 100)
        self.subwindow_progress_bar.setValue(max(0, min(100, int(value))))
        dlg=getattr(self,"_exclusive_progress",None)
        if dlg is not None:
            if int(value) >= 100:
                dlg.finish()
            else:
                dlg.show_progress(int(value), text, title="Spectrum data processing",
                                  message="Please wait. Spectrum/Cavitation controls are temporarily locked while data are being prepared.",
                                  process_events=pump_events)
        if pump_events:
            QApplication.processEvents()


    def showEvent(self, event):
        super().showEvent(event)
        # R0116x: never open outside the usable desktop. Large fixed-size dialogs
        # were clipped on 1366x768 / laptop displays. Fit once to the screen that
        # actually contains the window while preserving normal resize/maximize.
        if not self._screen_fit_done:
            self._screen_fit_done = True
            screen = self.screen() or QApplication.primaryScreen()
            if screen is not None:
                area = screen.availableGeometry()
                margin = 18
                target_w = min(self.width(), max(900, area.width() - margin * 2))
                target_h = min(self.height(), max(620, area.height() - margin * 2))
                self.resize(target_w, target_h)
                x = area.x() + max(0, (area.width() - target_w) // 2)
                y = area.y() + max(0, (area.height() - target_h) // 2)
                self.move(x, y)
                self._stable_window_geometry = self.geometry()
        # Always open on a complete-data view rather than inheriting a stale zoom.
        QTimer.singleShot(0, lambda: self._fit_all_data_views(force=True))

    def _clamp_window_to_screen(self) -> None:
        """Keep top-level geometry stable and inside the usable desktop."""
        screen=self.screen() or QApplication.primaryScreen()
        if screen is None:
            return
        area=screen.availableGeometry()
        g=self.geometry()
        w=min(g.width(),max(720,area.width()-24))
        h=min(g.height(),max(480,area.height()-24))
        x=min(max(g.x(),area.x()),area.right()-w+1)
        y=min(max(g.y(),area.y()),area.bottom()-h+1)
        if (w,h,x,y)!=(g.width(),g.height(),g.x(),g.y()):
            self.setGeometry(x,y,w,h)
        self._stable_window_geometry=self.geometry()

    def _analyzer_tab_changed(self, index: int) -> None:
        if hasattr(self, "vendor_cavitation_tab") and self.tabs.widget(index) is self.vendor_cavitation_tab:
            self._apply_vendor_tab_default_layout()
        QTimer.singleShot(0, lambda: (self._fit_current_tab(force=True), self._clamp_window_to_screen()))

    def _apply_vendor_tab_default_layout(self) -> None:
        """Restore the screenshot-approved CGA/Vendor composition for each new replay."""
        token = id(self.replay) if self.replay is not None else None
        if self._vendor_layout_token == token and token is not None:
            return
        self._vendor_layout_token = token
        if hasattr(self, "vendor_details_btn"):
            self.vendor_details_btn.setChecked(False)
        widgets = [
            (getattr(self, "vendor_view_combo", None), "All 8 receivers"),
            (getattr(self, "vendor_lower_mode_combo", None), "Both"),
        ]
        for widget, text in widgets:
            if widget is not None:
                widget.blockSignals(True); widget.setCurrentText(text); widget.blockSignals(False)
        for checkbox in (getattr(self, "vendor_smooth_check", None), getattr(self, "vendor_cursor_check", None), getattr(self, "vendor_legend_check", None)):
            if checkbox is not None:
                checkbox.blockSignals(True); checkbox.setChecked(True); checkbox.blockSignals(False)
        for checkbox in getattr(self, "vendor_series_checks", {}).values():
            checkbox.blockSignals(True); checkbox.setChecked(True); checkbox.blockSignals(False)
        if hasattr(self, "vendor_energy_plot"):
            self.vendor_energy_plot.setMinimumHeight(280)
        if hasattr(self, "vendor_power_plot"):
            self.vendor_power_plot.setMinimumHeight(245)
        if self.replay is not None:
            self._draw_vendor_cavitation()

    @staticmethod
    def _fit_plot(plot, *, x_range=None) -> None:
        if plot is None:
            return
        try:
            plot.enableAutoRange(axis=pg.ViewBox.XYAxes, enable=True)
            plot.autoRange(padding=0.025)
            if x_range is not None:
                plot.setXRange(float(x_range[0]), float(x_range[1]), padding=0.0)
        except Exception:
            pass

    @staticmethod
    def _finite_range(values):
        try:
            arr=np.asarray(values,dtype=float).reshape(-1)
            arr=arr[np.isfinite(arr)]
            if arr.size:
                lo=float(np.min(arr)); hi=float(np.max(arr))
                if hi <= lo:
                    eps=max(0.05,abs(lo)*0.01)
                    return (lo-eps,hi+eps)
                return (lo,hi)
        except Exception:
            pass
        return None

    def _plot_data_x_range(self, plot):
        """Return the real finite X extent of data items already drawn.

        Infinite irradiation markers and labels are intentionally ignored.  This
        keeps every Analyzer tab fitted to the interval where payload actually
        exists instead of to MR duration or an annotation outside the payload.
        """
        if plot is None:
            return None
        xs=[]
        try:
            for item in plot.listDataItems():
                x,_y=item.getData()
                if x is not None:
                    a=np.asarray(x,dtype=float).reshape(-1)
                    a=a[np.isfinite(a)]
                    if a.size: xs.append(a)
        except Exception:
            pass
        if xs:
            return self._finite_range(np.concatenate(xs))
        # ImageItems (spectrogram/heatmap) do not appear in listDataItems().
        try:
            for item in plot.items():
                if isinstance(item, pg.ImageItem):
                    r=item.mapRectToParent(item.boundingRect())
                    if r.width() > 0:
                        xs.append(np.asarray([r.left(),r.right()],dtype=float))
        except Exception:
            pass
        return self._finite_range(np.concatenate(xs)) if xs else None

    def _fit_current_tab(self, *, force: bool = False) -> None:
        if not hasattr(self, "tabs"):
            return
        page=self.tabs.currentWidget()
        plots=[]
        if page is getattr(self, "raw_tab", None):
            plots=list(getattr(self, "raw_plots", []))
        elif page is getattr(self, "spectrum_tab", None):
            plots=list(getattr(self, "spectrum_plots", []))
        elif page is getattr(self, "spectrogram_tab", None):
            plots=[getattr(self, "spectrogram_plot", None)]
        elif page is getattr(self, "band_tab", None):
            plots=[getattr(self, "band_plot", None)]
        elif page is getattr(self, "vendor_cavitation_tab", None):
            plots=[getattr(self, "vendor_energy_plot", None),getattr(self, "vendor_power_plot", None)]
        elif page is getattr(self, "cavitation_events_tab", None):
            plots=[getattr(self, "cavitation_control_plot", None)]
        elif page is getattr(self, "navigator_tab", None):
            plots=[getattr(self, "cavitation_likelihood_plot", None),getattr(self, "cavitation_heatmap_plot", None)]
        for plot in plots:
            xr=self._plot_data_x_range(plot)
            self._fit_plot(plot,x_range=xr)

    def _fit_all_data_views(self, *, force: bool = False) -> None:
        plots=[]
        plots.extend(getattr(self, "raw_plots", []))
        plots.extend(getattr(self, "spectrum_plots", []))
        for name in ("spectrogram_plot", "band_plot", "vendor_energy_plot", "vendor_power_plot", "cavitation_control_plot",
                     "cavitation_likelihood_plot", "cavitation_heatmap_plot"):
            plots.append(getattr(self,name,None))
        for plot in plots:
            xr=self._plot_data_x_range(plot)
            self._fit_plot(plot,x_range=xr)

    def _open_loaded_export(self):
        if self.package is None:
            QMessageBox.information(
                self, "Spectrum Dump Analyzer",
                "No Export is currently loaded in Sonication Analysis."
            )
            return
        self.open_loaded_workspace(self.package.workspace)

    def _open_export_zip(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "Open Export ZIP", "", "ZIP files (*.zip)")
        if file_name: self.open_dump_source(Path(file_name))

    def _open_dump_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Open folder containing Spectrum dumps")
        if folder: self.open_dump_source(Path(folder))

    def _open_dump_file(self):
        file_name, _ = QFileDialog.getOpenFileName(
            self, "Open Spectrum dump", "",
            "Spectrum dumps (*.dmp *.dmp_FFT);;All files (*.*)"
        )
        if file_name: self.open_dump_source(Path(file_name))

    def open_loaded_workspace(self, workspace: Path, *, auto_pick: bool = False) -> bool:
        """Use Spectrum files from the Export workspace already loaded by Sonication Analysis.

        No ZIP is extracted a second time.  The existing Replay workspace is scanned
        recursively, candidates are paired exactly as in standalone import, and the
        user can choose the logical Spectrum measurement to display.
        """
        workspace = Path(workspace).resolve()
        self._set_subwindow_progress(10, "Indexing loaded Export Spectrum sources…")
        try:
            if self.package is not None and Path(self.package.workspace).resolve() == workspace:
                candidates = self.dump_importer.discover_from_files(
                    workspace, list(getattr(self.package, "cpc_spectrum_files", []) or [])
                )
                if not any(c.family == "CPC Spectrum" for c in candidates):
                    candidates = self.dump_importer.discover(workspace)
            else:
                candidates = self.dump_importer.discover(workspace)
        except Exception as exc:
            QMessageBox.critical(self, "Spectrum Dump Analyzer", str(exc))
            return False
        if not candidates:
            self._set_subwindow_progress(None)
            QMessageBox.information(
                self, "Spectrum Dump Analyzer",
                "No compatible Spectrum*.dmp / Spectrum*.dmp_FFT file was found in the loaded Export."
            )
            return False

        self._set_subwindow_progress(35, f"Found {len(candidates)} Spectrum candidate(s)")
        candidate = candidates[0]
        if len(candidates) > 1 and not auto_pick:
            # The picker is an intentional user-interaction point; release the
            # exclusive busy window before opening it, then resume progress
            # after a source is selected.
            if getattr(self,"_exclusive_progress",None) is not None: self._exclusive_progress.finish()
            picker = SpectrumDumpPickerDialog(candidates, self)
            picker.setWindowTitle("Select Spectrum dump from loaded Export")
            if picker.exec() != QDialog.DialogCode.Accepted:
                return False
            candidate = picker.selected_candidate()
            if candidate is None:
                return False

        # This source only references the already-owned Sonication Analysis
        # workspace.  It must never be deleted by the Spectrum importer.
        from src.services.spectrum_dump_import_service import SpectrumDumpSource
        self.dump_source = SpectrumDumpSource(
            source=workspace, workspace=workspace, candidates=candidates, temporary=False
        )
        self.source_entries = []
        self._loaded_sonication_index = None
        self.sonication_combo.blockSignals(True); self.sonication_combo.clear()
        for i, item in enumerate(candidates):
            label=f"{item.family}: {item.label} [{item.completeness}]"
            self.sonication_combo.addItem(label, i)
            self.sonication_combo.setItemData(self.sonication_combo.count()-1,label,Qt.ItemDataRole.ToolTipRole)
        selected_index = candidates.index(candidate)
        self.sonication_combo.setCurrentIndex(selected_index); self.sonication_combo.blockSignals(False)
        self._set_subwindow_progress(55, "Spectrum source selected; scheduling background decode…", pump_events=False)
        source_token = self.dump_source
        QTimer.singleShot(0, lambda src=source_token, idx=selected_index: self._continue_dump_candidate(src, idx))
        return True

    def open_dump_source(self, source: Path):
        source=Path(source).expanduser().resolve()
        # If the user picks the same Export ZIP already owned by the main Replay,
        # never extract it a second time into a private Spectrum temp directory.
        # Reuse the adopted workspace and authoritative CPC inventory instead.
        package=getattr(self, "package", None)
        if package is not None:
            try:
                package_source=Path(getattr(package, "source", "")).expanduser().resolve()
            except Exception:
                package_source=None
            if package_source is not None and source == package_source:
                self._set_subwindow_progress(8, "Reusing loaded Export workspace…")
                candidates=self.dump_importer.discover_from_files(
                    Path(package.workspace), list(getattr(package, "cpc_spectrum_files", []) or [])
                )
                if not any(c.family == "CPC Spectrum" for c in candidates):
                    candidates=self.dump_importer.discover(Path(package.workspace))
                from src.services.spectrum_dump_import_service import SpectrumDumpSource
                result=SpectrumDumpSource(
                    source=source, workspace=Path(package.workspace),
                    candidates=candidates, temporary=False
                )
            else:
                result=None
        else:
            result=None
        self._set_subwindow_progress(10, "Opening Spectrum source…")
        try:
            if result is None:
                result = self.dump_importer.open_source(source)
        except Exception as exc:
            self._set_subwindow_progress(None)
            QMessageBox.critical(self, "Spectrum Dump Analyzer", str(exc)); return
        if not result.candidates:
            self._set_subwindow_progress(None)
            QMessageBox.information(
                self, "Spectrum Dump Analyzer",
                "No compatible Spectrum*.dmp / Spectrum*.dmp_FFT file was found."
            ); return
        self._set_subwindow_progress(35, f"Found {len(result.candidates)} Spectrum candidate(s)")
        candidate = result.candidates[0]
        if len(result.candidates) > 1:
            if getattr(self,"_exclusive_progress",None) is not None: self._exclusive_progress.finish()
            picker = SpectrumDumpPickerDialog(result.candidates, self)
            if picker.exec() != QDialog.DialogCode.Accepted:
                return
            candidate = picker.selected_candidate()
            if candidate is None: return
        self.dump_source = result
        # Candidate-only mode must not retain the package-mode source_entries.
        # Otherwise combo changes are interpreted as Sonication rows and can
        # dispatch the wrong loader after Open ZIP / Open Folder.
        self.source_entries = []
        self._loaded_sonication_index = None
        # Keep any loaded Sonication Analysis package as reusable context so
        # the user can return to "Select From Loaded Export" without loading
        # the treatment ZIP again.
        self.sonication_combo.blockSignals(True); self.sonication_combo.clear()
        for i, item in enumerate(result.candidates):
            label=f"{item.family}: {item.label} [{item.completeness}]"
            self.sonication_combo.addItem(label, i)
            self.sonication_combo.setItemData(self.sonication_combo.count()-1,label,Qt.ItemDataRole.ToolTipRole)
        selected_index = result.candidates.index(candidate)
        self.sonication_combo.setCurrentIndex(selected_index); self.sonication_combo.blockSignals(False)
        self._set_subwindow_progress(55, "Spectrum source selected; scheduling background decode…", pump_events=False)
        source_token = self.dump_source
        QTimer.singleShot(0, lambda src=source_token, idx=selected_index: self._continue_dump_candidate(src, idx))

    def _continue_dump_candidate(self, source_token, selected_index: int) -> None:
        """Start a scheduled candidate decode only if the source is still current."""
        if source_token is None or self.dump_source is not source_token:
            return
        self._set_subwindow_progress(56, "Starting background Spectrum decoder…")
        self.load_dump_candidate(int(selected_index))

    def _start_dump_decode(self, index: int, candidate: SpectrumDumpCandidate, *, sonication_index: int | None = None) -> None:
        """Start one CPC Spectrum decode without blocking Qt."""
        self._decode_request_id += 1
        request_id = int(self._decode_request_id)
        self._decode_context = {
            "kind": "sonication" if sonication_index is not None else "dump",
            "index": int(index),
            "candidate": candidate,
            "sonication_index": int(sonication_index) if sonication_index is not None else None,
        }

        # A stale worker is allowed to finish naturally; its signals are ignored
        # by request id.  This avoids unsafe QThread.terminate() while keeping the
        # newest source authoritative.
        thread = QThread(self)
        worker = SpectrumDecodeWorker(request_id, candidate.fft_path, candidate.raw_path)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._dump_decode_progress)
        worker.ready.connect(self._dump_decode_ready)
        worker.failed.connect(self._dump_decode_failed)
        worker.ready.connect(lambda *_: thread.quit())
        worker.failed.connect(lambda *_: thread.quit())
        thread.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(lambda rid=request_id, t=thread: self._dump_decode_thread_finished(rid, t))
        self._decode_thread = thread
        self._decode_worker = worker
        self._decode_started_monotonic = time.monotonic()
        self._decode_last_progress = 56
        self._decode_last_message = "Starting background FFT / RAW decode…"
        self._set_subwindow_progress(56, "SpectrumDumps: starting background FFT / RAW decode…")
        self.source_label.setText(f"Decoding CPC Spectrum: {candidate.label} …")
        self._decode_heartbeat.start()
        thread.start(QThread.Priority.NormalPriority)

    def _dump_decode_progress(self, request_id: int, value: int, message: str) -> None:
        if int(request_id) != int(self._decode_request_id):
            return
        # 55..82 is reserved for the actual decoder.  Unlike the old synchronous
        # path, these queued signals are painted immediately by the GUI thread.
        mapped = 56 + int(max(0, min(100, int(value))) * 0.26)
        mapped = min(82, mapped)
        self._decode_last_progress = mapped
        self._decode_last_message = str(message)
        elapsed = 0.0 if self._decode_started_monotonic is None else max(0.0, time.monotonic() - self._decode_started_monotonic)
        self._set_subwindow_progress(mapped, f"{message}  |  elapsed {elapsed:.1f} s")
        if self._decode_context and self._decode_context.get("candidate") is not None:
            candidate = self._decode_context["candidate"]
            self.source_label.setText(f"Decoding {candidate.label}: {message}")

    def _update_decode_heartbeat(self) -> None:
        thread = getattr(self, "_decode_thread", None)
        if thread is None or not thread.isRunning():
            self._decode_heartbeat.stop()
            return
        elapsed = 0.0 if self._decode_started_monotonic is None else max(0.0, time.monotonic() - self._decode_started_monotonic)
        detail = f"{self._decode_last_message or 'Spectrum decode running…'}  |  elapsed {elapsed:.1f} s"
        self.subwindow_progress_label.setText(detail)
        dlg = getattr(self, "_exclusive_progress", None)
        if dlg is not None and dlg.isVisible():
            dlg.detail_label.setText(detail)

    def _dump_decode_ready(self, request_id: int, replay) -> None:
        if int(request_id) != int(self._decode_request_id):
            return
        self._decode_heartbeat.stop()
        context = dict(self._decode_context or {})
        candidate = context.get("candidate")
        index = int(context.get("index", 0))
        if candidate is None:
            self._dump_decode_failed(request_id, "Decode completed without a candidate context.")
            return
        self.replay = replay
        # If this worker was launched for a mapped Sonication, retain the decoded
        # replay under that Sonication index so subsequent navigation is instant.
        sonication_cache_index = context.get("sonication_index") if context.get("kind") == "sonication" else None
        if sonication_cache_index is not None and self.package is not None:
            self._preloaded_replays[int(sonication_cache_index)] = replay
            self._bind_sonication_timebase(int(sonication_cache_index), candidate)
        self._set_subwindow_progress(83, "Applying receiver calibration / enabled-channel mask…")
        self._apply_authoritative_calibration_mask()
        QApplication.processEvents()
        self._set_subwindow_progress(84, "SpectrumDumps: publishing decoded RCV0–RCV7 data…")

        fft = self.replay.source_fft.name if self.replay.source_fft else "No FFT companion"
        raw = self.replay.source_raw.name if self.replay.source_raw else "No RAW companion"
        cal = self.replay.calibration_ini.name if self.replay.calibration_ini else "Not found"
        response = self.replay.response_ini.name if self.replay.response_ini else "Not found"
        session=getattr(self.replay,"acquisition_session_index",None)
        session_txt=(f" | Acquisition session {int(session)+1} [{getattr(self.replay,'mapping_confidence','Unknown')}]" if session is not None else "")
        self.source_label.setText(f"Decoded {len(self.replay.frames)} frame(s) | FFT: {fft} | RAW: {raw} | Calibration: {cal} | Response: {response}{session_txt}")
        factors = ", ".join(f"RCV{i}={v:.6g}" for i, v in enumerate(self.replay.spectrum_factors))
        axis_audit = ""
        if self.replay.frequency_start_hz is not None and self.replay.frequency_spacing_hz is not None and self.replay.frequency_end_hz is not None:
            axis_audit = (f"\nFrequency axis audit: {self.replay.frequency_axis_source}; "
                          f"{self.replay.frequency_start_hz/1e3:.3f}–{self.replay.frequency_end_hz/1e3:.3f} kHz; "
                          f"Δf={self.replay.frequency_spacing_hz:.6f} Hz; "
                          f"f0 bin error={self.replay.main_frequency_bin_error_hz:+.3f} Hz." if self.replay.main_frequency_bin_error_hz is not None else "")
        self.note.setText(self.replay.note + axis_audit + f"\nApplied calibration audit: SpectrumCoef={self.replay.spectrum_coef:.6g}; {factors}; response points={self.replay.response_point_count}.")
        count = len(self.replay.frames)
        self.slider.setRange(0, max(0, count-1))
        self.measure_spin.setRange(1, max(1, count))
        self._set_subwindow_progress(86, "Publishing first FFT frame…")
        self._set_frame_primary_only(0)
        QApplication.processEvents()

        # Primary FFT data are already visible after the lightweight first-frame publish.  Defer the
        # heavier spectrogram/Vendor/Cavitation products to the next event turn
        # so standalone Open ZIP can never appear frozen at 55%.
        self._set_subwindow_progress(90, f"Spectrum displayed — {count} FFT frame(s); finishing secondary analysis…")
        replay_token = self.replay
        QTimer.singleShot(0, lambda r=replay_token: self._finish_secondary_replay_publish(r))

    def _hide_decode_progress_if_current(self, request_id: int) -> None:
        if int(request_id) == int(self._decode_request_id):
            self._set_subwindow_progress(None)

    def _dump_decode_failed(self, request_id: int, message: str) -> None:
        if int(request_id) != int(self._decode_request_id):
            return
        self._decode_heartbeat.stop()
        self.replay = None
        self.slider.setRange(0, 0)
        self.measure_spin.setRange(1, 1)
        self.source_label.setText("Spectrum decode failed — see details")
        self.note.setText(str(message))
        self.note.setVisible(True)
        self.source_details_btn.setChecked(True)
        self._set_subwindow_progress(None)
        QMessageBox.critical(self, "Spectrum Dump Analyzer", f"Spectrum data could not be decoded.\n\n{message}")

    def _dump_decode_thread_finished(self, request_id: int, thread) -> None:
        if int(request_id) == int(self._decode_request_id) and self._decode_thread is thread:
            self._decode_thread = None
            self._decode_worker = None

    def load_dump_candidate(self, index: int):
        if self.dump_source is None or not (0 <= index < len(self.dump_source.candidates)):
            return
        # R0116zk: Open ZIP used to show 55% and then run the full Cavitation UI
        # reset before even starting the decoder. That is the standalone twin of
        # the former 58% preload stall. Invalidate stale workers and do only the
        # cheap ownership reset until primary Spectrum is visible.
        self._decode_request_id += 1
        self._decode_context = None
        self._decode_heartbeat.stop()
        self._reset_replay_state_fast()
        candidate = self.dump_source.candidates[index]
        if candidate.family == "SpectrumMsg":
            self.replay = None
            self.source_label.setText(f"SpectrumMsg: {candidate.primary_path.name}")
            self.note.setText(
                "SpectrumMsg is a reduced workstation/message stream. It is detected and selectable, "
                "but this independent 8CH CPC view does not invent channel identities from it. "
                "Use the main Sonication Spectrum view for SpectrumMsg analysis."
            )
            self.slider.setRange(0, 0); self.measure_spin.setRange(1, 1); self.set_frame(0)
            self._set_subwindow_progress(None)
            return
        if candidate.fft_path is None:
            self._dump_decode_failed(self._decode_request_id,
                f"Selected CPC measurement has no matching *_FFT companion: {candidate.label}")
            return
        self._start_dump_decode(index, candidate)

    def dragEnterEvent(self, event):
        if any(url.isLocalFile() for url in event.mimeData().urls()):
            event.acceptProposedAction()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            if not url.isLocalFile(): continue
            path = Path(url.toLocalFile())
            if path.is_dir() or path.suffix.lower() == ".zip" or "spectrum" in path.name.lower():
                self.open_dump_source(path); event.acceptProposedAction(); return

    def load_package(self, package, sonication_index: int, *, select_from_loaded_export: bool = False):
        """Load Sonication sources and ADD SpectrumDumps from the loaded Export.

        The original Sonication choices are always preserved. SpectrumDumps are
        additional selectable sources, never replacements.
        """
        self._set_subwindow_progress(8, "Loading Export context…")
        self.package = package
        self.open_loaded_export_btn.setEnabled(True)
        candidates = self.dump_importer.discover_from_files(Path(package.workspace), list(getattr(package, "cpc_spectrum_files", []) or []))
        self._set_subwindow_progress(30, f"Discovered {len(candidates)} Spectrum source(s)")
        from src.services.spectrum_dump_import_service import SpectrumDumpSource
        self.dump_source = SpectrumDumpSource(source=Path(package.workspace), workspace=Path(package.workspace), candidates=candidates, temporary=False) if candidates else None
        # R0116v: one authoritative mapping is shared by Sonication loading,
        # Hydrophone x Band, Probable Location and Cavitation analysis.  Do not
        # rediscover/map the same SpectrumDumps independently in each tab.
        self._sonication_dump_map = self.dump_importer.map_candidates_to_sonications(candidates, package.sonications)
        self.source_entries = []
        self.sonication_combo.blockSignals(True); self.sonication_combo.clear()
        for i, son in enumerate(package.sonications):
            self.source_entries.append(("sonication", i))
            label=f"Sonication / {son.name}"
            self.sonication_combo.addItem(label)
            self.sonication_combo.setItemData(self.sonication_combo.count()-1,label,Qt.ItemDataRole.ToolTipRole)
        for i, candidate in enumerate(candidates):
            # Avoid duplicating Sonication-local SpectrumMsg entries as a second
            # physical 8CH source. CPC SpectrumDumps are the intended additions.
            if candidate.family == "SpectrumMsg":
                continue
            self.source_entries.append(("dump", i))
            label=f"SpectrumDumps / {candidate.label} [{candidate.completeness}]"
            self.sonication_combo.addItem(label)
            self.sonication_combo.setItemData(self.sonication_combo.count()-1,label,Qt.ItemDataRole.ToolTipRole)
        target_row = next((row for row, entry in enumerate(self.source_entries) if entry == ("sonication", max(0, sonication_index))), 0)
        self.sonication_combo.setCurrentIndex(target_row); self.sonication_combo.blockSignals(False)
        self._set_subwindow_progress(50, "Loading selected Sonication source…")
        # Completion is owned by the actual decode/publish path. Do not announce
        # 100% here while an asynchronous worker or deferred publish is running.
        self._load_source_entry(target_row)

    def _load_source_entry(self, row: int):
        if not (0 <= row < len(self.source_entries)):
            return
        kind, index = self.source_entries[row]
        if kind == "dump":
            self.load_dump_candidate(index)
        else:
            self.load_sonication(index)

    def load_sonication(self, index: int):
        if self.package is None:
            return
        index = max(0, min(int(index), max(0, len(self.package.sonications)-1)))
        # R0116zj: never perform the expensive secondary-widget reset before
        # publishing the first FFT frame.  Advance the visible stage first, then
        # reset only cheap ownership state.
        self._set_subwindow_progress(60, "Adopting decoded Spectrum replay…")
        QApplication.processEvents()
        self._reset_replay_state_fast()
        self._set_subwindow_progress(62, "Resolving selected Sonication Spectrum source…")
        QApplication.processEvents()

        discovered = len(self.dump_source.candidates) if self.dump_source is not None else 0
        physical = [c for c in (self.dump_source.candidates if self.dump_source is not None else []) if c.family == "CPC Spectrum"]
        candidate = getattr(self, "_sonication_dump_map", {}).get(index)
        mapped = candidate is not None

        cached = self._preloaded_replays.get(index)
        if cached is not None:
            self.replay = cached
            route = "background preload cache"
            candidate = getattr(self, "_sonication_dump_map", {}).get(index)
            mapped = candidate is not None
        # Primary route: use the exact SpectrumDumps candidate already discovered
        # from the loaded Export.  This removes the old split path where the UI
        # could discover SpectrumDumps but load_sonication() only consulted
        # package.cpc_spectrum_files and therefore decoded nothing.
        if cached is None and candidate is not None:
            # R0116zg: Sonication selection must never synchronously decode CPC on
            # the GUI thread.  This was a second, older decode path that bypassed
            # SpectrumDecodeWorker and could leave the Analyzer at "No data".
            # Route the exact mapped candidate through the same worker used by
            # standalone SpectrumDumps and publish only when frames are ready.
            self.source_label.setText(f"Loading mapped CPC Spectrum source: {candidate.label} …")
            try:
                candidate_index = list(self.dump_source.candidates).index(candidate) if self.dump_source is not None else index
            except ValueError:
                candidate_index = index
            self._loaded_sonication_index = index
            self._start_dump_decode(candidate_index, candidate, sonication_index=index)
            return
        elif cached is None:
            # Treatment Export with physical CPC data must never fall back to a
            # positional "latest N" selector.  If the authoritative binding cannot
            # prove this Sonication's CPC identity, show an explicit unresolved
            # state rather than displaying data from another sonication.
            if physical:
                self.replay = self.service.build_direct(None, None)
                route = "UNRESOLVED CPC / SONICATION BINDING"
                self.source_label.setText(
                    f"CPC binding unresolved for Sonication {index+1}; {len(physical)} physical CPC pair(s) discovered. "
                    "No positional substitution was made."
                )
            else:
                fft_path, raw_path = self.service.select_files(
                    self.package.cpc_spectrum_files, index, len(self.package.sonications)
                )
                if fft_path is not None:
                    fallback_candidate = SpectrumDumpCandidate(
                        label=(raw_path or fft_path).name, raw_path=raw_path, fft_path=fft_path,
                        relative_path=str(fft_path), family="CPC Spectrum"
                    )
                    self.source_label.setText(f"Loading CPC source: {(fft_path or raw_path).name} …")
                    self._loaded_sonication_index = index
                    self._start_dump_decode(index, fallback_candidate, sonication_index=index)
                    return
                self.replay = self.service.build_direct(None, None)
                route = "NO CPC PAIR"

        self._set_subwindow_progress(63, "Aligning CPC / Acquisition / Sonication time base…")
        self._bind_sonication_timebase(index, candidate)
        self._set_subwindow_progress(64, "Applying receiver calibration / enabled-channel mask…")
        self._apply_authoritative_calibration_mask()
        QApplication.processEvents()
        self._loaded_sonication_index = index
        decoded = len(self.replay.frames)
        self._set_subwindow_progress(72, "Preparing decoded Spectrum metadata…")

        fft = self.replay.source_fft.name if self.replay.source_fft else "No FFT"
        raw = self.replay.source_raw.name if self.replay.source_raw else "No raw"
        cal = self.replay.calibration_ini.name if self.replay.calibration_ini else "Not found"
        response = self.replay.response_ini.name if self.replay.response_ini else "Not found"
        session=getattr(self.replay,"acquisition_session_index",None)
        session_txt=(f" | Acquisition session {int(session)+1} [{getattr(self.replay,'mapping_confidence','Unknown')}]" if session is not None else "")
        self.source_label.setText(
            f"Discovered {discovered} ({len(physical)} CPC) | Mapped {'YES' if mapped else 'NO'} | "
            f"Decoded {decoded} frame(s) | FFT: {fft} | RAW: {raw} | Calibration: {cal} | Response: {response}{session_txt}"
        )

        factors = ", ".join(f"RCV{i}={v:.6g}" for i, v in enumerate(self.replay.spectrum_factors))
        axis_audit = ""
        if self.replay.frequency_start_hz is not None and self.replay.frequency_spacing_hz is not None and self.replay.frequency_end_hz is not None:
            axis_audit = (f"\nFrequency axis audit: {self.replay.frequency_axis_source}; "
                          f"{self.replay.frequency_start_hz/1e3:.3f}–{self.replay.frequency_end_hz/1e3:.3f} kHz; "
                          f"Δf={self.replay.frequency_spacing_hz:.6f} Hz; "
                          f"f0 bin error={self.replay.main_frequency_bin_error_hz:+.3f} Hz." if self.replay.main_frequency_bin_error_hz is not None else "")
        connection_audit = (
            f"\nSource connection audit: Sonication {index+1}; discovered={discovered}; physical CPC={len(physical)}; "
            f"mapped={'yes' if mapped else 'no'}; decoded={decoded}; route={route}; "
            f"Acquisition session={('-' if session is None else int(session)+1)}; "
            f"mapping={getattr(self.replay,'mapping_evidence','Unresolved')}."
        )
        self.note.setText(self.replay.note + axis_audit + connection_audit +
                          f"\nApplied calibration audit: SpectrumCoef={self.replay.spectrum_coef:.6g}; {factors}; response points={self.replay.response_point_count}.")

        count = len(self.replay.frames)
        self.slider.setRange(0, max(0, count-1))
        self.measure_spin.setRange(1, max(1, count))
        self._set_subwindow_progress(82, "Publishing first FFT frame…")
        self._set_frame_primary_only(0)
        QApplication.processEvents()

        if count <= 0:
            # Keep the failure visible in every data tab rather than presenting
            # an apparently valid empty chart.
            self._set_subwindow_progress(None)
            self.note.setText(self.note.text() + "\nERROR: Spectrum source was discovered/mapped but no 8CH FFT frames were decoded.")
            return

        # Primary FFT data are now visible.  Do not make the user wait for all
        # secondary Vendor/Cavitation products before seeing Spectrum data.
        self._set_subwindow_progress(90, f"Spectrum displayed — {count} FFT frame(s); finishing secondary analysis…")
        replay_token = self.replay
        QTimer.singleShot(0, lambda r=replay_token: self._finish_secondary_replay_publish(r))

    def _finish_secondary_replay_publish(self, replay_token) -> None:
        """Finish secondary views as discrete Qt event-loop stages."""
        if replay_token is None or self.replay is not replay_token:
            return
        self._set_subwindow_progress(91, "Clearing previous secondary analysis views…", pump_events=False)
        try:
            self._clear_secondary_analysis_views()
        except Exception as exc:
            self.note.setText(self.note.text() + f"\nSecondary clear warning: {type(exc).__name__}: {exc}")
        QTimer.singleShot(0, lambda r=replay_token: self._finish_secondary_spectrogram(r))

    def _finish_secondary_spectrogram(self, replay_token) -> None:
        if replay_token is None or self.replay is not replay_token:
            return
        self._set_subwindow_progress(92, "Rendering spectrogram / band energy…", pump_events=False)
        try:
            self._draw_spectrogram()
            self._draw_band_energy()
        except Exception as exc:
            self.note.setText(self.note.text() + f"\nSpectrogram/Band warning: {type(exc).__name__}: {exc}")
        QTimer.singleShot(0, lambda r=replay_token: self._finish_secondary_vendor(r))

    def _finish_secondary_vendor(self, replay_token) -> None:
        if replay_token is None or self.replay is not replay_token:
            return
        self._set_subwindow_progress(96, "Rendering Vendor / CGA views…", pump_events=False)
        try:
            self._apply_vendor_band_defaults()
            self._draw_vendor_cavitation()
        except Exception as exc:
            self.note.setText(self.note.text() + f"\nVendor/CGA warning: {type(exc).__name__}: {exc}")
        QTimer.singleShot(0, lambda r=replay_token: self._finish_secondary_cavitation(r))

    def _finish_secondary_cavitation(self, replay_token) -> None:
        if replay_token is None or self.replay is not replay_token:
            return
        self._set_subwindow_progress(98, "Evaluating cavitation evidence…", pump_events=False)
        try:
            self._refresh_cavitation_analysis()
            detail = f"Ready — {len(self.replay.frames)} decoded FFT frame(s)"
        except Exception as exc:
            self.note.setText(self.note.text() + f"\nCavitation analysis warning: {type(exc).__name__}: {exc}")
            detail = f"Spectrum ready — cavitation analysis warning: {exc}"
        self._set_subwindow_progress(100, detail)
        QTimer.singleShot(0, lambda r=replay_token: self._fit_all_data_views(force=True) if self.replay is r else None)
        QTimer.singleShot(900, lambda r=replay_token: self._hide_publish_progress_if_current(r))

    def _hide_publish_progress_if_current(self, replay_token) -> None:
        if self.replay is replay_token:
            self._set_subwindow_progress(None)

    def sync_sonication(self, index: int):
        index = int(index)
        row = next((r for r, entry in enumerate(self.source_entries) if entry == ("sonication", index)), -1)
        if row >= 0:
            self.sonication_combo.blockSignals(True)
            self.sonication_combo.setCurrentIndex(row)
            self.sonication_combo.blockSignals(False)
            if self._loaded_sonication_index != index:
                self.load_sonication(index)
            else:
                self._update_vendor_sync_cursors()
                self._update_vendor_current_marker()

    def _sonication_changed(self, index: int):
        if index < 0: return
        if self.source_entries:
            kind, source_index = self.source_entries[index]
            self._load_source_entry(index)
            if kind == "sonication": self.sonicationRequested.emit(source_index)
            return
        if self.dump_source is not None:
            self.load_dump_candidate(index); return
        self.load_sonication(index); self.sonicationRequested.emit(index)

    def _sync_cavitation_dynamic_views(self):
        """Synchronize every dynamic Cavitation tab to the current FFT snapshot."""
        if not self.replay or not self.replay.frames:
            return
        if hasattr(self,'cavitation_heatmap_cursor'):
            try: self.cavitation_heatmap_cursor.setPos(float(self.frame_index)+0.5)
            except Exception: pass
        if hasattr(self,'cavitation_heatmap_image'):
            self._render_direct_band_heatmap()
        analysis=getattr(self,'cavitation_analysis',None)
        table=getattr(self,'cavitation_event_table',None)
        if analysis is not None and table is not None and getattr(analysis,'events',None):
            target=None; best=None
            for row,event in enumerate(analysis.events):
                distance=abs(int(getattr(event,'snapshot_index',-999))-int(self.frame_index))
                if best is None or distance<best:
                    best=distance; target=row
            if target is not None:
                table.blockSignals(True); table.selectRow(int(target)); table.blockSignals(False)
        self._last_dynamic_frame_index=int(self.frame_index)

    def _set_frame_primary_only(self, index: int) -> None:
        """Publish the first usable FFT frame without secondary analysis.

        Initial Spectrum publish previously called set_frame(0), which also ran
        Vendor cursors, control replay, direct-band heatmap and Probable Location
        estimation.  Any one of those could block the GUI at 58/84% before the
        user saw a Spectrum curve.  This path updates only frame controls plus
        Raw/Spectrum/Statistics; all secondary products are deferred.
        """
        count = len(self.replay.frames) if self.replay else 0
        self.frame_index = max(0, min(int(index), max(0, count-1)))
        self.slider.blockSignals(True); self.slider.setValue(self.frame_index); self.slider.blockSignals(False)
        self.measure_spin.blockSignals(True); self.measure_spin.setValue(self.frame_index+1); self.measure_spin.blockSignals(False)
        interval = self.replay.frame_interval_s if self.replay else 0.010
        if self.replay and count and self.frame_index < len(self.replay.frames):
            frame = self.replay.frames[self.frame_index]
            actual_time = frame.acquisition_time_s if frame.acquisition_time_s is not None else self.frame_index * interval
            cycle_text = f" · Acquisition cycle {frame.acquisition_cycle}" if frame.acquisition_cycle is not None else ""
        else:
            actual_time = self.frame_index * interval
            cycle_text = ""
        self.frame_label.setText(f"FFT Snapshot {self.frame_index+1 if count else '-'} / {count or '-'} · Time {actual_time:.3f} s{cycle_text}")
        self._refresh_frame_views()

    def set_frame(self, index: int):
        count = len(self.replay.frames) if self.replay else 0
        self.frame_index = max(0, min(int(index), max(0, count-1)))
        self.slider.blockSignals(True); self.slider.setValue(self.frame_index); self.slider.blockSignals(False)
        self.measure_spin.blockSignals(True); self.measure_spin.setValue(self.frame_index+1); self.measure_spin.blockSignals(False)
        interval = self.replay.frame_interval_s if self.replay else 0.010
        if self.replay and count and self.frame_index < len(self.replay.frames):
            frame = self.replay.frames[self.frame_index]
            actual_time = frame.acquisition_time_s if frame.acquisition_time_s is not None else self.frame_index * interval
            cycle_text = f" · Acquisition cycle {frame.acquisition_cycle}" if frame.acquisition_cycle is not None else ""
        else:
            actual_time = self.frame_index * interval
            cycle_text = ""
        self.frame_label.setText(f"FFT Snapshot {self.frame_index+1 if count else '-'} / {count or '-'} · Time {actual_time:.3f} s{cycle_text}")
        if self.timer.isActive() and count and self.frame_index >= count-1:
            self.timer.stop(); self.play_btn.setText("▶")
        self._refresh_frame_views()
        self._update_vendor_sync_cursors()
        self._update_control_replay_cursor()
        self._update_vendor_current_marker()
        # Ordinary replay navigation releases only the Probable Location pin.
        # The selected-event red cursor/table highlight remains visible so it can
        # be compared against the independently moving white replay cursor.
        if not self._event_navigation_in_progress:
            self._probable_location_pinned_to_event=False
        self._sync_cavitation_dynamic_views()
        self._update_cavitation_likelihood()

    @staticmethod
    def _speed_factor_from_text(text: str) -> float:
        t=str(text or "1").replace("×", "").replace("Actual", "").strip()
        try: return max(0.01, float(t))
        except ValueError: return 1.0

    def _probable_speed_changed(self, _text: str):
        # The Probable Location tab uses the same replay timer/frame cursor as all
        # hydrophone views. Changing speed must not change the selected snapshot.
        if self.timer.isActive():
            interval = self.replay.frame_interval_s if self.replay else 0.010
            factor = self._speed_factor_from_text(self.probable_speed_combo.currentText()) if hasattr(self,'probable_speed_combo') else 1.0
            self.timer.start(max(10, int(interval*1000/max(factor,0.01))))

    def _toggle_play(self):
        if self.timer.isActive():
            self.timer.stop(); self.play_btn.setText("▶")
        else:
            if self.replay and self.replay.frames and self.frame_index >= len(self.replay.frames)-1: self.set_frame(0)
            interval = self.replay.frame_interval_s if self.replay else 0.010
            factor = self._speed_factor_from_text(self.probable_speed_combo.currentText()) if hasattr(self,'probable_speed_combo') else 1.0
            self.timer.start(max(10, int(interval*1000/max(factor,0.01)))); self.play_btn.setText("Ⅱ")

    def _bind_sonication_timebase(self, sonication_index: int, candidate: SpectrumDumpCandidate | None) -> None:
        """Bind the selected Sonication, CPC pair and Acquisition session to one identity."""
        if self.replay is None:
            return
        history=getattr(self.replay,"vendor_history_validation",None)
        validated_session=getattr(history,"log_session_index",None) if history is not None else None
        candidate_session=getattr(candidate,"acquisition_session_index",None) if candidate is not None else None
        session_index=validated_session if validated_session is not None else candidate_session
        self.replay.acquisition_session_index=session_index
        evidence=str(getattr(candidate,"mapping_evidence","Unresolved") if candidate is not None else "Unresolved")
        confidence=str(getattr(candidate,"mapping_confidence","Unknown") if candidate is not None else "Unknown")
        if validated_session is not None:
            evidence += f"; vendor Band0 history EXACT session {int(validated_session)+1}"
            confidence="Exact"
        self.replay.mapping_evidence=evidence
        self.replay.mapping_confidence=confidence
        if self.package is not None:
            canonical = getattr(self.package.sonications[int(sonication_index)], "canonical_acquisition_session_index", None) if 0 <= int(sonication_index) < len(self.package.sonications) else None
            if canonical is not None and session_index is None:
                session_index = int(canonical)
                self.replay.acquisition_session_index = session_index
            self.replay.sonication_time_zero_offset_s = AcousticControlService().sonication_time_zero_offset(
                Path(self.package.workspace), int(sonication_index), session_index
            )
            son = self.package.sonications[int(sonication_index)]
            self.replay.mr_timeline_duration_s = float(getattr(son, "mr_timeline_duration_s", 0.0) or 0.0)
            self.replay.mr_sonication_start_s = float(getattr(son, "mr_sonication_start_s", 0.0) or 0.0)
            self.replay.mr_sonication_end_s = float(getattr(son, "mr_sonication_end_s", 0.0) or 0.0)
            self.replay.mr_timeline_source = str(getattr(son, "mr_timeline_source", "Unavailable"))
            self.replay.mr_timeline_confidence = str(getattr(son, "mr_timeline_confidence", "Unknown"))
        else:
            self.replay.sonication_time_zero_offset_s=0.0
            self.replay.mr_timeline_duration_s=0.0
            self.replay.mr_sonication_start_s=0.0
            self.replay.mr_sonication_end_s=0.0

    def _apply_authoritative_calibration_mask(self) -> None:
        """Use package Calibration.ini IsEnabled for RCV visibility whenever available."""
        if self.replay is None:
            return
        calibration=None
        try:
            if self.package is not None and getattr(self.package,"workspace",None):
                calibration=HydrophoneCalibrationService().read(Path(self.package.workspace))
        except Exception:
            calibration=None
        if calibration is not None and calibration.calibration_ini is not None:
            self.replay.receiver_enabled=tuple(bool(v) for v in calibration.is_enabled)
            self.replay.calibration_ini=calibration.calibration_ini
            self.replay.response_ini=calibration.response_ini
            self.replay.spectrum_coef=float(calibration.spectrum_coef)
            self.replay.spectrum_factors=tuple(float(v) for v in calibration.spectrum_factors)
        self._update_disabled_receiver_controls()

    def _update_disabled_receiver_controls(self) -> None:
        show=bool(getattr(self,"show_disabled_receivers_check",None) and self.show_disabled_receivers_check.isChecked())
        visible=set(ch for ch in range(8) if show or self._receiver_enabled(ch))
        if visible and self.channel_spin.value() not in visible:
            self.channel_spin.blockSignals(True); self.channel_spin.setValue(min(visible)); self.channel_spin.blockSignals(False)
        if hasattr(self,"vendor_receiver_combo"):
            for ch in range(min(8,self.vendor_receiver_combo.count())):
                item=self.vendor_receiver_combo.model().item(ch)
                if item is not None:
                    item.setEnabled(ch in visible)
        for ch in range(8):
            key=f"rcv{ch}"
            cell=getattr(self,"vendor_series_cells",{}).get(key)
            if cell is not None:
                cell.setVisible(ch in visible)
        enabled_text=', '.join(f'RCV{ch}' for ch in range(8) if self._receiver_enabled(ch)) or 'none'
        if hasattr(self,"show_disabled_receivers_check"):
            self.show_disabled_receivers_check.setToolTip(
                f"Calibration.ini IsEnabled: enabled {enabled_text}. Disabled receivers are hidden unless checked."
            )

    def _receiver_enabled(self, ch: int) -> bool:
        values=getattr(self.replay,"receiver_enabled",(True,)*8) if self.replay is not None else (True,)*8
        return bool(values[ch]) if 0 <= int(ch) < len(values) else True

    def _visible_receivers(self):
        show=bool(getattr(self,"show_disabled_receivers_check",None) and self.show_disabled_receivers_check.isChecked())
        return [ch for ch in range(8) if show or self._receiver_enabled(ch)]

    def _disabled_receiver_visibility_changed(self, _checked=False):
        self._update_disabled_receiver_controls()
        self._refresh_all()

    def _refresh_all(self):
        self._refresh_frame_views(); self._draw_spectrogram(); self._draw_band_energy(); self._draw_vendor_cavitation()

    def _refresh_frame_views(self):
        self._draw_raw(); self._draw_spectrum(); self._draw_statistics()
        self._set_mr_xrange(*getattr(self, "raw_plots", []))

    def _draw_raw(self):
        for plot in getattr(self, "raw_plots", []): plot.clear()
        if not self.replay or not self.replay.frames or not self.raw_plots: return
        frame = self.replay.frames[self.frame_index]
        if not frame.raw_channels:
            if self.replay.raw_timeline_channels:
                t = self.replay.mr_raw_timeline_time_s
                mode = self.raw_mode.currentText()
                channels = self._visible_receivers() if mode != "Single CH" else [self.channel_spin.value()]
                if mode == "8 Panels":
                    visible=set(self._visible_receivers())
                    for ch, plot in enumerate(self.raw_plots):
                        if ch not in visible:
                            plot.setTitle(f"RCV{ch} disabled by calibration.ini"); continue
                        y = self.replay.raw_timeline_channels[ch]
                        plot.plot(t[:len(y)], y, pen=pg.intColor(ch, 8))
                        plot.setLabel("bottom", "MR acquisition time", units="s")
                        plot.setLabel("left", "History value")
                        plot.setTitle(f"RCV{ch} measurement history")
                else:
                    plot = self.raw_plots[0]
                    for ch in channels:
                        y = self.replay.raw_timeline_channels[ch]
                        plot.plot(t[:len(y)], y, pen=pg.intColor(ch, 8), name=f"RCV{ch}")
                    plot.setLabel("bottom", "MR acquisition time", units="s")
                    plot.setLabel("left", "History value")
                    suffix = "Raw A/D payload is not present in this export"
                    plot.setTitle(f"Validated CPC 8CH measurement history — {suffix}")
            else:
                self.raw_plots[0].setTitle("CPC raw companion container not decoded")
            return
        mode = self.raw_mode.currentText()
        channels = self._visible_receivers() if mode != "Single CH" else [self.channel_spin.value()]
        common = max((float(np.max(np.abs(frame.raw_channels[ch]))) for ch in channels if len(frame.raw_channels[ch])), default=1.0)
        if mode == "8 Panels":
            visible=set(self._visible_receivers())
            for ch, plot in enumerate(self.raw_plots):
                if ch not in visible:
                    plot.setTitle(f"RCV{ch} disabled by calibration.ini"); continue
                y = frame.raw_channels[ch]; plot.plot(np.arange(len(y)), y, pen=pg.intColor(ch, 8))
                if self.raw_scale.currentText() == "Common symmetric": plot.setYRange(-common, common, padding=.02)
        else:
            plot = self.raw_plots[0]
            for ch in channels:
                y = frame.raw_channels[ch]; plot.plot(np.arange(len(y)), y, pen=pg.intColor(ch, 8), name=f"RCV{ch}")
            plot.setTitle("RCV0–RCV7 raw overlay" if mode == "Overlay 8CH" else f"RCV{self.channel_spin.value()} raw")
            if self.raw_scale.currentText() == "Common symmetric": plot.setYRange(-common, common, padding=.02)

    def _draw_spectrum(self):
        for plot in getattr(self, "spectrum_plots", []): plot.clear()
        if not self.replay or not self.replay.frames or not self.spectrum_plots: return
        frame = self.replay.frames[self.frame_index]; x = frame.frequency_hz / 1e6
        floor = float(self.db_floor.value())
        layout_mode = self.spectrum_mode.currentText()
        value_mode = self.spectrum_value_mode.currentText()
        channels = self._visible_receivers() if layout_mode != "Single CH" else [self.channel_spin.value()]

        def curves(ch: int):
            if value_mode == "Relative dB":
                return [(self.service.relative_db(self.replay, frame, ch), "calibrated")]
            if value_mode == "Raw absolute":
                return [(self.service.absolute_db(frame, ch, False), "raw")]
            if value_mode == "Raw + calibrated":
                return [(self.service.absolute_db(frame, ch, False), "raw"), (self.service.absolute_db(frame, ch, True), "calibrated")]
            return [(self.service.absolute_db(frame, ch, True), "calibrated")]

        def draw(plot, ch):
            items = curves(ch)
            for idx, (y, label) in enumerate(items):
                pen = pg.mkPen(pg.intColor(ch, 8), width=2 if label == "calibrated" else 1, style=Qt.PenStyle.SolidLine if label == "calibrated" else Qt.PenStyle.DashLine)
                plot.plot(x[:len(y)], np.maximum(y, floor), pen=pen, name=f"RCV{ch} {label}")
            plot.setLabel("left", "Relative level" if value_mode == "Relative dB" else "Absolute amplitude", units="dB")
            if value_mode == "Relative dB": plot.setYRange(max(floor, -120), 0.0, padding=0.0)

        if layout_mode == "8 Panels":
            visible=set(self._visible_receivers())
            for ch, plot in enumerate(self.spectrum_plots):
                if ch not in visible:
                    plot.setTitle(f"RCV{ch} disabled by calibration.ini"); continue
                draw(plot, ch)
                factor = self.replay.spectrum_factors[ch] * self.replay.spectrum_coef
                plot.setTitle(f"RCV{ch} · static coef {factor:.6g}")
        else:
            plot = self.spectrum_plots[0]
            for ch in channels: draw(plot, ch)
            plot.setTitle("RCV0–RCV7 spectrum overlay" if layout_mode == "Overlay 8CH" else f"RCV{self.channel_spin.value()} spectrum")

    def _draw_spectrogram(self):
        if not hasattr(self, "spectrogram_image") or not self.replay or not self.replay.frames: return
        _decoder_time, freq, matrix = self.service.spectrogram(self.replay, self.channel_spin.value())
        time = np.asarray(self.replay.mr_frame_times_s, float)
        low = self.spec_min.value()*1e6; high = self.spec_max.value()*1e6
        mask = (freq >= low) & (freq <= high)
        if not np.any(mask): return
        image = matrix[:, mask].T
        self.spectrogram_image.setImage(image, autoLevels=False, levels=(self.replay.display_db_min, self.replay.display_db_max))
        f_values = freq[mask]/1e6
        # ImageItem requires uniformly spaced pixels.  If CPC snapshots are irregular,
        # resample the DISPLAY image onto a uniform MR-time grid. Exact FFT values
        # remain untouched and are still available in Spectrum/Band/Navigator views.
        finite=np.isfinite(time)
        if np.count_nonzero(finite) >= 2 and image.shape[1] == len(time):
            order=np.argsort(time[finite])
            source_t=time[finite][order]
            source_img=image[:, finite][:, order]
            end=float(getattr(self.replay, "mr_timeline_duration_s", 0.0) or source_t[-1])
            x_min=0.0 if end > 0 else float(source_t[0])
            x_max=end if end > 0 else float(source_t[-1])
            target_t=np.linspace(x_min, max(x_max, x_min + 1e-6), max(2, len(source_t)))
            image=np.vstack([np.interp(target_t, source_t, row, left=np.nan, right=np.nan) for row in source_img])
            self.spectrogram_image.setImage(image, autoLevels=False, levels=(self.replay.display_db_min, self.replay.display_db_max))
            width=max(x_max-x_min, 1e-6)
        else:
            x_min=0.0
            width=max(float(getattr(self.replay, "mr_timeline_duration_s", 0.0) or len(self.replay.frames)), 1.0)
        self.spectrogram_plot.setLabel("bottom", "MR acquisition time", units="s")
        self.spectrogram_image.setRect(QRectF(x_min, float(f_values[0]), width, float(f_values[-1]-f_values[0] if len(f_values)>1 else .001)))
        self.spectrogram_plot.setTitle(f"RCV{self.channel_spin.value()} · time-frequency relative level (MR timeline)")
        self._set_mr_xrange(self.spectrogram_plot)

    def _selected_bands(self):
        return [(i, self.band_low[i].value()*1e6, self.band_high[i].value()*1e6) for i, enabled in enumerate(self.band_enabled) if enabled.isChecked() and self.band_high[i].value() > self.band_low[i].value()]

    def _draw_band_energy(self):
        if not hasattr(self, "band_plot"): return
        self.band_plot.clear()
        if not self.replay or not self.replay.frames: return
        time = self.replay.mr_frame_times_s
        vendor_bands = {int(b.index): b for b in (getattr(self.replay.vendor_profile, "bands", []) if getattr(self.replay, "vendor_profile", None) else [])}
        inferred_bands = self.standalone_cavitation_service.infer_band_ranges(self.replay) if not vendor_bands else {}
        for band_index, low, high in self._selected_bands():
            vendor = vendor_bands.get(int(band_index))
            if vendor is not None:
                exact_vendor = bool(abs(low-vendor.low_hz) <= 1.0 and abs(high-vendor.high_hz) <= 1.0 and getattr(self.replay, "vendor_embedded_band_energy_available", False))
            elif int(band_index) in inferred_bands:
                ilo,ihi,_err=inferred_bands[int(band_index)]
                exact_vendor = bool(abs(low-ilo) <= 1.0 and abs(high-ihi) <= 1.0 and getattr(self.replay, "vendor_embedded_band_energy_available", False))
            else:
                exact_vendor = False
            energy = self.service.vendor_band_energy(self.replay, band_index) if exact_vendor else self.service.band_energy(self.replay, low, high)
            for ch in self._visible_receivers():
                y = energy[:, ch]
                valid = np.isfinite(y) & (y > 0)
                if not np.any(valid): continue
                ref = float(np.nanmax(y[valid])); db = np.full_like(y, -120.0)
                db[valid] = 10.0*np.log10(y[valid]/max(ref, np.finfo(float).tiny))
                pen = pg.mkPen(pg.intColor(ch, 8), width=2 if band_index == 0 else 1)
                suffix = " exact" if exact_vendor else " local"
                self.band_plot.plot(time[:len(db)], db, pen=pen, name=f"B{band_index} RCV{ch}{suffix}")
        self.band_plot.setYRange(-60, 0, padding=.03)
        self._set_mr_xrange(self.band_plot)

    def _apply_vendor_band_defaults(self):
        if not self.replay:
            return
        profile=getattr(self.replay, "vendor_profile", None)
        bands=list(profile.bands or []) if profile is not None else []
        if bands:
            ranges={int(b.index):(float(b.low_hz),float(b.high_hz)) for b in bands[:4]}
        else:
            ranges={i:(lo,hi) for i,(lo,hi,_err) in self.standalone_cavitation_service.infer_band_ranges(self.replay).items()}
        for i in range(min(4,len(self.band_low))):
            if i not in ranges: continue
            low,high=ranges[i]
            self.band_low[i].blockSignals(True); self.band_high[i].blockSignals(True)
            self.band_low[i].setValue(float(low)/1e6); self.band_high[i].setValue(float(high)/1e6)
            self.band_low[i].blockSignals(False); self.band_high[i].blockSignals(False)
        self._draw_band_energy()

    def _sync_vendor_rule_view_geometry(self):
        if hasattr(self, "vendor_rule_view") and hasattr(self, "vendor_power_plot"):
            self.vendor_rule_view.setGeometry(self.vendor_power_plot.plotItem.vb.sceneBoundingRect())
            self.vendor_rule_view.linkedViewChanged(self.vendor_power_plot.plotItem.vb, self.vendor_rule_view.XAxis)

    @staticmethod
    def _moving_average(values: np.ndarray, samples: int) -> np.ndarray:
        arr = np.asarray(values, float)
        if samples <= 1 or arr.size < samples:
            return arr
        valid = np.isfinite(arr).astype(float)
        clean = np.where(np.isfinite(arr), arr, 0.0)
        kernel = np.ones(int(samples), float)
        sums = np.convolve(clean, kernel, mode="same")
        counts = np.convolve(valid, kernel, mode="same")
        return np.divide(sums, counts, out=np.full(arr.shape, np.nan, float), where=counts > 0)

    def _vendor_display_series(self, values: np.ndarray) -> np.ndarray:
        arr = np.asarray(values, float)
        if not hasattr(self, "vendor_smooth_check") or not self.vendor_smooth_check.isChecked() or not self.replay:
            return arr
        samples = max(1, int(round(0.100 / max(float(self.replay.acquisition_interval_s), 1e-6))))
        return self._moving_average(arr, samples)

    def _current_vendor_time(self) -> float:
        if not self.replay or not self.replay.frames:
            return 0.0
        frame = self.replay.frames[min(self.frame_index, len(self.replay.frames)-1)]
        raw = float(frame.acquisition_time_s) if frame.acquisition_time_s is not None else float(self.frame_index) * float(self.replay.frame_interval_s)
        return self.replay.acquisition_to_mr_time_s(raw)

    def _install_vendor_sync_cursors(self):
        self._vendor_cursor_lines = []
        if not hasattr(self, "vendor_cursor_check") or not self.vendor_cursor_check.isChecked() or not self.replay or not self.replay.frames or not self._vendor_series_enabled("current_time"):
            return
        t = self._current_vendor_time()
        for plot in (self.vendor_energy_plot, self.vendor_power_plot):
            line = pg.InfiniteLine(pos=t, angle=90, movable=False, pen=pg.mkPen("#ffffff", width=1.4, style=Qt.PenStyle.DashLine))
            plot.addItem(line)
            self._vendor_cursor_lines.append(line)

    def _update_vendor_sync_cursors(self):
        if not getattr(self, "_vendor_cursor_lines", None):
            return
        t = self._current_vendor_time()
        for line in self._vendor_cursor_lines:
            line.setPos(t)

    def _set_all_vendor_legend_series(self, checked: bool) -> None:
        checks = getattr(self, "vendor_series_checks", {})
        if not checks:
            return
        for cb in checks.values():
            cb.blockSignals(True)
            cb.setChecked(bool(checked))
            cb.blockSignals(False)
        self._draw_vendor_cavitation(preserve_view=True)

    def _vendor_series_enabled(self, key: str) -> bool:
        checks=getattr(self, "vendor_series_checks", {})
        cb=checks.get(key)
        return True if cb is None else bool(cb.isChecked())

    def _workstation_actual_power_series(self):
        """Return authoritative Workstation PowerGraph on the Analyzer time axis.

        Acquisition_Brain ExPowerRatio is a controller state and can change during
        pre-irradiation setup. It must not be labelled or drawn as emitted
        "Actual power". For treatment Sonications, spotsonicationdata.xml
        PowerGraph is the authoritative applied-power trace and its clock is
        relative to irradiation start.
        """
        if self.package is None or self.replay is None:
            return np.asarray([], dtype=float), np.asarray([], dtype=float)
        index = getattr(self, "_loaded_sonication_index", None)
        if index is None:
            return np.asarray([], dtype=float), np.asarray([], dtype=float)
        try:
            series = AcousticControlService().power_graph_for_sonication(Path(self.package.workspace), int(index))
        except Exception:
            series = None
        if series is None:
            return np.asarray([], dtype=float), np.asarray([], dtype=float)
        t, power_percent = series
        t = np.asarray(t, dtype=float)
        power_percent = np.asarray(power_percent, dtype=float)
        valid = np.isfinite(t) & np.isfinite(power_percent) & (t >= 0.0)
        t = t[valid]; power_percent = power_percent[valid]
        if not t.size:
            return np.asarray([], dtype=float), np.asarray([], dtype=float)
        irradiation_start = float(getattr(self.replay, "mr_sonication_start_s", 0.0) or 0.0)
        ratio = power_percent / 100.0
        if t[0] > 1e-9:
            t = np.concatenate(([0.0], t))
            ratio = np.concatenate(([0.0], ratio))
        return irradiation_start + t, ratio

    def _draw_vendor_cavitation(self, *_args, preserve_view: bool = False):
        if not hasattr(self, "vendor_energy_plot"):
            return
        # Legend series toggles must not disturb the user's inspection state.
        # Capture all visible ViewBox ranges before rebuilding plot items.
        saved_ranges = None
        if preserve_view:
            try:
                saved_ranges = {
                    "energy": [list(r) for r in self.vendor_energy_plot.plotItem.vb.viewRange()],
                    "power": [list(r) for r in self.vendor_power_plot.plotItem.vb.viewRange()] if hasattr(self, "vendor_power_plot") else None,
                    "rule": [list(r) for r in self.vendor_rule_view.viewRange()] if hasattr(self, "vendor_rule_view") else None,
                }
            except Exception:
                saved_ranges = None
        self.vendor_energy_plot.clear()
        if hasattr(self, "vendor_power_plot"): self.vendor_power_plot.clear()
        if hasattr(self, "vendor_rule_view"):
            self.vendor_rule_view.clear()
        if hasattr(self, "vendor_control_table"): self.vendor_control_table.setRowCount(0)
        if not self.replay:
            self.vendor_profile_label.setText("Vendor cavitation rules are not loaded")
            return
        profile = getattr(self.replay, "vendor_profile", None)
        validation = getattr(self.replay, "vendor_history_validation", None)
        if profile is None:
            self.vendor_profile_label.setText("Cavitation profile object is unavailable")
            return
        inferred = self.standalone_cavitation_service.infer_band_ranges(self.replay) if not profile.bands else {}
        for row in range(4):
            band = next((b for b in profile.bands if b.index == row), None)
            if band is None and row in inferred:
                low,high,error=inferred[row]
                values = [f"Band{row}", "Recovered", "-", f"{low/1000:.3f} – {high/1000:.3f} kHz", f"SpectrumDumps-only: FFT-bin range reproduces embedded energy; relative error {error:.3g}"]
            elif band is None:
                values = [f"Band{row}", "-", "-", "Unavailable", "Not decoded"]
            else:
                evidence = "Vendor HARMONICS_BANDWIDTHS"
                if row == 0:
                    evidence += "; exact FFT-snapshot energy + exact continuous 8CH saved history + Display Rule 1 validation"
                elif row == 1:
                    evidence += "; exact FFT-snapshot energy; continuous combined energy reconstructed from Display Rule 2 × 0.018"
                elif row == 2:
                    evidence += "; exact FFT-snapshot energy; sparse threshold events from Decrease Power Rule 4/5"
                elif row == 3:
                    evidence += "; exact FFT-snapshot energy; no active combined display/control rule in this configuration"
                values = [f"Band{row}", f"{band.ratio:.3f} × f0", f"± {band.delta_hz/1000:.1f} kHz", f"{band.low_hz/1000:.3f} – {band.high_hz/1000:.3f} kHz", evidence]
            for col, value in enumerate(values): self.vendor_band_table.setItem(row, col, QTableWidgetItem(str(value)))
        validation_text = validation.note if validation is not None else "No saved-history validation"
        self.vendor_profile_label.setText(
            f"f0={self.replay.main_frequency_hz/1e6:.6f} MHz | Rules: {profile.source_ini.name if profile.source_ini else 'SpectrumDumps-only / no INI'} | "
            f"Acquisition: {profile.acquisition_ini.name if profile.acquisition_ini else 'not found'}\n"
            f"History semantic: {validation.status if validation else 'Not validated'}\n"
            f"FFT Band0-3 table: {'EXACT' if getattr(self.replay, 'vendor_embedded_band_energy_validated', False) else 'Not validated'}"
            f" | Snapshot→cycle map: {'EXACT' if getattr(self.replay, 'snapshot_cycle_mapping_validated', False) else 'Not validated'}\n"
            f"Control: {getattr(getattr(self.replay, 'vendor_control_validation', None), 'status', 'Not validated')} | "
            f"start ratio={profile.starting_power_ratio if profile.starting_power_ratio is not None else '-'} | levels={profile.cavitation_levels or '-'} | "
            f"RTDCA stop={profile.stop_on_rtdca} | SW/HW policy={profile.error_policy_sw}/{profile.error_policy_hw}\n"
            f"{validation_text}\n{getattr(getattr(self.replay, 'vendor_control_validation', None), 'note', '')}"
        )
        if not self.replay.raw_timeline_channels:
            return
        time = np.asarray(self.replay.mr_raw_timeline_time_s, float)
        view_mode = self.vendor_view_combo.currentText() if hasattr(self, "vendor_view_combo") else "Control overview"
        rcv_colors = ["#e6194b", "#3cb44b", "#ffe119", "#4363d8", "#f58231", "#911eb4", "#42d4f4", "#f032e6"]
        visible_receivers=set(self._visible_receivers())
        if view_mode == "All 8 receivers":
            for ch, values in enumerate(self.replay.raw_timeline_channels[:8]):
                if ch not in visible_receivers or not self._vendor_series_enabled(f"rcv{ch}"):
                    continue
                y=self._vendor_display_series(np.asarray(values,float))
                self.vendor_energy_plot.plot(time[:len(y)], y, pen=pg.mkPen(rcv_colors[ch], width=1), name=f"RCV{ch} Band0")
        elif view_mode == "Selected receiver":
            ch = int(self.channel_spin.value())
            if ch in visible_receivers and ch < len(self.replay.raw_timeline_channels) and self._vendor_series_enabled(f"rcv{ch}"):
                y=self._vendor_display_series(np.asarray(self.replay.raw_timeline_channels[ch],float))
                self.vendor_energy_plot.plot(time[:len(y)], y, pen=pg.mkPen(rcv_colors[ch], width=2.0), name=f"Selected RCV{ch} Band0")
        weighted=np.asarray(getattr(self.replay, "vendor_band0_weighted", []), float)
        if weighted.size and self._vendor_series_enabled("weighted_b0"):
            y_weighted=self._vendor_display_series(weighted)
            self.vendor_energy_plot.plot(time[:len(y_weighted)], y_weighted, pen=pg.mkPen("#ffffff", width=2.6), name="Combined Band0 / control input")
        band1=np.asarray(getattr(self.replay, "vendor_band1_log_exact", []), float)
        if band1.size and np.isfinite(band1).any() and self._vendor_series_enabled("band1"):
            self.vendor_energy_plot.plot(time[:len(band1)], self._vendor_display_series(band1), pen=pg.mkPen("#4cc9f0", width=2.2), name="Combined Band1 / Rule 2")
        band2=np.asarray(getattr(self.replay, "vendor_band2_log_events", []), float)
        if band2.size and np.isfinite(band2).any() and self._vendor_series_enabled("band2"):
            mask=np.isfinite(band2); self.vendor_energy_plot.plot(time[:len(band2)][mask], band2[mask], pen=None, symbol="o", symbolSize=7, symbolBrush="#f72585", name="Band2 exact threshold events")
        # R0033: the FFT container itself stores exact Band0..Band3 energy for
        # every hydrophone and snapshot. Plot the selected channel at its true
        # acquisition-cycle timestamps; no log is required for these points.
        if getattr(self.replay, "vendor_embedded_band_energy_validated", False) and view_mode != "Control overview":
            snapshot_time = self.replay.mr_frame_times_s
            ch = int(self.channel_spin.value())
            if ch not in visible_receivers:
                ch = min(visible_receivers) if visible_receivers else -1
            symbols = ["o", "t", "s", "d"]
            brushes = ["#ffffff", "#60cf72", "#ff5c5c", "#f4a261"]
            keys = ["snapshot_b0", "snapshot_b1", "snapshot_b2", "snapshot_b3"]
            for band_index in range(4):
                if not self._vendor_series_enabled(keys[band_index]):
                    continue
                exact = self.service.vendor_band_energy(self.replay, band_index)
                if ch >= 0 and exact.shape[0] and ch < exact.shape[1]:
                    y = exact[:, ch]
                    self.vendor_energy_plot.plot(snapshot_time[:len(y)], y, pen=None, symbol=symbols[band_index], symbolSize=6, symbolBrush=brushes[band_index], name=f"Band{band_index} RCV{ch} exact FFT snapshots")
        inc = profile.increase_rule0
        if inc is not None and inc.limit is not None and self._vendor_series_enabled("increase_limit"):
            self.vendor_energy_plot.addItem(pg.InfiniteLine(pos=float(inc.limit), angle=0, movable=False, pen=pg.mkPen("#ffd166", width=2, style=Qt.PenStyle.DashLine), label=f"Increase limit {inc.limit:g}"))
        display1=profile.display_rules.get(1)
        normalized=np.asarray(getattr(self.replay, "vendor_display_rule1", []), float)
        display2=np.asarray(getattr(self.replay, "vendor_display_rule2", []), float)
        lower_mode = self.vendor_lower_mode_combo.currentText() if hasattr(self, "vendor_lower_mode_combo") else "Both"
        show_rule = lower_mode in ("Both", "CGA Display Rule")
        show_power = lower_mode in ("Both", "Control response")
        if show_rule and normalized.size and self._vendor_series_enabled("rule1"):
            curve=pg.PlotCurveItem(time[:len(normalized)], self._vendor_display_series(normalized), pen=pg.mkPen("#06d6a0", width=2.5), name="Rule 1 / Band0")
            self.vendor_rule_view.addItem(curve)
        if show_rule and display2.size and np.isfinite(display2).any() and self._vendor_series_enabled("rule2"):
            curve=pg.PlotCurveItem(time[:len(display2)], self._vendor_display_series(display2), pen=pg.mkPen("#4cc9f0", width=2.2), name="Rule 2 / Band1")
            self.vendor_rule_view.addItem(curve)
        if show_rule and (normalized.size or (display2.size and np.isfinite(display2).any())) and self._vendor_series_enabled("rule_threshold"):
            threshold=pg.InfiniteLine(pos=1.0, angle=0, movable=False, pen=pg.mkPen("#ffd166", width=2, style=Qt.PenStyle.DashLine), label="CGA normalized threshold = 1.0")
            self.vendor_rule_view.addItem(threshold)
            self.vendor_rule_view.setYRange(0.0, max(1.05, float(np.nanmax(normalized)) if normalized.size and np.isfinite(normalized).any() else 1.05), padding=0.04)
        self.vendor_power_plot.getAxis("right").setVisible(True)

        # R0034: Decode the actual cavitation-control state machine from the INI.
        control_rows=[]
        def weighted_input(rule):
            active=np.argwhere(np.asarray(rule.weights, float) != 0)
            if active.size == 0: return "Disabled"
            bands=sorted({int(b) for _ch,b in active}); channels=sorted({int(ch) for ch,_b in active})
            return f"Band{','.join(str(b) for b in bands)} / RCV{','.join(str(c) for c in channels)}"
        validation=getattr(self.replay, "vendor_control_validation", None)
        runtime_status=validation.status if validation is not None else "Not validated"
        for idx,rule in sorted(profile.decrease_rules.items()):
            if not np.any(np.asarray(rule.weights,float)): continue
            threshold="-" if rule.threshold is None else f"> {rule.threshold:g}"
            action="-" if rule.power_ratio is None else f"Power × {1.0-float(rule.power_ratio):.3f} ({100*float(rule.power_ratio):.1f}% decrease)"
            control_rows.append(("Decrease",idx,weighted_input(rule),threshold,action,runtime_status))
        if profile.increase_rule0 is not None:
            inc_ratio = getattr(profile, "increase_power_ratio", None)
            action = "-" if inc_ratio is None else f"Power × {1.0+float(inc_ratio):.3f} (until 1.0)"
            threshold = "-" if profile.increase_rule0.limit is None else f"< {profile.increase_rule0.limit:g}"
            control_rows.append(("Increase",0,weighted_input(profile.increase_rule0),threshold,action,runtime_status))
        for idx,rule in sorted(profile.safety_rules.items()):
            if not np.any(np.asarray(rule.weights,float)): continue
            threshold=f"Max>{rule.threshold:g}" if rule.threshold is not None else "-"
            if rule.critical_threshold is not None: threshold += f" / Critical>{rule.critical_threshold:g}"
            persistence=f"Max {rule.max_failures if rule.max_failures is not None else '-'} in {rule.max_failure_window_ms if rule.max_failure_window_ms is not None else '-'} ms; Critical {rule.critical_failures if rule.critical_failures is not None else '-'} in {rule.critical_failure_window_ms if rule.critical_failure_window_ms is not None else '-'} ms"
            control_rows.append(("Safety",idx,weighted_input(rule),threshold,persistence,"INI decoded; no safety-stop event required for validation"))
        for idx,rule in sorted(profile.dynamic_rules.items()):
            if not np.any(np.asarray(rule.weights,float)): continue
            threshold="-" if rule.threshold is None else f"> {rule.threshold:g}"
            action=f"Switch to SubSonication {rule.switch_to_subsonication if rule.switch_to_subsonication is not None else '-'}; {rule.max_failures if rule.max_failures is not None else '-'} failures / {rule.max_failure_window_ms if rule.max_failure_window_ms is not None else '-'} ms"
            control_rows.append(("Dynamic",idx,weighted_input(rule),threshold,action,"CavitationDynamicRules_0.ini"))
        self.vendor_control_table.setRowCount(len(control_rows))
        self.vendor_control_table.verticalHeader().setDefaultSectionSize(22)
        for r,row in enumerate(control_rows):
            for c,value in enumerate(row): self.vendor_control_table.setItem(r,c,QTableWidgetItem(str(value)))

        if show_power:
            actual_t, actual_ratio = self._workstation_actual_power_series()
            if actual_t.size and actual_ratio.size and self._vendor_series_enabled("actual_power"):
                self.vendor_power_plot.plot(actual_t, actual_ratio, pen=pg.mkPen("#ffffff",width=2.5),
                                            name="Actual power ratio (Workstation PowerGraph)")
            if validation is not None and validation.event_cycles.size and self._vendor_series_enabled("reconstructed"):
                tx=(np.asarray(validation.event_cycles,float)-1.0)*float(self.replay.acquisition_interval_s)
                tx = tx - float(self.replay.sonication_time_zero_offset_s or 0.0) + float(self.replay.mr_sonication_start_s or 0.0)
                predicted=np.asarray(validation.predicted_power_ratio,float)
                start=float(getattr(self.replay,"mr_sonication_start_s",0.0) or 0.0)
                n=min(len(tx),len(predicted)); tx=tx[:n]; predicted=predicted[:n]
                mask=np.isfinite(tx) & np.isfinite(predicted) & (tx >= start-1e-9)
                if np.any(mask):
                    self.vendor_power_plot.plot(tx[mask],predicted[mask],pen=pg.mkPen("#06d6a0",width=1.8,style=Qt.PenStyle.DashLine),
                                                name="INI-rule prediction (irradiation)")
            self.vendor_power_plot.setYRange(0.0,1.05,padding=0.0)
        self.vendor_power_plot.getAxis("left").setVisible(True)
        self.vendor_energy_plot.setXLink(self.vendor_power_plot)
        self._apply_mr_timeline_window(self.vendor_energy_plot, self.vendor_power_plot)
        self._install_vendor_sync_cursors()
        if preserve_view and saved_ranges:
            # Do not call autoRange for a visibility-only operation. Restore the
            # exact X/Y ranges so zoom/pan stays unchanged when a legend checkbox
            # is toggled. X linking is kept after the restoration.
            try:
                er=saved_ranges.get("energy")
                pr=saved_ranges.get("power")
                rr=saved_ranges.get("rule")
                if er:
                    self.vendor_energy_plot.plotItem.vb.enableAutoRange(x=False, y=False)
                    self.vendor_energy_plot.plotItem.vb.setRange(xRange=er[0], yRange=er[1], padding=0)
                if pr:
                    self.vendor_power_plot.plotItem.vb.enableAutoRange(x=False, y=False)
                    self.vendor_power_plot.plotItem.vb.setRange(xRange=pr[0], yRange=pr[1], padding=0)
                if rr:
                    self.vendor_rule_view.enableAutoRange(x=False, y=False)
                    self.vendor_rule_view.setRange(xRange=rr[0], yRange=rr[1], padding=0)
            except Exception:
                pass
        else:
            for plot in (self.vendor_energy_plot, self.vendor_power_plot):
                plot.enableAutoRange(axis=pg.ViewBox.XAxis, enable=True)
                plot.autoRange(padding=0.04)
        self._sync_vendor_rule_view_geometry()
        self._update_vendor_current_marker()

    def _update_vendor_current_marker(self):
        if not self.replay or not hasattr(self, "vendor_profile_label"):
            return
        validation = getattr(self.replay, "vendor_history_validation", None)
        if validation is None or not self.replay.raw_timeline_channels:
            return
        # Use the exact R0033 Band0-fingerprint mapping when available. It
        # recovers real 10-ms acquisition cycle/time and preserves gaps.
        frame = self.replay.frames[self.frame_index] if self.replay.frames and self.frame_index < len(self.replay.frames) else None
        if frame is not None and frame.acquisition_history_index is not None:
            raw_index = int(frame.acquisition_history_index)
        else:
            t = float(self.frame_index) * float(self.replay.frame_interval_s)
            raw_index = min(max(int(round(t / max(self.replay.acquisition_interval_s, 1e-9))), 0), len(self.replay.raw_timeline_channels[0])-1)
        weighted=np.asarray(getattr(self.replay, "vendor_band0_weighted", []),float)
        normalized=np.asarray(getattr(self.replay, "vendor_display_rule1", []),float)
        display2=np.asarray(getattr(self.replay, "vendor_display_rule2", []),float)
        band1=np.asarray(getattr(self.replay, "vendor_band1_log_exact", []),float)
        band2=np.asarray(getattr(self.replay, "vendor_band2_log_events", []),float)
        current_energy = weighted[raw_index] if raw_index < weighted.size else np.nan
        current_rule = normalized[raw_index] if raw_index < normalized.size else np.nan
        current_rule2 = display2[raw_index] if raw_index < display2.size else np.nan
        current_band1 = band1[raw_index] if raw_index < band1.size else np.nan
        current_band2 = band2[raw_index] if raw_index < band2.size else np.nan
        base = self.vendor_profile_label.text().split("\nCurrent:",1)[0]
        f6=lambda v: "N/A" if not np.isfinite(v) else f"{v:.6f}"
        f4=lambda v: "N/A" if not np.isfinite(v) else f"{v:.4f}"
        band2_text = f6(current_band2) if np.isfinite(current_band2) else "no threshold event"
        snapshot_text = ""
        if frame is not None and np.asarray(frame.vendor_band_energies).shape == (8,4):
            ch=int(self.channel_spin.value()); ev=np.asarray(frame.vendor_band_energies,float)[ch]
            snapshot_text = " | FFT exact " + ", ".join(f"B{i}={f6(ev[i])}" for i in range(4))
        self.vendor_profile_label.setText(base + f"\nCurrent: acquisition #{raw_index+1} | Band0={f6(current_energy)} (Rule1={f4(current_rule)}) | Band1={f6(current_band1)} (Rule2={f4(current_rule2)}) | Band2={band2_text}{snapshot_text}")

    def _draw_statistics(self):
        if not hasattr(self, "stats_table") or not self.replay or not self.replay.frames: return
        bands = self._selected_bands()
        low, high = (bands[0][1], bands[0][2]) if bands else (0.25e6, 0.30e6)
        rows = self.service.frame_statistics(self.replay, self.frame_index, low, high)
        self.packet_label.setText(
            f"Measure #{self.frame_index+1} of {len(self.replay.frames)} · "
            f"Sonication frequency {self.replay.main_frequency_hz/1e6:.6f} MHz · "
            f"Band {low/1e6:.3f}–{high/1e6:.3f} MHz"
        )
        for r, data in enumerate(rows):
            values = [
                f"RCV{int(data['channel'])}", self._fmt(data['raw_peak']), self._fmt(data['raw_rms']),
                self._fmt(data['dominant_hz']/1e6, 6), self._fmt(data['peak_db'], 2), self._fmt(data['band_energy'], 5),
                self._fmt(data['raw_spectrum_peak'], 5), self._fmt(data['calibrated_spectrum_peak'], 5), self._fmt(data['main_frequency_coefficient'], 6),
            ]
            for c, value in enumerate(values): self.stats_table.setItem(r, c, QTableWidgetItem(value))

    def closeEvent(self, event):
        self.timer.stop()
        self.dump_importer.cleanup()
        super().closeEvent(event)

    @staticmethod
    def _fmt(value: float, digits: int = 3) -> str:
        return "N/A" if not np.isfinite(value) else f"{value:.{digits}g}"
