from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re

import numpy as np

from src.services.cpc_vendor_reproduction_service import VendorCavitationProfile, CpcVendorReproductionService


@dataclass(slots=True)
class ObservedCavitationEvent:
    session_index: int
    timestamp_s: float | None
    cycle: int | None
    family: str
    rule_index: int
    severity: str
    weighted_energy: float | None
    threshold: float | None
    critical_threshold: float | None
    contributing_channels: tuple[int, ...] = ()
    contributing_bands: tuple[int, ...] = ()
    dominant_channel: int | None = None
    dominant_band: int | None = None
    dominant_energy: float | None = None
    before_power_ratio: float | None = None
    after_power_ratio: float | None = None
    action: str = ""
    result: str = ""
    evidence: str = ""


@dataclass(slots=True)
class CavitationControlTimeline:
    source_log: Path | None = None
    session_index: int | None = None
    events: list[ObservedCavitationEvent] = field(default_factory=list)
    session_start_s: float | None = None
    actual_power_times_s: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    actual_power_ratio: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    actual_power_cycles: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=int))
    predicted_power_times_s: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    predicted_power_ratio: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    summary: str = ""


class CavitationControlTimelineService:
    _TS_RE = re.compile(r"(?P<h>\d{2}):(?P<m>\d{2}):(?P<s>\d{2}):(?P<ms>\d{3})")
    _SET_RE = re.compile(r"Set:.*?ExciterPower\s*=\s*([^,]+),.*?ExPowerRatio\s*=\s*([-+0-9.eE]+)", re.I)
    _CYCLE_RE = re.compile(r"Cycle\s+(\d+)\s+Done", re.I)
    _INC_RE = re.compile(r"Increase Power Rule no\.\s*(\d+)\s*:.*?Calculated Energy:\s*<\s*([-+0-9.eE]+)\s*>.*?Bottom.*?:\s*<\s*([-+0-9.eE]+)\s*>", re.I)
    _DEC_RE = re.compile(r"Decrease Power Rule no\.\s*(\d+)\s*:.*?Calculated Energy:\s*<\s*([-+0-9.eE]+)\s*>.*?Calculated Top Energy limit:\s*<\s*([-+0-9.eE]+)\s*>", re.I)
    _SAFETY_RE = re.compile(r"Safety Rule no\.\s*(\d+)\s*:.*?(critical|maximal).*", re.I)
    _CALC_RE = re.compile(r"Calculated Energy:\s*<\s*([-+0-9.eE]+)\s*>", re.I)
    _THRESH_RE = re.compile(r"(Critical|Maximum) Energy:\s*<\s*([-+0-9.eE]+)\s*>", re.I)
    _RULE_BLOCK_RE = re.compile(r"RuleNo\.\s*<(\d+)>.*?calculation\s+([-+0-9.eE]+)\s*=", re.I)
    _CH_RE = re.compile(r"Ch\s*<\s*(\d+)\s*>\s*(.*)")
    _BAND_TERM_RE = re.compile(r"band<(\d+)>\s*([-+0-9.eE]+).*?\*\s*([-+0-9.eE]+)\(", re.I)

    @staticmethod
    def _timestamp_s(line: str) -> float | None:
        m = CavitationControlTimelineService._TS_RE.search(line)
        if not m:
            return None
        return int(m.group("h")) * 3600 + int(m.group("m")) * 60 + int(m.group("s")) + int(m.group("ms")) / 1000.0

    @staticmethod
    def _find_log(source_path: Path | None) -> Path | None:
        return CpcVendorReproductionService._find_upwards(source_path, (), ("Acquisition_Brain_*.txt",))

    @staticmethod
    def _rule_from_profile(profile: VendorCavitationProfile | None, family: str, index: int):
        if profile is None:
            return None
        if family == "Increase":
            return profile.increase_rule0 if index == 0 else None
        if family == "Decrease":
            return profile.decrease_rules.get(index)
        if family == "Safety":
            return profile.safety_rules.get(index)
        if family == "Dynamic":
            return profile.dynamic_rules.get(index)
        return None

    @staticmethod
    def _rule_channels_bands(rule) -> tuple[tuple[int, ...], tuple[int, ...]]:
        if rule is None or not hasattr(rule, "weights"):
            return (), ()
        active = np.argwhere(np.asarray(rule.weights, float) != 0)
        if active.size == 0:
            return (), ()
        channels = tuple(sorted({int(ch) for ch, _band in active}))
        bands = tuple(sorted({int(band) for _ch, band in active}))
        return channels, bands

    @staticmethod
    def _relative_times(times: list[float]) -> tuple[np.ndarray, float | None]:
        if not times:
            return np.asarray([], dtype=float), None
        base = float(times[0])
        return np.asarray([float(t) - base for t in times], dtype=float), base

    def parse(
        self,
        source_path: Path | None,
        profile: VendorCavitationProfile | None,
        preferred_session_index: int | None = None,
        predicted_cycles: np.ndarray | None = None,
        predicted_ratio: np.ndarray | None = None,
    ) -> CavitationControlTimeline:
        timeline = CavitationControlTimeline()
        log_path = self._find_log(source_path)
        timeline.source_log = log_path
        if log_path is None:
            timeline.summary = "Acquisition_Brain log not found; observed cavitation-control timeline unavailable."
            return timeline

        sessions: list[dict] = []
        current = {"events": [], "power": []}
        session_index = 0
        pending_non_safety: list[ObservedCavitationEvent] = []
        pending_safety: list[ObservedCavitationEvent] = []
        last_power_ratio: float | None = None
        last_cycle: int | None = None
        safety_stub: dict | None = None
        block_event: ObservedCavitationEvent | None = None
        block_remaining = 0

        with log_path.open("r", encoding="utf-8", errors="ignore") as f:
            for raw in f:
                line = raw.rstrip("\n")
                ts = self._timestamp_s(line)

                if "Got StartSpectrumMeasurement" in line:
                    if current["events"] or current["power"]:
                        sessions.append(current)
                    current = {"events": [], "power": []}
                    session_index = len(sessions)
                    pending_non_safety = []
                    pending_safety = []
                    last_power_ratio = None
                    last_cycle = None
                    safety_stub = None
                    block_event = None
                    block_remaining = 0
                    continue

                cycle_match = self._CYCLE_RE.search(line)
                if cycle_match:
                    last_cycle = int(cycle_match.group(1))

                set_match = self._SET_RE.search(line)
                if set_match:
                    try:
                        after_ratio = float(set_match.group(2))
                    except ValueError:
                        after_ratio = None
                    if ts is not None and after_ratio is not None:
                        current["power"].append((ts, after_ratio, (last_cycle + 1) if last_cycle is not None else None))
                    attach = list(pending_non_safety)
                    attach.extend(e for e in pending_safety if e.result or e.action or after_ratio == 0.0)
                    for event in attach:
                        if event.after_power_ratio is None:
                            event.before_power_ratio = last_power_ratio
                            event.after_power_ratio = after_ratio
                            if not event.action:
                                event.action = f"{event.family} control"
                            if not event.result:
                                if after_ratio == 0.0 and event.family == "Safety":
                                    event.result = "HALTED BY CAVITATION"
                                else:
                                    before = "?" if last_power_ratio is None else f"{last_power_ratio:.3f}"
                                    after = "?" if after_ratio is None else f"{after_ratio:.3f}"
                                    event.result = f"ExPowerRatio {before} → {after}"
                    pending_non_safety = []
                    if after_ratio == 0.0:
                        pending_safety = []
                    last_power_ratio = after_ratio
                    continue

                inc_match = self._INC_RE.search(line)
                if inc_match:
                    idx = int(inc_match.group(1))
                    energy = float(inc_match.group(2))
                    threshold = float(inc_match.group(3))
                    rule = self._rule_from_profile(profile, "Increase", idx)
                    channels, bands = self._rule_channels_bands(rule)
                    event = ObservedCavitationEvent(
                        session_index=session_index,
                        timestamp_s=ts,
                        cycle=last_cycle,
                        family="Increase",
                        rule_index=idx,
                        severity="Observed",
                        weighted_energy=energy,
                        threshold=threshold,
                        critical_threshold=None,
                        contributing_channels=channels,
                        contributing_bands=bands,
                        action="Increase power",
                        evidence="Acquisition_Brain",
                    )
                    current["events"].append(event)
                    pending_non_safety.append(event)
                    continue

                dec_match = self._DEC_RE.search(line)
                if dec_match:
                    idx = int(dec_match.group(1))
                    energy = float(dec_match.group(2))
                    threshold = float(dec_match.group(3))
                    rule = self._rule_from_profile(profile, "Decrease", idx)
                    channels, bands = self._rule_channels_bands(rule)
                    event = ObservedCavitationEvent(
                        session_index=session_index,
                        timestamp_s=ts,
                        cycle=last_cycle,
                        family="Decrease",
                        rule_index=idx,
                        severity="Observed",
                        weighted_energy=energy,
                        threshold=threshold,
                        critical_threshold=None,
                        contributing_channels=channels,
                        contributing_bands=bands,
                        action="Decrease power",
                        evidence="Acquisition_Brain",
                    )
                    current["events"].append(event)
                    pending_non_safety.append(event)
                    continue

                safety_match = self._SAFETY_RE.search(line)
                if safety_match:
                    safety_stub = {
                        "idx": int(safety_match.group(1)),
                        "critical": "critical" in safety_match.group(2).lower(),
                        "ts": ts,
                        "cycle": last_cycle,
                    }
                    continue

                if safety_stub is not None:
                    calc_match = self._CALC_RE.search(line)
                    if calc_match:
                        safety_stub["energy"] = float(calc_match.group(1))
                        continue
                    thresh_match = self._THRESH_RE.search(line)
                    if thresh_match:
                        idx = int(safety_stub["idx"])
                        observed_threshold = float(thresh_match.group(2))
                        rule = self._rule_from_profile(profile, "Safety", idx)
                        channels, bands = self._rule_channels_bands(rule)
                        event = ObservedCavitationEvent(
                            session_index=session_index,
                            timestamp_s=safety_stub["ts"],
                            cycle=safety_stub["cycle"],
                            family="Safety",
                            rule_index=idx,
                            severity="Observed critical" if safety_stub.get("critical") else "Observed maximum",
                            weighted_energy=safety_stub.get("energy"),
                            threshold=(rule.threshold if rule is not None and rule.threshold is not None else (None if safety_stub.get("critical") else observed_threshold)),
                            critical_threshold=(rule.critical_threshold if rule is not None and rule.critical_threshold is not None else (observed_threshold if safety_stub.get("critical") else None)),
                            contributing_channels=channels,
                            contributing_bands=bands,
                            action="Safety evaluation",
                            evidence="Acquisition_Brain",
                        )
                        current["events"].append(event)
                        pending_safety.append(event)
                        safety_stub = None
                        continue

                block_match = self._RULE_BLOCK_RE.search(line)
                if block_match:
                    rule_index = int(block_match.group(1))
                    block_event = None
                    for event in reversed(current["events"]):
                        if event.family == "Safety" and event.rule_index == rule_index and event.dominant_channel is None:
                            block_event = event
                            block_remaining = 8
                            break
                    continue

                if block_event is not None and block_remaining > 0:
                    ch_match = self._CH_RE.search(line)
                    if ch_match:
                        ch = int(ch_match.group(1))
                        rest = ch_match.group(2)
                        contrib_channels = set(block_event.contributing_channels)
                        contrib_bands = set(block_event.contributing_bands)
                        best = None
                        for band_match in self._BAND_TERM_RE.finditer(rest):
                            band = int(band_match.group(1))
                            energy = float(band_match.group(2))
                            weight = float(band_match.group(3))
                            if weight > 0:
                                contrib_channels.add(ch)
                                contrib_bands.add(band)
                                contribution = energy * weight
                                if best is None or contribution > best[0]:
                                    best = (contribution, ch, band, energy)
                        block_event.contributing_channels = tuple(sorted(contrib_channels))
                        block_event.contributing_bands = tuple(sorted(contrib_bands))
                        if best is not None and (block_event.dominant_energy is None or best[3] > block_event.dominant_energy):
                            block_event.dominant_channel = best[1]
                            block_event.dominant_band = best[2]
                            block_event.dominant_energy = best[3]
                        block_remaining -= 1
                        if block_remaining <= 0:
                            block_event = None
                        continue

                if "HALTED BY CAVITATION" in line:
                    for event in reversed(current["events"]):
                        if event.family == "Safety" and not event.result:
                            event.action = "Immediate stop"
                            event.result = "HALTED BY CAVITATION"
                            break

        if current["events"] or current["power"]:
            sessions.append(current)

        if not sessions:
            timeline.summary = "Acquisition_Brain log found, but no cavitation-control events were parsed."
            return timeline

        if preferred_session_index is None or not (0 <= preferred_session_index < len(sessions)):
            preferred_session_index = max(range(len(sessions)), key=lambda i: len(sessions[i]["events"]))
        chosen = sessions[preferred_session_index]
        timeline.session_index = preferred_session_index
        timeline.events = chosen["events"]
        power_times = [row[0] for row in chosen["power"]]
        power_values = [row[1] for row in chosen["power"]]
        power_cycles = [row[2] for row in chosen["power"]]
        rel_times, base = self._relative_times(power_times)
        timeline.session_start_s = base
        timeline.actual_power_times_s = rel_times
        timeline.actual_power_ratio = np.asarray(power_values, dtype=float)
        timeline.actual_power_cycles = np.asarray([c if c is not None else -1 for c in power_cycles], dtype=int)
        if predicted_cycles is not None and predicted_ratio is not None and np.asarray(predicted_cycles).size and np.asarray(predicted_ratio).size:
            pred_cycles = np.asarray(predicted_cycles, dtype=float)
            valid_actual_cycles = timeline.actual_power_cycles[timeline.actual_power_cycles >= 0]
            if valid_actual_cycles.size:
                base_cycle = float(valid_actual_cycles[0])
                timeline.predicted_power_times_s = (pred_cycles - base_cycle) * 0.010
            else:
                timeline.predicted_power_times_s = (pred_cycles - 1.0) * 0.010
            timeline.predicted_power_ratio = np.asarray(predicted_ratio, dtype=float)

        valid_actual_cycles = timeline.actual_power_cycles[timeline.actual_power_cycles >= 0]
        base_cycle = int(valid_actual_cycles[0]) if valid_actual_cycles.size else None
        for event in timeline.events:
            if event.cycle is not None and base_cycle is not None:
                event.timestamp_s = (float(event.cycle) - float(base_cycle)) * 0.010
            elif event.timestamp_s is not None and base is not None:
                event.timestamp_s = float(event.timestamp_s) - float(base)
            if not event.evidence:
                event.evidence = "Acquisition_Brain"

        halt_count = sum(1 for e in timeline.events if "HALTED" in e.result)
        decrease_count = sum(1 for e in timeline.events if e.family == "Decrease")
        increase_count = sum(1 for e in timeline.events if e.family == "Increase")
        safety_count = sum(1 for e in timeline.events if e.family == "Safety")
        timeline.summary = (
            f"Observed control session {preferred_session_index}: events={len(timeline.events)} "
            f"(increase={increase_count}, decrease={decrease_count}, safety={safety_count}, halts={halt_count}). "
            "Observed = parsed from Acquisition_Brain; Reconstructed = inferred from dump + common/vendor rules."
        )
        return timeline
