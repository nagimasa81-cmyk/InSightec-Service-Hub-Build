# R0190t — Distance ruler state / signal / physical geometry hardening

## Root cause
The additive Distance implementation connected pyqtgraph ROI signals with `lambda e=entry`. pyqtgraph supplies the emitting ROI as the first positional argument, overwriting the default `entry`. After creation, dragging a ruler therefore sent a `LineSegmentROI` where the measurement dictionary was required. This broke per-ruler refresh/selection, leaving creation-time values and making Clear target stale.

## Fix
- Capture each ruler entry with keyword-only closure (`lambda *_args, e=entry`).
- Recompute the moved ruler's own endpoints/result/label on every region change.
- Preserve independent line/label/result objects for D1, D2, ... .
- Clear removes only the actually selected ruler.
- Use independent image X/Y pixel spacing for physical distance: sqrt((dx*sx)^2+(dy*sy)^2).
- Keep legacy scalar spacing compatibility and horizontal physical ruler behavior.
- Offset each value label from its own segment midpoint for readability.
- Refresh existing rulers when spacing metadata becomes available.

## Regression scope
No DQA focus calculation or DQA diagnostic marker geometry was changed.
