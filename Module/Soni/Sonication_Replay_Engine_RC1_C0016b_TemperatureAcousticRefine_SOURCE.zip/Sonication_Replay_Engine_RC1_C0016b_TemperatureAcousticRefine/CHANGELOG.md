# C0016b Temperature / Acoustic Refinement

- Temperature Trend defaults to 40–60 °C with 2 °C major ticks, 1 °C minor ticks, background temperature bands, and synchronized replay cursor.
- Red Threshold now changes the temperature at which the overlay turns red; it no longer hides all temperatures below the threshold.
- Power and Score values are drawn inside their shared chart.
- Hydrophone channel selection moved to Acoustic Spectrum and supports single, multiple, and all-channel selection.
- Acoustic Spectrum uses 0.20–0.80 MHz and 0–4 Relative Amplitude axes.
- Waterfall renamed to Acoustic Spectrum Over Replay Time and uses relative-amplitude color intensity.
- Fallback voxel changed to 10 mm × 10 mm.

# C0016a
- Initialized Temperature Trend workspace
- Prepared Peak Navigation foundation
