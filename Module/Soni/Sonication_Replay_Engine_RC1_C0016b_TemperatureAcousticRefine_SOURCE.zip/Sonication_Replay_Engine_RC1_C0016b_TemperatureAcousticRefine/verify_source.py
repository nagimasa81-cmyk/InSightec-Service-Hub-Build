from __future__ import annotations

import math
import struct
import tempfile
import json
from pathlib import Path

from src.integration.spectrum_provider import SpectrumMsgAnalyzerAdapter
from src.services.xd_ini_service import XdIniService
from src.services.acoustic_control_service import AcousticControlService


def _verify_release_metadata() -> None:
    root = Path(__file__).resolve().parent
    version_text = (root / "VERSION").read_text(encoding="utf-8").strip()
    version_json = json.loads((root / "version.json").read_text(encoding="utf-8"))
    pyproject = (root / "pyproject.toml").read_text(encoding="utf-8")
    from src.common.constants import APP_VERSION

    assert version_text == "RC1 C0016b TemperatureAcousticRefine"
    assert APP_VERSION == version_text
    assert version_json["version"] == "RC1-C0016b"
    assert version_json["commit"] == "C0016b"
    assert 'version = "0.1.16"' in pyproject
    assert 'C0016b TemperatureAcousticRefine' in pyproject


def main() -> int:
    _verify_release_metadata()
    with tempfile.TemporaryDirectory(
        prefix="SonicationReplayC0016bVerify_"
    ) as temp:
        root = Path(temp)

        ini = root / "Xd_ABC123.ini"
        ini.write_text(
            "[Transducer]\nSerial=ABC123\nMainFrequency=650 kHz\n",
            encoding="utf-8",
        )

        metadata = XdIniService().read_main_frequency(root)
        assert metadata.frequency_hz == 650000.0
        assert metadata.source_path == ini
        assert metadata.raw_line == "MainFrequency=650 kHz"

        son = root / "Sonication1"
        son.mkdir()

        values = []
        sample_count = 2048
        for index in range(sample_count):
            value = (
                math.exp(-((index - 930) / 20.0) ** 2) * 100.0
                + math.exp(-((index - 465) / 16.0) ** 2) * 25.0
                + math.exp(-((index - 1860) / 30.0) ** 2) * 40.0
            )
            values.append(struct.pack("<f", value))

        spectrum_file = son / "SpectrumMsg-1.dmp"
        spectrum_file.write_bytes(
            b"SPECTRUMMSG" + b"\x00" * 21 + b"".join(values)
        )

        adapter = SpectrumMsgAnalyzerAdapter(
            metadata.frequency_hz
        )
        frames = adapter.load([spectrum_file])

        assert len(frames) == 1
        assert frames[0].frequency
        assert frames[0].amplitude
        assert frames[0].main_peak_hz is not None
        assert abs(frames[0].main_peak_hz - 650000.0) < 100000.0

        acquisition = root / "Acquisition_Brain_650_Test.txt"
        acquisition.write_text(
            "08:00:00:000 Inf 1 StartSpectrumMeasurement: SetInitial PowerRatios: (1.000, 1.000)\n"
            "08:00:00:100 Inf 1 Set: AblPowerRatio = 0.8000 (200), Validity = 1\n"
            "08:00:00:110 Inf 1 Increase Power Rule: Calculated Energy: <0.001680>. Bottom Limit Of Harmless Energy: <0.014>\n",
            encoding="utf-8",
        )
        segments = AcousticControlService().parse_segments(acquisition)
        assert len(segments) == 1
        powers = [sample.power_percent for sample in segments[0].samples if sample.power_percent is not None]
        scores = [sample.score_percent for sample in segments[0].samples if sample.score_percent is not None]
        assert powers and abs(powers[-1] - 80.0) < 1e-6
        assert scores and abs(scores[-1] - 12.0) < 1e-6

    print("VERIFY_SOURCE_OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
