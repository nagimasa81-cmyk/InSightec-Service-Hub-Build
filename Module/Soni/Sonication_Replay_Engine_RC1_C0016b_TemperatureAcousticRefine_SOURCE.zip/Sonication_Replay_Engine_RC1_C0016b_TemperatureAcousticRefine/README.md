# Sonication Replay Engine — RC1 C0016b TemperatureAcousticRefine

Replay-first FUS workstation-style viewer.

## C0007 thermometry
- Absolute-temperature map is the default display.
- RAW data is classified as absolute temperature or delta temperature.
- Delta RAW is converted to absolute temperature with an explicit 37.0 C fallback reference.
- Max and Average temperatures are calculated inside an explicit ROI.
- The current fallback ROI is shown as `Default center ROI (ACT/Protocol pending)`; it is never hidden.
- Workstation-style temperature scale presets: 30–90, 35–60, and 40–60 C.
- Red-threshold overlay and investigation-only ΔTemperature mode.
- Temperature chart, image, spectrum, acoustic controls, and frame navigator remain replay-synchronized.

The next thermometry step is reading the exact target/ROI and reference temperature from ACT/Protocol metadata when present.


## C0014 current release
- New file/Sonication load starts from an initialized Fit/WL/WW view.
- SpectrumMsg internal frames are decoded and mapped to Replay frames.
- Spectrum amplitude is normalized to relative dB for visible plotting.
- Acoustic Spectrum and Waterfall use the 200–800 kHz display range.
- `version.json`, `VERSION`, `APP_VERSION`, and `pyproject.toml` are synchronized.

## C0013 data integrity note
The supplied Sonication `.act` file is an element table (1024 element amplitude/phase values). It does not provide a validated frame-by-frame Workstation `Power %` or `Score` stream. C0013 therefore does not synthesize these values from SpectrumMsg decoder confidence or peak amplitude.

## C0016b current release
- Reads `Acquisition_Brain_*.txt` control telemetry from the ANx/CPCFiles tree.
- Power % is taken from `AblPowerRatio × 100`, representing applied/requested acoustic power.
- Score is taken from `Calculated Energy / Bottom Limit Of Harmless Energy × 100`.
- Both curves are synchronized to the selected Sonication replay frames.
- The cards show Power %, Score, and the measured energy/limit pair.
- Values are not inferred from SpectrumMsg peak amplitude.
