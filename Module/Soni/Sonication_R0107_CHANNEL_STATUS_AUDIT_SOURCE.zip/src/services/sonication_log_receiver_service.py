from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re


@dataclass(slots=True)
class SonicChannelValue:
    channel: int
    logical_amplitude: float | None = None
    logical_phase_rad: float | None = None
    measured_amplitude: float | None = None
    measured_phase_rad: float | None = None
    measured_frequency_hz: float | None = None
    measured_source: Path | None = None
    sonication_phase_rad: float | None = None
    sonication_phase_source: Path | None = None
    sonication_phase_method: str | None = None

    @property
    def blade_index(self) -> int:
        return max(0, int(self.channel)) // 64

    @property
    def blade_number(self) -> int:
        return self.blade_index + 1

    @property
    def blade_channel(self) -> int:
        return max(0, int(self.channel)) % 64


@dataclass(slots=True)
class SonicChannelSnapshot:
    timestamp: str | None
    declared_channels: int | None
    source: Path
    values: list[SonicChannelValue] = field(default_factory=list)
    logical_decoded_channels: int = 0
    measured_decoded_channels: int = 0
    measured_frequency_hz: float | None = None
    measured_source: Path | None = None
    sonication_phase_rad: float | None = None
    sonication_phase_source: Path | None = None
    sonication_phase_method: str | None = None


@dataclass(slots=True)
class ChannelMeasureTable:
    source: Path
    frequencies_hz: list[float]
    selected_frequency_hz: float
    values: dict[int, tuple[float, float]]


class SonicationLogReceiverService:
    """Decode 1024 transmit-channel sonication data.

    Two evidence streams are deliberately kept distinct:
      * Sonication_Brain ``Logical Amplitude/Logical Phase`` = per-sonication log.
      * CPCFiles/Site/Ini/ChannelMeasure.ini = 1024-channel measured calibration
        at the frequency nearest the selected sonication frequency.

    The measured table is used to populate all 1024 physical channel slots while
    preserving which channels actually had Logical values in the sonication log.
    RCV0..RCV7 hydrophone receivers are a separate namespace and never enter here.
    """

    _TIME = re.compile(r"\b(\d{1,2}:\d{2}:\d{2}(?:[.:]\d+)?)\b")
    _NUMBER = re.compile(r"Number\s+Of\s+Channels\s*<\s*(\d+)\s*>", re.I)
    _CHANNEL = re.compile(r"\bChannel\s*<\s*(\d+)\s*>", re.I)
    _AMP = re.compile(r"Logical\s+Amplitude\s*<\s*([-+0-9.eE]+)\s*>", re.I)
    _PHASE = re.compile(r"Logical\s+Phase\s*<\s*([-+0-9.eE]+)\s*>", re.I)
    _FREQ_LINE = re.compile(r"^\s*FREQ(\d+)\s*=\s*([-+0-9.eE]+)", re.I)
    _MEASURE_CH = re.compile(r"^\s*CH(\d+)\s*=\s*(.+?)\s*$", re.I)

    @staticmethod
    def _candidate_files(root: Path, preferred_folder: Path | None = None, sonication_number: int | None = None, direct_files: list[Path] | None = None) -> list[Path]:
        root = Path(root)
        files: list[Path] = []
        if direct_files:
            files.extend(Path(p) for p in direct_files if Path(p).is_file())
        if root.exists():
            for p in root.rglob('*'):
                if not p.is_file() or p.suffix.lower() not in {'.txt','.log'}:
                    continue
                n=p.name.lower()
                if 'sonication' in n or 'sonic' in n:
                    files.append(p)
        unique=[]; seen=set()
        preferred = Path(preferred_folder).resolve() if preferred_folder and Path(preferred_folder).exists() else None
        token = f"sonication{sonication_number}" if sonication_number is not None else ''
        def rank(path: Path):
            rp = path.resolve()
            inside = 0 if preferred is not None and (rp == preferred or preferred in rp.parents) else 1
            name = path.name.lower().replace('_','').replace('-','')
            number_match = 0 if token and token in name else 1
            brain = 0 if 'sonication_brain' in path.name.lower() or 'sonicationbrain' in name else 1
            return (inside, number_match, brain, len(path.parts), path.name.lower())
        for p in sorted(files, key=rank):
            key=str(p.resolve())
            if key in seen: continue
            seen.add(key); unique.append(p)
        return unique

    @classmethod
    def read_channel_measure(cls, root: Path, target_frequency_hz: float | None = None) -> ChannelMeasureTable | None:
        root=Path(root)
        hits=sorted(root.rglob('ChannelMeasure.ini')) if root.exists() else []
        if not hits:
            return None
        path=hits[0]
        try:
            lines=path.read_text(encoding='utf-8',errors='ignore').splitlines()
        except OSError:
            return None
        freqs={}
        for line in lines:
            m=cls._FREQ_LINE.match(line)
            if m:
                try: freqs[int(m.group(1))]=float(m.group(2))*1e6
                except ValueError: pass
        if not freqs:
            return None
        ordered=sorted(freqs)
        target=float(target_frequency_hz or freqs[ordered[0]])
        selected_idx=min(ordered,key=lambda i:abs(freqs[i]-target))
        selected_hz=float(freqs[selected_idx])
        values={}
        for line in lines:
            m=cls._MEASURE_CH.match(line)
            if not m: continue
            try: ch=int(m.group(1))
            except ValueError: continue
            if not (0 <= ch < 1024): continue
            try: nums=[float(x) for x in m.group(2).split()]
            except ValueError: continue
            base=selected_idx*2
            if base+1 >= len(nums): continue
            values[ch]=(float(nums[base]),float(nums[base+1]))
        if not values:
            return None
        return ChannelMeasureTable(path,[float(freqs[i]) for i in ordered],selected_hz,values)

    @staticmethod
    def _merge_measurement(snapshot: SonicChannelSnapshot, table: ChannelMeasureTable | None) -> SonicChannelSnapshot:
        logical_by={int(v.channel):v for v in snapshot.values}
        snapshot.logical_decoded_channels=len(logical_by)
        if table is None:
            snapshot.values=[logical_by[k] for k in sorted(logical_by)]
            return snapshot
        merged=[]
        declared=max(int(snapshot.declared_channels or 0),1024 if len(table.values)>=1024 else len(table.values))
        for ch in range(declared):
            v=logical_by.get(ch) or SonicChannelValue(ch)
            measured=table.values.get(ch)
            if measured is not None:
                v.measured_amplitude=float(measured[0]); v.measured_phase_rad=float(measured[1])
                v.measured_frequency_hz=table.selected_frequency_hz; v.measured_source=table.source
            merged.append(v)
        snapshot.values=merged
        snapshot.declared_channels=declared
        snapshot.measured_decoded_channels=sum(1 for v in merged if v.measured_phase_rad is not None or v.measured_amplitude is not None)
        snapshot.measured_frequency_hz=table.selected_frequency_hz
        snapshot.measured_source=table.source
        return snapshot


    @staticmethod
    def _wrap_phase(value: float) -> float:
        import math
        return math.atan2(math.sin(float(value)), math.cos(float(value)))

    @classmethod
    def _merge_sonication_phase(cls, snapshot: SonicChannelSnapshot, root: Path, sonication_number: int | None) -> SonicChannelSnapshot:
        """Attach a 1024-channel sonication phase from SkullMeasures evidence.

        SkullMeasures contains one row per transmit element and exposes both
        ``Phase Correction`` and ``Total Phase Shift``.  The latter is the closest
        exported evidence to the workstation sonication-phase display.  A common
        circular offset is estimated from any observed Logical Phase channels
        (typically CH0..CH3) so the reconstructed 1024-channel array shares the
        absolute phase reference used by the Sonication_Brain log.
        """
        try:
            from src.services.skull_measures_service import SkullMeasuresService
            data=SkullMeasuresService().find_and_read(Path(root),sonication_number,Path(root))
        except Exception:
            return snapshot
        if not getattr(data,'elements',None):
            return snapshot
        raw={}
        for el in data.elements:
            try:
                ch=int(el.number)
                val=float(el.values.get('Total Phase Shift', float('nan')))
            except Exception:
                continue
            if 0 <= ch < 1024 and val == val:
                raw[ch]=val
        if not raw:
            return snapshot
        import math, cmath
        vals=list(raw.values())
        # Workstation SkullMeasures phase columns are generally degrees.  Keep a
        # defensive radians path for export generations that already use radians.
        sorted_abs=sorted(abs(v) for v in vals)
        p95=sorted_abs[min(len(sorted_abs)-1, int(round((len(sorted_abs)-1)*0.95)))]
        degrees = p95 > (2.0*math.pi*1.25)
        base={ch:(math.radians(v) if degrees else v) for ch,v in raw.items()}
        by={int(v.channel):v for v in snapshot.values}
        for ch in raw:
            if ch not in by:
                by[ch]=SonicChannelValue(ch)
        snapshot.values=[by[ch] for ch in sorted(by)]
        snapshot.declared_channels=max(int(snapshot.declared_channels or 0), max(raw)+1)
        deltas=[]
        for ch,v in by.items():
            if ch in base and v.logical_phase_rad is not None:
                deltas.append(cls._wrap_phase(float(v.logical_phase_rad)-base[ch]))
        offset=0.0
        if deltas:
            z=sum(cmath.exp(1j*d) for d in deltas)/len(deltas)
            offset=cmath.phase(z)
        method='SkullMeasures Total Phase Shift' + (' + Logical common-phase anchor' if deltas else '')
        source=getattr(data,'source',None)
        for ch,v in by.items():
            if ch in base:
                v.sonication_phase_rad=cls._wrap_phase(base[ch]+offset)
                v.sonication_phase_source=source
                v.sonication_phase_method=method
        return snapshot

    def read_snapshots(self, root: Path, preferred_folder: Path | None = None, sonication_number: int | None = None,
                       direct_files: list[Path] | None = None, target_frequency_hz: float | None = None) -> list[SonicChannelSnapshot]:
        snapshots=[]
        for path in self._candidate_files(Path(root), preferred_folder, sonication_number, direct_files):
            try: lines=path.read_text(encoding='utf-8',errors='ignore').splitlines()
            except OSError: continue
            current=None; current_channel=None; last_time=None
            def flush():
                nonlocal current,current_channel
                if current is not None and current.values:
                    by={v.channel:v for v in current.values}; current.values=[by[k] for k in sorted(by)]
                    current.logical_decoded_channels=len(current.values)
                    snapshots.append(current)
                current=None; current_channel=None
            for line in lines:
                tm=self._TIME.search(line)
                if tm: last_time=tm.group(1).replace(':','.',3) if tm.group(1).count(':')==3 else tm.group(1)
                block_start = 'CLoadSonicationData fields' in line
                m_number=self._NUMBER.search(line)
                if block_start:
                    flush(); current=SonicChannelSnapshot(last_time,None,path,[]); continue
                if m_number:
                    declared=int(m_number.group(1))
                    if current is None or current.values:
                        flush(); current=SonicChannelSnapshot(last_time,declared,path,[])
                    else:
                        current.declared_channels=declared
                    continue
                m=self._CHANNEL.search(line)
                if m:
                    if current is None: current=SonicChannelSnapshot(last_time,None,path,[])
                    current_channel=int(m.group(1))
                    if 0 <= current_channel < 1024: current.values.append(SonicChannelValue(current_channel))
                    else: current_channel=None
                    continue
                if current_channel is None or current is None or not current.values: continue
                m=self._AMP.search(line)
                if m:
                    try: current.values[-1].logical_amplitude=float(m.group(1))
                    except ValueError: pass
                    continue
                m=self._PHASE.search(line)
                if m:
                    try: current.values[-1].logical_phase_rad=float(m.group(1))
                    except ValueError: pass
            flush()
        out=[]; seen=set()
        table=self.read_channel_measure(Path(root),target_frequency_hz)
        for snap in snapshots:
            sig=(str(snap.source),snap.timestamp,tuple((v.channel,v.logical_amplitude,v.logical_phase_rad) for v in snap.values))
            if sig in seen: continue
            seen.add(sig)
            merged=self._merge_measurement(snap,table)
            merged=self._merge_sonication_phase(merged,Path(root),sonication_number)
            out.append(merged)
        # ChannelMeasure.ini is valid evidence even when no Sonication_Brain block
        # was logged. Expose one static 1024-channel snapshot in that case.
        if not out and table is not None:
            base=SonicChannelSnapshot(None,1024,table.source,[])
            out=[self._merge_measurement(base,table)]
        return out
