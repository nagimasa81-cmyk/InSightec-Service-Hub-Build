from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import math
import re

import numpy as np


@dataclass(slots=True)
class VendorBand:
    index: int
    ratio: float
    delta_hz: float
    low_hz: float
    high_hz: float


@dataclass(slots=True)
class VendorRule:
    name: str
    weights: np.ndarray
    limit: float | None = None


@dataclass(slots=True)
class VendorCavitationProfile:
    source_ini: Path | None = None
    acquisition_ini: Path | None = None
    bands: list[VendorBand] = field(default_factory=list)
    increase_rule0: VendorRule | None = None
    display_rules: dict[int, VendorRule] = field(default_factory=dict)
    graph_low_hz: float | None = None
    graph_high_hz: float | None = None
    calculated_e_factor: float | None = None


@dataclass(slots=True)
class VendorHistoryValidation:
    status: str = "Not validated"
    source_log: Path | None = None
    matched_samples: int = 0
    correlation: float | None = None
    mae: float | None = None
    max_abs_error: float | None = None
    cycle_offset: int | None = None
    weighted_history: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    normalized_display_rule1: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    display_rule1_matched_samples: int = 0
    display_rule1_correlation: float | None = None
    display_rule1_mae: float | None = None
    note: str = ""


class CpcVendorReproductionService:
    """Recover vendor band definitions and validate CPC energy histories.

    The 6.33 CPC export carries enough redundant evidence to prove the semantic
    identity of one saved 8-channel history.  The INI defines Band0..Band3 and
    rule weights; Acquisition_Brain logs record the rule's Calculated Energy on
    each acquisition cycle.  If weighted saved history reproduces those logged
    values to floating-point precision, the history can be labelled as vendor
    Band0 energy rather than a generic signal.
    """

    _BAND_RE = re.compile(r"^Bandwidth_(\d+)\s*=\s*([-+0-9.eE]+)\s+([-+0-9.eE]+)", re.I)
    _KV_RE = re.compile(r"^\s*([^;=]+?)\s*=\s*([^;]+)")

    @staticmethod
    def _find_upwards(start: Path | None, relative_candidates: tuple[str, ...], glob_names: tuple[str, ...] = ()) -> Path | None:
        if start is None:
            return None
        base = Path(start).resolve()
        if base.is_file():
            base = base.parent
        for parent in (base, *base.parents):
            for rel in relative_candidates:
                candidate = parent / rel
                if candidate.exists() and candidate.is_file():
                    return candidate
            for name in glob_names:
                matches = sorted(parent.glob(name))
                if matches:
                    return matches[0]
        return None

    @staticmethod
    def _section(text: str, name: str) -> list[str]:
        lines = text.splitlines()
        target = name.strip().lower()
        active = False
        out: list[str] = []
        for line in lines:
            m = re.match(r"^\s*\[([^]]+)\]", line)
            if m:
                if active:
                    break
                active = m.group(1).strip().lower() == target
                continue
            if active:
                out.append(line)
        return out

    @classmethod
    def _key_value(cls, lines: list[str], key: str) -> str | None:
        key_l = key.lower()
        for line in lines:
            m = cls._KV_RE.match(line)
            if m and m.group(1).strip().lower() == key_l:
                return m.group(2).strip()
        return None

    @staticmethod
    def _numbers(value: str | None) -> list[float]:
        if not value:
            return []
        return [float(v) for v in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?", value)]

    def read_profile(self, source_path: Path | None, main_frequency_hz: float) -> VendorCavitationProfile:
        profile = VendorCavitationProfile()
        safety = self._find_upwards(
            source_path,
            ("Site/Ini/CavitationSafetyAndControl.ini", "CPCFiles/Site/Ini/CavitationSafetyAndControl.ini"),
        )
        acquisition = self._find_upwards(
            source_path,
            ("App/Ini/Acquisition.ini", "CPCFiles/App/Ini/Acquisition.ini"),
        )
        profile.source_ini = safety
        profile.acquisition_ini = acquisition
        if acquisition:
            text = acquisition.read_text(encoding="utf-8", errors="ignore")
            lines = self._section(text, "SPECTRUM")
            vals = self._numbers(self._key_value(lines, "f1ForGraph")); profile.graph_low_hz = vals[0] if vals else None
            vals = self._numbers(self._key_value(lines, "f2ForGraph")); profile.graph_high_hz = vals[0] if vals else None
            vals = self._numbers(self._key_value(lines, "CalculatedE_Factor")); profile.calculated_e_factor = vals[0] if vals else None
        if not safety:
            return profile
        text = safety.read_text(encoding="utf-8", errors="ignore")
        harmonic_lines = self._section(text, "HARMONICS_BANDWIDTHS")
        for line in harmonic_lines:
            m = self._BAND_RE.match(line.strip())
            if not m:
                continue
            index = int(m.group(1)); ratio = float(m.group(2)); delta_hz = float(m.group(3)) * 1000.0
            center = float(main_frequency_hz) * ratio
            profile.bands.append(VendorBand(index, ratio, delta_hz, center-delta_hz, center+delta_hz))
        profile.bands.sort(key=lambda b: b.index)

        inc = self._section(text, "INCREASE_POWER_RULE_0")
        weights = self._numbers(self._key_value(inc, "IncreaseRuleWeight"))
        limit_n = self._numbers(self._key_value(inc, "BottomLimitOfHarmlessEnergy"))
        if len(weights) >= 32:
            profile.increase_rule0 = VendorRule("Increase Power Rule 0", np.asarray(weights[:32], float).reshape(8,4), limit_n[0] if limit_n else None)

        for rule_index in range(8):
            lines = self._section(text, f"DISPLAY_RULE_{rule_index}")
            weights = self._numbers(self._key_value(lines, "DisplayRuleWeight"))
            limit_n = self._numbers(self._key_value(lines, "MaximumEnergyForAllHydrophones"))
            if len(weights) >= 32:
                profile.display_rules[rule_index] = VendorRule(
                    f"Display Rule {rule_index}", np.asarray(weights[:32], float).reshape(8,4), limit_n[0] if limit_n else None
                )
        return profile

    @staticmethod
    def weighted_band0(history_channels: list[np.ndarray], weights_8x4: np.ndarray) -> np.ndarray:
        if len(history_channels) < 8 or weights_8x4.shape != (8,4):
            return np.asarray([], dtype=float)
        length = min(len(np.asarray(ch)) for ch in history_channels[:8])
        if length <= 0:
            return np.asarray([], dtype=float)
        matrix = np.vstack([np.asarray(ch, float)[:length] for ch in history_channels[:8]])
        weights = np.asarray(weights_8x4[:,0], float)
        return np.nansum(matrix * weights[:,None], axis=0)

    @staticmethod
    def _parse_sessions(log_path: Path) -> list[list[tuple[int, float]]]:
        sessions: list[list[tuple[int, float]]] = []
        current: list[tuple[int, float]] | None = None
        pending: float | None = None
        for line in log_path.read_text(encoding="utf-8", errors="ignore").splitlines():
            if "Got StartSpectrumMeasurement" in line:
                if current:
                    sessions.append(current)
                current = []
                pending = None
                continue
            if current is None:
                continue
            m = re.search(r"Increase Power Rule no\.\s*0.*Calculated Energy:\s*<([-+0-9.eE]+)>", line, re.I)
            if m:
                try:
                    pending = float(m.group(1))
                except ValueError:
                    pending = None
            m = re.search(r"Cycle\s+(\d+)\s+Done", line, re.I)
            if m and pending is not None:
                current.append((int(m.group(1)), pending))
                pending = None
            if "Got StopSpectrumMeasurement" in line and current:
                sessions.append(current); current = None; pending = None
        if current:
            sessions.append(current)
        return sessions

    @staticmethod
    def _parse_display_rule1_sessions(log_path: Path) -> list[list[tuple[int, float]]]:
        sessions: list[list[tuple[int, float]]] = []
        current: list[tuple[int, float]] | None = None
        for line in log_path.read_text(encoding="utf-8", errors="ignore").splitlines():
            if "Got StartSpectrumMeasurement" in line:
                if current:
                    sessions.append(current)
                current = []
                continue
            if current is None:
                continue
            m_cycle = re.search(r"Cycle\s+(\d+)\s+Done", line, re.I)
            m_rule = re.search(r"Display:\s*.*?Rule\s*<1>:\s*([-+0-9.eE]+)", line, re.I)
            if m_cycle and m_rule:
                try:
                    current.append((int(m_cycle.group(1)), float(m_rule.group(1))))
                except ValueError:
                    pass
            if "Got StopSpectrumMeasurement" in line and current:
                sessions.append(current); current = None
        if current:
            sessions.append(current)
        return sessions

    def validate_saved_band0_history(self, source_path: Path | None, history_channels: list[np.ndarray], profile: VendorCavitationProfile) -> VendorHistoryValidation:
        result = VendorHistoryValidation()
        rule = profile.increase_rule0
        if rule is None:
            result.note = "Increase Power Rule 0 was not decoded from CavitationSafetyAndControl.ini."
            return result
        weighted = self.weighted_band0(history_channels, rule.weights)
        result.weighted_history = weighted
        if weighted.size == 0:
            result.note = "Saved CPC 8-channel history is unavailable."
            return result
        if rule.limit and rule.limit > 0:
            # CGA/Acquisition Display Rule reports Energy / MaximumEnergy.
            display_rule = profile.display_rules.get(1)
            display_limit = display_rule.limit if display_rule and display_rule.limit else None
            if display_limit and display_limit > 0:
                result.normalized_display_rule1 = weighted / float(display_limit)
        log_path = self._find_upwards(source_path, (), ("Acquisition_Brain_*.txt",))
        if log_path is None:
            result.status = "INI-derived"
            result.note = "Band0 weighting decoded, but Acquisition_Brain log was not found for numerical validation."
            return result
        result.source_log = log_path
        sessions = self._parse_sessions(log_path)
        candidates = []
        for session_index, session in enumerate(sessions):
            xs=[]; ys=[]
            for cycle, value in session:
                # Acquisition cycle numbering is 1-based; saved history array is 0-based.
                idx = cycle - 1
                if 0 <= idx < weighted.size:
                    xs.append(float(weighted[idx])); ys.append(float(value))
            if len(xs) < 20:
                continue
            xa=np.asarray(xs,float); ya=np.asarray(ys,float)
            finite=np.isfinite(xa)&np.isfinite(ya)
            if np.count_nonzero(finite)<20:
                continue
            xa=xa[finite]; ya=ya[finite]
            corr=float(np.corrcoef(xa,ya)[0,1]) if np.std(xa)>0 and np.std(ya)>0 else float('nan')
            errors=np.abs(xa-ya)
            mae=float(np.mean(errors)); maxerr=float(np.max(errors))
            candidates.append((mae, -corr if math.isfinite(corr) else 0.0, session_index, len(xa), corr, maxerr))
        if not candidates:
            result.status = "INI-derived"
            result.note = "No Acquisition log session overlapped enough saved history cycles for validation."
            return result
        mae, _negcorr, session_index, count, corr, maxerr = min(candidates)
        result.matched_samples=count; result.correlation=corr; result.mae=mae; result.max_abs_error=maxerr; result.cycle_offset=-1
        # Independently validate the normalized CGA/Acquisition Display Rule 1.
        if result.normalized_display_rule1.size:
            display_candidates=[]
            for dsession in self._parse_display_rule1_sessions(log_path):
                dx=[]; dy=[]
                for cycle, value in dsession:
                    idx=cycle-1
                    if 0 <= idx < result.normalized_display_rule1.size and math.isfinite(value):
                        dx.append(float(result.normalized_display_rule1[idx])); dy.append(float(value))
                if len(dx) < 20:
                    continue
                dxa=np.asarray(dx,float); dya=np.asarray(dy,float)
                dcorr=float(np.corrcoef(dxa,dya)[0,1]) if np.std(dxa)>0 and np.std(dya)>0 else float('nan')
                dmae=float(np.mean(np.abs(dxa-dya)))
                display_candidates.append((dmae, -dcorr if math.isfinite(dcorr) else 0.0, len(dxa), dcorr))
            if display_candidates:
                dmae,_neg,nmatch,dcorr=min(display_candidates)
                result.display_rule1_matched_samples=nmatch; result.display_rule1_correlation=dcorr; result.display_rule1_mae=dmae
        if math.isfinite(corr) and corr >= 0.999 and mae <= 1e-5 and maxerr <= 5e-5:
            result.status = "EXACT vendor Band0 history"
            result.note = (
                f"Saved 8CH history weighted by INCREASE_POWER_RULE_0 reproduces Acquisition log Calculated Energy: "
                f"n={count}, r={corr:.6f}, MAE={mae:.3g}, max error={maxerr:.3g}; cycle N maps to history[N-1]."
                + (f" Display Rule 1 also matches Energy/MaximumEnergy: n={result.display_rule1_matched_samples}, "
                   f"r={result.display_rule1_correlation:.6f}, MAE={result.display_rule1_mae:.3g}."
                   if result.display_rule1_matched_samples and result.display_rule1_correlation is not None and result.display_rule1_mae is not None else "")
            )
        else:
            result.status = "Partial validation"
            result.note = f"Best log match: n={count}, r={corr:.6f}, MAE={mae:.3g}, max error={maxerr:.3g}."
        return result
