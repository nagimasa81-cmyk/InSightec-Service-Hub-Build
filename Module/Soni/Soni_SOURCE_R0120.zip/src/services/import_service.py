from __future__ import annotations

import shutil
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

from src.services.zip_password_service import ZipPasswordService


class ImportService:
    """Open treatment folders or ZIP packages in an isolated workspace."""

    def __init__(self, zip_password_service: ZipPasswordService | None = None) -> None:
        self.temp_dirs: list[Path] = []
        self.zip_passwords = zip_password_service or ZipPasswordService()

    @staticmethod
    def _validate_member(name: str) -> None:
        normalized = name.replace("\\", "/")
        member = PurePosixPath(normalized)
        if member.is_absolute() or ".." in member.parts:
            raise ValueError(f"Unsafe ZIP entry rejected: {name}")
        if member.parts and ":" in member.parts[0]:
            raise ValueError(f"Unsafe ZIP entry rejected: {name}")

    @staticmethod
    def _is_encrypted(infos: list) -> bool:
        # Bit 0 of the general-purpose flag marks the entry as encrypted
        # (ZIP APPNOTE 4.4.4). Any encrypted member means the archive needs
        # a password before extraction can proceed.
        return any(bool(info.flag_bits & 0x1) for info in infos)

    def _extract_all(self, archive: zipfile.ZipFile, infos: list, temp: Path, progress_callback, pwd: bytes | None) -> None:
        total = max(1, len(infos))
        for index, info in enumerate(infos):
            archive.extract(info, temp, pwd=pwd)
            if progress_callback and (index % max(1, total // 80) == 0 or index == total - 1):
                value = 5 + int(65 * (index + 1) / total)
                progress_callback(value, f"Extracting files... {index+1}/{total}")

    @staticmethod
    def _clear_dir(path: Path) -> None:
        for child in path.iterdir():
            if child.is_dir():
                shutil.rmtree(child, ignore_errors=True)
            else:
                child.unlink(missing_ok=True)

    def _extract_password_protected(self, archive: zipfile.ZipFile, infos: list, temp: Path, progress_callback) -> None:
        """Try every configured candidate password in order.

        Each attempt starts from an empty temp directory so a wrong
        password's partial/garbage output never mixes with the next
        attempt's files. Stops (raises) the moment it is clear no
        configured password will work, per spec: never guess beyond the
        configured list.
        """
        candidates = self.zip_passwords.get_passwords()
        if not candidates:
            raise PermissionError(
                "This ZIP is password-protected, and no ZIP password is configured. "
                "Add one in ZIP password settings, then try again."
            )
        unsupported_encryption = False
        for candidate in candidates:
            self._clear_dir(temp)
            try:
                self._extract_all(archive, infos, temp, progress_callback, pwd=candidate.encode("utf-8"))
                return
            except NotImplementedError:
                # Strong (e.g. WinZip AES) encryption: Python's stdlib zipfile
                # cannot decrypt this regardless of which password is correct.
                # No candidate password will ever succeed; stop trying more of
                # them, but still report the outcome after the loop so the
                # message explains *why*, not just "failed".
                # NOTE: NotImplementedError is a RuntimeError subclass, so this
                # clause MUST be checked before the plain RuntimeError one below
                # -- Python tries except clauses in source order, and the wider
                # RuntimeError branch would otherwise swallow it first and
                # mis-report it as "wrong password".
                unsupported_encryption = True
                break
            except RuntimeError as exc:
                # Wrong password for standard ZipCrypto: zipfile raises RuntimeError
                # with a message naming the bad password/file. Try the next candidate.
                if "password" in str(exc).lower():
                    continue
                raise
            except zipfile.BadZipFile:
                # Decompressed but failed its CRC check: also a wrong-password
                # signal for ZipCrypto-protected members with compressed data.
                continue
        self._clear_dir(temp)
        if unsupported_encryption:
            raise PermissionError(
                "This ZIP uses an encryption method this app cannot decrypt "
                "(e.g. AES). Ask the sender for a standard password-protected ZIP."
            )
        raise PermissionError(
            "This ZIP is password-protected and no configured ZIP password could open it. "
            "Extraction stopped; add the correct password in ZIP password settings and try again."
        )

    def open(self, source: Path, progress_callback=None) -> Path:
        source = source.expanduser().resolve()
        if source.is_dir():
            if progress_callback: progress_callback(70, "Using selected folder...")
            return source
        if not source.is_file():
            raise FileNotFoundError(f"Source not found: {source}")
        if source.suffix.lower() != ".zip":
            raise ValueError("Select a ZIP file or folder.")

        temp = Path(tempfile.mkdtemp(prefix="SonicationReplay_"))
        try:
            with zipfile.ZipFile(source) as archive:
                # Do not call ZipFile.testzip() here.  extract() reads each member
                # and validates its CRC, so testzip() would decompress the complete
                # Export a second time before extraction.
                infos = archive.infolist()
                for info in infos:
                    self._validate_member(info.filename)
                if self._is_encrypted(infos):
                    self._extract_password_protected(archive, infos, temp, progress_callback)
                else:
                    self._extract_all(archive, infos, temp, progress_callback, pwd=None)
        except Exception:
            shutil.rmtree(temp, ignore_errors=True)
            raise

        self.temp_dirs.append(temp)
        return temp

    def release(self, workspace: Path | None) -> None:
        if workspace is None:
            return
        resolved = workspace.resolve()
        for temp in list(self.temp_dirs):
            if temp.resolve() == resolved:
                shutil.rmtree(temp, ignore_errors=True)
                self.temp_dirs.remove(temp)

    def cleanup(self) -> None:
        for path in self.temp_dirs:
            shutil.rmtree(path, ignore_errors=True)
        self.temp_dirs.clear()
