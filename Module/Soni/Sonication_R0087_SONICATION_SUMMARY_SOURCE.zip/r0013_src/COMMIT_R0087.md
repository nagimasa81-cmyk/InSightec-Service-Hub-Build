# COMMIT R0087 — Sonication Summary

## Summary
Adds a treatment-level Sonication Summary view so users can compare all Sonications in one table and display selectable trend charts across treatment order.

## Added
- New `Sonication Summary` tab
- Summary table for all Sonications in treatment order
- Chart selector for:
  - Cavitation status
  - Cavitation RCA score
  - Power (W)
  - Duration (s)
  - Energy (J)
  - Start temperature (°C)
  - Peak temperature (°C)
  - ΔT (°C)
- Cavitation marker overlay (toggle)
- Double-click a row to jump Replay to that Sonication
- Current Sonication indicator line on the chart

## Table columns
- Sonication No.
- Name
- Cavitation status
- RCA score
- Power
- Duration
- Energy
- Start temperature
- Peak temperature
- Delta temperature
- Replay frames

## Cavitation status logic
- `Detected`: control-event / cavitation-event evidence present
- `Warning`: no explicit event, but RCA indicates elevated cavitation risk
- `None`: no event and no warning evidence
- `Unavailable`: evidence unavailable
