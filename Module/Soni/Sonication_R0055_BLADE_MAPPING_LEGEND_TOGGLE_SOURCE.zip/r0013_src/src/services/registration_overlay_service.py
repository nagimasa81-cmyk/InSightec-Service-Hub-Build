from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
import numpy as np


@dataclass(slots=True)
class RegistrationOverlayResult:
    overlay: np.ndarray | None
    matrix: np.ndarray | None
    matrix_source: Path | None
    ct_source: Path | None
    status: str
    selected_slice_index: int | None = None
    alignment_score: float | None = None


@dataclass(slots=True)
class CtGeometry:
    origin_ras: np.ndarray
    row_direction: np.ndarray
    col_direction: np.ndarray
    slice_direction: np.ndarray
    pixel_size_x: float
    pixel_size_y: float
    slice_spacing: float
    source: Path


class RegistrationOverlayService:
    """Render an evidence-preserving CT bone overlay on planning MR.

    The treatment export stores the adopted CT↔MR registration in CtMr_mat.txt.
    For the 2-D replay review we project the relevant in-plane rotation and
    translation from that 4x4 matrix onto the selected MR plane. This is not a
    replacement for a full 3-D reslice; it is deliberately labelled as a 2-D
    treatment-registration review overlay.
    """

    _FLOAT_RE = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?")

    @classmethod
    def read_matrix(cls, path: Path | None) -> np.ndarray | None:
        if path is None or not Path(path).is_file():
            return None
        try:
            vals = [float(x) for x in cls._FLOAT_RE.findall(Path(path).read_text(encoding='utf-8', errors='ignore'))]
        except (OSError, ValueError):
            return None
        if len(vals) < 16:
            return None
        return np.asarray(vals[:16], float).reshape(4, 4)

    @staticmethod
    def find_treatment_matrix(workspace: Path, sonication_index: int) -> Path | None:
        candidates = [
            workspace / f"Sonication{sonication_index}" / "CtMr_mat.txt",
            workspace / f"Sonication_{sonication_index}" / "CtMr_mat.txt",
            workspace / "WSFiles" / "lastCtMrRegistration_mat.txt",
        ]
        for p in candidates:
            if p.is_file():
                return p
        hits = sorted(workspace.rglob("CtMr_mat.txt"))
        return hits[0] if hits else None

    @staticmethod
    def find_treatment_mrmr_matrix(workspace: Path, sonication_index: int) -> Path | None:
        candidates = [
            workspace / f"Sonication{sonication_index}" / "MrMr_mat.txt",
            workspace / f"Sonication_{sonication_index}" / "MrMr_mat.txt",
            workspace / "WSFiles" / "lastMrMrRegistration_mat.txt",
        ]
        for p in candidates:
            if p.is_file():
                return p
        hits = sorted(workspace.rglob("MrMr_mat.txt"))
        return hits[0] if hits else None

    @staticmethod
    def _row_float(row, *names):
        low={str(k).lower():v for k,v in row.items()}
        for name in names:
            if name.lower() in low:
                try: return float(low[name.lower()])
                except (TypeError,ValueError): pass
        return None

    @classmethod
    def _vec_from_row(cls,row,prefixes):
        for px,py,pz in prefixes:
            vals=[cls._row_float(row,px),cls._row_float(row,py),cls._row_float(row,pz)]
            if all(v is not None for v in vals):
                a=np.asarray(vals,float); n=float(np.linalg.norm(a))
                if n>1e-6: return a/n
        return None

    @classmethod
    def read_ct_geometry(cls, workspace: Path, ct_asset=None) -> CtGeometry | None:
        """Recover CT voxel→RAS geometry from exported CT metadata.

        Prefer per-slice CtImage rows because consecutive TopLeftCoord values
        directly establish the true slice direction/spacing. This prevents the
        old centered-pixel approximation from being presented as registration.
        """
        try:
            from src.parsers.ado_rowset import parse_ado_rowset
        except Exception:
            return None
        workspace=Path(workspace)
        paths=[p for p in workspace.rglob('*') if p.is_file() and p.name.lower() in {'ctimage.xml','ctvolumedata.xml'}]
        target_field=getattr(ct_asset,'field_index',16) if ct_asset is not None else 16
        target_son=getattr(ct_asset,'sonication_index',None) if ct_asset is not None else None
        for path in paths:
            try: rows=parse_ado_rowset(path)
            except Exception: continue
            candidates=[]
            for row in rows:
                low={str(k).lower():v for k,v in row.items()}
                try: field=int(low.get('fieldindex',target_field))
                except (TypeError,ValueError): field=target_field
                if path.name.lower()=='ctimage.xml' and field != target_field: continue
                if target_son is not None and 'sonicationindex' in low:
                    try:
                        if int(low['sonicationindex']) != int(target_son): continue
                    except (TypeError,ValueError): pass
                ox=cls._row_float(row,'topleftcoordr','originr','origin_r','voloriginr','ctoriginr')
                oy=cls._row_float(row,'topleftcoorda','origina','origin_a','volorigina','ctorigina')
                oz=cls._row_float(row,'topleftcoords','origins','origin_s','volorigins','ctorigins')
                if None in (ox,oy,oz): continue
                rd=cls._vec_from_row(row,[( 'rowdirectcosrasx','rowdirectcosrasy','rowdirectcosrasz'),('rowdirectionx','rowdirectiony','rowdirectionz')])
                cd=cls._vec_from_row(row,[( 'coldirectcosrasx','coldirectcosrasy','coldirectcosrasz'),('coldirectionx','coldirectiony','coldirectionz')])
                if rd is None or cd is None: continue
                px=cls._row_float(row,'pixsizex','pixelsizex','voxsizex','voxelsizex')
                py=cls._row_float(row,'pixsizey','pixelsizey','voxsizey','voxelsizey')
                if not px or not py: continue
                try: order=int(low.get('arrayindex',low.get('sliceindex',len(candidates))))
                except (TypeError,ValueError): order=len(candidates)
                candidates.append((order,np.asarray([ox,oy,oz],float),rd,cd,float(px),float(py)))
            if not candidates: continue
            candidates.sort(key=lambda x:x[0])
            order,origin,rd,cd,px,py=candidates[0]
            normal=np.cross(rd,cd); nn=float(np.linalg.norm(normal))
            if nn<1e-6: continue
            normal/=nn
            spacing=None; sdir=normal
            if len(candidates)>=2:
                diffs=[]
                for a,b in zip(candidates[:-1],candidates[1:]):
                    d=b[1]-a[1]; n=float(np.linalg.norm(d))
                    if n>1e-5: diffs.append(d)
                if diffs:
                    d=np.median(np.asarray(diffs),axis=0); spacing=float(np.linalg.norm(d)); sdir=d/max(spacing,1e-9)
            if not spacing:
                row0=rows[0] if rows else {}
                spacing=cls._row_float(row0,'slicespacing','slicethickness','pixsizez','voxsizez','voxelsizez')
            if not spacing or spacing<=0: continue
            return CtGeometry(origin,rd,cd,sdir,px,py,float(spacing),path)
        return None

    @staticmethod
    def _mr_geometry(mr_asset):
        if mr_asset is None: return None
        vals=[getattr(mr_asset,k,None) for k in ('top_left_r','top_left_a','top_left_s','pixel_size_x','pixel_size_y')]
        if any(v is None for v in vals): return None
        rd=np.asarray(getattr(mr_asset,'row_direction',None),float); cd=np.asarray(getattr(mr_asset,'col_direction',None),float)
        if rd.size!=3 or cd.size!=3 or np.linalg.norm(rd)<1e-6 or np.linalg.norm(cd)<1e-6: return None
        return np.asarray(vals[:3],float),rd/np.linalg.norm(rd),cd/np.linalg.norm(cd),float(vals[3]),float(vals[4])

    def _world_reslice(self, volume, mr_shape, mr_asset, ct_geom: CtGeometry, matrix, matrix_direction: str):
        mg=self._mr_geometry(mr_asset)
        if mg is None: return None
        origin,rd,cd,px,py=mg; h,w=map(int,mr_shape[:2]); yy,xx=np.mgrid[0:h,0:w]
        world=origin[:,None,None] + rd[:,None,None]*(xx*px) + cd[:,None,None]*(yy*py)
        pts=np.vstack([world.reshape(3,-1),np.ones((1,h*w))])
        try:
            if matrix_direction=='CtMr': ct_world=np.linalg.inv(matrix)@pts
            else: ct_world=matrix@pts
        except np.linalg.LinAlgError: return None
        basis=np.column_stack([ct_geom.row_direction*ct_geom.pixel_size_x,ct_geom.col_direction*ct_geom.pixel_size_y,ct_geom.slice_direction*ct_geom.slice_spacing])
        try: inv_basis=np.linalg.inv(basis)
        except np.linalg.LinAlgError: return None
        ijk=inv_basis@(ct_world[:3]-ct_geom.origin_ras[:,None])
        x=ijk[0].reshape(h,w); y=ijk[1].reshape(h,w); z=ijk[2].reshape(h,w)
        vol=np.asarray(volume,float); d,hh,ww=vol.shape
        x0=np.floor(x).astype(int); y0=np.floor(y).astype(int); z0=np.floor(z).astype(int)
        x1=x0+1; y1=y0+1; z1=z0+1
        valid=(x0>=0)&(y0>=0)&(z0>=0)&(x1<ww)&(y1<hh)&(z1<d)
        out=np.full((h,w),np.nan,float)
        if not np.any(valid): return out
        xv=x[valid]; yv=y[valid]; zv=z[valid]; xa=x0[valid]; xb=x1[valid]; ya=y0[valid]; yb=y1[valid]; za=z0[valid]; zb=z1[valid]
        wx=xv-xa; wy=yv-ya; wz=zv-za
        c000=vol[za,ya,xa]; c100=vol[za,ya,xb]; c010=vol[za,yb,xa]; c110=vol[za,yb,xb]
        c001=vol[zb,ya,xa]; c101=vol[zb,ya,xb]; c011=vol[zb,yb,xa]; c111=vol[zb,yb,xb]
        c00=c000*(1-wx)+c100*wx; c10=c010*(1-wx)+c110*wx; c01=c001*(1-wx)+c101*wx; c11=c011*(1-wx)+c111*wx
        c0=c00*(1-wy)+c10*wy; c1=c01*(1-wy)+c11*wy; out[valid]=c0*(1-wz)+c1*wz
        return self._bone_edges(out)

    @staticmethod
    def _plane_axes(plane: str) -> tuple[int, int]:
        p = (plane or '').lower()
        if 'sag' in p:
            return (1, 2)  # A/S
        if 'cor' in p:
            return (0, 2)  # R/S
        return (0, 1)      # R/A (Axial default)

    @staticmethod
    def _bilinear_sample(image: np.ndarray, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        h, w = image.shape[:2]
        x0 = np.floor(x).astype(int); y0 = np.floor(y).astype(int)
        x1 = x0 + 1; y1 = y0 + 1
        valid = (x0 >= 0) & (y0 >= 0) & (x1 < w) & (y1 < h)
        out = np.full(x.shape, np.nan, float)
        if not np.any(valid):
            return out
        xv = x[valid]; yv = y[valid]
        x0v=x0[valid]; x1v=x1[valid]; y0v=y0[valid]; y1v=y1[valid]
        wx=xv-x0v; wy=yv-y0v
        a=image[y0v,x0v]; b=image[y0v,x1v]; c=image[y1v,x0v]; d=image[y1v,x1v]
        out[valid]=(1-wx)*(1-wy)*a + wx*(1-wy)*b + (1-wx)*wy*c + wx*wy*d
        return out

    @staticmethod
    def _bone_edges(ct: np.ndarray) -> np.ndarray:
        arr=np.asarray(ct,float)
        finite=arr[np.isfinite(arr)]
        if finite.size < 64:
            return np.full(arr.shape, np.nan, float)
        # Signed HU-like CT: isolate the high-density tail.  A pure percentile
        # can collapse to background when most voxels are zero, so combine it
        # with a fraction of the observed dynamic range.
        low=float(np.percentile(finite, 5)); high=float(np.percentile(finite, 99.5))
        if float(np.nanmax(finite)) - float(np.nanmin(finite)) <= np.finfo(float).eps:
            return np.full(arr.shape, np.nan, float)
        threshold=max(float(np.percentile(finite, 84)), low + 0.30*max(high-low, 0.0))
        if high <= low or threshold >= float(np.nanmax(finite)):
            threshold=low + 0.50*max(float(np.nanmax(finite))-low, 0.0)
        mask=(arr >= threshold).astype(float)
        gy,gx=np.gradient(mask)
        edge=np.hypot(gx,gy) > 0.05
        # One-pixel dilation makes the skull trace visible on laptop displays
        # without turning the CT into an opaque fill.
        e=edge.copy()
        for dy in (-1,0,1):
            for dx in (-1,0,1):
                if dx==0 and dy==0: continue
                e |= np.roll(np.roll(edge,dy,axis=0),dx,axis=1)
        e[[0,-1],:]=False; e[:,[0,-1]]=False
        return np.where(e, arr, np.nan)

    def project_2d(self, ct: np.ndarray, mr_shape: tuple[int,int], matrix: np.ndarray, plane: str,
                   ct_pixel_mm: float = 0.5, mr_pixel_mm: tuple[float,float] = (1.0,1.0)) -> np.ndarray:
        ct=np.asarray(ct,float)
        mh,mw=int(mr_shape[0]),int(mr_shape[1])
        ch,cw=ct.shape[:2]
        axes=self._plane_axes(plane)
        rot=matrix[np.ix_(axes, axes)]
        trans=matrix[list(axes), 3]
        # Mapping output MR pixel -> source CT pixel. Invert the treatment transform.
        try:
            inv=np.linalg.inv(rot)
        except np.linalg.LinAlgError:
            inv=np.eye(2)
        yy,xx=np.mgrid[0:mh,0:mw]
        mx=(xx-(mw-1)/2.0)*float(mr_pixel_mm[0])
        my=(yy-(mh-1)/2.0)*float(mr_pixel_mm[1])
        pts=np.stack([mx-trans[0], my-trans[1]],axis=0).reshape(2,-1)
        src=inv@pts
        sx=(src[0]/float(ct_pixel_mm)+(cw-1)/2.0).reshape(mh,mw)
        sy=(src[1]/float(ct_pixel_mm)+(ch-1)/2.0).reshape(mh,mw)
        warped=self._bilinear_sample(ct,sx,sy)
        return self._bone_edges(warped)


    @staticmethod
    def _mr_edge_strength(mr: np.ndarray) -> np.ndarray:
        arr=np.asarray(mr,float)
        finite=arr[np.isfinite(arr)]
        if finite.size < 64:
            return np.zeros(arr.shape,float)
        lo,hi=np.percentile(finite,[2,98.5])
        scaled=np.clip((arr-lo)/max(hi-lo,1e-9),0,1)
        gy,gx=np.gradient(scaled)
        return np.hypot(gx,gy)

    @classmethod
    def _alignment_score(cls, mr: np.ndarray, bone_overlay: np.ndarray) -> float:
        edge=np.isfinite(bone_overlay)
        if np.count_nonzero(edge) < 20:
            return float('-inf')
        mr_edge=cls._mr_edge_strength(mr)
        vals=mr_edge[edge]
        if vals.size < 20:
            return float('-inf')
        # Reward bone edges that land on strong MR anatomical boundaries while
        # mildly penalizing overlays that cover an excessive fraction of image.
        score=float(np.nanmean(vals))
        density=float(np.count_nonzero(edge))/float(edge.size)
        return score-0.12*max(0.0,density-0.12)

    @staticmethod
    def _volume_plane_slices(volume: np.ndarray, plane: str):
        vol=np.asarray(volume,float)
        p=(plane or '').lower()
        if vol.ndim != 3:
            return []
        if 'sag' in p:
            return [(i,vol[:,:,i]) for i in range(vol.shape[2])]
        if 'cor' in p:
            return [(i,vol[:,i,:]) for i in range(vol.shape[1])]
        return [(i,vol[i,:,:]) for i in range(vol.shape[0])]

    def _registration_hypotheses(self, workspace: Path, sonication_index: int, mr_asset, ctmr: np.ndarray):
        """Return evidence-preserving transform hypotheses.

        CtMr direction differs across exported generations.  Planning MR uses the
        treatment CtMr directly, while preplanning MR may require the treatment
        MrMr chain.  Rather than hard-code an unverified direction, evaluate the
        small set of physically plausible matrix directions against MR/CT edges
        and retain the best-supported one.
        """
        out=[("CtMr",ctmr)]
        try: out.append(("inv(CtMr)",np.linalg.inv(ctmr)))
        except np.linalg.LinAlgError: pass
        category=str(getattr(mr_asset,'category','') or '').upper()
        if category.startswith('PREPLANNING_MR'):
            mp=self.find_treatment_mrmr_matrix(Path(workspace),sonication_index)
            mm=self.read_matrix(mp)
            if mm is not None:
                combos=[]
                try: combos.append(("inv(MrMr) × CtMr",np.linalg.inv(mm)@ctmr))
                except np.linalg.LinAlgError: pass
                combos.append(("MrMr × CtMr",mm@ctmr))
                try: combos.append(("CtMr × inv(MrMr)",ctmr@np.linalg.inv(mm)))
                except np.linalg.LinAlgError: pass
                combos.append(("CtMr × MrMr",ctmr@mm))
                out=combos+out
        # de-duplicate numerically equivalent candidates
        unique=[]
        for name,m in out:
            if not any(np.allclose(m,u[1],rtol=1e-7,atol=1e-7) for u in unique): unique.append((name,m))
        return unique

    def render_volume(self, workspace: Path, sonication_index: int, mr: np.ndarray, plane: str,
                      ct_asset, ct_volume: np.ndarray, mr_asset=None) -> RegistrationOverlayResult:
        matrix_path=self.find_treatment_matrix(Path(workspace),sonication_index)
        matrix=self.read_matrix(matrix_path)
        if matrix is None:
            return RegistrationOverlayResult(None,None,matrix_path,getattr(ct_asset,'path',None),"Treatment CtMr registration matrix unavailable")
        ct_geom=self.read_ct_geometry(Path(workspace),ct_asset)
        mr_geom=self._mr_geometry(mr_asset)
        if ct_geom is None or mr_geom is None:
            missing=[]
            if ct_geom is None: missing.append("CT voxel/RAS geometry")
            if mr_geom is None: missing.append("MR RAS geometry")
            return RegistrationOverlayResult(None,matrix,matrix_path,getattr(ct_asset,'path',None),
                "Registration matrix decoded, but " + " + ".join(missing) + " is unavailable; misleading centered 2-D bone overlay suppressed")
        best=None
        for direction in ('CtMr','MrCt'):
            overlay=self._world_reslice(ct_volume,np.asarray(mr).shape[:2],mr_asset,ct_geom,matrix,direction)
            if overlay is None: continue
            score=self._alignment_score(mr,overlay)
            if best is None or score>best[0]: best=(score,overlay,direction)
        if best is None or not np.isfinite(best[0]):
            return RegistrationOverlayResult(None,matrix,matrix_path,getattr(ct_asset,'path',None),"Patient-coordinate CT reslice produced no usable skull overlay")
        score,overlay,direction=best
        status=(f"Registration ON · patient-coordinate 3-D CT→MR reslice · matrix {matrix_path.name} ({direction} direction selected by edge evidence) · "
                f"CT geometry {ct_geom.source.name} · MR/CT edge agreement={score:.3f}")
        return RegistrationOverlayResult(overlay,matrix,matrix_path,getattr(ct_asset,'path',None),status,None,float(score))

    def render(self, workspace: Path, sonication_index: int, mr: np.ndarray, plane: str,
               ct_asset, ct_array: np.ndarray, mr_asset=None) -> RegistrationOverlayResult:
        matrix_path=self.find_treatment_matrix(Path(workspace), sonication_index)
        matrix=self.read_matrix(matrix_path)
        if matrix is None:
            return RegistrationOverlayResult(None,None,matrix_path,getattr(ct_asset,'path',None),"Treatment CtMr registration matrix unavailable")
        mr_px=(float(getattr(mr_asset,'pixel_size_x',1.0) or 1.0), float(getattr(mr_asset,'pixel_size_y',1.0) or 1.0))
        overlay=self.project_2d(ct_array, np.asarray(mr).shape[:2], matrix, plane, 0.5, mr_px)
        finite=np.isfinite(overlay)
        status=(f"Registration ON · treatment CtMr matrix: {matrix_path.name} · "
                f"{plane} 2-D projection · bone edge pixels={int(np.count_nonzero(finite))}")
        return RegistrationOverlayResult(overlay,matrix,matrix_path,getattr(ct_asset,'path',None),status)
