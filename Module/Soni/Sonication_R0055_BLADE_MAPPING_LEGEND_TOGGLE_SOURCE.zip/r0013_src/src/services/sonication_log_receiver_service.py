from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re


@dataclass(slots=True)
class SonicChannelValue:
    channel: int
    logical_amplitude: float | None = None
    logical_phase_rad: float | None = None

    @property
    def blade_index(self) -> int:
        """Zero-based blade index for the 1024-element transducer (16 x 64)."""
        return max(0, int(self.channel)) // 64

    @property
    def blade_number(self) -> int:
        """Human-facing Blade number (1..16)."""
        return self.blade_index + 1

    @property
    def blade_channel(self) -> int:
        """Zero-based channel index within the Blade (0..63)."""
        return max(0, int(self.channel)) % 64


@dataclass(slots=True)
class SonicChannelSnapshot:
    timestamp: str | None
    declared_channels: int | None
    source: Path
    values: list[SonicChannelValue] = field(default_factory=list)


class SonicationLogReceiverService:
    """Decode per-sonication 1024-element phase/amplitude log blocks.

    The Sonication_Brain log's ``Channel <n>`` entries are the ultrasound
    transmit elements: 1024 channels arranged as 16 Blades x 64 channels.
    They are a separate namespace from the 8 cavitation receivers RCV0..RCV7.
    """

    _TIME = re.compile(r"\b(\d{1,2}:\d{2}:\d{2}(?:[.:]\d+)?)\b")
    _NUMBER = re.compile(r"Number\s+Of\s+Channels\s*<\s*(\d+)\s*>", re.I)
    _CHANNEL = re.compile(r"\bChannel\s*<\s*(\d+)\s*>", re.I)
    _AMP = re.compile(r"Logical\s+Amplitude\s*<\s*([-+0-9.eE]+)\s*>", re.I)
    _PHASE = re.compile(r"Logical\s+Phase\s*<\s*([-+0-9.eE]+)\s*>", re.I)

    @staticmethod
    def _candidate_files(root: Path) -> list[Path]:
        root=Path(root)
        files=[]
        for p in root.rglob('*'):
            if not p.is_file() or p.suffix.lower() not in {'.txt','.log'}: continue
            n=p.name.lower()
            if 'sonication_' in n or n.startswith('sonication') or 'sonication_brain' in n:
                files.append(p)
        return sorted(files,key=lambda p:(0 if 'cpcfiles' in str(p).lower() else 1,len(p.parts),p.name.lower()))

    def read_snapshots(self, root: Path) -> list[SonicChannelSnapshot]:
        snapshots=[]
        for path in self._candidate_files(Path(root)):
            try: lines=path.read_text(encoding='utf-8',errors='ignore').splitlines()
            except OSError: continue
            current=None; current_channel=None; last_time=None
            def flush():
                nonlocal current,current_channel
                if current is not None and current.values:
                    # Retain the latest entry per channel within this block.
                    by={v.channel:v for v in current.values}; current.values=[by[k] for k in sorted(by)]
                    snapshots.append(current)
                current=None; current_channel=None
            for line in lines:
                tm=self._TIME.search(line)
                if tm: last_time=tm.group(1).replace(':','.',3) if tm.group(1).count(':')==3 else tm.group(1)
                if 'CLoadSonicationData fields' in line:
                    flush(); current=SonicChannelSnapshot(last_time,None,path,[]); continue
                if current is None: continue
                m=self._NUMBER.search(line)
                if m: current.declared_channels=int(m.group(1)); continue
                m=self._CHANNEL.search(line)
                if m:
                    current_channel=int(m.group(1)); current.values.append(SonicChannelValue(current_channel)); continue
                if current_channel is None or not current.values: continue
                m=self._AMP.search(line)
                if m:
                    try: current.values[-1].logical_amplitude=float(m.group(1))
                    except ValueError: pass
                    continue
                m=self._PHASE.search(line)
                if m:
                    try: current.values[-1].logical_phase_rad=float(m.group(1))
                    except ValueError: pass
            flush()
        # De-duplicate repeated identical timestamp/source blocks.
        out=[]; seen=set()
        for snap in snapshots:
            sig=(str(snap.source),snap.timestamp,tuple((v.channel,v.logical_amplitude,v.logical_phase_rad) for v in snap.values))
            if sig in seen: continue
            seen.add(sig); out.append(snap)
        return out
