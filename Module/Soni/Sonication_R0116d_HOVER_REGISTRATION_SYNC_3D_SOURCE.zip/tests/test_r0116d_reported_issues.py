from pathlib import Path
import ast
ROOT=Path(__file__).parents[1]
MAIN=(ROOT/"src/ui/main_window.py").read_text(encoding="utf-8")
REG=(ROOT/"src/services/registration_overlay_service.py").read_text(encoding="utf-8")
def test_hover():
    assert "QSize(640,500)" in MAIN
    assert "popup.setMinimumSize(460,360)" in MAIN
def test_refresh():
    assert "def _refresh_all_sonication_dependent_views" in MAIN
def test_marker_projection():
    assert "def _umbrella_project_status_points" in MAIN
    assert "self._umbrella_project_points" in MAIN
def test_outer_skull():
    assert "external skull envelope" in REG or "outer-skull" in REG
def test_no_duplicates():
    tr=ast.parse(MAIN)
    for node in ast.walk(tr):
        if isinstance(node,ast.ClassDef):
            seen=set()
            for x in node.body:
                if isinstance(x,ast.FunctionDef):
                    assert x.name not in seen, x.name
                    seen.add(x.name)
