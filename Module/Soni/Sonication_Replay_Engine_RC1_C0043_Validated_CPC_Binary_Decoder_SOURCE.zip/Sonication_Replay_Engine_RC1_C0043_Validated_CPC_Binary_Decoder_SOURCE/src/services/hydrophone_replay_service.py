from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import gzip
import struct
import numpy as np


@dataclass(slots=True)
class CpcHydrophoneFrame:
    index: int
    frequency_hz: np.ndarray
    channels: list[np.ndarray]
    raw_channels: list[np.ndarray] = field(default_factory=list)
    duration_s: float = 0.010
    hw_status: int | None = None


@dataclass(slots=True)
class CpcHydrophoneReplay:
    source_fft: Path | None
    source_raw: Path | None
    channel_count: int = 8
    sampling_frequency_hz: float = 0.0
    main_frequency_hz: float = 0.0
    declared_frame_count: int = 0
    total_samples: int = 0
    frames: list[CpcHydrophoneFrame] = field(default_factory=list)
    channel_reference_levels: list[float] = field(default_factory=lambda: [1.0] * 8)
    display_db_min: float = -60.0
    display_db_max: float = 0.0
    note: str = ""
    decoder_confidence: str = "failed"

    @property
    def frame_interval_s(self) -> float:
        values = [f.duration_s for f in self.frames if np.isfinite(f.duration_s) and f.duration_s > 0]
        return float(np.median(values)) if values else 0.010


class HydrophoneReplayService:
    """Decode CPC Spectrum containers without mixing Sonication SpectrumMsg data.

    Header fields of the FFT container are stable in the supplied exports:
    saved-measure count, 8 channels, 16384 acquisition samples, FFT processing
    length, sample rate and sonication frequency.  The vendor record payload is
    not publicly documented, therefore record slicing is isolated and labelled
    diagnostic.  All analysis is calculated from decoded CPC payloads only.
    """

    DEFAULT_BANDS_MHZ = (
        (0.25, 0.30), (0.30, 0.35), (0.35, 0.40),
        (0.40, 0.50), (0.50, 0.65), (0.65, 0.80),
    )

    @staticmethod
    def _read_blob(path: Path | None) -> bytes:
        if path is None:
            return b""
        try:
            with gzip.open(path, "rb") as stream:
                return stream.read()
        except OSError:
            return path.read_bytes()

    def select_files(self, cpc_files: list[Path], sonication_index: int, sonication_count: int) -> tuple[Path | None, Path | None]:
        fft_files = sorted(p for p in cpc_files if p.name.lower().endswith(".dmp_fft"))
        raw_files = sorted(p for p in cpc_files if p.name.lower().endswith(".dmp") and not p.name.lower().endswith(".dmp_fft"))

        def select(items: list[Path]) -> Path | None:
            if not items:
                return None
            mapped = items[-sonication_count:] if sonication_count and len(items) >= sonication_count else items
            return mapped[min(max(sonication_index, 0), len(mapped) - 1)]

        return select(fft_files), select(raw_files)

    def build(self, cpc_files: list[Path], sonication_index: int, sonication_count: int) -> CpcHydrophoneReplay:
        fft_path, raw_path = self.select_files(cpc_files, sonication_index, sonication_count)
        result = CpcHydrophoneReplay(source_fft=fft_path, source_raw=raw_path)
        fft_blob = self._read_blob(fft_path)
        if len(fft_blob) < 40:
            result.note = "No valid CPC Spectrum_*.dmp_FFT container was mapped."
            return result

        first, frame_count, channel_count, total_samples, processing, sample_rate = struct.unpack("<6I", fft_blob[:24])
        main_frequency = struct.unpack("<d", fft_blob[32:40])[0]
        result.channel_count = int(channel_count)
        result.sampling_frequency_hz = float(sample_rate)
        result.main_frequency_hz = float(main_frequency)
        result.declared_frame_count = int(frame_count)
        result.total_samples = int(total_samples)
        if channel_count != 8 or frame_count <= 0:
            result.note = f"Unsupported CPC FFT header: channels={channel_count}, measures={frame_count}."
            return result

        fft_frames = self._decode_fft_payload(fft_blob[40:], frame_count, channel_count, sample_rate)
        raw_frames = self._decode_raw_payload(self._read_blob(raw_path), len(fft_frames), channel_count, total_samples)
        for index, (freq, channels) in enumerate(fft_frames):
            raw = raw_frames[index] if index < len(raw_frames) else []
            result.frames.append(CpcHydrophoneFrame(index, freq, channels, raw_channels=raw))

        result.channel_reference_levels = self._references(result.frames)
        result.decoder_confidence = "validated_fft" if result.frames else "failed"
        if any(f.raw_channels for f in result.frames):
            result.decoder_confidence = "validated_fft_and_raw"
        raw_state = "validated raw decoded" if any(f.raw_channels for f in result.frames) else "raw waveform not verified (disabled)"
        result.note = (
            f"Independent CPC 8CH analyzer: {len(result.frames)} saved measures, {raw_state}, "
            f"Fs={sample_rate/1e6:.3f} MHz, sonication={main_frequency/1e6:.3f} MHz. "
            "FFT blocks are structurally validated; spectrogram and editable band energy are calculated locally. "
            "The proprietary per-record envelope remains diagnostic; channel labels CH0–CH7 are preserved, physical positions are not inferred."
        )
        return result

    @staticmethod
    def _decode_fft_payload(payload: bytes, frame_count: int, channel_count: int, sample_rate: float) -> list[tuple[np.ndarray, list[np.ndarray]]]:
        """Decode validated CPC FFT channel blocks.

        Real CPC exports store each channel spectrum as a 32-bit bin-count marker
        (normally 256), followed by that many float32 bins.  Channel blocks are
        separated by a fixed metadata envelope, and eight consecutive markers
        form one saved measure.  This parser intentionally rejects the old
        equal-slice heuristic.
        """
        if channel_count != 8 or len(payload) < 4096:
            return []
        blob = memoryview(payload)
        markers=[]
        for off in range(0, len(blob)-4, 4):
            n=struct.unpack_from('<I', blob, off)[0]
            if 16 <= n <= 8192 and off + 4 + n*4 <= len(blob):
                vals=np.frombuffer(blob[off+4:off+4+n*4], dtype='<f4')
                finite=np.isfinite(vals)
                if finite.mean() > .995 and np.nanmax(np.abs(vals[finite])) < 1e12:
                    markers.append((off,n))
        groups=[]
        i=0
        while i+7 < len(markers):
            cand=markers[i:i+8]
            if len({n for _,n in cand})==1:
                gaps=np.diff([o for o,_ in cand])
                if np.all(gaps==gaps[0]) and gaps[0] >= 4+cand[0][1]*4:
                    groups.append(cand); i+=8; continue
            i+=1
        frames=[]
        for group in groups[:frame_count]:
            bins=group[0][1]
            channels=[]
            valid=True
            for off,n in group:
                arr=np.frombuffer(blob[off+4:off+4+n*4], dtype='<f4').astype(float)
                if len(arr)!=bins or not np.all(np.isfinite(arr)):
                    valid=False; break
                channels.append(np.abs(arr))
            if not valid: continue
            freq=np.linspace(0.0, sample_rate/2.0, bins, endpoint=False, dtype=float)
            frames.append((freq,channels))
        return frames

    @staticmethod
    def _decode_raw_payload(blob: bytes, expected_frames: int, channel_count: int, expected_samples: int = 16384) -> list[list[np.ndarray]]:
        """Decode raw samples only when a full, structurally valid 8CH payload exists.

        The supplied .dmp file is an energy/packet stream rather than a verified
        16384-sample waveform container.  Returning no data is safer than showing
        header bytes as ADC samples.  Future format-specific decoders can be added
        here without changing the UI/API.
        """
        if len(blob) < 40 or expected_frames <= 0 or channel_count != 8:
            return []
        required=expected_samples*channel_count*2
        payload=blob[40:]
        if len(payload) < required*expected_frames:
            return []
        # Accept only exact contiguous int16 frames; reject envelopes/remainders.
        if len(payload) != required*expected_frames:
            return []
        out=[]
        for i in range(expected_frames):
            chunk=payload[i*required:(i+1)*required]
            matrix=np.frombuffer(chunk,dtype='<i2').reshape(expected_samples,channel_count).T
            out.append([row.astype(float,copy=True) for row in matrix])
        return out

    @staticmethod
    def _references(frames: list[CpcHydrophoneFrame]) -> list[float]:
        refs: list[float] = []
        tiny = np.finfo(float).tiny
        for ch in range(8):
            levels = []
            for frame in frames:
                if ch >= len(frame.channels):
                    continue
                amp = np.asarray(frame.channels[ch], dtype=float)
                freq = np.asarray(frame.frequency_hz, dtype=float)
                mask = np.isfinite(amp) & (amp > 0) & np.isfinite(freq) & (freq >= 50_000) & (freq <= 1_000_000)
                if np.any(mask):
                    levels.append(float(np.percentile(amp[mask], 99.5)))
            refs.append(max(float(np.median(levels)) if levels else 1.0, tiny))
        return refs

    @staticmethod
    def relative_db(replay: CpcHydrophoneReplay, frame: CpcHydrophoneFrame, channel: int) -> np.ndarray:
        amp = np.asarray(frame.channels[channel], dtype=float)
        ref = max(float(replay.channel_reference_levels[channel]), np.finfo(float).tiny)
        floor = ref * 10.0 ** (replay.display_db_min / 20.0)
        safe = np.maximum(np.where(np.isfinite(amp), np.abs(amp), 0.0), floor)
        return np.clip(20.0 * np.log10(safe / ref), replay.display_db_min, replay.display_db_max)

    def spectrogram(self, replay: CpcHydrophoneReplay, channel: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        if not replay.frames:
            return np.array([]), np.array([]), np.empty((0, 0))
        min_bins = min(len(f.channels[channel]) for f in replay.frames)
        matrix = np.vstack([self.relative_db(replay, f, channel)[:min_bins] for f in replay.frames])
        freq = replay.frames[0].frequency_hz[:min_bins]
        time = np.arange(len(replay.frames), dtype=float) * replay.frame_interval_s
        return time, freq, matrix

    def band_energy(self, replay: CpcHydrophoneReplay, low_hz: float, high_hz: float) -> np.ndarray:
        output = np.full((len(replay.frames), replay.channel_count), np.nan, dtype=float)
        for i, frame in enumerate(replay.frames):
            freq = np.asarray(frame.frequency_hz, dtype=float)
            mask = (freq >= low_hz) & (freq <= high_hz)
            if not np.any(mask):
                continue
            for ch in range(min(replay.channel_count, len(frame.channels))):
                amp = np.asarray(frame.channels[ch], dtype=float)
                n = min(len(amp), len(mask))
                local = mask[:n]
                if np.any(local):
                    output[i, ch] = float(np.trapezoid(np.square(np.abs(amp[:n][local])), freq[:n][local]))
        return output

    def frame_statistics(self, replay: CpcHydrophoneReplay, frame_index: int, low_hz: float, high_hz: float) -> list[dict[str, float]]:
        if not replay.frames:
            return []
        frame = replay.frames[min(max(frame_index, 0), len(replay.frames)-1)]
        rows = []
        for ch in range(replay.channel_count):
            amp = np.asarray(frame.channels[ch], dtype=float)
            freq = np.asarray(frame.frequency_hz, dtype=float)
            n = min(len(amp), len(freq)); amp = amp[:n]; freq = freq[:n]
            valid = np.isfinite(amp) & np.isfinite(freq)
            peak_i = int(np.argmax(np.where(valid, amp, -np.inf))) if np.any(valid) else 0
            mask = valid & (freq >= low_hz) & (freq <= high_hz)
            energy = float(np.trapezoid(np.square(amp[mask]), freq[mask])) if np.count_nonzero(mask) > 1 else float("nan")
            raw = np.asarray(frame.raw_channels[ch], dtype=float) if ch < len(frame.raw_channels) else np.array([])
            rows.append({
                "channel": float(ch),
                "raw_peak": float(np.max(np.abs(raw))) if raw.size else float("nan"),
                "raw_rms": float(np.sqrt(np.mean(np.square(raw)))) if raw.size else float("nan"),
                "dominant_hz": float(freq[peak_i]) if n else float("nan"),
                "peak_db": float(self.relative_db(replay, frame, ch)[peak_i]) if n else float("nan"),
                "band_energy": energy,
            })
        return rows
