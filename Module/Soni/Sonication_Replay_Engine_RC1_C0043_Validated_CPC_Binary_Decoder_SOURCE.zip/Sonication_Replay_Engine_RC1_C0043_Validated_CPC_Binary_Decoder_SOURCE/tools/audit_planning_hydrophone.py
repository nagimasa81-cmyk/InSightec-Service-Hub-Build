from __future__ import annotations
import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.services.import_service import ImportService
from src.services.discovery_service import DiscoveryService
from src.services.hydrophone_replay_service import HydrophoneReplayService


def main(argv=None):
    argv = argv or sys.argv[1:]
    if not argv:
        raise SystemExit("Usage: python tools/audit_planning_hydrophone.py <treatment.zip|folder> [report.json]")
    source = Path(argv[0]).resolve()
    importer = ImportService(); workspace = importer.open(source)
    try:
        package = DiscoveryService().discover(source, workspace)
        service = HydrophoneReplayService()
        report = {"source": str(source), "planning": {}, "sonications": []}
        for asset in package.planning_assets:
            report["planning"].setdefault(asset.category, []).append({
                "path": str(asset.path.relative_to(workspace)), "role": asset.role,
                "confidence": asset.confidence, "notes": asset.notes,
            })
        for index, son in enumerate(package.sonications):
            replay = service.build(package.cpc_spectrum_files, index, len(package.sonications))
            report["sonications"].append({
                "name": son.name,
                "fft_source": replay.source_fft.name if replay.source_fft else None,
                "raw_source": replay.source_raw.name if replay.source_raw else None,
                "measures": len(replay.frames),
                "channels": replay.channel_count,
                "sample_rate_hz": replay.sampling_frequency_hz,
                "main_frequency_hz": replay.main_frequency_hz,
                "raw_decoded": bool(replay.frames and replay.frames[0].raw_channels),
                "decoder_note": replay.note,
            })
        out = Path(argv[1]).resolve() if len(argv) > 1 else Path.cwd()/"planning_hydrophone_audit.json"
        out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(out); return 0
    finally:
        importer.release(workspace)

if __name__ == "__main__":
    raise SystemExit(main())
