from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re


@dataclass(slots=True)
class SonicChannelValue:
    channel: int
    logical_amplitude: float | None = None
    logical_phase_rad: float | None = None

    @property
    def blade_index(self) -> int:
        """Zero-based blade index for the 1024-element transducer (16 x 64)."""
        return max(0, int(self.channel)) // 64

    @property
    def blade_number(self) -> int:
        """Human-facing Blade number (1..16)."""
        return self.blade_index + 1

    @property
    def blade_channel(self) -> int:
        """Zero-based channel index within the Blade (0..63)."""
        return max(0, int(self.channel)) % 64


@dataclass(slots=True)
class SonicChannelSnapshot:
    timestamp: str | None
    declared_channels: int | None
    source: Path
    values: list[SonicChannelValue] = field(default_factory=list)


class SonicationLogReceiverService:
    """Decode per-sonication 1024-element phase/amplitude log blocks.

    The Sonication_Brain log's ``Channel <n>`` entries are the ultrasound
    transmit elements: 1024 channels arranged as 16 Blades x 64 channels.
    They are a separate namespace from the 8 cavitation receivers RCV0..RCV7.
    """

    _TIME = re.compile(r"\b(\d{1,2}:\d{2}:\d{2}(?:[.:]\d+)?)\b")
    _NUMBER = re.compile(r"Number\s+Of\s+Channels\s*<\s*(\d+)\s*>", re.I)
    _CHANNEL = re.compile(r"\bChannel\s*<\s*(\d+)\s*>", re.I)
    _AMP = re.compile(r"Logical\s+Amplitude\s*<\s*([-+0-9.eE]+)\s*>", re.I)
    _PHASE = re.compile(r"Logical\s+Phase\s*<\s*([-+0-9.eE]+)\s*>", re.I)

    @staticmethod
    def _candidate_files(root: Path, preferred_folder: Path | None = None, sonication_number: int | None = None, direct_files: list[Path] | None = None) -> list[Path]:
        root = Path(root)
        files: list[Path] = []
        if direct_files:
            files.extend(Path(p) for p in direct_files if Path(p).is_file())
        if root.exists():
            for p in root.rglob('*'):
                if not p.is_file() or p.suffix.lower() not in {'.txt','.log'}:
                    continue
                n=p.name.lower()
                if 'sonication' in n or 'sonic' in n:
                    files.append(p)
        unique=[]; seen=set()
        preferred = Path(preferred_folder).resolve() if preferred_folder and Path(preferred_folder).exists() else None
        token = f"sonication{sonication_number}" if sonication_number is not None else ''
        def rank(path: Path):
            rp = path.resolve()
            inside = 0 if preferred is not None and (rp == preferred or preferred in rp.parents) else 1
            name = path.name.lower().replace('_','').replace('-','')
            number_match = 0 if token and token in name else 1
            brain = 0 if 'sonication_brain' in path.name.lower() or 'sonicationbrain' in name else 1
            return (inside, number_match, brain, len(path.parts), path.name.lower())
        for p in sorted(files, key=rank):
            key=str(p.resolve())
            if key in seen: continue
            seen.add(key); unique.append(p)
        return unique

    def read_snapshots(self, root: Path, preferred_folder: Path | None = None, sonication_number: int | None = None, direct_files: list[Path] | None = None) -> list[SonicChannelSnapshot]:
        snapshots=[]
        for path in self._candidate_files(Path(root), preferred_folder, sonication_number, direct_files):
            try: lines=path.read_text(encoding='utf-8',errors='ignore').splitlines()
            except OSError: continue
            current=None; current_channel=None; last_time=None
            def flush():
                nonlocal current,current_channel
                if current is not None and current.values:
                    by={v.channel:v for v in current.values}; current.values=[by[k] for k in sorted(by)]
                    snapshots.append(current)
                current=None; current_channel=None
            for line in lines:
                tm=self._TIME.search(line)
                if tm: last_time=tm.group(1).replace(':','.',3) if tm.group(1).count(':')==3 else tm.group(1)
                block_start = 'CLoadSonicationData fields' in line
                m_number=self._NUMBER.search(line)
                if block_start:
                    flush(); current=SonicChannelSnapshot(last_time,None,path,[]); continue
                if m_number:
                    declared=int(m_number.group(1))
                    # Some software versions omit the CLoadSonicationData marker.
                    # Treat a declared 1024-channel block as an implicit snapshot start.
                    if current is None or current.values:
                        flush(); current=SonicChannelSnapshot(last_time,declared,path,[])
                    else:
                        current.declared_channels=declared
                    continue
                m=self._CHANNEL.search(line)
                if m:
                    if current is None:
                        # Generic fallback for older/newer Sonication logs that expose
                        # Channel/Amplitude/Phase lines without the known header marker.
                        current=SonicChannelSnapshot(last_time,None,path,[])
                    current_channel=int(m.group(1))
                    if 0 <= current_channel < 1024:
                        current.values.append(SonicChannelValue(current_channel))
                    else:
                        current_channel=None
                    continue
                if current_channel is None or current is None or not current.values: continue
                m=self._AMP.search(line)
                if m:
                    try: current.values[-1].logical_amplitude=float(m.group(1))
                    except ValueError: pass
                    continue
                m=self._PHASE.search(line)
                if m:
                    try: current.values[-1].logical_phase_rad=float(m.group(1))
                    except ValueError: pass
            flush()
        out=[]; seen=set()
        for snap in snapshots:
            sig=(str(snap.source),snap.timestamp,tuple((v.channel,v.logical_amplitude,v.logical_phase_rad) for v in snap.values))
            if sig in seen: continue
            seen.add(sig); out.append(snap)
        return out
