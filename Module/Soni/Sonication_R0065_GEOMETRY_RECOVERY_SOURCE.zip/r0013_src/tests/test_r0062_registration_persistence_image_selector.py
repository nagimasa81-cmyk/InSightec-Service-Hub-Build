from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
TEXT=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')

def test_registration_is_not_silently_cleared_when_image_changes():
    sync=TEXT[TEXT.index('def _sync_registration_button_state'):TEXT.index('def _planning_reference_type_changed')]
    assert 'self.registration_overlay_enabled = False' not in sync
    activate=TEXT[TEXT.index('def _activate_image_payload'):TEXT.index('def _registration_toggled')]
    assert 'Registration ON retained; overlay resumes on MR reference' in activate

def test_full_series_image_combos_are_present():
    assert 'self.planning_image_combo = QComboBox()' in TEXT
    assert 'self.anatomy_image_combo = QComboBox()' in TEXT
    assert 'self.thermal_image_combo = QComboBox()' in TEXT
    assert 'def _image_combo_selected' in TEXT
