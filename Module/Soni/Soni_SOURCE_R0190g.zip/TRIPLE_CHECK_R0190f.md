# R0190f triple check

1. Static cross-cut audit
   - No production `double_click_callback=lambda ... popup/enlarge` wiring remains.
   - No production `open_enlarged_plot` symbol remains.
   - No "Double-click ... enlarge" tooltip remains.
   - Replay `_chart_panel()` installs the common reset interaction directly.
   - Hydrophone static and dynamic PlotWidgets retain reset callbacks that clear manual view overrides.

2. Regression tests
   - `tests/test_r0190*.py`: 34/34 PASS after superseding the obsolete R0190b/c popup expectations with the authoritative R0190f reset contract.
   - R0190f reset + R0190e DQA focused contract: 6/6 PASS.
   - R0190 family + release metadata regression: 39/39 PASS.
   - `python -m compileall -q src`: PASS.
   - `python verify_source.py`: VERIFY_SOURCE_OK.

3. Full-suite limitation
   - Full `pytest -q` cannot collect in this Linux validation environment because PySide6 is not installed (`test_r0015_circular_roi_measurement.py`). This is an environment limitation, not counted as a pass.

4. DQA preservation
   - No DQA service code was changed in R0190f. R0190e X=Axial LR center, Y=Sagittal AP center, Z/Tilt existing method remains intact.
