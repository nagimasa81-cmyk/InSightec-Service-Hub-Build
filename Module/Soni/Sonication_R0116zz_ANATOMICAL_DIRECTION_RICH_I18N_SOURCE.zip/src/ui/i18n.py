from __future__ import annotations

import re

LANGUAGES = {
    "en": "English",
    "ja": "日本語",
    "ko": "한국어",
    "zh_TW": "繁體中文（台灣）",
    "es": "Español",
    "th": "ไทย",
    "hi": "हिन्दी",
}

TEXT = {
    "en": {
        "load_sonication": "Load a Sonication to begin",
        "root_unavailable": "Root-cause analysis unavailable.",
        "sync_evidence": "Sonication {son} · Replay {time:.3f} s · synchronized cavitation evidence",
        "no_event": "No observed event",
        "no_mr": "No MR correlation",
        "registered_ct_pending": "Registered CT available · classification pending",
        "indeterminate": "Indeterminate",
        "probable": "probable ({x:+.2f}, {y:+.2f})",
        "note": "Observed = acquisition/control log evidence. Reconstructed = SpectrumDumps + INI rules. Location integrates RCV intensity, FUS/vendor receiver weighting, and MR magnitude signal-loss correlation. Candidate space is not restricted to intracranial regions; skull classification is applied only when registered CT geometry is trustworthy. Root Cause Analysis ranks supporting evidence and does not claim biological causality.",
        "ready": "Ready",
        "rca_detected": "Cavitation detected",
        "rca_not_detected": "No confirmed cavitation-control event",
        "rca_summary": "{state}. Most supported contributors: {names}. RCA score {score:.0f}/100 ({confidence} evidence coverage).",
        "rca_warning": "Pre-cavitation warning candidate: {label} is elevated despite no confirmed control event.",
        "unavailable_evidence": "Unavailable evidence",
        "not_inferred": "Not inferred; add the missing source data.",
        "confidence_High": "High",
        "confidence_Moderate": "Moderate",
        "confidence_Low": "Low",
        "confidence_Unavailable": "Unavailable",
        "factor_event": "Cavitation control threshold crossing",
        "factor_multiband": "Rapid acoustic multi-band escalation",
        "factor_drive": "High acoustic drive / escalation",
        "factor_thermal": "Thermal preconditioning / accumulated heating",
        "factor_rcv": "Localized RCV contribution concentration",
        "factor_history": "Prior-Sonication cavitation history",
        "factor_mr": "MR change correlated with acoustic candidate",
        "improve_event": "Reduce escalation before the same threshold region; verify which vendor rule/band/RCV triggered first.",
        "improve_multiband": "Use the earliest rising acoustic signature as a pre-cavitation warning and limit further power escalation.",
        "improve_drive": "Use smaller power increments or a lower peak drive while confirming thermal response.",
        "improve_thermal": "Allow more cooling or avoid repeating high drive while the target remains thermally elevated.",
        "improve_rcv": "Review focus/phase/element loading and whether the same receiver dominance repeats across Sonications.",
        "improve_history": "If recurrent, treat the event as history-dependent and reduce escalation / extend cooling before retry.",
        "improve_mr": "If acoustic and MR changes co-localize, review the registered location before further escalation.",
        "evidence_missing": "Previous Sonication cavitation evidence unavailable",
        "replay_cpc_unavailable": "CPC cavitation evidence unavailable for this Sonication",
        "dominant_rcv_unavailable": "Dominant RCV: -- | MR correlation: --",
        "no_sync_cpc": "No synchronized CPC/RCV measurement at MR time {time:.3f} s",
        "likelihood_unavailable": "Cavitation likelihood map is unavailable for the current evidence.",
        "probable_region_note": "Interpretation: this is a probable region, not a single-point localization.",
    },
    "ja": {
        "load_sonication": "Sonicationを読み込むと解析を開始します",
        "root_unavailable": "Root Cause Analysisを実行できません。",
        "sync_evidence": "Sonication {son} · Replay {time:.3f} s · Cavitationエビデンス同期済み",
        "no_event": "観測されたCavitationイベントなし",
        "no_mr": "MR相関データなし",
        "registered_ct_pending": "登録済みCTあり · 分類待ち",
        "indeterminate": "判定不能",
        "probable": "推定位置 ({x:+.2f}, {y:+.2f})",
        "note": "Observed はAcquisition/Control Logの実測エビデンス、Reconstructed はSpectrumDumpsとINIルールからの再構成です。位置推定はRCV強度、FUS/vendor receiver weighting、MR magnitude signal-loss相関を統合します。候補位置は頭蓋内に限定せず、Skull分類は登録CT geometryの信頼性が確認できる場合のみ適用します。Root Cause Analysisは支持エビデンスを順位付けするもので、生物学的因果関係を断定するものではありません。",
        "ready": "準備完了",
        "rca_detected": "Cavitationを検出",
        "rca_not_detected": "Cavitation control eventは確認されていません",
        "rca_summary": "{state}。最も支持される要因: {names}。RCA score {score:.0f}/100（エビデンス信頼度: {confidence}）。",
        "rca_warning": "Pre-cavitation warning候補: 確定control eventはありませんが、{label} が高値です。",
        "unavailable_evidence": "利用できないエビデンス",
        "not_inferred": "推測は行っていません。不足しているsource dataを追加してください。",
        "confidence_High": "高",
        "confidence_Moderate": "中",
        "confidence_Low": "低",
        "confidence_Unavailable": "利用不可",
        "factor_event": "Cavitation control閾値超過",
        "factor_multiband": "Acoustic multi-bandの急激な上昇",
        "factor_drive": "高いacoustic drive / 急激な出力上昇",
        "factor_thermal": "Thermal preconditioning / 蓄積加熱",
        "factor_rcv": "局所的なRCV寄与集中",
        "factor_history": "直前SonicationのCavitation履歴",
        "factor_mr": "Acoustic candidateと相関するMR変化",
        "improve_event": "同じ閾値領域に到達する前に出力上昇を抑え、最初に発火したvendor rule / band / RCVを確認します。",
        "improve_multiband": "最初に立ち上がるacoustic signatureをpre-cavitation warningとして利用し、それ以降の出力上昇を制限します。",
        "improve_drive": "Thermal responseを確認しながらPower incrementを小さくするか、peak driveを下げます。",
        "improve_thermal": "Cooling時間を延長するか、targetが高温の間は高driveの反復を避けます。",
        "improve_rcv": "Focus / phase / element loadingを確認し、同じreceiver優位性が複数Sonicationで再現するか確認します。",
        "improve_history": "再発する場合は履歴依存として扱い、再照射前に出力上昇を抑えるかcoolingを延長します。",
        "improve_mr": "Acoustic変化とMR変化が同じ位置に一致する場合、追加出力前に登録位置を確認します。",
        "evidence_missing": "直前SonicationのCavitationエビデンスを利用できません",
        "replay_cpc_unavailable": "このSonicationではCPC Cavitationエビデンスを利用できません",
        "dominant_rcv_unavailable": "Dominant RCV: -- | MR相関: --",
        "no_sync_cpc": "MR時刻 {time:.3f} s に同期するCPC/RCV measurementがありません",
        "likelihood_unavailable": "現在のエビデンスではCavitation likelihood mapを作成できません。",
        "probable_region_note": "解釈: これは単一点の位置決定ではなく、推定領域です。",
    },
    "ko": {
        "load_sonication": "Sonication을 불러오면 분석을 시작합니다",
        "root_unavailable": "Root Cause Analysis를 실행할 수 없습니다.",
        "sync_evidence": "Sonication {son} · Replay {time:.3f} s · Cavitation evidence 동기화됨",
        "no_event": "관찰된 Cavitation event 없음",
        "no_mr": "MR correlation 데이터 없음",
        "registered_ct_pending": "등록된 CT 있음 · 분류 대기",
        "indeterminate": "판정 불가",
        "probable": "추정 위치 ({x:+.2f}, {y:+.2f})",
        "note": "Observed는 acquisition/control log의 실제 evidence이고, Reconstructed는 SpectrumDumps와 INI rule에서 재구성한 결과입니다. 위치는 RCV intensity, FUS/vendor receiver weighting, MR magnitude signal-loss correlation을 통합하여 추정합니다. 후보 위치는 두개강 내로 제한하지 않으며, skull classification은 등록 CT geometry의 신뢰성이 확보된 경우에만 적용합니다. Root Cause Analysis는 supporting evidence의 순위를 제시하며 생물학적 인과관계를 단정하지 않습니다.",
        "ready": "준비 완료",
        "rca_detected": "Cavitation 감지됨",
        "rca_not_detected": "확인된 Cavitation control event 없음",
        "rca_summary": "{state}. 가장 강하게 지지되는 요인: {names}. RCA score {score:.0f}/100 (evidence confidence: {confidence}).",
        "rca_warning": "Pre-cavitation warning 후보: 확정 control event는 없지만 {label} 항목이 높습니다.",
        "unavailable_evidence": "사용할 수 없는 evidence",
        "not_inferred": "추정하지 않았습니다. 누락된 source data를 추가하십시오.",
        "confidence_High": "높음",
        "confidence_Moderate": "보통",
        "confidence_Low": "낮음",
        "confidence_Unavailable": "사용 불가",
        "factor_event": "Cavitation control threshold 초과",
        "factor_multiband": "급격한 acoustic multi-band 상승",
        "factor_drive": "높은 acoustic drive / 급격한 출력 상승",
        "factor_thermal": "Thermal preconditioning / 누적 가열",
        "factor_rcv": "국소 RCV contribution 집중",
        "factor_history": "이전 Sonication의 Cavitation history",
        "factor_mr": "Acoustic candidate와 연관된 MR 변화",
        "improve_event": "같은 threshold 영역에 도달하기 전에 출력을 완화하고 최초 trigger가 된 vendor rule/band/RCV를 확인합니다.",
        "improve_multiband": "가장 이른 acoustic 상승 신호를 pre-cavitation warning으로 사용하고 추가 출력 상승을 제한합니다.",
        "improve_drive": "Thermal response를 확인하면서 power increment를 줄이거나 peak drive를 낮춥니다.",
        "improve_thermal": "Cooling 시간을 늘리거나 target이 고온인 동안 높은 drive 반복을 피합니다.",
        "improve_rcv": "Focus/phase/element loading을 검토하고 동일 receiver dominance가 반복되는지 확인합니다.",
        "improve_history": "반복될 경우 history-dependent event로 보고 재시도 전 출력 상승을 줄이거나 cooling을 연장합니다.",
        "improve_mr": "Acoustic 변화와 MR 변화가 같은 위치에 나타나면 추가 출력 전에 등록 위치를 검토합니다.",
        "evidence_missing": "이전 Sonication의 Cavitation evidence를 사용할 수 없습니다",
        "replay_cpc_unavailable": "이 Sonication에서는 CPC Cavitation evidence를 사용할 수 없습니다",
        "dominant_rcv_unavailable": "Dominant RCV: -- | MR correlation: --",
        "no_sync_cpc": "MR 시간 {time:.3f} s에 동기화된 CPC/RCV measurement가 없습니다",
        "likelihood_unavailable": "현재 evidence로는 Cavitation likelihood map을 만들 수 없습니다.",
        "probable_region_note": "해석: 단일 지점 위치가 아니라 추정 영역입니다.",
    },
    "zh_TW": {
        "load_sonication": "載入 Sonication 後開始分析",
        "root_unavailable": "無法執行 Root Cause Analysis。",
        "sync_evidence": "Sonication {son} · Replay {time:.3f} s · Cavitation evidence 已同步",
        "no_event": "未觀察到 Cavitation event",
        "no_mr": "沒有 MR correlation 資料",
        "registered_ct_pending": "已有配準 CT · 等待分類",
        "indeterminate": "無法判定",
        "probable": "推定位置 ({x:+.2f}, {y:+.2f})",
        "note": "Observed 代表 acquisition/control log 的實測 evidence；Reconstructed 代表由 SpectrumDumps 與 INI rule 重建的結果。位置推定整合 RCV intensity、FUS/vendor receiver weighting 與 MR magnitude signal-loss correlation。候選位置不限制於顱內，Skull classification 僅在配準 CT geometry 可信時套用。Root Cause Analysis 是對 supporting evidence 進行排序，並不宣稱生物學上的因果關係。",
        "ready": "就緒",
        "rca_detected": "已偵測到 Cavitation",
        "rca_not_detected": "未確認 Cavitation control event",
        "rca_summary": "{state}。最受支持的因素：{names}。RCA score {score:.0f}/100（evidence confidence：{confidence}）。",
        "rca_warning": "Pre-cavitation warning 候選：雖然沒有確認的 control event，但 {label} 偏高。",
        "unavailable_evidence": "無法取得的 evidence",
        "not_inferred": "未進行推測；請加入缺少的 source data。",
        "confidence_High": "高",
        "confidence_Moderate": "中",
        "confidence_Low": "低",
        "confidence_Unavailable": "無法使用",
        "factor_event": "Cavitation control threshold 超限",
        "factor_multiband": "Acoustic multi-band 快速上升",
        "factor_drive": "高 acoustic drive / 快速輸出上升",
        "factor_thermal": "Thermal preconditioning / 累積加熱",
        "factor_rcv": "局部 RCV contribution 集中",
        "factor_history": "前一個 Sonication 的 Cavitation history",
        "factor_mr": "與 acoustic candidate 相關的 MR 變化",
        "improve_event": "在進入相同 threshold 區域前降低輸出上升幅度，並確認最先觸發的 vendor rule / band / RCV。",
        "improve_multiband": "將最早出現的 acoustic 上升訊號作為 pre-cavitation warning，並限制後續輸出上升。",
        "improve_drive": "確認 thermal response 的同時縮小 power increment，或降低 peak drive。",
        "improve_thermal": "增加 cooling 時間，或在 target 仍偏熱時避免重複高 drive。",
        "improve_rcv": "檢查 focus / phase / element loading，並確認相同 receiver dominance 是否在多個 Sonication 重複出現。",
        "improve_history": "若反覆發生，視為 history-dependent event，重試前降低輸出上升或延長 cooling。",
        "improve_mr": "若 acoustic 與 MR 變化共定位，進一步提高輸出前先檢查配準位置。",
        "evidence_missing": "無法取得前一個 Sonication 的 Cavitation evidence",
        "replay_cpc_unavailable": "此 Sonication 無法取得 CPC Cavitation evidence",
        "dominant_rcv_unavailable": "Dominant RCV: -- | MR correlation: --",
        "no_sync_cpc": "MR 時間 {time:.3f} s 沒有同步的 CPC/RCV measurement",
        "likelihood_unavailable": "目前的 evidence 無法建立 Cavitation likelihood map。",
        "probable_region_note": "解讀：這是推定區域，不是單一點定位。",
    },
    "es": {
        "load_sonication": "Cargue una Sonication para iniciar el análisis",
        "root_unavailable": "El Root Cause Analysis no está disponible.",
        "sync_evidence": "Sonication {son} · Replay {time:.3f} s · evidencia de cavitación sincronizada",
        "no_event": "No se observó ningún evento de cavitación",
        "no_mr": "No hay correlación con MR",
        "registered_ct_pending": "CT registrado disponible · clasificación pendiente",
        "indeterminate": "Indeterminado",
        "probable": "posición probable ({x:+.2f}, {y:+.2f})",
        "note": "Observed corresponde a evidencia real del acquisition/control log. Reconstructed corresponde a datos reconstruidos desde SpectrumDumps y las reglas INI. La localización integra intensidad RCV, ponderación del receptor FUS/vendor y correlación con pérdida de señal en MR magnitude. El espacio candidato no se limita a regiones intracraneales; la clasificación del cráneo solo se aplica cuando la geometría del CT registrado es confiable. Root Cause Analysis clasifica la evidencia de apoyo y no afirma causalidad biológica.",
        "ready": "Listo",
        "rca_detected": "Cavitación detectada",
        "rca_not_detected": "No se confirmó un evento de control de cavitación",
        "rca_summary": "{state}. Factores con mayor respaldo: {names}. RCA score {score:.0f}/100 (confianza de evidencia: {confidence}).",
        "rca_warning": "Posible alerta pre-cavitación: {label} está elevado aunque no existe un evento de control confirmado.",
        "unavailable_evidence": "Evidencia no disponible",
        "not_inferred": "No se infiere; agregue los datos fuente faltantes.",
        "confidence_High": "Alta",
        "confidence_Moderate": "Moderada",
        "confidence_Low": "Baja",
        "confidence_Unavailable": "No disponible",
        "factor_event": "Cruce del umbral de control de cavitación",
        "factor_multiband": "Escalada acústica multibanda rápida",
        "factor_drive": "Drive acústico alto / escalada de potencia",
        "factor_thermal": "Preacondicionamiento térmico / calentamiento acumulado",
        "factor_rcv": "Concentración localizada de contribución RCV",
        "factor_history": "Historial de cavitación de la Sonication previa",
        "factor_mr": "Cambio en MR correlacionado con el candidato acústico",
        "improve_event": "Reduzca la escalada antes de alcanzar la misma región de umbral y verifique qué vendor rule/band/RCV se activó primero.",
        "improve_multiband": "Use la primera firma acústica ascendente como alerta pre-cavitación y limite aumentos adicionales de potencia.",
        "improve_drive": "Use incrementos de potencia más pequeños o un peak drive menor mientras confirma la respuesta térmica.",
        "improve_thermal": "Permita mayor cooling o evite repetir un drive alto mientras el target permanezca térmicamente elevado.",
        "improve_rcv": "Revise focus/phase/element loading y si el mismo receiver dominance se repite entre Sonications.",
        "improve_history": "Si se repite, trátelo como un evento dependiente del historial y reduzca la escalada o prolongue el cooling antes de reintentar.",
        "improve_mr": "Si los cambios acústicos y de MR se co-localizan, revise la ubicación registrada antes de aumentar más la potencia.",
        "evidence_missing": "No está disponible la evidencia de cavitación de la Sonication previa",
        "replay_cpc_unavailable": "La evidencia CPC de cavitación no está disponible para esta Sonication",
        "dominant_rcv_unavailable": "Dominant RCV: -- | correlación MR: --",
        "no_sync_cpc": "No existe una medición CPC/RCV sincronizada al tiempo MR {time:.3f} s",
        "likelihood_unavailable": "El mapa de probabilidad de cavitación no está disponible con la evidencia actual.",
        "probable_region_note": "Interpretación: se trata de una región probable, no de una localización puntual.",
    },
}


def tr(locale: str, key: str, **kwargs) -> str:
    table = TEXT.get(locale, TEXT["en"])
    value = table.get(key, TEXT["en"].get(key, key))
    try:
        return value.format(**kwargs)
    except Exception:
        return value


def confidence(locale: str, value: str) -> str:
    return tr(locale, f"confidence_{value}")


def factor_label(locale: str, key: str, fallback: str) -> str:
    return tr(locale, f"factor_{key}") if f"factor_{key}" in TEXT.get(locale, {}) else fallback


def factor_improvement(locale: str, key: str, fallback: str) -> str:
    return tr(locale, f"improve_{key}") if f"improve_{key}" in TEXT.get(locale, {}) else fallback


def localize_evidence(locale: str, key: str, evidence: str) -> str:
    if locale == "en":
        return evidence
    text = str(evidence or "")
    replacements = {
        "ja": {
            "control event present": "control eventあり",
            "no decrease/safety/dynamic cavitation event in the synchronized control timeline": "同期control timelineにDecrease/Safety/Dynamic Cavitation eventなし",
            "CPC/RCV frames unavailable": "CPC/RCV frameを利用できません",
            "vendor Band0–3 per-receiver energy unavailable": "receiver別vendor Band0–3 energyを利用できません",
            "receiver energy is zero": "receiver energyは0です",
            "CPC spectrum unavailable": "CPC spectrumを利用できません",
            "not enough CPC snapshots for an escalation trend": "escalation trendの評価に必要なCPC snapshot数が不足しています",
            "positive acoustic baseline unavailable": "正のacoustic baselineを利用できません",
            "measured/planned power unavailable": "measured/planned powerを利用できません",
            "no treatment/prior power reference": "treatment/previous power referenceなし",
            "thermometry unavailable": "thermometryを利用できません",
            "previous Sonication cavitation evidence unavailable": "直前SonicationのCavitation evidenceを利用できません",
            "previous Sonication also had a cavitation-control event": "直前SonicationでもCavitation control eventあり",
            "no cavitation-control event in previous Sonication": "直前SonicationにCavitation control eventなし",
            "MR correlation unavailable": "MR correlationを利用できません",
            "dominant": "dominant",
            "share": "比率",
            "of peak per-receiver Band0–3 energy": "（receiver別peak Band0–3 energyに対する比率）",
            "peak total vendor-band energy / early baseline": "peak total vendor-band energy / early baseline",
            "treatment median": "治療median",
            "previous Sonication": "直前Sonication",
            "previous peak": "直前peak",
            "hydrophone/MR correlation score": "hydrophone/MR correlation score",
            "event families": "event family",
            "peak weighted-energy/limit": "peak weighted-energy/limit",
        },
        "ko": {
            "control event present": "control event 있음",
            "no decrease/safety/dynamic cavitation event in the synchronized control timeline": "동기화된 control timeline에 Decrease/Safety/Dynamic Cavitation event 없음",
            "CPC/RCV frames unavailable": "CPC/RCV frame 사용 불가",
            "vendor Band0–3 per-receiver energy unavailable": "receiver별 vendor Band0–3 energy 사용 불가",
            "CPC spectrum unavailable": "CPC spectrum 사용 불가",
            "thermometry unavailable": "thermometry 사용 불가",
            "previous Sonication cavitation evidence unavailable": "이전 Sonication Cavitation evidence 사용 불가",
            "previous Sonication also had a cavitation-control event": "이전 Sonication에도 Cavitation control event 있음",
            "no cavitation-control event in previous Sonication": "이전 Sonication에 Cavitation control event 없음",
            "MR correlation unavailable": "MR correlation 사용 불가",
            "treatment median": "치료 median",
            "previous Sonication": "이전 Sonication",
            "previous peak": "이전 peak",
        },
        "zh_TW": {
            "control event present": "存在 control event",
            "no decrease/safety/dynamic cavitation event in the synchronized control timeline": "同步 control timeline 中沒有 Decrease/Safety/Dynamic Cavitation event",
            "CPC/RCV frames unavailable": "無法取得 CPC/RCV frame",
            "vendor Band0–3 per-receiver energy unavailable": "無法取得各 receiver 的 vendor Band0–3 energy",
            "CPC spectrum unavailable": "無法取得 CPC spectrum",
            "thermometry unavailable": "無法取得 thermometry",
            "previous Sonication cavitation evidence unavailable": "無法取得前一個 Sonication 的 Cavitation evidence",
            "previous Sonication also had a cavitation-control event": "前一個 Sonication 也有 Cavitation control event",
            "no cavitation-control event in previous Sonication": "前一個 Sonication 沒有 Cavitation control event",
            "MR correlation unavailable": "無法取得 MR correlation",
            "treatment median": "治療 median",
            "previous Sonication": "前一個 Sonication",
            "previous peak": "前一個 peak",
        },
        "es": {
            "control event present": "evento de control presente",
            "no decrease/safety/dynamic cavitation event in the synchronized control timeline": "no hay evento Decrease/Safety/Dynamic de cavitación en el control timeline sincronizado",
            "CPC/RCV frames unavailable": "frames CPC/RCV no disponibles",
            "vendor Band0–3 per-receiver energy unavailable": "energía vendor Band0–3 por receiver no disponible",
            "CPC spectrum unavailable": "CPC spectrum no disponible",
            "thermometry unavailable": "thermometry no disponible",
            "previous Sonication cavitation evidence unavailable": "evidencia de cavitación de la Sonication previa no disponible",
            "previous Sonication also had a cavitation-control event": "la Sonication previa también tuvo un evento de control de cavitación",
            "no cavitation-control event in previous Sonication": "no hubo evento de control de cavitación en la Sonication previa",
            "MR correlation unavailable": "correlación MR no disponible",
            "treatment median": "mediana del tratamiento",
            "previous Sonication": "Sonication previa",
            "previous peak": "peak previo",
        },
    }
    for src, dst in replacements.get(locale, {}).items():
        text = text.replace(src, dst)
    return text


# R0116zq: richer runtime localization for high-visibility UI chrome.
# Scientific identifiers (CPC, RCV, CGA, FFT, MR, Spectrum, Sonication) are
# deliberately retained where translating them would make cross-site support
# harder. The surrounding action/description text is localized.
UI_TEXT = {
    "ja": {
        "File":"ファイル","Open ZIP...":"ZIPを開く...","Open Folder...":"フォルダーを開く...","Language:":"言語:","&Language":"言語(&L)",
        "Replay":"リプレイ","Cavitation Intelligence":"キャビテーション解析","Sonication Summary":"Sonicationサマリー","Sonication Elements":"Sonication要素",
        "Analysis (preserved)":"解析（保持）","Planning / Reference":"プランニング / 参照","Export / Replay Status":"Export / Replay状態","Thermometry Data":"温度データ",
        "Elements Skull":"Elements / Skull","Comparison":"比較","Engineering Analysis":"エンジニアリング解析","Diagnostics":"診断",
        "Spectrum Dump Analyzer":"Spectrum Dump Analyzer","Select From Loaded Export":"読み込み済みExportから選択","Open Export ZIP":"Export ZIPを開く","Open Folder":"フォルダーを開く","Open Spectrum File":"Spectrumファイルを開く",
        "Sonication":"Sonication","Receiver":"Receiver","Show disabled RCV":"無効RCVを表示","No CPC source loaded":"CPC source未読込","Cavitation mode":"Cavitationモード","Candidate threshold":"候補閾値",
        "Measurement Timeline / Raw A/D":"計測タイムライン / Raw A/D","Spectrum":"Spectrum","Spectrogram":"Spectrogram","Band Energy":"Band Energy","CGA Cavitation / Vendor Rules":"CGA Cavitation / Vendor Rules","Cavitation Events":"Cavitationイベント","Measure / Statistics":"計測 / 統計",
        "Display":"表示","Y scale":"Yスケール","Show rule / band details":"Rule / Band詳細を表示","Hide rule / band details":"Rule / Band詳細を隠す","Why popup":"Whyポップアップ","Show Increase events":"Increaseイベントを表示","Show pre-irradiation control":"照射前Controlを表示","Sync replay to selected event":"選択イベントへReplay同期","Lock plot view":"プロット表示を固定","Reset view":"表示をリセット",
        "Control Timeline":"Controlタイムライン","Probable Location":"推定位置","Hydrophone × Band":"Hydrophone × Band","Replay speed":"Replay速度","Event list":"イベント一覧","Show analysis details":"解析詳細を表示",
        "View":"表示","All 8 receivers":"全8 Receiver","Lower chart":"下段チャート","Both":"両方","Smooth 100 ms":"100 ms平滑化","Sync cursor":"カーソル同期","Legend":"凡例","All ON":"すべてON","All Clear":"すべて解除",
        "Source details":"Source詳細","Temperature Trend (ROI)":"温度トレンド (ROI)","Power / Score (%)":"Power / Score (%)","Acoustic Spectrum (Current)":"Acoustic Spectrum（現在）",
        "Treatment MR":"治療MR","Treatment Thermal":"治療Thermal","Temperature":"温度","Power":"Power","Score":"Score","Ready":"準備完了","Processing…":"処理中…","No data":"データなし",
    },
    "ko": {
        "File":"파일","Open ZIP...":"ZIP 열기...","Open Folder...":"폴더 열기...","Language:":"언어:","&Language":"언어(&L)","Replay":"리플레이","Cavitation Intelligence":"캐비테이션 분석","Sonication Summary":"Sonication 요약","Sonication Elements":"Sonication 요소","Analysis (preserved)":"분석 (유지)","Planning / Reference":"Planning / Reference","Export / Replay Status":"Export / Replay 상태","Thermometry Data":"온도 데이터","Comparison":"비교","Engineering Analysis":"엔지니어링 분석","Diagnostics":"진단",
        "Select From Loaded Export":"로드된 Export에서 선택","Open Export ZIP":"Export ZIP 열기","Open Folder":"폴더 열기","Open Spectrum File":"Spectrum 파일 열기","Receiver":"Receiver","Show disabled RCV":"비활성 RCV 표시","No CPC source loaded":"CPC source 미로드","Cavitation mode":"Cavitation 모드","Candidate threshold":"후보 임계값","Measurement Timeline / Raw A/D":"측정 타임라인 / Raw A/D","Cavitation Events":"Cavitation 이벤트","Measure / Statistics":"측정 / 통계","Display":"표시","Y scale":"Y 스케일","Show rule / band details":"Rule / Band 상세 표시","Why popup":"Why 팝업","Show Increase events":"Increase 이벤트 표시","Show pre-irradiation control":"조사 전 Control 표시","Sync replay to selected event":"선택 이벤트에 Replay 동기화","Lock plot view":"플롯 보기 잠금","Reset view":"보기 초기화","Control Timeline":"Control 타임라인","Probable Location":"추정 위치","Replay speed":"Replay 속도","Event list":"이벤트 목록","Show analysis details":"분석 상세 표시","View":"보기","All 8 receivers":"8개 Receiver 모두","Lower chart":"하단 차트","Both":"둘 다","Smooth 100 ms":"100 ms 평활화","Sync cursor":"커서 동기화","Legend":"범례","All ON":"모두 ON","All Clear":"모두 해제","Source details":"Source 상세","Temperature Trend (ROI)":"온도 추세 (ROI)","Treatment MR":"치료 MR","Treatment Thermal":"치료 Thermal","Temperature":"온도","Ready":"준비 완료","Processing…":"처리 중…","No data":"데이터 없음",
    },
    "zh_TW": {
        "File":"檔案","Open ZIP...":"開啟 ZIP...","Open Folder...":"開啟資料夾...","Language:":"語言:","&Language":"語言(&L)","Replay":"重播","Cavitation Intelligence":"空化分析","Sonication Summary":"Sonication 摘要","Sonication Elements":"Sonication 元件","Analysis (preserved)":"分析（保留）","Planning / Reference":"規劃 / 參考","Export / Replay Status":"Export / Replay 狀態","Thermometry Data":"溫度資料","Comparison":"比較","Engineering Analysis":"工程分析","Diagnostics":"診斷",
        "Select From Loaded Export":"從已載入 Export 選擇","Open Export ZIP":"開啟 Export ZIP","Open Folder":"開啟資料夾","Open Spectrum File":"開啟 Spectrum 檔案","Receiver":"Receiver","Show disabled RCV":"顯示停用 RCV","No CPC source loaded":"尚未載入 CPC source","Cavitation mode":"Cavitation 模式","Candidate threshold":"候選閾值","Measurement Timeline / Raw A/D":"量測時間軸 / Raw A/D","Cavitation Events":"Cavitation 事件","Measure / Statistics":"量測 / 統計","Display":"顯示","Y scale":"Y 軸尺度","Show rule / band details":"顯示 Rule / Band 詳細資料","Why popup":"Why 彈出視窗","Show Increase events":"顯示 Increase 事件","Show pre-irradiation control":"顯示照射前 Control","Sync replay to selected event":"Replay 同步至所選事件","Lock plot view":"鎖定圖表視圖","Reset view":"重設視圖","Control Timeline":"Control 時間軸","Probable Location":"推定位置","Replay speed":"Replay 速度","Event list":"事件清單","Show analysis details":"顯示分析詳細資料","View":"顯示","All 8 receivers":"全部 8 個 Receiver","Lower chart":"下方圖表","Both":"兩者","Smooth 100 ms":"100 ms 平滑化","Sync cursor":"同步游標","Legend":"圖例","All ON":"全部開啟","All Clear":"全部清除","Source details":"Source 詳細資料","Temperature Trend (ROI)":"溫度趨勢 (ROI)","Treatment MR":"治療 MR","Treatment Thermal":"治療 Thermal","Temperature":"溫度","Ready":"就緒","Processing…":"處理中…","No data":"無資料",
    },
    "es": {
        "File":"Archivo","Open ZIP...":"Abrir ZIP...","Open Folder...":"Abrir carpeta...","Language:":"Idioma:","&Language":"Idioma(&L)","Replay":"Reproducción","Cavitation Intelligence":"Análisis de cavitación","Sonication Summary":"Resumen de Sonication","Sonication Elements":"Elementos de Sonication","Analysis (preserved)":"Análisis (conservado)","Planning / Reference":"Planificación / Referencia","Export / Replay Status":"Estado Export / Replay","Thermometry Data":"Datos de temperatura","Comparison":"Comparación","Engineering Analysis":"Análisis de ingeniería","Diagnostics":"Diagnóstico",
        "Select From Loaded Export":"Seleccionar del Export cargado","Open Export ZIP":"Abrir Export ZIP","Open Folder":"Abrir carpeta","Open Spectrum File":"Abrir archivo Spectrum","Receiver":"Receiver","Show disabled RCV":"Mostrar RCV deshabilitados","No CPC source loaded":"CPC source no cargado","Cavitation mode":"Modo de cavitación","Candidate threshold":"Umbral candidato","Measurement Timeline / Raw A/D":"Línea temporal / Raw A/D","Cavitation Events":"Eventos de cavitación","Measure / Statistics":"Medición / Estadísticas","Display":"Vista","Y scale":"Escala Y","Show rule / band details":"Mostrar detalles Rule / Band","Why popup":"Ventana Why","Show Increase events":"Mostrar eventos Increase","Show pre-irradiation control":"Mostrar Control pre-irradiación","Sync replay to selected event":"Sincronizar Replay al evento","Lock plot view":"Bloquear vista","Reset view":"Restablecer vista","Control Timeline":"Línea temporal Control","Probable Location":"Ubicación probable","Replay speed":"Velocidad Replay","Event list":"Lista de eventos","Show analysis details":"Mostrar detalles del análisis","View":"Vista","All 8 receivers":"Los 8 Receiver","Lower chart":"Gráfico inferior","Both":"Ambos","Smooth 100 ms":"Suavizado 100 ms","Sync cursor":"Sincronizar cursor","Legend":"Leyenda","All ON":"Todo ON","All Clear":"Limpiar todo","Source details":"Detalles de Source","Temperature Trend (ROI)":"Tendencia de temperatura (ROI)","Treatment MR":"MR de tratamiento","Treatment Thermal":"Thermal de tratamiento","Temperature":"Temperatura","Ready":"Listo","Processing…":"Procesando…","No data":"Sin datos",
    },
    "th": {
        "File":"ไฟล์","Open ZIP...":"เปิด ZIP...","Open Folder...":"เปิดโฟลเดอร์...","Language:":"ภาษา:","&Language":"ภาษา(&L)","Replay":"รีเพลย์","Cavitation Intelligence":"การวิเคราะห์ Cavitation","Sonication Summary":"สรุป Sonication","Sonication Elements":"องค์ประกอบ Sonication","Analysis (preserved)":"การวิเคราะห์ (คงไว้)","Planning / Reference":"การวางแผน / อ้างอิง","Export / Replay Status":"สถานะ Export / Replay","Thermometry Data":"ข้อมูลอุณหภูมิ","Comparison":"เปรียบเทียบ","Engineering Analysis":"การวิเคราะห์ทางวิศวกรรม","Diagnostics":"การวินิจฉัย",
        "Select From Loaded Export":"เลือกจาก Export ที่โหลดแล้ว","Open Export ZIP":"เปิด Export ZIP","Open Folder":"เปิดโฟลเดอร์","Open Spectrum File":"เปิดไฟล์ Spectrum","Receiver":"Receiver","Show disabled RCV":"แสดง RCV ที่ปิดใช้งาน","No CPC source loaded":"ยังไม่ได้โหลด CPC source","Cavitation mode":"โหมด Cavitation","Candidate threshold":"เกณฑ์ผู้สมัคร","Measurement Timeline / Raw A/D":"ไทม์ไลน์การวัด / Raw A/D","Cavitation Events":"เหตุการณ์ Cavitation","Measure / Statistics":"การวัด / สถิติ","Display":"แสดงผล","Y scale":"สเกล Y","Show rule / band details":"แสดงรายละเอียด Rule / Band","Why popup":"ป๊อปอัป Why","Show Increase events":"แสดงเหตุการณ์ Increase","Show pre-irradiation control":"แสดง Control ก่อนฉาย","Sync replay to selected event":"ซิงค์ Replay กับเหตุการณ์ที่เลือก","Lock plot view":"ล็อกมุมมองกราฟ","Reset view":"รีเซ็ตมุมมอง","Control Timeline":"ไทม์ไลน์ Control","Probable Location":"ตำแหน่งที่เป็นไปได้","Replay speed":"ความเร็ว Replay","Event list":"รายการเหตุการณ์","Show analysis details":"แสดงรายละเอียดการวิเคราะห์","View":"มุมมอง","All 8 receivers":"Receiver ทั้ง 8","Lower chart":"กราฟล่าง","Both":"ทั้งสอง","Smooth 100 ms":"ทำให้เรียบ 100 ms","Sync cursor":"ซิงค์เคอร์เซอร์","Legend":"คำอธิบาย","All ON":"เปิดทั้งหมด","All Clear":"ล้างทั้งหมด","Source details":"รายละเอียด Source","Temperature Trend (ROI)":"แนวโน้มอุณหภูมิ (ROI)","Treatment MR":"MR การรักษา","Treatment Thermal":"Thermal การรักษา","Temperature":"อุณหภูมิ","Ready":"พร้อม","Processing…":"กำลังประมวลผล…","No data":"ไม่มีข้อมูล",
    },
    "hi": {
        "File":"फ़ाइल","Open ZIP...":"ZIP खोलें...","Open Folder...":"फ़ोल्डर खोलें...","Language:":"भाषा:","&Language":"भाषा(&L)","Replay":"रीप्ले","Cavitation Intelligence":"Cavitation विश्लेषण","Sonication Summary":"Sonication सारांश","Sonication Elements":"Sonication तत्व","Analysis (preserved)":"विश्लेषण (सुरक्षित)","Planning / Reference":"Planning / Reference","Export / Replay Status":"Export / Replay स्थिति","Thermometry Data":"तापमान डेटा","Comparison":"तुलना","Engineering Analysis":"इंजीनियरिंग विश्लेषण","Diagnostics":"निदान",
        "Select From Loaded Export":"लोड किए Export से चुनें","Open Export ZIP":"Export ZIP खोलें","Open Folder":"फ़ोल्डर खोलें","Open Spectrum File":"Spectrum फ़ाइल खोलें","Receiver":"Receiver","Show disabled RCV":"अक्षम RCV दिखाएँ","No CPC source loaded":"CPC source लोड नहीं है","Cavitation mode":"Cavitation मोड","Candidate threshold":"Candidate threshold","Measurement Timeline / Raw A/D":"मापन टाइमलाइन / Raw A/D","Cavitation Events":"Cavitation घटनाएँ","Measure / Statistics":"मापन / सांख्यिकी","Display":"डिस्प्ले","Y scale":"Y स्केल","Show rule / band details":"Rule / Band विवरण दिखाएँ","Why popup":"Why पॉपअप","Show Increase events":"Increase घटनाएँ दिखाएँ","Show pre-irradiation control":"पूर्व-irradiation Control दिखाएँ","Sync replay to selected event":"चयनित घटना से Replay सिंक करें","Lock plot view":"प्लॉट व्यू लॉक करें","Reset view":"व्यू रीसेट करें","Control Timeline":"Control टाइमलाइन","Probable Location":"संभावित स्थान","Replay speed":"Replay गति","Event list":"घटना सूची","Show analysis details":"विश्लेषण विवरण दिखाएँ","View":"व्यू","All 8 receivers":"सभी 8 Receiver","Lower chart":"निचला चार्ट","Both":"दोनों","Smooth 100 ms":"100 ms smoothing","Sync cursor":"कर्सर सिंक","Legend":"लेजेंड","All ON":"सभी ON","All Clear":"सभी साफ़","Source details":"Source विवरण","Temperature Trend (ROI)":"तापमान ट्रेंड (ROI)","Treatment MR":"Treatment MR","Treatment Thermal":"Treatment Thermal","Temperature":"तापमान","Ready":"तैयार","Processing…":"प्रोसेस हो रहा है…","No data":"कोई डेटा नहीं",
    },
}


def ui_text(locale: str, text: str) -> str:
    """Translate a known static UI label while allowing reversible language switching."""
    raw = str(text or "")
    # Recover the canonical English source if the current text is already localized.
    canonical = raw
    for mapping in UI_TEXT.values():
        for source, localized in mapping.items():
            if raw == localized:
                canonical = source
                break
        if canonical != raw:
            break
    if locale == "en":
        return canonical
    return UI_TEXT.get(locale, {}).get(canonical, canonical)


def localize_qt_tree(root, locale: str) -> None:
    """Localize known static labels/actions/tabs below a Qt object without touching data values."""
    if root is None:
        return
    # Walk QObject children without importing Qt here; this keeps i18n.py usable
    # in source-validation environments where PySide6 is not installed.
    objects = [root]
    cursor = 0
    while cursor < len(objects):
        parent = objects[cursor]
        cursor += 1
        try:
            objects.extend(list(parent.children()))
        except Exception:
            pass
    seen = set()
    for obj in objects:
        if id(obj) in seen:
            continue
        seen.add(id(obj))
        try:
            if hasattr(obj, "text") and hasattr(obj, "setText"):
                current = obj.text()
                translated = ui_text(locale, current)
                if translated != current:
                    obj.setText(translated)
        except Exception:
            pass
        # QGroupBox/QMenu/window titles.
        try:
            if hasattr(obj, "title") and hasattr(obj, "setTitle"):
                current = obj.title()
                translated = ui_text(locale, current)
                if translated != current:
                    obj.setTitle(translated)
        except Exception:
            pass
        # QTabWidget labels are not ordinary child text properties.
        try:
            if hasattr(obj, "count") and hasattr(obj, "tabText") and hasattr(obj, "setTabText"):
                for i in range(int(obj.count())):
                    current = obj.tabText(i)
                    translated = ui_text(locale, current)
                    if translated != current:
                        obj.setTabText(i, translated)
        except Exception:
            pass
        # Static combo-box choices (Color by, View, Lower chart, etc.).
        # Only exact canonical strings in UI_TEXT are touched, so data-driven
        # combo entries such as file names and Sonication IDs remain unchanged.
        try:
            if hasattr(obj, "count") and hasattr(obj, "itemText") and hasattr(obj, "setItemText"):
                for i in range(int(obj.count())):
                    current = obj.itemText(i)
                    translated = ui_text(locale, current)
                    if translated != current:
                        obj.setItemText(i, translated)
        except Exception:
            pass
        # QTableWidget/QTableView headers frequently contained the last English
        # strings after a language switch.  Translate exact known header text.
        try:
            if hasattr(obj, "columnCount") and hasattr(obj, "horizontalHeaderItem"):
                for i in range(int(obj.columnCount())):
                    item = obj.horizontalHeaderItem(i)
                    if item is None:
                        continue
                    current = item.text()
                    translated = ui_text(locale, current)
                    if translated != current:
                        item.setText(translated)
        except Exception:
            pass
        # Tooltips are also part of the visible language surface.  Exact-match
        # localization avoids touching dynamic evidence/tooltips.
        try:
            if hasattr(obj, "toolTip") and hasattr(obj, "setToolTip"):
                current = obj.toolTip()
                translated = ui_text(locale, current)
                if translated != current:
                    obj.setToolTip(translated)
        except Exception:
            pass

# Additional high-level workspaces and engineering tabs.
UI_TEXT['ja'].update({'Elements & Skull':'Elements / Skull','Metrics':'メトリクス','Dependency Graph':'依存関係グラフ','ACT / Elements':'ACT / Elements','Skull / SDR':'Skull / SDR','Spectrum Structure':'Spectrum構造','Thermometry':'温度計測','RCV likelihood':'RCV尤度','MR correlation':'MR相関'})
UI_TEXT['ko'].update({'Elements & Skull':'Elements / Skull','Metrics':'메트릭','Dependency Graph':'의존성 그래프','ACT / Elements':'ACT / Elements','Skull / SDR':'Skull / SDR','Spectrum Structure':'Spectrum 구조','Thermometry':'온도 측정','RCV likelihood':'RCV 가능도','MR correlation':'MR 상관'})
UI_TEXT['zh_TW'].update({'Elements & Skull':'Elements / Skull','Metrics':'指標','Dependency Graph':'相依性圖','ACT / Elements':'ACT / Elements','Skull / SDR':'Skull / SDR','Spectrum Structure':'Spectrum 結構','Thermometry':'溫度量測','RCV likelihood':'RCV 可能性','MR correlation':'MR 相關性'})
UI_TEXT['es'].update({'Elements & Skull':'Elements / Skull','Metrics':'Métricas','Dependency Graph':'Gráfico de dependencias','ACT / Elements':'ACT / Elements','Skull / SDR':'Skull / SDR','Spectrum Structure':'Estructura Spectrum','Thermometry':'Termometría','RCV likelihood':'Probabilidad RCV','MR correlation':'Correlación MR'})
UI_TEXT['th'].update({'Elements & Skull':'Elements / Skull','Metrics':'เมตริก','Dependency Graph':'กราฟความสัมพันธ์','ACT / Elements':'ACT / Elements','Skull / SDR':'Skull / SDR','Spectrum Structure':'โครงสร้าง Spectrum','Thermometry':'การวัดอุณหภูมิ','RCV likelihood':'ความเป็นไปได้ RCV','MR correlation':'สหสัมพันธ์ MR'})
UI_TEXT['hi'].update({'Elements & Skull':'Elements / Skull','Metrics':'मेट्रिक्स','Dependency Graph':'निर्भरता ग्राफ','ACT / Elements':'ACT / Elements','Skull / SDR':'Skull / SDR','Spectrum Structure':'Spectrum संरचना','Thermometry':'थर्मोमेट्री','RCV likelihood':'RCV संभावना','MR correlation':'MR सहसंबंध'})

# Core narrative localization for the two newly supported APAC languages.
TEXT['th'] = {
    'load_sonication':'โหลด Sonication เพื่อเริ่มการวิเคราะห์','root_unavailable':'ไม่สามารถทำ Root Cause Analysis ได้',
    'sync_evidence':'Sonication {son} · Replay {time:.3f} s · ซิงค์หลักฐาน Cavitation แล้ว','no_event':'ไม่พบเหตุการณ์ Cavitation','no_mr':'ไม่มีข้อมูลสหสัมพันธ์ MR',
    'registered_ct_pending':'มี CT ที่ลงทะเบียนแล้ว · รอการจำแนก','indeterminate':'ไม่สามารถสรุปได้','probable':'ตำแหน่งที่เป็นไปได้ ({x:+.2f}, {y:+.2f})',
    'note':'Observed คือหลักฐานที่วัดได้จาก acquisition/control log ส่วน Reconstructed คือผลที่สร้างใหม่จาก SpectrumDumps และกฎ INI การระบุตำแหน่งรวมความเข้ม RCV, receiver weighting ของ FUS/vendor และสหสัมพันธ์การสูญเสียสัญญาณ MR magnitude โดย Root Cause Analysis จัดอันดับหลักฐานสนับสนุนและไม่ยืนยันเหตุเชิงชีววิทยา',
    'ready':'พร้อม','rca_detected':'ตรวจพบ Cavitation','rca_not_detected':'ไม่พบเหตุการณ์ควบคุม Cavitation ที่ยืนยันแล้ว',
    'rca_summary':'{state} ปัจจัยที่มีหลักฐานสนับสนุนมากที่สุด: {names} คะแนน RCA {score:.0f}/100 (ความครอบคลุมหลักฐาน {confidence})',
    'rca_warning':'ผู้สมัคร pre-cavitation warning: {label} สูงขึ้นแม้ยังไม่มี control event ที่ยืนยัน','unavailable_evidence':'ไม่มีหลักฐานที่ใช้ได้','not_inferred':'ไม่ทำการคาดเดา โปรดเพิ่ม source data ที่ขาด',
    'confidence_High':'สูง','confidence_Moderate':'ปานกลาง','confidence_Low':'ต่ำ','confidence_Unavailable':'ใช้ไม่ได้',
    'factor_event':'Cavitation control threshold crossing','factor_multiband':'การเพิ่มขึ้นอย่างรวดเร็วของ acoustic multi-band','factor_drive':'acoustic drive สูง / การเพิ่มกำลังเร็ว','factor_thermal':'Thermal preconditioning / ความร้อนสะสม','factor_rcv':'การกระจุกตัวของ RCV contribution','factor_history':'ประวัติ Cavitation ของ Sonication ก่อนหน้า','factor_mr':'การเปลี่ยนแปลง MR ที่สัมพันธ์กับ acoustic candidate',
    'improve_event':'ลดการเพิ่มกำลังก่อนถึง threshold เดิม และตรวจว่า vendor rule / band / RCV ใด trigger ก่อน','improve_multiband':'ใช้ acoustic signature ที่เพิ่มขึ้นก่อนสุดเป็น pre-cavitation warning และจำกัดการเพิ่มกำลังต่อ','improve_drive':'ลด power increment หรือ peak drive พร้อมตรวจ thermal response','improve_thermal':'เพิ่มเวลาระบายความร้อนหรือหลีกเลี่ยง high drive ซ้ำขณะ target ยังร้อน','improve_rcv':'ตรวจ focus / phase / element loading และดูว่า receiver dominance เดิมเกิดซ้ำหรือไม่','improve_history':'หากเกิดซ้ำให้พิจารณา history-dependent และลด escalation / เพิ่ม cooling ก่อนลองใหม่','improve_mr':'หาก acoustic และ MR change อยู่ตำแหน่งเดียวกัน ให้ตรวจตำแหน่ง registration ก่อนเพิ่มกำลัง',
    'evidence_missing':'ไม่มีหลักฐาน Cavitation ของ Sonication ก่อนหน้า','replay_cpc_unavailable':'ไม่มีหลักฐาน CPC Cavitation สำหรับ Sonication นี้','dominant_rcv_unavailable':'Dominant RCV: -- | MR correlation: --','no_sync_cpc':'ไม่มี CPC/RCV measurement ที่ซิงค์กับ MR time {time:.3f} s','likelihood_unavailable':'ไม่สามารถสร้าง Cavitation likelihood map จากหลักฐานปัจจุบัน','probable_region_note':'การตีความ: นี่คือบริเวณที่เป็นไปได้ ไม่ใช่การระบุตำแหน่งจุดเดียว',
}
TEXT['hi'] = {
    'load_sonication':'विश्लेषण शुरू करने के लिए Sonication लोड करें','root_unavailable':'Root Cause Analysis उपलब्ध नहीं है।',
    'sync_evidence':'Sonication {son} · Replay {time:.3f} s · Cavitation evidence सिंक्रोनाइज़्ड','no_event':'कोई Cavitation घटना नहीं मिली','no_mr':'MR correlation डेटा उपलब्ध नहीं है',
    'registered_ct_pending':'Registered CT उपलब्ध · classification लंबित','indeterminate':'निर्णय संभव नहीं','probable':'संभावित स्थान ({x:+.2f}, {y:+.2f})',
    'note':'Observed acquisition/control log से मापा गया evidence है और Reconstructed SpectrumDumps तथा INI rules से पुनर्निर्मित परिणाम है। स्थान निर्धारण RCV intensity, FUS/vendor receiver weighting और MR magnitude signal-loss correlation को जोड़ता है। Root Cause Analysis सहायक evidence को रैंक करता है और जैविक कारण का दावा नहीं करता।',
    'ready':'तैयार','rca_detected':'Cavitation पाया गया','rca_not_detected':'कोई पुष्ट Cavitation control event नहीं',
    'rca_summary':'{state}. सबसे समर्थित कारक: {names}. RCA score {score:.0f}/100 (evidence coverage: {confidence}).',
    'rca_warning':'Pre-cavitation warning candidate: पुष्ट control event नहीं है, लेकिन {label} बढ़ा हुआ है।','unavailable_evidence':'Evidence उपलब्ध नहीं','not_inferred':'अनुमान नहीं लगाया गया। कृपया अनुपलब्ध source data जोड़ें।',
    'confidence_High':'उच्च','confidence_Moderate':'मध्यम','confidence_Low':'निम्न','confidence_Unavailable':'अनुपलब्ध',
    'factor_event':'Cavitation control threshold crossing','factor_multiband':'Acoustic multi-band में तेज़ वृद्धि','factor_drive':'उच्च acoustic drive / तेज़ power escalation','factor_thermal':'Thermal preconditioning / संचित heating','factor_rcv':'स्थानीय RCV contribution concentration','factor_history':'पिछली Sonication का Cavitation इतिहास','factor_mr':'Acoustic candidate से संबंधित MR बदलाव',
    'improve_event':'उसी threshold तक पहुँचने से पहले escalation घटाएँ और देखें कि कौन-सा vendor rule / band / RCV पहले trigger हुआ।','improve_multiband':'सबसे पहले बढ़ने वाले acoustic signature को pre-cavitation warning की तरह उपयोग करें और आगे power escalation सीमित करें।','improve_drive':'Thermal response देखते हुए छोटे power increments या कम peak drive का उपयोग करें।','improve_thermal':'Cooling बढ़ाएँ या target गर्म रहने पर high drive दोहराने से बचें।','improve_rcv':'Focus / phase / element loading की समीक्षा करें और देखें कि वही receiver dominance दोहरती है या नहीं।','improve_history':'दोहराव होने पर इसे history-dependent मानें और retry से पहले escalation घटाएँ / cooling बढ़ाएँ।','improve_mr':'यदि acoustic और MR बदलाव co-localize हों तो आगे escalation से पहले registered location की समीक्षा करें।',
    'evidence_missing':'पिछली Sonication का Cavitation evidence उपलब्ध नहीं','replay_cpc_unavailable':'इस Sonication के लिए CPC Cavitation evidence उपलब्ध नहीं','dominant_rcv_unavailable':'Dominant RCV: -- | MR correlation: --','no_sync_cpc':'MR time {time:.3f} s पर synchronized CPC/RCV measurement उपलब्ध नहीं','likelihood_unavailable':'वर्तमान evidence से Cavitation likelihood map उपलब्ध नहीं है।','probable_region_note':'व्याख्या: यह संभावित क्षेत्र है, एकल-बिंदु localization नहीं।',
}


# R0116zz: expand the runtime localization surface to the scientific-analysis
# workspaces introduced in the late R0116 series.  Anatomical axis identifiers
# (RL/AP/SI) and engineering identifiers (ROW/COL, MR/CPC/RCV/CGA/FFT) remain
# unchanged so screenshots can be compared across sites/languages.
_RICH_UI_I18N = {
    "ja": {
        "Orientation":"方向","Displayed Plane":"表示プレーン","Orientation Status":"方向状態","Frequency Dir":"周波数方向","Frequency Direction":"周波数方向",
        "Target Energy":"目標Energy","Actual Energy":"実Energy","Target Power":"目標Power","Actual Power":"実Power","Target Duration":"目標時間","Actual Duration":"実時間","Frequency":"周波数",
        "Show in Replay":"Replayで表示","Open Spectrum Dump Analyzer":"Spectrum Dump Analyzerを開く","Treatment Outcome Science":"Treatment Outcome Science",
        "Replay position":"Replay位置","Show event / element lists":"Event / Element一覧を表示","Evidence chain — Time → RCV → Band → MR → Location → Skull → Power":"Evidence chain — Time → RCV → Band → MR → Location → Skull → Power",
        "Thermal × Cavitation outcome: --":"Thermal × Cavitation outcome: --","Thermal response":"Thermal response","Cavitation burden":"Cavitation burden","What-if priority: --":"What-if優先度: --",
        "Cavitation Root Cause Analysis — why did this Sonication cavitate?":"Cavitation Root Cause Analysis — なぜこのSonicationでcavitationが起きたか？",
        "Rank / Contributor":"順位 / 要因","Contribution":"寄与度","Evidence":"Evidence","Confidence":"信頼度","Improvement direction":"改善方向",
        "Build / Refresh treatment map":"Treatment mapを作成 / 更新","Color by":"色分け","Sonication labels":"Sonicationラベル","Treatment map: not built":"Treatment map: 未作成",
        "Power":"Power","Energy":"Energy","Peak temperature":"Peak temperature","RCA score":"RCA score","RCV concentration":"RCV集中度",
        "Sonication":"Sonication","Thermal":"Thermal","Cavitation":"Cavitation","Peak °C":"Peak °C","Power W":"Power W","Energy J":"Energy J","RCV conc.":"RCV集中度","Outcome":"Outcome","Balance":"Balance","What-if priority":"What-if優先度",
        "Event":"Event","Band / Energy":"Band / Energy","MR Signal":"MR Signal","Skull Class":"Skull分類","Power Response":"Power Response",
        "Series Description":"Series Description","Manufacturer":"Manufacturer","Matrix":"Matrix","Slice Thickness":"Slice Thickness","Pixel Size":"Pixel Size","Flip Angle":"Flip Angle","Series UID":"Series UID",
        "Protocol Name":"Protocol名","Planned Power %":"予定Power %","Planned Duration":"予定時間","Cooling Duration":"Cooling時間","Dose Threshold":"Dose threshold","Spot Diameter":"Spot径",
        "Show analysis details":"解析詳細を表示","Hide analysis details":"解析詳細を隠す","Analysis details":"解析詳細","Controller ExPowerRatio":"Controller ExPowerRatio",
        "Reference / trade-off candidates: --":"Reference / trade-off候補: --","Reference candidates":"Reference候補","Poor trade-off candidates":"Poor trade-off候補",
        "Descriptive score":"記述スコア","Irradiation time (s)":"照射時間 (s)","Measurement time (s)":"計測時間 (s)","Time (s)":"時間 (s)",
        "Threshold":"Threshold","80% threshold":"80% threshold","Normalized threshold":"Normalized threshold",
    },
    "ko": {
        "Orientation":"방향","Displayed Plane":"표시 평면","Orientation Status":"방향 상태","Frequency Dir":"주파수 방향","Frequency Direction":"주파수 방향",
        "Target Energy":"목표 Energy","Actual Energy":"실제 Energy","Target Power":"목표 Power","Actual Power":"실제 Power","Target Duration":"목표 시간","Actual Duration":"실제 시간","Frequency":"주파수",
        "Show in Replay":"Replay에서 보기","Open Spectrum Dump Analyzer":"Spectrum Dump Analyzer 열기","Treatment Outcome Science":"Treatment Outcome Science",
        "Replay position":"Replay 위치","Show event / element lists":"Event / Element 목록 표시","Thermal response":"Thermal response","Cavitation burden":"Cavitation burden","What-if priority: --":"What-if 우선순위: --",
        "Cavitation Root Cause Analysis — why did this Sonication cavitate?":"Cavitation Root Cause Analysis — 이 Sonication에서 왜 cavitation이 발생했나?",
        "Rank / Contributor":"순위 / 기여요인","Contribution":"기여도","Evidence":"근거","Confidence":"신뢰도","Improvement direction":"개선 방향",
        "Build / Refresh treatment map":"Treatment map 생성 / 갱신","Color by":"색상 기준","Sonication labels":"Sonication 라벨","Treatment map: not built":"Treatment map: 미생성",
        "Peak temperature":"Peak temperature","RCA score":"RCA score","RCV concentration":"RCV 집중도","Thermal":"Thermal","Cavitation":"Cavitation","RCV conc.":"RCV 집중도","Outcome":"결과","Balance":"균형","What-if priority":"What-if 우선순위",
        "Event":"Event","Band / Energy":"Band / Energy","MR Signal":"MR Signal","Skull Class":"Skull 분류","Power Response":"Power Response",
        "Protocol Name":"Protocol 이름","Planned Power %":"계획 Power %","Planned Duration":"계획 시간","Cooling Duration":"Cooling 시간","Dose Threshold":"Dose threshold","Spot Diameter":"Spot 직경",
        "Analysis details":"분석 상세","Reference candidates":"Reference 후보","Poor trade-off candidates":"Poor trade-off 후보","Irradiation time (s)":"조사 시간 (s)","Measurement time (s)":"측정 시간 (s)","Time (s)":"시간 (s)",
    },
    "zh_TW": {
        "Orientation":"方向","Displayed Plane":"顯示平面","Orientation Status":"方向狀態","Frequency Dir":"頻率方向","Frequency Direction":"頻率方向",
        "Target Energy":"目標 Energy","Actual Energy":"實際 Energy","Target Power":"目標 Power","Actual Power":"實際 Power","Target Duration":"目標時間","Actual Duration":"實際時間","Frequency":"頻率",
        "Show in Replay":"在 Replay 顯示","Open Spectrum Dump Analyzer":"開啟 Spectrum Dump Analyzer","Treatment Outcome Science":"Treatment Outcome Science",
        "Replay position":"Replay 位置","Show event / element lists":"顯示 Event / Element 清單","Thermal response":"Thermal response","Cavitation burden":"Cavitation burden","What-if priority: --":"What-if 優先順序: --",
        "Cavitation Root Cause Analysis — why did this Sonication cavitate?":"Cavitation Root Cause Analysis — 為何此 Sonication 發生 cavitation？",
        "Rank / Contributor":"排名 / 因素","Contribution":"貢獻度","Evidence":"證據","Confidence":"可信度","Improvement direction":"改善方向",
        "Build / Refresh treatment map":"建立 / 更新 Treatment map","Color by":"著色依據","Sonication labels":"Sonication 標籤","Treatment map: not built":"Treatment map: 尚未建立",
        "Peak temperature":"Peak temperature","RCA score":"RCA score","RCV concentration":"RCV 集中度","Thermal":"Thermal","Cavitation":"Cavitation","RCV conc.":"RCV 集中度","Outcome":"結果","Balance":"平衡","What-if priority":"What-if 優先順序",
        "Event":"Event","Band / Energy":"Band / Energy","MR Signal":"MR Signal","Skull Class":"Skull 分類","Power Response":"Power Response",
        "Protocol Name":"Protocol 名稱","Planned Power %":"計畫 Power %","Planned Duration":"計畫時間","Cooling Duration":"Cooling 時間","Dose Threshold":"Dose threshold","Spot Diameter":"Spot 直徑",
        "Analysis details":"分析詳細資料","Reference candidates":"Reference 候選","Poor trade-off candidates":"Poor trade-off 候選","Irradiation time (s)":"照射時間 (s)","Measurement time (s)":"量測時間 (s)","Time (s)":"時間 (s)",
    },
    "es": {
        "Orientation":"Orientación","Displayed Plane":"Plano mostrado","Orientation Status":"Estado de orientación","Frequency Dir":"Dirección de frecuencia","Frequency Direction":"Dirección de frecuencia",
        "Target Energy":"Energía objetivo","Actual Energy":"Energía real","Target Power":"Potencia objetivo","Actual Power":"Potencia real","Target Duration":"Duración objetivo","Actual Duration":"Duración real","Frequency":"Frecuencia",
        "Show in Replay":"Mostrar en Replay","Open Spectrum Dump Analyzer":"Abrir Spectrum Dump Analyzer","Treatment Outcome Science":"Treatment Outcome Science",
        "Replay position":"Posición Replay","Show event / element lists":"Mostrar listas Event / Element","Thermal response":"Respuesta térmica","Cavitation burden":"Carga de cavitación","What-if priority: --":"Prioridad What-if: --",
        "Cavitation Root Cause Analysis — why did this Sonication cavitate?":"Cavitation Root Cause Analysis — ¿por qué cavitó esta Sonication?",
        "Rank / Contributor":"Rango / Factor","Contribution":"Contribución","Evidence":"Evidencia","Confidence":"Confianza","Improvement direction":"Dirección de mejora",
        "Build / Refresh treatment map":"Crear / actualizar mapa","Color by":"Color por","Sonication labels":"Etiquetas Sonication","Treatment map: not built":"Mapa: no creado",
        "Peak temperature":"Temperatura pico","RCA score":"Puntuación RCA","RCV concentration":"Concentración RCV","Thermal":"Térmico","Cavitation":"Cavitación","RCV conc.":"Conc. RCV","Outcome":"Resultado","Balance":"Balance","What-if priority":"Prioridad What-if",
        "Event":"Evento","Band / Energy":"Band / Energía","MR Signal":"Señal MR","Skull Class":"Clase Skull","Power Response":"Respuesta de Power",
        "Protocol Name":"Nombre de Protocol","Planned Power %":"Power % planificado","Planned Duration":"Duración planificada","Cooling Duration":"Duración Cooling","Dose Threshold":"Umbral de dosis","Spot Diameter":"Diámetro Spot",
        "Analysis details":"Detalles del análisis","Reference candidates":"Candidatos Reference","Poor trade-off candidates":"Candidatos de mal trade-off","Irradiation time (s)":"Tiempo de irradiación (s)","Measurement time (s)":"Tiempo de medición (s)","Time (s)":"Tiempo (s)",
    },
    "th": {
        "Orientation":"แนวภาพ","Displayed Plane":"ระนาบที่แสดง","Orientation Status":"สถานะแนวภาพ","Frequency Dir":"ทิศทางความถี่","Frequency Direction":"ทิศทางความถี่",
        "Target Energy":"Energy เป้าหมาย","Actual Energy":"Energy จริง","Target Power":"Power เป้าหมาย","Actual Power":"Power จริง","Target Duration":"ระยะเวลาเป้าหมาย","Actual Duration":"ระยะเวลาจริง","Frequency":"ความถี่",
        "Show in Replay":"แสดงใน Replay","Open Spectrum Dump Analyzer":"เปิด Spectrum Dump Analyzer","Treatment Outcome Science":"Treatment Outcome Science",
        "Replay position":"ตำแหน่ง Replay","Show event / element lists":"แสดงรายการ Event / Element","Thermal response":"การตอบสนอง Thermal","Cavitation burden":"ภาระ Cavitation","What-if priority: --":"ลำดับ What-if: --",
        "Cavitation Root Cause Analysis — why did this Sonication cavitate?":"Cavitation Root Cause Analysis — เหตุใด Sonication นี้จึงเกิด cavitation?",
        "Rank / Contributor":"อันดับ / ปัจจัย","Contribution":"สัดส่วน","Evidence":"หลักฐาน","Confidence":"ความเชื่อมั่น","Improvement direction":"แนวทางปรับปรุง",
        "Build / Refresh treatment map":"สร้าง / รีเฟรช Treatment map","Color by":"ระบายสีตาม","Sonication labels":"ป้าย Sonication","Treatment map: not built":"Treatment map: ยังไม่สร้าง",
        "Peak temperature":"อุณหภูมิสูงสุด","RCA score":"คะแนน RCA","RCV concentration":"ความเข้มข้น RCV","Thermal":"Thermal","Cavitation":"Cavitation","RCV conc.":"RCV concentration","Outcome":"ผลลัพธ์","Balance":"สมดุล","What-if priority":"ลำดับ What-if",
        "Event":"Event","Band / Energy":"Band / Energy","MR Signal":"สัญญาณ MR","Skull Class":"การจำแนก Skull","Power Response":"การตอบสนอง Power",
        "Protocol Name":"ชื่อ Protocol","Planned Power %":"Power % ที่วางแผน","Planned Duration":"ระยะเวลาที่วางแผน","Cooling Duration":"ระยะเวลา Cooling","Dose Threshold":"Dose threshold","Spot Diameter":"เส้นผ่านศูนย์กลาง Spot",
        "Analysis details":"รายละเอียดการวิเคราะห์","Reference candidates":"Reference candidates","Poor trade-off candidates":"Poor trade-off candidates","Irradiation time (s)":"เวลาฉาย (s)","Measurement time (s)":"เวลาวัด (s)","Time (s)":"เวลา (s)",
    },
    "hi": {
        "Orientation":"ओरिएंटेशन","Displayed Plane":"दिखाया गया प्लेन","Orientation Status":"ओरिएंटेशन स्थिति","Frequency Dir":"फ्रीक्वेंसी दिशा","Frequency Direction":"फ्रीक्वेंसी दिशा",
        "Target Energy":"लक्ष्य Energy","Actual Energy":"वास्तविक Energy","Target Power":"लक्ष्य Power","Actual Power":"वास्तविक Power","Target Duration":"लक्ष्य अवधि","Actual Duration":"वास्तविक अवधि","Frequency":"फ्रीक्वेंसी",
        "Show in Replay":"Replay में दिखाएँ","Open Spectrum Dump Analyzer":"Spectrum Dump Analyzer खोलें","Treatment Outcome Science":"Treatment Outcome Science",
        "Replay position":"Replay स्थिति","Show event / element lists":"Event / Element सूची दिखाएँ","Thermal response":"Thermal response","Cavitation burden":"Cavitation burden","What-if priority: --":"What-if प्राथमिकता: --",
        "Cavitation Root Cause Analysis — why did this Sonication cavitate?":"Cavitation Root Cause Analysis — इस Sonication में cavitation क्यों हुआ?",
        "Rank / Contributor":"रैंक / कारक","Contribution":"योगदान","Evidence":"Evidence","Confidence":"विश्वास","Improvement direction":"सुधार दिशा",
        "Build / Refresh treatment map":"Treatment map बनाएँ / रीफ्रेश करें","Color by":"रंग आधार","Sonication labels":"Sonication लेबल","Treatment map: not built":"Treatment map: नहीं बना",
        "Peak temperature":"Peak temperature","RCA score":"RCA score","RCV concentration":"RCV concentration","Thermal":"Thermal","Cavitation":"Cavitation","RCV conc.":"RCV conc.","Outcome":"परिणाम","Balance":"संतुलन","What-if priority":"What-if प्राथमिकता",
        "Event":"Event","Band / Energy":"Band / Energy","MR Signal":"MR Signal","Skull Class":"Skull वर्ग","Power Response":"Power प्रतिक्रिया",
        "Protocol Name":"Protocol नाम","Planned Power %":"योजनाबद्ध Power %","Planned Duration":"योजनाबद्ध अवधि","Cooling Duration":"Cooling अवधि","Dose Threshold":"Dose threshold","Spot Diameter":"Spot व्यास",
        "Analysis details":"विश्लेषण विवरण","Reference candidates":"Reference candidates","Poor trade-off candidates":"Poor trade-off candidates","Irradiation time (s)":"Irradiation समय (s)","Measurement time (s)":"मापन समय (s)","Time (s)":"समय (s)",
    },
}
for _locale, _mapping in _RICH_UI_I18N.items():
    UI_TEXT.setdefault(_locale, {}).update(_mapping)
