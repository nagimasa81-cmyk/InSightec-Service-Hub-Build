import numpy as np
from src.services.replay_service import ReplayService

def test_spatial_peak_rejects_three_scattered_hot_pixels():
    a=np.full((7,7),40.0)
    a[0,0]=80.; a[0,6]=79.; a[6,0]=78.
    roi=np.ones_like(a,dtype=bool)
    v=ReplayService._spatial_robust_peak(a,roi)
    assert v is not None and v < 50.0

def test_spatial_peak_preserves_coherent_hot_neighbourhood():
    a=np.full((7,7),40.0)
    a[2:5,2:5]=60.0
    roi=np.ones_like(a,dtype=bool)
    v=ReplayService._spatial_robust_peak(a,roi)
    assert v is not None and v >= 60.0
