from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
TEXT=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')

def _vendor_energy_block():
    start=TEXT.index('    def _draw_ci_linked_vendor_energy')
    end=TEXT.index('    def _draw_ci_linked_control', start)
    return TEXT[start:end]

def test_ci_linked_vendor_panel_overlays_full_timeline_aggregate_band0_and_band1():
    block=_vendor_energy_block()
    assert 'spectral = getattr(replay, "spectral_replay", None)' in block
    assert 'cached_secondary_products(' in block
    assert 'aggregate_band_energy' in block
    assert 'aggregate_time_s' in block
    assert 'SpectrumMsg aggregate Band0' in block
    assert 'SpectrumMsg aggregate Band1' in block
    assert 'full timeline; no RCV identity' in block

def test_ci_overlay_reuses_preload_owned_products_instead_of_recomputing():
    block=_vendor_energy_block()
    assert '.hydrophone.band_energy(' not in block
    assert 'resolved_band_ranges(' not in block

def test_aggregate_overlay_failure_is_logged_not_swallowed():
    block=_vendor_energy_block()
    assert 'except Exception:' in block
    assert 'LOG.exception("Failed to publish cached aggregate Band0/Band1 on CI linked vendor plot")' in block
