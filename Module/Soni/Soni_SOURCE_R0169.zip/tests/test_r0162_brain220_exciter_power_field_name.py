import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SERVICE_SRC = (ROOT / 'src/services/cavitation_control_timeline_service.py').read_text(encoding='utf-8')


def _current_set_re() -> re.Pattern:
    match = re.search(r'_SET_RE = re\.compile\((r".*?")', SERVICE_SRC)
    assert match, "_SET_RE definition not found"
    pattern = eval(match.group(1))
    return re.compile(pattern, re.I)


BRAIN220_LINE = (
    "19:32:20:004 Inf 2200 4       Set: SubSonic = 0, ExciterElectricalPower = 1200.000 W, "
    "ExciterAcousticalPower = 240.000 W, AblPower = 1200.000 W, ExPowerRatio = 1.0000 (255) "
    "AblPowerRatio = 1.0000 (255), Validity = 9000"
)
BRAIN650_LINE = (
    "19:32:20:004 Inf 2200 4       Set: SubSonic = 0, ExciterPower = 30.000 W, "
    "AblPower = 30.000 W, ExPowerRatio = 1.0000 (255), Validity = 9000"
)


def test_set_re_matches_both_brain220_and_brain650_field_names():
    """Regression guard for a real bug found against a real Brain220
    Acquisition_Brain log: the field is reported as
    "ExciterElectricalPower"/"ExciterAcousticalPower" on Brain220-family
    systems, not the plain "ExciterPower" the old pattern required exactly.
    That made _SET_RE never match a single "Set:" line in any Brain220
    export, so current["power"] -- the observed ExPowerRatio timeline and
    every Decrease/Safety event derived from it -- stayed permanently
    empty, not because no control events occurred but because the parser
    could never see a "Set:" line at all. Confirmed against the real log:
    27305 "ExPowerRatio" occurrences and thousands of "Set:" lines existed,
    yet zero were parsed before this fix."""
    pattern = _current_set_re()
    m220 = pattern.search(BRAIN220_LINE)
    assert m220 is not None, "must match the Brain220 ExciterElectricalPower field name"
    assert m220.group(1).strip() == "1200.000 W"
    assert m220.group(2) == "1.0000"

    m650 = pattern.search(BRAIN650_LINE)
    assert m650 is not None, "must still match the original Brain650 plain ExciterPower field name"
    assert m650.group(1).strip() == "30.000 W"
    assert m650.group(2) == "1.0000"


def test_set_re_prefers_electrical_power_not_acoustical_power():
    """ExciterElectricalPower appears before ExciterAcousticalPower on the
    same Brain220 line; the captured value must be the electrical one
    (1200.000 W), not the acoustical one (240.000 W), matching what the
    plain ExciterPower field represents on Brain650 logs."""
    pattern = _current_set_re()
    m = pattern.search(BRAIN220_LINE)
    assert m.group(1).strip() == "1200.000 W"
