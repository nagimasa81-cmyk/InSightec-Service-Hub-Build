from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
H=(ROOT/'src/ui/hydrophone_window.py').read_text()

def test_default_time_window_ends_at_selected_sonication_not_full_mr():
    block=H.split('self.time_axis_end_combo = QComboBox()',1)[1].split('self.time_axis_status_label',1)[0]
    assert 'addItem("Sonication end", "sonication_end")' in block
    assert 'addItem("MR acquisition end", "mr_end")' in block
    assert 'setCurrentIndex(0)' in block
