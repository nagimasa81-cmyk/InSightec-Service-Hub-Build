from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'src/ui/main_window.py').read_text(encoding='utf-8')


def _block(func_name: str) -> str:
    return MAIN.split(f'def {func_name}', 1)[1].split('\n    def ', 1)[0]


def test_ci_linked_vendor_energy_resets_axis_when_replay_is_none():
    """Regression guard for a real bug found via live screenshots: a blank
    'Vendor band energy reproduction' / 'Cavitation control response' panel
    showed a leftover X-axis range as extreme as -150..100 s (or, in
    another screenshot, a range that simply didn't match the current
    Sonication at all). Root cause: plot.clear() removes plotted curves
    but does NOT reset the ViewBox's view range, and the `if replay is
    None: return` early-exit never touched the range either -- so whatever
    axis a *previous*, unrelated draw call left behind (a different
    Sonication, or a stale pre-fix range) stayed visible underneath the
    now-empty chart. This happens whenever self.default_cpc_replay is
    briefly None while a Sonication switch's background preload is still
    in flight and this panel is asked to redraw in the meantime."""
    block = _block('_draw_ci_linked_vendor_energy')
    none_branch = block.split('if replay is None:', 1)[1].split('return', 1)[0]
    assert 'plot.enableAutoRange(axis=pg.ViewBox.XAxis, enable=True)' in none_branch
    assert 'plot.enableAutoRange(axis=pg.ViewBox.YAxis, enable=True)' in none_branch


def test_ci_linked_control_resets_axis_when_replay_is_none():
    block = _block('_draw_ci_linked_control')
    none_branch = block.split('if replay is None:', 1)[1].split('return', 1)[0]
    assert 'plot.enableAutoRange(axis=pg.ViewBox.XAxis, enable=True)' in none_branch
    assert 'plot.enableAutoRange(axis=pg.ViewBox.YAxis, enable=True)' in none_branch
