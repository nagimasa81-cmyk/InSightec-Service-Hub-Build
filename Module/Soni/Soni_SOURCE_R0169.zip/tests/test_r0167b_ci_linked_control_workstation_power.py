from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'src/ui/main_window.py').read_text(encoding='utf-8')


def _control_block() -> str:
    return MAIN.split('def _draw_ci_linked_control', 1)[1].split('\n    def ', 1)[0]


def test_ci_linked_control_now_plots_workstation_actual_power():
    """The Spectrum Dump Analyzer's own equivalent view
    (hydrophone_window.py's _workstation_actual_power_series /
    _draw_vendor_cavitation) already plots the Workstation PowerGraph's
    "Actual power ratio" alongside CGA Rule 1/2. This CI-linked panel
    (main_window.py) previously only plotted Rule 1/2 -- confirmed against
    a real Brain220 export that Rule 1 (vendor_display_rule1) is 0.0 for
    every one of Sonication1's 698 samples, so this panel could look
    completely flat/near-empty even while the Analyzer's own chart plainly
    showed delivered power rising, because it was simply missing this
    series rather than mis-mapping a domain like R0166."""
    block = _control_block()
    assert 'AcousticControlService().power_graph_for_sonication(' in block
    assert 'name="Actual power ratio (Workstation PowerGraph)"' in block
    assert 'int(self.sonication_index)' in block


def test_workstation_power_lookup_failure_is_logged_not_swallowed():
    block = _control_block()
    workstation_block = block.split('try:', 1)[1].split('if series is not None:', 1)[0]
    assert 'except Exception:' in workstation_block
    assert 'LOG.exception("Failed to load Workstation PowerGraph for CI linked control plot")' in workstation_block
