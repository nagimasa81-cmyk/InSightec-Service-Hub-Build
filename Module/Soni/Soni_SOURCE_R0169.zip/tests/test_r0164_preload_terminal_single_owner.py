from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text()

def test_completed_preload_cannot_be_restarted_by_gui_cache_miss():
    block=MAIN.split('def _start_spectrum_preload',1)[1].split('def _spectrum_preload_thread_finished',1)[0]
    assert 'preload_complete' in block
    assert '_spectrum_preload_failed_workspace' in block

def test_worker_marks_study_attempt_complete_once():
    block=MAIN.split('class SpectrumPreloadWorker',1)[1].split('class SonicationMetadataWorker',1)[0]
    assert 'merged_context["preload_complete"]=True' in block
    assert 'merged_context["attempted_indices"]=set(order)' in block
