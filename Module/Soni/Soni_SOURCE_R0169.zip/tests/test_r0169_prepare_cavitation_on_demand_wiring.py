from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'src/ui/main_window.py').read_text(encoding='utf-8')


def _page_block() -> str:
    return MAIN.split('def _update_cavitation_intelligence_page', 1)[1].split('\n    def ', 1)[0]


def test_prepare_cavitation_on_demand_is_now_wired_in():
    """Regression guard for a real bug found via a live screenshot: the
    MainWindow's "Cavitation Intelligence" -> "Linked Cavitation Analysis"
    panel stayed permanently blank for a whole Sonication (observed at
    "Replay 8/12 - Cooling - 29.0 sec", well past when a real 220 kHz
    Sonication's own background preload should have completed).

    _prepare_cavitation_on_demand() -- a cache-only recovery / preload
    kickoff specifically designed to populate self.default_cpc_replay when
    it's still None -- was defined in the codebase but never called from
    anywhere. Every per-frame Replay update
    (_update_cavitation_intelligence_page, called once per Replay frame
    step) kept reading self.default_cpc_replay as None indefinitely
    whenever the initial preload-completion signal was missed or slow,
    with nothing to ever retry it.
    """
    block = _page_block()
    assert 'self._prepare_cavitation_on_demand()' in block


def test_wiring_cannot_infinitely_recurse():
    """_prepare_cavitation_on_demand() tail-calls back into
    _update_cavitation_intelligence_page() once it has actually adopted a
    replay (self.default_cpc_replay is no longer None at that point), so
    the second invocation's `if self.default_cpc_replay is None` check
    is false and it proceeds past the guard instead of calling
    _prepare_cavitation_on_demand() again -- bounded to one extra level of
    re-entry, not an infinite loop."""
    page_block = _page_block()
    guard = page_block.split('if self.default_cpc_replay is None and self.package is not None:', 1)[1].split('result=', 1)[0]
    assert 'self._prepare_cavitation_on_demand()' in guard
    assert 'return' in guard

    on_demand_block = MAIN.split('def _prepare_cavitation_on_demand', 1)[1].split('\n\n    def ', 1)[0]
    # The only path that calls back into _update_cavitation_intelligence_page
    # is guarded by having first set self.default_cpc_replay=replay.
    tail = on_demand_block.split('self.default_cpc_replay=replay', 1)[1]
    assert 'self._update_cavitation_intelligence_page()' in tail
    # The early-return path (still no replay available) must NOT call back
    # into _update_cavitation_intelligence_page at all.
    early_return = on_demand_block.split('self.default_cpc_replay=replay', 1)[0]
    assert '_update_cavitation_intelligence_page' not in early_return
