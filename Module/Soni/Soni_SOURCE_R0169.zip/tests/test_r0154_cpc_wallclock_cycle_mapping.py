from pathlib import Path
import numpy as np

from src.services.cavitation_control_timeline_service import CavitationControlTimelineService
from src.services.hydrophone_replay_service import CpcHydrophoneFrame, CpcHydrophoneReplay


def test_control_cycle_mapping_uses_acquisition_brain_wallclock_not_fixed_10ms(tmp_path: Path):
    log = tmp_path / 'Acquisition_Brain_test.txt'
    log.write_text('\n'.join([
        '12:00:00:000 Inf Got StartSpectrumMeasurementA',
        '12:00:00:010 Inf Cycle 1 Done.',
        '12:00:00:030 Inf Cycle 2 Done.',
        '12:00:00:100 Inf Set: SubSonic = 0, ExciterPower = 10 W, AblPower = 10 W, ExPowerRatio = 0.2 (1) AblPowerRatio = 0.2 (1)',
        '12:00:00:110 Inf Cycle 3 Done.',
        '12:00:00:160 Inf Set: SubSonic = 0, ExciterPower = 20 W, AblPower = 20 W, ExPowerRatio = 0.4 (2) AblPowerRatio = 0.4 (2)',
        '12:00:00:170 Inf Cycle 4 Done.',
        '12:00:00:300 Inf Cycle 5 Done.',
        '12:00:00:300 Inf Got StopSpectrumMeasurementS',
    ]), encoding='utf-8')
    tl = CavitationControlTimelineService().parse(log, None, 0, None, None, 0.0, 7.0, 20.0, 40.0, None, None, 0.010)
    assert tl.cycle_numbers.tolist() == [1, 2, 3, 4, 5]
    # First physical power Set is 12:00:00.100, so exact Cycle 3 Done is 10 ms later.
    assert np.isclose(tl.cycle_times_s[2], 7.000, atol=1e-9)
    # Cycle 5 occurs 200 ms after acoustic onset, not (5-3)*10ms = 20 ms.
    assert np.isclose(tl.cycle_times_s[4], 7.190, atol=1e-9)
    assert np.isclose(tl.actual_power_times_s[-1], 7.060, atol=1e-9)


def test_replay_history_uses_fft_frame_anchored_fit_not_index_as_cycle_number():
    """R0166 regression guard: mr_raw_timeline_time_s used to treat the
    10-ms measurement history's own sample *indices* (1, 2, 3, ...) as if
    they were real absolute controller cycle numbers, feeding them
    straight into the same cycle-number-to-MR-time table used for FFT
    frames. There is no real per-sample cycle number recorded for the
    history array, so this only ever "worked" by coincidence when a
    Sonication's actual absolute cycle numbers happened to start near 1.
    Confirmed against a real Brain220 export this coincidence does not
    hold in general: fitting over an 18-physical-frame domain spanning
    only ~0.17 s and extrapolating it across ~700 history samples spanning
    ~7 s amplified the mapped timeline out to ~380 s -- far past that
    Sonication's own end time.

    The corrected mapping instead reuses the FFT frames' own real
    acquisition_cycle-anchored mapping (mr_frame_times_s /
    sonication_frame_times_s, which the first two assertions below already
    cover) and fits the 10-ms history's *relative* time base onto that same
    physical relationship via linear interpolation -- anchored to real
    data, not a coincidental index/cycle-number overlap.
    """
    frames = [
        CpcHydrophoneFrame(0, np.array([1.0]), [np.array([1.0])], acquisition_cycle=3, acquisition_time_s=0.02),
        CpcHydrophoneFrame(1, np.array([1.0]), [np.array([1.0])], acquisition_cycle=5, acquisition_time_s=0.04),
    ]
    replay = CpcHydrophoneReplay(None, None, frames=frames, mr_sonication_start_s=7.0)
    replay.raw_timeline_time_s = np.arange(5, dtype=float) * 0.010
    replay.raw_timeline_channels = [np.arange(5, dtype=float) for _ in range(8)]
    replay.controller_cycle_numbers = np.array([1, 2, 3, 4, 5])
    replay.controller_cycle_mr_times_s = np.array([6.91, 6.93, 7.01, 7.07, 7.20])
    assert np.allclose(replay.mr_frame_times_s, [7.01, 7.20])
    assert np.allclose(replay.sonication_frame_times_s, [0.01, 0.20])
    # Anchored to the FFT frames' own real cycle->time fit (slope 9.5,
    # intercept -0.18 from the two real acquisition_cycle anchors above),
    # not the coincidental controller_cycle_mr_times_s lookup table.
    assert np.allclose(replay.mr_raw_timeline_time_s, [6.82, 6.915, 7.01, 7.105, 7.20], atol=1e-9)


def test_extrapolation_guard_falls_back_to_plain_offset_when_domains_mismatch():
    """A composite 220/230 kHz Sonication's physical FFT frame domain can be
    far smaller than the 10-ms history domain being mapped (e.g. 18 frames
    spanning 0.17 s vs. ~700 history samples spanning ~7 s -- a real
    Brain220 export). _acquisition_times_to_sonication() must not
    extrapolate its FFT-frame-fitted line that far; it must fall back to a
    plain offset instead of fabricating a wildly amplified time base."""
    frames = [
        CpcHydrophoneFrame(0, np.array([1.0]), [np.array([1.0])], acquisition_cycle=1, acquisition_time_s=0.00),
        CpcHydrophoneFrame(1, np.array([1.0]), [np.array([1.0])], acquisition_cycle=2, acquisition_time_s=0.01),
    ]
    replay = CpcHydrophoneReplay(None, None, frames=frames, mr_sonication_start_s=9.0,
                                  sonication_time_zero_offset_s=0.0)
    replay.controller_cycle_numbers = np.array([1, 2])
    replay.controller_cycle_mr_times_s = np.array([9.00, 9.60])
    # A long history (7 s) mapped through a fit learned over only 0.01 s of
    # FFT-frame domain -- exactly the real-world amplification scenario.
    long_history = np.arange(700, dtype=float) * 0.010
    mapped = replay._acquisition_times_to_sonication(long_history)
    # Must equal the plain-offset fallback, not an amplified extrapolation.
    assert np.allclose(mapped, long_history - 0.0)
    assert float(np.nanmax(mapped)) < 10.0, "must not amplify a 7s domain into hundreds of seconds"
