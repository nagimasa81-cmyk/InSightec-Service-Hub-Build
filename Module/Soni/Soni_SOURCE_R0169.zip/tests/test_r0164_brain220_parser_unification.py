from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
TIMELINE=(ROOT/'src/services/cavitation_control_timeline_service.py').read_text()
VENDOR=(ROOT/'src/services/cpc_vendor_reproduction_service.py').read_text()

def test_both_acquisition_brain_consumers_accept_brain220_electrical_power():
    token=r'Exciter(?:Electrical)?Power'
    assert token in TIMELINE
    assert token in VENDOR
    rx=re.compile(r"Set:.*?Exciter(?:Electrical)?Power\s*=\s*([-+0-9.eE]+)\s*W.*?ExPowerRatio\s*=\s*([-+0-9.eE]+)",re.I)
    assert rx.search('Set: ExciterElectricalPower = 450 W, ExPowerRatio = 0.72')
    assert rx.search('Set: ExciterPower = 450 W, ExPowerRatio = 0.72')
