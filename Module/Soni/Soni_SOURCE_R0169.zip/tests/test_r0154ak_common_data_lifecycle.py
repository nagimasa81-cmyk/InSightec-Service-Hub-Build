from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "src/ui/main_window.py").read_text(encoding="utf-8")
ANALYZER = (ROOT / "src/ui/hydrophone_window.py").read_text(encoding="utf-8")
REPLAY = (ROOT / "src/services/replay_service.py").read_text(encoding="utf-8")


def _block(text: str, start: str, end: str) -> str:
    a = text.index(start)
    b = text.index(end, a)
    return text[a:b]


def test_preload_publishes_each_sonication_before_study_completion():
    worker = _block(MAIN, "class SpectrumPreloadWorker", "class SonicationMetadataWorker")
    wiring = _block(MAIN, "    def _start_spectrum_preload", "    def _spectrum_preload_thread_finished")
    assert "sonicationReady = Signal" in worker
    assert "self.sonicationReady.emit" in worker
    assert "worker.sonicationReady.connect(self._spectrum_preload_sonication_ready)" in wiring


def test_derived_product_failure_does_not_hide_decoded_core_evidence():
    worker = _block(MAIN, "class SpectrumPreloadWorker", "class SonicationMetadataWorker")
    assert "secondary_errors" in worker
    assert "Core decoded evidence is already valid" in worker
    assert worker.index("self.sonicationReady.emit") > worker.index("secondary_errors")


def test_summary_starts_detail_and_thermometry_as_independent_background_owners():
    refresh = _block(MAIN, "    def _refresh_sonication_summary", "    def _sonication_summary_progressed")
    assert "thread.start(QThread.Priority.LowPriority)" in refresh
    assert "self._start_sonication_summary_temperature_background(generation)" in refresh


def test_composite_analyzer_controls_use_the_spectrum_cursor_domain():
    handoff = _block(ANALYZER, "    def _finish_loaded_sonication_handoff", "    def _set_secondary_product_state")
    assert "count = self._cursor_frame_count()" in handoff
    assert "count = len(self.replay.frames)" not in handoff
    assert "self.slider.setRange(0, max(0, count-1))" in handoff


def test_named_nonthermal_mr_protocol_cannot_become_celsius():
    protocol = _block(REPLAY, "    def _thermometry_protocol", "    def _baseline")
    mode = _block(REPLAY, "    def _temperature_mode", "    def clear_cache")
    assert "T2_STAR" in protocol and "NFUSCAL" in protocol and "TMAP" in protocol
    assert "if protocol_ok is False" in mode
    assert '("Unavailable", 37.0)' in mode


def test_partial_acquisition_score_is_filled_without_extrapolation():
    merge = _block(MAIN, "    def _merge_replay_score_into_acoustic", "    def _build_acoustic_trends")
    assert "np.where(np.isfinite(prior),prior,fallback)" in merge
    assert "q<=st[-1]+1e-6" in merge
    assert "explicit Acquisition Score retained" in merge


def test_vendor_view_reports_separate_control_and_hydrophone_coverage():
    vendor = _block(ANALYZER, "    def _draw_vendor_cavitation", "    def _update_vendor_current_marker")
    assert "physical CPC Rule/Score history" in vendor
    assert "SpectrumMsg hydrophone aggregate" in vendor
    assert "never synthesized beyond its saved coverage" in vendor
