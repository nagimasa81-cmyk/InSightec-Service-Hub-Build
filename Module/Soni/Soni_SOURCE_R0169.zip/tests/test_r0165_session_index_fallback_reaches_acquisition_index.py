from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _sites():
    return [
        (ROOT / 'src/ui/hydrophone_window.py', '_build_observed_cavitation_timeline_for_replay'),
        (ROOT / 'src/services/spectrum_evidence_repository.py', '_observed_control_timeline'),
        (ROOT / 'src/services/sonication_summary_cavitation_evidence_service.py', None),
    ]


def test_no_remaining_site_treats_a_non_none_history_object_as_a_usable_session():
    """Regression guard for a real bug found by cross-Sonication evaluation
    against a real 7-Sonication Brain220 export: every one of the three
    call sites that resolve which Acquisition_Brain session to parse used

        preferred = history.log_session_index if history is not None else replay.acquisition_session_index

    `history` (vendor_history_validation) is almost always a real object
    even when its cross-validation didn't reach "EXACT" (status=
    "INI-derived", see COMMIT_R0162.md/COMMIT_R0164.md) -- so `history is
    not None` was true for every Sonication, `history.log_session_index`
    was None in every case, and the correct per-Sonication fallback
    (replay.acquisition_session_index, which genuinely differs: 32, 33,
    34, 35, 36, 37, 38 in the real export) was never reached.
    CavitationControlTimelineService.parse() then auto-picked "whichever
    session has the most events" for every single Sonication -- silently
    showing one Sonication's observed control timeline (Control Timeline
    tab, _current_control_time() cursor mapping, observed-event highlight)
    on all seven.
    """
    stale_pattern_variants = (
        'preferred_session = history_validation.log_session_index if history_validation is not None else getattr(replay, "acquisition_session_index", None)',
        'preferred = getattr(history, "log_session_index", None) if history is not None else getattr(replay, "acquisition_session_index", None)',
    )
    for path, _ in _sites():
        text = path.read_text(encoding='utf-8')
        for stale in stale_pattern_variants:
            assert stale not in text, f"{path}: stale history-is-not-None-implies-usable pattern still present"


def test_all_three_sites_fall_back_to_acquisition_session_index_when_log_session_index_is_none():
    hydro = (ROOT / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    repo = (ROOT / 'src/services/spectrum_evidence_repository.py').read_text(encoding='utf-8')
    evidence = (ROOT / 'src/services/sonication_summary_cavitation_evidence_service.py').read_text(encoding='utf-8')

    block = hydro.split('def _build_observed_cavitation_timeline_for_replay', 1)[1].split('\n\ndef ', 1)[0]
    assert 'if preferred_session is None:' in block
    assert 'preferred_session = getattr(replay, "acquisition_session_index", None)' in block

    block = repo.split('def _observed_control_timeline', 1)[1].split('\n\n    @', 1)[0]
    assert 'if preferred_session is None:' in block
    assert 'preferred_session = getattr(replay, "acquisition_session_index", None)' in block

    block = evidence.split('preferred = getattr(history, "log_session_index", None) if history is not None else None', 1)[1][:200]
    assert 'if preferred is None:' in block
    assert 'preferred = getattr(replay, "acquisition_session_index", None)' in block
