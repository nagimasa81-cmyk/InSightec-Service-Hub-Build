from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')

def _func(text,name,next_name):
    start=text.index(f'    def {name}')
    end=text.index(f'    def {next_name}', start)
    return text[start:end]

def test_ci_aggregate_is_cache_owned_not_recomputed_in_paint_path():
    body=_func(MAIN,'_draw_ci_linked_vendor_energy','_draw_ci_linked_control')
    assert 'cached_secondary_products(' in body
    assert 'aggregate_band_energy' in body
    assert 'aggregate_time_s' in body
    assert '.hydrophone.band_energy(' not in body

def test_tab_change_is_cache_publish_only():
    body=_func(HYDRO,'_analyzer_tab_changed','_ensure_current_tab_materialized')
    assert '_publish_current_secondary_tab_from_cache' in body
    assert '_ensure_current_tab_materialized' not in body
    assert '_queue_secondary_analysis' not in body
