from pathlib import Path

P=Path(__file__).resolve().parents[1]/'src'/'services'/'import_diagnostics_service.py'
T=P.read_text(encoding='utf-8')


def test_diagnostics_distinguish_source_frames_from_replay_aligned_samples():
    assert 'replay_aligned_finite_samples' in T
    assert '"decoded_frames"' not in T


def test_diagnostics_include_per_source_frame_temperature_audit_without_pixels():
    assert 'def _thermometry_source_frame_audit' in T
    assert 'robust_peak_c' in T
    assert 'robust_delta_c' in T
    assert 'mapped_replay_samples' in T
