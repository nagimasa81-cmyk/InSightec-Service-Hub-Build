from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'src/services/hydrophone_replay_service.py').read_text(encoding='utf-8')


def test_mr_raw_timeline_time_s_no_longer_treats_history_index_as_cycle_number():
    """Regression guard for a real bug found via live 220 kHz screenshots:
    every one of 7 real Sonications' Vendor/Raw-history timelines (the
    "Measurement Timeline / Raw A/D" and "CGA Cavitation / Vendor Rules"
    tabs) stretched out to ~130-400 s -- this study's overall
    multi-Sonication session span -- instead of the few seconds the
    10-ms measurement history actually covers, and far past each
    Sonication's own reported end time (e.g. 10.6 s, 27.6 s, 50.1 s).

    Root cause: mr_raw_timeline_time_s passed np.arange(1, n+1) (plain
    1-based sample indices) into _cycles_to_mr() as if they were real
    absolute CPC controller cycle numbers. raw_timeline_time_s itself
    (np.arange(len(timeline[0])) * acquisition_interval_s) carries no real
    per-sample cycle number at all -- whenever a Sonication's actual
    controller_cycle_numbers happened to overlap the small range 1..n,
    np.interp silently produced a finite-looking but physically wrong MR
    time for every sample.
    """
    block = SRC.split('def mr_raw_timeline_time_s', 1)[1].split('\n\n    @property', 1)[0]
    assert 'np.arange(1,n+1' not in block
    assert 'self._cycles_to_mr(' not in block
    assert 'return self.sonication_raw_timeline_time_s + float(self.mr_sonication_start_s or 0.0)' in block


def test_acquisition_times_to_sonication_guards_against_extrapolation():
    """A composite 220/230 kHz Sonication's physical FFT frame domain can
    be a tiny fraction (e.g. 0.17 s) of the 10-ms history domain (several
    seconds) being mapped through the same linear fit. Confirmed against a
    real Brain220 export: fitting over x in [0.00, 0.17] s and applying
    that fit to history values up to ~7 s amplified the mapped range by
    ~53x, out to ~380 s. The fit must not be trusted that far past the
    domain it was learned over."""
    block = SRC.split('def _acquisition_times_to_sonication', 1)[1].split('\n\n    def ', 1)[0]
    assert 'fit_span=float(x[-1]-x[0])' in block
    assert 'arr_span=float(np.nanmax(arr)-np.nanmin(arr))' in block
    assert 'if fit_span > 0 and arr_span <= max(fit_span*5.0, 1.0):' in block
    # The plain-offset fallback must remain reachable when the guard trips.
    assert 'return arr - float(self.sonication_time_zero_offset_s or 0.0)' in block
