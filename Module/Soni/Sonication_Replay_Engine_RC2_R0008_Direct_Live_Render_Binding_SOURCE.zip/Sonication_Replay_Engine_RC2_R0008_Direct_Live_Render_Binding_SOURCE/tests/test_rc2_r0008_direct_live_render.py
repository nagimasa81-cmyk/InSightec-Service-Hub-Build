from pathlib import Path


def _source():
    return Path("src/ui/main_window.py").read_text(encoding="utf-8")


def test_navigation_has_direct_final_render():
    source = _source()
    block = source[source.index("def set_frame"):source.index("def _render_replay_selection")]
    assert "self._render_replay_selection(after)" in block
    assert "self.replay_context.refresh()" in block


def test_thumbnail_has_immediate_payload_render():
    source = _source()
    block = source[source.index("def _activate_image_payload"):source.index("def _activate_replay_mode_for_navigation")]
    assert "self.overlay.set_overlay(array, None" in block
    assert "self.overlay.set_overlay(mag, array" in block
    assert "self.set_frame(replay_index, display_mode=mode)" in block


def test_runtime_label_exposes_actual_render_indices():
    source = _source()
    assert "Render {self._render_serial}" in source
    assert "snapshot.magnitude_index" in source
    assert "snapshot.temperature_index" in source
