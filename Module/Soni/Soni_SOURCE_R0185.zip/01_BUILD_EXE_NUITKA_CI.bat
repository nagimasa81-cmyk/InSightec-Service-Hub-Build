@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PYTHON_EXE=python"
%PYTHON_EXE% -c "import sys; assert sys.version_info[:2] == (3,13)" || exit /b 1
%PYTHON_EXE% -m pip install --upgrade pip setuptools wheel || exit /b 1
%PYTHON_EXE% -m pip install -r requirements.txt nuitka ordered-set || exit /b 1
%PYTHON_EXE% verify_source.py || exit /b 1
%PYTHON_EXE% -m compileall -q main.py src tools || exit /b 1
if exist dist rmdir /s /q dist
%PYTHON_EXE% -m nuitka --standalone --enable-plugin=pyside6 --windows-console-mode=disable --assume-yes-for-downloads --output-dir=dist --output-filename=Sonication_Replay_Engine.exe --windows-product-name="Sonication Replay Engine" --windows-file-description="Sonication Replay Engine RC7.10-R0185" --windows-file-version=7.10.0.179 --windows-product-version=7.10.0.179 main.py
if errorlevel 1 exit /b 1
for /d %%D in (dist\*.dist) do set "DISTDIR=%%D"
if not defined DISTDIR exit /b 1
if not exist "%DISTDIR%\Sonication_Replay_Engine.exe" exit /b 1
exit /b 0
