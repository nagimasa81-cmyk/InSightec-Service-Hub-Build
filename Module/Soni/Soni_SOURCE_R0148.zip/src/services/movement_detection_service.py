from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import math
import re
import xml.etree.ElementTree as ET


@dataclass(frozen=True, slots=True)
class MovementDetectionRecord:
    sonication_number: int
    rl: float
    si: float
    ap: float
    source: Path

    @property
    def display(self) -> str:
        return format_movement_detection(self.rl, self.si, self.ap)


def _axis_token(value: float, positive: str, negative: str) -> str:
    # The workstation presentation uses direction letters plus magnitude.
    # Keep one decimal place, including 0.0, for stable Summary alignment.
    direction = positive if value >= 0.0 else negative
    return f"{direction}{abs(float(value)):.1f}"


def format_movement_detection(rl: float, si: float, ap: float) -> str:
    """Format three anatomical displacement components.

    Display order follows the workstation Summary convention requested for Soni:
    RL, SI, AP -> ``R0.1 S0.2 A0.0``. Positive directions are R/S/A and
    negative directions are L/I/P. Zero uses the positive-side letter.
    """
    return " ".join((
        _axis_token(rl, "R", "L"),
        _axis_token(si, "S", "I"),
        _axis_token(ap, "A", "P"),
    ))


class MovementDetectionService:
    """Read authoritative three-axis Movement Detection values when exported.

    A scalar ``SpotDoseData.motionvalue`` is *not* enough to reconstruct RL/SI/AP
    and is therefore never split or copied into the three axes.  We accept only
    explicit three-axis evidence associated with a Sonication index.  This keeps
    the Summary fail-closed for exports such as 40108 where ``motionvalue=-1`` and
    the MD reference/current image counts are zero.

    Export revisions have used several names for the same anatomical components,
    so matching is alias-based but value-driven; filename/order based inference is
    intentionally prohibited.
    """

    _ALIASES = {
        "rl": (
            "motionrl", "movementrl", "displacementrl", "mddisplacementrl",
            "mdrl", "rlmotion", "rlmovement", "rlvalue", "motionx",
            "movementx", "displacementx", "mddx", "mdx",
        ),
        "si": (
            "motionsi", "movementsi", "displacementsi", "mddisplacementsi",
            "mdsi", "simotion", "simovement", "sivalue", "motionz",
            "movementz", "displacementz", "mddz", "mdz",
        ),
        "ap": (
            "motionap", "movementap", "displacementap", "mddisplacementap",
            "mdap", "apmotion", "apmovement", "apvalue", "motiony",
            "movementy", "displacementy", "mddy", "mdy",
        ),
    }

    _TEXT_TRIPLE = re.compile(
        r"(?i)\b([RL])\s*([+-]?\d+(?:\.\d+)?)\s*[,;/ ]+"
        r"([SI])\s*([+-]?\d+(?:\.\d+)?)\s*[,;/ ]+"
        r"([AP])\s*([+-]?\d+(?:\.\d+)?)\b"
    )

    @staticmethod
    def _finite(raw) -> float | None:
        try:
            value = float(str(raw).strip())
        except (TypeError, ValueError):
            return None
        return value if math.isfinite(value) else None

    @classmethod
    def _get_axis(cls, attrs: dict[str, str], axis: str) -> float | None:
        for name in cls._ALIASES[axis]:
            if name in attrs:
                return cls._finite(attrs[name])
        return None

    @staticmethod
    def _signed(letter: str, magnitude: float, positive: str) -> float:
        mag = abs(float(magnitude))
        return mag if letter.upper() == positive else -mag

    @classmethod
    def _extract_from_attrs(cls, attrs: dict[str, str]) -> tuple[float, float, float] | None:
        rl = cls._get_axis(attrs, "rl")
        si = cls._get_axis(attrs, "si")
        ap = cls._get_axis(attrs, "ap")
        if rl is not None and si is not None and ap is not None:
            return rl, si, ap

        # Some exports serialize the already-labelled three-axis result into one
        # text attribute. Parse only when all three anatomical direction letters
        # are present; never reinterpret a lone scalar motionvalue.
        for raw in attrs.values():
            m = cls._TEXT_TRIPLE.search(str(raw))
            if not m:
                continue
            rl = cls._signed(m.group(1), float(m.group(2)), "R")
            si = cls._signed(m.group(3), float(m.group(4)), "S")
            ap = cls._signed(m.group(5), float(m.group(6)), "A")
            return rl, si, ap
        return None

    def read_indexed(self, workspace: Path) -> dict[int, MovementDetectionRecord]:
        workspace = Path(workspace)
        # Search XML evidence broadly because the exact table carrying the
        # three-axis result differs by workstation/export revision.  A row is
        # eligible only when it explicitly carries sonicationindex + all axes.
        candidates = sorted(
            (p for p in workspace.rglob("*.xml") if p.is_file()),
            key=lambda p: (len(p.relative_to(workspace).parts), str(p).lower()),
        )
        values: dict[int, list[tuple[tuple[float, float, float], Path]]] = {}
        for path in candidates:
            try:
                root = ET.parse(path).getroot()
            except (ET.ParseError, OSError):
                continue
            for elem in root.iter():
                attrs = {str(k).lower(): str(v) for k, v in elem.attrib.items()}
                if "sonicationindex" not in attrs:
                    continue
                try:
                    number = int(str(attrs["sonicationindex"]).strip())
                except (TypeError, ValueError):
                    continue
                if number <= 0:
                    continue
                triple = self._extract_from_attrs(attrs)
                if triple is None:
                    continue
                values.setdefault(number, []).append((triple, path))

        out: dict[int, MovementDetectionRecord] = {}
        for number, rows in values.items():
            # Duplicate package copies with the same values collapse; conflicting
            # three-axis results fail closed rather than choosing by path/order.
            unique: dict[tuple[float, float, float], Path] = {}
            for triple, path in rows:
                key = tuple(round(float(v), 9) for v in triple)
                unique.setdefault(key, path)
            if len(unique) != 1:
                continue
            (rl, si, ap), source = next(iter(unique.items()))
            out[number] = MovementDetectionRecord(number, rl, si, ap, source)
        return out
