# C0016c Temperature / Acoustic Refinement

- Temperature Trend defaults to 40–60 °C with 2 °C major ticks, 1 °C minor ticks, background temperature bands, and synchronized replay cursor.
- Red Threshold now changes the temperature at which the overlay turns red; it no longer hides all temperatures below the threshold.
- Power and Score values are drawn inside their shared chart.
- Hydrophone channel selection moved to Acoustic Spectrum and supports single, multiple, and all-channel selection.
- Acoustic Spectrum uses 0.20–0.80 MHz and 0–4 Relative Amplitude axes.
- Waterfall renamed to Acoustic Spectrum Over Replay Time and uses relative-amplitude color intensity.
- Fallback voxel changed to 10 mm × 10 mm.

# C0016a
- Initialized Temperature Trend workspace
- Prepared Peak Navigation foundation


## RC1 C0016c ReplayVisibilityFix
- Reset WL/WW per sonication so DQA images do not inherit prior settings.
- Replaced inline hydrophone checkboxes with compact CH popup multi-selection.
- Added colored relative-amplitude waterfall LUT and clearer panel title.
- Fixed Acquisition_Brain segment start detection so Power/Score curves populate.
- Reduced chart header/margin waste.
- Added target-centered 20 mm blue circular ROI.
- Added Temperature Trend mouse-hover Max/Avg/Cursor temperature popup.
