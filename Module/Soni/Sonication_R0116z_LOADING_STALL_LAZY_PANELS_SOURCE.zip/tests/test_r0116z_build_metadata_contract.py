from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]

def test_release_metadata_complete_and_synchronized():
    meta = json.loads((ROOT / "version.json").read_text(encoding="utf-8"))
    constants = (ROOT / "src/common/constants.py").read_text(encoding="utf-8")
    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    contract = json.loads((ROOT / "insightec_build_contract.json").read_text(encoding="utf-8"))
    assert meta["version"] == "RC7.2-R0116z"
    assert meta["commit"] == "R0116z"
    assert version == meta["version"]
    assert 'APP_VERSION = "RC7.2-R0116z"' in constants
    assert 'APP_COMMIT = "R0116z"' in constants
    assert contract["source_version"] == "rc7.2-r0116y"
    assert contract["release_sequence"] == 116

def test_build_scripts_embed_current_release_identity():
    for name in ("01_BUILD_EXE_NUITKA.bat", "01_BUILD_EXE_NUITKA_CI.bat"):
        text = (ROOT / name).read_text(encoding="utf-8")
        assert "RC7.2-R0116z" in text
        assert "7.2.0.116" in text
        assert "RC7.2-R0078" not in text
