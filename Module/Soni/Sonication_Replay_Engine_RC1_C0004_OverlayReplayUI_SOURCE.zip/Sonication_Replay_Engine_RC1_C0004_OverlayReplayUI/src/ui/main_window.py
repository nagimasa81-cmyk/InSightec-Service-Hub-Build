from __future__ import annotations

import logging
from pathlib import Path
import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import QSettings, Qt, QTimer, QSize
from PySide6.QtGui import QAction, QImage, QPixmap, QIcon
from PySide6.QtWidgets import (
    QFileDialog, QGroupBox, QHeaderView, QHBoxLayout, QLabel, QListWidget,
    QListWidgetItem, QMainWindow, QMessageBox, QPushButton, QSlider, QSpinBox,
    QSplitter, QTableWidget, QTableWidgetItem, QTreeWidget, QTreeWidgetItem,
    QVBoxLayout, QWidget, QComboBox
)

from src.common.constants import APP_NAME, APP_VERSION, ORGANIZATION
from src.domain.models import SonicationModel
from src.integration.spectrum_provider import SpectrumMsgAnalyzerAdapter
from src.services.discovery_service import DiscoveryService
from src.services.import_service import ImportService
from src.services.replay_service import ReplayService
from src.ui.image_panel import OverlayPanel

LOG = logging.getLogger(__name__)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} - {APP_VERSION}")
        self.resize(1760, 1050)
        self.setAcceptDrops(True)
        self.settings = QSettings(ORGANIZATION, APP_NAME)
        self.importer = ImportService(); self.discovery = DiscoveryService(); self.replay = ReplayService()
        self.package = None; self.current: SonicationModel | None = None
        self.frame_index = 0; self.delta_trend: list[float] = []; self.spectrum_frames = []
        self.spectrum_provider = SpectrumMsgAnalyzerAdapter()
        self.timer = QTimer(self); self.timer.timeout.connect(self.next_frame)
        self._build_actions(); self._build_ui(); self._restore()

    def _build_actions(self):
        menu = self.menuBar().addMenu("&File")
        oz = QAction("Open ZIP...", self); oz.triggered.connect(self.open_zip); menu.addAction(oz)
        of = QAction("Open Folder...", self); of.triggered.connect(self.open_folder); menu.addAction(of)
        toolbar = self.addToolBar("Main"); toolbar.setObjectName("MainToolbar"); toolbar.setMovable(False)
        toolbar.addAction(oz); toolbar.addAction(of)

    def _build_ui(self):
        self.tree = QTreeWidget(); self.tree.setHeaderLabels(["Sonication / Data", "Count"])
        self.tree.itemSelectionChanged.connect(self.select_sonication)
        left = QGroupBox("Sonications"); ll = QVBoxLayout(left); ll.addWidget(self.tree)

        self.overlay = OverlayPanel("Magnitude + ΔTemperature Overlay")
        self.frame_list = QListWidget(); self.frame_list.setViewMode(QListWidget.ViewMode.IconMode)
        self.frame_list.setIconSize(QSize(116, 116)); self.frame_list.setGridSize(QSize(132, 150))
        self.frame_list.setResizeMode(QListWidget.ResizeMode.Adjust); self.frame_list.setMovement(QListWidget.Movement.Static)
        self.frame_list.currentRowChanged.connect(lambda i: self.set_frame(i) if i >= 0 else None)
        frames_box = QGroupBox("Frame Navigator"); fl = QVBoxLayout(frames_box); fl.addWidget(self.frame_list)

        upper = QSplitter(Qt.Orientation.Horizontal); upper.addWidget(self.overlay); upper.addWidget(frames_box); upper.setSizes([1180, 420])

        self.spectrum_plot = pg.PlotWidget(title="Spectrum")
        self.spectrum_plot.setLabel("left", "Amplitude"); self.spectrum_plot.setLabel("bottom", "Frequency", units="kHz")
        self.spectrum_plot.showGrid(x=True, y=True, alpha=.25)

        self.temperature_plot = pg.PlotWidget(title="Maximum ΔTemperature Trend")
        self.temperature_plot.setLabel("left", "ΔTemperature", units="°C"); self.temperature_plot.setLabel("bottom", "Replay Frame")
        self.temperature_plot.showGrid(x=True, y=True, alpha=.25)
        self.temperature_curve = self.temperature_plot.plot()
        self.temperature_cursor = pg.InfiniteLine(angle=90, movable=False); self.temperature_plot.addItem(self.temperature_cursor)
        self.temperature_plot.scene().sigMouseClicked.connect(self._temperature_plot_clicked)

        first=QPushButton("|<"); prev=QPushButton("<"); self.play=QPushButton("Play"); nxt=QPushButton(">"); last=QPushButton(">|")
        first.clicked.connect(lambda:self.set_frame(0)); prev.clicked.connect(self.previous_frame); self.play.clicked.connect(self.toggle_play)
        nxt.clicked.connect(self.next_frame); last.clicked.connect(lambda:self.set_frame(max(0,self.current.replay_frame_count-1) if self.current else 0))
        self.speed=QSpinBox(); self.speed.setRange(1,20); self.speed.setValue(5); self.speed.setSuffix(" fps"); self.speed.valueChanged.connect(self.speed_changed)
        self.opacity=QSlider(Qt.Orientation.Horizontal); self.opacity.setRange(0,100); self.opacity.setValue(55); self.opacity.setMaximumWidth(180)
        self.opacity.valueChanged.connect(lambda _: self.set_frame(self.frame_index))
        self.range_combo=QComboBox(); self.range_combo.addItems(["Auto","0–5 °C","0–10 °C","0–20 °C"]); self.range_combo.currentIndexChanged.connect(lambda _:self.set_frame(self.frame_index))
        self.frame_label=QLabel("Frame -/-")
        controls=QHBoxLayout()
        for w in (first,prev,self.play,nxt,last,self.frame_label,QLabel("Speed"),self.speed,QLabel("Overlay opacity"),self.opacity,QLabel("ΔT range"),self.range_combo): controls.addWidget(w)
        self.timeline=QSlider(Qt.Orientation.Horizontal); self.timeline.valueChanged.connect(self.slider_changed)
        timeline_box=QGroupBox("Replay Timeline"); tl=QVBoxLayout(timeline_box); tl.addLayout(controls); tl.addWidget(self.timeline)

        self.metrics=QTableWidget(0,2); self.metrics.setHorizontalHeaderLabels(["Metadata","Value"])
        self.metrics.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch); self.metrics.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.metadata_box=QGroupBox("Metadata"); self.metadata_box.setCheckable(True); self.metadata_box.setChecked(False)
        ml=QVBoxLayout(self.metadata_box); ml.addWidget(self.metrics); self.metadata_box.toggled.connect(self._toggle_metadata)
        self._toggle_metadata(False)

        lower=QSplitter(Qt.Orientation.Vertical); lower.addWidget(self.spectrum_plot); lower.addWidget(self.temperature_plot); lower.setSizes([260,260])
        center=QWidget(); cl=QVBoxLayout(center); cl.addWidget(timeline_box); cl.addWidget(upper,1); cl.addWidget(lower); cl.addWidget(self.metadata_box)
        self.main_split=QSplitter(Qt.Orientation.Horizontal); self.main_split.addWidget(left); self.main_split.addWidget(center); self.main_split.setSizes([300,1450])
        self.setCentralWidget(self.main_split); self.statusBar().showMessage("Ready")

    def _toggle_metadata(self, checked):
        self.metrics.setVisible(checked); self.metadata_box.setMaximumHeight(260 if checked else 42)

    def open_zip(self):
        f,_=QFileDialog.getOpenFileName(self,"Open treatment or Sonication ZIP","","ZIP files (*.zip)")
        if f:self.load(Path(f))
    def open_folder(self):
        f=QFileDialog.getExistingDirectory(self,"Open treatment or Sonication folder")
        if f:self.load(Path(f))

    def load(self, source: Path):
        try:
            workspace=self.importer.open(source); self.package=self.discovery.discover(source,workspace)
        except Exception as exc:
            LOG.exception("Import failed"); QMessageBox.critical(self,APP_NAME,str(exc)); return
        self.spectrum_provider=SpectrumMsgAnalyzerAdapter(self.package.main_frequency_hz); self.tree.clear()
        if not self.package.sonications:
            QMessageBox.information(self,APP_NAME,"No compatible Sonication data found."); return
        freq=self.package.main_frequency_hz/1000.0
        fi=QTreeWidgetItem(["Main Frequency",f"{freq:.1f} kHz ({'Xd INI' if self.package.main_frequency_source else 'Default'})"]); self.tree.addTopLevelItem(fi)
        for son in self.package.sonications:
            item=QTreeWidgetItem([son.name,f"{son.replay_frame_count} replay frames"]); item.setData(0,Qt.ItemDataRole.UserRole,son.name)
            for name,count in (("Temperature RAW",len(son.temperature_frames)),("Magnitude RAW",len(son.magnitude_frames)),("SpectrumMsg",len(son.spectrum_files)),("ACT",len(son.act_files))): item.addChild(QTreeWidgetItem([name,str(count)]))
            item.setExpanded(True); self.tree.addTopLevelItem(item)
        self.tree.setCurrentItem(self.tree.topLevelItem(1 if self.tree.topLevelItemCount()>1 else 0)); self.statusBar().showMessage(f"Loaded {len(self.package.sonications)} sonication(s)")

    def select_sonication(self):
        items=self.tree.selectedItems()
        if not items or items[0].parent() is not None:return
        name=items[0].data(0,Qt.ItemDataRole.UserRole)
        if not name:return
        self.current=next((s for s in self.package.sonications if s.name==name),None)
        if not self.current:return
        self.spectrum_frames=self.spectrum_provider.load(self.current.spectrum_files)
        self._build_temperature_trend(); self._build_frame_navigator(); self.set_frame(0)

    def _build_temperature_trend(self):
        self.delta_trend=[]
        if not self.current:return
        for i in range(self.current.replay_frame_count):
            try:v=self.replay.frame(self.current,i).maximum_delta_temperature
            except Exception:v=np.nan
            self.delta_trend.append(v if v is not None else np.nan)
        self.temperature_curve.setData(np.arange(len(self.delta_trend)),np.asarray(self.delta_trend,float))

    def _build_frame_navigator(self):
        self.frame_list.blockSignals(True); self.frame_list.clear()
        if not self.current:self.frame_list.blockSignals(False);return
        for i in range(self.current.replay_frame_count):
            try:
                d=self.replay.frame(self.current,i); src=d.temperature_delta if d.temperature_delta is not None else d.magnitude
                icon=self._array_icon(src); text=f"Frame {i+1}\nΔT {d.maximum_delta_temperature:.2f} °C" if d.maximum_delta_temperature is not None else f"Frame {i+1}"
            except Exception:
                icon=QIcon(); text=f"Frame {i+1}"
            it=QListWidgetItem(icon,text); it.setTextAlignment(Qt.AlignmentFlag.AlignHCenter); self.frame_list.addItem(it)
        self.frame_list.blockSignals(False)

    @staticmethod
    def _array_icon(arr):
        if arr is None:return QIcon()
        a=np.nan_to_num(np.asarray(arr,float)); lo,hi=np.percentile(a,[2,98]) if a.size else (0,1)
        if hi<=lo:hi=lo+1
        u=np.clip((a-lo)/(hi-lo)*255,0,255).astype(np.uint8)
        rgb=np.stack([u,u,u],axis=2); h,w=rgb.shape[:2]
        q=QImage(rgb.data,w,h,3*w,QImage.Format.Format_RGB888).copy()
        return QIcon(QPixmap.fromImage(q).scaled(116,116,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))

    def _delta_levels(self, delta):
        idx=self.range_combo.currentIndex()
        if idx==1:return (0.0,5.0)
        if idx==2:return (0.0,10.0)
        if idx==3:return (0.0,20.0)
        finite=delta[np.isfinite(delta)] if delta is not None else np.array([])
        return (0.0,max(1.0,float(np.percentile(finite,99)))) if finite.size else None

    def set_frame(self,index:int):
        if not self.current:return
        try:d=self.replay.frame(self.current,index)
        except Exception as exc: QMessageBox.warning(self,APP_NAME,f"Unable to decode frame\n{exc}"); return
        self.frame_index=d.replay_index; count=self.current.replay_frame_count
        self.timeline.blockSignals(True); self.timeline.setRange(0,max(0,count-1)); self.timeline.setValue(self.frame_index); self.timeline.blockSignals(False)
        self.frame_list.blockSignals(True); self.frame_list.setCurrentRow(self.frame_index); self.frame_list.blockSignals(False)
        self.frame_label.setText(f"Frame {self.frame_index+1}/{count}"); self.temperature_cursor.setPos(self.frame_index)
        mag_levels=None
        if d.magnitude is not None: mag_levels=(float(np.percentile(d.magnitude,1)),float(np.percentile(d.magnitude,99)))
        lut=pg.colormap.get("CET-L4").getLookupTable(0,1,256)
        hs=(d.hotspot_x,d.hotspot_y) if d.hotspot_x is not None else None
        hst=f"X={d.hotspot_x} Y={d.hotspot_y}\nΔT {d.maximum_delta_temperature:.2f} °C" if d.maximum_delta_temperature is not None else None
        self.overlay.set_overlay(d.magnitude,d.temperature_delta,mag_levels,self._delta_levels(d.temperature_delta),lut,self.opacity.value()/100.0,hs,hst)
        self._update_spectrum(count); self._update_metadata(d,count)

    def _update_spectrum(self,count):
        self.spectrum_plot.clear(); sf=None; status="No SpectrumMsg"
        if self.spectrum_frames:
            si=self.replay.raw.normalize_index(self.frame_index,count,len(self.spectrum_frames)); sf=self.spectrum_frames[si]
            x=np.asarray(sf.frequency,float)/1000.0; y=np.asarray(sf.amplitude,float); self.spectrum_plot.plot(x,y)
            main=self.package.main_frequency_hz/1000.0
            for f,label in ((main,"Main"),(main/2,"Sub"),(main*2,"2nd"),(main*3,"3rd")): self.spectrum_plot.addItem(pg.InfiniteLine(pos=f,angle=90,movable=False,label=label))
            if sf.main_peak_hz is not None:self.spectrum_plot.addItem(pg.InfiniteLine(pos=sf.main_peak_hz/1000.0,angle=90,movable=False,label="Current Peak"))
            status=f"Frame {si+1}/{len(self.spectrum_frames)}; confidence {sf.confidence:.1f}%"
        self._spectrum_status=status; self._spectrum_frame=sf

    def _update_metadata(self,d,count):
        sf=getattr(self,'_spectrum_frame',None)
        rows=[("Sonication",self.current.name),("Replay frame",f"{self.frame_index+1}/{count}"),("Maximum temperature",f"{d.maximum_temperature:.2f} °C" if d.maximum_temperature is not None else "Unavailable"),("Maximum ΔTemperature",f"{d.maximum_delta_temperature:.2f} °C" if d.maximum_delta_temperature is not None else "Unavailable"),("Mean ΔTemperature",f"{d.mean_delta_temperature:.2f} °C" if d.mean_delta_temperature is not None else "Unavailable"),("Hotspot",f"X={d.hotspot_x}, Y={d.hotspot_y}" if d.hotspot_x is not None else "Unavailable"),("Main frequency",f"{self.package.main_frequency_hz/1000.0:.1f} kHz"),("Frequency source",self.package.main_frequency_source.name if self.package.main_frequency_source else "Default 650 kHz"),("Spectrum",getattr(self,'_spectrum_status','No SpectrumMsg')),("Spectrum main peak",f"{sf.main_peak_hz/1000.0:.1f} kHz" if sf is not None and sf.main_peak_hz is not None else "Unavailable"),("ACT",f"{len(self.current.act_files)} file(s)")]
        self.metrics.setRowCount(len(rows))
        for r,(k,v) in enumerate(rows): self.metrics.setItem(r,0,QTableWidgetItem(k)); self.metrics.setItem(r,1,QTableWidgetItem(v))

    def _temperature_plot_clicked(self,event):
        if not self.current:return
        p=self.temperature_plot.plotItem.vb.mapSceneToView(event.scenePos()); self.set_frame(int(round(p.x())))
    def slider_changed(self,v):self.set_frame(v)
    def previous_frame(self):self.set_frame(max(0,self.frame_index-1))
    def next_frame(self):
        if not self.current:return
        n=self.frame_index+1
        if n>=self.current.replay_frame_count:n=0 if self.timer.isActive() else self.current.replay_frame_count-1
        self.set_frame(n)
    def toggle_play(self):
        if self.timer.isActive():self.timer.stop();self.play.setText("Play")
        else:self.timer.start(max(20,int(1000/self.speed.value())));self.play.setText("Pause")
    def speed_changed(self,v):
        if self.timer.isActive():self.timer.start(max(20,int(1000/v)))
    def keyPressEvent(self,event):
        if event.key()==Qt.Key.Key_Left:self.previous_frame();return
        if event.key()==Qt.Key.Key_Right:self.next_frame();return
        super().keyPressEvent(event)
    def wheelEvent(self,event):
        if self.current:self.set_frame(self.frame_index+(1 if event.angleDelta().y()<0 else -1));event.accept();return
        super().wheelEvent(event)
    def dragEnterEvent(self,event):
        if any(u.isLocalFile() for u in event.mimeData().urls()):event.acceptProposedAction()
    def dropEvent(self,event):
        for u in event.mimeData().urls():
            if u.isLocalFile():
                p=Path(u.toLocalFile())
                if p.is_dir() or p.suffix.lower()=='.zip':self.load(p);event.acceptProposedAction();break
    def _restore(self):
        try:
            g=self.settings.value("geometry")
            if g:self.restoreGeometry(g)
        except Exception:pass
    def closeEvent(self,event):
        self.settings.setValue("geometry",self.saveGeometry()); super().closeEvent(event)
