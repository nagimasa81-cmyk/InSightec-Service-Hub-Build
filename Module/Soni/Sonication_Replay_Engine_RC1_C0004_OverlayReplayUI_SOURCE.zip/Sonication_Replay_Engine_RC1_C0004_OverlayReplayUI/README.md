# Sonication Replay Engine RC1 C0004

Overlay Replay UI for synchronized review of Magnitude, Frame0-referenced ΔTemperature, SpectrumMsg and temperature trend.

## Run
Use `build/03_RUN_DEBUG.bat`.

## Build
Use `build/01_BUILD_EXE.bat` for the standard Nuitka build or `build/02_BUILD_DEBUG.bat` for a console build.
