# Changelog

## RC1 C0004 OverlayReplayUI
- Rebuilt replay workspace around a large Magnitude + ΔTemperature overlay.
- Temperature display now uses Frame0-referenced ΔT.
- Added frame navigator thumbnails and synchronized click/keyboard/wheel navigation.
- Added synchronized spectrum and maximum ΔT trend with graph-click seeking.
- Added collapsible metadata panel.
- Added selectable ΔT display range and overlay opacity.
- Added CPCFiles/Site/ini Xd frequency usage with 650 kHz fallback.
- Updated title/version and retained BAT-based GitHub build workflow.
