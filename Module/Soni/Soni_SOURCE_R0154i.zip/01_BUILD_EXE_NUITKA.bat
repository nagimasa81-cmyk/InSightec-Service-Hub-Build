@echo off
setlocal EnableExtensions
cd /d "%~dp0"

rem R0116zb: Defender-conservative standalone build profile.
rem IMPORTANT: build a normal standalone directory. Do NOT use --onefile.
if not exist ".venv\Scripts\python.exe" py -3.13 -m venv .venv
if errorlevel 1 goto :error
call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto :error
python -m pip install -r requirements.txt nuitka ordered-set
if errorlevel 1 goto :error
call 00_VERIFY_SOURCE.bat
if errorlevel 1 goto :error
python -m compileall -q main.py src tools
if errorlevel 1 goto :error

if exist dist rmdir /s /q dist
if exist release rmdir /s /q release
mkdir release

python -m nuitka ^
  --standalone ^
  --enable-plugin=pyside6 ^
  --windows-console-mode=disable ^
  --assume-yes-for-downloads ^
  --output-dir=dist ^
  --output-filename=Sonication_Replay_Engine.exe ^
  --windows-product-name="Sonication Replay Engine" ^
  --windows-file-description="Sonication Replay Engine RC7.10-R0154i" ^
  --windows-file-version=7.10.0.154 ^
  --windows-product-version=7.10.0.154 ^
  main.py
if errorlevel 1 goto :error

for /d %%D in (dist\*.dist) do set "DISTDIR=%%D"
if not defined DISTDIR goto :error
if not exist "%DISTDIR%\Sonication_Replay_Engine.exe" goto :error

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop'; $src='%DISTDIR%'; $out='release\Sonication_R0137_Windows_Standalone.zip'; Compress-Archive -Path ($src+'\*') -DestinationPath $out -Force; Get-FileHash -Algorithm SHA256 $out | ForEach-Object { $_.Hash + '  ' + (Split-Path -Leaf $_.Path) } | Set-Content -Encoding ascii ($out+'.sha256')"
if errorlevel 1 goto :error

echo.
echo R0137 standalone build completed.
echo Run the EXE from the extracted folder; keep all DLLs beside it.
echo release\Sonication_R0137_Windows_Standalone.zip
exit /b 0

:error
echo Build failed.
exit /b 1
