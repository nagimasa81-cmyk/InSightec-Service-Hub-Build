from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import xml.etree.ElementTree as ET

from src.parsers.ado_rowset import parse_ado_rowset


@dataclass(slots=True)
class SonicationTiming:
    planned_duration_s: float | None = None
    actual_duration_s: float | None = None
    planned_power_w: float | None = None
    actual_power_w: float | None = None
    planned_energy_j: float | None = None
    actual_energy_j: float | None = None
    frequency_hz: float | None = None
    source: Path | None = None

    @property
    def best_duration_s(self) -> float | None:
        if self.actual_duration_s is not None and self.actual_duration_s > 0:
            return self.actual_duration_s
        if self.planned_duration_s is not None and self.planned_duration_s > 0:
            return self.planned_duration_s
        return None


class SonicationTimingService:
    """Resolve per-sonication duration from the workstation summary XML.

    The summary rows are stored in sonication order.  Using the measured
    ``actualduration`` prevents the previous fixed 4-second frame spacing from
    stretching a 3-second cavitation test into a roughly 40-second replay.
    """

    SUMMARY_NAMES = ("SonicationSummary.xml", "sonicationsummary.xml")

    def read_all(self, workspace: Path) -> list[SonicationTiming]:
        summary = self._find_summary(workspace)
        if summary is None:
            return []
        try:
            rows = parse_ado_rowset(summary)
        except (ET.ParseError, OSError, ValueError):
            return []
        result: list[SonicationTiming] = []
        for row in rows:
            if "actualduration" not in row and "duration" not in row:
                continue
            result.append(SonicationTiming(
                planned_duration_s=self._number(self._first(row, "duration", "targetduration", "plannedduration")),
                actual_duration_s=self._number(self._first(row, "actualduration", "deliveredduration", "measuredduration")),
                planned_power_w=self._number(self._first(row, "power", "targetpower", "plannedpower")),
                actual_power_w=self._number(self._first(row, "actualpower", "deliveredpower", "averagepower", "measuredpower")),
                planned_energy_j=self._number(self._first(row, "energy", "targetenergy", "plannedenergy")),
                actual_energy_j=self._number(self._first(row, "actualenergy", "deliveredenergy", "measuredenergy", "totalenergy")),
                frequency_hz=self._frequency_hz(self._first(row, "frequency", "sonicationfrequency", "transducerfrequency")),
                source=summary,
            ))
        return result

    def _find_summary(self, workspace: Path) -> Path | None:
        direct = workspace / "SonicationSummary.xml"
        if direct.exists():
            return direct
        candidates = [p for p in workspace.rglob("*.xml") if p.name.lower() == "sonicationsummary.xml"]
        return sorted(candidates, key=lambda p: len(p.parts))[0] if candidates else None

    @staticmethod
    def _first(row: dict, *keys):
        for key in keys:
            value = row.get(key)
            if value not in (None, ""):
                return value
        return None

    @classmethod
    def _frequency_hz(cls, value) -> float | None:
        number = cls._number(value)
        if number is None or number <= 0:
            return None
        if number < 10:
            return number * 1_000_000.0
        if number < 10_000:
            return number * 1_000.0
        return number

    @staticmethod
    def _number(value) -> float | None:
        if value is None:
            return None
        try:
            return float(value.strip()) if isinstance(value, str) else float(value)
        except (TypeError, ValueError):
            return None
