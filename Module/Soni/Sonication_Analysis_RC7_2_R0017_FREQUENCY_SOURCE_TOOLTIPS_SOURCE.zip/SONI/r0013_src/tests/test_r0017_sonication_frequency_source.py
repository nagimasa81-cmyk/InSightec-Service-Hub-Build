from pathlib import Path

from src.services.sonication_timing_service import SonicationTimingService


def test_frequency_unit_normalisation():
    service = SonicationTimingService()
    assert service._frequency_hz("630000") == 630000.0
    assert service._frequency_hz("630") == 630000.0
    assert service._frequency_hz("0.630") == 630000.0


def test_discovery_preserves_summary_frequency_before_fallback():
    text = Path("src/services/discovery_service.py").read_text(encoding="utf-8")
    assign = text.index("if timing.frequency_hz is not None:")
    guard = text.index("if model.main_frequency_hz is not None:")
    local = text.index("local = self.sonication_frequency.read(model.folder)")
    assert assign < guard < local


def test_hover_only_provenance_ui():
    text = Path("src/ui/main_window.py").read_text(encoding="utf-8")
    assert "setToolTip(tooltip)" in text
    assert "Source type:" in text
    assert "Source file:" in text
    assert "Fallback used:" in text
    assert 'summary_keys = (' in text
    for key in ("Target Energy", "Actual Energy", "Target Power", "Actual Power", "Target Duration", "Actual Duration", "Frequency"):
        assert f'"{key}"' in text


def test_version_is_r0017():
    assert Path("VERSION").read_text(encoding="utf-8").strip() == "RC2-R0017"
