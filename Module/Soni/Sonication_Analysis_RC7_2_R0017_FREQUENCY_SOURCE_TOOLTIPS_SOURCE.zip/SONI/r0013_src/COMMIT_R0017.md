# RC2-R0017 — Sonication Frequency Source Tooltips

- Uses the per-sonication `SonicationSummary.xml` `frequency` field as the authoritative sonication frequency.
- Prevents ACT or package defaults from overwriting a valid per-sonication frequency.
- Displays target and actual Energy, Power, and Duration separately.
- Keeps source details hidden during normal use and shows provenance only on mouse hover.
- Tooltip includes source type, field, raw value/unit, source file, source record, and fallback state.
- Frequency is independent of MRI manufacturer and is shown in MHz after conversion from the raw Sonication value.
