
## RC7.10-R0154n
- Deep Brain220 export binding: exact variable-record SpectrumMsg structure is recognized by the common structure inspector.
- Exact SpectrumMsg record-count and embedded-time bridge to PowerGraph / actualsonicduration.
- Workstation StartSonicate counter fallback recovers Brain220 power/duration/frequency/steering and multi-target RAS geometry when Sonication_Brain text is absent.
- DQA excludes structurally proven multi-target voxel Sonications from single-focus centre judgement.
- Preserves unresolved 20-byte history tag semantics without guessing a ninth receiver.
# RC7.10-R0154m

- Deep ancestry-regression audit repaired the ZIP-drop Summary scheduled-preload race and the lost R0137 authoritative retry.
- DQA detail errors now terminate visibly instead of leaving `Analyzing…`.
- Brain220 Spectrum legacy decoding is family-aware and cannot silently bypass a valid vendor frame header through the global 8-record grouper.

## RC7.10-R0154i
- DQA focus alignment now validates that SonicationSummary focalRAS and DQA phantom MriImageParams geometry share the same exported coordinate frame before subtracting them. Coordinate-frame mismatches fail closed as N/A and cannot create false 100+ mm DQA alerts.
- Brain220 Sonication switching clears stale Spectrum data immediately; a selected 220-kHz Sonication can no longer show the preceding 650-kHz trace while its own stream is loading.
- Spectrum display range is family/data aware, including the Brain220 subharmonic region instead of forcing 0.20–0.80 MHz.
- SpectrumMsg embedded graph axes that exclude the actual Sonication main frequency are rejected and rebuilt from Acquisition.ini / the family-aware presentation fallback without changing stored amplitudes.

## RC7.10-R0154h
- CPC Spectrum decode is single-owner: SpectrumPreloadWorker alone owns authoritative CPC binding/decode; selected Replay can no longer stall at 74% waiting on a duplicate CPC read.
- Brain220 DQA non-temperature/T2*-like float32 RAW now fails closed as Temperature Unavailable instead of producing impossible temperatures.
- DQA center-alignment thresholds exclude electronic-steering shots and repeated target-voxel DQA targets with an explicit N/A reason.
- Sonication Elements recovers 1024-channel Umbrella geometry from serial-specific XdGeometry_####.ini when SkullMeasures geometry is absent; 0000 templates remain excluded and geometry is background-owned/cache-only in the GUI.
- Explained amplitude=0 remains gray; unexplained amplitude=0 remains black across Tile/Umbrella/Phase.

## RC7.10-R0154g
- DQA reference-series alignment: DQA-Axial/DQA-Sagittal geometry + per-Sonication focalRAS offsets; removes fixed S1/S2/S3 assumption.
- CPC-less DQA bypasses CPC binding and falls back directly to SpectrumMsg.
- amplitude=0 visuals: explained=gray, unexplained=black.

## Brain 220 / Brain 650 acoustic-family support

- Added evidence-first acoustic system classification. Actual SonicationSummary frequency is primary, followed by TransducerInfo.transtype and serial-specific Xd_####.ini evidence.
- Brain 220 family supports the observed 210-260 kHz operating band; Brain 650 family supports the observed 620-700 kHz band. The gap remains invalid to prevent unrelated frequencies being accepted.
- Package main frequency now follows the median actual SonicationSummary frequency when available.
- Export Status and diagnostics expose the acoustic family, actual frequency, transducer type, evidence and conflicts.
- Spectrum presentation honors Acquisition.ini f1ForGraph/f2ForGraph; low-frequency fallback is family-aware.
- Verified against real DQA exports: Tx41/230 kHz/serial XD 6314 and Tx42/670 kHz/serial XD 7491.
- DQA focus-alignment behavior from R0154f is retained for Brain220 DQA exports.

# RC7.10-R0154e

- Sonication Summary ZIP-drop behavior is now tab-independent: CPC/cavitation detail waits for the canonical initial Replay/Spectrum binding instead of racing it when Summary is visible during import.
- Source switches invalidate/cancel old Summary workers so stale callbacks cannot publish into a replacement study.
- Added metadata-only **Export Import Diagnostics ZIP** for fresh-start Export discovery/CPC-binding failures that are too large to share directly.
- Diagnostics lazily binds to the exact current ReplayPackage and is cleared on source switch.
- No raw MR/Spectrum payloads or log text are included in the diagnostic ZIP.

# R0154e
- Unified ZIP-drop lifecycle so the active tab cannot change import semantics.
- Sonication Summary detail waits for the canonical selected-Replay/Spectrum CPC binding; fast exported values still appear immediately.
- Summary resume is event-driven from worker completion; no polling loop.
- Source switching now invalidates/cancels old Summary detail and thermometry workers so a previous Export cannot publish rows into a newly loaded Export.
- Preserves R0154d Elements layout, R0154c focus/movement UI, R0154b amplitude-zero warnings, and R0154a CPC wall-clock timing.

## RC7.10-R0154d
- Rebalanced Sonication Elements layout on laptop displays: the right control stack now scrolls independently and no longer forces the umbrella viewport to collapse.
- Keeps a useful minimum umbrella viewport while the element table is open; initial table share reduced to about 25% and remains user-resizable.
- Repaints the umbrella after splitter geometry settles without resetting yaw, pitch, projection, or user zoom.

# RC7.10-R0154b

- Sonication Elements: report unexplained zero-amplitude channels separately from defect/disabled/masked-off evidence.
- Detect both ACT amplitude=0 and decoded measured amplitude=0, while excluding explicit INI disabled/disconnected/defect and SkullHeating OffReason channels.
- Added dedicated warning count/list/filter and map/selection indicators.

## RC7.10-R0154a
- Triple-check hardening after R0154 CPC wall-clock timing change.
- Fix repository ordering so exact controller cycle timestamps are anchored directly on canonical MR Sonication start before subviews consume them.
- Clear stale controller-cycle maps on failed cached replay rebinds.
- Route Cavitation Intelligence controller traces and Spectrum event fallback through the shared exact cycle-to-MR mapper; remove local cycle*10ms re-computation.
- Audit duplicate definitions, marker redraw lifecycle, async signal patterns and unbounded loops.

## RC7.10-R0154
- Fix CPC timeline compression by mapping Acquisition_Brain `Cycle N Done` timestamps instead of assuming every controller cycle is exactly 10 ms.
- Apply the exact wall-clock cycle map to FFT snapshots, measurement history and cavitation/control timelines.
- Keep fixed AcquireInterval mapping only as a fail-safe for legacy logs without timestamped cycles.

# RC7.10-R0152

- Sonication Elements now shows authoritative steered target separately from phase-derived focus.

# RC7.10-R0151a

- Restored R0150a logical Spectrum/FFT locator handling in AcousticControlService.find_log while preserving all R0151 fixes.

## RC7.10-R0151

- Fixed Sonication Elements snapshot/list selection: the selection callback no longer aborts on an undefined `payload`; all map, steering, channel-state, and selected-element views now finish refreshing from the published evidence cache.
- Fixed intermittent Sonication-end marker drift: Workstation acoustic power windows are collected from all WS logs and selected by SonicationSummary clock, never by Acquisition_Brain session ordinal.
- When exact MRServer scan bounds are unavailable, the end marker now uses exact WS power-on -> Post-sonication duration when available; SonicationSummary actualduration is fallback only.


## RC7.10-R0150
- Movement Detection primary evidence: treatment-day WS `FinalMovementVector` (RAS).
- Bind each measured vector to the next Sonication by `SonicationSummary.sontime` within 90 s; unmeasured Sonications remain gaps.
- Summary cell format remains RL/SI/AP (`R0.1 S0.2 A0.0`).
- Added dedicated **Movement Detection graph** button with RL / SI / AP series.
- Preserved R0149 per-Sonication electronic steering binding.
## RC7.10-R0149
- Bind Movement Detection to researchparameters correctshift XYZ and bind electronic steering per Sonication from the treatment Sonication_Brain log.

- R0148: Movement Detection in Sonication Summary is now directional RL/SI/AP text (for example R0.1 S0.2 A0.0); scalar motionvalue is no longer presented as the movement result.
# R0147
- Cavitation Intelligence vertical allocation no longer reserves a viewport-sized minimum blank region; lower plots/tables stay reachable while passive scrolling remains available.
- Sonication Summary now shows exported Movement Detection values from SpotDoseData.xml when actually measured; -1/unavailable values remain blank.

# R0144
- Added application-wide laptop-safe top-level window fitting for all QMainWindow/QDialog routes.
- Spectrum Dump Analyzer now always retains a vertical scroll escape path; collapsed/detail transitions can no longer disable it.
- Native Windows frame, taskbar reserve, DPI rounding and delayed sizeHint changes are handled by repeated post-show fitting.

## RC7.10-R0143

- Select the treatment-specific `Acquisition_Brain` log using `SonicationSummary.sontime` / log timestamp instead of largest-file size.
- Unify Cavitation Control Timeline and vendor reproduction on the same treatment-aware Acquisition log selector.
- Treat CPC candidates independently bound to the selected Acquisition sessions as the authoritative treatment block before considering historical unbound CPC dumps.
- Real-data validation: case 40108 contains 27 CPC Spectrum dumps, but only the final 5 belong to the current treatment; all 5 bind to the 18:27 Acquisition log with <=0.935 s end-clock error and decode successfully.

## RC7.10-R0142
- Unified generic `Got StartSpectrumMeasurement` handling across AcousticControl and Cavitation Control parsing.
- Restores Acquisition-session construction used by authoritative CPC mapping and Cavitation Summary on affected workstation exports.
- Added exact regression coverage for CPC clock/session binding without unsafe latest-N guessing.

# R0140

- Reconstructed ReplayPackage from canonical numbered Sonication evidence instead of physical folder count.
- Added `sonication_number` first-class identity and fixed positional Summary/PowerGraph/MR/CPC binding.
- Preserved Summary/Spectrum-defined Sonications even when a physical `SonicationN` folder is missing.
- Merged duplicate Sonication folders created by nested ZIP expansion.
- Added folder/nested-ZIP import parity through an isolated overlay workspace.
- Extended import completeness audit with logical identity and duplicate-folder checks.
- Full non-GUI regression: 893 passed, 1 skipped; verify_source PASS.

# R0136
- Unified loaded-Export Spectrum/Power/control evidence under one study-scoped repository owner.
- Partial CPC inventory now escalates to recursive discovery when Sonication coverage is incomplete.
- Removed Analyzer-local fallback after preload failure; loaded Export cannot silently switch to a smaller CPC universe.
- Selected Power/Score uses the same authoritative Acquisition session as CPC/control evidence.
- Fixed repeated Power-chart refresh subtracting irradiation start multiple times; canonical acoustic time is never mutated by painting.
- Updated regression contracts so tests protect the current architecture instead of requiring ancestor RC7.2/fallback behavior.


## RC7.9-R0135
- Fixed CPC Spectrum preload failure caused by assigning `sonication_index` to a slotted replay without a declared field.
- Fixed wrapped-export Acquisition session fallback so treatment Sonications bind to the final treatment sessions, not early DQA/calibration sessions.
- Hardened Summary/Treatment Outcome control-session selection to use authoritative CPC candidate mapping even when Spectrum decode is unavailable.
- Added recursive package-root Acquisition_Brain discovery for wrapped exports.
- Preserved exact Spectrum candidate mapping confidence/evidence on decoded replay objects.
- Real-data validation on `17-00-24_ANx(5).zip`: all 8 Sonications decode and bind to Acquisition sessions 8-15; Sonication 5 = CAVITATION HALT ×1 / control responses ×2; Sonication 6 = CAVITATION HALT ×1 / control responses ×25.
## RC7.9-R0134
- Hardened async Spectrum/Main-tab publication against blank tabs after equivalent replay-object handoff.
- Unified secondary Spectrum cache ownership on stable semantic replay identity.
- Visible heavy main tab is re-materialized after selected-data and Spectrum-preload completion.

## R0133
- Corrected main-image anatomical annotation screen mapping using real 17-00-24_ANx MriImageParams data: exported COL maps to screen X and ROW maps to screen Y; image pixels remain unchanged.
- Frequency-direction hat now uses preserved acquisition ROW/COL directly (COL=horizontal, ROW=vertical), eliminating the inherited 90-degree axis error.
- Moved left/right anatomical labels away from the vertical center to avoid the physical ruler.

## R0132

- Triple-check hardening for R0131 X-axis range zoom.
- Applied range-zoom/reset interaction to dynamically-created selected-range FFT result charts.
- Excluded hidden-axis image/map PlotWidgets from generic chart reset handling.
- Removed generated __pycache__/pyc files from SOURCE and retired stale RC7.2 pyproject identity text.
- Preserved R0130 Band0 0.311–0.411 MHz, frequency-direction hat, R0129 layout fixes, and FFT range selection.

## R0131
- Added common horizontal-axis range zoom: left-drag directly on the bottom X axis selects the interval and zooms X only while preserving Y.
- Added left-button double-click on chart viewports to reset to full data bounds.
- Preserved ordinary chart-area pan/wheel interaction and the existing Raw A/D FFT range-selection mode; generic range zoom owns only the bottom axis.
- Applied the interaction to main Sonication charts and Spectrum Dump Analyzer plots, including dynamically rebuilt raw plots.

## R0116zzg11
- Build identity and exact-cache freshness hardening; carries R0116zzg9 functional fixes.

## RC7.2-R0116zzg8
- Cavitation Summary now derives Power Decrease/Safety status from the exact CPC-bound Acquisition_Brain session used by the shared Spectrum replay.
- Spectrum Dump Analyzer Sonication switching now reuses/awaits the shared SpectrumEvidenceRepository instead of starting an independent duplicate decode.
- Fixes false No Cavitation rows and repeated blank/84% Spectrum handoff stalls on Sonication changes.

## RC7.2-R0116zzg7
- Restored Cavitation Status/Severity to the authoritative Power Decrease/Safety event gate. Vendor Rule Trigger remains supporting evidence only.
- Preserved same-study Spectrum replay cache during Sonication retargeting and reused repository-decoded selected-Sonication replay when opening Spectrum Dump Analyzer.
- Aligned CI probable-event selection to the same Decrease/Safety-only contract.

## RC7.2-R0116zzg6
- Fixed blank Replay/CI image and delayed chart publication after Sonication Summary navigation; hardened Spectrum 72% handoff.

## R0116zzy — Minimal 1 mm physical ruler overlay

- Finalized the MR/Thermal physical ruler as a screen-fixed, vertically centered right-edge overlay.
- Removed ruler background, numeric labels, and helper text.
- Uses pale cyan only, with a 5 mm physical span and 1 mm interval ticks.
- Tick direction is inward/left from the right-side spine.
- Zoom changes physical on-screen length using pixel spacing; ruler position remains at the vertical center.

## R0116zzx — Visual / Cavitation / Recomposition consistency

See `COMMIT_R0116zzx.md` and `REGRESSION_R0116zzx.md`.

## RC7.2-R0116zzu

- Fix Load images OFF→ON freeze after Sonication change by making essential image loading a single-owner, cycle-scoped state machine.
- Never overlap two Treatment MR/Thermal RAW readers; a new request waits asynchronously for the prior QThread to exit.
- Keep the previous worker/thread owned until `thread.finished`; do not discard a still-running QThread reference.
- Coalesce duplicate navigator requests from Sonication staged loading and the Load images checkbox.
- Invalidate delayed callbacks on OFF, Sonication change, and a new explicit ON cycle.
- Show `Finishing previous image read…` rather than leaving progress at `Preparing image workers… 1%` while a previous bounded RAW read retires.
- Preserve R0116zzt registration, thumbnail, summary, cross-view sync, Probable Location and Spectrum Analyzer fixes.

## RC7.2-R0087
- Fixed Power % / Score timeline using exported PowerGraph and measured Acquisition pre-roll alignment.

# R0081 — Cavitation Root Cause Analysis
- Added evidence-weighted per-Sonication root-cause ranking.
- Integrated control thresholds, CPC Band0–3 escalation, acoustic drive, thermometry history, RCV concentration, previous-Sonication history and MR correlation.
- Added RCA evidence/confidence/improvement table in Cavitation Intelligence.
- Missing evidence is never inferred; normal Increase rules are explicitly excluded from cavitation detection.

## R0054
- Cavitation Intelligence: event-click probable-location synchronization.
- MR signal-loss viewer: WW/WL, Auto, pan/zoom and Fit.
- Added evidence-first Sonication log receiver phase/channel parser and table.
- Registration overlay now prefers patient/world geometry and suppresses misleading geometry-free overlays.
- Cavitation chart legends use reserved non-overlapping header area.

## RC7.2-R0053
- Added first-class Replay Cavitation Intelligence workspace and direct toolbar access.
- Added synchronized evidence chain, RCV likelihood, MR signal-loss correlation, and event table.

## R0052
- Product-style Registration gating restored: display MR first, then Registration ON.
- Hardened global arrow navigation and Treatment MR fit behavior.
- Reorganized cavitation charts and added explicit receiver/lower-chart selectors.
- Improved registration transform hypothesis selection and bone-edge visibility.

## R0051
- Fixed Registration button remaining disabled when an MR reference series was available.
- Registration ON can now activate the selected/first visible Preplanning/Planning MR reference automatically.
- Centralized Registration button state synchronization after reference-list rebuilds and mode changes.
- Added inline guidance instead of a blocking popup when no MR reference is available.

## R0050
- Added Cavitation × MR magnitude correlation using gain-normalized multi-frame baseline signal-loss maps.
- Added hydrophone-likelihood × MR-loss overlap score, centroid distance, and candidate confidence.
- Added a dedicated MR correlation view inside default Sonication Replay Cavitation Intelligence.
- Improved Registration ON review: search the full preplanning CT volume for the plane/slice with best MR/CT edge agreement after applying the treatment CtMr matrix in-plane transform.
- Registration status now reports the selected CT slice and alignment score instead of assuming corresponding slice indices.

## R0049
- Separated image selectors into Preplanning CT, Preplanning MR Ax/Sag/Cor, Planning MR Ax/Sag/Cor, Treatment MR, and Treatment Thermal.
- Mapped Sonication1 planning MR RAW files to MriImageParams series/plane metadata instead of treating every non-TMAP RAW as one generic planning family.
- Added Registration OFF/ON control, enabled only while preplanning/planning MR is displayed.
- Registration ON overlays CT skull/bone edges using the treatment-adopted per-sonication CtMr_mat.txt (with lastCtMrRegistration fallback).
- Added 2-D treatment-registration review projection for Ax/Sag/Cor reference images and explicit registration-source status.
- Preserved live Treatment MR/Thermal replay as separate image families.

## R0048
- Enabled 100 ms display smoothing by default in CGA Cavitation / Vendor Rules.
- Replaced fixed-fps Sonication Replay with 1× Actual treatment-timeline playback by default.
- Added selectable 0.25× / 0.5× / 1× / 2× / 4× / 8× playback multipliers.
- Playback timer now derives its interval from the active replay timeline instead of an arbitrary FPS value.

## R0047
- Fixed global arrow navigation.
- Full-range cavitation chart defaults and chart/table synchronization.
- Corrected reconstructed-vs-observed power timeline alignment.
- RCV0-RCV7 receiver naming and Cap/Tile geometry presentation.
- Reworked registration display to avoid synthetic/misregistered CT/MR fusion.

## R0046
- Added status-bar progress label and progress bar for ZIP/folder loading and sonication stream preparation.
- ZIP extraction and package discovery now run off the UI thread.
- Sonication preparation is staged with stale-selection cancellation so Prev/Next/PageUp/PageDown can change selection between loading stages.
- Replaced load/decode modal message boxes in the main replay path with inline status messages.
- Chart hover labels are now single-instance-at-a-time and placed away from the cursor.
- Fusion view now keeps MR dominant and overlays CT bone edges from the best structural CT slice instead of a filled arbitrary first CT slice.
- Study diagnostics are deferred independently from sonication selection so rapid selection changes do not cancel study initialization.

## R0045
- Made CGA cavitation charts easier to read with Control overview / Selected hydrophone / All 8 hydrophones views.
- Default Control overview removes the dense 8CH diagnostic overlay and emphasizes combined control inputs, rules and power response.
- Added display-only 100 ms smoothing, synchronized current-time cursor and linked X axes.
- Restored Up/Down/Left/Right replay navigation across focused child widgets via WindowWithChildren shortcuts; PageUp/PageDown change sonication in the main replay.

## R0044
- Fixed Cavitation Events Control Timeline remaining empty: observed Acquisition_Brain timeline is now loaded and drawn during cavitation refresh.
- Automatically selects the observed event nearest the current FFT acquisition cycle.
- Updated default hydrophone geometry to the provided RCV reference: CH0-3 Cap RCV inner positions and CH4-7 Tile RCV outer positions.
- Likelihood view now labels CH0/H1 through CH7/H8 and identifies Cap vs Tile RCV.
- Geometry axes are reference coordinates rather than unverified patient anatomical directions.

## R0043
- Reworked Cavitation Events into chart-priority subtabs: Control Timeline, Probable Location, Hydrophone × Band.
- Hid analysis/evidence text by default behind Show analysis details.
- Guaranteed useful minimum heights for all cavitation charts on laptop displays.
- Moved contribution table beside the location map instead of stacking it vertically.
- Found and fixed a duplicated frame-loop line in observed-event navigation during triple check.

## R0042
- Prioritized cavitation charts over descriptive text in the Spectrum Dump Analyzer.
- Collapsed source details and vendor rule/band details by default.
- Increased minimum chart heights so the lower cavitation-control response chart remains visible on laptop displays.

## R0041
- Fixed CGA Cavitation / Vendor Rules vertical layout where the lower charts could collapse to only a few pixels.
- Compacted the profile summary and Band/Control tables.
- Placed Vendor Band Energy and Display Rule charts side-by-side to reduce vertical pressure.
- Protected minimum height for the Cavitation Control Response chart so actual vs reconstructed power remains visible on laptop/1080p screens.

## R0039
- Fixed Spectrum Dump Analyzer not opening after R0038.
- Root cause: a leftover bare `PLACEHOLDER` token in `_draw_cavitation_likelihood()` raised `NameError` during immediate package autoload, before the dialog reached `show()`.
- Restored the intended likelihood summary/evidence label update.
- Added regression guards against placeholder runtime tokens in the analyzer UI.

## R0038
- Integrated cavitation intelligence into the default Sonication Replay; CPC evidence is decoded in the background without requiring CPC source mode.
- Added compact Replay Cavitation Intelligence panel with Band0-3 values, dominant/contributing hydrophones, probable-region map, and observed rule/result status.
- Added synchronization to nearest exact CPC acquisition cycle and observed Increase/Decrease/Safety/Halt event.
- Added MR magnitude central-ROI signal-loss screening with receive-gain normalization for cavitation-image correlation triage.
- Preserved the full Spectrum Dump Analyzer / Cavitation Events workflow for deeper inspection.

## R0037
- Added cavitation likelihood-region visualization based on hydrophone contribution pattern.
- Added schematic 8CH geometry plot with dominant hydrophone, contributing hydrophones, focus marker, and likelihood centroid.
- Added per-hydrophone contribution table and textual probable-region summary.
- Supports both observed cavitation-control events and dump-only current FFT snapshot evidence.
- Added regression tests for frame-based and event-based likelihood estimation.

## R0036
- Added observed cavitation-control timeline reconstruction from Acquisition_Brain logs.
- Added visualization-focused cavitation control plot showing observed and reconstructed power response.
- Added observed event table with rule, threshold, dominant hydrophone, contributing hydrophones/bands, and result.
- Kept SpectrumDumps-only candidate analysis and heatmap, and now display it alongside observed control behavior when available.
- Added regression test for parsed HALTED BY CAVITATION event and dominant hydrophone extraction.

## R0035
- Added SpectrumDumps-only cavitation analysis mode independent of treatment Export loading.
- Added cavitation activity heatmap/event table and evidence-level labeling.
- Added dump-only Band0–Band3 frequency-range reconstruction from embedded energy equality.
- Added INI-independent 8CH Band0 snapshot-to-cycle mapping when the raw companion is available.

## R0034
- Decoded `DECREASE_POWER_RULE_*`, `INCREASE_POWER_RULE_0`, `SAFETY_RULE_*`, cavitation-control levels, general error policies, and `CavitationDynamicRules_0.ini`.
- Reconstructed runtime power control from Acquisition_Brain: simultaneous decrease rules use the strongest configured decrease; decrease and increase ratios are multiplicative; increase saturates at 1.0.
- Added actual-vs-predicted power-ratio chart and control-rule table to `CGA Cavitation / Vendor Rules`.
- Added runtime evidence for threshold, weighted input band/channel, power action, safety persistence windows, and dynamic sub-sonication switching rules.
- Preserved R0033 exact Band0-3 FFT energies and exact snapshot-to-acquisition-cycle mapping.

## R0033
- Decoded the embedded vendor 8CH × Band0..Band3 energy table from each CPC FFT snapshot.
- Proved embedded Band0..Band3 values equal the sum of FFT graph bins inside vendor HARMONICS_BANDWIDTHS to float precision.
- Added exact FFT-snapshot → 10-ms acquisition-cycle mapping using the Band0 8CH fingerprint; real gaps are preserved.
- Band Energy view uses embedded exact vendor energies for matching Band0..Band3 definitions instead of recomputing approximate values.
- CGA Cavitation view plots exact per-snapshot Band0..Band3 values and reports the exact acquisition cycle/time.
- Spectrogram no longer pretends non-uniform snapshot gaps are uniformly sampled time.

## R0032
- Extended vendor cavitation reproduction from Band0 to multi-band evidence.
- Band1 continuous combined energy is reconstructed from Display Rule 2 and its configured 0.018 maximum-energy normalization.
- Band2 exact threshold-event energy is recovered from Decrease Power Rule 4/5 log entries.
- Disabled CGA rules (`-1.#IND`) are now excluded from numeric history parsing.
- Vendor cavitation plots now show Band0, Band1, Band2 event evidence, Display Rule 1 and Display Rule 2.
- Band3 remains evidence-limited rather than guessed.

## R0031
- Decoded vendor `HARMONICS_BANDWIDTHS` from `CavitationSafetyAndControl.ini` instead of using generic fixed cavitation bands.
- Decoded `INCREASE_POWER_RULE_0` and `DISPLAY_RULE_1` 8×4 weight matrices and thresholds.
- Proved CPC raw companion history is exact vendor Band0 per-hydrophone energy when Acquisition_Brain log evidence is available.
- Reconstructed the control `Calculated Energy` as weighted CH1–CH4 Band0 energy and `Display Rule 1` as Energy / MaximumEnergy.
- Added CGA Cavitation / Vendor Rules tab with exact Band0 channel histories, weighted energy, normalized Display Rule 1, and vendor band table.
- Added validator tool for exported CPC datasets.

## R0030
- Deep frequency-axis reconstruction using embedded SpectrumMsg/CPC graph metadata.
- Added Hz/MHz vendor-unit auto-detection for graph start and bin spacing.
- Added SpectrumMsg header record-count validation before exact graph reconstruction.
- Added frequency-axis provenance, f0-bin error, and theoretical FFT-spacing audit.
- Added export-level frequency reproducibility validation tool and regression tests.

## R0029
- Corrected SpectrumMsg frequency reconstruction using the explicit 256-bin GUI graph records embedded in the dump.
- Uses the exported graph metadata (start frequency 250000 Hz and bin spacing ~1953 Hz in the validated dataset) instead of a synthetic 0..f0*2.2 axis.
- Corrected CPC SpectrumDumps `_FFT` frequency reconstruction to honor Acquisition.ini `f1ForGraph` / `f2ForGraph`.
- Validated against 17-00-24_ANx: f0=670 kHz is reconstructed at ~669.9 kHz and f0/2 at ~335.9 kHz.
- Added regression tests for CPC and SpectrumMsg frequency axes.

# RC7.2-R0025

- Added Engineering Analysis workspace with source/confidence-labelled metrics.
- Added capability Dependency Graph for best-effort PARTIAL analysis.
- Added ACT element statistics and ACT ↔ SkullMeasures phase cross-check.
- Added SkullMeasures SDR/thickness/velocity/angle/ray-shift statistics.
- Added SkullHeating OffReason, model power, skull-temperature and model/reference metrics.
- Added Field33 / Field23 mask-aware thermometry diagnostics and Field2/34 local-map occupancy.
- Kept SpectrumMsg 8-channel value as container metadata only; no unverified payload split.
- Workstation Replay frequency remains sourced from SonicationSummary.

# RC1-C0045

## CPC Spectrum / 8CH Time-Frequency Analyzer

- Added Raw Data, Spectrum, Spectrogram, Band Energy, and Measure/Statistics tabs.
- Added editable MHz bands and time-resolved energy calculation for all eight channels.
- Added frame navigation, playback, per-channel raw peak/RMS and spectral measurements.
- Repaired the planning/hydrophone audit utility.
- CPC data remains independent from Sonication SpectrumMsg.

# RC1-C0041

- Completed CT/Power-Score/XD/metadata data binding fixes.

## RC1-C0041

- Unified CPC 8CH hydrophone scale to fixed 0–1 MHz and -60–0 dB for cavitation visibility.

# RC1-C0037 Replay Data Foundation Fix

- Linked CtImage.xml rowset records to exported RAW planning image payloads.
- Added ProtocolData.xml and MriImageParams.xml metadata extraction.
- Added CPC 8CH acoustic frame playback with 10 ms timeline display.
- Added XD colour scale minimum and maximum controls and continuous colour ramp.
- Stabilized embedded Power/Score curves and added visible planned-power fallback when measured telemetry is unavailable.

# C0036

Independent Sonication Acoustic Spectrum and CPCFiles 8CH Hydrophone display paths.

# RC1-C0035 Initial Main Image and Row Source Selection

- Display the first valid replay image immediately after loading a sonication.
- Prefer Thermal replay for the initial main image and fall back to Anatomy MR.
- Give all three image rows the same fixed choices: Planning CT, Planning MR, Anatomy MR, Thermal, and All images.
- Keep Planning CT and Planning MR as separate selectable image categories.
- Preserve Temperature Trend : Acoustic Spectrum at 3 : 4.

# RC1-C0034 ReplayDisplayXDScaleFix

- Fixed image selection, initial blank viewer, Power/Score stability, planning thumbnails, and XD colour scale.

## RC1-C0032
- Main image initialization/state reset and product-style Planning/Anatomy/Thermal selectors.
- Relative Acoustic Spectrum removed from Replay UI.

# RC1-C0031 Acoustic Timeline Synchronization

- Maps treatment Sonication 1-N to the final N Acquisition telemetry segments when pre-treatment/DQA segments exist.
- Uses the complete MR acquisition interval as the Replay time axis.
- Preserves acoustic onset at its measured offset from MR acquisition start.
- Hides Relative Acoustic Spectrum from the main Replay until its physical mapping is verified.
- Reloads Power/Score telemetry for every Sonication selection.


## RC1-C0027-02b-Fix1
- Fixed Diagnostics remaining empty after Replay data was loaded.
- Diagnostics now loads from the exact extracted Replay workspace before the first sonication is selected.
- Added Replay-package fallback metadata for datasets without workstation XML metadata files.
- Synchronized Replay sonication selection with Diagnostics.
- Fixed SkullMeasures parsing for concatenated signed numeric columns.
- Fixed SkullMeasures element-row counting to exclude numeric header lines.
# C0024 - Synchronized Cavitation Timeline

- Removed the fixed four-second temperature frame cadence.
- Reads planned and measured duration per sonication from SonicationSummary.xml.
- Rebased Acquisition telemetry to the measured acoustic power-ramp onset.
- Preserves measured telemetry time instead of normalizing CPC pre-roll over the MR replay.
- Temperature, replay cursor, Power, Score, waterfall and chart clicks now use one elapsed-time axis.
- Detects the first high cavitation score and abrupt power modulation events.
- Validated against the supplied Sonication 5 deliberate-cavitation test: 2.99041 s, 250 W.

# C0022 Hydrophone Reverse Engineering

- Added an evidence-first Hydrophone Reverse Engineering Lab for SpectrumMsg, Acquisition, Reflection and CavitationControl DMP files.
- Added binary structure profiling: ASCII markers, entropy, zero ratio, block periodicity, endian/type candidates and ranked spectrum-like numeric regions.
- Added Acquisition_Brain telemetry summary for Power and Score validation.
- Added Confirmed / Estimated / Unknown classifications and prevented speculative candidates from entering Replay rendering.
- Added JSON and CSV diagnostic exports plus a Windows launcher.
- Preserved the existing C0021 Replay display while the underlying format is investigated.

# C0021 Acoustic / Temperature Synchronization

- Replaced per-frame spectrum normalization with one fixed sonication baseline and scale so real acoustic-energy increases remain visible.
- Added Current, Average, Max Hold, and Baseline Δ spectrum modes; Average is the default score-window view.
- Added subharmonic, ultraharmonic, broadband, and total relative-energy calculations for the active channel.
- Kept embedded and popup Acoustic Spectrum on the same renderer and mode.
- Temperature Trend now fits the complete sonication by default, includes all finite Max/ROI Average/Cursor values, and moves only the replay cursor during playback.
- Temperature zoom/range and all acoustic controls remain persistent across sonication and CPC source changes.
- Missing temperature samples are rendered as gaps rather than artificial zero-temperature points.

# C0020 Acoustic Spectrum Workstation Reproduction

- Replaced pseudo-3D current spectrum with the workstation-style current-frame 1D FFT.
- Shared one CurrentSpectrumRenderer between embedded and popup charts.
- Fixed axes to 0.20-0.80 MHz and 0-4 relative amplitude.
- Added robust baseline subtraction, percentile normalization and light smoothing.
- Default single active channel uses the workstation orange trace; multi-CH keeps fixed colors.
- Added synchronized Time display and main/subharmonic guides.
- Added main-chart mouse-over frequency and per-channel relative amplitude.
- Preserved CPC, channel and chart-state behavior across Sonication changes.

# C0019 Acoustic Spectrum Engine v2 / Chart State

- Relative Acoustic Spectrum now uses all decoded FFT bins as a Time × Frequency heat map.
- Embedded chart and popup use the same renderer.
- Coloured overlay curves represent the selected channels current-frame FFT, replacing misleading peak-ridge lines.
- CPC remains OFF by default and only changes the data source; channel choices are retained.
- Sonication-local configured CH0–CH7 is used as the default channel.
- CH, CPC and future chart choices are retained across Sonication changes.

# Changelog

## RC1-C0017c
- Rebuilt embedded Power/Score curves on every telemetry refresh so the main chart and popup share the same visible data.
- Added hover values to the main Power/Score chart and all enlarged chart popups.
- Synchronized Temperature, Power/Score, Spectrum, and Waterfall popups with frame and sonication changes.
- Changed the visible ROI average curve to green and clarified it as the 5 mm x 5 mm voxel average.
- Kept the 20 mm target circle display-only and changed the calculation ROI/voxel square to 5 mm x 5 mm.
- Strengthened the enlarged acoustic-spectrum perspective with multiple receding traces.


## RC1-C0017b
- Reattached the embedded Power/Score curves to the main PlotWidget on every refresh, fixing the case where only the enlarged popup displayed telemetry.
- Unified main and popup chart data refresh for frame and sonication changes.
- Enlarged Temperature Trend and Acoustic Spectrum while reducing Power/Score and Waterfall height.
- Added Workstation-like pseudo-3D multi-depth Acoustic Spectrum traces with a visible quiet baseline and expanded peak range.
- Added a display-only 20 mm target circle plus a 10 mm x 10 mm square calculation ROI.
- Restored the Voxel (ROI) 10 mm x 10 mm label and reduced chart-panel padding.
- Renamed the waterfall panel to Relative Acoustic Spectrum vs Replay Time.

## RC1-C0017a
- Fixed acoustic telemetry start-line debouncing so Power/Score segments are populated.
- Added synchronized chart popups.
- Added temperature-map mouse hover readout below the cursor.
- Added Red Threshold step buttons.
- Restored Voxel 10 mm × 10 mm label.
- Increased Acoustic Spectrum headroom and visible quiet baseline.
- Reduced chart height and unused margins.

# C0016c Temperature / Acoustic Refinement

- Temperature Trend defaults to 40–60 °C with 2 °C major ticks, 1 °C minor ticks, background temperature bands, and synchronized replay cursor.
- Red Threshold now changes the temperature at which the overlay turns red; it no longer hides all temperatures below the threshold.
- Power and Score values are drawn inside their shared chart.
- Hydrophone channel selection moved to Acoustic Spectrum and supports single, multiple, and all-channel selection.
- Acoustic Spectrum uses 0.20–0.80 MHz and 0–4 Relative Amplitude axes.
- Waterfall renamed to Acoustic Spectrum Over Replay Time and uses relative-amplitude color intensity.
- Fallback voxel changed to 10 mm × 10 mm.

# C0016a
- Initialized Temperature Trend workspace
- Prepared Peak Navigation foundation


## RC1 C0016c ReplayVisibilityFix
- Reset WL/WW per sonication so DQA images do not inherit prior settings.
- Replaced inline hydrophone checkboxes with compact CH popup multi-selection.
- Added colored relative-amplitude waterfall LUT and clearer panel title.
- Fixed Acquisition_Brain segment start detection so Power/Score curves populate.
- Reduced chart header/margin waste.
- Added target-centered 20 mm blue circular ROI.
- Added Temperature Trend mouse-hover Max/Avg/Cursor temperature popup.


## C0018 Multi-CH 3D Heatmap / CPC Optional
- Fixed hydrophone labels to CH0 through CH7.
- Sonication-folder SpectrumMsg is the only default acoustic source.
- Added CPC OFF/ON button; CPCFiles SpectrumMsg/Acquisition DMP candidates are decoded only while enabled.
- Added per-Sonication main-frequency resolver with ACT/settings priority, then Xd INI, then 650 kHz fallback.
- Changed Relative Acoustic Spectrum into a perspective heat-map with channel-coloured ridge curves.
- Applied stable fixed colours to CH0..CH7.
- Explicitly marks Sonication and CPCFiles source kinds in decoded spectrum frames.

## RC1 C0024 — Synchronized Cavitation Timeline

- Added a standalone PySide6 Hydrophone RE Lab GUI.
- Added ZIP/folder/file drag-and-drop import and recursive candidate discovery.
- Added Hex/ASCII Binary Explorer with offset and length controls.
- Added Interactive Decoder for Float32/64, Int16/32, UInt16, UInt8 and endian selection.
- Added automatic structure profiling and ranked numeric candidates.
- Added waveform, FFT, PSD and dB previews with main/sub/ultraharmonic guides.
- Added band-energy table, candidate double-click loading, telemetry correlation and lag search.
- Added JSON/CSV/PNG session export and evidence report display.
- Updated build/04_HYDROPHONE_RE_LAB.bat to launch the GUI.
- Added build/05_BUILD_HYDROPHONE_RE_LAB_EXE.bat for standalone Nuitka EXE creation.

### C0024 timing/cavitation corrections
- Removed the fixed 4-second-per-frame replay time assumption.
- Removed telemetry normalization/stretching to the MR replay span.
- Added a measured common elapsed-time axis from Acquisition_Brain per sonication.
- Temperature, Power, Score, cursors, and replay navigation now share the same sonication duration.
- Added Cavitation Event Timeline tab with Sonication selector (default 5).
- Added synchronized Power/Score plot, log-event markers, findings, and CSV/JSON export.
- Added power-reduction candidate detection and Score threshold timing.


## RC1-C0025 DQA Information / XD Prototype
- Added left-side Sonication summary: Orientation, Frequency Dir, Energy, Power, Duration, Frequency.
- Updated Info window with DQA and result context.
- Added single-instance MR and Scan protocol information popups.
- Added single-instance XD popup for SkullMeasures element-map visualization.
- XD parameter selection redraws automatically and supports enabled/disabled element filtering and hover values.
- Sonication changes refresh all open information windows without creating duplicate popups.

## RC1-C0025a Information Data / XD Map Hot Fix
- Search metadata across the complete extracted export.
- Decode MR rows from MRFiles/review.out.
- Populate Scan information from Sonication ACT and resolved timing.
- Search SkullMeasures by active sonication across the workspace.
- Replace the XY chart with a workstation-style transducer element map and gradient scale.

## RC1 C0027-02b — Replay Diagnostics Framework
- Added a permanent Diagnostics tab connected to the C0027 Metadata Engine.
- Added automatic validation after ZIP/folder import.
- Added Health Score, metadata coverage, Warning Center and Resource Monitor.
- Added Sonication Metadata Explorer, Replay Inspector and double-click Replay navigation.
- Added timeline inventory for MR, sonication, replay, temperature and SpectrumMsg resources.
- Added metadata load/performance metrics.
- Added JSON, CSV and standalone HTML diagnostic report export.

## RC1-C0029 PlanningHydrophoneReplay
- Added PlanningDataService for CT/SDR, pre-treatment MR, registration and Sonication1 non-replay RAW classification.
- Added HydrophoneReplayService with eight-channel SpectrumMsg replay grouping.
- Added Planning / Reference and Hydrophone 1-8 application tabs.
- Added `03_AUDIT_PLANNING_HYDROPHONE.bat` and JSON audit output.

## RC2-R0003 Atomic Frame Snapshot

One immutable frame snapshot now carries the decoded replay frame, elapsed time, mapped magnitude/temperature indices, and mapped spectrum index to every synchronized view. Old snapshots are invalidated when the Sonication source changes.

## RC2-R0016
- Responsive scrollable replay information panel and High-DPI readability fix.

## R0023
- Added standalone Spectrum Dump Analyzer input workflow for Export ZIP / folder / file.
- Added recursive Spectrum dump discovery, RAW+FFT pairing, candidate selection, and direct single-file open.
- Preserved validated CPC 8CH semantics and explicit SpectrumMsg separation.


## R0026
- Spectrum Dump Analyzer reuses the already-loaded Sonication Analysis Export workspace.
- On analyzer launch after Export load, recursively discovers Spectrum candidates and prompts for measurement selection when multiple candidates exist.
- Added Select From Loaded Export for returning to the current treatment dataset without reloading ZIP/folder input.
- Preserved standalone ZIP/folder/file/drop behavior when no Export is loaded.

## RC7.2-R0067
- Decode CPCFiles/Site/Ini/ChannelMeasure.ini as a full 1024-channel measured amplitude/phase table at the nearest sonication frequency.
- Merge full measured channel data with sparse per-sonication Logical Amplitude/Phase log evidence without conflating them.
- Connect the full 1024-channel phase array to Tile, Umbrella, and Phase Dedicated element views.
- Correct Phase Dedicated rendering methods to live on SonicationElementMapWidget.
- Add per-series checkboxes to the existing vendor cavitation legend without changing its layout.

## RC7.2-R0116zzt
- Fixed registration/Thermal overlay state leakage, Planning MR lazy thumbnails, Summary thermometry enrichment, irradiation-relative chart-click synchronization, event-gated probable cavitation region, Spectrum Analyzer open progress, and explicit empty Control Timeline diagnostics.
## RC7.2-R0116zzg1
- Cavitation Status now treats observed power Decrease and Safety responses as cavitation events; Increase remains excluded.
- Newly selected Sonications open at irradiation end across synchronized Replay views, and the bound Spectrum Dump Analyzer starts at the corresponding FFT snapshot.


## RC7.2-R0116zzg2
- Fixed the post-100% Sonication-load freeze by making the irradiation-end startup publish lightweight and keeping hidden Analysis/Cavitation refreshes lazy until their tabs are opened.

## RC7.2-R0116zzg3
- Prevented Spectrum Analyzer load stalls by ending the exclusive/modal decode phase before primary pyqtgraph/table rendering, then publishing the irradiation-end FFT frame on the next Qt event-loop turn. Secondary Spectrum/Cavitation analysis remains non-modal and worker-owned.

## R0116zzg9
- Repaired Analyzer tab materialization and replay-identity-aware Spectrum secondary cache.
- Spectrogram/Band Energy now self-publish from the authoritative replay without requiring Replay cursor movement.


## R0129
- FFT range presets now activate selection directly and no longer require a hidden second toggle state.
- Control Timeline first-open nested layout hardened; lower table remains reachable and user splitter adjustments persist.

## R0130
- Fixed FFT-derived Band0 analysis interval to 0.311–0.411 MHz.
- Selected Raw A/D FFT result highlights Band0 and reports per-RCV Band0 FFT RMS.
- Added workstation-style cyan frequency-direction hat marker to the main image lower-right overlay, oriented from resolved MR frequency axis.
- Preserved R0129 FFT range and Control Timeline first-open hardening.
## RC7.10-R0141
- Deduplicate byte-identical CPC Spectrum copies introduced by nested ZIP materialization.
- Bind CPC candidates to Acquisition_Brain sessions from the package workspace rather than an overly-deep candidate parent.
- Unify cavitation-control session start detection with AcousticControlService, including `StartSpectrumMeasurement: SetInitial PowerRatios`.
- Preserve fail-closed authoritative mapping; no blind positional CPC fallback added.


## RC7.10-R0153
- Canonicalized Sonication timing across Replay, Cavitation Intelligence, and Spectrum Dump Analyzer.
- Matched WS/MRServer evidence by full datetime and retained safe legacy undated-log compatibility.
- Removed irradiation-relative double offsets from synchronized Main charts and click navigation.
- Added redraw guards so Sonication start/end markers are not duplicated after time-axis/tab refreshes.

## R0154m
- Exact variable-record Brain220 SpectrumMsg decoder based on the supplied 42110 export.
- Decodes all 161/6/347/153/346/348/346 records for Sonication1–7 instead of one heuristic frame.
- Supports 1000-bin/250 Hz and 400-bin/625 Hz FFT variants with exact embedded 0–250 kHz axes.
- Propagates embedded acquisition-history timestamps for Spectrum/Replay synchronization.
- Brain220 current-spectrum and spectrogram presentation now use the 50–250 kHz vendor graph window and include the 115 kHz subharmonic.

## R0154o
- Deepened Brain220 SpectrumMsg history decoding and proved per-record timestamp identity with PowerGraph.
- Bound the embedded integer state to active target voxels only for WS-validated multi-target sonications; ambiguous single-focus values remain unlabeled.
- Added active target-voxel/RAS context to the Replay Spectrum overlay.
- Changed PowerGraph synchronization from blind timestamp overwrite to exact cross-validation with fail-closed mismatch handling.
