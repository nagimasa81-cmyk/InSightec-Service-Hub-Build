# Changelog

## RC1 C0008 FUSWSInteractiveReplay
- Changed default thermal display from Frame0 delta to workstation-style absolute temperature.
- Added automatic Absolute RAW / Delta RAW classification.
- Added explicit reference-temperature and ROI-source reporting.
- Max/Avg now use ROI values instead of whole-image values.
- Added 30–90, 35–60, 40–60 C scales and red threshold.
- Preserved ΔTemperature as investigation mode.
- Preserved synchronized Replay/Spectrum/Temperature behavior.

## RC1 C0008 FUSWSInteractiveReplay
- Rebuilt Replay screen to match the approved FUS workstation-inspired image.
- Corrected main-image orientation to match frame thumbnails by using row-major image display.
- Main image defaults to fit-to-view; right analysis area remains readable.
- Removed the persistent replay parameter table and replaced it with a non-modal always-on-top Info window.
- Info window remains movable, minimizable, and does not block the replay window.
- Red threshold changed to a horizontal slider.
- Sonication number changed to compact previous/next controls; details appear only while right-click is held.
- Added explicit Acoustic Controls cards and synchronized Waterfall display.
- Added a clickable, movable crosshair on the main image.
- Crosshair temperature is sampled at the selected pixel and plotted as a synchronized cursor-temperature trend.
