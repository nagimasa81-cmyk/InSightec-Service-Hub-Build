from __future__ import annotations

import re
from pathlib import Path

from src.common.constants import MAGNITUDE_PREFIX, TEMPERATURE_PREFIX, DEFAULT_MAIN_FREQUENCY_HZ
from src.domain.models import RawFrame, ReplayPackage, SonicationModel
from src.services.xd_ini_service import XdIniService
from src.services.sonication_frequency_service import SonicationFrequencyService
from src.services.sonication_timing_service import SonicationTimingService
from src.services.planning_data_service import PlanningDataService
from src.services.sonication_evidence_service import SonicationEvidenceService
from src.services.mr_timeline_service import MRTimelineService
from src.core.fus_export_core import inspect_export
from src.services.import_completeness_service import ImportCompletenessService
from src.services.sonication_identity_service import SonicationIdentityService


SON_RE = re.compile(r"^sonication\s*[_-]?\s*(\d+)$", re.I)
RAW_RE = re.compile(r"^(\d+)-.*-(\d+)\.raw$", re.I)


def natural_key(text):
    return [
        int(x) if x.isdigit() else x.lower()
        for x in re.split(r"(\d+)", text)
    ]


class DiscoveryService:
    def __init__(self) -> None:
        self.xd_ini = XdIniService()
        self.sonication_frequency = SonicationFrequencyService()
        self.sonication_timing = SonicationTimingService()
        self.planning_data = PlanningDataService()
        self.sonication_evidence = SonicationEvidenceService()
        self.mr_timeline = MRTimelineService()
        self.import_completeness = ImportCompletenessService()
        self.sonication_identity = SonicationIdentityService()

    def discover(self, source: Path, workspace: Path) -> ReplayPackage:
        # R0141: logical Sonication identity is no longer owned by physical
        # SonicationN folders.  Resolve it from the union of numbered evidence
        # first, then build exactly one model per logical Sonication number.
        identity = self.sonication_identity.resolve(workspace)
        numbers = list(identity.numbers)

        # Legacy single-Sonication exports may have local RAW/Spectrum evidence
        # without any numbered identity marker. Preserve that established path.
        if not numbers and any(
            path.is_file() and ("spectrummsg" in path.name.lower() or path.suffix.lower() == ".raw")
            for path in workspace.iterdir()
        ):
            numbers = [1]

        models = [
            self._build_logical(
                workspace=workspace,
                number=number,
                folders=identity.folders_by_number.get(number, []),
                identity_evidence=identity.evidence_by_number.get(number, []),
            )
            for number in numbers
        ]

        # Semantic Export inspection is intentionally independent from replay
        # decoding. PARTIAL sonications remain loadable; missing assets are
        # reported per capability rather than blocking the whole case.
        export_inspection = inspect_export(workspace)
        inspection_by_number = {item.number: item for item in export_inspection.sonications}
        for model in models:
            item = inspection_by_number.get(model.sonication_number)
            if item is not None:
                model.completeness_status = item.status
                model.completeness_score = item.score
                model.missing_required = list(item.missing_required)
                model.missing_optional = list(item.missing_optional)
                model.degraded_items = list(item.degraded_items)
                model.capabilities = {
                    key: {
                        "available": value.available,
                        "degraded": value.degraded,
                        "reason": value.reason,
                        "evidence": list(value.evidence),
                    }
                    for key, value in item.capabilities.items()
                }
                model.thermometry_mode = item.thermometry_mode
            elif model.synthetic_identity:
                model.completeness_status = "PARTIAL"
                model.missing_required = ["Physical Sonication folder"]
                model.degraded_items = ["Logical identity reconstructed from package-level evidence"]

        timings = self.sonication_timing.read_indexed(workspace)
        for model in models:
            timing = timings.get(model.sonication_number)
            if timing is None:
                continue
            model.planned_duration_s = timing.planned_duration_s
            model.actual_duration_s = timing.actual_duration_s
            model.planned_power_w = timing.planned_power_w
            model.actual_power_w = timing.actual_power_w
            model.planned_energy_j = timing.planned_energy_j
            model.actual_energy_j = timing.actual_energy_j
            # Authoritative Workstation Replay frequency: SonicationSummary.xml
            # per-sonication row. Do not replace this value with SkullHeating
            # or package/XD nominal frequency.
            if timing.frequency_hz is not None:
                model.main_frequency_hz = timing.frequency_hz
                model.main_frequency_source = timing.source
                model.main_frequency_raw_line = f"SonicationSummary.frequency={timing.frequency_hz:g}"
            model.timing_source = timing.source
            model.panic_type = timing.panic_type

        xd_references = self.xd_ini.discover_references(workspace)
        frequency = self.xd_ini.read_main_frequency(workspace)
        fallback_hz = frequency.frequency_hz if frequency.frequency_hz is not None else DEFAULT_MAIN_FREQUENCY_HZ
        for model in models:
            # SonicationSummary frequency is authoritative for Workstation Replay.
            # Legacy/local discovery is used only when the summary has no frequency.
            if model.main_frequency_hz is not None:
                continue
            local = self.sonication_frequency.read(model.folder) if model.folder.exists() else self.sonication_frequency.read(workspace)
            model.main_frequency_hz = local.frequency_hz if local.frequency_hz is not None else fallback_hz
            model.main_frequency_source = local.source if local.source is not None else frequency.source_path
            model.main_frequency_raw_line = local.raw_line if local.raw_line is not None else frequency.raw_line

        # R0116zm/R0141: bind evidence by explicit Sonication number, never by
        # list position. This is required for missing/gapped/duplicate folders.
        try:
            evidence_rows = self.sonication_evidence.read(workspace, models)
        except Exception:
            evidence_rows = []
        evidence_by_number = {row.sonication_index: row for row in evidence_rows}
        for model in models:
            evidence = evidence_by_number.get(model.sonication_number)
            if evidence is None:
                continue
            model.canonical_acquisition_session_index = evidence.acquisition_session_index
            model.canonical_setup_clock_s = evidence.setup_record.clock_s if evidence.setup_record is not None else None
            model.canonical_mapping_confidence = evidence.confidence
            model.canonical_mapping_evidence = list(evidence.evidence)
            model.spectrummsg_frame_count = evidence.spectrummsg_frame_count
            model.powergraph_size = evidence.powergraph_size
            model.sonication_file_inventory = dict(evidence.file_inventory)

        # R0116zn/R0141: one authoritative clock for the whole application.
        # MRTimelineService also resolves Summary rows by Sonication number.
        try:
            mr_timelines = self.mr_timeline.resolve_all(workspace, models)
        except Exception:
            mr_timelines = []
        for model, timeline in zip(models, mr_timelines):
            model.mr_timeline_duration_s = float(timeline.duration_s)
            model.mr_sonication_start_s = float(timeline.sonication_start_s)
            model.mr_sonication_end_s = float(timeline.sonication_end_s)
            model.mr_frame_interval_s = timeline.frame_interval_s
            model.mr_timeline_source = str(timeline.source)
            model.mr_timeline_confidence = str(timeline.confidence)
            model.mr_timeline_evidence = list(timeline.evidence)

        cpc_files = []
        for path in workspace.rglob('*'):
            if not path.is_file():
                continue
            low = path.name.lower()
            if 'spectrummsg' in low:
                continue
            if low.startswith('spectrum_') and (low.endswith('.dmp') or low.endswith('.dmp_fft')):
                cpc_files.append(path)
        cpc_files = sorted(set(cpc_files), key=lambda path: natural_key(str(path)))

        planning = self.planning_data.discover(workspace)

        try:
            import_audit = self.import_completeness.audit(workspace, models).to_dict()
        except Exception as exc:
            import_audit = {
                "status": "WARN",
                "issues": [f"Import completeness audit failed: {type(exc).__name__}: {exc}"],
            }

        return ReplayPackage(
            source=source,
            workspace=workspace,
            sonications=models,
            main_frequency_hz=frequency.frequency_hz if frequency.frequency_hz is not None else DEFAULT_MAIN_FREQUENCY_HZ,
            main_frequency_source=frequency.source_path,
            main_frequency_raw_line=frequency.raw_line,
            main_frequency_confidence=frequency.confidence,
            main_frequency_interpretation=frequency.unit_interpretation if frequency.frequency_hz is not None else "Default 650 kHz",
            cpc_spectrum_files=cpc_files,
            planning_assets=planning.assets,
            xd_reference_files=xd_references.xd_files,
            xd_geometry_files=xd_references.geometry_files,
            workflow_mode=export_inspection.workflow_mode,
            thermometry_mode=export_inspection.thermometry_mode,
            import_audit=import_audit,
        )

    def _build_logical(
        self,
        workspace: Path,
        number: int,
        folders: list[Path],
        identity_evidence: list[str],
    ) -> SonicationModel:
        # Pick a stable primary path for APIs that still expect ``model.folder``.
        # All duplicate physical folders are merged into this one logical model.
        primary = folders[0] if folders else workspace / f"Sonication{number}"
        model = SonicationModel(
            name=f"Sonication{number}",
            folder=primary,
            sonication_number=int(number),
            evidence_folders=list(folders),
            synthetic_identity=not bool(folders),
            identity_evidence=list(identity_evidence),
        )

        scan_roots = list(folders)
        seen_file_keys: set[tuple[str, int]] = set()
        files: list[Path] = []
        for root in scan_roots:
            if not root.exists():
                continue
            for path in root.rglob("*"):
                if not path.is_file():
                    continue
                try:
                    size = path.stat().st_size
                except OSError:
                    size = -1
                # Nested ZIP expansion can materialize the same Sonication folder
                # twice. Merge duplicate copies by filename+size while retaining
                # distinct evidence with different names/sizes.
                key = (path.name.lower(), int(size))
                if key in seen_file_keys:
                    continue
                seen_file_keys.add(key)
                files.append(path)

        # A missing physical Sonication folder must not hide package-level
        # SpectrumMsg-N evidence. Also capture it if it lives outside the folder.
        spectrum_pattern = re.compile(rf"^spectrummsg[-_ ]?{int(number)}(?:\D|$)", re.I)
        for path in workspace.rglob("*"):
            if not path.is_file() or path.suffix.lower() != ".dmp":
                continue
            if not spectrum_pattern.match(path.name):
                continue
            try:
                size = path.stat().st_size
            except OSError:
                size = -1
            key = (path.name.lower(), int(size))
            if key not in seen_file_keys:
                seen_file_keys.add(key)
                files.append(path)

        for path in files:
            low = path.name.lower()
            raw_match = RAW_RE.match(path.name)
            if raw_match:
                frame = RawFrame(path=path, index=int(raw_match.group(2)), prefix=raw_match.group(1))
                if frame.prefix == TEMPERATURE_PREFIX:
                    model.temperature_frames.append(frame)
                elif frame.prefix == MAGNITUDE_PREFIX:
                    model.magnitude_frames.append(frame)
                else:
                    model.other_files.append(path)
            elif "spectrummsg" in low and path.suffix.lower() == ".dmp":
                model.spectrum_files.append(path)
            elif path.suffix.lower() == ".act":
                model.act_files.append(path)
            else:
                model.other_files.append(path)

        model.temperature_frames.sort(key=lambda frame: frame.index)
        model.magnitude_frames.sort(key=lambda frame: frame.index)
        model.spectrum_files.sort(key=lambda path: natural_key(path.name))
        model.act_files.sort(key=lambda path: natural_key(path.name))
        return model

    def _build(
        self,
        folder: Path,
        fallback: int,
    ) -> SonicationModel:
        match = SON_RE.match(folder.name)
        name = (
            f"Sonication{int(match.group(1))}"
            if match
            else f"Sonication{fallback}"
        )

        model = SonicationModel(
            name=name,
            folder=folder,
        )

        for path in folder.rglob("*"):
            if not path.is_file():
                continue

            low = path.name.lower()
            raw_match = RAW_RE.match(path.name)

            if raw_match:
                frame = RawFrame(
                    path=path,
                    index=int(raw_match.group(2)),
                    prefix=raw_match.group(1),
                )
                if frame.prefix == TEMPERATURE_PREFIX:
                    model.temperature_frames.append(frame)
                elif frame.prefix == MAGNITUDE_PREFIX:
                    model.magnitude_frames.append(frame)
                else:
                    model.other_files.append(path)
            elif (
                "spectrummsg" in low
                and path.suffix.lower() == ".dmp"
            ):
                model.spectrum_files.append(path)
            elif path.suffix.lower() == ".act":
                model.act_files.append(path)
            else:
                model.other_files.append(path)

        model.temperature_frames.sort(key=lambda frame: frame.index)
        model.magnitude_frames.sort(key=lambda frame: frame.index)
        model.spectrum_files.sort(
            key=lambda path: natural_key(path.name)
        )
        model.act_files.sort(
            key=lambda path: natural_key(path.name)
        )
        return model
