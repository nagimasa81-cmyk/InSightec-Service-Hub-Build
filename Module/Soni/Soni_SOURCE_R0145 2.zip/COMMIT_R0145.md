# R0145 — Internal vertical-budget hardening

R0144 kept top-level native window frames inside the usable Windows desktop, but real laptop feedback showed a separate class of failures: a graph inside an already-safe window could consume the remaining vertical layout and make lower controls or axes unreachable.

R0145 changes the allocation contract from **plot first** to **controls first, plots second**.

- Cavitation Intelligence keeps a vertical `ScrollBarAsNeeded` escape path in every state.
- The entire Linked Cavitation Analysis group is height-budgeted, including group frame, filter row, event table, and explanatory note. The graph stack receives only the remainder.
- CI linked RCV/probable/vendor/control plots have zero hard minimum height and yield to controls.
- Main Analysis and Sonication Summary graph-heavy pages are re-budgeted on resize and main-tab changes.
- Spectrum Dump Analyzer vendor reproduction now reserves visible legend/details/control rows before dividing remaining height between its two plots.
- Spectrum Dump Analyzer Raw, Spectrum, and Spectrogram pages also cap graph height to the active tab viewport and preserve the pinned Replay/navigation row.
- Vendor legend/detail visibility changes trigger an immediate rebudget.

This is deliberately an internal-layout fix; R0144's application-wide top-level native-frame screen guard remains in place.
