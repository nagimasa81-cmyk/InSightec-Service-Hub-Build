from pathlib import Path
import ast
ROOT=Path(__file__).parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
def test_summary_frequency():
    assert 'QTableWidget(0,13)' in MAIN and '"Frequency (MHz)"' in MAIN and '"frequency_mhz":frequency_mhz' in MAIN
def test_summary_auto_background():
    assert 'def _start_sonication_summary_background' in MAIN and 'QTimer.singleShot(350' in MAIN
def test_summary_lower_chart_default_hidden():
    assert 'QCheckBox("Show lower chart")' in MAIN and 'setChecked(False)' in MAIN and 'sonication_summary_plot.setVisible(False)' in MAIN
def test_hydro_dropdown_full_names():
    assert 'self.sonication_combo.view().setMinimumWidth(520)' in HYDRO and 'self.sonication_combo.view().setMaximumWidth(760)' in HYDRO and 'setTextElideMode(Qt.TextElideMode.ElideNone)' in HYDRO
def test_main_dropdown_full_names():
    assert 'self.sonication_combo.view().setMinimumWidth(620)' in MAIN
def test_no_duplicate_mainwindow_methods():
    tree=ast.parse(MAIN); mw=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='MainWindow'); seen=set()
    for n in mw.body:
        if isinstance(n,ast.FunctionDef):
            assert n.name not in seen,n.name; seen.add(n.name)
