# R0190f focused verification

1. Direct-pixel DQA contract test added.
2. Superseded R0188/R0190 tests updated so old nearest-reference behavior cannot silently return.
3. Focused DQA/chart regression suite: 21 passed.
4. Python compilation of dqa_focus_alignment_service.py passed.
5. Active build identity synchronized to R0190f; historical comments/docs intentionally retain their original release labels.
