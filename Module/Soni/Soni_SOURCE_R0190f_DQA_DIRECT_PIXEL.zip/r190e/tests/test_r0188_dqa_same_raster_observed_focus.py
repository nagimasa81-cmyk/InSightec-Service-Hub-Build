"""Historical R0188 regression, superseded by the stricter R0190f direct-pixel contract."""
from types import SimpleNamespace
from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService

def test_missing_exact_pair_is_fail_closed(monkeypatch,tmp_path):
    svc=DqaFocusAlignmentService(); pkg=SimpleNamespace(workspace=tmp_path,sonications=[])
    monkeypatch.setattr(svc,'is_dqa',lambda _p: True)
    monkeypatch.setattr(svc,'_summary_focal_ras',lambda _p:{})
    monkeypatch.setattr(svc,'_dqa_common_locate_focal_ras',lambda _p:(None,[],None))
    monkeypatch.setattr(svc,'_observed_dqa_focus_by_orientation',lambda _p,_f:({},['no thermal focus']))
    monkeypatch.setattr(svc,'_dqa_reference_geometry',lambda _p:{'evidence':[],'axial_candidates':[],'sagittal_candidates':[]})
    r=svc.analyze_series(pkg)
    assert r.excluded_reason is not None
    assert r.x_mm is None and r.y_mm is None and r.z_mm is None
    assert r.calculator_contract == 'R0190f'

def test_planned_focalras_is_not_displacement_zero_point():
    from pathlib import Path
    text=(Path(__file__).resolve().parents[1]/'src/services/dqa_focus_alignment_service.py').read_text()
    block=text.split('def analyze_series',1)[1].split('def clear_cache',1)[0]
    assert '_series_fixed_focus_ras' not in block
    assert 'registered_focal[0]-ref_xyz[0]' not in block
    assert "axial['hotspot_pixel']" in block
    assert "sagittal['hotspot_pixel']" in block
