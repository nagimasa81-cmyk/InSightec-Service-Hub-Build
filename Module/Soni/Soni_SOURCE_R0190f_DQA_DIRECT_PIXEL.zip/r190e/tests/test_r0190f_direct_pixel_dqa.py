from pathlib import Path
S=(Path(__file__).parents[1]/'src/services/dqa_focus_alignment_service.py').read_text(encoding='utf-8')
def test_r0190f_xy_are_direct_exact_pair_pixels():
    a=S[S.index("        axial=observed.get('Axial')"):S.index("        sagittal=observed.get('Sagittal')")]
    assert "fp=axial['hotspot_pixel']" in a
    assert "candidate=axial.get('paired_reference')" in a
    assert '_nearest_reference_candidate' not in a
    assert "x=float(np.asarray(pixel_delta,float)[0])" in a
    b=S[S.index("        sagittal=observed.get('Sagittal')"):S.index('        if x is None and y is None and z is None:')]
    assert "fp=sagittal['hotspot_pixel']" in b
    assert "ap=candidate['phantom_ap_center_pixel']" in b
    assert '_nearest_reference_candidate' not in b
    assert "y=float(np.asarray(ap_delta,float)[1])" in b
    assert 'ref_ras[2]+=20.0' in b

def test_r0190f_contract():
    assert 'calculator_contract: str = "R0190f"' in S
    assert 'r0190f::series::' in S
