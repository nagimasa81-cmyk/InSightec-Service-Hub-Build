from __future__ import annotations

import threading
from pathlib import Path

import numpy as np

from src.services.spectrum_dump_import_service import SpectrumDumpImportService
from src.services.hydrophone_replay_service import HydrophoneReplayService
from src.services.standalone_cavitation_service import StandaloneCavitationService
from src.services.cavitation_control_timeline_service import CavitationControlTimelineService


class SpectrumEvidenceRepository:
    """Study-scoped shared Spectrum decode/evidence cache.

    Multiple background consumers (preload, Summary, Treatment Outcome) can ask for
    the same Sonication.  Exactly one decoder owns a Sonication at a time; peers wait
    for that result rather than performing duplicate FFT/vendor-rule work.
    """

    def __init__(self, hydrophone_service=None, acoustic_control_service=None, standalone_service=None):
        self.hydrophone = hydrophone_service or HydrophoneReplayService()
        self.acoustic = acoustic_control_service
        self.standalone = standalone_service or StandaloneCavitationService()
        self._condition = threading.Condition()
        self._workspace_token = None
        self._mapping = None
        self._replays = {}
        self._standalone = {}
        self._errors = {}
        self._inflight = set()
        self._secondary = {}
        self._secondary_errors = {}
        self._secondary_inflight = set()

    @staticmethod
    def _token(package) -> str:
        try:
            return str(Path(package.workspace).resolve())
        except Exception:
            return str(getattr(package, "workspace", ""))

    def clear(self) -> None:
        with self._condition:
            self._workspace_token = None
            self._mapping = None
            self._replays.clear(); self._standalone.clear(); self._errors.clear(); self._inflight.clear()
            self._secondary.clear(); self._secondary_errors.clear(); self._secondary_inflight.clear()
            self._condition.notify_all()

    def _ensure_workspace(self, package) -> str:
        token = self._token(package)
        with self._condition:
            if self._workspace_token != token:
                self._workspace_token = token
                self._mapping = None
                self._replays.clear(); self._standalone.clear(); self._errors.clear(); self._inflight.clear()
                self._secondary.clear(); self._secondary_errors.clear(); self._secondary_inflight.clear()
        return token

    def candidate_mapping(self, package):
        self._ensure_workspace(package)
        with self._condition:
            if self._mapping is not None:
                return self._mapping
            # Hold the repository lock while building the index. Discovery is worker-
            # thread owned, and serializing it prevents duplicate recursive scans.
            importer = SpectrumDumpImportService()
            workspace = Path(package.workspace)
            inventory = list(getattr(package, "cpc_spectrum_files", []) or [])
            candidates = importer.discover_from_files(workspace, inventory)
            if not any(getattr(c, "family", "") == "CPC Spectrum" for c in candidates):
                candidates = importer.discover(workspace)
            self._mapping = importer.map_candidates_to_sonications(candidates, list(getattr(package, "sonications", []) or []))
            return self._mapping

    def _configure_replay(self, package, index: int, son, replay, candidate):
        replay.sonication_index = int(index)
        preferred = getattr(getattr(replay, "vendor_history_validation", None), "log_session_index", None)
        if preferred is None and candidate is not None:
            preferred = getattr(candidate, "acquisition_session_index", None)
        if preferred is None:
            preferred = getattr(son, "canonical_acquisition_session_index", None)
        replay.acquisition_session_index = int(preferred) if preferred is not None else None
        if self.acoustic is not None:
            replay.sonication_time_zero_offset_s = self.acoustic.sonication_time_zero_offset(
                Path(package.workspace), int(index), replay.acquisition_session_index
            )
        # R0116zzg13: establish the physical controller-cycle origin once and
        # share it with every Spectrum/CI consumer.  This is deliberately parsed
        # without MR/CPC time transforms: the first observed ExPowerRatio cycle is
        # the authoritative Sonication power t=0 in Acquisition_Brain.
        try:
            control = CavitationControlTimelineService().parse(
                replay.source_fft or replay.source_raw or Path(package.workspace),
                None, replay.acquisition_session_index, None, None,
                0.0, 0.0, 0.0, 0.0, None, None, replay.acquisition_interval_s,
            )
            valid_cycles = [int(c) for c in np.asarray(getattr(control, "actual_power_cycles", []), dtype=int).tolist() if int(c) >= 0]
            replay.sonication_cycle_zero = valid_cycles[0] if valid_cycles else None
        except Exception:
            replay.sonication_cycle_zero = None
        replay.mr_timeline_duration_s = float(getattr(son, "mr_timeline_duration_s", 0.0) or 0.0)
        replay.mr_sonication_start_s = float(getattr(son, "mr_sonication_start_s", 0.0) or 0.0)
        replay.mr_sonication_end_s = float(getattr(son, "mr_sonication_end_s", 0.0) or 0.0)
        replay.mr_timeline_source = str(getattr(son, "mr_timeline_source", "Unavailable"))
        replay.mr_timeline_confidence = str(getattr(son, "mr_timeline_confidence", "Unknown"))
        return replay

    def replay(self, package, index: int, son=None, progress_callback=None):
        token = self._ensure_workspace(package)
        index = int(index)
        if son is None:
            son = list(getattr(package, "sonications", []) or [])[index]
        with self._condition:
            if index in self._replays:
                return self._replays[index]
            while index in self._inflight:
                self._condition.wait(timeout=0.25)
                if self._workspace_token != token:
                    raise RuntimeError("Spectrum repository study changed during decode")
                if index in self._replays:
                    return self._replays[index]
                if index in self._errors:
                    raise RuntimeError(self._errors[index])
            self._inflight.add(index)
        try:
            candidate = self.candidate_mapping(package).get(index)
            if candidate is None:
                raise RuntimeError(f"No authoritative CPC Spectrum source for Sonication {index+1}.")
            replay = self.hydrophone.build_direct(
                candidate.fft_path, candidate.raw_path,
                progress_callback=progress_callback, include_vendor_validation=True,
            )
            if replay is None or not getattr(replay, "frames", None):
                raise RuntimeError(f"Spectrum decode returned zero frames for Sonication {index+1}.")
            replay = self._configure_replay(package, index, son, replay, candidate)
            with self._condition:
                if self._workspace_token == token:
                    self._replays[index] = replay
                    self._errors.pop(index, None)
            return replay
        except Exception as exc:
            with self._condition:
                if self._workspace_token == token:
                    self._errors[index] = str(exc)
            raise
        finally:
            with self._condition:
                self._inflight.discard(index)
                self._condition.notify_all()

    def standalone_analysis(self, package, index: int, son=None, progress_callback=None):
        token = self._ensure_workspace(package)
        index = int(index)
        with self._condition:
            if index in self._standalone:
                return self._standalone[index]
        replay = self.replay(package, index, son, progress_callback)
        analysis = self.standalone.analyze(replay, "Auto Evidence-First", 6.0)
        with self._condition:
            if self._workspace_token == token:
                self._standalone[index] = analysis
        return analysis

    def cached_replay(self, package, index: int):
        token = self._ensure_workspace(package)
        with self._condition:
            if self._workspace_token != token:
                return None
            return self._replays.get(int(index))
    @staticmethod
    def _replay_key(index: int, replay) -> tuple | None:
        """Stable replay identity across equivalent decode/handoff instances."""
        if replay is None or not getattr(replay, "frames", None):
            return None
        source = getattr(replay, "source_fft", None) or getattr(replay, "source_raw", None)
        try:
            source_key = str(Path(source).resolve()) if source is not None else ""
        except Exception:
            source_key = str(source or "")
        return (int(index), source_key, int(len(replay.frames)))

    @classmethod
    def _payload_matches_replay(cls, payload, index: int, replay) -> bool:
        if payload is None or replay is None:
            return payload is not None and replay is None
        key = cls._replay_key(index, replay)
        cached_key = payload.get("replay_key") if isinstance(payload, dict) else None
        if cached_key is not None:
            try:
                return tuple(cached_key) == tuple(key)
            except Exception:
                return False
        return isinstance(payload, dict) and payload.get("replay_id") == id(replay)

    @staticmethod
    def _secondary_key(index: int, channel: int, analysis_mode: str, candidate_z: float):
        return (int(index), int(channel), str(analysis_mode), round(float(candidate_z), 6))

    @staticmethod
    def _observed_control_timeline(replay):
        validation = getattr(replay, "vendor_control_validation", None)
        predicted_cycles = validation.event_cycles if validation is not None else []
        predicted_ratio = validation.predicted_power_ratio if validation is not None else []
        history_validation = getattr(replay, "vendor_history_validation", None)
        preferred_session = history_validation.log_session_index if history_validation is not None else getattr(replay, "acquisition_session_index", None)
        source_path = replay.source_fft or replay.source_raw
        anchor = next((f for f in getattr(replay, "frames", []) if getattr(f, "acquisition_cycle", None) is not None and getattr(f, "acquisition_time_s", None) is not None), None)
        return CavitationControlTimelineService().parse(
            source_path, getattr(replay, "vendor_profile", None), preferred_session,
            predicted_cycles, predicted_ratio,
            getattr(replay, "sonication_time_zero_offset_s", 0.0),
            getattr(replay, "mr_sonication_start_s", 0.0),
            getattr(replay, "mr_sonication_end_s", 0.0),
            getattr(replay, "mr_timeline_duration_s", 0.0),
            getattr(anchor, "acquisition_cycle", None) if anchor is not None else None,
            getattr(anchor, "acquisition_time_s", None) if anchor is not None else None,
            getattr(replay, "acquisition_interval_s", 0.010),
        )

    def secondary_products(self, package, index: int, channel: int, analysis_mode: str, candidate_z: float, replay=None):
        """Return all derived Spectrum products from one study-scoped cache.

        Spectrogram, Vendor Band Energy and canonical dump-side cavitation analysis
        are produced together so Analyzer tabs cannot disagree about whether the
        same replay is ready. This method is worker-thread only: peer workers may
        wait on the condition, but the GUI thread never calls it.
        """
        token = self._ensure_workspace(package)
        key = self._secondary_key(index, channel, analysis_mode, candidate_z)
        with self._condition:
            cached = self._secondary.get(key)
            # R0116zzg9: secondary products are valid only for the exact replay
            # object that produced them.  The same Sonication key can be decoded
            # again/rebound during Analyzer handoff; returning a payload carrying
            # an old replay_id makes every secondary renderer reject it forever.
            if cached is not None and (replay is None or self._payload_matches_replay(cached, index, replay)):
                return cached
            if cached is not None and replay is not None and not self._payload_matches_replay(cached, index, replay):
                self._secondary.pop(key, None)
                self._secondary_errors.pop(key, None)
            while key in self._secondary_inflight:
                self._condition.wait(timeout=0.25)
                if self._workspace_token != token:
                    raise RuntimeError("Spectrum repository study changed during secondary analysis")
                cached = self._secondary.get(key)
                if cached is not None and (replay is None or self._payload_matches_replay(cached, index, replay)):
                    return cached
                if cached is not None and replay is not None and not self._payload_matches_replay(cached, index, replay):
                    self._secondary.pop(key, None)
                    self._secondary_errors.pop(key, None)
                if key in self._secondary_errors:
                    raise RuntimeError(self._secondary_errors[key])
            self._secondary_inflight.add(key)
        try:
            replay = replay or self.replay(package, int(index))
            if replay is None or not getattr(replay, "frames", None):
                raise RuntimeError(f"Spectrum secondary analysis has no decoded frames for Sonication {int(index)+1}.")
            payload = {
                "replay_id": id(replay),
                "replay_key": self._replay_key(index, replay),
                "channel": int(channel),
                "analysis_mode": str(analysis_mode),
                "candidate_z": float(candidate_z),
            }
            payload["spectrogram"] = self.hydrophone.spectrogram(replay, int(channel))
            resolved = self.standalone.resolved_band_ranges(replay)
            payload["resolved_bands"] = resolved
            energies = {}
            for band_index, values in resolved.items():
                low, high = float(values[0]), float(values[1])
                exact = bool(getattr(replay, "vendor_embedded_band_energy_available", False))
                energies[int(band_index)] = (
                    self.hydrophone.vendor_band_energy(replay, int(band_index)) if exact
                    else self.hydrophone.band_energy(replay, low, high)
                )
            payload["band_energy"] = energies
            # R0117: evidence-only f0/2 sub-harmonic flags per receiver, produced
            # in the same worker-thread pass as the other secondary products.
            try:
                payload["subharmonic_events"] = {
                    int(ch): replay.subharmonic_events(channel=int(ch))
                    for ch in range(int(getattr(replay, "channel_count", 0) or 0))
                }
            except Exception:
                payload["subharmonic_events"] = {}
            payload["cavitation_analysis"] = self.standalone.analyze(replay, str(analysis_mode), float(candidate_z))
            payload["preirradiation_cavitation_summary"] = self.standalone.summarize_preirradiation(
                replay, payload["cavitation_analysis"]
            )
            payload["observed_cavitation_timeline"] = self._observed_control_timeline(replay)
            payload["gap_reconstruction"] = replay.reconstruction_support()
            with self._condition:
                if self._workspace_token == token:
                    self._secondary[key] = payload
                    self._secondary_errors.pop(key, None)
            return payload
        except Exception as exc:
            with self._condition:
                if self._workspace_token == token:
                    self._secondary_errors[key] = str(exc)
            raise
        finally:
            with self._condition:
                self._secondary_inflight.discard(key)
                self._condition.notify_all()

    def cached_secondary_products(self, package, index: int, channel: int, analysis_mode: str, candidate_z: float, replay=None):
        token = self._ensure_workspace(package)
        key = self._secondary_key(index, channel, analysis_mode, candidate_z)
        with self._condition:
            if self._workspace_token != token:
                return None
            payload = self._secondary.get(key)
            if payload is not None and replay is not None and not self._payload_matches_replay(payload, index, replay):
                # Never hand a stale derived-product cache to the GUI.  Remove it
                # so the next worker computes against the authoritative replay.
                self._secondary.pop(key, None)
                self._secondary_errors.pop(key, None)
                return None
            return payload

