from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re
import xml.etree.ElementTree as ET


@dataclass(slots=True)
class PlanningAsset:
    category: str
    path: Path
    role: str
    confidence: float
    notes: str = ""


@dataclass(slots=True)
class PlanningDataSummary:
    assets: list[PlanningAsset] = field(default_factory=list)

    def by_category(self, category: str) -> list[PlanningAsset]:
        return [item for item in self.assets if item.category == category]

    @property
    def counts(self) -> dict[str, int]:
        result: dict[str, int] = {}
        for item in self.assets:
            result[item.category] = result.get(item.category, 0) + 1
        return result


class PlanningDataService:
    """Classify planning/reference resources without treating them as replay frames."""

    _RAW_RE = re.compile(r"^(\d+)-.*-(\d+)\.raw$", re.I)


    def _ct_linked_raws(self, workspace: Path) -> list[tuple[Path, str]]:
        """Resolve CtImage rowset records to exported RAW image files.

        CtImage.xml is a rowset index; it is not pixel data.  The exported pixel
        payload follows <fieldindex>-1-0-<arrayindex>.raw inside SonicationN.
        Only square image records are exposed as Planning CT candidates.
        """
        xml_path = workspace / "CtImage.xml"
        if not xml_path.exists():
            return []
        result=[]
        try:
            root=ET.parse(xml_path).getroot()
            for row in root.iter():
                a=row.attrib
                if not {"fieldindex","sonicationindex","arrayindex"} <= set(a):
                    continue
                try:
                    field=int(a["fieldindex"]); son=int(a["sonicationindex"]); arr=int(a["arrayindex"])
                    sx=int(a.get("imagesize_x","0")); sy=int(a.get("imagesize_y","0"))
                except ValueError:
                    continue
                if sx < 32 or sy < 32 or sx != sy:
                    continue
                folder=next((d for d in workspace.rglob("*") if d.is_dir() and re.fullmatch(fr"sonication[_-]?{son}", d.name, re.I)), None)
                if folder is None:
                    continue
                candidates=[folder/f"{field}-1-0-{arr}.raw", folder/f"{field}-0-0-{arr}.raw"]
                raw=next((x for x in candidates if x.exists()), None)
                if raw is not None:
                    result.append((raw, f"CtImage row: field={field}, sonication={son}, array={arr}, {sx}x{sy}"))
        except (ET.ParseError, OSError):
            return []
        seen=set(); unique=[]
        for raw,note in result:
            if raw not in seen:
                seen.add(raw); unique.append((raw,note))
        return unique

    def discover(self, workspace: Path) -> PlanningDataSummary:
        assets: list[PlanningAsset] = []
        for raw, note in self._ct_linked_raws(workspace):
            assets.append(PlanningAsset("PLANNING_CT", raw, "CT planning image linked by CtImage.xml", 0.96, note))
        son1 = next((p for p in workspace.rglob("*") if p.is_dir() and p.name.lower().replace("_", "") == "sonication1"), None)

        for path in workspace.rglob("*"):
            if not path.is_file():
                continue
            low_name = path.name.lower()
            low_path = str(path).lower().replace("\\", "/")
            category = role = notes = ""
            confidence = 0.0

            if low_name in {"ctimage.xml", "ctvolumedata.xml"}:
                category, role, confidence = "PLANNING_CT", "CT volume metadata used by skull/SDR planning", 1.0
            elif "skullmeasure" in low_name or "bonespot" in low_name or "sdr" in low_name:
                category, role, confidence = "SDR_DATA", "Skull/SDR calculation input or result", 0.95
            elif low_name.startswith("ctmr") or "ctmrregistration" in low_name:
                category, role, confidence = "REGISTRATION_DATA", "CT-to-MR registration", 0.98
            elif low_name.startswith("mrmr") or "mrmrregistration" in low_name:
                category, role, confidence = "REGISTRATION_DATA", "MR-to-MR registration", 0.98
            elif low_name == "mriimageparams.xml" or "mi_params" in low_name or low_name.startswith("miparams"):
                category, role, confidence = "PRE_TREATMENT_MR", "MR acquisition/reference metadata", 0.90
            elif "/sonication1/" in low_path and self._RAW_RE.match(path.name):
                prefix = self._RAW_RE.match(path.name).group(1)
                if prefix not in {"5", "6"}:
                    category, role, confidence = "PRE_TREATMENT_MR", f"Sonication1 non-replay RAW series (prefix {prefix})", 0.85
                    notes = "Kept separate from thermometry/magnitude replay until image semantics are verified."
            elif son1 is not None and path.parent == son1 and path.suffix.lower() in {".rgs", ".txt"} and ("fid" in low_name or "mat" in low_name):
                category, role, confidence = "REGISTRATION_DATA", "Planning registration matrix/fiducials", 0.90

            if category:
                assets.append(PlanningAsset(category, path, role, confidence, notes))

        assets.sort(key=lambda item: (item.category, str(item.path).lower()))
        return PlanningDataSummary(assets)
