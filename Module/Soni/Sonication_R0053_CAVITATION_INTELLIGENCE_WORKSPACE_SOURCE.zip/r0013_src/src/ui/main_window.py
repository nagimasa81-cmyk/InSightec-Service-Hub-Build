from __future__ import annotations

import logging
import re
from pathlib import Path

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import QSettings, Qt, QTimer, QSize, QRectF, QEvent, QObject, QThread, Signal
from PySide6.QtGui import QAction, QImage, QPixmap, QIcon, QCursor, QPainter, QColor, QPen, QBrush, QShortcut, QKeySequence
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QFileDialog, QFrame, QGroupBox, QHeaderView,
    QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QMainWindow,
    QMessageBox, QPushButton, QSlider, QSpinBox, QDoubleSpinBox, QSplitter, QTableWidget, QProgressBar,
    QTableWidgetItem, QTabWidget, QTreeWidget, QTreeWidgetItem, QVBoxLayout,
    QWidget, QDialog, QGridLayout, QToolButton, QMenu, QFormLayout, QScrollArea, QToolTip, QApplication,
)

from src.common.constants import APP_NAME, APP_VERSION, ORGANIZATION
from src.domain.models import SonicationModel
from src.integration.spectrum_provider import SpectrumMsgAnalyzerAdapter
from src.services.discovery_service import DiscoveryService
from src.services.import_service import ImportService
from src.services.replay_service import ReplayService
from src.services.acoustic_control_service import AcousticControlService
from src.services.sonication_channel_service import SonicationChannelService
from src.services.sonication_metadata_service import SonicationMetadataService
from src.services.skull_measures_service import SkullMeasuresService
from src.services.engineering_analysis_service import EngineeringAnalysisService
from src.services.hydrophone_replay_service import HydrophoneReplayService
from src.services.hydrophone_calibration_service import HydrophoneCalibrationService
from src.services.cavitation_visualization_service import CavitationVisualizationService
from src.services.cavitation_control_timeline_service import CavitationControlTimelineService
from src.services.cavitation_likelihood_service import CavitationLikelihoodService
from src.services.cavitation_mr_correlation_service import CavitationMrCorrelationService
from src.services.registration_overlay_service import RegistrationOverlayService
from src.integration.spectrum_provider import SpectrumFrame
from src.core.chart_state import ChartState
from src.core.replay_context import ReplayContext, ReplaySelection
from src.core.replay_snapshot import ReplayFrameSnapshot, ReplaySnapshotProvider
from src.ui.replay_view_coordinator import ReplayViewCoordinator
from src.core.relative_spectrum_renderer import RelativeSpectrumRenderer
from src.core.current_spectrum_renderer import CurrentSpectrumRenderer
from src.core.fus_export_core import FIELD_SEMANTICS, RAW_RE as EXPORT_RAW_RE, decode_spectrum_structure
from src.ui.image_panel import OverlayPanel
from src.ui.diagnostics import DiagnosticsTab
from src.ui.hydrophone_window import EightHydrophoneWindow

LOG = logging.getLogger(__name__)


class PackageLoadWorker(QObject):
    progress = Signal(int, str)
    finished = Signal(object, object, object, object)
    failed = Signal(str)

    def __init__(self, source: Path):
        super().__init__()
        self.source = Path(source)

    def run(self):
        importer = ImportService()
        try:
            self.progress.emit(3, "Opening source...")
            def cb(value, message):
                self.progress.emit(int(value), str(message))
            workspace = importer.open(self.source, progress_callback=cb)
            self.progress.emit(76, "Discovering Sonications and treatment resources...")
            discovery = DiscoveryService()
            package = discovery.discover(self.source, workspace)
            self.progress.emit(94, f"Found {len(package.sonications)} sonication(s); preparing interface...")
            self.finished.emit(self.source, workspace, package, importer.temp_dirs)
        except Exception as exc:
            importer.cleanup()
            self.failed.emit(str(exc))


class ChartHoverPopup(QLabel):
    """Persistent chart-local hover popup that works in packaged Qt builds.

    QToolTip can be suppressed by Windows timing/style behavior when it is
    repeatedly refreshed from a high-frequency pyqtgraph mouse signal. This
    QLabel remains parented to the chart widget and is moved beside the cursor.
    """
    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.setTextFormat(Qt.TextFormat.PlainText)
        self.setStyleSheet(
            "QLabel { background: rgba(18, 22, 30, 235); color: white; "
            "border: 1px solid #8da2b8; border-radius: 4px; padding: 5px 7px; }"
        )
        self.setWordWrap(False)
        self.hide()

    def show_lines(self, lines) -> None:
        text = "\n".join(str(line) for line in lines if str(line))
        if not text:
            self.hide()
            return
        # Only one chart popup is visible at a time; multiple floating labels
        # made the compact laptop view difficult to read.
        window = self.window()
        if window is not None:
            for other in window.findChildren(ChartHoverPopup):
                if other is not self:
                    other.hide()
        self.setText(text)
        self.adjustSize()
        parent = self.parentWidget()
        pos = parent.mapFromGlobal(QCursor.pos())
        # Place the label in the opposite half of the plot so it does not cover
        # the point currently being inspected.
        margin = 6
        x = margin if pos.x() > parent.width()/2 else max(margin, parent.width()-self.width()-margin)
        y = margin if pos.y() > parent.height()/2 else max(margin, parent.height()-self.height()-margin)
        self.move(int(x), int(y))
        self.raise_()
        self.show()


class InfoWindow(QDialog):
    """Non-modal, movable, minimizable information window kept above the replay UI."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Sonication Information")
        self.setWindowFlags(
            Qt.WindowType.Window | Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowCloseButtonHint
        )
        self.setModal(False)
        self.resize(540, 360)
        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["Item", "Value"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout = QVBoxLayout(self)
        layout.addWidget(self.table)

    def update_rows(self, rows):
        self.table.setRowCount(len(rows))
        for r, (key, value) in enumerate(rows):
            self.table.setItem(r, 0, QTableWidgetItem(str(key)))
            self.table.setItem(r, 1, QTableWidgetItem(str(value)))


class DetailWindow(InfoWindow):
    """Reusable single-instance non-modal detail table."""
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(620, 430)


class TransducerMapWidget(QWidget):
    """Workstation-style transducer element map. This is deliberately not a chart."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(650, 520)
        self.data = None
        self.parameter = "Element SDR"
        self.show_enabled = True
        self.show_disabled = True
        self._screen_points = []
        self.setMouseTracking(True)
        self.tooltip = ""
        self.display_max = None
        self.display_min = None
        self.scale_mode = "Adaptive"
        self.gamma = 1.0
        self._lut = [self._interpolate_lut(i / 255.0) for i in range(256)]

    def configure(self, data, parameter, show_enabled, show_disabled, display_min=None, display_max=None, scale_mode="Adaptive", gamma=1.0):
        self.data = data
        self.parameter = parameter
        self.show_enabled = show_enabled
        self.show_disabled = show_disabled
        self.display_min = float(display_min) if display_min is not None else None
        self.display_max = float(display_max) if display_max is not None else None
        self.scale_mode = str(scale_mode or "Adaptive")
        self.gamma = max(0.25, min(4.0, float(gamma)))
        self.update()

    @staticmethod
    def _interpolate_lut(level):
        """Workstation-like SDR LUT: deep blue → cyan → green → yellow → red → magenta."""
        level = max(0.0, min(1.0, float(level)))
        stops = [
            (0.00, (20, 38, 170)),
            (0.16, (20, 82, 222)),
            (0.34, (18, 190, 220)),
            (0.52, (40, 205, 102)),
            (0.68, (205, 220, 42)),
            (0.82, (250, 170, 28)),
            (0.94, (238, 58, 38)),
            (0.985, (232, 40, 120)),
            (1.00, (235, 35, 175)),
        ]
        for (x0,c0),(x1,c1) in zip(stops,stops[1:]):
            if level <= x1:
                t=(level-x0)/(x1-x0) if x1>x0 else 0.0
                return QColor(*[round(a+(b-a)*t) for a,b in zip(c0,c1)])
        return QColor(*stops[-1][1])

    def _color(self, level):
        index = max(0, min(255, int(round(float(level) * 255.0))))
        return self._lut[index]

    def _display_color(self, normalized_level):
        """Return the exact colour used by both elements and the legend.

        Keeping gamma and LUT lookup in one function prevents the element map
        and colour bar from drifting apart when display settings change.
        """
        level = min(1.0, max(0.0, float(normalized_level)))
        return self._color(level ** self.gamma)

    def _draw_color_bar(self, painter, bar, lo, hi):
        """Draw a true scan-line gradient from the shared display LUT.

        A one-pixel-wide QImage stretched by QPainter was rendered as a nearly
        solid colour on some Windows/Qt raster backends.  Drawing every screen
        row explicitly avoids that backend-specific scaling path and guarantees
        that the legend matches the element colours exactly.
        """
        top = int(round(bar.top()))
        bottom = int(round(bar.bottom()))
        left = int(round(bar.left()))
        right = int(round(bar.right()))
        height = max(1, bottom - top)
        for y in range(top, bottom + 1):
            normalized = 1.0 - ((y - top) / height)
            painter.setPen(QPen(self._display_color(normalized), 1.0))
            painter.drawLine(left, y, right, y)

        painter.setPen(QPen(QColor(70, 70, 68), 1.0))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(bar)
        painter.setPen(QColor(45, 45, 43))
        for i in range(11):
            normalized = i / 10.0
            y = bar.bottom() - normalized * bar.height()
            value = lo + normalized * (hi - lo)
            painter.drawLine(int(bar.right()), int(y), int(bar.right() + 5), int(y))
            painter.drawText(
                QRectF(bar.right() + 8, y - 9, 48, 18),
                Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
                f"{value:.2f}",
            )

    @staticmethod
    def _robust_limits(values, requested_lo, requested_hi, mode):
        finite = np.asarray(values, dtype=float)
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            return 0.0, 1.0
        mode = str(mode or "Adaptive")
        if mode == "Manual":
            lo = float(requested_lo) if requested_lo is not None else float(np.min(finite))
            hi = float(requested_hi) if requested_hi is not None else float(np.max(finite))
        elif mode == "Normalized":
            lo, hi = float(np.percentile(finite, 2.0)), float(np.percentile(finite, 98.0))
        else:  # Adaptive: preserve physical values but suppress isolated extremes.
            lo, hi = float(np.percentile(finite, 1.0)), float(np.percentile(finite, 99.0))
        if not np.isfinite(lo): lo = float(np.min(finite))
        if not np.isfinite(hi): hi = float(np.max(finite))
        if hi <= lo:
            hi = lo + max(abs(lo) * 1e-6, 1e-6)
        return lo, hi

    @staticmethod
    def _ring_radii(xs, ys, cx, cy):
        radii = np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2)
        if radii.size < 8:
            return []
        ordered = np.sort(radii)
        gaps = np.diff(ordered)
        threshold = max(float(np.median(gaps) * 5.0), float((ordered[-1] - ordered[0]) / 80.0))
        split = np.where(gaps > threshold)[0] + 1
        groups = np.split(ordered, split)
        centers = [float(np.median(g)) for g in groups if len(g) >= 3]
        # Avoid drawing every element row as a ring; retain the major radial bands only.
        if len(centers) > 8:
            idx = np.linspace(0, len(centers) - 1, 6).round().astype(int)
            centers = [centers[i] for i in sorted(set(idx.tolist()))]
        return centers

    @staticmethod
    def _sector_angles(xs, ys, cx, cy):
        angles = np.mod(np.arctan2(ys - cy, xs - cx), 2 * np.pi)
        if angles.size < 12:
            return []
        ordered = np.sort(angles)
        wrapped = np.concatenate([ordered, [ordered[0] + 2 * np.pi]])
        gaps = np.diff(wrapped)
        # The six physical sector gaps are the largest angular gaps in the actual cloud.
        count = min(6, len(gaps))
        candidates = np.argsort(gaps)[-count:]
        return sorted(float((wrapped[i] + gaps[i] / 2.0) % (2 * np.pi)) for i in candidates)

    def paintEvent(self, _event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        # The treatment workstation uses a neutral light canvas around the element field.
        painter.fillRect(self.rect(), QColor(226, 226, 224))
        self._screen_points = []
        if not self.data or not self.data.elements:
            painter.setPen(QColor(45, 45, 45))
            msg = self.data.error if self.data and self.data.error else "No SkullMeasures data"
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, msg)
            return

        rows = []
        for el in self.data.elements:
            if el.enabled and not self.show_enabled:
                continue
            if not el.enabled and not self.show_disabled:
                continue
            x = el.values.get("Element X", float("nan"))
            y = el.values.get("Element Y", float("nan"))
            value = el.values.get(self.parameter, float("nan"))
            if np.isfinite(x) and np.isfinite(y):
                rows.append((el, float(x), float(y), float(value)))
        if not rows:
            painter.setPen(QColor(45, 45, 45))
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "No elements match the display filters")
            return

        vals = np.asarray([r[3] for r in rows if np.isfinite(r[3])], float)
        lo, hi = self._robust_limits(vals, self.display_min, self.display_max, self.scale_mode)
        if self.parameter == "Element SDR" and self.scale_mode != "Manual":
            lo, hi = 0.0, 1.0

        # Reserve a compact lower-right strip for the vertical colour legend.
        map_rect = QRectF(26, 18, max(120, self.width() - 150), max(120, self.height() - 42))
        xs = np.asarray([r[1] for r in rows], float)
        ys = np.asarray([r[2] for r in rows], float)
        xmin, xmax = float(xs.min()), float(xs.max())
        ymin, ymax = float(ys.min()), float(ys.max())
        span = max(xmax - xmin, ymax - ymin, 1.0)
        scale = min(map_rect.width(), map_rect.height()) / span * 0.94
        cx, cy = (xmin + xmax) / 2.0, (ymin + ymax) / 2.0
        sx, sy = map_rect.center().x(), map_rect.center().y()

        # Estimate element pitch from the real coordinate cloud, then size the markers
        # to match the dense dot field of the treatment workstation.
        nearest = []
        if len(rows) > 1:
            sample = np.column_stack((xs, ys))
            stride = max(1, len(sample) // 180)
            for pt in sample[::stride]:
                d2 = np.sum((sample - pt) ** 2, axis=1)
                d2[d2 == 0] = np.inf
                nearest.append(float(np.sqrt(np.min(d2))))
        pitch = float(np.median(nearest)) if nearest else span / 40.0
        radius = max(1.8, min(4.4, pitch * scale * 0.31))

        # Geometry-derived guides: use the real radial bands and physical sector gaps.
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(QColor(178, 178, 174), 0.65))
        ring_radii = self._ring_radii(xs, ys, cx, cy)
        for physical_radius in ring_radii:
            rr = physical_radius * scale
            painter.drawEllipse(map_rect.center(), rr, rr)
        outer_physical = float(np.max(np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2)))
        outer = outer_physical * scale
        painter.setPen(QPen(QColor(190, 190, 186), 0.55))
        for angle in self._sector_angles(xs, ys, cx, cy):
            x2 = sx + np.cos(angle) * outer
            y2 = sy - np.sin(angle) * outer
            painter.drawLine(int(sx), int(sy), int(x2), int(y2))

        finite_rows = [r for r in rows if np.isfinite(r[3]) and r[0].enabled]
        max_element = max(finite_rows, key=lambda r: r[3]) if finite_rows else None
        for el, x, y, value in rows:
            px = sx + (x - cx) * scale
            py = sy - (y - cy) * scale
            radial_fraction = min(1.0, max(0.0, np.hypot(x - cx, y - cy) / max(outer_physical, 1e-9)))
            point_radius = radius * (1.12 - 0.24 * radial_fraction)
            if el.enabled:
                level = (value - lo) / (hi - lo) if np.isfinite(value) else 0.0
                level = min(1.0, max(0.0, level))
                color = self._display_color(level)
            else:
                color = QColor(145, 145, 142)
            painter.setPen(QPen(QColor(95, 95, 92), 0.30))
            painter.setBrush(QBrush(color))
            painter.drawEllipse(QRectF(px - point_radius, py - point_radius, 2 * point_radius, 2 * point_radius))
            self._screen_points.append((px, py, point_radius, el, value))

            # Workstation-like hot-element locator: a compact magenta square over max SDR.
            if max_element is not None and el.number == max_element[0].number:
                painter.setPen(QPen(QColor(245, 210, 235), 0.9))
                painter.setBrush(QBrush(QColor(236, 22, 166)))
                side = max(4.0, radius * 1.55)
                painter.drawRect(QRectF(px - side / 2, py - side / 2, side, side))

        # Vertical workstation-style colour scale.
        bar_h = min(260.0, max(150.0, self.height() * 0.46))
        bar = QRectF(self.width() - 77, self.height() - bar_h - 48, 22, bar_h)
        self._draw_color_bar(painter, bar, lo, hi)

        # Small selector/value boxes mimic the reference console without pretending to
        # reproduce proprietary controls.
        badge = QRectF(bar.left() - 3, bar.top() - 34, bar.width() + 8, 25)
        painter.setPen(QPen(QColor(95, 95, 90), 1.0))
        painter.setBrush(QBrush(QColor(245, 230, 205)))
        painter.drawRect(badge)
        painter.drawText(badge, Qt.AlignmentFlag.AlignCenter, "1")
        zero_badge = QRectF(bar.left() - 3, bar.bottom() + 8, bar.width() + 8, 25)
        painter.drawRect(zero_badge)
        painter.drawText(zero_badge, Qt.AlignmentFlag.AlignCenter, f"{lo:.0f}")

        painter.setPen(QColor(45, 45, 43))
        painter.drawText(QRectF(8, 8, 190, 24), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                         self.parameter)
    def mouseMoveEvent(self, event):
        x,y=event.position().x(),event.position().y()
        hit=None
        for px,py,r,el,value in self._screen_points:
            if (px-x)**2+(py-y)**2 <= (r+4)**2:
                hit=(el,value); break
        if hit:
            el,value=hit
            self.setToolTip(f"Element {el.number}\n{self.parameter}: {value:.5g}\nEnabled: {'Yes' if el.enabled else 'No'}\nFailure reason: {el.failure_reason}")
        else:
            self.setToolTip("")
        super().mouseMoveEvent(event)


class XDWindow(QDialog):
    """SkullMeasures transducer element map with automatic parameter updates."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("XD - Skull Element Map — RC2-R0016")
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowStaysOnTopHint |
                            Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowMaximizeButtonHint |
                            Qt.WindowType.WindowCloseButtonHint)
        self.setModal(False)
        self.resize(920, 720)
        self.data = None
        self.parameter = QComboBox()
        self.parameter.addItems(list(SkullMeasuresService.PARAMETERS.keys()))
        self.parameter.setCurrentText("Element SDR")
        self.show_enabled = QCheckBox("Enable Elements"); self.show_enabled.setChecked(True)
        self.show_disabled = QCheckBox("Disable Elements"); self.show_disabled.setChecked(True)
        self.scale_mode = QComboBox(); self.scale_mode.addItems(["Adaptive", "Manual", "Normalized"]); self.scale_mode.setCurrentText("Adaptive")
        self.gamma = QDoubleSpinBox(); self.gamma.setDecimals(2); self.gamma.setRange(0.25, 4.0); self.gamma.setSingleStep(0.05); self.gamma.setValue(1.15); self.gamma.setKeyboardTracking(False)
        self.scale_min = QDoubleSpinBox(); self.scale_min.setDecimals(3); self.scale_min.setRange(-999999.0,999999.0); self.scale_min.setKeyboardTracking(False)
        self.scale_max = QDoubleSpinBox()
        self.scale_max.setDecimals(3); self.scale_max.setRange(0.001, 999999.0); self.scale_max.setValue(1.0)
        self.scale_max.setKeyboardTracking(False); self.scale_max.setToolTip("Upper value of the colour scale")
        self.source_label = QLabel("No SkullMeasures data")
        self.source_label.setWordWrap(True)
        self.summary_label = QLabel("Elements: -")
        self.map = TransducerMapWidget(self)
        self.parameter.currentTextChanged.connect(self._redraw)
        self.show_enabled.toggled.connect(self._redraw)
        self.show_disabled.toggled.connect(self._redraw)
        self.scale_mode.currentTextChanged.connect(self._redraw)
        self.gamma.valueChanged.connect(self._redraw)
        self.scale_min.valueChanged.connect(self._redraw)
        self.scale_max.valueChanged.connect(self._redraw)
        controls=QHBoxLayout()
        controls.addWidget(QLabel("Parameter")); controls.addWidget(self.parameter,1)
        controls.addWidget(QLabel("Scale")); controls.addWidget(self.scale_mode)
        controls.addWidget(QLabel("Min")); controls.addWidget(self.scale_min)
        controls.addWidget(QLabel("Max")); controls.addWidget(self.scale_max)
        controls.addWidget(QLabel("Gamma")); controls.addWidget(self.gamma)
        controls.addWidget(self.show_enabled); controls.addWidget(self.show_disabled)
        layout=QVBoxLayout(self)
        layout.addLayout(controls); layout.addWidget(self.source_label)
        layout.addWidget(self.map,1); layout.addWidget(self.summary_label)

    def set_data(self, data):
        self.data=data
        if data and data.source:
            self.source_label.setText(f"Source: {data.source.name}")
        else:
            self.source_label.setText(data.error if data else "SkullMeasures log not found")
        if data and data.elements:
            values=[el.values.get(self.parameter.currentText(), float("nan")) for el in data.elements]
            values=np.asarray(values,float); values=values[np.isfinite(values)]
            if values.size:
                self.scale_min.blockSignals(True); self.scale_min.setValue(float(np.nanmin(values))); self.scale_min.blockSignals(False)
                self.scale_max.blockSignals(True); self.scale_max.setValue(float(np.nanmax(values))); self.scale_max.blockSignals(False)
        self._redraw()

    def _redraw(self, *_):
        self.map.configure(self.data,self.parameter.currentText(),self.show_enabled.isChecked(),self.show_disabled.isChecked(),self.scale_min.value(),self.scale_max.value(),self.scale_mode.currentText(),self.gamma.value())
        if not self.data or not self.data.elements:
            self.summary_label.setText("Elements: 0")
            return
        enabled=sum(1 for e in self.data.elements if e.enabled)
        vals=[e.values.get(self.parameter.currentText(),float("nan")) for e in self.data.elements]
        finite=np.asarray([v for v in vals if np.isfinite(v)],float)
        value_text=f"{float(np.min(finite)):.4g} to {float(np.max(finite)):.4g}" if finite.size else "Unavailable"
        self.summary_label.setText(f"{self.parameter.currentText()}: {value_text}    Scale: {self.scale_mode.currentText()}    Gamma: {self.gamma.value():.2f}    Elements: {len(self.data.elements)}    On: {enabled}    Off: {len(self.data.elements)-enabled}")


class HoldInfoButton(QPushButton):
    """Shows a temporary popup only while the right mouse button is held."""
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.popup = QLabel()
        self.popup.setWindowFlags(Qt.WindowType.ToolTip)
        self.popup.setStyleSheet("QLabel { background:#152536; color:white; border:1px solid #4c789d; padding:10px; }")

    def set_popup_text(self, text):
        self.popup.setText(text)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.RightButton:
            self.popup.adjustSize()
            self.popup.move(QCursor.pos())
            self.popup.show()
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.RightButton:
            self.popup.hide()
            event.accept()
            return
        super().mouseReleaseEvent(event)



class ChartPopup(QDialog):
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowCloseButtonHint)
        self.setModal(False); self.resize(1000,650)
        self.plot = pg.PlotWidget(title=title); self.plot.showGrid(x=True,y=True,alpha=.2)
        self.hover_series = []
        self.hover_text = pg.TextItem(anchor=(0, 1), color="#ffffff", fill=pg.mkBrush(0, 0, 0, 210))
        self.hover_text.setZValue(100); self.hover_text.hide(); self.plot.addItem(self.hover_text)
        self.hover_proxy = pg.SignalProxy(self.plot.scene().sigMouseMoved, rateLimit=45, slot=self._hovered)
        layout=QVBoxLayout(self); layout.addWidget(self.plot)

    def set_hover_series(self, series):
        """series: [(label, x-array, y-array, unit), ...]."""
        self.hover_series = series or []
        if not self.hover_series:
            self.hover_text.hide()

    def _hovered(self, event):
        scene_pos = event[0] if isinstance(event, (tuple, list)) else event
        if not self.hover_series or not self.plot.sceneBoundingRect().contains(scene_pos):
            self.hover_text.hide(); return
        point = self.plot.plotItem.vb.mapSceneToView(scene_pos)
        lines=[]; best_x=None
        for label, x_values, y_values, unit in self.hover_series:
            x=np.asarray(x_values,float); y=np.asarray(y_values,float)
            valid=np.isfinite(x)&np.isfinite(y)
            if not valid.any(): continue
            xv=x[valid]; yv=y[valid]; i=int(np.argmin(np.abs(xv-point.x())))
            if best_x is None: best_x=float(xv[i]); lines.append(f"{best_x:.2f} sec")
            lines.append(f"{label}: {float(yv[i]):.2f}{unit}")
        if not lines:
            self.hover_text.hide(); return
        self.hover_text.setText("\n".join(lines)); self.hover_text.setPos(point.x(),point.y()); self.hover_text.show()


class MainWindow(QMainWindow):
    """FUS workstation-inspired Sonication-folder replay UI.

    The RC1 replay UI deliberately prioritizes replay-first behavior. The
    partially developed acoustic-analysis controls remain available on the
    Analysis tab, but they no longer reduce the size of the replay image.
    """

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} - {APP_VERSION}")
        self.resize(1760, 1040)
        self.setMinimumSize(1180, 720)
        self.setAcceptDrops(True)

        self.settings = QSettings(ORGANIZATION, APP_NAME)
        self.importer = ImportService()
        self.discovery = DiscoveryService()
        self.replay = ReplayService()
        self.registration_overlay_service = RegistrationOverlayService()
        self.registration_overlay_enabled = False
        self._active_planning_asset = None
        self._active_planning_array = None
        self.acoustic_control_service = AcousticControlService()
        self.package = None
        self.current: SonicationModel | None = None
        self.frame_index = 0
        # Runtime render diagnostics.  These counters deliberately live in the
        # real GUI path (not only tests) so packaged EXEs can prove that a click
        # or arrow reached the image renderer.
        self._render_serial = 0
        self._last_render_signature = None
        self.replay_context = ReplayContext(self)
        self.replay_views = ReplayViewCoordinator(self.replay_context)
        self.snapshot_provider = ReplaySnapshotProvider(
            self.replay.frame, self._index_to_seconds, self._map_replay_to_data
        )
        # R0010: RC1 direct rendering is the authoritative runtime path.
        # Do not register the removed RC2 callback; doing so caused the packaged
        # EXE to fail in MainWindow.__init__ before the window could appear.
        self.max_temperature_trend: list[float] = []
        self.mean_temperature_trend: list[float] = []
        self.delta_trend: list[float] = []
        self.temperature_display_mode = "Absolute Temperature"
        self.spectrum_channels: dict[str, list] = {}
        self.chart_state = ChartState()
        self.cpc_enabled = self.chart_state.cpc_enabled
        self.sonication_channel_service = SonicationChannelService()
        self.metadata_service = SonicationMetadataService()
        self.skull_measures_service = SkullMeasuresService()
        self.engineering_analysis_service = EngineeringAnalysisService()
        self.current_engineering_analysis = None
        self.hydrophone_replay_service = HydrophoneReplayService()
        self.hydrophone_calibration_service = HydrophoneCalibrationService()
        self.cavitation_service = CavitationVisualizationService()
        self.cavitation_control_timeline_service = CavitationControlTimelineService()
        self.cavitation_likelihood_service = CavitationLikelihoodService()
        self.cavitation_mr_correlation_service = CavitationMrCorrelationService()
        self.default_cavitation_mr_correlation = None
        self.hydrophone_calibration = None
        self.hydrophone_window = None
        self.current_metadata = None
        self._displayed_plane_override = None
        self._cavitation_trend = None
        self.default_cpc_replay = None
        self.default_cavitation_timeline = None
        self.default_cavitation_likelihood = None
        self.relative_spectrum_renderer = RelativeSpectrumRenderer()
        self.current_spectrum_renderer = CurrentSpectrumRenderer()
        self._active_spectrum_channel = "CH0"
        self._channel_colors = {
            "CH0":"#ff3b30", "CH1":"#ff9500", "CH2":"#ffd60a", "CH3":"#9ef01a",
            "CH4":"#30d158", "CH5":"#32d7ff", "CH6":"#0a84ff", "CH7":"#bf5af2",
        }
        self.spectrum_provider = SpectrumMsgAnalyzerAdapter()
        self._spectrum_frame = None
        self._spectrum_status = "No SpectrumMsg"
        self.sonication_index = -1
        self.cursor_temperature_trend: list[float] = []
        self._overlay_session_view = None
        self._overlay_session_levels = None
        self._restore_overlay_session = False

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.next_frame)
        # R0014: vendor-workstation replay behavior.  In this mode the charts
        # reveal only acquired data, the thumbnail rows follow the live frame,
        # and playback stops at the end instead of wrapping silently.
        self.workstation_replay_enabled = True
        self._workstation_phase = "Ready"
        self._package_load_thread = None
        self._package_load_worker = None
        self._selection_generation = 0
        self._load_progress_hide_timer = QTimer(self)
        self._load_progress_hide_timer.setSingleShot(True)
        self._load_progress_hide_timer.timeout.connect(lambda: self._set_load_progress(None, ""))

        pg.setConfigOption("background", "k")
        pg.setConfigOption("foreground", "w")

        self._build_actions()
        self._build_ui()
        self._install_navigation_shortcuts()
        QApplication.instance().installEventFilter(self)
        self._restore()

    def _install_navigation_shortcuts(self):
        """Make replay navigation work regardless of which child widget owns focus.

        Qt child controls such as tables, tabs and spin boxes can consume arrow-key
        events before MainWindow.keyPressEvent sees them. WindowWithChildrenShortcut
        keeps the replay navigation consistent across the entire tool.
        """
        self._nav_shortcuts = []
        bindings = [
            (Qt.Key.Key_Left, self.previous_frame),
            (Qt.Key.Key_Up, self.previous_frame),
            (Qt.Key.Key_Right, self.next_frame),
            (Qt.Key.Key_Down, self.next_frame),
            (Qt.Key.Key_PageUp, lambda: self._change_sonication(-1)),
            (Qt.Key.Key_PageDown, lambda: self._change_sonication(1)),
        ]
        for key, slot in bindings:
            shortcut = QShortcut(QKeySequence(key), self)
            shortcut.setContext(Qt.ShortcutContext.WindowShortcut)
            shortcut.activated.connect(slot)
            self._nav_shortcuts.append(shortcut)

    def eventFilter(self, obj, event):
        # Global replay navigation: tables, combo boxes, spin boxes and plots often
        # consume arrow keys before QMainWindow.keyPressEvent. Intercept them at
        # the application level while this window is active.
        if event.type() == QEvent.Type.KeyPress:
            active = QApplication.activeWindow()
            belongs = active is self or (active is not None and self.isAncestorOf(active))
            if belongs and event.modifiers() == Qt.KeyboardModifier.NoModifier:
                key = event.key()
                if key in (Qt.Key.Key_Up, Qt.Key.Key_Left):
                    self.previous_frame(); event.accept(); return True
                if key in (Qt.Key.Key_Down, Qt.Key.Key_Right):
                    self.next_frame(); event.accept(); return True
                if key == Qt.Key.Key_PageUp:
                    self._change_sonication(-1); event.accept(); return True
                if key == Qt.Key.Key_PageDown:
                    self._change_sonication(1); event.accept(); return True
        return super().eventFilter(obj, event)

    # ------------------------------------------------------------------ UI
    def _build_actions(self):
        menu = self.menuBar().addMenu("&File")
        open_zip = QAction("Open ZIP...", self)
        open_zip.triggered.connect(self.open_zip)
        menu.addAction(open_zip)
        open_folder = QAction("Open Folder...", self)
        open_folder.triggered.connect(self.open_folder)
        menu.addAction(open_folder)

        toolbar = self.addToolBar("Main")
        toolbar.setObjectName("MainToolbar")
        toolbar.setMovable(False)
        toolbar.addAction(open_zip)
        toolbar.addAction(open_folder)
        toolbar.addSeparator()
        self.open_hydrophone_action = QAction("Spectrum Dump Analyzer", self)
        self.open_hydrophone_action.setToolTip("Open Spectrum dump analyzer; accepts Export ZIP, folder, or Spectrum file")
        self.open_hydrophone_action.triggered.connect(self._open_hydrophone_window)
        toolbar.addAction(self.open_hydrophone_action)
        self.open_cavitation_intelligence_action = QAction("Cavitation Intelligence", self)
        self.open_cavitation_intelligence_action.setToolTip("Open the Replay cavitation evidence workspace")
        self.open_cavitation_intelligence_action.triggered.connect(self._open_cavitation_intelligence)
        toolbar.addAction(self.open_cavitation_intelligence_action)

    def _build_ui(self):
        self.tabs = QTabWidget()
        self.replay_tab = self._build_replay_tab()
        self.tabs.addTab(self.replay_tab, "Replay")
        self.cavitation_intelligence_tab = self._build_cavitation_intelligence_tab()
        self.tabs.addTab(self.cavitation_intelligence_tab, "Cavitation Intelligence")
        self.tabs.addTab(self._build_analysis_tab(), "Analysis (preserved)")
        self.tabs.addTab(self._build_planning_tab(), "Planning / Reference")
        self.tabs.addTab(self._build_export_status_tab(), "Export / Replay Status")
        self.tabs.addTab(self._build_thermometry_data_tab(), "Thermometry Data")
        self.tabs.addTab(self._build_elements_skull_tab(), "Elements & Skull")
        self.tabs.addTab(self._build_comparison_tab(), "Comparison")
        self.tabs.addTab(self._build_engineering_analysis_tab(), "Engineering Analysis")
        self.diagnostics_tab = DiagnosticsTab(self)
        self.diagnostics_tab.sonicationRequested.connect(self._select_sonication_index)
        self.tabs.addTab(self.diagnostics_tab, "Diagnostics")
        self.setCentralWidget(self.tabs)
        self.load_progress_label = QLabel("")
        self.load_progress_bar = QProgressBar()
        self.load_progress_bar.setRange(0, 100)
        self.load_progress_bar.setTextVisible(True)
        self.load_progress_bar.setFixedWidth(220)
        self.load_progress_label.hide(); self.load_progress_bar.hide()
        self.statusBar().addPermanentWidget(self.load_progress_label)
        self.statusBar().addPermanentWidget(self.load_progress_bar)
        self.statusBar().showMessage("Ready")


    def _open_cavitation_intelligence(self) -> None:
        """Open the dedicated cavitation workspace without changing Replay state."""
        if hasattr(self, "tabs") and hasattr(self, "cavitation_intelligence_tab"):
            self.tabs.setCurrentWidget(self.cavitation_intelligence_tab)
        self._update_cavitation_intelligence_page()

    def _build_cavitation_intelligence_tab(self) -> QWidget:
        page = QWidget()
        root = QVBoxLayout(page)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)

        header = QHBoxLayout()
        title = QLabel("Cavitation Intelligence")
        title.setObjectName("SectionTitle")
        header.addWidget(title)
        self.ci_summary = QLabel("Load a Sonication to begin")
        self.ci_summary.setObjectName("CurrentValue")
        self.ci_summary.setWordWrap(True)
        header.addWidget(self.ci_summary, 1)
        back = QPushButton("Back to Replay")
        back.clicked.connect(lambda: self.tabs.setCurrentWidget(self.replay_tab) if hasattr(self, "replay_tab") else None)
        header.addWidget(back)
        analyzer = QPushButton("Open Spectrum Dump Analyzer")
        analyzer.clicked.connect(self._open_hydrophone_window)
        header.addWidget(analyzer)
        root.addLayout(header)

        # The workflow strip makes the evidence chain explicit instead of hiding
        # the interpretation across unrelated tabs.
        chain = QGridLayout(); chain.setHorizontalSpacing(5); chain.setVerticalSpacing(2)
        self.ci_chain_labels = {}
        steps = [
            ("Event", "Event"), ("RCV", "Receiver"), ("Band", "Band / Energy"),
            ("MR", "MR Signal"), ("Location", "Probable Location"),
            ("Skull", "Skull Class"), ("Power", "Power Response"),
        ]
        for col,(key,caption) in enumerate(steps):
            grid_col=col*2
            cap=QLabel(caption); cap.setAlignment(Qt.AlignmentFlag.AlignCenter)
            val=QLabel("--"); val.setAlignment(Qt.AlignmentFlag.AlignCenter); val.setWordWrap(True)
            val.setObjectName("CurrentValue")
            chain.addWidget(cap,0,grid_col); chain.addWidget(val,1,grid_col)
            self.ci_chain_labels[key]=val
            if col < len(steps)-1:
                arrow=QLabel("→"); arrow.setAlignment(Qt.AlignmentFlag.AlignCenter)
                chain.addWidget(arrow,1,grid_col+1)
        chain_box=QGroupBox("Evidence chain — Time → RCV → Band → MR → Location → Skull → Power")
        cb=QVBoxLayout(chain_box); cb.addLayout(chain)
        root.addWidget(chain_box)

        plots = QSplitter(Qt.Orientation.Horizontal)
        self.ci_likelihood_plot = pg.PlotWidget(); self.ci_likelihood_plot.setAspectLocked(True)
        self.ci_likelihood_plot.hideAxis("left"); self.ci_likelihood_plot.hideAxis("bottom")
        self.ci_likelihood_plot.setMouseEnabled(x=False,y=False)
        self.ci_likelihood_image = pg.ImageItem(axisOrder="row-major"); self.ci_likelihood_plot.addItem(self.ci_likelihood_image)
        self.ci_mr_plot = pg.PlotWidget(); self.ci_mr_plot.setAspectLocked(True)
        self.ci_mr_plot.hideAxis("left"); self.ci_mr_plot.hideAxis("bottom")
        self.ci_mr_plot.setMouseEnabled(x=False,y=False)
        self.ci_mr_image = pg.ImageItem(axisOrder="row-major"); self.ci_mr_plot.addItem(self.ci_mr_image)
        left_box=QGroupBox("RCV contribution → probable cavitation region"); ll=QVBoxLayout(left_box); ll.addWidget(self.ci_likelihood_plot)
        right_box=QGroupBox("MR magnitude signal-loss correlation"); rr=QVBoxLayout(right_box); rr.addWidget(self.ci_mr_plot)
        plots.addWidget(left_box); plots.addWidget(right_box); plots.setSizes([520,520])
        plots.setStretchFactor(0,1); plots.setStretchFactor(1,1)
        root.addWidget(plots, 1)

        self.ci_event_table = QTableWidget(0, 8)
        self.ci_event_table.setHorizontalHeaderLabels(["Time", "State", "Rule", "RCV", "Weighted", "Threshold", "Power", "Evidence"])
        self.ci_event_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.ci_event_table.horizontalHeader().setStretchLastSection(True)
        self.ci_event_table.setMaximumHeight(170)
        self.ci_event_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.ci_event_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        root.addWidget(self.ci_event_table)

        note = QLabel("Observed = acquisition/control log evidence. Reconstructed = SpectrumDumps + INI rules. "
                      "Location is a probability region; skull classification remains indeterminate until a registered CT skull boundary is available.")
        note.setWordWrap(True)
        root.addWidget(note)
        return page

    def _draw_ci_likelihood(self, result) -> None:
        if not hasattr(self, "ci_likelihood_plot"):
            return
        self.ci_likelihood_plot.clear(); self.ci_likelihood_plot.addItem(self.ci_likelihood_image)
        if result is None or np.asarray(result.likelihood_map).size == 0:
            self.ci_likelihood_image.setImage(np.empty((0,0))); return
        arr=np.asarray(result.likelihood_map,float)
        self.ci_likelihood_image.setImage(arr,autoLevels=False,levels=(0,1))
        self.ci_likelihood_image.setRect(QRectF(-1.05,-1.05,2.10,2.10))
        theta=np.linspace(0,2*np.pi,160)
        self.ci_likelihood_plot.plot(np.cos(theta),np.sin(theta),pen=pg.mkPen("#aaaaaa",width=1))
        pos=np.asarray(result.hydrophone_positions,float)
        for ch in range(min(8,len(pos))):
            dominant=(result.dominant_channel is not None and ch==result.dominant_channel)
            active=float(result.per_channel_scores[ch])>0.01
            brush="#f72585" if dominant else "#ffd166" if active else "#4cc9f0"
            self.ci_likelihood_plot.plot([pos[ch,0]],[pos[ch,1]],pen=None,symbol="o",symbolSize=11 if dominant else 7,symbolBrush=brush)
            label=pg.TextItem(f"RCV{ch}",color="#ffffff",anchor=(0.5,1.3)); label.setPos(pos[ch,0],pos[ch,1]); self.ci_likelihood_plot.addItem(label)
        self.ci_likelihood_plot.plot([0],[0],pen=None,symbol="+",symbolSize=12,symbolPen=pg.mkPen("#ffffff",width=2))
        if result.centroid_xy is not None:
            self.ci_likelihood_plot.plot([result.centroid_xy[0]],[result.centroid_xy[1]],pen=None,symbol="x",symbolSize=12,symbolPen=pg.mkPen("#06d6a0",width=2))

    def _draw_ci_mr(self, result) -> None:
        if not hasattr(self,"ci_mr_plot"):
            return
        self.ci_mr_plot.clear(); self.ci_mr_plot.addItem(self.ci_mr_image)
        if result is None or np.asarray(result.correlated_map).size==0:
            self.ci_mr_image.setImage(np.empty((0,0))); return
        arr=np.asarray(result.correlated_map,float)
        maxv=float(np.nanmax(arr)) if np.isfinite(arr).any() else 0.0
        self.ci_mr_image.setImage(arr,autoLevels=False,levels=(0,max(maxv,1e-6)))
        h,w=arr.shape; self.ci_mr_image.setRect(QRectF(0,0,w,h))
        if result.loss_centroid_xy is not None:
            nx,ny=result.loss_centroid_xy; x=(nx+1)*0.5*(w-1); y=(1-ny)*0.5*(h-1)
            self.ci_mr_plot.plot([x],[y],pen=None,symbol="x",symbolSize=12,symbolPen=pg.mkPen("#f72585",width=2))
        self.ci_mr_plot.setRange(xRange=(0,w),yRange=(0,h),padding=0.01)

    def _update_cavitation_intelligence_page(self) -> None:
        if not hasattr(self,"ci_summary"):
            return
        if not self.current:
            self.ci_summary.setText("Load a Sonication to begin")
            return
        result=getattr(self,"default_cavitation_likelihood",None)
        corr=getattr(self,"default_cavitation_mr_correlation",None)
        replay=self.default_cpc_replay
        replay_time=self._index_to_seconds(self.frame_index,self.current.replay_frame_count) if self.current else 0.0
        event=self._nearest_observed_cavitation_event(replay_time, tolerance_s=0.25)
        self.ci_summary.setText(f"Sonication {self.sonication_index+1} · Replay {replay_time:.3f} s · synchronized cavitation evidence")
        dom=getattr(result,"dominant_channel",None) if result is not None else None
        self.ci_chain_labels["RCV"].setText(f"RCV{dom}" if dom is not None else "--")
        if event is not None:
            family=str(getattr(event,"family","Observed")); ri=getattr(event,"rule_index",None)
            self.ci_chain_labels["Event"].setText(f"{family} R{ri}" if ri is not None else family)
            weighted=getattr(event,"weighted_energy",None); threshold=getattr(event,"threshold",None)
        else:
            self.ci_chain_labels["Event"].setText("No observed event")
            weighted=threshold=None
        band_txt="--"
        if replay is not None and replay.frames:
            idx=self._nearest_cpc_frame_index(replay_time)
            if idx is not None:
                en=np.asarray(getattr(replay.frames[idx],"vendor_band_energies",[]),float)
                if en.shape==(8,4):
                    row=en[dom] if dom is not None else np.nanmax(en,axis=0)
                    band_txt=" · ".join(f"B{i} {v:.4g}" for i,v in enumerate(row))
        self.ci_chain_labels["Band"].setText(band_txt)
        self.ci_chain_labels["MR"].setText(getattr(corr,"summary","No MR correlation") if corr is not None else "No MR correlation")
        if result is not None and result.centroid_xy is not None:
            self.ci_chain_labels["Location"].setText(f"probable ({result.centroid_xy[0]:+.2f}, {result.centroid_xy[1]:+.2f})")
        else:
            self.ci_chain_labels["Location"].setText("--")
        reg_on=bool(getattr(self,"registration_enabled",False))
        self.ci_chain_labels["Skull"].setText("Registered CT available · classification pending" if reg_on else "Indeterminate")
        power_txt="--"
        if event is not None:
            pr=getattr(event,"power_ratio",None)
            res=getattr(event,"result","")
            if pr is not None: power_txt=f"{float(pr):.3f}"
            if res: power_txt += f" · {res}"
        self.ci_chain_labels["Power"].setText(power_txt)
        self._draw_ci_likelihood(result); self._draw_ci_mr(corr)

        self.ci_event_table.setRowCount(0)
        timeline=self.default_cavitation_timeline
        if timeline is not None:
            events=list(getattr(timeline,"events",[]) or [])
            near=[]
            for ev in events:
                t=getattr(ev,"timestamp_s",None)
                if t is None: continue
                if abs(float(t)-replay_time) <= 1.0: near.append(ev)
            if not near and events:
                near=sorted(events,key=lambda ev: abs(float(getattr(ev,"timestamp_s",1e9))-replay_time))[:8]
            for ev in near[:12]:
                r=self.ci_event_table.rowCount(); self.ci_event_table.insertRow(r)
                vals=[
                    f"{float(getattr(ev,'timestamp_s',0.0)):.3f}",
                    str(getattr(ev,'family','')),
                    str(getattr(ev,'rule_index','')),
                    f"RCV{getattr(ev,'dominant_channel','--')}" if getattr(ev,'dominant_channel',None) is not None else "--",
                    f"{float(getattr(ev,'weighted_energy',np.nan)):.5g}" if getattr(ev,'weighted_energy',None) is not None else "--",
                    f"{float(getattr(ev,'threshold',np.nan)):.5g}" if getattr(ev,'threshold',None) is not None else "--",
                    f"{float(getattr(ev,'power_ratio',np.nan)):.3f}" if getattr(ev,'power_ratio',None) is not None else "--",
                    str(getattr(ev,'evidence','Observed')),
                ]
                for c,v in enumerate(vals): self.ci_event_table.setItem(r,c,QTableWidgetItem(v))

    def _build_export_status_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        note = QLabel(
            "Best-effort replay never rejects a PARTIAL sonication. Available streams remain enabled; "
            "missing or degraded assets are listed below with their functional impact."
        )
        note.setWordWrap(True); layout.addWidget(note)
        detail = QLabel("* Container ch bytes is frame_size/channel_count arithmetic from the validated header. It does not claim that SpectrumMsg channel FFT payload boundaries are fully decoded.")
        detail.setWordWrap(True); layout.addWidget(detail)
        self.export_status_summary = QLabel("No Export loaded")
        self.export_status_summary.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(self.export_status_summary)
        self.capability_table = QTableWidget(0, 5)
        self.capability_table.setHorizontalHeaderLabels(["Capability", "State", "Replay behavior", "Reason", "Evidence"])
        self.capability_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.capability_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.capability_table, 1)
        self.spectrum_structure_table = QTableWidget(0, 8)
        self.spectrum_structure_table.setHorizontalHeaderLabels([
            "SpectrumMsg", "Mode", "Frames", "Frame bytes", "Channels", "Header bytes", "Container ch bytes*", "Confidence"
        ])
        self.spectrum_structure_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.spectrum_structure_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.spectrum_structure_table, 1)
        return page

    def _build_thermometry_data_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        self.thermometry_status_label = QLabel("No Sonication selected")
        self.thermometry_status_label.setWordWrap(True); layout.addWidget(self.thermometry_status_label)
        self.thermometry_field_table = QTableWidget(0, 5)
        self.thermometry_field_table.setHorizontalHeaderLabels(["Field", "Semantic", "Files", "Storage", "Replay use"])
        self.thermometry_field_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.thermometry_field_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.thermometry_field_table, 1)
        return page

    def _build_elements_skull_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        self.elements_skull_label = QLabel("No Sonication selected")
        self.elements_skull_label.setWordWrap(True); layout.addWidget(self.elements_skull_label)
        self.elements_skull_table = QTableWidget(0, 4)
        self.elements_skull_table.setHorizontalHeaderLabels(["Data", "Available", "Source count", "Analysis / limitation"])
        self.elements_skull_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.elements_skull_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.elements_skull_table, 1)
        return page

    def _build_comparison_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        label = QLabel("Treatment-level Sonication comparison. PARTIAL rows remain in the table and are never silently dropped.")
        label.setWordWrap(True); layout.addWidget(label)
        self.comparison_table = QTableWidget(0, 10)
        self.comparison_table.setHorizontalHeaderLabels([
            "Sonication", "Status", "Replay %", "Power W", "Duration s", "Energy J",
            "Temp", "Spectrum", "ACT", "Skull"
        ])
        self.comparison_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.comparison_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.comparison_table.cellDoubleClicked.connect(lambda row, _col: self._select_sonication_index(row))
        layout.addWidget(self.comparison_table, 1)
        return page

    def _build_engineering_analysis_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        intro = QLabel(
            "Evidence-first engineering analysis derived from the Export. Values are source-labelled and do not replace "
            "Workstation Sonication information. Missing streams reduce only the dependent analysis."
        )
        intro.setWordWrap(True); layout.addWidget(intro)
        self.engineering_summary_label = QLabel("No Sonication selected")
        self.engineering_summary_label.setWordWrap(True); layout.addWidget(self.engineering_summary_label)

        self.engineering_tabs = QTabWidget()
        self.engineering_metrics_table = QTableWidget(0, 5)
        self.engineering_metrics_table.setHorizontalHeaderLabels(["Metric", "Value", "Source", "Confidence", "Note"])
        self.engineering_metrics_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.engineering_metrics_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.engineering_tabs.addTab(self.engineering_metrics_table, "Metrics")

        self.dependency_table = QTableWidget(0, 5)
        self.dependency_table.setHorizontalHeaderLabels(["Feature", "State", "Depends on", "Source", "Impact / fallback"])
        self.dependency_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.dependency_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.engineering_tabs.addTab(self.dependency_table, "Dependency Graph")

        def make_detail(headers):
            table = QTableWidget(0, len(headers))
            table.setHorizontalHeaderLabels(headers)
            table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
            table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
            return table
        self.engineering_act_table = make_detail(["ACT metric", "Value", "Evidence / note"])
        self.engineering_skull_table = make_detail(["Skull metric", "Value", "Evidence / note"])
        self.engineering_spectrum_table = make_detail(["Spectrum source", "Structure", "Evidence / note"])
        self.engineering_thermo_table = make_detail(["Thermometry metric", "Value", "Evidence / note"])
        self.engineering_tabs.addTab(self.engineering_act_table, "ACT / Elements")
        self.engineering_tabs.addTab(self.engineering_skull_table, "Skull / SDR")
        self.engineering_tabs.addTab(self.engineering_spectrum_table, "Spectrum Structure")
        self.engineering_tabs.addTab(self.engineering_thermo_table, "Thermometry")
        layout.addWidget(self.engineering_tabs, 1)
        return page

    @staticmethod
    def _fill_three_column_table(table: QTableWidget, rows) -> None:
        table.setRowCount(len(rows))
        for row, values in enumerate(rows):
            for col, value in enumerate(values):
                table.setItem(row, col, QTableWidgetItem(str(value)))

    def _refresh_engineering_analysis(self) -> None:
        if not self.current or not self.package:
            return
        analysis = self.engineering_analysis_service.analyze(
            self.current, self.package.workspace, self.sonication_index + 1
        )
        self.current_engineering_analysis = analysis
        self.engineering_summary_label.setText(
            f"{self.current.name} | {self.current.completeness_status} {self.current.completeness_score}% | "
            f"Workflow: {self.package.workflow_mode} | Thermometry: {self.current.thermometry_mode} | "
            "Replay frequency source: Sonication information when available"
        )
        self.engineering_metrics_table.setRowCount(len(analysis.metrics))
        for row, metric in enumerate(analysis.metrics):
            values = [metric.name, metric.value, metric.source, metric.confidence, metric.note]
            for col, value in enumerate(values):
                self.engineering_metrics_table.setItem(row, col, QTableWidgetItem(str(value)))
        self.dependency_table.setRowCount(len(analysis.dependencies))
        for row, item in enumerate(analysis.dependencies):
            values = [item.feature, item.state, item.depends_on, item.source, item.impact]
            for col, value in enumerate(values):
                self.dependency_table.setItem(row, col, QTableWidgetItem(str(value)))
        self._fill_three_column_table(self.engineering_act_table, analysis.act_rows)
        self._fill_three_column_table(self.engineering_skull_table, analysis.skull_rows)
        self._fill_three_column_table(self.engineering_spectrum_table, analysis.spectrum_rows)
        self._fill_three_column_table(self.engineering_thermo_table, analysis.thermometry_rows)

    @staticmethod
    def _capability_replay_behavior(key: str, cap: dict) -> str:
        if cap.get("available") and not cap.get("degraded"):
            return "Full feature enabled"
        if cap.get("available"):
            return "Best-effort / limited feature enabled"
        return {
            "thermometry": "Replay anatomy/spectrum without temperature overlay",
            "spectrum": "Replay MR/thermal without acoustic spectrum",
            "elements": "Replay without element amplitude/phase analysis",
            "skull": "Replay without skull propagation/heating analysis",
            "motion": "Replay without reference/current 3-plane comparison",
            "dose": "Temperature replay available; dose maps unavailable",
            "registration": "Images remain viewable; fusion geometry unavailable",
            "geometry": "2D replay available; mesh overlays unavailable",
            "planning": "Sonication replay available; planning workspace limited",
        }.get(key, "Feature unavailable")

    def _refresh_export_workspaces(self) -> None:
        if not self.current or not self.package:
            return
        status = self.current.completeness_status
        missing = self.current.missing_required + self.current.missing_optional
        self.export_status_summary.setText(
            f"{self.current.name}: {status} ({self.current.completeness_score}%)  |  "
            f"Workflow: {self.package.workflow_mode}  |  Thermometry: {self.current.thermometry_mode}  |  "
            f"Missing: {', '.join(missing) if missing else 'None'}"
        )
        caps = self.current.capabilities or {}
        self.capability_table.setRowCount(len(caps))
        for row, (key, cap) in enumerate(caps.items()):
            state = "AVAILABLE" if cap.get("available") else "MISSING"
            if cap.get("available") and cap.get("degraded"):
                state = "DEGRADED"
            evidence = cap.get("evidence") or []
            vals = [key, state, self._capability_replay_behavior(key, cap), cap.get("reason", ""), "; ".join(map(str, evidence[:3]))]
            for col, val in enumerate(vals):
                self.capability_table.setItem(row, col, QTableWidgetItem(str(val)))

        structures=[]
        for path in self.current.spectrum_files:
            try:
                structures.append(decode_spectrum_structure(path))
            except Exception:
                continue
        self.spectrum_structure_table.setRowCount(len(structures))
        for row, spec in enumerate(structures):
            vals=[Path(spec.path).name, "Exact" if spec.exact_structure else "Legacy fallback", spec.frame_count, spec.frame_size,
                  spec.channel_count, spec.header_size, spec.bytes_per_channel, spec.format_confidence]
            for col,val in enumerate(vals): self.spectrum_structure_table.setItem(row,col,QTableWidgetItem(str(val)))

        counts = {}
        for path in [f.path for f in self.current.temperature_frames] + [f.path for f in self.current.magnitude_frames] + list(self.current.other_files):
            m = EXPORT_RAW_RE.match(path.name)
            if m:
                fid=int(m.group("field")); counts[fid]=counts.get(fid,0)+1
        thermo_ids=[5,6,23,28,33,2,34]
        self.thermometry_field_table.setRowCount(len(thermo_ids))
        uses={5:"Temperature replay",6:"Anatomy / thermometry magnitude",23:"Dynamic validity mask",28:"37 °C reference",33:"Background mask",2:"Local derived map A",34:"Local derived map B"}
        for row,fid in enumerate(thermo_ids):
            semantic,storage=FIELD_SEMANTICS[fid]
            vals=[fid,semantic,counts.get(fid,0),storage,uses[fid] if counts.get(fid,0) else "Unavailable — other streams still replay"]
            for col,val in enumerate(vals): self.thermometry_field_table.setItem(row,col,QTableWidgetItem(str(val)))
        self.thermometry_status_label.setText(
            f"{self.current.thermometry_mode}. Magnitude={counts.get(6,0)}, Temperature={counts.get(5,0)}. "
            "TMAP and TMAP-ME (Multi Echo) share the same Export field semantics; acquisition mode is reported separately."
        )

        acts=list(self.current.act_files)
        skull_measures=list(self.current.folder.rglob("SkullMeasures*.log"))
        skull_heating=list(self.current.folder.rglob("SkullHeating*.log"))
        meshes=list(self.current.folder.rglob("*.mesh"))
        if not meshes and self.package.workspace != self.current.folder:
            meshes=list(self.package.workspace.rglob("*.mesh"))
        rows=[
            ("ACT / 1024-element control", bool(acts), len(acts), "Amplitude/phase and element-state analysis" if acts else "Element replay unavailable"),
            ("SkullMeasures", bool(skull_measures), len(skull_measures), "Per-element skull path / SDR analysis" if skull_measures else "Skull path metrics unavailable"),
            ("SkullHeating", bool(skull_heating), len(skull_heating), "Predicted skull heating / power distribution" if skull_heating else "Heating prediction unavailable"),
            ("Meshes", bool(meshes), len(meshes), "Skull / sinus / calcification / spot geometry" if meshes else "3D geometry unavailable"),
        ]
        self.elements_skull_table.setRowCount(len(rows))
        for row,vals in enumerate(rows):
            for col,val in enumerate(vals): self.elements_skull_table.setItem(row,col,QTableWidgetItem(str(val)))
        self.elements_skull_label.setText(
            "This workspace separates element control, skull propagation/heating, and mesh geometry so a missing component does not disable the others."
        )

        sons=self.package.sonications
        self.comparison_table.setRowCount(len(sons))
        for row,son in enumerate(sons):
            c=son.capabilities or {}
            def yn(k):
                x=c.get(k,{})
                return "Limited" if x.get("available") and x.get("degraded") else ("Yes" if x.get("available") else "No")
            vals=[son.name,son.completeness_status,son.completeness_score,
                  f"{son.actual_power_w:.1f}" if son.actual_power_w is not None else "-",
                  f"{son.actual_duration_s:.2f}" if son.actual_duration_s is not None else "-",
                  f"{son.actual_energy_j:.1f}" if son.actual_energy_j is not None else "-",
                  yn("thermometry"),yn("spectrum"),yn("elements"),yn("skull")]
            for col,val in enumerate(vals): self.comparison_table.setItem(row,col,QTableWidgetItem(str(val)))

    def _chart_panel(self, title: str, plot: pg.PlotWidget, key: str) -> QWidget:
        panel=QGroupBox(title); lay=QVBoxLayout(panel); lay.setContentsMargins(3,3,3,3); lay.setSpacing(1)
        header=QHBoxLayout(); header.setContentsMargins(0,0,0,0)
        expand=QToolButton(); expand.setText("↗"); expand.setToolTip("Open enlarged chart")
        expand.setFixedSize(20,20); expand.setStyleSheet("QToolButton{padding:0;font-size:10px;}")
        expand.clicked.connect(lambda: self._open_chart_popup(key))
        header.addStretch(1); header.addWidget(expand); lay.addLayout(header); lay.addWidget(plot,1)
        return panel

    def _make_image_strip(self, role: str) -> QListWidget:
        widget = QListWidget()
        widget.setProperty("imageRole", role)
        widget.setViewMode(QListWidget.ViewMode.IconMode)
        widget.setIconSize(QSize(88, 70)); widget.setGridSize(QSize(98, 88))
        widget.setResizeMode(QListWidget.ResizeMode.Adjust)
        widget.setMovement(QListWidget.Movement.Static)
        widget.setFlow(QListWidget.Flow.LeftToRight)
        widget.setWrapping(False)
        widget.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        widget.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        widget.setMaximumHeight(92); widget.setMinimumHeight(86)
        return widget

    def _clear_replay_display(self) -> None:
        """Remove every visual belonging to the previous sonication."""
        self.timer.stop()
        if hasattr(self, "play_btn"): self.play_btn.setText("▶")
        if hasattr(self, "overlay"):
            self.overlay.set_hover_temperature(None)
            self.overlay.set_roi(None, None)
            self.overlay.set_overlay(None, None, fit=False)
        for name in ("planning_frame_list", "anatomy_frame_list", "thermal_frame_list"):
            widget = getattr(self, name, None)
            if widget is not None:
                widget.blockSignals(True); widget.clear(); widget.blockSignals(False)
        for curve_name in ("max_temperature_curve", "mean_temperature_curve", "cursor_temperature_curve", "acoustic_power_curve", "acoustic_score_curve"):
            curve = getattr(self, curve_name, None)
            if curve is not None:
                try: curve.setData([], [])
                except Exception: pass
        if hasattr(self, "spectrum_plot"): self.spectrum_plot.clear()
        if hasattr(self, "frame_label"): self.frame_label.setText("Frame -/-")
        if hasattr(self, "sync_label"): self.sync_label.setText("Loading selected sonication...")
        self._planning_display_arrays = []
        self._planning_assets_all = []
        self._anatomy_row_map = []
        self._thermal_row_map = []
        self._main_image_mode = "thermal"
        self._active_planning_asset = None
        self._active_planning_array = None
        self.registration_overlay_enabled = False
        if hasattr(self, "registration_toggle_btn"):
            self.registration_toggle_btn.blockSignals(True); self.registration_toggle_btn.setChecked(False); self.registration_toggle_btn.setText("Registration OFF"); self.registration_toggle_btn.setEnabled(False); self.registration_toggle_btn.blockSignals(False)

    @staticmethod
    def _decode_planning_image(asset):
        """Decode a planning image with CtImage metadata; never guess CT dtype."""
        path = Path(asset.path)
        try:
            suffix = path.suffix.lower()
            if suffix in {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}:
                image = QImage(str(path))
                if image.isNull(): return None
                image = image.convertToFormat(QImage.Format.Format_Grayscale8)
                ptr = image.bits(); arr = np.frombuffer(ptr, np.uint8, image.width()*image.height())
                return arr.reshape(image.height(), image.width()).astype(np.float32)
            if suffix != ".raw": return None
            width = getattr(asset, "width", None); height = getattr(asset, "height", None)
            dtype_name = getattr(asset, "dtype", None)
            if width and height and dtype_name:
                dtype = np.dtype(dtype_name)
                expected = int(width) * int(height) * dtype.itemsize
                if path.stat().st_size != expected:
                    return None
                values = np.fromfile(path, dtype=dtype).reshape(int(height), int(width)).astype(np.float32)
                finite = values[np.isfinite(values)]
                return values if finite.size and float(np.nanstd(finite)) > 1e-8 else None
            # Non-CT planning MR fallback remains conservative.
            size = path.stat().st_size
            for dtype in (np.dtype('<u2'), np.dtype('<i2'), np.dtype('<f4')):
                count = size // dtype.itemsize; side = int(round(count ** 0.5))
                if side >= 32 and side * side == count:
                    values = np.fromfile(path, dtype=dtype).reshape(side, side).astype(np.float32)
                    finite = values[np.isfinite(values)]
                    if finite.size and float(np.nanstd(finite)) > 1e-8:
                        return values
            return None
        except (OSError, ValueError, TypeError):
            return None

    def _planning_type_changed(self, _text: str) -> None:
        self._rebuild_planning_strip()

    def _planning_category(self, asset) -> str:
        category=str(getattr(asset, "category", "") or "").upper()
        mapping={
            "PLANNING_CT":"Preplanning CT",
            "PREPLANNING_MR_AX":"Preplanning MR Ax",
            "PREPLANNING_MR_SAG":"Preplanning MR Sag",
            "PREPLANNING_MR_COR":"Preplanning MR Cor",
            "PLANNING_MR_AX":"Planning MR Ax",
            "PLANNING_MR_SAG":"Planning MR Sag",
            "PLANNING_MR_COR":"Planning MR Cor",
        }
        if category in mapping:
            return mapping[category]
        text = " ".join(str(getattr(asset, name, "")) for name in ("category", "role", "path")).lower()
        if "ct" in text or "skull" in text:
            return "Preplanning CT"
        if "mr" in text or "mri" in text or "dicom" in text:
            return "Preplanning MR"
        return "Planning Other"

    def _rebuild_planning_strip(self) -> None:
        if not hasattr(self, "planning_frame_list"):
            return
        selected = self.planning_type_combo.currentText() if hasattr(self, "planning_type_combo") else "All Planning"
        self.planning_frame_list.blockSignals(True); self.planning_frame_list.clear()
        self._planning_display_arrays = []
        for asset, array, label, category in getattr(self, "_planning_assets_all", []):
            if selected not in ("", "All Planning") and category != selected:
                continue
            icon = self._array_icon(array) if array is not None else QIcon()
            item = QListWidgetItem(icon, label); item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
            item.setToolTip(f"{getattr(asset, 'role', category)}\n{getattr(asset, 'path', '')}")
            self.planning_frame_list.addItem(item)
            self._planning_display_arrays.append((array, label))
        self.planning_frame_list.blockSignals(False)

    def _first_valid_replay_frame(self) -> int:
        """Return the first frame that can actually render an anatomy image."""
        if not self.current:
            return 0
        count = max(1, int(self.current.replay_frame_count))
        for index in range(count):
            try:
                data = self.replay.frame(self.current, index)
                magnitude = getattr(data, "magnitude", None)
                if magnitude is not None:
                    arr = np.asarray(magnitude, float)
                    finite = arr[np.isfinite(arr)]
                    if finite.size and float(np.nanstd(finite)) > 1e-8:
                        return index
            except Exception:
                continue
        return 0

    def _planning_frame_selected(self, row: int) -> None:
        if row < 0 or row >= len(getattr(self, "_planning_display_arrays", [])): return
        array, label = self._planning_display_arrays[row]
        if array is None:
            self.statusBar().showMessage(f"Planning resource is metadata only: {label}")
            return
        self._main_image_mode = "planning"
        self.overlay.set_hover_temperature(None); self.overlay.set_roi(None, None)
        self.overlay.set_overlay(array, None, fit=True)
        self.frame_label.setText(f"Planning image: {label}")
        self.sync_label.setText("Planning CT / MR selected")

    def _anatomy_frame_selected(self, row: int) -> None:
        if not self.current or row < 0 or not self.current.magnitude_frames: return
        source_row = self._anatomy_row_map[row] if row < len(self._anatomy_row_map) else row
        replay_index = self._map_replay_to_data(source_row, len(self.current.magnitude_frames), self.current.replay_frame_count)
        self._main_image_mode = "anatomy"
        self.set_frame(replay_index, display_mode="anatomy")

    def _thermal_frame_selected(self, row: int) -> None:
        if not self.current or row < 0: return
        source_row = self._thermal_row_map[row] if row < len(self._thermal_row_map) else row
        series_count = max(1, len(self.current.temperature_frames))
        replay_index = self._map_replay_to_data(source_row, series_count, self.current.replay_frame_count)
        self._main_image_mode = "thermal"
        self.set_frame(replay_index, display_mode="thermal")

    def _build_replay_tab(self) -> QWidget:
        # Compact top strip: Sonication number is intentionally not a list.
        self.son_prev_btn = QPushButton("≪")
        self.son_next_btn = QPushButton("≫")
        self.son_number_btn = HoldInfoButton("-")
        self.son_number_btn.setMinimumWidth(64)
        self.son_prev_btn.clicked.connect(lambda: self._change_sonication(-1))
        self.son_next_btn.clicked.connect(lambda: self._change_sonication(1))
        self.info_btn = QPushButton("Info")
        self.mr_btn = QPushButton("MR")
        self.scan_btn = QPushButton("Scan")
        self.xd_btn = QPushButton("XD")
        self.info_btn.clicked.connect(self._show_info_window)
        self.mr_btn.clicked.connect(self._show_mr_window)
        self.scan_btn.clicked.connect(self._show_scan_window)
        self.xd_btn.clicked.connect(self._show_xd_window)
        self.info_window = InfoWindow(self)
        self.mr_window = DetailWindow("MR Information", self)
        self.scan_window = DetailWindow("Scan Protocol Information", self)
        self.xd_window = XDWindow(self)

        top_bar = QHBoxLayout()
        top_bar.addWidget(QLabel("Sonication No."))
        top_bar.addWidget(self.son_prev_btn)
        top_bar.addWidget(self.son_number_btn)
        top_bar.addWidget(self.son_next_btn)
        top_bar.addWidget(QLabel("Right-click and hold for details"))
        top_bar.addStretch(1)

        # Left controls: temperature scale and a true slider for red threshold.
        self.temperature_mode_combo = QComboBox()
        self.temperature_mode_combo.addItems(["Absolute Temperature", "ΔTemperature (Investigation)"])
        self.temperature_mode_combo.currentTextChanged.connect(self._temperature_mode_changed)
        self.range_combo = QComboBox()
        self.range_combo.addItems(["40–60 °C", "35–60 °C", "30–90 °C", "0–60 °C", "Auto"])
        self.range_combo.currentIndexChanged.connect(self._temperature_range_changed)
        self.overlay_opacity = QSlider(Qt.Orientation.Horizontal)
        self.overlay_opacity.setRange(0, 100); self.overlay_opacity.setValue(55)
        self.overlay_opacity.valueChanged.connect(lambda _: self.set_frame(self.frame_index))
        self.threshold_slider = QSlider(Qt.Orientation.Horizontal)
        self.threshold_slider.setRange(30, 90); self.threshold_slider.setValue(48)
        self.threshold_minus = QPushButton("◀"); self.threshold_plus = QPushButton("▶")
        for button in (self.threshold_minus, self.threshold_plus): button.setFixedWidth(28)
        self.threshold_minus.clicked.connect(lambda: self.threshold_slider.setValue(self.threshold_slider.value()-1))
        self.threshold_plus.clicked.connect(lambda: self.threshold_slider.setValue(self.threshold_slider.value()+1))
        self.threshold_value = QLabel("Red starts at 48 °C")
        self.threshold_slider.valueChanged.connect(self._threshold_changed)
        self.baseline_label = QLabel("Temperature source: waiting")
        self.baseline_label.setWordWrap(True); self.baseline_label.setObjectName("CurrentValue")
        self.cursor_temperature_label = QLabel("Cursor Temperature: --")
        self.cursor_temperature_label.setWordWrap(True); self.cursor_temperature_label.setObjectName("CurrentValue")

        # Responsive left information panel.  The previous fixed 190-245 px panel
        # compressed wrapped labels on 125/150% Windows DPI and made Sonication
        # values unreadable.  Keep the content in a scroll area and size rows from
        # the active font instead of relying on fixed label heights.
        left_content = QWidget()
        ll = QVBoxLayout(left_content)
        ll.setContentsMargins(8, 8, 8, 8)
        ll.setSpacing(10)

        display_box = QGroupBox("Temperature Display")
        display_layout = QVBoxLayout(display_box)
        display_layout.setContentsMargins(8, 12, 8, 8)
        display_layout.setSpacing(6)
        display_layout.addWidget(QLabel("Mode")); display_layout.addWidget(self.temperature_mode_combo)
        display_layout.addWidget(QLabel("Overlay opacity")); display_layout.addWidget(self.overlay_opacity)
        display_layout.addWidget(QLabel("Temperature range")); display_layout.addWidget(self.range_combo)
        display_layout.addWidget(QLabel("Red threshold"))
        threshold_row = QHBoxLayout(); threshold_row.setContentsMargins(0,0,0,0); threshold_row.setSpacing(6)
        threshold_row.addWidget(self.threshold_minus); threshold_row.addWidget(self.threshold_slider, 1); threshold_row.addWidget(self.threshold_plus)
        display_layout.addLayout(threshold_row); display_layout.addWidget(self.threshold_value)
        ll.addWidget(display_box)

        roi_box = QGroupBox("Temperature ROI")
        roi_layout = QVBoxLayout(roi_box)
        roi_layout.setContentsMargins(8, 12, 8, 8)
        roi_layout.setSpacing(7)
        self.voxel_label = QLabel("Voxel (ROI): 3 pixels × 3 pixels")
        self.voxel_label.setObjectName("CurrentValue")
        self.voxel_label.setWordWrap(True)
        roi_layout.addWidget(self.voxel_label)
        self.measurement_summary_label = QLabel("ROI is hidden")
        self.measurement_summary_label.setWordWrap(True)
        self.measurement_summary_label.setObjectName("CurrentValue")
        self.measurement_summary_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        roi_layout.addWidget(self.measurement_summary_label)
        measure_row = QHBoxLayout(); measure_row.setSpacing(6)
        self.measure_roi_btn = QPushButton("Show ROI")
        self.copy_measure_btn = QPushButton("Copy")
        self.clear_measure_btn = QPushButton("Clear")
        for button in (self.measure_roi_btn, self.copy_measure_btn, self.clear_measure_btn):
            button.setMinimumHeight(40)
            button.setMinimumWidth(68)
            measure_row.addWidget(button, 1)
        roi_layout.addLayout(measure_row)
        ll.addWidget(roi_box)

        cursor_box = QGroupBox("Cursor Temperature")
        cursor_layout = QVBoxLayout(cursor_box)
        cursor_layout.setContentsMargins(8, 12, 8, 8)
        cursor_layout.setSpacing(6)
        self.cursor_temperature_label.setWordWrap(True)
        self.cursor_temperature_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        cursor_layout.addWidget(self.cursor_temperature_label)
        self.baseline_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        cursor_layout.addWidget(self.baseline_label)
        ll.addWidget(cursor_box)

        self.sonication_summary_box = QGroupBox("Sonication")
        summary_layout = QGridLayout(self.sonication_summary_box)
        summary_layout.setContentsMargins(8, 14, 8, 8)
        summary_layout.setHorizontalSpacing(10)
        summary_layout.setVerticalSpacing(7)
        summary_layout.setColumnStretch(0, 0)
        summary_layout.setColumnStretch(1, 1)
        self.summary_value_labels = {}
        for row, key in enumerate(("Orientation", "Displayed Plane", "Orientation Status", "Frequency Dir", "Target Energy", "Actual Energy", "Target Power", "Actual Power", "Target Duration", "Actual Duration", "Frequency")):
            key_label = QLabel(key)
            key_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
            value_label = QLabel("-")
            value_label.setObjectName("CurrentValue")
            value_label.setWordWrap(True)
            value_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            self.summary_value_labels[key] = value_label
            summary_layout.addWidget(key_label, row, 0)
            summary_layout.addWidget(value_label, row, 1)
        ll.addWidget(self.sonication_summary_box)

        info_buttons = QHBoxLayout(); info_buttons.setSpacing(6)
        for button in (self.info_btn, self.mr_btn, self.scan_btn, self.xd_btn):
            button.setMinimumHeight(42)
            button.setMinimumWidth(58)
            info_buttons.addWidget(button, 1)
        ll.addLayout(info_buttons)
        ll.addStretch(1)

        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setFrameShape(QFrame.Shape.NoFrame)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        left_scroll.setWidget(left_content)
        left_scroll.setMinimumWidth(265)
        left_scroll.setMaximumWidth(340)
        left = left_scroll

        # Dominant workstation image. Click moves the crosshair and updates temperature.
        self.overlay = OverlayPanel("Thermal Replay - Workstation Temperature Map")
        self.overlay.cursorMoved.connect(self._overlay_cursor_moved)
        self.overlay.viewStateChanged.connect(self._capture_overlay_state_debounced)
        self.overlay.levelsChanged.connect(self._capture_overlay_levels)
        self.overlay.measurementChanged.connect(self._overlay_measurement_changed)
        self.measure_roi_btn.clicked.connect(self.overlay.show_measure_roi)
        self.copy_measure_btn.clicked.connect(self.overlay.copy_measurement)
        self.clear_measure_btn.clicked.connect(self._clear_overlay_measurement)
        self._overlay_save_timer=QTimer(self); self._overlay_save_timer.setSingleShot(True); self._overlay_save_timer.timeout.connect(self._save_overlay_state)
        self._fit_overlay_next = True
        self.cursor_x = None; self.cursor_y = None

        # Product-style three independent image rows.  Each row scrolls
        # horizontally and selects what is shown in the main image viewer.
        self.planning_frame_list = self._make_image_strip("planning")
        self.anatomy_frame_list = self._make_image_strip("anatomy")
        self.thermal_frame_list = self._make_image_strip("thermal")
        self.planning_type_combo = QComboBox()
        self.planning_type_combo.setMinimumWidth(135)
        image_row_options = [
            "Preplanning CT",
            "Preplanning MR Ax", "Preplanning MR Sag", "Preplanning MR Cor",
            "Planning MR Ax", "Planning MR Sag", "Planning MR Cor",
            "Treatment MR", "Treatment Thermal", "All images",
        ]
        self.planning_type_combo.addItems(image_row_options)
        self.anatomy_type_combo = QComboBox(); self.anatomy_type_combo.addItems(image_row_options)
        self.thermal_type_combo = QComboBox(); self.thermal_type_combo.addItems(image_row_options)
        self.planning_type_combo.setCurrentText("Planning MR Ax")
        self.anatomy_type_combo.setCurrentText("Treatment MR")
        self.thermal_type_combo.setCurrentText("Treatment Thermal")
        for combo in (self.planning_type_combo,self.anatomy_type_combo,self.thermal_type_combo): combo.setMinimumWidth(135)
        self.planning_type_combo.currentTextChanged.connect(self._planning_reference_type_changed)
        self.anatomy_type_combo.currentTextChanged.connect(self._rebuild_all_image_strips)
        self.thermal_type_combo.currentTextChanged.connect(self._rebuild_all_image_strips)
        # Compatibility alias used by older navigation code.
        self.frame_list = self.thermal_frame_list
        # itemClicked is required because Replay rendering automatically tracks
        # the current thumbnail.  Clicking that already-selected thumbnail does
        # not emit currentRowChanged, which previously made Anatomy/Thermal look
        # dead.  currentRowChanged is retained for keyboard navigation.
        for strip in (self.planning_frame_list, self.anatomy_frame_list, self.thermal_frame_list):
            # itemPressed fires before selection bookkeeping and is the most
            # reliable mouse path in packaged Qt builds. itemActivated keeps
            # keyboard/double-click access. Do not depend on currentRowChanged:
            # the replay renderer changes current rows programmatically.
            strip.itemPressed.connect(lambda item, owner=strip: self._unified_image_item_selected(owner, item))
            strip.itemClicked.connect(lambda item, owner=strip: self._unified_image_item_selected(owner, item))
            strip.itemActivated.connect(lambda item, owner=strip: self._unified_image_item_selected(owner, item))
        navigator_box = QGroupBox("Preplanning / Planning / Treatment Images")
        nav_layout = QGridLayout(navigator_box); nav_layout.setContentsMargins(3,8,3,3); nav_layout.setSpacing(2)
        for row,(label,combo,strip) in enumerate((("Reference",self.planning_type_combo,self.planning_frame_list),("Treatment MR",self.anatomy_type_combo,self.anatomy_frame_list),("Treatment Thermal",self.thermal_type_combo,self.thermal_frame_list))):
            box=QWidget(); bl=QVBoxLayout(box); bl.setContentsMargins(0,0,0,0); bl.setSpacing(2); bl.addWidget(QLabel(label)); bl.addWidget(combo)
            nav_layout.addWidget(box,row,0); nav_layout.addWidget(strip,row,1)
        self.registration_toggle_btn = QPushButton("Registration OFF")
        self.registration_toggle_btn.setCheckable(True)
        self.registration_toggle_btn.setEnabled(False)
        self.registration_toggle_btn.setToolTip("Overlay preplanning CT skull/bone using the treatment-adopted CtMr registration while a preplanning/planning MR image is displayed.")
        self.registration_toggle_btn.toggled.connect(self._registration_toggled)
        nav_layout.addWidget(self.registration_toggle_btn, 3, 0, 1, 2)
        navigator_box.setMinimumHeight(145)
        nav_layout.setColumnStretch(1, 1)
        self._main_image_mode = "thermal"
        self._planning_display_arrays = []

        self.temperature_plot = pg.PlotWidget()
        self.temperature_plot.setLabel("left", "Temperature", units="°C")
        self.temperature_plot.setLabel("bottom", "MR acquisition time", units="sec")
        self.temperature_plot.showGrid(x=True, y=True, alpha=.28)
        self.temperature_plot.setYRange(40, 60, padding=0)
        self.temperature_plot.getAxis("left").setTickSpacing(major=2, minor=1)
        # Workstation-style temperature bands remain behind every curve.
        self.temperature_bands = []
        for low, high, rgba in (
            (40, 44, (70, 105, 150, 35)),
            (44, 48, (70, 145, 120, 35)),
            (48, 52, (205, 170, 35, 38)),
            (52, 56, (220, 105, 25, 42)),
            (56, 60, (190, 30, 30, 46)),
        ):
            band = pg.LinearRegionItem(values=(low, high), orientation="horizontal", movable=False, brush=pg.mkBrush(*rgba), pen=pg.mkPen(None))
            band.setZValue(-20)
            self.temperature_plot.addItem(band)
            self.temperature_bands.append(band)
        self.max_temperature_curve = self.temperature_plot.plot(pen=pg.mkPen("#ff3b30", width=3), name="Max")
        self.mean_temperature_curve = self.temperature_plot.plot(pen=pg.mkPen("#49e36b", width=2.5), name="ROI Average")
        self.cursor_temperature_curve = self.temperature_plot.plot(pen=pg.mkPen("#b98cff", width=1.6, style=Qt.PenStyle.DashLine), name="Cursor")
        self.temperature_cursor = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen("#00bfff", width=1.5))
        self.temperature_plot.addItem(self.temperature_cursor)
        self.temperature_plot.scene().sigMouseClicked.connect(self._temperature_plot_clicked)
        self.temperature_hover_text = pg.TextItem(anchor=(0, 1), color="#ffffff", fill=pg.mkBrush(0, 0, 0, 190))
        self.temperature_hover_text.setZValue(50); self.temperature_hover_text.hide(); self.temperature_plot.addItem(self.temperature_hover_text)
        self.temperature_hover_proxy = pg.SignalProxy(self.temperature_plot.scene().sigMouseMoved, rateLimit=45, slot=self._temperature_plot_hovered)
        self.temperature_hover_popup = ChartHoverPopup(self.temperature_plot)
        self._updating_temperature_range = False
        self.temperature_plot.plotItem.vb.sigRangeChanged.connect(self._temperature_range_changed_by_user)

        self.spectrum_plot = pg.PlotWidget()
        self.spectrum_plot.setLabel("left", "Relative Amplitude")
        self.spectrum_plot.setLabel("bottom", "Frequency", units="MHz")
        self.spectrum_plot.showGrid(x=True, y=True, alpha=.24)
        self.spectrum_plot.setXRange(0.2, 0.8, padding=0)
        self.spectrum_plot.setYRange(0.0, 4.0, padding=0)
        self.spectrum_hover_text = pg.TextItem(anchor=(0, 1), color="#ffffff", fill=pg.mkBrush(0, 0, 0, 205))
        self.spectrum_hover_text.setZValue(100); self.spectrum_hover_text.hide(); self.spectrum_plot.addItem(self.spectrum_hover_text)
        self.spectrum_hover_series = []
        self.spectrum_hover_proxy = pg.SignalProxy(self.spectrum_plot.scene().sigMouseMoved, rateLimit=45, slot=self._spectrum_plot_hovered)
        self.spectrum_hover_popup = ChartHoverPopup(self.spectrum_plot)
        self.spectrum_plot.plotItem.vb.sigRangeChanged.connect(lambda *_: self._remember_chart_range("spectrum", self.spectrum_plot))

        self.graph_split = QSplitter(Qt.Orientation.Horizontal)
        self.temperature_panel=self._chart_panel("Temperature Trend (ROI)",self.temperature_plot,"temperature")
        self.spectrum_panel=self._chart_panel("Acoustic Spectrum (Current Frame)",self.spectrum_plot,"spectrum")
        self.graph_split.addWidget(self.temperature_panel); self.graph_split.addWidget(self.spectrum_panel)
        # Temperature is the primary replay trend; spectrum is contextual data
        # for the selected frame.  C0045 incorrectly made spectrum wider (3:4).
        self.graph_split.setStretchFactor(0, 65); self.graph_split.setStretchFactor(1, 35)
        self.graph_split.setChildrenCollapsible(False)
        self.temperature_panel.setMinimumWidth(420)
        self.spectrum_panel.setMinimumWidth(280)
        self.graph_split.setSizes([650, 350])
        self.graph_split.setMinimumHeight(155)

        # FUS workstation-style Power and Score trend. Current values are drawn inside the chart.
        self.acoustic_control_plot = pg.PlotWidget()
        self.acoustic_control_plot.setMinimumHeight(150)
        self.acoustic_control_plot.setLabel("left", "Power / Score", units="%")
        self.acoustic_control_plot.setLabel("bottom", "MR acquisition time", units="sec")
        self.acoustic_control_plot.setYRange(0.0, 110.0, padding=0)
        self.acoustic_control_plot.showGrid(x=True, y=True, alpha=.22)
        self.acoustic_power_curve = self.acoustic_control_plot.plot(pen=pg.mkPen("#58f26a", width=2.3), name="Power %")
        self.acoustic_score_curve = self.acoustic_control_plot.plot(pen=pg.mkPen("#ff9d22", width=2.3), name="Score")
        self.acoustic_control_cursor = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen("#00bfff", width=1.3))
        self.acoustic_control_plot.addItem(self.acoustic_control_cursor)
        self.acoustic_control_plot.scene().sigMouseClicked.connect(self._acoustic_plot_clicked)
        self.acoustic_hover_text = pg.TextItem(anchor=(0, 1), color="#ffffff", fill=pg.mkBrush(0, 0, 0, 205))
        self.acoustic_hover_text.setZValue(80); self.acoustic_hover_text.hide(); self.acoustic_control_plot.addItem(self.acoustic_hover_text)
        self.acoustic_hover_proxy = pg.SignalProxy(self.acoustic_control_plot.scene().sigMouseMoved, rateLimit=45, slot=self._acoustic_plot_hovered)
        self.acoustic_hover_popup = ChartHoverPopup(self.acoustic_control_plot)
        self.acoustic_power_text = pg.TextItem("Power: --", color="#58f26a", anchor=(1, 1), fill=pg.mkBrush(0, 0, 0, 150))
        self.acoustic_score_text = pg.TextItem("Score: --", color="#ff9d22", anchor=(1, 0), fill=pg.mkBrush(0, 0, 0, 150))
        self.acoustic_power_text.setZValue(20); self.acoustic_score_text.setZValue(20)
        self.acoustic_control_plot.addItem(self.acoustic_power_text); self.acoustic_control_plot.addItem(self.acoustic_score_text)
        self.acoustic_power_value = QLabel("Unavailable")
        self.acoustic_score_value = QLabel("Unavailable")
        self.acoustic_cavitation_value = QLabel("Unavailable")
        for w in (self.acoustic_power_value, self.acoustic_score_value, self.acoustic_cavitation_value):
            w.hide()

        self.waterfall_replay_plot = pg.PlotWidget()
        self.waterfall_replay_plot.setLabel("left", "Frequency", units="MHz")
        self.waterfall_replay_plot.setLabel("bottom", "Replay time", units="sec")
        self.waterfall_replay_plot.setTitle("")
        self.waterfall_replay_image = pg.ImageItem(axisOrder="row-major")
        self.waterfall_replay_plot.addItem(self.waterfall_replay_image)
        waterfall_colors = np.array([[0,0,25,255],[0,55,170,255],[0,210,255,255],[255,235,0,255],[255,75,0,255],[255,255,255,255]], dtype=np.ubyte)
        waterfall_positions = np.linspace(0.0, 1.0, len(waterfall_colors))
        self.waterfall_replay_image.setLookupTable(pg.ColorMap(waterfall_positions, waterfall_colors).getLookupTable(0.0, 1.0, 256))
        self.waterfall_replay_cursor = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen("w", width=1.5))
        self.waterfall_replay_plot.addItem(self.waterfall_replay_cursor)

        # Compact CH popup: single, multiple, or all channels without wasting chart height.
        self.channel_actions = {}
        self.channel_button = QToolButton()
        self.channel_button.setText("CH")
        self.channel_button.setToolTip("Select one, multiple, or all hydrophone channels")
        self.channel_button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.channel_menu = QMenu(self.channel_button)
        self.all_channels_action = QAction("All Channels", self.channel_menu)
        self.all_channels_action.setCheckable(True); self.all_channels_action.setChecked(False)
        self.all_channels_action.toggled.connect(self._toggle_all_channels)
        self.channel_menu.addAction(self.all_channels_action)
        self.channel_menu.addSeparator()
        self.channel_button.setMenu(self.channel_menu)
        self.current_spectrum_label = QLabel("Spectrum: waiting")
        self.current_spectrum_label.setObjectName("CurrentValue")
        self.current_spectrum_label.setMaximumHeight(20)
        spectrum_layout = self.spectrum_panel.layout()
        channel_row = QHBoxLayout(); channel_row.setContentsMargins(0,0,0,0); channel_row.setSpacing(4)
        self.cpc_button = QPushButton("CPC OFF")
        self.cpc_button.setCheckable(True)
        self.cpc_button.setChecked(False)
        self.cpc_button.setToolTip("Switch the main Acoustic Spectrum between Sonication SpectrumMsg and mapped CPC 8CH FFT data")
        self.cpc_button.show()
        self.cpc_button.toggled.connect(self._cpc_toggled)
        self.spectrum_mode_combo = QComboBox()
        self.spectrum_mode_combo.addItems(["Current", "Average", "Max Hold", "Baseline Δ"])
        self.spectrum_mode_combo.setCurrentText(self.chart_state.spectrum_mode)
        self.spectrum_mode_combo.setToolTip("Current frame, score-window average, max hold, or fixed-baseline delta")
        self.spectrum_mode_combo.currentTextChanged.connect(self._spectrum_mode_changed)
        channel_row.addWidget(self.channel_button); channel_row.addWidget(self.cpc_button); channel_row.addWidget(self.spectrum_mode_combo); channel_row.addWidget(self.current_spectrum_label); channel_row.addStretch(1)
        spectrum_layout.insertLayout(0, channel_row)
        acoustic_box = self._chart_panel("Power % / Score", self.acoustic_control_plot, "acoustic")
        self.waterfall_panel = self._chart_panel("Relative Acoustic Spectrum vs Replay Time", self.waterfall_replay_plot, "waterfall")

        # R0038: Cavitation intelligence is part of the default Sonication Replay.
        # It is decoded in the background from the mapped CPC SpectrumDumps and
        # Acquisition_Brain evidence; the main acoustic spectrum source does not
        # need to be switched to CPC for this panel to work.
        self.replay_cavitation_box = QGroupBox("Cavitation Intelligence")
        cav_layout = QVBoxLayout(self.replay_cavitation_box)
        cav_layout.setContentsMargins(7, 12, 7, 7); cav_layout.setSpacing(4)
        self.replay_cavitation_status = QLabel("Waiting for Sonication data")
        self.replay_cavitation_status.setWordWrap(True); self.replay_cavitation_status.setObjectName("CurrentValue")
        cav_layout.addWidget(self.replay_cavitation_status)
        band_row = QHBoxLayout(); band_row.setSpacing(6)
        self.replay_band_labels = []
        for band in range(4):
            label = QLabel(f"B{band}: --")
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            label.setToolTip(f"Vendor cavitation Band{band} energy at the nearest CPC FFT snapshot")
            self.replay_band_labels.append(label); band_row.addWidget(label, 1)
        cav_layout.addLayout(band_row)
        self.replay_cavitation_tabs = QTabWidget()
        self.replay_cavitation_tabs.setDocumentMode(True)
        self.replay_cavitation_map = pg.PlotWidget()
        self.replay_cavitation_map.setMinimumHeight(105)
        self.replay_cavitation_map.setAspectLocked(True)
        self.replay_cavitation_map.hideAxis("left"); self.replay_cavitation_map.hideAxis("bottom")
        self.replay_cavitation_map.setMouseEnabled(x=False, y=False)
        self.replay_cavitation_image = pg.ImageItem(axisOrder="row-major")
        self.replay_cavitation_map.addItem(self.replay_cavitation_image)
        self.replay_cavitation_tabs.addTab(self.replay_cavitation_map, "RCV likelihood")
        self.replay_mr_corr_plot = pg.PlotWidget()
        self.replay_mr_corr_plot.setMinimumHeight(105)
        self.replay_mr_corr_plot.setAspectLocked(True)
        self.replay_mr_corr_plot.hideAxis("left"); self.replay_mr_corr_plot.hideAxis("bottom")
        self.replay_mr_corr_plot.setMouseEnabled(x=False, y=False)
        self.replay_mr_corr_image = pg.ImageItem(axisOrder="row-major")
        self.replay_mr_corr_plot.addItem(self.replay_mr_corr_image)
        self.replay_cavitation_tabs.addTab(self.replay_mr_corr_plot, "MR correlation")
        cav_layout.addWidget(self.replay_cavitation_tabs, 1)
        self.replay_cavitation_detail = QLabel("Dominant RCV: -- | MR correlation: --")
        self.replay_cavitation_detail.setWordWrap(True)
        cav_layout.addWidget(self.replay_cavitation_detail)

        right = QWidget(); rl = QVBoxLayout(right); rl.setContentsMargins(0,0,0,0)
        # A vertical splitter guarantees a real plotting viewport for Power/Score
        # on 1366x768 laptops; fixed minimums previously exceeded screen height.
        self.waterfall_panel.setVisible(False)
        self.lower_split=QSplitter(Qt.Orientation.Horizontal)
        self.lower_split.addWidget(acoustic_box); self.lower_split.addWidget(self.replay_cavitation_box); self.lower_split.setMinimumHeight(150)
        self.lower_split.setStretchFactor(0, 3); self.lower_split.setStretchFactor(1, 2)
        self.lower_split.setSizes([560, 360])
        self.right_vertical_split = QSplitter(Qt.Orientation.Vertical)
        self.right_vertical_split.addWidget(navigator_box)
        self.right_vertical_split.addWidget(self.graph_split)
        self.right_vertical_split.addWidget(self.lower_split)
        for i in range(3): self.right_vertical_split.setCollapsible(i, False)
        self.right_vertical_split.setStretchFactor(0, 3)
        self.right_vertical_split.setStretchFactor(1, 4)
        self.right_vertical_split.setStretchFactor(2, 4)
        self.right_vertical_split.setSizes([190, 230, 210])
        rl.addWidget(self.right_vertical_split,1)

        self.top_split = QSplitter(Qt.Orientation.Horizontal)
        self.top_split.addWidget(left); self.top_split.addWidget(self.overlay); self.top_split.addWidget(right)
        self.top_split.setSizes([285,735,760]); self.top_split.setStretchFactor(1,5); self.top_split.setStretchFactor(2,4)

        self.first_btn=QPushButton("|<"); self.prev_btn=QPushButton("<"); self.play_btn=QPushButton("▶")
        self.next_btn=QPushButton(">"); self.last_btn=QPushButton(">|")
        self.first_btn.clicked.connect(lambda:self.set_frame(0)); self.prev_btn.clicked.connect(self.previous_frame)
        self.play_btn.clicked.connect(self.toggle_play); self.next_btn.clicked.connect(self.next_frame)
        self.last_btn.clicked.connect(lambda:self.set_frame(max(0,self.current.replay_frame_count-1) if self.current else 0))
        self.speed=QComboBox()
        self.speed.addItem("0.25×", 0.25)
        self.speed.addItem("0.5×", 0.5)
        self.speed.addItem("1× Actual", 1.0)
        self.speed.addItem("2×", 2.0)
        self.speed.addItem("4×", 4.0)
        self.speed.addItem("8×", 8.0)
        self.speed.setCurrentIndex(2)
        self.speed.setToolTip("1× Actual replays each MR frame using the treatment acquisition timeline. Faster/slower settings multiply that real timing.")
        self.speed.currentIndexChanged.connect(self.speed_changed)
        self.workstation_replay_check = QCheckBox("Workstation replay")
        self.workstation_replay_check.setChecked(True)
        self.workstation_replay_check.setToolTip("Reveal acquired images and trends progressively, matching the treatment workstation recording")
        self.workstation_replay_check.toggled.connect(self._workstation_replay_toggled)
        self.frame_label=QLabel("Frame -/-"); self.frame_label.setObjectName("CurrentValue")
        self.sync_label=QLabel("Image / Temperature / Spectrum: waiting"); self.sync_label.setObjectName("CurrentValue")
        self.timeline=QSlider(Qt.Orientation.Horizontal); self.timeline.valueChanged.connect(self.slider_changed)
        controls=QHBoxLayout()
        for w in (self.first_btn,self.prev_btn,self.play_btn,self.next_btn,self.last_btn,QLabel("Replay speed"),self.speed,self.workstation_replay_check,self.frame_label): controls.addWidget(w)
        controls.addStretch(1); controls.addWidget(self.sync_label)
        bottom=QWidget(); bl=QVBoxLayout(bottom); bl.setContentsMargins(5,1,5,3); bl.addLayout(controls); bl.addWidget(self.timeline)

        page=QWidget(); layout=QVBoxLayout(page); layout.setContentsMargins(2,2,2,2)
        layout.addLayout(top_bar); layout.addWidget(self.top_split,1); layout.addWidget(bottom,0)
        return page

    def _build_analysis_tab(self) -> QWidget:
        """Preserve earlier analysis work without allowing it to dominate Replay."""
        self.hydro_view = QComboBox()
        self.hydro_view.addItems(["Both", "Spectrum", "Waterfall"])
        self.hydro_view.currentIndexChanged.connect(self._hydro_layout_changed)
        self.hydro_arrangement = QComboBox()
        self.hydro_arrangement.addItems(["Overlay", "Stacked"])
        self.hydro_arrangement.currentIndexChanged.connect(lambda _: self._update_analysis_hydrophone())

        controls = QHBoxLayout()
        controls.addWidget(QLabel("View"))
        controls.addWidget(self.hydro_view)
        controls.addWidget(QLabel("Spectrum layout"))
        controls.addWidget(self.hydro_arrangement)
        controls.addStretch(1)

        self.analysis_spectrum_plot = pg.PlotWidget(title="Hydrophone Spectrum Analysis")
        self.analysis_spectrum_plot.setLabel("bottom", "Frequency", units="kHz")
        self.analysis_spectrum_plot.showGrid(x=True, y=True, alpha=.2)
        self.waterfall_plot = pg.PlotWidget(title="Hydrophone Waterfall")
        self.waterfall_plot.setLabel("left", "Spectrum frame / channel")
        self.waterfall_plot.setLabel("bottom", "Frequency", units="kHz")
        self.waterfall_image = pg.ImageItem()
        self.waterfall_plot.addItem(self.waterfall_image)
        self.waterfall_cursor = pg.InfiniteLine(angle=0, movable=False, pen=pg.mkPen("y", width=2))
        self.waterfall_plot.addItem(self.waterfall_cursor)

        self.hydro_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.hydro_splitter.addWidget(self.analysis_spectrum_plot)
        self.hydro_splitter.addWidget(self.waterfall_plot)
        self.hydro_splitter.setSizes([800, 800])

        info = QLabel(
            "The earlier acoustic-analysis work is preserved here. "
            "Replay-first synchronization is completed before further analysis expansion."
        )
        info.setWordWrap(True)

        self.cavitation_summary = QLabel("Spectrum-derived cavitation indicators are not available until a sonication is loaded.")
        self.cavitation_summary.setWordWrap(True)
        self.cavitation_plot = pg.PlotWidget(title="Cavitation Visualization")
        self.cavitation_plot.setLabel("left", "Relative level", units="dB")
        self.cavitation_plot.setLabel("bottom", "MR acquisition time", units="sec")
        self.cavitation_plot.showGrid(x=True, y=True, alpha=.2)
        self.cavitation_plot.addLegend(offset=(12,8))
        self.cavitation_sub_curve=self.cavitation_plot.plot(pen=pg.mkPen("#4cc9f0",width=2),name="Subharmonic")
        self.cavitation_ultra_curve=self.cavitation_plot.plot(pen=pg.mkPen("#f72585",width=2),name="Ultraharmonic")
        self.cavitation_broad_curve=self.cavitation_plot.plot(pen=pg.mkPen("#ffd166",width=2),name="Broadband")
        self.cavitation_total_curve=self.cavitation_plot.plot(pen=pg.mkPen("#06d6a0",width=2.5),name="Cavitation index")
        self.cavitation_cursor=pg.InfiniteLine(angle=90,movable=False,pen=pg.mkPen("#ffffff",width=1.5,style=Qt.PenStyle.DashLine))
        self.cavitation_plot.addItem(self.cavitation_cursor)

        page = QWidget()
        layout = QVBoxLayout(page)
        layout.addWidget(info)
        layout.addLayout(controls)
        layout.addWidget(self.hydro_splitter, 1)
        layout.addWidget(self.cavitation_summary)
        layout.addWidget(self.cavitation_plot, 0)
        return page

    def _build_planning_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        note = QLabel("Planning resources are extracted separately from Sonication replay frames. CT/SDR, pre-treatment MR, and registration data remain traceable to their source files.")
        note.setWordWrap(True); layout.addWidget(note)
        self.planning_table = QTableWidget(0, 5)
        self.planning_table.setHorizontalHeaderLabels(["Category", "Role", "Confidence", "File", "Notes"])
        self.planning_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.planning_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.planning_table, 1)
        return page

    def _build_hydrophone_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        self.hydrophone_note = QLabel("No sonication loaded")
        self.hydrophone_note.setWordWrap(True); layout.addWidget(self.hydrophone_note)
        self.hydrophone_table = QTableWidget(8, 4)
        self.hydrophone_table.setHorizontalHeaderLabels(["Hydrophone", "Decoded Frames", "Peak Amplitude", "Status"])
        self.hydrophone_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.hydrophone_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.hydrophone_table, 1)
        return page

    def _update_planning_view(self):
        assets = list(getattr(self.package, "planning_assets", []) or []) if self.package else []
        self.planning_table.setRowCount(len(assets))
        for row, asset in enumerate(assets):
            values = [asset.category, asset.role, f"{asset.confidence:.0%}", str(asset.path.relative_to(self.package.workspace)), asset.notes]
            for col, value in enumerate(values):
                self.planning_table.setItem(row, col, QTableWidgetItem(str(value)))

    def _update_hydrophone_view(self):
        if not self.current or not self.package:
            return
        replay = self.hydrophone_replay_service.build(self.current, self.current.main_frequency_hz or self.package.main_frequency_hz or 650000.0)
        self.hydrophone_note.setText(replay.decoder_note)
        for row, channel in enumerate(replay.channels):
            peak = "-" if channel.peak_amplitude is None else f"{channel.peak_amplitude:.6g}"
            values = [channel.label, len(channel.frames), peak, "Available" if channel.frames else "No decoded record"]
            for col, value in enumerate(values):
                self.hydrophone_table.setItem(row, col, QTableWidgetItem(str(value)))

    def _open_hydrophone_window(self):
        if self.hydrophone_window is None:
            self.hydrophone_window = EightHydrophoneWindow(self)
            self.hydrophone_window.sonicationRequested.connect(self._select_sonication_index)
        if self.package:
            self.hydrophone_window.load_package(
                self.package, max(0, self.sonication_index), select_from_loaded_export=True
            )
        self.hydrophone_window.show(); self.hydrophone_window.raise_(); self.hydrophone_window.activateWindow()

    # --------------------------------------------------------------- Loading
    def _set_load_progress(self, value, message: str = ""):
        if not hasattr(self, "load_progress_bar"):
            return
        if value is None:
            self.load_progress_bar.hide(); self.load_progress_label.hide()
            return
        self.load_progress_bar.show(); self.load_progress_label.show()
        self.load_progress_bar.setValue(max(0, min(100, int(value))))
        self.load_progress_label.setText(message)
        self.statusBar().showMessage(message)

    def _inline_notice(self, message: str, *, error: bool = False):
        self.statusBar().showMessage(message, 10000)
        if hasattr(self, "sync_label"):
            self.sync_label.setText(message)
            self.sync_label.setStyleSheet("color:#c0392b;" if error else "")

    def open_zip(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "Open treatment or Sonication ZIP", "", "ZIP files (*.zip)")
        if file_name:
            self.load(Path(file_name))

    def open_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Open treatment or Sonication folder")
        if folder:
            self.load(Path(folder))

    def load(self, source: Path):
        # Package extraction/discovery is intentionally asynchronous.  The current
        # replay remains interactive until the new package is ready.
        if self._package_load_thread is not None and self._package_load_thread.isRunning():
            self._inline_notice("Another source is still loading. Finish or select within the current study while it completes.")
            return
        self._set_load_progress(1, f"Loading {Path(source).name}...")
        thread = QThread(self)
        worker = PackageLoadWorker(Path(source))
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._set_load_progress)
        worker.finished.connect(self._package_load_finished)
        worker.failed.connect(self._package_load_failed)
        worker.finished.connect(thread.quit); worker.failed.connect(thread.quit)
        thread.finished.connect(worker.deleteLater); thread.finished.connect(thread.deleteLater)
        self._package_load_thread = thread; self._package_load_worker = worker
        thread.start()

    def _package_load_failed(self, message: str):
        LOG.error("Import failed: %s", message)
        self._set_load_progress(100, "Load failed")
        self._inline_notice(f"Load failed: {message}", error=True)
        self._load_progress_hide_timer.start(5000)

    def _package_load_finished(self, source, workspace, package, temp_dirs):
        previous_workspace = self.package.workspace if self.package else None
        if not package.sonications:
            # Adopt the worker temp dir only long enough to release it cleanly.
            for temp in list(temp_dirs or []):
                if temp not in self.importer.temp_dirs: self.importer.temp_dirs.append(temp)
            self.importer.release(workspace)
            self._set_load_progress(100, "No compatible Sonication data found")
            self._inline_notice("No compatible Sonication data found.", error=True)
            self._load_progress_hide_timer.start(4000)
            return
        for temp in list(temp_dirs or []):
            if temp not in self.importer.temp_dirs: self.importer.temp_dirs.append(temp)
        self.package = package
        if previous_workspace is not None and previous_workspace != workspace:
            self.importer.release(previous_workspace)
        self._clear_replay_display()
        self.hydrophone_calibration = self.hydrophone_calibration_service.read(self.package.workspace)
        self.spectrum_provider = SpectrumMsgAnalyzerAdapter(self.package.main_frequency_hz, self.hydrophone_calibration)
        self.sonication_index = 0
        self.replay_context.configure_study(len(self.package.sonications))
        self._set_load_progress(96, "Package ready; loading first Sonication...")
        # Heavy study panels are deferred so the Replay selector becomes usable first.
        self._select_sonication_index(0)
        workspace_token = Path(self.package.workspace)
        QTimer.singleShot(0, lambda w=workspace_token: self._deferred_study_load(w))

    def _deferred_study_load(self, workspace_token: Path):
        if not self.package or Path(self.package.workspace) != Path(workspace_token):
            return
        try:
            self._set_load_progress(97, "Loading diagnostics...")
            self.diagnostics_tab.load_study(self.package.workspace, self.package)
            self._update_planning_view()
        except Exception as exc:
            LOG.exception("Deferred study load failed")
            self._inline_notice(f"Some study details could not be loaded: {exc}", error=True)
        self._set_load_progress(100, f"Loaded {len(self.package.sonications)} sonication(s)")
        self._load_progress_hide_timer.start(2200)

    def _change_sonication(self, step: int):
        if not self.package or not self.package.sonications:
            return
        self._select_sonication_index((self.sonication_index + step) % len(self.package.sonications))

    def _select_sonication_index(self, index: int):
        if not self.package or not self.package.sonications:
            return
        self._selection_generation += 1
        generation = self._selection_generation
        self._clear_replay_display()
        self.sonication_index = max(0, min(index, len(self.package.sonications)-1))
        self.current = self.package.sonications[self.sonication_index]
        son_freq = self.current.main_frequency_hz or self.package.main_frequency_hz
        channel_info = self.sonication_channel_service.read(self.current.folder) if getattr(self.current, "folder", None) else None
        self.spectrum_provider = SpectrumMsgAnalyzerAdapter(
            son_freq, self.hydrophone_calibration,
            channel_hint=(channel_info.channel if channel_info else None),
            channel_source=(str(channel_info.source) if channel_info and channel_info.source else None),
        )
        self.timer.stop(); self.play_btn.setText("▶")
        self.replay.clear_cache()
        self.cursor_x = self.cursor_y = None
        self._overlay_session_view = None; self._overlay_session_levels = None
        self._restore_overlay_session = False; self._fit_overlay_next = True
        self.son_number_btn.setText(str(self.sonication_index + 1))
        self.son_number_btn.set_popup_text(self._sonication_popup_text())
        self.frame_index = 0
        initial_mode = "thermal" if self.current.temperature_frames else "anatomy"
        self._main_image_mode = initial_mode
        self.replay_context.select_sonication(self.sonication_index, self.current.replay_frame_count, self.frame_index)
        try:
            self.set_frame(self.frame_index, display_mode=initial_mode)
        except Exception as exc:
            LOG.debug("Initial frame deferred: %s", exc)
        self._set_load_progress(8, f"Sonication {self.sonication_index+1}: loading streams...")
        QTimer.singleShot(0, lambda g=generation: self._load_selected_stage(g, 0))

    def _load_selected_stage(self, generation: int, stage: int):
        if generation != self._selection_generation or not self.current or not self.package:
            return
        stages = [
            (22, "Spectrum and timing", self._selected_stage_spectrum),
            (42, "Temperature / power trends", self._selected_stage_trends),
            (61, "Cavitation evidence", self._selected_stage_cavitation),
            (78, "Image thumbnails", self._selected_stage_navigator),
            (91, "Metadata and analysis panels", self._selected_stage_metadata),
        ]
        if stage >= len(stages):
            self._set_load_progress(100, f"Sonication {self.sonication_index+1} ready")
            self.statusBar().showMessage(f"Sonication {self.sonication_index+1} ready; selection remains active during background-style staged loading")
            self._load_progress_hide_timer.start(1800)
            return
        value, label, fn = stages[stage]
        self._set_load_progress(value, f"Sonication {self.sonication_index+1}: {label}...")
        try:
            fn()
        except Exception as exc:
            LOG.exception("Sonication load stage failed: %s", label)
            self._inline_notice(f"{label} partially unavailable: {exc}", error=True)
        QTimer.singleShot(0, lambda g=generation, s=stage+1: self._load_selected_stage(g, s))

    def _selected_stage_spectrum(self):
        self._load_spectrum_channels()
        spectrum_counts = {name: len(frames) for name, frames in self.spectrum_channels.items() if frames}
        self.snapshot_provider.bind_sonication(self.sonication_index, self.current, spectrum_counts)
        self._prepare_common_timeline()

    def _selected_stage_trends(self):
        self._build_temperature_trends()
        self._build_acoustic_trends()

    def _selected_stage_cavitation(self):
        self._prepare_default_cavitation_intelligence()

    def _selected_stage_navigator(self):
        self._build_frame_navigator()
        first = self._first_valid_replay_frame()
        if first != self.frame_index:
            self.frame_index = first
            self.set_frame(first, display_mode=self._main_image_mode)

    def _selected_stage_metadata(self):
        self._update_sonication_metadata()
        self._refresh_export_workspaces()
        self._refresh_engineering_analysis()
        try:
            self.diagnostics_tab.select_sonication(self.sonication_index)
        except Exception:
            pass
        if self.hydrophone_window is not None and self.hydrophone_window.isVisible():
            self.hydrophone_window.sync_sonication(self.sonication_index)

    def _highest_average_frame(self):
        if not self.mean_temperature_trend:
            return 0
        values=np.asarray(self.mean_temperature_trend,float)
        return int(np.nanargmax(values)) if np.isfinite(values).any() else 0

    def select_sonication(self):
        return

    def _sonication_popup_text(self):
        if not self.current or not self.package:
            return "No sonication loaded"
        return (f"Sonication {self.sonication_index+1} / {len(self.package.sonications)}\n"
                f"Name: {self.current.name}\nFrames: {self.current.replay_frame_count}\n"
                f"Duration: {self._replay_duration_s():.3f} sec\n"
                f"Temperature RAW: {len(self.current.temperature_frames)}\n"
                f"Magnitude RAW: {len(self.current.magnitude_frames)}\n"
                f"SpectrumMsg: {len(self.current.spectrum_files)}\nACT: {len(self.current.act_files)}")

    # ---------------------------------------------------------- Synchronization
    def _prepare_common_timeline(self) -> None:
        self.current_timeline_duration_s = 0.0
        if not self.current or not self.package:
            return
        if self.current.replay_frame_count > 1:
            # Product Replay shows the complete MR acquisition window.  Exported
            # thermometry frames are approximately 3.4 s apart in this platform.
            self.current_timeline_duration_s = float(self.current.replay_frame_count - 1) * 3.4
        else:
            measured = self.acoustic_control_service.measured_duration_for_sonication(
                self.package.workspace, self.sonication_index
            )
            self.current_timeline_duration_s = float(measured or 0.0)

    def _build_temperature_trends(self):
        self.max_temperature_trend = []
        self.mean_temperature_trend = []
        self.delta_trend = []
        if not self.current:
            return
        for index in range(self.current.replay_frame_count):
            try:
                data = self.replay.frame(self.current, index)
                self.max_temperature_trend.append(data.maximum_temperature if data.maximum_temperature is not None else np.nan)
                self.mean_temperature_trend.append(data.mean_temperature if data.mean_temperature is not None else np.nan)
                self.delta_trend.append(data.maximum_delta_temperature if data.maximum_delta_temperature is not None else np.nan)
            except Exception:
                self.max_temperature_trend.append(np.nan)
                self.mean_temperature_trend.append(np.nan)
                self.delta_trend.append(np.nan)
        x = self._frame_time_axis(self.current.replay_frame_count)
        self.max_temperature_curve.setData(x, np.asarray(self.max_temperature_trend, float), connect="finite")
        self.mean_temperature_curve.setData(x, np.asarray(self.mean_temperature_trend, float), connect="finite")
        if len(x):
            self._fit_temperature_trend(force=not self.chart_state.temperature_user_zoomed)

    def _build_acoustic_trends(self):
        count = self.current.replay_frame_count if self.current else 0
        if not self.current or not self.package or count <= 0:
            self.acoustic_peaks = np.asarray([], dtype=float)
            self.acoustic_scores = np.asarray([], dtype=float)
            self.acoustic_control_trend = None
            self.acoustic_power_curve.setData([], [])
            self.acoustic_score_curve.setData([], [])
            return
        duration = self._index_to_seconds(max(count - 1, 0), count)
        trend = self.acoustic_control_service.trend_for_sonication(
            self.package.workspace, self.sonication_index, count, duration
        )
        self.acoustic_control_trend = trend
        self.acoustic_peaks = trend.power_percent
        self.acoustic_scores = trend.score_percent
        tx=np.asarray(trend.time_s,float); py=np.asarray(trend.power_percent,float); sy=np.asarray(trend.score_percent,float)
        if not np.isfinite(py).any() and self.current.planned_power_w is not None:
            # planned_power_w is an absolute Watt value, never a percentage.
            # Keep the percentage plot empty and expose the Watt value as annotation.
            py=np.full(tx.shape, np.nan, dtype=float)
            trend.power_percent=py
            trend.status=f"Measured Power % unavailable; planned power {float(self.current.planned_power_w):.1f} W"
        self.acoustic_power_curve.setData(tx, py, connect="finite")
        self.acoustic_score_curve.setData(tx, sy, connect="finite")
        finite = np.concatenate((trend.power_percent[np.isfinite(trend.power_percent)], trend.score_percent[np.isfinite(trend.score_percent)]))
        # Power and Score are percentages: keep a stable 0-110 % viewport.
        self.acoustic_control_plot.setYRange(0.0, 110.0, padding=0.0)
        if not np.isfinite(py).any() and self.current.planned_power_w is not None:
            self.acoustic_power_text.setText(f"Planned: {float(self.current.planned_power_w):.1f} W\nMeasured Power % unavailable")
        if trend.time_s.size:
            self.acoustic_control_plot.setXRange(float(np.nanmin(trend.time_s)), float(np.nanmax(trend.time_s) or 1.0), padding=0.01)
        self.acoustic_control_plot.enableAutoRange(axis='x', enable=False)
        if trend.source:
            self.acoustic_control_plot.setTitle("")
        else:
            self.acoustic_control_plot.setTitle("")

    def _ensure_acoustic_curve_items(self):
        """Recreate embedded Power/Score PlotDataItems when Qt loses them.

        Recreating the curves is more reliable than re-adding stale PlotDataItems
        after a popup has been opened or a sonication has changed.
        """
        for attr in ("acoustic_power_curve", "acoustic_score_curve"):
            item=getattr(self,attr,None)
            if item is not None:
                try: self.acoustic_control_plot.removeItem(item)
                except Exception: pass
        self.acoustic_power_curve=self.acoustic_control_plot.plot(pen=pg.mkPen("#58f26a",width=2.5),name="Power %")
        self.acoustic_score_curve=self.acoustic_control_plot.plot(pen=pg.mkPen("#ff9d22",width=2.5),name="Score")
        for item in (self.acoustic_control_cursor,self.acoustic_hover_text,self.acoustic_power_text,self.acoustic_score_text):
            try:
                if item not in self.acoustic_control_plot.items(): self.acoustic_control_plot.addItem(item)
            except Exception:
                try: self.acoustic_control_plot.addItem(item)
                except Exception: pass

    def _build_frame_navigator(self):
        for widget in (self.planning_frame_list, self.anatomy_frame_list, self.thermal_frame_list):
            widget.blockSignals(True); widget.clear()
        self._planning_display_arrays = []
        self._planning_assets_all = []
        self._anatomy_row_map = []
        self._thermal_row_map = []
        if not self.current:
            for widget in (self.planning_frame_list, self.anatomy_frame_list, self.thermal_frame_list): widget.blockSignals(False)
            return

        assets = list(getattr(self.package, "planning_assets", []) or []) if self.package else []
        categories = []
        for asset in assets:
            array = self._decode_planning_image(asset)
            category = self._planning_category(asset)
            label = f"{category.replace('Planning ', '')}\n{asset.path.name}"
            if array is not None:
                self._planning_assets_all.append((asset, array, label, category))
                if category not in categories: categories.append(category)
        # Row selectors are fixed and identical for all three rows.  Do not
        # repopulate the first combo from discovered categories because that
        # would remove the requested cross-row choices.

        for row, frame in enumerate(self.current.magnitude_frames):
            try:
                array = self.replay.raw.read_magnitude(frame.path)
                finite = np.asarray(array, float); finite = finite[np.isfinite(finite)]
                if not finite.size or float(np.nanstd(finite)) <= 1e-8: continue
                icon = self._array_icon(array)
            except Exception:
                continue
            item=QListWidgetItem(icon, f"MR {row+1}\n{frame.path.name}"); item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
            self.anatomy_frame_list.addItem(item); self._anatomy_row_map.append(row)

        for row, frame in enumerate(self.current.temperature_frames):
            try:
                array = self.replay.raw.read_temperature(frame.path)
                finite = np.asarray(array, float); finite = finite[np.isfinite(finite)]
                # Empty/constant first thermal frames are acquisition placeholders, not images.
                if not finite.size or float(np.nanstd(finite)) <= 1e-8: continue
                icon = self._array_icon(array)
            except Exception:
                continue
            item=QListWidgetItem(icon, f"Temp {row+1}\n{frame.path.name}"); item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
            self.thermal_frame_list.addItem(item); self._thermal_row_map.append(row)

        for widget in (self.planning_frame_list, self.anatomy_frame_list, self.thermal_frame_list): widget.blockSignals(False)
        self._rebuild_all_image_strips()

    def _all_image_entries(self):
        entries=[]
        planning_assets=list(getattr(self,"_planning_assets_all",[]))
        verified_ct_available=any(category=="Preplanning CT" and getattr(asset,"field_index",None)==16 for asset,_array,_label,category in planning_assets)
        category_to_mode={
            "Preplanning CT":"preplanning_ct",
            "Preplanning MR Ax":"preplanning_mr_ax", "Preplanning MR Sag":"preplanning_mr_sag", "Preplanning MR Cor":"preplanning_mr_cor",
            "Planning MR Ax":"planning_mr_ax", "Planning MR Sag":"planning_mr_sag", "Planning MR Cor":"planning_mr_cor",
        }
        for asset,array,label,category in planning_assets:
            mode=category_to_mode.get(category)
            if mode is None: continue
            if category=="Preplanning CT":
                if verified_ct_available and getattr(asset,"field_index",None)!=16: continue
                slice_no=getattr(asset,"array_index",None); label=f"CT {slice_no+1 if isinstance(slice_no,int) else '?'}\n{asset.path.name}"
            else:
                slice_no=getattr(asset,"array_index",None)
                desc=getattr(asset,"series_description",None) or getattr(asset,"role",category)
                label=f"{category.replace('Preplanning MR ','').replace('Planning MR ','')} {slice_no+1 if isinstance(slice_no,int) else '?'}\n{desc}"
            entries.append((mode,array,label,asset))
        if self.current:
            for row,frame in enumerate(self.current.magnitude_frames):
                try:
                    arr=self.replay.raw.read_magnitude(frame.path); finite=np.asarray(arr,float); finite=finite[np.isfinite(finite)]
                    if finite.size and float(np.nanstd(finite))>1e-8: entries.append(("treatment_mr",arr,f"Treatment MR {row+1}\n{frame.path.name}",row))
                except Exception: pass
            for row,frame in enumerate(self.current.temperature_frames):
                try:
                    arr=self.replay.raw.read_temperature(frame.path); finite=np.asarray(arr,float); finite=finite[np.isfinite(finite)]
                    if finite.size and float(np.nanstd(finite))>1e-8: entries.append(("treatment_thermal",arr,f"Thermal {row+1}\n{frame.path.name}",row))
                except Exception: pass
        return entries

    def _rebuild_all_image_strips(self, *_):
        mapping={
            "Preplanning CT":{"preplanning_ct"},
            "Preplanning MR Ax":{"preplanning_mr_ax"}, "Preplanning MR Sag":{"preplanning_mr_sag"}, "Preplanning MR Cor":{"preplanning_mr_cor"},
            "Planning MR Ax":{"planning_mr_ax"}, "Planning MR Sag":{"planning_mr_sag"}, "Planning MR Cor":{"planning_mr_cor"},
            "Treatment MR":{"treatment_mr"}, "Treatment Thermal":{"treatment_thermal"},
            "All images":{"preplanning_ct","preplanning_mr_ax","preplanning_mr_sag","preplanning_mr_cor","planning_mr_ax","planning_mr_sag","planning_mr_cor","treatment_mr","treatment_thermal"},
        }
        entries=self._all_image_entries()
        for strip,combo in ((self.planning_frame_list,self.planning_type_combo),(self.anatomy_frame_list,self.anatomy_type_combo),(self.thermal_frame_list,self.thermal_type_combo)):
            strip.blockSignals(True); strip.clear()
            allowed=mapping.get(combo.currentText(),{"planning","anatomy","thermal"})
            for mode,array,label,source_index in entries:
                if mode not in allowed: continue
                item=QListWidgetItem(self._array_icon(array),label); item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
                item.setData(Qt.ItemDataRole.UserRole,(mode,source_index,array,label)); strip.addItem(item)
            strip.blockSignals(False)
        # Planning rows are reference selectors only.  Rebuilding thumbnails must
        # never replace the live replay image with a CT/MR planning slice.
        # The main viewer remains owned by ReplayContext until the user explicitly
        # clicks a planning thumbnail.
        self._sync_registration_button_state()

    def _is_registration_reference_mode(self, mode: str | None = None) -> bool:
        mode = self._main_image_mode if mode is None else str(mode)
        return mode.startswith("preplanning_mr_") or mode.startswith("planning_mr_")

    def _reference_combo_is_mr(self) -> bool:
        if not hasattr(self, "planning_type_combo"):
            return False
        return self.planning_type_combo.currentText().startswith("Preplanning MR") or self.planning_type_combo.currentText().startswith("Planning MR")

    def _sync_registration_button_state(self) -> None:
        if not hasattr(self, "registration_toggle_btn"):
            return
        main_is_mr = self._is_registration_reference_mode() and self._active_planning_asset is not None and self._active_planning_array is not None
        enabled = bool(main_is_mr)
        self.registration_toggle_btn.setEnabled(enabled)
        if enabled:
            if main_is_mr:
                self.registration_toggle_btn.setToolTip("Overlay preplanning CT skull/bone on the displayed MR using the treatment-adopted CtMr registration.")
            else:
                self.registration_toggle_btn.setToolTip("Display a Preplanning MR or Planning MR in the main Replay image first, then turn Registration ON.")
        else:
            self.registration_toggle_btn.setToolTip("Display a Preplanning MR or Planning MR in the main Replay image first to enable Registration.")
        if not enabled and self.registration_toggle_btn.isChecked():
            self.registration_toggle_btn.blockSignals(True)
            self.registration_toggle_btn.setChecked(False)
            self.registration_toggle_btn.setText("Registration OFF")
            self.registration_toggle_btn.blockSignals(False)
            self.registration_overlay_enabled = False

    def _planning_reference_type_changed(self, *_):
        self._rebuild_all_image_strips()
        # Product operation: changing the selector alone must NOT enable registration.
        # Registration becomes available only after the MR reference is actually
        # displayed in the main Replay viewer.
        self._sync_registration_button_state()

    def _activate_reference_for_registration(self) -> bool:
        if not hasattr(self, "planning_frame_list") or self.planning_frame_list.count() <= 0:
            return False
        row = self.planning_frame_list.currentRow()
        if row < 0:
            row = 0
        item = self.planning_frame_list.item(row)
        if item is None:
            return False
        payload = item.data(Qt.ItemDataRole.UserRole)
        if not payload or not self._is_registration_reference_mode(payload[0]):
            # Find the first MR reference in the visible list.
            for i in range(self.planning_frame_list.count()):
                candidate = self.planning_frame_list.item(i)
                cp = candidate.data(Qt.ItemDataRole.UserRole) if candidate is not None else None
                if cp and self._is_registration_reference_mode(cp[0]):
                    item = candidate; row = i; payload = cp; break
            else:
                return False
        self.planning_frame_list.blockSignals(True)
        self.planning_frame_list.setCurrentRow(row)
        self.planning_frame_list.blockSignals(False)
        self._activate_image_payload(payload)
        return self._is_registration_reference_mode()

    def _unified_image_item_selected(self, strip, item) -> None:
        """Activate a thumbnail even when it is already the current item."""
        if item is None:
            return
        self._activate_image_payload(item.data(Qt.ItemDataRole.UserRole))

    def _unified_image_selected(self, strip, row):
        if row < 0:
            return
        item = strip.item(row)
        if item is not None:
            self._activate_image_payload(item.data(Qt.ItemDataRole.UserRole))

    def _activate_image_payload(self, payload) -> None:
        """Display one thumbnail using explicit preplanning/planning/treatment semantics."""
        if not payload: return
        mode, source_index, array, label = payload
        planning_mr_modes={"preplanning_mr_ax","preplanning_mr_sag","preplanning_mr_cor","planning_mr_ax","planning_mr_sag","planning_mr_cor"}
        if mode == "preplanning_ct" or mode in planning_mr_modes:
            self._main_image_mode = mode
            self._active_planning_asset = source_index
            self._active_planning_array = np.asarray(array,float) if array is not None else None
            self._displayed_plane_override = self._infer_asset_plane(source_index)
            self.overlay.set_hover_temperature(None); self.overlay.set_roi(None,None)
            if mode in planning_mr_modes and self.registration_overlay_enabled:
                self._apply_registration_overlay()
            else:
                self.overlay.set_overlay(array,None,fit=True)
            is_mr=mode in planning_mr_modes
            if hasattr(self,"registration_toggle_btn"):
                self._sync_registration_button_state()
                if not is_mr and self.registration_toggle_btn.isChecked():
                    self.registration_toggle_btn.blockSignals(True); self.registration_toggle_btn.setChecked(False); self.registration_toggle_btn.setText("Registration OFF"); self.registration_toggle_btn.blockSignals(False)
                    self.registration_overlay_enabled=False
            kind="Preplanning CT" if mode=="preplanning_ct" else self._planning_category(source_index)
            self.frame_label.setText(f"{kind}: {label}")
            if not (is_mr and self.registration_overlay_enabled): self.sync_label.setText(f"{kind} selected · Registration available on MR reference images")
            self._update_orientation_alignment_labels(); return
        if not self.current or source_index is None: return
        replay_mode="anatomy" if mode=="treatment_mr" else "thermal"
        series_count=len(self.current.magnitude_frames) if replay_mode=="anatomy" else len(self.current.temperature_frames)
        replay_index=self._map_data_to_replay(int(source_index),max(1,series_count),max(1,self.current.replay_frame_count))
        self._main_image_mode=replay_mode
        self._active_planning_asset=None; self._active_planning_array=None
        if hasattr(self,"registration_toggle_btn"):
            self._sync_registration_button_state()
        if replay_mode=="anatomy":
            # A reference/planning image may leave the ImageView zoomed. Force the
            # first Treatment MR render to refit the full acquired MR frame.
            self._overlay_session_view = None
            self._restore_overlay_session = False
            self._fit_overlay_next = True
            self.overlay.set_hover_temperature(None); self.overlay.set_roi(None,None)
        else:
            mag=None
            if self.current.magnitude_frames:
                mi=self._map_replay_to_data(replay_index,self.current.replay_frame_count,len(self.current.magnitude_frames))
                try: mag=self.replay.raw.read_magnitude(self.current.magnitude_frames[mi].path)
                except Exception: mag=None
            levels=self._temperature_levels(array); lut=self._temperature_lut_with_red_threshold(*(levels or (35.0,60.0)))
            self.overlay.set_overlay(mag,array,None,levels,lut,self.overlay_opacity.value()/100.0,fit=True)
        self.set_frame(replay_index,display_mode=replay_mode)

    def _registration_toggled(self, checked: bool) -> None:
        # Match treatment-workstation operation: Registration is a review overlay
        # on the MR that is already visible in the main Replay image. Never change
        # the displayed image implicitly when the button is pressed.
        if checked and not self._is_registration_reference_mode():
            self.registration_toggle_btn.blockSignals(True)
            self.registration_toggle_btn.setChecked(False)
            self.registration_toggle_btn.setText("Registration OFF")
            self.registration_toggle_btn.blockSignals(False)
            self.registration_overlay_enabled=False
            self._inline_notice("Display a Preplanning MR or Planning MR in the main Replay image first.", error=False)
            self._sync_registration_button_state()
            return
        self.registration_overlay_enabled=bool(checked)
        self.registration_toggle_btn.setText("Registration ON" if checked else "Registration OFF")
        planning_mr=self._is_registration_reference_mode()
        if checked and planning_mr:
            self._apply_registration_overlay()
        elif self._active_planning_array is not None and planning_mr:
            self.overlay.set_overlay(self._active_planning_array,None,fit=False)
            self.sync_label.setText("Registration OFF · MR reference image only")
        self._sync_registration_button_state()

    def _ct_volume_for_registration(self):
        ct_items=[(a,np.asarray(arr,float)) for a,arr,_label,cat in getattr(self,"_planning_assets_all",[]) if cat=="Preplanning CT" and getattr(a,"field_index",None)==16 and arr is not None]
        if not ct_items:
            return None,None
        ct_items.sort(key=lambda pair:getattr(pair[0],"array_index",0) or 0)
        shapes=[arr.shape for _a,arr in ct_items]
        common=max(set(shapes),key=shapes.count)
        ct_items=[pair for pair in ct_items if pair[1].shape==common]
        if not ct_items:
            return None,None
        return ct_items[0][0],np.stack([arr for _a,arr in ct_items],axis=0)

    def _apply_registration_overlay(self) -> None:
        if self._active_planning_asset is None or self._active_planning_array is None or not self.package:
            return
        ct_asset,ct_volume=self._ct_volume_for_registration()
        if ct_volume is None:
            self.sync_label.setText("Registration ON requested · preplanning CT volume unavailable"); return
        plane=getattr(self._active_planning_asset,"plane",None) or self._infer_asset_plane(self._active_planning_asset) or "Ax"
        result=self.registration_overlay_service.render_volume(Path(self.package.workspace),self.sonication_index+1,self._active_planning_array,plane,ct_asset,ct_volume,self._active_planning_asset)
        if result.overlay is None or not np.isfinite(result.overlay).any():
            self.overlay.set_overlay(self._active_planning_array,None,fit=False); self.sync_label.setText(result.status); return
        vals=result.overlay[np.isfinite(result.overlay)]; levels=tuple(map(float,np.percentile(vals,[5,99]))) if vals.size else None
        self.overlay.set_overlay(self._active_planning_array,result.overlay,None,levels,self._bone_overlay_lut(),0.82,fit=False)
        self.frame_label.setText(f"REGISTRATION ON · {self._planning_category(self._active_planning_asset)}")
        self.sync_label.setText(result.status + " · verify skull alignment on MR")

    def _activate_replay_mode_for_navigation(self) -> None:
        """Return the main viewer from a planning reference to live replay.

        Planning thumbnails are intentionally static references.  Timeline,
        arrows, wheel and playback always control the sonication replay and must
        therefore restore Thermal (or Anatomy when thermometry is unavailable).
        """
        if self._main_image_mode.startswith("preplanning_") or self._main_image_mode.startswith("planning_mr_") or self._main_image_mode in {"planning", "planning_ct", "planning_mr", "fusion"}:
            self._main_image_mode = "thermal" if self.current and self.current.temperature_frames else "anatomy"
            if hasattr(self, "planning_frame_list"):
                self.planning_frame_list.blockSignals(True)
                self.planning_frame_list.setCurrentRow(-1)
                self.planning_frame_list.blockSignals(False)
            self._fit_overlay_next = True
            self._sync_registration_button_state()

    @staticmethod
    def _resample_to_shape(array, shape):
        arr=np.asarray(array,float)
        if arr.shape[:2] == tuple(shape): return arr
        yi=np.linspace(0,arr.shape[0]-1,int(shape[0])).astype(int); xi=np.linspace(0,arr.shape[1]-1,int(shape[1])).astype(int)
        return arr[np.ix_(yi,xi)]

    @staticmethod
    def _bone_overlay_lut():
        lut=np.zeros((256,4),dtype=np.ubyte)
        for i in range(256): lut[i]=[255,220,170,int(np.clip((i/255.0)**1.6*230,0,255))]
        lut[:32,3]=0
        return lut

    def _infer_asset_plane(self, asset):
        if asset is None: return None
        text=' '.join(str(getattr(asset,n,'')) for n in ('role','notes','path')).lower()
        for plane in ('axial','coronal','sagittal'):
            if plane in text: return plane.title()
        return None

    def _displayed_plane(self):
        if self._displayed_plane_override: return self._displayed_plane_override
        return self.current_metadata.summary.get('Orientation','Unavailable') if self.current_metadata else 'Unavailable'

    def _update_orientation_alignment_labels(self):
        if not hasattr(self,'summary_value_labels'): return
        meta=self.current_metadata.summary.get('Orientation','Unavailable') if self.current_metadata else 'Unavailable'
        displayed=self._displayed_plane()
        status='Unavailable' if 'Unavailable' in (meta,displayed) else ('Aligned' if meta==displayed else f'Metadata {meta} / Display {displayed}')
        if 'Orientation' in self.summary_value_labels: self.summary_value_labels['Orientation'].setText(meta)
        if 'Displayed Plane' in self.summary_value_labels: self.summary_value_labels['Displayed Plane'].setText(displayed)
        if 'Orientation Status' in self.summary_value_labels: self.summary_value_labels['Orientation Status'].setText(status)

    @staticmethod
    def _gradient_signature(array):
        arr=np.asarray(array,float)
        finite=arr[np.isfinite(arr)]
        if finite.size < 16:
            return None
        lo,hi=np.percentile(finite,[2,98])
        scale=max(float(hi-lo),1e-6)
        norm=np.clip((arr-lo)/scale,0,1)
        gy,gx=np.gradient(np.nan_to_num(norm,nan=0.0))
        return np.hypot(gx,gy)

    def _best_ct_for_fusion(self, mr, preferred=None):
        candidates=[]
        for asset,array,_label,category in getattr(self,"_planning_assets_all",[]):
            if category != "Planning CT" or array is None:
                continue
            if getattr(asset,"field_index",None) not in (None,16):
                continue
            candidates.append((asset,array))
        if preferred is not None:
            candidates.sort(key=lambda pair: 0 if pair[0] is preferred else 1)
        if not candidates:
            return None,None,None
        mr_arr=np.asarray(mr,float)
        mr_sig=self._gradient_signature(mr_arr)
        best=None
        for asset,ct in candidates[:160]:
            ct_r=self._resample_to_shape(ct,mr_arr.shape[:2])
            ct_sig=self._gradient_signature(ct_r)
            if mr_sig is None or ct_sig is None:
                score=-1.0
            else:
                a=mr_sig.ravel(); b=ct_sig.ravel()
                valid=np.isfinite(a)&np.isfinite(b)
                if np.count_nonzero(valid)<100 or np.std(a[valid])<1e-8 or np.std(b[valid])<1e-8:
                    score=-1.0
                else:
                    score=float(np.corrcoef(a[valid],b[valid])[0,1])
            if best is None or score>best[0]:
                best=(score,asset,ct_r)
        return (best[1],best[2],best[0]) if best else (None,None,None)

    @staticmethod
    def _ct_edge_overlay(ct):
        arr=np.asarray(ct,float)
        finite=arr[np.isfinite(arr)]
        if finite.size < 16:
            return None
        bone_lo=float(np.percentile(finite,82))
        bone=np.where(arr>=bone_lo,arr,np.nan)
        # Edge-only overlay prevents a mismatched CT slice from obscuring MR anatomy.
        mask=np.isfinite(bone).astype(float)
        gy,gx=np.gradient(mask)
        edge=np.hypot(gx,gy)>0.05
        return np.where(edge,arr,np.nan)

    def _show_fusion_preview(self,payload,label):
        """Registration reference view.

        Do not fabricate a fusion by resizing CT to MR. A valid registration image
        requires a decoded transform. Until the transform matrix is decoded, show
        the Planning MR as the registered reference and report the CT/registration
        sources explicitly. This is safer and much closer to workstation behavior
        than a visually convincing but geometrically false overlay.
        """
        payload=payload or {}; mr=payload.get('mr')
        if mr is None:
            self.frame_label.setText('REGISTRATION | unavailable')
            self.sync_label.setText('Planning MR reference is required for registration review')
            return
        mr=np.asarray(mr,float)
        mf=mr[np.isfinite(mr)]
        ml=tuple(map(float,np.percentile(mf,[2,98.5]))) if mf.size else None
        self.overlay.set_hover_temperature(None); self.overlay.set_roi(None,None)
        self.overlay.set_overlay(mr,None,ml,None,None,0.0,fit=True)
        registrations=list(payload.get('registration_assets') or [])
        ct_asset=payload.get('ct_asset')
        ct_txt=f"CT source: {getattr(getattr(ct_asset,'path',None),'name','available')}" if ct_asset is not None else 'CT source unavailable'
        if registrations:
            reg_name=getattr(getattr(registrations[0],'path',None),'name','registration data')
            status=f"Registration source: {reg_name}; transform decoding pending"
        else:
            status='Registration transform not found'
        self.frame_label.setText(f'REGISTRATION REFERENCE | {label}')
        self.sync_label.setText(f'MR reference displayed | {ct_txt} | {status} | no synthetic CT/MR overlay')

    def _prepare_default_cavitation_intelligence(self) -> None:
        """Decode CPC cavitation evidence for the default Replay without changing source mode."""
        self.default_cpc_replay = None
        self.default_cavitation_timeline = None
        self.default_cavitation_likelihood = None
        if not self.package or not self.current:
            return
        try:
            replay = self.hydrophone_replay_service.build(
                self.package.cpc_spectrum_files, self.sonication_index, len(self.package.sonications)
            )
            self.default_cpc_replay = replay
            validation = getattr(replay, "vendor_control_validation", None)
            history = getattr(replay, "vendor_history_validation", None)
            preferred = getattr(history, "log_session_index", None) if history is not None else None
            cycles = getattr(validation, "event_cycles", np.asarray([], int)) if validation is not None else np.asarray([], int)
            predicted = getattr(validation, "predicted_power_ratio", np.asarray([], float)) if validation is not None else np.asarray([], float)
            source_path = replay.source_fft or replay.source_raw or self.package.workspace
            self.default_cavitation_timeline = self.cavitation_control_timeline_service.parse(
                source_path, getattr(replay, "vendor_profile", None), preferred, cycles, predicted
            )
        except Exception as exc:
            LOG.warning("Default cavitation intelligence unavailable: %s", exc)
            self.default_cpc_replay = None
            self.default_cavitation_timeline = None

    def _nearest_cpc_frame_index(self, replay_time_s: float) -> int | None:
        replay = self.default_cpc_replay
        if replay is None or not replay.frames:
            return None
        times = np.asarray([
            float(f.acquisition_time_s) if getattr(f, "acquisition_time_s", None) is not None else i * float(replay.frame_interval_s)
            for i, f in enumerate(replay.frames)
        ], float)
        if not times.size or not np.isfinite(times).any():
            return None
        return int(np.nanargmin(np.abs(times - float(replay_time_s))))

    def _nearest_observed_cavitation_event(self, replay_time_s: float, tolerance_s: float = 0.12):
        timeline = self.default_cavitation_timeline
        if timeline is None or not timeline.events:
            return None
        candidates=[]
        for event in timeline.events:
            t = getattr(event, "timestamp_s", None)
            if t is None or not np.isfinite(float(t)):
                continue
            candidates.append((abs(float(t)-float(replay_time_s)), event))
        if not candidates:
            return None
        distance,event=min(candidates,key=lambda item:item[0])
        return event if distance <= tolerance_s else None

    def _current_magnitude_signal_loss(self) -> tuple[float | None, str]:
        """Return robust central-ROI magnitude loss vs prior magnitude frame."""
        if not self.current or len(self.current.magnitude_frames) < 2:
            return None, "MR signal loss unavailable"
        count=max(1,int(self.current.replay_frame_count))
        idx=self.replay.raw.normalize_index(self.frame_index,count,len(self.current.magnitude_frames))
        if idx <= 0:
            return None, "MR baseline frame"
        try:
            prev=np.asarray(self.replay.raw.read_magnitude(self.current.magnitude_frames[idx-1].path),float)
            curr=np.asarray(self.replay.raw.read_magnitude(self.current.magnitude_frames[idx].path),float)
        except Exception:
            return None, "MR signal loss unavailable"
        if prev.shape != curr.shape or prev.ndim != 2 or not prev.size:
            return None, "MR signal loss unavailable"
        h,w=prev.shape; radius=max(4,min(h,w)//10); cy=h//2; cx=w//2
        y0,y1=max(0,cy-radius),min(h,cy+radius+1); x0,x1=max(0,cx-radius),min(w,cx+radius+1)
        p=prev[y0:y1,x0:x1]; c=curr[y0:y1,x0:x1]
        valid=np.isfinite(p)&np.isfinite(c)&(p>0)
        if np.count_nonzero(valid)<16:
            return None, "MR signal loss unavailable"
        # Remove global receive-gain drift by normalizing the current image to
        # the previous image using the whole-image positive median.
        gvalid=np.isfinite(prev)&np.isfinite(curr)&(prev>0)&(curr>0)
        if np.count_nonzero(gvalid)>64:
            gain=float(np.nanmedian(prev[gvalid])/max(np.nanmedian(curr[gvalid]),1e-9))
        else:
            gain=1.0
        ratio=np.asarray(c*gain,float)[valid]/np.asarray(p,float)[valid]
        median_ratio=float(np.nanmedian(ratio))
        loss=max(0.0,100.0*(1.0-median_ratio))
        local_fraction=float(np.mean(ratio<0.75))*100.0
        return loss, f"central ROI loss {loss:.1f}% · pixels <75% baseline {local_fraction:.1f}%"

    def _current_magnitude_correlation(self, likelihood_result):
        if not self.current or not self.current.magnitude_frames:
            return None
        count=max(1,int(self.current.replay_frame_count))
        idx=self.replay.raw.normalize_index(self.frame_index,count,len(self.current.magnitude_frames))
        if idx <= 0:
            return None
        try:
            current=np.asarray(self.replay.raw.read_magnitude(self.current.magnitude_frames[idx].path),float)
            baseline=[]
            for j in range(max(0,idx-3),idx):
                baseline.append(np.asarray(self.replay.raw.read_magnitude(self.current.magnitude_frames[j].path),float))
        except Exception:
            return None
        hp=None if likelihood_result is None else np.asarray(likelihood_result.likelihood_map,float)
        try:
            return self.cavitation_mr_correlation_service.analyze(baseline,current,hp)
        except Exception as exc:
            LOG.debug("MR cavitation correlation unavailable: %s",exc)
            return None

    def _draw_replay_mr_correlation(self, result) -> None:
        if not hasattr(self,"replay_mr_corr_plot"):
            return
        self.replay_mr_corr_plot.clear(); self.replay_mr_corr_plot.addItem(self.replay_mr_corr_image)
        if result is None or np.asarray(result.correlated_map).size==0:
            self.replay_mr_corr_image.setImage(np.empty((0,0))); return
        arr=np.asarray(result.correlated_map,float)
        maxv=float(np.nanmax(arr)) if np.isfinite(arr).any() else 0.0
        self.replay_mr_corr_image.setImage(arr,autoLevels=False,levels=(0,max(maxv,1e-6)))
        h,w=arr.shape
        self.replay_mr_corr_image.setRect(QRectF(0,0,w,h))
        if result.loss_centroid_xy is not None:
            nx,ny=result.loss_centroid_xy
            x=(nx+1)*0.5*(w-1); y=(1-ny)*0.5*(h-1)
            self.replay_mr_corr_plot.plot([x],[y],pen=None,symbol="x",symbolSize=10,symbolPen=pg.mkPen("#f72585",width=2))
        self.replay_mr_corr_plot.setRange(xRange=(0,w),yRange=(0,h),padding=0.01)

    def _draw_replay_cavitation_map(self, result) -> None:
        if not hasattr(self, "replay_cavitation_map"):
            return
        self.replay_cavitation_map.clear()
        self.replay_cavitation_map.addItem(self.replay_cavitation_image)
        if result is None or np.asarray(result.likelihood_map).size == 0:
            self.replay_cavitation_image.setImage(np.empty((0,0)))
            return
        arr=np.asarray(result.likelihood_map,float)
        self.replay_cavitation_image.setImage(arr,autoLevels=False,levels=(0,1))
        self.replay_cavitation_image.setRect(QRectF(-1.05,-1.05,2.10,2.10))
        theta=np.linspace(0,2*np.pi,160)
        self.replay_cavitation_map.plot(np.cos(theta),np.sin(theta),pen=pg.mkPen("#aaaaaa",width=1))
        self.replay_cavitation_map.plot([0],[0],pen=None,symbol="+",symbolSize=11,symbolPen=pg.mkPen("#ffffff",width=2))
        pos=np.asarray(result.hydrophone_positions,float)
        for ch in range(min(8,len(pos))):
            dominant=(result.dominant_channel is not None and ch==result.dominant_channel)
            active=float(result.per_channel_scores[ch])>0.01
            brush="#f72585" if dominant else "#ffd166" if active else "#4cc9f0"
            self.replay_cavitation_map.plot([pos[ch,0]],[pos[ch,1]],pen=None,symbol="o",symbolSize=9 if dominant else 6,symbolBrush=brush)
        if result.centroid_xy is not None:
            self.replay_cavitation_map.plot([result.centroid_xy[0]],[result.centroid_xy[1]],pen=None,symbol="x",symbolSize=10,symbolPen=pg.mkPen("#06d6a0",width=2))

    def _update_default_cavitation_intelligence(self) -> None:
        if not hasattr(self, "replay_cavitation_status"):
            return
        replay=self.default_cpc_replay
        if replay is None or not replay.frames:
            self.replay_cavitation_status.setText("CPC cavitation evidence unavailable for this Sonication")
            self.replay_cavitation_detail.setText("Dominant RCV: -- | MR correlation: --")
            for label in self.replay_band_labels: label.setText(label.text().split(':')[0]+": --")
            self._draw_replay_cavitation_map(None)
            self._draw_replay_mr_correlation(None)
            return
        replay_time=self._index_to_seconds(self.frame_index,self.current.replay_frame_count) if self.current else 0.0
        cpc_index=self._nearest_cpc_frame_index(replay_time)
        if cpc_index is None:
            return
        frame=replay.frames[cpc_index]
        event=self._nearest_observed_cavitation_event(float(getattr(frame,"acquisition_time_s",replay_time) or 0.0))
        try:
            result=self.cavitation_likelihood_service.estimate(replay,cpc_index,event)
        except Exception as exc:
            LOG.debug("Likelihood map unavailable: %s",exc); result=None
        self.default_cavitation_likelihood=result
        energies=np.asarray(getattr(frame,"vendor_band_energies",[]),float)
        dominant=result.dominant_channel if result is not None else None
        for band,label in enumerate(self.replay_band_labels):
            if energies.shape==(8,4) and dominant is not None:
                label.setText(f"B{band}: {energies[dominant,band]:.4g}")
            elif energies.shape==(8,4):
                label.setText(f"B{band}: {np.nanmax(energies[:,band]):.4g}")
            else:
                label.setText(f"B{band}: --")
        if event is not None:
            state=f"OBSERVED {event.family} Rule {event.rule_index}"
            if getattr(event,"result",""):
                state += f" · {event.result}"
        else:
            state="CPC Band0–3 monitoring"
        timing="exact cycle" if getattr(replay,"snapshot_cycle_mapping_validated",False) else "snapshot timing"
        self.replay_cavitation_status.setText(f"{state} | FFT #{cpc_index+1} | {timing}")
        loss,loss_text=self._current_magnitude_signal_loss()
        corr=self._current_magnitude_correlation(result)
        self.default_cavitation_mr_correlation=corr
        dom_txt=f"RCV{dominant}" if dominant is not None else "--"
        contrib=""
        if result is not None:
            active=[f"RCV{i} {100*v:.0f}%" for i,v in enumerate(result.per_channel_scores) if v>0.05]
            contrib=" | "+", ".join(active) if active else ""
        corr_text=corr.summary if corr is not None else loss_text
        self.replay_cavitation_detail.setText(f"Dominant RCV: {dom_txt}{contrib} | MR {corr_text}")
        self._draw_replay_cavitation_map(result)
        self._draw_replay_mr_correlation(corr)
        self._update_cavitation_intelligence_page()

    def _update_cavitation_visualization(self):
        if not hasattr(self,'cavitation_plot') or not self.current or not self.package: return
        main_hz=self.current.main_frequency_hz or self.package.main_frequency_hz
        trend=self.cavitation_service.compute(self.spectrum_channels,self._selected_channels(),main_hz,max(1,self.current.replay_frame_count),self._index_to_seconds(max(0,self.current.replay_frame_count-1),self.current.replay_frame_count))
        self._cavitation_trend=trend
        if trend is None:
            for curve in (self.cavitation_sub_curve,self.cavitation_ultra_curve,self.cavitation_broad_curve,self.cavitation_total_curve): curve.setData([],[])
            self.cavitation_summary.setText('Spectrum-derived cavitation indicators are unavailable for this sonication.')
            return
        x=np.asarray(trend.time_s,float)
        self.cavitation_sub_curve.setData(x,trend.subharmonic_db,connect='finite'); self.cavitation_ultra_curve.setData(x,trend.ultraharmonic_db,connect='finite'); self.cavitation_broad_curve.setData(x,trend.broadband_db,connect='finite'); self.cavitation_total_curve.setData(x,trend.cavitation_index_db,connect='finite')
        self.cavitation_cursor.setPos(self._index_to_seconds(self.frame_index,self.current.replay_frame_count))
        i=max(0,min(self.frame_index,len(trend.cavitation_index_db)-1)); fmt=lambda v:'N/A' if not np.isfinite(v) else f'{v:.1f} dB'
        self.cavitation_summary.setText(f"Channels: {', '.join(trend.selected_channels)} | f0 {trend.main_frequency_hz/1e6:.3f} MHz | Sub {fmt(trend.subharmonic_db[i])} | Ultra {fmt(trend.ultraharmonic_db[i])} | Broadband {fmt(trend.broadband_db[i])} | Index {fmt(trend.cavitation_index_db[i])}")

    def set_frame(self, index: int, display_mode: str | None = None):
        """Synchronously decode and render one live replay frame.

        This restores the direct RC1 behavior that previously worked. The
        central image, thumbnails, temperature cursor, acoustic spectrum and
        cards are updated in one call. ReplayContext is only a state mirror.
        """
        if not self.current:
            return
        if display_mode is None:
            self._activate_replay_mode_for_navigation()
        else:
            self._main_image_mode = display_mode
        if self._main_image_mode in {"thermal", "anatomy"}:
            self._displayed_plane_override = None
        count = max(1, int(self.current.replay_frame_count))
        target = max(0, min(int(index), count - 1))
        try:
            data = self.replay.frame(self.current, target)
        except Exception as exc:
            self._inline_notice(f"Unable to decode frame: {exc}", error=True)
            return

        self.frame_index = int(data.replay_index)
        try:
            self.replay_context.select_frame(self.frame_index)
            snapshot = self.snapshot_provider.resolve(self.replay_context.selection)
        except Exception:
            snapshot = None
        seconds = self._index_to_seconds(self.frame_index, count)

        self.timeline.blockSignals(True)
        self.timeline.setRange(0, count - 1)
        self.timeline.setValue(self.frame_index)
        self.timeline.blockSignals(False)

        if self.current.temperature_frames:
            ti_source = self.replay.raw.normalize_index(self.frame_index, count, len(self.current.temperature_frames))
            ti = min(range(len(self._thermal_row_map)), key=lambda i: abs(self._thermal_row_map[i] - ti_source)) if self._thermal_row_map else -1
            self.thermal_frame_list.blockSignals(True)
            self.thermal_frame_list.setCurrentRow(ti)
            self.thermal_frame_list.blockSignals(False)
        if self.current.magnitude_frames:
            mi_source = self.replay.raw.normalize_index(self.frame_index, count, len(self.current.magnitude_frames))
            mi = min(range(len(self._anatomy_row_map)), key=lambda i: abs(self._anatomy_row_map[i] - mi_source)) if self._anatomy_row_map else -1
            self.anatomy_frame_list.blockSignals(True)
            self.anatomy_frame_list.setCurrentRow(mi)
            self.anatomy_frame_list.blockSignals(False)

        self.frame_label.setText(
            f"{self._main_image_mode.upper()} | MR acquisition: {seconds:.2f} sec | "
            f"Frame {self.frame_index + 1}/{count} | "
            f"MR {data.magnitude_index + 1 if data.magnitude_index is not None else '-'} | "
            f"Temp {data.temperature_index + 1 if data.temperature_index is not None else '-'}"
        )
        self.temperature_cursor.setPos(seconds)
        if not self.chart_state.temperature_user_zoomed:
            self._fit_temperature_trend(force=True)

        magnitude_levels = self._overlay_session_levels
        if magnitude_levels is None and data.magnitude is not None:
            finite_mag = np.asarray(data.magnitude, float)
            finite_mag = finite_mag[np.isfinite(finite_mag)]
            if finite_mag.size:
                low, high = np.percentile(finite_mag, [2.0, 98.5])
                if high <= low:
                    high = low + 1.0
                magnitude_levels = (float(low), float(high))

        hotspot = (data.hotspot_x, data.hotspot_y) if data.hotspot_x is not None else None
        hotspot_text = None
        if data.maximum_temperature is not None:
            hotspot_text = f"Max = {data.maximum_temperature:.1f} °C\nAvg = {data.mean_temperature:.1f} °C"
        investigation = self.temperature_display_mode.startswith("Δ")
        shown = data.temperature_delta if investigation else data.temperature
        levels = self._delta_levels(shown) if investigation else self._temperature_levels(shown)
        if investigation:
            lut = pg.colormap.get("CET-L4").getLookupTable(0, 1, 256)
        else:
            low, high = levels if levels is not None else (40.0, 60.0)
            lut = self._temperature_lut_with_red_threshold(low, high)

        if self._main_image_mode == "anatomy":
            shown = None
            self.overlay.set_roi(None, None)
            self.overlay.set_hover_temperature(None)
        else:
            self.overlay.set_roi(data.roi_center_x, data.roi_center_y, data.roi_radius, data.roi_width, data.roi_height)
            self.overlay.set_hover_temperature(shown)

        self.overlay.set_overlay(
            data.magnitude, shown, magnitude_levels, levels, lut,
            self.overlay_opacity.value() / 100.0,
            hotspot, hotspot_text, None, fit=self._fit_overlay_next,
        )
        self._fit_overlay_next = False
        if self._restore_overlay_session and self._overlay_session_view:
            self.overlay.set_view_range(self._overlay_session_view)
        if self._restore_overlay_session and self._overlay_session_levels:
            self.overlay.set_magnitude_levels(self._overlay_session_levels)
        self._restore_overlay_session = True
        self.baseline_label.setText(
            f"Source: {data.temperature_source}\nReference: {data.reference_temperature:.1f} °C\nROI: {data.roi_source}"
        )

        if snapshot is not None:
            spectrum_index, spectrum_count = self._update_replay_spectrum(snapshot)
        else:
            spectrum_index, spectrum_count = None, 0
        self._update_analysis_hydrophone()
        self._update_info_window(data, count, spectrum_index, spectrum_count)
        self._update_acoustic_cards(data)
        self._update_cursor_for_frame(data)
        self._apply_workstation_replay_behavior(data, count)
        self._update_orientation_alignment_labels()
        self._update_cavitation_visualization()
        self._update_default_cavitation_intelligence()
        self._refresh_chart_popups()
        self.sync_label.setText(
            f"Image {self.frame_index + 1}/{count} | "
            f"Temperature {data.temperature_index + 1 if data.temperature_index is not None else '-'} | "
            f"Spectrum {spectrum_index + 1 if spectrum_index is not None else '-'}/{spectrum_count or '-'} | "
            f"Phase: {self._workstation_phase}"
        )

    def _workstation_replay_toggled(self, checked: bool) -> None:
        self.workstation_replay_enabled = bool(checked)
        if self.current:
            self.set_frame(self.frame_index, display_mode=self._main_image_mode)

    def _workstation_phase_for_frame(self, data, count: int) -> str:
        """Derive a stable acquisition/heating/cooling phase for replay UI.

        The export does not always contain explicit workstation state markers,
        so the phase is inferred conservatively from measured power and the
        temperature trend.  It is display metadata only and never changes the
        decoded data.
        """
        index = int(getattr(data, "replay_index", self.frame_index) or 0)
        if index <= 0:
            return "MR acquisition"
        power = np.nan
        if getattr(self, "acoustic_control_trend", None) is not None:
            arr = np.asarray(self.acoustic_control_trend.power_percent, float)
            if arr.size:
                power = arr[min(index, arr.size - 1)]
        values = np.asarray(self.max_temperature_trend, float)
        current = values[min(index, values.size - 1)] if values.size else np.nan
        previous = values[min(max(index - 1, 0), values.size - 1)] if values.size else np.nan
        if np.isfinite(power) and power > 3.0:
            return "Sonication"
        if np.isfinite(current) and np.isfinite(previous):
            if current > previous + 0.15:
                return "Heating"
            if current < previous - 0.15:
                return "Cooling"
        if index >= max(0, count - 1):
            return "Complete"
        return "Post acquisition"

    def _apply_workstation_replay_behavior(self, data, count: int) -> None:
        """Mirror the time-progressive behavior seen in the reference video.

        * Trends reveal only samples acquired up to the selected frame.
        * Current Anatomy/Thermal thumbnails remain visible and auto-scroll.
        * Main image stays in live Anatomy/Thermal replay while navigating.
        * Status reports the current acquisition/heating/cooling phase.
        """
        self._workstation_phase = self._workstation_phase_for_frame(data, count)
        if not getattr(self, "workstation_replay_enabled", True):
            # Restore complete trends when progressive replay is disabled.
            tx = self._frame_time_axis(count)
            self.max_temperature_curve.setData(tx, np.asarray(self.max_temperature_trend, float), connect="finite")
            self.mean_temperature_curve.setData(tx, np.asarray(self.mean_temperature_trend, float), connect="finite")
            trend = getattr(self, "acoustic_control_trend", None)
            if trend is not None:
                self.acoustic_power_curve.setData(np.asarray(trend.time_s, float), np.asarray(trend.power_percent, float), connect="finite")
                self.acoustic_score_curve.setData(np.asarray(trend.time_s, float), np.asarray(trend.score_percent, float), connect="finite")
            return

        end = min(max(0, self.frame_index) + 1, count)
        tx = self._frame_time_axis(count)[:end]
        self.max_temperature_curve.setData(tx, np.asarray(self.max_temperature_trend, float)[:end], connect="finite")
        self.mean_temperature_curve.setData(tx, np.asarray(self.mean_temperature_trend, float)[:end], connect="finite")
        if self.cursor_temperature_trend:
            self.cursor_temperature_curve.setData(tx, np.asarray(self.cursor_temperature_trend, float)[:end], connect="finite")

        trend = getattr(self, "acoustic_control_trend", None)
        if trend is not None and np.asarray(trend.time_s).size:
            current_s = self._index_to_seconds(self.frame_index, count)
            mask = np.asarray(trend.time_s, float) <= current_s + 1e-9
            self.acoustic_power_curve.setData(np.asarray(trend.time_s, float)[mask], np.asarray(trend.power_percent, float)[mask], connect="finite")
            self.acoustic_score_curve.setData(np.asarray(trend.time_s, float)[mask], np.asarray(trend.score_percent, float)[mask], connect="finite")

        for strip in (getattr(self, "anatomy_frame_list", None), getattr(self, "thermal_frame_list", None)):
            if strip is None or strip.count() <= 0:
                continue
            row = strip.currentRow()
            if row >= 0:
                item = strip.item(row)
                if item is not None:
                    strip.scrollToItem(item, QListWidget.ScrollHint.PositionAtCenter)

        self.statusBar().showMessage(
            f"Replay {self.frame_index + 1}/{count} · {self._workstation_phase} · "
            f"{self._index_to_seconds(self.frame_index, count):.1f} sec"
        )

    def _update_replay_spectrum(self, snapshot: ReplayFrameSnapshot):
        replay_count = snapshot.selection.frame_count
        selected = self._selected_channels()
        seconds = snapshot.elapsed_seconds
        main_frequency = ((self.current.main_frequency_hz if self.current else None) or
                          (self.package.main_frequency_hz if self.package else None))
        saved_x = self.chart_state.x_ranges.get("spectrum")
        saved_y = self.chart_state.y_ranges.get("spectrum")
        result = self.current_spectrum_renderer.render(
            self.spectrum_plot, self.spectrum_channels, selected,
            self.frame_index, replay_count, self._channel_colors,
            main_frequency, self._map_replay_to_data, seconds,
            mode=self.chart_state.spectrum_mode,
            average_window=self.chart_state.spectrum_average_window,
            frame_indices=dict(snapshot.spectrum_indices),
        )
        self.spectrum_plot.addItem(self.spectrum_hover_text)
        if saved_x is not None:
            self.spectrum_plot.setXRange(*saved_x, padding=0)
        if saved_y is not None:
            self.spectrum_plot.setYRange(*saved_y, padding=0)
        self.spectrum_hover_series = result.series
        first_index = None
        first_count = 0
        statuses = []
        self._spectrum_frame = None
        for channel in selected:
            frames = self.spectrum_channels.get(channel, [])
            if not frames or channel not in result.frame_indices:
                continue
            idx = result.frame_indices[channel]
            statuses.append(f"{channel}:{idx + 1}/{len(frames)}")
            if first_index is None:
                first_index, first_count = idx, len(frames)
                self._spectrum_frame = frames[idx]
        self._spectrum_status = "; ".join(statuses) if statuses else "No SpectrumMsg"
        metric_text = ""
        if result.metrics:
            metric_text = (f" | Sub {result.metrics.get('subharmonic',0.0):.3f}"
                           f" Ultra {result.metrics.get('ultraharmonic',0.0):.3f}"
                           f" BB {result.metrics.get('broadband',0.0):.3f}")
        calibration_text = "CAL ON" if self.hydrophone_calibration is not None and self.hydrophone_calibration.available else "CAL OFF"
        source_text = "CPC" if self.cpc_enabled else "SpectrumMsg"
        axis_text = ""
        if self._spectrum_frame is not None:
            axis_source = getattr(self._spectrum_frame, "frequency_axis_source", "Unknown")
            spacing = getattr(self._spectrum_frame, "frequency_spacing_hz", None)
            if spacing is None:
                freq = np.asarray(getattr(self._spectrum_frame, "frequency", []), float)
                spacing = float(np.median(np.diff(freq))) if freq.size > 1 else None
            if axis_source != "Unknown" or spacing is not None:
                axis_text = f" | Axis: {axis_source}" + (f" Δf={spacing:.3f} Hz" if spacing is not None else "")
        self.current_spectrum_label.setText(f"Spectrum [{source_text} / {calibration_text}]: {self._spectrum_status}{metric_text}{axis_text}")
        return first_index, first_count

    def _update_analysis_hydrophone(self):
        if not hasattr(self, "analysis_spectrum_plot"):
            return
        self.analysis_spectrum_plot.clear()
        selected = self._selected_channels()
        replay_count = self.current.replay_frame_count if self.current else 1
        colors = ["#00bfff", "#ffcc00", "#ff66cc", "#66ff66", "#ff8844", "#cccccc"]
        stacked = self.hydro_arrangement.currentText() == "Stacked"
        for channel_index, channel in enumerate(selected):
            frames = self.spectrum_channels.get(channel, [])
            if not frames:
                continue
            spectrum_index = self._map_replay_to_data(self.frame_index, replay_count, len(frames))
            frame = frames[spectrum_index]
            x = np.asarray(frame.frequency, float) / 1000.0
            y = np.asarray(frame.amplitude, float)
            if stacked and y.size:
                span = max(1.0, float(np.nanmax(y) - np.nanmin(y)))
                y = y - channel_index * span * 1.2
            self.analysis_spectrum_plot.plot(x, y, pen=pg.mkPen(colors[channel_index % len(colors)], width=1.5))
        self._add_spectrum_reference_lines(self.analysis_spectrum_plot, mhz=False)
        self._update_waterfall()

    def _update_waterfall(self):
        selected = self._selected_channels()
        blocks = []
        max_columns = 0
        x_max = 1.0
        current_row = 0
        row_offset = 0
        replay_count = self.current.replay_frame_count if self.current else 1
        for channel in selected:
            frames = self.spectrum_channels.get(channel, [])
            rows = []
            for frame in frames:
                amplitude = np.asarray(frame.amplitude, float)
                if amplitude.size:
                    rows.append(amplitude)
                    max_columns = max(max_columns, amplitude.size)
                    if frame.frequency:
                        x_max = max(x_max, float(frame.frequency[-1]) / 1000.0)
            if rows:
                if not blocks:
                    current_row = row_offset + self._map_replay_to_data(self.frame_index, replay_count, len(rows))
                blocks.append(rows)
                row_offset += len(rows) + 2
        if not blocks or max_columns == 0:
            self.waterfall_image.setImage(np.empty((0, 0)))
            return
        bands = []
        for rows in blocks:
            padded = np.full((len(rows), max_columns), np.nan)
            for row_index, row in enumerate(rows):
                padded[row_index, : len(row)] = row
            bands.append(padded)
            bands.append(np.full((2, max_columns), np.nan))
        image = np.vstack(bands[:-1])
        finite = image[np.isfinite(image)]
        if finite.size:
            low, high = np.percentile(finite, [2, 98])
            self.waterfall_image.setImage(image, autoLevels=False, levels=(float(low), float(high)))
        else:
            self.waterfall_image.setImage(image)
        self.waterfall_image.setRect(QRectF(0, 0, x_max, image.shape[0]))
        self.waterfall_plot.setYRange(0, image.shape[0], padding=0)
        self.waterfall_cursor.setPos(current_row)

    def _threshold_changed(self, value: int):
        self.threshold_value.setText(f"Red starts at {value} °C")
        self.set_frame(self.frame_index)

    def _overlay_cursor_moved(self, x: float, y: float):
        self.cursor_x, self.cursor_y = x, y
        self._rebuild_cursor_temperature_trend()
        self.set_frame(self.frame_index)

    def _overlay_measurement_changed(self, result: dict):
        if not result:
            self.measurement_summary_label.setText("ROI is hidden")
            return
        source = str(result.get("source", "Image"))
        unit = "°C" if source.lower().startswith("temperature") else "a.u."
        self.measurement_summary_label.setText(
            f"Source      {source}\n"
            f"Diameter    {float(result.get('diameter_px', 0.0)):.1f} px\n"
            f"Pixels      {int(result.get('pixels', 0))}\n"
            f"Mean        {float(result.get('mean', 0.0)):.2f} {unit}\n"
            f"Maximum     {float(result.get('max', 0.0)):.2f} {unit}"
        )

    def _clear_overlay_measurement(self):
        self.overlay.hide_measure_roi()
        self.measurement_summary_label.setText("ROI is hidden")

    def _rebuild_cursor_temperature_trend(self):
        self.cursor_temperature_trend = []
        if not self.current or self.cursor_x is None or self.cursor_y is None:
            self.cursor_temperature_curve.setData([], [])
            return
        for i in range(self.current.replay_frame_count):
            try:
                data = self.replay.frame(self.current, i)
                arr = data.temperature
                if arr is None:
                    self.cursor_temperature_trend.append(np.nan); continue
                xi = int(np.clip(round(self.cursor_x), 0, arr.shape[1]-1))
                yi = int(np.clip(round(self.cursor_y), 0, arr.shape[0]-1))
                self.cursor_temperature_trend.append(float(arr[yi, xi]))
            except Exception:
                self.cursor_temperature_trend.append(np.nan)
        self.cursor_temperature_curve.setData(self._frame_time_axis(len(self.cursor_temperature_trend)), np.asarray(self.cursor_temperature_trend,float))

    def _update_cursor_for_frame(self, data):
        arr = data.temperature
        if arr is None:
            self.cursor_temperature_label.setText("Temperature   --\nX             --\nY             --")
            return
        if self.cursor_x is None or self.cursor_y is None:
            self.cursor_temperature_label.setText("Click or drag the small cyan target to inspect temperature.")
            return
        xi = int(np.clip(round(self.cursor_x),0,arr.shape[1]-1)); yi = int(np.clip(round(self.cursor_y),0,arr.shape[0]-1))
        value=float(arr[yi,xi])
        self.overlay.set_cursor(self.cursor_x,self.cursor_y,f"T {value:.1f} °C\nX {xi}  Y {yi}")
        self.cursor_temperature_label.setText(f"Temperature   {value:.1f} °C\nX             {xi} px\nY             {yi} px")

    def _show_info_window(self):
        if self.info_window.isVisible(): return
        self.info_window.show(); self.info_window.raise_(); self.info_window.activateWindow()

    def _show_mr_window(self):
        if self.mr_window.isVisible(): return
        self.mr_window.show(); self.mr_window.raise_(); self.mr_window.activateWindow()

    def _show_scan_window(self):
        if self.scan_window.isVisible(): return
        self.scan_window.show(); self.scan_window.raise_(); self.scan_window.activateWindow()

    def _show_xd_window(self):
        if self.current is not None and self.package is not None:
            self.xd_window.set_data(self.skull_measures_service.find_and_read(
                self.current.folder, self.sonication_index + 1, self.package.workspace
            ))
        if self.xd_window.isVisible():
            self.xd_window.raise_(); self.xd_window.activateWindow(); return
        self.xd_window.show(); self.xd_window.raise_(); self.xd_window.activateWindow()

    def _update_sonication_metadata(self):
        if not self.current or not self.package: return
        self.current_metadata=self.metadata_service.read(self.current,self.package,self.sonication_index+1)
        for key,label in self.summary_value_labels.items():
            if key in ("Displayed Plane", "Orientation Status"):
                continue
            label.setText(self.current_metadata.summary.get(key,"Unavailable"))
        self._update_orientation_alignment_labels()
        mr_rows = list(self.current_metadata.mr or [])
        scan_rows = list(self.current_metadata.scan or [])
        if not mr_rows:
            mr_rows = [
                ("Sonication", self.current.name),
                ("Magnitude RAW files", len(self.current.magnitude_frames)),
                ("Temperature RAW files", len(self.current.temperature_frames)),
                ("Main frequency", f"{((self.current.main_frequency_hz or self.package.main_frequency_hz or 0)/1_000_000):.3f} MHz"),
                ("Source folder", str(self.current.folder)),
            ]
        if not scan_rows:
            scan_rows = [
                ("Replay frames", self.current.replay_frame_count),
                ("Magnitude frames", len(self.current.magnitude_frames)),
                ("Temperature frames", len(self.current.temperature_frames)),
                ("Spectrum files", len(self.current.spectrum_files)),
                ("ACT files", len(self.current.act_files)),
            ]
        self.mr_window.update_rows(mr_rows)
        self.scan_window.update_rows(scan_rows)
        self.xd_window.set_data(self.skull_measures_service.find_and_read(self.current.folder, self.sonication_index + 1, self.package.workspace))

    def _update_info_window(self, data, count, spectrum_index, spectrum_count):
        frequency = ((self.current.main_frequency_hz if self.current else None) or (self.package.main_frequency_hz if self.package else 0.0)) / 1_000_000.0
        summary = self.current_metadata.summary if self.current_metadata else {}
        rows=[
            ("Sonication No.", f"{self.sonication_index+1} / {len(self.package.sonications) if self.package else '-'}"),
            ("Orientation", summary.get("Orientation", "Unavailable")),
            ("Displayed Plane", self._displayed_plane()),
            ("Orientation Status", self.summary_value_labels["Orientation Status"].text() if "Orientation Status" in self.summary_value_labels else "Unavailable"),
            ("Frequency Direction", summary.get("Frequency Dir", "Unavailable")),
            ("Target Power", summary.get("Target Power", "Unavailable")),
            ("Actual Power", summary.get("Actual Power", "Unavailable")),
            ("Target Duration", summary.get("Target Duration", "Unavailable")),
            ("Actual Duration", summary.get("Actual Duration", "Unavailable")),
            ("Target Energy", summary.get("Target Energy", "Unavailable")),
            ("Actual Energy", summary.get("Actual Energy", "Unavailable")),
            ("Hotspot Check", summary.get("Hotspot Check", "Unavailable")),
            ("Name", self.current.name if self.current else "-"),
            ("Replay Completeness", f"{self.current.completeness_status} ({self.current.completeness_score}%)" if self.current else "-"),
            ("Replay Available", "Yes — best-effort reconstruction" if self.current and self.current.replay_frame_count > 0 else "No"),
            ("Missing for Full Replay", "; ".join(self.current.missing_required) if self.current and self.current.missing_required else "None"),
            ("Missing Optional", "; ".join(self.current.missing_optional) if self.current and self.current.missing_optional else "None"),
            ("Degraded / Limited", "; ".join(self.current.degraded_items) if self.current and self.current.degraded_items else "None"),
            ("Workflow", getattr(self.package, "workflow_mode", "Unknown") if self.package else "Unknown"),
            ("Thermometry", getattr(self.current, "thermometry_mode", "Unknown") if self.current else "Unknown"),
            ("Frequency", summary.get("Frequency", "Unavailable")),
            ("Replay Frame", f"{self.frame_index+1}/{count}"),
            ("Temperature RAW", data.temperature_index+1 if data.temperature_index is not None else "-"),
            ("SpectrumMsg", f"{spectrum_index+1 if spectrum_index is not None else '-'}/{spectrum_count or '-'}"),
            ("Temperature Source", data.temperature_source),
            ("Reference Temperature", f"{data.reference_temperature:.1f} °C"),
            ("ROI Source", data.roi_source),
            ("Max Temperature (ROI)", f"{data.maximum_temperature:.1f} °C" if data.maximum_temperature is not None else "-"),
            ("Average Temperature (ROI)", f"{data.mean_temperature:.1f} °C" if data.mean_temperature is not None else "-"),
            ("Loaded Folder", str(self.package.source_path) if self.package and hasattr(self.package,'source_path') else "-"),
        ]
        self.info_window.update_rows(rows)

    def _update_acoustic_cards(self, data):
        trend = getattr(self, "acoustic_control_trend", None)
        if trend is not None:
            self.acoustic_power_curve.setData(np.asarray(trend.time_s,float), np.asarray(trend.power_percent,float), connect="finite")
            self.acoustic_score_curve.setData(np.asarray(trend.time_s,float), np.asarray(trend.score_percent,float), connect="finite")
        self.acoustic_control_cursor.setPos(self._index_to_seconds(self.frame_index,self.current.replay_frame_count) if self.current else 0)
        if trend is None or self.frame_index >= len(trend.power_percent):
            self.acoustic_power_value.setText("Unavailable")
            self.acoustic_score_value.setText("Unavailable")
            self.acoustic_cavitation_value.setText("Unavailable")
            self.acoustic_power_text.setText("Power: --")
            self.acoustic_score_text.setText("Score: --")
            return
        power = trend.power_percent[self.frame_index]
        score = trend.score_percent[self.frame_index]
        energy = trend.energy[self.frame_index]
        limit = trend.harmless_limit[self.frame_index]
        power_text = f"{power:.1f} %" if np.isfinite(power) else "--"
        score_text = f"{score:.1f} %" if np.isfinite(score) else "--"
        self.acoustic_power_value.setText(power_text)
        self.acoustic_score_value.setText(score_text)
        self.acoustic_power_text.setText(f"Power: {power_text}")
        self.acoustic_score_text.setText(f"Score: {score_text}")
        x_max = self._index_to_seconds(max(0, self.current.replay_frame_count - 1), self.current.replay_frame_count) if self.current else 0.0
        self.acoustic_power_text.setPos(x_max, 106.0)
        self.acoustic_score_text.setPos(x_max, 88.0)
        if np.isfinite(energy) and np.isfinite(limit):
            self.acoustic_cavitation_value.setText(f"{energy:.5f} / {limit:.5f}")
        else:
            self.acoustic_cavitation_value.setText("Unavailable")

    def _update_replay_waterfall(self, replay_count: int):
        """Render the true all-bin Time × Frequency spectrogram.

        Coloured overlay lines are selected channels' current-frame FFT curves,
        not peak-frequency or ridge histories. The popup uses this same renderer.
        """
        selected = self._selected_channels()
        source = "Sonication SpectrumMsg"
        result = self.relative_spectrum_renderer.render(
            self.waterfall_replay_plot, self.spectrum_channels, selected,
            self.frame_index, replay_count, self._channel_colors,
            (self.current.main_frequency_hz if self.current else None) or
            (self.package.main_frequency_hz if self.package else None),
            f"Relative Acoustic Spectrum · {source} · {', '.join(selected)}",
        )
        self.waterfall_replay_image = result.image_item

    # ------------------------------------------------------------- Helpers
    def _load_spectrum_channels(self):
        channels = {f"CH{i}": [] for i in range(8)}
        configured = self.sonication_channel_service.read(self.current.folder) if self.current else None
        configured_index = configured.channel if configured and configured.channel is not None else 0
        self._active_spectrum_channel = f"CH{configured_index}"

        son_frames = [] if self.cpc_enabled else self.spectrum_provider.load(list(self.current.spectrum_files), source_kind="Sonication")
        for frame in son_frames:
            explicit = self._channel_name(Path(frame.source), default=None)
            channel = explicit if explicit is not None else self._active_spectrum_channel
            frame.channel = int(channel[2:]); channels[channel].append(frame)

        # CPC mode is a real source switch.  It uses the validated independent
        # 8CH decoder and maps only the CPC file belonging to this sonication.
        if self.cpc_enabled and self.package is not None and self.current is not None:
            replay = self.hydrophone_replay_service.build(
                self.package.cpc_spectrum_files, self.sonication_index, len(self.package.sonications)
            )
            for frame in replay.frames:
                frequency = np.asarray(frame.frequency_hz, dtype=float)
                for channel_index, amplitude in enumerate(frame.channels[:8]):
                    calibrated = np.asarray(amplitude, dtype=float)
                    channels[f"CH{channel_index}"].append(SpectrumFrame(
                        index=frame.index,
                        frequency=[float(v) for v in frequency],
                        amplitude=[float(v) for v in calibrated],
                        timestamp_seconds=frame.index * replay.frame_interval_s,
                        confidence=1.0,
                        source=str(replay.source_fft or "CPC FFT"),
                        channel=channel_index,
                        source_kind="CPCFiles mapped",
                        frequency_axis_source=replay.frequency_axis_source,
                        frequency_start_hz=replay.frequency_start_hz,
                        frequency_spacing_hz=replay.frequency_spacing_hz,
                        frequency_end_hz=replay.frequency_end_hz,
                    ))
            if replay.frames:
                son_frames = []

        self.spectrum_channels = channels
        self._rebuild_channel_controls()

    def _rebuild_channel_controls(self):
        previous = set(self.chart_state.selected_channels)
        for action in self.channel_actions.values():
            self.channel_menu.removeAction(action); action.deleteLater()
        self.channel_actions.clear()
        if not self.chart_state.user_selected_channels:
            previous = {self._active_spectrum_channel}
            self.chart_state.selected_channels = set(previous)
        for name in [f"CH{i}" for i in range(8)]:
            action = QAction(name, self.channel_menu)
            action.setCheckable(True); action.setChecked(name in previous)
            action.toggled.connect(self._channel_selection_changed)
            self.channel_actions[name] = action; self.channel_menu.addAction(action)
        self.all_channels_action.blockSignals(True)
        self.all_channels_action.setChecked(len(previous) == 8)
        self.all_channels_action.blockSignals(False)
        self._update_channel_button_text()

    def _cpc_toggled(self, checked: bool):
        self.cpc_enabled = bool(checked); self.chart_state.cpc_enabled = self.cpc_enabled
        self.cpc_button.setText("CPC ON" if checked else "CPC OFF")
        if self.current is not None:
            self._load_spectrum_channels(); self.set_frame(self.frame_index)
        count = len(self.package.cpc_spectrum_files) if self.package is not None else 0
        self.statusBar().showMessage(f"CPCFiles {'enabled' if checked else 'disabled'} ({count} candidate DMP file(s))")

    def _toggle_all_channels(self, checked: bool):
        self.chart_state.user_selected_channels = True
        for action in self.channel_actions.values():
            action.blockSignals(True); action.setChecked(checked); action.blockSignals(False)
        self.chart_state.selected_channels = set(self.channel_actions) if checked else set()
        self._update_channel_button_text(); self.set_frame(self.frame_index)

    def _channel_selection_changed(self):
        self.chart_state.user_selected_channels = True
        selected={name for name,action in self.channel_actions.items() if action.isChecked()}
        self.chart_state.selected_channels=set(selected)
        self.all_channels_action.blockSignals(True)
        self.all_channels_action.setChecked(len(selected)==len(self.channel_actions) and bool(selected))
        self.all_channels_action.blockSignals(False)
        self._update_channel_button_text(); self.set_frame(self.frame_index)

    def _update_channel_button_text(self):
        selected = [name for name, action in self.channel_actions.items() if action.isChecked()]
        if selected and len(selected) == len(self.channel_actions): self.channel_button.setText("CH: All")
        elif len(selected) == 1: self.channel_button.setText(f"CH: {selected[0]}")
        elif selected: self.channel_button.setText(f"CH: {len(selected)}")
        else: self.channel_button.setText("CH: None")

    def _selected_channels(self):
        selected = [name for name, action in self.channel_actions.items() if action.isChecked()]
        return selected or [self._active_spectrum_channel]

    def _hydro_layout_changed(self):
        mode = self.hydro_view.currentText()
        self.analysis_spectrum_plot.setVisible(mode in ("Both", "Spectrum"))
        self.waterfall_plot.setVisible(mode in ("Both", "Waterfall"))
        if mode == "Spectrum":
            self.hydro_splitter.setSizes([1000, 0])
        elif mode == "Waterfall":
            self.hydro_splitter.setSizes([0, 1000])
        else:
            self.hydro_splitter.setSizes([600, 600])
        self._update_analysis_hydrophone()

    def _update_parameter_table(self, data, count: int, spectrum_index, spectrum_count):
        frequency_mhz = ((self.current.main_frequency_hz if self.current else None) or self.package.main_frequency_hz) / 1_000_000.0
        rows = [
            ("Energy", "From ACT when available", "Sonication", self.current.name),
            ("Power", "From ACT when available", "Replay Frame", f"{self.frame_index + 1}/{count}"),
            ("Duration", f"{self._index_to_seconds(count - 1, count):.1f} sec", "Temperature RAW", f"{data.temperature_index + 1 if data.temperature_index is not None else '-'}"),
            ("Frequency", f"{frequency_mhz:.3f} MHz", "SpectrumMsg", f"{spectrum_index + 1 if spectrum_index is not None else '-'}/{spectrum_count or '-'}"),
            ("Temperature Source", data.temperature_source, "Max Temperature (ROI)", f"{data.maximum_temperature:.1f} °C" if data.maximum_temperature is not None else "-"),
            ("Reference Temperature", f"{data.reference_temperature:.1f} °C", "Average Temperature (ROI)", f"{data.mean_temperature:.1f} °C" if data.mean_temperature is not None else "-"),
            ("ROI Source", data.roi_source, "Max ΔTemperature", f"{data.maximum_delta_temperature:.1f} °C" if data.maximum_delta_temperature is not None else "-"),
        ]
        self.parameter_table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            for column_index, value in enumerate(row):
                self.parameter_table.setItem(row_index, column_index, QTableWidgetItem(str(value)))

    def _add_spectrum_reference_lines(self, plot, mhz: bool):
        if not self.package:
            return
        divisor = 1_000_000.0 if mhz else 1000.0
        main = self.package.main_frequency_hz / divisor
        for frequency, label in ((main / 2, "Sub"), (main, "Main"), (main * 2, "2nd"), (main * 3, "3rd")):
            plot.addItem(pg.InfiniteLine(pos=frequency, angle=90, movable=False, label=label))

    def _current_temperature_range(self):
        levels=self._temperature_levels(None)
        return levels if levels is not None else (40.0,60.0)

    def _temperature_range_changed(self, _index):
        lo,hi=self._current_temperature_range()
        self.temperature_plot.setYRange(lo,hi,padding=0)
        self.settings.setValue("temperature_range", self.range_combo.currentText())
        self.set_frame(self.frame_index)

    def _capture_overlay_state_debounced(self):
        if hasattr(self,"_overlay_save_timer"):
            self._overlay_save_timer.start(120)

    def _save_overlay_state(self):
        if hasattr(self,"overlay") and self._restore_overlay_session:
            self._overlay_session_view = self.overlay.view_range()

    def _capture_overlay_levels(self, low, high):
        if self._restore_overlay_session:
            self._overlay_session_levels = (float(low), float(high))

    @staticmethod
    def _amplitude_db(values):
        amplitude=np.abs(np.nan_to_num(np.asarray(values,float),nan=0.0,posinf=0.0,neginf=0.0))
        if amplitude.size == 0:
            return amplitude
        reference=max(float(np.nanmax(amplitude)),1e-30)
        return np.clip(20.0*np.log10(np.maximum(amplitude,reference*1e-5)/reference),-100.0,0.0)

    @staticmethod
    def _relative_spectrum(values):
        """Scale one spectrum onto the workstation-like 0..4 relative axis."""
        amplitude = np.abs(np.nan_to_num(np.asarray(values, float), nan=0.0, posinf=0.0, neginf=0.0))
        if amplitude.size == 0:
            return amplitude
        baseline = float(np.percentile(amplitude, 10))
        signal = np.maximum(amplitude - baseline, 0.0)
        reference = float(np.percentile(signal, 99.5))
        if not np.isfinite(reference) or reference <= 1e-30:
            reference = max(float(np.nanmax(signal)), 1e-30)
        normalized = signal / reference
        # Keep quiet frames slightly above zero so the noise floor is visible,
        # while cavitation peaks retain enough headroom to stand out clearly.
        return np.clip(0.08 + normalized * 7.2, 0.0, 8.0)

    def _temperature_lut_with_red_threshold(self, low: float, high: float):
        """Keep all temperature colors visible and move the red transition only."""
        low, high = float(low), float(high)
        if high <= low:
            high = low + 1.0
        red = float(np.clip(self.threshold_slider.value(), low, high))
        split = float(np.clip((red - low) / (high - low), 0.02, 0.98))
        positions = np.asarray([0.0, max(0.0, split * 0.55), max(0.0, split * 0.85), split, 1.0], float)
        positions = np.maximum.accumulate(positions)
        colors = np.asarray([
            (0, 0, 0, 0),
            (255, 235, 45, 180),
            (255, 145, 20, 215),
            (255, 0, 0, 240),
            (255, 0, 0, 255),
        ], dtype=np.ubyte)
        cmap = pg.ColorMap(positions, colors)
        return cmap.getLookupTable(0.0, 1.0, 256)

    def _temperature_mode_changed(self, text: str):
        self.temperature_display_mode = text
        self.range_combo.setEnabled(not text.startswith("Δ"))
        self.threshold_slider.setEnabled(not text.startswith("Δ"))
        self.set_frame(self.frame_index)

    def _temperature_levels(self, temperature):
        index = self.range_combo.currentIndex()
        if index == 0:
            return 40.0, 60.0
        if index == 1:
            return 35.0, 60.0
        if index == 2:
            return 30.0, 90.0
        if index == 3:
            return 0.0, 60.0
        finite = temperature[np.isfinite(temperature)] if temperature is not None else np.array([])
        if not finite.size:
            return None
        lo, hi = np.percentile(finite, [1, 99.5])
        return float(lo), max(float(lo) + 1.0, float(hi))

    def _delta_levels(self, delta):
        finite = delta[np.isfinite(delta)] if delta is not None else np.array([])
        return (0.0, max(1.0, float(np.percentile(finite, 99)))) if finite.size else None

    @staticmethod
    def _channel_name(path: Path, default: str | None = "CH0") -> str | None:
        text = f"{path.parent.name}_{path.stem}"
        for pattern in (r"(?:^|[_\- ])(?:CH|HP)[_\- ]?(\d+)", r"hydrophone[_\- ]?(\d+)"):
            match = re.search(pattern, text, re.I)
            if match:
                return f"CH{int(match.group(1))}"
        return default

    @staticmethod
    def _map_replay_to_data(index: int, replay_count: int, data_count: int) -> int:
        """Map one replay position to another stream with endpoint-safe ratio.

        This is the explicit fallback when timestamps are absent. It guarantees
        frame movement changes Spectrum/Waterfall position instead of leaving a
        static first record.
        """
        if data_count <= 1 or replay_count <= 1:
            return 0
        ratio = index / float(replay_count - 1)
        return max(0, min(data_count - 1, int(round(ratio * (data_count - 1)))))

    @staticmethod
    def _map_data_to_replay(index: int, data_count: int, replay_count: int) -> int:
        """Inverse endpoint-safe mapping used by thumbnail selection."""
        if replay_count <= 1 or data_count <= 1:
            return 0
        ratio = max(0, min(data_count - 1, int(index))) / float(data_count - 1)
        return max(0, min(replay_count - 1, int(round(ratio * (replay_count - 1)))))


    def _index_to_seconds(self, index: int, count: int) -> float:
        if count <= 1:
            return 0.0
        duration = float(getattr(self, "current_timeline_duration_s", 0.0) or 0.0)
        if duration <= 0:
            duration = float(count - 1)
        ratio = max(0.0, min(1.0, float(index) / float(count - 1)))
        return ratio * duration

    def _replay_duration_s(self) -> float:
        """Return the active replay duration without assuming metadata exists."""
        count = int(getattr(self.current, "replay_frame_count", 0) or 0) if self.current else 0
        duration = float(getattr(self, "current_timeline_duration_s", 0.0) or 0.0)
        if duration > 0.0:
            return duration
        return float(max(0, count - 1))

    def _seconds_to_index(self, seconds: float, count: int) -> int:
        """Map a chart time back to a replay index, clamped to valid bounds."""
        count = max(1, int(count or 1))
        if count <= 1:
            return 0
        duration = self._replay_duration_s()
        if duration <= 0.0:
            return max(0, min(count - 1, int(round(float(seconds)))))
        ratio = max(0.0, min(1.0, float(seconds) / duration))
        return max(0, min(count - 1, int(round(ratio * (count - 1)))))

    def _frame_time_axis(self, count: int):
        return np.asarray([self._index_to_seconds(index, count) for index in range(count)], float)

    @staticmethod
    def _array_icon(array):
        if array is None:
            return QIcon()
        values = np.nan_to_num(np.asarray(array, float))
        low, high = np.percentile(values, [2, 98]) if values.size else (0, 1)
        if high <= low:
            high = low + 1
        gray = np.clip((values - low) / (high - low) * 255, 0, 255).astype(np.uint8)
        rgb = np.stack([gray, gray, gray], axis=2)
        height, width = rgb.shape[:2]
        image = QImage(rgb.data, width, height, 3 * width, QImage.Format.Format_RGB888).copy()
        return QIcon(QPixmap.fromImage(image).scaled(110, 100, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    def _open_chart_popup(self,key: str):
        popup=ChartPopup({"temperature":"Temperature Trend (ROI)","spectrum":"Acoustic Spectrum","acoustic":"Power % / Score","waterfall":"Relative Acoustic Spectrum (disabled)"}.get(key,key),self)
        if not hasattr(self,"_chart_popups"): self._chart_popups=[]
        popup.chart_key=key; self._chart_popups.append(popup)
        self._render_chart_popup(popup)
        popup.show(); popup.raise_()

    def _render_chart_popup(self,popup):
        key=getattr(popup,"chart_key",""); plot=popup.plot; plot.clear(); popup.hover_text=pg.TextItem(anchor=(0,1),color="#ffffff",fill=pg.mkBrush(0,0,0,210)); popup.hover_text.setZValue(100); popup.hover_text.hide(); plot.addItem(popup.hover_text)
        popup.hover_series=[]
        if key=="temperature":
            x=self._frame_time_axis(len(self.max_temperature_trend)); lo,hi=self._temperature_data_range(); plot.setYRange(lo,hi,padding=0.05); plot.setLabel("left","Temperature",units="°C"); plot.setLabel("bottom","Replay time",units="sec")
            if len(x): plot.setXRange(float(x[0]), float(x[-1]), padding=0.02)
            plot.plot(x,self.max_temperature_trend,pen=pg.mkPen("#ff3b30",width=3),connect="finite"); plot.plot(x,self.mean_temperature_trend,pen=pg.mkPen("#49e36b",width=2.5),connect="finite")
            if self.cursor_temperature_trend: plot.plot(x,self.cursor_temperature_trend,pen=pg.mkPen("#b98cff",width=1.6,style=Qt.PenStyle.DashLine))
            plot.addLine(x=self._index_to_seconds(self.frame_index,len(x)),pen=pg.mkPen("#00bfff",width=1.3))
            popup.set_hover_series([("Max",x,self.max_temperature_trend," °C"),("ROI Avg",x,self.mean_temperature_trend," °C"),("Cursor",x,self.cursor_temperature_trend," °C")])
        elif key=="acoustic":
            trend=getattr(self,"acoustic_control_trend",None); plot.setYRange(0,110,padding=0); plot.setLabel("left","Power / Score",units="%"); plot.setLabel("bottom","Replay time",units="sec")
            if trend is not None:
                plot.plot(trend.time_s,trend.power_percent,pen=pg.mkPen("#58f26a",width=2.5),connect="finite"); plot.plot(trend.time_s,trend.score_percent,pen=pg.mkPen("#ff9d22",width=2.5),connect="finite"); plot.addLine(x=self._index_to_seconds(self.frame_index,self.current.replay_frame_count),pen=pg.mkPen("#00bfff",width=1.3))
                popup.set_hover_series([("Power",trend.time_s,trend.power_percent," %"),("Score",trend.time_s,trend.score_percent," %")])
        elif key=="spectrum":
            selected=self._selected_channels()
            replay_count=self.current.replay_frame_count if self.current else 1
            main_frequency=((self.current.main_frequency_hz if self.current else None) or
                            (self.package.main_frequency_hz if self.package else None))
            result=self.current_spectrum_renderer.render(
                plot, self.spectrum_channels, selected, self.frame_index,
                replay_count, self._channel_colors, main_frequency,
                self._map_replay_to_data,
                self._index_to_seconds(self.frame_index,replay_count),
                mode=self.chart_state.spectrum_mode,
                average_window=self.chart_state.spectrum_average_window,
            )
            plot.addItem(popup.hover_text)
            saved_x=self.chart_state.x_ranges.get("spectrum")
            saved_y=self.chart_state.y_ranges.get("spectrum")
            if saved_x is not None: plot.setXRange(*saved_x,padding=0)
            if saved_y is not None: plot.setYRange(*saved_y,padding=0)
            popup.set_hover_series(result.series)
        elif key=="waterfall":
            self._render_waterfall_popup(plot)

    def _render_waterfall_popup(self,plot):
        selected=self._selected_channels()
        source="Sonication SpectrumMsg"
        self.relative_spectrum_renderer.render(
            plot, self.spectrum_channels, selected, self.frame_index,
            self.current.replay_frame_count if self.current else 1,
            self._channel_colors,
            (self.current.main_frequency_hz if self.current else None) or
            (self.package.main_frequency_hz if self.package else None),
            f"Relative Acoustic Spectrum · {source} · {', '.join(selected)}",
        )

    def _refresh_chart_popups(self):
        for popup in list(getattr(self,"_chart_popups",[])):
            if popup.isVisible(): self._render_chart_popup(popup)

    # -------------------------------------------------------------- Controls
    def _spectrum_mode_changed(self, text: str) -> None:
        self.chart_state.spectrum_mode = text or "Average"
        if self.current:
            self.set_frame(self.frame_index)

    def _temperature_data_range(self) -> tuple[float, float]:
        arrays = [self.max_temperature_trend, self.mean_temperature_trend, self.cursor_temperature_trend]
        finite = []
        for values in arrays:
            arr = np.asarray(values, float)
            if arr.size:
                finite.append(arr[np.isfinite(arr)])
        finite = [v for v in finite if v.size]
        if not finite:
            return self._current_temperature_range()
        values = np.concatenate(finite)
        low = float(np.nanmin(values)); high = float(np.nanmax(values))
        pad = max(1.0, (high-low)*0.10)
        return low-pad, high+pad

    def _fit_temperature_trend(self, force: bool = False) -> None:
        if not self.current or (self.chart_state.temperature_user_zoomed and not force):
            return
        x = self._frame_time_axis(self.current.replay_frame_count)
        if not len(x):
            return
        lo, hi = self._temperature_data_range()
        self._updating_temperature_range = True
        try:
            self.temperature_plot.setXRange(float(x[0]), float(x[-1]), padding=0.02)
            self.temperature_plot.setYRange(lo, hi, padding=0.02)
        finally:
            self._updating_temperature_range = False

    def _temperature_range_changed_by_user(self, *_args) -> None:
        if self._updating_temperature_range:
            return
        self.chart_state.temperature_user_zoomed = True
        try:
            xr, yr = self.temperature_plot.plotItem.vb.viewRange()
            self.chart_state.remember_range("temperature", xr, yr)
        except Exception:
            pass

    def _remember_chart_range(self, key: str, plot) -> None:
        try:
            x_range, y_range = plot.plotItem.vb.viewRange()
            self.chart_state.remember_range(key, x_range, y_range)
        except Exception:
            return

    def _show_chart_tooltip(self, widget, lines) -> None:
        popup = None
        if widget is self.spectrum_plot:
            popup = getattr(self, "spectrum_hover_popup", None)
        elif widget is self.acoustic_control_plot:
            popup = getattr(self, "acoustic_hover_popup", None)
        elif widget is self.temperature_plot:
            popup = getattr(self, "temperature_hover_popup", None)
        if popup is not None:
            popup.show_lines(lines)
        # Keep native tooltip as a secondary accessibility fallback.
        text = "\n".join(str(line) for line in lines if str(line))
        if text:
            QToolTip.showText(QCursor.pos(), text, widget, widget.rect(), 1200)
        else:
            QToolTip.hideText()

    def _hide_chart_tooltip(self, widget) -> None:
        if widget is self.spectrum_plot:
            popup = getattr(self, "spectrum_hover_popup", None)
        elif widget is self.acoustic_control_plot:
            popup = getattr(self, "acoustic_hover_popup", None)
        else:
            popup = getattr(self, "temperature_hover_popup", None)
        if popup is not None:
            popup.hide()
        QToolTip.hideText()

    def _spectrum_plot_hovered(self, event):
        scene_pos = event[0] if isinstance(event, (tuple, list)) else event
        if not self.spectrum_hover_series or not self.spectrum_plot.sceneBoundingRect().contains(scene_pos):
            self.spectrum_hover_text.hide(); self._hide_chart_tooltip(self.spectrum_plot); return
        point = self.spectrum_plot.plotItem.vb.mapSceneToView(scene_pos)
        lines = [f"Frequency: {point.x():.4f} MHz"]
        best_y = None
        for label, x_values, y_values, _unit in self.spectrum_hover_series:
            x=np.asarray(x_values,float); y=np.asarray(y_values,float)
            valid=np.isfinite(x)&np.isfinite(y)
            if not valid.any(): continue
            xv=x[valid]; yv=y[valid]; i=int(np.argmin(np.abs(xv-point.x())))
            value=float(yv[i]); lines.append(f"{label}: {value:.3f}")
            if best_y is None: best_y=value
        if best_y is None:
            self.spectrum_hover_text.hide(); self._hide_chart_tooltip(self.spectrum_plot); return
        self.spectrum_hover_text.setText("\n".join(lines))
        self.spectrum_hover_text.setPos(point.x(), best_y)
        self.spectrum_hover_text.show()
        self._show_chart_tooltip(self.spectrum_plot, lines)

    def _acoustic_plot_hovered(self, event):
        scene_pos=event[0] if isinstance(event,(tuple,list)) else event
        trend=getattr(self,"acoustic_control_trend",None)
        if trend is None or not self.acoustic_control_plot.sceneBoundingRect().contains(scene_pos):
            self.acoustic_hover_text.hide(); self._hide_chart_tooltip(self.acoustic_control_plot); return
        point=self.acoustic_control_plot.plotItem.vb.mapSceneToView(scene_pos)
        x=np.asarray(trend.time_s,float)
        if not x.size: self.acoustic_hover_text.hide(); return
        i=int(np.argmin(np.abs(x-point.x())))
        lines=[f"{x[i]:.2f} sec"]
        if i < len(trend.power_percent) and np.isfinite(trend.power_percent[i]): lines.append(f"Power: {trend.power_percent[i]:.1f} %")
        if i < len(trend.score_percent) and np.isfinite(trend.score_percent[i]): lines.append(f"Score: {trend.score_percent[i]:.1f} %")
        self.acoustic_hover_text.setText("\n".join(lines)); self.acoustic_hover_text.setPos(point.x(),point.y()); self.acoustic_hover_text.show()
        self._show_chart_tooltip(self.acoustic_control_plot, lines)

    def _temperature_plot_clicked(self, event):
        if not self.current:
            return
        point = self.temperature_plot.plotItem.vb.mapSceneToView(event.scenePos())
        self.set_frame(self._seconds_to_index(point.x(), self.current.replay_frame_count))

    def _temperature_plot_hovered(self, event):
        if not self.current or not self.max_temperature_trend:
            self.temperature_hover_text.hide(); self._hide_chart_tooltip(self.temperature_plot); return
        scene_pos = event[0] if isinstance(event, (tuple, list)) else event
        if not self.temperature_plot.sceneBoundingRect().contains(scene_pos):
            self.temperature_hover_text.hide(); self._hide_chart_tooltip(self.temperature_plot); return
        point = self.temperature_plot.plotItem.vb.mapSceneToView(scene_pos)
        index = self._seconds_to_index(point.x(), len(self.max_temperature_trend))
        max_t = self.max_temperature_trend[index]
        avg_t = self.mean_temperature_trend[index] if index < len(self.mean_temperature_trend) else np.nan
        cursor_t = self.cursor_temperature_trend[index] if index < len(self.cursor_temperature_trend) else np.nan
        lines = [f"{self._index_to_seconds(index, len(self.max_temperature_trend)):.1f} sec"]
        if np.isfinite(max_t): lines.append(f"Max {max_t:.1f} °C")
        if np.isfinite(avg_t): lines.append(f"Avg {avg_t:.1f} °C")
        if np.isfinite(cursor_t): lines.append(f"Cursor {cursor_t:.1f} °C")
        self.temperature_hover_text.setText("\n".join(lines))
        self.temperature_hover_text.setPos(point.x(), point.y())
        self.temperature_hover_text.show()
        self._show_chart_tooltip(self.temperature_plot, lines)

    def _acoustic_plot_clicked(self, event):
        if not self.current:
            return
        point = self.acoustic_control_plot.plotItem.vb.mapSceneToView(event.scenePos())
        self.set_frame(self._seconds_to_index(point.x(), self.current.replay_frame_count))

    def slider_changed(self, value):
        self._activate_replay_mode_for_navigation()
        self.set_frame(value)

    def previous_frame(self):
        if not self.current:
            return
        self._activate_replay_mode_for_navigation()
        self.set_frame(self.frame_index - 1)

    def next_frame(self):
        if not self.current:
            return
        self._activate_replay_mode_for_navigation()
        current = self.frame_index
        count = max(1, self.current.replay_frame_count)
        target = current + 1
        if target >= count:
            if self.timer.isActive() and getattr(self, "workstation_replay_enabled", True):
                self.timer.stop()
                self.play_btn.setText("▶")
                target = count - 1
            elif self.timer.isActive():
                target = 0
            else:
                target = count - 1
        self.set_frame(target)

    def _playback_speed_multiplier(self) -> float:
        if not hasattr(self, "speed"):
            return 1.0
        value = self.speed.currentData()
        try:
            multiplier = float(value)
        except (TypeError, ValueError):
            multiplier = 1.0
        return max(0.05, multiplier)

    def _actual_replay_frame_interval_s(self) -> float:
        """Replay interval derived from the active treatment acquisition timeline."""
        if not self.current:
            return 1.0
        count = max(1, int(self.current.replay_frame_count or 1))
        if count <= 1:
            return max(0.020, float(self._replay_duration_s() or 1.0))
        t0 = self._index_to_seconds(self.frame_index, count)
        t1 = self._index_to_seconds(min(self.frame_index + 1, count - 1), count)
        delta = float(t1 - t0)
        if delta <= 0.0:
            duration = float(self._replay_duration_s())
            delta = duration / float(count - 1) if duration > 0 else 1.0
        return max(0.020, delta)

    def _playback_timer_interval_ms(self) -> int:
        actual = self._actual_replay_frame_interval_s()
        return max(20, int(round(1000.0 * actual / self._playback_speed_multiplier())))

    def toggle_play(self):
        if self.timer.isActive():
            self.timer.stop()
            self.play_btn.setText("▶")
        else:
            self.timer.start(self._playback_timer_interval_ms())
            self.play_btn.setText("Ⅱ")

    def speed_changed(self, _index=None):
        if self.timer.isActive():
            self.timer.start(self._playback_timer_interval_ms())

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Left, Qt.Key.Key_Up):
            self.previous_frame()
            return
        if event.key() in (Qt.Key.Key_Right, Qt.Key.Key_Down):
            self.next_frame()
            return
        if event.key() == Qt.Key.Key_Space:
            self.toggle_play()
            return
        super().keyPressEvent(event)

    def wheelEvent(self, event):
        if self.current:
            self._activate_replay_mode_for_navigation()
            delta = 1 if event.angleDelta().y() < 0 else -1
            self.set_frame(self.frame_index + delta)
            event.accept()
            return
        super().wheelEvent(event)

    def dragEnterEvent(self, event):
        if any(url.isLocalFile() for url in event.mimeData().urls()):
            event.acceptProposedAction()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            if url.isLocalFile():
                path = Path(url.toLocalFile())
                if path.is_dir() or path.suffix.lower() == ".zip":
                    self.load(path)
                    event.acceptProposedAction()
                    break

    def _restore(self):
        try:
            geometry = self.settings.value("geometry")
            if geometry:
                self.restoreGeometry(geometry)
            layout_version = int(self.settings.value("layout/version", 0) or 0)
            for key, splitter in (("top_split", getattr(self,"top_split",None)),("graph_split",getattr(self,"graph_split",None)),("lower_split",getattr(self,"lower_split",None))):
                # Do not restore the pre-C0046 graph ratio, which encoded the
                # incorrect 3:4 temperature/spectrum split.
                if key == "graph_split" and layout_version < 46:
                    continue
                state=self.settings.value(key)
                if state and splitter is not None: splitter.restoreState(state)
            if getattr(self, "graph_split", None) is not None and layout_version < 46:
                self.graph_split.setSizes([650, 350])
            saved_range=self.settings.value("temperature_range", "40–60 °C")
            self.chart_state.cpc_enabled = str(self.settings.value("chart/cpc_enabled", "false")).lower() == "true"
            self.cpc_enabled = False
            self.chart_state.cpc_enabled = False
            saved_channels = self.settings.value("chart/selected_channels", []) or []
            if isinstance(saved_channels, str): saved_channels=[saved_channels]
            self.chart_state.selected_channels=set(map(str,saved_channels))
            self.chart_state.user_selected_channels=bool(saved_channels)
            self.cpc_button.blockSignals(True); self.cpc_button.setChecked(self.cpc_enabled); self.cpc_button.setText("CPC ON" if self.cpc_enabled else "CPC OFF"); self.cpc_button.blockSignals(False)
            idx=self.range_combo.findText(str(saved_range)); self.range_combo.setCurrentIndex(idx if idx>=0 else 0)
        except Exception:
            pass

    def closeEvent(self, event):
        self.settings.setValue("geometry", self.saveGeometry())
        for key, splitter in (("top_split", getattr(self,"top_split",None)),("graph_split",getattr(self,"graph_split",None)),("lower_split",getattr(self,"lower_split",None))):
            if splitter is not None: self.settings.setValue(key, splitter.saveState())
        self.settings.setValue("layout/version", 46)
        self.settings.setValue("chart/cpc_enabled", self.cpc_enabled)
        self.settings.setValue("chart/selected_channels", sorted(self.chart_state.selected_channels))
        super().closeEvent(event)
