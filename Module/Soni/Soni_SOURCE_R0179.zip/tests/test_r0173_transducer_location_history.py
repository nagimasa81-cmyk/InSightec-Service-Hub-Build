from pathlib import Path
import math

from src.services.transducer_location_service import TransducerLocationService


def test_extracts_xd_location_as_physical_position_and_keeps_steering_separate(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir()
    log=ws/'2026_Apr_01_18_30_13.Log'
    log.write_text('''
18:40:00:000 Inf Dbg 1 Locate Transducer started
18:40:01:250 Inf Dbg 1 Xd loc XYZ: 1.0 -2.0 3.5, roll: 0.25, pitch: -0.5, Steering: 10.0 20.0 30.0
18:41:44:135 Ent Dbg 7940 [CGeneralSonicationLogic::StartSonicate] Sonication Counter:0. Burn Pointer:20000005
18:50:00:000 Inf Dbg 1 Xd loc XYZ: 2.0 -1.0 5.5, roll: 0.5, pitch: -0.25, Steering: 11.0 21.0 31.0
''',encoding='utf-8')
    svc=TransducerLocationService()
    # R0176 supersedes R0173: Xd-state rows are diagnostic-only even if an
    # explicit Locate phrase precedes them; tracker-derived CSA result is required.
    assert svc.parse(tmp_path)==[]
    raw=svc.raw_xd_reports(tmp_path)
    assert len(raw)==2
    assert (raw[0].x,raw[0].y,raw[0].z)==(1.0,-2.0,3.5)
    assert (raw[0].steering_x,raw[0].steering_y,raw[0].steering_z)==(10.0,20.0,30.0)


def test_ws_setup_xd_location_line_is_extracted_without_claiming_it_was_explicit_locate(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir()
    (ws/'2026_Apr_01_18_30_13.Log').write_text('''
18:41:44:135 Ent Dbg 7940 [CGeneralSonicationLogic::StartSonicate] Sonication Counter:0. Burn Pointer:20000005
18:41:44:144 Inf Dbg 7940 Xd loc XYZ: 0 0 0, roll: 0, pitch: 0, Steering: 0.44 -1.52 149.82
''',encoding='utf-8')
    rows=TransducerLocationService().parse(tmp_path)
    assert rows==[]
    raw=TransducerLocationService().raw_xd_reports(tmp_path)
    assert len(raw)==1
    assert raw[0].trigger=='XD state report'
    assert raw[0].related_sonication==1
