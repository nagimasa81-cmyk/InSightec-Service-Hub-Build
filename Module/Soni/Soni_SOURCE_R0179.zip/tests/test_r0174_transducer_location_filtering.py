from pathlib import Path
import math

from src.services.transducer_location_service import TransducerLocationService


def test_recurring_xd_state_reports_are_not_published_as_location_history(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir()
    log=ws/'2026_Apr_01_18_30_13.Log'
    log.write_text('''
18:41:44:135 Ent Dbg 7940 [CGeneralSonicationLogic::StartSonicate] Sonication Counter:0. Burn Pointer:20000005
18:41:44:144 Inf Dbg 7940 Xd loc XYZ: 0 0 0, roll: 0, pitch: 0, Steering: 0.44 -1.52 149.82
18:41:45:144 Inf Dbg 7940 Xd loc XYZ: 0 0 0, roll: 0, pitch: 0, Steering: 0.54 -1.42 149.72
''',encoding='utf-8')
    svc=TransducerLocationService()
    assert len(svc.raw_xd_reports(tmp_path))==2
    assert svc.parse(tmp_path)==[]


def test_only_causally_locate_associated_nonzero_results_are_published(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir()
    log=ws/'2026_Apr_01_18_30_13.Log'
    log.write_text('''
18:40:00:000 Inf Dbg 1 Locate Transducer started
18:40:01:250 Inf Dbg 1 Xd loc XYZ: 1.0 -2.0 3.5, roll: 0.25, pitch: -0.5, Steering: 10.0 20.0 30.0
18:50:00:000 Inf Dbg 1 Xd loc XYZ: 2.0 -1.0 5.5, roll: 0.5, pitch: -0.25, Steering: 11.0 21.0 31.0
18:59:58:000 Inf Dbg 1 Locate Transducer completed
19:00:00:000 Inf Dbg 1 Xd loc XYZ: 2.5 -0.5 6.0, roll: 0.6, pitch: -0.2, Steering: 12.0 22.0 32.0
''',encoding='utf-8')
    svc=TransducerLocationService()
    raw=svc.raw_xd_reports(tmp_path)
    rows=svc.parse(tmp_path)
    assert len(raw)==3
    # R0176 supersedes the synthetic R0174 contract: an explicit Locate phrase
    # cannot promote recurring Xd-state rows. Only tracker-derived CSA results
    # are authoritative physical transducer locations.
    assert rows==[]


def test_zero_xyz_after_locate_is_not_accepted_as_baseline(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir()
    (ws/'2026_Apr_01_18_30_13.Log').write_text('''
18:40:00:000 Inf Dbg 1 Locate Transducer started
18:40:01:000 Inf Dbg 1 Xd loc XYZ: 0 0 0, roll: 0, pitch: 0, Steering: 1 2 3
''',encoding='utf-8')
    assert TransducerLocationService().parse(tmp_path)==[]


def test_locate_evidence_captures_context_without_treating_xd_state_as_event(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir()
    (ws/'2026_Apr_01_18_30_13.Log').write_text('''
18:39:59:000 Inf Dbg 1 before
18:40:00:000 Inf Dbg 1 Locate Transducer started
18:40:01:000 Inf Dbg 1 after
18:40:02:000 Inf Dbg 1 Xd loc XYZ: 0 0 0, roll: 0, pitch: 0, Steering: 1 2 3
''',encoding='utf-8')
    ev=TransducerLocationService().locate_evidence(tmp_path,context_radius=1)
    assert len(ev)==1
    assert 'Locate Transducer' in ev[0].text
    assert len(ev[0].context)==3
