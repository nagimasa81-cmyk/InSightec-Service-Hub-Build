from pathlib import Path
from types import SimpleNamespace

from src.services.replay_service import ReplayService


def test_per_frame_thermometry_semantics_bind_array_index_exactly(tmp_path):
    svc=ReplayService()
    son_folder=tmp_path/"Sonication1"
    son_folder.mkdir()
    son=SimpleNamespace(folder=son_folder, temperature_frames=[])
    svc._mr_parameter_cache[str(tmp_path.resolve())]=[
        {"fieldindex":"5","sonicationindex":"1","zoneindex":"3","arrayindex":"0","seriesdiscription":"TMAP-ME","echonum":"1"},
        {"fieldindex":"5","sonicationindex":"1","zoneindex":"3","arrayindex":"10","seriesdiscription":"T2_Star_ME_1SL","echonum":"2"},
    ]
    ok=svc.thermometry_frame_semantics(son,son_folder/"5-1-3-0.raw")
    bad=svc.thermometry_frame_semantics(son,son_folder/"5-1-3-10.raw")
    assert ok["decision"] is True
    assert "TMAP" in ok["series_description"]
    assert bad["decision"] is False
    assert "T2_Star" in bad["series_description"]


def test_r0171_temperature_trend_checks_each_source_frame_not_only_first():
    text=Path("src/services/replay_service.py").read_text(encoding="utf-8")
    block=text.split("def temperature_trend",1)[1].split("def temperature_frame_metrics",1)[0]
    assert "thermometry_frame_semantics(son,frame.path)" in block
    assert 'sem.get("decision") is not True' in block
    assert 'source_frame_semantics' in block


def test_r0171_diagnostics_exports_frame_semantics_and_roi_binding():
    text=Path("src/services/import_diagnostics_service.py").read_text(encoding="utf-8")
    for token in (
        '"accepted_as_thermometry"', '"series_description"', '"series_uid"',
        '"echo_number"', '"echo_time"', '"roi_center_x"', '"roi_center_y"',
    ):
        assert token in text
