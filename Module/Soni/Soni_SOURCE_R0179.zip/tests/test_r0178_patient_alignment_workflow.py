from pathlib import Path
from src.services.transducer_location_service import TransducerLocationService

LOG = """08:00:00:000 Inf Dbg 1 Protocol data - name: Brain Treatment
08:00:01:000 Inf Dbg 1 Home position read from section [PatientInfo]. UVW = (10.0, 20.0, 30.0), Transducer Direction: UVW = (0,0,-1)
08:01:00:000 Inf Dbg 1 New XD pos. in CSA coords. according to trackers - X: 2.0, Y: -1.5, Z: 0.5
08:02:00:000 Inf Dbg 1 New XD pos. in CSA coords. according to trackers - X: 0.9, Y: -0.8, Z: 0.7
08:03:00:000 Inf Dbg 1 New XD pos. in CSA coords. according to trackers - X: 0.4, Y: -0.2, Z: 0.3
"""

def test_patient_workflow_preserves_clinical_sequence_and_repeat_after_pass(tmp_path: Path):
    ws=tmp_path/"WSFiles"; ws.mkdir(); (ws/"2026_Sep_05.Log").write_text(LOG)
    rows=TransducerLocationService().patient_alignment_workflow(tmp_path)
    assert [r.stage for r in rows] == [
        "1. Initial Locate Transducer",
        "2. Target entered — first gap check",
        "3. Post-adjustment Locate #1",
        "3. Post-adjustment Locate #2",
    ]
    assert rows[0].target_xyz is None and rows[0].overall_pass is None
    assert rows[1].timestamp is None  # target entry does not invent a Locate timestamp
    assert rows[1].delta_xyz == (2.0,-1.5,0.5) and rows[1].overall_pass is False
    assert rows[2].overall_pass is True
    assert rows[3].overall_pass is True  # physician may re-Locate after an already passing check

def test_dqa_does_not_create_patient_workflow(tmp_path: Path):
    ws=tmp_path/"WSFiles"; ws.mkdir()
    (ws/"2026_Sep_05.Log").write_text(LOG.replace("Brain Treatment","Brain DQA"))
    assert TransducerLocationService().patient_alignment_workflow(tmp_path) == []
