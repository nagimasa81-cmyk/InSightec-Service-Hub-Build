from pathlib import Path

from src.services.transducer_location_service import TransducerLocationService


def test_broad_discovery_never_promotes_without_explicit_locate(tmp_path: Path):
    log = tmp_path / 'WS_2026_Sep_04.log'
    log.write_text(
        '11:00:00:000 Transducer registration detector started\n'
        '11:00:00:100 Xd loc XYZ: 1.0 2.0 3.0, roll: 0, pitch: 0, Steering: 4 5 6\n',
        encoding='utf-8',
    )
    svc=TransducerLocationService()
    evidence=svc.discovery_evidence(tmp_path)
    assert any(e.evidence_kind == 'broad-workflow-candidate' for e in evidence)
    assert any(e.evidence_kind == 'xd-state-report' for e in evidence)
    assert svc.parse(tmp_path) == []


def test_xd_context_samples_are_bounded_and_contextual(tmp_path: Path):
    log = tmp_path / 'WS_2026_Sep_04.log'
    lines=[]
    for i in range(50):
        lines.append(f'11:00:{i%60:02d}:000 context {i}')
        lines.append(f'11:00:{i%60:02d}:100 Xd loc XYZ: 0 0 0, roll: 0, pitch: 0, Steering: {i} 0 0')
    log.write_text('\n'.join(lines), encoding='utf-8')
    rows=TransducerLocationService().raw_xd_context_samples(tmp_path,max_rows=8)
    assert 1 <= len(rows) <= 8
    assert all(r.evidence_kind == 'xd-context-sample' for r in rows)
    assert all(r.context for r in rows)
