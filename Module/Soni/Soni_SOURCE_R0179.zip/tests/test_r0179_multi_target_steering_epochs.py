from pathlib import Path
from src.services.transducer_location_service import TransducerLocationService

LOG = """08:00:00:000 Inf Dbg 1 Protocol data - name: Brain Treatment
08:00:01:000 Inf Dbg 1 Home position read from section [PatientInfo]. UVW = (10.0, 20.0, 30.0), Transducer Direction: UVW = (0,0,-1)
08:01:00:000 Inf Dbg 1 New XD pos. in CSA coords. according to trackers - X: 2.0, Y: -1.5, Z: 0.5
08:05:00:000 Ent Dbg 1 [CGeneralSonicationLogic::StartSonicate] Sonication Counter:0
08:05:00:010 Inf Dbg 1 Steering: 10.0 20.0 30.0
08:06:00:000 Ent Dbg 1 [CGeneralSonicationLogic::StartSonicate] Sonication Counter:1
08:06:00:010 Inf Dbg 1 Steering: 11.0 20.0 30.0
08:07:00:000 Ent Dbg 1 [CGeneralSonicationLogic::StartSonicate] Sonication Counter:2
08:07:00:010 Inf Dbg 1 Steering: 11.0 20.0 30.0
08:10:00:000 Inf Dbg 1 Home position read from section [PatientInfo]. UVW = (15.0, 25.0, 35.0), Transducer Direction: UVW = (0,0,-1)
08:11:00:000 Inf Dbg 1 New XD pos. in CSA coords. according to trackers - X: 0.8, Y: -0.7, Z: 0.6
08:12:00:000 Inf Dbg 1 New XD pos. in CSA coords. according to trackers - X: 0.4, Y: -0.3, Z: 0.2
08:13:00:000 Ent Dbg 1 [CGeneralSonicationLogic::StartSonicate] Sonication Counter:3
08:13:00:010 Inf Dbg 1 Steering: 15.0 25.0 35.0
08:14:00:000 Ent Dbg 1 [CGeneralSonicationLogic::StartSonicate] Sonication Counter:4
08:14:00:010 Inf Dbg 1 Steering: 15.5 25.0 35.0
"""

def _rows(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir(); (ws/'2026_Sep_05.Log').write_text(LOG)
    return TransducerLocationService().patient_alignment_workflow(tmp_path)

def test_steering_change_stays_in_same_physical_target_epoch(tmp_path: Path):
    rows=_rows(tmp_path)
    steering=[r for r in rows if r.change_mode == 'Electronic steering']
    assert len(steering) == 2
    assert steering[0].target_epoch == 1
    assert steering[0].sonication_number == 2
    assert steering[0].steering_xyz == (11.0,20.0,30.0)
    assert steering[0].steering_delta_xyz == (1.0,0.0,0.0)
    assert steering[0].overall_pass is None
    assert steering[1].target_epoch == 2
    assert steering[1].steering_xyz == (15.5,25.0,35.0)

def test_reentered_physical_target_opens_new_epoch_and_relocate_history(tmp_path: Path):
    rows=_rows(tmp_path)
    assert max(r.target_epoch or 0 for r in rows) == 2
    retarget=[r for r in rows if r.change_mode == 'Physical retarget']
    assert len(retarget) == 1
    assert retarget[0].target_epoch == 2
    assert retarget[0].target_xyz == (15.0,25.0,35.0)
    loc2=[r for r in rows if r.target_epoch == 2 and 'Locate' in r.stage]
    assert len(loc2) >= 2
    assert loc2[0].overall_pass is True
    assert loc2[1].overall_pass is True

def test_unchanged_steering_is_not_reported_as_change(tmp_path: Path):
    rows=_rows(tmp_path)
    changes=[r for r in rows if r.change_mode == 'Electronic steering']
    assert all(r.sonication_number != 3 for r in changes)
