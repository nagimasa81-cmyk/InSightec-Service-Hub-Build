from pathlib import Path
import math

from src.services.transducer_location_service import TransducerLocationService


def test_r0176_tracker_localization_is_authoritative_and_zero_state_is_ignored(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir()
    log=ws/'2026_Sep_04_07_58_39.Log'
    log.write_text('''08:17:31:367 Inf Dbg 8364 \tHome position read from section [PatientInfo]. UVW = (0.489600, -31.067017, 148.330109), Transducer Direction: UVW = (-0.000447, 0.015182, -0.999885)\n08:19:00:879 Inf Srv 8364 \ttracker 0 coordinates: PQR:(146.428, 70.511, 77.2711)  - iniPQR:(146.462, 70.5135, 77.2639)\n08:19:00:879 Inf Srv 8364 \ttracker 1 coordinates: PQR:(133.871, -90.0536, 100.916)  - iniPQR:(133.859, -90.0439, 100.921)\n08:19:00:879 Inf Dbg 8364 \tTransducer tilt: (-0.000118933, 0.0157688, -0.999876)\n08:19:00:880 Inf Srv 8364 \tTRACKERS SELECTION: Xd location was decoded from the trackers with high reliability (e.g. all trackers gave good signals)\n08:19:00:880 Inf Srv 8364 \tCalculateXdPosition  return TRACKER_HIGH_RELIABILITY\n08:19:00:880 Inf Dbg 8364 \tFound TrackerPos 0is: (147.033, -100.013, 69.0942)\n08:19:00:880 Inf Dbg 8364 \tFound TrackerPos 1is: (134.138, 60.8762, 47.9739)\n08:19:00:880 Inf Dbg 8364 \tNew XD pos. in CSA coords. according to trackers - X: 0.019591, Y: 0.035643, Z: -0.016206, Roll: 0.000000, Pitch: 0.000000\n08:19:00:880 Inf Dbg 8364 \tLocation sent on MoveTo - X: 0.000000, Y: 0.000000, Z: 0.000000, Roll: 0.000000, Pitch: 0.000000\n08:19:00:881 Inf Dbg 8364 \tXd loc XYZ: 0 0 0, roll: 0, pitch: 0, Steering: 4 4 154\n''',encoding='utf-8')
    rows=TransducerLocationService().parse(tmp_path)
    assert len(rows)==1
    r=rows[0]
    assert (r.x,r.y,r.z)==(0.019591,0.035643,-0.016206)
    assert r.coordinate_frame=='CSA residual'
    assert r.reliability=='high reliability'
    assert r.reliability_code=='TRACKER_HIGH_RELIABILITY'
    assert r.home_uvw==(0.4896,-31.067017,148.330109)
    assert r.tracker_pqr[0]==(146.428,70.511,77.2711)
    assert r.tracker_uvw[0]==(147.033,-100.013,69.0942)
    assert math.isclose(r.displacement,0.0,abs_tol=1e-12)


def test_r0176_delta_is_from_first_tracker_localization(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir()
    log=ws/'2026_Sep_04_07_58_39.Log'
    log.write_text('''08:19:00:880 Inf Srv x TRACKERS SELECTION: Xd location was decoded from the trackers with high reliability\n08:19:00:880 Inf Dbg x New XD pos. in CSA coords. according to trackers - X: 1.0, Y: 2.0, Z: 3.0, Roll: 0, Pitch: 0\n08:21:53:717 Inf Srv x TRACKERS SELECTION: Xd location was decoded from the trackers with high reliability\n08:21:53:717 Inf Dbg x New XD pos. in CSA coords. according to trackers - X: 2.0, Y: 4.0, Z: 5.0, Roll: 0, Pitch: 0\n''',encoding='utf-8')
    rows=TransducerLocationService().parse(tmp_path)
    assert len(rows)==2
    assert (rows[1].delta_x,rows[1].delta_y,rows[1].delta_z)==(1.0,2.0,2.0)
    assert math.isclose(rows[1].displacement,3.0,rel_tol=1e-12)

def test_r0176_consecutive_localization_blocks_do_not_cross_bind_reliability(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir()
    log=ws/'2026_Sep_04_07_58_39.Log'
    log.write_text('''08:19:00:000 Inf Srv x TRACKERS SELECTION: Xd location was decoded from the trackers with high reliability\n08:19:00:000 Inf Srv x CalculateXdPosition  return TRACKER_HIGH_RELIABILITY\n08:19:00:001 Inf Dbg x New XD pos. in CSA coords. according to trackers - X: 1, Y: 2, Z: 3, Roll: 0, Pitch: 0\n08:19:20:000 Inf Srv x TRACKERS SELECTION: Xd location was decoded from the trackers with low reliability\n08:19:20:001 Inf Dbg x New XD pos. in CSA coords. according to trackers - X: 4, Y: 5, Z: 6, Roll: 0, Pitch: 0\n''', encoding='utf-8')
    rows=TransducerLocationService().parse(tmp_path)
    assert len(rows)==2
    assert rows[0].reliability=='high reliability'
    assert rows[0].reliability_code=='TRACKER_HIGH_RELIABILITY'
    assert rows[1].reliability=='low reliability'
    assert rows[1].reliability_code is None
