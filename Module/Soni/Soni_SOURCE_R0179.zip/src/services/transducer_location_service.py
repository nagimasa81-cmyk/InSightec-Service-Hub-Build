from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
import math
import re


_CLOCK_RE = re.compile(r"(?P<h>\d{2}):(?P<m>\d{2}):(?P<s>\d{2}):(?P<ms>\d{3})")
_FLOAT = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"
_XD_RE = re.compile(
    rf"Xd\s*loc\s*XYZ\s*:\s*\(?\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*\)?"
    rf"(?:\s*,?\s*roll\s*:\s*({_FLOAT}))?"
    rf"(?:\s*,?\s*pitch\s*:\s*({_FLOAT}))?"
    rf"(?:\s*,?\s*Steering\s*:\s*\(?\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*\)?)?",
    re.I,
)
_TRACKER_XD_RE = re.compile(
    rf"New\s+XD\s+pos\.\s+in\s+CSA\s+coords\.\s+according\s+to\s+trackers\s*-\s*"
    rf"X\s*:\s*({_FLOAT})\s*,\s*Y\s*:\s*({_FLOAT})\s*,\s*Z\s*:\s*({_FLOAT})"
    rf"(?:\s*,\s*Roll\s*:\s*({_FLOAT}))?(?:\s*,\s*Pitch\s*:\s*({_FLOAT}))?",
    re.I,
)
_TRACKER_PQR_RE = re.compile(
    rf"tracker\s+(\d+)\s+coordinates\s*:\s*PQR\s*:\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)"
    rf"(?:\s*-\s*iniPQR\s*:\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\))?",
    re.I,
)
_TRACKER_POS_RE = re.compile(
    rf"Found\s+TrackerPos\s+(\d+)\s*is\s*:\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)", re.I
)
_TILT_RE = re.compile(rf"Transducer\s+tilt\s*:\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)", re.I)
_RELIABILITY_RE = re.compile(r"TRACKERS\s+SELECTION\s*:\s*Xd\s+location\s+was\s+decoded\s+from\s+the\s+trackers\s+with\s+([^\r\n(]+)", re.I)
_RELIABILITY_CODE_RE = re.compile(r"CalculateXdPosition\s+return\s+([A-Z0-9_]+)", re.I)
_HOME_RE = re.compile(
    rf"Home\s+position\s+read.*?UVW\s*=\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)", re.I
)
_PROTOCOL_RE = re.compile(r"protocol\s+data\s*-\s*name\s*:\s*([^,\r\n]+)", re.I)
_START_RE = re.compile(r"\[CGeneralSonicationLogic::StartSonicate\]\s*Sonication Counter\s*:\s*(\d+)", re.I)
_START_STEERING_RE = re.compile(rf"Steering\s*:\s*({_FLOAT})\s+({_FLOAT})\s+({_FLOAT})", re.I)
# R0174: an ordinary 'Xd loc XYZ' state report is NOT itself a Locate Transducer
# event.  Only explicit operator/workflow phrases may open an association window.
_LOCATE_EVENT_RE = re.compile(
    r"(?:\blocate\s+transducer\b|\btransducer\s+locat(?:e|ion|ing)\b|"
    r"\blocat(?:e|ing)\s+(?:the\s+)?xd\b|\bxd\s+transducer\s+locat(?:e|ion|ing)\b)",
    re.I,
)
# R0175 diagnostics-only discovery signature.  This deliberately does NOT
# promote a row to a confirmed location result.  It exists solely to reveal
# the workstation's real vendor wording in the next diagnostic package.
_LOCATE_DISCOVERY_RE = re.compile(
    r"(?:\btransducer\b|\blocali[sz](?:e|ed|ing|ation)\b|\blocat(?:e|ed|ing|ion)\b|"
    r"\bregistration\b|\bposition(?:ing)?\b|\bpose\b|\bdetector\b|\bxd\s*loc\b)",
    re.I,
)
_FILE_DATE_RE = re.compile(r"(?P<year>20\d{2})[_-](?P<mon>[A-Za-z]{3}|\d{1,2})[_-](?P<day>\d{1,2})", re.I)
_MONTHS = {m.lower(): i for i, m in enumerate(("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"), 1)}


@dataclass(slots=True)
class TransducerLocationRecord:
    timestamp: datetime | None
    clock_s: float
    x: float
    y: float
    z: float
    roll: float | None
    pitch: float | None
    steering_x: float | None
    steering_y: float | None
    steering_z: float | None
    source: Path
    line_number: int
    trigger: str = "Locate Transducer"
    related_sonication: int | None = None
    related_delta_s: float | None = None
    delta_x: float = 0.0
    delta_y: float = 0.0
    delta_z: float = 0.0
    displacement: float = 0.0
    locate_event_line: int | None = None
    locate_event_clock_s: float | None = None
    locate_event_text: str | None = None
    coordinate_frame: str = "CSA"
    reliability: str | None = None
    reliability_code: str | None = None
    tilt_xyz: tuple[float, float, float] | None = None
    tracker_pqr: dict[int, tuple[float, float, float]] | None = None
    tracker_ini_pqr: dict[int, tuple[float, float, float]] | None = None
    tracker_uvw: dict[int, tuple[float, float, float]] | None = None
    home_uvw: tuple[float, float, float] | None = None
    protocol_name: str | None = None
    patient_target_xyz: tuple[float, float, float] | None = None
    patient_transducer_xyz: tuple[float, float, float] | None = None
    patient_delta_xyz: tuple[float, float, float] | None = None
    patient_axis_pass: tuple[bool, bool, bool] | None = None
    patient_alignment_pass: bool | None = None
    patient_alignment_threshold_mm: float = 1.0




@dataclass(slots=True)
class PatientAlignmentWorkflowRow:
    """Clinical Patient-treatment alignment timeline.

    A comparison row may reuse the most recent Locate Transducer result: entering
    the target does not itself re-run localization.
    """
    stage: str
    sequence: int
    timestamp: datetime | None
    clock_s: float | None
    target_xyz: tuple[float, float, float] | None
    transducer_xyz: tuple[float, float, float] | None
    delta_xyz: tuple[float, float, float] | None
    axis_pass: tuple[bool, bool, bool] | None
    overall_pass: bool | None
    source_record: TransducerLocationRecord | None
    note: str
    target_epoch: int | None = None
    change_mode: str = "Physical alignment"
    steering_xyz: tuple[float, float, float] | None = None
    steering_delta_xyz: tuple[float, float, float] | None = None
    effective_target_xyz: tuple[float, float, float] | None = None
    sonication_number: int | None = None


@dataclass(slots=True)
class SonicationSteeringEvent:
    timestamp: datetime | None
    clock_s: float
    sonication_number: int
    steering_xyz: tuple[float, float, float]
    source: Path
    line_number: int


@dataclass(slots=True)
class LocateTransducerEvidence:
    source: Path
    line_number: int
    clock_s: float | None
    text: str
    context: tuple[str, ...]
    evidence_kind: str = "explicit-locate"


class TransducerLocationService:
    """Extract *confirmed/associated* Locate Transducer position results.

    Workstation logs also emit recurring ``Xd loc XYZ`` state lines during normal
    operation.  R0173 incorrectly presented every one of those rows as a physical
    location history.  R0174 keeps those raw reports as diagnostic evidence only
    and publishes a location record only when an explicit Locate Transducer
    workflow/event precedes the report inside a bounded time window.

    ``Steering XYZ`` remains a separate electronic-steering field; it is never
    substituted for physical X/Y/Z.
    """

    LOCATE_ASSOCIATION_WINDOW_S = 30.0
    LOCATE_ASSOCIATION_MAX_LINES = 120

    @staticmethod
    def _clock_s(line: str) -> float | None:
        m = _CLOCK_RE.search(line)
        if not m:
            return None
        return (int(m.group("h"))*3600.0 + int(m.group("m"))*60.0 + int(m.group("s")) + int(m.group("ms"))/1000.0)

    @staticmethod
    def _date_from_name(path: Path) -> datetime | None:
        m = _FILE_DATE_RE.search(path.name)
        if not m:
            return None
        mon_raw=m.group("mon")
        try:
            mon=int(mon_raw) if mon_raw.isdigit() else _MONTHS[mon_raw.lower()]
            return datetime(int(m.group("year")), mon, int(m.group("day")))
        except Exception:
            return None

    @staticmethod
    def _candidate_logs(workspace: Path) -> list[Path]:
        logs=[]
        for pattern in ("*.Log", "*.log"):
            logs.extend(Path(workspace).rglob(pattern))
        return sorted(set(logs), key=lambda p: (0 if "wsfiles" in str(p.parent).lower() else 1, len(p.parts), str(p).lower()))

    @staticmethod
    def _is_nonzero_location(x: float, y: float, z: float) -> bool:
        # (0,0,0) is common as an unpopulated/default state in real exports.  It
        # must never become the displacement baseline without an independently
        # confirmed Locate workflow result.
        return bool(abs(float(x)) > 1e-9 or abs(float(y)) > 1e-9 or abs(float(z)) > 1e-9)

    def locate_evidence(self, workspace: Path, context_radius: int = 5) -> list[LocateTransducerEvidence]:
        """Return explicit Locate/Transducer workflow lines plus nearby raw context.

        This is intentionally diagnostic evidence, not a location parser.  It lets
        the next real export reveal the workstation's exact success/result wording
        without hard-coding an unobserved vendor signature.
        """
        out=[]
        seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            for i,line in enumerate(lines):
                if not _LOCATE_EVENT_RE.search(line):
                    continue
                key=(str(path.resolve()), i)
                if key in seen:
                    continue
                seen.add(key)
                lo=max(0,i-int(context_radius)); hi=min(len(lines),i+int(context_radius)+1)
                out.append(LocateTransducerEvidence(
                    source=path, line_number=i+1, clock_s=self._clock_s(line), text=line.strip(),
                    context=tuple(lines[lo:hi]),
                ))
        return out


    def discovery_evidence(self, workspace: Path, context_radius: int = 5, max_rows: int = 300) -> list[LocateTransducerEvidence]:
        """Return broad transducer/localization workflow evidence for diagnostics only.

        R0174 proved that the real workstation export does not necessarily spell
        the operation ``Locate Transducer``.  This intentionally broad scan is
        never used by :meth:`parse`; it only serializes small, bounded snippets
        so the vendor's actual success/result wording can be learned from a real
        export without guessing.
        """
        out=[]; seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            for i,line in enumerate(lines):
                if not _LOCATE_DISCOVERY_RE.search(line):
                    continue
                key=(str(path.resolve()),i)
                if key in seen:
                    continue
                seen.add(key)
                lo=max(0,i-int(context_radius)); hi=min(len(lines),i+int(context_radius)+1)
                kind=("explicit-locate" if _LOCATE_EVENT_RE.search(line) else
                      "xd-state-report" if _XD_RE.search(line) else "broad-workflow-candidate")
                out.append(LocateTransducerEvidence(
                    source=path,line_number=i+1,clock_s=self._clock_s(line),text=line.strip(),
                    context=tuple(lines[lo:hi]),evidence_kind=kind,
                ))
                if len(out) >= int(max_rows):
                    return out
        return out

    def raw_xd_context_samples(self, workspace: Path, context_radius: int = 4, max_rows: int = 24) -> list[LocateTransducerEvidence]:
        """Return bounded first/middle/last Xd-report contexts for diagnostics."""
        candidates=[]
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            hits=[i for i,line in enumerate(lines) if _XD_RE.search(line)]
            if not hits:
                continue
            # Preserve boundary and evenly-spaced evidence without dumping the log.
            if len(hits) <= max_rows:
                chosen=hits
            else:
                step=(len(hits)-1)/float(max_rows-1)
                chosen=sorted({hits[int(round(k*step))] for k in range(max_rows)})
            for i in chosen:
                lo=max(0,i-int(context_radius)); hi=min(len(lines),i+int(context_radius)+1)
                candidates.append(LocateTransducerEvidence(
                    source=path,line_number=i+1,clock_s=self._clock_s(lines[i]),text=lines[i].strip(),
                    context=tuple(lines[lo:hi]),evidence_kind="xd-context-sample",
                ))
                if len(candidates) >= int(max_rows):
                    return candidates
        return candidates

    def raw_xd_reports(self, workspace: Path) -> list[TransducerLocationRecord]:
        """Return all recurring Xd state reports for diagnostics only."""
        records=[]; seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            base_date=self._date_from_name(path)
            starts=[]
            for i,line in enumerate(lines):
                sm=_START_RE.search(line); cs=self._clock_s(line)
                if sm and cs is not None:
                    starts.append((cs, int(sm.group(1))+1, i))
            locate_events=[]
            for i,line in enumerate(lines):
                if _LOCATE_EVENT_RE.search(line):
                    locate_events.append((self._clock_s(line), i, line.strip()))
            for i,line in enumerate(lines):
                m=_XD_RE.search(line)
                if not m:
                    continue
                cs=self._clock_s(line)
                if cs is None:
                    continue
                vals=[float(m.group(j)) if m.group(j) is not None else None for j in range(1,9)]
                x,y,z=vals[:3]
                key=(round(cs,3), round(x,6), round(y,6), round(z,6), str(path.resolve()), i)
                if key in seen:
                    continue
                seen.add(key)
                timestamp=(base_date + timedelta(seconds=cs)) if base_date is not None else None
                assoc=None
                # Causal association only: an explicit Locate event must precede
                # the Xd report.  A later event cannot retroactively label it.
                candidates=[]
                for ev_cs, ev_i, ev_text in locate_events:
                    if ev_i >= i or i-ev_i > self.LOCATE_ASSOCIATION_MAX_LINES:
                        continue
                    if ev_cs is not None:
                        dt=cs-ev_cs
                        if dt < 0 or dt > self.LOCATE_ASSOCIATION_WINDOW_S:
                            continue
                    else:
                        dt=None
                    candidates.append((ev_i, ev_cs, ev_text, dt))
                if candidates:
                    assoc=max(candidates,key=lambda q:q[0])
                related=None; related_delta=None
                if starts:
                    best=min(starts, key=lambda row: abs(row[0]-cs)); delta=best[0]-cs
                    if abs(delta) <= 180.0:
                        related=best[1]; related_delta=float(delta)
                records.append(TransducerLocationRecord(
                    timestamp=timestamp, clock_s=float(cs), x=float(x), y=float(y), z=float(z),
                    roll=vals[3], pitch=vals[4], steering_x=vals[5], steering_y=vals[6], steering_z=vals[7],
                    source=path, line_number=i+1,
                    trigger="Locate Transducer" if assoc is not None else "XD state report",
                    related_sonication=related, related_delta_s=related_delta,
                    locate_event_line=(assoc[0]+1 if assoc is not None else None),
                    locate_event_clock_s=(assoc[1] if assoc is not None else None),
                    locate_event_text=(assoc[2] if assoc is not None else None),
                ))
        records.sort(key=lambda r: ((r.timestamp or datetime.min), r.clock_s, str(r.source).lower(), r.line_number))
        return records

    def _tracker_localizations(self, workspace: Path) -> list[TransducerLocationRecord]:
        """Parse authoritative tracker-derived transducer positions.

        The real workstation export emits recurring ``Xd loc XYZ`` rows that can
        remain (0,0,0).  The vendor result line below is semantically different:
        ``New XD pos. in CSA coords. according to trackers`` is emitted by the
        tracker localization path after TRACKERS SELECTION / CalculateXdPosition.
        R0177 treats that result as the tracker-vs-calibrated-XD residual in CSA. For Patient treatment, the latest preceding calibrated/home target is combined with this residual to reconstruct the tracker-derived transducer XYZ. DQA remains excluded from this Patient alignment judgement.
        """
        records=[]; seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            base_date=self._date_from_name(path)
            starts=[]
            for i,line in enumerate(lines):
                sm=_START_RE.search(line); cs=self._clock_s(line)
                if sm and cs is not None:
                    starts.append((cs, int(sm.group(1))+1, i))
            # Home UVW is state that can be updated. Bind each localization to
            # the latest preceding value rather than one global first value.
            homes=[]
            for i,line in enumerate(lines):
                hm=_HOME_RE.search(line)
                if hm:
                    homes.append((i,(float(hm.group(1)),float(hm.group(2)),float(hm.group(3)))))
            protocols=[]
            for i,line in enumerate(lines):
                pm=_PROTOCOL_RE.search(line)
                if pm:
                    protocols.append((i, pm.group(1).strip()))
            for i,line in enumerate(lines):
                m=_TRACKER_XD_RE.search(line)
                if not m:
                    continue
                cs=self._clock_s(line)
                if cs is None:
                    continue
                x,y,z=(float(m.group(1)),float(m.group(2)),float(m.group(3)))
                roll=float(m.group(4)) if m.group(4) is not None else None
                pitch=float(m.group(5)) if m.group(5) is not None else None
                key=(str(path.resolve()),i,round(x,9),round(y,9),round(z,9))
                if key in seen:
                    continue
                seen.add(key)

                # Same localization block is compact in observed WS logs. Use a
                # bounded causal look-back and never cross the previous authoritative
                # tracker-localization result, otherwise tracker/reliability evidence
                # from two consecutive localizations could be merged.
                previous_result=-1
                for j in range(i-1, max(-1,i-400), -1):
                    if _TRACKER_XD_RE.search(lines[j]):
                        previous_result=j
                        break
                lo=max(previous_result+1, i-160, 0)
                block=lines[lo:i+1]
                pqr={}; ini_pqr={}; uvw={}; tilt=None; reliability=None; reliability_code=None
                for rel,ctx in enumerate(block):
                    pm=_TRACKER_PQR_RE.search(ctx)
                    if pm:
                        idx=int(pm.group(1)); pqr[idx]=(float(pm.group(2)),float(pm.group(3)),float(pm.group(4)))
                        if pm.group(5) is not None:
                            ini_pqr[idx]=(float(pm.group(5)),float(pm.group(6)),float(pm.group(7)))
                    fm=_TRACKER_POS_RE.search(ctx)
                    if fm:
                        uvw[int(fm.group(1))]=(float(fm.group(2)),float(fm.group(3)),float(fm.group(4)))
                    tm=_TILT_RE.search(ctx)
                    if tm:
                        tilt=(float(tm.group(1)),float(tm.group(2)),float(tm.group(3)))
                    rm=_RELIABILITY_RE.search(ctx)
                    if rm:
                        reliability=rm.group(1).strip().rstrip(' .')
                    cm=_RELIABILITY_CODE_RE.search(ctx)
                    if cm:
                        reliability_code=cm.group(1).strip()

                home=None
                preceding=[row for row in homes if row[0] < i]
                if preceding:
                    home=max(preceding,key=lambda row:row[0])[1]
                protocol_name=None
                pprev=[row for row in protocols if row[0] < i]
                if pprev:
                    protocol_name=max(pprev,key=lambda row:row[0])[1]
                is_dqa=bool(protocol_name and "dqa" in protocol_name.lower())
                patient_target=None; patient_transducer=None; patient_delta=None; patient_axis_pass=None; patient_pass=None
                if home is not None and protocol_name and not is_dqa:
                    # Vendor immediately calls CompareTrackerAndCalibXd after the
                    # tracker-derived CSA result. Treat x/y/z as the residual from
                    # the calibrated/target XD position, not as an absolute pose.
                    patient_target=(float(home[0]),float(home[1]),float(home[2]))
                    patient_delta=(float(x),float(y),float(z))
                    patient_transducer=(patient_target[0]+patient_delta[0], patient_target[1]+patient_delta[1], patient_target[2]+patient_delta[2])
                    patient_axis_pass=tuple(abs(v) < 1.0 for v in patient_delta)
                    patient_pass=all(patient_axis_pass)
                related=None; related_delta=None
                if starts:
                    best=min(starts,key=lambda row:abs(row[0]-cs)); delta=best[0]-cs
                    if abs(delta) <= 180.0:
                        related=best[1]; related_delta=float(delta)
                timestamp=(base_date+timedelta(seconds=cs)) if base_date is not None else None
                records.append(TransducerLocationRecord(
                    timestamp=timestamp,clock_s=float(cs),x=x,y=y,z=z,roll=roll,pitch=pitch,
                    steering_x=None,steering_y=None,steering_z=None,source=path,line_number=i+1,
                    trigger="Tracker localization",related_sonication=related,related_delta_s=related_delta,
                    locate_event_line=i+1,locate_event_clock_s=float(cs),locate_event_text=line.strip(),
                    coordinate_frame="CSA residual",reliability=reliability,reliability_code=reliability_code,
                    tilt_xyz=tilt,tracker_pqr=pqr,tracker_ini_pqr=ini_pqr,tracker_uvw=uvw,home_uvw=home,
                    protocol_name=protocol_name,patient_target_xyz=patient_target,patient_transducer_xyz=patient_transducer,
                    patient_delta_xyz=patient_delta,patient_axis_pass=patient_axis_pass,patient_alignment_pass=patient_pass,
                ))
        records.sort(key=lambda r:((r.timestamp or datetime.min),r.clock_s,str(r.source).lower(),r.line_number))
        if records:
            bx,by,bz=records[0].x,records[0].y,records[0].z
            for r in records:
                r.delta_x=r.x-bx; r.delta_y=r.y-by; r.delta_z=r.z-bz
                r.displacement=math.sqrt(r.delta_x*r.delta_x+r.delta_y*r.delta_y+r.delta_z*r.delta_z)
        return records

    @staticmethod
    def _xyz_changed(a: tuple[float, float, float] | None, b: tuple[float, float, float] | None, tol: float = 1e-6) -> bool:
        if a is None or b is None:
            return a != b
        return any(abs(float(a[i]) - float(b[i])) > float(tol) for i in range(3))

    def _sonication_steering_events(self, workspace: Path) -> list[SonicationSteeringEvent]:
        """Parse per-Sonication authoritative Steering XYZ from StartSonicate blocks.

        These coordinates describe the software-selected sonication target. They
        are intentionally kept separate from tracker-derived physical alignment.
        """
        out=[]; seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            base_date=self._date_from_name(path)
            starts=[i for i,line in enumerate(lines) if _START_RE.search(line)]
            for pos,i in enumerate(starts):
                sm0=_START_RE.search(lines[i]); cs=self._clock_s(lines[i])
                if sm0 is None or cs is None:
                    continue
                end=starts[pos+1] if pos+1 < len(starts) else min(len(lines),i+700)
                steering=None; steering_line=i
                for j in range(i,min(end,i+700)):
                    sm=_START_STEERING_RE.search(lines[j])
                    if sm:
                        steering=tuple(float(sm.group(k)) for k in range(1,4)); steering_line=j; break
                if steering is None:
                    continue
                son=int(sm0.group(1))+1
                key=(str(path.resolve()),i,son,tuple(round(v,9) for v in steering))
                if key in seen:
                    continue
                seen.add(key)
                ts=(base_date+timedelta(seconds=cs)) if base_date is not None else None
                out.append(SonicationSteeringEvent(ts,float(cs),son,steering,path,steering_line+1))
        out.sort(key=lambda e:((e.timestamp or datetime.min),e.clock_s,str(e.source).lower(),e.line_number))
        return out

    def patient_alignment_workflow(self, workspace: Path) -> list[PatientAlignmentWorkflowRow]:
        """Build a multi-target Patient-treatment timeline.

        Physical target epochs and electronic Steering epochs are separate:
        - a changed calibrated/target reference opens a new physical target epoch
          and requires physical re-alignment / Locate verification;
        - a StartSonicate Steering XYZ change changes only the effective sonication
          target and never re-runs the physical <1 mm judgement.
        - PASS does not close an epoch; later physician-directed re-Locate remains.
        """
        locs=[r for r in self._tracker_localizations(workspace)
              if not (r.protocol_name and "dqa" in r.protocol_name.lower())]
        if not locs:
            return []
        steering_events=self._sonication_steering_events(workspace)
        rows=[]
        initial=locs[0]
        rows.append(PatientAlignmentWorkflowRow(
            stage="1. Initial Locate Transducer", sequence=1, timestamp=initial.timestamp, clock_s=initial.clock_s,
            target_xyz=None, transducer_xyz=initial.patient_transducer_xyz, delta_xyz=None, axis_pass=None, overall_pass=None,
            source_record=initial, note="Initial transducer position before same-day MRI registration / AC-PC / treatment-target entry.",
            target_epoch=None, change_mode="Initial physical Locate"))

        # Build physical target epochs from tracker-localization target references.
        epoch=0; current_target=None; epoch_start_clock=None
        loc_epoch={}
        for idx,r in enumerate(locs):
            t=r.patient_target_xyz
            if t is not None and (current_target is None or self._xyz_changed(t,current_target)):
                epoch += 1; current_target=t; epoch_start_clock=r.clock_s
                # First target entry reuses the initial Locate. Later changes are
                # explicitly physical retargets; the exact entry time is unknown.
                if epoch == 1:
                    d=initial.patient_delta_xyz; axis=tuple(abs(v)<1.0 for v in d) if d is not None else None
                    rows.append(PatientAlignmentWorkflowRow(
                        stage="2. Target entered — first gap check", sequence=len(rows)+1, timestamp=None, clock_s=None,
                        target_xyz=t, transducer_xyz=initial.patient_transducer_xyz, delta_xyz=d, axis_pass=axis,
                        overall_pass=(all(axis) if axis is not None else None), source_record=initial, target_epoch=1,
                        change_mode="Physical target entry",
                        note="After registration and AC-PC definition, compare Target #1 with the latest initial Locate result; no new Locate is implied."))
                else:
                    rows.append(PatientAlignmentWorkflowRow(
                        stage=f"Physical Target #{epoch} entered — re-alignment required", sequence=len(rows)+1, timestamp=None, clock_s=None,
                        target_xyz=t, transducer_xyz=None, delta_xyz=None, axis_pass=None, overall_pass=None, source_record=r,
                        target_epoch=epoch, change_mode="Physical retarget",
                        note=f"Treatment target was re-entered before this Locate. Target epoch changed from #{epoch-1} to #{epoch}; physical XYZ re-alignment is required."))
            loc_epoch[id(r)]=epoch if epoch else None
            if idx == 0:
                continue
            d=r.patient_delta_xyz; axis=tuple(abs(v)<1.0 for v in d) if d is not None else None
            this_epoch=loc_epoch[id(r)]
            previous_epoch=loc_epoch.get(id(locs[idx-1]))
            if this_epoch is not None and this_epoch != previous_epoch:
                stage=f"Physical Target #{this_epoch} — Locate #1"
                mode="Physical retarget Locate"
            else:
                prior_same=sum(1 for q in locs[1:idx] if loc_epoch.get(id(q)) == this_epoch)
                stage=(f"3. Post-adjustment Locate #{prior_same+1}" if this_epoch == 1
                       else f"Target #{this_epoch or '?'} — Post-adjustment Locate #{prior_same+1}")
                mode="Physical re-Locate"
            rows.append(PatientAlignmentWorkflowRow(
                stage=stage, sequence=len(rows)+1, timestamp=r.timestamp, clock_s=r.clock_s, target_xyz=r.patient_target_xyz,
                transducer_xyz=r.patient_transducer_xyz, delta_xyz=d, axis_pass=axis, overall_pass=(all(axis) if axis is not None else None),
                source_record=r, target_epoch=this_epoch, change_mode=mode,
                note="Physical XYZ alignment check after mechanical transducer adjustment. PASS requires every axis <1.000 mm; later re-Locate remains visible even after PASS."))

        # Assign each sonication to the latest physical target epoch by clock and
        # surface only software target changes as Electronic Steering events.
        target_change_points=[]
        current=None; ep=0
        for r in locs:
            if r.patient_target_xyz is not None and (current is None or self._xyz_changed(r.patient_target_xyz,current)):
                ep+=1; current=r.patient_target_xyz; target_change_points.append((r.clock_s,ep,current))
        previous_steering_by_epoch={}
        for ev in steering_events:
            candidates=[x for x in target_change_points if x[0] <= ev.clock_s]
            if not candidates:
                continue
            _,ev_epoch,base_target=max(candidates,key=lambda x:x[0])
            prev=previous_steering_by_epoch.get(ev_epoch)
            delta_prev=(tuple(ev.steering_xyz[i]-prev[i] for i in range(3)) if prev is not None else None)
            changed=(prev is not None and self._xyz_changed(ev.steering_xyz,prev,1e-6))
            if prev is None or changed:
                rows.append(PatientAlignmentWorkflowRow(
                    stage=(f"Target #{ev_epoch} — Electronic steering change" if changed else f"Target #{ev_epoch} — Sonication target established"),
                    sequence=0, timestamp=ev.timestamp, clock_s=ev.clock_s, target_xyz=base_target, transducer_xyz=None,
                    delta_xyz=None, axis_pass=None, overall_pass=None, source_record=None, target_epoch=ev_epoch,
                    change_mode=("Electronic steering" if changed else "Sonication target"), steering_xyz=ev.steering_xyz,
                    steering_delta_xyz=delta_prev, effective_target_xyz=ev.steering_xyz, sonication_number=ev.sonication_number,
                    note=("Software/electronic target change only; physical transducer position and <1 mm alignment status are not reinterpreted."
                          if changed else "First exported sonication target in this physical target epoch; establishes the electronic-target baseline.")))
            previous_steering_by_epoch[ev_epoch]=ev.steering_xyz

        # Preserve true chronology where timestamps exist. Untimed target-entry
        # transitions are anchored immediately before their source Locate rows.
        def sort_key(w):
            if w.clock_s is not None:
                # Initial Locate is the actual acquisition at this clock.
                return (float(w.clock_s), 1, w.sequence)
            r=w.source_record
            anchor=float(r.clock_s) if r is not None else -1.0
            if w.change_mode == "Physical target entry":
                # Target entry follows the initial Locate in the clinical workflow.
                return (anchor, 2, w.sequence)
            # Later physical retarget entry happened before the associated re-Locate.
            return (anchor, 0, w.sequence)
        rows.sort(key=sort_key)
        for i,w in enumerate(rows,1):
            w.sequence=i
        return rows

    def parse(self, workspace: Path) -> list[TransducerLocationRecord]:
        """Return tracker-derived localization residuals plus Patient-treatment alignment when a target reference is available."""
        return self._tracker_localizations(workspace)
