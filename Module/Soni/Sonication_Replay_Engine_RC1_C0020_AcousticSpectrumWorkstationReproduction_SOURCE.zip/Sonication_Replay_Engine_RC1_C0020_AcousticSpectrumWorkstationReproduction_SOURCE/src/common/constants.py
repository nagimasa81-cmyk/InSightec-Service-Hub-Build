APP_NAME = "Sonication Replay Engine"
APP_VERSION = "RC1-C0020 AcousticSpectrumWorkstationReproduction"
ORGANIZATION = "InSightec Service Tools"
IMAGE_SHAPE = (256, 256)
TEMPERATURE_PREFIX = "5"
MAGNITUDE_PREFIX = "6"
DEFAULT_MAIN_FREQUENCY_HZ = 650000.0

# C0016a marker
APP_COMMIT = 'C0020'
