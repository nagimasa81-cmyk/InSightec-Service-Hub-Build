from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import Qt


@dataclass(slots=True)
class CurrentSpectrumRenderResult:
    series: list[tuple[str, np.ndarray, np.ndarray, str]]
    frame_indices: dict[str, int]


class CurrentSpectrumRenderer:
    """Workstation-style current-frame acoustic spectrum renderer.

    This renderer is intentionally shared by the embedded chart and popup so
    both views always show the same FFT bins, normalization, reference lines,
    axis ranges and selected channels.
    """

    X_MIN_MHZ = 0.20
    X_MAX_MHZ = 0.80
    Y_MIN = 0.0
    Y_MAX = 4.0

    @staticmethod
    def relative_amplitude(values) -> np.ndarray:
        amplitude = np.abs(np.nan_to_num(np.asarray(values, float), nan=0.0, posinf=0.0, neginf=0.0))
        if amplitude.size == 0:
            return amplitude
        # Robust workstation-like baseline subtraction. A lower percentile
        # estimates the quiet noise floor; a high percentile, rather than the
        # absolute maximum, prevents a single corrupt bin from flattening the
        # rest of the spectrum.
        baseline = float(np.nanpercentile(amplitude, 12.0))
        signal = np.maximum(amplitude - baseline, 0.0)
        scale = float(np.nanpercentile(signal, 99.7))
        if not np.isfinite(scale) or scale <= 1e-30:
            scale = max(float(np.nanmax(signal)), 1e-30)
        relative = np.clip(signal / scale * 3.65, 0.0, 4.0)
        # Light five-point smoothing reproduces the workstation's stable line
        # without erasing narrow subharmonic peaks.
        if relative.size >= 5:
            kernel = np.asarray([1.0, 2.0, 3.0, 2.0, 1.0], float)
            kernel /= kernel.sum()
            relative = np.convolve(relative, kernel, mode="same")
        return np.clip(relative, 0.0, 4.0)

    def render(
        self,
        plot,
        channels: dict[str, list],
        selected: list[str],
        frame_index: int,
        replay_count: int,
        colors: dict[str, str],
        main_frequency_hz: float | None,
        map_index: Callable[[int, int, int], int],
        replay_seconds: float,
        title: str = "",
    ) -> CurrentSpectrumRenderResult:
        plot.clear()
        plot.showGrid(x=True, y=True, alpha=.22)
        plot.setLabel("left", "Relative Amplitude")
        plot.setLabel("bottom", "Frequency", units="MHz")
        if title:
            plot.setTitle(title)

        series: list[tuple[str, np.ndarray, np.ndarray, str]] = []
        indices: dict[str, int] = {}
        active = [ch for ch in selected if channels.get(ch)]
        single = len(active) <= 1
        for ch in active:
            frames = channels[ch]
            idx = map_index(frame_index, replay_count, len(frames))
            indices[ch] = idx
            frame = frames[idx]
            x = np.asarray(frame.frequency, float) / 1_000_000.0
            y = self.relative_amplitude(frame.amplitude)
            mask = np.isfinite(x) & np.isfinite(y) & (x >= self.X_MIN_MHZ) & (x <= self.X_MAX_MHZ)
            x, y = x[mask], y[mask]
            if not x.size:
                continue
            # The workstation defaults to one orange active-channel trace.
            # Multi-channel comparison retains stable per-channel colors.
            color = "#ff8c1a" if single else colors.get(ch, "#ffffff")
            plot.plot(x, y, pen=pg.mkPen(color, width=2.2), name=ch)
            series.append((ch, x, y, ""))

        main = float(main_frequency_hz or 0.0) / 1_000_000.0
        for value, label, color in (
            (main / 2.0, "Sub", "#55d7ff"),
            (main, "Main", "#ffd24a"),
        ):
            if self.X_MIN_MHZ <= value <= self.X_MAX_MHZ:
                line = pg.InfiniteLine(
                    pos=value, angle=90, movable=False,
                    pen=pg.mkPen(color, width=1.0, style=Qt.PenStyle.DashLine),
                    label=label,
                )
                plot.addItem(line)

        time_text = pg.TextItem(
            text=f"Time: {replay_seconds:.2f} s",
            color="#ff8c1a", anchor=(1.0, 0.0),
            fill=pg.mkBrush(20, 20, 20, 130),
        )
        time_text.setPos(self.X_MAX_MHZ - 0.005, self.Y_MAX - 0.08)
        time_text.setZValue(50)
        plot.addItem(time_text)
        plot.setXRange(self.X_MIN_MHZ, self.X_MAX_MHZ, padding=0)
        plot.setYRange(self.Y_MIN, self.Y_MAX, padding=0)
        return CurrentSpectrumRenderResult(series, indices)
