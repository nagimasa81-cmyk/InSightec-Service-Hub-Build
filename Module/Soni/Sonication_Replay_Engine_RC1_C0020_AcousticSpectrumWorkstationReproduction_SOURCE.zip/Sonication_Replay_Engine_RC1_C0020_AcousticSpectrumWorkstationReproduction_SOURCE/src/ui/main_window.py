from __future__ import annotations

import logging
import re
from pathlib import Path

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import QSettings, Qt, QTimer, QSize, QRectF, QEvent
from PySide6.QtGui import QAction, QImage, QPixmap, QIcon, QCursor
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QFileDialog, QFrame, QGroupBox, QHeaderView,
    QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QMainWindow,
    QMessageBox, QPushButton, QSlider, QSpinBox, QSplitter, QTableWidget,
    QTableWidgetItem, QTabWidget, QTreeWidget, QTreeWidgetItem, QVBoxLayout,
    QWidget, QDialog, QGridLayout, QToolButton, QMenu,
)

from src.common.constants import APP_NAME, APP_VERSION, ORGANIZATION
from src.domain.models import SonicationModel
from src.integration.spectrum_provider import SpectrumMsgAnalyzerAdapter
from src.services.discovery_service import DiscoveryService
from src.services.import_service import ImportService
from src.services.replay_service import ReplayService
from src.services.acoustic_control_service import AcousticControlService
from src.services.sonication_channel_service import SonicationChannelService
from src.core.chart_state import ChartState
from src.core.relative_spectrum_renderer import RelativeSpectrumRenderer
from src.core.current_spectrum_renderer import CurrentSpectrumRenderer
from src.ui.image_panel import OverlayPanel

LOG = logging.getLogger(__name__)


class InfoWindow(QDialog):
    """Non-modal, movable, minimizable information window kept above the replay UI."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Sonication Information")
        self.setWindowFlags(
            Qt.WindowType.Window | Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowCloseButtonHint
        )
        self.setModal(False)
        self.resize(540, 360)
        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["Item", "Value"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout = QVBoxLayout(self)
        layout.addWidget(self.table)

    def update_rows(self, rows):
        self.table.setRowCount(len(rows))
        for r, (key, value) in enumerate(rows):
            self.table.setItem(r, 0, QTableWidgetItem(str(key)))
            self.table.setItem(r, 1, QTableWidgetItem(str(value)))


class HoldInfoButton(QPushButton):
    """Shows a temporary popup only while the right mouse button is held."""
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.popup = QLabel()
        self.popup.setWindowFlags(Qt.WindowType.ToolTip)
        self.popup.setStyleSheet("QLabel { background:#152536; color:white; border:1px solid #4c789d; padding:10px; }")

    def set_popup_text(self, text):
        self.popup.setText(text)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.RightButton:
            self.popup.adjustSize()
            self.popup.move(QCursor.pos())
            self.popup.show()
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.RightButton:
            self.popup.hide()
            event.accept()
            return
        super().mouseReleaseEvent(event)



class ChartPopup(QDialog):
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowCloseButtonHint)
        self.setModal(False); self.resize(1000,650)
        self.plot = pg.PlotWidget(title=title); self.plot.showGrid(x=True,y=True,alpha=.2)
        self.hover_series = []
        self.hover_text = pg.TextItem(anchor=(0, 1), color="#ffffff", fill=pg.mkBrush(0, 0, 0, 210))
        self.hover_text.setZValue(100); self.hover_text.hide(); self.plot.addItem(self.hover_text)
        self.hover_proxy = pg.SignalProxy(self.plot.scene().sigMouseMoved, rateLimit=45, slot=self._hovered)
        layout=QVBoxLayout(self); layout.addWidget(self.plot)

    def set_hover_series(self, series):
        """series: [(label, x-array, y-array, unit), ...]."""
        self.hover_series = series or []
        if not self.hover_series:
            self.hover_text.hide()

    def _hovered(self, event):
        scene_pos = event[0] if isinstance(event, (tuple, list)) else event
        if not self.hover_series or not self.plot.sceneBoundingRect().contains(scene_pos):
            self.hover_text.hide(); return
        point = self.plot.plotItem.vb.mapSceneToView(scene_pos)
        lines=[]; best_x=None
        for label, x_values, y_values, unit in self.hover_series:
            x=np.asarray(x_values,float); y=np.asarray(y_values,float)
            valid=np.isfinite(x)&np.isfinite(y)
            if not valid.any(): continue
            xv=x[valid]; yv=y[valid]; i=int(np.argmin(np.abs(xv-point.x())))
            if best_x is None: best_x=float(xv[i]); lines.append(f"{best_x:.2f} sec")
            lines.append(f"{label}: {float(yv[i]):.2f}{unit}")
        if not lines:
            self.hover_text.hide(); return
        self.hover_text.setText("\n".join(lines)); self.hover_text.setPos(point.x(),point.y()); self.hover_text.show()


class MainWindow(QMainWindow):
    """FUS workstation-inspired Sonication-folder replay UI.

    The RC1 replay UI deliberately prioritizes replay-first behavior. The
    partially developed acoustic-analysis controls remain available on the
    Analysis tab, but they no longer reduce the size of the replay image.
    """

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} - {APP_VERSION}")
        self.resize(1760, 1040)
        self.setMinimumSize(1180, 720)
        self.setAcceptDrops(True)

        self.settings = QSettings(ORGANIZATION, APP_NAME)
        self.importer = ImportService()
        self.discovery = DiscoveryService()
        self.replay = ReplayService()
        self.acoustic_control_service = AcousticControlService()
        self.package = None
        self.current: SonicationModel | None = None
        self.frame_index = 0
        self.max_temperature_trend: list[float] = []
        self.mean_temperature_trend: list[float] = []
        self.delta_trend: list[float] = []
        self.temperature_display_mode = "Absolute Temperature"
        self.spectrum_channels: dict[str, list] = {}
        self.chart_state = ChartState()
        self.cpc_enabled = self.chart_state.cpc_enabled
        self.sonication_channel_service = SonicationChannelService()
        self.relative_spectrum_renderer = RelativeSpectrumRenderer()
        self.current_spectrum_renderer = CurrentSpectrumRenderer()
        self._active_spectrum_channel = "CH0"
        self._channel_colors = {
            "CH0":"#ff3b30", "CH1":"#ff9500", "CH2":"#ffd60a", "CH3":"#9ef01a",
            "CH4":"#30d158", "CH5":"#32d7ff", "CH6":"#0a84ff", "CH7":"#bf5af2",
        }
        self.spectrum_provider = SpectrumMsgAnalyzerAdapter()
        self._spectrum_frame = None
        self._spectrum_status = "No SpectrumMsg"
        self.sonication_index = -1
        self.cursor_temperature_trend: list[float] = []
        self._overlay_session_view = None
        self._overlay_session_levels = None
        self._restore_overlay_session = False

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.next_frame)

        pg.setConfigOption("background", "k")
        pg.setConfigOption("foreground", "w")

        self._build_actions()
        self._build_ui()
        self._restore()

    # ------------------------------------------------------------------ UI
    def _build_actions(self):
        menu = self.menuBar().addMenu("&File")
        open_zip = QAction("Open ZIP...", self)
        open_zip.triggered.connect(self.open_zip)
        menu.addAction(open_zip)
        open_folder = QAction("Open Folder...", self)
        open_folder.triggered.connect(self.open_folder)
        menu.addAction(open_folder)

        toolbar = self.addToolBar("Main")
        toolbar.setObjectName("MainToolbar")
        toolbar.setMovable(False)
        toolbar.addAction(open_zip)
        toolbar.addAction(open_folder)

    def _build_ui(self):
        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_replay_tab(), "Replay")
        self.tabs.addTab(self._build_analysis_tab(), "Analysis (preserved)")
        self.setCentralWidget(self.tabs)
        self.statusBar().showMessage("Ready")

    def _chart_panel(self, title: str, plot: pg.PlotWidget, key: str) -> QWidget:
        panel=QGroupBox(title); lay=QVBoxLayout(panel); lay.setContentsMargins(3,3,3,3); lay.setSpacing(1)
        header=QHBoxLayout(); header.setContentsMargins(0,0,0,0)
        expand=QToolButton(); expand.setText("↗"); expand.setToolTip("Open enlarged chart")
        expand.setFixedSize(20,20); expand.setStyleSheet("QToolButton{padding:0;font-size:10px;}")
        expand.clicked.connect(lambda: self._open_chart_popup(key))
        header.addStretch(1); header.addWidget(expand); lay.addLayout(header); lay.addWidget(plot,1)
        return panel

    def _build_replay_tab(self) -> QWidget:
        # Compact top strip: Sonication number is intentionally not a list.
        self.son_prev_btn = QPushButton("≪")
        self.son_next_btn = QPushButton("≫")
        self.son_number_btn = HoldInfoButton("-")
        self.son_number_btn.setMinimumWidth(64)
        self.son_prev_btn.clicked.connect(lambda: self._change_sonication(-1))
        self.son_next_btn.clicked.connect(lambda: self._change_sonication(1))
        self.info_btn = QPushButton("ⓘ Info")
        self.info_btn.clicked.connect(self._show_info_window)
        self.info_window = InfoWindow(self)

        top_bar = QHBoxLayout()
        top_bar.addWidget(QLabel("Sonication No."))
        top_bar.addWidget(self.son_prev_btn)
        top_bar.addWidget(self.son_number_btn)
        top_bar.addWidget(self.son_next_btn)
        top_bar.addWidget(QLabel("Right-click and hold for details"))
        top_bar.addStretch(1)
        top_bar.addWidget(self.info_btn)

        # Left controls: temperature scale and a true slider for red threshold.
        self.temperature_mode_combo = QComboBox()
        self.temperature_mode_combo.addItems(["Absolute Temperature", "ΔTemperature (Investigation)"])
        self.temperature_mode_combo.currentTextChanged.connect(self._temperature_mode_changed)
        self.range_combo = QComboBox()
        self.range_combo.addItems(["40–60 °C", "35–60 °C", "30–90 °C", "0–60 °C", "Auto"])
        self.range_combo.currentIndexChanged.connect(self._temperature_range_changed)
        self.overlay_opacity = QSlider(Qt.Orientation.Horizontal)
        self.overlay_opacity.setRange(0, 100); self.overlay_opacity.setValue(55)
        self.overlay_opacity.valueChanged.connect(lambda _: self.set_frame(self.frame_index))
        self.threshold_slider = QSlider(Qt.Orientation.Horizontal)
        self.threshold_slider.setRange(30, 90); self.threshold_slider.setValue(48)
        self.threshold_minus = QPushButton("◀"); self.threshold_plus = QPushButton("▶")
        for button in (self.threshold_minus, self.threshold_plus): button.setFixedWidth(28)
        self.threshold_minus.clicked.connect(lambda: self.threshold_slider.setValue(self.threshold_slider.value()-1))
        self.threshold_plus.clicked.connect(lambda: self.threshold_slider.setValue(self.threshold_slider.value()+1))
        self.threshold_value = QLabel("Red starts at 48 °C")
        self.threshold_slider.valueChanged.connect(self._threshold_changed)
        self.baseline_label = QLabel("Temperature source: waiting")
        self.baseline_label.setWordWrap(True); self.baseline_label.setObjectName("CurrentValue")
        self.cursor_temperature_label = QLabel("Cursor Temperature: --")
        self.cursor_temperature_label.setWordWrap(True); self.cursor_temperature_label.setObjectName("CurrentValue")

        left = QWidget(); ll = QVBoxLayout(left); ll.setContentsMargins(3,3,3,3)
        ll.addWidget(QLabel("Temperature display")); ll.addWidget(self.temperature_mode_combo)
        ll.addWidget(QLabel("Overlay opacity")); ll.addWidget(self.overlay_opacity)
        ll.addWidget(QLabel("Temperature range")); ll.addWidget(self.range_combo)
        ll.addWidget(QLabel("Red Threshold"));
        threshold_row=QHBoxLayout(); threshold_row.setContentsMargins(0,0,0,0); threshold_row.setSpacing(3)
        threshold_row.addWidget(self.threshold_minus); threshold_row.addWidget(self.threshold_slider,1); threshold_row.addWidget(self.threshold_plus)
        ll.addLayout(threshold_row); ll.addWidget(self.threshold_value)
        self.voxel_label = QLabel("Voxel (ROI)  5 mm × 5 mm"); self.voxel_label.setObjectName("CurrentValue"); ll.addWidget(self.voxel_label)
        ll.addWidget(self.cursor_temperature_label)
        ll.addWidget(self.baseline_label); ll.addStretch(1)
        left.setMinimumWidth(145); left.setMaximumWidth(190)

        # Dominant workstation image. Click moves the crosshair and updates temperature.
        self.overlay = OverlayPanel("Thermal Replay - Workstation Temperature Map")
        self.overlay.cursorMoved.connect(self._overlay_cursor_moved)
        self.overlay.viewStateChanged.connect(self._capture_overlay_state_debounced)
        self.overlay.levelsChanged.connect(self._capture_overlay_levels)
        self._overlay_save_timer=QTimer(self); self._overlay_save_timer.setSingleShot(True); self._overlay_save_timer.timeout.connect(self._save_overlay_state)
        self._fit_overlay_next = True
        self.cursor_x = None; self.cursor_y = None

        # Frame strip.
        self.frame_list = QListWidget()
        self.frame_list.setViewMode(QListWidget.ViewMode.IconMode)
        self.frame_list.setIconSize(QSize(100, 84)); self.frame_list.setGridSize(QSize(110, 108))
        self.frame_list.setResizeMode(QListWidget.ResizeMode.Adjust)
        self.frame_list.setMovement(QListWidget.Movement.Static)
        self.frame_list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.frame_list.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.frame_list.currentRowChanged.connect(lambda i: self.set_frame(i) if i >= 0 else None)
        navigator_box = QGroupBox("Thermal / Anatomy Frames")
        nav_layout = QVBoxLayout(navigator_box); nav_layout.setContentsMargins(3,10,3,3); nav_layout.addWidget(self.frame_list)
        navigator_box.setMaximumHeight(142)

        self.temperature_plot = pg.PlotWidget()
        self.temperature_plot.setLabel("left", "Temperature", units="°C")
        self.temperature_plot.setLabel("bottom", "Replay time", units="sec")
        self.temperature_plot.showGrid(x=True, y=True, alpha=.28)
        self.temperature_plot.setYRange(40, 60, padding=0)
        self.temperature_plot.getAxis("left").setTickSpacing(major=2, minor=1)
        # Workstation-style temperature bands remain behind every curve.
        self.temperature_bands = []
        for low, high, rgba in (
            (40, 44, (70, 105, 150, 35)),
            (44, 48, (70, 145, 120, 35)),
            (48, 52, (205, 170, 35, 38)),
            (52, 56, (220, 105, 25, 42)),
            (56, 60, (190, 30, 30, 46)),
        ):
            band = pg.LinearRegionItem(values=(low, high), orientation="horizontal", movable=False, brush=pg.mkBrush(*rgba), pen=pg.mkPen(None))
            band.setZValue(-20)
            self.temperature_plot.addItem(band)
            self.temperature_bands.append(band)
        self.max_temperature_curve = self.temperature_plot.plot(pen=pg.mkPen("#ff3b30", width=3), name="Max")
        self.mean_temperature_curve = self.temperature_plot.plot(pen=pg.mkPen("#49e36b", width=2.5), name="ROI Average")
        self.cursor_temperature_curve = self.temperature_plot.plot(pen=pg.mkPen("#b98cff", width=1.6, style=Qt.PenStyle.DashLine), name="Cursor")
        self.temperature_cursor = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen("#00bfff", width=1.5))
        self.temperature_plot.addItem(self.temperature_cursor)
        self.temperature_plot.scene().sigMouseClicked.connect(self._temperature_plot_clicked)
        self.temperature_hover_text = pg.TextItem(anchor=(0, 1), color="#ffffff", fill=pg.mkBrush(0, 0, 0, 190))
        self.temperature_hover_text.setZValue(50); self.temperature_hover_text.hide(); self.temperature_plot.addItem(self.temperature_hover_text)
        self.temperature_hover_proxy = pg.SignalProxy(self.temperature_plot.scene().sigMouseMoved, rateLimit=45, slot=self._temperature_plot_hovered)

        self.spectrum_plot = pg.PlotWidget()
        self.spectrum_plot.setLabel("left", "Relative Amplitude")
        self.spectrum_plot.setLabel("bottom", "Frequency", units="MHz")
        self.spectrum_plot.showGrid(x=True, y=True, alpha=.24)
        self.spectrum_plot.setXRange(0.2, 0.8, padding=0)
        self.spectrum_plot.setYRange(0.0, 4.0, padding=0)
        self.spectrum_hover_text = pg.TextItem(anchor=(0, 1), color="#ffffff", fill=pg.mkBrush(0, 0, 0, 205))
        self.spectrum_hover_text.setZValue(100); self.spectrum_hover_text.hide(); self.spectrum_plot.addItem(self.spectrum_hover_text)
        self.spectrum_hover_series = []
        self.spectrum_hover_proxy = pg.SignalProxy(self.spectrum_plot.scene().sigMouseMoved, rateLimit=45, slot=self._spectrum_plot_hovered)
        self.spectrum_plot.plotItem.vb.sigRangeChanged.connect(lambda *_: self._remember_chart_range("spectrum", self.spectrum_plot))

        self.graph_split = QSplitter(Qt.Orientation.Horizontal)
        self.temperature_panel=self._chart_panel("Temperature Trend (ROI)",self.temperature_plot,"temperature")
        self.spectrum_panel=self._chart_panel("Acoustic Spectrum (Current Frame)",self.spectrum_plot,"spectrum")
        self.graph_split.addWidget(self.temperature_panel); self.graph_split.addWidget(self.spectrum_panel); self.graph_split.setSizes([500,500])
        self.graph_split.setMaximumHeight(320)
        self.graph_split.setMinimumHeight(230)

        # FUS workstation-style Power and Score trend. Current values are drawn inside the chart.
        self.acoustic_control_plot = pg.PlotWidget()
        self.acoustic_control_plot.setLabel("left", "Power / Score", units="%")
        self.acoustic_control_plot.setLabel("bottom", "Replay time", units="sec")
        self.acoustic_control_plot.setYRange(0.0, 110.0, padding=0)
        self.acoustic_control_plot.showGrid(x=True, y=True, alpha=.22)
        self.acoustic_power_curve = self.acoustic_control_plot.plot(pen=pg.mkPen("#58f26a", width=2.3), name="Power %")
        self.acoustic_score_curve = self.acoustic_control_plot.plot(pen=pg.mkPen("#ff9d22", width=2.3), name="Score")
        self.acoustic_control_cursor = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen("#00bfff", width=1.3))
        self.acoustic_control_plot.addItem(self.acoustic_control_cursor)
        self.acoustic_control_plot.scene().sigMouseClicked.connect(self._acoustic_plot_clicked)
        self.acoustic_hover_text = pg.TextItem(anchor=(0, 1), color="#ffffff", fill=pg.mkBrush(0, 0, 0, 205))
        self.acoustic_hover_text.setZValue(80); self.acoustic_hover_text.hide(); self.acoustic_control_plot.addItem(self.acoustic_hover_text)
        self.acoustic_hover_proxy = pg.SignalProxy(self.acoustic_control_plot.scene().sigMouseMoved, rateLimit=45, slot=self._acoustic_plot_hovered)
        self.acoustic_power_text = pg.TextItem("Power: --", color="#58f26a", anchor=(1, 1), fill=pg.mkBrush(0, 0, 0, 150))
        self.acoustic_score_text = pg.TextItem("Score: --", color="#ff9d22", anchor=(1, 0), fill=pg.mkBrush(0, 0, 0, 150))
        self.acoustic_power_text.setZValue(20); self.acoustic_score_text.setZValue(20)
        self.acoustic_control_plot.addItem(self.acoustic_power_text); self.acoustic_control_plot.addItem(self.acoustic_score_text)
        self.acoustic_power_value = QLabel("Unavailable")
        self.acoustic_score_value = QLabel("Unavailable")
        self.acoustic_cavitation_value = QLabel("Unavailable")
        for w in (self.acoustic_power_value, self.acoustic_score_value, self.acoustic_cavitation_value):
            w.hide()

        self.waterfall_replay_plot = pg.PlotWidget()
        self.waterfall_replay_plot.setLabel("left", "Frequency", units="MHz")
        self.waterfall_replay_plot.setLabel("bottom", "Replay time", units="sec")
        self.waterfall_replay_plot.setTitle("")
        self.waterfall_replay_image = pg.ImageItem(axisOrder="row-major")
        self.waterfall_replay_plot.addItem(self.waterfall_replay_image)
        waterfall_colors = np.array([[0,0,25,255],[0,55,170,255],[0,210,255,255],[255,235,0,255],[255,75,0,255],[255,255,255,255]], dtype=np.ubyte)
        waterfall_positions = np.linspace(0.0, 1.0, len(waterfall_colors))
        self.waterfall_replay_image.setLookupTable(pg.ColorMap(waterfall_positions, waterfall_colors).getLookupTable(0.0, 1.0, 256))
        self.waterfall_replay_cursor = pg.InfiniteLine(angle=90, movable=False, pen=pg.mkPen("w", width=1.5))
        self.waterfall_replay_plot.addItem(self.waterfall_replay_cursor)

        # Compact CH popup: single, multiple, or all channels without wasting chart height.
        self.channel_actions = {}
        self.channel_button = QToolButton()
        self.channel_button.setText("CH")
        self.channel_button.setToolTip("Select one, multiple, or all hydrophone channels")
        self.channel_button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.channel_menu = QMenu(self.channel_button)
        self.all_channels_action = QAction("All Channels", self.channel_menu)
        self.all_channels_action.setCheckable(True); self.all_channels_action.setChecked(False)
        self.all_channels_action.toggled.connect(self._toggle_all_channels)
        self.channel_menu.addAction(self.all_channels_action)
        self.channel_menu.addSeparator()
        self.channel_button.setMenu(self.channel_menu)
        self.current_spectrum_label = QLabel("Spectrum: waiting")
        self.current_spectrum_label.setObjectName("CurrentValue")
        self.current_spectrum_label.setMaximumHeight(20)
        spectrum_layout = self.spectrum_panel.layout()
        channel_row = QHBoxLayout(); channel_row.setContentsMargins(0,0,0,0); channel_row.setSpacing(4)
        self.cpc_button = QPushButton("CPC OFF")
        self.cpc_button.setCheckable(True)
        self.cpc_button.setChecked(False)
        self.cpc_button.setToolTip("OFF: Sonication folder only. ON: also decode CPCFiles Spectrum/Acquisition DMP data")
        self.cpc_button.toggled.connect(self._cpc_toggled)
        channel_row.addWidget(self.channel_button); channel_row.addWidget(self.cpc_button); channel_row.addWidget(self.current_spectrum_label); channel_row.addStretch(1)
        spectrum_layout.insertLayout(0, channel_row)
        acoustic_box = self._chart_panel("Power % / Score", self.acoustic_control_plot, "acoustic")
        self.waterfall_panel = self._chart_panel("Relative Acoustic Spectrum vs Replay Time", self.waterfall_replay_plot, "waterfall")

        right = QWidget(); rl = QVBoxLayout(right); rl.setContentsMargins(0,0,0,0)
        self.lower_split=QSplitter(Qt.Orientation.Horizontal); self.lower_split.addWidget(acoustic_box); self.lower_split.addWidget(self.waterfall_panel); self.lower_split.setSizes([430,570]); self.lower_split.setMaximumHeight(165); self.lower_split.setMinimumHeight(105)
        rl.addWidget(navigator_box,0); rl.addWidget(self.graph_split,1); rl.addWidget(self.lower_split,2)

        self.top_split = QSplitter(Qt.Orientation.Horizontal)
        self.top_split.addWidget(left); self.top_split.addWidget(self.overlay); self.top_split.addWidget(right)
        self.top_split.setSizes([155,760,760]); self.top_split.setStretchFactor(1,5); self.top_split.setStretchFactor(2,4)

        self.first_btn=QPushButton("|<"); self.prev_btn=QPushButton("<"); self.play_btn=QPushButton("▶")
        self.next_btn=QPushButton(">"); self.last_btn=QPushButton(">|")
        self.first_btn.clicked.connect(lambda:self.set_frame(0)); self.prev_btn.clicked.connect(self.previous_frame)
        self.play_btn.clicked.connect(self.toggle_play); self.next_btn.clicked.connect(self.next_frame)
        self.last_btn.clicked.connect(lambda:self.set_frame(max(0,self.current.replay_frame_count-1) if self.current else 0))
        self.speed=QSpinBox(); self.speed.setRange(1,20); self.speed.setValue(5); self.speed.setSuffix(" fps"); self.speed.valueChanged.connect(self.speed_changed)
        self.frame_label=QLabel("Frame -/-"); self.frame_label.setObjectName("CurrentValue")
        self.sync_label=QLabel("Image / Temperature / Spectrum: waiting"); self.sync_label.setObjectName("CurrentValue")
        self.timeline=QSlider(Qt.Orientation.Horizontal); self.timeline.valueChanged.connect(self.slider_changed)
        controls=QHBoxLayout()
        for w in (self.first_btn,self.prev_btn,self.play_btn,self.next_btn,self.last_btn,QLabel("Speed"),self.speed,self.frame_label): controls.addWidget(w)
        controls.addStretch(1); controls.addWidget(self.sync_label)
        bottom=QWidget(); bl=QVBoxLayout(bottom); bl.setContentsMargins(5,1,5,3); bl.addLayout(controls); bl.addWidget(self.timeline)

        page=QWidget(); layout=QVBoxLayout(page); layout.setContentsMargins(2,2,2,2)
        layout.addLayout(top_bar); layout.addWidget(self.top_split,1); layout.addWidget(bottom,0)
        return page

    def _build_analysis_tab(self) -> QWidget:
        """Preserve earlier analysis work without allowing it to dominate Replay."""
        self.hydro_view = QComboBox()
        self.hydro_view.addItems(["Both", "Spectrum", "Waterfall"])
        self.hydro_view.currentIndexChanged.connect(self._hydro_layout_changed)
        self.hydro_arrangement = QComboBox()
        self.hydro_arrangement.addItems(["Overlay", "Stacked"])
        self.hydro_arrangement.currentIndexChanged.connect(lambda _: self._update_analysis_hydrophone())

        controls = QHBoxLayout()
        controls.addWidget(QLabel("View"))
        controls.addWidget(self.hydro_view)
        controls.addWidget(QLabel("Spectrum layout"))
        controls.addWidget(self.hydro_arrangement)
        controls.addStretch(1)

        self.analysis_spectrum_plot = pg.PlotWidget(title="Hydrophone Spectrum Analysis")
        self.analysis_spectrum_plot.setLabel("bottom", "Frequency", units="kHz")
        self.analysis_spectrum_plot.showGrid(x=True, y=True, alpha=.2)
        self.waterfall_plot = pg.PlotWidget(title="Hydrophone Waterfall")
        self.waterfall_plot.setLabel("left", "Spectrum frame / channel")
        self.waterfall_plot.setLabel("bottom", "Frequency", units="kHz")
        self.waterfall_image = pg.ImageItem()
        self.waterfall_plot.addItem(self.waterfall_image)
        self.waterfall_cursor = pg.InfiniteLine(angle=0, movable=False, pen=pg.mkPen("y", width=2))
        self.waterfall_plot.addItem(self.waterfall_cursor)

        self.hydro_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.hydro_splitter.addWidget(self.analysis_spectrum_plot)
        self.hydro_splitter.addWidget(self.waterfall_plot)
        self.hydro_splitter.setSizes([800, 800])

        info = QLabel(
            "The earlier acoustic-analysis work is preserved here. "
            "Replay-first synchronization is completed before further analysis expansion."
        )
        info.setWordWrap(True)

        page = QWidget()
        layout = QVBoxLayout(page)
        layout.addWidget(info)
        layout.addLayout(controls)
        layout.addWidget(self.hydro_splitter, 1)
        return page

    # --------------------------------------------------------------- Loading
    def open_zip(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "Open treatment or Sonication ZIP", "", "ZIP files (*.zip)")
        if file_name:
            self.load(Path(file_name))

    def open_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Open treatment or Sonication folder")
        if folder:
            self.load(Path(folder))

    def load(self, source: Path):
        try:
            workspace = self.importer.open(source)
            self.package = self.discovery.discover(source, workspace)
        except Exception as exc:
            LOG.exception("Import failed")
            QMessageBox.critical(self, APP_NAME, str(exc))
            return
        self.spectrum_provider = SpectrumMsgAnalyzerAdapter(self.package.main_frequency_hz)
        if not self.package.sonications:
            QMessageBox.information(self, APP_NAME, "No compatible Sonication data found.")
            return
        self.sonication_index = 0
        self._select_sonication_index(0)
        self.statusBar().showMessage(f"Loaded {len(self.package.sonications)} sonication(s)")

    def _change_sonication(self, step: int):
        if not self.package or not self.package.sonications:
            return
        self._select_sonication_index((self.sonication_index + step) % len(self.package.sonications))

    def _select_sonication_index(self, index: int):
        if not self.package or not self.package.sonications:
            return
        self.sonication_index = max(0, min(index, len(self.package.sonications)-1))
        self.current = self.package.sonications[self.sonication_index]
        son_freq = self.current.main_frequency_hz or self.package.main_frequency_hz
        self.spectrum_provider = SpectrumMsgAnalyzerAdapter(son_freq)
        self.timer.stop(); self.play_btn.setText("▶")
        self.replay.clear_cache()
        self._load_spectrum_channels()
        self.cursor_x = self.cursor_y = None
        self._build_temperature_trends()
        self._build_acoustic_trends()
        self._build_frame_navigator()
        # Every newly opened source/sonication starts from a clean, fitted view.
        # Pan/zoom/WLWW are then retained only for the current loaded session.
        self._overlay_session_view = None
        self._overlay_session_levels = None
        self._restore_overlay_session = False
        self._fit_overlay_next = True
        self.son_number_btn.setText(str(self.sonication_index + 1))
        self.son_number_btn.set_popup_text(self._sonication_popup_text())
        self.set_frame(self._highest_average_frame())

    def _highest_average_frame(self):
        if not self.mean_temperature_trend:
            return 0
        values=np.asarray(self.mean_temperature_trend,float)
        return int(np.nanargmax(values)) if np.isfinite(values).any() else 0

    def select_sonication(self):
        return

    def _sonication_popup_text(self):
        if not self.current or not self.package:
            return "No sonication loaded"
        return (f"Sonication {self.sonication_index+1} / {len(self.package.sonications)}\n"
                f"Name: {self.current.name}\nFrames: {self.current.replay_frame_count}\n"
                f"Temperature RAW: {len(self.current.temperature_frames)}\n"
                f"Magnitude RAW: {len(self.current.magnitude_frames)}\n"
                f"SpectrumMsg: {len(self.current.spectrum_files)}\nACT: {len(self.current.act_files)}")

    # ---------------------------------------------------------- Synchronization
    def _build_temperature_trends(self):
        self.max_temperature_trend = []
        self.mean_temperature_trend = []
        self.delta_trend = []
        if not self.current:
            return
        for index in range(self.current.replay_frame_count):
            try:
                data = self.replay.frame(self.current, index)
                self.max_temperature_trend.append(data.maximum_temperature if data.maximum_temperature is not None else np.nan)
                self.mean_temperature_trend.append(data.mean_temperature if data.mean_temperature is not None else np.nan)
                self.delta_trend.append(data.maximum_delta_temperature if data.maximum_delta_temperature is not None else np.nan)
            except Exception:
                self.max_temperature_trend.append(np.nan)
                self.mean_temperature_trend.append(np.nan)
                self.delta_trend.append(np.nan)
        x = self._frame_time_axis(self.current.replay_frame_count)
        self.max_temperature_curve.setData(x, np.asarray(self.max_temperature_trend, float))
        self.mean_temperature_curve.setData(x, np.asarray(self.mean_temperature_trend, float))

    def _build_acoustic_trends(self):
        count = self.current.replay_frame_count if self.current else 0
        if not self.current or not self.package or count <= 0:
            self.acoustic_peaks = np.asarray([], dtype=float)
            self.acoustic_scores = np.asarray([], dtype=float)
            self.acoustic_control_trend = None
            self.acoustic_power_curve.setData([], [])
            self.acoustic_score_curve.setData([], [])
            return
        duration = self._index_to_seconds(max(count - 1, 0), count)
        trend = self.acoustic_control_service.trend_for_sonication(
            self.package.workspace, self.sonication_index, count, duration
        )
        self.acoustic_control_trend = trend
        self._ensure_acoustic_curve_items()
        self.acoustic_peaks = trend.power_percent
        self.acoustic_scores = trend.score_percent
        self.acoustic_power_curve.setData(np.asarray(trend.time_s,float), np.asarray(trend.power_percent,float), connect="finite")
        self.acoustic_score_curve.setData(np.asarray(trend.time_s,float), np.asarray(trend.score_percent,float), connect="finite")
        finite = np.concatenate((trend.power_percent[np.isfinite(trend.power_percent)], trend.score_percent[np.isfinite(trend.score_percent)]))
        ymax = max(110.0, float(np.nanmax(finite) * 1.1)) if finite.size else 110.0
        self.acoustic_control_plot.setYRange(0.0, ymax, padding=0.02)
        if trend.source:
            self.acoustic_control_plot.setTitle("")
        else:
            self.acoustic_control_plot.setTitle("")

    def _ensure_acoustic_curve_items(self):
        """Recreate embedded Power/Score PlotDataItems when Qt loses them.

        Recreating the curves is more reliable than re-adding stale PlotDataItems
        after a popup has been opened or a sonication has changed.
        """
        for attr in ("acoustic_power_curve", "acoustic_score_curve"):
            item=getattr(self,attr,None)
            if item is not None:
                try: self.acoustic_control_plot.removeItem(item)
                except Exception: pass
        self.acoustic_power_curve=self.acoustic_control_plot.plot(pen=pg.mkPen("#58f26a",width=2.5),name="Power %")
        self.acoustic_score_curve=self.acoustic_control_plot.plot(pen=pg.mkPen("#ff9d22",width=2.5),name="Score")
        for item in (self.acoustic_control_cursor,self.acoustic_hover_text,self.acoustic_power_text,self.acoustic_score_text):
            try:
                if item not in self.acoustic_control_plot.items(): self.acoustic_control_plot.addItem(item)
            except Exception:
                try: self.acoustic_control_plot.addItem(item)
                except Exception: pass

    def _build_frame_navigator(self):
        self.frame_list.blockSignals(True)
        self.frame_list.clear()
        if not self.current:
            self.frame_list.blockSignals(False)
            return
        count = self.current.replay_frame_count
        for index in range(count):
            try:
                data = self.replay.frame(self.current, index)
                source = data.magnitude if data.magnitude is not None else data.temperature
                icon = self._array_icon(source)
                seconds = self._index_to_seconds(index, count)
                text = f"{seconds:.1f} Sec\nFrame {index + 1}"
            except Exception:
                icon = QIcon()
                text = f"Frame {index + 1}"
            item = QListWidgetItem(icon, text)
            item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
            self.frame_list.addItem(item)
        self.frame_list.blockSignals(False)

    def set_frame(self, index: int):
        if not self.current:
            return
        try:
            data = self.replay.frame(self.current, index)
        except Exception as exc:
            QMessageBox.warning(self, APP_NAME, f"Unable to decode frame\n{exc}")
            return

        self.frame_index = data.replay_index
        count = self.current.replay_frame_count
        seconds = self._index_to_seconds(self.frame_index, count)

        self.timeline.blockSignals(True)
        self.timeline.setRange(0, max(0, count - 1))
        self.timeline.setValue(self.frame_index)
        self.timeline.blockSignals(False)
        self.frame_list.blockSignals(True)
        self.frame_list.setCurrentRow(self.frame_index)
        self.frame_list.blockSignals(False)
        self.frame_list.scrollToItem(self.frame_list.currentItem())

        self.frame_label.setText(f"Frame {self.frame_index + 1}/{count}   {seconds:.2f} sec")
        self.temperature_cursor.setPos(seconds)
        lo,hi=self._current_temperature_range(); self.temperature_plot.setYRange(lo,hi,padding=0)

        # WL/WW is dataset-local. Never inherit global settings into a new DQA/Treatment.
        magnitude_levels = self._overlay_session_levels
        if magnitude_levels is None and data.magnitude is not None:
            finite_mag = np.asarray(data.magnitude, float)
            finite_mag = finite_mag[np.isfinite(finite_mag)]
            if finite_mag.size:
                low, high = np.percentile(finite_mag, [2.0, 98.5])
                if high <= low:
                    high = low + 1.0
                magnitude_levels = (float(low), float(high))
        hotspot = (data.hotspot_x, data.hotspot_y) if data.hotspot_x is not None else None
        hotspot_text = None
        if data.maximum_temperature is not None:
            hotspot_text = (
                f"Max = {data.maximum_temperature:.1f} °C\n"
                f"Avg = {data.mean_temperature:.1f} °C"
            )
        investigation = self.temperature_display_mode.startswith("Δ")
        shown = data.temperature_delta if investigation else data.temperature
        levels = self._delta_levels(shown) if investigation else self._temperature_levels(shown)
        if investigation:
            lut = pg.colormap.get("CET-L4").getLookupTable(0, 1, 256)
        else:
            low, high = levels if levels is not None else (40.0, 60.0)
            lut = self._temperature_lut_with_red_threshold(low, high)
        self.overlay.set_roi(data.roi_center_x, data.roi_center_y, data.roi_radius, data.roi_width, data.roi_height)
        self.overlay.set_hover_temperature(shown)
        self.overlay.set_overlay(
            data.magnitude,
            shown,
            magnitude_levels,
            levels,
            lut,
            self.overlay_opacity.value() / 100.0,
            hotspot,
            hotspot_text,
            None,
            fit=self._fit_overlay_next,
        )
        self._fit_overlay_next = False
        # Keep pan/zoom/WLWW while navigating within the current loaded source,
        # but never inherit a previous file's image state on first open.
        if self._restore_overlay_session and self._overlay_session_view:
            self.overlay.set_view_range(self._overlay_session_view)
        if self._restore_overlay_session and self._overlay_session_levels:
            self.overlay.set_magnitude_levels(self._overlay_session_levels)
        self._restore_overlay_session = True
        self.baseline_label.setText(
            f"Source: {data.temperature_source}\n"
            f"Reference: {data.reference_temperature:.1f} °C\n"
            f"ROI: {data.roi_source}"
        )

        spectrum_index, spectrum_count = self._update_replay_spectrum(count)
        self._update_analysis_hydrophone()
        self._update_info_window(data, count, spectrum_index, spectrum_count)
        self._update_acoustic_cards(data)
        self._update_replay_waterfall(count)
        self._update_cursor_for_frame(data)
        self._refresh_chart_popups()
        self.sync_label.setText(
            f"Image {self.frame_index + 1}/{count} | "
            f"Temperature {data.temperature_index + 1 if data.temperature_index is not None else '-'} | "
            f"Spectrum {spectrum_index + 1 if spectrum_index is not None else '-'}/{spectrum_count or '-'}"
        )

    def _update_replay_spectrum(self, replay_count: int):
        selected = self._selected_channels()
        seconds = self._index_to_seconds(self.frame_index, replay_count)
        main_frequency = ((self.current.main_frequency_hz if self.current else None) or
                          (self.package.main_frequency_hz if self.package else None))
        saved_x = self.chart_state.x_ranges.get("spectrum")
        saved_y = self.chart_state.y_ranges.get("spectrum")
        result = self.current_spectrum_renderer.render(
            self.spectrum_plot, self.spectrum_channels, selected,
            self.frame_index, replay_count, self._channel_colors,
            main_frequency, self._map_replay_to_data, seconds,
        )
        self.spectrum_plot.addItem(self.spectrum_hover_text)
        if saved_x is not None:
            self.spectrum_plot.setXRange(*saved_x, padding=0)
        if saved_y is not None:
            self.spectrum_plot.setYRange(*saved_y, padding=0)
        self.spectrum_hover_series = result.series
        first_index = None
        first_count = 0
        statuses = []
        self._spectrum_frame = None
        for channel in selected:
            frames = self.spectrum_channels.get(channel, [])
            if not frames or channel not in result.frame_indices:
                continue
            idx = result.frame_indices[channel]
            statuses.append(f"{channel}:{idx + 1}/{len(frames)}")
            if first_index is None:
                first_index, first_count = idx, len(frames)
                self._spectrum_frame = frames[idx]
        self._spectrum_status = "; ".join(statuses) if statuses else "No SpectrumMsg"
        self.current_spectrum_label.setText(f"Spectrum: {self._spectrum_status}")
        return first_index, first_count

    def _update_analysis_hydrophone(self):
        if not hasattr(self, "analysis_spectrum_plot"):
            return
        self.analysis_spectrum_plot.clear()
        selected = self._selected_channels()
        replay_count = self.current.replay_frame_count if self.current else 1
        colors = ["#00bfff", "#ffcc00", "#ff66cc", "#66ff66", "#ff8844", "#cccccc"]
        stacked = self.hydro_arrangement.currentText() == "Stacked"
        for channel_index, channel in enumerate(selected):
            frames = self.spectrum_channels.get(channel, [])
            if not frames:
                continue
            spectrum_index = self._map_replay_to_data(self.frame_index, replay_count, len(frames))
            frame = frames[spectrum_index]
            x = np.asarray(frame.frequency, float) / 1000.0
            y = np.asarray(frame.amplitude, float)
            if stacked and y.size:
                span = max(1.0, float(np.nanmax(y) - np.nanmin(y)))
                y = y - channel_index * span * 1.2
            self.analysis_spectrum_plot.plot(x, y, pen=pg.mkPen(colors[channel_index % len(colors)], width=1.5))
        self._add_spectrum_reference_lines(self.analysis_spectrum_plot, mhz=False)
        self._update_waterfall()

    def _update_waterfall(self):
        selected = self._selected_channels()
        blocks = []
        max_columns = 0
        x_max = 1.0
        current_row = 0
        row_offset = 0
        replay_count = self.current.replay_frame_count if self.current else 1
        for channel in selected:
            frames = self.spectrum_channels.get(channel, [])
            rows = []
            for frame in frames:
                amplitude = np.asarray(frame.amplitude, float)
                if amplitude.size:
                    rows.append(amplitude)
                    max_columns = max(max_columns, amplitude.size)
                    if frame.frequency:
                        x_max = max(x_max, float(frame.frequency[-1]) / 1000.0)
            if rows:
                if not blocks:
                    current_row = row_offset + self._map_replay_to_data(self.frame_index, replay_count, len(rows))
                blocks.append(rows)
                row_offset += len(rows) + 2
        if not blocks or max_columns == 0:
            self.waterfall_image.setImage(np.empty((0, 0)))
            return
        bands = []
        for rows in blocks:
            padded = np.full((len(rows), max_columns), np.nan)
            for row_index, row in enumerate(rows):
                padded[row_index, : len(row)] = row
            bands.append(padded)
            bands.append(np.full((2, max_columns), np.nan))
        image = np.vstack(bands[:-1])
        finite = image[np.isfinite(image)]
        if finite.size:
            low, high = np.percentile(finite, [2, 98])
            self.waterfall_image.setImage(image, autoLevels=False, levels=(float(low), float(high)))
        else:
            self.waterfall_image.setImage(image)
        self.waterfall_image.setRect(QRectF(0, 0, x_max, image.shape[0]))
        self.waterfall_plot.setYRange(0, image.shape[0], padding=0)
        self.waterfall_cursor.setPos(current_row)

    def _threshold_changed(self, value: int):
        self.threshold_value.setText(f"Red starts at {value} °C")
        self.set_frame(self.frame_index)

    def _overlay_cursor_moved(self, x: float, y: float):
        self.cursor_x, self.cursor_y = x, y
        self._rebuild_cursor_temperature_trend()
        self.set_frame(self.frame_index)

    def _rebuild_cursor_temperature_trend(self):
        self.cursor_temperature_trend = []
        if not self.current or self.cursor_x is None or self.cursor_y is None:
            self.cursor_temperature_curve.setData([], [])
            return
        for i in range(self.current.replay_frame_count):
            try:
                data = self.replay.frame(self.current, i)
                arr = data.temperature
                if arr is None:
                    self.cursor_temperature_trend.append(np.nan); continue
                xi = int(np.clip(round(self.cursor_x), 0, arr.shape[1]-1))
                yi = int(np.clip(round(self.cursor_y), 0, arr.shape[0]-1))
                self.cursor_temperature_trend.append(float(arr[yi, xi]))
            except Exception:
                self.cursor_temperature_trend.append(np.nan)
        self.cursor_temperature_curve.setData(self._frame_time_axis(len(self.cursor_temperature_trend)), np.asarray(self.cursor_temperature_trend,float))

    def _update_cursor_for_frame(self, data):
        arr = data.temperature
        if arr is None:
            self.cursor_temperature_label.setText("Cursor Temperature: --")
            return
        if self.cursor_x is None or self.cursor_y is None:
            self.cursor_temperature_label.setText("Cursor Temperature: click or drag the small cyan target")
            return
        xi = int(np.clip(round(self.cursor_x),0,arr.shape[1]-1)); yi = int(np.clip(round(self.cursor_y),0,arr.shape[0]-1))
        value=float(arr[yi,xi])
        self.overlay.set_cursor(self.cursor_x,self.cursor_y,f"T {value:.1f} °C\nX {xi}  Y {yi}")
        self.cursor_temperature_label.setText(f"Cursor Temperature\nT: {value:.1f} °C\nX: {xi} px\nY: {yi} px")

    def _show_info_window(self):
        self.info_window.show(); self.info_window.raise_(); self.info_window.activateWindow()

    def _update_info_window(self, data, count, spectrum_index, spectrum_count):
        frequency = ((self.current.main_frequency_hz if self.current else None) or (self.package.main_frequency_hz if self.package else 0.0)) / 1_000_000.0
        rows=[
            ("Sonication No.", f"{self.sonication_index+1} / {len(self.package.sonications) if self.package else '-'}"),
            ("Name", self.current.name if self.current else "-"),
            ("Frequency", f"{frequency:.3f} MHz"),
            ("Replay Frame", f"{self.frame_index+1}/{count}"),
            ("Temperature RAW", data.temperature_index+1 if data.temperature_index is not None else "-"),
            ("SpectrumMsg", f"{spectrum_index+1 if spectrum_index is not None else '-'}/{spectrum_count or '-'}"),
            ("Temperature Source", data.temperature_source),
            ("Reference Temperature", f"{data.reference_temperature:.1f} °C"),
            ("ROI Source", data.roi_source),
            ("Max Temperature (ROI)", f"{data.maximum_temperature:.1f} °C" if data.maximum_temperature is not None else "-"),
            ("Average Temperature (ROI)", f"{data.mean_temperature:.1f} °C" if data.mean_temperature is not None else "-"),
            ("Loaded Folder", str(self.package.source_path) if self.package and hasattr(self.package,'source_path') else "-"),
        ]
        self.info_window.update_rows(rows)

    def _update_acoustic_cards(self, data):
        self._ensure_acoustic_curve_items()
        trend = getattr(self, "acoustic_control_trend", None)
        if trend is not None:
            self.acoustic_power_curve.setData(np.asarray(trend.time_s,float), np.asarray(trend.power_percent,float), connect="finite")
            self.acoustic_score_curve.setData(np.asarray(trend.time_s,float), np.asarray(trend.score_percent,float), connect="finite")
        self.acoustic_control_cursor.setPos(self._index_to_seconds(self.frame_index,self.current.replay_frame_count) if self.current else 0)
        if trend is None or self.frame_index >= len(trend.power_percent):
            self.acoustic_power_value.setText("Unavailable")
            self.acoustic_score_value.setText("Unavailable")
            self.acoustic_cavitation_value.setText("Unavailable")
            self.acoustic_power_text.setText("Power: --")
            self.acoustic_score_text.setText("Score: --")
            return
        power = trend.power_percent[self.frame_index]
        score = trend.score_percent[self.frame_index]
        energy = trend.energy[self.frame_index]
        limit = trend.harmless_limit[self.frame_index]
        power_text = f"{power:.1f} %" if np.isfinite(power) else "--"
        score_text = f"{score:.1f} %" if np.isfinite(score) else "--"
        self.acoustic_power_value.setText(power_text)
        self.acoustic_score_value.setText(score_text)
        self.acoustic_power_text.setText(f"Power: {power_text}")
        self.acoustic_score_text.setText(f"Score: {score_text}")
        x_max = self._index_to_seconds(max(0, self.current.replay_frame_count - 1), self.current.replay_frame_count) if self.current else 0.0
        self.acoustic_power_text.setPos(x_max, 106.0)
        self.acoustic_score_text.setPos(x_max, 88.0)
        if np.isfinite(energy) and np.isfinite(limit):
            self.acoustic_cavitation_value.setText(f"{energy:.5f} / {limit:.5f}")
        else:
            self.acoustic_cavitation_value.setText("Unavailable")

    def _update_replay_waterfall(self, replay_count: int):
        """Render the true all-bin Time × Frequency spectrogram.

        Coloured overlay lines are selected channels' current-frame FFT curves,
        not peak-frequency or ridge histories. The popup uses this same renderer.
        """
        selected = self._selected_channels()
        source = "Sonication + CPCFiles" if self.cpc_enabled else "Sonication only"
        result = self.relative_spectrum_renderer.render(
            self.waterfall_replay_plot, self.spectrum_channels, selected,
            self.frame_index, replay_count, self._channel_colors,
            (self.current.main_frequency_hz if self.current else None) or
            (self.package.main_frequency_hz if self.package else None),
            f"Relative Acoustic Spectrum · {source} · {', '.join(selected)}",
        )
        self.waterfall_replay_image = result.image_item

    # ------------------------------------------------------------- Helpers
    def _load_spectrum_channels(self):
        channels = {f"CH{i}": [] for i in range(8)}
        configured = self.sonication_channel_service.read(self.current.folder) if self.current else None
        configured_index = configured.channel if configured and configured.channel is not None else 0
        self._active_spectrum_channel = f"CH{configured_index}"

        son_frames = self.spectrum_provider.load(list(self.current.spectrum_files), source_kind="Sonication")
        for frame in son_frames:
            explicit = self._channel_name(Path(frame.source), default=None)
            channel = explicit if explicit is not None else self._active_spectrum_channel
            frame.channel = int(channel[2:]); channels[channel].append(frame)

        if self.cpc_enabled and self.package is not None:
            cpc_frames = self.spectrum_provider.load(list(self.package.cpc_spectrum_files), source_kind="CPCFiles")
            for i, frame in enumerate(cpc_frames):
                explicit = self._channel_name(Path(frame.source), default=None)
                channel = explicit if explicit is not None else f"CH{i % 8}"
                frame.channel = int(channel[2:]); channels[channel].append(frame)

        self.spectrum_channels = channels
        self._rebuild_channel_controls()

    def _rebuild_channel_controls(self):
        previous = set(self.chart_state.selected_channels)
        for action in self.channel_actions.values():
            self.channel_menu.removeAction(action); action.deleteLater()
        self.channel_actions.clear()
        if not self.chart_state.user_selected_channels:
            previous = {self._active_spectrum_channel}
            self.chart_state.selected_channels = set(previous)
        for name in [f"CH{i}" for i in range(8)]:
            action = QAction(name, self.channel_menu)
            action.setCheckable(True); action.setChecked(name in previous)
            action.toggled.connect(self._channel_selection_changed)
            self.channel_actions[name] = action; self.channel_menu.addAction(action)
        self.all_channels_action.blockSignals(True)
        self.all_channels_action.setChecked(len(previous) == 8)
        self.all_channels_action.blockSignals(False)
        self._update_channel_button_text()

    def _cpc_toggled(self, checked: bool):
        self.cpc_enabled = bool(checked); self.chart_state.cpc_enabled = self.cpc_enabled
        self.cpc_button.setText("CPC ON" if checked else "CPC OFF")
        if self.current is not None:
            self._load_spectrum_channels(); self.set_frame(self.frame_index)
        count = len(self.package.cpc_spectrum_files) if self.package is not None else 0
        self.statusBar().showMessage(f"CPCFiles {'enabled' if checked else 'disabled'} ({count} candidate DMP file(s))")

    def _toggle_all_channels(self, checked: bool):
        self.chart_state.user_selected_channels = True
        for action in self.channel_actions.values():
            action.blockSignals(True); action.setChecked(checked); action.blockSignals(False)
        self.chart_state.selected_channels = set(self.channel_actions) if checked else set()
        self._update_channel_button_text(); self.set_frame(self.frame_index)

    def _channel_selection_changed(self):
        self.chart_state.user_selected_channels = True
        selected={name for name,action in self.channel_actions.items() if action.isChecked()}
        self.chart_state.selected_channels=set(selected)
        self.all_channels_action.blockSignals(True)
        self.all_channels_action.setChecked(len(selected)==len(self.channel_actions) and bool(selected))
        self.all_channels_action.blockSignals(False)
        self._update_channel_button_text(); self.set_frame(self.frame_index)

    def _update_channel_button_text(self):
        selected = [name for name, action in self.channel_actions.items() if action.isChecked()]
        if selected and len(selected) == len(self.channel_actions): self.channel_button.setText("CH: All")
        elif len(selected) == 1: self.channel_button.setText(f"CH: {selected[0]}")
        elif selected: self.channel_button.setText(f"CH: {len(selected)}")
        else: self.channel_button.setText("CH: None")

    def _selected_channels(self):
        selected = [name for name, action in self.channel_actions.items() if action.isChecked()]
        return selected or [self._active_spectrum_channel]

    def _hydro_layout_changed(self):
        mode = self.hydro_view.currentText()
        self.analysis_spectrum_plot.setVisible(mode in ("Both", "Spectrum"))
        self.waterfall_plot.setVisible(mode in ("Both", "Waterfall"))
        if mode == "Spectrum":
            self.hydro_splitter.setSizes([1000, 0])
        elif mode == "Waterfall":
            self.hydro_splitter.setSizes([0, 1000])
        else:
            self.hydro_splitter.setSizes([600, 600])
        self._update_analysis_hydrophone()

    def _update_parameter_table(self, data, count: int, spectrum_index, spectrum_count):
        frequency_mhz = ((self.current.main_frequency_hz if self.current else None) or self.package.main_frequency_hz) / 1_000_000.0
        rows = [
            ("Energy", "From ACT when available", "Sonication", self.current.name),
            ("Power", "From ACT when available", "Replay Frame", f"{self.frame_index + 1}/{count}"),
            ("Duration", f"{self._index_to_seconds(count - 1, count):.1f} sec", "Temperature RAW", f"{data.temperature_index + 1 if data.temperature_index is not None else '-'}"),
            ("Frequency", f"{frequency_mhz:.3f} MHz", "SpectrumMsg", f"{spectrum_index + 1 if spectrum_index is not None else '-'}/{spectrum_count or '-'}"),
            ("Temperature Source", data.temperature_source, "Max Temperature (ROI)", f"{data.maximum_temperature:.1f} °C" if data.maximum_temperature is not None else "-"),
            ("Reference Temperature", f"{data.reference_temperature:.1f} °C", "Average Temperature (ROI)", f"{data.mean_temperature:.1f} °C" if data.mean_temperature is not None else "-"),
            ("ROI Source", data.roi_source, "Max ΔTemperature", f"{data.maximum_delta_temperature:.1f} °C" if data.maximum_delta_temperature is not None else "-"),
        ]
        self.parameter_table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            for column_index, value in enumerate(row):
                self.parameter_table.setItem(row_index, column_index, QTableWidgetItem(str(value)))

    def _add_spectrum_reference_lines(self, plot, mhz: bool):
        if not self.package:
            return
        divisor = 1_000_000.0 if mhz else 1000.0
        main = self.package.main_frequency_hz / divisor
        for frequency, label in ((main / 2, "Sub"), (main, "Main"), (main * 2, "2nd"), (main * 3, "3rd")):
            plot.addItem(pg.InfiniteLine(pos=frequency, angle=90, movable=False, label=label))

    def _current_temperature_range(self):
        levels=self._temperature_levels(None)
        return levels if levels is not None else (40.0,60.0)

    def _temperature_range_changed(self, _index):
        lo,hi=self._current_temperature_range()
        self.temperature_plot.setYRange(lo,hi,padding=0)
        self.settings.setValue("temperature_range", self.range_combo.currentText())
        self.set_frame(self.frame_index)

    def _capture_overlay_state_debounced(self):
        if hasattr(self,"_overlay_save_timer"):
            self._overlay_save_timer.start(120)

    def _save_overlay_state(self):
        if hasattr(self,"overlay") and self._restore_overlay_session:
            self._overlay_session_view = self.overlay.view_range()

    def _capture_overlay_levels(self, low, high):
        if self._restore_overlay_session:
            self._overlay_session_levels = (float(low), float(high))

    @staticmethod
    def _amplitude_db(values):
        amplitude=np.abs(np.nan_to_num(np.asarray(values,float),nan=0.0,posinf=0.0,neginf=0.0))
        if amplitude.size == 0:
            return amplitude
        reference=max(float(np.nanmax(amplitude)),1e-30)
        return np.clip(20.0*np.log10(np.maximum(amplitude,reference*1e-5)/reference),-100.0,0.0)

    @staticmethod
    def _relative_spectrum(values):
        """Scale one spectrum onto the workstation-like 0..4 relative axis."""
        amplitude = np.abs(np.nan_to_num(np.asarray(values, float), nan=0.0, posinf=0.0, neginf=0.0))
        if amplitude.size == 0:
            return amplitude
        baseline = float(np.percentile(amplitude, 10))
        signal = np.maximum(amplitude - baseline, 0.0)
        reference = float(np.percentile(signal, 99.5))
        if not np.isfinite(reference) or reference <= 1e-30:
            reference = max(float(np.nanmax(signal)), 1e-30)
        normalized = signal / reference
        # Keep quiet frames slightly above zero so the noise floor is visible,
        # while cavitation peaks retain enough headroom to stand out clearly.
        return np.clip(0.08 + normalized * 7.2, 0.0, 8.0)

    def _temperature_lut_with_red_threshold(self, low: float, high: float):
        """Keep all temperature colors visible and move the red transition only."""
        low, high = float(low), float(high)
        if high <= low:
            high = low + 1.0
        red = float(np.clip(self.threshold_slider.value(), low, high))
        split = float(np.clip((red - low) / (high - low), 0.02, 0.98))
        positions = np.asarray([0.0, max(0.0, split * 0.55), max(0.0, split * 0.85), split, 1.0], float)
        positions = np.maximum.accumulate(positions)
        colors = np.asarray([
            (0, 0, 0, 0),
            (255, 235, 45, 180),
            (255, 145, 20, 215),
            (255, 0, 0, 240),
            (255, 0, 0, 255),
        ], dtype=np.ubyte)
        cmap = pg.ColorMap(positions, colors)
        return cmap.getLookupTable(0.0, 1.0, 256)

    def _temperature_mode_changed(self, text: str):
        self.temperature_display_mode = text
        self.range_combo.setEnabled(not text.startswith("Δ"))
        self.threshold_slider.setEnabled(not text.startswith("Δ"))
        self.set_frame(self.frame_index)

    def _temperature_levels(self, temperature):
        index = self.range_combo.currentIndex()
        if index == 0:
            return 40.0, 60.0
        if index == 1:
            return 35.0, 60.0
        if index == 2:
            return 30.0, 90.0
        if index == 3:
            return 0.0, 60.0
        finite = temperature[np.isfinite(temperature)] if temperature is not None else np.array([])
        if not finite.size:
            return None
        lo, hi = np.percentile(finite, [1, 99.5])
        return float(lo), max(float(lo) + 1.0, float(hi))

    def _delta_levels(self, delta):
        finite = delta[np.isfinite(delta)] if delta is not None else np.array([])
        return (0.0, max(1.0, float(np.percentile(finite, 99)))) if finite.size else None

    @staticmethod
    def _channel_name(path: Path, default: str | None = "CH0") -> str | None:
        text = f"{path.parent.name}_{path.stem}"
        for pattern in (r"(?:^|[_\- ])(?:CH|HP)[_\- ]?(\d+)", r"hydrophone[_\- ]?(\d+)"):
            match = re.search(pattern, text, re.I)
            if match:
                return f"CH{int(match.group(1))}"
        return default

    @staticmethod
    def _map_replay_to_data(index: int, replay_count: int, data_count: int) -> int:
        """Map one replay position to another stream with endpoint-safe ratio.

        This is the explicit fallback when timestamps are absent. It guarantees
        frame movement changes Spectrum/Waterfall position instead of leaving a
        static first record.
        """
        if data_count <= 1 or replay_count <= 1:
            return 0
        ratio = index / float(replay_count - 1)
        return max(0, min(data_count - 1, int(round(ratio * (data_count - 1)))))

    @staticmethod
    def _index_to_seconds(index: int, count: int) -> float:
        # 4 s is the typical thermometry cadence; actual timestamp integration
        # remains isolated for the next data-validation commit.
        return max(0.0, float(index) * 4.0)

    def _frame_time_axis(self, count: int):
        return np.asarray([self._index_to_seconds(index, count) for index in range(count)], float)

    @staticmethod
    def _array_icon(array):
        if array is None:
            return QIcon()
        values = np.nan_to_num(np.asarray(array, float))
        low, high = np.percentile(values, [2, 98]) if values.size else (0, 1)
        if high <= low:
            high = low + 1
        gray = np.clip((values - low) / (high - low) * 255, 0, 255).astype(np.uint8)
        rgb = np.stack([gray, gray, gray], axis=2)
        height, width = rgb.shape[:2]
        image = QImage(rgb.data, width, height, 3 * width, QImage.Format.Format_RGB888).copy()
        return QIcon(QPixmap.fromImage(image).scaled(110, 100, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    def _open_chart_popup(self,key: str):
        popup=ChartPopup({"temperature":"Temperature Trend (ROI)","spectrum":"Acoustic Spectrum","acoustic":"Power % / Score","waterfall":"Relative Acoustic Spectrum vs Replay Time"}.get(key,key),self)
        if not hasattr(self,"_chart_popups"): self._chart_popups=[]
        popup.chart_key=key; self._chart_popups.append(popup)
        self._render_chart_popup(popup)
        popup.show(); popup.raise_()

    def _render_chart_popup(self,popup):
        key=getattr(popup,"chart_key",""); plot=popup.plot; plot.clear(); popup.hover_text=pg.TextItem(anchor=(0,1),color="#ffffff",fill=pg.mkBrush(0,0,0,210)); popup.hover_text.setZValue(100); popup.hover_text.hide(); plot.addItem(popup.hover_text)
        popup.hover_series=[]
        if key=="temperature":
            x=self._frame_time_axis(len(self.max_temperature_trend)); lo,hi=self._current_temperature_range(); plot.setYRange(lo,hi,padding=0); plot.setLabel("left","Temperature",units="°C"); plot.setLabel("bottom","Replay time",units="sec")
            plot.plot(x,self.max_temperature_trend,pen=pg.mkPen("#ff3b30",width=3)); plot.plot(x,self.mean_temperature_trend,pen=pg.mkPen("#49e36b",width=2.5))
            if self.cursor_temperature_trend: plot.plot(x,self.cursor_temperature_trend,pen=pg.mkPen("#b98cff",width=1.6,style=Qt.PenStyle.DashLine))
            plot.addLine(x=self._index_to_seconds(self.frame_index,len(x)),pen=pg.mkPen("#00bfff",width=1.3))
            popup.set_hover_series([("Max",x,self.max_temperature_trend," °C"),("ROI Avg",x,self.mean_temperature_trend," °C"),("Cursor",x,self.cursor_temperature_trend," °C")])
        elif key=="acoustic":
            trend=getattr(self,"acoustic_control_trend",None); plot.setYRange(0,110,padding=0); plot.setLabel("left","Power / Score",units="%"); plot.setLabel("bottom","Replay time",units="sec")
            if trend is not None:
                plot.plot(trend.time_s,trend.power_percent,pen=pg.mkPen("#58f26a",width=2.5),connect="finite"); plot.plot(trend.time_s,trend.score_percent,pen=pg.mkPen("#ff9d22",width=2.5),connect="finite"); plot.addLine(x=self._index_to_seconds(self.frame_index,self.current.replay_frame_count),pen=pg.mkPen("#00bfff",width=1.3))
                popup.set_hover_series([("Power",trend.time_s,trend.power_percent," %"),("Score",trend.time_s,trend.score_percent," %")])
        elif key=="spectrum":
            selected=self._selected_channels()
            replay_count=self.current.replay_frame_count if self.current else 1
            main_frequency=((self.current.main_frequency_hz if self.current else None) or
                            (self.package.main_frequency_hz if self.package else None))
            result=self.current_spectrum_renderer.render(
                plot, self.spectrum_channels, selected, self.frame_index,
                replay_count, self._channel_colors, main_frequency,
                self._map_replay_to_data,
                self._index_to_seconds(self.frame_index,replay_count),
            )
            plot.addItem(popup.hover_text)
            saved_x=self.chart_state.x_ranges.get("spectrum")
            saved_y=self.chart_state.y_ranges.get("spectrum")
            if saved_x is not None: plot.setXRange(*saved_x,padding=0)
            if saved_y is not None: plot.setYRange(*saved_y,padding=0)
            popup.set_hover_series(result.series)
        elif key=="waterfall":
            self._render_waterfall_popup(plot)

    def _render_waterfall_popup(self,plot):
        selected=self._selected_channels()
        source="Sonication + CPCFiles" if self.cpc_enabled else "Sonication only"
        self.relative_spectrum_renderer.render(
            plot, self.spectrum_channels, selected, self.frame_index,
            self.current.replay_frame_count if self.current else 1,
            self._channel_colors,
            (self.current.main_frequency_hz if self.current else None) or
            (self.package.main_frequency_hz if self.package else None),
            f"Relative Acoustic Spectrum · {source} · {', '.join(selected)}",
        )

    def _refresh_chart_popups(self):
        for popup in list(getattr(self,"_chart_popups",[])):
            if popup.isVisible(): self._render_chart_popup(popup)

    # -------------------------------------------------------------- Controls
    def _remember_chart_range(self, key: str, plot) -> None:
        try:
            x_range, y_range = plot.plotItem.vb.viewRange()
            self.chart_state.remember_range(key, x_range, y_range)
        except Exception:
            return

    def _spectrum_plot_hovered(self, event):
        scene_pos = event[0] if isinstance(event, (tuple, list)) else event
        if not self.spectrum_hover_series or not self.spectrum_plot.sceneBoundingRect().contains(scene_pos):
            self.spectrum_hover_text.hide(); return
        point = self.spectrum_plot.plotItem.vb.mapSceneToView(scene_pos)
        lines = [f"Frequency: {point.x():.4f} MHz"]
        best_y = None
        for label, x_values, y_values, _unit in self.spectrum_hover_series:
            x=np.asarray(x_values,float); y=np.asarray(y_values,float)
            valid=np.isfinite(x)&np.isfinite(y)
            if not valid.any(): continue
            xv=x[valid]; yv=y[valid]; i=int(np.argmin(np.abs(xv-point.x())))
            value=float(yv[i]); lines.append(f"{label}: {value:.3f}")
            if best_y is None: best_y=value
        if best_y is None:
            self.spectrum_hover_text.hide(); return
        self.spectrum_hover_text.setText("\n".join(lines))
        self.spectrum_hover_text.setPos(point.x(), best_y)
        self.spectrum_hover_text.show()

    def _acoustic_plot_hovered(self, event):
        scene_pos=event[0] if isinstance(event,(tuple,list)) else event
        trend=getattr(self,"acoustic_control_trend",None)
        if trend is None or not self.acoustic_control_plot.sceneBoundingRect().contains(scene_pos):
            self.acoustic_hover_text.hide(); return
        point=self.acoustic_control_plot.plotItem.vb.mapSceneToView(scene_pos)
        x=np.asarray(trend.time_s,float)
        if not x.size: self.acoustic_hover_text.hide(); return
        i=int(np.argmin(np.abs(x-point.x())))
        lines=[f"{x[i]:.2f} sec"]
        if i < len(trend.power_percent) and np.isfinite(trend.power_percent[i]): lines.append(f"Power: {trend.power_percent[i]:.1f} %")
        if i < len(trend.score_percent) and np.isfinite(trend.score_percent[i]): lines.append(f"Score: {trend.score_percent[i]:.1f} %")
        self.acoustic_hover_text.setText("\n".join(lines)); self.acoustic_hover_text.setPos(point.x(),point.y()); self.acoustic_hover_text.show()

    def _temperature_plot_clicked(self, event):
        if not self.current:
            return
        point = self.temperature_plot.plotItem.vb.mapSceneToView(event.scenePos())
        self.set_frame(int(round(point.x() / 4.0)))

    def _temperature_plot_hovered(self, event):
        if not self.current or not self.max_temperature_trend:
            self.temperature_hover_text.hide(); return
        scene_pos = event[0] if isinstance(event, (tuple, list)) else event
        if not self.temperature_plot.sceneBoundingRect().contains(scene_pos):
            self.temperature_hover_text.hide(); return
        point = self.temperature_plot.plotItem.vb.mapSceneToView(scene_pos)
        index = int(np.clip(round(point.x() / 4.0), 0, len(self.max_temperature_trend)-1))
        max_t = self.max_temperature_trend[index]
        avg_t = self.mean_temperature_trend[index] if index < len(self.mean_temperature_trend) else np.nan
        cursor_t = self.cursor_temperature_trend[index] if index < len(self.cursor_temperature_trend) else np.nan
        lines = [f"{self._index_to_seconds(index, len(self.max_temperature_trend)):.1f} sec"]
        if np.isfinite(max_t): lines.append(f"Max {max_t:.1f} °C")
        if np.isfinite(avg_t): lines.append(f"Avg {avg_t:.1f} °C")
        if np.isfinite(cursor_t): lines.append(f"Cursor {cursor_t:.1f} °C")
        self.temperature_hover_text.setText("\n".join(lines))
        self.temperature_hover_text.setPos(point.x(), point.y())
        self.temperature_hover_text.show()

    def _acoustic_plot_clicked(self, event):
        if not self.current:
            return
        point = self.acoustic_control_plot.plotItem.vb.mapSceneToView(event.scenePos())
        self.set_frame(int(round(point.x() / 4.0)))

    def slider_changed(self, value):
        self.set_frame(value)

    def previous_frame(self):
        self.set_frame(max(0, self.frame_index - 1))

    def next_frame(self):
        if not self.current:
            return
        next_index = self.frame_index + 1
        if next_index >= self.current.replay_frame_count:
            next_index = 0 if self.timer.isActive() else self.current.replay_frame_count - 1
        self.set_frame(next_index)

    def toggle_play(self):
        if self.timer.isActive():
            self.timer.stop()
            self.play_btn.setText("▶")
        else:
            self.timer.start(max(20, int(1000 / self.speed.value())))
            self.play_btn.setText("Ⅱ")

    def speed_changed(self, value):
        if self.timer.isActive():
            self.timer.start(max(20, int(1000 / value)))

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Left:
            self.previous_frame()
            return
        if event.key() == Qt.Key.Key_Right:
            self.next_frame()
            return
        if event.key() == Qt.Key.Key_Space:
            self.toggle_play()
            return
        super().keyPressEvent(event)

    def wheelEvent(self, event):
        if self.current:
            self.set_frame(self.frame_index + (1 if event.angleDelta().y() < 0 else -1))
            event.accept()
            return
        super().wheelEvent(event)

    def dragEnterEvent(self, event):
        if any(url.isLocalFile() for url in event.mimeData().urls()):
            event.acceptProposedAction()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            if url.isLocalFile():
                path = Path(url.toLocalFile())
                if path.is_dir() or path.suffix.lower() == ".zip":
                    self.load(path)
                    event.acceptProposedAction()
                    break

    def _restore(self):
        try:
            geometry = self.settings.value("geometry")
            if geometry:
                self.restoreGeometry(geometry)
            for key, splitter in (("top_split", getattr(self,"top_split",None)),("graph_split",getattr(self,"graph_split",None)),("lower_split",getattr(self,"lower_split",None))):
                state=self.settings.value(key)
                if state and splitter is not None: splitter.restoreState(state)
            saved_range=self.settings.value("temperature_range", "40–60 °C")
            self.chart_state.cpc_enabled = str(self.settings.value("chart/cpc_enabled", "false")).lower() == "true"
            self.cpc_enabled = self.chart_state.cpc_enabled
            saved_channels = self.settings.value("chart/selected_channels", []) or []
            if isinstance(saved_channels, str): saved_channels=[saved_channels]
            self.chart_state.selected_channels=set(map(str,saved_channels))
            self.chart_state.user_selected_channels=bool(saved_channels)
            self.cpc_button.blockSignals(True); self.cpc_button.setChecked(self.cpc_enabled); self.cpc_button.setText("CPC ON" if self.cpc_enabled else "CPC OFF"); self.cpc_button.blockSignals(False)
            idx=self.range_combo.findText(str(saved_range)); self.range_combo.setCurrentIndex(idx if idx>=0 else 0)
        except Exception:
            pass

    def closeEvent(self, event):
        self.settings.setValue("geometry", self.saveGeometry())
        for key, splitter in (("top_split", getattr(self,"top_split",None)),("graph_split",getattr(self,"graph_split",None)),("lower_split",getattr(self,"lower_split",None))):
            if splitter is not None: self.settings.setValue(key, splitter.saveState())
        self.settings.setValue("chart/cpc_enabled", self.cpc_enabled)
        self.settings.setValue("chart/selected_channels", sorted(self.chart_state.selected_channels))
        super().closeEvent(event)
