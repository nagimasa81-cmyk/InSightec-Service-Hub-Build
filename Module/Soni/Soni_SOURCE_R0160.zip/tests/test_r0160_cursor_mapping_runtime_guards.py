from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HYDRO = (ROOT / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')


def _method_block(name: str) -> str:
    marker = f'    def {name}'
    block = HYDRO.split(marker, 1)[1]
    return block.split('\n    def ', 1)[0]


def test_current_control_time_keeps_cycle_and_cycles_definitions_after_physical_mapping():
    block = _method_block('_current_control_time')
    assert 'self.replay.frames[self._physical_frame_index()]' in block
    assert 'cycle=getattr(frame,"acquisition_cycle",None)' in block
    assert 'cycles=np.asarray(getattr(timeline,"actual_power_cycles"' in block
    assert 'if cycle is not None and cycles.size' in block


def test_observed_timeline_highlight_keeps_cycle_definition_after_physical_mapping():
    block = _method_block('_load_observed_cavitation_timeline')
    assert 'self.replay.frames[self._physical_frame_index()]' in block
    assert 'cycle = getattr(frame, "acquisition_cycle", None)' in block
    assert 'if cycle is not None:' in block


def test_cursor_to_physical_mapping_remains_time_based():
    block = _method_block('_physical_frame_index')
    assert 'mr_frame_times_s' in block
    assert 'np.argmin' in block
    assert 'st[self.frame_index]' in block
