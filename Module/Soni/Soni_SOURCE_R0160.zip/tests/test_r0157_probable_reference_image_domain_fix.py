from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HYDRO = (ROOT / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')


def _probable_reference_image_block() -> str:
    return HYDRO.split('def _probable_reference_image', 1)[1].split('\n\n    def ', 1)[0]


def test_target_domain_tracks_which_replay_target_frame_was_indexed_against():
    """Regression guard: _probable_reference_image() picks target_frame from
    up to three different sources, each indexed against a *different*
    replay:
      - default: self.frame_index, a cursor/composite-domain index (see
        R0156 -- _cursor_frame_count() prefers _spectral_replay())
      - the 'observed cavitation event' branch: _frame_by_cycle(self.replay,
        ...) returns a *physical*-domain index
      - the 'cavitation_analysis.events' branch: snapshot_index is indexed
        against analysis_replay = spectral or physical (see
        SpectrumEvidenceRepository's composite-Brain220 comment), i.e. the
        spectral/aggregate replay

    The old code always looked up self.replay.mr_frame_times_s (physical)
    regardless of which domain target_frame actually came from. On a
    220/230 kHz composite Sonication (physical replay far shorter than the
    spectral one), any cavitation-analysis event past the physical replay's
    short frame count fell through to a ratio-based fallback that also
    divided by the physical frame count -- producing a wildly out-of-range
    index instead of a real one.
    """
    block = _probable_reference_image_block()
    assert 'target_domain_replay = self._spectral_replay()' in block
    assert 'target_domain_replay = self.replay' in block
    assert 'times = np.asarray(getattr(target_domain_replay, "mr_frame_times_s", []), float)' in block
    assert 'denominator = max(1, len(getattr(target_domain_replay, "frames", []) or []) - 1)' in block
    # The old, domain-blind lookups must be gone.
    assert 'times = np.asarray(getattr(self.replay, "mr_frame_times_s", []), float)' not in block
    assert 'len(self.replay.frames)-1' not in block


def test_observed_event_branch_uses_physical_domain_matching_frame_by_cycle():
    """_frame_by_cycle(self.replay, ...) indexes into self.replay.frames
    (physical), so the branch that uses it must keep target_domain_replay
    pinned to self.replay, not silently fall back to the spectral default."""
    block = _probable_reference_image_block()
    observed_branch = block.split('if observed is not None:', 1)[1].split('else:', 1)[0]
    assert 'target_domain_replay = self.replay' in observed_branch
