# R0160 — Integrate R0159 cursor-domain fix and repair two introduced runtime regressions

R0159 correctly identified that Spectrum cursor indices must not be used directly as physical CPC frame indices on composite 220/230 kHz Sonications. The shared `_physical_frame_index()` time-based mapping is retained at all five R0159 call sites.

During comparison against the clean R0157a baseline, two replacement regressions were found in R0159:

1. `_current_control_time()` changed the frame lookup but accidentally removed both `cycle` and `cycles` assignments while still referencing them.
2. `_load_observed_cavitation_timeline()` changed the frame lookup but accidentally removed the `cycle` assignment while still referencing it.

Those would raise `NameError` when the corresponding control/cavitation timeline paths execute. R0160 restores the required assignments while keeping the R0159 time-based physical-frame mapping.

A new regression test checks not only that stale direct indexing is absent, but also that the dependent cycle variables remain defined at the modified call sites.

## Additional integration repair
The existing R0116zzg9 self-healing Analyzer path had also been partially disconnected: `_analyzer_tab_changed()` only published cache and never scheduled `_ensure_current_tab_materialized()`, R0160 reconnects the missing scheduling of `_ensure_current_tab_materialized()` so visible primary/cached content is republished after a tab change. It intentionally does **not** make a cache miss start secondary decoding: loaded Exports retain the newer single-owner preload rule, preventing tab navigation from starting duplicate data I/O. The older R0116zzg9 test expecting a tab-driven secondary queue is therefore superseded by the later R0154aj ownership contract.
