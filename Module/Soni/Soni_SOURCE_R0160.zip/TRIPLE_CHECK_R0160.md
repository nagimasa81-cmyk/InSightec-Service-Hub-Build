# R0160 Triple Check

1. Baseline comparison: R0159 differs from clean R0157a only in version/build metadata, two commit notes, one new regression test, and `src/ui/hydrophone_window.py` cursor-domain changes. No duplicate nested source tree is present.
2. Logic audit: all physical-frame reads driven by the Spectrum cursor use `_physical_frame_index()` where domain conversion is required. Physical-only cube iteration remains intentionally unchanged.
3. Runtime-regression audit: restored `cycle` / `cycles` definitions accidentally deleted in R0159; added dedicated guards so a future textual replacement cannot silently recreate the NameError.

## Test-status note
- Focused integration/regression set: 21 passed.
- `verify_source.py`: PASS.
- Full historical suite is not a clean release gate in this Linux sandbox: two GUI tests cannot collect because PySide6/pyqtgraph are absent, and several older static-contract tests conflict with later single-owner/data-completion architecture. In particular, R0116zzg9 expects tab navigation to queue secondary analysis, while the newer R0154aj contract explicitly forbids loaded-Export tab navigation from starting secondary data I/O. R0160 follows the newer R0154aj ownership rule.
