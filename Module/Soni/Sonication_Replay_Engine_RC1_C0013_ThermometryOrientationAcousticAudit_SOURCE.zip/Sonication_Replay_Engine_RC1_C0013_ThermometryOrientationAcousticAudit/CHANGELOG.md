# CHANGELOG

## C0013 ThermometryOrientationAcousticAudit
- Default temperature range changed to 40–60 °C.
- Temperature chart Y axis follows the selected temperature range.
- Main image uses the MR Image Explorer raster convention (ViewBox invertY true; row 0 at top).
- Main image zoom/pan and magnitude WL/WW are persisted continuously.
- Target ROI changed to 50 mm × 50 mm (pixel-spacing conversion remains explicitly pending).
- Acoustic Spectrum and Waterfall are limited to 200–800 kHz.
- Waterfall now displays frequency versus replay time with amplitude encoded by color.
- Removed fabricated Power%/Score derivation from spectrum amplitude/confidence. Current Sonication folder ACT contains element amplitude/phase only; validated time-series Power% and Score sources were not found, so the chart is marked unavailable.
