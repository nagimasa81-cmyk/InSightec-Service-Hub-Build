# R0154ae

## DQA series alignment contract corrected

DQA is a fixed-XD mechanical alignment series. The Summary now owns one series-common result:

- X/Y: fixed natural focus minus the phantom centre recovered from the DQA-Axial stack.
- Z: fixed natural focus minus the lower phantom baseline recovered from the DQA-Sagittal stack.
- Tilt: DQA-Sagittal lower-baseline angle, with image horizontal = 0 degrees.

The fixed natural focus is taken only from a workstation-proven default-centre steering shot. Individual electronically steered DQA shots are not averaged as if the XD moved.

For real export 42110 the default-centre shot is S2 (steering 0,0,150), giving series alignment approximately X -2.31 mm, Y -1.07 mm, Z +3.80 mm, Tilt -0.66 degrees.

## Thermometry evidence separation

Thermal hotspot evidence is no longer the zero-point of the mechanical DQA series result. It remains an independent evidence stream. Named MR series must positively identify thermometry (TMAP/MEMP/THERM/TEMPERATURE) before temperature values are accepted. DQA-Axial, DQA-Sagittal, DQA-Coronal, Brn-NFUSCAL1, and T2*/T2_Star series are explicitly non-thermometry even if their numeric values happen to overlap a temperature-like range.

This prevents T2*/magnitude/calibration images from becoming false temperature maps and prevents missing thermometry from deleting a valid phantom-geometry DQA alignment.

## Umbrella

Retains R0154ad single-axis screen conversion fix; no additional Z inversion was introduced.
