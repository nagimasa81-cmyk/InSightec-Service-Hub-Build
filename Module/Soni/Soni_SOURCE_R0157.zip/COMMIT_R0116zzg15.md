# R0116zzg15 — Workstation-style MR main-image annotations

- Adds persistent main-image anatomical edge direction labels derived from exported RAS direction cosines.
- Adds image-center RAS position derived from MriImageParams top-left coordinate, pixel spacing, matrix size and row/column direction cosines.
- Adds current MR acquisition time to the image overlay and updates it on every Replay frame.
- Adds MR protocol/series, TR, TE and variable bandwidth to the main image overlay.
- Uses cached Sonication metadata only during frame rendering; detailed metadata remains background-owned and never performs synchronous file I/O on Replay.
- Annotation overlay is independent from magnitude/temperature/registration LUT state and survives WW/WL, red-threshold and Replay refreshes.
