# R0116zzx Regression / Real-Data Revalidation

## Automated regression

- Non-PySide6 suite: **659 passed**.
- Dedicated `test_r0116zzx_visual_cavitation_consistency.py`: **10 passed**.
- `verify_source.py`: **VERIFY_SOURCE_OK**.
- `compileall`: **PASS**.
- Duplicate class methods: **0**.
- Production `QApplication.processEvents()`: **0**.
- Production `.wait(`: **0**.
- Production `.terminate(`: **0**.

The known PySide6-dependent circular-ROI GUI collection remains unavailable in this Linux validation environment.

## 10-00-09_ANx real export

This is the export matching the values visible in the user's Sonication Summary screenshot. The recomposition recovered S1 = 429.8 W / 11.47 s / 4536.2 J, S3 = 962.2 W / 24.58 s / 21070.4 J, S7 = 885.1 W / 30.94 s / 20869.7 J, S8 = 875.0 W / 52.00 s / 32126.0 J.

| Son | Power W | Duration s | Energy J | Delivered %* | Peak °C | ΔT °C | Obs | Vendor triggers | Canonical |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---|
| 1 | 429.8 | 11.47 | 4536.2 | 100.0 | 44.4 | 7.4 | 0 | 0 | No confirmed |
| 2 | 429.8 | 11.47 | 4536.7 | 100.0 | 40.6 | 3.6 | 0 | 0 | No confirmed |
| 3 | 962.2 | 24.58 | 21070.4 | 100.0 | 50.8 | 13.8 | 0 | 966 | Detected |
| 4 | 729.2 | 5.25 | 2167.4 | 5.9 | 39.8 | 2.8 | 0 | 150 | Detected |
| 5 | 437.6 | 6.86 | 2644.0 | 7.2 | 38.5 | 1.5 | 0 | 515 | Detected |
| 6 | 482.3 | 5.89 | 2338.7 | 6.4 | 40.9 | 3.9 | 0 | 545 | Detected |
| 7 | 885.1 | 30.94 | 20869.7 | 57.1 | 50.7 | 13.7 | 0 | 1416 | Detected |
| 8 | 875.0 | 52.00 | 32126.0 | 87.9 | 49.6 | 12.6 | 0 | 1924 | Detected |

`*` Display is capped at 100%; raw measured/planned ratio is retained only in the validation JSON.

Key consistency result: Sonication 3 and Sonications 4–8 contain confirmed Vendor Rule Triggers, so Summary must not display `No cavitation-control event` for those sonications.

## 4231-2026-08-13-11-17-24 real export

All 13 sonications were recomposed independently. The second dataset also contains confirmed vendor-rule evidence, demonstrating that the Summary/CI unification is not specific to one export.

| Son | Power W | Duration s | Energy J | Delivered %* | Peak °C | ΔT °C | Obs | Vendor triggers | Canonical |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---|
| 1 | 202.7 | 14.01 | 1933.3 | 96.7 | 44.3 | 7.3 | 0 | 39 | Detected |
| 2 | 256.5 | 13.96 | 3005.0 | 100.0 | 48.8 | 11.8 | 0 | 27 | Detected |
| 3 | 256.6 | 12.86 | 3021.0 | 100.0 | 45.7 | 8.7 | 0 | 5 | Detected |
| 4 | 303.6 | 12.97 | 3609.9 | 100.0 | 49.2 | 12.2 | 0 | 9 | Detected |
| 5 | 357.2 | 16.55 | 5578.3 | 100.0 | 52.6 | 15.6 | 0 | 29 | Detected |
| 6 | 455.1 | 16.74 | 7206.7 | 100.0 | 53.8 | 16.8 | 0 | 2 | Detected |
| 7 | 563.7 | 16.65 | 8875.2 | 100.0 | 58.2 | 21.2 | 0 | 1 | Detected |
| 8 | 612.4 | 16.65 | 9632.1 | 100.0 | 54.4 | 17.4 | 0 | 1 | Detected |
| 9 | 814.6 | 16.66 | 12825.2 | 100.0 | 57.6 | 20.6 | 0 | 38 | Detected |
| 10 | 967.2 | 19.63 | 18082.5 | 100.0 | 61.0 | 24.0 | 0 | 66 | Detected |
| 11 | 573.3 | 16.36 | 8854.8 | 100.0 | 51.5 | 14.5 | 0 | 43 | Detected |
| 12 | 771.3 | 16.47 | 11989.6 | 100.0 | 53.6 | 16.6 | 0 | 10 | Detected |
| 13 | 983.4 | 16.46 | 15279.3 | 100.0 | 54.8 | 17.8 | 0 | 13 | Detected |
