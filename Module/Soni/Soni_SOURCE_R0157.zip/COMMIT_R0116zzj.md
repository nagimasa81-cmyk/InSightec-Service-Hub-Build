# R0116zzj — authoritative Spectrum Dump Analyzer vendor Band0–3 definitions
