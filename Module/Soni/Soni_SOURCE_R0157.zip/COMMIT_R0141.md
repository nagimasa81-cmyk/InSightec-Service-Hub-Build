# R0141 — CPC duplicate-source / control-session boundary hardening

## Reported Windows symptom
R0140 real execution showed two failures together:
- Spectrum Analyzer: `0/5 mapped` while `27 CPC candidate(s) discovered`; every Spectrum tab remained empty.
- Cavitation Summary: all rows stayed `Control evidence unavailable` even though cavitation/control responses were known to have occurred.

## Root causes hardened

### 1. Nested ZIPs can expose byte-identical CPC files at multiple filesystem paths
R0139/R0140 preserved and expanded nested ZIP evidence. That is correct for completeness, but the repository de-duplicated only by resolved path. The same physical CPC dump copied both outside and inside a nested archive therefore remained as two candidates. When both copies independently resolved to the same Acquisition session, canonical mapping became ambiguous and correctly failed closed.

R0141 adds content-equivalent CPC de-duplication:
- RAW and FFT payloads are identified with size + SHA-256.
- Only byte-identical logical sources are merged.
- Distinct measurements are never merged just because names or timestamps match.
- When equivalent copies differ by extraction location, an explicit `SonicationN` path is preferred.
- Repository fast inventory and recursive discovery both pass through the same de-duplication contract.

### 2. Acquisition_Brain lookup was rooted too deeply
Candidate-to-session binding previously searched from the first CPC candidate's parent directory. In wrapped/nested exports the Acquisition log may be a sibling higher in the extracted study tree, so no sessions were found even though the log existed.

R0141 lets repository mapping pass the package workspace into candidate/session binding. The authoritative Acquisition_Brain search therefore starts at the extracted study workspace. Legacy call signatures remain supported for regression/test compatibility.

### 3. Control timeline session splitting had drifted from AcousticControlService
`AcousticControlService` already recognized both:
- `Got StartSpectrumMeasurement...`
- `StartSpectrumMeasurement: SetInitial PowerRatios`

but `CavitationControlTimelineService` only recognized the older `Got StartSpectrumMeasurement` form. On exports using the SetInitial form, the control parser collapsed multiple sonications into one session. A valid preferred session index could then be out of range and Summary lost authoritative control evidence.

R0141 uses the same start-session family in the control timeline parser. This specifically restores Decrease/Safety event assignment even when Spectrum/CPC decode is unavailable.

## Safety
No latest-N, filename-only, or blind positional CPC fallback was added. Mapping still fails closed unless a unique evidence-consistent source exists.

## Validation
- New R0141 duplicate CPC / SetInitial session tests: PASS
- Focused R0140/R0136/R0135/canonical/control regressions: 36 passed
- Prior full non-GUI run before final metadata synchronization: 893 passed, 1 skipped, with only two build-metadata mismatches; both metadata files were then synchronized and their tests pass.
- `verify_source.py`: `VERIFY_SOURCE_OK`
- Key Python files compile successfully.
