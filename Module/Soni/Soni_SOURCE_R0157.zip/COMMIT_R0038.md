# R0038 — Default Replay Cavitation Intelligence

This commit brings the R0031-R0037 cavitation findings into the normal Sonication Replay workflow.

- CPC Band0-Band3 energies are decoded automatically for the selected Sonication.
- Observed Acquisition_Brain cavitation-control events are synchronized when available.
- Hydrophone contribution likelihood is rendered in a compact Replay panel.
- Current dominant/contributing hydrophones and Band0-Band3 values are shown without opening Spectrum Dump Analyzer.
- MR magnitude signal loss is screened against the previous magnitude frame after global gain normalization.
- The standalone Spectrum Dump Analyzer remains the detailed inspection environment.
