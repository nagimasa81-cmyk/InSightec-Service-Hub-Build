# R0018 — File-derived sonication frequency

- Removed the fixed 0.630 MHz value from the Sonication information panel.
- The displayed frequency now uses each sonication model's discovered frequency.
- Sonication-local ACT/INI/CFG/CONF/TXT/XML files are searched first.
- Package-level Xd_*.ini remains a fallback only when no sonication-local frequency is found.
- The panel displays Unavailable when no valid frequency can be resolved.
