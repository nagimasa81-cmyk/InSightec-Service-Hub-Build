# R0116zzg13 — authoritative controller clock + partial-delivery audit

- Fixed a cross-domain timebase defect: CPC FFT history cycles and Acquisition_Brain physical power/control cycles were previously mixed, then Acquisition pre-roll was subtracted twice from control events.
- Physical Decrease/Safety responses now use the first observed ExPowerRatio controller cycle as Sonication power t=0.
- CPC FFT frame times use the same controller-cycle zero when available, preventing short/aborted Sonications from mapping every Spectrum frame to negative time.
- Cavitation Status admits only observed physical Decrease/Safety responses (power change or halt/stop), not rule-evaluation rows alone.
- Preserves SonicationSummary `panictype` and exposes it in Sonication Summary so partial delivery is not automatically misclassified as cavitation.
- Verified against supplied 17-00-24_ANx export: Sonication 5 and 6 are cavitation halts; Sonication 4 has 80.13% delivered energy but no Acquisition_Brain Decrease/Safety response and `panictype=Patient`.
