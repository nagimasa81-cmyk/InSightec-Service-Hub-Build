# R0116zzy — Minimal 1 mm Physical Ruler

## Change
The MR/Thermal scale overlay is now intentionally minimal: no background panel, no numbers, and no text labels. It draws only a pale-cyan vertical spine and 1 mm interval ticks over a true 5 mm physical span.

## Placement
The ruler remains pinned to the right side of the visible image viewport and vertically centered. Zoom changes its on-screen length according to image pixel spacing; pan/zoom do not move its anchor away from the right-center location.

## Direction
Ticks extend leftward from the right-side spine, matching the approved orientation.

## Regression guard
`tests/test_r0116zzy_ruler_ticks_only.py` prevents reintroduction of a dark background, numeric/text labels, wrong tick direction, or loss of the center-right anchor.
