# COMMIT R0084 — Vendor Legend Marker Toggles

## Summary
Adds exact FFT snapshot marker entries to the Vendor energy chart legend and allows each marker series to be toggled on/off independently.

## Added legend toggles
- White circle: Band0 exact FFT snapshots
- Green triangle: Band1 exact FFT snapshots
- Red square: Band2 exact FFT snapshots
- Orange diamond: Band3 exact FFT snapshots

## UI behavior
- Legend lists the new marker types alongside existing line/rule items
- Each marker type has its own checkbox
- Toggling a marker preserves the current zoom/pan state
- Plot marker colors match the legend
