# R0154a — CPC timing anti-regression triple check

## Findings fixed
1. SpectrumEvidenceRepository configured the R0154 controller cycle map before installing canonical MR timing. That produced cycle_times_s in a Sonication-relative axis and then treated them as MR-axis coordinates. The order is now canonical MR timing first, cycle-map parse second.
2. Cached replay rebind failures could leave a stale controller cycle map. Failure now clears the cycle origin and both cycle arrays.
3. Cavitation Intelligence still rebuilt validation event times from cycle*AcquireInterval. It now uses replay.cycles_to_mr_times(), the same exact Acquisition_Brain wall-clock map as FFT/history.
4. Spectrum event fallback also uses the shared cycle mapper instead of a local 10-ms formula.

## Triple-check scope
- Duplicate Python method definitions: none.
- Global MR start/end markers: owned markers are removed before redraw; CI linked plots clear before rebuilding.
- Control replay cursor: plot clear removes old cursor and install creates one current cursor.
- while True loops: three static occurrences; all advance their search/read position and have explicit break conditions.
- Signal connect scan: repeated textual patterns are separate local worker/thread instances, not repeated connects on one persistent signal.
- R0150a/R0151a/R0152/R0153 logic retained.
