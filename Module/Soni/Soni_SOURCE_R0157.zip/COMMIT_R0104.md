# R0104
- Seven CT skull landmarks (center, X-/X+, Y-/Y+, Z-/Z+).
- 3D transform through exported registration chain.
- Per-series nearest real MR slice correspondence for every landmark.
- Reports nearest array, slice distance, MR pixel, inside/matched.
- Slice-spacing based tolerance.
- Ax/Sag/Cor ranking uses multi-landmark 3D coverage.
- Forward/inverse diagnostic only; production matrix unchanged.
- Separates 3D chain validity from 2D skull-edge QA.
