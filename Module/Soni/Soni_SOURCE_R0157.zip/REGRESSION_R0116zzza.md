# R0116zzza Regression / Orientation Audit

- Full non-PySide6 suite: 679 passed.
- PySide6 circular-ROI GUI test remains unavailable in this Linux validation environment.
- `python -m compileall -q src tests`: PASS.
- Dedicated orientation-unification tests: 9/9 PASS.
- Display flip audit: no `np.flipud` / `np.fliplr` in MainWindow or HydrophoneWindow.
- Intentional registration flip hypotheses remain isolated inside `RegistrationOverlayService` candidate matching.
- Anatomical routes audited: Replay magnitude/thermal overlay, Planning/Reference, Registration overlay, Linked Probable Region, Replay MR Correlation, Spectrum Dump Analyzer nearest Treatment MR probable region, thumbnails/QImage previews.
- Non-anatomical routes intentionally remain Cartesian: RCV contribution/likelihood schematic, spectrogram/waterfall, cavitation heatmap, 1024-element geometry views.
