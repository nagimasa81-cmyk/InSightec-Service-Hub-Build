# R0154d — Sonication Elements layout balance

- Preserve full umbrella visibility when Element Table is shown.
- Right-side controls are placed in a vertical scroll area so their minimum height cannot compress the map.
- Umbrella canvas and upper splitter receive minimum-height guarantees.
- Table opens compactly (~25%, bounded 150–220 px) and remains draggable.
- Layout refit only repaints/recalculates from the current viewport; it does not reset the user camera.
