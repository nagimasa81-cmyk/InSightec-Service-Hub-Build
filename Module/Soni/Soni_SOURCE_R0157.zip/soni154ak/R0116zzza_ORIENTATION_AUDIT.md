# R0116zzza Full Image Orientation Audit

## Canonical contract
Anatomical arrays are raster data: row 0 is the top of the displayed image. They are never pre-flipped in UI code. Anatomical pyqtgraph views use `invertY(True)` exactly at the ViewBox level.

Receiver-reference likelihood fields are Cartesian Y-up arrays. Projection onto anatomical raster converts the field exactly once using `receiver_field_to_raster_rows()`; MR evidence projected back into receiver coordinates uses the inverse conversion.

## Audited anatomical routes
- Main Thermal Replay magnitude + thermal overlay — canonical `OverlayPanel`, Y inverted at ViewBox.
- Selected Treatment MR/Thermal — same `OverlayPanel` route.
- Planning/Reference MR — same `OverlayPanel` route.
- Registration bone overlay — same anatomical ViewBox; registration candidate flips stay service-internal.
- Main Cavitation Intelligence linked probable region — explicit anatomical ViewBox Y inversion.
- Main Replay MR correlation — explicit anatomical ViewBox Y inversion.
- Spectrum Dump Analyzer probable region with nearest Treatment MR — dynamic anatomical mode; receiver schematic mode remains Cartesian.
- Thumbnail / QImage preview routes — native raster/QImage row order; no display flip.

## Audited non-anatomical routes
No anatomical inversion applied to receiver contribution maps, receiver-only likelihood maps, spectrum/spectrogram/waterfall, cavitation heatmaps, or 1024-element geometry displays.

## Data-fusion correction
- Hydrophone likelihood is converted from receiver Y-up rows to MR raster rows before Cavitation MR correlation.
- MR signal-loss evidence is converted from raster rows to receiver Y-up rows before refining the receiver likelihood field.
- Normalized candidate centroids use shared normalized-X/Y-to-raster coordinate functions.

## Additional pending user contract applied
Red threshold mask now means temperature `<= Red threshold`; solid-red connected-region fill follows that predicate.

## Validation
- Dedicated orientation tests: 9 passed.
- Full non-PySide6 regression: 679 passed.
- compileall: PASS.
- verify_source.py: VERIFY_SOURCE_OK.
- MainWindow/HydrophoneWindow/ImagePanel display code contains no `np.flipud` or `np.fliplr`.
- Registration candidate search retains intentional flips and is isolated from display code.
