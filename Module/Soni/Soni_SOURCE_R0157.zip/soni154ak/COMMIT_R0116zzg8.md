# R0116zzg8 — Authoritative Cavitation Session + Spectrum Repository Unification

## Root causes fixed
1. Sonication Summary parsed Acquisition_Brain before it had the CPC replay's exact vendor-history session, vendor profile, cycle anchor and sonication time zero. Multi-sonication exports could therefore bind the wrong session and falsely report `No Power Decrease / Safety event` for every row.
2. Spectrum Dump Analyzer selector only checked its local `_preloaded_replays` cache. Summary/CI could already have decoded the selected Sonication into the shared `SpectrumEvidenceRepository`, but the Analyzer ignored it and started a second independent decode. This caused blank data states and the repeated 84% `publishing decoded RCV0-RCV7` stall when changing Sonications.

## Changes
- Summary canonical evidence now derives the observed control timeline from the exact shared CPC replay using `vendor_history_validation.log_session_index`, vendor profile, cycle anchor, Acquisition interval and MR/sonication timebase.
- Removed the unbound workspace-first timeline parse from `_build_one_sonication_summary`.
- Analyzer checks the study-scoped repository on every Sonication selector change.
- Loaded-Export Spectrum decode workers now call `SpectrumEvidenceRepository.replay()` instead of creating a parallel direct decoder; if another worker owns the decode, it waits/reuses that result.
- Standalone Spectrum file/ZIP decoding remains direct and independent.
