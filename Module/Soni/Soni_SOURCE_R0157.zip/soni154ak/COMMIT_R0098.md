# R0098
- Restored independent Sonication Summary tab: full table, selectable chart, cavitation overlay, double-click jump, current-Sonication line.
- Removed duplicate R0097 CI-local mini-summary.
- Fixed Why popup repetition: event candidate selection was accidentally inside the event loop.
- Synchronizes an existing Spectrum Dump Analyzer with Replay package/Sonication even while hidden.
- CPC selection prefers explicit Sonication-folder ownership before positional fallback.
- Registration keeps exported CtMr/MrMr deterministic; grossly displaced overlays are suppressed and residual/bias/coverage are reported instead of displaying misleading registration.
