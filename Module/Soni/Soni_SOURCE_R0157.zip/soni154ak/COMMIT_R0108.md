# R0108 — Geometry-derived elliptical Sonication Elements

The R0107 phase view still used a synthetic radial 16x64 circle. That cannot reproduce
the exported transducer bowl geometry.

R0108:
- reads Element X / Y / Z from the current Sonication's SkullMeasures log;
- maps element number 1..1024 to channel 0..1023;
- Phase dedicated uses the real X-Z side projection;
- preserves one common mm-to-pixel scale for both axes, so the exported bowl naturally
  appears elliptical instead of being forced into a circle;
- phase affects color only;
- INI disabled/defect remains black;
- ACT amplitude=0 remains a separate white-center marker;
- no synthetic blade/radius coordinates are used in Phase dedicated;
- if geometry is absent, the panel reports that explicitly rather than fabricating a circle.
