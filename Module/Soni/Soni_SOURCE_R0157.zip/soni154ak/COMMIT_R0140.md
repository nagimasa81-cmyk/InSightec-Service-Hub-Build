# R0140 — Canonical Sonication Identity / ReplayPackage reconstruction

## Problem
R0139 made import incompleteness visible, but ReplayPackage construction was still driven by physical `SonicationN` folders. A treatment export could therefore contain authoritative SonicationSummary/SpectrumMsg evidence for eight Sonications while ReplayPackage exposed only five. Downstream CPC mapping then correctly failed closed (`0/5 mapped`) because canonical Sonication identity had already been lost upstream.

## R0140 changes

### 1. Canonical Sonication Identity Resolver
Added `SonicationIdentityService`. Logical Sonication identity is now the union of independently numbered imported evidence:

- physical `SonicationN` directories
- `SonicationSummary.xml` rows
- `spotsonicationdata.xml` rows
- `SpectrumMsg-N.dmp`

No number absent from all numbered evidence is invented.

### 2. ReplayPackage is no longer folder-count driven
Discovery now constructs exactly one logical `SonicationModel` per canonical Sonication number. If Summary/evidence identifies Sonication6–8 but only Sonication1–5 folders exist, Sonication6–8 remain present as `PARTIAL` synthetic logical models rather than disappearing.

### 3. Duplicate physical folders are merged
Nested ZIP expansion can expose the same `SonicationN` more than once. R0140 merges those physical folders into one logical model and de-duplicates same-name/same-size copies while retaining distinct evidence.

### 4. Explicit Sonication number is a first-class model field
`SonicationModel` now carries `sonication_number`, `evidence_folders`, `synthetic_identity`, and `identity_evidence`. Summary, PowerGraph, evidence binding, MR timeline selection, and CPC explicit-folder mapping use that number instead of ReplayPackage list position.

### 5. Evidence binding position bug fixed
`SonicationEvidenceService` no longer interprets the third item in a sparse list as Sonication3. For example `[Sonication1, Sonication2, Sonication4]` binds Summary/PowerGraph rows 1, 2, and 4 respectively. Sparse identity sets do not use positional Type-6 setup-window binding.

### 6. CPC explicit folder identity fixed
CPC candidates located under `Sonication4/...` are mapped to the logical model whose `sonication_number == 4`, not blindly to list index `4-1`.

### 7. ZIP/folder parity
Opening a directory that contains nested ZIP evidence now uses an isolated copied workspace and the same recursive nested-ZIP materialization contract as ZIP drop. The user's source folder is never modified.

### 8. Import completeness audit extended
Audit now records ReplayPackage Sonication numbers, unique physical folder count, physical folder occurrence count, and duplicate identity. It verifies ReplayPackage identity against the union of imported numbered evidence.

## Safety policy retained
R0140 does not add a latest-N or blind positional CPC fallback. CPC mapping still fails closed when authoritative identity/session evidence is not sufficient.

## Validation
- R0140 canonical identity tests: 7 passed
- Full non-GUI regression: 893 passed, 1 skipped
- Skip reason: optional `pyzipper` package unavailable in the validation environment for the real AES ZIP test
- GUI circular ROI collection is not runnable in this Linux validation environment because PySide6 is unavailable
- `python verify_source.py`: `VERIFY_SOURCE_OK`
- Python compile: PASS
- Duplicate class-method AST audit: 0 duplicates

## Expected behavior on the reported real export
If imported evidence contains Summary/Spectrum identities 1–8 while physical Sonication folders are only 1–5, Main must now expose Sonication1–8. Sonication6–8 are retained as partial logical Sonications. This allows canonical Acquisition/CPC mapping to be attempted against the correct eight-treatment identity universe rather than an already-truncated five-item ReplayPackage.
