# R0116zzd — Spectrum 96% publish stall repair

## Root cause
- Secondary Spectrum computation finished in its worker, then the GUI publish path reparsed the observed cavitation/control timeline synchronously at 96%.
- The final publish bundled Spectrogram, Band Energy, Vendor controls and Cavitation/Control Timeline into one GUI callback, so any expensive final binding made the modal dialog appear frozen at 96%.

## Repair
- Move observed control-timeline parsing into SpectrumSecondaryWorker / SpectrumEvidenceRepository.
- GUI `_load_observed_cavitation_timeline()` is cache-only and never parses files.
- Stage final publishing across Qt event-loop turns: Spectrogram → Band Energy → Vendor → Cavitation/Control Timeline.
- Make the final publish progress dialog non-modal while keeping visible progress.
- Preserve stale-generation rejection and shared repository identity.
