# R0116n — Cavitation Complete Flow

## Cavitation analysis flow
- Graph markers and Event list are generated from one `_visible_observed_events` collection.
- Added graph/table integrity guard so a future display disconnect is surfaced immediately.
- Increase remains hidden by default from both graph markers and Event list.
- Event-list row selection maps correctly after filtering and opens Why for the exact event.
- Why displays irradiation phase, exact ExciterPower at the event, weighted energy, threshold and final classification.
- Added analysis funnel: visible control events -> rule-qualified -> treatment cavitation.

## Irradiation timing
- Acquisition_Brain `Set:` lines now retain both ExciterPower (W) and ExPowerRatio.
- `ExciterPower = NA` is still accepted so ExPowerRatio=0/halt updates are not lost.
- Each control event is classified from the ExciterPower sample at that event: Irradiation active / Pre-irradiation / Unknown.
- Decrease/Safety only counts as treatment cavitation when irradiation is active and the rule threshold is actually met.
- The graph explicitly says `Control time from first Set`; this clock is not MR acquisition time.

## View stability
- Added `Lock plot view`, default ON, to prevent accidental mouse-wheel zoom or drag-pan from hiding the full analysis.
- Added `Reset view` to restore full auto-range.

## Validation
- Python compileall PASS.
- 376 non-Qt regression tests PASS.
- One Qt GUI test cannot be collected in this Linux validation container because PySide6 is not installed; this is an environment limitation, not a failing assertion.
- Real export `10-00-09_ANx(1).zip` was parsed directly. Acquisition_Brain Set lines contain non-zero ExciterPower from control-time 0 in the checked sessions. Example: session 4 first Decrease at 0.94 s had ExciterPower 168.36 W, weighted energy 0.016362, threshold 0.015. Therefore this early Decrease is during acoustic output even though it can appear before MR/replay time zero on another clock.
