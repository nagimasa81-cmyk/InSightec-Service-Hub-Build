# R0118 — Consolidate the two independent sub-harmonic detectors

## Problem
R0117 added `CpcHydrophoneReplay.subharmonic_events()` as a new, independent
implementation of "is there a prominent f0/2 sub-harmonic". It was only
discovered afterward that `CavitationVisualizationService.compute()` already
computed the same physical quantity (`CavitationTrend.subharmonic_db`),
already wired into the main Cavitation Intelligence workspace
(`main_window.py`'s `cavitation_sub_curve`), using a *different* frequency
window and a *different* dB formula (10*log10 band-integrated energy vs.
20*log10 single peak-bin amplitude ratio). Two independent definitions of the
same physical concept can drift apart and disagree about the same frame --
exactly the "duplicate implementation path" risk called out in the R0117
codebase review.

## Fix
- `CavitationVisualizationService` gained four small public helpers
  (`band_energy`, `energy_ratio_db`, `fundamental_window_hz`,
  `subharmonic_window_hz`) that expose its existing private band-integration
  and dB-conversion logic. `compute()` itself now calls the two window-width
  helpers instead of inlining the same magic numbers a second time.
- `CpcHydrophoneReplay.subharmonic_events()` was rewritten to call these same
  helpers instead of computing its own peak-bin amplitude ratio. It keeps its
  own value: a per-frame, per-channel *discrete event* view with a
  noise-floor gate (useful for markers/evidence lists), whereas
  `CavitationTrend` is a channel-averaged *continuous trend* (useful for
  visual trend review) -- but both now measure the identical underlying
  quantity.
- `SubharmonicEvent.fundamental_amplitude`/`subharmonic_amplitude` are now
  documented as band-integrated energy (matching `CavitationTrend`), not a
  single peak-bin amplitude as before.

## Verified consolidation, not just "similar"
`tests/test_r0118_subharmonic_detection_consolidation.py` includes a
behavioral (not just static-text) test: on synthetic frames with an
engineered f0/2 spike, `subharmonic_events()`'s reported `ratio_db` for the
firing frame is asserted equal (to 1e-6) to `CavitationTrend.subharmonic_db`
for that same frame -- proving the two call sites now literally share the
same measurement. Manually re-verified against the real Brain650 export used
in R0117: `CavitationTrend.subharmonic_db` and `subharmonic_events().ratio_db`
now produce numerically identical values per frame (e.g. frame 7: 13.36 dB in
both), and the previously-independent noise-floor gate in
`subharmonic_events()` correctly still suppresses reporting on early
low-signal frames that the continuous trend also shows as unremarkable
(~2-4 dB) without needing a gate of its own.

## Tests
- `tests/test_r0117_band0_hardening_and_subharmonic_detection.py`: updated
  the ratio-math assertion to check delegation instead of the old inline
  20*log10 formula (scoped to the `subharmonic_events` function body only,
  since unrelated 20*log10 amplitude-to-dB conversions legitimately exist
  elsewhere in the file for spectrogram/waterfall display).
- `tests/test_r0118_subharmonic_detection_consolidation.py` (new): static
  checks that the canonical helpers are public and reused inside `compute()`,
  plus the synthetic-data behavioral cross-validation above.

All R0116zzg23 / R0117 / R0117b assertions re-verified unchanged (no
regression).
