# R0117 — Band0 validation hardening + f0/2 sub-harmonic evidence

## 1) Band0 gap-reconstruction validation was too easy to trigger
- `_draw_band_energy` accepted a *single* matched FFT/history sample as
  "stable" (a lone ratio trivially matches itself, relative error 0). Added
  `MIN_VALIDATION_PAIRS = 5`: reconstruction is now enabled only when at
  least 5 FFT snapshots were cross-validated against the 10-ms history AND
  their ratio spread stayed within 2%.
- Rejection is now quantified instead of a flat message: the status line
  reports either `max dev X.X% over N sample(s)` or `only N sample(s), need
  >= 5`, so an operator/engineer can tell "barely failed" from "no usable
  overlap" without opening a debugger.

## 2) Silent exception swallowing in the CI canonical axis
- `_apply_ci_canonical_mr_axis` (main_window.py) previously had a bare
  `except Exception: pass`. A malformed replay (e.g. missing
  `mr_timeline_duration_s`) produced a blank/default axis with zero trace of
  why. Now logs via `LOG.exception(...)` so failures are visible in
  diagnostics instead of masquerading as "nothing to draw".

## 3) New: f0/2 sub-harmonic evidence (passive cavitation indicator)
- `CpcHydrophoneReplay.subharmonic_events(channel, prominence_db=-3.0,
  tolerance=0.03)` scans every decoded frame's spectrum for a sub-harmonic
  bin (f0/2) that is comparably strong to, or stronger than, the fundamental
  (f0) -- the textbook acoustic signature of stable/inertial cavitation.
  Deliberately evidence-only: it reports a measured ratio and a
  `moderate`/`high` confidence tag, never a diagnosis, consistent with the
  project's existing `CavitationLikelihoodService` philosophy.
- Wired into both secondary-product pipelines
  (`SpectrumSecondaryWorker.run()` for the standalone/dev path and
  `SpectrumEvidenceRepository.secondary_products()` for the shared
  study-scoped app path) so it is computed once, off the GUI thread, per
  receiver channel.
- Surfaced in `_draw_band_energy` as small triangular markers directly on
  top of the already-plotted measured Band0/Band-N dB curve (never a new,
  separate scale) plus a status-line note
  `"▲ f0/2 sub-harmonic evidence at N sample(s) -- not a cavitation
  diagnosis"`. Markers never gate or replace the existing measured/
  reconstructed curves.

## Validated against real Brain650 export data
Applied to a real 5-sonication Brain650 export (not synthetic fixtures):
`subharmonic_events` independently reproduced a strong f0/2 sub-harmonic
episode (ratio up to +32 dB above the fundamental, `confidence="high"`) in
the receiver channel and time window that lines up exactly with a CGA
controller power cut visible in the raw `CGA_Brain_650_*.txt` log
(297.8 W -> 32.1 W in ~100 ms) during the highest-power sonication of that
export.

## Tests
`tests/test_r0117_band0_hardening_and_subharmonic_detection.py` (static,
source-text based, matching the existing R0116zzg23 test style):
- minimum validated-pair guard is present in `_draw_band_energy`
- rejection message is quantified
- sub-harmonic markers are additive, never replace measured/reconstructed
  curves
- `_apply_ci_canonical_mr_axis` failures are logged, not swallowed
- `SubharmonicEvent` / `subharmonic_events` exist and are documented as
  evidence-only
- the new payload key is wired into both secondary-product pipelines, per
  channel

All prior R0116zzg23 assertions re-verified unchanged (no regression).
