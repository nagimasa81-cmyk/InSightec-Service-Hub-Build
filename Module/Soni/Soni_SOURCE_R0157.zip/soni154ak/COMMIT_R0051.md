# R0051

Fixes the Registration ON activation path. The button is enabled when a Preplanning/Planning MR reference series is available, even while live replay is currently displayed. Pressing Registration ON automatically brings the selected or first MR reference into the main viewer and applies the treatment CtMr overlay.
