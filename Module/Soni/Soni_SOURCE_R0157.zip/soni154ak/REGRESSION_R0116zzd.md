# R0116zzd regression

- Dedicated 96% stall tests: 4 PASS.
- Related Spectrum publish / red-threshold tests: 13 PASS.
- Full non-PySide6 suite: 692 PASS.
- Known environment limitation: `test_r0015_circular_roi_measurement.py` requires PySide6, unavailable in this Linux validation environment.
- Python compileall: PASS.
