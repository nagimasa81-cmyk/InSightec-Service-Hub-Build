# R0116zq — Rich Localization

- Expanded display languages from 5 to 7: English, Japanese, Korean, Traditional Chinese (Taiwan), Spanish, Thai, Hindi.
- Added reversible runtime translation for high-visibility static UI labels across Main Window and Spectrum Dump Analyzer.
- Localized major tabs, open/load actions, Spectrum/Cavitation controls, event controls, analysis navigation, engineering tabs, and common status labels.
- Preserved scientific identifiers such as CPC, RCV, CGA, FFT, MR, Spectrum, and Sonication where translation would reduce technical clarity.
- Added Thai and Hindi narrative localization for RCA/cavitation summaries and evidence guidance.
- Language switching recovers canonical English labels before applying the next locale, preventing cumulative/double translation.
- Qt-tree localization uses QObject children traversal without importing PySide6, preserving source-validation compatibility.

Validation:
- rich-i18n + selector tests: 7/7 PASS
- R0116 regression: 179/179 PASS
- full non-GUI suite: 485/485 PASS
- PySide6-dependent ROI GUI test not runnable in this container.
