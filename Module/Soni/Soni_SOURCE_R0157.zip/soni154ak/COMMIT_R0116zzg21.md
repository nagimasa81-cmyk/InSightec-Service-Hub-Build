# R0116zzg21 — Spectrum Analyzer canonical MR time-axis unification

## Triple-check findings
1. Legacy `_set_mr_xrange()` / `_apply_mr_timeline_window()` still auto-fit each plot to its own payload, so Raw, Spectrogram, Band Energy, Vendor and Control charts could show different horizontal windows.
2. The g16 Spectrum MR label re-zeroed `mr_frame_times_s` at the first decoded CPC snapshot, while Spectrogram/Band/Vendor used the canonical MR coordinate directly. This shifted Spectrum timeline annotations relative to the other charts.
3. Cavitation Hydrophone×Band heatmap still used FFT snapshot number on X, not MR time.
4. Raw A/D snapshot plots used sample index on X, so the global MR timeline could not be applied consistently.
5. Layout-fit/reset routines could silently undo a timeline range after a chart had already been drawn correctly.

## Fix
- One global Chart time axis selector: Start = MR acquisition start or Sonication start; End = Sonication end or MR acquisition end. Default is MR acquisition start → MR acquisition end.
- One canonical coordinate: MR acquisition start = 0 s.
- Time-domain views use the same selected MR window: Measurement/Raw, Spectrogram, Band Energy, Vendor/CGA time curves, Cavitation Control Timeline, and Hydrophone×Band activity.
- Spectrum remains a frequency-domain graph; its frame annotations now use canonical MR time without local re-zeroing.
- Raw snapshot samples are placed at current MR frame time + sample offset.
- Hydrophone×Band heatmap X changed from snapshot index to MR acquisition time.
- Fit/reset/show callbacks no longer replace the selected time window with per-payload auto-fit.
- Pre-irradiation Spectrum Summary window is explicitly MR t=0 to Sonication start.
