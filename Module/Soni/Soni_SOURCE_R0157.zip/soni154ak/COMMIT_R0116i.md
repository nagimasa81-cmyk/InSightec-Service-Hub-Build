# R0116i

- Added per-Sonication Frequency (MHz) to Sonication Summary and chart metric.
- Detailed Sonication Summary starts automatically in a worker after Export ZIP load.
- Added Show lower chart; default OFF hides the lower Summary chart.
- CPC Spectrum / 8CH Hydrophone Analyzer source dropdown popup is wide/non-elided with full-name tooltips.
- Main Sonication dropdown uses the same full-name popup behavior.
- Preserves R0116h image-I/O gating and earlier cavitation fixes.
