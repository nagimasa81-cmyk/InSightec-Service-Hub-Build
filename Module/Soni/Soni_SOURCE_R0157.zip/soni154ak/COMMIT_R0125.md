# R0125 — Mouse-selected Raw A/D FFT

## Scope
Adds a frequency-domain FFT workflow to Spectrum Dump Analyzer > Measurement Timeline / Raw A/D.

## Behavior
- `FFT range selection` enables a draggable LinearRegionItem on the Raw A/D chart(s).
- The selected MR-time interval is synchronized across Overlay / Single / 8-panel Raw views.
- `FFT selected range` extracts only structurally validated per-measure Raw A/D waveform samples from decoded `frame.raw_channels`.
- Validated CPC measurement-history traces are explicitly rejected as FFT input; they are metrics, not waveform.
- A selected interval containing missing Raw A/D samples is rejected instead of concatenating across a gap.
- FFT supports Hann (default), Hamming, and Rectangular windows.
- Result window overlays enabled RCV spectra and reports source interval, duration, sample count, sampling frequency, frequency resolution, and window.
- Existing mouse pan/zoom remains available whenever FFT range-selection mode is off.

## Regression guard
R0124 plot interaction and canonical MR timeline behavior are preserved.
