# R0154l ancestry / regression audit

This audit was performed against the current R0154k source and the historical regression contracts carried inside the package.

## Confirmed regressions found in R0154k

1. **ZIP-drop Summary could pass its gate before Spectrum preload had even started.**
   The load sequence scheduled Summary work before the delayed Spectrum preload. The gate checked only live/pending worker objects, so the scheduled-but-not-yet-created preload was invisible.

2. **Authoritative Summary retry from R0137 could be lost.**
   A Spectrum handoff marked `_sonication_summary_needs_detail=True`, but R0154k cleared that state when the current Summary pass was already running. The running pass was preserved, but the required post-handoff retry disappeared.

3. **A completed Summary row could retain `Analyzing…` in DQA alignment.**
   Worker exceptions terminalized only the cavitation-status cell, leaving the seeded DQA cell untouched.

4. **Brain220 structural SpectrumMsg could fall through to an unsafe legacy global grouper.**
   When a valid vendor frame header existed but the strict global graph-record count did not match, the decoder could still accept a legacy hard-coded 8-record grouping and return fewer frames without exposing the declared-frame mismatch.

5. **Brain220 legacy heuristic search still inherited the 200–800 kHz Brain650 band.**
   This could underweight/reject low-frequency and subharmonic evidence in fallback decoding.

## Fixes in R0154l

- Explicit initial Spectrum-handoff lifecycle state covers the delay before the preload QThread exists.
- Summary retry state survives an active pass and is executed only after that pass completes.
- DQA cells terminalize on row errors.
- Valid structural headers cannot fall through to the global hard-coded 8-record grouper.
- Brain220 heuristic search includes the low/subharmonic region.

## Important remaining architecture observation

The old R0116zzr statement that Summary detail does not decode CPC per Sonication is no longer literally true in the current architecture. `SonicationSummaryCavitationEvidenceService.analyze()` calls the shared `SpectrumEvidenceRepository.replay()`. This is still single-owner, off-GUI-thread I/O and therefore does not reintroduce the old GUI freeze, but it means Summary completion can depend on sequential CPC decode for Sonications not already in the repository cache. This behavior came from later exact-session/evidence unification work (R0116zzg8/R0136) and is not silently treated as equivalent to the older cache-only contract.

A future performance pass should separate **fast Summary control evidence** from **deep CPC/RCA enrichment**, while preserving the single authoritative repository/session mapping.

## Validation

- `verify_source.py`: PASS
- `python -m compileall -q src`: PASS
- Focused ancestry/timing/Brain220 suite: 52 PASS
- Full non-PySide suite: 1002 PASS, 1 SKIP (`pyzipper` unavailable)
- Full collection has one environment-only error because PySide6 is not installed in this Linux runtime (`test_r0015_circular_roi_measurement.py`).
