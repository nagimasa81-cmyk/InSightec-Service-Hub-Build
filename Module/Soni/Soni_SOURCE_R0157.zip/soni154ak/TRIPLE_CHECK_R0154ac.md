# R0154ac triple check

- DQA is rendered as one series-common result because XD is mechanically fixed during DQA acquisition.
- X/Y are aggregated only from Axial same-raster observed-minus-planned focus measurements.
- Z is aggregated only from Sagittal same-raster observed-minus-planned focus measurements.
- Tilt is independently recovered from the DQA Sagittal phantom lower baseline, with image horizontal defined as 0 degrees.
- No per-row X/Y/Z mixing is displayed in Sonication Summary; the DQA column is vertically spanned across the series.
- Brain220 target voxel labeling is frequency-gated (150-350 kHz). Generic 650/690-kHz SpotSonicationData is reported as a standard focus/spot, not as a target voxel.
- Existing 650/690 and Brain220 Spectrum/CPC preload changes from R0154ab are preserved.
- Regression: 1050 passed, 1 skipped (pyzipper unavailable); PySide6-only GUI collection test excluded in this Linux environment.
- verify_source.py: PASS.
- Duplicate top-level class/function definitions in src: 0.
