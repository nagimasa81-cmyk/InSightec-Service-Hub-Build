# R0116p — Unified Cavitation State / FFT Link Repair

- Control event cycles now map to the nearest real SpectrumDump FFT snapshot instead of requiring exact cycle equality.
- Probable Location evidence reports event cycle, mapped FFT snapshot, FFT cycle, and delta cycle.
- Hydrophone × Band is generated directly from replay.frames vendor_band_energies and no longer disappears when candidate/event detection returns zero events.
- Added FFT/Band connection diagnostics: current snapshot, count of valid 8×4 matrices, and current maximum band energy.
- Current FFT snapshot refresh updates the Hydrophone × Band cursor/data diagnostics and Probable Location from the same replay state.
- Source reset clears FFT/Band linkage diagnostics together with the old replay state.
