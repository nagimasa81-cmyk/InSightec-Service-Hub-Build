# RC2-R0020 XD Reference File Selection

- XD parameter references are now restricted to `Xd_####.ini`.
- XD geometry references are restricted to `XdGometry_####.ini`; the compatible spelling `XdGeometry_####.ini` is also recognized.
- Serial `0000` is treated as a default/template file and is never used as an XD reference.
- Broad or ambiguous XD names are ignored.
- Sonication-local frequency scanning excludes XD parameter/geometry files, preventing `Xd_0000.ini` from overriding the actual sonication frequency.
- The replay package retains the selected XD parameter and geometry reference lists for later audit/UI use.
