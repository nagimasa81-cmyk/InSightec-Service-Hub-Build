# R0116t Triple Check

## 1. Data-path check
- Probable Location depends on replay FFT/Band data and therefore its dynamic update confirms the replay dataset is present.
- Control Timeline uses Acquisition_Brain observed-control data separately; blank rows are treated as a UI population/runtime fault, not as evidence of missing replay data.

## 2. Runtime-connection check
- Control Timeline scene click -> nearest visible event by pixel distance -> selected-event state -> optional Why popup.
- Event list row click -> selected-event state -> optional Why popup.
- Replay frame change -> independent white Control Timeline cursor update -> dynamic cavitation views -> Probable Location update.
- Selected-event red cursor is not reused as the replay cursor.

## 3. Regression / overwrite check
- No duplicate methods in EightHydrophoneWindow.
- Existing R0116q/r/s Why-popup contracts retained.
- Non-PySide regression suite: 403 PASS.
- compileall: PASS.
- VERSION/version.json/constants synchronized to RC7.2-R0116t.
