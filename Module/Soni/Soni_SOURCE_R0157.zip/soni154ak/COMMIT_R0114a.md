# R0114a — Study-Scoped Preplanning / Planning Cache

- Preplanning CT, Preplanning MR, and Planning MR are retained for the lifetime of the loaded Export package.
- Sonication reselection no longer discards decoded reference arrays, reference thumbnails, the stacked CT volume, the native 3-D skull mask, or prior per-Sonication registration renders.
- Treatment MR, Thermal, replay curves, and other Sonication-scoped state are still rebuilt for the selected Sonication.
- All study-level caches are invalidated when a different ZIP/folder package is loaded, preventing cross-patient or cross-study reuse.
