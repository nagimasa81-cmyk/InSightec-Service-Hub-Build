# R0154v — Brain220 DQA fail-closed + CPC FFT timing repair

- Brain220/230 DQA numeric focus displacement is suppressed unless a common-frame hotspot/phantom registration is explicitly proven; unconfirmed coordinate differences no longer become X/Y/Z alarms.
- Detects collapsed/pre-roll CPC FFT fingerprint timing (e.g. a 20 s sonication rendered into ~0.18 s) after Acquisition_Brain controller-cycle binding.
- Rebinds display timing only to exact controller Cycle-N-Done timestamps sampled across the irradiation window; FFT amplitudes and vendor energies are never modified.
- Spectrum, Spectrogram, Band Energy, CGA and CI now share the repaired MR-axis timing provenance.
