# R0089 — Visible Language Selector

- Added an always-visible Language selector to the Main toolbar.
- Added a normal top-level Language menu as a second access path.
- Both controls are synchronized and persist through QSettings.
- Supported selections remain: English, 日本語, 한국어, 繁體中文（台灣）, Español.
- Removed reliance on QMenuBar.setCornerWidget(), which could disappear in the packaged Windows UI.
- R0088 Sonication Phase phasor fix is preserved.
