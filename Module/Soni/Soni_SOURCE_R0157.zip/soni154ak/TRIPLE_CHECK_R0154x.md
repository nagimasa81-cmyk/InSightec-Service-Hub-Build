# R0154x triple check

1. Source/data routing
   - Brain220 diagnostics prove SpectrumMsg frame counts match PowerGraphSize (S1-S4 75, S5 10, S6-S7 192) and embedded SpectrumMsg end-times match PowerGraph end-times.
   - Previous R0154w Sonication view still preferred mapped physical CPC, whose sparse 18 FFT snapshots were therefore displayed as the complete spectrum. R0154x routes the exact Sonication-owned SpectrumMsg to the default spectral view while retaining physical CPC rows for 8CH/history/vendor inspection.

2. DQA semantic gate
   - R0154w blanket-excluded every 150-350 kHz study before attempting same-raster DQA measurement.
   - R0154x attempts the existing same-raster proof first for every family; only unproven Brain220 numeric displacement is withheld.
   - Ordinary Brain220 treatment data are not excluded from Spectrum, thermometry, power, voxel/spot, steering, or Summary analysis.

3. Regression/ancestry/overwrite check
   - Relevant regression set: 617 passed.
   - Full non-GUI suite: 1027 passed, 1 skipped (pyzipper unavailable).
   - Full suite collection stops only on the pre-existing PySide6 runtime dependency in this Linux environment.
   - Python compile PASS for changed runtime modules.
   - Summary schema intentionally changed from 17 to 18 columns; schema-sensitive historical tests updated accordingly.
