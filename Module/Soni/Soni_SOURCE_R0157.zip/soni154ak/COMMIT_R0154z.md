# R0154z

## Brain220 DQA focus measurement / judgement split

- Removed the Brain220/230 family-level early N/A gate.
- DQA focus measurement is now attempted for every DQA Sonication regardless of 220/230 kHz family.
- Steering, multi-target and target-voxel evidence excludes only centre-alignment threshold judgement; measured X/Y/Z/Tilt remain visible with `Not judged`.
- Selected Sonication image-native evidence is retained even when that shot is steered; other excluded shots cannot redefine the nominal cross-plane DQA reference.
- Common-frame SonicationSummary focalRAS remains available after same-raster and observed-thermal attempts, with the existing frame-compatibility and non-local-offset rejection gates intact.
- No return to unrestricted focalRAS-minus-phantom subtraction.

Regression: `test_r0154z_dqa_measurement_judgement_split.py` plus existing R0154h/j/u DQA tests.
