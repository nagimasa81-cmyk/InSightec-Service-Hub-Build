# R0070 — Measured CPC Synchronization

- Power/Score continue to terminate at measured acoustic-control end.
- CPC/RCV acquisition is no longer disabled merely because power delivery ended.
- Replay uses CPC `acquisition_time_s` to select the closest real hydrophone snapshot.
- A tolerance window prevents reuse of the last CPC frame when no measurement exists at the current MR time.
- CPC SpectrumFrame timestamps now use decoded acquisition time when available.
- Cavitation Intelligence remains active for post-power measured background, but reports the synchronized FFT time and whether the cursor is in the post-power monitoring period.
- Current spectrum rendering respects an explicit synchronized frame map and does not fall back to proportional mapping for missing channels.
