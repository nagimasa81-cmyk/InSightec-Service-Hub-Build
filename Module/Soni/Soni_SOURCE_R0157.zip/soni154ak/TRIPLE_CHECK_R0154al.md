# TRIPLE CHECK R0154al

1. **Family gate** — Brain220 (230 kHz) retains the currently correct vertical orientation; Brain650 (690 kHz) receives the opposite native-Z normalization.
2. **Single-flip gate** — family handedness is resolved only in `_canonical_umbrella_points`; named orthographic views, perspective camera, focus markers, and status markers do not add a second Z inversion.
3. **Regression gate** — compileall PASS; new R0154al tests 4/4 PASS; related R0154ad/R0154q/R0113a tests 19/19 PASS. Unknown family preserves historical behavior.
