# R0107 — Sonication Element Channel State Semantics

## Semantics
- ACT amplitude=0 is **not** DISABLED or DEFECT.
- ACT amplitude=0 is a sonication-specific commanded zero-amplitude state.
- SkullHeating_sonic*.log is used as evidence for the recorded OffReason:
  - 0 OffByAlgorithm
  - 2 OffByNPR
  - 3 OffManually
  - 4 OffByApod
  - 5 OffByCPC
- DISABLED is defined only from `DisabledReflectionChannels.ini`.
- DEFECT/DISCONNECTED is defined only from `DisconnectedChannels.ini`.
- State layers may overlap; the UI shows every applicable state instead of overwriting one with another.

## Display
- Phase dedicated is a physical 16-Blade × 64-channel circle.
- Phase affects color, never element position.
- INI disabled/defect channels are black.
- ACT amplitude=0 is a separate white-center marker unless the same channel is INI black.
- Click/hover shows channel state, INI source, and ACT/log OffReason.

## Audit
- No duplicate method definitions inside the same class before patching.
- SonicationElementMapWidget and TransducerMapWidget both own `_draw_phase_dedicated`; these are separate classes and not an overwrite.
- elementClicked / parameter change / layout change each have one signal connection.
- Staged metadata refresh remains the single automatic Sonication Elements refresh path.
