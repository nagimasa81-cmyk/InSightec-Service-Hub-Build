# R0057 — Sonication Elements Workstation UI

- Reworked Sonication Elements UI using the supplied workstation reference.
- Large central element map with compact parameter controls.
- Umbrella view is now the default; Tile 16×64 remains selectable.
- Added Blade 1–16 visibility checkboxes plus All/Clear.
- Added click-to-select element details and synchronized table selection.
- Element table is hidden by default and can be toggled on.
- Sonication Elements remains separate from Cavitation Intelligence / RCV0–RCV7.
- Phase/amplitude values remain color-gradient selectable.
