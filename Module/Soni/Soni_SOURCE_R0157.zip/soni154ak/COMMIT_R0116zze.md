# COMMIT R0116zze

## Spectrum 96% publish hardening
- Secondary Spectrum progress uses a dedicated non-modal BackgroundProgressDialog.
- Worker completion performs no chart/table clearing before returning to the Qt event loop.
- Cached secondary payloads use the same staged publish path as fresh worker results.
- 96% now means worker complete / publish scheduled; 97-99 identify the exact view being bound.
- Slow individual publish stages (>0.75 s) are recorded in the Analyzer note for diagnostics.

## Red threshold edge
- Red classification remains temperature >= Red threshold.
- The threshold mask is binary; no multi-pass alpha blur is applied.
- MRI image smoothing remains enabled for zoom display, giving only display-pixel antialiasing.
