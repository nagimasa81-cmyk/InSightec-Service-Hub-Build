# R0154e — tab-independent ZIP drop + fresh-start import diagnostics

## Problems
1. Dropping the same Export while **Sonication Summary** was active could leave cavitation/location fields at `pending` / `control evidence unavailable`, while dropping on Replay first and opening Summary later worked.
2. A different Export could fail CPC/control binding even on a **fresh application start**. Because the original Export can be too large to share, the failing discovery stage was difficult to identify remotely.
3. Re-loading a different study still needed explicit stale Summary worker invalidation as a separate lifecycle hardening measure.

## Fixes
- Gate detailed Sonication Summary analysis until the initial selected-Replay / Spectrum ownership handoff is complete.
- Keep cheap Summary fields (Power, Duration, Frequency, etc.) visible immediately while CPC detail waits.
- Resume Summary detail from worker-completion events; no timer polling or duplicate decode loop was added.
- Invalidate Summary generation and cancel old detail/temperature workers on every source switch.
- Diagnostics tab now lazily binds to the exact currently adopted ReplayPackage and is cleared atomically during a source switch.
- Added **Export Import Diagnostics ZIP** in Diagnostics.
  - Generates `import_diagnostics.json` + `README.txt` only.
  - Contains metadata only: Sonication identity, import audit, Acquisition_Brain candidates/selected log/session counts, Sonication_Brain setup records, CPC/Spectrum candidates and mapping evidence, canonical MR timing and clock-sync status, relevant relative file inventory and sizes.
  - Does **not** copy MR image payloads, Spectrum sample payloads, or log text.
- Fresh-start Export incompatibility is deliberately treated as a separate discovery/binding problem, not attributed to stale prior-study workers.

## Validation
- R0154e drop/lifecycle/diagnostics targeted suite: 5 PASS.
- Timing/Elements/previous R0154 regressions combined targeted suite: 36 PASS.
- Full non-PySide regression: **956 passed / 1 skipped**.
  - Skip: optional AES ZIP test because `pyzipper` is unavailable in the Linux validation environment.
- `python verify_source.py`: `VERIFY_SOURCE_OK`.
- `python -m compileall -q src`: PASS.
