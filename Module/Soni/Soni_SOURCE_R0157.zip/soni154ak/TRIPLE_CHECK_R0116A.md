# R0116a Triple Check — Connection / Override / Regression Audit

## Scope
R0116 was audited across the current source, historical regression tests, receiver-disable propagation, thumbnail navigation, Registration, and 3-D focus linkage.

## Triple check 1 — Data source and propagation
- `Calibration.ini [SPECTRUM] IsEnabled` is the authoritative RCV0–RCV7 enable/disable source.
- `CavitationSafetyAndControl.ini` remains a cavitation-rule/configuration source only; it is not used to decide whether an RCV channel is disabled.
- The parsed `receiver_enabled` mask now propagates into:
  - Spectrum Dump Analyzer receiver selector
  - Raw/Spectrum/Band Energy channel curves
  - Vendor/CGA per-RCV curves and exact FFT snapshot receiver selection
  - Standalone cavitation candidate calculation
  - Cavitation likelihood calculation itself
  - Cavitation likelihood receiver markers/table
  - Main Sonication Analysis acoustic-spectrum channel menu
  - Main replay cavitation receiver markers and contributor selection
- Disabled RCVs are removed before cavitation likelihood normalization, so a hidden channel can no longer remain the dominant/contributing RCV internally.

## Triple check 2 — UI connection / state overwrite
- Found and fixed a real disconnected state path: `main_window.py` read `show_disabled_rcv_action` but R0116 never created that QAction. R0116a creates it, default OFF, and connects it to a single refresh handler.
- Found and fixed a stale-selection overwrite path: `_rebuild_channel_controls()` removed hidden actions but left disabled channel names inside `chart_state.selected_channels`. R0116a intersects persisted selection with the current visible action set and writes the corrected set back to `chart_state`.
- `All Channels` now means all currently visible channels rather than hard-coded 8 channels.
- No duplicate class methods, stale `*.py.bak`, `.orig`, or editor backup sources remain under `src/`.
- Duplicate-looking worker `.connect()` lines are in separate worker lifecycles, not duplicate connections on the same signal instance.

## Triple check 3 — Regression / ancestor-return audit
- The old thumbnail `QScrollBar` implementation is absent from active source. Current navigation is image-index `QSlider`.
- Old `Show Reference` / `Show Treatment MR` checkbox symbols are absent from active source.
- `XDWindow` obsolete class reference is absent.
- Historical tests that asserted obsolete implementation details (old QScrollBar, old R0113 version string, always-on registration diagnostic) were updated to test the current intended behavior rather than force an ancestor implementation back in.
- Version metadata was inconsistent in R0116 (`VERSION=R0113`, `constants.py=R0114a`, `version.json=R0116`). R0116a makes all three `RC7.2-R0116a`.

## Registration
- Normal overlay rendering stays separate from the expensive full reference-series diagnostic.
- `Registration Trace` explicitly triggers the full diagnostic; normal MR switching does not.
- Current display-only outer-skull filtering remains in place. No automatic image-similarity correction or silent treatment-matrix rewrite is introduced.
- Actual Windows visual validation is still required for skull placement; static/source tests cannot prove patient-coordinate overlay accuracy.

## 3-D focus
- The existing same-camera focus projection remains connected for 3-D Umbrella Perspective/XY/XZ/YZ views.
- R0116a does not change the physical focus model further; it prevents RCV-disable/state changes from interfering with this path.

## Validation
- `python -m compileall -q src`: PASS
- Focused R0107–R0116a regression set: 66 PASS
- Complete non-GUI suite: 320 PASS
- GUI-only test not executed in this Linux validation container because PySide6 is not installed (`tests/test_r0015_circular_roi_measurement.py`).
- Synthetic `Calibration.ini IsEnabled = 0 1 1 0 0 1 1 1` parses exactly as `(False, True, True, False, False, True, True, True)`.

## Remaining Windows/real-export checks
1. With Show disabled RCV OFF, RCV0/3/4 must be absent from every per-channel graph, legend/list, receiver selector, and cavitation contribution display for the referenced calibration mask.
2. Turning the checkbox ON must restore them without changing enabled-channel values or replay position.
3. Switching Sonication/tab/view must not re-enable disabled channels through cached `chart_state`.
4. Thumbnail slider must reach the final image in each Ax/Sag/Cor/Treatment/Thermal strip.
5. Registration must be visually verified against the real CT/MR export; QA warning must not be confused with proof of correct skull geometry.
