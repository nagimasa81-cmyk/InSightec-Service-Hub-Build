# R0091 Cavitation Intelligence code audit

Confirmed code-level problems:
1. Replay rejected stale CPC by tolerance, but Cavitation Intelligence used nearest CPC and could immediately reintroduce stale Band/RCV data.
2. When no synchronized CPC existed, the visible Replay panel was cleared but `default_cavitation_likelihood` was not, so the dedicated Intelligence page could retain the prior frame's RCV/location.
3. Clicking a historical event row overwrote `default_cavitation_likelihood`, changing shared live state without moving the Replay cursor.
4. Sonication changes cleared CPC/timeline/likelihood but not the MR-correlation object.
5. Event table substituted arbitrary nearest events when none were close to the replay cursor.
6. `SonicationElementMapWidget` contained two `paintEvent()` methods; the first was silently shadowed.

R0091 makes the replay cursor the single authoritative state source, separates historical-event preview from live state, and applies one strict CPC synchronization rule to both Replay and Cavitation Intelligence.
