# R0116zzg7 — Cavitation event gate restore + selected Spectrum cache handoff

- Restores the authoritative Cavitation Event/Status contract: only observed Power Decrease or Safety responses count.
- Vendor Rule Trigger / dump candidate evidence remains visible in dedicated evidence views but cannot create Cavitation Status, Cavitation Severity, or Summary RCA by itself.
- Cavitation Severity now derives only from observed control-response severity and is blank when no event occurred.
- Summary RCA is built only when a confirmed Decrease/Safety cavitation event exists.
- Preserves same-study Spectrum preload context while a different Sonication is prepared instead of clearing already-ready replays.
- Spectrum Dump Analyzer now reuses a Sonication replay already decoded in the shared SpectrumEvidenceRepository (for example by Summary/CI) even if UI preload publication lags behind.
