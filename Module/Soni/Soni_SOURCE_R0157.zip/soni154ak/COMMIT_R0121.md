# R0121 — i18n coverage for R0117b/R0120 UI strings

## Problem
The app's i18n mechanism (`ui_text()` / `localize_qt_tree()`) works by
exact-match lookup in the `UI_TEXT` dictionary -- widget construction code
never has to call `tr()` itself; `localize_qt_tree(root, locale)` walks the
Qt tree and rewrites any `.text()`/`.title()`/tab label/combo item/table
header/tooltip that exactly matches a known English source string. This
means every string introduced in R0117b (chart time-axis window controls)
and R0120 (ZIP password menu action + settings dialog) was silently
English-only in all 6 non-English languages this app ships, since it was
simply never added to `UI_TEXT`.

## Fix
- Added `UI_TEXT` entries (ja, ko, zh_TW, es, th, hi) for every user-visible
  string from R0117b/R0120: "Chart time axis", "Start", "End", the four
  time-axis combo items ("MR acquisition start", "Sonication start",
  "Sonication end", "MR acquisition end"), "Earliest decoded Spectrum
  (pre-irradiation)", the End-combo tooltip, "ZIP Password Settings...",
  the dialog title, its instructional label, "Add", "Remove selected", and
  the menu action's tooltip.
- `ZipPasswordSettingsDialog` is built fresh every time it is opened (it is
  not a permanent MainWindow child present when the language was last
  switched), so it now calls `localize_qt_tree(self, self._locale)` itself
  at the end of `__init__`, using the parent window's current `language`.
- `localize_qt_tree()` does not cover `QDialog.windowTitle()` (only widget
  `.text()`/`.title()`), so the dialog's window title is now set via an
  explicit `ui_text(self._locale, "ZIP Password Settings")` call instead of
  a raw literal.
- Removed an unused `QMessageBox` import from `zip_password_dialog.py`
  noticed while editing this file.

## Known remaining gap (not fixed here, noted for scope)
`QLineEdit.placeholderText()` ("New password…") is not covered by
`localize_qt_tree()` at all (it only handles the attributes listed above).
Extending the sweep to placeholder text would touch every QLineEdit in the
app, which is a larger, separate change; left as English-only for now.

## Tests
`tests/test_r0121_new_ui_strings_i18n_coverage.py`, in the same style as
the existing `test_r0116zp_rich_i18n.py`:
- every new label resolves to a distinct, non-English string in all 6
  locales
- every new label round-trips back to its canonical English source
- the dialog imports and calls `localize_qt_tree`/`ui_text` correctly, and
  sets its window title through `ui_text()`
- the File-menu action exists with the exact literal used as the `UI_TEXT`
  key

All prior i18n tests (`test_r0116zp_rich_i18n.py`,
`test_r0116zz_anatomical_direction_i18n.py`) and all R0120 ZIP-password
tests re-verified passing. `verify_source.py` re-run against the packaged,
re-extracted `Soni_SOURCE_R0121.zip` -> `VERIFY_SOURCE_OK` (exit 0).
