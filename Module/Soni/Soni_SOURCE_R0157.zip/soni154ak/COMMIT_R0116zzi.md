# R0116zzi — Cavitation Intelligence full-space utilization

- Removed the linked-plot maximum-height cap that left a large white band inside the expanding Cavitation Intelligence workspace.
- Linked Cavitation Analysis now consumes the full remaining viewport height.
- Compact single-line summary and temperature labels reclaim vertical space.
- Explanatory note height reduced while full text remains available through the existing UI context.
- Updated legacy regression tests so fixed-height layout cannot be reintroduced.
