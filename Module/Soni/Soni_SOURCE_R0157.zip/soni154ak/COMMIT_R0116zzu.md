# R0116zzu — image toggle / Sonication re-entry race repair

## Reproduction

1. Load an Export and enable **Load images**.
2. Change Sonication while an essential image worker may still be reading RAW data.
3. Turn **Load images** OFF and immediately ON again.
4. R0116zzs could remain visually at **Preparing image workers… 1%** while old and new image-read paths competed.

## Root cause

R0116zzs cancelled the essential worker but immediately cleared its Python references even when the QThread was still running inside a bounded RAW read.  A new OFF→ON request could therefore create another EssentialImageLoadWorker before the previous QThread actually exited.  Sonication staged loading also calls the image navigator, creating a second start path.

## Repair

- Added `_image_load_cycle_generation` to invalidate stale delayed callbacks.
- Added single-owner `_essential_image_active_cycle` / `_essential_image_pending_cycle` state.
- A running essential QThread is retained until `thread.finished`.
- A replacement reader is started only after the previous QThread has really exited; GUI thread never calls `wait()`.
- Same-cycle starts are coalesced.
- Sonication change retires the old reader before assigning the new `self.current`.
- OFF invalidates the active cycle and worker generation.
- ON and staged Sonication navigator share the current cycle instead of launching duplicate readers.
- Progress explicitly reports `Finishing previous image read…` during asynchronous retirement.

No Reference/Planning bulk decode was reintroduced.
