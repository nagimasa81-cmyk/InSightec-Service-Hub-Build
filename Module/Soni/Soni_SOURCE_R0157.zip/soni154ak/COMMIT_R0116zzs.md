# R0116zzs — deterministic essential image loader / 62% stall root-cause repair

## Root cause

The R0116zzr initial image path did move numeric RAW decoding off the GUI thread, but it still started Treatment MR and Thermal as two independent QThreads. Each worker entered one monolithic `np.fromfile()` call per RAW and emitted no progress until that call returned. If one Thermal RAW read stalled, the UI therefore remained on the last Treatment-MR progress message (for example `treatment_mr 11/11`) even though the actual blocked operation was a later/parallel Thermal RAW read. The concurrent disk streams also made the displayed numerator nondeterministic and hid the identity of the blocking file.

## Repair

- Initial `Load images` now uses one ordered `EssentialImageLoadWorker` for the current Sonication only.
- Decode order is deterministic: Treatment MR first, then Thermal.
- Every RAW records `starting -> preflight(size) -> read -> ready/SKIP` to `image_load_trace.log` in the extracted workspace.
- Every progress update includes the exact RAW filename and role.
- Each individual RAW decode is isolated by a bounded daemon decode boundary (30 s circuit breaker). A malformed or blocked RAW is skipped rather than stranding all remaining images. This is a safety circuit breaker in addition to, not instead of, the structural worker repair.
- Reference/Planning assets remain outside the essential workload and are not bulk-decoded.
- QPixmap/QIcon creation remains on the GUI thread only after numeric decode, and thumbnail-strip materialization remains incremental.
- Legacy Treatment-MR/Thermal workers are retained only as compatibility/on-demand helpers and are no longer both launched by the initial blocking image-load path.

## Expected progress semantics

For 11 Treatment MR + 10 Thermal frames, progress deterministically advances through MR 1..11 and then Thermal 1..10. A slow/bad Thermal file is explicitly named instead of leaving the dialog apparently frozen at Treatment MR 11/11.
