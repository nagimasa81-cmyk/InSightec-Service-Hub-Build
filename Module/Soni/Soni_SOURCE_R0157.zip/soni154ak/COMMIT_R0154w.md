# R0154w — R0154v triple-check hardening

- Preserves original FFT `acquisition_cycle` evidence when repairing only the MR-axis display timing; prevents repaired display positions from contaminating cavitation/rule cycle correlation.
- Keeps `frame_mr_time_override_s` as the only timing override consumed by Spectrum/Spectrogram/Band Energy/CI display axes.
- Removes Python bytecode and pytest caches from the distributable SOURCE ZIP to eliminate stale-code ancestry risk.
- Adds regression coverage that rejected collapsed timing does not overwrite decoder cycle evidence.
