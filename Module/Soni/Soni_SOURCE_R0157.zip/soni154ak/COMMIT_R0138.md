# R0138 — Fix: AcousticControlTrend.power_percent/score_percent went all-NaN
# once mr_sonication_start_s is correctly non-zero

## Reported symptom
"Power/Score%" sometimes not correctly reflected after dropping a ZIP.

## Root cause — a domino effect from the earlier mr_sonication_start_s fix
`AcousticControlService.trend_for_sonication()` builds a resampling grid,
`target_t`, used to produce `power_percent`/`score_percent` (the series
`main_window.py`'s `_apply_acoustic_trend` checks to decide whether *any*
measured Power % exists at all -- if every value is NaN, it replaces the
curve with "Measured Power % unavailable; planned power ... W").

`target_t` was built as a bare `linspace(0.0, replay_duration_s,
replay_count)`. Meanwhile `vendor_t`/`source_t` (the vendor PowerGraph and
control-log time axes actually holding the measured data) are explicitly
shifted onto the MR-acquisition-absolute clock a few lines later via `+
mr_sonication_start_s`. As long as `mr_sonication_start_s` was (incorrectly)
`0.0` -- the R0116zzg23-era bug fixed in `COMMIT_R0123.md` -- `target_t` and
`vendor_t` coincidentally shared the same `[0, duration]` domain and this
was invisible. Once that timeline bug was fixed and `mr_sonication_start_s`
correctly resolves to several seconds, `target_t` (still anchored at 0) and
`vendor_t` (now starting several seconds later) stopped overlapping at all;
every `np.interp(target_t, vendor_t, vendor_power, left=np.nan,
right=np.nan)` call fell into the `left=np.nan` branch for every point.

Verified directly against the real Brain650 export used throughout this
investigation:

| Sonication | power_percent finite (before) | power_percent finite (after) |
|---|---|---|
| 1 | 0/34 | 33/34 |
| 2 | 0/33 | 30/33 |
| 3 | 0/34 | 32/34 |
| 4 | 0/34 | 32/34 |
| 5 | 0/12 | 10/12 |

`plot_power_percent`/`plot_time_s` (the series the chart actually draws)
already had real, correct values throughout -- only the separate
`power_percent` series used for the "is any measured data present at all"
availability check was affected, which is why the symptom looked like
"sometimes the % readout/status is wrong" rather than "the chart is always
empty".

## Fix
`target_t` now starts at `mr_sonication_start_s` (the same absolute-clock
anchor as `vendor_t`/`source_t`) instead of `0.0`:
```python
mr_start_offset = float(mr_sonication_start_s or 0.0)
target_t = np.linspace(mr_start_offset, mr_start_offset + max(replay_duration_s, 0.0), max(replay_count, 1))
```

## Second reported symptom (Spectrum Dump Analyzer)
"Opening Spectrum Dump Analyzer looks like data loaded, but nothing is
actually reflected" was also reported. Investigated:
- Data layer verified correct with real data: `CpcHydrophoneReplay` frames
  decode normally, `mr_sonication_start_s`/`mr_frame_times_s` are correct,
  `reconstruction_support()`/`subharmonic_events()` behave as expected.
- The GUI handoff path (`_open_hydrophone_window` ->
  `accept_preloaded_context`/`prepare_for_background_preload` ->
  `load_sonication` -> `_continue_preloaded_publish`) is already heavily
  hardened against stale-context/race bugs across R0116zb/zg/zh/zj/zk/
  zzg9/R0134-R0137, and no equivalent "domain mismatch" bug (the pattern
  that caused the Power/Score symptom above) was found in
  `_canonical_mr_axis_points`/`_apply_selected_time_window`/
  `_draw_band_energy`'s own time-axis construction.
- Could not be reproduced or further isolated without a live Qt session
  (PySide6 is not installed in this environment). Needs either a GUI
  reproduction or a more specific detail (e.g. does the status/note text
  say "ready" while the plot area is blank, or does the frame counter
  advance while the curve stays empty) to continue narrowing this down.

## Tests
`tests/test_r0138_acoustic_trend_absolute_clock_alignment.py`:
- static: `target_t` construction uses `mr_start_offset`, and the old
  buggy `linspace(0.0, ...)` construction is gone from this function.
- behavioral: reproduces the exact failure shape (mr_sonication_start_s >
  replay_duration_s) and proves both that the *old* construction produces
  0 finite points and the *new* one produces the full expected count.

Existing related tests (`test_r0093_readability_and_power_axis.py`,
`test_r0087_powergraph_source.py`, `test_r0116zl_authoritative_session_alignment.py`,
`test_r0135_preload_power_cavitation_hardening.py`,
`test_r0069_post_sonication_acoustic_gate.py`) re-verified passing.
`verify_source.py`: PASS.
