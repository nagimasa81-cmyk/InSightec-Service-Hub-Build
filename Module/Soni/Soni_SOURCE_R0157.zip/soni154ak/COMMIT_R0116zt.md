# R0116zt — Thermal × Cavitation Science Foundation

- Adds Thermal response as a first-class outcome alongside Cavitation burden.
- Adds four-zone Thermal × Cavitation outcome classification.
- Adds What-if priority text focused on preserving heating while reducing cavitation.
- Thermal response score is descriptive/comparative, not a clinical efficacy threshold.
- Keeps thermal preconditioning as a separate root-cause factor.
