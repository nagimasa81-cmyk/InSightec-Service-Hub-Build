# R0116zzg12 — Authoritative cavitation response grouping + analyzer presentation repair

- Validated against provided export `17-00-24_ANx`: Sonication6 maps to Acquisition session 12 / Spectrum 19:01:50 and contains 30 Decrease rule rows + 5 Safety rule rows, but only 25 unique physical response cycles, with one confirmed `HALTED BY CAVITATION` stop.
- Canonical Summary no longer counts multiple rule rows in the same acquisition cycle as separate cavitation events.
- A confirmed safety halt is surfaced explicitly as `CAVITATION HALT`.
- Analyzer funnel distinguishes evidence rows from unique physical controller responses.
- Control Timeline presentation is compacted so plot/data are not pushed out by an empty table area.
- Carries forward R0116zzg11 and all R0116zzg9/g10 Spectrum publish/cache fixes.
