# R0116zzg11 — Sonication Summary double-click navigation-only

- Sonication Summary double-click remains the canonical select/load + Replay jump action.
- Suppresses the global readability full-text dialog for the Sonication Summary table only.
- Tooltip/readability behavior remains available without a modal popup.
- Prevents two cellDoubleClicked handlers from firing for Summary rows.
