# R0116v — Unified Spectrum Source Binding

- Unified Spectrum Dump Analyzer Sonication loading with the candidates already discovered from the loaded Export.
- Added deterministic Sonication -> CPC SpectrumDumps mapping; explicit SonicationN folder identity wins.
- SpectrumMsg is never used as the physical 8-channel CPC source.
- `load_sonication()` now prefers the mapped candidate and calls `build_direct(fft, raw)` instead of relying only on `package.cpc_spectrum_files`.
- Legacy package mapping remains as a compatibility fallback only.
- Added visible source connection audit: Discovered / CPC / Mapped / Decoded / route.
- Zero decoded frames are now surfaced as an explicit connection error instead of a normal empty chart.
- Added focused regression tests for mapping and source-route precedence.
