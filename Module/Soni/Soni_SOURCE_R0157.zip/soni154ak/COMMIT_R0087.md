# R0087 — PowerGraph / Score Timeline Fix

- Decode `spotsonicationdata.xml` `powergraph` as whitespace-tolerant little-endian float32 `(time_s, power_ratio)` pairs.
- Validate `powergraphsize` and convert the exported ratio to Power %.
- Use the native PowerGraph timeline for the Power/Score chart instead of plotting the Acquisition pre-roll as if it were sonication time.
- Align Acquisition cavitation score to PowerGraph by measured power-trajectory matching, then trim score to the actual sonic duration.
- Keep frame-sampled telemetry for replay cards while rendering the chart from native PowerGraph points.
- Regression coverage includes split-hex decoding and a 7.5 s Acquisition pre-roll alignment case.
