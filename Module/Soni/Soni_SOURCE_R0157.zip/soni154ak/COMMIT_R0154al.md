# R0154al — Brain220/Brain650 Umbrella vertical orientation

## Reported regression
Umbrella vertical orientation was opposite between the Brain220 and Brain650 families. The current Brain220 orientation is the validated/correct reference.

## Root cause
`SonicationElementMapWidget._canonical_umbrella_points()` unconditionally inverted Element Z for every acoustic family. Real Brain220 and Brain650 element geometry use opposite native-Z handedness, so applying the Brain220 conversion to Brain650 mirrored the complete 3-D bowl vertically.

## Fix
- Preserve Brain220 exactly as-is: 180–320 kHz uses the existing Z inversion.
- Brain650: 550–750 kHz keeps native Z (no extra inversion).
- Pass the active Sonication/package frequency and acoustic profile into the element-map widget before installing geometry.
- Keep the family correction in one canonical geometry-normalisation function only.
- Do not add any family-specific flip in Front XZ, Side YZ, Perspective, status-channel projection, or focus-marker projection; all use the same canonical geometry path.
- Unknown/conflicting family keeps the previous Brain220-safe behavior rather than guessing.

## Verification
- Python source compile: PASS.
- New family orientation unit gates: 4/4 PASS.
- Existing Umbrella / thermometry / Brain220 contract gates: 19/19 PASS.
- Legacy basis gate updated to verify both family conventions without importing Qt/pyqtgraph.
