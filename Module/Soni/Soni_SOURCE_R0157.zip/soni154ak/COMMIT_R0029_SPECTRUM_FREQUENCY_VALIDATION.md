# R0029 Spectrum Frequency Validation

Real-data validation source: `17-00-24_ANx(2).zip`.

## Evidence
- CPC `Acquisition.ini`: `f1ForGraph=250000`, `f2ForGraph=750000`.
- CPC FFT header: sample rate 2,000,000 Hz, 8 channels, 16,384 total samples, sonication frequency 670,000 Hz.
- SpectrumMsg contains 47 frames and 376 explicit 256-bin graph records (47 x 8).
- Per-record metadata stores graph start=250000 Hz and spacing=1953 Hz.

## Before fix
- SpectrumMsg synthetic axis used `0 .. max(f0*2.2, f0+200k)` and placed the main peak around 785-798 kHz.
- CPC `_FFT` used `0 .. Fs/2`, which did not match the workstation graph presentation window.

## After fix
- SpectrumMsg axis: 250.000 .. 748.015 kHz, 1.953 kHz/bin.
- Main-frequency peak: 669.895 kHz for a 670 kHz sonication.
- Half-frequency bin: 335.932 kHz.
- CPC `_FFT` axis: 250.000 .. 748.047 kHz, 1.953125 kHz/bin from Acquisition.ini.
- 670 kHz target bin: 669.922 kHz; half-frequency bin: 335.938 kHz.
