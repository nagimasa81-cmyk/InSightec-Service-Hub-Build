# R0154ai

- Includes the attached SpectrumMsg stream in async replay/cache identity, so a late full-timeline handoff invalidates the earlier short CPC-derived cache.
- Shows SpectrumMsg aggregate Band0 through its full timestamp range, explicitly separated from physical per-RCV CPC evidence.
- Parses Power/Score telemetry when Calculated Energy and Bottom Limit are emitted on separate log lines.
- Uses the same robust hottest-three-pixel temperature statistic in Cavitation Intelligence and Sonication Summary.
- Computes series DQA X/Y from axial and Z from sagittal same-raster observed-minus-planned focus measurements; the sagittal phantom baseline is used only for tilt.
- Runs Import Diagnostics ZIP generation off the GUI thread and exposes an Exporting state and success/failure result.
