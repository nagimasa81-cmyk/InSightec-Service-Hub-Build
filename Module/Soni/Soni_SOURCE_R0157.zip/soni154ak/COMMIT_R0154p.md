# RC7.10-R0154p

## Fixes
- Repeated ZIP load lifecycle: cancellable Acquisition log scan + per-workspace parse cache.
- DQA slice-to-metadata binding corrected for Brain220 DQA-Axial/DQA-Sagittal and Brain650 haste_DQA_tra/haste_DQA_sag stacks.
- DQA stack-centre coordinate model replaces first-slice/lower-line subtraction.
- Brain220 DQA classification uses explicit WS multi-target/steering evidence before numeric judgement.

## Real-export checks
- 42110 Brain220: S1/S3/S5/S6/S7 multi-target excluded; S4 steering excluded; S2 evaluates near phantom centre.
- 4267 Brain650/690: S4 steering excluded; repeated centre sonications remain evaluable.
- 17-00-24_ANx: 24.7 MB Acquisition log path exercised; repeated consumers reuse parsed telemetry and stale workers can cancel during scan.
