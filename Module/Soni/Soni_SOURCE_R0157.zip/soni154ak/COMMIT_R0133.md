# R0133 — Real-data MR annotation orientation fix

- Validated against 17-00-24_ANx/MriImageParams.xml TMAP-ME rows.
- Displayed image orientation is intentionally unchanged.
- Screen X uses exported COL direction; screen Y uses exported ROW direction.
- Frequency encoding uses raw ROW/COL: COL horizontal, ROW vertical.
- Side direction labels moved to 30% image height to avoid the center-right physical ruler.
