# R0116zzv — Cross-cutting async lifecycle hardening

## Purpose
Prevent Sonication Replay Engine freezes and stale-data overwrites during image/data/Sonication switching, Spectrum processing, list/chart refresh, and repeated UI changes.

## Key implementation
- Preserves R0116zzu essential image single-owner / latest-request behavior.
- Spectrum source discovery and decode remain background-owned.
- Added `SpectrumSecondaryWorker` for CPU-heavy secondary Spectrum products:
  - spectrogram calculation
  - Band Energy calculation
  - standalone cavitation evidence analysis
- Secondary Spectrum work is single-owner with latest-pending semantics and stale replay/request suppression.
- Removed runtime `QApplication.processEvents()` event-loop pumping from production sources.
- No production `QThread.wait()` / `QThread.terminate()` calls remain.
- Hidden 1024-element table now has zero rows/items.
- Visible 1024-element table is populated in 96-row `QTimer` batches with generation invalidation, so a stale snapshot cannot finish populating over a newer one.
- Existing cache-only/deferred-panel protections from the R0116zzv audit remain in place for Planning/Reference, thermometry, CPC/Spectrum, RCA and secondary panel workflows.

## Safety / stale-result rules
- Old worker results are rejected by request id and replay identity.
- A running secondary Spectrum worker is cancelled logically and its thread is requested to quit; only the latest pending request is launched after teardown.
- Element table chunk callbacks are invalidated when the table is hidden or a new population generation starts.

## Compatibility
- Primary Spectrum frame is still published before secondary analysis completes.
- Existing progress wording retained where regression contracts depend on it.
