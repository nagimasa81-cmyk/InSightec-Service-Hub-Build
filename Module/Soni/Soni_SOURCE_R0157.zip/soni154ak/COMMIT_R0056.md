# R0056 — Sonication Element Map Workspace

## Added
- New **Sonication Elements** tab, separate from **Cavitation Intelligence**.
- Reads the decoded 1024 transmit-element snapshots from the Sonication log.
- Visualizes element values with two layouts:
  - **Tile 16×64**
  - **Umbrella 16-blade**
- Supports color / gradient display for:
  - **Logical amplitude**
  - **Logical phase (rad)**
  - **Logical phase (deg)**

## Notes
- This workspace is explicitly separate from cavitation receivers **RCV0–RCV7**.
- The visual map is a review / usability representation, not a claim of exact proprietary workstation geometry.
