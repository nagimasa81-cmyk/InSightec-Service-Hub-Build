# R0116zzg — Spectrum Analyzer first-show screen-fit stabilization

- Fixes the first-open Spectrum Dump Analyzer layout where the pinned bottom replay controls could be below the usable desktop until maximize/restore.
- Re-fits after showEvent using the real native `frameGeometry()` (including Windows title bar/non-client frame), not only the client-size geometry.
- Activates the content/tab layouts before recalculating vertical budgets.
- Performs bounded settle passes at 0/60/180 ms so late native-frame and source/tab sizeHint changes cannot recreate the initial clipping.
- Keeps normal resize/maximize behavior and the existing no-main-scrollbar collapsed-mode contract.
