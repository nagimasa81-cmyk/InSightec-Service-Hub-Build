# R0146 — Known-good data-loading restoration + passive screen access

- Base reset to R0144, the last build confirmed on real hardware to improve Spectrum Dump Analyzer loading.
- Import, ReplayPackage, Spectrum mapping, Acquisition_Brain selection, CPC mapping, decoders and service code are byte-identical to R0144.
- Reapplies only passive UI accessibility changes that do not connect to tab/data callbacks:
  - Spectrum Analyzer graph pages yield vertically and retain `ScrollBarAsNeeded`.
  - Cavitation Intelligence keeps a vertical `ScrollBarAsNeeded` escape path.
- R0145 main-window `currentChanged` / `resizeEvent` dynamic graph-budget callbacks are intentionally removed to eliminate load-time UI re-entrancy risk.
