# R0149 — Movement Detection + per-Sonication steering binding

- Movement Detection now binds researchparameters.xml bcorrectshift + correctshiftx/y/z.
- X/Y/Z maps to RL/AP/SI; Summary displays RL/SI/AP as R/L, S/I, A/P.
- bcorrectshift=0 is treated as not measured even when numeric shifts are zero.
- Sonication_Brain selection is treatment-time aware, matching the R0143 Acquisition_Brain policy.
- Canonical setup steering XYZ is persisted per Sonication.
- Elements reports authoritative per-Sonication steering before phase-derived validation.
- Setup matching accepts both direct duration equality and legacy +3 s envelope exports.
