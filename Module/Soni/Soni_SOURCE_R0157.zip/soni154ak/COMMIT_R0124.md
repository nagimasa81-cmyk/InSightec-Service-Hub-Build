# R0124 — Plot mouse interaction regression repair

## Triple-check findings
- `Cavitation Events > Lock plot view` was introduced in R0116n with **default ON**. That calls `ViewBox.setMouseEnabled(False, False)` and disables the context menu for multiple analysis charts. This is the direct regression from the earlier mouse-operable behavior.
- Standard Spectrum Dump Analyzer PlotWidgets otherwise inherit pyqtgraph defaults, but the expected interaction contract was implicit and therefore vulnerable to later UI hardening. R0124 makes it explicit for every standard Analyzer plot.
- The Vendor lower chart has a transparent secondary `ViewBox` for the right CGA axis. That overlay is display-only and now has mouse handling disabled so the base plot exclusively owns pan/zoom gestures.
- Replay Temperature, Current Spectrum, and Power/Score charts are also explicitly mouse-enabled/menu-enabled to prevent the same class of regression outside the Analyzer.

## Behavior
- Default: left-drag pans, wheel zooms, right-click pyqtgraph menu is available.
- `Lock plot view` remains available as an **opt-in** safety feature only on Cavitation Events.
- Canonical MR time-axis selection still defines reset/default X ranges; manual inspection is not disabled by that range policy.

## Third-pass persistence check
- R0123 time-axis hardening reapplied `setXRange()` on redraw/tab materialization. Even when mouse input itself was enabled, that could immediately snap a user-pan/zoom back to the canonical MR window and make the chart feel locked.
- R0124 listens to `ViewBox.sigRangeChangedManually` and preserves manual ranges across ordinary redraws.
- Manual ranges are intentionally cleared only for: new replay/Sonication adoption, explicit Chart time-axis selection change, or Reset view.
