# R0116zzg11 — Build identity / exact-cache freshness hardening

- Carries forward the R0116zzg9 Analyzer full-publish repair.
- Corrects stale R0116zzg8 release metadata that remained inside the R0116zzg9 SOURCE package.
- Corrects stale R0116zf Windows file-description / standalone release naming in both Nuitka build scripts.
- Extends verify_source.py so VERSION, version.json, constants, build contract and build scripts must agree before compilation.
- Intended to be paired with the V7 workflow, where reuse_existing may reuse only an exact completed artifact signature; a cache miss forces compilation of the currently resolved SOURCE ZIP.
