# R0116zf — Spectrum Decode Recovery / Nonblocking FFT Pipeline

## User-visible failure reproduced
Spectrum Dump Analyzer discovered and listed CPC Spectrum sources, but opening the selected source stayed visually at 55% and no real FFT data reached the charts. The standalone Open ZIP path behaved the same way.

## Root causes
1. Standalone `load_dump_candidate()` called `HydrophoneReplayService.build_direct()` synchronously on the Qt GUI thread. Progress callbacks therefore could not repaint reliably while the decode was running; the last painted state was typically 55%.
2. `_decode_fft_payload()` scanned the entire decompressed FFT container with a Python loop at every 4-byte offset. Large treatment dumps could require millions/tens-of-millions of Python iterations before frames were built.
3. The primary Spectrum graph was unnecessarily gated behind Acquisition_Brain numerical validation. A slow treatment log could delay display even after FFT data had already been structurally decoded.

## Changes
- Added `SpectrumDecodeWorker` + dedicated `QThread` for standalone/loaded-workspace CPC Spectrum decode.
- Worker progress is delivered to the GUI with Qt signals; decode no longer blocks the event loop.
- Replaced Python full-file 4-byte marker scan with an equivalent NumPy uint32 candidate pass, preserving the validated 4-byte-aligned marker contract.
- Added `include_vendor_validation=False` fast-primary path for interactive Spectrum opening. FFT/RCV data, spectrogram and band energy are published without waiting for Acquisition_Brain runtime validation.
- Zero-frame decodes are hard failures with the selected FFT/RAW filenames and decoder note shown to the user; the UI no longer reports Ready for an empty replay.
- Removed the old unconditional `Ready` transition immediately after starting a manual Spectrum decode. Ready is emitted only after decoded frames are actually installed in the Analyzer.

## Regression
- Existing CPC decoder/vendor/source-binding tests retained.
- Added R0116zf tests for vectorized marker discovery, fast-primary decode, and off-GUI-thread standalone decode wiring.

## Additional hotspot removed
- `_decode_embedded_band_energy_table()` no longer scans from the final FFT group to EOF in a Python `range(..., step=2)` loop when no next group exists.
- `uint32 band_count=4` candidates are found by `bytes.find()` and then validated with the unchanged 8-row/36-byte structural contract.
- Synthetic 64 MiB final-frame stress case improved from ~23.95 s to ~0.264 s in this environment while still decoding the same validated frame.
