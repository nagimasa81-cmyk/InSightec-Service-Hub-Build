# R0154ac

- DQA is one series-common result because XD is mechanically fixed during DQA.
- X/Y are aggregated from Axial observed-minus-planned focus measurements only.
- Z is aggregated from Sagittal observed-minus-planned focus measurements only.
- Tilt is restored from the Sagittal phantom baseline; image horizontal is 0 degrees.
- Steering/multi-target shots cannot define the common centre result.
- Sonication Summary renders one vertically-spanned DQA cell for the full series.
- Generic 650/690-kHz SpotData is no longer mislabeled as a target voxel; Target voxel(s) is Brain220-only.
