# R0021a Triple Check

## Check 1 — Frequency resolution
- Sonication-local candidates are accepted only from 550,000 to 700,000 Hz.
- Xd_####.ini fallback uses the same valid range.
- Xd_0000.ini remains excluded.
- 0.800 MHz rejection and 0.630 MHz acceptance tests pass.

## Check 2 — Hover popup implementation
- R0021 relied primarily on repeatedly refreshed native QToolTip behavior.
- R0021a adds a persistent chart-local QLabel popup for Spectrum, Power/Score, and Temperature charts.
- Native QToolTip remains only as a secondary fallback.
- Popup hide paths are connected when the pointer leaves the chart or data is unavailable.

## Check 3 — Source/package integrity
- Python compileall: PASS.
- R0020/R0021 targeted regression tests: 8 PASS.
- verify_source.py: VERIFY_SOURCE_OK.
- Full PySide6 UI runtime test was not executable in this Linux validation environment because PySide6 is not installed; actual Windows EXE hover behavior still requires real-machine confirmation.
