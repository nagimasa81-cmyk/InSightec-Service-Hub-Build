# Spectrum Dump Analyzer — Time Axis Triple Check (R0116zzg21)

## Check 1 — Coordinate ownership
- Canonical time owner: Treatment MR timeline.
- MR acquisition start = 0 s.
- Sonication start/end = `mr_sonication_start_s` / `mr_sonication_end_s` from the selected Sonication binding.
- MR acquisition end = `mr_timeline_duration_s`.
- CPC FFT and RAW/history data are mapped into this MR coordinate before drawing.
- Spectrum tab remains frequency-domain on X; only its current-frame time annotation uses MR time.

## Check 2 — Cross-tab draw audit
Time-domain charts now share the same selected X window:
- Measurement Timeline / Raw A/D
- Spectrogram
- Band Energy
- CGA Cavitation / Vendor Rules energy/power charts
- Cavitation Events Control Timeline
- Cavitation Hydrophone × Band activity heatmap

The following are intentionally not time-axis-controlled:
- Spectrum: Frequency (MHz)
- Probable Location: spatial coordinates
- Measure / Statistics: table/statistics view

Removed inconsistencies:
- Spectrum timeline no longer re-zeroes at first CPC frame.
- Hydrophone × Band heatmap no longer uses FFT snapshot number for X.
- Raw snapshot data no longer uses plain sample index for X; samples are placed at current MR time + sample offset.
- Spectrogram labels use MR acquisition time.

## Check 3 — Lifecycle / UI override audit
Legacy payload-auto-fit behavior could overwrite the time range after:
- tab change
- initial show/layout settle
- reset view
- secondary data publication

Those paths now reapply the selected canonical MR window rather than silently reverting to per-payload extents.

## New user control
Start selector:
- MR acquisition start (default)
- Sonication start

End selector:
- Sonication end
- MR acquisition end (default)

Default: MR acquisition start -> MR acquisition end.

## Regression status
- Spectrum g16-g20 focused regression suite: PASS.
- Full suite excluding the one PySide6-only GUI test unavailable in this Linux environment: 775 PASS.
- `verify_source.py`: PASS.
- Python compile: PASS.
