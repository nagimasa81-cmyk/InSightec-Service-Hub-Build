# R0116q — Cavitation Dynamic State Sync

- Fixes Probable Location remaining pinned to a previously selected control event during replay.
- Introduces explicit selected-event state instead of relying on QTableWidget.currentRow(), which remains set after clearSelection().
- Separates the red selected-event cursor from the white replay/current-FFT cursor by default.
- Adds `Sync replay to selected event` (default OFF) for optional event-to-replay jumps.
- Control Timeline marker/row clicks always open the exact Why popup; the vendor-chart Why checkbox remains applicable to vendor-chart clicks only.
- Adds Event-list self-healing/integrity verification after event-loop refresh and fixed row heights for visibility.
- Normal replay clears stale selected-event state so Probable Location follows the current FFT snapshot and updates contribution values.
