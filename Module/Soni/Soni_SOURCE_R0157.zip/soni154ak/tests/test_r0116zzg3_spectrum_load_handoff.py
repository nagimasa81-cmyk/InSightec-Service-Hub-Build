from pathlib import Path

SRC = Path(__file__).parents[1] / "src" / "ui" / "hydrophone_window.py"
TEXT = SRC.read_text(encoding="utf-8")

def test_primary_publish_is_deferred_after_decode():
    assert "Spectrum decode complete — handing off to display…" in TEXT
    assert "QTimer.singleShot(1, lambda g=publish_generation" in TEXT

def test_exclusive_dialog_finishes_before_primary_render():
    block = TEXT.split("Spectrum decode complete — handing off to display…", 1)[1][:900]
    assert "dlg.finish()" in block
    assert "_publish_primary_replay_after_decode" in block

def test_deferred_publish_keeps_irradiation_end_target():
    assert "target=max(0, min(int(index), count-1))" in TEXT
    assert '"Publishing irradiation-end FFT frame…" if target else "Publishing first FFT frame…"' in TEXT

def test_secondary_analysis_stays_after_primary_publish():
    block = TEXT.split("def _publish_primary_replay_after_decode", 1)[1][:1800]
    assert "self._set_frame_primary_only(target)" in block
    assert "self._queue_secondary_analysis()" in block
