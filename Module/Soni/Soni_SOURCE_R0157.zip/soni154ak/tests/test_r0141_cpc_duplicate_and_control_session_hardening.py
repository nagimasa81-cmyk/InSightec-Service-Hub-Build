
from pathlib import Path
from types import SimpleNamespace

from src.services.spectrum_dump_import_service import SpectrumDumpImportService, SpectrumDumpCandidate
from src.services.cavitation_control_timeline_service import CavitationControlTimelineService


def _candidate(path: Path) -> SpectrumDumpCandidate:
    return SpectrumDumpCandidate(
        label=path.name,
        raw_path=path,
        fft_path=None,
        relative_path=str(path),
        family="CPC Spectrum",
    )


def test_r0141_byte_identical_nested_cpc_copies_are_deduplicated(tmp_path):
    a = tmp_path / "outer" / "Spectrum_12_00_00_0000.dmp"
    b = tmp_path / "nested__expanded" / "Spectrum_12_00_00_0000.dmp"
    c = tmp_path / "outer" / "Spectrum_12_00_01_0000.dmp"
    for p in (a, b, c):
        p.parent.mkdir(parents=True, exist_ok=True)
    a.write_bytes(b"same-spectrum-payload")
    b.write_bytes(b"same-spectrum-payload")
    c.write_bytes(b"different-spectrum-payload")

    service = SpectrumDumpImportService()
    out = service.deduplicate_content_equivalent_candidates(
        [_candidate(a), _candidate(b), _candidate(c)]
    )
    assert len(out) == 2
    assert {x.primary_path.read_bytes() for x in out} == {
        b"same-spectrum-payload",
        b"different-spectrum-payload",
    }


def test_r0141_control_timeline_accepts_setinitial_session_start_variant(tmp_path):
    log = tmp_path / "Acquisition_Brain_001.txt"
    log.write_text(
        "\n".join([
            "12:00:00:000 StartSpectrumMeasurement: SetInitial PowerRatios",
            "12:00:00:010 Set: ExciterPower = 100, ExPowerRatio = 1.0",
            "12:00:01:000 Decrease Power Rule no. 1 : Calculated Energy: < 2.0 > Calculated Top Energy limit: < 1.0 >",
            "12:00:01:010 Set: ExciterPower = 90, ExPowerRatio = 0.8",
            "12:01:00:000 StartSpectrumMeasurement: SetInitial PowerRatios",
            "12:01:00:010 Set: ExciterPower = 100, ExPowerRatio = 1.0",
            "12:01:01:000 Safety Rule no. 1 : critical",
            "12:01:01:001 Calculated Energy: < 9.0 >",
            "12:01:01:002 Critical Energy: < 5.0 >",
            "12:01:01:010 Set: ExciterPower = 0, ExPowerRatio = 0.0",
        ]),
        encoding="utf-8",
    )
    service = CavitationControlTimelineService()
    timeline = service.parse(
        tmp_path, None, preferred_session_index=1,
        mr_timeline_duration_s=5.0,
    )
    assert timeline.source_log == log
    assert timeline.session_index == 1
    assert any(e.family == "Safety" for e in timeline.events)
    assert any(e.counts_as_cavitation for e in timeline.events)
