from pathlib import Path

from src.services.sonication_metadata_service import SonicationMetadataService

ROOT = Path(__file__).resolve().parents[1]
PANEL = (ROOT / 'src/ui/image_panel.py').read_text(encoding='utf-8')
MAIN = (ROOT / 'src/ui/main_window.py').read_text(encoding='utf-8')


def _row(row_vec, col_vec, freq):
    return {
        'rowdirectcosrasx': row_vec[0], 'rowdirectcosrasy': row_vec[1], 'rowdirectcosrasz': row_vec[2],
        'coldirectcosrasx': col_vec[0], 'coldirectcosrasy': col_vec[1], 'coldirectcosrasz': col_vec[2],
        'freqdirection': freq,
        'topleftcoordr': 0, 'topleftcoorda': 0, 'topleftcoords': 0,
        'imgmatrixx': 256, 'imgmatrixy': 256, 'pixsizex': 1, 'pixsizey': 1,
    }


def test_real_export_axial_fixture_maps_col_to_screen_x_row_to_screen_y():
    # 17-00-24_ANx / MriImageParams.xml / Sonication 1 TMAP-ME:
    # ROW=(0,-1,0), COL=(-1,0,0), Frequency=ROW.
    g = SonicationMetadataService._image_annotation_geometry(_row((0,-1,0), (-1,0,0), 'ROW'))
    assert g['Top Direction'] == 'A'
    assert g['Bottom Direction'] == 'P'
    assert g['Left Direction'] == 'R'
    assert g['Right Direction'] == 'L'


def test_real_export_sagittal_fixture_maps_col_to_screen_x_row_to_screen_y():
    # Same export / Sonication 2 TMAP-ME: ROW=(0,0,-1), COL=(0,-1,0).
    g = SonicationMetadataService._image_annotation_geometry(_row((0,0,-1), (0,-1,0), 'ROW'))
    assert g['Top Direction'] == 'S'
    assert g['Bottom Direction'] == 'I'
    assert g['Left Direction'] == 'A'
    assert g['Right Direction'] == 'P'


def test_real_export_coronal_fixture_and_col_frequency_is_horizontal():
    # Same export / Sonication 3 TMAP-ME: ROW=(0,0,-1), COL=(-1,0,0), Frequency=COL.
    g = SonicationMetadataService._image_annotation_geometry(_row((0,0,-1), (-1,0,0), 'COL'))
    assert g['Top Direction'] == 'S'
    assert g['Bottom Direction'] == 'I'
    assert g['Left Direction'] == 'R'
    assert g['Right Direction'] == 'L'
    assert "freq_encoding == 'COL'" in PANEL
    assert "freq_encoding == 'ROW'" not in PANEL  # ROW is the else/vertical branch


def test_frequency_marker_uses_preserved_row_col_not_anatomical_axis_matching():
    assert '"frequency_encoding"' in MAIN
    assert 'summary.get("Frequency Encoding"' in MAIN
    assert "freq_encoding = str(self._data.get('frequency_encoding')" in PANEL
    assert "if freq_encoding == 'COL'" in PANEL
    assert "freq_axis == lr_axis" not in PANEL
    assert "freq_axis == tb_axis" not in PANEL


def test_side_annotations_are_not_centered_on_ruler_height():
    assert "h * 0.30" in PANEL
    assert "margin, h / 2, self._data.get('left')" not in PANEL
    assert "w - margin, h / 2, self._data.get('right')" not in PANEL


def test_image_pixels_are_not_rotated_or_transposed_for_annotation_fix():
    # Fix is metadata-to-screen mapping only. Do not mutate main image orientation.
    assert 'np.rot90' not in PANEL
    assert 'np.transpose' not in PANEL
