from pathlib import Path
SRC = Path(__file__).parents[1] / 'src' / 'ui' / 'hydrophone_window.py'
text = SRC.read_text(encoding='utf-8')

def test_fft_range_dropdown_restored():
    assert 'self.raw_fft_range_combo = QComboBox()' in text
    for label in ('Mouse drag','Visible chart range','MR start → Sonication start','Sonication start → Sonication end','MR start → MR end'):
        assert label in text
    assert 'def _raw_fft_range_preset_changed' in text

def test_control_timeline_uses_splitter_and_delayed_settle():
    assert 'self.cavitation_timeline_splitter = QSplitter(Qt.Orientation.Vertical)' in text
    assert 'self.cavitation_timeline_splitter.addWidget(self.cavitation_control_plot)' in text
    assert 'self.cavitation_timeline_splitter.addWidget(self.cavitation_observed_table)' in text
    assert 'for delay in (0, 40, 140)' in text
