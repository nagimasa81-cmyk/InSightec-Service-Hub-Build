
from pathlib import Path

SOURCE = (Path(__file__).parents[1] / "src/ui/main_window.py").read_text(encoding="utf-8")

def test_workstation_replay_uses_authoritative_plot_arrays():
    helper = SOURCE.split("def _update_acoustic_replay_view", 1)[1].split("def _ensure_acoustic_curve_items", 1)[0]
    replay = SOURCE.split("def _apply_workstation_replay_behavior", 1)[1].split("def _post_sonication_acoustic_period", 1)[0]
    assert 'trend.plot_time_s if getattr(trend, "plot_time_s", None) is not None else trend.time_s' in helper
    assert 'trend.plot_power_percent if getattr(trend, "plot_power_percent", None) is not None else trend.power_percent' in helper
    assert 'trend.plot_score_percent if getattr(trend, "plot_score_percent", None) is not None else trend.score_percent' in helper
    assert '_update_acoustic_replay_view' in replay

def test_replay_does_not_replace_power_score_with_frame_sampled_arrays():
    block = SOURCE.split("def _apply_workstation_replay_behavior", 1)[1].split("def _post_sonication_acoustic_period", 1)[0]
    assert "mask = np.asarray(trend.time_s" not in block
    assert "trend.time_s" not in block
    assert "_update_acoustic_replay_view" in block

def test_existing_update_path_uses_plot_arrays():
    block = SOURCE.split("def _update_acoustic_cards", 1)[1].split("def _update_replay_waterfall", 1)[0]
    assert "trend.plot_time_s" in block
    assert "trend.plot_power_percent" in block
    assert "trend.plot_score_percent" in block
