from pathlib import Path

TEXT = Path('src/ui/main_window.py').read_text(encoding='utf-8')

def test_chart_panel_has_no_local_collapse_or_expand_buttons():
    s=TEXT.index('def _chart_panel')
    e=TEXT.index('def _make_image_strip',s)
    block=TEXT[s:e]
    assert 'QToolButton' not in block
    assert '_open_chart_popup' not in block
    assert 'lay.addWidget(plot, 1)' in block

def test_temperature_uses_single_autohide_popup_only():
    assert 'self.temperature_hover_text = None' in TEXT
    assert 'self.temperature_hover_popup.set_auto_hide(1500)' in TEXT
    s=TEXT.index('def _temperature_plot_hovered')
    e=TEXT.index('def _acoustic_plot_clicked',s)
    block=TEXT[s:e]
    assert 'temperature_hover_text.setText' not in block
    assert '_show_chart_tooltip(self.temperature_plot, lines)' in block

def test_temperature_native_tooltip_is_suppressed():
    s=TEXT.index('def _show_chart_tooltip')
    e=TEXT.index('def _hide_chart_tooltip',s)
    block=TEXT[s:e]
    assert 'if widget is self.temperature_plot' in block
    assert 'QToolTip.hideText()' in block

def test_science_plot_leaves_label_margin_and_flips_edge_labels():
    assert 'plot.setXRange(-4,108,padding=0.0)' in TEXT
    assert 'plot.setYRange(-4,108,padding=0.0)' in TEXT
    assert 'ax = 1 if x >= 92 else 0' in TEXT
    assert 'ay = 0 if y >= 92 else 1' in TEXT
