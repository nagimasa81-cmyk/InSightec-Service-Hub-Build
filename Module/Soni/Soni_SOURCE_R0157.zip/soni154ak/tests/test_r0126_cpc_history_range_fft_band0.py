from pathlib import Path

SRC = Path(__file__).parents[1] / 'src' / 'ui' / 'hydrophone_window.py'

def test_cpc_history_selected_range_analysis_is_available():
    src = SRC.read_text(encoding='utf-8')
    assert 'FFT + Band0 selected range' in src
    assert 'def _history_fft_has_valid_metric' in src
    assert 'def _extract_history_range_selection' in src
    assert 'def _run_selected_history_fft_band0' in src
    assert 'Selected CPC Band0 History — FFT + Statistics' in src


def test_history_fft_is_not_mislabeled_as_acoustic_fft():
    src = SRC.read_text(encoding='utf-8')
    assert 'temporal modulation frequency' in src
    assert 'NOT a reconstructed hydrophone acoustic spectrum' in src
    assert 'Band0 selected-range statistics' in src


def test_raw_fft_remains_preferred_when_raw_exists():
    src = SRC.read_text(encoding='utf-8')
    assert 'if not self._raw_fft_has_valid_waveform() and self._history_fft_has_valid_metric()' in src
    assert 'self._extract_raw_fft_selection' in src
