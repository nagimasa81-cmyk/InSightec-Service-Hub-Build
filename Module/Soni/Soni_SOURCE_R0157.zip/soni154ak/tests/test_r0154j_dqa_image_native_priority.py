from types import SimpleNamespace
from pathlib import Path

from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService


def test_image_native_alignment_never_borrows_components_from_peer_sonications(tmp_path: Path, monkeypatch):
    pkg=SimpleNamespace(
        workspace=tmp_path,
        source=tmp_path/'case.zip',
        sonications=[
            SimpleNamespace(sonication_number=1, canonical_steering_xyz=None, temperature_frames=[]),
            SimpleNamespace(sonication_number=2, canonical_steering_xyz=None, temperature_frames=[]),
        ],
    )
    svc=DqaFocusAlignmentService()
    monkeypatch.setattr(svc, '_find_mri_params', lambda _w: tmp_path/'MriImageParams.xml')
    # Old code could combine X/Y from S1 with Z/tilt from S2.  That is forbidden:
    # no same-Sonication observed thermometry => no numeric DQA result.
    out=svc._image_native_alignment(pkg,{1:(100,100,100),2:(100,100,100)},1)
    assert out is None

def test_analyze_prefers_image_native_result_over_plausible_but_wrong_focalras(tmp_path: Path, monkeypatch):
    (tmp_path/'SonicationSummary.xml').write_text(
        '<root xmlns:z="urn:schemas-microsoft-com:rowset"><z:row sonicationindex="1" treatprotocol="Low-Energy-DQA" focalrasx="112" focalrasy="81" focalrasz="-63.9" /></root>',
        encoding='utf-8')
    pkg=SimpleNamespace(workspace=tmp_path,source=tmp_path/'case.zip',sonications=[SimpleNamespace(sonication_number=1,canonical_steering_xyz=None)])
    svc=DqaFocusAlignmentService()
    native=SimpleNamespace(x_mm=1.0,y_mm=-1.5,z_mm=2.0,tilt_deg=0.2,confidence='High',evidence=['native'],excluded_reason=None,display='native',alert=False)
    monkeypatch.setattr(svc, '_dqa_reference_geometry', lambda _p: {'center_ras':(0.0,0.0,0.0),'validation_rows':[]})
    monkeypatch.setattr(svc, '_image_native_alignment', lambda _p,_f,_n: native)
    out=svc.analyze(pkg,0)
    assert out is native
