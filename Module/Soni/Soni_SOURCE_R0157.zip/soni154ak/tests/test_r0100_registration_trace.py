
from pathlib import Path
REG=(Path(__file__).parents[1]/"src/services/registration_overlay_service.py").read_text(encoding="utf-8")
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_trace_uses_exact_world_reslice_geometry_convention():
    assert "class RegistrationTrace" in REG
    block=REG.split("def _trace_ct_voxel_to_mr_pixel",1)[1].split("def _alignment_score",1)[0]
    assert "ct_geom.col_direction * (x * ct_geom.pixel_size_x)" in block
    assert "ct_geom.row_direction * (y * ct_geom.pixel_size_y)" in block
    assert "recipe.matrix" in block
    assert "_mr_geometry(mr_asset)" in block

def test_suppressed_registration_exposes_full_chain():
    block=REG.split("if gross_mismatch:",1)[1].split("return RegistrationOverlayResult",1)[0]
    assert "CT RAS" in block
    assert "MR RAS" in block
    assert "MR pixel" in block
    assert "matrix direction / MR geometry / reference-plane mismatch" in block

def test_no_registration_optimization_is_added():
    assert "no automatic image-similarity correction applied" in REG

def test_registration_trace_button_is_visible():
    assert 'QPushButton("Registration Trace")' in MAIN
    assert "def _show_registration_trace" in MAIN
