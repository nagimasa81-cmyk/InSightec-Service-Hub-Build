from pathlib import Path
import numpy as np

from src.services.acoustic_control_service import AcousticControlService
from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService


def test_dqa_stack_compatibility_accepts_any_slice_per_orientation():
    # Synthetic orthogonal stacks: the focal need only be coplanar with one slice
    # in each stack, never with the first slice of the series.
    def axial(s):
        return {
            'pixsizex':1.0,'pixsizey':1.0,
            'topleftcoordr':128.0,'topleftcoorda':128.0,'topleftcoords':float(s),
            'rowdirectcosrasx':0.0,'rowdirectcosrasy':-1.0,'rowdirectcosrasz':0.0,
            'coldirectcosrasx':-1.0,'coldirectcosrasy':0.0,'coldirectcosrasz':0.0,
            'imgplane':2,
        }
    def sagittal(r):
        return {
            'pixsizex':1.0,'pixsizey':1.0,
            'topleftcoordr':float(r),'topleftcoorda':128.0,'topleftcoords':128.0,
            'rowdirectcosrasx':0.0,'rowdirectcosrasy':0.0,'rowdirectcosrasz':-1.0,
            'coldirectcosrasx':0.0,'coldirectcosrasy':-1.0,'coldirectcosrasz':0.0,
            'imgplane':4,
        }
    ref={'validation_rows':[
        ('ax first',axial(40)),('ax target',axial(20)),
        ('sag first',sagittal(-20)),('sag target',sagittal(0)),
    ]}
    ok,_=DqaFocusAlignmentService._focal_reference_frame_compatibility(ref,(0.0,0.0,20.0))
    assert ok


def test_acoustic_log_parse_cache_reuses_same_workspace_file(tmp_path):
    log=tmp_path/'Acquisition_Brain_650_Thu_Jun_11_14_33_56_2026.txt'
    log.write_text(
        '14:00:00:000 Got StartSpectrumMeasurement\n'
        '14:00:00:010 AblPowerRatio = 0.5\n'
        '14:00:00:020 Calculated Energy: <1> Bottom Limit Of Harmless Energy: <2>\n',
        encoding='utf-8'
    )
    svc=AcousticControlService()
    a=svc.parse_segments(log)
    # If a second read attempted filesystem parsing this invalid replacement would
    # change the result. The immutable stat-keyed cache must return the same data.
    b=svc.parse_segments(log)
    assert a is b
    assert len(a)==1 and len(a[0].samples)==2
