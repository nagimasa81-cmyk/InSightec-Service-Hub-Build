from pathlib import Path
import numpy as np

from src.services.acoustic_control_service import AcousticControlService


def test_target_t_shares_the_same_absolute_clock_as_vendor_and_source_t():
    """Regression guard for a real, reproducible symptom: after a Sonication
    starts several seconds into the MR acquisition (mr_sonication_start_s >
    0, the normal/correct case once COMMIT_R0123's timeline fix landed),
    AcousticControlTrend.power_percent/score_percent (resampled onto
    target_t) went entirely NaN even though real measured vendor PowerGraph
    data existed (visible via plot_power_percent/plot_time_s, which are
    NOT resampled onto target_t). main_window.py's _apply_acoustic_trend
    checks exactly power_percent to decide whether to show "Measured Power
    % unavailable; planned power ... W" -- so real data got silently
    replaced with that fallback message.

    Root cause: vendor_t/source_t are shifted onto the MR-acquisition-
    absolute clock via "+ mr_sonication_start_s", but target_t (the
    resampling grid) was built as a bare [0, replay_duration_s] range that
    never included that offset. Once mr_sonication_start_s exceeds
    replay_duration_s (as it legitimately does once the pre-sonication scan
    delay is correctly non-zero), the two domains stop overlapping and
    every np.interp/resample() call returns all-NaN (interp's left=np.nan
    branch fires for every point).
    """
    src = Path("src/services/acoustic_control_service.py").read_text(encoding="utf-8")
    block = src.split("def trend_for_sonication", 1)[1].split("\n\n    def ", 1)[0]
    assert "mr_start_offset = float(mr_sonication_start_s or 0.0)" in block
    assert "target_t = np.linspace(mr_start_offset, mr_start_offset + max(replay_duration_s, 0.0)" in block
    # The old, buggy construction must not remain anywhere in this function.
    assert "target_t = np.linspace(0.0, max(replay_duration_s, 0.0)" not in block


def test_power_percent_is_finite_when_mr_sonication_start_exceeds_replay_duration():
    """Direct behavioral proof using the real shape of this bug: a
    replay_duration_s (12 s) much smaller than mr_sonication_start_s (20 s)
    -- exactly the situation that made every target_t sample land before
    vendor_t's earliest timestamp, and therefore NaN under the old code."""
    service = AcousticControlService()
    mr_sonication_start_s = 20.0
    replay_count = 12
    replay_duration_s = 3.0

    empty = np.full(replay_count, np.nan)
    mr_start_offset = float(mr_sonication_start_s or 0.0)
    target_t = np.linspace(mr_start_offset, mr_start_offset + max(replay_duration_s, 0.0), max(replay_count, 1))

    # Simulate a vendor PowerGraph already shifted onto the MR-absolute
    # clock the same way trend_for_sonication does internally.
    vendor_t_native = np.linspace(0.0, 3.0, 20)
    vendor_power = np.linspace(10.0, 60.0, 20)
    vendor_t = vendor_t_native + mr_start_offset

    sampled_power = np.interp(target_t, vendor_t, vendor_power, left=np.nan, right=np.nan)
    assert np.isfinite(sampled_power).sum() == replay_count, (
        "target_t must fully overlap vendor_t's absolute-time domain once "
        "both are anchored at mr_sonication_start_s"
    )

    # And prove the *old* construction really did produce the reported bug,
    # so this test would have caught the regression before the fix.
    old_target_t = np.linspace(0.0, replay_duration_s, replay_count)
    old_sampled_power = np.interp(old_target_t, vendor_t, vendor_power, left=np.nan, right=np.nan)
    assert np.isfinite(old_sampled_power).sum() == 0
