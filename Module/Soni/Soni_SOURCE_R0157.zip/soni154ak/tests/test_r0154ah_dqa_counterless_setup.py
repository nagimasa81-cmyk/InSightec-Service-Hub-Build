from pathlib import Path


def test_brain220_counterless_setup_tail_is_bound_to_treatment_series():
    src=Path('src/services/dqa_focus_alignment_service.py').read_text()
    block=src.split('def _series_fixed_focus_ras',1)[1].split('def analyze_series',1)[0]
    assert 'if not numbered:' in block
    assert 'tail=list(setups)[-len(sons):]' in block
    assert 'Brain220 counterless setup tail bound' in block
    assert 'nominal=np.nanmedian(steering,axis=0)' in block
