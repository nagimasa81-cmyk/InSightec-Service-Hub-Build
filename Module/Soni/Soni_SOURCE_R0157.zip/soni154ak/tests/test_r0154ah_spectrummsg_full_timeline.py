from pathlib import Path
import numpy as np


def test_spectrummsg_uses_powergraph_timestamps_when_record_counts_match():
    src=Path('src/services/spectrummsg_aggregate_service.py').read_text()
    assert 'supplied.size==len(decoded)' in src
    assert 't=(float(supplied[i]) if use_supplied else' in src
    repo=Path('src/services/spectrum_evidence_repository.py').read_text()
    assert 'power_graph_for_sonication' in repo
    assert 'graph_times' in repo
