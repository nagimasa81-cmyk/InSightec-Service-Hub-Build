from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np

CAV_VIZ = (ROOT / 'src/services/cavitation_visualization_service.py').read_text(encoding='utf-8')
REPLAY_SVC = (ROOT / 'src/services/hydrophone_replay_service.py').read_text(encoding='utf-8')


def test_canonical_helpers_are_public_and_reused_inside_compute():
    """The window widths/dB formula used by CavitationTrend must live in one
    named place, not be re-derived inline in every consumer."""
    assert 'def band_energy(freq_hz, amp, low_hz: float, high_hz: float)' in CAV_VIZ
    assert 'def energy_ratio_db(value: float, ref: float)' in CAV_VIZ
    assert 'def fundamental_window_hz(main_frequency_hz: float)' in CAV_VIZ
    assert 'def subharmonic_window_hz(main_frequency_hz: float)' in CAV_VIZ
    compute_block = CAV_VIZ.split('def compute(', 1)[1]
    assert 'self.fundamental_window_hz(main_hz)' in compute_block
    assert 'self.subharmonic_window_hz(main_hz)' in compute_block
    # The old inline magic numbers must be gone from compute(), not duplicated
    # alongside the new named helpers.
    assert 'mw=max(5000.0,0.04*main_hz)' not in compute_block


def test_hydrophone_replay_service_delegates_instead_of_reimplementing():
    block = REPLAY_SVC.split('def subharmonic_events', 1)[1].split('\n\n\n', 1)[0]
    assert 'CavitationVisualizationService.band_energy' in block
    assert 'CavitationVisualizationService.energy_ratio_db' in block
    assert 'CavitationVisualizationService.fundamental_window_hz' in block
    assert 'CavitationVisualizationService.subharmonic_window_hz' in block


def _synthetic_frame(freq_hz, f0, sub_level, fund_level, noise_level=1e-4, rng=None):
    from src.services.hydrophone_replay_service import CpcHydrophoneFrame
    rng = rng or np.random.default_rng(0)
    amp = np.full_like(freq_hz, noise_level) + rng.uniform(0, noise_level, size=freq_hz.size)
    amp[np.argmin(np.abs(freq_hz - f0))] = fund_level
    amp[np.argmin(np.abs(freq_hz - f0 / 2.0))] = sub_level
    return CpcHydrophoneFrame(index=0, frequency_hz=freq_hz, channels=[amp])


def test_subharmonic_events_and_cavitation_trend_agree_on_synthetic_data():
    """Behavioral proof of consolidation: build frames with an obvious f0/2
    spike, then check CpcHydrophoneReplay.subharmonic_events() and
    CavitationVisualizationService.compute() -- the two previously-
    independent code paths -- agree on which frame is elevated, using
    numerically identical dB values now that both call the same helpers."""
    from src.services.hydrophone_replay_service import CpcHydrophoneReplay
    from src.services.cavitation_visualization_service import CavitationVisualizationService

    f0 = 680_000.0
    freq_hz = np.linspace(250_000.0, 750_000.0, 256)
    rng = np.random.default_rng(0)
    quiet = _synthetic_frame(freq_hz, f0, sub_level=1e-4, fund_level=1e-2, rng=rng)
    quiet.index = 0
    loud = _synthetic_frame(freq_hz, f0, sub_level=5e-2, fund_level=1e-2, rng=rng)
    loud.index = 1
    replay = CpcHydrophoneReplay(source_fft=None, source_raw=None, main_frequency_hz=f0,
                                  frames=[quiet, loud], acquisition_interval_s=0.010)

    events = replay.subharmonic_events(channel=0)
    fired_frames = {e.frame_index for e in events}
    assert 0 not in fired_frames, "quiet frame must not fire"
    assert 1 in fired_frames, "frame with a strong f0/2 spike must fire"

    class F:
        def __init__(self, frequency, amplitude):
            self.frequency = frequency
            self.amplitude = amplitude

    frames_for_ch = [F(f.frequency_hz, f.channels[0]) for f in replay.frames]
    trend = CavitationVisualizationService().compute(
        {"RCV0": frames_for_ch}, ["RCV0"], f0, len(replay.frames), 1.0
    )
    assert trend is not None
    # The event's own reported ratio_db must equal the trend's dB for that
    # same frame (same helpers, same inputs) -- not just "agree in direction".
    fired_event = next(e for e in events if e.frame_index == 1)
    assert abs(fired_event.ratio_db - float(trend.subharmonic_db[1])) < 1e-6
    assert trend.subharmonic_db[1] > trend.subharmonic_db[0]
