from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
REG=(ROOT/'src/services/registration_overlay_service.py').read_text(encoding='utf-8')

def test_explicit_thumbnail_scrollbar_present():
    assert 'QSlider(Qt.Orientation.Horizontal)' in MAIN
    assert 'def _scroll_image_strip_to_index' in MAIN
    assert 'self.image_strip_scrollbars' in MAIN
    assert 'scroll.valueChanged.connect(lambda index,owner=strip: self._scroll_image_strip_to_index(owner,index))' in MAIN

def test_preplanning_registration_uses_export_chain():
    assert 'recipe=self._registration_recipe' in REG
    assert "mm@ct" in REG
    assert "'inv(MrMr) × CtMr'" in REG
    assert 'hypotheses=self._registration_hypotheses' not in REG
