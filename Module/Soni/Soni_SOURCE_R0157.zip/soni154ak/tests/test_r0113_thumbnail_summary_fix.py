from pathlib import Path
MAIN=(Path(__file__).parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')

def test_show_image_row_checkboxes_removed_completely():
    assert 'Show Reference' not in MAIN
    assert 'Show Treatment MR' not in MAIN
    assert 'show_reference_images_check' not in MAIN
    assert 'show_treatment_mr_images_check' not in MAIN
    assert '_reference_nav_widgets' not in MAIN
    assert '_treatment_mr_nav_widgets' not in MAIN

def test_all_planning_planes_have_combined_default_view():
    assert '"Planning MR All"' in MAIN
    assert 'self.planning_type_combo.setCurrentText("Planning MR All")' in MAIN
    assert '"Planning MR All":{"planning_mr_ax","planning_mr_sag","planning_mr_cor"}' in MAIN

def test_thumbnail_ready_updates_item_without_rebuilding_list():
    block=MAIN.split('def _image_thumbnail_ready',1)[1].split('def _apply_ready_thumbnail_to_visible_items',1)[0]
    assert '_apply_ready_thumbnail_to_visible_items' in block
    assert '_rebuild_all_image_strips()' not in block

def test_summary_detail_runs_on_worker_thread():
    assert 'class SonicationSummaryDetailWorker(QObject):' in MAIN
    block=MAIN.split('def _refresh_sonication_summary',1)[1].split('def _sonication_summary_row_ready',1)[0]
    assert '_seed_sonication_summary_fast()' in block
    assert 'QThread(self)' in block
    assert 'SonicationSummaryDetailWorker' in block
    assert 'Loading…' not in block
