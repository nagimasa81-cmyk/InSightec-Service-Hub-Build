from pathlib import Path
from types import SimpleNamespace
import numpy as np

from src.services.mr_timeline_service import MRTimelineService
from src.services.hydrophone_replay_service import CpcHydrophoneReplay, CpcHydrophoneFrame


def test_mr_timeline_exact_ws_mrserver_clock(tmp_path):
    (tmp_path/'SonicationSummary.xml').write_text(
        '<?xml version="1.0"?><root><row sonicationindex="1" sontime="20260813122549" actualduration="14.0" protocol="TMAP3-ME"/></root>'
    )
    (tmp_path/'2026_Aug_13_09_05_51.Log').write_text(
        '12:26:02:512 Main status changed from: Sonication to Sonication power on\n'
        '12:26:16:590 Main status changed from: Sonication power on to Post sonication\n'
    )
    (tmp_path/'mrserver_test.log').write_text(
        '12:25:53:461 Status changed from Preparing to Scanning.\n'
        '12:26:36:409 Status changed from Scanning to Idle.\n'
    )
    row=MRTimelineService().resolve_all(tmp_path,[SimpleNamespace(replay_frame_count=11)])[0]
    assert row.confidence == 'Exact'
    assert abs(row.duration_s - 42.948) < 1e-3
    assert abs(row.sonication_start_s - 9.051) < 1e-3
    assert abs(row.sonication_end_s - 23.129) < 1e-3


def test_cpc_acquisition_maps_inside_mr_clock():
    replay=CpcHydrophoneReplay(None,None)
    replay.frames=[CpcHydrophoneFrame(0,np.array([1.0]),[np.array([1.0])],acquisition_time_s=14.5)]
    replay.sonication_time_zero_offset_s=14.4
    replay.mr_sonication_start_s=9.0
    assert np.allclose(replay.mr_frame_times_s,[9.1])
    assert abs(replay.acquisition_to_mr_time_s(14.5)-9.1)<1e-9


def test_ui_vendor_and_control_use_mr_timebase():
    text=Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'time = np.asarray(self.replay.mr_raw_timeline_time_s, float)' in text
    assert 'snapshot_time = self.replay.mr_frame_times_s' in text
    assert 'tx = tx - float(self.replay.sonication_time_zero_offset_s or 0.0) + float(self.replay.mr_sonication_start_s or 0.0)' in text
    assert 'self._apply_mr_timeline_window(self.vendor_energy_plot, self.vendor_power_plot)' in text


def test_control_timeline_filters_pre_mr_negative_times():
    text=Path('src/services/cavitation_control_timeline_service.py').read_text(encoding='utf-8')
    assert 'mr_timeline_duration_s: float = 0.0' in text
    assert 'float(e.timestamp_s) >= -1e-9' in text


def test_discovery_resolves_mr_timeline_for_each_sonication():
    text=Path('src/services/discovery_service.py').read_text(encoding='utf-8')
    assert 'self.mr_timeline.resolve_all(workspace, models)' in text
    assert 'model.mr_timeline_duration_s = float(timeline.duration_s)' in text


def test_control_cycle_anchor_is_used_for_upper_lower_alignment():
    text=Path('src/services/cavitation_control_timeline_service.py').read_text(encoding='utf-8')
    assert 'cycle_anchor_cycle: int | None = None' in text
    assert 'cycle_anchor_acquisition_time_s: float | None = None' in text
    assert 'acq = float(cycle_anchor_acquisition_time_s) + (float(cycle)-float(cycle_anchor_cycle))*float(acquisition_interval_s or 0.010)' in text
    assert 'anchored = cycle_to_mr(event.cycle)' in text


def test_exact_ws_irradiation_window_drives_event_state():
    text=Path('src/services/cavitation_control_timeline_service.py').read_text(encoding='utf-8')
    assert 'mr_sonication_end_s: float = 0.0' in text
    assert 'state="Post-irradiation"' in text
    assert 'state="Irradiation active"' in text
