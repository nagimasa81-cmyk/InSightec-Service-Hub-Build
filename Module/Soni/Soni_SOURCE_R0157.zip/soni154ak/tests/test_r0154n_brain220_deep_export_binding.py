from pathlib import Path
import struct

from src.core.fus_export_core import decode_spectrum_structure
from src.services.sonication_evidence_service import SonicationEvidenceService


def _ws_double(v: float) -> bytes:
    raw = struct.pack('<d', v)
    lo, hi = struct.unpack('<II', raw)
    return struct.pack('<II', hi, lo)


def _record(bins=400, spacing=625.0, times=(0.1, 0.2)):
    extent = 48 + bins * 8
    r = bytearray(56 + bins * 8)
    struct.pack_into('<I', r, 0, extent)
    r[24:32] = _ws_double(spacing)
    r[32:40] = _ws_double(0.0)
    r[40:48] = _ws_double(bins * spacing)
    for i in range(bins):
        r[56+i*8:64+i*8] = _ws_double(0.001 + i * 1e-6)
    r.extend(struct.pack('<I', len(times)))
    for idx, t in enumerate(times):
        # cumulative, average, integer state/index, elapsed time, increment
        r.extend(struct.pack('<ffIf f'.replace(' ', ''), 0.001*idx, 0.0001*idx, idx, t, 0.00001))
    r.extend(b'\x00' * 12)
    return bytes(r)


def test_structure_decoder_recognizes_variable_size_table_and_last_time(tmp_path: Path):
    records = [_record(times=(0.1, 0.25)), _record(times=(0.3, 0.5))]
    data = struct.pack('<I', len(records)) + struct.pack('<2I', *(len(r) for r in records)) + b''.join(records)
    p = tmp_path / 'SpectrumMsg-1.dmp'
    p.write_bytes(data)
    st = decode_spectrum_structure(p)
    assert st.exact_structure is True
    assert st.layout == 'Variable size-table FFT/history'
    assert st.frame_count == 2
    assert st.channel_count == 0
    assert st.fft_bins == 400
    assert st.frequency_spacing_hz == 625.0
    assert st.last_timestamp_seconds == 0.5


def test_ws_startsonicate_fallback_recovers_counter_and_multi_target_geometry(tmp_path: Path):
    ws = tmp_path / 'WSFiles'; ws.mkdir()
    (ws / '2026_Apr_01_18_30_13.Log').write_text('''
18:41:44:135 Ent Dbg 7940 [CGeneralSonicationLogic::StartSonicate] Sonication Counter:0. Burn Pointer:20000005
18:41:44:144 Inf Dbg 7940 Xd loc XYZ: 0 0 0, roll: 0, pitch: 0, Steering: 0.44 -1.52 149.82
18:41:44:144 Inf Dbg 7940 Sonication Type:6
18:41:44:145 Inf Dbg 10212 Acoustic Power = 50.000000
18:41:44:145 Inf Dbg 10212 PulseDuration = 90.000000
18:41:44:145 Inf Dbg 10212 Frequency = 230000.000000
18:41:44:145 Inf Dbg 10212 Number of sub-sonications = 3
18:41:44:145 Inf Dbg 10212 Sub sonication data: Num, Mode, Power, Duration, Steering
18:41:44:145 Inf Dbg 10212 0, 0, 1.000000, 0.109375, (-3.0,0.0,0.0)
18:41:44:145 Inf Dbg 10212 1, 0, 1.000000, 0.109375, (0.0,0.0,0.0)
18:41:44:145 Inf Dbg 10212 2, 0, 1.000000, 0.109375, (3.0,0.0,0.0)
18:41:44:157 Inf Dbg 7940 Sub - sonications coordinates in RAS: Size:3 Elements:(1, 2, 3) (4, 5, 6) (7, 8, 9)
''', encoding='utf-8')
    recs = SonicationEvidenceService().parse_setup_records(tmp_path)
    assert len(recs) == 1
    r = recs[0]
    assert r.sonication_counter == 0
    assert r.sonication_type == 6
    assert r.power_w == 50.0
    assert r.frequency_hz == 230000.0
    assert r.subsonication_count == 3
    assert r.subsonication_ras == ((1.0,2.0,3.0),(4.0,5.0,6.0),(7.0,8.0,9.0))
    assert len(r.subsonication_steering) == 3
