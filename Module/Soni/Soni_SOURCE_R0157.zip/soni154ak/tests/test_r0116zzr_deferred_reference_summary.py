from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
TEXT=(ROOT/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_image_load_blocks_only_on_live_replay_images():
    assert 'self._image_load_expected = {"reference":0, "treatment_mr":mr_count, "thermal":thermal_count}' in TEXT
    assert 'for role,sources in (("treatment_mr",treatment_frames),):' in TEXT

def test_hidden_planning_strip_not_materialized_during_blocking_load():
    assert 'if role == "planning" and not strip.isVisible()' in TEXT

def test_combo_rebuild_is_incremental():
    body=TEXT[TEXT.index('def _rebuild_all_image_strips'):TEXT.index('def _is_registration_reference_mode')]
    assert '_start_incremental_image_strip_build()' in body
    assert 'self._start_incremental_image_strip_build()' in body

def test_summary_does_not_decode_cpc_fft_per_sonication():
    body=TEXT[TEXT.index('def _build_one_sonication_summary'):TEXT.index('def _cancel_sonication_summary_worker')]
    assert '_build_cpc_replay' not in body
    assert '_summary_canonical_cavitation_evidence(index,son,None)' in body
