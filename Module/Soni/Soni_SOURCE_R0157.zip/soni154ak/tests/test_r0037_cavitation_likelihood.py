import numpy as np

from src.services.cavitation_likelihood_service import CavitationLikelihoodService
from src.services.hydrophone_replay_service import CpcHydrophoneReplay, CpcHydrophoneFrame


class DummyEvent:
    family = "Safety"
    rule_index = 3
    cycle = 10
    contributing_channels = (2, 3)
    contributing_bands = (0,)
    dominant_channel = 2
    dominant_energy = 0.8


def test_likelihood_from_frame():
    replay = CpcHydrophoneReplay(source_fft=None, source_raw=None)
    frame = CpcHydrophoneFrame(index=0, frequency_hz=np.array([1.0]), channels=[np.array([0.0])]*8, vendor_band_energies=np.zeros((8,4), float), acquisition_cycle=1)
    frame.vendor_band_energies[2,0] = 0.8
    frame.vendor_band_energies[3,0] = 0.2
    replay.frames = [frame]
    svc = CavitationLikelihoodService()
    result = svc.estimate(replay, 0, None)
    assert result.dominant_channel == 2
    assert result.likelihood_map.shape[0] > 50
    assert np.max(result.likelihood_map) <= 1.0 + 1e-9


def test_likelihood_from_observed_event():
    replay = CpcHydrophoneReplay(source_fft=None, source_raw=None)
    frame = CpcHydrophoneFrame(index=0, frequency_hz=np.array([1.0]), channels=[np.array([0.0])]*8, vendor_band_energies=np.zeros((8,4), float), acquisition_cycle=10)
    frame.vendor_band_energies[2,0] = 0.8
    frame.vendor_band_energies[3,0] = 0.2
    replay.frames = [frame]
    svc = CavitationLikelihoodService()
    result = svc.estimate(replay, 0, DummyEvent())
    assert result.dominant_channel == 2
    assert "Probable cavitation region" in result.summary
