from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / "src" / "ui" / "main_window.py"

def test_r0053_first_class_cavitation_workspace_present():
    text = SRC.read_text(encoding="utf-8")
    assert 'self.tabs.addTab(self.cavitation_intelligence_tab, "Cavitation Intelligence")' in text
    assert 'QAction("Cavitation Intelligence", self)' in text
    assert 'Evidence chain — Time → RCV → Band → MR → Location → Skull → Power' in text
    assert 'RCV contribution → probable cavitation region' in text
    assert 'MR magnitude signal-loss correlation' in text
    assert 'self._update_cavitation_intelligence_page()' in text
