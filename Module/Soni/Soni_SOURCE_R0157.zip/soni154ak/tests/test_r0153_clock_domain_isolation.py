from types import SimpleNamespace
from pathlib import Path

import numpy as np

from src.services.clock_domain_service import ClockDomainService
from src.services.mr_timeline_service import MRTimeline


def _segment(start_clock_s):
    # sample elapsed times are arbitrary here; _collapse is monkeypatched.
    return SimpleNamespace(start_clock_s=float(start_clock_s), samples=[object(), object()])


def _timeline(ws_on):
    return MRTimeline(ws_power_on_abs_s=float(ws_on), ws_power_off_abs_s=float(ws_on)+13.0)


def test_stable_multi_sonication_offset_is_accepted(monkeypatch, tmp_path):
    svc = ClockDomainService()
    fake_log = tmp_path / "Acquisition_Brain_1_Wed_Aug_26_17_00_00_2026.txt"
    fake_log.write_text("x")
    monkeypatch.setattr(svc.acoustic, "find_log", lambda _w: fake_log)
    monkeypatch.setattr(svc.acoustic, "parse_segments", lambda _p: [_segment(17*3600+10), _segment(17*3600+20), _segment(17*3600+30)])
    monkeypatch.setattr(svc.acoustic, "_collapse", lambda _samples: (np.array([0.,1.]), np.array([0.,100.]), np.array([0.,0.]), np.array([0.,0.]), np.array([1.,1.])))
    monkeypatch.setattr(svc.acoustic, "_vendor_power_graph", lambda _w, _i: (np.array([0.,1.]), np.array([0.,100.])))
    monkeypatch.setattr(svc.acoustic, "_align_control_to_vendor_power", lambda *_args: 2.0)

    midnight = ClockDomainService._midnight_from_log(fake_log)
    # CPC acoustic onsets = 17:00:12, :22, :32. Treatment WS is +6.8 s.
    timelines = [_timeline(midnight + 17*3600 + x + 6.8) for x in (12,22,32)]
    sons = [SimpleNamespace(sonication_number=i+1, canonical_acquisition_session_index=i) for i in range(3)]
    result = svc.assess(tmp_path, sons, timelines)
    assert result.status == "Stable offset"
    assert result.correction_allowed
    assert result.anchor_count == 3
    assert abs(result.cpc_to_ws_offset_s - 6.8) < 1e-6
    assert result.spread_s < 1e-6


def test_unstable_offsets_fail_closed(monkeypatch, tmp_path):
    svc = ClockDomainService()
    fake_log = tmp_path / "Acquisition_Brain_1_Wed_Aug_26_17_00_00_2026.txt"
    fake_log.write_text("x")
    monkeypatch.setattr(svc.acoustic, "find_log", lambda _w: fake_log)
    monkeypatch.setattr(svc.acoustic, "parse_segments", lambda _p: [_segment(17*3600+10), _segment(17*3600+20), _segment(17*3600+30)])
    monkeypatch.setattr(svc.acoustic, "_collapse", lambda _samples: (np.array([0.,1.]), np.array([0.,100.]), np.array([0.,0.]), np.array([0.,0.]), np.array([1.,1.])))
    monkeypatch.setattr(svc.acoustic, "_vendor_power_graph", lambda _w, _i: (np.array([0.,1.]), np.array([0.,100.])))
    monkeypatch.setattr(svc.acoustic, "_align_control_to_vendor_power", lambda *_args: 2.0)
    midnight = ClockDomainService._midnight_from_log(fake_log)
    # Residuals do not behave like one Windows clock offset.
    offsets = (1.0, 5.0, -2.0)
    timelines = [_timeline(midnight + 17*3600 + x + off) for x, off in zip((12,22,32), offsets)]
    sons = [SimpleNamespace(sonication_number=i+1, canonical_acquisition_session_index=i) for i in range(3)]
    result = svc.assess(tmp_path, sons, timelines)
    assert result.status == "Ambiguous / unstable"
    assert not result.correction_allowed
    assert result.cpc_to_ws_offset_s is None
    assert any("disabled" in line.lower() for line in result.evidence)


def test_single_anchor_never_enables_clock_correction(monkeypatch, tmp_path):
    svc = ClockDomainService()
    fake_log = tmp_path / "Acquisition_Brain_1_Wed_Aug_26_17_00_00_2026.txt"
    fake_log.write_text("x")
    monkeypatch.setattr(svc.acoustic, "find_log", lambda _w: fake_log)
    monkeypatch.setattr(svc.acoustic, "parse_segments", lambda _p: [_segment(17*3600+10)])
    monkeypatch.setattr(svc.acoustic, "_collapse", lambda _samples: (np.array([0.,1.]), np.array([0.,100.]), np.array([0.,0.]), np.array([0.,0.]), np.array([1.,1.])))
    monkeypatch.setattr(svc.acoustic, "_vendor_power_graph", lambda _w, _i: (np.array([0.,1.]), np.array([0.,100.])))
    monkeypatch.setattr(svc.acoustic, "_align_control_to_vendor_power", lambda *_args: 2.0)
    midnight = ClockDomainService._midnight_from_log(fake_log)
    result = svc.assess(tmp_path, [SimpleNamespace(sonication_number=1, canonical_acquisition_session_index=0)], [_timeline(midnight + 17*3600 + 18.0)])
    assert result.status == "Insufficient anchors"
    assert not result.correction_allowed
    assert result.cpc_to_ws_offset_s is None
