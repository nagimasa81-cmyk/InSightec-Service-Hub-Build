from pathlib import Path
import numpy as np

from src.services.cpc_vendor_reproduction_service import CpcVendorReproductionService


SAFETY = r'''
[GENERAL]
IsStopSonicationOnCavitationFromRTDCA=1
SonicaitonErrorPolicyInSW=2
SonicaitonErrorPolicyInHW=2
TimetOIgnoreStartSonic=50
TimetOIgnoreEndSonic=50
CavitationControlStartingPowerRatio=0.20

[HARMONICS_BANDWIDTHS]
Bandwidth_0=0.539 50
Bandwidth_1=0.42 20
Bandwidth_2=0.5 5
Bandwidth_3=1.0 5

[INCREASE_POWER_RULE_0]
IncreaseRuleWeight=| 0 0 0 0 | .25 0 0 0 | .25 0 0 0 | .25 0 0 0 | .25 0 0 0 | 0 0 0 0 | 0 0 0 0 | 0 0 0 0 |
BottomLimitOfHarmlessEnergy=0.014
IncreasePowerRatio=0.01

[DECREASE_POWER_RULE_0]
DecreaseRuleWeight=| 0 0 0 0 | .25 0 0 0 | .25 0 0 0 | .25 0 0 0 | .25 0 0 0 | 0 0 0 0 | 0 0 0 0 | 0 0 0 0 |
TopLimitOfHarmlessEnergy=0.015
DecreasePowerRatio=0.1

[DECREASE_POWER_RULE_1]
DecreaseRuleWeight=| 0 0 0 0 | .25 0 0 0 | .25 0 0 0 | .25 0 0 0 | .25 0 0 0 | 0 0 0 0 | 0 0 0 0 | 0 0 0 0 |
TopLimitOfHarmlessEnergy=0.017
DecreasePowerRatio=0.2

[DECREASE_POWER_RULE_4]
DecreaseRuleWeight=| 0 0 0 0 | 0 0 .25 0 | 0 0 .25 0 | 0 0 .25 0 | 0 0 .25 0 | 0 0 0 0 | 0 0 0 0 | 0 0 0 0 |
TopLimitOfHarmlessEnergy=0.006
DecreasePowerRatio=0.15

[SAFETY_RULE_0]
SafetyRuleWeight=| 0 0 0 0 | .25 0 0 0 | .25 0 0 0 | .25 0 0 0 | .25 0 0 0 | 0 0 0 0 | 0 0 0 0 | 0 0 0 0 |
MaximumEnergyForAllHydrophones=0.025
CriticalEnergyForAllHydrophones=0.04
TimeOfMaximumTestAllowedFailures=1500
TimeOfCriticalTestAllowedFailures=400
NumOfMaximumTestAllowedFailures=20
NumOfCriticalTestAllowedFailures=1

[CAVITATION_CONTROL_LEVELS]
DefaultCavitationControlLevel=1.0
Level0=1.0
Level1=1.5
'''

DYNAMIC = r'''
[DYNAMIC_RULE_0]
DynamicRuleWeight=| 0 0 .5 0 | 0 0 .5 0 | 0 0 0 0 | 0 0 0 0 | 0 0 0 0 | 0 0 0 0 | 0 0 0 0 | 0 0 0 0 |
TopLimitEnergyToSwitchSubSonicaiton=0.03
TimeOfTestAllowedFailures=50
NumOfTestAllowedFailures=5
SwitchToSubSonicationNumber=1
'''

LOG = r'''
00:00:00 Inf Got StartSpectrumMeasurement
00:00:00 Inf Set: SubSonic = 0, ExciterPower = 100 W, AblPower = 100 W, ExPowerRatio = 0.4000 (0) AblPowerRatio = 0.4000 (0), Validity = 1
00:00:00 Inf Cycle 1 Done.
00:00:00 Inf Decrease Power Rule no. 0 : (power will be decreased) Calculated Energy: <0.02>.
00:00:00 Inf Decrease Power Rule no. 1 : (power will be decreased) Calculated Energy: <0.02>.
00:00:00 Inf Decrease Power Rule no. 4 : (power will be decreased) Calculated Energy: <0.008>.
00:00:00 Inf Set: SubSonic = 0, ExciterPower = 80 W, AblPower = 80 W, ExPowerRatio = 0.3200 (0) AblPowerRatio = 0.3200 (0), Validity = 1
00:00:00 Inf Cycle 2 Done.
00:00:00 Inf Increase Power Rule no. 0 : (power can be increased) Calculated Energy: <0.01>.
00:00:00 Inf Set: SubSonic = 0, ExciterPower = 80.8 W, AblPower = 80.8 W, ExPowerRatio = 0.3232 (0) AblPowerRatio = 0.3232 (0), Validity = 1
00:00:00 Inf Cycle 3 Done.
00:00:00 Inf Got StopSpectrumMeasurement
'''


def _write_fixture(tmp_path: Path) -> Path:
    cpc = tmp_path / 'CPCFiles'
    site = cpc / 'Site' / 'Ini'
    site.mkdir(parents=True)
    (site / 'CavitationSafetyAndControl.ini').write_text(SAFETY, encoding='utf-8')
    (site / 'CavitationDynamicRules_0.ini').write_text(DYNAMIC, encoding='utf-8')
    (cpc / 'Acquisition_Brain_test.txt').write_text(LOG, encoding='utf-8')
    return cpc / 'Spectrum_test.dmp_FFT'


def test_decodes_control_and_dynamic_rules(tmp_path):
    source = _write_fixture(tmp_path)
    service = CpcVendorReproductionService()
    profile = service.read_profile(source, 670_000.0)
    assert profile.starting_power_ratio == 0.20
    assert profile.increase_power_ratio == 0.01
    assert profile.cavitation_levels == (1.0, 1.5)
    assert profile.decrease_rules[1].power_ratio == 0.2
    assert profile.safety_rules[0].critical_threshold == 0.04
    assert profile.dynamic_rules[0].max_failures == 5
    assert profile.dynamic_rules[0].max_failure_window_ms == 50
    assert profile.dynamic_rules[0].switch_to_subsonication == 1


def test_strongest_decrease_wins_and_increase_is_multiplicative(tmp_path):
    source = _write_fixture(tmp_path)
    service = CpcVendorReproductionService()
    profile = service.read_profile(source, 670_000.0)
    validation = service.validate_power_control(source, profile, preferred_session_index=0)
    assert validation.status == 'EXACT control reproduction'
    assert validation.decrease_events == 1
    assert validation.increase_events == 1
    assert np.allclose(validation.actual_power_ratio, [0.32, 0.3232], atol=1e-8)
    assert np.allclose(validation.predicted_power_ratio, [0.32, 0.3232], atol=1e-8)
