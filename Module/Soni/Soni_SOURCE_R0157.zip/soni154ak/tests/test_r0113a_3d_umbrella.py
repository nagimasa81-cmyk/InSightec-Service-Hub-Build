from pathlib import Path
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def block(a,b):
    return MAIN.split(a,1)[1].split(b,1)[0]

def test_named_projection_axes_are_exact():
    b=block("def _named_projection","def _perspective_projection")
    assert 'projection=="Top XY"' in b and 'points[:,0], points[:,1], points[:,2]' in b
    assert 'projection=="Front XZ"' in b and 'points[:,0], points[:,2], -points[:,1]' in b
    assert 'projection=="Side YZ"' in b and 'points[:,1], points[:,2], points[:,0]' in b

def test_dense_points_no_longer_block_rotation():
    b=block("def mousePressEvent(self,event):","def mouseMoveEvent(self,event):")
    assert "Always start a possible drag" in b
    assert "_umbrella_press_channel" in b
    first_branch=b.split('if self.layout_mode.startswith("Umbrella")',1)[1].split('ch=self._nearest_screen_channel',1)[0]
    assert "elementClicked.emit" not in first_branch

def test_click_release_and_drag_are_separated():
    move=block("def mouseMoveEvent(self,event):","def mouseReleaseEvent(self,event):")
    release=block("def mouseReleaseEvent(self,event):","class SkullElementWindow")
    assert "_umbrella_dragged=True" in move
    assert 'self.umbrella_projection="Perspective"' in move
    assert "if not self._umbrella_dragged" in release
    assert "self.elementClicked.emit(ch)" in release

def test_depth_cues_and_blade_wireframe_present():
    assert "Wire each physical blade" in MAIN
    assert "depth-dependent point size" in MAIN
    assert "blade_channels" in MAIN

def test_projection_ui_stays_synchronized():
    assert "self.element_map.viewChanged.connect(self._sync_element_projection_combo)" in MAIN
    assert "def _reset_element_3d_view" in MAIN
