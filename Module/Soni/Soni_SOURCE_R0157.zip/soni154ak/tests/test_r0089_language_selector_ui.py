from pathlib import Path

SRC = (Path(__file__).parents[1] / 'src/ui/main_window.py').read_text(encoding='utf-8')


def test_language_selector_is_visible_on_toolbar():
    assert 'self.language_label = QLabel("Language:")' in SRC
    assert 'toolbar.addWidget(self.language_combo)' in SRC
    assert 'self.language_combo.setObjectName("LanguageCombo")' in SRC


def test_language_menu_is_available_from_normal_menu_bar():
    assert 'self.language_menu = self.menuBar().addMenu("&Language")' in SRC
    assert 'self.language_actions = {}' in SRC
    assert 'action.setCheckable(True)' in SRC


def test_toolbar_and_menu_are_kept_in_sync_and_persisted():
    assert 'def _set_language(self, code: str) -> None:' in SRC
    assert 'self.settings.setValue("language", code)' in SRC
    assert 'action.setChecked(action_code == code)' in SRC
    assert 'self.language_combo.setCurrentIndex(idx)' in SRC
