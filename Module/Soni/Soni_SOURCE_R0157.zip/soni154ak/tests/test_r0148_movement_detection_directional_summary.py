from pathlib import Path

from src.services.movement_detection_service import MovementDetectionService, format_movement_detection


def _write_xml(path: Path, rows: list[dict[str, str]]) -> None:
    body = "\n".join(
        "<row " + " ".join(f'{k}="{v}"' for k, v in row.items()) + "/>"
        for row in rows
    )
    path.write_text(f"<root>{body}</root>", encoding="utf-8")


def test_direction_format_requested_by_workstation_summary():
    assert format_movement_detection(0.1, 0.2, 0.0) == "R0.1 S0.2 A0.0"
    assert format_movement_detection(-0.1, -0.2, -0.3) == "L0.1 I0.2 P0.3"


def test_reads_only_explicit_three_axis_evidence(tmp_path: Path):
    _write_xml(tmp_path / "Movement.xml", [
        {"sonicationindex":"1", "movementrl":"0.1", "movementsi":"0.2", "movementap":"0.0"},
        {"sonicationindex":"2", "motionvalue":"0.7"},
    ])
    rows = MovementDetectionService().read_indexed(tmp_path)
    assert rows[1].display == "R0.1 S0.2 A0.0"
    assert 2 not in rows  # scalar must never be expanded to three axes


def test_direction_label_string_can_be_parsed_without_guessing(tmp_path: Path):
    _write_xml(tmp_path / "Movement.xml", [
        {"sonicationindex":"3", "movementresult":"L0.4 I0.5 A0.6"},
    ])
    row = MovementDetectionService().read_indexed(tmp_path)[3]
    assert (row.rl, row.si, row.ap) == (-0.4, -0.5, 0.6)
    assert row.display == "L0.4 I0.5 A0.6"


def test_conflicting_duplicate_axis_values_fail_closed(tmp_path: Path):
    a=tmp_path/'a'; b=tmp_path/'b'; a.mkdir(); b.mkdir()
    _write_xml(a/'Movement.xml', [{"sonicationindex":"4", "motionrl":"0.1", "motionsi":"0.2", "motionap":"0.3"}])
    _write_xml(b/'Movement.xml', [{"sonicationindex":"4", "motionrl":"0.1", "motionsi":"0.2", "motionap":"0.4"}])
    assert 4 not in MovementDetectionService().read_indexed(tmp_path)


def test_summary_uses_directional_text_not_scalar_metric():
    text=(Path(__file__).resolve().parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'movement_detection_display' in text
    assert 'Movement Detection RL/SI/AP' in text
    # Composite directional text is not a scalar chart metric.
    metric_block=text[text.index('self.sonication_summary_metric.addItems(['):text.index('])', text.index('self.sonication_summary_metric.addItems(['))+2]
    assert 'Movement detection' not in metric_block
    assert 'for col,key in ((12,"start_temp"),(13,"peak_temp"),(14,"delta_temp")):' in text
