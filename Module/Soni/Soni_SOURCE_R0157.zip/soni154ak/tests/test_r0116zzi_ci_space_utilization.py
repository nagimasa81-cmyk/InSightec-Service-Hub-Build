from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_ci_uses_full_remaining_height_without_plot_cap():
    s=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'plot_min = 110 if compact else 135' in s
    assert 'stack_min = 130 if compact else 155' in s
    assert 'w.setMaximumHeight(16777215)' in s
    assert 'stack.setMinimumHeight(stack_min)' in s
    assert 'self.ci_summary.setWordWrap(False)' in s
    assert 'self.ci_temperature_summary.setWordWrap(False)' in s
    assert 'self.ci_explanatory_note.setMaximumHeight(30)' in s
