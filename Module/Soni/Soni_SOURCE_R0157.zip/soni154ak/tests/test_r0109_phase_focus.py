from pathlib import Path
import numpy as np
from src.services.phase_focus_service import PhaseFocusService

MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_synthetic_phase_focus_recovers_shift():
    # Bowl points on a spherical cap, focus intentionally shifted.
    theta=np.linspace(0,2*np.pi,64,endpoint=False)
    rings=np.linspace(0.35,1.0,8)
    pts=[]
    for r in rings:
        for t in theta:
            x=80*r*np.cos(t); y=80*r*np.sin(t)
            z=150-np.sqrt(max(1.0,150**2-x*x-y*y))
            pts.append((x,y,z))
    geom={i:p for i,p in enumerate(pts)}
    target=np.array([2.0,-1.5,148.0])
    f=670000.0; c=1500.0
    k=2*np.pi*f/c/1000.0
    phase={i:float(-k*np.linalg.norm(target-np.asarray(p))) for i,p in geom.items()}
    amp={i:1.0 for i in geom}
    # The fitted geometric focus is near (0,0,150); requested vector selects convention.
    res=PhaseFocusService.estimate(
        geom,phase,amp,f,requested_steering_xyz_mm=(2.0,-1.5,-2.0),sound_speed_m_s=c
    )
    assert res.phase_focus_xyz_mm is not None
    assert res.steering_xyz_mm is not None
    assert res.coherence is not None and res.coherence > 0.85
    assert np.linalg.norm(np.asarray(res.steering_xyz_mm)-np.array([2.0,-1.5,-2.0])) < 1.5

def test_main_ui_explains_phase_focus_limit():
    assert "Steering estimate uses wrap(Total Phase Shift − Phase Correction)" in MAIN
    assert "Geometric focus" in MAIN
    assert "Phase-derived focus" in MAIN

def test_act_zero_disabled_defect_are_excluded():
    b=MAIN.split("def _phase_focus_for_snapshot",1)[1].split("def _sonication_element_geometry",1)[0]
    assert "excluded=set(act_zero)|set(disabled)|set(defect)" in b
    assert "ACT amplitude is the preferred weighting" in b

def test_requested_steering_is_not_guessed_when_multiple():
    b=MAIN.split("def _exported_requested_steering",1)[1].split("def _phase_focus_for_snapshot",1)[0]
    assert "return unique[0] if len(unique)==1 else None" in b
