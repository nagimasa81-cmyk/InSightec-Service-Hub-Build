
from pathlib import Path
import ast
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_geometry_comes_from_skullmeasures_xyz():
    b=MAIN.split("def _sonication_element_geometry",1)[1].split("def _sonication_element_channel_states",1)[0]
    assert '"Element X"' in b and '"Element Y"' in b and '"Element Z"' in b
    assert "int(el.number)-1" in b

def test_phase_dedicated_is_xz_geometry_not_synthetic_circle():
    start=MAIN.index("class SonicationElementMapWidget")
    b=MAIN[start:].split("def _draw_phase_dedicated",1)[1].split("def _limits",1)[0]
    assert "channel_geometry_xyz" in b
    assert "X-Z" in b
    assert "scale=min(plot.width()/xspan,plot.height()/zspan)*0.92" in b
    assert "(blade + 0.5)" not in b
    assert "blade_ch / 63.0" not in b

def test_same_scale_preserves_ellipse():
    b=MAIN.split("def _draw_phase_dedicated",2)[2].split("def _limits",1)[0]
    assert "sx+(xs-cx)*scale" in b
    assert "sz-(zs-cz)*scale" in b
    assert "X/Z span=" in b

def test_channel_semantics_preserved():
    assert "gray=explained amplitude=0 · black=unexpected amplitude=0" in MAIN
    assert "white center=ACT amplitude=0" not in MAIN

def test_no_same_class_duplicate_methods():
    tree=ast.parse(MAIN)
    for node in ast.walk(tree):
        if isinstance(node,ast.ClassDef):
            names=set()
            for item in node.body:
                if isinstance(item,(ast.FunctionDef,ast.AsyncFunctionDef)):
                    assert item.name not in names,f"duplicate {node.name}.{item.name}"
                    names.add(item.name)
