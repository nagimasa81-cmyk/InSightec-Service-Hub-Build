from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PROGRESS=(ROOT/'src/ui/progress_window.py').read_text(encoding='utf-8')
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYD=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')

def test_long_operation_progress_dialog_is_nonmodal():
    assert 'self.setWindowModality(Qt.WindowModality.NonModal)' in PROGRESS
    assert 'self.setWindowModality(Qt.WindowModality.ApplicationModal)' not in PROGRESS

def test_spectrum_wait_mode_never_restores_application_modal():
    block=HYD.split('def _set_background_wait_mode',1)[1].split('\n    def ',1)[0]
    assert 'Qt.WindowModality.ApplicationModal' not in block
    assert 'Qt.WindowModality.NonModal' in block

def test_primary_load_remains_worker_owned():
    block=MAIN.split('def load(self, source: Path):',1)[1].split('\n    def ',1)[0]
    assert 'QThread(self)' in block
    assert 'PackageLoadWorker' in block

def test_major_secondary_progress_is_nonmodal():
    for name in ('_image_progress','_summary_progress','_selected_data_progress','_planning_io_progress','_deferred_panel_progress'):
        assert f'{name} = BackgroundProgressDialog(self)' in MAIN
