
from pathlib import Path
import ast
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_no_same_class_duplicate_methods():
    tree=ast.parse(MAIN)
    for node in ast.walk(tree):
        if isinstance(node,ast.ClassDef):
            names=[]
            for item in node.body:
                if isinstance(item,(ast.FunctionDef,ast.AsyncFunctionDef)):
                    assert item.name not in names, f"duplicate {node.name}.{item.name}"
                    names.append(item.name)

def test_connections_are_single():
    assert MAIN.count("self.element_map.elementClicked.connect(")==1
    assert MAIN.count("self.element_parameter_combo.currentTextChanged.connect(")==1
    assert MAIN.count("self.element_layout_combo.currentTextChanged.connect(")==1

def test_act_zero_is_separate_from_disabled_defect():
    b=MAIN.split("def _sonication_element_channel_states",1)[1].split("def _select_element_channel",1)[0]
    assert "act_zero" in b and "disabled" in b and "defect" in b
    assert "DisabledReflectionChannels.ini" in b
    assert "DisconnectedChannels.ini" in b
    assert "Element numbering is 1-based" in b

def test_skullheating_offreason_is_used():
    b=MAIN.split("def _sonication_element_channel_states",1)[1].split("def _select_element_channel",1)[0]
    for text in ("OffByAlgorithm","OffByNPR","OffManually","OffByApod","OffByCPC"):
        assert text in b

def test_phase_position_is_geometry_derived_not_phase_derived():
    start=MAIN.index("class SonicationElementMapWidget")
    b=MAIN.split("def _draw_phase_dedicated",2)[2].split("def _limits",1)[0]
    assert "channel_geometry_xyz" in b
    assert "X-Z" in b
    assert "sx+(xs-cx)*scale" in b
    assert "sz-(zs-cz)*scale" in b
    assert "theta=np.deg2rad(float(rel_deg))" not in b

def test_ini_status_black_and_act_zero_distinct():
    assert "gray=explained amplitude=0 · black=unexpected amplitude=0" in MAIN
    assert "white center=ACT amplitude=0" not in MAIN
    assert 'states.append("ACT AMPLITUDE=0")' in MAIN

def test_channel_regexes_are_not_double_escaped():
    assert 'r"^Element(\\d+)\\s*=\\s*([-+0-9.eE]+)"' in MAIN
    assert 'r"CH(\\d+)\\s*=\\s*([-+0-9.eE]+)"' in MAIN
