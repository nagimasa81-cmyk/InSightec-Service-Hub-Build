import ast
from pathlib import Path
import numpy as np

SRC=Path('src/ui/main_window.py').read_text(encoding='utf-8')
TREE=ast.parse(SRC)
CLS=next(n for n in TREE.body if isinstance(n,ast.ClassDef) and n.name=='SonicationElementMapWidget')
WANTED={'_umbrella_z_sign','_canonical_umbrella_points'}
methods=[n for n in CLS.body if isinstance(n,ast.FunctionDef) and n.name in WANTED]
mod=ast.Module(body=[ast.ClassDef(name='BareUmbrella',bases=[],keywords=[],body=methods,decorator_list=[])],type_ignores=[])
ast.fix_missing_locations(mod)
ns={'np':np}; exec(compile(mod,'<umbrella-basis>','exec'),ns)


def test_family_specific_native_z_is_normalised_once_without_mutating_input():
    w=ns['BareUmbrella'](); w.acoustic_frequency_hz=230_000.0; w.acoustic_system_profile='Brain 220 family'
    points=np.asarray([[1.0,2.0,3.0],[-1.0,-2.0,-4.0]])
    converted=w._canonical_umbrella_points(points)
    np.testing.assert_allclose(converted,[[1.0,2.0,-3.0],[-1.0,-2.0,4.0]])
    np.testing.assert_allclose(points,[[1.0,2.0,3.0],[-1.0,-2.0,-4.0]])

    w.acoustic_frequency_hz=690_000.0; w.acoustic_system_profile='Brain 650 family'
    np.testing.assert_allclose(w._canonical_umbrella_points(points),points)
