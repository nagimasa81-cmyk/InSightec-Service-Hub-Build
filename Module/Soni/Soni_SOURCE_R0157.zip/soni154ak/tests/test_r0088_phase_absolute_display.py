
from pathlib import Path

def test_sonication_phase_display_keeps_absolute_wrapped_reference():
    src=(Path(__file__).parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'plotted = np.angle(np.exp(1j * phase_arr))' in src
    assert "phase_label = 'wrapped sonication phase'" in src

def test_phase_dedicated_keeps_physical_geometry_and_phase_as_colour():
    src=(Path(__file__).parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'Channel position comes only from exported geometry.' in src
    assert 'Phase controls colour only.' in src
