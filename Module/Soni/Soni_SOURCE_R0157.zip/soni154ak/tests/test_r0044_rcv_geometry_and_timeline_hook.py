from pathlib import Path
import numpy as np

from src.services.cavitation_likelihood_service import CavitationLikelihoodService


def test_default_rcv_geometry_matches_reference_layout():
    pos = CavitationLikelihoodService.DEFAULT_POSITIONS
    assert pos.shape == (8, 2)
    # Cap RCV inner: 0 upper-left, 1 upper-right, 2 lower-right, 3 lower-left
    assert pos[0,0] < 0 and pos[0,1] > 0
    assert pos[1,0] > 0 and pos[1,1] > 0
    assert pos[2,0] > 0 and pos[2,1] < 0
    assert pos[3,0] < 0 and pos[3,1] < 0
    # Tile RCV outer: 4 upper-left, 5 upper-right, 6 lower-right, 7 lower-left
    assert pos[4,0] < 0 and pos[4,1] > 0
    assert pos[5,0] > 0 and pos[5,1] > 0
    assert pos[6,0] > 0 and pos[6,1] < 0
    assert pos[7,0] < 0 and pos[7,1] < 0
    assert np.all(np.linalg.norm(pos[4:], axis=1) > np.linalg.norm(pos[:4], axis=1))
    assert CavitationLikelihoodService.RECEIVER_FAMILY == ("Cap","Cap","Cap","Cap","Tile","Tile","Tile","Tile")


def test_ui_refresh_restores_observed_timeline_hook():
    source = Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'self._load_observed_cavitation_timeline()' in source
    assert 'self._draw_observed_cavitation_timeline()' in source
    # R0116zzd: control-log parsing is worker/repository owned; GUI binds cached timeline only.
    assert 'self.control_timeline_service.parse(' not in source[source.index('    def _load_observed_cavitation_timeline'):source.index('    def _direct_replay_band_cube')]
    assert 'cache.get("observed_cavitation_timeline")' in source
