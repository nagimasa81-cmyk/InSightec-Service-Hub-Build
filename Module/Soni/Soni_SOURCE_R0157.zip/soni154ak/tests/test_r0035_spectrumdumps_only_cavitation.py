import numpy as np
from types import SimpleNamespace

from src.services.standalone_cavitation_service import StandaloneCavitationService


def _frame(index, value=1.0, cycle=None):
    energies=np.ones((8,4),float)*value
    return SimpleNamespace(
        vendor_band_energies=energies,
        acquisition_cycle=cycle,
        acquisition_time_s=(None if cycle is None else (cycle-1)*0.01),
    )


def test_dump_only_labels_outlier_as_candidate_not_vendor_trigger():
    frames=[_frame(i,1.0) for i in range(12)]
    frames[8].vendor_band_energies[3,2]=50.0
    replay=SimpleNamespace(frames=frames,vendor_profile=None)
    result=StandaloneCavitationService().analyze(replay,"SpectrumDumps Only",3.0)
    assert result.mode == "SpectrumDumps Only"
    assert "candidate" in result.rule_status.lower()
    assert any(e.channel==3 and e.band==2 and e.severity=="Candidate" for e in result.events)
    assert not any(e.severity=="Rule Trigger" for e in result.events)


def test_dump_only_preserves_exact_cycle_when_decoder_mapped_it():
    frames=[_frame(i,1.0,cycle=20+i*40) for i in range(5)]
    frames[3].vendor_band_energies[0,0]=30.0
    replay=SimpleNamespace(frames=frames,vendor_profile=None)
    result=StandaloneCavitationService().analyze(replay,"SpectrumDumps Only",2.0)
    assert result.timing_status.startswith("Exact")
    event=next(e for e in result.events if e.channel==0 and e.band==0)
    assert event.acquisition_cycle == 140
    assert abs(event.time_s-1.39) < 1e-9


def test_dump_only_recovers_band_ranges_from_embedded_energy():
    freq=np.arange(100_000.0, 356_000.0, 1_000.0)
    frames=[]
    ranges={0:(20,40),1:(60,75),2:(100,106),3:(150,158)}
    rng=np.random.default_rng(3)
    for fi in range(5):
        channels=[]; energies=np.zeros((8,4),float)
        for ch in range(8):
            amp=rng.random(freq.size,dtype=np.float32)*0.01 + np.float32((ch+1)*(fi+1)*1e-5)
            channels.append(amp)
            for b,(i,j) in ranges.items():
                energies[ch,b]=float(np.sum(amp[i:j+1],dtype=np.float32))
        frames.append(SimpleNamespace(
            vendor_band_energies=energies, uncalibrated_channels=channels,
            frequency_hz=freq, acquisition_cycle=None, acquisition_time_s=None,
        ))
    replay=SimpleNamespace(frames=frames,vendor_profile=None)
    result=StandaloneCavitationService().analyze(replay,"SpectrumDumps Only",6.0)
    assert len(result.inferred_bands)==4
    for b,(i,j) in ranges.items():
        low,high,error=result.inferred_bands[b]
        assert low == freq[i]
        assert high == freq[j]
        assert error < 1e-6
