from pathlib import Path

from src.services.acoustic_control_service import AcousticControlService
from src.services.cavitation_control_timeline_service import CavitationControlTimelineService
from src.services.hydrophone_replay_service import CpcHydrophoneReplay


def test_cpc_replay_declares_sonication_index_in_slots():
    replay = CpcHydrophoneReplay(None, None)
    replay.sonication_index = 4
    assert replay.sonication_index == 4


def test_treatment_segment_mapping_counts_wrapped_sonication_dirs(tmp_path):
    wrapper = tmp_path / "17-00-24_ANx"
    wrapper.mkdir()
    for n in range(1, 9):
        (wrapper / f"Sonication{n}").mkdir()
    svc = AcousticControlService()
    # 15 Acquisition sessions, final eight are treatment => indexes 7..14.
    assert [svc._treatment_segment_index(tmp_path, i, 15) for i in range(8)] == list(range(7, 15))


def test_control_timeline_log_lookup_recurses_from_wrapped_workspace(tmp_path):
    log = tmp_path / "case" / "CPCFiles" / "Acquisition_Brain_test.txt"
    log.parent.mkdir(parents=True)
    log.write_text("test", encoding="utf-8")
    assert CavitationControlTimelineService._find_log(tmp_path) == log


def test_repository_preserves_candidate_mapping_provenance():
    source = Path(__file__).resolve().parents[1] / "src/services/spectrum_evidence_repository.py"
    text = source.read_text(encoding="utf-8")
    assert 'replay.mapping_confidence = str(getattr(candidate, "mapping_confidence"' in text
    assert 'replay.mapping_evidence = str(getattr(candidate, "mapping_evidence"' in text


def test_package_map_fallback_uses_candidate_session_not_arbitrary_max_event_session():
    source = Path(__file__).resolve().parents[1] / "src/ui/main_window.py"
    text = source.read_text(encoding="utf-8")
    block = text.split("class TreatmentOutcomeScienceWorker", 1)[1].split("class SpectrumPreloadWorker", 1)[0]
    assert 'preferred=getattr(candidate,"acquisition_session_index",None)' in block
    assert 'preferred=acoustic._treatment_segment_index' in block
    assert 'timeline_available = getattr(timeline, "source_log", None) is not None and preferred is not None' in block
