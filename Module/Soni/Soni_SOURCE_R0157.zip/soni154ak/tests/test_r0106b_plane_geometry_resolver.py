from pathlib import Path
from src.services.planning_data_service import PlanningDataService


def test_geometry_resolves_axial_when_numeric_plane_code_is_unknown():
    svc=PlanningDataService()
    # Real 10-00-09_ANx series 900 / field 19 direction cosines.
    rd=(0.0087,-0.994919,-0.100302)
    cd=(-0.99984,-0.0102,0.014701)
    assert svc._plane_from_description('(Creator:10362)',2,2,rd,cd)=='Ax'


def test_geometry_resolves_each_orthogonal_plane():
    svc=PlanningDataService()
    assert svc._plane_from_direction_cosines((0,1,0),(0,0,1))=='Sag'
    assert svc._plane_from_direction_cosines((1,0,0),(0,0,1))=='Cor'
    assert svc._plane_from_direction_cosines((1,0,0),(0,1,0))=='Ax'


def test_description_and_known_codes_keep_priority():
    svc=PlanningDataService()
    assert svc._plane_from_description('BRAVO Sag',2,2,(1,0,0),(0,1,0))=='Sag'
    assert svc._plane_from_description('',18,18,(0,1,0),(0,0,1))=='Ax'
