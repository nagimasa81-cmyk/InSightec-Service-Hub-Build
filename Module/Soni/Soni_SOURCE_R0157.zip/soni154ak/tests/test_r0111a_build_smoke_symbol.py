from pathlib import Path
import ast

MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_xd_window_constructor_resolves():
    assert "class SkullElementWindow(QDialog):" in MAIN
    assert "self.xd_window = SkullElementWindow(self)" in MAIN
    assert "self.xd_window = XDWindow(self)" not in MAIN

def test_no_duplicate_methods():
    tree=ast.parse(MAIN)
    for node in ast.walk(tree):
        if isinstance(node,ast.ClassDef):
            seen=set()
            for item in node.body:
                if isinstance(item,(ast.FunctionDef,ast.AsyncFunctionDef)):
                    assert item.name not in seen, f"duplicate {node.name}.{item.name}"
                    seen.add(item.name)
