from pathlib import Path
from types import SimpleNamespace
import numpy as np

import src.services.spectrum_evidence_repository as repo_mod
from src.services.spectrum_evidence_repository import SpectrumEvidenceRepository


def _replay():
    return SimpleNamespace(
        mapping_confidence='Unknown', mapping_evidence='Unresolved',
        vendor_history_validation=None, acquisition_session_index=None,
        source_fft=Path('dummy_fft.dmp'), source_raw=None,
        acquisition_interval_s=0.010, sonication_time_zero_offset_s=0.0,
        sonication_cycle_zero=None,
        controller_cycle_numbers=np.asarray([], dtype=int),
        controller_cycle_mr_times_s=np.asarray([], dtype=float),
    )


def test_repository_builds_cycle_map_in_canonical_mr_axis(monkeypatch, tmp_path: Path):
    calls=[]
    def fake_parse(self, source, profile, preferred, predicted_cycles, predicted_ratio,
                   zero_offset, mr_start, mr_end, mr_duration, anchor_cycle, anchor_time, interval):
        calls.append((mr_start, mr_end, mr_duration))
        return SimpleNamespace(
            actual_power_cycles=np.asarray([514, 515], dtype=int),
            cycle_numbers=np.asarray([514, 515], dtype=int),
            cycle_times_s=np.asarray([mr_start, mr_start + 0.012], dtype=float),
        )
    monkeypatch.setattr(repo_mod.CavitationControlTimelineService, 'parse', fake_parse)
    repo=SpectrumEvidenceRepository()
    package=SimpleNamespace(workspace=tmp_path)
    son=SimpleNamespace(
        canonical_acquisition_session_index=0,
        mr_timeline_duration_s=41.125,
        mr_sonication_start_s=6.895,
        mr_sonication_end_s=20.004,
        mr_timeline_source='exact', mr_timeline_confidence='High',
    )
    replay=_replay()
    repo._configure_replay(package, 0, son, replay, None)
    assert calls == [(6.895, 20.004, 41.125)]
    assert np.allclose(replay.controller_cycle_mr_times_s, [6.895, 6.907])


def test_repository_clears_stale_cycle_map_when_rebind_parse_fails(monkeypatch, tmp_path: Path):
    def fail(*args, **kwargs):
        raise RuntimeError('bad session')
    monkeypatch.setattr(repo_mod.CavitationControlTimelineService, 'parse', fail)
    repo=SpectrumEvidenceRepository()
    package=SimpleNamespace(workspace=tmp_path)
    son=SimpleNamespace(canonical_acquisition_session_index=0, mr_timeline_duration_s=40.0,
                        mr_sonication_start_s=7.0, mr_sonication_end_s=20.0,
                        mr_timeline_source='x', mr_timeline_confidence='High')
    replay=_replay()
    replay.sonication_cycle_zero=123
    replay.controller_cycle_numbers=np.asarray([1,2])
    replay.controller_cycle_mr_times_s=np.asarray([7.0,7.01])
    repo._configure_replay(package, 0, son, replay, None)
    assert replay.sonication_cycle_zero is None
    assert replay.controller_cycle_numbers.size == 0
    assert replay.controller_cycle_mr_times_s.size == 0


def test_replay_public_cycle_mapper_prefers_exact_wallclock():
    from src.services.hydrophone_replay_service import CpcHydrophoneReplay
    replay=CpcHydrophoneReplay(None, None, mr_sonication_start_s=7.0, sonication_cycle_zero=100,
                               acquisition_interval_s=0.010)
    replay.controller_cycle_numbers=np.asarray([100,101,102],dtype=int)
    replay.controller_cycle_mr_times_s=np.asarray([7.0,7.013,7.031],dtype=float)
    assert np.allclose(replay.cycles_to_mr_times([100,102]), [7.0,7.031])


def test_ci_source_does_not_recompute_controller_cycles_with_fixed_interval():
    text=Path('src/ui/main_window.py').read_text(encoding='utf-8')
    start=text.index('def _draw_ci_linked_control')
    end=text.index('def _update_ci_linked_panel', start)
    body=text[start:end]
    assert 'cycles_to_mr_times(cycles)' in body
    assert '(cycles-float(cycle_zero))*interval' not in body
