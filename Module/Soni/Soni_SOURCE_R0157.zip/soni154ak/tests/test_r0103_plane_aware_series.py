
from pathlib import Path
REG=(Path(__file__).parents[1]/"src/services/registration_overlay_service.py").read_text(encoding="utf-8")
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_series_grouping_not_slice_spam():
    b=REG.split("def diagnose_reference_series",1)[1].split("def format_reference_diagnostic",1)[0]
    assert "groups.setdefault(self._series_key(asset),[])" in b
    assert '"slice_count":len(assets)' in b

def test_through_plane_distance_selects_representative_slice():
    assert "def _slice_plane_distance_mm" in REG
    b=REG.split("def diagnose_reference_series",1)[1].split("def format_reference_diagnostic",1)[0]
    assert "forward_plane_distance_mm" in b
    assert "rep=min(slices,key=rep_key)" in b

def test_active_plane_ranking():
    b=REG.split("def diagnose_reference_series",1)[1].split("def format_reference_diagnostic",1)[0]
    assert "same_plane=bool(active_plane and plane==active_plane)" in b
    assert "if same_plane:score+=25.0" in b

def test_report_is_series_level():
    b=REG.split("def format_reference_diagnostic",1)[1].split("def _trace_ct_voxel_to_mr_pixel",1)[0]
    assert "REFERENCE SERIES (series-level, plane-aware" in b
    assert "LEADING REFERENCE SERIES:" in b
    assert "ACTIVE SERIES" in b
    assert "SAME PLANE" in b

def test_main_passes_active_asset():
    b=MAIN.split("def _update_registration_reference_report",1)[1].split("def _apply_registration_overlay",1)[0]
    assert "active_asset=self._active_planning_asset" in b
