from pathlib import Path
RECV=(Path(__file__).parents[1]/"src/services/sonication_log_receiver_service.py").read_text(encoding="utf-8")
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_total_phase_unwrapped_radians():
    b=RECV.split("def _merge_sonication_phase",1)[1].split("def read_snapshots",1)[0]
    assert "Total Phase Shift (unwrapped radians)" in b
    assert "math.radians" not in b

def test_steering_residual():
    b=RECV.split("def _merge_sonication_phase",1)[1].split("def read_snapshots",1)[0]
    assert "total_raw[ch]-correction" in b
    assert "steering_phase_rad" in b

def test_focus_uses_residual_and_exported_focal():
    b=MAIN.split("def _phase_focus_for_snapshot",1)[1].split("def _sonication_element_geometry",1)[0]
    assert 'getattr(value,"steering_phase_rad",None)' in b
    assert "focal_point_xyz_mm" in b
    assert "Phase input: wrap(Total Phase Shift - Phase Correction)" in b
