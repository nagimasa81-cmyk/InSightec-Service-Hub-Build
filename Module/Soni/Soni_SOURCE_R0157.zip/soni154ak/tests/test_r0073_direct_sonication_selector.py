from pathlib import Path


def test_r0073_direct_sonication_selector_present():
    text=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")
    assert "self.sonication_combo = QComboBox()" in text
    assert "self.sonication_combo.currentIndexChanged.connect(self._sonication_combo_changed)" in text
    assert "def _populate_sonication_combo" in text
    assert "def _sonication_combo_changed" in text
    assert "self._select_sonication_index(index)" in text
    assert "self._populate_sonication_combo()" in text
