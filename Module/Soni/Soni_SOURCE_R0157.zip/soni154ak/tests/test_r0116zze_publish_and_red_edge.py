from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
IMAGE=(ROOT/'src/ui/image_panel.py').read_text(encoding='utf-8')

def test_secondary_uses_background_progress_dialog():
    assert 'BusyProgressDialog, BackgroundProgressDialog' in HYDRO
    assert 'self._secondary_progress = BackgroundProgressDialog(self)' in HYDRO

def test_worker_ready_schedules_without_full_view_clear():
    start=HYDRO.index('def _schedule_secondary_publish')
    end=HYDRO.index('def _publish_secondary_stage', start)
    body=HYDRO[start:end]
    assert '_clear_secondary_analysis_views()' not in body
    assert 'QTimer.singleShot(1' in body
    assert '_exclusive_progress' in body and '.finish()' in body

def test_cached_secondary_uses_same_staged_publish_path():
    start=HYDRO.index('def _queue_secondary_analysis')
    end=HYDRO.index('def _start_secondary_analysis', start)
    body=HYDRO[start:end]
    assert 'self._schedule_secondary_publish(replay, cached)' in body
    assert 'self._publish_secondary_payload()' not in body

def test_publish_stage_progress_is_identifiable():
    assert '(97, "Publishing Spectrogram…"' in HYDRO
    assert '(98, "Publishing Vendor Band Energy…"' in HYDRO
    assert '(99, "Publishing Vendor control views…"' in HYDRO
    assert 'Publishing cavitation evidence / control timeline…' in HYDRO

def test_red_threshold_mask_is_binary_and_not_blurred():
    start=IMAGE.index('if solid_red_fill and temperature_threshold is not None:')
    end=IMAGE.index('else:', start)
    body=IMAGE[start:end]
    assert 'alpha=mask.astype(float)' in body
    assert '_smooth_binary_mask' not in body
    assert 'arr>=float(threshold)' in IMAGE
