from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')


def test_cache_backed_images_are_allowed_during_background_load():
    assert 'images_enabled = self._image_loading_enabled()' in MAIN
    assert 'if images_enabled and bool(locals().get("cache_image_ready", False))' in MAIN
    assert 'if int(row)==int(target_row):' in MAIN
    assert 'defer_heavy=True' in MAIN


def test_selected_sonication_retargets_cpc_preload_and_merges_cache():
    assert 'self._start_spectrum_preload(self.package, int(self.sonication_index))' in MAIN
    assert 'merged["ready_indices"]=' in MAIN
    assert 'replays.update(context.get("replays",{}) or {})' in MAIN


def test_analyzer_72_percent_boundary_yields_before_metadata_publish():
    assert 'Decoded Spectrum ready — handing off metadata' in HYDRO
    assert '_finish_loaded_sonication_handoff' in HYDRO
    assert 'QTimer.singleShot(1' in HYDRO
    boundary=HYDRO.index('Decoded Spectrum ready — handing off metadata')
    handoff=HYDRO.index('def _finish_loaded_sonication_handoff', boundary)
    assert HYDRO.index('dlg.finish()', boundary, handoff) > boundary
