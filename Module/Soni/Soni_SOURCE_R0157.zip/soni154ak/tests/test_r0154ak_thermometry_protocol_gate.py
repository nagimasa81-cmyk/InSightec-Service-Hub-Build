from pathlib import Path
from types import SimpleNamespace

import numpy as np

from src.services.replay_service import ReplayService


def _sonication(root: Path, series: str):
    folder = root / "Sonication1"
    folder.mkdir(exist_ok=True)
    raw = folder / "5-1-0-0.raw"
    np.full((256, 256), 37.0, dtype="<f4").tofile(raw)
    (root / "MriImageParams.xml").write_text(
        "<xml xmlns:z='#RowsetSchema'><rs:data xmlns:rs='urn:schemas-microsoft-com:rowset'>"
        f"<z:row sonicationindex='1' fieldindex='5' zoneindex='0' arrayindex='0' seriesdiscription='{series}'/>"
        "</rs:data></xml>", encoding="utf-8")
    frame = SimpleNamespace(path=raw)
    return SimpleNamespace(folder=folder, temperature_frames=[frame])


def test_temperature_like_t2star_values_are_rejected(tmp_path: Path):
    service = ReplayService()
    son = _sonication(tmp_path, "T2_Star_ME_1SL")
    assert service._thermometry_protocol(son)[0] is False
    assert service._temperature_mode(son)[0] == "Unavailable"


def test_exact_tmap_protocol_allows_conservative_value_classifier(tmp_path: Path):
    service = ReplayService()
    son = _sonication(tmp_path, "TMAP-ME Axial")
    assert service._thermometry_protocol(son)[0] is True
    assert service._temperature_mode(son)[0] == "Absolute RAW"
