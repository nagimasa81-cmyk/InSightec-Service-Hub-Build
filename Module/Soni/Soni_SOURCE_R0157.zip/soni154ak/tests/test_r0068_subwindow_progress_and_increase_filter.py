from pathlib import Path

def test_r0068_hydrophone_progress_and_increase_filter_present():
    text=Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    assert 'QCheckBox("Show Increase events")' in text
    assert 'setChecked(False)' in text
    assert 'Increase events are hidden from both the chart and event list by default' in text
    assert '_visible_observed_events' in text
    assert 'str(getattr(ev, "family", "")) != "Increase"' in text
    assert '_set_subwindow_progress' in text
    assert 'background FFT / RAW decode' in text or 'Decoding 8-channel FFT snapshots' in text
    assert 'publishing cavitation evidence / control timeline' in text.lower()

def test_r0068_other_dialogs_have_progress_feedback():
    text=Path("src/ui/main_window.py").read_text(encoding="utf-8")
    assert 'self.progress_bar = QProgressBar()' in text
    assert 'Loading element data' in text
    assert 'Updating details' in text
