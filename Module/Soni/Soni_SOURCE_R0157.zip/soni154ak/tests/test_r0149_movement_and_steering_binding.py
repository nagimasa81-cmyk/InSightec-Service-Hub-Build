from pathlib import Path
import xml.etree.ElementTree as ET

from src.services.movement_detection_service import MovementDetectionService
from src.services.sonication_evidence_service import SonicationEvidenceService, SonicationEvidence


def _rowset(path: Path, rows):
    root=ET.Element('xml')
    data=ET.SubElement(root,'data')
    for attrs in rows:
        ET.SubElement(data,'row', {k:str(v) for k,v in attrs.items()})
    ET.ElementTree(root).write(path, encoding='utf-8')


def test_researchparameters_correctshift_is_directional_movement(tmp_path):
    _rowset(tmp_path/'researchparameters.xml', [
        {'sonicationindex':1,'bcorrectshift':1,'correctshiftx':0.1,'correctshifty':0.0,'correctshiftz':0.2},
        {'sonicationindex':2,'bcorrectshift':0,'correctshiftx':9.0,'correctshifty':9.0,'correctshiftz':9.0},
    ])
    rows=MovementDetectionService().read_indexed(tmp_path)
    assert rows[1].display == 'R0.1 S0.2 A0.0'
    assert 2 not in rows


def test_treatment_sonication_brain_is_selected_by_summary_clock(tmp_path):
    _rowset(tmp_path/'SonicationSummary.xml', [
        {'sonicationindex':1,'sontime':'20260823183429','power':20,'duration':13,'frequency':670000},
    ])
    old=tmp_path/'Sonication_Brain_650_Sun_Aug_23_16_30_13_2026.txt'
    new=tmp_path/'Sonication_Brain_650_Sun_Aug_23_18_27_30_2026.txt'
    old.write_text('16:31:00:000 Inf CPC Burn Spot fields:\n\tAcoustic Power <99>\n\tDuration <13>\n\tFrequency <0.6700> MHz\n\tSonication Type <6>\n\tSteering X <0>\n\tSteering Y <0>\n\tSteering Z <150>\n')
    new.write_text('18:34:08:255 Inf CPC Burn Spot fields:\n\tAcoustic Power <20>\n\tDuration <13>\n\tFrequency <0.6700> MHz\n\tSonication Type <6>\n\tSteering X <4>\n\tSteering Y <4>\n\tSteering Z <154>\n')
    svc=SonicationEvidenceService()
    assert svc._find_treatment_sonication_log(tmp_path) == new
    recs=svc.parse_setup_records(tmp_path)
    assert len(recs)==1
    assert recs[0].steering_xyz == (4.0,4.0,154.0)


def test_setup_duration_accepts_direct_workstation_relation():
    ev=SonicationEvidence(1, displayed_power_w=30, summary_duration_s=13, frequency_hz=670000)
    from src.services.sonication_evidence_service import SonicationSetupRecord
    rec=SonicationSetupRecord(clock_s=1, power_w=30, duration_s=13, frequency_hz=670000, sonication_type=6)
    assert SonicationEvidenceService._setup_match_cost(ev, rec) == 0.0


def test_elements_ui_uses_canonical_per_sonication_steering():
    text=(Path(__file__).parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert '_canonical_steering_delta' in text
    assert 'Electronic steering APPLIED' in text
    assert 'Authoritative steering status comes from the selected Sonication setup' in text
    assert '_parse_requested_steering' not in text
