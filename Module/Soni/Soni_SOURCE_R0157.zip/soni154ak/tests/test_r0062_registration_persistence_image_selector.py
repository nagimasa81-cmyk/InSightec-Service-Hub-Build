from pathlib import Path
TEXT=(Path(__file__).resolve().parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')

def test_registration_state_persistence_logic_is_present():
    assert 'Preserve the user\'s Registration ON request while browsing other images.' in TEXT
    assert 'self.registration_overlay_enabled' in TEXT

def test_r0072_uses_thumbnail_strip_instead_of_image_number_combo():
    assert 'self.planning_image_combo = QComboBox()' not in TEXT
    assert 'slide horizontally to browse all' in TEXT
