from pathlib import Path


def _source():
    return Path("src/ui/main_window.py").read_text(encoding="utf-8")

def test_power_score_x_axis_links_temperature():
    s=_source()
    assert "self.acoustic_control_plot.setXLink(self.temperature_plot)" in s
    block=s[s.index("def _update_acoustic_replay_view"):s.index("def _ensure_acoustic_curve_items")]
    assert "temp_axis" in block
    assert "self.acoustic_control_plot.setXLink(self.temperature_plot)" in block
    assert "plot_tx <= float(current_s)" in block  # progressive data clipping only

def test_registration_controls_are_vertical_stack():
    s=_source()
    assert "self.image_action_stack = QWidget()" in s
    assert "image_action_layout.addWidget(self.registration_toggle_btn)" in s
    assert "image_action_layout.addWidget(self.registration_trace_btn)" in s
    assert "image_action_layout.addWidget(self.load_images_toggle)" in s

def test_right_sections_use_horizontal_visibility_checkboxes():
    s=_source()
    for name in ("right_images_check","right_trends_check","right_analysis_check"):
        assert name in s
    assert 'QCheckBox("Images / Registration")' in s
    chart=s[s.index("def _chart_panel"):s.index("def _make_image_strip")]
    # R0116zw: local chart buttons were intentionally removed; the enclosing
    # replay sections own collapse so plots keep the full available viewport.
    assert "QToolButton" not in chart
    assert "lay.addWidget(plot, 1)" in chart
