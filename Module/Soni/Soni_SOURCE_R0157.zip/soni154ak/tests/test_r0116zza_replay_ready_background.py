from pathlib import Path

MAIN = Path(__file__).resolve().parents[1] / 'src/ui/main_window.py'
TEXT = MAIN.read_text(encoding='utf-8')


def body(name: str) -> str:
    start = TEXT.index(f'    def {name}(')
    nxt = TEXT.find('\n    def ', start + 8)
    return TEXT[start: nxt if nxt > 0 else len(TEXT)]


def test_cavitation_stage_does_not_decode_cpc_on_gui_thread():
    b = body('_selected_stage_cavitation')
    assert '_prepare_default_cavitation_intelligence()' not in b
    assert '_build_cpc_replay(' not in b
    assert '_spectrum_preload_context' in b


def test_metadata_stage_is_only_fast_plus_background_handoff():
    b = body('_selected_stage_metadata')
    assert '_update_sonication_metadata_fast()' in b
    assert '_start_sonication_metadata_background()' in b
    assert 'QTimer.singleShot(0, self._update_sonication_metadata)' not in b


def test_metadata_worker_has_stale_study_and_generation_guards():
    assert 'class SonicationMetadataWorker(QObject):' in TEXT
    b = body('_sonication_metadata_background_ready')
    assert 'Path(self.package.workspace) != Path(workspace)' in b
    assert 'generation' in b and '_selection_generation' in b
    assert 'sonication_index' in b


def test_cavitation_is_lazy_on_explicit_ci_open():
    b = body('_main_tab_changed')
    assert '_prepare_cavitation_on_demand' in b
    assert 'widget is self.cavitation_intelligence_tab' in b


def test_progress_labels_document_background_handoff():
    assert 'Cavitation evidence (background)' in TEXT
    assert 'Metadata handoff (background)' in TEXT
