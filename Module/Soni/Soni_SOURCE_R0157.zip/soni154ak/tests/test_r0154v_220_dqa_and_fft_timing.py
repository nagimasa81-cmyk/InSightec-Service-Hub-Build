from types import SimpleNamespace
import numpy as np
from src.services.hydrophone_replay_service import CpcHydrophoneReplay, CpcHydrophoneFrame
from src.services.spectrum_evidence_repository import SpectrumEvidenceRepository


def _frame(i, cycle):
    return CpcHydrophoneFrame(i, np.asarray([100e3,230e3]), [np.asarray([1.,2.]) for _ in range(8)], acquisition_cycle=cycle, acquisition_time_s=i*0.01)


def test_collapsed_fft_cycles_rebound_across_irradiation_window():
    r=CpcHydrophoneReplay(None,None)
    r.frames=[_frame(i,i+1) for i in range(18)]
    r.snapshot_cycle_mapping_validated=True
    r.mr_sonication_start_s=7.6
    r.mr_sonication_end_s=27.68
    r.controller_cycle_numbers=np.arange(500,2501,dtype=int)
    r.controller_cycle_mr_times_s=np.linspace(7.6,27.68,2001)
    SpectrumEvidenceRepository._repair_snapshot_timing(r)
    t=r.mr_frame_times_s
    assert len(t)==18
    assert np.all(np.diff(t)>0)
    assert t[0] >= 7.59 and t[-1] <= 27.69
    assert t[-1]-t[0] > 18.0
    assert not r.snapshot_cycle_mapping_validated
    assert 'irradiation-window' in r.snapshot_timing_source


def test_plausible_exact_fft_cycles_are_not_rewritten():
    r=CpcHydrophoneReplay(None,None)
    cycles=np.linspace(500,2500,18).round().astype(int)
    r.frames=[_frame(i,int(c)) for i,c in enumerate(cycles)]
    r.snapshot_cycle_mapping_validated=True
    r.mr_sonication_start_s=7.6
    r.mr_sonication_end_s=27.68
    r.controller_cycle_numbers=np.arange(500,2501,dtype=int)
    r.controller_cycle_mr_times_s=np.linspace(7.6,27.68,2001)
    SpectrumEvidenceRepository._repair_snapshot_timing(r)
    assert r.frame_mr_time_override_s.size==0
    assert r.snapshot_cycle_mapping_validated
    assert r.snapshot_timing_source.startswith('Exact')

def test_r0154w_timing_repair_preserves_original_cycle_evidence():
    import numpy as np
    from types import SimpleNamespace
    from src.services.spectrum_evidence_repository import SpectrumEvidenceRepository

    frames=[SimpleNamespace(acquisition_cycle=i+1) for i in range(18)]
    replay=SimpleNamespace(
        frames=frames,
        frame_mr_time_override_s=np.asarray([],float),
        snapshot_cycle_mapping_validated=True,
        controller_cycle_numbers=np.arange(1,5001,dtype=int),
        controller_cycle_mr_times_s=np.arange(5000,dtype=float)*0.01,
        mr_sonication_start_s=7.7,
        mr_sonication_end_s=27.7,
        mapping_evidence='fixture',
    )
    original=[f.acquisition_cycle for f in frames]
    SpectrumEvidenceRepository._repair_snapshot_timing(replay)
    assert replay.frame_mr_time_override_s.size == 18
    assert [f.acquisition_cycle for f in frames] == original
    assert replay.snapshot_cycle_mapping_validated is False
    assert 'display timing only' in replay.mapping_evidence
