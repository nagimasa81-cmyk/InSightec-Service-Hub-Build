from pathlib import Path
import ast
ROOT=Path(__file__).parents[1]
H=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')

def test_probable_location_uses_explicit_event_state_only():
    assert 'self._selected_observed_event_index = None' in H
    assert 'idx=getattr(self,"_selected_observed_event_index",None)' in H
    assert 'self._selected_observed_event_index=None' in H

def test_event_and_replay_cursor_independent_default():
    assert 'QCheckBox("Sync replay to selected event")' in H
    assert 'self.sync_replay_to_event_check.setChecked(False)' in H
    assert 'and self.sync_replay_to_event_check.isChecked()' in H

def test_control_timeline_why_is_gated_by_dedicated_checkbox():
    assert 'def _show_event_why_popup(self, ev, force: bool = False)' in H
    assert 'self.control_why_popup_check = QCheckBox("Why popup")' in H
    assert 'self.control_why_popup_check.setChecked(False)' in H
    assert H.count('control_why_popup_check.isChecked()') >= 2
    assert '_show_event_why_popup(event, force=True)' in H
    assert '_show_event_why_popup(ev, force=True)' in H

def test_event_table_self_heals():
    assert 'def _ensure_observed_event_table_integrity' in H
    assert 'Event list rows {actual}/{expected}' in H
    assert 'QTimer.singleShot(0, self._ensure_observed_event_table_integrity)' in H

def test_ast():
    ast.parse(H)
