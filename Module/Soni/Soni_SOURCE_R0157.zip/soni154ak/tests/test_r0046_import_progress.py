from pathlib import Path
import zipfile

from src.services.import_service import ImportService


def test_zip_progress_callback(tmp_path):
    source=tmp_path/'sample.zip'
    with zipfile.ZipFile(source,'w') as z:
        for i in range(10):
            z.writestr(f'data/f{i}.txt', 'x'*32)
    calls=[]
    svc=ImportService()
    workspace=svc.open(source, progress_callback=lambda value,message: calls.append((value,message)))
    assert workspace.exists()
    assert calls
    assert max(v for v,_ in calls) >= 70
    assert any('Extracting' in m for _,m in calls)
    svc.cleanup()


def test_folder_progress_callback(tmp_path):
    calls=[]
    svc=ImportService()
    workspace=svc.open(tmp_path, progress_callback=lambda value,message: calls.append((value,message)))
    assert workspace == tmp_path.resolve()
    assert calls[-1][0] == 70
