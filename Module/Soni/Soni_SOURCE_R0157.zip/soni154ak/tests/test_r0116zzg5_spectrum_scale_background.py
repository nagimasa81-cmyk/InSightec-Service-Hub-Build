from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UI = (ROOT / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
SERVICE = (ROOT / 'src/services/hydrophone_replay_service.py').read_text(encoding='utf-8')


def test_fixed_spectrum_scale_is_worker_owned():
    body = UI.split('    def _spectrum_fixed_y_range', 1)[1].split('    def _queue_spectrum_y_range', 1)[0]
    assert '_queue_spectrum_y_range' in body
    assert 'for frame in self.replay.frames' not in body
    assert 'for idx in range(len(self.replay.frames))' not in body


def test_heavy_prefix_modes_do_not_build_from_draw_callback():
    body = UI.split('    def _draw_spectrum(self):', 1)[1].split('    def _draw_spectrogram', 1)[0]
    assert 'Preparing fixed Spectrum scale in background' in body
    assert 'scale_key not in self._spectrum_y_cache' in body


def test_prefix_cache_can_be_shared_from_worker_to_gui_service():
    assert '_accumulated_prefix_cache: dict = field(default_factory=dict' in SERVICE
    assert 'shared = replay._accumulated_prefix_cache' in SERVICE
    assert 'shared[key] = cached' in SERVICE
