from types import SimpleNamespace
import numpy as np
from src.services.cavitation_root_cause_service import CavitationRootCauseService


def _replay(scale=1.0):
    frames=[]
    for i,factor in enumerate((1.0,1.1,1.4,2.7)):
        en=np.ones((8,4),float)*scale*factor
        en[3]*=(1+i*0.7)
        frames.append(SimpleNamespace(vendor_band_energies=en))
    return SimpleNamespace(frames=frames)


def test_root_cause_ranks_measured_evidence():
    ev=SimpleNamespace(family='Safety',result='HALTED BY CAVITATION',severity='Critical',weighted_energy=0.055,threshold=0.04,critical_threshold=0.05)
    result=CavitationRootCauseService().analyze(
        sonication_number=7,events=[ev],replay=_replay(),power=900,treatment_power_median=650,
        previous_power=700,energy=21000,duration=24,start_temp=39,peak_temp=58,delta_temp=19,
        previous_peak_temp=57,previous_cavitation=True,mr_correlation_score=72)
    assert result.cavitation_detected is True
    assert result.root_cause_score >= 55
    assert result.ranked_factors[0].contribution >= result.ranked_factors[-1].contribution
    assert any(f.key=='multiband' and f.available for f in result.factors)
    assert any(f.key=='history' and f.contribution>0 for f in result.factors)


def test_missing_data_is_not_inferred():
    result=CavitationRootCauseService().analyze(sonication_number=1,events=None)
    unavailable=[f.key for f in result.factors if not f.available]
    assert 'multiband' in unavailable and 'thermal' in unavailable and 'history' in unavailable
    assert result.confidence == 'Low'

def test_increase_rule_is_not_cavitation_event():
    ev=SimpleNamespace(family='Increase',result='ExPowerRatio 0.3 -> 0.4',severity='Observed',weighted_energy=0.1,threshold=0.01,critical_threshold=None)
    result=CavitationRootCauseService().analyze(sonication_number=2,events=[ev])
    assert result.cavitation_detected is False
    event=next(f for f in result.factors if f.key=='event')
    assert event.contribution == 0
