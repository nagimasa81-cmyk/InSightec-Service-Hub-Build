from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
REPO=(ROOT/'src/services/spectrum_evidence_repository.py').read_text(encoding='utf-8')
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')

def test_secondary_async_ownership_uses_semantic_replay_key():
    assert 'def _semantic_replay_key' in HYDRO
    assert 'def _cache_matches_replay' in HYDRO
    for token in [
        'self._cache_matches_replay(cache, self.replay)',
        'self._semantic_replay_key(replay) != self._semantic_replay_key(self.replay)',
        'payload["replay_key"] = self._semantic_replay_key(current)',
    ]:
        assert token in HYDRO

def test_repository_secondary_cache_survives_equivalent_replay_instance():
    assert 'def _replay_key' in REPO
    assert 'def _payload_matches_replay' in REPO
    assert '"replay_key": self._replay_key(index, replay)' in REPO
    assert 'self._payload_matches_replay(cached, index, replay)' in REPO

def test_selected_data_completion_re_materializes_visible_main_tab():
    assert 'def _refresh_visible_main_tab_after_data_handoff' in MAIN
    block=MAIN.split('def _selected_replay_data_ready',1)[1].split('def ',1)[0]
    assert 'self._refresh_visible_main_tab_after_data_handoff' in block

def test_spectrum_preload_completion_re_materializes_visible_main_tab():
    assert MAIN.count('self._refresh_visible_main_tab_after_data_handoff') >= 2
