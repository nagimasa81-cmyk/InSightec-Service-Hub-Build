
from pathlib import Path
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")
HYD=(Path(__file__).parents[1]/"src/ui/hydrophone_window.py").read_text(encoding="utf-8")

def test_ci_single_image_viewport():
    # Superseded by R0096: upper image viewport intentionally removed.
    assert 'self.ci_image_view_combo = QComboBox()' not in MAIN


def test_linked_lower_dropdown_has_only_two_time_views():
    # Superseded by R0096: lower panel intentionally restored to three choices.
    assert 'RCV Contribution + probable cavitation region' in MAIN
    assert 'self.ci_linked_mode.setCurrentIndex(2)' in MAIN


def test_linked_dropdown_is_display_only_no_heavy_redraw():
    block=MAIN.split("def _ci_linked_mode_changed",1)[1].split("def _ci_event_time",1)[0]
    assert "_update_ci_linked_panel()" not in block
    assert "setCurrentIndex" in block
    update=MAIN.split("def _update_ci_linked_panel",1)[1].split("def _",1)[0]
    assert "_ci_linked_data_key" in update
    assert "setUpdatesEnabled(False)" in update

def test_why_popup_is_visible_and_default_off():
    build=HYD.split("def _build_vendor_cavitation_tab",1)[1].split("def _build_cavitation_events_tab",1)[0]
    assert 'QCheckBox("Why popup")' in build
    assert "self.vendor_why_popup_check.setChecked(False)" in build
    assert "Why popup: OFF" in build

def test_why_popup_uses_timestamp_or_cycle_and_relaxed_hit_window():
    assert "def _event_time_seconds" in HYD
    assert 'getattr(ev, "cycle", None)' in HYD
    assert "def _why_click_tolerance_s" in HYD
    assert "max(0.35, interval * 3.0)" in HYD
    assert HYD.count("self._event_time_seconds(ev)") >= 2
