from src.services.sonication_metadata_service import SonicationMetadataService
from src.ui.i18n import ui_text, localize_qt_tree


def _row(row_vec, col_vec, freq):
    return {
        'rowdirectcosrasx': row_vec[0], 'rowdirectcosrasy': row_vec[1], 'rowdirectcosrasz': row_vec[2],
        'coldirectcosrasx': col_vec[0], 'coldirectcosrasy': col_vec[1], 'coldirectcosrasz': col_vec[2],
        'freqdirection': freq,
    }


def test_standard_plane_axis_relationships_use_anatomical_axis_plus_row_col():
    svc = SonicationMetadataService
    axial = _row((1, 0, 0), (0, 1, 0), 'ROW')
    assert svc._frequency_direction_display(axial, 'ROW') == 'RL (ROW)'
    assert svc._frequency_direction_display(axial, 'COL') == 'AP (COL)'

    sagittal = _row((0, 1, 0), (0, 0, 1), 'COL')
    assert svc._frequency_direction_display(sagittal, 'ROW') == 'AP (ROW)'
    assert svc._frequency_direction_display(sagittal, 'COL') == 'SI (COL)'

    coronal = _row((1, 0, 0), (0, 0, 1), 'ROW')
    assert svc._frequency_direction_display(coronal, 'ROW') == 'RL (ROW)'
    assert svc._frequency_direction_display(coronal, 'COL') == 'SI (COL)'


def test_row_col_is_not_assumed_from_plane_or_fixed_orientation():
    # Same axial physical plane, but row/column orientation is rotated 90 degrees.
    rotated_axial = _row((0, 1, 0), (1, 0, 0), 'ROW')
    assert SonicationMetadataService._orientation_from_cosines(rotated_axial) == 'Axial'
    assert SonicationMetadataService._frequency_direction_display(rotated_axial, 'ROW') == 'AP (ROW)'
    assert SonicationMetadataService._frequency_direction_display(rotated_axial, 'COL') == 'RL (COL)'


def test_missing_cosines_keeps_traceability_without_inventing_anatomical_axis():
    assert SonicationMetadataService._frequency_direction_display({}, 'ROW') == 'ROW'
    assert SonicationMetadataService._frequency_direction_display({}, 'COL') == 'COL'
    assert SonicationMetadataService._frequency_direction_display({}, None) == 'Unavailable'


def test_legacy_anatomical_direction_is_normalized_without_fake_row_col():
    assert SonicationMetadataService._frequency_direction_display({}, 'R/L') == 'RL'
    assert SonicationMetadataService._frequency_direction_display({}, 'A/P') == 'AP'
    assert SonicationMetadataService._frequency_direction_display({}, 'S/I') == 'SI'


class _HeaderItem:
    def __init__(self, text): self._text = text
    def text(self): return self._text
    def setText(self, value): self._text = value


class _FakeWidget:
    def __init__(self):
        self._children = []
        self._items = ['Power', 'Peak temperature', 'RCA score']
        self._headers = [_HeaderItem('Contribution'), _HeaderItem('Evidence'), _HeaderItem('Confidence')]
    def children(self): return self._children
    def count(self): return len(self._items)
    def itemText(self, i): return self._items[i]
    def setItemText(self, i, value): self._items[i] = value
    def columnCount(self): return len(self._headers)
    def horizontalHeaderItem(self, i): return self._headers[i]


def test_rich_i18n_localizes_combo_items_and_table_headers_reversibly():
    widget = _FakeWidget()
    localize_qt_tree(widget, 'ja')
    assert widget._items[1] == 'Peak temperature'  # scientific term intentionally retained in Japanese
    assert widget._headers[0].text() == '寄与度'
    assert widget._headers[2].text() == '信頼度'
    localize_qt_tree(widget, 'es')
    assert widget._headers[0].text() == 'Contribución'
    localize_qt_tree(widget, 'en')
    assert widget._headers[0].text() == 'Contribution'
    assert widget._headers[1].text() == 'Evidence'


def test_frequency_direction_label_is_localized_but_axis_value_is_not():
    assert ui_text('ja', 'Frequency Direction') == '周波数方向'
    assert ui_text('ko', 'Frequency Direction') == '주파수 방향'
    assert ui_text('zh_TW', 'Frequency Direction') == '頻率方向'
    # Dynamic value is not part of UI_TEXT and remains identical across locales.
    assert ui_text('ja', 'RL (ROW)') == 'RL (ROW)'
