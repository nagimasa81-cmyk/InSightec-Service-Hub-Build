from pathlib import Path
ROOT=Path(__file__).parents[1]
CAL=(ROOT/'src/services/hydrophone_calibration_service.py').read_text()
HYD=(ROOT/'src/ui/hydrophone_window.py').read_text()
MAIN=(ROOT/'src/ui/main_window.py').read_text()
def test_calibration_is_authoritative():
 assert 'IsEnabled' in CAL and 'is_enabled' in CAL
 assert 'Show disabled RCV' in HYD
 assert 'calibration.ini' in HYD
 assert 'Show INI-disabled rules' not in HYD
 assert 'Show INI-disabled rules' not in MAIN
