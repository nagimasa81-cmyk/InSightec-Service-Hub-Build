from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYD=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')


def test_summary_retry_does_not_directly_restart_worker_from_spectrum_handoff():
    block=MAIN.split('def _adopt_authoritative_spectrum_context',1)[1].split('def _spectrum_preload_ready',1)[0]
    assert 'QTimer.singleShot(0,self._request_sonication_summary_detail)' in block
    assert 'QTimer.singleShot(0,self._refresh_sonication_summary)' not in block


def test_summary_request_preserves_running_full_table_pass():
    block=MAIN.split('def _request_sonication_summary_detail',1)[1].split('def _resume_sonication_summary_after_initial_data',1)[0]
    assert 'thread.isRunning()' in block
    assert 'if running:' in block
    assert 'return' in block


def test_completed_summary_row_never_stays_evidence_pending_after_exception():
    block=MAIN.split('def _build_one_sonication_summary',1)[1].split('def _build_one_sonication_temperature_summary',1)[0]
    assert 'cav_status="Control evidence unavailable"' in block


def test_history_plot_is_explicitly_not_raw_waveform():
    assert 'processed history (not Raw A/D waveform)' in HYD
