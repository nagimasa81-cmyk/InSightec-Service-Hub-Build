from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
import zipfile

from src.services.import_service import ImportService
from src.services.import_completeness_service import ImportCompletenessService


def test_nested_zip_is_expanded_without_removing_original(tmp_path):
    inner = tmp_path / "inner.zip"
    with zipfile.ZipFile(inner, "w") as z:
        z.writestr("Sonication1/SpectrumMsg-1.dmp", b"evidence")
        z.writestr("Sonication1/keep.txt", "keep")

    outer = tmp_path / "export.zip"
    with zipfile.ZipFile(outer, "w") as z:
        z.write(inner, "packages/inner.zip")
        z.writestr("root.txt", "root")

    service = ImportService()
    workspace = service.open(outer)
    nested = workspace / "packages" / "inner.zip"
    expanded = workspace / "packages" / "inner__expanded"
    assert nested.is_file()
    assert (expanded / "Sonication1" / "SpectrumMsg-1.dmp").is_file()
    assert service.last_import_report["nested_zip_count"] == 1
    assert service.last_import_report["nested_member_count"] == 2
    service.cleanup()


def test_nested_zip_path_traversal_fails_closed_and_cleans_temp(tmp_path):
    inner = tmp_path / "unsafe.zip"
    with zipfile.ZipFile(inner, "w") as z:
        z.writestr("../escape.txt", "bad")
    outer = tmp_path / "export.zip"
    with zipfile.ZipFile(outer, "w") as z:
        z.write(inner, "unsafe.zip")

    service = ImportService()
    try:
        service.open(outer)
    except RuntimeError as exc:
        assert "Nested ZIP could not be completely extracted" in str(exc)
    else:
        raise AssertionError("unsafe nested ZIP must fail")
    assert service.temp_dirs == []


def test_import_audit_reports_upstream_count_mismatch(tmp_path, monkeypatch):
    for n in range(1, 6):
        folder = tmp_path / f"Sonication{n}"
        folder.mkdir()
        (folder / f"SpectrumMsg-{n}.dmp").write_bytes(b"x")

    # Avoid requiring a complete vendor ADO fixture; pin the semantic row sets
    # the same way a real 8-Sonication SonicationSummary would be observed.
    service = ImportCompletenessService()
    monkeypatch.setattr(service, "_row_indices", lambda path: list(range(1, 9)) if path and path.name == "SonicationSummary.xml" else [])
    (tmp_path / "SonicationSummary.xml").write_text("placeholder", encoding="utf-8")

    sons = [SimpleNamespace(canonical_acquisition_session_index=None) for _ in range(5)]
    report = service.audit(tmp_path, sons)
    assert report.replay_sonication_count == 5
    assert report.summary_sonication_count == 8
    assert report.status == "WARN"
    assert any("Sonication folder identity differs" in item for item in report.issues)


def test_hydrophone_window_version_is_not_hardcoded_to_r0133():
    root = Path(__file__).resolve().parents[1]
    text = (root / "src" / "ui" / "hydrophone_window.py").read_text(encoding="utf-8")
    assert 'APP_VERSION' in text
    assert 'Analyzer — R0133' not in text
