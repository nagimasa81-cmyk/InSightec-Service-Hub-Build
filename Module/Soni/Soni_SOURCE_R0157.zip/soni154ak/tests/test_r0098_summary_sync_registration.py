
from pathlib import Path
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")
HYD=(Path(__file__).parents[1]/"src/ui/hydrophone_window.py").read_text(encoding="utf-8")
HRS=(Path(__file__).parents[1]/"src/services/hydrophone_replay_service.py").read_text(encoding="utf-8")
REG=(Path(__file__).parents[1]/"src/services/registration_overlay_service.py").read_text(encoding="utf-8")
def test_summary():
    assert 'self.tabs.addTab(self.sonication_summary_tab, "Sonication Summary")' in MAIN
    for x in ["Cavitation status","RCA score","Replay frames","Cavitation marker overlay"]: assert x in MAIN
    assert "cellDoubleClicked.connect" in MAIN and "sonication_summary_current_line" in MAIN
def test_why_once():
    b=HYD.split("def _vendor_chart_clicked",1)[1].split("def set_language",1)[0]
    assert b.count("_show_event_why_popup")==1
def test_sync():
    assert "self.hydrophone_window.sync_sonication(self.sonication_index)" in MAIN
def test_mapping():
    assert "def _explicit_sonication_number" in HRS
    assert "def _pair_key" in HRS
def test_registration_guard():
    assert "gross_mismatch" in REG and "Registration suppressed" in REG
