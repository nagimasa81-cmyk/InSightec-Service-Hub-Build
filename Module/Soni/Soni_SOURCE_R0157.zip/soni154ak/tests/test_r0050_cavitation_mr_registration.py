import numpy as np
from pathlib import Path

from src.services.cavitation_mr_correlation_service import CavitationMrCorrelationService
from src.services.registration_overlay_service import RegistrationOverlayService


class Asset:
    pixel_size_x = 1.0
    pixel_size_y = 1.0
    path = Path('ct.raw')


def test_mr_correlation_prefers_overlapping_loss():
    svc=CavitationMrCorrelationService()
    base=np.ones((64,64),float)*100.0
    cur=base.copy(); cur[26:38,26:38]=55.0
    hp=np.zeros((64,64),float); hp[24:40,24:40]=1.0
    result=svc.analyze([base,base],cur,hp)
    assert result.correlation_score is not None
    assert result.correlation_score > 45
    assert result.loss_centroid_xy is not None
    assert result.overlap_score is not None and result.overlap_score > 0.5


def test_mr_correlation_low_when_spatially_separate():
    svc=CavitationMrCorrelationService()
    base=np.ones((64,64),float)*100.0
    cur=base.copy(); cur[5:15,5:15]=55.0
    hp=np.zeros((64,64),float); hp[48:60,48:60]=1.0
    result=svc.analyze([base],cur,hp)
    assert result.overlap_score is not None
    assert result.overlap_score < 0.1


def test_registration_volume_selects_matching_slice(tmp_path):
    svc=RegistrationOverlayService()
    # Synthetic CT volume with a square bone boundary only on slice 4.
    vol=np.zeros((9,64,64),float)
    vol[4,18:46,18:46]=1000.0
    # MR has an intensity boundary at the same square.
    mr=np.zeros((64,64),float); mr[18:46,18:46]=100.0
    matrix=np.eye(4)
    matrix_path=tmp_path/'CtMr_mat.txt'
    matrix_path.write_text(' '.join(str(v) for v in matrix.reshape(-1)),encoding='utf-8')
    # Put matrix in expected Sonication1 path.
    s=tmp_path/'Sonication1'; s.mkdir(); (s/'CtMr_mat.txt').write_text(matrix_path.read_text(),encoding='utf-8')
    result=svc.render_volume(tmp_path,1,mr,'Ax',Asset(),vol,Asset())
    # R0054 intentionally suppresses the old centered 2-D approximation when
    # patient-coordinate CT/MR geometry is absent. A visually plausible but
    # spatially ungrounded skull trace must not be labelled registration.
    assert result.overlay is None
    assert "geometry" in result.status.lower()
