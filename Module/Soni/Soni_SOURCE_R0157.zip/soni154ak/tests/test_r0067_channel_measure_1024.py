from pathlib import Path
from src.services.sonication_log_receiver_service import SonicationLogReceiverService


def test_channel_measure_builds_1024_and_selects_nearest_frequency(tmp_path: Path):
    ini=tmp_path/'CPCFiles'/'Site'/'Ini'/'ChannelMeasure.ini'
    ini.parent.mkdir(parents=True)
    rows=['[FREQUENCY]','NUM_OF_FREQ=2','FREQ0=0.6800','FREQ1=0.6700','','[AMPLITUDE_AND_PHASE_CORRECTIONS]','NumberOfChannels=1024']
    rows += [f'CH{i}=1.1 0.1 {1.0+i/10000:.4f} {-0.05+i/100000:.5f}' for i in range(1024)]
    ini.write_text('\n'.join(rows),encoding='utf-8')
    table=SonicationLogReceiverService.read_channel_measure(tmp_path,670000.0)
    assert table is not None
    assert table.selected_frequency_hz == 670000.0
    assert len(table.values) == 1024
    assert table.values[0] == (1.0,-0.05)


def test_sparse_log_is_merged_with_full_measurement(tmp_path: Path):
    ini=tmp_path/'CPCFiles'/'Site'/'Ini'/'ChannelMeasure.ini'
    ini.parent.mkdir(parents=True)
    rows=['[FREQUENCY]','FREQ0=0.6700','[AMPLITUDE_AND_PHASE_CORRECTIONS]','NumberOfChannels=1024']
    rows += [f'CH{i}=1.0 {i/100000:.5f}' for i in range(1024)]
    ini.write_text('\n'.join(rows),encoding='utf-8')
    log=tmp_path/'CPCFiles'/'Sonication_Brain.txt'
    log.write_text('12:00:00:100 CLoadSonicationData fields:\nNumber Of Channels <1024>\nChannel <0>\nLogical Amplitude <1>\nLogical Phase <425.2>\nChannel <3>\nLogical Amplitude <0.9>\nLogical Phase <425.5>\n',encoding='utf-8')
    snaps=SonicationLogReceiverService().read_snapshots(tmp_path,target_frequency_hz=670000.0)
    assert len(snaps)==1
    snap=snaps[0]
    assert len(snap.values)==1024
    assert snap.measured_decoded_channels==1024
    assert snap.logical_decoded_channels==2
    assert snap.values[4].measured_phase_rad is not None
    assert snap.values[4].logical_phase_rad is None
