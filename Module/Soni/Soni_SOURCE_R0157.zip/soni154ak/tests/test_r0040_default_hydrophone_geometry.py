import numpy as np
from src.services.cavitation_likelihood_service import CavitationLikelihoodService


def test_default_physical_rcv_geometry():
    p = CavitationLikelihoodService.DEFAULT_POSITIONS
    assert p.shape == (8, 2)
    # CH0-CH3: Cap RCV inner square: left-top, right-top, right-bottom, left-bottom.
    assert p[0,0] < 0 and p[0,1] > 0
    assert p[1,0] > 0 and p[1,1] > 0
    assert p[2,0] > 0 and p[2,1] < 0
    assert p[3,0] < 0 and p[3,1] < 0
    # CH4-CH7: Tile RCV outer square in the same quadrant order.
    assert p[4,0] < 0 and p[4,1] > 0
    assert p[5,0] > 0 and p[5,1] > 0
    assert p[6,0] > 0 and p[6,1] < 0
    assert p[7,0] < 0 and p[7,1] < 0
    assert np.all(np.linalg.norm(p[4:], axis=1) > np.linalg.norm(p[:4], axis=1))
    assert CavitationLikelihoodService.RECEIVER_FAMILY == ("Cap", "Cap", "Cap", "Cap", "Tile", "Tile", "Tile", "Tile")
