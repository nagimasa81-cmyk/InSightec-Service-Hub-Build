
from pathlib import Path
PLANNING=(Path(__file__).parents[1]/"src/services/planning_data_service.py").read_text(encoding="utf-8")
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_series_data_item_is_authoritative():
    assert "studytype=0 -> treatment-day Planning MR set" in PLANNING
    assert "studytype=1 -> Preplanning MR set" in PLANNING
    assert "_match_series_data_item" in PLANNING

def test_exported_reformats_are_identified():
    assert 'source_kind="Exported original 3D series"' in PLANNING
    assert 'source_kind="Exported saved reformat"' in PLANNING

def test_thermal_default_and_optional_other_rows():
    assert 'QCheckBox("Show Reference")' not in MAIN
    assert 'QCheckBox("Show Treatment MR")' not in MAIN
    assert "Reference, Treatment MR and Treatment Thermal rows are always visible" in MAIN
    assert 'self._main_image_mode = "thermal"' in MAIN

def test_reference_combo_does_not_replace_main_view():
    b=MAIN.split("def _planning_reference_type_changed",1)[1].split("def _activate_reference_for_registration",1)[0]
    assert "_activate_image_payload" not in b
    assert "dominant main viewer stays on live Thermal" in b

def test_planning_decode_is_lazy():
    b=MAIN.split("def _build_frame_navigator",1)[1].split("def _all_image_entries",1)[0]
    assert "background worker" in b
    assert "self._planning_assets_all.append((asset,None,label,category))" in b
    assert "def _planning_array_for_asset" in MAIN
