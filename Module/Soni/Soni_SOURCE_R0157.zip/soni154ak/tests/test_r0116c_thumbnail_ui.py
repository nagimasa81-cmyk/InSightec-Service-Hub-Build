from pathlib import Path
ROOT=Path(__file__).parents[1]
MAIN=(ROOT/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_full_frame_thumbnail_renderer():
    assert "Create a full-frame, letterboxed thumbnail; never crop or distort" in MAIN
    assert "KeepAspectRatio" in MAIN
    assert "canvas.fill(QColor(0,0,0))" in MAIN

def test_hover_preview_exists():
    assert "def _show_thumbnail_hover_preview" in MAIN
    assert "ThumbnailHoverPreview" in MAIN
    assert "itemEntered.connect" in MAIN

def test_expand_gallery_exists():
    assert "def _open_thumbnail_gallery" in MAIN
    assert 'expand.setText("↗")' in MAIN
    assert "Show all" in MAIN
    assert "gallery.setWrapping(True)" in MAIN

def test_slider_remains_index_based():
    assert "scroll=QSlider(Qt.Orientation.Horizontal)" in MAIN
    assert "def _scroll_image_strip_to_index" in MAIN
