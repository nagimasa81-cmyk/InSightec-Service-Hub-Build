
from pathlib import Path
SRC=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")
SVC=(Path(__file__).parents[1]/"src/services/acoustic_control_service.py").read_text(encoding="utf-8")
def test_global_table_readability_installed():
    assert "def _install_global_readability" in SRC
    assert "ScrollBarAsNeeded" in SRC and "def _show_table_cell_popup" in SRC and "QTextEdit" in SRC
def test_rca_full_text_tooltips():
    b=SRC.split("def _update_ci_root_cause",1)[1].split("def _update_cavitation_intelligence_page",1)[0]
    assert "item.setToolTip(str(v))" in b
def test_power_curve_and_axis_separate():
    b=SRC.split("def _update_acoustic_replay_view",1)[1].split("def _ensure_acoustic_curve_items",1)[0]
    assert "exposure_end" in b and "plot_tx <= float(current_s)" in b and "setXRange(0.0, axis_end" in b
def test_vendor_terminal_zero_not_plotted():
    assert "terminal_zero" in SVC and "plot_t = vendor_t[plot_keep].copy()" in SVC
