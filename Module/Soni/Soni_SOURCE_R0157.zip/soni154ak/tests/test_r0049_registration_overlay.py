from pathlib import Path
import numpy as np

from src.services.registration_overlay_service import RegistrationOverlayService


def test_matrix_decode(tmp_path):
    p=tmp_path/'CtMr_mat.txt'
    p.write_text(''' 1 0 0 2\n0 1 0 -3\n0 0 1 4\n0 0 0 1\n''')
    m=RegistrationOverlayService.read_matrix(p)
    assert m.shape==(4,4)
    assert m[0,3]==2
    assert m[1,3]==-3


def test_projected_bone_overlay_has_pixels():
    ct=np.zeros((64,64),float)
    yy,xx=np.mgrid[:64,:64]
    ring=np.abs(np.sqrt((xx-31.5)**2+(yy-31.5)**2)-20)<2
    ct[ring]=1000
    svc=RegistrationOverlayService()
    out=svc.project_2d(ct,(64,64),np.eye(4),'Ax',1.0,(1.0,1.0))
    assert np.isfinite(out).sum()>20
