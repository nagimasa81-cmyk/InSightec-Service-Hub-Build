from pathlib import Path
import gzip, struct
from src.core.fus_export_core import decode_spectrum_structure, inspect_export
from src.core.spectrum_decoder import SharedSpectrumDecoder


def _spectrum_payload(frame_count=67, frame_size=200640, channels=8, header=272):
    # Synthetic >8MB file validating that exact layout is solved from full size.
    prefix = bytearray(header)
    struct.pack_into('<iii', prefix, 0, frame_count, frame_size, channels)
    # Put a plausible float spectrum window at the beginning of every frame.
    import numpy as np
    total = bytearray(prefix)
    for _ in range(frame_count):
        f = bytearray(frame_size)
        vals = np.ones(2048, dtype='<f4')
        vals[1000] = 1000.0
        f[:vals.nbytes] = vals.tobytes()
        total.extend(f)
    return bytes(total)


def test_exact_spectrum_structure_uses_full_payload_above_8mb(tmp_path):
    p=tmp_path/'SpectrumMsg-10.dmp'
    p.write_bytes(gzip.compress(_spectrum_payload()))
    info=decode_spectrum_structure(p)
    assert info.exact_structure
    assert (info.frame_count, info.frame_size, info.channel_count, info.header_size)==(67,200640,8,272)
    # The Replay decoder must honor exact frame boundaries even though the file
    # exceeds the old 8MB heuristic cap.
    frames=SharedSpectrumDecoder().decode_frames(p, 650000.0)
    assert len(frames)==67


def test_partial_inherits_reference_motion_from_spaced_sonication1(tmp_path):
    root=tmp_path/'Export'; s1=root/'Sonication 1'; s2=root/'Sonication 2'
    s1.mkdir(parents=True); s2.mkdir(parents=True)
    for fid in (37,38,39): (s1/f'{fid}-1-0-0.raw').write_bytes(b'0')
    # Give sonication2 one usable major stream and current motion.
    (s2/'Sonication2.act').write_text('x')
    for fid in (40,41,42): (s2/f'{fid}-2-0-0.raw').write_bytes(b'0')
    result=inspect_export(root)
    son2=next(s for s in result.sonications if s.number==2)
    assert son2.capabilities['motion'].available
    assert not son2.capabilities['motion'].degraded
    assert son2.status=='PARTIAL'
