from pathlib import Path
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def method(name):
    block=MAIN.split(f"def {name}",1)[1]
    return block.split("\n    def ",1)[0]

def test_summary_schema_self_heals_new_columns():
    src=method("_ensure_sonication_summary_schema")
    assert '"Cavitation severity","Energy delivered (%)"' in src.replace("\n","")
    assert 'setColumnHidden(4,False)' in src
    assert 'setColumnHidden(5,False)' in src
    assert '_ensure_sonication_summary_schema()' in method("_refresh_sonication_summary")
    assert '_ensure_sonication_summary_schema()' in method("_sonication_summary_row_ready")

def test_load_images_progress_precedes_navigator_and_navigator_is_deferred():
    src=method("_image_loading_toggled")
    assert src.index('_begin_image_load_progress()') < src.index('QTimer.singleShot(0,lambda c=cycle:self._build_frame_navigator(c))')

def test_initial_navigator_does_not_build_thousand_item_strips_synchronously():
    src=method("_build_frame_navigator")
    assert '_rebuild_all_image_strips()' not in src
    assert '_reference_thumbnail_assets' in src

def test_frame_ready_path_does_not_construct_icons_without_existing_item():
    src=method("_apply_ready_thumbnail_to_visible_items")
    assert src.index('if item is None:') < src.index('icon=')

def test_final_strip_materialization_is_batched():
    src=method("_continue_incremental_image_strip_build")
    assert 'budget=18' in src
    assert 'QTimer.singleShot(0,self._continue_incremental_image_strip_build)' in src
