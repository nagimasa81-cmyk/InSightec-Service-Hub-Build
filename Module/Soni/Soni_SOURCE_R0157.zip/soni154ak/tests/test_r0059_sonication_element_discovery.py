from pathlib import Path
from src.services.sonication_log_receiver_service import SonicationLogReceiverService


def test_generic_1024_block_without_cload_marker(tmp_path: Path):
    p = tmp_path / 'Sonication_Brain_test.txt'
    p.write_text(
        '15:00:00:000 Inf Number Of Channels <1024>\n'
        'Channel <0>\nLogical Amplitude <0.75>\nLogical Phase <1.25>\n'
        'Channel <65>\nLogical Amplitude <0.50>\nLogical Phase <2.50>\n'
    )
    snaps = SonicationLogReceiverService().read_snapshots(tmp_path)
    assert len(snaps) == 1
    assert snaps[0].declared_channels == 1024
    assert [v.channel for v in snaps[0].values] == [0, 65]
    assert snaps[0].values[1].blade_number == 2
    assert snaps[0].values[1].blade_channel == 1


def test_direct_file_is_read_even_if_name_is_nonstandard(tmp_path: Path):
    p = tmp_path / 'exported_hardware.txt'
    p.write_text('Channel <2>\nLogical Amplitude <1.0>\nLogical Phase <3.0>\n')
    snaps = SonicationLogReceiverService().read_snapshots(tmp_path, direct_files=[p])
    assert len(snaps) == 1
    assert snaps[0].values[0].channel == 2
