from pathlib import Path


def test_spectrum_tab_exposes_preirradiation_mr_navigation():
    text = Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'Last pre-irradiation' in text
    assert '_jump_spectrum_mr_phase("mr_start")' in text
    assert '_jump_spectrum_mr_phase("pre_end")' in text
    assert '_jump_spectrum_mr_phase("irradiation_start")' in text
    assert 'mr_frame_times_s' in text
    assert 'Pre-irradiation' in text
    assert 'MR Spectrum timeline' in text


def test_frame_label_uses_canonical_mr_time_when_available():
    text = Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert '· MR {mr_t:.3f} s · {mr_phase}' in text
    assert 'plot.setTitle(title + mr_suffix)' in text
