from pathlib import Path

SRC = Path(__file__).parents[1] / "src" / "ui" / "main_window.py"
TEXT = SRC.read_text(encoding="utf-8")

def test_startup_selected_frame_publish_is_lightweight():
    assert "self.set_frame(self.frame_index, display_mode=initial_mode, defer_heavy=True)" in TEXT

def test_background_stream_completion_does_not_force_hidden_analysis():
    assert "self.set_frame(self.frame_index, defer_heavy=True)" in TEXT

def test_image_cache_completion_uses_lightweight_publish():
    assert 'display_mode=self._main_image_mode,defer_heavy=True' in TEXT

def test_hidden_analysis_and_ci_are_gated_by_current_tab():
    assert 'analysis_visible = current_tab is getattr(self, "analysis_tab", None)' in TEXT
    assert 'ci_visible = current_tab is getattr(self, "cavitation_intelligence_tab", None)' in TEXT
    assert "if not defer_heavy and analysis_visible:" in TEXT
    assert "if not defer_heavy and ci_visible:" in TEXT

def test_analysis_refreshes_when_opened():
    marker = "elif widget is self.analysis_tab:"
    assert marker in TEXT
    block = TEXT.split(marker,1)[1][:500]
    assert "self._update_analysis_hydrophone()" in block
    assert "self._update_cavitation_visualization()" in block
