from pathlib import Path

def test_blade_mapping_properties():
    from src.services.sonication_log_receiver_service import SonicChannelValue
    cases=[(0,1,0),(63,1,63),(64,2,0),(127,2,63),(960,16,0),(1023,16,63)]
    for ch,blade,local in cases:
        v=SonicChannelValue(ch)
        assert v.blade_number==blade
        assert v.blade_channel==local

def test_ui_labels_and_legend_toggle_present():
    root=Path(__file__).resolve().parents[1]
    main=(root/'src/ui/main_window.py').read_text(encoding='utf-8')
    hydro=(root/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'Element CH' in main
    assert '16 Blades × 64 CH' in main
    assert 'Blade CH' in main
    assert 'QCheckBox("Legend")' in hydro
    assert 'vendor_legend_check.toggled.connect(self.vendor_legend_label.setVisible)' in hydro
