from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / "src" / "ui" / "main_window.py"
TEXT = SRC.read_text(encoding="utf-8")


def test_movement_detection_abs_sum_and_threshold_are_explicit():
    assert "def _movement_detection_abs_sum" in TEXT
    assert "sum(abs(v) for v in vals)" in TEXT
    assert "total >= 2.0" in TEXT
    assert "|RL|+|SI|+|AP|" in TEXT
    assert 'QColor("#d32f2f")' in TEXT


def test_three_focus_markers_have_independent_visibility_controls():
    assert "show_reference_focus = True" in TEXT
    assert "show_authoritative_focus = True" in TEXT
    assert "show_phase_derived_focus = True" in TEXT
    assert 'QCheckBox("Reference focus")' in TEXT
    assert 'QCheckBox("Authoritative steered target")' in TEXT
    assert 'QCheckBox("Phase-derived focus")' in TEXT
    assert "def set_focus_visibility" in TEXT
    assert "def _element_focus_visibility_changed" in TEXT


def test_element_table_uses_vertical_splitter_instead_of_clipped_max_height():
    assert "self.element_vertical_splitter = QSplitter(Qt.Orientation.Vertical)" in TEXT
    assert "self.element_vertical_splitter.addWidget(self.element_table)" in TEXT
    assert "self.element_table.setMinimumHeight(150)" in TEXT
    assert "self.element_table.setMaximumHeight(220)" not in TEXT
    assert "splitter.setSizes" in TEXT
