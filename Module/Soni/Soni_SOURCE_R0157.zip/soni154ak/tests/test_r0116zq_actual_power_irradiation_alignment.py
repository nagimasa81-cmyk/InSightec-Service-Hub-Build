from pathlib import Path


def test_vendor_actual_power_uses_workstation_powergraph():
    text = Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'def _workstation_actual_power_series' in text
    assert 'power_graph_for_sonication' in text
    assert 'Actual power ratio (Workstation PowerGraph)' in text
    assert 'Actual ExPowerRatio' not in text


def test_workstation_powergraph_is_anchored_at_irradiation_start():
    text = Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    start = text.index('def _workstation_actual_power_series')
    end = text.index('def _draw_vendor_cavitation', start)
    block = text[start:end]
    assert 'irradiation_start + t' in block
    assert 'np.concatenate(([0.0], t))' in block
    assert 'np.concatenate(([0.0], ratio))' in block


def test_controller_prediction_is_not_drawn_before_irradiation():
    text = Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'mask=np.isfinite(tx) & np.isfinite(predicted) & (tx >= start-1e-9)' in text
    assert 'INI-rule prediction (irradiation)' in text
