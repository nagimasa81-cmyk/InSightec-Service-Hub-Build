from pathlib import Path
from types import SimpleNamespace

from src.services.canonical_cavitation_evidence_service import CanonicalCavitationEvidenceService

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYD=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
CTL=(ROOT/'src/services/cavitation_control_timeline_service.py').read_text(encoding='utf-8')


def test_decrease_and_safety_are_authoritative_cavitation_events_even_if_old_flag_false():
    events=[
        SimpleNamespace(family='Decrease', counts_as_cavitation=False),
        SimpleNamespace(family='Safety', counts_as_cavitation=False),
        SimpleNamespace(family='Increase', counts_as_cavitation=True),
    ]
    evidence=CanonicalCavitationEvidenceService.combine(events, SimpleNamespace(events=[]))
    assert evidence.detected is True
    assert len(evidence.observed_events)==2
    assert {event.family for event in evidence.observed_events} == {'Decrease','Safety'}
    assert 'Observed control cavitation ×2' in evidence.status


def test_control_timeline_marks_observed_decrease_safety_without_timing_gate():
    assert 'event.counts_as_cavitation=bool(event.family in ("Decrease","Safety"))' in CTL
    assert 'state=="Irradiation active" and trigger and event.family' not in CTL


def test_main_replay_defaults_new_sonication_to_irradiation_end():
    assert 'def _default_irradiation_end_frame_index' in MAIN
    select=MAIN.split('def _select_sonication_index',1)[1].split('def _load_selected_stage',1)[0]
    assert 'self.frame_index = self._default_irradiation_end_frame_index()' in select
    navigator=MAIN.split('def _selected_stage_navigator',1)[1].split('def _selected_stage_metadata',1)[0]
    assert '_first_valid_replay_frame()' not in navigator
    assert '_default_irradiation_end_frame_index()' in navigator


def test_spectrum_analyzer_uses_bound_sonication_end_for_initial_fft_snapshot():
    assert 'def _default_irradiation_end_frame_index' in HYD
    assert 'mr_sonication_end_s' in HYD
    assert 'mr_frame_times_s' in HYD
    assert HYD.count('initial_index=self._default_irradiation_end_frame_index()') >= 2
