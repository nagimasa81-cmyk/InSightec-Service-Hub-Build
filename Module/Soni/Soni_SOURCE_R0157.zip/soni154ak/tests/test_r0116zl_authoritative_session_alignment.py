from pathlib import Path


def test_main_window_control_consumers_use_authoritative_session():
    text = Path('src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'def _preferred_acquisition_session' in text
    assert 'preferred_session_index=preferred_session' in text
    assert 'else getattr(replay,"acquisition_session_index",None)' in text
    assert 'else getattr(replay, "acquisition_session_index", None)' in text


def test_main_window_does_not_positional_substitute_when_physical_mapping_unresolved():
    text = Path('src/ui/main_window.py').read_text(encoding='utf-8')
    start = text.index('def _resolve_cpc_pair')
    end = text.index('def _preferred_acquisition_session', start)
    block = text[start:end]
    assert 'if physical:' in block
    assert 'return None, None' in block


def test_analyzer_does_not_use_positional_fallback_when_physical_cpc_exists():
    text = Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    start = text.index('def load_sonication')
    end = text.index('def _sonication_changed', start)
    block = text[start:end]
    assert 'UNRESOLVED CPC / SONICATION BINDING' in block
    assert 'No positional substitution was made.' in block
    assert 'legacy fallback' not in block


def test_measured_duration_accepts_preferred_session():
    text = Path('src/services/acoustic_control_service.py').read_text(encoding='utf-8')
    assert 'def measured_duration_for_sonication(self, workspace: Path, sonication_index: int, preferred_session_index: int | None = None)' in text
