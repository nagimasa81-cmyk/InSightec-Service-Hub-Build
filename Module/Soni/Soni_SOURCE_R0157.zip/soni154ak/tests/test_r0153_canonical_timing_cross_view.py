from pathlib import Path
from datetime import datetime

from src.services.mr_timeline_service import MRTimelineService

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYD=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')


def _block(text: str, name: str) -> str:
    start=text.index(f'def {name}')
    tail=text[start+4:]
    nxt=tail.find('\n    def ')
    return text[start:] if nxt < 0 else text[start:start+4+nxt]


def test_full_datetime_power_matching_rejects_other_day_same_clock(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir()
    wrong=ws/'2026_Aug_25_11_59_00.Log'
    right=ws/'2026_Aug_26_11_59_00.Log'
    body=(
        '12:00:06:000 Inf Main status changed from: Sonication to Sonication power on\n'
        '12:00:19:000 Inf Main status changed from: Sonication power on to Post sonication\n'
    )
    wrong.write_text(body,encoding='utf-8'); right.write_text(body,encoding='utf-8')
    svc=MRTimelineService()
    windows=svc._power_windows(tmp_path)
    hint=datetime(2026,8,26,12,0,0).timestamp()
    picked=svc._select_power_window(windows,hint,0,1)
    assert picked is not None
    assert datetime.fromtimestamp(picked[0]).date().isoformat() == '2026-08-26'


def test_mrserver_prepped_transition_is_a_valid_scan_start(tmp_path: Path):
    ws=tmp_path/'WSFiles'; ws.mkdir()
    p=ws/'mrserver_Wed_Aug_26_11_59_00_2026.log'
    p.write_text(
        '12:00:00:000> Status changed from Prepped to Scanning.\n'
        '12:00:41:000> Status changed from Scanning to Idle.\n', encoding='utf-8')
    intervals=MRTimelineService()._scan_intervals(tmp_path)
    assert len(intervals)==1
    assert abs((intervals[0][1]-intervals[0][0])-41.0)<1e-6


def test_main_time_domain_charts_use_one_mr_acquisition_origin():
    temp=_block(MAIN,'_apply_temperature_trend')
    acoustic=_block(MAIN,'_apply_acoustic_trend')
    replay=_block(MAIN,'_update_acoustic_replay_view')
    assert 'x_abs-irradiation_start' not in temp.replace(' ','')
    assert 'plot_tx_abs-irradiation_start' not in acoustic.replace(' ','')
    assert 'plot_tx_abs-irradiation_start' not in replay.replace(' ','')
    assert '"MR acquisition time"' in temp
    assert '"MR acquisition time"' in acoustic


def test_chart_click_navigation_does_not_double_add_sonication_start():
    for name in ('_acoustic_plot_clicked','_waterfall_plot_clicked','_cavitation_plot_clicked'):
        b=_block(MAIN,name)
        assert '_activate_replay_mode_for_navigation()' in b
        assert 'point.x())+irradiation_start' not in b.replace(' ','')
        assert '_seconds_to_index(float(point.x())' in b


def test_main_timing_markers_are_removed_before_readding():
    b=_block(MAIN,'_apply_main_mr_timeline_guides')
    assert 'removeItem' in b
    assert '_mr_timeline_guide_items=[]' in b.replace(' ','')
    assert 'forxin(start,stop)' in b.replace(' ','')


def test_spectrum_analyzer_uses_bound_model_timing_and_deduplicates_global_markers():
    bind=_block(HYD,'_bind_sonication_timebase')
    apply=_block(HYD,'_apply_selected_time_window')
    assert 'getattr(son, "mr_sonication_start_s"' in bind
    assert 'getattr(son, "mr_sonication_end_s"' in bind
    assert '_global_mr_axis_marker' in apply
    assert 'plot.removeItem(item)' in apply


def test_replay_cursor_and_progressive_power_share_absolute_mr_time():
    cards=_block(MAIN,'_update_acoustic_cards')
    progressive=_block(MAIN,'_apply_workstation_replay_behavior')
    assert 'cursor_rel' not in cards
    assert 'self.acoustic_control_cursor.setPos(cursor_abs)' in cards
    assert '_update_acoustic_replay_view(current_abs_s' in progressive


def test_vendor_redraw_reapplies_canonical_mr_window_after_autofit():
    b=_block(HYD,'_draw_vendor_cavitation')
    assert 'enableAutoRange(axis=pg.ViewBox.XAxis, enable=False)' in b
    assert 'self._apply_mr_timeline_window(self.vendor_energy_plot, self.vendor_power_plot)' in b
