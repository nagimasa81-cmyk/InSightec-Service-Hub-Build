from pathlib import Path
ROOT=Path(__file__).parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')

def test_array_preview_helper_exists():
    assert 'def _array_preview_pixmap' in MAIN

def test_hover_preview_uses_payload_array():
    assert 'payload=item.data(Qt.ItemDataRole.UserRole)' in MAIN
    assert 'array=payload[2]' in MAIN
    assert 'self._array_preview_pixmap(array,max_box)' in MAIN

def test_popup_padding_reduced_and_resize_follows_pix():
    assert 'padding:2px' in MAIN
    assert 'popup.resize(pix.width()+frame_pad,pix.height()+frame_pad)' in MAIN
