from pathlib import Path
import numpy as np

from src.services.cavitation_control_timeline_service import CavitationControlTimelineService
from src.services.hydrophone_replay_service import CpcHydrophoneReplay, CpcHydrophoneFrame
from src.services.sonication_timing_service import SonicationTimingService
from src.services.canonical_cavitation_evidence_service import CanonicalCavitationEvidenceService


def test_control_event_uses_physical_power_cycle_origin_not_cpc_history_anchor(tmp_path: Path):
    log = tmp_path / 'Acquisition_Brain_case.txt'
    log.write_text(
        '12:00:00:000 Inf Got StartSpectrumMeasurement\n'
        '12:00:07:500 Inf Cycle 515 Done.\n'
        '12:00:07:510 Inf Set: SubSonic = 0, ExciterPower = 100 W, AblPower = 100 W, ExPowerRatio = 0.8465 (0) AblPowerRatio = 0.8465 (0)\n'
        '12:00:08:990 Inf Cycle 664 Done.\n'
        '12:00:09:000 Err Decrease Power Rule no. 0 : Calculated Energy: < 0.10 > Calculated Top Energy limit: < 0.05 >\n'
        '12:00:09:000 Inf Set: SubSonic = 0, ExciterPower = 100 W, AblPower = 100 W, ExPowerRatio = 0.1693 (0) AblPowerRatio = 0.1693 (0)\n'
        '12:00:09:480 Inf Cycle 713 Done.\n'
        '12:00:09:490 Err Safety Rule no. 3: Calculated Energy from all hydrophones is more than a critical energy (Changing Frequency = 0 )\n'
        '                        Calculated Energy: < 0.064407 >\n'
        '                        Critical Energy:   < 0.060000 >\n'
        '12:00:09:490 Inf Status was changed to <HALTED BY CAVITATION> AddStatus<13>\n'
        '12:00:09:490 Inf Set: SubSonic = 0, ExciterPower = NA, AblPower = NA, ExPowerRatio = 0 (0) AblPowerRatio = 0 (0)\n',
        encoding='utf-8',
    )
    tl = CavitationControlTimelineService().parse(
        log, None, 0, None, None,
        7.51, 0.0, 1.99, 30.4,
        20, 0.19, 0.010,
    )
    observed = [e for e in tl.events if e.family in {'Decrease', 'Safety'} and e.counts_as_cavitation]
    assert observed
    assert any(abs(float(e.timestamp_s) - 1.49) < 0.03 for e in observed if e.family == 'Decrease')
    assert any('HALTED' in e.result for e in observed)
    assert max(float(e.timestamp_s) for e in observed) <= 1.99 + 1e-6
    canonical = CanonicalCavitationEvidenceService.combine(observed, None, timeline_available=True, spectrum_available=True)
    assert canonical.detected is True
    assert canonical.halt_count == 1


def test_cpc_fft_time_uses_controller_cycle_zero_when_available():
    replay = CpcHydrophoneReplay(None, None, acquisition_interval_s=0.010, sonication_time_zero_offset_s=7.51, sonication_cycle_zero=516)
    replay.frames = [
        CpcHydrophoneFrame(index=0, frequency_hz=np.asarray([1.0]), channels=[np.asarray([1.0])], acquisition_cycle=20, acquisition_time_s=0.19),
        CpcHydrophoneFrame(index=1, frequency_hz=np.asarray([1.0]), channels=[np.asarray([1.0])], acquisition_cycle=665, acquisition_time_s=6.64),
        CpcHydrophoneFrame(index=2, frequency_hz=np.asarray([1.0]), channels=[np.asarray([1.0])], acquisition_cycle=715, acquisition_time_s=7.14),
    ]
    assert np.allclose(replay.sonication_frame_times_s, [-4.96, 1.49, 1.99])


def test_sonication_summary_preserves_panic_type(tmp_path: Path):
    xml = tmp_path / 'SonicationSummary.xml'
    xml.write_text('''<?xml version="1.0"?>\n<xml xmlns:rs="urn:schemas-microsoft-com:rowset" xmlns:z="#RowsetSchema"><rs:data><z:row sonicationindex="1" duration="15" actualduration="12.7" power="1200" measuredpower="1129" energy="16835" measuredenergy="13490" frequency="670000" panictype="Patient" /></rs:data></xml>''', encoding='utf-8')
    rows = SonicationTimingService().read_all(tmp_path)
    assert rows and rows[0].panic_type == 'Patient'
