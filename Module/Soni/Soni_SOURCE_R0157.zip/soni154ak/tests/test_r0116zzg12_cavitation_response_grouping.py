from types import SimpleNamespace
from pathlib import Path
from src.services.canonical_cavitation_evidence_service import CanonicalCavitationEvidenceService

ROOT=Path(__file__).resolve().parents[1]
HYD=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
CTL=(ROOT/'src/services/cavitation_control_timeline_service.py').read_text(encoding='utf-8')

def ev(family, cycle, before, after, result=''):
    return SimpleNamespace(family=family,cycle=cycle,before_power_ratio=before,after_power_ratio=after,result=result)

def test_multiple_rule_rows_same_cycle_are_one_physical_cavitation_response():
    evidence=CanonicalCavitationEvidenceService.combine([
        ev('Decrease',100,1.0,.8),
        ev('Decrease',100,1.0,.8),
        ev('Safety',101,.8,0.0,'HALTED BY CAVITATION'),
        ev('Safety',101,.8,0.0,'HALTED BY CAVITATION'),
        ev('Safety',101,.8,0.0,'HALTED BY CAVITATION'),
    ], SimpleNamespace(events=[]))
    assert evidence.detected is True
    assert evidence.observed_response_count == 2
    assert evidence.decrease_response_count == 1
    assert evidence.safety_response_count == 1
    assert evidence.halt_count == 1
    assert evidence.status == 'CAVITATION HALT ×1 · control responses ×2'

def test_analyzer_distinguishes_evidence_rows_from_controller_responses():
    assert 'Multiple rules in one acquisition cycle are one physical controller response.' in HYD
    assert 'Decrease/Safety responses' in HYD
    assert 'evidence rows=' in CTL
    assert 'decrease responses=' in CTL
