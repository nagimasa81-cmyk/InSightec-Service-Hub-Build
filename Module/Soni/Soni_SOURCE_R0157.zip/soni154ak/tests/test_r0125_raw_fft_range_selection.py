from pathlib import Path


def test_r0125_raw_fft_range_selection_contract():
    src = (Path(__file__).parents[1] / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'FFT range selection' in src
    assert 'FFT selected range' in src
    assert 'pg.LinearRegionItem' in src
    assert 'raw_adc_available' in src
    assert 'The visible CPC measurement history is not a raw waveform' in src
    assert 'Selected range contains missing Raw A/D samples' in src
    assert 'np.fft.rfft' in src
    assert 'np.fft.rfftfreq' in src
    assert 'Hann' in src and 'Hamming' in src and 'Rectangular' in src


def test_r0125_fft_does_not_replace_normal_mouse_interaction_contract():
    src = (Path(__file__).parents[1] / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'setMouseEnabled(x=True, y=True)' in src
    assert 'self.raw_fft_select_btn.setCheckable(True)' in src
    assert 'self.raw_fft_select_btn.toggled.connect(self._raw_fft_selection_toggled)' in src
