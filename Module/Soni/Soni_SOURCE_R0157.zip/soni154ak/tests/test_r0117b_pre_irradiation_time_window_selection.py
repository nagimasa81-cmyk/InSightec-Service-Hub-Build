from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HYDRO = (ROOT / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')


def test_end_combo_offers_sonication_start_for_pre_irradiation_window():
    """Without this item, 'MR acquisition start -> Sonication start' could
    never be selected from the chart time-axis controls, even though the
    underlying anchor/redraw plumbing already supported it."""
    block = HYDRO.split('self.time_axis_end_combo = QComboBox()', 1)[1].split('self.time_axis_status_label', 1)[0]
    assert 'addItem("Sonication start", "sonication_start")' in block
    # Must not change the pre-existing default selection (index 1 = MR acquisition end).
    assert 'setCurrentIndex(1)' in block


def test_start_combo_offers_earliest_decoded_spectrum_anchor():
    """'MR acquisition start' is a fixed t=0 axis convention, not necessarily
    the earliest decoded Spectrum snapshot: CPC can start recording before
    the registered Sonication/MR anchor. Without a separate anchor for that,
    real pre-irradiation snapshots are silently clipped whenever
    mr_sonication_start_s itself resolves to 0.0."""
    block = HYDRO.split('self.time_axis_start_combo = QComboBox()', 1)[1].split('self.time_axis_end_combo = QComboBox()', 1)[0]
    assert 'addItem("Earliest decoded Spectrum (pre-irradiation)", "spectrum_earliest")' in block


def test_canonical_mr_axis_points_computes_spectrum_earliest_anchor():
    block = HYDRO.split('def _canonical_mr_axis_points', 1)[1].split('def _selected_mr_time_window', 1)[0]
    assert 'spectrum_earliest' in block
    assert 'min(np.min(a) for a in arrays_earliest)' in block
    # It must be sourced from the same MR-aligned arrays as everything else,
    # not from a separate/inconsistent time base.
    assert 'mr_frame_times_s' in block
    assert 'mr_raw_timeline_time_s' in block
    assert '"spectrum_earliest":spectrum_earliest' in block
    assert '"spectrum_earliest":None' in block  # no-replay early-return case
