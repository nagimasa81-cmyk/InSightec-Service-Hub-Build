from pathlib import Path


def test_treatment_science_worker_is_background_and_evidence_complete():
    text = Path('src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'class TreatmentOutcomeScienceWorker(QObject)' in text
    assert 'worker.moveToThread(thread)' in text
    assert 'Treatment outcome map — Thermal response × Cavitation burden' in text
    assert 'Build / Refresh treatment map' in text
    assert 'Reference candidates:' in text
    assert 'Poor trade-off candidates:' in text


def test_treatment_science_supports_required_visual_dimensions():
    text = Path('src/ui/main_window.py').read_text(encoding='utf-8')
    for label in ['Power', 'Energy', 'ΔT', 'Peak temperature', 'RCA score', 'RCV concentration']:
        assert label in text
    assert 'thermal_response' in text
    assert 'cavitation_burden' in text
    assert 'what_if_priority' in text
    assert 'balance_score' in text


def test_study_switch_cancels_treatment_science_worker():
    text = Path('src/ui/main_window.py').read_text(encoding='utf-8')
    start = text.index('def _prepare_source_switch')
    end = text.index('def _run_pending_source_load', start)
    block = text[start:end]
    assert 'self._cancel_treatment_outcome_science()' in block
    assert 'self._ci_science_workspace = None' in block
