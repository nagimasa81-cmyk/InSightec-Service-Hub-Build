from pathlib import Path

SRC = Path(__file__).parents[1] / "src" / "ui" / "hydrophone_window.py"
TEXT = SRC.read_text(encoding="utf-8")

def test_non_mouse_fft_preset_activates_selection_overlay():
    block = TEXT.split("def _raw_fft_range_preset_changed",1)[1].split("def _raw_fft_has_valid_waveform",1)[0]
    assert 'select_btn.setChecked(True)' in block
    assert '_set_raw_fft_drag_region' in block

def test_run_button_accepts_preset_selection_state():
    block = TEXT.split("def _update_raw_fft_controls",1)[1].split("def _clear_raw_fft_selection",1)[0]
    assert 'preset_active' in block
    assert 'combo.currentData()' in block

def test_clear_restores_mouse_mode_and_cursor():
    block = TEXT.split("def _clear_raw_fft_selection",1)[1].split("def _history_fft_uniform_selection",1)[0]
    assert 'combo.setCurrentIndex(0)' in block
    assert '_set_raw_fft_selection_cursor(False)' in block

def test_control_timeline_has_dedicated_nested_first_open_settle():
    assert 'self.cavitation_visual_tabs.currentChanged.connect(self._cavitation_visual_tab_changed)' in TEXT
    assert 'def _seed_control_timeline_splitter_once' in TEXT
    assert 'tabs.contentsRect().height()' in TEXT
    assert 'self._control_timeline_splitter_initialized = True' in TEXT
    assert 'self.cavitation_timeline_splitter.setHandleWidth(6)' in TEXT
