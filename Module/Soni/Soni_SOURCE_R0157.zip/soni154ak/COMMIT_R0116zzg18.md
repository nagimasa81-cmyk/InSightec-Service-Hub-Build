# R0116zzg18 — Spectrum Summary pre-irradiation cavitation classification

- Adds Spectrum Summary on the Spectrum tab for the interval from MR Spectrum acquisition start until immediately before irradiation start.
- Classification is evidence-preserving: YES for pre-irradiation Decrease/Safety vendor-rule threshold evidence, CANDIDATE for dump-only robust outliers, NO when analyzed snapshots contain neither, UNKNOWN when timing/data are insufficient.
- Keeps this classification separate from treatment cavitation/power-decrease/safety events.
- Reuses the immutable secondary-analysis payload; no GUI-thread re-decode or file parsing is added.
- Carries forward R0116zzg17 primary Spectrum publish anti-regression and all previous cavitation/timing fixes.
