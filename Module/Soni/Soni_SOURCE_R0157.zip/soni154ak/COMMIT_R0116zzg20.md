# R0116zzg20 — Spectrum primary publish triple-check hardening

Focus: repeated empty Spectrum tab despite successful CPC FFT decode.

## Triple-check findings
1. **Loaded-Export handoff was not using the g17 target-aware publisher.**
   `_finish_loaded_sonication_handoff()` still queued `_publish_primary_replay_after_decode()` with a captured replay object. If the shared repository replaced that equivalent replay before the Qt timer fired, the identity guard discarded the only paint. Direct dump decode had already been hardened, but the loaded-Export path had not.
2. **The core publisher still treated Python object identity as an ownership contract.**
   Equivalent replay instances are legitimate during repository/preload adoption. Ownership is now checked by selected Sonication + resolved Spectrum source + decoded frame count.
3. **Recovery trusted a bookkeeping signature, not visible curves.**
   A zero-curve/partial publish could still set `_primary_materialized_signature`; the 80/300 ms recovery turns then exited while the chart remained empty. Recovery now confirms an actual pyqtgraph data item exists before considering Spectrum materialized.

## Changes
- Unify loaded-Export and direct-decode primary publication on `_publish_primary_latest()`.
- Add 80 ms and 300 ms no-I/O materialization checks to loaded-Export handoff too.
- Allow equivalent repository replay replacement in `_publish_primary_replay_after_decode()` when authoritative signatures match.
- Add `_spectrum_primary_visible()` and never mark primary materialized without a visible Spectrum data curve.
- Clear stale primary/recovery signatures whenever a new decoded replay is adopted.
- Remove unreachable post-return secondary-analysis code in direct decode path; secondary analysis remains launched by successful primary publication.

No FFT decode, calibration, cavitation, MR timeline, Spectrogram, or Band Energy algorithms were changed.
