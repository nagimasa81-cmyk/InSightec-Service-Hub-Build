# R0154ag — Brain 220 Power / Score replay repair

## Root cause

Replay Score parsing accepted only compact values such as `<0.005>`. Brain 220
Acquisition logs also emit the same evidence as `< 0.005 >`. The cavitation
timeline parser already accepted that syntax, but `AcousticControlService` did
not, leaving every Score sample as NaN and the Replay chart at `Score: --`.

## Fix

- Accept optional whitespace inside both Calculated Energy and harmless-limit
  angle brackets.
- Preserve the authoritative Workstation PowerGraph as the Power % source.
- Add a behavioral Brain 220 regression covering both harmless-limit label and
  separator variants.
