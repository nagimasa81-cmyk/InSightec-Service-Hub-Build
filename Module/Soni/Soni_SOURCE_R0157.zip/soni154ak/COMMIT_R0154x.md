# R0154x

- Brain220 Spectrum Analyzer source arbitration: when an exact Sonication-owned SpectrumMsg exists, Sonication selection uses it as the default spectral stream. Physical CPC 8CH/history candidates remain separately selectable as SpectrumDumps entries.
- Removed blanket frequency-family exclusion from the front of Brain220 DQA alignment. A proven same-raster DQA measurement may be reported for 220/230 kHz; otherwise Brain220 numeric displacement remains fail-closed.
- Sonication Summary now exposes export-proven executed Target voxel(s): count plus physical size. Ownership comes from SpotSonicationData and size from SpotData/validated SpotMesh. BBB internal sub-sonications are never counted as target voxels.
- Clarified that the fixed cyan '+' at image center is an annotation/display raster center, not a treatment target or DQA focus.
