# R0060 — Cavitation Intelligence Workspace Usability

- Enlarged probable-location and MR signal-loss correlation views.
- Added explicit synchronized Replay position (Sonication, replay frame, time, CPC snapshot, acquisition cycle).
- Added Previous / Next and Show in Replay controls.
- Event and sonication-element lists are side-by-side and collapsed by default.
- Added workstation-style mouse drag WW/WL control to the MR correlation image; wheel zoom and right-drag pan remain available.
