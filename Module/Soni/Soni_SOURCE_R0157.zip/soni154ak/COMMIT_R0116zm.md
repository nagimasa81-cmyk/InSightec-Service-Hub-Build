# R0116zm — Sonication Evidence Chain + Canonical Timeline

## Purpose
Make the numbered Sonication folder the identity anchor and connect every related data source to the same treatment Sonication and the same time-zero.

## Evidence chain
SonicationN folder -> SpectrumMsg-N -> spotsonicationdata PowerGraph -> SonicationSummary -> Sonication_Brain Type6 setup -> Acquisition_Brain session -> physical CPC Spectrum RAW/FFT -> Vendor Band0/CGA/Control.

## Implemented
- Added SonicationEvidenceService.
- Sweeps per-Sonication folder inventory (SpectrumMsg, ACT, RAW, INI, text/log, total).
- Validates SpectrumMsg frame count against PowerGraphSize.
- Validates PowerGraph end against actualsonicduration.
- Parses Sonication_Brain Type6 records including acoustic power, duration, frequency, steering, cavitation mode/level, channel/subsonication metadata and receiver skull attenuation.
- Finds a unique contiguous Type6 treatment block by Sonication power/frequency/duration signature rather than assuming the final N records.
- Binds Type6 setup clock to Acquisition_Brain session start.
- CPC mapping now first requires the independently-derived Acquisition session to match the Sonication canonical session.
- CPC replay uses Sonication PowerGraph time-zero offset; raw acquisition pre-roll is no longer treated as Sonication time.
- SpectrumMsg timestamps use exact PowerGraph timestamps when cardinality matches.
- Spectrum/Spectrogram/RCV views use sonication_frame_times_s.
- Cavitation Control timeline accepts the same Sonication time-zero offset.
- Unresolved identity remains unresolved rather than silently selecting another CPC source.

## Real export validation — 4231-2026-08-13-11-17-24.zip
- Sonications: 13.
- SpectrumMsg frame count == PowerGraphSize: 13/13.
- PowerGraph end == actualsonicduration: 13/13.
- Unique Sonication_Brain Type6 treatment block: 13/13.
- Type6 -> Acquisition session: sessions 7..19, 13/13 Exact.
- CPC candidate -> same Acquisition sessions: 7..19, 13/13.
- Sonication3 canonical session: 9.
- Sonication3 Acquisition pre-roll offset: 14.435865 s; old event 18.650 s becomes Sonication t=4.214135 s.

## Older June export validation
- SpectrumMsg frame count == PowerGraphSize: 8/8.
- Strong Type6 chain unavailable in this export, therefore not falsely marked Exact.
- Conservative CPC/Acquisition treatment-block fallback maps sessions 8..15, 8/8.

## Regression
- R0116 tests: 162/162 PASS.
- Full non-PySide6 suite: 468/468 PASS.
- compileall: PASS.
- GUI ROI test requiring PySide6 cannot run in this container.
