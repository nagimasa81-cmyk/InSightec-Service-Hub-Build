# R0116ze — Atomic Study Switch / Stale State Elimination

## Why this revision exists
R0116zd correctly unified CPC Spectrum mapping and improved preload progress, but the
main window still kept the previous `self.package` alive while a replacement ZIP was
loading. The widgets were cleared, yet old-study preload/summary callbacks could still
see an authoritative package. If the replacement ZIP failed or contained no compatible
Sonication, stale study state could remain logically adopted and later repopulate tabs.

## Changes
- Source switching now cancels Spectrum preload before detaching the old study.
- Cached Spectrum preload context and CPC binding caches are invalidated immediately.
- `self.package`, `self.current`, Sonication index, calibration and Spectrum provider are
  reset atomically with the visible UI.
- The previous extracted workspace is retained only as a cleanup token and is released
  when the replacement load reaches success, no-compatible-data, or failure.
- Spectrum Dump Analyzer receives the same hard source reset at switch time.
- Added regression tests proving stale package state cannot survive a source switch.

## Scope retained from R0116zd
The authoritative CPC mapping, latest-N physical-pair fallback, zero-frame preload
rejection, real decode progress relay, and loaded-workspace Spectrum discovery remain
unchanged.
