# R0116zzg22 — Spectrum gap reconstruction with provenance

- Detects real CPC FFT timestamp gaps instead of visually interpolating through them.
- Spectrogram keeps missing FFT intervals missing; no full-spectrum values are invented.
- Band Energy measured curves are broken across long FFT gaps.
- When CPC 10-ms measurement history is validated against embedded Band0 fingerprints, Band0 metric history is retained in the shared secondary-analysis cache and rendered as `reconstructed metric`.
- Full-spectrum reconstruction is allowed only when structurally verified RAW A/D exists. The supplied CPC history arrays are never relabeled as RAW waveform.
- Reconstructed metrics are display/metric evidence only and are not promoted to measured Spectrum snapshots or spectral cavitation evidence.
