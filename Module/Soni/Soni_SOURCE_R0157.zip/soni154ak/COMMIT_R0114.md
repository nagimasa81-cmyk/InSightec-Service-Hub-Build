# R0114 — Registration Performance and Thumbnail Slider Repair

- Restored a visible, mouse-grabbable thumbnail scrollbar handle with stable page/single steps.
- Removed full reference-series registration diagnostics from the normal image-display path; diagnostics now run only when Registration Trace is explicitly opened.
- Cached the decoded CT volume, native 3-D skull mask, and completed per-MR-slice registration render.
- Invalidated all registration caches when the replay/sonication planning data is cleared or rebuilt.
- Preserved the exported CtMr/MrMr matrix chain without adding image-similarity correction or modifying treatment geometry.
