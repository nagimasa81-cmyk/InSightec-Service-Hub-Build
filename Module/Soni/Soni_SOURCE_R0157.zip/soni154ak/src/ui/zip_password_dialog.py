from __future__ import annotations

"""Small Settings dialog for the configurable ZIP-open password list.

This is the in-app equivalent of hand-editing zip_passwords.json: it reads
and writes through the same ZipPasswordService, so nothing here is a second
source of truth for the password list.
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QPushButton,
)

from src.services.zip_password_service import ZipPasswordService
from src.ui.i18n import localize_qt_tree, ui_text


class ZipPasswordSettingsDialog(QDialog):
    def __init__(self, parent=None, service: ZipPasswordService | None = None):
        super().__init__(parent)
        self._locale = str(getattr(parent, "language", "en") or "en")
        self.setWindowTitle(ui_text(self._locale, "ZIP Password Settings"))
        self.setMinimumWidth(420)
        self.service = service or ZipPasswordService()

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(
            "Passwords tried, in order, when opening a password-protected ZIP.\n"
            "A built-in default is pre-filled on first use; add or remove any "
            "site-specific password here at any time -- no restart required."
        ))

        self.list_widget = QListWidget()
        layout.addWidget(self.list_widget, 1)

        add_row = QHBoxLayout()
        self.new_password_edit = QLineEdit()
        self.new_password_edit.setPlaceholderText("New password…")
        self.new_password_edit.returnPressed.connect(self._add_password)
        add_row.addWidget(self.new_password_edit, 1)
        add_btn = QPushButton("Add")
        add_btn.clicked.connect(self._add_password)
        add_row.addWidget(add_btn)
        layout.addLayout(add_row)

        remove_btn = QPushButton("Remove selected")
        remove_btn.clicked.connect(self._remove_selected)
        layout.addWidget(remove_btn)

        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

        self._reload()

        # R0121: this dialog is built on demand each time it is opened, so it
        # never gets swept by the MainWindow-level localize_qt_tree() call
        # that runs on a *language change*. Localize it once here, using
        # whichever locale the parent window is currently showing.
        localize_qt_tree(self, self._locale)

    def _reload(self) -> None:
        self.list_widget.clear()
        for password in self.service.get_passwords():
            self.list_widget.addItem(password)

    def _add_password(self) -> None:
        password = self.new_password_edit.text().strip()
        if not password:
            return
        self.service.add_password(password)
        self.new_password_edit.clear()
        self._reload()

    def _remove_selected(self) -> None:
        items = self.list_widget.selectedItems()
        if not items:
            return
        for item in items:
            self.service.remove_password(item.text())
        self._reload()
