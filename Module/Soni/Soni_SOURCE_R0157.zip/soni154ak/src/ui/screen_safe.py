from __future__ import annotations

from PySide6.QtCore import QEvent, QObject, QTimer
from PySide6.QtWidgets import QApplication, QDialog, QMainWindow, QWidget


# Keep a small guaranteed strip above the Windows taskbar / dock.  Some Windows
# display/scaling combinations report an availableGeometry that is a handful of
# pixels too optimistic until the native frame has settled.
DEFAULT_MARGIN = 10
DEFAULT_BOTTOM_RESERVE = 24


def _safe_screen_rect(widget: QWidget, margin: int = DEFAULT_MARGIN, bottom_reserve: int = DEFAULT_BOTTOM_RESERVE):
    screen = widget.screen() or QApplication.primaryScreen()
    if screen is None:
        return None
    area = screen.availableGeometry()
    left = area.left() + margin
    top = area.top() + margin
    right = area.right() - margin
    bottom = area.bottom() - margin - bottom_reserve
    if right <= left or bottom <= top:
        return area
    return area.adjusted(margin, margin, -margin, -(margin + bottom_reserve))


def fit_top_level_to_screen(widget: QWidget, *, margin: int = DEFAULT_MARGIN, bottom_reserve: int = DEFAULT_BOTTOM_RESERVE) -> None:
    """Keep a top-level dialog/window fully inside the usable desktop.

    Geometry is calculated from the *native frame* rather than client geometry.
    This is important on Windows where title-bar/border metrics appear only after
    show() and can otherwise push the bottom control row under the taskbar.

    The function is intentionally conservative: maximized/full-screen windows are
    left to the window manager, while normal windows may have their minimum size
    reduced only as far as required by the current screen.
    """
    if widget is None or not widget.isWindow():
        return
    if widget.isMaximized() or widget.isFullScreen():
        return
    safe = _safe_screen_rect(widget, margin=margin, bottom_reserve=bottom_reserve)
    if safe is None:
        return

    try:
        if widget.layout() is not None:
            widget.layout().activate()
    except Exception:
        pass

    geom = widget.geometry()
    frame = widget.frameGeometry()
    extra_w = max(0, frame.width() - geom.width())
    extra_h = max(0, frame.height() - geom.height())
    max_client_w = max(320, safe.width() - extra_w)
    max_client_h = max(240, safe.height() - extra_h)

    # A hard minimum larger than the screen makes every later resize/clamp fail.
    # Lower only the offending dimension; preserve the application's normal
    # minimum on larger displays.
    min_w = min(widget.minimumWidth(), max_client_w)
    min_h = min(widget.minimumHeight(), max_client_h)
    if min_w != widget.minimumWidth() or min_h != widget.minimumHeight():
        widget.setMinimumSize(max(0, min_w), max(0, min_h))

    target_w = min(widget.width(), max_client_w)
    target_h = min(widget.height(), max_client_h)
    if target_w != widget.width() or target_h != widget.height():
        widget.resize(max(min_w, target_w), max(min_h, target_h))
        try:
            if widget.layout() is not None:
                widget.layout().activate()
        except Exception:
            pass

    # Re-read frame metrics after resize, then position the native frame.
    frame = widget.frameGeometry()
    x = min(max(frame.x(), safe.left()), max(safe.left(), safe.right() - frame.width() + 1))
    y = min(max(frame.y(), safe.top()), max(safe.top(), safe.bottom() - frame.height() + 1))
    if (x, y) != (frame.x(), frame.y()):
        delta = widget.pos() - frame.topLeft()
        widget.move(x + delta.x(), y + delta.y())


class ScreenSafeTopLevelFilter(QObject):
    """Application-wide laptop-safe guard for every QMainWindow/QDialog path."""

    def eventFilter(self, obj, event):
        if isinstance(obj, (QMainWindow, QDialog)) and obj.isWindow():
            et = event.type()
            if et in (QEvent.Type.Show, QEvent.Type.WindowStateChange):
                # Native frame metrics settle asynchronously on Windows.  Three
                # passes cover immediate layout, frame creation and late sizeHint
                # changes without continuously fighting user-driven resizing.
                for delay in (0, 60, 180):
                    QTimer.singleShot(delay, lambda w=obj: fit_top_level_to_screen(w))
        return False


def install_screen_safe_guard(app: QApplication) -> ScreenSafeTopLevelFilter:
    guard = ScreenSafeTopLevelFilter(app)
    app.installEventFilter(guard)
    # Keep a strong reference for the whole QApplication lifetime.
    app._screen_safe_top_level_guard = guard
    return guard
