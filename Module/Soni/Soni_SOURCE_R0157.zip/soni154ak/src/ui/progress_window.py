from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QProgressBar


class BusyProgressDialog(QDialog):
    """Visible non-modal progress window for long-running data operations.

    Data ownership is guarded by generation/request tokens in the callers.  Keeping
    this dialog non-modal prevents a slow/stalled worker from making the whole
    application appear frozen on Windows while preserving a clear progress signal.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("BusyProgressDialog")
        self.setWindowTitle("Processing")
        self.setWindowModality(Qt.WindowModality.NonModal)
        self.setWindowFlag(Qt.WindowType.WindowContextHelpButtonHint, False)
        self.setWindowFlag(Qt.WindowType.WindowCloseButtonHint, False)
        self.setMinimumWidth(460)
        self.setMaximumWidth(680)

        layout = QVBoxLayout(self)
        self.title_label = QLabel("Loading data…")
        self.title_label.setStyleSheet("font-size:16px;font-weight:600;")
        self.message_label = QLabel("Please wait. Controls are temporarily locked while this operation is running.")
        self.message_label.setWordWrap(True)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.detail_label = QLabel("")
        self.detail_label.setWordWrap(True)
        self.detail_label.setStyleSheet("color:#59636e;")
        layout.addWidget(self.title_label)
        layout.addWidget(self.message_label)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.detail_label)

    def reject(self):
        # Exclusive operations are intentionally non-cancelable.
        return

    def closeEvent(self, event):
        if self.property("allow_close"):
            event.accept()
        else:
            event.ignore()

    def show_progress(self, value: int, detail: str = "", *, title: str | None = None,
                      message: str | None = None, process_events: bool = True) -> None:
        if title:
            self.setWindowTitle(title)
            self.title_label.setText(title)
        if message:
            self.message_label.setText(message)
        self.progress_bar.setValue(max(0, min(100, int(value))))
        self.detail_label.setText(detail or "")
        if not self.isVisible():
            self.show()
        self.raise_()
        self.activateWindow()
        # Intentionally no nested event-loop pumping; background workers keep the UI responsive.

    def finish(self) -> None:
        self.setProperty("allow_close", True)
        self.hide()
        self.setProperty("allow_close", False)


class BackgroundProgressDialog(QDialog):
    """Non-modal progress popup for long background analyses.

    It keeps the main window responsive while making background work explicit.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Processing")
        self.setWindowModality(Qt.WindowModality.NonModal)
        self.setWindowFlag(Qt.WindowType.WindowContextHelpButtonHint, False)
        self.setMinimumWidth(420)
        layout=QVBoxLayout(self)
        self.title_label=QLabel("Processing…")
        self.title_label.setStyleSheet("font-size:15px;font-weight:600;")
        self.message_label=QLabel(""); self.message_label.setWordWrap(True)
        self.progress_bar=QProgressBar(); self.progress_bar.setRange(0,100); self.progress_bar.setValue(0)
        layout.addWidget(self.title_label); layout.addWidget(self.message_label); layout.addWidget(self.progress_bar)

    def show_progress(self, value:int, detail:str="", title:str="Processing", *, message:str|None=None, process_events:bool=False):
        self.setWindowTitle(title); self.title_label.setText(title)
        text=str(detail or "")
        if message:
            text = text + ("\n" if text else "") + str(message)
        self.message_label.setText(text)
        self.progress_bar.setValue(max(0,min(100,int(value))))
        if not self.isVisible(): self.show()
        self.raise_()
        # Never pump a nested event loop here. `process_events` is accepted only
        # for backward call compatibility with BusyProgressDialog.

    def finish(self):
        self.hide()
