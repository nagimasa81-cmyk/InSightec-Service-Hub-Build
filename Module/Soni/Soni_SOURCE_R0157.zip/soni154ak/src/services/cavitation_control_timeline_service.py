from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re

import numpy as np

from src.services.cpc_vendor_reproduction_service import VendorCavitationProfile, CpcVendorReproductionService


@dataclass(slots=True)
class ObservedCavitationEvent:
    session_index: int
    timestamp_s: float | None
    cycle: int | None
    family: str
    rule_index: int
    severity: str
    weighted_energy: float | None
    threshold: float | None
    critical_threshold: float | None
    contributing_channels: tuple[int, ...] = ()
    contributing_bands: tuple[int, ...] = ()
    rule_channels: tuple[int, ...] = ()
    rule_bands: tuple[int, ...] = ()
    observed_channels: tuple[int, ...] = ()
    observed_bands: tuple[int, ...] = ()
    dominant_channel: int | None = None
    dominant_band: int | None = None
    dominant_energy: float | None = None
    before_power_ratio: float | None = None
    after_power_ratio: float | None = None
    action: str = ""
    result: str = ""
    evidence: str = ""
    source_message: str = ""
    irradiation_state: str = "Unknown"
    exciter_power_w: float | None = None
    counts_as_cavitation: bool = False


@dataclass(slots=True)
class CavitationControlTimeline:
    source_log: Path | None = None
    session_index: int | None = None
    events: list[ObservedCavitationEvent] = field(default_factory=list)
    session_start_s: float | None = None
    actual_power_times_s: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    actual_power_ratio: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    actual_power_cycles: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=int))
    exciter_power_times_s: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    exciter_power: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    irradiation_onset_s: float | None = None
    predicted_power_times_s: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    predicted_power_ratio: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    cycle_numbers: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=int))
    cycle_times_s: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    summary: str = ""


class CavitationControlTimelineService:
    _LOG_TEXT_CACHE: dict[str, tuple[int, int, tuple[str, ...]]] = {}

    @classmethod
    def _cached_log_lines(cls, path: Path) -> tuple[str, ...]:
        """Read Acquisition_Brain once per unchanged file for repeated session queries."""
        try:
            stat=path.stat(); key=str(path.resolve())
            signature=(int(stat.st_mtime_ns),int(stat.st_size))
            cached=cls._LOG_TEXT_CACHE.get(key)
            if cached is not None and cached[:2]==signature:
                return cached[2]
            with path.open("r",encoding="utf-8",errors="ignore") as handle:
                lines=tuple(line.rstrip("\n") for line in handle)
            cls._LOG_TEXT_CACHE[key]=(signature[0],signature[1],lines)
            return lines
        except Exception:
            return ()

    @staticmethod
    def control_response_severity(events) -> dict:
        """Return descriptive cavitation-control response metrics.

        Severity is *not* a clinical cavitation grade. It is a transparent 0–100
        control-response score derived from observed power modulation. Repeated
        Decrease events accumulate through the actually observed ExPowerRatio
        reductions. Any Safety event that halts the sonication scores 100.
        """
        qualified=[]
        for event in list(events or []):
            family=str(getattr(event,"family","") or "")
            active=str(getattr(event,"irradiation_state","") or "") == "Irradiation active"
            if family not in {"Decrease","Safety"}:
                continue
            if bool(getattr(event,"counts_as_cavitation",False)) or active:
                qualified.append(event)
        modulation_events=[]; safety_events=[]; drops=[]
        safety_stop=False
        for event in qualified:
            family=str(getattr(event,"family","") or "")
            before=getattr(event,"before_power_ratio",None); after=getattr(event,"after_power_ratio",None)
            result=str(getattr(event,"result","") or "").upper()
            if family == "Decrease":
                modulation_events.append(event)
                try:
                    b=float(before); a=float(after)
                    if np.isfinite(b) and np.isfinite(a) and b > 1e-9 and a < b:
                        drops.append(float(np.clip((b-a)/b,0.0,1.0)))
                except (TypeError,ValueError):
                    pass
            elif family == "Safety":
                safety_events.append(event)
                try:
                    stopped=(after is not None and float(after) <= 1e-9)
                except (TypeError,ValueError):
                    stopped=False
                safety_stop = safety_stop or stopped or ("HALT" in result) or ("STOP" in result)
        residual=1.0
        for drop in drops:
            residual *= (1.0-float(drop))
        if not qualified:
            modulation_burden=None
            severity=None
        else:
            modulation_burden=float(np.clip(1.0-residual,0.0,1.0)) if drops else (0.0 if not modulation_events else None)
            severity=100.0 if safety_stop else (100.0*modulation_burden if modulation_burden is not None else None)
        return {
            "severity": severity,
            "modulation_count": len(modulation_events),
            "safety_event_count": len(safety_events),
            "safety_stop_count": 1 if safety_stop else 0,
            "cumulative_power_reduction_fraction": modulation_burden,
            "event_count": len(qualified),
        }

    _TS_RE = re.compile(r"(?P<h>\d{2}):(?P<m>\d{2}):(?P<s>\d{2}):(?P<ms>\d{3})")
    # Keep control-session boundaries identical to AcousticControlService.
    # Some workstation releases log "StartSpectrumMeasurement: SetInitial ..."
    # without the older "Got StartSpectrumMeasurement..." prefix.
    _START_RE = re.compile(
        r"(?:Got\s+StartSpectrumMeasurementA|Got\s+StartSpectrumMeasurement|"
        r"StartSpectrumMeasurement:\s*SetInitial\s+PowerRatios)",
        re.I,
    )
    _SET_RE = re.compile(r"Set:.*?ExciterPower\s*=\s*([^,]+),.*?ExPowerRatio\s*=\s*([-+0-9.eE]+)", re.I)
    _CYCLE_RE = re.compile(r"Cycle\s+(\d+)\s+Done", re.I)
    _INC_RE = re.compile(r"Increase Power Rule no\.\s*(\d+)\s*:.*?Calculated Energy:\s*<\s*([-+0-9.eE]+)\s*>.*?Bottom.*?:\s*<\s*([-+0-9.eE]+)\s*>", re.I)
    _DEC_RE = re.compile(r"Decrease Power Rule no\.\s*(\d+)\s*:.*?Calculated Energy:\s*<\s*([-+0-9.eE]+)\s*>.*?Calculated Top Energy limit:\s*<\s*([-+0-9.eE]+)\s*>", re.I)
    _SAFETY_RE = re.compile(r"Safety Rule no\.\s*(\d+)\s*:.*?(critical|maximal).*", re.I)
    _CALC_RE = re.compile(r"Calculated Energy:\s*<\s*([-+0-9.eE]+)\s*>", re.I)
    _THRESH_RE = re.compile(r"(Critical|Maximum) Energy:\s*<\s*([-+0-9.eE]+)\s*>", re.I)
    _RULE_BLOCK_RE = re.compile(r"RuleNo\.\s*<(\d+)>.*?calculation\s+([-+0-9.eE]+)\s*=", re.I)
    _CH_RE = re.compile(r"Ch\s*<\s*(\d+)\s*>\s*(.*)")
    _BAND_TERM_RE = re.compile(r"band<(\d+)>\s*([-+0-9.eE]+).*?\*\s*([-+0-9.eE]+)\(", re.I)

    @staticmethod
    def _timestamp_s(line: str) -> float | None:
        m = CavitationControlTimelineService._TS_RE.search(line)
        if not m:
            return None
        return int(m.group("h")) * 3600 + int(m.group("m")) * 60 + int(m.group("s")) + int(m.group("ms")) / 1000.0

    @staticmethod
    def _find_log(source_path: Path | None) -> Path | None:
        # R0143: use the same treatment-aware Acquisition_Brain selector as every
        # other control/Spectrum consumer. Export CPCFiles can retain older, larger
        # logs; alphabetical or size-first selection binds current Spectrum data to
        # stale sessions and makes control evidence appear unavailable.
        if source_path is None:
            return None
        try:
            from src.services.acoustic_control_service import AcousticControlService
            return AcousticControlService().find_log(Path(source_path))
        except Exception:
            return None

    @staticmethod
    def _rule_from_profile(profile: VendorCavitationProfile | None, family: str, index: int):
        if profile is None:
            return None
        if family == "Increase":
            return profile.increase_rule0 if index == 0 else None
        if family == "Decrease":
            return profile.decrease_rules.get(index)
        if family == "Safety":
            return profile.safety_rules.get(index)
        if family == "Dynamic":
            return profile.dynamic_rules.get(index)
        return None

    @staticmethod
    def _rule_channels_bands(rule) -> tuple[tuple[int, ...], tuple[int, ...]]:
        if rule is None or not hasattr(rule, "weights"):
            return (), ()
        active = np.argwhere(np.asarray(rule.weights, float) != 0)
        if active.size == 0:
            return (), ()
        channels = tuple(sorted({int(ch) for ch, _band in active}))
        bands = tuple(sorted({int(band) for _ch, band in active}))
        return channels, bands

    @staticmethod
    def _relative_times(times: list[float]) -> tuple[np.ndarray, float | None]:
        if not times:
            return np.asarray([], dtype=float), None
        base = float(times[0])
        return np.asarray([float(t) - base for t in times], dtype=float), base

    def parse(
        self,
        source_path: Path | None,
        profile: VendorCavitationProfile | None,
        preferred_session_index: int | None = None,
        predicted_cycles: np.ndarray | None = None,
        predicted_ratio: np.ndarray | None = None,
        sonication_time_zero_offset_s: float = 0.0,
        mr_sonication_start_s: float = 0.0,
        mr_sonication_end_s: float = 0.0,
        mr_timeline_duration_s: float = 0.0,
        cycle_anchor_cycle: int | None = None,
        cycle_anchor_acquisition_time_s: float | None = None,
        acquisition_interval_s: float = 0.010,
    ) -> CavitationControlTimeline:
        timeline = CavitationControlTimeline()
        log_path = self._find_log(source_path)
        timeline.source_log = log_path
        if log_path is None:
            timeline.summary = "Acquisition_Brain log not found; observed cavitation-control timeline unavailable."
            return timeline

        sessions: list[dict] = []
        current = {"events": [], "power": [], "exciter": [], "cycles": []}
        session_index = 0
        pending_non_safety: list[ObservedCavitationEvent] = []
        pending_safety: list[ObservedCavitationEvent] = []
        last_power_ratio: float | None = None
        last_cycle: int | None = None
        safety_stub: dict | None = None
        block_event: ObservedCavitationEvent | None = None
        block_remaining = 0

        for line in self._cached_log_lines(log_path):
                ts = self._timestamp_s(line)

                if self._START_RE.search(line):
                    if current["events"] or current["power"] or current["exciter"] or current["cycles"]:
                        sessions.append(current)
                    current = {"events": [], "power": [], "exciter": [], "cycles": []}
                    session_index = len(sessions)
                    pending_non_safety = []
                    pending_safety = []
                    last_power_ratio = None
                    last_cycle = None
                    safety_stub = None
                    block_event = None
                    block_remaining = 0
                    continue

                cycle_match = self._CYCLE_RE.search(line)
                if cycle_match:
                    last_cycle = int(cycle_match.group(1))
                    if ts is not None:
                        current["cycles"].append((last_cycle, float(ts)))

                set_match = self._SET_RE.search(line)
                if set_match:
                    try:
                        exciter_token=re.search(r"[-+0-9.eE]+",set_match.group(1))
                        exciter_power=float(exciter_token.group(0)) if exciter_token else None
                    except (ValueError,AttributeError):
                        exciter_power = None
                    try:
                        after_ratio = float(set_match.group(2))
                    except ValueError:
                        after_ratio = None
                    if ts is not None and exciter_power is not None:
                        current["exciter"].append((ts, exciter_power))
                    if ts is not None and after_ratio is not None:
                        current["power"].append((ts, after_ratio, (last_cycle + 1) if last_cycle is not None else None))
                    attach = list(pending_non_safety)
                    attach.extend(e for e in pending_safety if e.result or e.action or after_ratio == 0.0)
                    for event in attach:
                        if event.after_power_ratio is None:
                            event.before_power_ratio = last_power_ratio
                            event.after_power_ratio = after_ratio
                            if not event.action:
                                event.action = f"{event.family} control"
                            if not event.result:
                                if after_ratio == 0.0 and event.family == "Safety":
                                    event.result = "HALTED BY CAVITATION"
                                else:
                                    before = "?" if last_power_ratio is None else f"{last_power_ratio:.3f}"
                                    after = "?" if after_ratio is None else f"{after_ratio:.3f}"
                                    event.result = f"ExPowerRatio {before} → {after}"
                    pending_non_safety = []
                    if after_ratio == 0.0:
                        pending_safety = []
                    last_power_ratio = after_ratio
                    continue

                inc_match = self._INC_RE.search(line)
                if inc_match:
                    idx = int(inc_match.group(1))
                    energy = float(inc_match.group(2))
                    threshold = float(inc_match.group(3))
                    rule = self._rule_from_profile(profile, "Increase", idx)
                    channels, bands = self._rule_channels_bands(rule)
                    event = ObservedCavitationEvent(
                        session_index=session_index,
                        timestamp_s=ts,
                        cycle=last_cycle,
                        family="Increase",
                        rule_index=idx,
                        severity="Observed",
                        weighted_energy=energy,
                        threshold=threshold,
                        critical_threshold=None,
                        contributing_channels=channels,
                        contributing_bands=bands,
                        rule_channels=channels,
                        rule_bands=bands,
                        action="Increase power",
                        evidence="Acquisition_Brain",
                        source_message=line.strip(),
                    )
                    current["events"].append(event)
                    pending_non_safety.append(event)
                    continue

                dec_match = self._DEC_RE.search(line)
                if dec_match:
                    idx = int(dec_match.group(1))
                    energy = float(dec_match.group(2))
                    threshold = float(dec_match.group(3))
                    rule = self._rule_from_profile(profile, "Decrease", idx)
                    channels, bands = self._rule_channels_bands(rule)
                    event = ObservedCavitationEvent(
                        session_index=session_index,
                        timestamp_s=ts,
                        cycle=last_cycle,
                        family="Decrease",
                        rule_index=idx,
                        severity="Observed",
                        weighted_energy=energy,
                        threshold=threshold,
                        critical_threshold=None,
                        contributing_channels=channels,
                        contributing_bands=bands,
                        rule_channels=channels,
                        rule_bands=bands,
                        action="Decrease power",
                        evidence="Acquisition_Brain",
                        source_message=line.strip(),
                    )
                    current["events"].append(event)
                    pending_non_safety.append(event)
                    continue

                safety_match = self._SAFETY_RE.search(line)
                if safety_match:
                    safety_stub = {
                        "idx": int(safety_match.group(1)),
                        "critical": "critical" in safety_match.group(2).lower(),
                        "ts": ts,
                        "cycle": last_cycle,
                        "line": line.strip(),
                    }
                    continue

                if safety_stub is not None:
                    calc_match = self._CALC_RE.search(line)
                    if calc_match:
                        safety_stub["energy"] = float(calc_match.group(1))
                        continue
                    thresh_match = self._THRESH_RE.search(line)
                    if thresh_match:
                        idx = int(safety_stub["idx"])
                        observed_threshold = float(thresh_match.group(2))
                        rule = self._rule_from_profile(profile, "Safety", idx)
                        channels, bands = self._rule_channels_bands(rule)
                        event = ObservedCavitationEvent(
                            session_index=session_index,
                            timestamp_s=safety_stub["ts"],
                            cycle=safety_stub["cycle"],
                            family="Safety",
                            rule_index=idx,
                            severity="Observed critical" if safety_stub.get("critical") else "Observed maximum",
                            weighted_energy=safety_stub.get("energy"),
                            threshold=(rule.threshold if rule is not None and rule.threshold is not None else (None if safety_stub.get("critical") else observed_threshold)),
                            critical_threshold=(rule.critical_threshold if rule is not None and rule.critical_threshold is not None else (observed_threshold if safety_stub.get("critical") else None)),
                            contributing_channels=channels,
                            contributing_bands=bands,
                            rule_channels=channels,
                            rule_bands=bands,
                            action="Safety evaluation",
                            evidence="Acquisition_Brain",
                            source_message=str(safety_stub.get("line","")),
                        )
                        current["events"].append(event)
                        pending_safety.append(event)
                        safety_stub = None
                        continue

                block_match = self._RULE_BLOCK_RE.search(line)
                if block_match:
                    rule_index = int(block_match.group(1))
                    block_event = None
                    for event in reversed(current["events"]):
                        if event.family == "Safety" and event.rule_index == rule_index and event.dominant_channel is None:
                            block_event = event
                            block_remaining = 8
                            break
                    continue

                if block_event is not None and block_remaining > 0:
                    ch_match = self._CH_RE.search(line)
                    if ch_match:
                        ch = int(ch_match.group(1))
                        rest = ch_match.group(2)
                        contrib_channels = set(block_event.contributing_channels)
                        contrib_bands = set(block_event.contributing_bands)
                        observed_channels = set(block_event.observed_channels)
                        observed_bands = set(block_event.observed_bands)
                        best = None
                        for band_match in self._BAND_TERM_RE.finditer(rest):
                            band = int(band_match.group(1))
                            energy = float(band_match.group(2))
                            weight = float(band_match.group(3))
                            if weight > 0:
                                contrib_channels.add(ch)
                                contrib_bands.add(band)
                                observed_channels.add(ch)
                                observed_bands.add(band)
                                contribution = energy * weight
                                if best is None or contribution > best[0]:
                                    best = (contribution, ch, band, energy)
                        block_event.contributing_channels = tuple(sorted(contrib_channels))
                        block_event.contributing_bands = tuple(sorted(contrib_bands))
                        block_event.observed_channels = tuple(sorted(observed_channels))
                        block_event.observed_bands = tuple(sorted(observed_bands))
                        if best is not None and (block_event.dominant_energy is None or best[3] > block_event.dominant_energy):
                            block_event.dominant_channel = best[1]
                            block_event.dominant_band = best[2]
                            block_event.dominant_energy = best[3]
                        block_remaining -= 1
                        if block_remaining <= 0:
                            block_event = None
                        continue

                if "HALTED BY CAVITATION" in line:
                    for event in reversed(current["events"]):
                        if event.family == "Safety" and not event.result:
                            event.action = "Immediate stop"
                            event.result = "HALTED BY CAVITATION"
                            break

        if current["events"] or current["power"] or current["exciter"] or current["cycles"]:
            sessions.append(current)

        if not sessions:
            timeline.summary = "Acquisition_Brain log found, but no cavitation-control events were parsed."
            return timeline

        if preferred_session_index is None or not (0 <= preferred_session_index < len(sessions)):
            preferred_session_index = max(range(len(sessions)), key=lambda i: len(sessions[i]["events"]))
        chosen = sessions[preferred_session_index]
        timeline.session_index = preferred_session_index
        def cycle_to_mr(cycle):
            """CPC-history fallback only; physical controller cycles take priority."""
            if cycle is None or cycle_anchor_cycle is None or cycle_anchor_acquisition_time_s is None:
                return None
            try:
                acq = float(cycle_anchor_acquisition_time_s) + (float(cycle)-float(cycle_anchor_cycle))*float(acquisition_interval_s or 0.010)
                return acq - float(sonication_time_zero_offset_s or 0.0) + float(mr_sonication_start_s or 0.0)
            except Exception:
                return None

        timeline.events = chosen["events"]
        power_times = [row[0] for row in chosen["power"]]
        power_values = [row[1] for row in chosen["power"]]
        power_cycles = [row[2] for row in chosen["power"]]
        rel_times, base = self._relative_times(power_times)
        timeline.session_start_s = base
        timeline.actual_power_ratio = np.asarray(power_values, dtype=float)
        timeline.actual_power_cycles = np.asarray([c if c is not None else -1 for c in power_cycles], dtype=int)

        # R0116zzg13 authoritative control clock:
        # chosen["power"] starts at the first physical ExPowerRatio Set for this
        # Sonication.  Therefore its relative timestamp is already Sonication
        # power time.  The old code subtracted Acquisition pre-roll a second time
        # and, worse, preferred the CPC FFT history cycle-20 anchor over the
        # controller's cycle-500+ domain.  Short cavitation-stop Sonications then
        # moved all Decrease/Safety rows negative and silently filtered them out.
        valid_actual_cycles = timeline.actual_power_cycles[timeline.actual_power_cycles >= 0]
        base_cycle = int(valid_actual_cycles[0]) if valid_actual_cycles.size else None
        interval = float(acquisition_interval_s or 0.010)

        # R0154: Acquisition.ini Acquire Interval is a scheduling target, not a
        # wall-clock timestamp.  Real CPC cycles can take >10 ms because DCA/HW
        # wait and processing time vary.  Preserve the exact Acquisition_Brain
        # Cycle N Done timestamps whenever they exist; fixed cycle*interval is
        # only a legacy fallback for logs without timestamped cycle rows.
        cycle_rows=list(chosen.get("cycles",[]) or [])
        if cycle_rows and base is not None:
            by_cycle={}
            for cyc, ts_abs in cycle_rows:
                try:
                    c=int(cyc); t=float(ts_abs)
                except (TypeError,ValueError):
                    continue
                if np.isfinite(t):
                    by_cycle[c]=t
            ordered=sorted(by_cycle.items())
            if ordered:
                timeline.cycle_numbers=np.asarray([c for c,_ in ordered],dtype=int)
                # Anchor the controller cycle that owns the first physical power
                # Set exactly at canonical Sonication start.  Cycle N Done is
                # logged a few milliseconds after the Set that began that cycle;
                # using that completion timestamp as t=0 would shift every
                # predicted/control point by one processing interval.  Preserve
                # the measured wall-clock deltas between cycles, but normalize
                # the base cycle itself to mr_sonication_start_s.
                anchor_ts=by_cycle.get(base_cycle) if base_cycle is not None else None
                if anchor_ts is None:
                    anchor_ts=float(base)
                timeline.cycle_times_s=np.asarray([t-float(anchor_ts)+float(mr_sonication_start_s or 0.0) for _,t in ordered],dtype=float)

        def control_cycle_to_mr(cycle):
            if cycle is None:
                return None
            try:
                c=float(cycle)
            except Exception:
                return None
            if timeline.cycle_numbers.size >= 2 and timeline.cycle_times_s.size == timeline.cycle_numbers.size:
                x=np.asarray(timeline.cycle_numbers,dtype=float); y=np.asarray(timeline.cycle_times_s,dtype=float)
                if x[0] <= c <= x[-1]:
                    return float(np.interp(c,x,y))
            if base_cycle is None:
                return None
            try:
                return (c - float(base_cycle)) * interval + float(mr_sonication_start_s or 0.0)
            except Exception:
                return None

        timeline.actual_power_times_s = np.asarray(rel_times, dtype=float) + float(mr_sonication_start_s or 0.0)
        if base_cycle is not None and timeline.actual_power_cycles.size:
            mapped=np.asarray([control_cycle_to_mr(c) if int(c) >= 0 else np.nan for c in timeline.actual_power_cycles],dtype=float)
            valid=np.isfinite(mapped)
            timeline.actual_power_times_s=np.where(valid,mapped,timeline.actual_power_times_s)

        exciter_rows=list(chosen.get("exciter",[]) or [])
        if exciter_rows:
            exc_abs=[float(r[0]) for r in exciter_rows]
            exc_values=np.asarray([float(r[1]) for r in exciter_rows],dtype=float)
            exc_base=float(base) if base is not None else float(exc_abs[0])
            timeline.exciter_power_times_s=np.asarray([t-exc_base for t in exc_abs],dtype=float) + float(mr_sonication_start_s or 0.0)
            timeline.exciter_power=exc_values
            positive=np.where(np.isfinite(exc_values) & (exc_values > 1e-9))[0]
            if positive.size:
                timeline.irradiation_onset_s=float(timeline.exciter_power_times_s[int(positive[0])])

        if predicted_cycles is not None and predicted_ratio is not None and np.asarray(predicted_cycles).size and np.asarray(predicted_ratio).size:
            pred_cycles = np.asarray(predicted_cycles, dtype=float)
            if base_cycle is not None:
                timeline.predicted_power_times_s = np.asarray([control_cycle_to_mr(c) for c in pred_cycles],dtype=float)
            elif cycle_anchor_cycle is not None and cycle_anchor_acquisition_time_s is not None:
                # Last-resort fallback for sources with no physical power Set rows.
                timeline.predicted_power_times_s = np.asarray([cycle_to_mr(c) for c in pred_cycles],dtype=float)
            else:
                timeline.predicted_power_times_s = (pred_cycles - pred_cycles[0]) * interval + float(mr_sonication_start_s or 0.0)
            timeline.predicted_power_ratio = np.asarray(predicted_ratio, dtype=float)

        for event in timeline.events:
            # Legacy CPC-history path was: anchored = cycle_to_mr(event.cycle).
            # Keep that function only as a no-controller-cycle fallback; normal
            # treatment events must use the physical ExPowerRatio cycle origin.
            anchored = control_cycle_to_mr(event.cycle) if event.cycle is not None else None
            if anchored is not None:
                event.timestamp_s = anchored
            elif event.timestamp_s is not None and base is not None:
                event.timestamp_s = float(event.timestamp_s) - float(base) + float(mr_sonication_start_s or 0.0)

            state="Unknown"
            if event.timestamp_s is not None and float(mr_sonication_start_s or 0.0) > 0:
                et=float(event.timestamp_s); st=float(mr_sonication_start_s); en=float(mr_sonication_end_s or 0.0)
                if et < st - 1e-9:
                    state="Pre-irradiation"
                elif en > st and et > en + 1e-9:
                    state="Post-irradiation"
                else:
                    state="Irradiation active"
            elif event.timestamp_s is not None and timeline.exciter_power_times_s.size:
                idx=np.searchsorted(timeline.exciter_power_times_s,float(event.timestamp_s),side="right")-1
                if idx < 0:
                    idx=0
                if idx < timeline.exciter_power.size:
                    event.exciter_power_w=float(timeline.exciter_power[idx])
                    state="Irradiation active" if event.exciter_power_w > 1e-9 else "Pre-irradiation"
            elif event.timestamp_s is not None and timeline.irradiation_onset_s is not None:
                state="Irradiation active" if float(event.timestamp_s) >= float(timeline.irradiation_onset_s)-1e-9 else "Pre-irradiation"
            event.irradiation_state=state

            trigger=False
            try:
                if event.weighted_energy is not None and event.threshold is not None:
                    if event.family=="Increase":
                        trigger=float(event.weighted_energy) < float(event.threshold)
                    else:
                        trigger=float(event.weighted_energy) > float(event.threshold)
            except Exception:
                trigger=False
            # R0116zzg1: the application-level cavitation event contract follows
            # the observed control response.  Any Decrease or Safety event assigned
            # to this Sonication is a cavitation event; Increase never is.  Keep the
            # threshold/irradiation-state diagnostics above as explanatory evidence,
            # but do not use them to hide a real power-decrease or safety response.
            event.counts_as_cavitation=bool(event.family in ("Decrease","Safety"))
            if not event.evidence:
                event.evidence = "Acquisition_Brain"

        # Exact treatment window is owned by Workstation power-on/off markers,
        # not by CPC exciter pre-roll. The latter may be active during setup.
        if float(mr_sonication_start_s or 0.0) > 0:
            timeline.irradiation_onset_s=float(mr_sonication_start_s)
        # Canonical application timeline is the MR acquisition window. CPC can
        # contain pre-MR setup/control and post-MR history; keep those available
        # in source evidence, but do not expose negative/out-of-window times as
        # if they belonged to the Sonication MR replay.
        mr_end = float(mr_timeline_duration_s or 0.0)
        def in_mr_window(values):
            arr=np.asarray(values,float)
            mask=np.isfinite(arr) & (arr >= -1e-9)
            if mr_end > 0:
                mask &= arr <= mr_end + 1e-9
            return mask
        mask=in_mr_window(timeline.actual_power_times_s)
        timeline.actual_power_times_s=timeline.actual_power_times_s[mask]
        timeline.actual_power_ratio=timeline.actual_power_ratio[mask]
        timeline.actual_power_cycles=timeline.actual_power_cycles[mask]
        if timeline.exciter_power_times_s.size:
            mask=in_mr_window(timeline.exciter_power_times_s)
            timeline.exciter_power_times_s=timeline.exciter_power_times_s[mask]
            timeline.exciter_power=timeline.exciter_power[mask]
        if timeline.predicted_power_times_s.size:
            mask=in_mr_window(timeline.predicted_power_times_s)
            timeline.predicted_power_times_s=timeline.predicted_power_times_s[mask]
            timeline.predicted_power_ratio=timeline.predicted_power_ratio[mask]
        timeline.events=[e for e in timeline.events if e.timestamp_s is not None and float(e.timestamp_s) >= -1e-9 and (mr_end <= 0 or float(e.timestamp_s) <= mr_end + 1e-9)]

        # Rule rows are not physical responses. Several rules can fire in the same
        # acquisition cycle and all attach to one ExPowerRatio change. Report both
        # raw evidence rows and unique controller responses so Summary/Analyzer do
        # not inflate one cavitation stop into dozens of "events".
        halt_cycles={e.cycle for e in timeline.events if "HALTED" in str(e.result).upper()}
        decrease_rows=sum(1 for e in timeline.events if e.family == "Decrease")
        increase_count=sum(1 for e in timeline.events if e.family == "Increase")
        safety_rows=sum(1 for e in timeline.events if e.family == "Safety")
        decrease_cycles={e.cycle for e in timeline.events if e.family == "Decrease"}
        safety_cycles={e.cycle for e in timeline.events if e.family == "Safety"}
        cav_cycles={e.cycle for e in timeline.events if e.counts_as_cavitation}
        halt_count=len(halt_cycles)
        decrease_count=len(decrease_cycles)
        safety_count=len(safety_cycles)
        cav_count=len(cav_cycles)
        pre_count=sum(1 for e in timeline.events if e.irradiation_state=="Pre-irradiation")
        onset_txt="unknown" if timeline.irradiation_onset_s is None else f"{timeline.irradiation_onset_s:.3f} s"
        timeline.summary = (
            f"Observed control session {preferred_session_index}: evidence rows={len(timeline.events)} "
            f"(increase rows={increase_count}, decrease responses={decrease_count}/{decrease_rows} rows, "
            f"safety responses={safety_count}/{safety_rows} rows, halts={halt_count}); "
            f"treatment cavitation responses={cav_count}, pre-irradiation control={pre_count}, irradiation onset={onset_txt}. "
            "Observed = parsed from Acquisition_Brain; pre-irradiation rule evaluations are not counted as treatment cavitation."
        )
        return timeline
