from __future__ import annotations
from pathlib import Path
import time
import numpy as np
from src.common.constants import IMAGE_SHAPE

class RawDecodeError(RuntimeError): pass

class RawService:
    @staticmethod
    def _validate_exact_raw_size(path: Path, dtype, expected_values: int, label: str) -> None:
        dt=np.dtype(dtype)
        expected_bytes=int(expected_values)*int(dt.itemsize)
        try:
            actual_bytes=int(Path(path).stat().st_size)
        except Exception as exc:
            raise RawDecodeError(f'{label} RAW size could not be read: {exc}') from exc
        if actual_bytes != expected_bytes:
            actual_values = actual_bytes / max(1, dt.itemsize)
            raise RawDecodeError(
                f'{label} RAW has {actual_bytes} bytes ({actual_values:g} values); '
                f'expected exactly {expected_bytes} bytes ({expected_values} values).'
            )


    @staticmethod
    def _read_exact_cooperative(path: Path, dtype, expected_values: int, label: str, cancel_check=None, deadline=None, chunk_bytes: int = 65536):
        dt=np.dtype(dtype)
        RawService._validate_exact_raw_size(path, dt, expected_values, label)
        expected_bytes=int(expected_values)*int(dt.itemsize)
        buffer=bytearray(expected_bytes)
        view=memoryview(buffer)
        offset=0
        with Path(path).open('rb', buffering=0) as fh:
            while offset < expected_bytes:
                if cancel_check is not None and bool(cancel_check()):
                    raise RawDecodeError(f'{label} RAW read cancelled.')
                if deadline is not None and time.monotonic() > float(deadline):
                    raise RawDecodeError(f'{label} RAW read exceeded deadline.')
                end=min(expected_bytes, offset+max(int(chunk_bytes), dt.itemsize))
                n=fh.readinto(view[offset:end])
                if not n:
                    break
                offset += int(n)
        if offset != expected_bytes:
            raise RawDecodeError(f'{label} RAW read returned {offset} bytes; expected {expected_bytes}.')
        if cancel_check is not None and bool(cancel_check()):
            raise RawDecodeError(f'{label} RAW read cancelled.')
        if deadline is not None and time.monotonic() > float(deadline):
            raise RawDecodeError(f'{label} RAW read exceeded deadline.')
        return np.frombuffer(buffer, dtype=dt, count=expected_values).copy()

    def read_temperature_cooperative(self,path:Path,cancel_check=None,deadline=None)->np.ndarray:
        expected=IMAGE_SHAPE[0]*IMAGE_SHAPE[1]
        data=self._read_exact_cooperative(path,'<f4',expected,'Temperature',cancel_check,deadline)
        return data.reshape(IMAGE_SHAPE)

    def read_magnitude_cooperative(self,path:Path,cancel_check=None,deadline=None)->np.ndarray:
        expected=IMAGE_SHAPE[0]*IMAGE_SHAPE[1]
        data=self._read_exact_cooperative(path,'<u2',expected,'Magnitude',cancel_check,deadline)
        return data.reshape(IMAGE_SHAPE).astype(np.float32)

    def read_temperature(self,path:Path)->np.ndarray:
        expected=IMAGE_SHAPE[0]*IMAGE_SHAPE[1]
        self._validate_exact_raw_size(path,'<f4',expected,'Temperature')
        data=np.fromfile(path,dtype='<f4',count=expected)
        if data.size!=expected: raise RawDecodeError(f'Temperature RAW read returned {data.size} values; expected {expected}.')
        return data.reshape(IMAGE_SHAPE)
    def read_magnitude(self,path:Path)->np.ndarray:
        expected=IMAGE_SHAPE[0]*IMAGE_SHAPE[1]
        self._validate_exact_raw_size(path,'<u2',expected,'Magnitude')
        data=np.fromfile(path,dtype='<u2',count=expected)
        if data.size!=expected: raise RawDecodeError(f'Magnitude RAW read returned {data.size} values; expected {expected}.')
        return data.reshape(IMAGE_SHAPE).astype(np.float32)
    @staticmethod
    def normalize_index(replay_index:int,replay_count:int,series_count:int)->int:
        if series_count<=1 or replay_count<=1: return 0
        return min(series_count-1,round(replay_index*(series_count-1)/(replay_count-1)))
