from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import math
import re
import xml.etree.ElementTree as ET
from datetime import datetime


@dataclass(frozen=True, slots=True)
class MovementDetectionRecord:
    sonication_number: int
    rl: float
    si: float
    ap: float
    source: Path

    @property
    def display(self) -> str:
        return format_movement_detection(self.rl, self.si, self.ap)


def _axis_token(value: float, positive: str, negative: str) -> str:
    # The workstation presentation uses direction letters plus magnitude.
    # Keep one decimal place, including 0.0, for stable Summary alignment.
    direction = positive if value >= 0.0 else negative
    return f"{direction}{abs(float(value)):.1f}"


def format_movement_detection(rl: float, si: float, ap: float) -> str:
    """Format three anatomical displacement components.

    Display order follows the workstation Summary convention requested for Soni:
    RL, SI, AP -> ``R0.1 S0.2 A0.0``. Positive directions are R/S/A and
    negative directions are L/I/P. Zero uses the positive-side letter.
    """
    return " ".join((
        _axis_token(rl, "R", "L"),
        _axis_token(si, "S", "I"),
        _axis_token(ap, "A", "P"),
    ))


class MovementDetectionService:
    """Read authoritative three-axis Movement Detection values when exported.

    A scalar ``SpotDoseData.motionvalue`` is *not* enough to reconstruct RL/SI/AP
    and is therefore never split or copied into the three axes.  We accept only
    explicit three-axis evidence associated with a Sonication index.  This keeps
    the Summary fail-closed for exports such as 40108 where ``motionvalue=-1`` and
    the MD reference/current image counts are zero.

    Export revisions have used several names for the same anatomical components,
    so matching is alias-based but value-driven; filename/order based inference is
    intentionally prohibited.
    """

    _FINAL_VECTOR_RE = re.compile(
        r"(?P<h>\d{1,2}):(?P<m>\d{2}):(?P<s>\d{2}):(?P<ms>\d{3}).*?FinalMovementVector\s*=\s*\(\s*"
        r"(?P<x>[+-]?\d+(?:\.\d+)?)\s*,\s*(?P<y>[+-]?\d+(?:\.\d+)?)\s*,\s*(?P<z>[+-]?\d+(?:\.\d+)?)\s*\)",
        re.IGNORECASE,
    )
    _LOG_DATE_RE = re.compile(
        r"(?P<year>20\d{2})[_-](?P<mon>Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[_-](?P<day>\d{1,2})",
        re.IGNORECASE,
    )
    _MAX_PRE_SONICATION_SECONDS = 90.0

    _ALIASES = {
        "rl": (
            "motionrl", "movementrl", "displacementrl", "mddisplacementrl",
            "mdrl", "rlmotion", "rlmovement", "rlvalue", "motionx",
            "movementx", "displacementx", "mddx", "mdx",
        ),
        "si": (
            "motionsi", "movementsi", "displacementsi", "mddisplacementsi",
            "mdsi", "simotion", "simovement", "sivalue", "motionz",
            "movementz", "displacementz", "mddz", "mdz",
        ),
        "ap": (
            "motionap", "movementap", "displacementap", "mddisplacementap",
            "mdap", "apmotion", "apmovement", "apvalue", "motiony",
            "movementy", "displacementy", "mddy", "mdy",
        ),
    }

    _TEXT_TRIPLE = re.compile(
        r"(?i)\b([RL])\s*([+-]?\d+(?:\.\d+)?)\s*[,;/ ]+"
        r"([SI])\s*([+-]?\d+(?:\.\d+)?)\s*[,;/ ]+"
        r"([AP])\s*([+-]?\d+(?:\.\d+)?)\b"
    )

    @staticmethod
    def _finite(raw) -> float | None:
        try:
            value = float(str(raw).strip())
        except (TypeError, ValueError):
            return None
        return value if math.isfinite(value) else None

    @classmethod
    def _get_axis(cls, attrs: dict[str, str], axis: str) -> float | None:
        for name in cls._ALIASES[axis]:
            if name in attrs:
                return cls._finite(attrs[name])
        return None

    @staticmethod
    def _signed(letter: str, magnitude: float, positive: str) -> float:
        mag = abs(float(magnitude))
        return mag if letter.upper() == positive else -mag

    @classmethod
    def _extract_from_attrs(cls, attrs: dict[str, str]) -> tuple[float, float, float] | None:
        # Workstation researchparameters.xml stores the directional motion
        # correction as correctshiftx/y/z and marks validity with bcorrectshift.
        # X/Y/Z are workstation patient axes: X=RL, Y=AP, Z=SI.  A row with
        # bcorrectshift=0 is not a measured Movement Detection result even when
        # the numeric fields happen to contain zeros.
        if all(name in attrs for name in ("correctshiftx", "correctshifty", "correctshiftz")):
            valid_raw = str(attrs.get("bcorrectshift", "")).strip().lower()
            valid = valid_raw in {"1", "true", "yes", "y"}
            if not valid:
                return None
            x = cls._finite(attrs.get("correctshiftx"))
            y = cls._finite(attrs.get("correctshifty"))
            z = cls._finite(attrs.get("correctshiftz"))
            if x is not None and y is not None and z is not None:
                return x, z, y  # RL, SI, AP

        rl = cls._get_axis(attrs, "rl")
        si = cls._get_axis(attrs, "si")
        ap = cls._get_axis(attrs, "ap")
        if rl is not None and si is not None and ap is not None:
            return rl, si, ap

        # Some exports serialize the already-labelled three-axis result into one
        # text attribute. Parse only when all three anatomical direction letters
        # are present; never reinterpret a lone scalar motionvalue.
        for raw in attrs.values():
            m = cls._TEXT_TRIPLE.search(str(raw))
            if not m:
                continue
            rl = cls._signed(m.group(1), float(m.group(2)), "R")
            si = cls._signed(m.group(3), float(m.group(4)), "S")
            ap = cls._signed(m.group(5), float(m.group(6)), "A")
            return rl, si, ap
        return None

    @staticmethod
    def _summary_sonication_times(workspace: Path) -> dict[int, datetime]:
        out: dict[int, datetime] = {}
        for path in sorted(Path(workspace).rglob("SonicationSummary.xml")):
            try:
                root = ET.parse(path).getroot()
            except (ET.ParseError, OSError):
                continue
            for elem in root.iter():
                attrs = {str(k).lower(): str(v).strip() for k, v in elem.attrib.items()}
                raw_n = attrs.get("sonicationindex")
                raw_t = attrs.get("sontime")
                if not raw_n or not raw_t:
                    continue
                try:
                    n = int(raw_n)
                    dt = datetime.strptime(raw_t[:14], "%Y%m%d%H%M%S")
                except (TypeError, ValueError):
                    continue
                if n > 0:
                    out[n] = dt
            if out:
                break
        return out

    @classmethod
    def _log_file_date(cls, path: Path, fallback: datetime | None = None) -> datetime | None:
        m = cls._LOG_DATE_RE.search(path.name)
        if m:
            try:
                return datetime.strptime(
                    f"{m.group('year')}-{m.group('mon')}-{m.group('day')}", "%Y-%b-%d"
                )
            except ValueError:
                pass
        return fallback.replace(hour=0, minute=0, second=0, microsecond=0) if fallback else None

    @classmethod
    def _read_ws_vectors(cls, workspace: Path, summary_times: dict[int, datetime]) -> list[tuple[datetime, tuple[float, float, float], Path]]:
        if not summary_times:
            return []
        treatment_day = min(summary_times.values())
        candidates: list[Path] = []
        for path in Path(workspace).rglob("*"):
            if not path.is_file() or path.suffix.lower() not in {".log", ".txt"}:
                continue
            # Prefer current-treatment WS logs, but content validation below remains authoritative.
            if cls._LOG_DATE_RE.search(path.name):
                candidates.append(path)
        events: list[tuple[datetime, tuple[float, float, float], Path]] = []
        for path in candidates:
            day = cls._log_file_date(path, treatment_day)
            if day is None or day.date() != treatment_day.date():
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            if "FinalMovementVector" not in text:
                continue
            for m in cls._FINAL_VECTOR_RE.finditer(text):
                try:
                    event_dt = day.replace(
                        hour=int(m.group("h")), minute=int(m.group("m")), second=int(m.group("s")),
                        microsecond=int(m.group("ms")) * 1000,
                    )
                    x, y, z = (float(m.group("x")), float(m.group("y")), float(m.group("z")))
                except (TypeError, ValueError):
                    continue
                if not all(math.isfinite(v) for v in (x, y, z)):
                    continue
                # Workstation logs explicitly label this vector RAS: X=RL, Y=AP, Z=SI.
                events.append((event_dt, (x, z, y), path))
        events.sort(key=lambda row: row[0])
        return events

    @classmethod
    def _map_ws_vectors_to_sonications(
        cls, summary_times: dict[int, datetime],
        events: list[tuple[datetime, tuple[float, float, float], Path]],
    ) -> dict[int, MovementDetectionRecord]:
        out: dict[int, MovementDetectionRecord] = {}
        used: set[int] = set()
        for number, son_dt in sorted(summary_times.items(), key=lambda row: row[1]):
            best_i = None
            best_delta = None
            for i, (event_dt, _triple, _path) in enumerate(events):
                if i in used or event_dt > son_dt:
                    continue
                delta = (son_dt - event_dt).total_seconds()
                if delta < 0 or delta > cls._MAX_PRE_SONICATION_SECONDS:
                    continue
                if best_delta is None or delta < best_delta:
                    best_i, best_delta = i, delta
            if best_i is None:
                continue
            used.add(best_i)
            _event_dt, (rl, si, ap), source = events[best_i]
            out[number] = MovementDetectionRecord(number, rl, si, ap, source)
        return out

    def _read_explicit_xml_indexed(self, workspace: Path) -> dict[int, MovementDetectionRecord]:
        workspace = Path(workspace)
        candidates = sorted(
            (p for p in workspace.rglob("*.xml") if p.is_file()),
            key=lambda p: (len(p.relative_to(workspace).parts), str(p).lower()),
        )
        values: dict[int, list[tuple[tuple[float, float, float], Path]]] = {}
        for path in candidates:
            try:
                root = ET.parse(path).getroot()
            except (ET.ParseError, OSError):
                continue
            for elem in root.iter():
                attrs = {str(k).lower(): str(v) for k, v in elem.attrib.items()}
                if "sonicationindex" not in attrs:
                    continue
                try:
                    number = int(str(attrs["sonicationindex"]).strip())
                except (TypeError, ValueError):
                    continue
                if number <= 0:
                    continue
                triple = self._extract_from_attrs(attrs)
                if triple is None:
                    continue
                values.setdefault(number, []).append((triple, path))

        out: dict[int, MovementDetectionRecord] = {}
        for number, rows in values.items():
            unique: dict[tuple[float, float, float], Path] = {}
            for triple, path in rows:
                key = tuple(round(float(v), 9) for v in triple)
                unique.setdefault(key, path)
            if len(unique) != 1:
                continue
            (rl, si, ap), source = next(iter(unique.items()))
            out[number] = MovementDetectionRecord(number, rl, si, ap, source)
        return out

    def read_indexed(self, workspace: Path) -> dict[int, MovementDetectionRecord]:
        """Return per-Sonication Movement Detection measurements.

        Primary evidence is the treatment-day WS ``FinalMovementVector`` (RAS)
        measured immediately before a Sonication.  The event is bound to the next
        Sonication by ``SonicationSummary.sontime`` within a strict 90-second
        pre-sonication window.  Explicit indexed three-axis XML is retained only
        as a fallback for export revisions that do not include the WS vector log.
        """
        workspace = Path(workspace)
        summary_times = self._summary_sonication_times(workspace)
        ws = self._map_ws_vectors_to_sonications(
            summary_times, self._read_ws_vectors(workspace, summary_times)
        )
        if ws:
            return ws
        return self._read_explicit_xml_indexed(workspace)

