from __future__ import annotations

import shutil
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

from src.services.zip_password_service import ZipPasswordService


class ImportService:
    """Open treatment folders or ZIP packages in an isolated workspace."""

    def __init__(self, zip_password_service: ZipPasswordService | None = None) -> None:
        self.temp_dirs: list[Path] = []
        self.zip_passwords = zip_password_service or ZipPasswordService()
        self.last_import_report: dict = {}

    @staticmethod
    def _validate_member(name: str) -> None:
        normalized = name.replace("\\", "/")
        member = PurePosixPath(normalized)
        if member.is_absolute() or ".." in member.parts:
            raise ValueError(f"Unsafe ZIP entry rejected: {name}")
        if member.parts and ":" in member.parts[0]:
            raise ValueError(f"Unsafe ZIP entry rejected: {name}")

    @staticmethod
    def _is_encrypted(infos: list) -> bool:
        # Bit 0 of the general-purpose flag marks the entry as encrypted
        # (ZIP APPNOTE 4.4.4). Any encrypted member means the archive needs
        # a password before extraction can proceed.
        return any(bool(info.flag_bits & 0x1) for info in infos)

    @staticmethod
    def _is_aes_encrypted(infos: list) -> bool:
        # WinZip-style AE-x (AES) entries store compress_type == 99; the real
        # compression method and AES key size live in the 0x9901 extra field
        # instead. This is a different signal from the general "encrypted"
        # flag bit above: it tells us *which* decryptor is needed, since
        # stdlib zipfile can only ever decrypt traditional ZipCrypto.
        return any(getattr(info, "compress_type", None) == 99 for info in infos)

    def _extract_all(self, archive: zipfile.ZipFile, infos: list, temp: Path, progress_callback, pwd: bytes | None) -> None:
        total = max(1, len(infos))
        for index, info in enumerate(infos):
            archive.extract(info, temp, pwd=pwd)
            if progress_callback and (index % max(1, total // 80) == 0 or index == total - 1):
                value = 5 + int(65 * (index + 1) / total)
                progress_callback(value, f"Extracting files... {index+1}/{total}")

    @staticmethod
    def _clear_dir(path: Path) -> None:
        for child in path.iterdir():
            if child.is_dir():
                shutil.rmtree(child, ignore_errors=True)
            else:
                child.unlink(missing_ok=True)

    def _extract_password_protected(self, archive: zipfile.ZipFile, infos: list, temp: Path, progress_callback) -> None:
        """Try every configured candidate password in order.

        Each attempt starts from an empty temp directory so a wrong
        password's partial/garbage output never mixes with the next
        attempt's files. Stops (raises) the moment it is clear no
        configured password will work, per spec: never guess beyond the
        configured list.
        """
        candidates = self.zip_passwords.get_passwords()
        if not candidates:
            raise PermissionError(
                "This ZIP is password-protected, and no ZIP password is configured. "
                "Add one in ZIP password settings, then try again."
            )
        unsupported_encryption = False
        for candidate in candidates:
            self._clear_dir(temp)
            try:
                self._extract_all(archive, infos, temp, progress_callback, pwd=candidate.encode("utf-8"))
                return
            except NotImplementedError:
                # Strong (e.g. WinZip AES) encryption: Python's stdlib zipfile
                # cannot decrypt this regardless of which password is correct.
                # No candidate password will ever succeed; stop trying more of
                # them, but still report the outcome after the loop so the
                # message explains *why*, not just "failed".
                # NOTE: NotImplementedError is a RuntimeError subclass, so this
                # clause MUST be checked before the plain RuntimeError one below
                # -- Python tries except clauses in source order, and the wider
                # RuntimeError branch would otherwise swallow it first and
                # mis-report it as "wrong password".
                unsupported_encryption = True
                break
            except RuntimeError as exc:
                # Wrong password for standard ZipCrypto: zipfile raises RuntimeError
                # with a message naming the bad password/file. Try the next candidate.
                if "password" in str(exc).lower():
                    continue
                raise
            except zipfile.BadZipFile:
                # Decompressed but failed its CRC check: also a wrong-password
                # signal for ZipCrypto-protected members with compressed data.
                continue
        self._clear_dir(temp)
        if unsupported_encryption:
            raise PermissionError(
                "This ZIP uses an encryption method this app cannot decrypt "
                "(e.g. AES). Ask the sender for a standard password-protected ZIP."
            )
        raise PermissionError(
            "This ZIP is password-protected and no configured ZIP password could open it. "
            "Extraction stopped; add the correct password in ZIP password settings and try again."
        )

    def _extract_aes_password_protected(self, source: Path, infos: list, temp: Path, progress_callback) -> None:
        """Try every configured candidate password against an AES (WinZip
        AE-x) protected archive using the optional 'pyzipper' package.

        Kept as a fully separate code path from _extract_password_protected:
        stdlib zipfile cannot decrypt AES at all, so this never touches the
        already-covered ZipCrypto behavior above. A mixed archive (some
        members ZipCrypto, some AES) is still handled correctly here, since
        pyzipper.AESZipFile reads both formats.
        """
        try:
            import pyzipper
        except ImportError as exc:
            raise PermissionError(
                "This ZIP uses AES encryption, which requires the optional "
                "'pyzipper' package (listed in requirements.txt). Install it "
                "(pip install pyzipper) and try again."
            ) from exc

        candidates = self.zip_passwords.get_passwords()
        if not candidates:
            raise PermissionError(
                "This ZIP is password-protected (AES), and no ZIP password is "
                "configured. Add one in ZIP password settings, then try again."
            )
        # Exact exception types for "wrong password" vary a little across
        # pyzipper versions; treat any of these as "try the next candidate"
        # rather than a hard stop. Anything else (disk full, corrupt archive,
        # etc.) still propagates immediately instead of being misreported as
        # a password problem.
        bad_password_types = tuple(
            t for t in (
                getattr(pyzipper, "BadPasswordError", None),
                zipfile.BadZipFile,
                RuntimeError,
            ) if t is not None
        )
        last_error: Exception | None = None
        for candidate in candidates:
            self._clear_dir(temp)
            try:
                with pyzipper.AESZipFile(source) as archive:
                    archive.setpassword(candidate.encode("utf-8"))
                    total = max(1, len(infos))
                    for index, info in enumerate(archive.infolist()):
                        archive.extract(info, temp)
                        if progress_callback and (index % max(1, total // 80) == 0 or index == total - 1):
                            value = 5 + int(65 * (index + 1) / total)
                            progress_callback(value, f"Extracting files... {index+1}/{total}")
                return
            except bad_password_types as exc:
                last_error = exc
                continue
        self._clear_dir(temp)
        detail = f" (last error: {type(last_error).__name__}: {last_error})" if last_error is not None else ""
        raise PermissionError(
            "This ZIP is password-protected (AES) and no configured ZIP password "
            "could open it. Extraction stopped; add the correct password in ZIP "
            f"password settings and try again.{detail}"
        )


    def _extract_nested_archive(self, source: Path, target: Path) -> int:
        """Extract one nested archive with the same security/password contract.

        The original nested ZIP is retained as evidence; expansion goes into a
        sibling ``<stem>__expanded`` directory so files never overwrite members
        from the outer export.
        """
        target.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(source) as archive:
            infos = archive.infolist()
            for info in infos:
                self._validate_member(info.filename)
            if self._is_encrypted(infos):
                if self._is_aes_encrypted(infos):
                    self._extract_aes_password_protected(source, infos, target, None)
                else:
                    self._extract_password_protected(archive, infos, target, None)
            else:
                self._extract_all(archive, infos, target, None, pwd=None)
        return len(infos)

    def _expand_nested_archives(self, workspace: Path, progress_callback=None, max_depth: int = 5) -> dict:
        """Recursively materialize ZIPs found inside an Export.

        FUS exports may carry evidence inside nested packages.  Older import code
        extracted only the outer ZIP, so discovery silently differed from direct
        folder/file workflows.  R0139 expands every readable nested ZIP while
        preserving the archive itself and fails explicitly when a nested package
        cannot be materialized.
        """
        queue: list[tuple[Path, int]] = [
            (p, 1) for p in sorted(workspace.rglob("*.zip"), key=lambda x: str(x).lower()) if p.is_file()
        ]
        seen: set[Path] = set()
        expanded = 0
        members = 0
        max_seen_depth = 0
        while queue:
            archive_path, depth = queue.pop(0)
            max_seen_depth = max(max_seen_depth, depth)
            key = archive_path.resolve()
            if key in seen:
                continue
            seen.add(key)
            if depth > max_depth:
                raise RuntimeError(
                    f"Nested ZIP depth exceeds supported completeness limit ({max_depth}): {archive_path}"
                )
            target = archive_path.with_name(archive_path.stem + "__expanded")
            try:
                count = self._extract_nested_archive(archive_path, target)
            except zipfile.BadZipFile:
                # A file named .zip that is not actually a ZIP is evidence, not a
                # container. Keep it untouched and do not misclassify it as data loss.
                if target.exists():
                    shutil.rmtree(target, ignore_errors=True)
                continue
            except Exception as exc:
                if target.exists():
                    shutil.rmtree(target, ignore_errors=True)
                raise RuntimeError(
                    f"Nested ZIP could not be completely extracted: {archive_path.name}: "
                    f"{type(exc).__name__}: {exc}"
                ) from exc
            expanded += 1
            members += count
            if progress_callback:
                progress_callback(71, f"Expanding nested evidence ZIPs... {expanded}")
            for child in sorted(target.rglob("*.zip"), key=lambda x: str(x).lower()):
                if child.is_file():
                    queue.append((child, depth + 1))
        return {
            "nested_zip_count": expanded,
            "nested_member_count": members,
            "nested_max_depth": max_seen_depth if expanded else 0,
        }

    def open(self, source: Path, progress_callback=None) -> Path:
        source = source.expanduser().resolve()
        if source.is_dir():
            nested_archives = [p for p in source.rglob("*.zip") if p.is_file()]
            if not nested_archives:
                if progress_callback: progress_callback(70, "Using selected folder...")
                self.last_import_report = {
                    "source": str(source),
                    "outer_member_count": None,
                    "nested_zip_count": 0,
                    "nested_member_count": 0,
                    "workspace_file_count": sum(1 for p in source.rglob("*") if p.is_file()),
                    "folder_overlay": False,
                }
                return source

            # R0141 parity contract: a folder containing nested evidence ZIPs must
            # produce the same discovery universe as dropping the equivalent outer
            # ZIP. Never expand into the user's selected folder; build an isolated
            # copy and materialize nested evidence there.
            temp = Path(tempfile.mkdtemp(prefix="SonicationReplay_Folder_"))
            try:
                if progress_callback:
                    progress_callback(15, "Preparing isolated folder workspace...")
                shutil.copytree(source, temp, dirs_exist_ok=True)
                nested_report = self._expand_nested_archives(temp, progress_callback=progress_callback)
            except Exception:
                shutil.rmtree(temp, ignore_errors=True)
                raise
            self.temp_dirs.append(temp)
            self.last_import_report = {
                "source": str(source),
                "outer_member_count": None,
                **nested_report,
                "workspace_file_count": sum(1 for p in temp.rglob("*") if p.is_file()),
                "folder_overlay": True,
            }
            return temp
        if not source.is_file():
            raise FileNotFoundError(f"Source not found: {source}")
        if source.suffix.lower() != ".zip":
            raise ValueError("Select a ZIP file or folder.")

        temp = Path(tempfile.mkdtemp(prefix="SonicationReplay_"))
        try:
            with zipfile.ZipFile(source) as archive:
                # Do not call ZipFile.testzip() here.  extract() reads each member
                # and validates its CRC, so testzip() would decompress the complete
                # Export a second time before extraction.
                infos = archive.infolist()
                for info in infos:
                    self._validate_member(info.filename)
                if self._is_encrypted(infos):
                    if self._is_aes_encrypted(infos):
                        self._extract_aes_password_protected(source, infos, temp, progress_callback)
                    else:
                        self._extract_password_protected(archive, infos, temp, progress_callback)
                else:
                    self._extract_all(archive, infos, temp, progress_callback, pwd=None)
        except Exception:
            shutil.rmtree(temp, ignore_errors=True)
            raise

        try:
            nested_report = self._expand_nested_archives(temp, progress_callback=progress_callback)
        except Exception:
            shutil.rmtree(temp, ignore_errors=True)
            raise
        self.last_import_report = {
            "source": str(source),
            "outer_member_count": len(infos),
            **nested_report,
            "workspace_file_count": sum(1 for p in temp.rglob("*") if p.is_file()),
        }
        self.temp_dirs.append(temp)
        return temp

    def release(self, workspace: Path | None) -> None:
        if workspace is None:
            return
        resolved = workspace.resolve()
        for temp in list(self.temp_dirs):
            if temp.resolve() == resolved:
                shutil.rmtree(temp, ignore_errors=True)
                self.temp_dirs.remove(temp)

    def cleanup(self) -> None:
        for path in self.temp_dirs:
            shutil.rmtree(path, ignore_errors=True)
        self.temp_dirs.clear()
