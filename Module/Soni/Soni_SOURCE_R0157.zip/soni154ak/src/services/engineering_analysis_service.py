from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import math
import re

import numpy as np

from src.core.fus_export_core import decode_spectrum_structure, RAW_RE
from src.services.raw_service import RawService, RawDecodeError
from src.services.skull_measures_service import SkullMeasuresService


_ACT_ELEMENT_RE = re.compile(
    r"^Element(?P<index>\d+)\s*=\s*(?P<amplitude>[-+0-9.eE]+)\s+[\t ]*(?P<phase>[-+0-9.eE]+)",
    re.I,
)
_ACT_COUNT_RE = re.compile(r"NumberOfElements\s*=\s*(\d+)", re.I)


@dataclass(slots=True)
class Metric:
    name: str
    value: str
    source: str
    confidence: str = "High"
    note: str = ""


@dataclass(slots=True)
class DependencyNode:
    feature: str
    state: str
    depends_on: str
    source: str
    impact: str


@dataclass(slots=True)
class EngineeringAnalysis:
    metrics: list[Metric] = field(default_factory=list)
    dependencies: list[DependencyNode] = field(default_factory=list)
    act_rows: list[tuple[str, str, str]] = field(default_factory=list)
    skull_rows: list[tuple[str, str, str]] = field(default_factory=list)
    spectrum_rows: list[tuple[str, str, str]] = field(default_factory=list)
    thermometry_rows: list[tuple[str, str, str]] = field(default_factory=list)


class EngineeringAnalysisService:
    """Evidence-first engineering analysis over one discovered Sonication.

    This service never invents missing streams. It calculates only metrics that
    can be derived from the Export files and explicitly reports the source and
    confidence so the UI can distinguish Workstation data from interpretation.
    """

    def __init__(self) -> None:
        self.raw = RawService()
        self.skull = SkullMeasuresService()

    @staticmethod
    def _fmt(value: float | None, suffix: str = "", digits: int = 3) -> str:
        if value is None or not math.isfinite(float(value)):
            return "Unavailable"
        return f"{float(value):.{digits}f}{suffix}"

    def _parse_act(self, path: Path) -> tuple[int | None, np.ndarray, np.ndarray]:
        text = path.read_text(encoding="utf-8", errors="replace")
        declared = None
        m = _ACT_COUNT_RE.search(text)
        if m:
            declared = int(m.group(1))
        amp, phase = [], []
        for line in text.splitlines():
            m = _ACT_ELEMENT_RE.match(line.strip())
            if not m:
                continue
            amp.append(float(m.group("amplitude")))
            phase.append(float(m.group("phase")))
        return declared, np.asarray(amp, dtype=float), np.asarray(phase, dtype=float)

    def _act_analysis(self, son) -> tuple[list[Metric], list[tuple[str, str, str]]]:
        if not getattr(son, "act_files", None):
            return [], [("ACT", "Unavailable", "No ACT file")]
        path = Path(son.act_files[0])
        try:
            declared, amp, phase = self._parse_act(path)
        except Exception as exc:
            return [], [("ACT", "Parse error", str(exc))]
        if amp.size == 0:
            return [], [("ACT", "No elements", path.name)]
        on = amp > 1e-9
        active = int(np.count_nonzero(on))
        total = int(amp.size)
        phase_on = phase[on] if np.any(on) else phase
        amp_on = amp[on] if np.any(on) else amp
        metrics = [
            Metric("ACT elements", str(total), path.name, note=f"Declared={declared if declared is not None else '-'}"),
            Metric("Active elements", str(active), path.name),
            Metric("Disabled elements", str(total-active), path.name),
            Metric("Active aperture", f"{active/total*100.0:.1f}%", path.name),
            Metric("Amplitude mean (active)", f"{float(np.mean(amp_on)):.6f}", path.name),
            Metric("Amplitude range (active)", f"{float(np.min(amp_on)):.6f} .. {float(np.max(amp_on)):.6f}", path.name),
            Metric("Phase range", f"{float(np.min(phase_on)):.6f} .. {float(np.max(phase_on)):.6f} rad", path.name),
            Metric("Phase RMS (active)", f"{float(np.sqrt(np.mean(np.square(phase_on)))):.6f} rad", path.name),
        ]
        rows = [
            ("Elements", str(total), f"Declared {declared if declared is not None else 'unknown'}"),
            ("Active / Off", f"{active} / {total-active}", "Amplitude > 0 defines active in ACT"),
            ("Amplitude active mean", f"{float(np.mean(amp_on)):.6f}", path.name),
            ("Amplitude active median", f"{float(np.median(amp_on)):.6f}", path.name),
            ("Phase active min/max", f"{float(np.min(phase_on)):.6f} / {float(np.max(phase_on)):.6f} rad", path.name),
        ]
        return metrics, rows

    def _skull_analysis(self, son, workspace: Path, sonication_number: int) -> tuple[list[Metric], list[tuple[str, str, str]]]:
        data = self.skull.find_and_read(son.folder, sonication_number, workspace)
        if data.error or not data.elements:
            return [], [("SkullMeasures", "Unavailable", data.error or "No rows")]
        enabled = [e for e in data.elements if e.enabled]
        source = data.source.name if data.source else "SkullMeasures"
        metrics: list[Metric] = [
            Metric("SkullMeasures elements", str(len(data.elements)), source),
            Metric("Geometrically enabled elements", str(len(enabled)), source),
            Metric("Skull path rejected", str(len(data.elements)-len(enabled)), source),
        ]
        rows: list[tuple[str, str, str]] = []
        for label in ("Element SDR", "Skull Thickness", "Average Skull Velocity", "Outer Angle", "Inner Angle", "Ray Shift"):
            vals = np.asarray([e.values.get(label, np.nan) for e in enabled], dtype=float)
            vals = vals[np.isfinite(vals)]
            if vals.size == 0:
                continue
            unit = ""
            if label == "Skull Thickness" or label == "Ray Shift": unit = " mm"
            elif "Velocity" in label: unit = " m/s"
            elif "Angle" in label: unit = "°"
            value = f"mean {np.mean(vals):.3f}{unit}; median {np.median(vals):.3f}{unit}; range {np.min(vals):.3f}..{np.max(vals):.3f}{unit}"
            metrics.append(Metric(label, value, source))
            rows.append((label, value, f"n={vals.size}"))
        reasons: dict[int, int] = {}
        for e in data.elements:
            if not e.enabled:
                reasons[e.failure_reason] = reasons.get(e.failure_reason, 0) + 1
        rows.append(("Failure reason counts", ", ".join(f"{k}:{v}" for k,v in sorted(reasons.items())) or "None", source))
        return metrics, rows

    def _thermometry_analysis(self, son) -> tuple[list[Metric], list[tuple[str, str, str]]]:
        metrics: list[Metric] = []
        rows: list[tuple[str, str, str]] = []
        temp_frames = getattr(son, "temperature_frames", [])
        mag_frames = getattr(son, "magnitude_frames", [])
        rows.append(("Magnitude / Temperature frames", f"{len(mag_frames)} / {len(temp_frames)}", "Export Field 6 / 5"))

        field_paths: dict[int, Path] = {}
        for path in list(getattr(son, "other_files", [])):
            m = RAW_RE.match(path.name)
            if m:
                field_paths.setdefault(int(m.group("field")), Path(path))
        mask33 = mask23 = None
        try:
            p33 = field_paths.get(33)
            if p33 and p33.stat().st_size == 256*256:
                mask33 = np.fromfile(p33, dtype=np.uint8).reshape(256,256) > 0
        except Exception:
            mask33 = None
        try:
            p23 = field_paths.get(23)
            if p23 and p23.stat().st_size == 256*256*8:
                mask23 = np.fromfile(p23, dtype='<f8').reshape(256,256) > 0.5
        except Exception:
            mask23 = None

        if not temp_frames:
            return metrics, rows
        frame_max: list[float] = []
        frame_mean: list[float] = []
        masked33_peaks: list[float] = []
        quality_peaks: list[float] = []
        baseline = None
        for i, frame in enumerate(temp_frames):
            try:
                arr = self.raw.read_temperature(frame.path)
            except (OSError, RawDecodeError, ValueError):
                continue
            finite_mask = np.isfinite(arr)
            finite = arr[finite_mask]
            if finite.size == 0:
                continue
            if i == 0:
                baseline = float(np.median(finite))
            frame_max.append(float(np.nanmax(finite)))
            frame_mean.append(float(np.nanmean(finite)))
            if mask33 is not None:
                values = arr[finite_mask & mask33]
                if values.size:
                    masked33_peaks.append(float(np.nanmax(values)))
            if mask33 is not None and mask23 is not None:
                values = arr[finite_mask & mask33 & mask23]
                if values.size:
                    quality_peaks.append(float(np.nanmax(values)))
        if not frame_max:
            return metrics, rows
        peak = float(np.nanmax(frame_max)); peak_index = int(np.nanargmax(frame_max))
        metrics.extend([
            Metric("Thermometry frames", str(len(temp_frames)), "Field 5"),
            Metric("Thermometry baseline", self._fmt(baseline, " °C", 2), "Field 5 frame 0"),
            Metric("Global raw peak temperature", self._fmt(peak, " °C", 2), f"Field 5 frame {peak_index}", confidence="Medium", note="Unmasked raw maximum; may include invalid pixels"),
        ])
        rows.extend([
            ("Baseline median", self._fmt(baseline, " °C", 2), "Field 5 frame 0"),
            ("Raw global peak", self._fmt(peak, " °C", 2), f"Frame {peak_index}; may include invalid pixels"),
            ("Mean temperature range", f"{min(frame_mean):.2f} .. {max(frame_mean):.2f} °C", "Whole 256x256 field; engineering diagnostic"),
        ])
        if masked33_peaks:
            value = float(np.nanmax(masked33_peaks))
            metrics.append(Metric("Background-mask peak temperature", self._fmt(value, " °C", 2), "Field 5 + Field 33", confidence="High", note="Excludes pixels outside the Export background/valid-region mask"))
            rows.append(("Field33 masked peak", self._fmt(value, " °C", 2), "Field 5 ∩ Field 33"))
        if quality_peaks:
            value = float(np.nanmax(quality_peaks))
            metrics.append(Metric("Quality-mask peak temperature", self._fmt(value, " °C", 2), "Field 5 + Field 33 + Field 23", confidence="Medium", note="Uses current evidence-based interpretation of Field 23 as validity/rejection mask"))
            rows.append(("Field33 + Field23 peak", self._fmt(value, " °C", 2), "Field 23 meaning remains evidence-based"))

        for fid in (2,34):
            path = field_paths.get(fid)
            if not path:
                continue
            try:
                data = np.fromfile(path, dtype='<f8')
                finite = data[np.isfinite(data)]
                if finite.size:
                    nonzero = int(np.count_nonzero(np.abs(finite) > 1e-12))
                    rows.append((f"Field {fid} local derived map", f"{nonzero}/{finite.size} nonzero", f"max={float(np.max(finite)):.6g}; {path.name}"))
            except Exception:
                pass
        return metrics, rows

    def _spectrum_analysis(self, son) -> tuple[list[Metric], list[tuple[str, str, str]]]:
        metrics: list[Metric] = []
        rows: list[tuple[str, str, str]] = []
        for path in getattr(son, "spectrum_files", []):
            spec = decode_spectrum_structure(path)
            mode = "Exact" if spec.exact_structure else "Legacy/unknown"
            rows.append((path.name, f"{spec.frame_count} frames; {spec.channel_count} ch container; {spec.frame_size} B/frame", f"{mode}; header={spec.header_size} B"))
            metrics.append(Metric("Spectrum frame structure", f"{spec.frame_count} × {spec.frame_size} B", path.name, confidence="High" if spec.exact_structure else "Low"))
            if spec.channel_count:
                metrics.append(Metric("Spectrum container channels", str(spec.channel_count), path.name, confidence="High" if spec.exact_structure else "Low", note="Container channel count only; payload channel boundaries are not assumed"))
            if spec.frame_period_hint_s is not None:
                metrics.append(Metric("Spectrum frame period hint", f"{spec.frame_period_hint_s:.6f} s", path.name, confidence="Medium", note="Header hint, not a sampling-frequency claim"))
        if not rows:
            rows.append(("SpectrumMsg", "Unavailable", "No SpectrumMsg file"))
        return metrics, rows



    def _skull_heating_analysis(self, son) -> tuple[list[Metric], list[tuple[str, str, str]]]:
        candidates = sorted(Path(son.folder).glob("SkullHeating*.log"))
        if not candidates:
            return [], [("SkullHeating", "Unavailable", "No SkullHeating log")]
        path = candidates[0]
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError as exc:
            return [], [("SkullHeating", "Read error", str(exc))]
        header: dict[str, float | str] = {}
        for line in lines[:10]:
            if not line.lstrip().startswith('%'):
                continue
            for key, value in re.findall(r"([A-Za-z][A-Za-z0-9_]*)\s*[:=]\s*([^\s%]+)", line):
                try: header[key] = float(value)
                except ValueError: header[key] = value
        records=[]
        for line in lines:
            if not line.strip() or not line.strip()[0].isdigit():
                continue
            tokens = re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?", line)
            if len(tokens) < 9:
                continue
            try: vals=[float(x) for x in tokens]
            except ValueError: continue
            records.append(vals)
        if not records:
            return [], [("SkullHeating", "No element rows", path.name)]
        reasons: dict[int,int] = {}
        active=0; avg_power=[]; external=[]; internal=[]
        for vals in records:
            off=int(vals[2])
            reasons[off]=reasons.get(off,0)+1
            if off == -1:
                active += 1
            if len(vals)>4 and math.isfinite(vals[4]): avg_power.append(vals[4])
            if len(vals)>7 and math.isfinite(vals[7]): external.append(vals[7])
            if len(vals)>8 and math.isfinite(vals[8]): internal.append(vals[8])
        names={-1:"Valid",0:"Algorithm",2:"NPR",3:"Manual",4:"Apodization",5:"CPC"}
        breakdown=", ".join(f"{names.get(k,str(k))}={v}" for k,v in sorted(reasons.items()))
        metrics=[
            Metric("SkullHeating active elements", str(active), path.name, confidence="High"),
            Metric("Element off-reason breakdown", breakdown, path.name, confidence="High"),
        ]
        rows=[("Active / total", f"{active} / {len(records)}", path.name), ("Off reasons", breakdown, "SkullHeating OffReason") ]
        if avg_power:
            power_sum=float(np.sum(avg_power))
            metrics.append(Metric("Skull model element AvgPower sum", f"{power_sum:.3f} W", path.name, confidence="High", note="SkullHeating model power; separate from Workstation actual power"))
            rows.append(("Σ element AvgPower", f"{power_sum:.3f} W", "Model distribution"))
        if external:
            value=float(np.max(external)); metrics.append(Metric("Predicted max external skull temperature", f"{value:.3f} °C", path.name, confidence="High")); rows.append(("Max external temperature", f"{value:.3f} °C", "SkullHeating model"))
        if internal:
            value=float(np.max(internal)); metrics.append(Metric("Predicted max internal skull temperature", f"{value:.3f} °C", path.name, confidence="High")); rows.append(("Max internal temperature", f"{value:.3f} °C", "SkullHeating model"))
        for key,label,unit in (("fFrequency","Skull model frequency"," MHz"),("fUserAvgPower","Skull model user AvgPower"," W"),("fPulseDuration","Skull model pulse duration"," s"),("fBathTemp","Bath temperature"," °C")):
            val=header.get(key)
            if isinstance(val,(int,float)):
                metrics.append(Metric(label, f"{float(val):.3f}{unit}", path.name, confidence="High", note="Model/reference value; does not override Workstation Replay Sonication information"))
        return metrics, rows

    def _cross_checks(self, son, workspace: Path, sonication_number: int) -> tuple[list[Metric], list[tuple[str, str, str]]]:
        metrics: list[Metric] = []
        rows: list[tuple[str, str, str]] = []
        if not getattr(son, "act_files", None):
            return metrics, rows
        try:
            _, amp, act_phase = self._parse_act(Path(son.act_files[0]))
        except Exception:
            return metrics, rows
        skull = self.skull.find_and_read(son.folder, sonication_number, workspace)
        if skull.error or not skull.elements or len(skull.elements) != len(act_phase):
            return metrics, rows
        skull_phase = np.asarray([e.values.get("Phase Correction", np.nan) for e in skull.elements], dtype=float)
        valid = np.isfinite(act_phase) & np.isfinite(skull_phase)
        if valid.any():
            diff = np.abs(act_phase[valid] - skull_phase[valid])
            max_diff = float(np.max(diff)); mean_diff = float(np.mean(diff))
            metrics.append(Metric(
                "ACT ↔ Skull phase consistency",
                f"max Δ={max_diff:.6f} rad; mean Δ={mean_diff:.6f} rad",
                "Sonication ACT + SkullMeasures",
                confidence="High",
                note="Cross-source validation of the exported per-element phase correction",
            ))
            rows.append(("ACT vs Skull phase", f"max Δ {max_diff:.6f} rad", f"mean Δ {mean_diff:.6f} rad; n={int(valid.sum())}"))
        act_active = int(np.count_nonzero(amp > 1e-9))
        skull_enabled = int(sum(1 for e in skull.elements if e.enabled))
        metrics.append(Metric(
            "Aperture filtering after skull geometry",
            f"Skull-valid {skull_enabled} → ACT-active {act_active} ({skull_enabled-act_active} additional off)",
            "SkullMeasures + ACT",
            confidence="High",
            note="Additional exclusions can include NPR/CPC/algorithm decisions; reason breakdown requires SkullHeating/off-reason data",
        ))
        rows.append(("Skull-valid → ACT-active", f"{skull_enabled} → {act_active}", f"additional disabled={skull_enabled-act_active}"))
        return metrics, rows

    @staticmethod
    def _dependencies(son) -> list[DependencyNode]:
        caps = getattr(son, "capabilities", {}) or {}
        def state(key: str) -> str:
            c = caps.get(key, {})
            if c.get("available") and c.get("degraded"): return "DEGRADED"
            if c.get("available"): return "AVAILABLE"
            return "MISSING"
        return [
            DependencyNode("Temperature replay", state("thermometry"), "Field 5 + Field 6; Field 23/28/33 enhance validation", "Export RAW", "Temperature overlay disabled only when Field 5/6 are absent"),
            DependencyNode("Dose analysis", state("dose"), "Field 2 / Field 34 + thermometry", "Export RAW", "Dose workspace limited; MR/Spectrum remain usable"),
            DependencyNode("Spectrum analysis", state("spectrum"), "SpectrumMsg + Sonication frequency", "SpectrumMsg / SonicationSummary", "Acoustic analysis unavailable only when SpectrumMsg is absent"),
            DependencyNode("Element analysis", state("elements"), "Sonication*.act", "ACT", "Amplitude/phase/aperture unavailable; replay remains usable"),
            DependencyNode("Skull propagation", state("skull"), "SkullMeasures / SkullHeating", "Skull logs", "SDR/path/heating unavailable independently"),
            DependencyNode("Motion comparison", state("motion"), "Reference 37-39 + Current 40-42", "3Plane-Volume RAW", "Current or reference-only data remain inspectable"),
            DependencyNode("Fusion geometry", state("registration"), "CtMr / MrMr registration", "RGS / matrices / fusregistration.xml", "Images remain viewable without registered fusion"),
            DependencyNode("Planning", state("planning"), "Sonication1 planning fields 7/8/12/16/19/20/21/43/44", "Sonication1 shared assets", "Subsequent Sonications inherit available planning assets"),
        ]

    def analyze(self, son, workspace: Path, sonication_number: int) -> EngineeringAnalysis:
        result = EngineeringAnalysis()
        # Workstation-level values first, because these are authoritative when available.
        source = Path(son.timing_source).name if getattr(son, "timing_source", None) else "Sonication information"
        for name, value, unit, digits in (
            ("Replay frequency", getattr(son, "main_frequency_hz", None), " MHz", 3),
            ("Target power", getattr(son, "planned_power_w", None), " W", 1),
            ("Actual power", getattr(son, "actual_power_w", None), " W", 1),
            ("Target duration", getattr(son, "planned_duration_s", None), " s", 3),
            ("Actual duration", getattr(son, "actual_duration_s", None), " s", 3),
            ("Target energy", getattr(son, "planned_energy_j", None), " J", 1),
            ("Actual energy", getattr(son, "actual_energy_j", None), " J", 1),
        ):
            if value is None:
                continue
            shown = float(value)/1e6 if name == "Replay frequency" else float(value)
            result.metrics.append(Metric(name, f"{shown:.{digits}f}{unit}", source, confidence="High"))
        result.metrics.append(Metric("Replay completeness", f"{son.completeness_status} ({son.completeness_score}%)", "FUS Export Core", confidence="High"))

        for producer in (self._act_analysis,):
            metrics, rows = producer(son)
            result.metrics.extend(metrics); result.act_rows.extend(rows)
        metrics, rows = self._skull_analysis(son, workspace, sonication_number)
        result.metrics.extend(metrics); result.skull_rows.extend(rows)
        metrics, rows = self._skull_heating_analysis(son)
        result.metrics.extend(metrics); result.skull_rows.extend(rows)
        metrics, rows = self._thermometry_analysis(son)
        result.metrics.extend(metrics); result.thermometry_rows.extend(rows)
        metrics, rows = self._spectrum_analysis(son)
        result.metrics.extend(metrics); result.spectrum_rows.extend(rows)
        metrics, rows = self._cross_checks(son, workspace, sonication_number)
        result.metrics.extend(metrics); result.act_rows.extend(rows)
        result.dependencies = self._dependencies(son)
        return result
