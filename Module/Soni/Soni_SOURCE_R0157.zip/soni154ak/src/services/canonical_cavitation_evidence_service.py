from __future__ import annotations

from dataclasses import dataclass
from types import SimpleNamespace
from typing import Iterable
import math


@dataclass(frozen=True)
class CanonicalCavitationEvidence:
    detected: bool | None
    observed_events: tuple
    vendor_rule_events: tuple
    candidate_events: tuple
    status: str
    evidence_complete: bool = True
    unavailable_reason: str | None = None

    @property
    def vendor_exceedance_severity(self) -> float | None:
        """Transparent 0–100 threshold-exceedance score for vendor Rule Triggers.

        score = 100 * (1 - threshold / measured), so a just-crossed threshold is
        near 0, 2× threshold is 50, and stronger exceedance approaches 100.
        This is an engineering evidence score, not a clinical cavitation grade.
        """
        scores=[]
        for ev in self.vendor_rule_events:
            try:
                measured=float(getattr(ev,"energy",float("nan")))
                threshold=float(getattr(ev,"baseline",float("nan")))
                if measured>threshold>0:
                    scores.append(max(0.0,min(100.0,100.0*(1.0-threshold/measured))))
            except Exception:
                continue
        return max(scores) if scores else None

    @staticmethod
    def _response_key(ev):
        """Collapse rule rows that caused one physical controller response.

        Acquisition_Brain can emit several Decrease/Safety rule rows at the same
        cycle and all are attached to the same subsequent ExPowerRatio change.
        Those are evidence rows, not multiple independent cavitation events.
        """
        cycle=getattr(ev,"cycle",None)
        if cycle is not None:
            try: return ("cycle",int(cycle))
            except Exception: pass
        ts=getattr(ev,"timestamp_s",None)
        if ts is not None:
            try:
                value=float(ts)
                if math.isfinite(value): return ("time",round(value,4))
            except Exception: pass
        before=getattr(ev,"before_power_ratio",None); after=getattr(ev,"after_power_ratio",None)
        try:
            return ("power",round(float(before),4),round(float(after),4))
        except Exception:
            return ("row",id(ev))

    @property
    def observed_response_count(self) -> int:
        return len({self._response_key(ev) for ev in self.observed_events})

    @property
    def decrease_response_count(self) -> int:
        return len({self._response_key(ev) for ev in self.observed_events if str(getattr(ev,"family","")).lower()=="decrease"})

    @property
    def safety_response_count(self) -> int:
        return len({self._response_key(ev) for ev in self.observed_events if str(getattr(ev,"family","")).lower()=="safety"})

    @property
    def halt_count(self) -> int:
        keys=set()
        for ev in self.observed_events:
            result=str(getattr(ev,"result","") or "").upper()
            after=getattr(ev,"after_power_ratio",None)
            halted="HALT" in result or "STOP" in result
            try: halted=halted or (after is not None and float(after)<=1e-9 and str(getattr(ev,"family","")).lower()=="safety")
            except Exception: pass
            if halted: keys.add(self._response_key(ev))
        return len(keys)

    @property
    def rca_events(self) -> tuple:
        """Events admitted to cavitation RCA under the authoritative event gate.

        Cavitation Summary is event-driven: only an observed Decrease or Safety
        control response establishes that a cavitation event occurred. Reproduced
        vendor-rule threshold crossings remain supporting acoustic evidence and must
        never create an RCA event on their own. Once a control event is confirmed,
        vendor-rule rows may still be used by dedicated evidence views, but the
        Summary RCA input itself stays anchored to the observed control response.
        """
        return tuple(self.observed_events)


class CanonicalCavitationEvidenceService:
    """One event contract shared by Replay, CI and Sonication Summary.

    A Cavitation Event/Status exists only when the treatment control path records an
    observed Power Decrease or Safety response. Spectrum/vendor-rule threshold
    crossings and dump-only candidates remain acoustic evidence; they never promote
    Cavitation Status or Cavitation Severity by themselves. Increase is not a
    cavitation event.
    """

    @staticmethod
    def combine(
        timeline_events: Iterable | None = None,
        standalone_analysis=None,
        *,
        timeline_available: bool = True,
        spectrum_available: bool = True,
        unavailable_reason: str | None = None,
    ) -> CanonicalCavitationEvidence:
        observed=[]
        for ev in list(timeline_events or []):
            family=str(getattr(ev,"family","") or "").strip().lower()
            # Authoritative application contract: only an observed Power Decrease
            # or Safety response is a Cavitation Event. Parser flags and acoustic
            # threshold evidence cannot widen this gate.
            if family in {"decrease","safety"}:
                observed.append(ev)

        rule=[]; candidates=[]
        for ev in list(getattr(standalone_analysis,"events",[]) or []):
            severity=str(getattr(ev,"severity","") or "")
            if severity=="Rule Trigger": rule.append(ev)
            elif severity=="Candidate": candidates.append(ev)

        confirmed=bool(observed)
        # Timeline/control evidence is sufficient to decide event status. Spectrum
        # availability only affects supporting evidence completeness, not whether a
        # Decrease/Safety event happened.
        detected = True if confirmed else (False if timeline_available else None)
        complete=bool(timeline_available and spectrum_available)
        if confirmed:
            keys={CanonicalCavitationEvidence._response_key(ev) for ev in observed}
            halt_keys=set()
            for ev in observed:
                result=str(getattr(ev,"result","") or "").upper()
                after=getattr(ev,"after_power_ratio",None)
                halted=("HALT" in result or "STOP" in result)
                try: halted=halted or (after is not None and float(after)<=1e-9 and str(getattr(ev,"family","")).lower()=="safety")
                except Exception: pass
                if halted: halt_keys.add(CanonicalCavitationEvidence._response_key(ev))
            if halt_keys:
                status=f"CAVITATION HALT ×{len(halt_keys)} · control responses ×{len(keys)}"
            else:
                status=f"Observed control cavitation ×{len(keys)}"
        elif timeline_available:
            status="No Power Decrease / Safety event"
        else:
            status="Control evidence unavailable — Needs attention"
        return CanonicalCavitationEvidence(
            detected=detected,
            observed_events=tuple(observed),
            vendor_rule_events=tuple(rule),
            candidate_events=tuple(candidates),
            status=status,
            evidence_complete=complete,
            unavailable_reason=(None if complete else (unavailable_reason or "One or more cavitation evidence sources were unavailable")),
        )
