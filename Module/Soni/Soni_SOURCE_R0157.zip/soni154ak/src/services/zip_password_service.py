from __future__ import annotations

"""Configurable password candidates for opening password-protected ZIP exports.

This intentionally never hardcodes a password as the *only* option: the
built-in value ("clinicalopt") is written once as the initial seed of a
plain, user-editable JSON config file. From then on the file -- not this
module -- is the single source of truth, so a site can add, remove, or
replace passwords later without a code change or new build.

Passwords are stored in plain JSON, matching every other config file this
app already uses (INI/JSON, no secrets store). This is a convenience
mechanism for a known, shared site password, not a security boundary --
anyone with filesystem access to this machine can already read it.
"""

import json
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_SEED_PASSWORDS: tuple[str, ...] = ("clinicalopt",)


@dataclass(slots=True)
class ZipPasswordConfig:
    passwords: list[str] = field(default_factory=list)
    config_path: Path | None = None
    seeded_default: bool = False


class ZipPasswordService:
    """Reads/writes the configurable list of ZIP-open password candidates."""

    def __init__(self, config_path: Path | None = None) -> None:
        self.config_path = config_path or (Path.home() / "SonicationReplayEngine" / "config" / "zip_passwords.json")

    def _read_raw(self) -> dict:
        try:
            return json.loads(self.config_path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _write_raw(self, payload: dict) -> None:
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        self.config_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    def load(self) -> ZipPasswordConfig:
        """Return the current candidate list, seeding the default on first run.

        The default ("clinicalopt") is written into the config file itself
        exactly once. Every later read/write goes through this same file, so
        a site can freely edit, remove, or replace it afterward.
        """
        if not self.config_path.exists():
            seeded = list(DEFAULT_SEED_PASSWORDS)
            self._write_raw({"passwords": seeded})
            return ZipPasswordConfig(passwords=seeded, config_path=self.config_path, seeded_default=True)
        raw = self._read_raw()
        passwords = [str(p) for p in (raw.get("passwords") or []) if str(p)]
        return ZipPasswordConfig(passwords=passwords, config_path=self.config_path, seeded_default=False)

    def get_passwords(self) -> list[str]:
        return self.load().passwords

    def set_passwords(self, passwords: list[str]) -> None:
        cleaned = [str(p) for p in passwords if str(p).strip()]
        self._write_raw({"passwords": cleaned})

    def add_password(self, password: str) -> None:
        password = str(password)
        if not password:
            return
        current = self.get_passwords()
        if password not in current:
            current.append(password)
            self.set_passwords(current)

    def remove_password(self, password: str) -> None:
        current = self.get_passwords()
        remaining = [p for p in current if p != password]
        if remaining != current:
            self.set_passwords(remaining)
