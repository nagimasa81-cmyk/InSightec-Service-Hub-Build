from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import configparser
import re
from datetime import datetime, timedelta

from src.parsers.ado_rowset import parse_ado_rowset


_CLOCK_RE = re.compile(r"^(\d{2}):(\d{2}):(\d{2}):(\d{3})")
_WS_DATE_RE = re.compile(r"(?P<y>\d{4})_(?P<mon>[A-Za-z]{3})_(?P<d>\d{2})_(?P<h>\d{2})_(?P<m>\d{2})_(?P<s>\d{2})", re.I)
_MRSERVER_DATE_RE = re.compile(r"mrserver_[A-Za-z]{3}_(?P<mon>[A-Za-z]{3})_(?P<d>\d{2})_(?P<h>\d{2})_(?P<m>\d{2})_(?P<s>\d{2})_(?P<y>\d{4})", re.I)


@dataclass(slots=True)
class MRTimeline:
    mr_start_s: float = 0.0
    mr_end_s: float = 0.0
    sonication_start_s: float = 0.0
    sonication_end_s: float = 0.0
    frame_interval_s: float | None = None
    source: str = "Unavailable"
    confidence: str = "Unknown"
    evidence: list[str] = field(default_factory=list)
    # Absolute Treatment-WS clock anchors are retained for cross-host clock
    # diagnostics. They are never exposed as the chart X-axis.
    ws_power_on_abs_s: float | None = None
    ws_power_off_abs_s: float | None = None
    mr_scan_start_abs_s: float | None = None
    mr_scan_end_abs_s: float | None = None

    @property
    def duration_s(self) -> float:
        return max(0.0, float(self.mr_end_s) - float(self.mr_start_s))


class MRTimelineService:
    """Build one canonical per-Sonication time base owned by the treatment MR scan.

    Canonical clock:
      MR scanning start = 0 s
      MR scanning end   = timeline end
      acoustic power-on/off are events *inside* that window.

    Preferred evidence is workstation-local logs because MR status and FUS power
    state then share one clock.  CPC clocks are deliberately not used to define
    MR zero; they are mapped later through the Sonication power trajectory.
    """

    def resolve_all(self, workspace: Path, sonications: list[object]) -> list[MRTimeline]:
        workspace = Path(workspace)
        summary_rows = self._summary_rows(workspace)
        summary_by_number: dict[int, dict] = {}
        for fallback, row in enumerate(summary_rows, start=1):
            try:
                number = int(float(row.get("sonicationindex", fallback)))
            except (TypeError, ValueError):
                number = fallback
            summary_by_number[number] = row
        power_windows = self._power_windows(workspace)
        scan_intervals = self._scan_intervals(workspace)
        protocol = self._protocol_parameters(workspace)
        canonical_indices=[]
        for son in sonications:
            try:
                value=getattr(son,"canonical_acquisition_session_index",None)
                if value is not None and int(value) >= 0:
                    canonical_indices.append(int(value))
            except (TypeError,ValueError):
                pass
        canonical_universe_count=(max(canonical_indices)+1) if canonical_indices else 0
        out: list[MRTimeline] = []

        for index, son in enumerate(sonications):
            try:
                sonication_number = int(getattr(son, "sonication_number", 0) or 0)
            except (TypeError, ValueError):
                sonication_number = 0
            if sonication_number <= 0:
                sonication_number = index + 1
            row = summary_by_number.get(sonication_number, {})
            hint = self._summary_clock(row)
            # The Sonication evidence binder already resolves the authoritative
            # Acquisition_Brain session.  Use the same ordinal Workstation power
            # window whenever available so MR, CPC and treatment identity cannot
            # drift independently.
            session_index=getattr(son, "canonical_acquisition_session_index", None)
            try: session_index=int(session_index) if session_index is not None else None
            except (TypeError, ValueError): session_index=None
            # R0151: Acquisition_Brain session ordinals are NOT positional
            # indexes into the union of Workstation power windows.  Historical
            # WS logs can coexist in one Export, so direct indexing can bind a
            # selected Sonication to an older treatment's power-off time.
            # Resolve the WS window independently from the SonicationSummary
            # clock; positional fallback remains allowed only when the universe
            # proves one-to-one inside _select_power_window().
            power = self._select_power_window(
                power_windows, hint, max(0, sonication_number - 1), len(sonications),
                session_index, canonical_universe_count,
            )
            if power is not None:
                on_s, off_s = power
                scan = self._select_scan_interval(scan_intervals, on_s, off_s)
                if scan is not None:
                    scan_start, scan_end = scan
                    start = max(0.0, on_s - scan_start)
                    end = max(start, off_s - scan_start)
                    duration = max(end, scan_end - scan_start)
                    out.append(MRTimeline(
                        0.0, duration, start, min(end, duration),
                        self._protocol_scan_time(row, protocol),
                        "WS + MRServer exact status clocks", "Exact",
                        [
                            f"MR Scanning {self._clock(scan_start)} -> {self._clock(scan_end)}",
                            f"Acoustic power {self._clock(on_s)} -> {self._clock(off_s)}",
                            f"MR-relative acoustic window {start:.3f} -> {end:.3f} s",
                        ],
                        ws_power_on_abs_s=float(on_s), ws_power_off_abs_s=float(off_s),
                        mr_scan_start_abs_s=float(scan_start), mr_scan_end_abs_s=float(scan_end),
                    ))
                    continue

            # Conservative fallback: protocol timing + exported MR frame count.
            scan_time = self._protocol_scan_time(row, protocol)
            pre = self._protocol_pre_frames(row, protocol)
            count = max(1, int(getattr(son, "replay_frame_count", 1) or 1))
            actual = self._number(row.get("actualduration"))
            if scan_time is not None and scan_time > 0:
                # First exported replay position owns t=0.  The complete scanner
                # window spans one acquisition period per replay frame.
                duration = max(float(count) * scan_time, float(max(0, count - 1)) * scan_time)
                acoustic_start = max(0.0, float(pre) * scan_time)
                exact_power_duration = None
                if power is not None:
                    try:
                        candidate=float(power[1])-float(power[0])
                        if 0.0 < candidate <= 300.0:
                            exact_power_duration=candidate
                    except Exception:
                        exact_power_duration=None
                chosen_duration = exact_power_duration if exact_power_duration is not None else max(0.0, float(actual or 0.0))
                acoustic_end = acoustic_start + chosen_duration
                duration = max(duration, acoustic_end)
                if exact_power_duration is not None:
                    source = "WS exact acoustic duration + SVAT protocol + MR RAW count"
                    confidence = "High"
                    evidence = [
                        f"ScanTime={scan_time:.3f}s", f"PreSonicateNum={pre}", f"ReplayFrames={count}",
                        f"WS power window={self._clock(power[0])} -> {self._clock(power[1])}",
                        f"ExactPowerDuration={exact_power_duration:.3f}s",
                        f"SummaryActualDuration={float(actual or 0.0):.3f}s",
                    ]
                else:
                    source = "SVAT protocol + SonicationSummary + MR RAW count"
                    confidence = "Reconstructed"
                    evidence = [f"ScanTime={scan_time:.3f}s", f"PreSonicateNum={pre}", f"ReplayFrames={count}", f"ActualDuration={float(actual or 0.0):.3f}s"]
                out.append(MRTimeline(
                    0.0, duration, acoustic_start, min(acoustic_end, duration), scan_time,
                    source, confidence, evidence,
                ))
            else:
                duration = float(max(0, count - 1))
                acoustic_end = min(duration, max(0.0, float(actual or 0.0)))
                out.append(MRTimeline(0.0, duration, 0.0, acoustic_end, None, "Replay frame order only", "Low", ["MR clock unavailable"]))
        return out

    @staticmethod
    def _seconds(match: re.Match) -> float:
        return int(match.group(1))*3600.0 + int(match.group(2))*60.0 + int(match.group(3)) + int(match.group(4))/1000.0

    @staticmethod
    def _clock(value: float) -> str:
        value=float(value)
        if value > 10_000_000.0:
            try:
                return datetime.fromtimestamp(value).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
            except Exception:
                pass
        value = value % 86400.0
        h = int(value // 3600); value -= h*3600
        m = int(value // 60); value -= m*60
        return f"{h:02d}:{m:02d}:{value:06.3f}"

    @staticmethod
    def _number(value):
        try:
            return float(str(value).strip()) if value is not None else None
        except (TypeError, ValueError):
            return None

    def _summary_rows(self, workspace: Path) -> list[dict]:
        path = next(iter(sorted(workspace.rglob("SonicationSummary.xml"), key=lambda p: len(p.parts))), None)
        if path is None:
            return []
        try:
            rows = list(parse_ado_rowset(path))
        except Exception:
            return []
        def idx(row):
            try: return int(row.get("sonicationindex", 10**9))
            except Exception: return 10**9
        return sorted(rows, key=idx)

    def _summary_clock(self, row: dict) -> float | None:
        """Return an absolute naive-local timestamp when SonicationSummary carries a date.

        R0153: the previous implementation discarded YYYYMMDD and compared only
        wall-clock seconds.  Historical workstation logs from another treatment
        day could therefore win the power-window match if they happened at a
        similar time of day.
        """
        raw = str(row.get("sontime", "") or "").strip()
        m = re.search(r"(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})", raw)
        if not m:
            return None
        try:
            dt=datetime(*(int(m.group(i)) for i in range(1,7)))
        except ValueError:
            return None
        return dt.timestamp()

    @staticmethod
    def _path_date(path: Path) -> datetime | None:
        """Resolve the local calendar date encoded in WS/MRServer filenames."""
        name=path.name
        match=_MRSERVER_DATE_RE.search(name) or _WS_DATE_RE.search(name)
        if match is None:
            return None
        try:
            mon=datetime.strptime(match.group("mon").title(), "%b").month
            return datetime(int(match.group("y")), mon, int(match.group("d")))
        except Exception:
            return None

    @classmethod
    def _line_timestamp(cls, match: re.Match, base_date: datetime | None, previous: float | None = None) -> float:
        tod=cls._seconds(match)
        if base_date is None:
            return tod
        value=(base_date + timedelta(seconds=tod)).timestamp()
        # A log can span midnight.  Keep line timestamps monotonic without
        # manufacturing a rollover for ordinary out-of-order diagnostic lines.
        if previous is not None and value < previous - 12*3600:
            value += 24*3600
        return value

    @staticmethod
    def _is_absolute_clock(value: float | None) -> bool:
        return value is not None and float(value) > 10_000_000.0

    def _ws_logs(self, workspace: Path) -> list[Path]:
        candidates=[]
        for p in workspace.rglob("*"):
            if not p.is_file() or p.suffix.lower() != ".log":
                continue
            low=p.name.lower()
            if "mrserver" in low or "service" in low or "dcm" in low or "src_" in low:
                continue
            # Main workstation logs are normally YYYY_Mmm_DD_HH_MM_SS.Log.
            if re.search(r"\d{4}_[a-z]{3}_\d{2}_\d{2}_\d{2}_\d{2}", low):
                candidates.append(p)
        return sorted(candidates, key=lambda p: p.stat().st_size if p.exists() else 0, reverse=True)

    def _power_windows(self, workspace: Path) -> list[tuple[float,float]]:
        """Return exact WS acoustic windows, retaining calendar identity.

        Dated workstation logs are converted to full local timestamps.  Legacy
        undated logs retain seconds-of-day and are only compared on that basis
        when no dated candidate universe is available.
        """
        out=[]
        for path in self._ws_logs(workspace):
            on=[]; off=[]
            base=self._path_date(path)
            previous=None
            try:
                with path.open("r", errors="ignore") as f:
                    for line in f:
                        m=_CLOCK_RE.match(line)
                        if not m: continue
                        t=self._line_timestamp(m,base,previous)
                        previous=t
                        if "Main status changed from: Sonication to Sonication power on" in line:
                            on.append(t)
                        elif "Main status changed from: Sonication power on to Post sonication" in line:
                            off.append(t)
            except OSError:
                continue
            j=0
            for start in sorted(on):
                while j < len(off) and off[j] < start:
                    j += 1
                if j < len(off):
                    finish=off[j]
                    if 0.0 <= finish-start <= 300.0:
                        out.append((start,finish))
                    j += 1
        return sorted(set(out), key=lambda w:(w[0],w[1]))

    def _mrserver_logs(self, workspace: Path) -> list[Path]:
        return sorted([p for p in workspace.rglob("*") if p.is_file() and "mrserver" in p.name.lower() and p.suffix.lower() in (".log", ".txt")], key=lambda p: p.stat().st_size if p.exists() else 0, reverse=True)

    def _scan_intervals(self, workspace: Path) -> list[tuple[float,float]]:
        """Return every plausible MR Scanning interval with full date identity."""
        out=[]
        start_tokens=(
            "Status changed from Preparing to Scanning.",
            "Status changed from Prepped to Scanning.",
            "Status changed from Prescanning to Scanning.",
            "Status changed from Idle to Scanning.",
        )
        end_tokens=(
            "Status changed from Scanning to Idle.",
            "Status changed from Scanning to Step is open.",
        )
        for path in self._mrserver_logs(workspace):
            starts=[]; ends=[]
            base=self._path_date(path)
            previous=None
            try:
                with path.open("r", errors="ignore") as f:
                    for line in f:
                        m=_CLOCK_RE.match(line)
                        if not m: continue
                        t=self._line_timestamp(m,base,previous)
                        previous=t
                        if any(token in line for token in start_tokens):
                            starts.append(t)
                        elif any(token in line for token in end_tokens):
                            ends.append(t)
            except OSError:
                continue
            for scan_start in starts:
                following=[e for e in ends if scan_start <= e <= scan_start + 600.0]
                if following:
                    out.append((scan_start,min(following)))
        return sorted(set(out), key=lambda x:(x[0],x[1]))

    @classmethod
    def _select_power_window(
        cls, windows: list[tuple[float,float]], hint: float | None, index: int, count: int,
        canonical_index: int | None = None, canonical_universe_count: int = 0,
    ):
        if hint is not None and windows:
            hint_abs=cls._is_absolute_clock(hint)
            dated=[w for w in windows if cls._is_absolute_clock(w[0])]
            undated=[w for w in windows if not cls._is_absolute_clock(w[0])]
            # Never compare a full treatment datetime to another day's window by
            # stripping the date.  If dated evidence exists, only dated windows
            # participate.  Undated legacy evidence is used only when it is the
            # entire available universe.
            candidates=dated if hint_abs and dated else windows
            compare_hint=float(hint)
            if hint_abs and not dated and undated:
                compare_hint=float(hint)%86400.0
                candidates=undated
            ranked=sorted(candidates, key=lambda w: (0 if -5.0 <= w[0]-compare_hint <= 120.0 else 1, abs(w[0]-compare_hint)))
            if ranked and abs(ranked[0][0]-compare_hint) <= 180.0:
                return ranked[0]
        # If SonicationSummary time is absent but the canonical Acquisition_Brain
        # index proves a complete one-to-one session universe, that canonical
        # index is stronger evidence than Sonication list position. This retains
        # legacy exports without reintroducing latest-N guessing.
        if (hint is None and canonical_index is not None and canonical_universe_count > 0
                and len(windows) == canonical_universe_count
                and 0 <= int(canonical_index) < len(windows)):
            return windows[int(canonical_index)]
        # Positional fallback remains valid only for a proven one-to-one universe.
        if len(windows) == count > 0 and 0 <= index < len(windows):
            return windows[index]
        return None

    @classmethod
    def _select_scan_interval(cls, intervals: list[tuple[float,float]], on_s: float, off_s: float):
        same_kind=[x for x in intervals if cls._is_absolute_clock(x[0]) == cls._is_absolute_clock(on_s)]
        if same_kind:
            candidates=same_kind
            compare_on=float(on_s); compare_off=float(off_s)
            project_date=False
        elif cls._is_absolute_clock(on_s) and intervals and all(not cls._is_absolute_clock(x[0]) for x in intervals):
            # Legacy MRServer filenames sometimes carry no date at all. Once a
            # dated WS power window has been selected, compare the undated MR
            # intervals only by time-of-day, then project the winning interval
            # onto that already-proven treatment date. This cannot select an
            # alternate treatment day because the date comes from the WS window.
            candidates=intervals
            compare_on=float(on_s)%86400.0; compare_off=float(off_s)%86400.0
            project_date=True
        else:
            candidates=intervals
            compare_on=float(on_s); compare_off=float(off_s)
            project_date=False
        containing=[x for x in candidates if x[0] <= compare_on <= x[1] and compare_off <= x[1] + 2.0]
        if containing:
            chosen=min(containing, key=lambda x: (x[1]-x[0], abs(compare_on-x[0])))
        else:
            before=[x for x in candidates if 0 <= compare_on-x[0] <= 120.0 and x[1] >= compare_off]
            chosen=min(before, key=lambda x: abs(compare_on-x[0])) if before else None
        if chosen is None or not project_date:
            return chosen
        midnight=datetime.fromtimestamp(float(on_s)).replace(hour=0,minute=0,second=0,microsecond=0).timestamp()
        start=midnight+float(chosen[0]); end=midnight+float(chosen[1])
        if end < start:
            end += 86400.0
        return start,end

    def _protocol_parameters(self, workspace: Path):
        configs=[]
        for p in workspace.rglob("*.ini"):
            low=p.name.lower()
            if "brainsvatprotocol" in low and "siemens" in low:
                configs.append(p)
        for path in sorted(configs, key=lambda p: ("nomultislice" not in p.name.lower(), len(p.parts))):
            cp=configparser.ConfigParser(interpolation=None, strict=False)
            cp.optionxform=str
            try:
                cp.read(path, encoding="utf-8-sig")
                if cp.sections(): return cp
            except Exception:
                continue
        return None

    def _protocol_scan_time(self, row: dict, cp) -> float | None:
        if cp is None: return None
        name=str(row.get("protocol", "") or "").strip()
        if not name or not cp.has_section(name): return None
        for key in ("ScanTime", "scantime"):
            if cp.has_option(name,key):
                return self._number(cp.get(name,key))
        return None

    @staticmethod
    def _resolve_alternative_section(cp, name: str, template: str) -> str:
        """Substitute ``$KeyName`` placeholders in an AlternativeSection
        template with that key's own value from the same section.

        e.g. ``AlternativeSection = PSD@$PSDType`` together with
        ``PSDType = SingleEcho`` in section ``name`` resolves to
        ``"PSD@SingleEcho"``. Without this substitution the literal,
        unresolved template string (containing a bare ``$PSDType``) never
        matches any real section name, so the lookup silently falls through
        to the base section -- which typically doesn't carry
        ``PreSonicateNum`` at all -- and the pre-sonication frame count
        defaults to 0. That made every Sonication start line up with MR
        acquisition start (t=0) instead of the true several-second
        pre-sonication scan delay.
        """
        def replace(match: re.Match) -> str:
            key = match.group(1)
            value = cp.get(name, key, fallback=None)
            return value if value is not None else match.group(0)
        return re.sub(r"\$(\w+)", replace, template)

    def _protocol_pre_frames(self, row: dict, cp) -> int:
        if cp is None: return 0
        name=str(row.get("protocol", "") or "").strip()
        if not name or not cp.has_section(name): return 0
        alt_template=cp.get(name,"AlternativeSection",fallback="").strip()
        alt=self._resolve_alternative_section(cp, name, alt_template) if alt_template else ""
        for section in (alt,name):
            if section and cp.has_section(section):
                raw=cp.get(section,"PreSonicateNum",fallback="")
                try: return max(0,int(float(raw)))
                except Exception: pass
        return 0
