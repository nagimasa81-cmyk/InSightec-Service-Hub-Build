from __future__ import annotations

from dataclasses import dataclass
import math
import numpy as np


@dataclass(slots=True)
class PhaseFocusResult:
    geometric_focus_xyz_mm: tuple[float, float, float] | None
    phase_focus_xyz_mm: tuple[float, float, float] | None
    steering_xyz_mm: tuple[float, float, float] | None
    steering_distance_mm: float | None
    frequency_hz: float | None
    sound_speed_m_s: float
    active_channels: int
    coherence: float | None
    phase_sign: str
    alternate_focus_xyz_mm: tuple[float, float, float] | None = None
    alternate_coherence: float | None = None
    requested_steering_xyz_mm: tuple[float, float, float] | None = None
    requested_error_mm: float | None = None
    confidence: str = "Unavailable"
    note: str = ""


class PhaseFocusService:
    """Estimate electronic steering from physical element coordinates + phase.

    This is a homogeneous-medium coherence model.  It deliberately does not move
    physical element locations and does not claim to separate steering phase from
    skull-aberration correction.  Both propagation phase conventions are evaluated;
    a requested steering vector may be used only to select the convention, never to
    force the result.
    """

    @staticmethod
    def _robust_sphere_center(points: np.ndarray) -> tuple[np.ndarray, float] | None:
        pts = np.asarray(points, float)
        if pts.ndim != 2 or pts.shape[1] != 3 or len(pts) < 16:
            return None

        def fit(p):
            A = np.c_[2.0 * p, np.ones(len(p))]
            b = np.sum(p * p, axis=1)
            sol, *_ = np.linalg.lstsq(A, b, rcond=None)
            center = sol[:3]
            radius_sq = float(np.dot(center, center) + sol[3])
            if radius_sq <= 0 or not np.isfinite(radius_sq):
                return None
            return center, math.sqrt(radius_sq)

        first = fit(pts)
        if first is None:
            return None
        center, radius = first
        residual = np.abs(np.linalg.norm(pts - center[None, :], axis=1) - radius)
        cutoff = float(np.percentile(residual, 95.0))
        keep = residual <= max(cutoff, 1e-9)
        second = fit(pts[keep])
        return second or first

    @staticmethod
    def _coherence(candidates, points, amplitude, phase, k_rad_per_mm, sign):
        candidates = np.asarray(candidates, float)
        out = []
        norm = max(float(np.sum(np.abs(amplitude))), 1e-12)
        for start in range(0, len(candidates), 1200):
            q = candidates[start:start + 1200]
            distance = np.linalg.norm(q[:, None, :] - points[None, :, :], axis=2)
            ph = phase[None, :] + float(sign) * float(k_rad_per_mm) * distance
            z = np.sum(amplitude[None, :] * np.exp(1j * ph), axis=1)
            out.append(np.abs(z) / norm)
        return np.concatenate(out) if out else np.zeros(0, float)

    @classmethod
    def _search(cls, center, points, amplitude, phase, k, sign):
        best = np.asarray(center, float)
        best_score = -1.0
        for half_width, step in ((12.0, 2.0), (3.0, 0.5), (0.75, 0.25)):
            axis = np.arange(-half_width, half_width + step * 0.25, step, dtype=float)
            gx, gy, gz = np.meshgrid(axis, axis, axis, indexing="ij")
            candidates = np.column_stack((gx.ravel(), gy.ravel(), gz.ravel())) + best[None, :]
            scores = cls._coherence(candidates, points, amplitude, phase, k, sign)
            if scores.size:
                idx = int(np.nanargmax(scores))
                best = candidates[idx]
                best_score = float(scores[idx])
        return best, best_score

    @classmethod
    def estimate(
        cls,
        geometry_xyz_by_channel: dict[int, tuple[float, float, float]],
        phase_rad_by_channel: dict[int, float],
        amplitude_by_channel: dict[int, float] | None,
        frequency_hz: float | None,
        *,
        excluded_channels: set[int] | None = None,
        requested_steering_xyz_mm: tuple[float, float, float] | None = None,
        geometric_focus_xyz_mm: tuple[float, float, float] | None = None,
        sound_speed_m_s: float = 1500.0,
    ) -> PhaseFocusResult:
        excluded = {int(v) for v in (excluded_channels or set())}
        common = sorted(set(geometry_xyz_by_channel) & set(phase_rad_by_channel))
        common = [ch for ch in common if ch not in excluded]

        if frequency_hz is None or not np.isfinite(float(frequency_hz)) or float(frequency_hz) <= 0:
            return PhaseFocusResult(
                None, None, None, None, None, float(sound_speed_m_s), len(common),
                None, "unknown", confidence="Unavailable",
                note="Frequency unavailable; phase-derived focus not calculated."
            )

        points, amplitude, phase = [], [], []
        for ch in common:
            try:
                xyz = tuple(float(v) for v in geometry_xyz_by_channel[ch])
                ph = float(phase_rad_by_channel[ch])
                amp = float((amplitude_by_channel or {}).get(ch, 1.0))
            except Exception:
                continue
            if len(xyz) != 3 or not all(np.isfinite(v) for v in xyz) or not np.isfinite(ph):
                continue
            if not np.isfinite(amp) or amp <= 0:
                continue
            points.append(xyz)
            amplitude.append(amp)
            phase.append(ph)

        if len(points) < 64:
            return PhaseFocusResult(
                None, None, None, None, float(frequency_hz), float(sound_speed_m_s), len(points),
                None, "unknown", confidence="Unavailable",
                note="Too few active geometry+phase channels."
            )

        points = np.asarray(points, float)
        amplitude = np.asarray(amplitude, float)
        phase = np.asarray(phase, float)

        sphere = cls._robust_sphere_center(points)
        if sphere is None and geometric_focus_xyz_mm is None:
            return PhaseFocusResult(
                None, None, None, None, float(frequency_hz), float(sound_speed_m_s), len(points),
                None, "unknown", confidence="Unavailable",
                note="Could not estimate geometric focus from physical element geometry."
            )
        if geometric_focus_xyz_mm is not None:
            try:
                geometric=np.asarray(geometric_focus_xyz_mm,float)
                if geometric.shape != (3,) or not np.all(np.isfinite(geometric)):
                    geometric=np.asarray(sphere[0],float)
            except Exception:
                geometric=np.asarray(sphere[0],float)
        else:
            geometric=np.asarray(sphere[0],float)

        k = 2.0 * math.pi * float(frequency_hz) / float(sound_speed_m_s) / 1000.0
        plus_focus, plus_score = cls._search(geometric, points, amplitude, phase, k, +1.0)
        minus_focus, minus_score = cls._search(geometric, points, amplitude, phase, k, -1.0)

        requested = None
        if requested_steering_xyz_mm is not None:
            try:
                requested = np.asarray(requested_steering_xyz_mm, float)
                if requested.shape != (3,) or not np.all(np.isfinite(requested)):
                    requested = None
            except Exception:
                requested = None

        plus_delta = plus_focus - geometric
        minus_delta = minus_focus - geometric

        # Convention selection:
        # 1) if an exported requested steering vector exists, choose the convention
        #    whose derived steering is closer to it;
        # 2) otherwise choose the stronger coherence peak.
        if requested is not None:
            ep = float(np.linalg.norm(plus_delta - requested))
            em = float(np.linalg.norm(minus_delta - requested))
            use_plus = ep <= em
        else:
            use_plus = plus_score >= minus_score

        focus = plus_focus if use_plus else minus_focus
        score = plus_score if use_plus else minus_score
        alt_focus = minus_focus if use_plus else plus_focus
        alt_score = minus_score if use_plus else plus_score
        sign_name = "+k·distance" if use_plus else "-k·distance"
        delta = focus - geometric
        distance = float(np.linalg.norm(delta))

        requested_error = None
        if requested is not None:
            requested_error = float(np.linalg.norm(delta - requested))

        # Confidence concerns convention ambiguity and coherence only.  It is not
        # a claim of in-vivo focal accuracy because skull correction is included.
        separation = abs(float(plus_score) - float(minus_score))
        if score >= 0.60 and separation >= 0.08:
            confidence = "High model coherence"
        elif score >= 0.40 and separation >= 0.03:
            confidence = "Moderate model coherence"
        elif score >= 0.25:
            confidence = "Low / sign-ambiguous"
        else:
            confidence = "Low coherence"

        note = (
            "Homogeneous-medium coherence estimate using steering-phase residual when available. "
            "Exported focal-point evidence is used for comparison, not to force the focus."
        )

        return PhaseFocusResult(
            tuple(map(float, geometric)),
            tuple(map(float, focus)),
            tuple(map(float, delta)),
            distance,
            float(frequency_hz),
            float(sound_speed_m_s),
            len(points),
            float(score),
            sign_name,
            tuple(map(float, alt_focus)),
            float(alt_score),
            None if requested is None else tuple(map(float, requested)),
            requested_error,
            confidence,
            note,
        )
