from __future__ import annotations

from dataclasses import dataclass, asdict, field
from pathlib import Path
import re

from src.parsers.ado_rowset import parse_ado_rowset
from src.services.acoustic_control_service import AcousticControlService
from src.services.sonication_evidence_service import SonicationEvidenceService
from src.services.spectrum_dump_import_service import SpectrumDumpImportService


_SON_DIR_RE = re.compile(r"^sonication\s*[_-]?\s*(\d+)$", re.I)
_SPECTRUM_MSG_RE = re.compile(r"^spectrummsg[-_ ]?(\d+)", re.I)


@dataclass(slots=True)
class ImportCompletenessReport:
    status: str = "UNKNOWN"
    workspace_file_count: int = 0
    sonication_folder_count: int = 0
    sonication_folder_occurrence_count: int = 0
    sonication_folder_numbers: list[int] = field(default_factory=list)
    replay_sonication_count: int = 0
    replay_sonication_numbers: list[int] = field(default_factory=list)
    summary_sonication_count: int = 0
    summary_sonication_numbers: list[int] = field(default_factory=list)
    spot_sonication_count: int = 0
    spot_sonication_numbers: list[int] = field(default_factory=list)
    spectrummsg_count: int = 0
    spectrummsg_sonication_numbers: list[int] = field(default_factory=list)
    cpc_candidate_count: int = 0
    acquisition_brain_session_count: int = 0
    sonication_brain_setup_count: int = 0
    canonical_session_resolved_count: int = 0
    cpc_mapped_count: int = 0
    issues: list[str] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)

    def compact_summary(self) -> str:
        return (
            f"Import audit {self.status}: Sonications {self.replay_sonication_count}; "
            f"folders {self.sonication_folder_count}; SpectrumMsg {self.spectrummsg_count}; "
            f"CPC {self.cpc_candidate_count}; Acquisition sessions {self.acquisition_brain_session_count}; "
            f"canonical {self.canonical_session_resolved_count}/{self.replay_sonication_count}; "
            f"CPC mapped {self.cpc_mapped_count}/{self.replay_sonication_count}"
        )


class ImportCompletenessService:
    """Audit the complete evidence chain produced by ZIP/folder import.

    This service does not invent missing mappings.  It reports exactly which
    evidence survived import/package construction so a downstream analyzer can
    distinguish "no CPC data" from "CPC data exists but canonical identity was
    lost upstream".
    """

    @staticmethod
    def _row_indices(path: Path | None) -> list[int]:
        if path is None or not path.exists():
            return []
        try:
            rows = parse_ado_rowset(path)
        except Exception:
            return []
        out: set[int] = set()
        for row in rows:
            try:
                out.add(int(float(row.get("sonicationindex", ""))))
            except (TypeError, ValueError):
                continue
        return sorted(out)

    @staticmethod
    def _first(workspace: Path, name: str) -> Path | None:
        items = sorted(workspace.rglob(name), key=lambda p: (len(p.parts), str(p).lower()))
        return items[0] if items else None

    def audit(self, workspace: Path, sonications: list[object]) -> ImportCompletenessReport:
        workspace = Path(workspace)
        report = ImportCompletenessReport()
        files = [p for p in workspace.rglob("*") if p.is_file()]
        report.workspace_file_count = len(files)

        folder_numbers: set[int] = set()
        folder_occurrences: list[int] = []
        for p in workspace.rglob("*"):
            if not p.is_dir():
                continue
            m = _SON_DIR_RE.match(p.name)
            if m:
                number = int(m.group(1))
                folder_numbers.add(number)
                folder_occurrences.append(number)
        root_match = _SON_DIR_RE.match(workspace.name)
        if root_match:
            number = int(root_match.group(1))
            folder_numbers.add(number)
            folder_occurrences.append(number)
        report.sonication_folder_numbers = sorted(folder_numbers)
        report.sonication_folder_count = len(folder_numbers)
        report.sonication_folder_occurrence_count = len(folder_occurrences)
        report.replay_sonication_count = len(sonications)
        replay_numbers = []
        for fallback, son in enumerate(sonications, start=1):
            try:
                number = int(getattr(son, "sonication_number", 0) or 0)
            except (TypeError, ValueError):
                number = 0
            replay_numbers.append(number if number > 0 else fallback)
        report.replay_sonication_numbers = replay_numbers

        summary_numbers = self._row_indices(self._first(workspace, "SonicationSummary.xml"))
        spot_numbers = self._row_indices(self._first(workspace, "spotsonicationdata.xml"))
        report.summary_sonication_numbers = summary_numbers
        report.summary_sonication_count = len(summary_numbers)
        report.spot_sonication_numbers = spot_numbers
        report.spot_sonication_count = len(spot_numbers)

        spectrum_numbers: set[int] = set()
        spectrum_count = 0
        for p in files:
            if "spectrummsg" not in p.name.lower() or p.suffix.lower() != ".dmp":
                continue
            spectrum_count += 1
            m = _SPECTRUM_MSG_RE.match(p.name)
            if m:
                spectrum_numbers.add(int(m.group(1)))
        report.spectrummsg_count = spectrum_count
        report.spectrummsg_sonication_numbers = sorted(spectrum_numbers)

        acoustic = AcousticControlService()
        try:
            log = acoustic.find_log(workspace)
            sessions = acoustic.parse_segments(log) if log is not None else []
            report.acquisition_brain_session_count = len(sessions)
        except Exception as exc:
            report.evidence.append(f"Acquisition_Brain parse unavailable: {type(exc).__name__}: {exc}")

        try:
            setups = SonicationEvidenceService().parse_setup_records(workspace)
            report.sonication_brain_setup_count = len(setups)
        except Exception as exc:
            report.evidence.append(f"Sonication_Brain parse unavailable: {type(exc).__name__}: {exc}")

        report.canonical_session_resolved_count = sum(
            getattr(son, "canonical_acquisition_session_index", None) is not None for son in sonications
        )

        try:
            dump_import = SpectrumDumpImportService()
            candidates = dump_import.discover(workspace)
            report.cpc_candidate_count = sum(c.family == "CPC Spectrum" for c in candidates)
            mapping = dump_import.map_candidates_to_sonications(candidates, sonications)
            report.cpc_mapped_count = len(mapping)
        except Exception as exc:
            report.evidence.append(f"CPC discovery/mapping unavailable: {type(exc).__name__}: {exc}")

        replay_set = set(report.replay_sonication_numbers)
        folder_set = set(report.sonication_folder_numbers)
        summary_set = set(summary_numbers)
        spot_set = set(spot_numbers)
        spectrum_set = set(report.spectrummsg_sonication_numbers)
        evidence_union = folder_set | summary_set | spot_set | spectrum_set

        if report.sonication_folder_occurrence_count > report.sonication_folder_count:
            duplicate_numbers = sorted({n for n in folder_occurrences if folder_occurrences.count(n) > 1})
            report.issues.append(
                f"Duplicate physical Sonication folder identity discovered for {duplicate_numbers}; merged into one logical Sonication each"
            )
        if summary_set and folder_set != summary_set:
            report.issues.append(
                f"Sonication folder identity differs from SonicationSummary: folders={sorted(folder_set)}, summary={sorted(summary_set)}"
            )
        if evidence_union and replay_set != evidence_union:
            report.issues.append(
                f"ReplayPackage logical identities {sorted(replay_set)} differ from imported numbered evidence {sorted(evidence_union)}"
            )
        if report.replay_sonication_count != report.sonication_folder_count:
            report.evidence.append(
                f"ReplayPackage logical Sonications={report.replay_sonication_count}; physical numbered folders={report.sonication_folder_count}"
            )
        if summary_set and not summary_set.issubset(replay_set):
            report.issues.append(
                f"ReplayPackage is missing SonicationSummary identities {sorted(summary_set - replay_set)}"
            )
        if spot_set and summary_set and spot_set != summary_set:
            report.issues.append(
                f"spotsonicationdata indices differ from SonicationSummary: spot={sorted(spot_set)}, summary={sorted(summary_set)}"
            )
        if spectrum_set and summary_set and not summary_set.issubset(spectrum_set):
            missing = sorted(summary_set - spectrum_set)
            report.issues.append(f"SpectrumMsg identity missing for Sonication(s): {missing}")
        if report.cpc_candidate_count > 0 and report.canonical_session_resolved_count < report.replay_sonication_count:
            report.issues.append(
                f"Canonical Acquisition session resolved for only {report.canonical_session_resolved_count}/{report.replay_sonication_count} Sonication(s)"
            )
        if report.cpc_candidate_count > 0 and report.cpc_mapped_count < report.replay_sonication_count:
            report.issues.append(
                f"Authoritative CPC mapping resolved for only {report.cpc_mapped_count}/{report.replay_sonication_count} Sonication(s) despite {report.cpc_candidate_count} CPC candidate(s)"
            )

        report.evidence.append(
            f"workspace files={report.workspace_file_count}, folders={report.sonication_folder_count}/{report.sonication_folder_occurrence_count}, "
            f"summary={report.summary_sonication_count}, spot={report.spot_sonication_count}, "
            f"SpectrumMsg={report.spectrummsg_count}, CPC={report.cpc_candidate_count}, "
            f"Acquisition sessions={report.acquisition_brain_session_count}, setup records={report.sonication_brain_setup_count}"
        )
        report.status = "PASS" if not report.issues else "WARN"
        return report
