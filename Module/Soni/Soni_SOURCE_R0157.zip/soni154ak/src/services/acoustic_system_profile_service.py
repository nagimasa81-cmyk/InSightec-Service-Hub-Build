from __future__ import annotations

import re
import statistics
from dataclasses import dataclass, field
from pathlib import Path


LOW_FAMILY_MIN_HZ = 180_000.0
LOW_FAMILY_MAX_HZ = 320_000.0
HIGH_FAMILY_MIN_HZ = 550_000.0
HIGH_FAMILY_MAX_HZ = 750_000.0


def frequency_family(hz: float | None) -> str | None:
    if hz is None:
        return None
    value = float(hz)
    if LOW_FAMILY_MIN_HZ <= value <= LOW_FAMILY_MAX_HZ:
        return "Brain 220 family"
    if HIGH_FAMILY_MIN_HZ <= value <= HIGH_FAMILY_MAX_HZ:
        return "Brain 650 family"
    return None


@dataclass(slots=True)
class AcousticSystemProfile:
    family: str = "Unknown"
    actual_frequency_hz: float | None = None
    transducer_type: int | None = None
    conflict: bool = False
    confidence: str = "Unknown"
    evidence: list[str] = field(default_factory=list)

    @property
    def display(self) -> str:
        f = "--" if self.actual_frequency_hz is None else f"{self.actual_frequency_hz/1000.0:.0f} kHz"
        tx = "Tx?" if self.transducer_type is None else f"Tx{self.transducer_type}"
        suffix = " · CONFLICT" if self.conflict else ""
        return f"{self.family} · actual {f} · {tx}{suffix}"


class AcousticSystemProfileService:
    """Classify the *used* acoustic system from treatment evidence.

    Presence of Brain220/Brain650 templates is not evidence that that family was
    used: exports can contain templates for both.  Priority is actual
    SonicationSummary frequency, then TransducerInfo.transtype, then serial XD.
    Conflicting strong evidence is reported rather than silently coerced.
    """

    _FREQ_RE = re.compile(r"\bfrequency\s*=\s*['\"]?([-+0-9.eE]+)", re.I)
    _TRANSTYPE_RE = re.compile(r"\btranstype\s*=\s*['\"]?(\d+)", re.I)
    _XD_SERIAL_RE = re.compile(r"^xd_(\d{4})\.ini$", re.I)
    _XD_FREQ_RE = re.compile(r"^\s*FREQ\d+\s*=\s*([-+0-9.eE]+)", re.I)

    @staticmethod
    def _normalise_frequency(raw: float) -> float | None:
        try:
            value = float(raw)
        except (TypeError, ValueError):
            return None
        if value <= 0:
            return None
        if value < 10:
            value *= 1_000_000.0
        elif value < 10_000:
            value *= 1_000.0
        return value

    def _summary_frequencies(self, workspace: Path) -> tuple[list[float], Path | None]:
        candidates = sorted(
            (p for p in workspace.rglob("*.xml") if p.name.lower() == "sonicationsummary.xml"),
            key=lambda p: (len(p.parts), str(p).lower()),
        )
        if not candidates:
            return [], None
        path = candidates[0]
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            return [], path
        values: list[float] = []
        for match in self._FREQ_RE.finditer(text):
            hz = self._normalise_frequency(float(match.group(1)))
            if hz is not None and frequency_family(hz) is not None:
                values.append(hz)
        return values, path

    def _transducer_type(self, workspace: Path) -> tuple[int | None, Path | None]:
        candidates = sorted(
            (p for p in workspace.rglob("*.xml") if p.name.lower() == "transducerinfo.xml"),
            key=lambda p: (len(p.parts), str(p).lower()),
        )
        if not candidates:
            return None, None
        path = candidates[0]
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            return None, path
        # Ignore schema declarations; the actual data row contains transtype='N'.
        matches = [int(m.group(1)) for m in self._TRANSTYPE_RE.finditer(text)]
        return (matches[-1] if matches else None), path

    def _serial_xd_family(self, workspace: Path) -> tuple[str | None, Path | None, list[float]]:
        candidates: list[Path] = []
        for path in workspace.rglob("*.ini"):
            m = self._XD_SERIAL_RE.fullmatch(path.name)
            if m and m.group(1) != "0000":
                candidates.append(path)
        candidates.sort(key=lambda p: str(p).lower())
        for path in candidates:
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            vals = []
            for line in text.splitlines():
                m = self._XD_FREQ_RE.match(line)
                if not m:
                    continue
                hz = self._normalise_frequency(float(m.group(1)))
                if hz is not None and frequency_family(hz) is not None:
                    vals.append(hz)
            fams = [frequency_family(v) for v in vals if frequency_family(v)]
            if fams:
                # A serial XD can contain disabled edge frequencies. Family is
                # still unambiguous when all supported values occupy one band.
                low = sum(f == "Brain 220 family" for f in fams)
                high = sum(f == "Brain 650 family" for f in fams)
                fam = "Brain 220 family" if low > high else "Brain 650 family" if high > low else None
                if fam:
                    return fam, path, vals
        return None, None, []

    def classify(self, workspace: Path, sonication_frequencies: list[float] | None = None) -> AcousticSystemProfile:
        profile = AcousticSystemProfile()
        values = [float(v) for v in (sonication_frequencies or []) if frequency_family(v) is not None]
        summary_path = None
        if not values:
            values, summary_path = self._summary_frequencies(workspace)
        else:
            # Still locate for human-readable evidence when available.
            _, summary_path = self._summary_frequencies(workspace)

        frequency_families = {frequency_family(v) for v in values if frequency_family(v)}
        if values:
            profile.actual_frequency_hz = float(statistics.median(values))
            profile.evidence.append(
                f"SonicationSummary actual frequency median={profile.actual_frequency_hz:g} Hz"
                + (f" ({summary_path})" if summary_path else "")
            )
            if len(frequency_families) == 1:
                profile.family = next(iter(frequency_families))
            elif len(frequency_families) > 1:
                profile.conflict = True
                profile.evidence.append("SonicationSummary frequencies span both acoustic families")

        tx, tx_path = self._transducer_type(workspace)
        profile.transducer_type = tx
        tx_family = {41: "Brain 220 family", 42: "Brain 650 family"}.get(tx)
        if tx is not None:
            profile.evidence.append(f"TransducerInfo transtype={tx}" + (f" ({tx_path})" if tx_path else ""))
        if tx_family:
            if profile.family == "Unknown":
                profile.family = tx_family
            elif profile.family != tx_family:
                profile.conflict = True
                profile.evidence.append(f"CONFLICT: frequency family={profile.family}, transducer family={tx_family}")

        xd_family, xd_path, xd_values = self._serial_xd_family(workspace)
        if xd_family:
            profile.evidence.append(
                f"Serial XD family={xd_family} ({xd_path}); observed band "
                f"{min(xd_values)/1000.0:.0f}-{max(xd_values)/1000.0:.0f} kHz"
            )
            if profile.family == "Unknown":
                profile.family = xd_family
            elif profile.family != xd_family:
                profile.conflict = True
                profile.evidence.append(f"CONFLICT: selected family={profile.family}, serial XD family={xd_family}")

        strong = bool(values) and tx_family is not None and not profile.conflict
        profile.confidence = "High" if strong else "Medium" if profile.family != "Unknown" and not profile.conflict else "Conflict" if profile.conflict else "Unknown"
        return profile
