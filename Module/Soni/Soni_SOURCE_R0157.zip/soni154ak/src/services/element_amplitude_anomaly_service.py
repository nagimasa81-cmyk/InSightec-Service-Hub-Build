from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping
import math


@dataclass(frozen=True)
class ZeroAmplitudeAnomaly:
    channel: int
    sources: tuple[str, ...]

    @property
    def reason(self) -> str:
        return " + ".join(self.sources)


class ElementAmplitudeAnomalyService:
    """Detect unexplained zero-amplitude sonication channels.

    A zero value by itself is *not* classified as a defect.  A channel is
    reported only when zero amplitude is observed while there is no exported
    evidence explaining why the channel was intentionally excluded:

    * DisabledReflectionChannels.ini
    * DisconnectedChannels.ini / defect evidence
    * SkullHeating explicit OffReason for an ACT-zero channel

    ACT and decoded measured amplitudes are kept as separate evidence labels so
    the UI can report what actually triggered the warning.
    """

    ZERO_EPS = 1e-12

    @classmethod
    def detect(
        cls,
        snapshot,
        *,
        act_zero: Iterable[int] | None = None,
        act_reasons: Mapping[int, str] | None = None,
        disabled: Iterable[int] | None = None,
        defect: Iterable[int] | None = None,
    ) -> dict[int, ZeroAmplitudeAnomaly]:
        act_zero_set = {int(v) for v in (act_zero or ()) if 0 <= int(v) < 1024}
        explicit_off = {int(k) for k, v in dict(act_reasons or {}).items() if str(v or "").strip()}
        excluded = ({int(v) for v in (disabled or ())} |
                    {int(v) for v in (defect or ())} |
                    explicit_off)

        evidence: dict[int, list[str]] = {}
        for ch in sorted(act_zero_set - excluded):
            evidence.setdefault(ch, []).append("ACT amplitude=0 without OFF reason")

        for value in list(getattr(snapshot, "values", []) or []):
            try:
                ch = int(getattr(value, "channel", -1))
            except Exception:
                continue
            if not 0 <= ch < 1024 or ch in excluded:
                continue
            raw = getattr(value, "measured_amplitude", None)
            if raw is None:
                continue
            try:
                amp = float(raw)
            except (TypeError, ValueError):
                continue
            if math.isfinite(amp) and abs(amp) <= cls.ZERO_EPS:
                evidence.setdefault(ch, []).append("Measured amplitude=0")

        return {
            ch: ZeroAmplitudeAnomaly(channel=ch, sources=tuple(dict.fromkeys(labels)))
            for ch, labels in evidence.items()
        }
