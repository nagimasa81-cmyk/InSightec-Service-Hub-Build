from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re

import numpy as np

from src.parsers.ado_rowset import parse_ado_rowset


_MESH_VERTEX_RE = re.compile(r"\.Vertices\s*=\s*\[(.*?)\];", re.I | re.S)
_NUM_RE = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?")
_RAW_NAME_RE = re.compile(r"^(\d+)-(\d+)-(\d+)-(\d+)\.raw$", re.I)


@dataclass(slots=True)
class TreatmentSpotGeometry:
    sonication_number: int
    spotcue: str
    vertices_uvw_mm: np.ndarray
    vertices_ras_mm: np.ndarray
    center_ras_mm: tuple[float, float, float]
    extent_ras_mm: tuple[float, float, float]
    diameter_mm: float | None = None
    length_mm: float | None = None
    source_mesh: str = ""
    evidence: list[str] = field(default_factory=list)


@dataclass(slots=True)
class ProjectedTreatmentSpot:
    sonication_number: int
    spotcue: str
    center_x: float
    center_y: float
    width_px: float
    height_px: float
    width_mm: float
    height_mm: float
    label: str


class TreatmentSpotGeometryService:
    """Read executed treatment-spot geometry from export evidence.

    Important Brain220 semantic boundary:
    ``BBB spot ... 9 sub-sonications`` is the internal firing lattice *inside*
    one treatment spot.  It is never used here as a target/voxel count.

    Executed target ownership comes from ``spotsonicationdata.xml``.  Physical
    size comes from the corresponding ``SpotMesh-<S>-<SpotCue>.mesh`` vertices.
    The mesh stores workstation UVW; comparison with SonicationSummary focalRAS
    in validated 220 exports establishes the exported transform R=-U, A=-V,
    S=W.  We validate that transform against focalRAS before using a mesh for MR
    projection; otherwise projection fails closed.
    """

    def __init__(self) -> None:
        self._cache: dict[tuple[str, int], list[TreatmentSpotGeometry]] = {}
        self._mr_rows_cache: dict[str, list[dict[str, object]]] = {}
        self._focal_cache: dict[str, dict[int, np.ndarray]] = {}

    @staticmethod
    def _first_file(workspace: Path, name: str) -> Path | None:
        low=name.lower()
        return next((p for p in workspace.rglob("*") if p.is_file() and p.name.lower()==low), None)

    @staticmethod
    def _mesh_vertices(path: Path) -> np.ndarray | None:
        try:
            text=path.read_text(errors="ignore")
        except Exception:
            return None
        m=_MESH_VERTEX_RE.search(text)
        if not m:
            return None
        rows=[]
        for line in m.group(1).split(";"):
            vals=[float(v) for v in _NUM_RE.findall(line)]
            if len(vals) >= 3:
                rows.append(vals[:3])
        if len(rows) < 4:
            return None
        arr=np.asarray(rows,float)
        return arr if arr.ndim==2 and arr.shape[1]==3 and np.isfinite(arr).all() else None

    def _summary_focals(self, workspace: Path) -> dict[int, np.ndarray]:
        token=str(workspace.resolve())
        if token in self._focal_cache:
            return self._focal_cache[token]
        path=self._first_file(workspace,"SonicationSummary.xml")
        out={}
        if path is not None:
            try:
                for row in parse_ado_rowset(path):
                    try:
                        n=int(float(row.get("sonicationindex")))
                        p=np.asarray([float(row.get(k)) for k in ("focalrasx","focalrasy","focalrasz")],float)
                    except Exception:
                        continue
                    if np.isfinite(p).all(): out[n]=p
            except Exception:
                pass
        self._focal_cache[token]=out
        return out

    @staticmethod
    def _uvw_to_ras(vertices: np.ndarray) -> np.ndarray:
        out=np.asarray(vertices,float).copy()
        out[:,0] *= -1.0
        out[:,1] *= -1.0
        return out

    def spots_for_sonication(self, workspace: Path, sonication_number: int) -> list[TreatmentSpotGeometry]:
        workspace=Path(workspace)
        key=(str(workspace.resolve()),int(sonication_number))
        if key in self._cache:
            return self._cache[key]
        owner=self._first_file(workspace,"spotsonicationdata.xml")
        cues=[]
        if owner is not None:
            try:
                for row in parse_ado_rowset(owner):
                    try:
                        if int(float(row.get("sonicationindex"))) != int(sonication_number): continue
                    except Exception:
                        continue
                    cue=str(row.get("spotcue") or "").strip()
                    if cue and cue not in cues: cues.append(cue)
            except Exception:
                pass
        if not cues:
            self._cache[key]=[]; return []

        spot_meta={}
        meta_path=self._first_file(workspace,"SpotData.xml")
        if meta_path is not None:
            try:
                for row in parse_ado_rowset(meta_path):
                    cue=str(row.get("spotcue") or row.get("cue") or "").strip()
                    if cue: spot_meta[cue]=row
            except Exception:
                pass

        focals=self._summary_focals(workspace)
        expected=focals.get(int(sonication_number))
        out=[]
        son_dir=workspace/f"Sonication{int(sonication_number)}"
        for ordinal,cue in enumerate(cues,1):
            candidates=[]
            if son_dir.exists(): candidates.extend(son_dir.glob(f"SpotMesh-{int(sonication_number)}-{cue}.mesh"))
            if not candidates: candidates=list(workspace.rglob(f"SpotMesh-{int(sonication_number)}-{cue}.mesh"))
            if not candidates: continue
            mesh=candidates[0]
            uvw=self._mesh_vertices(mesh)
            if uvw is None: continue
            ras=self._uvw_to_ras(uvw)
            center=np.nanmean(ras,axis=0)
            evidence=[f"SpotSonicationData S{sonication_number}->SpotCue {cue}",f"Physical extent from {mesh.name}"]
            if expected is not None:
                err=float(np.linalg.norm(center-expected))
                # Mesh centroids in the 220 export agree with Summary focalRAS to
                # well below a millimetre.  Reject an unknown coordinate family
                # rather than drawing a plausible-looking but misplaced target.
                if not np.isfinite(err) or err > 2.0:
                    continue
                evidence.append(f"UVW->RAS transform validated to focalRAS ({err:.3f} mm)")
            extent=np.nanmax(ras,axis=0)-np.nanmin(ras,axis=0)
            meta=spot_meta.get(cue,{})
            def fv(k):
                try:
                    v=float(meta.get(k)); return v if np.isfinite(v) else None
                except Exception: return None
            out.append(TreatmentSpotGeometry(
                sonication_number=int(sonication_number), spotcue=cue,
                vertices_uvw_mm=uvw, vertices_ras_mm=ras,
                center_ras_mm=tuple(float(v) for v in center),
                extent_ras_mm=tuple(float(v) for v in extent),
                diameter_mm=fv("diameter"), length_mm=fv("length"),
                source_mesh=str(mesh), evidence=evidence,
            ))
        self._cache[key]=out
        return out

    def _mr_rows(self, workspace: Path) -> list[dict[str, object]]:
        token=str(workspace.resolve())
        if token in self._mr_rows_cache: return self._mr_rows_cache[token]
        p=self._first_file(workspace,"MriImageParams.xml")
        rows=[]
        if p is not None:
            try: rows=parse_ado_rowset(p)
            except Exception: rows=[]
        self._mr_rows_cache[token]=rows
        return rows

    @staticmethod
    def _frame_identity(path: Path) -> tuple[int,int,int,int] | None:
        m=_RAW_NAME_RE.match(Path(path).name)
        return tuple(int(v) for v in m.groups()) if m else None

    def _row_for_frame(self, workspace: Path, frame_path: Path) -> dict[str, object] | None:
        identity=self._frame_identity(frame_path)
        if identity is None: return None
        field,son,zone,array=identity
        for row in self._mr_rows(workspace):
            try:
                if (int(float(row.get("fieldindex"))),int(float(row.get("sonicationindex"))),int(float(row.get("zoneindex"))),int(float(row.get("arrayindex")))) == identity:
                    return row
            except Exception:
                continue
        return None

    @staticmethod
    def _project_ras(row: dict[str, object], point_ras: np.ndarray) -> tuple[float,float] | None:
        try:
            origin=np.asarray([float(row[k]) for k in ("topleftcoordr","topleftcoorda","topleftcoords")],float)
            rv=np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")],float)
            cv=np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")],float)
            sx=float(row.get("pixsizex")); sy=float(row.get("pixsizey"))
        except Exception:
            return None
        rn=np.linalg.norm(rv); cn=np.linalg.norm(cv)
        if rn<.5 or cn<.5 or sx<=0 or sy<=0: return None
        rv=rv/rn; cv=cv/cn
        d=np.asarray(point_ras,float)-origin
        return float(np.dot(d,cv)/sx),float(np.dot(d,rv)/sy)

    def projected_spots(self, workspace: Path, sonication_number: int, frame_path: Path, shape: tuple[int,int]) -> list[ProjectedTreatmentSpot]:
        row=self._row_for_frame(Path(workspace),Path(frame_path))
        if row is None: return []
        h,w=shape
        out=[]
        for ordinal,spot in enumerate(self.spots_for_sonication(workspace,sonication_number),1):
            projected=[self._project_ras(row,v) for v in spot.vertices_ras_mm]
            projected=[p for p in projected if p is not None and np.isfinite(p).all()]
            center=self._project_ras(row,np.asarray(spot.center_ras_mm,float))
            if center is None or len(projected)<4: continue
            xs=np.asarray([p[0] for p in projected]); ys=np.asarray([p[1] for p in projected])
            # A 3-D spot may cross the displayed slice.  Its projected bounding
            # box communicates actual physical target size without pretending the
            # mesh is a spherical 4-mm ROI.
            width_px=max(1.0,float(np.ptp(xs))); height_px=max(1.0,float(np.ptp(ys)))
            if center[0] < -w or center[0] > 2*w or center[1] < -h or center[1] > 2*h: continue
            try:
                sx=float(row.get("pixsizex")); sy=float(row.get("pixsizey"))
            except Exception:
                sx=sy=1.0
            out.append(ProjectedTreatmentSpot(
                sonication_number=int(sonication_number),spotcue=spot.spotcue,
                center_x=float(center[0]),center_y=float(center[1]),
                width_px=width_px,height_px=height_px,
                width_mm=float(width_px*sx),height_mm=float(height_px*sy),
                label=f"Target {ordinal}",
            ))
        return out

    @staticmethod
    def mask_for_projected_spot(shape: tuple[int,int], spot: ProjectedTreatmentSpot | None) -> np.ndarray:
        h,w=shape
        if spot is None:
            cy,cx=h//2,w//2; yy,xx=np.ogrid[:h,:w]
            return (np.abs(xx-cx)<=1)&(np.abs(yy-cy)<=1)
        yy,xx=np.ogrid[:h,:w]
        hw=max(0.5,float(spot.width_px)/2.0); hh=max(0.5,float(spot.height_px)/2.0)
        # Elliptical in-plane target mask, matching the displayed physical target
        # footprint.  Temperature selection defaults to the first executed target.
        return ((xx-float(spot.center_x))/hw)**2 + ((yy-float(spot.center_y))/hh)**2 <= 1.0
