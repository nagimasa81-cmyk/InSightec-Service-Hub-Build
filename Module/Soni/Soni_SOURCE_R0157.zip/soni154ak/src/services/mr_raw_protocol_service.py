from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
import math
import re

import numpy as np

from src.parsers.ado_rowset import parse_ado_rowset


_RAW_RE = re.compile(r"^(?P<field>\d+)-(?P<son>\d+)-(?P<zone>\d+)-(?P<frame>\d+)\.raw$", re.I)


@dataclass(slots=True)
class MrRawSeries:
    sonication: int
    field_index: int
    series_description: str
    plane: str
    raw_files: int
    metadata_rows: int
    matrix: str
    pixel_size_mm: str
    slice_thickness_mm: str
    tr_ms: str
    te_ms: str
    flip_angle_deg: str
    bandwidth_khz: str
    frequency_direction: str
    acquisition_matrix: str
    center_frequency_hz: str
    actual_transmit_gain: str
    auto_transmit_gain: str
    prescan_r1: str
    prescan_r2: str
    shim_xyz: str
    coil_channels: str
    echo_number: str
    manufacturer: str
    series_uid: str
    raw_names: list[str] = field(default_factory=list)
    details: list[tuple[str, str]] = field(default_factory=list)


class MrRawProtocolService:
    """Bind Sonication-folder RAW payloads to their exact MriImageParams rows.

    The RAW filename supplies field/sonication ownership; MriImageParams supplies
    acquisition protocol parameters.  We never infer protocol from field number.
    One displayed row represents one unique MR series/field for the selected
    Sonication while ``details`` retains the complete representative metadata row.
    """

    @staticmethod
    def _find_params(workspace: Path) -> Path | None:
        for name in ("MriImageParams.xml", "MRIImageParams.xml"):
            matches = sorted(workspace.rglob(name))
            if matches:
                return matches[0]
        return None

    @staticmethod
    def _number(value: Any) -> float | None:
        try:
            out = float(value)
        except (TypeError, ValueError):
            return None
        return out if math.isfinite(out) else None

    @classmethod
    def _ms(cls, value: Any) -> str:
        v = cls._number(value)
        if v is None:
            return "—"
        # GE MriImageParams stores these fields in microseconds for the supplied
        # exports; smaller legacy values can already be milliseconds.
        ms = v / 1000.0 if abs(v) >= 1000.0 else v
        return f"{ms:.3f}".rstrip("0").rstrip(".")

    @classmethod
    def _fmt(cls, value: Any, digits: int = 3) -> str:
        v = cls._number(value)
        if v is None:
            text = str(value or "").strip()
            return text or "—"
        return f"{v:.{digits}f}".rstrip("0").rstrip(".")

    @staticmethod
    def _plane(row: dict[str, Any]) -> str:
        try:
            r = np.asarray([float(row[k]) for k in ("rowdirectcosrasx", "rowdirectcosrasy", "rowdirectcosrasz")], dtype=float)
            c = np.asarray([float(row[k]) for k in ("coldirectcosrasx", "coldirectcosrasy", "coldirectcosrasz")], dtype=float)
            n = np.cross(r, c)
            if np.all(np.isfinite(n)) and np.linalg.norm(n) > 0.5:
                return ("Sagittal", "Coronal", "Axial")[int(np.argmax(np.abs(n)))]
        except (KeyError, TypeError, ValueError):
            pass
        desc = str(row.get("seriesdiscription") or "").upper()
        for token, label in (("AXIAL", "Axial"), ("SAG", "Sagittal"), ("COR", "Coronal")):
            if token in desc:
                return label
        return "Unknown"

    @classmethod
    def _details(cls, row: dict[str, Any]) -> list[tuple[str, str]]:
        preferred = [
            "fieldindex", "sonicationindex", "zoneindex", "arrayindex", "imgnum",
            "seriesdiscription", "seriesuid", "manufacturer", "seriesplane", "imgplane",
            "imgmatrixx", "imgmatrixy", "pixsizex", "pixsizey", "slicethick",
            "repetitiontimetr", "echotimete", "exitationsnum", "mrflipangle", "varbandwidth",
            "freqdirection", "acquisitionmatrix", "epinumshots", "centerfreq",
            "actualtransmitgain", "autotransmitgain", "autocenterfreq", "prescanr1", "prescanr2",
            "shimx", "shimy", "shimz", "coilchannels", "echonum", "scantime",
            "rowdirectcosrasx", "rowdirectcosrasy", "rowdirectcosrasz",
            "coldirectcosrasx", "coldirectcosrasy", "coldirectcosrasz",
            "topleftcoordr", "topleftcoorda", "topleftcoords", "imgloc", "raslocletter",
        ]
        seen = set()
        out: list[tuple[str, str]] = []
        for key in preferred + sorted(row):
            if key in seen or key not in row:
                continue
            seen.add(key)
            value = row.get(key)
            if value in (None, ""):
                continue
            out.append((key, str(value)))
        return out

    def read(self, workspace: Path, sonication_folder: Path, sonication_number: int) -> list[MrRawSeries]:
        workspace = Path(workspace)
        folder = Path(sonication_folder)
        params = self._find_params(workspace)
        rows: list[dict[str, Any]] = []
        if params is not None:
            try:
                rows = [
                    r for r in parse_ado_rowset(params)
                    if int(float(r.get("sonicationindex", -1))) == int(sonication_number)
                ]
            except (OSError, ValueError, TypeError):
                rows = []

        raw_by_field: dict[int, list[Path]] = {}
        if folder.is_dir():
            for path in sorted(folder.glob("*.raw"), key=lambda p: p.name.lower()):
                m = _RAW_RE.match(path.name)
                if not m or int(m.group("son")) != int(sonication_number):
                    continue
                raw_by_field.setdefault(int(m.group("field")), []).append(path)

        rows_by_field: dict[int, list[dict[str, Any]]] = {}
        for row in rows:
            try:
                fid = int(float(row.get("fieldindex")))
            except (TypeError, ValueError):
                continue
            rows_by_field.setdefault(fid, []).append(row)

        result: list[MrRawSeries] = []
        # RAW ownership is authoritative for which series belong in this feature.
        for fid in sorted(raw_by_field):
            raw_files = raw_by_field[fid]
            field_rows = rows_by_field.get(fid, [])
            if not field_rows:
                result.append(MrRawSeries(
                    sonication=int(sonication_number), field_index=fid, series_description="Metadata unavailable",
                    plane="Unknown", raw_files=len(raw_files), metadata_rows=0, matrix="—", pixel_size_mm="—",
                    slice_thickness_mm="—", tr_ms="—", te_ms="—", flip_angle_deg="—", bandwidth_khz="—",
                    frequency_direction="—", acquisition_matrix="—", center_frequency_hz="—",
                    actual_transmit_gain="—", auto_transmit_gain="—", prescan_r1="—", prescan_r2="—",
                    shim_xyz="—", coil_channels="—", echo_number="—", manufacturer="—", series_uid="—",
                    raw_names=[p.name for p in raw_files],
                    details=[("binding", "RAW field exists but no matching MriImageParams row")],
                ))
                continue

            # A field normally maps to one SeriesUID.  Keep separate rows if a
            # vendor export legitimately reuses a field index for multiple series.
            groups: dict[tuple[str, str], list[dict[str, Any]]] = {}
            for row in field_rows:
                key = (str(row.get("seriesuid") or ""), str(row.get("seriesdiscription") or ""))
                groups.setdefault(key, []).append(row)
            for (_uid, _desc), group in groups.items():
                representative = max(group, key=lambda r: int(float(r.get("imgmatrixx", -1) or -1) > 0) + int(bool(r.get("seriesuid"))))
                matrix = f"{representative.get('imgmatrixx', '—')}×{representative.get('imgmatrixy', '—')}"
                pix = f"{self._fmt(representative.get('pixsizex'))}×{self._fmt(representative.get('pixsizey'))}"
                shim = "/".join(self._fmt(representative.get(k), 1) for k in ("shimx", "shimy", "shimz"))
                result.append(MrRawSeries(
                    sonication=int(sonication_number), field_index=fid,
                    series_description=str(representative.get("seriesdiscription") or "Unnamed MR series"),
                    plane=self._plane(representative), raw_files=len(raw_files), metadata_rows=len(group),
                    matrix=matrix, pixel_size_mm=pix, slice_thickness_mm=self._fmt(representative.get("slicethick")),
                    tr_ms=self._ms(representative.get("repetitiontimetr")), te_ms=self._ms(representative.get("echotimete")),
                    flip_angle_deg=self._fmt(representative.get("mrflipangle")), bandwidth_khz=self._fmt(representative.get("varbandwidth")),
                    frequency_direction=str(representative.get("freqdirection") or "—"),
                    acquisition_matrix=str(representative.get("acquisitionmatrix") or "—"),
                    center_frequency_hz=self._fmt(representative.get("centerfreq"), 0),
                    actual_transmit_gain=self._fmt(representative.get("actualtransmitgain"), 1),
                    auto_transmit_gain=self._fmt(representative.get("autotransmitgain"), 1),
                    prescan_r1=self._fmt(representative.get("prescanr1"), 1), prescan_r2=self._fmt(representative.get("prescanr2"), 1),
                    shim_xyz=shim, coil_channels=str(representative.get("coilchannels") or "—"),
                    echo_number=self._fmt(representative.get("echonum"), 0), manufacturer=str(representative.get("manufacturer") or "—"),
                    series_uid=str(representative.get("seriesuid") or "—"), raw_names=[p.name for p in raw_files],
                    details=self._details(representative),
                ))
        return result
