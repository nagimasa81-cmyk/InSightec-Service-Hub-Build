from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
import math

import numpy as np

from src.services.acoustic_control_service import AcousticControlService


@dataclass(slots=True)
class ClockDomainAssessment:
    """Treatment-WS <-> CPC clock relationship for one Export.

    ``cpc_to_ws_offset_s`` is the correction to ADD to a CPC wall-clock
    timestamp to express it in the Treatment Workstation clock domain.

    The offset is deliberately never inferred from a single anchor.  A stable
    multi-Sonication offset is evidence of a host-clock difference; a changing
    residual is treated as mapping ambiguity and is not auto-corrected.
    """

    status: str = "Unavailable"
    cpc_to_ws_offset_s: float | None = None
    anchor_count: int = 0
    spread_s: float | None = None
    max_residual_s: float | None = None
    source: Path | None = None
    evidence: list[str] = field(default_factory=list)

    @property
    def correction_allowed(self) -> bool:
        return self.status in {"Synchronized", "Stable offset"} and self.anchor_count >= 2


class ClockDomainService:
    """Estimate CPC-vs-treatment-WS Windows clock offset without guessing.

    Anchor definition:
      * Treatment WS: exact ``Sonication power on`` timestamp selected by the
        canonical MR timeline.
      * CPC: Acquisition_Brain session start + measured controller pre-roll,
        where pre-roll is aligned to that Sonication's exported PowerGraph.

    Both anchors represent the same physical acoustic power onset.  A robust
    median across >=2 Sonications is accepted only when residuals are small.
    """

    _SYNC_TOLERANCE_S = 0.250
    _MAX_STABLE_SPREAD_S = 0.500
    _MAX_STABLE_RESIDUAL_S = 0.750

    def __init__(self) -> None:
        self.acoustic = AcousticControlService()

    @staticmethod
    def _midnight_from_log(path: Path) -> float | None:
        stamp = AcousticControlService._log_stamp(Path(path))
        if stamp is None:
            return None
        return datetime(stamp.year, stamp.month, stamp.day).timestamp()

    @staticmethod
    def _finite(value) -> float | None:
        try:
            out = float(value)
        except (TypeError, ValueError):
            return None
        return out if math.isfinite(out) else None

    def assess(self, workspace: Path, sonications: list[object], timelines: list[object]) -> ClockDomainAssessment:
        workspace = Path(workspace)
        log = self.acoustic.find_log(workspace)
        if log is None:
            return ClockDomainAssessment(evidence=["Acquisition_Brain log unavailable"])
        midnight = self._midnight_from_log(log)
        if midnight is None:
            return ClockDomainAssessment(source=log, evidence=["Acquisition_Brain filename has no usable calendar date"])
        try:
            segments = self.acoustic.parse_segments(log)
        except Exception as exc:
            return ClockDomainAssessment(source=log, evidence=[f"Acquisition_Brain parse failed: {type(exc).__name__}: {exc}"])
        if not segments:
            return ClockDomainAssessment(source=log, evidence=["No Acquisition_Brain sessions parsed"])

        offsets: list[tuple[int, float, float, float]] = []
        for ordinal, (son, timeline) in enumerate(zip(sonications, timelines), start=1):
            try:
                number = int(getattr(son, "sonication_number", ordinal) or ordinal)
            except (TypeError, ValueError):
                number = ordinal
            try:
                session_index = getattr(son, "canonical_acquisition_session_index", None)
                session_index = int(session_index) if session_index is not None else None
            except (TypeError, ValueError):
                session_index = None
            ws_on = self._finite(getattr(timeline, "ws_power_on_abs_s", None))
            if session_index is None or ws_on is None or not (0 <= session_index < len(segments)):
                continue

            segment = segments[session_index]
            try:
                t, power, _score, _energy, _limit = self.acoustic._collapse(segment.samples)
            except Exception:
                continue
            if np.asarray(t).size < 2:
                continue
            vendor = self.acoustic._vendor_power_graph(workspace, max(0, number - 1))
            if vendor is None:
                continue
            vendor_t, vendor_power = vendor
            control_t = np.maximum(np.asarray(t, dtype=float) - float(np.nanmin(t)), 0.0)
            try:
                pre_roll = float(self.acoustic._align_control_to_vendor_power(
                    control_t,
                    self.acoustic._fill_forward(np.asarray(power, dtype=float)),
                    np.asarray(vendor_t, dtype=float),
                    np.asarray(vendor_power, dtype=float),
                ))
            except Exception:
                continue
            cpc_on = midnight + float(segment.start_clock_s) + pre_roll
            # Handle a session immediately after midnight when the log began on
            # the previous date.  Pick the nearest day projection to WS onset.
            choices = [cpc_on - 86400.0, cpc_on, cpc_on + 86400.0]
            cpc_on = min(choices, key=lambda v: abs(v - ws_on))
            offsets.append((number, ws_on - cpc_on, ws_on, cpc_on))

        if len(offsets) < 2:
            evidence = [f"Only {len(offsets)} shared acoustic-onset anchor(s); >=2 required for clock correction"]
            for number, off, _ws, _cpc in offsets:
                evidence.append(f"Sonication {number}: provisional CPC->WS offset {off:+.3f}s")
            return ClockDomainAssessment(
                status="Insufficient anchors", anchor_count=len(offsets), source=log, evidence=evidence,
            )

        values = np.asarray([item[1] for item in offsets], dtype=float)
        median = float(np.median(values))
        residual = np.abs(values - median)
        spread = float(np.max(values) - np.min(values))
        max_residual = float(np.max(residual))
        stable = spread <= self._MAX_STABLE_SPREAD_S and max_residual <= self._MAX_STABLE_RESIDUAL_S
        if not stable:
            evidence = [
                f"CPC/WS offset is not stable: spread={spread:.3f}s, max residual={max_residual:.3f}s",
                "Automatic cross-host clock correction disabled (fail-closed).",
            ]
            evidence.extend(f"Sonication {n}: CPC->WS {off:+.3f}s" for n, off, _ws, _cpc in offsets)
            return ClockDomainAssessment(
                status="Ambiguous / unstable", anchor_count=len(offsets), spread_s=spread,
                max_residual_s=max_residual, source=log, evidence=evidence,
            )

        status = "Synchronized" if abs(median) <= self._SYNC_TOLERANCE_S else "Stable offset"
        evidence = [
            f"Robust CPC->WS offset={median:+.3f}s from {len(offsets)} Sonications",
            f"spread={spread:.3f}s; max residual={max_residual:.3f}s",
        ]
        evidence.extend(f"Sonication {n}: CPC->WS {off:+.3f}s" for n, off, _ws, _cpc in offsets)
        return ClockDomainAssessment(
            status=status, cpc_to_ws_offset_s=median, anchor_count=len(offsets), spread_s=spread,
            max_residual_s=max_residual, source=log, evidence=evidence,
        )
