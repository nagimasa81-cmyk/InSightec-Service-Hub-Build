from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re
import xml.etree.ElementTree as ET


@dataclass(slots=True)
class PlanningAsset:
    category: str
    path: Path
    role: str
    confidence: float
    notes: str = ""
    width: int | None = None
    height: int | None = None
    dtype: str | None = None
    field_index: int | None = None
    sonication_index: int | None = None
    zone_index: int | None = None
    array_index: int | None = None
    plane: str | None = None
    series_description: str | None = None
    series_number: int | None = None
    pixel_size_x: float | None = None
    pixel_size_y: float | None = None
    top_left_r: float | None = None
    top_left_a: float | None = None
    top_left_s: float | None = None
    row_direction: tuple[float, float, float] | None = None
    col_direction: tuple[float, float, float] | None = None
    study_type: int | None = None
    series_type: int | None = None
    source_kind: str | None = None
    study_instance_uid: str | None = None


@dataclass(slots=True)
class PlanningDataSummary:
    assets: list[PlanningAsset] = field(default_factory=list)

    def by_category(self, category: str) -> list[PlanningAsset]:
        return [item for item in self.assets if item.category == category]

    @property
    def counts(self) -> dict[str, int]:
        result: dict[str, int] = {}
        for item in self.assets:
            result[item.category] = result.get(item.category, 0) + 1
        return result


class PlanningDataService:
    """Classify planning/reference resources without treating them as replay frames."""

    _RAW_RE = re.compile(r"^(\d+)-.*-(\d+)\.raw$", re.I)


    def _ct_linked_raws(self, workspace: Path) -> list[PlanningAsset]:
        """Resolve actual planning CT image payloads from CtImage.xml.

        CtImage.xml indexes many image families, including thermometry and anatomy.
        Planning CT is restricted to 512 x 512 records.  Field 16 is the signed
        CT/HU-like volume and is sorted first; other 512 x 512 CT-derived fields
        remain available after it.
        """
        xml_path = next((p for p in workspace.rglob("*") if p.is_file() and p.name.lower() == "ctimage.xml"), None)
        if xml_path is None:
            return []
        sonication_dirs = {
            int(match.group(1)): directory
            for directory in workspace.rglob("*")
            if directory.is_dir() and (match := re.fullmatch(r"sonication[_-]?(\d+)", directory.name, re.I))
        }
        assets: list[PlanningAsset] = []
        try:
            from src.parsers.ado_rowset import parse_ado_rowset
            rows = parse_ado_rowset(xml_path)
        except (ET.ParseError, OSError, ValueError):
            return []
        for row in rows:
            try:
                field = int(row.get("fieldindex", -1)); son = int(row.get("sonicationindex", -1))
                zone = int(row.get("zoneindex", 0)); arr = int(row.get("arrayindex", 0))
                sx = int(row.get("imagesize_x", 0)); sy = int(row.get("imagesize_y", 0))
            except (TypeError, ValueError):
                continue
            # This export's planning CT families are 512 x 512.  Exclude the
            # 256 x 256 TMAP/MR replay families that were previously mislabeled CT.
            if sx != 512 or sy != 512:
                continue
            folder = sonication_dirs.get(son)
            if folder is None:
                continue
            candidates = [
                folder / f"{field}-1-{zone}-{arr}.raw",
                folder / f"{field}-1-0-{arr}.raw",
                folder / f"{field}-0-{zone}-{arr}.raw",
                folder / f"{field}-0-0-{arr}.raw",
            ]
            raw = next((candidate for candidate in candidates if candidate.exists()), None)
            if raw is None:
                continue
            elements = sx * sy
            if raw.stat().st_size != elements * 2:
                continue
            dtype = "<i2" if field == 16 else "<u2"
            role = "Planning CT (signed CT/HU volume)" if field == 16 else f"Planning CT derived image (field {field})"
            confidence = 0.995 if field == 16 else 0.92
            assets.append(PlanningAsset(
                "PLANNING_CT", raw, role, confidence,
                f"CtImage row field={field}, sonication={son}, zone={zone}, array={arr}, {sx}x{sy}, dtype={dtype}",
                sx, sy, dtype, field, son, zone, arr,
            ))
        unique: dict[Path, PlanningAsset] = {asset.path: asset for asset in assets}
        return sorted(unique.values(), key=lambda item: (
            0 if item.field_index == 16 else 1,
            item.field_index or 999, item.sonication_index or 999, item.array_index or 0,
        ))

    @staticmethod
    def _plane_from_direction_cosines(row_direction=None, col_direction=None) -> str:
        """Resolve anatomical plane from exported RAS direction cosines.

        MriImageParams plane codes are not stable across all export generations.
        When description/code evidence is unavailable, use the image normal
        (row x column) in patient RAS coordinates.  Dominant X/Y/Z normal means
        Sagittal/Coronal/Axial respectively.  Sign does not affect plane identity.
        """
        try:
            rx, ry, rz = (float(v) for v in row_direction)
            cx, cy, cz = (float(v) for v in col_direction)
        except (TypeError, ValueError, OverflowError):
            return 'Unknown'
        nx = ry * cz - rz * cy
        ny = rz * cx - rx * cz
        nz = rx * cy - ry * cx
        mag2 = nx * nx + ny * ny + nz * nz
        if mag2 < 1e-8:
            return 'Unknown'
        axis = max(range(3), key=lambda i: abs((nx, ny, nz)[i]))
        return ('Sag', 'Cor', 'Ax')[axis]

    @classmethod
    def _plane_from_description(cls, description: str, imgplane=None, seriesplane=None,
                                row_direction=None, col_direction=None) -> str:
        low=(description or '').lower()
        if 'sag' in low: return 'Sag'
        if 'cor' in low: return 'Cor'
        if 'ax' in low or 'axial' in low: return 'Ax'

        # Known GE/FUS codes remain authoritative when present.  Other export
        # generations use different numeric values (for example imgplane=2), so
        # unknown codes must not force the image into PLANNING_MR_UNKNOWN.
        for value in (imgplane, seriesplane):
            try:
                code = int(value)
            except (TypeError, ValueError):
                continue
            known = {18:'Ax',20:'Sag',24:'Cor'}.get(code)
            if known:
                return known

        return cls._plane_from_direction_cosines(row_direction, col_direction)

    def _series_data_items(self, workspace: Path) -> list[dict]:
        xml_path=next((q for q in workspace.rglob('*') if q.is_file() and q.name.lower()=='seriesdataitem.xml'),None)
        if xml_path is None:
            return []
        try:
            from src.parsers.ado_rowset import parse_ado_rowset
            return list(parse_ado_rowset(xml_path))
        except Exception:
            return []

    @classmethod
    def _series_item_plane(cls, row: dict) -> str:
        try:
            normal=(
                float(row.get("imgnormalx")),
                float(row.get("imgnormaly")),
                float(row.get("imgnormalz")),
            )
            axis=max(range(3),key=lambda i:abs(normal[i]))
            return ("Sag","Cor","Ax")[axis]
        except Exception:
            return "Unknown"

    @classmethod
    def _match_series_data_item(cls, items: list[dict], series_number: int, plane: str) -> dict | None:
        candidates=[]
        for item in items:
            try:
                if int(item.get("seriesnumber",-999)) != int(series_number):
                    continue
            except Exception:
                continue
            item_plane=cls._series_item_plane(item)
            score=0
            if plane!="Unknown" and item_plane==plane:
                score+=100
            try:
                image_total=int(item.get("imagetotal",-999))
                if image_total >= 0:
                    score+=10
            except Exception:
                pass
            candidates.append((score,item))
        if not candidates:
            return None
        candidates.sort(key=lambda pair:-pair[0])
        return candidates[0][1]

    def _mr_linked_raws(self, workspace: Path) -> list[PlanningAsset]:
        """Map Sonication1 RAW planning MR families to MriImageParams semantics.

        The export contains both historical preplanning orthogonal MR and the
        treatment-day 3-D/reformatted planning MR.  They must not be mixed with
        TMAP treatment magnitude/thermal frames.
        """
        xml_path=next((q for q in workspace.rglob('*') if q.is_file() and q.name.lower()=='mriimageparams.xml'),None)
        if xml_path is None: return []
        try:
            from src.parsers.ado_rowset import parse_ado_rowset
            rows=parse_ado_rowset(xml_path)
        except Exception:
            return []
        son1=next((q for q in workspace.rglob('*') if q.is_dir() and q.name.lower().replace('_','')=='sonication1'),None)
        if son1 is None: return []
        assets=[]
        seen=set()
        series_items=self._series_data_items(workspace)
        for row in rows:
            try:
                son=int(row.get('sonicationindex',-1)); field=int(row.get('fieldindex',-1)); arr=int(row.get('arrayindex',0)); zone=int(row.get('zoneindex',0))
                sx=int(row.get('imgmatrixx',0)); sy=int(row.get('imgmatrixy',0)); series=int(row.get('imgseriesnum',0) or 0)
            except (TypeError,ValueError):
                continue
            if son != 1 or sx != 512 or sy != 512 or field == 16:
                continue
            desc=str(row.get('seriesdiscription','') or '')
            if 'tmap' in desc.lower():
                continue
            def fv(key):
                try: return float(row.get(key))
                except (TypeError,ValueError): return None
            rd=tuple(fv(k) or 0.0 for k in ('rowdirectcosrasx','rowdirectcosrasy','rowdirectcosrasz'))
            cd=tuple(fv(k) or 0.0 for k in ('coldirectcosrasx','coldirectcosrasy','coldirectcosrasz'))
            plane=self._plane_from_description(
                desc,row.get('imgplane'),row.get('seriesplane'),rd,cd
            )
            candidates=[son1/f"{field}-1-{zone}-{arr}.raw",son1/f"{field}-1-0-{arr}.raw",son1/f"{field}-0-{zone}-{arr}.raw",son1/f"{field}-0-0-{arr}.raw"]
            raw=next((q for q in candidates if q.is_file()),None)
            if raw is None or raw in seen: continue
            seen.add(raw)
            # SeriesDataItem is the authoritative export source for study role.
            # In validated Brain exports:
            #   studytype=0 -> treatment-day Planning MR set
            #   studytype=1 -> Preplanning MR set
            #   studytype=2 -> CT set
            # and seriestype identifies the saved orthogonal member of that study.
            sdi=self._match_series_data_item(series_items,series,plane)
            study_type=None; series_type=None; study_uid=None
            if sdi is not None:
                try:study_type=int(sdi.get("studytype"))
                except Exception:study_type=None
                try:series_type=int(sdi.get("seriestype"))
                except Exception:series_type=None
                study_uid=str(sdi.get("studyinstanceuid","") or "")
            if study_type==0:
                planning_day=True
            elif study_type==1:
                planning_day=False
            else:
                # Compatibility fallback only when SeriesDataItem is missing.
                planning_day=('bravo' in desc.lower()) or series>=700

            category=f"PLANNING_MR_{plane.upper()}" if planning_day else f"PREPLANNING_MR_{plane.upper()}"
            if planning_day and series_type==0:
                source_kind="Exported original 3D series"
            elif planning_day and series_type in (1,2):
                source_kind="Exported saved reformat"
            elif not planning_day:
                source_kind="Exported preplanning series"
            else:
                source_kind="Exported MR series"
            role=("Treatment-day planning MR" if planning_day else "Preplanning MR") + f" {plane} · {source_kind}"
            assets.append(PlanningAsset(
                category,raw,role,0.995 if sdi is not None else 0.98,
                f"MriImageParams field={field}, series={series}, description={desc}, plane={plane}, array={arr}; "
                f"SeriesDataItem studytype={study_type}, seriestype={series_type}, source={source_kind}",
                sx,sy,'<u2',field,son,zone,arr,plane,desc,series,fv('pixsizex'),fv('pixsizey'),fv('topleftcoordr'),fv('topleftcoorda'),fv('topleftcoords'),rd,cd,
                study_type,series_type,source_kind,study_uid
            ))
        return sorted(assets,key=lambda a:(a.category,a.series_number or 0,a.array_index or 0))

    def discover(self, workspace: Path) -> PlanningDataSummary:
        assets: list[PlanningAsset] = []
        assets.extend(self._ct_linked_raws(workspace))
        assets.extend(self._mr_linked_raws(workspace))
        son1 = next((p for p in workspace.rglob("*") if p.is_dir() and p.name.lower().replace("_", "") == "sonication1"), None)
        known_paths={a.path for a in assets}

        for path in workspace.rglob("*"):
            if not path.is_file():
                continue
            low_name = path.name.lower()
            low_path = str(path).lower().replace("\\", "/")
            category = role = notes = ""
            confidence = 0.0

            if low_name in {"ctimage.xml", "ctvolumedata.xml"}:
                category, role, confidence = "PLANNING_METADATA", "CT volume metadata used by skull/SDR planning", 1.0
            elif "skullmeasure" in low_name or "bonespot" in low_name or "sdr" in low_name:
                category, role, confidence = "SDR_DATA", "Skull/SDR calculation input or result", 0.95
            elif low_name.startswith("ctmr") or "ctmrregistration" in low_name:
                category, role, confidence = "REGISTRATION_DATA", "CT-to-MR registration", 0.98
            elif low_name.startswith("mrmr") or "mrmrregistration" in low_name:
                category, role, confidence = "REGISTRATION_DATA", "MR-to-MR registration", 0.98
            elif low_name == "mriimageparams.xml" or "mi_params" in low_name or low_name.startswith("miparams"):
                category, role, confidence = "PRE_TREATMENT_MR", "MR acquisition/reference metadata", 0.90
            elif "/sonication1/" in low_path and self._RAW_RE.match(path.name) and path not in known_paths:
                prefix = self._RAW_RE.match(path.name).group(1)
                if prefix not in {"5", "6", "16"}:
                    category, role, confidence = "PRE_TREATMENT_MR", f"Unclassified Sonication1 MR RAW series (prefix {prefix})", 0.65
                    notes = "Not assigned to preplanning/planning orthogonal groups because MriImageParams mapping was unavailable."
            elif son1 is not None and path.parent == son1 and path.suffix.lower() in {".rgs", ".txt"} and ("fid" in low_name or "mat" in low_name):
                category, role, confidence = "REGISTRATION_DATA", "Planning registration matrix/fiducials", 0.90

            if category:
                assets.append(PlanningAsset(category, path, role, confidence, notes))

        def _asset_sort_key(item: PlanningAsset):
            # Keep the verified signed CT/HU stack (field 16) first and preserve
            # numeric slice order.  The previous final lexical sort silently
            # destroyed _ct_linked_raws() ordering, so field 12 appeared first
            # and slices such as 100 were placed before 11.
            if item.category == "PLANNING_CT":
                field_priority = 0 if item.field_index == 16 else 1
                return (
                    0,
                    field_priority,
                    item.field_index if item.field_index is not None else 999,
                    item.sonication_index if item.sonication_index is not None else 999,
                    item.zone_index if item.zone_index is not None else 999,
                    item.array_index if item.array_index is not None else 999999,
                    str(item.path).lower(),
                )
            return (1, item.category, 0, 0, 0, 0, str(item.path).lower())

        assets.sort(key=_asset_sort_key)
        return PlanningDataSummary(assets)
