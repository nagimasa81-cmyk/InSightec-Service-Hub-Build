from __future__ import annotations

from dataclasses import dataclass
import math
import numpy as np


@dataclass(slots=True)
class CavitationTrend:
    time_s: np.ndarray
    subharmonic_db: np.ndarray
    ultraharmonic_db: np.ndarray
    broadband_db: np.ndarray
    cavitation_index_db: np.ndarray
    main_frequency_hz: float
    selected_channels: tuple[str, ...]


class CavitationVisualizationService:
    """Derive conservative spectrum-based cavitation indicators for visualization.

    R0118: the band-integration/dB helpers below are the *canonical* physical
    definition of "sub-harmonic energy" for this codebase.  Other services
    (e.g. per-frame sub-harmonic event detection on CpcHydrophoneReplay) call
    the public wrappers instead of re-deriving their own frequency-window or
    dB-conversion formula, so the two views of "is there a sub-harmonic"
    cannot silently disagree about what a sub-harmonic even is.
    """

    @staticmethod
    def fundamental_window_hz(main_frequency_hz: float) -> float:
        """Canonical half-width (Hz) of the band integrated around f0."""
        return max(5000.0, 0.04 * float(main_frequency_hz))

    @staticmethod
    def subharmonic_window_hz(main_frequency_hz: float) -> float:
        """Canonical half-width (Hz) of the band integrated around f0/2 (or 1.5*f0)."""
        return max(4000.0, 0.035 * float(main_frequency_hz))

    @staticmethod
    def band_energy(freq_hz, amp, low_hz: float, high_hz: float) -> float:
        """Public alias of the canonical band-integrated energy definition."""
        return CavitationVisualizationService._band_energy(freq_hz, amp, low_hz, high_hz)

    @staticmethod
    def energy_ratio_db(value: float, ref: float) -> float:
        """Public alias of the canonical power-ratio dB conversion (10*log10)."""
        return CavitationVisualizationService._db(value, ref)

    @staticmethod
    def _band_energy(freq_hz, amp, low_hz, high_hz):
        freq_hz=np.asarray(freq_hz,float); amp=np.asarray(amp,float)
        mask=(freq_hz>=low_hz)&(freq_hz<=high_hz)&np.isfinite(amp)
        if not np.any(mask): return float('nan')
        return float(np.trapezoid(np.maximum(amp[mask],0.0),freq_hz[mask]))

    @staticmethod
    def _broadband(freq_hz, amp, main_hz):
        freq_hz=np.asarray(freq_hz,float); amp=np.asarray(amp,float)
        mask=(freq_hz>=0.20*main_hz)&(freq_hz<=0.90*main_hz)&np.isfinite(amp)
        width=max(4000.0,0.03*main_hz)
        for center in (0.5*main_hz, main_hz): mask &= np.abs(freq_hz-center)>width
        if not np.any(mask): return float('nan')
        return float(np.trapezoid(np.maximum(amp[mask],0.0),freq_hz[mask]))

    @staticmethod
    def _db(value, ref):
        if not (math.isfinite(value) and math.isfinite(ref)) or value<=0 or ref<=0: return float('nan')
        return float(10*np.log10(value/ref))

    @staticmethod
    def _map(index,replay_count,data_count):
        if data_count<=1 or replay_count<=1: return 0
        return max(0,min(int(round(index*(data_count-1)/(replay_count-1))),data_count-1))

    def compute(self, spectrum_channels, selected_channels, main_frequency_hz, replay_count, duration_s):
        main_hz=float(main_frequency_hz or 0.0)
        channels=[c for c in selected_channels if spectrum_channels.get(c)]
        if main_hz<=0 or replay_count<=0 or not channels: return None
        sub=np.full(replay_count,np.nan); ultra=np.full(replay_count,np.nan); broad=np.full(replay_count,np.nan); total=np.full(replay_count,np.nan)
        mw=self.fundamental_window_hz(main_hz); sw=self.subharmonic_window_hz(main_hz)
        for ri in range(replay_count):
            mains=[]; subs=[]; ultras=[]; broads=[]
            for channel in channels:
                frames=spectrum_channels.get(channel) or []
                if not frames: continue
                frame=frames[self._map(ri,replay_count,len(frames))]
                f=np.asarray(getattr(frame,'frequency',[]),float); a=np.asarray(getattr(frame,'amplitude',[]),float)
                if not f.size or not a.size: continue
                vals=(self._band_energy(f,a,main_hz-mw,main_hz+mw), self._band_energy(f,a,.5*main_hz-sw,.5*main_hz+sw), self._band_energy(f,a,1.5*main_hz-sw,1.5*main_hz+sw), self._broadband(f,a,main_hz))
                for bucket,value in zip((mains,subs,ultras,broads),vals):
                    if math.isfinite(value): bucket.append(value)
            ref=float(np.mean(mains)) if mains else float('nan')
            s=float(np.mean(subs)) if subs else float('nan'); u=float(np.mean(ultras)) if ultras else float('nan'); b=float(np.mean(broads)) if broads else float('nan')
            sub[ri]=self._db(s,ref); ultra[ri]=self._db(u,ref); broad[ri]=self._db(b,ref)
            combined=sum(v for v in (s,u,b) if math.isfinite(v)); total[ri]=self._db(combined,ref)
        time=np.linspace(0.0,max(0.0,float(duration_s)),replay_count) if replay_count>1 else np.asarray([0.0])
        return CavitationTrend(time,sub,ultra,broad,total,main_hz,tuple(channels))
