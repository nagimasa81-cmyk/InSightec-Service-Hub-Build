from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re
import xml.etree.ElementTree as ET
import numpy as np

from src.parsers.ado_rowset import parse_ado_rowset


@dataclass(slots=True)
class SonicationMetadata:
    summary: dict[str, str] = field(default_factory=dict)
    mr: list[tuple[str, str]] = field(default_factory=list)
    scan: list[tuple[str, str]] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)


class SonicationMetadataService:
    """Resolve display metadata from the full export, not only the Sonication folder."""

    def __init__(self):
        self._workspace_file_cache: dict[Path, list[Path]] = {}
        self._text_file_cache: dict[Path, list[Path]] = {}

    DQA_FALLBACK = {
        1: ("Axial", "A/P", "R/L"),
        2: ("Sagittal", "A/P", "S/I"),
        3: ("Axial", "R/L", "A/P"),
    }


    def _row_for_sonication(self, path: Path, sonication_number: int) -> dict[str, object]:
        """Return only a real ADO z:row for the requested sonication."""
        if not path.exists():
            return {}
        try:
            rows = parse_ado_rowset(path)
        except (ET.ParseError, OSError, ValueError):
            return {}
        keys = ("sonicationindex", "sonication", "sonicationnumber", "sonicationno", "index")
        matched: list[dict[str, object]] = []
        for row in rows:
            for key in keys:
                value = row.get(key)
                try:
                    if value is not None and int(float(value)) == int(sonication_number):
                        matched.append(row)
                        break
                except (TypeError, ValueError):
                    continue
        if matched:
            # One sonication can contain placeholder rows plus many MR acquisitions.
            # Prefer the treatment thermometry/MEMP row with real direction cosines
            # instead of blindly taking the first row (often an empty fieldindex=9
            # placeholder, which caused Orientation/Frequency Dir to become Unknown).
            def quality(row: dict[str, object]) -> tuple[int, int, int, int]:
                series = str(row.get("seriesdiscription") or row.get("seriesdescription") or "").upper()
                treatment = int(any(token in series for token in ("MEMP", "TMAP", "THERM")))
                freq = int(bool(str(row.get("freqdirection") or "").strip()))
                matrix = int(float(row.get("imgmatrixx") or -1) > 0)
                try:
                    r = np.asarray([float(row.get(k, 0.0)) for k in ("rowdirectcosrasx", "rowdirectcosrasy", "rowdirectcosrasz")])
                    c = np.asarray([float(row.get(k, 0.0)) for k in ("coldirectcosrasx", "coldirectcosrasy", "coldirectcosrasz")])
                    cosines = int(np.linalg.norm(r) > 0.5 and np.linalg.norm(c) > 0.5 and np.linalg.norm(np.cross(r, c)) > 0.5)
                except (TypeError, ValueError):
                    cosines = 0
                return (treatment, cosines, freq, matrix)
            return max(matched, key=quality)
        # Some ADO exports store rows strictly in sonication order without an index column.
        data_rows = [row for row in rows if any(k in row for k in ("seriesuid", "name", "poweron", "sonicationduration", "imgmatrixx"))]
        index = int(sonication_number) - 1
        return data_rows[index] if 0 <= index < len(data_rows) else {}

    @staticmethod
    def _orientation_from_cosines(row: dict[str, object]) -> str | None:
        try:
            r = np.asarray([float(row[k]) for k in ("rowdirectcosrasx", "rowdirectcosrasy", "rowdirectcosrasz")])
            c = np.asarray([float(row[k]) for k in ("coldirectcosrasx", "coldirectcosrasy", "coldirectcosrasz")])
        except (KeyError, TypeError, ValueError):
            return None
        n = np.cross(r, c)
        if not np.all(np.isfinite(n)) or np.linalg.norm(n) < 1e-6:
            return None
        axis = int(np.argmax(np.abs(n)))
        return ("Sagittal", "Coronal", "Axial")[axis]

    @staticmethod
    def _patient_axis_from_vector(vector) -> str | None:
        """Return the dominant anatomical patient axis without inferring polarity.

        Direction-cosine signs vary with image ordering and coordinate convention,
        so the basic UI intentionally reports the anatomical *axis* (RL/AP/SI)
        rather than a one-way R/L/A/P/S/I direction.
        """
        try:
            v = np.asarray(vector, dtype=float)
        except (TypeError, ValueError):
            return None
        if v.size != 3 or not np.all(np.isfinite(v)) or np.linalg.norm(v) < 1e-6:
            return None
        return ("RL", "AP", "SI")[int(np.argmax(np.abs(v)))]

    @classmethod
    def _row_col_patient_axes(cls, row: dict[str, object]) -> tuple[str | None, str | None]:
        try:
            r = [float(row[k]) for k in ("rowdirectcosrasx", "rowdirectcosrasy", "rowdirectcosrasz")]
            c = [float(row[k]) for k in ("coldirectcosrasx", "coldirectcosrasy", "coldirectcosrasz")]
        except (KeyError, TypeError, ValueError):
            return None, None
        return cls._patient_axis_from_vector(r), cls._patient_axis_from_vector(c)

    @classmethod
    def _frequency_direction_display(cls, row: dict[str, object], value) -> str:
        """Resolve ROW/COL to an anatomical axis and retain ROW/COL for traceability.

        Example: ``RL (ROW)``.  We never assume ROW/COL from the plane alone;
        the anatomical part is emitted only when direction cosines support it.
        """
        if value is None or not str(value).strip():
            return "Unavailable"
        raw = str(value).strip().upper().replace(" ", "")
        raw = {"R/L":"RL", "L/R":"RL", "A/P":"AP", "P/A":"AP", "S/I":"SI", "I/S":"SI"}.get(raw, raw)
        row_axis, col_axis = cls._row_col_patient_axes(row)
        if raw == "ROW":
            return f"{row_axis} (ROW)" if row_axis else "ROW"
        if raw in {"COL", "COLUMN"}:
            return f"{col_axis} (COL)" if col_axis else "COL"
        if raw in {"RL", "AP", "SI"}:
            # Older exports may already encode the anatomical axis directly.
            return raw
        return raw


    @staticmethod
    def _format_mr_time_ms(value) -> str:
        try:
            v=float(value)
        except (TypeError,ValueError):
            return "Unavailable"
        if not np.isfinite(v):
            return "Unavailable"
        # GE export MriImageParams stores TR/TE in microseconds in this dataset
        # (e.g. 28000 -> 28.0 ms, 3128 -> 3.128 ms).  Smaller values are already ms.
        ms=v/1000.0 if abs(v) >= 1000.0 else v
        return f"{ms:.3f}".rstrip("0").rstrip(".") + " ms"

    @staticmethod
    def _format_bandwidth(value) -> str:
        try:
            v=float(value)
        except (TypeError,ValueError):
            return "Unavailable"
        if not np.isfinite(v):
            return "Unavailable"
        return f"{v:.3f} kHz"

    @staticmethod
    def _direction_letter(vector, *, positive=True) -> str | None:
        try:
            v=np.asarray(vector,dtype=float)
        except (TypeError,ValueError):
            return None
        if v.size != 3 or not np.all(np.isfinite(v)) or np.linalg.norm(v) < 1e-6:
            return None
        i=int(np.argmax(np.abs(v))); sign=float(v[i]) >= 0.0
        if not positive: sign=not sign
        pos=("R","A","S")[i]; neg=("L","P","I")[i]
        return pos if sign else neg

    @classmethod
    def _image_annotation_geometry(cls, row: dict[str, object]) -> dict[str,str]:
        out={}
        try:
            rv=np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")],float)
            cv=np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")],float)
            # R0133 REAL-DATA FIX: the treatment RAW raster presented by this app
            # uses the exported COLUMN direction on screen X and the exported ROW
            # direction on screen Y.  The prior row->X / col->Y assumption rotated
            # all edge annotations by 90 degrees.  Keep image pixels unchanged and
            # map metadata to the already-displayed raster instead.
            out["Right Direction"]=cls._direction_letter(cv,positive=True) or "Unavailable"
            out["Left Direction"]=cls._direction_letter(cv,positive=False) or "Unavailable"
            out["Bottom Direction"]=cls._direction_letter(rv,positive=True) or "Unavailable"
            out["Top Direction"]=cls._direction_letter(rv,positive=False) or "Unavailable"
            tl=np.asarray([float(row[k]) for k in ("topleftcoordr","topleftcoorda","topleftcoords")],float)
            cols=int(float(row.get("imgmatrixx") or 0)); rows=int(float(row.get("imgmatrixy") or 0))
            sx=float(row.get("pixsizex") or 0.0); sy=float(row.get("pixsizey") or 0.0)
            if cols>0 and rows>0 and sx>0 and sy>0:
                center=tl + rv*sx*((cols-1)/2.0) + cv*sy*((rows-1)/2.0)
                out["Image Center RAS"]=f"R={center[0]:.1f} A={center[1]:.1f} S={center[2]:.1f} mm"
        except (KeyError,TypeError,ValueError):
            pass
        return out

    @staticmethod
    def _f(row, key):
        try: return float(row[key])
        except (KeyError,TypeError,ValueError): return None

    def read(self, model, package, sonication_number: int) -> SonicationMetadata:
        workspace = Path(package.workspace)
        texts = self._text_files(workspace)
        mr_path=self._find_first(workspace,["MriImageParams.xml","MRIImageParams.xml"])
        protocol_path=self._find_first(workspace,["ProtocolData.xml"])
        mr_row=self._row_for_sonication(mr_path,sonication_number) if mr_path else {}
        protocol_row=self._row_for_sonication(protocol_path,sonication_number) if protocol_path else {}
        sources: list[str] = []

        orientation_text = self._search(texts, [r"(?:Scan\s*Plane|Orientation|Plane)\s*[:=]\s*([A-Za-z/]+)"])
        freq_text = self._search(texts, [r"(?:Frequency\s*(?:Dir|Direction)|FreqDir)\s*[:=]\s*([A-Za-z/]+)"])
        orientation_cosines = self._orientation_from_cosines(mr_row)
        hotspot = "Unavailable"
        fallback_orientation = fallback_freq_dir = None
        if sonication_number in self.DQA_FALLBACK:
            fallback_orientation, fallback_freq_dir, hotspot = self.DQA_FALLBACK[sonication_number]

        target_power = model.planned_power_w
        actual_power = model.actual_power_w
        target_duration = model.planned_duration_s
        if target_duration is None:
            target_duration = self._f(protocol_row, "sonicationduration")
        actual_duration = model.actual_duration_s
        target_energy = model.planned_energy_j
        if target_energy is None and target_power is not None and target_duration is not None:
            target_energy = target_power * target_duration
        actual_energy = model.actual_energy_j
        if actual_energy is None and actual_power is not None and actual_duration is not None:
            actual_energy = actual_power * actual_duration

        # Read the sonication frequency discovered from treatment files.
        # Sonication-local ACT/INI/XML/TXT settings are preferred by
        # DiscoveryService; package-level Xd_*.ini is used only as fallback.
        sonication_frequency_hz = model.main_frequency_hz

        # Per-sonication MR rows are authoritative when present.  Global text-log
        # fallbacks are intentionally used only when no indexed MR row exists;
        # otherwise an unrelated "Orientation: X" line from another subsystem
        # can overwrite the real treatment plane.
        orientation = orientation_cosines or (orientation_text if not mr_row else None) or fallback_orientation
        freq_dir = mr_row.get("freqdirection") or (freq_text if not mr_row else None) or fallback_freq_dir
        # Basic display uses patient-anatomical axes first and retains DICOM
        # ROW/COL in parentheses for traceability (e.g. RL (ROW)).
        freq_dir_display = self._frequency_direction_display(mr_row, freq_dir)
        raw_freq = str(freq_dir or "").strip().upper().replace(" ", "")
        freq_encoding = "ROW" if raw_freq == "ROW" else ("COL" if raw_freq in {"COL", "COLUMN"} else "")
        summary = {
            "Orientation": self._normal(orientation),
            "Frequency Dir": freq_dir_display,
            # Preserve the actual acquisition ROW/COL token for screen-direction
            # rendering.  Do not infer horizontal/vertical from anatomical labels.
            "Frequency Encoding": freq_encoding,
            "Target Energy": f"{target_energy:.1f} J" if target_energy is not None else "Unavailable",
            "Actual Energy": f"{actual_energy:.1f} J" if actual_energy is not None else "Unavailable",
            "Target Power": f"{target_power:.1f} W" if target_power is not None else "Unavailable",
            "Actual Power": f"{actual_power:.1f} W" if actual_power is not None else "Unavailable",
            "Target Duration": f"{target_duration:.3f} s" if target_duration is not None else "Unavailable",
            "Actual Duration": f"{actual_duration:.3f} s" if actual_duration is not None else "Unavailable",
            "Frequency": f"{sonication_frequency_hz/1e6:.3f} MHz" if sonication_frequency_hz is not None else "Unavailable",
            "Hotspot Check": hotspot,
            "MR Protocol": str(mr_row.get("seriesdiscription") or protocol_row.get("name") or "Unavailable"),
            "TR": self._format_mr_time_ms(mr_row.get("repetitiontimetr")),
            "TE": self._format_mr_time_ms(mr_row.get("echotimete")),
            "Bandwidth": self._format_bandwidth(mr_row.get("varbandwidth")),
        }
        summary.update(self._image_annotation_geometry(mr_row))

        review = self._find_first(workspace, ["review.out", "review.out.ar"])
        review_text = self._read(review) if review else ""
        if review: sources.append(str(review))
        mr = self._review_rows(review_text)
        xml_mr=[("Series Description",mr_row.get("seriesdiscription")),("Manufacturer",mr_row.get("manufacturer")),("Matrix",f"{mr_row.get('imgmatrixx','?')} x {mr_row.get('imgmatrixy','?')}"), ("Slice Thickness",mr_row.get("slicethick")),("Pixel Size",f"{mr_row.get('pixsizex','?')} x {mr_row.get('pixsizey','?')}"),("TR",summary["TR"]),("TE",summary["TE"]),("Bandwidth",summary["Bandwidth"]),("Flip Angle",mr_row.get("mrflipangle")),("Frequency Direction",summary["Frequency Dir"]),("Series UID",mr_row.get("seriesuid"))]
        # Frequency Direction must use the canonical anatomical + ROW/COL
        # representation even if review.out contains a legacy raw ROW/COL value.
        mr = [(k, v) for k, v in mr if k != "Frequency Direction"]
        existing={k for k,_ in mr}
        mr.extend((k,str(v)) for k,v in xml_mr if v not in (None,"") and k not in existing)
        if not mr:
            mr = [("Status", "MR information was not decoded from review.out")]
        mr.extend([
            ("Replay Orientation", summary["Orientation"]),
            ("Frequency Direction", summary["Frequency Dir"]),
            ("Temperature RAW Frames", str(len(model.temperature_frames))),
            ("Magnitude RAW Frames", str(len(model.magnitude_frames))),
        ])

        act = model.act_files[0] if model.act_files else None
        if act: sources.append(str(act))
        scan = [
            ("Protocol Name", protocol_row.get("name","Unavailable")),
            ("SVAT Protocol", protocol_row.get("svatprotocolname","Unavailable")),
            ("Planned Power %", f"{protocol_row.get('poweron')} %" if protocol_row.get("poweron") is not None else "Unavailable"),
            ("Planned Duration", protocol_row.get("sonicationduration","Unavailable")),
            ("Cooling Duration", protocol_row.get("coolingdurationl","Unavailable")),
            ("Dose Threshold", protocol_row.get("dosetreshold","Unavailable")),
            ("Spot Diameter", protocol_row.get("spotdiameter","Unavailable")),
            ("Sonication", str(sonication_number)),
            ("Orientation", summary["Orientation"]),
            ("Frequency Direction", summary["Frequency Dir"]),
            ("Hotspot Check Direction", hotspot),
            ("Target Power", summary["Target Power"]),
            ("Actual Power", summary["Actual Power"]),
            ("Target Duration", summary["Target Duration"]),
            ("Actual Duration", summary["Actual Duration"]),
            ("Target Energy", summary["Target Energy"]),
            ("Actual Energy", summary["Actual Energy"]),
            ("Transducer Frequency", summary["Frequency"]),
            ("ACT File", act.name if act else "Unavailable"),
            ("ACT Elements", self._act_element_count(act)),
            ("SpectrumMsg Files", str(len(model.spectrum_files))),
            ("Temperature RAW Frames", str(len(model.temperature_frames))),
        ]
        return SonicationMetadata(summary=summary, mr=mr, scan=scan, sources=sources)

    def _workspace_files(self, workspace: Path) -> list[Path]:
        workspace=Path(workspace)
        cached=self._workspace_file_cache.get(workspace)
        if cached is None:
            cached=[p for p in workspace.rglob("*") if p.is_file()]
            self._workspace_file_cache[workspace]=cached
        return cached

    def _text_files(self, workspace: Path):
        workspace=Path(workspace)
        cached=self._text_file_cache.get(workspace)
        if cached is None:
            cached=[p for p in self._workspace_files(workspace) if p.suffix.lower() in {".log", ".txt", ".act", ".ini"} or p.name.lower().startswith("review.out")]
            self._text_file_cache[workspace]=cached
        return cached

    def _search(self, paths, patterns):
        compiled=[re.compile(p,re.I) for p in patterns]
        for path in paths:
            text=self._read(path)
            for pattern in compiled:
                m=pattern.search(text)
                if m: return m.group(1).strip()
        return None

    def _find_first(self, root: Path, names):
        lower=[n.lower() for n in names]
        order={name:i for i,name in enumerate(lower)}
        matches=[p for p in self._workspace_files(Path(root)) if p.name.lower() in order]
        return sorted(matches, key=lambda p:(order.get(p.name.lower(),99), len(p.parts)))[0] if matches else None

    def _read(self, path):
        if not path: return ""
        try: return path.read_text(encoding="utf-8", errors="ignore")
        except OSError: return ""

    def _review_rows(self, text: str):
        if not text: return []
        specs = [
            ("Scanner Mode", r"Scanner Mode\s*:\s*([^\t\r\n]+)"),
            ("Patient Position", r"Position\s*:\s*([^\t\r\n]+)"),
            ("Coil Name", r"Coil Name\s*:\s*([^\t\r\n]+)"),
            ("Protocol", r"Protocol\s*:\s*([^\t\r\n]+)"),
            ("Series Description", r"Series De\s*:\s*([^\t\r\n]+)"),
            ("PSD Name", r"Psd Name\s*:\s*([^\t\r\n]+)"),
            ("TE", r"Echo Time \(TE\)\s*:\s*([^\t\r\n]+)"),
            ("TR", r"Rep Time \(TR\)\s*:\s*([^\t\r\n]+)"),
            ("FOV", r"Field of View\s*:\s*([^\t\r\n]+)"),
            ("Slice Thickness", r"Slice Thickness\s*:\s*([^\t\r\n]+)"),
            ("Acquisition Matrix", r"Acq\. Matrix\s*:\s*([^\t\r\n]+)"),
        ]
        rows=[]
        for label, pat in specs:
            m=re.search(pat,text,re.I)
            if m: rows.append((label, re.sub(r"\s+", " ", m.group(1)).strip()))
        return rows

    def _act_element_count(self, path):
        text=self._read(path)
        m=re.search(r"NumberOfElements\s*=\s*(\d+)",text,re.I)
        return m.group(1) if m else "Unavailable"

    def _normal(self, value):
        if not value: return "Unavailable"
        v=value.strip().replace("SAGITAL","SAGITTAL")
        return v.title()

    def _normal_dir(self, value):
        return value.strip().upper() if value else "Unavailable"
