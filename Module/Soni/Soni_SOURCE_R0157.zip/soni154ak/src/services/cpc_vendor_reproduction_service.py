from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import math
import re

import numpy as np


@dataclass(slots=True)
class VendorBand:
    index: int
    ratio: float
    delta_hz: float
    low_hz: float
    high_hz: float


@dataclass(slots=True)
class VendorRule:
    name: str
    weights: np.ndarray
    limit: float | None = None


@dataclass(slots=True)
class VendorControlRule:
    family: str
    index: int
    weights: np.ndarray
    threshold: float | None = None
    power_ratio: float | None = None
    critical_threshold: float | None = None
    max_failures: int | None = None
    critical_failures: int | None = None
    max_failure_window_ms: float | None = None
    critical_failure_window_ms: float | None = None
    switch_to_subsonication: int | None = None


@dataclass(slots=True)
class VendorControlValidation:
    status: str = "Not validated"
    source_log: Path | None = None
    matched_events: int = 0
    decrease_events: int = 0
    increase_events: int = 0
    mae_power_ratio: float | None = None
    max_abs_error_power_ratio: float | None = None
    event_cycles: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=int))
    actual_power_ratio: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    predicted_power_ratio: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    action_labels: list[str] = field(default_factory=list)
    triggered_rule_labels: list[str] = field(default_factory=list)
    note: str = ""


@dataclass(slots=True)
class VendorCavitationProfile:
    source_ini: Path | None = None
    acquisition_ini: Path | None = None
    bands: list[VendorBand] = field(default_factory=list)
    increase_rule0: VendorRule | None = None
    increase_power_ratio: float | None = None
    display_rules: dict[int, VendorRule] = field(default_factory=dict)
    graph_low_hz: float | None = None
    graph_high_hz: float | None = None
    calculated_e_factor: float | None = None
    decrease_rules: dict[int, VendorControlRule] = field(default_factory=dict)
    safety_rules: dict[int, VendorControlRule] = field(default_factory=dict)
    changing_frequency_safety_rules: dict[int, VendorControlRule] = field(default_factory=dict)
    dynamic_rules: dict[int, VendorControlRule] = field(default_factory=dict)
    cavitation_levels: tuple[float, ...] = ()
    default_cavitation_level: float | None = None
    starting_power_ratio: float | None = None
    error_policy_sw: int | None = None
    error_policy_hw: int | None = None
    stop_on_rtdca: bool | None = None
    ignore_start_ms: float | None = None
    ignore_end_ms: float | None = None


@dataclass(slots=True)
class VendorHistoryValidation:
    status: str = "Not validated"
    source_log: Path | None = None
    matched_samples: int = 0
    correlation: float | None = None
    mae: float | None = None
    max_abs_error: float | None = None
    cycle_offset: int | None = None
    log_session_index: int | None = None
    weighted_history: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    normalized_display_rule1: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    display_rule_histories: dict[int, np.ndarray] = field(default_factory=dict)
    weighted_band_histories_from_log: dict[int, np.ndarray] = field(default_factory=dict)
    sparse_control_rule_histories: dict[int, np.ndarray] = field(default_factory=dict)
    evidence_notes: dict[int, str] = field(default_factory=dict)
    display_rule1_matched_samples: int = 0
    display_rule1_correlation: float | None = None
    display_rule1_mae: float | None = None
    note: str = ""


@dataclass(slots=True)
class AcquisitionBrainParseCache:
    increase0_sessions: list[list[tuple[int, float]]] = field(default_factory=list)
    display_rule_sessions: list[dict[int, list[tuple[int, float]]]] = field(default_factory=list)
    decrease_rule_sessions: list[dict[int, list[tuple[int, float]]]] = field(default_factory=list)
    power_control_sessions: list[list[dict]] = field(default_factory=list)


class CpcVendorReproductionService:
    """Recover vendor band definitions and validate CPC energy histories.

    The 6.33 CPC export carries enough redundant evidence to prove the semantic
    identity of one saved 8-channel history.  The INI defines Band0..Band3 and
    rule weights; Acquisition_Brain logs record the rule's Calculated Energy on
    each acquisition cycle.  If weighted saved history reproduces those logged
    values to floating-point precision, the history can be labelled as vendor
    Band0 energy rather than a generic signal.
    """

    _BAND_RE = re.compile(r"^Bandwidth_(\d+)\s*=\s*([-+0-9.eE]+)\s+([-+0-9.eE]+)", re.I)
    _KV_RE = re.compile(r"^\s*([^;=]+?)\s*=\s*([^;]+)")
    _acq_cache: dict[tuple[str, int, int], AcquisitionBrainParseCache] = {}
    _acq_cache_max_entries = 8

    @staticmethod
    def _find_upwards(start: Path | None, relative_candidates: tuple[str, ...], glob_names: tuple[str, ...] = ()) -> Path | None:
        if start is None:
            return None
        base = Path(start).resolve()
        if base.is_file():
            base = base.parent
        for parent in (base, *base.parents):
            for rel in relative_candidates:
                candidate = parent / rel
                if candidate.exists() and candidate.is_file():
                    return candidate
            for name in glob_names:
                matches = sorted(parent.glob(name))
                if matches:
                    return matches[0]
        return None

    @staticmethod
    def _section(text: str, name: str) -> list[str]:
        lines = text.splitlines()
        target = name.strip().lower()
        active = False
        out: list[str] = []
        for line in lines:
            m = re.match(r"^\s*\[([^]]+)\]", line)
            if m:
                if active:
                    break
                active = m.group(1).strip().lower() == target
                continue
            if active:
                out.append(line)
        return out

    @classmethod
    def _key_value(cls, lines: list[str], key: str) -> str | None:
        key_l = key.lower()
        for line in lines:
            m = cls._KV_RE.match(line)
            if m and m.group(1).strip().lower() == key_l:
                return m.group(2).strip()
        return None

    @staticmethod
    def _numbers(value: str | None) -> list[float]:
        if not value:
            return []
        return [float(v) for v in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?", value)]

    @staticmethod
    def _number_or_none(values: list[float], index: int = 0):
        return values[index] if len(values) > index else None

    def _parse_control_rule(self, text: str, section_name: str, family: str, index: int, weight_key: str, threshold_key: str, power_ratio_key: str | None = None) -> VendorControlRule | None:
        lines = self._section(text, section_name)
        weights = self._numbers(self._key_value(lines, weight_key))
        if len(weights) < 32:
            return None
        threshold = self._number_or_none(self._numbers(self._key_value(lines, threshold_key)))
        power_ratio = self._number_or_none(self._numbers(self._key_value(lines, power_ratio_key))) if power_ratio_key else None
        critical = self._number_or_none(self._numbers(self._key_value(lines, "CriticalEnergyForAllHydrophones")))
        max_failures = self._number_or_none(self._numbers(self._key_value(lines, "NumOfMaximumTestAllowedFailures")))
        critical_failures = self._number_or_none(self._numbers(self._key_value(lines, "NumOfCriticalTestAllowedFailures")))
        max_window = self._number_or_none(self._numbers(self._key_value(lines, "TimeOfMaximumTestAllowedFailures")))
        critical_window = self._number_or_none(self._numbers(self._key_value(lines, "TimeOfCriticalTestAllowedFailures")))
        switch = self._number_or_none(self._numbers(self._key_value(lines, "SwitchToSubSonicationNumber")))
        return VendorControlRule(
            family=family, index=index, weights=np.asarray(weights[:32], float).reshape(8,4),
            threshold=threshold, power_ratio=power_ratio, critical_threshold=critical,
            max_failures=int(max_failures) if max_failures is not None else None,
            critical_failures=int(critical_failures) if critical_failures is not None else None,
            max_failure_window_ms=max_window, critical_failure_window_ms=critical_window,
            switch_to_subsonication=int(switch) if switch is not None else None,
        )

    def read_profile(self, source_path: Path | None, main_frequency_hz: float) -> VendorCavitationProfile:
        profile = VendorCavitationProfile()
        safety = self._find_upwards(
            source_path,
            ("Site/Ini/CavitationSafetyAndControl.ini", "CPCFiles/Site/Ini/CavitationSafetyAndControl.ini"),
        )
        acquisition = self._find_upwards(
            source_path,
            ("App/Ini/Acquisition.ini", "CPCFiles/App/Ini/Acquisition.ini"),
        )
        profile.source_ini = safety
        profile.acquisition_ini = acquisition
        if acquisition:
            text = acquisition.read_text(encoding="utf-8", errors="ignore")
            lines = self._section(text, "SPECTRUM")
            vals = self._numbers(self._key_value(lines, "f1ForGraph")); profile.graph_low_hz = vals[0] if vals else None
            vals = self._numbers(self._key_value(lines, "f2ForGraph")); profile.graph_high_hz = vals[0] if vals else None
            vals = self._numbers(self._key_value(lines, "CalculatedE_Factor")); profile.calculated_e_factor = vals[0] if vals else None
        if not safety:
            return profile
        text = safety.read_text(encoding="utf-8", errors="ignore")
        harmonic_lines = self._section(text, "HARMONICS_BANDWIDTHS")
        for line in harmonic_lines:
            m = self._BAND_RE.match(line.strip())
            if not m:
                continue
            index = int(m.group(1)); ratio = float(m.group(2)); delta_hz = float(m.group(3)) * 1000.0
            center = float(main_frequency_hz) * ratio
            profile.bands.append(VendorBand(index, ratio, delta_hz, center-delta_hz, center+delta_hz))
        profile.bands.sort(key=lambda b: b.index)

        inc = self._section(text, "INCREASE_POWER_RULE_0")
        weights = self._numbers(self._key_value(inc, "IncreaseRuleWeight"))
        limit_n = self._numbers(self._key_value(inc, "BottomLimitOfHarmlessEnergy"))
        if len(weights) >= 32:
            profile.increase_rule0 = VendorRule("Increase Power Rule 0", np.asarray(weights[:32], float).reshape(8,4), limit_n[0] if limit_n else None)
            inc_ratio_n = self._numbers(self._key_value(inc, "IncreasePowerRatio"))
            profile.increase_power_ratio = inc_ratio_n[0] if inc_ratio_n else None

        for rule_index in range(8):
            lines = self._section(text, f"DISPLAY_RULE_{rule_index}")
            weights = self._numbers(self._key_value(lines, "DisplayRuleWeight"))
            limit_n = self._numbers(self._key_value(lines, "MaximumEnergyForAllHydrophones"))
            if len(weights) >= 32:
                profile.display_rules[rule_index] = VendorRule(
                    f"Display Rule {rule_index}", np.asarray(weights[:32], float).reshape(8,4), limit_n[0] if limit_n else None
                )

        general = self._section(text, "GENERAL")
        profile.starting_power_ratio = self._number_or_none(self._numbers(self._key_value(general, "CavitationControlStartingPowerRatio")))
        profile.error_policy_sw = int(v) if (v := self._number_or_none(self._numbers(self._key_value(general, "SonicaitonErrorPolicyInSW")))) is not None else None
        profile.error_policy_hw = int(v) if (v := self._number_or_none(self._numbers(self._key_value(general, "SonicaitonErrorPolicyInHW")))) is not None else None
        stop = self._number_or_none(self._numbers(self._key_value(general, "IsStopSonicationOnCavitationFromRTDCA")))
        profile.stop_on_rtdca = bool(int(stop)) if stop is not None else None
        profile.ignore_start_ms = self._number_or_none(self._numbers(self._key_value(general, "TimetOIgnoreStartSonic")))
        profile.ignore_end_ms = self._number_or_none(self._numbers(self._key_value(general, "TimetOIgnoreEndSonic")))

        levels = self._section(text, "CAVITATION_CONTROL_LEVELS")
        profile.default_cavitation_level = self._number_or_none(self._numbers(self._key_value(levels, "DefaultCavitationControlLevel")))
        decoded_levels=[]
        for level_index in range(16):
            value=self._number_or_none(self._numbers(self._key_value(levels, f"Level{level_index}")))
            if value is None:
                break
            decoded_levels.append(float(value))
        profile.cavitation_levels=tuple(decoded_levels)

        for rule_index in range(16):
            rule=self._parse_control_rule(text, f"DECREASE_POWER_RULE_{rule_index}", "Decrease Power", rule_index, "DecreaseRuleWeight", "TopLimitOfHarmlessEnergy", "DecreasePowerRatio")
            if rule is not None:
                profile.decrease_rules[rule_index]=rule
            rule=self._parse_control_rule(text, f"SAFETY_RULE_{rule_index}", "Safety", rule_index, "SafetyRuleWeight", "MaximumEnergyForAllHydrophones")
            if rule is not None:
                profile.safety_rules[rule_index]=rule
            rule=self._parse_control_rule(text, f"SAFETY_RULES_FOR_CHANGING_FREQ_SONIC_{rule_index}", "Changing Frequency Safety", rule_index, "SafetyRuleWeight", "MaximumEnergyForAllHydrophones")
            if rule is not None:
                profile.changing_frequency_safety_rules[rule_index]=rule

        dynamic_path = self._find_upwards(source_path, ("Site/Ini/CavitationDynamicRules_0.ini", "CPCFiles/Site/Ini/CavitationDynamicRules_0.ini"))
        if dynamic_path is not None:
            dynamic_text=dynamic_path.read_text(encoding="utf-8", errors="ignore")
            for rule_index in range(16):
                rule=self._parse_control_rule(dynamic_text, f"DYNAMIC_RULE_{rule_index}", "Dynamic", rule_index, "DynamicRuleWeight", "TopLimitEnergyToSwitchSubSonicaiton")
                if rule is not None:
                    dlines=self._section(dynamic_text, f"DYNAMIC_RULE_{rule_index}")
                    n=self._number_or_none(self._numbers(self._key_value(dlines, "NumOfTestAllowedFailures")))
                    t=self._number_or_none(self._numbers(self._key_value(dlines, "TimeOfTestAllowedFailures")))
                    sw=self._number_or_none(self._numbers(self._key_value(dlines, "SwitchToSubSonicationNumber")))
                    rule.max_failures=int(n) if n is not None else None
                    rule.max_failure_window_ms=t
                    rule.switch_to_subsonication=int(sw) if sw is not None else None
                    profile.dynamic_rules[rule_index]=rule
        return profile

    @staticmethod
    def weighted_band0(history_channels: list[np.ndarray], weights_8x4: np.ndarray) -> np.ndarray:
        if len(history_channels) < 8 or weights_8x4.shape != (8,4):
            return np.asarray([], dtype=float)
        length = min(len(np.asarray(ch)) for ch in history_channels[:8])
        if length <= 0:
            return np.asarray([], dtype=float)
        matrix = np.vstack([np.asarray(ch, float)[:length] for ch in history_channels[:8]])
        weights = np.asarray(weights_8x4[:,0], float)
        return np.nansum(matrix * weights[:,None], axis=0)

    @classmethod
    def _parse_acquisition_brain(cls, log_path: Path) -> AcquisitionBrainParseCache:
        """Parse Acquisition_Brain once and share the result across all validations.

        Earlier builds re-read and regex-scanned the same multi-megabyte log for
        Increase Rule 0, Display Rules, Decrease Rules and power-control history.
        This single-pass parser keeps those products aligned to the same spectrum
        sessions and makes repeated Sonication/Analyzer refreshes effectively free.
        """
        path = Path(log_path).resolve()
        try:
            st = path.stat()
            key = (str(path), int(st.st_mtime_ns), int(st.st_size))
        except OSError:
            key = (str(path), 0, 0)
        cached = cls._acq_cache.get(key)
        if cached is not None:
            return cached

        result = AcquisitionBrainParseCache()
        current_inc: list[tuple[int, float]] | None = None
        current_display: dict[int, list[tuple[int, float]]] | None = None
        current_decrease: dict[int, list[tuple[int, float]]] | None = None
        current_power: list[dict] | None = None
        pending_inc0: float | None = None
        pending_decrease_energy: dict[int, float] = {}
        pending_decrease_rules: list[int] = []
        pending_increase_rules: list[int] = []
        pending_ratio: float | None = None
        pending_power_w: float | None = None

        def finish_session() -> None:
            nonlocal current_inc, current_display, current_decrease, current_power
            nonlocal pending_inc0, pending_decrease_energy, pending_decrease_rules
            nonlocal pending_increase_rules, pending_ratio, pending_power_w
            if current_inc is not None:
                result.increase0_sessions.append(current_inc)
                result.display_rule_sessions.append(current_display or {})
                result.decrease_rule_sessions.append(current_decrease or {})
                result.power_control_sessions.append(current_power or [])
            current_inc = None
            current_display = None
            current_decrease = None
            current_power = None
            pending_inc0 = None
            pending_decrease_energy = {}
            pending_decrease_rules = []
            pending_increase_rules = []
            pending_ratio = None
            pending_power_w = None

        with path.open('r', encoding='utf-8', errors='ignore') as fh:
            for line in fh:
                if 'Got StartSpectrumMeasurement' in line:
                    if current_inc is not None:
                        finish_session()
                    current_inc = []
                    current_display = {i: [] for i in range(8)}
                    current_decrease = {}
                    current_power = []
                    continue
                if current_inc is None:
                    continue

                m = re.search(r"Increase Power Rule no\.\s*0.*Calculated Energy:\s*<([-+0-9.eE]+)>", line, re.I)
                if m:
                    try:
                        pending_inc0 = float(m.group(1))
                    except ValueError:
                        pending_inc0 = None

                m = re.search(r"Decrease Power Rule no\.\s*(\d+).*Calculated Energy:\s*<([-+0-9.eE]+)>", line, re.I)
                if m:
                    try:
                        idx = int(m.group(1))
                        pending_decrease_energy[idx] = float(m.group(2))
                        pending_decrease_rules.append(idx)
                    except ValueError:
                        pass
                else:
                    m = re.search(r"Decrease Power Rule no\.\s*(\d+)", line, re.I)
                    if m:
                        pending_decrease_rules.append(int(m.group(1)))

                m = re.search(r"Increase Power Rule no\.\s*(\d+)", line, re.I)
                if m:
                    pending_increase_rules.append(int(m.group(1)))

                m = re.search(r"Set:.*?ExciterPower\s*=\s*([-+0-9.eE]+)\s*W.*?ExPowerRatio\s*=\s*([-+0-9.eE]+)", line, re.I)
                if m:
                    try:
                        pending_power_w = float(m.group(1))
                        pending_ratio = float(m.group(2))
                    except ValueError:
                        pending_power_w = pending_ratio = None

                m_cycle = re.search(r"Cycle\s+(\d+)\s+Done", line, re.I)
                if m_cycle:
                    cycle = int(m_cycle.group(1))
                    if pending_inc0 is not None:
                        current_inc.append((cycle, pending_inc0))
                    for dm in re.finditer(r"Rule\s*<(\d+)>:\s*(-1\.#IND|[-+0-9.eE]+)", line, re.I):
                        raw = dm.group(2)
                        if raw.lower().startswith('-1.#ind'):
                            continue
                        try:
                            current_display.setdefault(int(dm.group(1)), []).append((cycle, float(raw)))
                        except ValueError:
                            pass
                    for rule_index, value in pending_decrease_energy.items():
                        current_decrease.setdefault(rule_index, []).append((cycle, value))
                    current_power.append({
                        'cycle': cycle,
                        'power_ratio': pending_ratio,
                        'power_w': pending_power_w,
                        'decrease_rules': tuple(sorted(set(pending_decrease_rules))),
                        'increase_rules': tuple(sorted(set(pending_increase_rules))),
                    })
                    pending_inc0 = None
                    pending_decrease_energy = {}
                    pending_decrease_rules = []
                    pending_increase_rules = []
                    pending_ratio = None
                    pending_power_w = None

                if 'Got StopSpectrumMeasurement' in line:
                    finish_session()

        if current_inc is not None:
            finish_session()

        # Remove stale versions of the same path and bound memory use.
        for old_key in list(cls._acq_cache):
            if old_key[0] == str(path) and old_key != key:
                cls._acq_cache.pop(old_key, None)
        cls._acq_cache[key] = result
        while len(cls._acq_cache) > cls._acq_cache_max_entries:
            cls._acq_cache.pop(next(iter(cls._acq_cache)))
        return result

    @classmethod
    def _parse_sessions(cls, log_path: Path) -> list[list[tuple[int, float]]]:
        return cls._parse_acquisition_brain(log_path).increase0_sessions

    @classmethod
    def _parse_display_rule_sessions(cls, log_path: Path) -> list[dict[int, list[tuple[int, float]]]]:
        return cls._parse_acquisition_brain(log_path).display_rule_sessions

    @classmethod
    def _parse_control_rule_sessions(cls, log_path: Path, family: str = "Decrease Power") -> list[dict[int, list[tuple[int, float]]]]:
        if family.lower() == 'decrease power':
            return cls._parse_acquisition_brain(log_path).decrease_rule_sessions
        # Other families are uncommon and retain a lightweight one-pass fallback.
        sessions: list[dict[int, list[tuple[int, float]]]] = []
        current: dict[int, list[tuple[int, float]]] | None = None
        pending: dict[int, float] = {}
        family_re = re.escape(family)
        with Path(log_path).open('r', encoding='utf-8', errors='ignore') as fh:
            for line in fh:
                if 'Got StartSpectrumMeasurement' in line:
                    if current is not None:
                        sessions.append(current)
                    current = {}; pending = {}; continue
                if current is None:
                    continue
                m = re.search(rf"{family_re} Rule no\.\s*(\d+).*Calculated Energy:\s*<([-+0-9.eE]+)>", line, re.I)
                if m:
                    try: pending[int(m.group(1))] = float(m.group(2))
                    except ValueError: pass
                m_cycle = re.search(r"Cycle\s+(\d+)\s+Done", line, re.I)
                if m_cycle and pending:
                    cycle = int(m_cycle.group(1))
                    for rule_index, value in pending.items():
                        current.setdefault(rule_index, []).append((cycle, value))
                    pending = {}
                if 'Got StopSpectrumMeasurement' in line:
                    sessions.append(current); current = None; pending = {}
        if current is not None:
            sessions.append(current)
        return sessions

    @classmethod
    def _parse_display_rule1_sessions(cls, log_path: Path) -> list[list[tuple[int, float]]]:
        return [session.get(1, []) for session in cls._parse_display_rule_sessions(log_path) if session.get(1)]

    @classmethod
    def _parse_power_control_sessions(cls, log_path: Path) -> list[list[dict]]:
        return cls._parse_acquisition_brain(log_path).power_control_sessions

    def validate_power_control(self, source_path: Path | None, profile: VendorCavitationProfile, preferred_session_index: int | None = None) -> VendorControlValidation:
        result=VendorControlValidation()
        try:
            from src.services.acoustic_control_service import AcousticControlService
            log_path = AcousticControlService().find_log(Path(source_path)) if source_path is not None else None
        except Exception:
            log_path = None
        if log_path is None:
            result.note="Acquisition_Brain log was not found; INI control rules were decoded but runtime action cannot be validated."
            return result
        result.source_log=log_path
        sessions=self._parse_power_control_sessions(log_path)
        candidates=[]
        for session_index, session in enumerate(sessions):
            previous=None
            errors=[]; rows=[]; dec_count=0; inc_count=0
            for row in session:
                actual=row.get("power_ratio")
                if actual is None:
                    continue
                prediction=None; action="hold"; labels=[]
                if previous is not None:
                    dec_rules=[profile.decrease_rules[i] for i in row["decrease_rules"] if i in profile.decrease_rules and profile.decrease_rules[i].power_ratio is not None]
                    if dec_rules:
                        strongest=max(dec_rules, key=lambda rule: float(rule.power_ratio or 0.0))
                        prediction=float(previous)*(1.0-float(strongest.power_ratio))
                        action=f"decrease {100.0*float(strongest.power_ratio):.1f}%"
                        labels=[f"Decrease {rule.index}" for rule in dec_rules]
                        dec_count+=1
                    else:
                        inc_rules=[]
                        for i in row["increase_rules"]:
                            if i == 0 and profile.increase_rule0 is not None and profile.increase_power_ratio is not None:
                                inc_rules.append(float(profile.increase_power_ratio))
                        if inc_rules:
                            strongest=max(inc_rules)
                            prediction=min(1.0, float(previous)*(1.0+strongest))
                            action=f"increase {100.0*strongest:.1f}%"
                            labels=["Increase 0"]
                            inc_count+=1
                if prediction is not None:
                    error=abs(float(actual)-prediction)
                    errors.append(error)
                    rows.append((row["cycle"], float(actual), prediction, action, ", ".join(labels)))
                previous=float(actual)
            if errors:
                mae=float(np.mean(errors)); maxerr=float(np.max(errors))
                candidates.append((mae,maxerr,session_index,rows,dec_count,inc_count))
        if not candidates:
            result.status="INI-derived"
            result.note="Control rules decoded, but no log session had consecutive Set power-ratio records for validation."
            return result
        if preferred_session_index is not None:
            preferred=[c for c in candidates if c[2] == preferred_session_index]
            chosen=preferred[0] if preferred else min(candidates)
        else:
            chosen=min(candidates)
        mae,maxerr,session_index,rows,dec_count,inc_count=chosen
        result.matched_events=len(rows); result.decrease_events=dec_count; result.increase_events=inc_count
        result.mae_power_ratio=mae; result.max_abs_error_power_ratio=maxerr
        result.event_cycles=np.asarray([r[0] for r in rows], dtype=int)
        result.actual_power_ratio=np.asarray([r[1] for r in rows], dtype=float)
        result.predicted_power_ratio=np.asarray([r[2] for r in rows], dtype=float)
        result.action_labels=[r[3] for r in rows]
        result.triggered_rule_labels=[r[4] for r in rows]
        result.status="EXACT control reproduction" if maxerr <= 5e-4 else "Partial control reproduction"
        result.note=(
            f"Runtime power control reproduced from CavitationSafetyAndControl.ini: session={session_index}, "
            f"events={len(rows)} (decrease={dec_count}, increase={inc_count}), MAE={mae:.3g}, max error={maxerr:.3g}. "
            "When multiple decrease rules fire in one 10-ms cycle, the strongest configured decrease ratio wins; ratios are multiplicative. "
            "Increase Rule 0 applies multiplicatively and saturates at 1.0."
        )
        return result

    def validate_saved_band0_history(self, source_path: Path | None, history_channels: list[np.ndarray], profile: VendorCavitationProfile) -> VendorHistoryValidation:
        result = VendorHistoryValidation()
        rule = profile.increase_rule0
        if rule is None:
            result.note = "Increase Power Rule 0 was not decoded from CavitationSafetyAndControl.ini."
            return result
        weighted = self.weighted_band0(history_channels, rule.weights)
        result.weighted_history = weighted
        if weighted.size == 0:
            result.note = "Saved CPC 8-channel history is unavailable."
            return result
        if rule.limit and rule.limit > 0:
            # CGA/Acquisition Display Rule reports Energy / MaximumEnergy.
            display_rule = profile.display_rules.get(1)
            display_limit = display_rule.limit if display_rule and display_rule.limit else None
            if display_limit and display_limit > 0:
                result.normalized_display_rule1 = weighted / float(display_limit)
        try:
            from src.services.acoustic_control_service import AcousticControlService
            log_path = AcousticControlService().find_log(Path(source_path)) if source_path is not None else None
        except Exception:
            log_path = None
        if log_path is None:
            result.status = "INI-derived"
            result.note = "Band0 weighting decoded, but Acquisition_Brain log was not found for numerical validation."
            return result
        result.source_log = log_path
        sessions = self._parse_sessions(log_path)
        candidates = []
        for session_index, session in enumerate(sessions):
            xs=[]; ys=[]
            for cycle, value in session:
                # Acquisition cycle numbering is 1-based; saved history array is 0-based.
                idx = cycle - 1
                if 0 <= idx < weighted.size:
                    xs.append(float(weighted[idx])); ys.append(float(value))
            if len(xs) < 20:
                continue
            xa=np.asarray(xs,float); ya=np.asarray(ys,float)
            finite=np.isfinite(xa)&np.isfinite(ya)
            if np.count_nonzero(finite)<20:
                continue
            xa=xa[finite]; ya=ya[finite]
            corr=float(np.corrcoef(xa,ya)[0,1]) if np.std(xa)>0 and np.std(ya)>0 else float('nan')
            errors=np.abs(xa-ya)
            mae=float(np.mean(errors)); maxerr=float(np.max(errors))
            candidates.append((mae, -corr if math.isfinite(corr) else 0.0, session_index, len(xa), corr, maxerr))
        if not candidates:
            result.status = "INI-derived"
            result.note = "No Acquisition log session overlapped enough saved history cycles for validation."
            return result
        mae, _negcorr, session_index, count, corr, maxerr = min(candidates)
        result.matched_samples=count; result.correlation=corr; result.mae=mae; result.max_abs_error=maxerr; result.cycle_offset=-1
        result.log_session_index = int(session_index)

        # Decode every numeric Display Rule from the same acquisition session.
        display_sessions = self._parse_display_rule_sessions(log_path)
        if 0 <= session_index < len(display_sessions):
            dsession_all = display_sessions[session_index]
            for rule_index, points in dsession_all.items():
                arr = np.full(weighted.size, np.nan, dtype=float)
                for cycle, value in points:
                    idx = cycle - 1
                    if 0 <= idx < arr.size:
                        arr[idx] = float(value)
                if np.isfinite(arr).any():
                    result.display_rule_histories[int(rule_index)] = arr
                    display_rule = profile.display_rules.get(int(rule_index))
                    if display_rule is not None and display_rule.limit is not None and display_rule.limit > 0:
                        active_bands = sorted({int(band) for _ch, band in np.argwhere(display_rule.weights != 0)})
                        if len(active_bands) == 1:
                            band_index = active_bands[0]
                            result.weighted_band_histories_from_log[band_index] = arr * float(display_rule.limit)
                            result.evidence_notes[band_index] = (
                                f"Exact combined Band{band_index} history reconstructed from Acquisition Display Rule {rule_index} "
                                f"× MaximumEnergyForAllHydrophones ({display_rule.limit:g}); cycles map 1:1."
                            )

        # Decode sparse control-rule events. In this configuration Decrease Rule 4/5
        # are pure Band2 weighted rules, so their logged Calculated Energy values are
        # exact Band2 combined-energy samples when the control threshold is crossed.
        control_sessions = self._parse_control_rule_sessions(log_path, "Decrease Power")
        if 0 <= session_index < len(control_sessions):
            cs = control_sessions[session_index]
            # Map rule 4 preferentially; rule 5 is a second Band2 threshold and can
            # fill cycles not emitted by rule 4.
            band2 = np.full(weighted.size, np.nan, dtype=float)
            for rule_index in (4, 5):
                for cycle, value in cs.get(rule_index, []):
                    idx = cycle - 1
                    if 0 <= idx < band2.size:
                        band2[idx] = float(value)
            if np.isfinite(band2).any():
                result.sparse_control_rule_histories[2] = band2
                result.evidence_notes[2] = (
                    "Exact sparse Band2 energy events reconstructed from Decrease Power Rule 4/5 Calculated Energy; "
                    "only threshold-crossing cycles are logged, so this is not a continuous history."
                )

        # Independently validate the normalized CGA/Acquisition Display Rule 1.
        if result.normalized_display_rule1.size:
            display_candidates=[]
            for dsession in self._parse_display_rule1_sessions(log_path):
                dx=[]; dy=[]
                for cycle, value in dsession:
                    idx=cycle-1
                    if 0 <= idx < result.normalized_display_rule1.size and math.isfinite(value):
                        dx.append(float(result.normalized_display_rule1[idx])); dy.append(float(value))
                if len(dx) < 20:
                    continue
                dxa=np.asarray(dx,float); dya=np.asarray(dy,float)
                dcorr=float(np.corrcoef(dxa,dya)[0,1]) if np.std(dxa)>0 and np.std(dya)>0 else float('nan')
                dmae=float(np.mean(np.abs(dxa-dya)))
                display_candidates.append((dmae, -dcorr if math.isfinite(dcorr) else 0.0, len(dxa), dcorr))
            if display_candidates:
                dmae,_neg,nmatch,dcorr=min(display_candidates)
                result.display_rule1_matched_samples=nmatch; result.display_rule1_correlation=dcorr; result.display_rule1_mae=dmae
        if math.isfinite(corr) and corr >= 0.999 and mae <= 1e-5 and maxerr <= 5e-5:
            result.status = "EXACT vendor Band0 history"
            result.note = (
                f"Saved 8CH history weighted by INCREASE_POWER_RULE_0 reproduces Acquisition log Calculated Energy: "
                f"n={count}, r={corr:.6f}, MAE={mae:.3g}, max error={maxerr:.3g}; cycle N maps to history[N-1]."
                + (f" Display Rule 1 also matches Energy/MaximumEnergy: n={result.display_rule1_matched_samples}, "
                   f"r={result.display_rule1_correlation:.6f}, MAE={result.display_rule1_mae:.3g}."
                   if result.display_rule1_matched_samples and result.display_rule1_correlation is not None and result.display_rule1_mae is not None else "")
            )
        else:
            result.status = "Partial validation"
            result.note = f"Best log match: n={count}, r={corr:.6f}, MAE={mae:.3g}, max error={maxerr:.3g}."
        return result
