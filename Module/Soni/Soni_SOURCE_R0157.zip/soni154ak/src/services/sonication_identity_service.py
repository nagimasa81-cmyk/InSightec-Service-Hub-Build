from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re

from src.parsers.ado_rowset import parse_ado_rowset


_SON_DIR_RE = re.compile(r"^sonication\s*[_-]?\s*(\d+)$", re.I)
_SPECTRUM_MSG_RE = re.compile(r"^spectrummsg[-_ ]?(\d+)", re.I)


@dataclass(slots=True)
class SonicationIdentityInventory:
    numbers: list[int] = field(default_factory=list)
    folders_by_number: dict[int, list[Path]] = field(default_factory=dict)
    summary_numbers: list[int] = field(default_factory=list)
    spot_numbers: list[int] = field(default_factory=list)
    spectrummsg_numbers: list[int] = field(default_factory=list)
    evidence_by_number: dict[int, list[str]] = field(default_factory=dict)


class SonicationIdentityService:
    """Resolve logical Sonication identity independently from physical folders.

    A treatment Sonication must not disappear merely because one import path did
    not materialize its ``SonicationN`` directory.  Logical identity is the
    union of independently numbered evidence that survives import:

      * SonicationN directories
      * SonicationSummary.xml rows
      * spotsonicationdata.xml rows
      * SpectrumMsg-N.dmp files

    This resolver never invents a number that is absent from all authoritative
    evidence.  Duplicate physical folders are retained as evidence for one
    logical Sonication and are merged later by DiscoveryService.
    """

    @staticmethod
    def _first(workspace: Path, name: str) -> Path | None:
        items = sorted(workspace.rglob(name), key=lambda p: (len(p.parts), str(p).lower()))
        return items[0] if items else None

    @staticmethod
    def _row_indices(path: Path | None) -> list[int]:
        if path is None or not path.exists():
            return []
        try:
            rows = parse_ado_rowset(path)
        except Exception:
            return []
        out: set[int] = set()
        for row in rows:
            try:
                value = int(float(row.get("sonicationindex", "")))
            except (TypeError, ValueError):
                continue
            if value > 0:
                out.add(value)
        return sorted(out)

    def resolve(self, workspace: Path) -> SonicationIdentityInventory:
        workspace = Path(workspace)
        folders: dict[int, list[Path]] = {}
        for path in workspace.rglob("*"):
            if not path.is_dir():
                continue
            match = _SON_DIR_RE.match(path.name)
            if match:
                folders.setdefault(int(match.group(1)), []).append(path)
        match = _SON_DIR_RE.match(workspace.name)
        if match:
            folders.setdefault(int(match.group(1)), []).append(workspace)
        for number in list(folders):
            unique = {p.resolve(): p for p in folders[number]}
            folders[number] = sorted(unique.values(), key=lambda p: (len(p.parts), str(p).lower()))

        summary = self._row_indices(self._first(workspace, "SonicationSummary.xml"))
        spot = self._row_indices(self._first(workspace, "spotsonicationdata.xml"))

        spectrum: set[int] = set()
        for path in workspace.rglob("*"):
            if not path.is_file() or path.suffix.lower() != ".dmp":
                continue
            match = _SPECTRUM_MSG_RE.match(path.name)
            if match:
                spectrum.add(int(match.group(1)))

        # R0154f: a completely empty SonicationN directory is not sufficient
        # evidence for a real treatment Sonication. Some exports leave a trailing
        # empty folder (for example Sonication6 after five actual sonications).
        # Keep folder-only legacy Sonications when the directory contains at least
        # one file, but exclude truly empty placeholders so they cannot change the
        # treatment count and break otherwise one-to-one CPC/session mapping.
        substantive_folder_numbers: set[int] = set()
        for number, paths in folders.items():
            for folder in paths:
                try:
                    if any(child.is_file() for child in folder.rglob("*")):
                        substantive_folder_numbers.add(number)
                        break
                except OSError:
                    continue

        independently_numbered = set(summary) | set(spot) | spectrum
        numbers = sorted(independently_numbered | substantive_folder_numbers)
        evidence: dict[int, list[str]] = {n: [] for n in numbers}
        for n in numbers:
            if n in folders:
                evidence[n].append(f"Sonication folder(s): {len(folders[n])}")
            if n in summary:
                evidence[n].append("SonicationSummary")
            if n in spot:
                evidence[n].append("spotsonicationdata")
            if n in spectrum:
                evidence[n].append("SpectrumMsg")

        return SonicationIdentityInventory(
            numbers=numbers,
            folders_by_number=folders,
            summary_numbers=summary,
            spot_numbers=spot,
            spectrummsg_numbers=sorted(spectrum),
            evidence_by_number=evidence,
        )
