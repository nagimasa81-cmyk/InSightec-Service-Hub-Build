from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import datetime as _dt
import re

import numpy as np

from src.core.fus_export_core import decode_spectrum_structure
from src.parsers.ado_rowset import parse_ado_rowset
from src.services.acoustic_control_service import AcousticControlService


_TIME_RE = re.compile(r"(?P<h>\d{2}):(?P<m>\d{2}):(?P<s>\d{2}):(?P<ms>\d{3})")
_ANGLE_RE = re.compile(r"SkullAttenuationFactorsForEachReceiver:\s*([^\r\n]+)", re.I)
_SONICATION_LOG_RE = re.compile(
    r"Sonication_Brain_\d+_(?P<dow>Mon|Tue|Wed|Thu|Fri|Sat|Sun)_"
    r"(?P<mon>Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)_"
    r"(?P<day>\d{1,2})_(?P<h>\d{2})_(?P<m>\d{2})_(?P<s>\d{2})_(?P<y>\d{4})\.txt$", re.I)


@dataclass(slots=True)
class SonicationSetupRecord:
    clock_s: float
    sonication_counter: int | None = None
    power_w: float | None = None
    duration_s: float | None = None
    frequency_hz: float | None = None
    sonication_type: int | None = None
    cpc_mode: int | None = None
    cavitation_mode: int | None = None
    cavitation_level: float | None = None
    steering_xyz: tuple[float | None, float | None, float | None] = (None, None, None)
    channel_count: int | None = None
    subsonication_count: int | None = None
    subsonication_ras: tuple[tuple[float, float, float], ...] = ()
    subsonication_steering: tuple[tuple[float, float, float], ...] = ()
    subsonication_duration_s: tuple[float, ...] = ()
    receiver_skull_attenuation: tuple[float, ...] = ()
    source: Path | None = None


@dataclass(slots=True)
class SonicationEvidence:
    sonication_index: int
    spectrummsg_path: Path | None = None
    spectrummsg_frame_count: int | None = None
    spectrummsg_channel_count: int | None = None
    spectrummsg_layout: str | None = None
    spectrummsg_fft_bins: int | None = None
    spectrummsg_spacing_hz: float | None = None
    spectrummsg_last_time_s: float | None = None
    spectrum_powergraph_time_exact: bool = False
    powergraph_size: int | None = None
    powergraph_time_s: np.ndarray = field(default_factory=lambda: np.array([], dtype=float))
    powergraph_power_percent: np.ndarray = field(default_factory=lambda: np.array([], dtype=float))
    actual_duration_s: float | None = None
    displayed_power_w: float | None = None
    summary_power_w: float | None = None
    summary_duration_s: float | None = None
    summary_energy_j: float | None = None
    frequency_hz: float | None = None
    focal_ras: tuple[float | None, float | None, float | None] = (None, None, None)
    cavitation_safety_mode: int | None = None
    acoustic_threshold: float | None = None
    setup_record: SonicationSetupRecord | None = None
    acquisition_session_index: int | None = None
    acquisition_session_start_error_s: float | None = None
    evidence: list[str] = field(default_factory=list)
    file_inventory: dict[str, int] = field(default_factory=dict)
    confidence: str = "Unknown"

    @property
    def spectrum_powergraph_exact(self) -> bool:
        return (
            self.spectrummsg_frame_count is not None
            and self.powergraph_size is not None
            and int(self.spectrummsg_frame_count) == int(self.powergraph_size)
        )


class SonicationEvidenceService:
    """Cross-link Sonication-local and package-level treatment evidence.

    This service intentionally starts from the numbered ``SonicationN`` folder.
    The exported ``SpectrumMsg-N.dmp`` is the local identity anchor.  Its validated
    frame count is compared with ``spotsonicationdata.xml/PowerGraphSize``.  The
    workstation summary supplies the per-sonication power/duration/frequency, and
    the matching regular Type-6 setup block in ``Sonication_Brain`` supplies an
    absolute clock.  That clock is then matched to the Acquisition_Brain session.

    The result is a defensible chain:
      SonicationN -> SpectrumMsg-N -> PowerGraph row -> Sonication_Brain setup
      -> Acquisition_Brain session.
    No latest-N positional assumption is required when this evidence is present.
    """

    def __init__(self) -> None:
        self.acoustic = AcousticControlService()

    @staticmethod
    def _f(row: dict[str, object], key: str) -> float | None:
        try:
            value = row.get(key)
            if value in (None, ""):
                return None
            return float(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _i(row: dict[str, object], key: str) -> int | None:
        try:
            value = row.get(key)
            if value in (None, ""):
                return None
            return int(float(value))
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _clock_s(line: str) -> float | None:
        m = _TIME_RE.search(line)
        if not m:
            return None
        return (
            int(m.group("h")) * 3600.0
            + int(m.group("m")) * 60.0
            + int(m.group("s"))
            + int(m.group("ms")) / 1000.0
        )

    @staticmethod
    def _clock_delta_s(a: float, b: float) -> float:
        d = float(a) - float(b)
        if d > 43200:
            d -= 86400
        elif d < -43200:
            d += 86400
        return d

    @staticmethod
    def _find_first(workspace: Path, pattern: str) -> Path | None:
        items = sorted(workspace.rglob(pattern), key=lambda p: (len(p.parts), str(p).lower()))
        return items[0] if items else None

    @staticmethod
    def _rows_by_index(path: Path | None) -> dict[int, dict[str, object]]:
        if path is None or not path.exists():
            return {}
        try:
            rows = parse_ado_rowset(path)
        except Exception:
            return {}
        out: dict[int, dict[str, object]] = {}
        for row in rows:
            try:
                idx = int(float(row.get("sonicationindex", "")))
            except (TypeError, ValueError):
                continue
            out[idx] = row
        return out

    def _power_graph(self, workspace: Path, index0: int) -> tuple[np.ndarray, np.ndarray] | None:
        # One authoritative decoder is retained in AcousticControlService.
        try:
            return self.acoustic.power_graph_for_sonication(workspace, index0)
        except AttributeError:
            # Backward-compatible fallback while older sources are inspected.
            return self.acoustic._vendor_power_graph(workspace, index0)

    @staticmethod
    def _field(text: str, name: str) -> str | None:
        m = re.search(re.escape(name) + r"\s*<([^>]+)>", text, re.I)
        return m.group(1).strip() if m else None

    @classmethod
    def _float_field(cls, text: str, name: str, scale: float = 1.0) -> float | None:
        value = cls._field(text, name)
        try:
            return float(value) * scale if value is not None else None
        except (TypeError, ValueError):
            return None

    @classmethod
    def _int_field(cls, text: str, name: str) -> int | None:
        value = cls._field(text, name)
        try:
            return int(float(value)) if value is not None else None
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _sonication_log_stamp(path: Path) -> _dt.datetime | None:
        m = _SONICATION_LOG_RE.search(path.name)
        if not m:
            return None
        try:
            return _dt.datetime.strptime(
                f"{m.group('mon')} {m.group('day')} {m.group('y')} {m.group('h')}:{m.group('m')}:{m.group('s')}",
                "%b %d %Y %H:%M:%S",
            )
        except ValueError:
            return None

    def _find_treatment_sonication_log(self, workspace: Path) -> Path | None:
        base = Path(workspace)
        candidates = sorted(base.rglob("Sonication_Brain_*.txt"), key=lambda p: str(p).lower())
        if not candidates:
            return None
        treatment_stamp = self.acoustic._summary_first_sonication_stamp(base)
        stamped = [(self._sonication_log_stamp(path), path) for path in candidates]
        stamped = [(stamp, path) for stamp, path in stamped if stamp is not None]
        if treatment_stamp is not None and stamped:
            before = [(stamp, path) for stamp, path in stamped if stamp <= treatment_stamp]
            if before:
                return max(before, key=lambda item: item[0])[1]
            return min(stamped, key=lambda item: abs((item[0] - treatment_stamp).total_seconds()))[1]
        if stamped:
            return max(stamped, key=lambda item: item[0])[1]
        return candidates[-1]


    @staticmethod
    def _eq_float(text: str, name: str) -> float | None:
        m = re.search(re.escape(name) + r"\s*=\s*([-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)", text, re.I)
        try:
            return float(m.group(1)) if m else None
        except (TypeError, ValueError):
            return None

    @classmethod
    def _eq_int(cls, text: str, name: str) -> int | None:
        value = cls._eq_float(text, name)
        return int(value) if value is not None else None

    @staticmethod
    def _parse_xyz_list(line: str) -> tuple[tuple[float, float, float], ...]:
        # Parse only explicit parenthesized triples; Size: and timestamps cannot
        # contaminate the coordinate list.
        out = []
        for a, b, c in re.findall(r"\(\s*([-+]?\d+(?:\.\d+)?)\s*,\s*([-+]?\d+(?:\.\d+)?)\s*,\s*([-+]?\d+(?:\.\d+)?)\s*\)", line):
            try:
                out.append((float(a), float(b), float(c)))
            except ValueError:
                pass
        return tuple(out)

    def _parse_ws_start_sonicate_records(self, workspace: Path) -> list[SonicationSetupRecord]:
        """Parse authoritative StartSonicate blocks from the workstation .Log.

        Brain220 exports supplied in the field may not contain the historical
        Sonication_Brain_*.txt artifact at all, but their main workstation log
        records Sonication Counter plus the full CSA parameter block and, for
        target-voxel patterns, the sub-sonication RAS list.  Counter identity is
        stronger than positional matching and therefore wins when present.
        """
        candidates = []
        for pat in ("*.Log", "*.log"):
            candidates.extend(Path(workspace).rglob(pat))
        candidates = sorted(set(candidates), key=lambda q: (len(q.parts), str(q).lower()))
        best: list[SonicationSetupRecord] = []
        for path in candidates:
            try:
                lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            starts = [i for i, line in enumerate(lines) if "[CGeneralSonicationLogic::StartSonicate] Sonication Counter:" in line]
            if not starts:
                continue
            records: list[SonicationSetupRecord] = []
            for pos, start in enumerate(starts):
                end = starts[pos + 1] if pos + 1 < len(starts) else min(len(lines), start + 2500)
                # Setup parameters are emitted immediately after StartSonicate.
                # Bound the block to avoid absorbing later duplicated status dumps.
                block_lines = lines[start:min(end, start + 700)]
                text = "\n".join(block_lines)
                cm = re.search(r"Sonication Counter:(\d+)", lines[start], re.I)
                counter = int(cm.group(1)) if cm else None
                clock_s = self._clock_s(lines[start])
                if clock_s is None:
                    continue
                steering = (None, None, None)
                sm = re.search(r"Steering:\s*([-+]?\d+(?:\.\d+)?)\s+([-+]?\d+(?:\.\d+)?)\s+([-+]?\d+(?:\.\d+)?)", text, re.I)
                if sm:
                    steering = tuple(float(sm.group(i)) for i in range(1, 4))
                ras: tuple[tuple[float, float, float], ...] = ()
                for line in block_lines:
                    if "Sub - sonications coordinates in RAS:" in line and "CT RAS" not in line:
                        ras = self._parse_xyz_list(line)
                        if ras:
                            break
                substeer = []
                subdur = []
                table_seen = False
                row_re = re.compile(r"^\s*\d{2}:\d{2}:\d{2}:\d{3}.*?\s(\d+)\s*,\s*\d+\s*,\s*([-+]?\d+(?:\.\d+)?)\s*,\s*([-+]?\d+(?:\.\d+)?)\s*,\s*\(([-+]?\d+(?:\.\d+)?),([-+]?\d+(?:\.\d+)?),([-+]?\d+(?:\.\d+)?)\)")
                for line in block_lines:
                    if "Sub sonication data: Num" in line:
                        table_seen = True
                        continue
                    if table_seen:
                        m = row_re.search(line)
                        if m:
                            subdur.append(float(m.group(3)))
                            substeer.append((float(m.group(4)), float(m.group(5)), float(m.group(6))))
                rec = SonicationSetupRecord(
                    clock_s=float(clock_s),
                    sonication_counter=counter,
                    power_w=self._eq_float(text, "Acoustic Power"),
                    duration_s=self._eq_float(text, "PulseDuration"),
                    frequency_hz=self._eq_float(text, "Frequency"),
                    sonication_type=(int(float(m.group(1))) if (m := re.search(r"Sonication Type\s*:\s*([-+]?\d+(?:\.\d+)?)", text, re.I)) else None),
                    cavitation_level=self._eq_float(text, "Cavitation control level"),
                    steering_xyz=steering,
                    subsonication_count=self._eq_int(text, "Number of sub-sonications"),
                    subsonication_ras=ras,
                    subsonication_steering=tuple(substeer),
                    subsonication_duration_s=tuple(subdur),
                    source=path,
                )
                # When a count is logged, require the coordinate/table evidence to
                # agree if it is present; inconsistent fragments are left usable
                # for power/frequency but not promoted as sub-sonication geometry.
                if rec.subsonication_count is not None:
                    if rec.subsonication_ras and len(rec.subsonication_ras) != rec.subsonication_count:
                        rec.subsonication_ras = ()
                    if rec.subsonication_steering and len(rec.subsonication_steering) < rec.subsonication_count:
                        rec.subsonication_steering = ()
                    elif rec.subsonication_steering:
                        rec.subsonication_steering = rec.subsonication_steering[:rec.subsonication_count]
                    if rec.subsonication_duration_s and len(rec.subsonication_duration_s) < rec.subsonication_count:
                        rec.subsonication_duration_s = ()
                    elif rec.subsonication_duration_s:
                        rec.subsonication_duration_s = rec.subsonication_duration_s[:rec.subsonication_count]
                records.append(rec)
            if len(records) > len(best):
                best = records
        return best

    def parse_setup_records(self, workspace: Path) -> list[SonicationSetupRecord]:
        path = self._find_treatment_sonication_log(workspace)
        if path is None:
            return self._parse_ws_start_sonicate_records(workspace)
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            return []
        records: list[SonicationSetupRecord] = []
        i = 0
        while i < len(lines):
            if "CPC Burn Spot fields:" not in lines[i]:
                i += 1
                continue
            clock_s = self._clock_s(lines[i])
            block = [lines[i]]
            i += 1
            # Include CLoadSonicationData metadata and stop at the HW load completion.
            while i < len(lines):
                if "CPC Burn Spot fields:" in lines[i]:
                    break
                block.append(lines[i])
                if "CHwServerThread: LoadSonicationA: done" in lines[i]:
                    i += 1
                    break
                i += 1
            if clock_s is None:
                continue
            text = "\n".join(block)
            attenuation: tuple[float, ...] = ()
            am = _ANGLE_RE.search(text)
            if am:
                try:
                    attenuation = tuple(float(v) for v in re.findall(r"[-+]?\d+(?:\.\d+)?", am.group(1)))
                except ValueError:
                    attenuation = ()
            records.append(SonicationSetupRecord(
                clock_s=float(clock_s),
                power_w=self._float_field(text, "Acoustic Power"),
                duration_s=self._float_field(text, "Duration"),
                frequency_hz=self._float_field(text, "Frequency", 1e6),
                sonication_type=self._int_field(text, "Sonication Type"),
                cpc_mode=self._int_field(text, "CPC Sonication Mode"),
                cavitation_mode=self._int_field(text, "Cavitation Mode"),
                cavitation_level=self._float_field(text, "Cavitation Level"),
                steering_xyz=(
                    self._float_field(text, "Steering X"),
                    self._float_field(text, "Steering Y"),
                    self._float_field(text, "Steering Z"),
                ),
                channel_count=self._int_field(text, "Number Of Channels"),
                subsonication_count=self._int_field(text, "Number Of SubSonications"),
                receiver_skull_attenuation=attenuation,
                source=path,
            ))
        return records

    @staticmethod
    def _setup_match_cost(ev: SonicationEvidence, setup: SonicationSetupRecord) -> float:
        """Zero means the setup signature exactly matches the exported row."""
        cost = 0.0
        if ev.displayed_power_w is not None and setup.power_w is not None:
            cost += abs(ev.displayed_power_w - setup.power_w) / max(abs(ev.displayed_power_w), 1.0) * 100.0
        elif ev.summary_power_w is not None and setup.power_w is not None:
            cost += abs(ev.summary_power_w - setup.power_w) / max(abs(ev.summary_power_w), 1.0) * 100.0
        else:
            cost += 50.0
        if ev.frequency_hz is not None and setup.frequency_hz is not None:
            cost += abs(ev.frequency_hz - setup.frequency_hz) / 1000.0
        else:
            cost += 20.0
        # Workstation revisions differ: some Sonication_Brain setup durations
        # equal SonicationSummary directly, while older exports wrap the acoustic
        # duration in a 3 s setup envelope. Accept whichever documented relation
        # is closer; duration remains corroborating evidence, never the identity
        # key by itself.
        if ev.summary_duration_s is not None and setup.duration_s is not None:
            direct = abs(ev.summary_duration_s - setup.duration_s)
            envelope = abs((ev.summary_duration_s + 3.0) - setup.duration_s)
            cost += min(direct, envelope) * 10.0
        return float(cost)

    @staticmethod
    def _same_setup_signature(a: SonicationSetupRecord, b: SonicationSetupRecord) -> bool:
        def close(x, y, tol):
            if x is None or y is None:
                return x is y
            return abs(float(x) - float(y)) <= float(tol)
        return (
            close(a.power_w, b.power_w, 0.05)
            and close(a.duration_s, b.duration_s, 0.02)
            and close(a.frequency_hz, b.frequency_hz, 100.0)
            and a.sonication_type == b.sonication_type
            and a.cpc_mode == b.cpc_mode
            and all(close(x, y, 0.01) for x, y in zip(a.steering_xyz, b.steering_xyz))
        )

    @classmethod
    def _collapse_duplicate_setup_records(cls, records: list[SonicationSetupRecord]) -> list[SonicationSetupRecord]:
        """Collapse workstation duplicate setup writes for one physical sonication.

        Some releases write the same Type-6 CPC setup twice roughly two seconds
        apart before one Acquisition_Brain session. Treating both lines as two
        sonications makes a five-sonication treatment look like ten setup records
        and prevents canonical session binding. Collapse only near-adjacent records
        with the same physical signature; genuinely different rapid sonications are
        retained. The later record is kept because it is closest to acquisition start.
        """
        out: list[SonicationSetupRecord] = []
        for rec in records:
            if out:
                delta = AcousticControlService._clock_delta_seconds_compat(rec.clock_s, out[-1].clock_s)
                if 0.0 <= delta <= 5.0 and cls._same_setup_signature(out[-1], rec):
                    out[-1] = rec
                    continue
            out.append(rec)
        return out

    def _match_regular_setup_window(self, evidence: list[SonicationEvidence], records: list[SonicationSetupRecord]) -> list[SonicationSetupRecord] | None:
        regular = self._collapse_duplicate_setup_records([r for r in records if r.sonication_type == 6])
        n = len(evidence)
        if n == 0 or len(regular) < n:
            return None
        windows: list[tuple[float, float, int]] = []
        for start in range(len(regular) - n + 1):
            costs = [self._setup_match_cost(ev, rec) for ev, rec in zip(evidence, regular[start:start+n])]
            windows.append((float(sum(costs)), float(max(costs) if costs else 0.0), start))
        windows.sort()
        best_total, best_max, start = windows[0]
        second_total = windows[1][0] if len(windows) > 1 else float("inf")
        # Require every row to agree closely and the chosen window to be unique.
        if best_max > 2.5 or best_total > max(5.0, 0.5 * n):
            return None
        if np.isfinite(second_total) and second_total - best_total < max(5.0, 0.25 * n):
            return None
        return regular[start:start+n]

    def read(self, workspace: Path, sonications: list[object]) -> list[SonicationEvidence]:
        workspace = Path(workspace)
        summary_path = self._find_first(workspace, "SonicationSummary.xml")
        spot_path = self._find_first(workspace, "spotsonicationdata.xml")
        summary = self._rows_by_index(summary_path)
        spot = self._rows_by_index(spot_path)
        result: list[SonicationEvidence] = []

        for index0, model in enumerate(sonications):
            try:
                n = int(getattr(model, "sonication_number", 0) or 0)
            except (TypeError, ValueError):
                n = 0
            if n <= 0:
                name = str(getattr(model, "name", ""))
                m = re.search(r"(\d+)$", name)
                n = int(m.group(1)) if m else index0 + 1
            sr = summary.get(n, {})
            pr = spot.get(n, {})
            folder = Path(getattr(model, "folder", workspace / f"Sonication{n}"))
            spectrum_files = list(getattr(model, "spectrum_files", []) or [])
            spectrum_path = next((Path(p) for p in spectrum_files if "spectrummsg" in Path(p).name.lower()), None)
            if spectrum_path is None:
                direct = folder / f"SpectrumMsg-{n}.dmp"
                spectrum_path = direct if direct.exists() else None
            frame_count = channel_count = None
            spectrum_layout = None
            spectrum_fft_bins = None
            spectrum_spacing_hz = None
            spectrum_last_time_s = None
            if spectrum_path is not None and spectrum_path.exists():
                try:
                    st = decode_spectrum_structure(spectrum_path)
                    frame_count = st.frame_count
                    channel_count = st.channel_count or None
                    spectrum_layout = st.layout
                    spectrum_fft_bins = st.fft_bins
                    spectrum_spacing_hz = st.frequency_spacing_hz
                    spectrum_last_time_s = st.last_timestamp_seconds
                except Exception:
                    pass
            # PowerGraph rows are indexed by treatment Sonication number, not by
            # the current ReplayPackage list position.
            pg = self._power_graph(workspace, max(0, n - 1))
            pt = np.asarray(pg[0], float) if pg is not None else np.array([], dtype=float)
            pp = np.asarray(pg[1], float) if pg is not None else np.array([], dtype=float)
            evidence_folders = list(getattr(model, "evidence_folders", []) or [])
            if not evidence_folders and folder.exists():
                evidence_folders = [folder]
            all_local = []
            seen_local: set[Path] = set()
            for evidence_folder in evidence_folders:
                if not Path(evidence_folder).exists():
                    continue
                for p in Path(evidence_folder).rglob("*"):
                    if p.is_file() and p.resolve() not in seen_local:
                        seen_local.add(p.resolve())
                        all_local.append(p)
            inventory = {
                "total": len(all_local),
                "spectrummsg": sum("spectrummsg" in p.name.lower() for p in all_local),
                "act": sum(p.suffix.lower() == ".act" for p in all_local),
                "raw": sum(p.suffix.lower() == ".raw" for p in all_local),
                "ini": sum(p.suffix.lower() == ".ini" for p in all_local),
                "log_or_text": sum(p.suffix.lower() in (".txt", ".log", ".out") for p in all_local),
            }
            ev = SonicationEvidence(
                sonication_index=n,
                file_inventory=inventory,
                spectrummsg_path=spectrum_path,
                spectrummsg_frame_count=frame_count,
                spectrummsg_channel_count=channel_count,
                spectrummsg_layout=spectrum_layout,
                spectrummsg_fft_bins=spectrum_fft_bins,
                spectrummsg_spacing_hz=spectrum_spacing_hz,
                spectrummsg_last_time_s=spectrum_last_time_s,
                powergraph_size=self._i(pr, "powergraphsize"),
                powergraph_time_s=pt,
                powergraph_power_percent=pp,
                actual_duration_s=self._f(pr, "actualsonicduration"),
                displayed_power_w=self._f(pr, "displayedpower"),
                summary_power_w=self._f(sr, "power"),
                summary_duration_s=self._f(sr, "duration"),
                summary_energy_j=self._f(sr, "energy"),
                frequency_hz=self._f(sr, "frequency"),
                focal_ras=(self._f(sr, "focalrasx"), self._f(sr, "focalrasy"), self._f(sr, "focalrasz")),
                cavitation_safety_mode=self._i(pr, "cavitationsafetymode"),
                acoustic_threshold=self._f(pr, "acousticthreshold"),
            )
            ev.evidence.append("Sonication folder inventory: " + ", ".join(f"{k}={v}" for k, v in inventory.items()))
            if ev.spectrum_powergraph_exact:
                ev.evidence.append(f"SpectrumMsg frame count {frame_count} == PowerGraphSize {ev.powergraph_size}")
                if ev.spectrummsg_layout:
                    ev.evidence.append(
                        f"SpectrumMsg layout={ev.spectrummsg_layout}; FFT bins={ev.spectrummsg_fft_bins or '-'}; "
                        f"df={ev.spectrummsg_spacing_hz:g} Hz" if ev.spectrummsg_spacing_hz is not None
                        else f"SpectrumMsg layout={ev.spectrummsg_layout}"
                    )
            elif frame_count is not None and ev.powergraph_size is not None:
                ev.evidence.append(f"SpectrumMsg/PowerGraphSize mismatch {frame_count}!={ev.powergraph_size}")
            if ev.actual_duration_s is not None and pt.size:
                delta = abs(float(pt[-1]) - float(ev.actual_duration_s))
                if delta <= 0.01:
                    ev.evidence.append(f"PowerGraph end {pt[-1]:.6f}s == actualsonicduration")
                else:
                    ev.evidence.append(f"PowerGraph/actual duration delta {delta:.3f}s")
            if ev.spectrummsg_last_time_s is not None and pt.size:
                tdelta = abs(float(pt[-1]) - float(ev.spectrummsg_last_time_s))
                ev.spectrum_powergraph_time_exact = bool(tdelta <= 1e-6)
                if ev.spectrum_powergraph_time_exact:
                    ev.evidence.append(
                        f"SpectrumMsg embedded time {ev.spectrummsg_last_time_s:.6f}s == PowerGraph end exactly"
                    )
                else:
                    ev.evidence.append(f"SpectrumMsg/PowerGraph end delta {tdelta:.6f}s")
            result.append(ev)

        setup_records = self.parse_setup_records(workspace)
        # Workstation StartSonicate uses a zero-based Sonication Counter.  When
        # available this is an explicit identity key and is preferred over any
        # positional/signature window.
        by_counter = {int(r.sonication_counter) + 1: r for r in setup_records if r.sonication_counter is not None}
        for ev in result:
            rec = by_counter.get(ev.sonication_index)
            if rec is not None:
                ev.setup_record = rec
                ev.evidence.append(
                    f"WS StartSonicate counter {rec.sonication_counter} exact identity: power={rec.power_w:g}W, "
                    f"duration={rec.duration_s:g}s, frequency={rec.frequency_hz/1e3:g}kHz"
                    if rec.power_w is not None and rec.duration_s is not None and rec.frequency_hz is not None
                    else f"WS StartSonicate counter {rec.sonication_counter} exact identity"
                )
                if rec.subsonication_count is not None:
                    ev.evidence.append(
                        f"WS sub-sonications={rec.subsonication_count}; RAS coordinates={len(rec.subsonication_ras)}"
                    )
        numbers = [ev.sonication_index for ev in result]
        # Positional Type-6 setup windows are defensible only when logical
        # Sonication identity itself is contiguous. For sparse identity sets,
        # leave setup/session unresolved rather than silently shifting rows.
        contiguous = numbers == list(range(numbers[0], numbers[0] + len(numbers))) if numbers else True
        matched = self._match_regular_setup_window(result, setup_records) if contiguous else None
        if matched is not None:
            for ev, rec in zip(result, matched):
                if ev.setup_record is not None:
                    continue
                ev.setup_record = rec
                ev.evidence.append(
                    f"Sonication_Brain Type6 setup exact signature: power={rec.power_w:g}W, "
                    f"duration={rec.duration_s:g}s, frequency={rec.frequency_hz/1e3:g}kHz"
                )

        # Bind setup clock to Acquisition_Brain session start. This is independent
        # evidence from the CPC filename/session-end binding used by SpectrumDumps.
        log = self.acoustic.find_log(workspace)
        sessions = self.acoustic.parse_segments(log) if log is not None else []
        used_sessions: set[int] = set()
        for ev in result:
            rec = ev.setup_record
            if rec is None or not sessions:
                continue
            choices = []
            for si, session in enumerate(sessions):
                if si in used_sessions:
                    continue
                delta = self._clock_delta_s(float(session.start_clock_s), rec.clock_s)
                if -0.25 <= delta <= 6.0:
                    choices.append((abs(delta), si, delta))
            if not choices:
                continue
            err, si, delta = min(choices)
            if err <= 3.0:
                ev.acquisition_session_index = int(si)
                ev.acquisition_session_start_error_s = float(err)
                used_sessions.add(si)
                ev.evidence.append(
                    f"Acquisition_Brain session {si+1} starts {delta:.3f}s after Type6 setup"
                )

        for ev in result:
            strong = bool(ev.spectrum_powergraph_exact and ev.spectrum_powergraph_time_exact and ev.setup_record is not None and ev.acquisition_session_index is not None)
            ev.confidence = "Exact" if strong else ("High" if ev.setup_record is not None or ev.acquisition_session_index is not None else "Unknown")
        return result
