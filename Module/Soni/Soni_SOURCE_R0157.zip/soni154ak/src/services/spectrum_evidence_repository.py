from __future__ import annotations

import threading
from pathlib import Path

import numpy as np

from src.services.spectrum_dump_import_service import SpectrumDumpImportService
from src.services.hydrophone_replay_service import HydrophoneReplayService
from src.services.standalone_cavitation_service import StandaloneCavitationService
from src.services.cavitation_control_timeline_service import CavitationControlTimelineService
from src.services.spectrummsg_aggregate_service import SpectrumMsgAggregateService
from src.services.acoustic_control_service import AcousticControlService


class SpectrumEvidenceRepository:
    """Study-scoped shared Spectrum decode/evidence cache.

    Multiple background consumers (preload, Summary, Treatment Outcome) can ask for
    the same Sonication.  Exactly one decoder owns a Sonication at a time; peers wait
    for that result rather than performing duplicate FFT/vendor-rule work.
    """

    def __init__(self, hydrophone_service=None, acoustic_control_service=None, standalone_service=None):
        self.hydrophone = hydrophone_service or HydrophoneReplayService()
        self.acoustic = acoustic_control_service or AcousticControlService()
        self.standalone = standalone_service or StandaloneCavitationService()
        self._condition = threading.Condition()
        self._workspace_token = None
        self._mapping = None
        self._candidates = None
        self._replays = {}
        self._standalone = {}
        self._errors = {}
        self._inflight = set()
        self._secondary = {}
        self._secondary_errors = {}
        self._secondary_inflight = set()

    @staticmethod
    def _token(package) -> str:
        try:
            return str(Path(package.workspace).resolve())
        except Exception:
            return str(getattr(package, "workspace", ""))

    def clear(self) -> None:
        with self._condition:
            self._workspace_token = None
            self._mapping = None
            self._candidates = None
            self._replays.clear(); self._standalone.clear(); self._errors.clear(); self._inflight.clear()
            self._secondary.clear(); self._secondary_errors.clear(); self._secondary_inflight.clear()
            self._condition.notify_all()

    def _ensure_workspace(self, package) -> str:
        token = self._token(package)
        with self._condition:
            if self._workspace_token != token:
                self._workspace_token = token
                self._mapping = None
                self._candidates = None
                self._replays.clear(); self._standalone.clear(); self._errors.clear(); self._inflight.clear()
                self._secondary.clear(); self._secondary_errors.clear(); self._secondary_inflight.clear()
        return token

    @staticmethod
    def _candidate_identity(candidate) -> tuple:
        """Stable identity used when the fast inventory and deep scan overlap."""
        parts=[]
        for name in ("fft_path", "raw_path", "source"):
            value=getattr(candidate,name,None)
            if value is None:
                parts.append("")
                continue
            try:
                parts.append(str(Path(value).resolve()))
            except Exception:
                parts.append(str(value))
        return tuple(parts)

    @staticmethod
    def _dedupe_candidates(importer, candidates):
        fn = getattr(importer, "deduplicate_content_equivalent_candidates", None)
        return list(fn(candidates) if callable(fn) else candidates)

    @staticmethod
    def _map_candidates(importer, candidates, sonications, workspace):
        try:
            return importer.map_candidates_to_sonications(candidates, sonications, workspace)
        except TypeError:
            # Backward-compatible with older test doubles / source snapshots.
            return importer.map_candidates_to_sonications(candidates, sonications)

    def candidate_universe(self, package):
        """Return the complete CPC/Spectrum source universe for one loaded Export.

        Package discovery can legitimately expose only a partial CPC file inventory.
        R0135 trusted that partial list as soon as *any* CPC candidate was found,
        which meant a study with 8 Sonications could hand only 5 candidates to the
        Analyzer.  We now accept the fast inventory only when it produces complete
        Sonication coverage; otherwise one worker-owned recursive discovery expands
        the universe and de-duplicates the overlap deterministically.
        """
        self._ensure_workspace(package)
        with self._condition:
            if self._candidates is not None:
                return list(self._candidates)
            importer=SpectrumDumpImportService()
            workspace=Path(package.workspace)
            sonications=list(getattr(package,"sonications",[]) or [])
            inventory=list(getattr(package,"cpc_spectrum_files",[]) or [])
            # R0154q: package.cpc_spectrum_files intentionally excludes embedded
            # SpectrumMsg. If physical CPC already mapped every Sonication, the
            # old fast-path skipped the deep scan and the Analyzer never saw the
            # Sonication-owned SpectrumMsg streams. Merge those explicit files
            # into the fast universe so physical RCV and aggregate 220 evidence
            # are both available without a second recursive walk.
            for son in sonications:
                inventory.extend(list(getattr(son,"spectrum_files",[]) or []))
            inventory=sorted(set(Path(v) for v in inventory if v is not None),key=lambda q:str(q).lower())
            fast=list(importer.discover_from_files(workspace,inventory) or [])
            fast=self._dedupe_candidates(importer, fast)
            fast_map=self._map_candidates(importer, fast, sonications, workspace) if fast else {}
            needs_deep = len(fast_map) < len(sonications)
            candidates=list(fast)
            if needs_deep:
                deep=list(importer.discover(workspace) or [])
                merged={}
                for candidate in [*fast,*deep]:
                    merged.setdefault(self._candidate_identity(candidate),candidate)
                candidates=list(merged.values())
            candidates=self._dedupe_candidates(importer, candidates)
            self._candidates=candidates
            return list(self._candidates)

    def exact_spectrummsg_candidate(self, package, index: int):
        """Return one exact Sonication-owned SpectrumMsg candidate or None."""
        matches=[
            c for c in self.candidate_universe(package)
            if getattr(c, "family", "") == "SpectrumMsg"
            and SpectrumDumpImportService._explicit_sonication_number(c) == int(index) + 1
        ]
        return matches[0] if len(matches) == 1 else None

    def candidate_mapping(self, package):
        self._ensure_workspace(package)
        with self._condition:
            if self._mapping is not None:
                return self._mapping
            importer=SpectrumDumpImportService()
            candidates=self.candidate_universe(package)
            sonications=list(getattr(package,"sonications",[]) or [])
            self._mapping=self._map_candidates(importer, candidates, sonications, Path(package.workspace))
            return self._mapping

    def authoritative_session(self, package, index: int, son=None) -> int | None:
        """One Acquisition session owner shared by Power, CPC and control evidence."""
        index=int(index)
        if son is None:
            sons=list(getattr(package,"sonications",[]) or [])
            son=sons[index] if 0 <= index < len(sons) else None
        candidate=self.candidate_mapping(package).get(index)
        value=getattr(candidate,"acquisition_session_index",None) if candidate is not None else None
        if value is None and son is not None:
            value=getattr(son,"canonical_acquisition_session_index",None)
        if value is None and self.acoustic is not None:
            try:
                log=self.acoustic.find_log(Path(package.workspace))
                segments=self.acoustic.parse_segments(log) if log is not None else []
                if segments:
                    value=self.acoustic._treatment_segment_index(Path(package.workspace),index,len(segments))
            except Exception:
                value=None
        return int(value) if value is not None else None

    def authoritative_context(self, package, index: int, son=None, progress_callback=None) -> dict:
        """Materialize the single authoritative evidence binding for one Sonication."""
        index=int(index)
        candidates=self.candidate_universe(package)
        mapping=self.candidate_mapping(package)
        candidate=mapping.get(index)
        spectrummsg=self.exact_spectrummsg_candidate(package,index)
        if candidate is None and spectrummsg is None:
            audit = dict(getattr(package, "import_audit", {}) or {})
            audit_suffix = ""
            if audit:
                issues = list(audit.get("issues", []) or [])
                audit_suffix = (
                    f" Import audit {audit.get('status', 'UNKNOWN')}: "
                    f"folders={audit.get('sonication_folder_count', '?')}, "
                    f"summary={audit.get('summary_sonication_count', '?')}, "
                    f"SpectrumMsg={audit.get('spectrummsg_count', '?')}, "
                    f"Acquisition sessions={audit.get('acquisition_brain_session_count', '?')}, "
                    f"canonical={audit.get('canonical_session_resolved_count', '?')}/"
                    f"{audit.get('replay_sonication_count', '?')}, "
                    f"CPC mapped={audit.get('cpc_mapped_count', '?')}/"
                    f"{audit.get('replay_sonication_count', '?')}."
                )
                if issues:
                    audit_suffix += " Cause: " + " | ".join(str(x) for x in issues[:3])
            raise RuntimeError(
                f"No authoritative CPC Spectrum mapping for Sonication {index+1} "
                f"({len(mapping)}/{len(list(getattr(package,'sonications',[]) or []))} mapped; "
                f"{len([c for c in candidates if getattr(c,'family','')=='CPC Spectrum'])} CPC candidate(s) discovered)."
                + audit_suffix
            )
        replay=self.replay(package,index,son,progress_callback)
        session=self.authoritative_session(package,index,son)
        if session is not None:
            replay.acquisition_session_index=int(session)
        return {
            "workspace":Path(package.workspace),
            "candidates":list(candidates),
            "mapping":dict(mapping),
            "replays":{index:replay},
            "ready_indices":{index},
            "target_index":index,
            "acquisition_session_index":session,
            "spectral_only": candidate is None and spectrummsg is not None,
        }

    def _configure_replay(self, package, index: int, son, replay, candidate):
        replay.sonication_index = int(index)
        # Preserve the authoritative source-binding provenance on the replay itself.
        # UI/Summary/CI consumers should not regress to Unknown/Unresolved after an
        # exact candidate was selected by SpectrumDumpImportService.
        if candidate is not None:
            replay.mapping_confidence = str(getattr(candidate, "mapping_confidence", None) or replay.mapping_confidence)
            replay.mapping_evidence = str(getattr(candidate, "mapping_evidence", None) or replay.mapping_evidence)
        preferred = getattr(getattr(replay, "vendor_history_validation", None), "log_session_index", None)
        if preferred is None and candidate is not None:
            preferred = getattr(candidate, "acquisition_session_index", None)
        if preferred is None:
            preferred = getattr(son, "canonical_acquisition_session_index", None)
        replay.acquisition_session_index = int(preferred) if preferred is not None else None
        if self.acoustic is not None:
            replay.sonication_time_zero_offset_s = self.acoustic.sonication_time_zero_offset(
                Path(package.workspace), int(index), replay.acquisition_session_index
            )
        # Canonical MR timing must be installed before the controller-cycle map
        # is built.  R0154 cycle_times_s are MR-axis coordinates; parsing them
        # with mr_sonication_start_s=0 and assigning the real start afterwards
        # silently shifted every CPC curve left by the pre-sonication interval.
        replay.mr_timeline_duration_s = float(getattr(son, "mr_timeline_duration_s", 0.0) or 0.0)
        replay.mr_sonication_start_s = float(getattr(son, "mr_sonication_start_s", 0.0) or 0.0)
        replay.mr_sonication_end_s = float(getattr(son, "mr_sonication_end_s", 0.0) or 0.0)
        replay.mr_timeline_source = str(getattr(son, "mr_timeline_source", "Unavailable"))
        replay.mr_timeline_confidence = str(getattr(son, "mr_timeline_confidence", "Unknown"))

        # R0116zzg13/R0154: establish the physical controller-cycle origin once
        # and share the exact Acquisition_Brain wall-clock map with every
        # Spectrum/CI consumer.  The map is anchored directly on the canonical
        # MR Sonication start; subviews must not add that offset again.
        try:
            control = CavitationControlTimelineService().parse(
                replay.source_fft or replay.source_raw or Path(package.workspace),
                None, replay.acquisition_session_index, None, None,
                0.0, replay.mr_sonication_start_s, replay.mr_sonication_end_s,
                replay.mr_timeline_duration_s, None, None, replay.acquisition_interval_s,
            )
            valid_cycles = [int(c) for c in np.asarray(getattr(control, "actual_power_cycles", []), dtype=int).tolist() if int(c) >= 0]
            replay.sonication_cycle_zero = valid_cycles[0] if valid_cycles else None
            replay.controller_cycle_numbers = np.asarray(getattr(control, "cycle_numbers", []), dtype=int)
            replay.controller_cycle_mr_times_s = np.asarray(getattr(control, "cycle_times_s", []), dtype=float)
        except Exception:
            # _configure_replay can run again for a cached replay.  Fail closed
            # rather than leaving a stale cycle map from a previous binding.
            replay.sonication_cycle_zero = None
            replay.controller_cycle_numbers = np.asarray([], dtype=int)
            replay.controller_cycle_mr_times_s = np.asarray([], dtype=float)
        self._repair_snapshot_timing(replay)
        return replay

    @staticmethod
    def _repair_snapshot_timing(replay) -> None:
        """Fail closed on the Brain220-style collapsed FFT-cycle mapping.

        Some physical CPC pairs have perfectly valid 8CH FFT payloads but the
        Band0-history fingerprint is non-unique during the long zero/pre-roll
        region.  The old matcher then assigned snapshots to cycles 1..N, which
        collapsed an entire 20 s sonication into ~0.18 s at MR start.  Spectrum,
        Spectrogram and Band Energy consequently looked empty although the data
        were decoded.

        We never alter amplitudes.  When the measured cycle map is implausibly
        compressed or sits outside the irradiation interval, use exact
        Acquisition_Brain Cycle-N-Done MR timestamps sampled across the actual
        irradiation window as *display timing only*.  Proven mappings are left
        untouched.
        """
        frames=list(getattr(replay,"frames",[]) or [])
        n=len(frames)
        replay.frame_mr_time_override_s=np.asarray([],dtype=float)
        replay.snapshot_timing_source="Fingerprint cycle mapping" if getattr(replay,"snapshot_cycle_mapping_validated",False) else "Unresolved"
        if n < 2:
            return
        cycles=np.asarray(getattr(replay,"controller_cycle_numbers",[]),dtype=float)
        times=np.asarray(getattr(replay,"controller_cycle_mr_times_s",[]),dtype=float)
        good=np.isfinite(cycles)&np.isfinite(times)
        cycles=cycles[good]; times=times[good]
        if cycles.size < n or times.size < n:
            return
        start=float(getattr(replay,"mr_sonication_start_s",0.0) or 0.0)
        end=float(getattr(replay,"mr_sonication_end_s",0.0) or 0.0)
        duration=end-start
        if not np.isfinite(duration) or duration <= 0.2:
            return
        current=[]
        for f in frames:
            c=getattr(f,"acquisition_cycle",None)
            if c is None:
                current=[]; break
            hit=np.flatnonzero(cycles==float(c))
            if not hit.size:
                current=[]; break
            current.append(float(times[int(hit[0])]))
        plausible=False
        if len(current)==n and np.isfinite(current).all():
            span=float(max(current)-min(current))
            inside=sum((start-0.25 <= t <= end+0.25) for t in current)
            plausible=(span >= max(0.25,0.10*duration) and inside >= max(2,int(0.75*n)))
        if plausible:
            replay.snapshot_timing_source="Exact fingerprint/controller-cycle mapping"
            return
        mask=(times >= start-0.05) & (times <= end+0.05)
        eligible=np.flatnonzero(mask)
        if eligible.size < n:
            return
        pos=np.linspace(0,eligible.size-1,n)
        chosen=eligible[np.clip(np.rint(pos).astype(int),0,eligible.size-1)]
        # Ensure strict monotonicity where possible.
        chosen=np.maximum.accumulate(chosen)
        for i in range(1,len(chosen)):
            if chosen[i] <= chosen[i-1] and chosen[i-1]+1 < len(times):
                chosen[i]=chosen[i-1]+1
        if chosen[-1] >= len(times):
            return
        mapped=np.asarray(times[chosen],dtype=float)
        if mapped.size != n or not np.isfinite(mapped).all() or np.any(np.diff(mapped) <= 0):
            return
        replay.frame_mr_time_override_s=mapped
        replay.snapshot_cycle_mapping_validated=False
        replay.snapshot_timing_source="Acquisition_Brain irradiation-window timing (exact cycle timestamps; display positions sampled across irradiation window)"
        # Do NOT rewrite frame.acquisition_cycle here.  acquisition_cycle is evidence
        # used by cavitation/rule correlation and must remain the decoder's original
        # fingerprint result even when that result is rejected for display timing.
        # Only frame_mr_time_override_s is authoritative for the repaired display axis.
        replay.mapping_evidence=str(getattr(replay,"mapping_evidence","Unresolved")) + "; FFT fingerprint timing rejected as collapsed/pre-roll; display timing only rebound to irradiation-window controller timestamps; original acquisition_cycle evidence preserved"

    def replay(self, package, index: int, son=None, progress_callback=None):
        token = self._ensure_workspace(package)
        index = int(index)
        if son is None:
            son = list(getattr(package, "sonications", []) or [])[index]
        with self._condition:
            if index in self._replays:
                return self._replays[index]
            while index in self._inflight:
                self._condition.wait(timeout=0.25)
                if self._workspace_token != token:
                    raise RuntimeError("Spectrum repository study changed during decode")
                if index in self._replays:
                    return self._replays[index]
                if index in self._errors:
                    raise RuntimeError(self._errors[index])
            self._inflight.add(index)
        try:
            candidate = self.candidate_mapping(package).get(index)
            if candidate is None:
                # Legacy fail-closed contract marker: No authoritative CPC Spectrum source
                # is never positionally substituted; only an exact Sonication-owned
                # SpectrumMsg may satisfy the explicit spectral-only route.
                spectrummsg=self.exact_spectrummsg_candidate(package,index)
                if spectrummsg is None or getattr(spectrummsg,"primary_path",None) is None:
                    raise RuntimeError(f"No authoritative CPC or exact SpectrumMsg source for Sonication {index+1}.")
                try:
                    hz=float(getattr(son,"main_frequency_hz",0.0) or getattr(package,"main_frequency_hz",0.0) or 0.0)
                except Exception:
                    hz=0.0
                if hz <= 0.0:
                    raise RuntimeError(f"SpectrumMsg source for Sonication {index+1} has no validated main frequency.")
                if progress_callback is not None:
                    progress_callback(35,f"Decoding exact SpectrumMsg-only source for Sonication {index+1}…")
                replay=SpectrumMsgAggregateService().build(spectrummsg.primary_path,hz)
                try:
                    replay.vendor_profile=self.hydrophone.vendor_reproduction.read_profile(spectrummsg.primary_path,hz)
                except Exception:
                    replay.vendor_profile=None
                if replay is None or not getattr(replay,"frames",None):
                    raise RuntimeError(f"SpectrumMsg decode returned zero frames for Sonication {index+1}.")
                replay.sonication_index=int(index)
                replay.mr_timeline_duration_s=float(getattr(son,"mr_timeline_duration_s",0.0) or 0.0)
                replay.mr_sonication_start_s=float(getattr(son,"mr_sonication_start_s",0.0) or 0.0)
                replay.mr_sonication_end_s=float(getattr(son,"mr_sonication_end_s",0.0) or 0.0)
                replay.mr_timeline_source=str(getattr(son,"mr_timeline_source","Unavailable"))
                replay.mr_timeline_confidence=str(getattr(son,"mr_timeline_confidence","Unknown"))
                replay.mapping_evidence=f"Exact Sonication{index+1} SpectrumMsg ownership; physical CPC unavailable"
                replay.mapping_confidence="Exact spectral / no physical CPC"
            else:
                replay = self.hydrophone.build_direct(
                    candidate.fft_path, candidate.raw_path,
                    progress_callback=progress_callback, include_vendor_validation=True,
                )
                if replay is None or not getattr(replay, "frames", None):
                    raise RuntimeError(f"Spectrum decode returned zero frames for Sonication {index+1}.")
                replay = self._configure_replay(package, index, son, replay, candidate)
            # R0154ab: a loaded 220/230-kHz Sonication is composite at repository
            # ownership time, not only after the Analyzer window is opened.  The
            # physical CPC replay remains authoritative for 8CH history/control;
            # the exact Sonication-owned SpectrumMsg stream is attached as the
            # spectral sidecar used by Spectrum/Spectrogram.  This removes the
            # hidden lazy decode that previously began only on first Analyzer use.
            try:
                hz=float(getattr(son, "main_frequency_hz", 0.0) or getattr(package, "main_frequency_hz", 0.0) or 0.0)
            except Exception:
                hz=0.0
            if candidate is not None and 150000.0 <= hz <= 350000.0:
                msg_candidates=[
                    c for c in self.candidate_universe(package)
                    if getattr(c, "family", "") == "SpectrumMsg"
                    and SpectrumDumpImportService._explicit_sonication_number(c) == index + 1
                ]
                if len(msg_candidates) == 1 and getattr(msg_candidates[0], "primary_path", None) is not None:
                    graph=self.acoustic.power_graph_for_sonication(Path(package.workspace),int(index))
                    # PowerGraph values are Sonication-relative. CpcHydrophoneReplay
                    # adds mr_sonication_start_s exactly once in mr_frame_times_s.
                    graph_times=np.asarray(graph[0],float) if graph is not None else None
                    spectral=SpectrumMsgAggregateService().build(msg_candidates[0].primary_path, hz, graph_times)
                    try:
                        spectral.vendor_profile=self.hydrophone.vendor_reproduction.read_profile(msg_candidates[0].primary_path,hz)
                    except Exception:
                        spectral.vendor_profile=None
                    if spectral is not None and getattr(spectral, "frames", None):
                        spectral.sonication_index=int(index)
                        spectral.mr_timeline_duration_s=float(getattr(son, "mr_timeline_duration_s", 0.0) or 0.0)
                        spectral.mr_sonication_start_s=float(getattr(son, "mr_sonication_start_s", 0.0) or 0.0)
                        spectral.mr_sonication_end_s=float(getattr(son, "mr_sonication_end_s", 0.0) or 0.0)
                        spectral.mr_timeline_source=str(getattr(son, "mr_timeline_source", "Unavailable"))
                        spectral.mr_timeline_confidence=str(getattr(son, "mr_timeline_confidence", "Unknown"))
                        replay.spectral_replay=spectral
                        replay.spectral_source_kind="Sonication-owned SpectrumMsg"
                        replay.mapping_evidence=str(getattr(replay, "mapping_evidence", "Unresolved")) + "; exact Sonication-owned SpectrumMsg spectral sidecar preloaded"
            with self._condition:
                if self._workspace_token == token:
                    self._replays[index] = replay
                    self._errors.pop(index, None)
            return replay
        except Exception as exc:
            with self._condition:
                if self._workspace_token == token:
                    self._errors[index] = str(exc)
            raise
        finally:
            with self._condition:
                self._inflight.discard(index)
                self._condition.notify_all()

    def standalone_analysis(self, package, index: int, son=None, progress_callback=None):
        token = self._ensure_workspace(package)
        index = int(index)
        with self._condition:
            if index in self._standalone:
                return self._standalone[index]
        replay = self.replay(package, index, son, progress_callback)
        analysis = self.standalone.analyze(replay, "Auto Evidence-First", 6.0)
        with self._condition:
            if self._workspace_token == token:
                self._standalone[index] = analysis
        return analysis

    def cached_replay(self, package, index: int):
        token = self._ensure_workspace(package)
        with self._condition:
            if self._workspace_token != token:
                return None
            return self._replays.get(int(index))
    @staticmethod
    def _replay_key(index: int, replay) -> tuple | None:
        """Stable replay identity across equivalent decode/handoff instances."""
        if replay is None or not getattr(replay, "frames", None):
            return None
        source = getattr(replay, "source_fft", None) or getattr(replay, "source_raw", None)
        try:
            source_key = str(Path(source).resolve()) if source is not None else ""
        except Exception:
            source_key = str(source or "")
        spectral = getattr(replay, "spectral_replay", None)
        spectral_source = getattr(spectral, "source_fft", None) or getattr(spectral, "source_raw", None) if spectral is not None else None
        try:
            spectral_key = str(Path(spectral_source).resolve()) if spectral_source is not None else ""
        except Exception:
            spectral_key = str(spectral_source or "")
        spectral_count = int(len(getattr(spectral, "frames", []) or [])) if spectral is not None else 0
        return (int(index), source_key, int(len(replay.frames)), spectral_key, spectral_count)

    @classmethod
    def _payload_matches_replay(cls, payload, index: int, replay) -> bool:
        if payload is None or replay is None:
            return payload is not None and replay is None
        key = cls._replay_key(index, replay)
        cached_key = payload.get("replay_key") if isinstance(payload, dict) else None
        if cached_key is not None:
            try:
                return tuple(cached_key) == tuple(key)
            except Exception:
                return False
        return isinstance(payload, dict) and payload.get("replay_id") == id(replay)

    @staticmethod
    def _secondary_key(index: int, channel: int, analysis_mode: str, candidate_z: float):
        return (int(index), int(channel), str(analysis_mode), round(float(candidate_z), 6))

    @staticmethod
    def _observed_control_timeline(replay):
        validation = getattr(replay, "vendor_control_validation", None)
        predicted_cycles = validation.event_cycles if validation is not None else []
        predicted_ratio = validation.predicted_power_ratio if validation is not None else []
        history_validation = getattr(replay, "vendor_history_validation", None)
        preferred_session = history_validation.log_session_index if history_validation is not None else getattr(replay, "acquisition_session_index", None)
        source_path = replay.source_fft or replay.source_raw
        anchor = next((f for f in getattr(replay, "frames", []) if getattr(f, "acquisition_cycle", None) is not None and getattr(f, "acquisition_time_s", None) is not None), None)
        return CavitationControlTimelineService().parse(
            source_path, getattr(replay, "vendor_profile", None), preferred_session,
            predicted_cycles, predicted_ratio,
            getattr(replay, "sonication_time_zero_offset_s", 0.0),
            getattr(replay, "mr_sonication_start_s", 0.0),
            getattr(replay, "mr_sonication_end_s", 0.0),
            getattr(replay, "mr_timeline_duration_s", 0.0),
            getattr(anchor, "acquisition_cycle", None) if anchor is not None else None,
            getattr(anchor, "acquisition_time_s", None) if anchor is not None else None,
            getattr(replay, "acquisition_interval_s", 0.010),
        )

    def secondary_products(self, package, index: int, channel: int, analysis_mode: str, candidate_z: float, replay=None):
        """Return all derived Spectrum products from one study-scoped cache.

        Spectrogram, Vendor Band Energy and canonical dump-side cavitation analysis
        are produced together so Analyzer tabs cannot disagree about whether the
        same replay is ready. This method is worker-thread only: peer workers may
        wait on the condition, but the GUI thread never calls it.
        """
        token = self._ensure_workspace(package)
        key = self._secondary_key(index, channel, analysis_mode, candidate_z)
        with self._condition:
            cached = self._secondary.get(key)
            # R0116zzg9: secondary products are valid only for the exact replay
            # object that produced them.  The same Sonication key can be decoded
            # again/rebound during Analyzer handoff; returning a payload carrying
            # an old replay_id makes every secondary renderer reject it forever.
            if cached is not None and (replay is None or self._payload_matches_replay(cached, index, replay)):
                return cached
            if cached is not None and replay is not None and not self._payload_matches_replay(cached, index, replay):
                self._secondary.pop(key, None)
                self._secondary_errors.pop(key, None)
            while key in self._secondary_inflight:
                self._condition.wait(timeout=0.25)
                if self._workspace_token != token:
                    raise RuntimeError("Spectrum repository study changed during secondary analysis")
                cached = self._secondary.get(key)
                if cached is not None and (replay is None or self._payload_matches_replay(cached, index, replay)):
                    return cached
                if cached is not None and replay is not None and not self._payload_matches_replay(cached, index, replay):
                    self._secondary.pop(key, None)
                    self._secondary_errors.pop(key, None)
                if key in self._secondary_errors:
                    raise RuntimeError(self._secondary_errors[key])
            self._secondary_inflight.add(key)
        try:
            replay = replay or self.replay(package, int(index))
            if replay is None or not getattr(replay, "frames", None):
                raise RuntimeError(f"Spectrum secondary analysis has no decoded frames for Sonication {int(index)+1}.")
            payload = {
                "replay_id": id(replay),
                "replay_key": self._replay_key(index, replay),
                "channel": int(channel),
                "analysis_mode": str(analysis_mode),
                "candidate_z": float(candidate_z),
            }
            spectral=getattr(replay, "spectral_replay", None)
            spectrum_replay=spectral or replay
            spectrum_channel=0 if spectral is not None else int(channel)
            payload["product_errors"]={}
            try:
                payload["spectrogram"] = self.hydrophone.spectrogram(spectrum_replay, spectrum_channel)
            except Exception as exc:
                payload["spectrogram"] = None
                payload["product_errors"]["spectrogram"]=f"{type(exc).__name__}: {exc}"
            resolved = self.standalone.resolved_band_ranges(replay)
            if not resolved and spectral is not None:
                resolved = self.standalone.resolved_band_ranges(spectral)
            payload["resolved_bands"] = resolved
            energies = {}
            aggregate_energies = {}
            for band_index, values in resolved.items():
                low, high = float(values[0]), float(values[1])
                exact = bool(getattr(replay, "vendor_embedded_band_energy_available", False))
                try:
                    if exact:
                        energies[int(band_index)] = self.hydrophone.vendor_band_energy(replay, int(band_index))
                    else:
                        energies[int(band_index)] = self.hydrophone.band_energy(replay, low, high)
                except Exception as exc:
                    payload["product_errors"][f"physical_band_{int(band_index)}"]=f"{type(exc).__name__}: {exc}"
                if spectral is not None:
                    try:
                        aggregate=np.asarray(self.hydrophone.band_energy(spectral,low,high),dtype=float)
                        if aggregate.ndim == 2 and aggregate.shape[1]:
                            aggregate=aggregate[:,0]
                        aggregate_energies[int(band_index)]=np.asarray(aggregate,dtype=float).reshape(-1)
                    except Exception as exc:
                        payload["product_errors"][f"aggregate_band_{int(band_index)}"]=f"{type(exc).__name__}: {exc}"
            payload["band_energy"] = energies
            payload["aggregate_band_energy"] = aggregate_energies
            payload["aggregate_time_s"] = np.asarray(getattr(spectral,"mr_frame_times_s",[]),dtype=float) if spectral is not None else np.asarray([],dtype=float)
            # R0117: evidence-only f0/2 sub-harmonic flags per receiver, produced
            # in the same worker-thread pass as the other secondary products.
            try:
                payload["subharmonic_events"] = {
                    int(ch): replay.subharmonic_events(channel=int(ch))
                    for ch in range(int(getattr(replay, "channel_count", 0) or 0))
                }
            except Exception:
                payload["subharmonic_events"] = {}
            # For a composite Brain220 replay, cavitation spectral evidence must
            # follow the full SpectrumMsg stream. Physical CPC remains available
            # separately for per-RCV history and observed controller validation.
            analysis_replay=spectral or replay
            try:
                payload["cavitation_analysis"] = self.standalone.analyze(analysis_replay, str(analysis_mode), float(candidate_z))
                payload["preirradiation_cavitation_summary"] = self.standalone.summarize_preirradiation(
                    analysis_replay, payload["cavitation_analysis"]
                )
            except Exception as exc:
                payload["product_errors"]["aggregate_cavitation"]=f"{type(exc).__name__}: {exc}"
                try:
                    payload["cavitation_analysis"] = self.standalone.analyze(replay, str(analysis_mode), float(candidate_z))
                    payload["preirradiation_cavitation_summary"] = self.standalone.summarize_preirradiation(replay,payload["cavitation_analysis"])
                except Exception as fallback_exc:
                    payload["cavitation_analysis"]=None; payload["preirradiation_cavitation_summary"]=None
                    payload["product_errors"]["cavitation"]=f"{type(fallback_exc).__name__}: {fallback_exc}"
            try:
                payload["observed_cavitation_timeline"] = self._observed_control_timeline(replay)
            except Exception as exc:
                payload["observed_cavitation_timeline"]=None
                payload["product_errors"]["control_timeline"]=f"{type(exc).__name__}: {exc}"
            try:
                payload["gap_reconstruction"] = replay.reconstruction_support()
            except Exception as exc:
                payload["gap_reconstruction"]={}
                payload["product_errors"]["gap_reconstruction"]=f"{type(exc).__name__}: {exc}"
            with self._condition:
                if self._workspace_token == token:
                    self._secondary[key] = payload
                    self._secondary_errors.pop(key, None)
            return payload
        except Exception as exc:
            with self._condition:
                if self._workspace_token == token:
                    self._secondary_errors[key] = str(exc)
            raise
        finally:
            with self._condition:
                self._secondary_inflight.discard(key)
                self._condition.notify_all()

    def cached_secondary_products(self, package, index: int, channel: int, analysis_mode: str, candidate_z: float, replay=None):
        token = self._ensure_workspace(package)
        key = self._secondary_key(index, channel, analysis_mode, candidate_z)
        with self._condition:
            if self._workspace_token != token:
                return None
            payload = self._secondary.get(key)
            if payload is None and replay is not None and getattr(replay,"spectral_replay",None) is not None:
                # Composite Brain220 Spectrogram/Band products are aggregate and
                # independent of the selected physical RCV. Reuse the single
                # precomputed aggregate payload instead of starting hidden work
                # when the receiver selector currently says RCV4, etc.
                aggregate_key=self._secondary_key(index,0,analysis_mode,candidate_z)
                base=self._secondary.get(aggregate_key)
                if base is not None and self._payload_matches_replay(base,index,replay):
                    payload=dict(base); payload["channel"]=int(channel); payload["replay_key"]=self._replay_key(index,replay)
            if payload is not None and replay is not None and not self._payload_matches_replay(payload, index, replay):
                # Never hand a stale derived-product cache to the GUI.  Remove it
                # so the next worker computes against the authoritative replay.
                self._secondary.pop(key, None)
                self._secondary_errors.pop(key, None)
                return None
            return payload
