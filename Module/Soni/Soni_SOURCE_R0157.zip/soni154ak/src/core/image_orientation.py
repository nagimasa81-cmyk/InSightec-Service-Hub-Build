from __future__ import annotations

import numpy as np


def receiver_field_to_raster_rows(array: np.ndarray) -> np.ndarray:
    """Convert receiver-reference Cartesian Y-up rows to raster row-0-at-top.

    CavitationLikelihoodService builds maps with y coordinates increasing from
    -Y to +Y as row index increases. Anatomical MR arrays use conventional
    raster indexing where row 0 is displayed at the top. The conversion is a
    single vertical flip and must be applied exactly once when a receiver field
    is projected onto an anatomical image.
    """
    arr = np.asarray(array)
    return np.flipud(arr)


def raster_rows_to_receiver_field(array: np.ndarray) -> np.ndarray:
    """Inverse of :func:`receiver_field_to_raster_rows`."""
    arr = np.asarray(array)
    return np.flipud(arr)


def normalized_y_to_raster_row(y: float, height: int, *, extent: float = 1.0) -> float:
    """Map Cartesian normalized Y-up coordinate to raster row coordinate."""
    h = max(1, int(height))
    e = max(float(abs(extent)), 1e-12)
    return (e - float(y)) / (2.0 * e) * max(1, h - 1)


def normalized_x_to_raster_col(x: float, width: int, *, extent: float = 1.0) -> float:
    """Map Cartesian normalized X coordinate to raster column coordinate."""
    w = max(1, int(width))
    e = max(float(abs(extent)), 1e-12)
    return (float(x) + e) / (2.0 * e) * max(1, w - 1)
