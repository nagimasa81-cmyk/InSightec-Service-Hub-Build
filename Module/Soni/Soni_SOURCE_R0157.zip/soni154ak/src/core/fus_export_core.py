
from __future__ import annotations
import gzip, json, math, re, struct, xml.etree.ElementTree as ET
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Iterable

FIELD_SEMANTICS = {
    2:  ("Local derived thermal/dose map A", "float64/local"),
    5:  ("Temperature map", "float32"),
    6:  ("Thermometry magnitude", "uint16"),
    7:  ("Treatment-day MR Primary", "uint16"),
    8:  ("Treatment-day MR Secondary", "uint16"),
    9:  ("Reserved / empty placeholder", "none"),
    12: ("Treatment-day Tissue / Third MR", "uint16"),
    16: ("Pre-Plan CT", "int16 HU"),
    19: ("Pre-Plan MR Primary", "uint16"),
    20: ("Pre-Plan MR Secondary", "uint16"),
    21: ("Pre-Plan MR Third", "uint16"),
    23: ("Thermometry validity / rejection mask", "float64 mask"),
    28: ("Temperature reference / 37 C baseline", "float32"),
    33: ("Background / valid-region mask", "uint8 mask"),
    34: ("Local derived thermal/dose map B", "float64/local"),
    37: ("Motion reference Primary / 3Plane-Volume", "uint16"),
    38: ("Motion reference Secondary / 3Plane-Volume", "uint16"),
    39: ("Motion reference Third / 3Plane-Volume", "uint16"),
    40: ("Motion current Primary / 3Plane-Volume", "uint16"),
    41: ("Motion current Secondary / 3Plane-Volume", "uint16"),
    42: ("Motion current Third / 3Plane-Volume", "uint16"),
    43: ("Treatment-day / Live original MR volume", "uint16"),
    44: ("Pre-Plan original MR volume", "uint16"),
}

RAW_RE = re.compile(r"^(?P<field>\d+)-(?P<son>\d+)-(?P<group>\d+)-(?P<frame>\d+)\.raw$", re.I)
SON_RE = re.compile(r"^sonication\s*[_-]?\s*(\d+)$", re.I)
SPEC_RE = re.compile(r"^spectrummsg-(\d+)\.dmp$", re.I)

@dataclass
class Capability:
    name: str
    available: bool
    degraded: bool = False
    reason: str = ""
    evidence: list[str] = field(default_factory=list)

@dataclass
class SpectrumStructure:
    path: str
    compressed: bool = False
    exact_structure: bool = False
    header_size: int = 0
    frame_count: int = 0
    frame_size: int = 0
    channel_count: int = 0
    bytes_per_channel: int = 0
    float32_per_channel: int = 0
    frame_period_hint_s: float | None = None
    format_confidence: str = "Unknown"
    warnings: list[str] = field(default_factory=list)
    layout: str = "Unknown"
    fft_bins: int | None = None
    frequency_spacing_hz: float | None = None
    frequency_end_hz: float | None = None
    history_samples: int | None = None
    last_timestamp_seconds: float | None = None

@dataclass
class SonicationInspection:
    number: int
    folder: str
    status: str
    score: int
    capabilities: dict[str, Capability] = field(default_factory=dict)
    missing_required: list[str] = field(default_factory=list)
    missing_optional: list[str] = field(default_factory=list)
    degraded_items: list[str] = field(default_factory=list)
    present_fields: dict[int, int] = field(default_factory=dict)
    file_count: int = 0
    spectrum: list[SpectrumStructure] = field(default_factory=list)
    thermometry_mode: str = "Unknown"

    @property
    def replayable(self) -> bool:
        return any(v.available for k, v in self.capabilities.items()
                   if k in {"thermometry", "spectrum", "planning", "motion", "elements", "skull"})

@dataclass
class ExportInspection:
    root: str
    workflow_mode: str
    thermometry_mode: str
    sonications: list[SonicationInspection]
    planning_fields: dict[int, int] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self):
        return asdict(self)

def _read_maybe_gzip(path: Path) -> tuple[bytes, bool]:
    data = path.read_bytes()
    try:
        return gzip.decompress(data), True
    except Exception:
        return data, False

def decode_spectrum_structure(path: Path) -> SpectrumStructure:
    path = Path(path)
    result = SpectrumStructure(path=str(path))
    try:
        raw, compressed = _read_maybe_gzip(path)
        result.compressed = compressed
    except Exception as exc:
        result.warnings.append(str(exc))
        return result
    if len(raw) < 16:
        result.warnings.append("File too short for SpectrumMsg header.")
        return result
    try:
        frame_count, frame_size, channels = struct.unpack_from("<iii", raw, 0)
    except Exception as exc:
        result.warnings.append(str(exc))
        return result

    # Brain220 / CPC variable-record SpectrumMsg layout.  The first uint32 is a
    # record count, followed by one uint32 byte-size per record.  This must be
    # recognized before treating words 2/3 as the legacy fixed frame-size and
    # channel-count fields: in this format those words are simply record sizes.
    # Every size and every inner FFT/history length equation has to close, so an
    # arbitrary legacy stream cannot enter this path by filename or frequency.
    count = int(frame_count)
    if 1 <= count <= 200000 and 4 + 4 * count <= len(raw):
        try:
            sizes = [int(v) for v in struct.unpack_from(f"<{count}I", raw, 4)]
        except Exception:
            sizes = []
        if sizes and all(128 <= size <= len(raw) for size in sizes) and 4 + 4 * count + sum(sizes) == len(raw):
            pos = 4 + 4 * count
            bins_seen = []
            spacing_seen = []
            upper_seen = []
            history_total = 0
            record_times: list[float] = []
            valid = True
            for size in sizes:
                rec = raw[pos:pos + size]
                if len(rec) != size:
                    valid = False; break
                try:
                    extent = int(struct.unpack_from("<I", rec, 0)[0])
                except struct.error:
                    valid = False; break
                if extent < 48 or (extent - 48) % 8:
                    valid = False; break
                bins = (extent - 48) // 8
                hp = 56 + bins * 8
                if not (64 <= bins <= 16384) or hp + 16 > len(rec):
                    valid = False; break
                hc = int(struct.unpack_from("<I", rec, hp)[0])
                if hc > 100000 or hp + 4 + hc * 20 + 12 != len(rec):
                    valid = False; break
                def _ws_double(offset: int) -> float:
                    lo, hi = struct.unpack_from("<II", rec, offset)
                    return float(struct.unpack("<d", struct.pack("<II", hi, lo))[0])
                try:
                    spacing = _ws_double(24)
                    zero = _ws_double(32)
                    upper = _ws_double(40)
                except Exception:
                    valid = False; break
                if not (math.isfinite(spacing) and 0.1 <= spacing <= 100000.0):
                    valid = False; break
                if not math.isfinite(zero) or abs(zero) > max(10.0, spacing * 0.1):
                    valid = False; break
                expected_upper = bins * spacing
                if not (math.isfinite(upper) and abs(upper - expected_upper) <= max(spacing, expected_upper * 5e-4)):
                    valid = False; break
                times = []
                for j in range(hc):
                    try:
                        t = float(struct.unpack_from("<f", rec, hp + 4 + j * 20 + 12)[0])
                    except struct.error:
                        valid = False; break
                    if math.isfinite(t) and t >= 0.0:
                        times.append(t)
                if not valid:
                    break
                if times:
                    record_times.append(max(times))
                bins_seen.append(int(bins)); spacing_seen.append(float(spacing)); upper_seen.append(float(upper)); history_total += hc
                pos += size
            if valid and pos == len(raw):
                result.exact_structure = True
                result.layout = "Variable size-table FFT/history"
                result.header_size = 4 + 4 * count
                result.frame_count = count
                result.frame_size = 0
                result.channel_count = 0
                result.fft_bins = bins_seen[0] if bins_seen and len(set(bins_seen)) == 1 else None
                result.frequency_spacing_hz = spacing_seen[0] if spacing_seen and max(spacing_seen)-min(spacing_seen) <= 1e-6 else None
                result.frequency_end_hz = (result.fft_bins - 1) * result.frequency_spacing_hz if result.fft_bins and result.frequency_spacing_hz else None
                result.history_samples = int(history_total)
                if record_times:
                    if len(record_times) >= 3 and any(b + 1e-4 < a for a, b in zip(record_times, record_times[1:])):
                        result.warnings.append("Variable-record timestamps are not monotonic.")
                    else:
                        result.last_timestamp_seconds = float(record_times[-1])
                result.format_confidence = "High (exact variable-record size-table + FFT/history closure)"
                return result

    result.frame_count = int(frame_count)
    result.frame_size = int(frame_size)
    result.channel_count = int(channels)
    plausible = 1 <= frame_count <= 100000 and 1024 <= frame_size <= 50_000_000 and 1 <= channels <= 64
    if plausible:
        header_size = len(raw) - frame_count * frame_size
        if 0 <= header_size <= 65536:
            result.exact_structure = True
            result.header_size = int(header_size)
            if frame_size % channels == 0:
                result.bytes_per_channel = frame_size // channels
                if result.bytes_per_channel % 4 == 0:
                    result.float32_per_channel = result.bytes_per_channel // 4
            result.layout = "Fixed frame/channel"
            result.format_confidence = "High (size-validated frame structure)"
        else:
            result.warnings.append(
                f"Header-size equation failed: total={len(raw)}, frames={frame_count}, frame_size={frame_size}."
            )
    if not result.exact_structure:
        result.format_confidence = "Low (legacy/unknown SpectrumMsg layout)"
    # Empirical header hint observed across validated exports. Never use as a sampling frequency.
    if len(raw) >= 32:
        try:
            candidate = float(struct.unpack_from("<f", raw, 28)[0])
            if math.isfinite(candidate) and 0.00005 <= candidate <= 5.0:
                result.frame_period_hint_s = candidate
        except Exception:
            pass
    return result

def _field_counts(folder: Path) -> dict[int, int]:
    counts: dict[int, int] = {}
    for p in folder.rglob("*.raw"):
        m = RAW_RE.match(p.name)
        if m:
            f = int(m.group("field"))
            counts[f] = counts.get(f, 0) + 1
    return counts

def _has_any(folder: Path, patterns: Iterable[str]) -> list[str]:
    out=[]
    for pat in patterns:
        for p in folder.rglob(pat):
            if p.is_file():
                out.append(str(p))
    return out

def _thermometry_mode(root: Path) -> str:
    # Prefer MriImageParams; fall back to raw text search.
    for p in root.rglob("MriImageParams.xml"):
        try:
            text=p.read_text(encoding="utf-8", errors="ignore").upper()
            if "TMAP-ME" in text:
                return "TMAP-ME (Multi Echo)"
            if re.search(r"\bTMAP\b", text):
                return "TMAP (Single Echo)"
        except Exception:
            pass
    return "Unknown"

def _workflow_mode(root: Path, planning_counts: dict[int,int]) -> str:
    prevol = planning_counts.get(44, 0) > 0
    livevol = planning_counts.get(43, 0) > 0
    if prevol and livevol:
        return "3D Volume"
    if prevol and not livevol:
        return "Hybrid"
    if not prevol and not livevol:
        return "2D / Multi-plane"
    return "Mixed / Unusual"

def virtual_raw_header(path: Path, root: Path | None = None) -> dict:
    path=Path(path)
    m=RAW_RE.match(path.name)
    field_id=int(m.group("field")) if m else None
    son=int(m.group("son")) if m else None
    group=int(m.group("group")) if m else None
    frame=int(m.group("frame")) if m else None
    role,dtype=FIELD_SEMANTICS.get(field_id, ("Unknown Exablate RAW field","Unknown")) if field_id is not None else ("Unknown","Unknown")
    size=path.stat().st_size if path.exists() else 0
    matrix=""
    inferred_dtype=dtype
    candidates=[]
    for bpp,name in [(1,"uint8"),(2,"uint16"),(4,"float32"),(8,"float64")]:
        if size and size % bpp == 0:
            n=size//bpp
            side=int(round(math.sqrt(n)))
            if side*side==n:
                candidates.append(f"{side}x{side} {name}")
    if candidates:
        matrix="; ".join(candidates)
    mode=_thermometry_mode(Path(root)) if root else "Unknown"
    return {
        "metadata_type":"exablate_virtual_raw_header_v2",
        "physical_header":"None detected / headerless payload",
        "field_id":field_id,
        "field_semantic":role,
        "expected_storage":inferred_dtype,
        "sonication_number":son,
        "group_index":group,
        "frame_number":frame,
        "payload_bytes":size,
        "matrix_candidates_from_size":matrix or "Non-square / local map / unknown",
        "thermometry_mode":mode,
        "confidence":"High for field semantic when standard numeric filename is present; dtype/matrix remain evidence-based.",
    }

def inspect_sonication(folder: Path, number: int | None = None, root: Path | None = None) -> SonicationInspection:
    folder=Path(folder)
    if number is None:
        m=SON_RE.match(folder.name)
        number=int(m.group(1)) if m else 0
    counts=_field_counts(folder)
    files=[p for p in folder.rglob("*") if p.is_file()]
    evidence=lambda pats:_has_any(folder,pats)
    specs=evidence(["SpectrumMsg-*.dmp"])
    acts=evidence(["*.act"])
    skull=evidence(["SkullMeasures*.log","SkullHeating*.log"])
    regs=evidence(["*.rgs","*_mat.txt","fusregistration.xml"])
    mesh=evidence(["*.mesh"])
    shared_root = Path(root) if root is not None else folder
    if not regs and shared_root != folder:
        regs = _has_any(shared_root, ["*.rgs","*_mat.txt","fusregistration.xml"])
    if not mesh and shared_root != folder:
        mesh = _has_any(shared_root, ["*.mesh"])
    t=counts.get(5,0); mag=counts.get(6,0)
    caps={}
    caps["thermometry"]=Capability("Thermometry", t>0 or mag>0, degraded=not(t>0 and mag>0),
        reason=(f"Temperature={t}, Magnitude={mag}" if t or mag else "No Field 5/6 thermometry RAW"),
        evidence=[f"Field5={t}",f"Field6={mag}"])
    caps["spectrum"]=Capability("Spectrum", bool(specs), degraded=False,
        reason=f"{len(specs)} SpectrumMsg file(s)" if specs else "SpectrumMsg missing", evidence=specs[:4])
    caps["elements"]=Capability("Element control", bool(acts), reason="ACT present" if acts else "ACT missing", evidence=acts[:2])
    caps["skull"]=Capability("Skull analysis", bool(skull), degraded=len(skull)<2,
        reason=f"{len(skull)} skull log(s)" if skull else "SkullMeasures/SkullHeating missing", evidence=skull[:4])
    motion_ref=sum(counts.get(i,0) for i in (37,38,39))
    motion_cur=sum(counts.get(i,0) for i in (40,41,42))
    if motion_ref == 0 and shared_root != folder:
        for candidate in shared_root.rglob("*"):
            m = SON_RE.match(candidate.name) if candidate.is_dir() else None
            if m and int(m.group(1)) == 1:
                inherited_counts = _field_counts(candidate)
                motion_ref = sum(inherited_counts.get(i,0) for i in (37,38,39))
                if motion_ref:
                    break
    caps["motion"]=Capability("3-plane motion", motion_ref>0 or motion_cur>0,
        degraded=not(motion_ref>0 and motion_cur>0),
        reason=f"Reference={motion_ref}, Current={motion_cur}")
    caps["dose"]=Capability("Dose/derived maps", counts.get(2,0)>0 or counts.get(34,0)>0,
        degraded=not(counts.get(2,0)>0 and counts.get(34,0)>0),
        reason=f"Field2={counts.get(2,0)}, Field34={counts.get(34,0)}")
    caps["registration"]=Capability("Registration", bool(regs), reason=f"{len(regs)} registration asset(s)" if regs else "Registration assets missing", evidence=regs[:4])
    caps["geometry"]=Capability("Meshes/geometry", bool(mesh), reason=f"{len(mesh)} mesh file(s)" if mesh else "Mesh assets missing", evidence=mesh[:4])
    # Planning is usually only fully stored under Sonication1.
    planning=sum(counts.get(i,0) for i in (7,8,12,16,19,20,21,43,44))
    if planning == 0 and shared_root != folder:
        first_dirs = [p for p in shared_root.rglob("*") if p.is_dir() and SON_RE.match(p.name) and int(SON_RE.match(p.name).group(1)) == 1]
        if first_dirs:
            inherited_counts = _field_counts(first_dirs[0])
            planning = sum(inherited_counts.get(i,0) for i in (7,8,12,16,19,20,21,43,44))
    caps["planning"]=Capability("Planning images", planning>0, degraded=(number==1 and counts.get(16,0)==0),
        reason=f"{planning} planning/live image(s)" if planning else "Planning images unavailable")

    missing_required=[]
    # A replayable sonication does not require every stream. Required means "expected for full replay".
    for key,label in [("thermometry","Thermometry Field 5/6"),("spectrum","SpectrumMsg"),("elements","Sonication ACT"),("skull","Skull measures/heating")]:
        if not caps[key].available:
            missing_required.append(label)
    missing_optional=[]
    for key,label in [("motion","3Plane motion images"),("dose","Dose derived maps"),("registration","Registration"),("geometry","Mesh geometry"),("planning","Planning images")]:
        if not caps[key].available:
            missing_optional.append(label)
    degraded_items=[f"{c.name}: {c.reason}" for c in caps.values() if c.available and c.degraded]
    weights={"thermometry":20,"spectrum":20,"elements":15,"skull":15,"motion":5,"dose":5,"registration":10,"geometry":5,"planning":5}
    score=0.0
    for key,weight in weights.items():
        c=caps[key]
        if c.available:
            score += weight * (0.5 if c.degraded else 1.0)
    score=round(score)
    available_major=sum(1 for k in ("thermometry","spectrum","elements","skull") if caps[k].available)
    if not missing_required and not missing_optional and not degraded_items:
        status="COMPLETE"
    elif available_major >= 1:
        status="PARTIAL"
    else:
        status="INCOMPLETE"
    spect=[decode_spectrum_structure(Path(p)) for p in specs]
    return SonicationInspection(
        number=number, folder=str(folder), status=status, score=score,
        capabilities=caps, missing_required=missing_required, missing_optional=missing_optional,
        degraded_items=degraded_items,
        present_fields=counts, file_count=len(files), spectrum=spect,
        thermometry_mode=_thermometry_mode(root or folder),
    )

def inspect_export(root: Path) -> ExportInspection:
    root=Path(root)
    dirs=[]
    for p in root.rglob("*"):
        if p.is_dir():
            m=SON_RE.match(p.name)
            if m:
                dirs.append((int(m.group(1)),p))
    if SON_RE.match(root.name):
        dirs.append((int(SON_RE.match(root.name).group(1)),root))
    dirs=sorted({str(p.resolve()):(n,p) for n,p in dirs}.values())
    # If a single sonication folder was provided with no conventional name.
    if not dirs and any(root.glob("SpectrumMsg-*.dmp")):
        dirs=[(0,root)]
    inspections=[inspect_sonication(p,n,root) for n,p in sorted(dirs,key=lambda x:x[0])]
    planning={}
    if inspections:
        first=next((s for s in inspections if s.number==1),inspections[0])
        planning={k:v for k,v in first.present_fields.items() if k in {7,8,12,16,19,20,21,43,44}}
    return ExportInspection(
        root=str(root),
        workflow_mode=_workflow_mode(root,planning),
        thermometry_mode=_thermometry_mode(root),
        sonications=inspections,
        planning_fields=planning,
        warnings=[],
    )
