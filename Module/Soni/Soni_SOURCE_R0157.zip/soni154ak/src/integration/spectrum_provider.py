from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

import numpy as np

from src.core.spectrum_decoder import SharedSpectrumDecoder
from src.services.hydrophone_calibration_service import HydrophoneCalibration


@dataclass(slots=True)
class SpectrumFrame:
    index: int
    frequency: list[float] = field(default_factory=list)
    amplitude: list[float] = field(default_factory=list)
    timestamp_seconds: float | None = None
    confidence: float = 0.0
    source: str = "unavailable"
    main_peak_hz: float | None = None
    decoder_offset: int | None = None
    channel: int | None = None
    source_kind: str = "Sonication"
    channel_mapping: str = "Unknown"
    frequency_axis_source: str = "Unknown"
    frequency_start_hz: float | None = None
    frequency_spacing_hz: float | None = None
    frequency_end_hz: float | None = None
    history_sample_count: int = 0
    history_state_index: int | None = None
    history_state_semantics: str = "Unresolved"
    active_target_ras: tuple[float, float, float] | None = None
    timestamp_source: str = "Unknown"


class SpectrumProvider(Protocol):
    provider_name: str

    def supports(self, files: list[Path]) -> bool: ...
    def load(self, files: list[Path], source_kind: str = "Sonication") -> list[SpectrumFrame]: ...


class NullSpectrumProvider:
    provider_name = "Not connected"

    def supports(self, files: list[Path]) -> bool:
        return False

    def load(self, files: list[Path], source_kind: str = "Sonication") -> list[SpectrumFrame]:
        return []


class SpectrumMsgAnalyzerAdapter:
    provider_name = "SpectrumMsg Analyzer Shared Decoder"

    def __init__(self, main_frequency_hz: float | None = None, calibration: HydrophoneCalibration | None = None, channel_hint: int | None = None, channel_source: str | None = None, subsonication_count_hint: int | None = None, subsonication_ras_hint: tuple[tuple[float, float, float], ...] = ()) -> None:
        self.main_frequency_hz = main_frequency_hz
        self.calibration = calibration
        self.channel_hint = channel_hint if channel_hint is not None and 0 <= int(channel_hint) <= 7 else None
        self.channel_source = channel_source
        self.subsonication_count_hint = int(subsonication_count_hint) if subsonication_count_hint is not None and int(subsonication_count_hint) > 1 else None
        self.subsonication_ras_hint = tuple(subsonication_ras_hint or ())
        self.decoder = SharedSpectrumDecoder()
        self._cache: dict[tuple[tuple[str, ...], float | None], list[SpectrumFrame]] = {}

    def _calibrated_amplitude(self, frequency_hz, amplitude, channel: int):
        if self.calibration is None:
            return np.asarray(amplitude, dtype=float)
        return self.calibration.apply(
            np.asarray(frequency_hz, dtype=float),
            np.asarray(amplitude, dtype=float),
            channel,
        )

    def supports(self, files: list[Path]) -> bool:
        return self.main_frequency_hz is not None and any("spectrummsg" in path.name.lower() for path in files)

    def load(self, files: list[Path], source_kind: str = "Sonication") -> list[SpectrumFrame]:
        key = (tuple(str(path) for path in files) + (source_kind,), self.main_frequency_hz)
        if key in self._cache:
            return self._cache[key]
        if not self.supports(files):
            self._cache[key] = []
            return []

        frames: list[SpectrumFrame] = []
        frame_index = 0
        for path in files:
            decoded_rows = list(self.decoder.decode_frames(path, float(self.main_frequency_hz), channel_index=self.channel_hint))
            valid_states = {int(row.history_state_index) for row in decoded_rows if row.history_state_index is not None}
            promote_subsonication = bool(
                self.subsonication_count_hint is not None
                and valid_states
                and min(valid_states) >= 0
                and max(valid_states) < int(self.subsonication_count_hint)
                and len(valid_states) >= min(3, int(self.subsonication_count_hint))
            )
            for decoded in decoded_rows:
                # Never assign SpectrumMsg records with frame_index % 8. That was an
                # unsupported assumption. Apply channel calibration only when a
                # Sonication configuration file explicitly identifies the channel.
                channel = self.channel_hint
                calibrated = self._calibrated_amplitude(decoded.frequency_hz, decoded.amplitude, channel) if channel is not None else np.asarray(decoded.amplitude, dtype=float)
                frames.append(SpectrumFrame(
                    index=frame_index,
                    frequency=[float(value) for value in decoded.frequency_hz],
                    amplitude=[float(value) for value in calibrated],
                    confidence=decoded.confidence,
                    source=str(path),
                    main_peak_hz=decoded.main_peak_hz,
                    decoder_offset=decoded.offset,
                    channel=channel,
                    source_kind=source_kind,
                    channel_mapping=(f"Validated from {self.channel_source}" if channel is not None else "Unknown — calibration not applied"),
                    frequency_axis_source=decoded.frequency_axis_source,
                    frequency_start_hz=decoded.frequency_start_hz,
                    frequency_spacing_hz=decoded.frequency_spacing_hz,
                    frequency_end_hz=decoded.frequency_end_hz,
                    timestamp_seconds=decoded.timestamp_seconds,
                    history_sample_count=int(getattr(decoded, "history_sample_count", 0) or 0),
                    history_state_index=getattr(decoded, "history_state_index", None),
                    history_state_semantics=("WS-validated BBB sub-sonication index" if promote_subsonication and decoded.history_state_index is not None else "Unresolved"),
                    active_target_ras=(self.subsonication_ras_hint[int(decoded.history_state_index)] if promote_subsonication and decoded.history_state_index is not None and int(decoded.history_state_index) < len(self.subsonication_ras_hint) else None),
                    timestamp_source=str(getattr(decoded, "timestamp_source", "Unknown") or "Unknown"),
                ))
                frame_index += 1
        self._cache[key] = frames
        return frames
