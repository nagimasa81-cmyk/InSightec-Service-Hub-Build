import sys
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication
from src.common.constants import APP_NAME
from src.common.logger import configure_logging
from src.common.theme import DARK_STYLESHEET
from src.ui.main_window import MainWindow
from src.ui.screen_safe import install_screen_safe_guard, fit_top_level_to_screen
from insightec_handoff import load_handoff

def run():
    handoff = load_handoff("sonication_analysis")
    configure_logging()
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setStyleSheet(DARK_STYLESHEET)
    install_screen_safe_guard(app)
    window = MainWindow()
    window.show()
    QTimer.singleShot(0, lambda: fit_top_level_to_screen(window))
    if handoff and handoff.auto_load:
        source = handoff.preferred_source()
        handoff.mark("sonication_analysis", "accepted", input_count=len(handoff.input_paths()), source=str(source or ""))
        if source:
            QTimer.singleShot(0, lambda value=source: window.load(value))
    return app.exec()
