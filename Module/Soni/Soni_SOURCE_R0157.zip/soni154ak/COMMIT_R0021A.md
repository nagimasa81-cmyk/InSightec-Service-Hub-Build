# Commit R0021a — Triple-check correction

- Retains the 0.550–0.700 MHz validity guard; 0.800 MHz cannot be selected from Sonication-local or Xd_####.ini data.
- Replaces reliance on transient QToolTip alone with a persistent QLabel popup parented to each chart.
- Adds native QToolTip as a secondary accessibility fallback.
- Explicitly hides both popup implementations when the pointer leaves the chart or data is unavailable.
