# R0143 — Treatment-specific Acquisition_Brain binding

## Root cause
The supplied 40108 export contains two `Acquisition_Brain` logs. R0142 selected the physically largest file (16:30 session) instead of the current treatment log (18:27 session). The CPC directory also contains 27 historical Spectrum dumps, while the current five Sonications correspond to the final five dumps at 18:34:29, 18:36:19, 18:38:03, 18:39:34 and 18:40:56.

## Fix
- `AcousticControlService.find_log()` now selects the log immediately preceding the first `SonicationSummary.sontime`; without summary it selects the newest timestamped log rather than the largest.
- `CavitationControlTimelineService` and `CpcVendorReproductionService` use the same selector.
- `_validated_treatment_suffix()` first accepts exactly `N` CPC candidates that independently bind to `N` contiguous sessions in the selected treatment log. Historical unbound CPC dumps no longer invalidate that authoritative block.

## Real-data verification
On `40108-2026-08-23-18-28-56.zip`, the selected log is `Acquisition_Brain_650_Sun_Aug_23_18_27_32_2026.txt`. Five segments are parsed and map one-to-one to the five treatment CPC dumps with end-clock errors 0.935, 0.844, 0.534, 0.609 and 0.104 s. Direct decode of Sonication1 CPC RAW+FFT returns 37 frames.
