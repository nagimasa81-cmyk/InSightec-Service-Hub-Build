# R0112 — UI State Integrity / Registration / Fast Thumbnail Repair

## Fixed from R0111a field verification
- Reference and Treatment MR rows are visible by default again; their checkboxes remain available only as optional hide controls.
- Every exported Reference/Treatment MR image gets a list slot immediately; all thumbnail RAW decoding is moved off the UI thread.
- Thermal thumbnail cache now refreshes the visible strip directly; the removed Show-Thermal checkbox no longer blocks UI updates.
- Removed the R0111 synchronous 6-preview decode and synchronous Treatment MR thumbnail decode that increased ZIP/Sonication load time.
- Heavy Sonication Summary CPC/RCA analysis is deferred until the Summary tab is opened; Power/Duration/Energy are seeded immediately from SonicationSummary model data.
- When Registration is ON, a newly selected MR is displayed first, then the CT overlay is evaluated; failure cannot leave the previous MR frozen on screen.
- Fixed the registration QA crash: `_current_slice_projection_qa()` referenced `mr` without receiving it. This exception prevented bone overlay completion.
- Cavitation Intelligence now has its own `Show Increase events` checkbox, default OFF. Increase rows are removed from the CI list unless explicitly requested.
- Cavitation state is no longer the meaningless single label `Cavitation`. It reports family/rule counts; Increase-only is explicitly distinguished from decrease/safety intervention.
- CI event table is horizontally scrollable, every cell has a full tooltip, and double-click opens a full event-detail popup.
- Umbrella 3-D projection now remains active for phase parameters. `Phase dedicated` is used only when explicitly selected.
- Empty-canvas left-drag initializes Umbrella rotation; wheel zoom and Perspective / Top XY / Front XZ / Side YZ operate on the same Element X/Y/Z geometry.
