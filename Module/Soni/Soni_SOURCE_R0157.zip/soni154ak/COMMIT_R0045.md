# R0045

Focus: chart readability and navigation reliability.

- Control-first cavitation view is now the default.
- Diagnostic 8CH overlay remains one click away.
- 100 ms smoothing is display-only and does not alter exact calculations.
- All replay arrow keys work even when focus is inside tables, tabs or plot widgets.
