# R0116zu — Treatment Outcome Science

- Added treatment-wide Thermal × Cavitation outcome science map.
- Background worker evaluates all Sonications without blocking the GUI.
- X axis: descriptive Thermal response score; Y axis: evidence-weighted Cavitation burden.
- Four descriptive quadrants, Sonication labels, metadata color modes, synchronized table, and Sonication jump.
- Color dimensions: Power, Energy, Delta-T, Peak temperature, RCA score, RCV concentration.
- Automatically identifies reference candidates (strong thermal / no confirmed cavitation) and poor trade-off candidates (cavitation with limited thermal response).
- Each row carries What-if priority and evidence availability; missing thermometry/CPC is not imputed.
- Study switch cancels background science workers and rejects stale results.
- R0116 regression suite: 194/194 PASS.
- Full non-PySide6 regression suite: 500/500 PASS.
