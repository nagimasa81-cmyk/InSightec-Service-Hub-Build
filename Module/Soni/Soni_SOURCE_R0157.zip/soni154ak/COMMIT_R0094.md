# R0094 — Linked Cavitation Intelligence
- Cavitation Intelligence made vertically scrollable.
- New linked-analysis checkbox and 3-way lower-display dropdown.
- Lower displays: RCV probable region, Vendor band energy reproduction, Control response + CGA/Acquisition Display Rule.
- Linked Cavitation Events list shown with the lower display.
- Event click synchronizes Replay and places a persistent labelled timing marker on time charts.
- Marker restored after redraw/dropdown changes and panned into view when needed.
- Spectrum Dump Analyzer: Why popup checkbox, default OFF.
- Chart clicks within 100 ms of an observed cavitation event show Why/evidence only when enabled.
