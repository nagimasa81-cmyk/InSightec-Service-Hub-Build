# R0068 — Subwindow Progress + Cavitation Increase Filter

- Added progress feedback to the CPC Spectrum / 8CH Hydrophone Analyzer while scanning, decoding, building replay, rendering charts, and updating cavitation analysis.
- Added compact progress indicators to information/detail, XD element-map, and chart popup subwindows.
- Cavitation Control Timeline event list now hides **Increase** events by default.
- Added **Show Increase events** checkbox above the existing event list.
- Increase event markers remain plotted on the chart; this option filters the list only, as requested.
- Preserved row-to-event mapping after filtering so selection and replay synchronization stay correct.
