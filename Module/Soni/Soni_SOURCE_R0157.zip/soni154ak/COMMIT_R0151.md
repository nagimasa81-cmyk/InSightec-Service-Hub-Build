# R0151 — Snapshot selection publish + exact Sonication end

- Fix Sonication Elements snapshot selection callback using an undefined `payload` local. The callback now reads the currently published `_element_evidence_cache`, so selecting a snapshot cannot abort midway before steering/state/selection UI is refreshed.
- MR timeline now retains exact acoustic power windows from all Workstation logs instead of stopping at the first/largest historical log.
- When an exact MRServer scanning interval is unavailable but SVAT protocol timing exists, Sonication end now uses the exact WS `Sonication power on -> Post sonication` duration when available. `SonicationSummary.actualduration` remains the fallback only.
- No positional/latest-N treatment selection was introduced; Workstation windows are still selected by SonicationSummary clock / one-to-one proof.
