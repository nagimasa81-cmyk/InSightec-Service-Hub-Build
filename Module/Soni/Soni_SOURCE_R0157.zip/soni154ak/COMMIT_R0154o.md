# R0154o — Brain220 Spectrum history / target-voxel binding

## Deep findings from the supplied 42110 Brain220 export

- Every Brain220 SpectrumMsg record has an embedded 20-byte measurement-history list after the exact FFT vector.
- The fourth field is elapsed acquisition time. For Sonications 1–7, the maximum history time in every SpectrumMsg record is bit-identical (Float32) to the corresponding `spotsonicationdata.xml` PowerGraph timestamp, not just the final record.
- The third 32-bit field is structurally ambiguous in isolation: recurring metadata rows contain `0x3f333333` (IEEE754 0.7), while data rows contain small integers.
- Independent WS `StartSonicate` evidence resolves that small integer for 9-target Brain220 sonications: the values span 0–8 and correspond to the active sub-sonication/target-voxel sequence. Single-focus/scanless sonications are deliberately left unresolved even when their values happen to lie in 0–7.
- WS sub-sonication rows also provide per-target duration and steering. The supplied multi-target cases contain nine 0.109375 s targets.

## Code changes

- Preserve history sample count, latest integer state/index and timestamp provenance in each decoded Brain220 Spectrum frame.
- Promote the raw history integer to `WS-validated sub-sonication index` only when independent WS evidence proves a multi-target count and the observed state domain fits that count.
- Attach the corresponding target RAS coordinate to the Spectrum frame when the WS RAS table is complete.
- Surface the active target voxel and RAS in the current Spectrum overlay during Replay.
- Persist canonical sub-sonication count/RAS/steering/durations on the Sonication model.
- Strengthen PowerGraph/Spectrum synchronization: equal-length streams are now cross-validated timestamp-by-timestamp. Exact agreement is recorded as provenance; disagreement no longer silently overwrites embedded Spectrum timestamps. PowerGraph time is used only to fill missing legacy timestamps.

## Guard rails

- No filename/SHA/serial branching.
- No coefficient fitting or numeric clipping.
- No assumption that values 0–7 imply RCV channels.
- Single-focus 220 sonications remain semantically unresolved for the history integer unless independent evidence becomes available.
- Brain650 fixed-frame decode remains unchanged.
