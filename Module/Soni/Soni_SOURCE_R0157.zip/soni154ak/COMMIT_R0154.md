# R0154 — CPC wall-clock cycle timing

## Root cause
CPC Acquisition.ini `Acquire Interval = 10 ms` is a scheduling target, not an exact wall-clock interval. The previous replay mapped controller/FFT/history cycles with `(cycle - cycle0) * 0.010`, compressing treatments when real cycles took longer because of DCA/HW wait and processing time. This made CPC data appear to stop 1–2 s before the canonical Workstation Sonication end even when Acquisition_Brain continued almost to power-off.

## Changes
- Parse every timestamped `Cycle N Done` row inside the selected Acquisition_Brain session.
- Preserve exact cycle-number -> wall-clock mapping and anchor the first physical power-control cycle to canonical Sonication start.
- Use the exact map for CPC FFT snapshots, 8CH measurement history, observed control response, predicted control cycles and cavitation events.
- Retain `cycle * AcquireInterval` only as a legacy fallback when timestamped cycle evidence is unavailable.
- Remove a redundant nested raw-ADC availability check.
- Preserve R0150a/R0151a/R0152/R0153 source binding, timing, steering and clock-domain hardening.

## Real-data validation
4032 Sonication1: CPC cycle 514 at 17:42:11.474 and cycle 1685 at 17:42:24.462. Exact wall-clock mapping moves the final FFT to MR ~19.61 s and the final 10-ms history/control sample to MR ~19.88 s against canonical Sonication end ~20.00 s. The remaining ~0.39 s FFT gap is snapshot cadence; the ~0.12 s history gap is the real CPC-vs-WS event boundary, not missing fabricated data.

## Validation
- R0154 wall-clock regression tests PASS.
- Existing timing/control regressions PASS.
- Full non-PySide suite: 932 passed, 1 skipped (optional pyzipper unavailable).
- `verify_source.py`: VERIFY_SOURCE_OK.
