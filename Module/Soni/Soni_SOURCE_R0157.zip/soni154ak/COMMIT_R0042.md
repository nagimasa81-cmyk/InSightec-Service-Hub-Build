# R0042

## Cavitation chart visibility
- Spectrum Dump Analyzer source-detail text is hidden by default behind `Source details`.
- CGA Cavitation / Vendor Rules descriptive text, band table, and control table are collapsed by default behind `Show rule / band details`.
- The two vendor-energy/display-rule plots remain side-by-side.
- The cavitation-control power-response plot receives a dedicated lower half with a larger minimum height.
- Existing rule tables remain available on demand and all analysis behavior is preserved.
