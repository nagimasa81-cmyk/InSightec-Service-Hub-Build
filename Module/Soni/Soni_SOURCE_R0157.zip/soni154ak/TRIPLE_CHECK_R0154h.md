# R0154h Triple Check

- Full non-GUI regression: 984 passed, 1 skipped (optional AES/pyzipper environment-only skip).
- VERIFY_SOURCE_OK and compileall PASS.
- Duplicate class methods: 0.
- while True loops: 3, each contains an explicit break.
- GUI authoritative CPC decode ownership: one call site, SpectrumPreloadWorker only.
- Elements XdGeometry filesystem read: background DeferredPanelWorker only; GUI rendering uses cached geometry.
- Real Brain220 DQA 42110: Brain 220 family / actual 230 kHz / Tx41; 1024 serial geometry recovered; every Sonication has a 1024-value element snapshot; S6/S7 excluded from center alignment as repeated target-voxel DQA targets; non-temperature RAW fails closed.
- Real Brain650 4267: Brain 650 family / actual 690 kHz / Tx42; 5/5 authoritative CPC mapping; Spectrum replay frames decode successfully.
- Explained amplitude=0 remains gray; unexplained amplitude=0 remains black and retains independent warning semantics.
