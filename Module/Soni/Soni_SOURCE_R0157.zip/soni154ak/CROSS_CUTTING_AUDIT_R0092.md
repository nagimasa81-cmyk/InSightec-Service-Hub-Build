# R0092 Cross-Cutting Audit

## Confirmed issues fixed
1. Cavitation evidence was decoded during staged loading but not published to the current frame until a later Replay action.
2. Replay visual reset did not clear all Sonication-scoped Cavitation/RCA state.
3. Language refresh recomputed Cavitation page, RCA, and default Cavitation state through overlapping paths.
4. Cavitation event table connected click and double-click to the same analysis handler.
5. Thumbnail strips connected itemPressed + itemClicked + itemActivated to the same payload path; normal mouse clicks could execute twice.
6. Obsolete unsafe nearest-CPC resolver remained in the code after strict synchronization became authoritative.
7. Historical event-preview exceptions were silently swallowed.

## Preserved
R0087 PowerGraph/Score source, R0088 Sonication Phase fix, R0089 language selector, R0090 replay curve persistence, and R0091 strict Cavitation state integrity remain in the source.

## Broad regression audit
The historical non-GUI regression suite was also run. Remaining legacy failures are old contract assertions for obsolete version metadata or UI implementation details superseded by later releases. The PySide6 ROI runtime test cannot execute in this audit environment because PySide6 is unavailable.
