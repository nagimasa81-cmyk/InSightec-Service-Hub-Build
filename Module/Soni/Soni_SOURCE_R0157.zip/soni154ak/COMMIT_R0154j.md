# R0154j — DQA image-native focus alignment priority

## Why R0154i was still wrong
The R0154i frame gate only proved that `SonicationSummary.focalRAS` projected inside the large DQA Axial/Sagittal fields of view and close to their planes.  The new Windows screenshots show that this is not sufficient: values around `X +112 mm / Y +81 mm / Z -63.9 mm` can still pass that gate even while the displayed focus is visually near the phantom centre.

## Correction
- DQA alignment now prefers an image-native measurement whenever treatment thermometry and magnitude RAW are available.
- The focus is recovered from the thermal hotspot and compared with the phantom circle / lower straight-line landmarks in the *same displayed MR raster*.
- Axial acquisitions contribute X/Y; Sagittal acquisitions contribute Z/tilt; repeated valid samples are combined by robust median.
- No absolute `focalRAS - phantom RAS` subtraction is performed on this preferred path.
- Electronic-steering / explicit target-voxel exclusions remain fail-closed and do not redefine the nominal phantom reference.
- The R0154i absolute-RAS route is retained only as a fallback for exports where image-native DQA evidence is unavailable.

## Regression intent
A DQA export that visually places the thermal focus near the phantom centre must not be reported as a 100 mm-class displacement merely because two unrelated absolute coordinate frames happen to project inside the same large MR FOV.
