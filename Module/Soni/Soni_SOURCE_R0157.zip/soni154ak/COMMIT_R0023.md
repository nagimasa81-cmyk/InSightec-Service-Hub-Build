# R0023 — Spectrum Dump Import / CGA-style Analysis

## Input workflow
- `Spectrum Dump Analyzer` can be opened before any treatment package is loaded.
- Accepts **Export ZIP**, **folder**, or a **single Spectrum dump file**.
- ZIP and folder inputs are recursively scanned for `*Spectrum*.dmp` and `*Spectrum*.dmp_FFT`.
- Matching CPC RAW / `_FFT` companions are paired into one logical measurement.
- If multiple candidates exist, a selection table is shown before decoding.
- A single file selection is deterministic and is opened directly; an exact same-folder companion is attached automatically when present.
- The analyzer window itself accepts drag/drop for ZIP, folder, or Spectrum file.

## Analysis behavior
- CPC `Spectrum_*.dmp_FFT` remains the validated 8-channel source.
- Companion `Spectrum_*.dmp` supplies the validated measurement-history arrays when present.
- Existing spectrum, spectrogram, editable band-energy, navigation, calibration audit and per-channel statistics are retained.
- `SpectrumMsg*.dmp` is discoverable but is explicitly kept separate from physical 8CH CPC data; no invented channel mapping is performed.

## Safety / provenance
- ZIP path traversal is rejected before extraction.
- Unsupported or partial file sets are shown as such (`RAW only`, `FFT only`, `RAW + FFT`).
- Missing data never receives fabricated channel identity or raw-waveform semantics.
