# R0105 — Slice-Aware DICOM Projection / Display QA

- Current-slice 2D QA now uses only CT skull points within ±1.5 mm of the displayed MR plane.
- All other 3D skull points are NOT_APPLICABLE_TO_SLICE and excluded from the 2D QA denominator.
- Applicable CT points are transformed through the exported registration matrix and projected directly with MR RAS geometry.
- Direct projected points are compared with the production world-reslice overlay.
- Reports:
  - applicable / sampled points
  - inside-FOV fraction
  - direct projection vs renderer overlap
  - overlay vs direct projection agreement
  - current-slice tolerance
- Adds diagnostic-only identity / flip-X / flip-Y / flip-XY / transpose display hypotheses.
- Display hypotheses never alter the production image or registration.
- Outer-head MR intensity QA no longer suppresses an otherwise strongly geometry-coherent overlay by itself.
- Geometric mismatch still suppresses the overlay.
