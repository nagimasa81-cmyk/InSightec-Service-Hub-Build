# R0116r — Control Timeline Why Opt-In

- Added a dedicated `Why popup` checkbox to the Control Timeline event-filter row.
- Default is OFF.
- When ON, clicking either a Control Timeline event marker or an Event list row always opens the exact Why/evidence popup.
- When OFF, clicks still select/highlight the event and update linked analysis, but no popup is shown.
- Vendor-chart Why popup remains a separate independent control.
