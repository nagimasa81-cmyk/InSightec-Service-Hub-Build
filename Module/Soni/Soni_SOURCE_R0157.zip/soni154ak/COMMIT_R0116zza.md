# R0116zza — Replay-ready background loading

- Removed CPC/FFT decode and cavitation timeline construction from the exclusive 61% Replay load stage.
- Reused the existing low-priority Spectrum preload worker as the authoritative background CPC decode path.
- Moved detailed Sonication/MR metadata parsing out of the 91% GUI stage into SonicationMetadataWorker.
- Added workspace, selection-generation, and Sonication-index guards so stale metadata cannot overwrite a newly selected study/Sonication.
- Cavitation Intelligence now prepares evidence on explicit panel open and reuses predecoded Spectrum data when available.
- Updated regression tests so future changes cannot reintroduce blocking CPC decode at 61% or synchronous detailed metadata at 91%.

Validation:
- R0116 tests: 227/227 PASS
- Full suite excluding the known PySide6 ROI GUI test: 533/533 PASS
