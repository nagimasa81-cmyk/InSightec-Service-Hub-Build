# R0134 — Async Data Materialization / Blank-Tab Recovery

- Replaced Spectrum secondary-product ownership checks based on Python object identity with a stable semantic replay key: selected Sonication index + resolved source path + decoded FFT frame count.
- SpectrumEvidenceRepository now stores and validates `replay_key`, while retaining legacy `replay_id` only for backward compatibility with already-created payloads.
- Secondary worker completion, staged publishing, cache publication, tab self-healing, materialize-all flow, spectrum Y-range completion, and delayed fit/recovery all use semantic ownership.
- Main-window async selected-data completion and Spectrum preload completion now re-materialize whichever heavy main tab is currently visible, preventing a tab opened before background completion from remaining blank.
- Updated stale regression assertions that required the superseded identity-based contract.
- No change to R0133 image orientation/frequency-direction behavior.
