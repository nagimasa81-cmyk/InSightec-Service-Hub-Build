# R0116zzb — Spectrum Tab Publish Unification

- Unified Spectrogram, Band Energy, Vendor/CGA and Cavitation derived products through the study-scoped SpectrumEvidenceRepository.
- Added study-scoped secondary-product cache keyed by Sonication, receiver, analysis mode and threshold.
- Analyzer secondary worker consumes the shared repository for loaded Export studies instead of independently recomputing the same products.
- Replaced monolithic secondary publish with independent per-view publication so one tab failure cannot strand all later tabs in Waiting.
- Added cache republish when a tab is opened after worker completion.
- Added explicit Processing / No data / Needs attention states for Spectrogram and Band Energy and evidence-unavailable state for Cavitation.
- Removed recursive Band Energy drawing from vendor-band metadata setup.
- Preserved standalone Analyzer behavior when no loaded Export/package repository exists.
