# R0154ak triple check

## 1. Code and release-contract check

- `python3 -m compileall -q src tests`: PASS
- `python3 verify_source.py`: PASS
- Release identifiers synchronized across constants, VERSION, version.json, pyproject, build contract and both Nuitka scripts.
- New lifecycle/protocol/slider/coverage regression contracts: PASS (9 targeted checks).

## 2. Real-export evidence check

Fixture: supplied `42110-2026-04-01-18-30-47(1).zip`.

- Logical Sonications discovered: 7.
- Exact Sonication-owned SpectrumMsg frames: 161, 6, 347, 153, 346, 348, 346.
- Embedded coverage endpoints (s): 41.890736, 1.637082, 89.909439, 40.005161, 89.796082, 89.907097, 89.908569.
- Spectrum evidence repository decode and secondary-product pass completed for all 7 Sonications without product errors.
- Sonications 4, 5 and 7 field-5 candidates bind exactly to `T2_Star_ME_1SL` and are reported as Temperature Unavailable, not Celsius.
- Diagnostics v2 completed with 7 rows and zero diagnostic errors.

## 3. Regression/ancestry check

- 926 no-fixture test functions passed in the ad-hoc runner after the changes.
- 7 failures are unchanged baseline stale-contract failures already present in the supplied R0154aj source.
- No new failure remains relative to the supplied baseline after restoring the explicit scheduled-preload gate contract.
- Targeted previous contracts for ZIP-drop Summary, single-owner aggregate pipeline and robust Summary temperature all pass.

## Case-specific conclusion

- The supplied `20-25-58` diagnostics establish that SpectrumMsg hydrophone data continues through each Sonication (for Sonication 1, 75 frames through about 19.9705 s). Therefore the photographed mid-run Rule/Score cutoff is not evidence that hydrophone acquisition stopped.
- Rule/Score is a separate physical CPC/controller saved-history stream and may legitimately have shorter exported coverage. R0154ak shows both coverages and does not invent values beyond the physical history.
- The photographed Sonication 1 value (start 37.0 C, peak 78.8 C) cannot be numerically accepted or rejected from metadata-only diagnostics. Exact validation requires the matching `20-25-58` original Export; the attached `18-30-47` fixture is a different acquisition.
