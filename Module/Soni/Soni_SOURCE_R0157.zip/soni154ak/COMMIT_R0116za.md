# R0116za — 91% modal deadlock / metadata scan repair

- Close the exclusive progress dialog immediately when the minimum Replay-ready staged load reaches 100%.
- Remove automatic Diagnostics/Planning precompute from the exclusive load path.
- Remove the synchronous all-dependent-view refresh after Sonication selection.
- Replace the 91% metadata step with O(1) model/package metadata; detailed review/XML/log metadata is lazy.
- Remove workspace-wide SkullMeasures discovery from metadata loading; XD data is loaded only in Sonication Elements/XD 3-D.
- Keep Sonication Summary and secondary panels non-blocking/lazy.
