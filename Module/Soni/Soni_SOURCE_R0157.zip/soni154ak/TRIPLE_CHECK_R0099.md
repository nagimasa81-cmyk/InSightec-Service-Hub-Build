# R0099 Triple Check

## 1. Connection / signal routing
- No duplicate class methods.
- Removed duplicated click + double-click handler connections from both Spectrum Dump Analyzer cavitation tables.
- Added loaded-Sonication ownership to prevent Analyzer → Main → Analyzer from decoding the same CPC pair twice.
- Sonication Summary double-click now selects the row's Sonication and switches to Replay.

## 2. Cavitation data binding
- Fixed mismatch between Replay discovery and Spectrum Dump Analyzer discovery: valid physical Spectrum dumps are no longer limited to a folder literally named CPCFiles.
- SpectrumMsg remains excluded from physical 8-channel CPC data.
- RAW and FFT are now paired by same-directory measurement identity before Sonication mapping. This prevents cross-pairing when one side of a pair is missing.

## 3. Registration
- Exported CtMr / MrMr matrices remain authoritative; no automatic visual optimization was added.
- Existing residual / bias / angular coverage QA remains.
- Added skull-to-MR-head containment QA. A grossly outside-head overlay is suppressed rather than shown as Registration ON.

## Test interpretation
- Recent functional regression suite and registration/cavitation tests are required to pass.
- Historical source-contract tests that assert superseded UI text or old version metadata are not treated as current runtime requirements.
