# R0080 — Deterministic Export Registration Replay

- Registration no longer chooses among transform hypotheses using image similarity.
- Treatment Planning MR uses the saved accepted `CtMr` matrix directly (CT RAS -> treatment MR RAS).
- Preplanning MR uses the saved accepted chain `MrMr × CtMr` (CT RAS -> treatment MR RAS -> preplanning MR RAS).
- `CtMr.rgs` / `MrMr.rgs` are parsed and `IsMatrixValid`, `IsMatrixUpToDate`, `MrOrientation`, and `InitialSolution` are reported.
- Invalid/out-of-date saved registrations are not rendered.
- Edge agreement / outer-shell residual remain QA-only diagnostics and cannot flip, invert, optimize, or select the registration.
- R0078+ Defender-conservative standalone build configuration is preserved.
