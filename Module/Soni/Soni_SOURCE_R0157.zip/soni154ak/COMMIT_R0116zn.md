# R0116zn — MR canonical timeline + Spectrum auto-fit / Vendor layout

- Canonical time axis is MR acquisition start = 0 s through MR acquisition end.
- Workstation power-on/off is placed inside the MR window using exact WS + MRServer clocks when available.
- MR timeline binding reuses the authoritative Acquisition session index; latest-N guessing is not used.
- MRServer scan end accepts both Scanning -> Idle and Scanning -> Step is open transitions.
- CPC/Spectrum, Band Energy, Vendor/CGA, control events and main replay are mapped into MR time.
- Negative/pre-MR control points are clipped from the MR display window.
- Spectrum Dump Analyzer auto-fits all data on open, Sonication switch, and Spectrum/source load completion.
- CGA Cavitation / Vendor Rules opens in the approved composition: details collapsed, All 8 receivers, lower chart Both, smooth/sync/legend enabled, upper Vendor energy over lower control/CGA.
- Non-uniform Spectrogram snapshots are display-resampled to a uniform MR-time image grid; exact FFT values remain unchanged in numerical views.
- Main Relative Acoustic Spectrum is placed inside the MR window at the irradiation interval rather than starting at t=0.
