# R0128 — Direct mouse-drag FFT range selection

- Fixed the Windows/pyqtgraph usability regression where `FFT range selection` only created a small movable LinearRegionItem and dragging the chart itself still panned instead of selecting.
- When selection mode is ON, left-button drag anywhere inside Measurement Timeline / Raw A/D now directly defines the analysis interval in canonical MR time.
- Crosshair cursor clearly indicates selection mode.
- The selected interval is synchronized to every Raw/History panel and remains fine-tunable through the LinearRegionItem body/edges.
- A click without appreciable drag creates a small visible interval instead of an unusable zero-width selection.
- Selection mode OFF restores the standard chart pan/zoom interaction from R0124.
- R0126 processed CPC history FFT + Band0 analysis is unchanged.
