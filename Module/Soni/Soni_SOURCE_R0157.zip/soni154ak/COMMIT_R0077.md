# R0077 — Integrated Cavitation Location Fusion

- Cavitation location now integrates measured RCV intensity, FUS/vendor receiver weighting, and MR magnitude signal-loss evidence.
- Candidate space is not clipped to an intracranial circle; extracranial candidates remain possible.
- Cavitation Intelligence MR panel displays the real treatment MR image and overlays the probable region with a red dashed boundary instead of a single X marker.
- The detail line reports the acoustic/MR fusion weights and integrated location score.
