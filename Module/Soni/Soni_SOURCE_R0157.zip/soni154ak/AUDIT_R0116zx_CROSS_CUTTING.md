# R0116zx Cross-cutting regression / ancestry audit

## Scope
Audited active runtime source for:
- ancestry / old-route re-entry
- CPC/Sonication source binding
- duplicate decode/mapping routines
- stale Study/Sonication state republish
- signal duplication
- timeline / fit overwrite
- Actual Power vs Controller ExPowerRatio naming/data-source separation
- Spectrum preload and Treatment Outcome Science worker ownership
- duplicate Python method definitions
- release metadata synchronization

## Findings fixed
1. **Legacy CPC latest-N positional selector survived** in `HydrophoneReplayService.select_files()`.
   - Removed latest-N selection.
   - Only explicit SonicationN identity, or a provably single-pair/single-Sonication universe, is accepted by that legacy compatibility API.

2. **SpectrumPreloadWorker could bypass authoritative mapping** when `map_candidates_to_sonications()` returned unresolved.
   - If physical CPC pairs exist but binding is unresolved, preload now fails explicitly.
   - It never substitutes another CPC source by order.

3. **Raw/Spectrogram/Band Energy could revert to the obsolete full MR window** through legacy `_set_mr_xrange()` calls.
   - The compatibility function now fits only to finite payload data.
   - This makes old callers obey the current data-only Analyzer display contract.

4. **Cavitation Intelligence linked control chart mislabeled Controller ExPowerRatio as Actual Power**.
   - Renamed to `Controller ExPowerRatio` / `Reconstructed Controller ExPowerRatio`.
   - Linked Vendor/Control views now fit to finite payload X ranges rather than forcing 0..MR-end.

## Negative checks
- Duplicate Python methods in classes: **0**
- Duplicate top-level definitions: **0**
- Unsafe `candidates[-sonication_count:]` selector in active source: **0**
- Hydrophone Analyzer direct forced `0..MR duration` X-range pattern: **0**
- Obvious same-instance duplicate UI signal connection: **0**
- Old release version in active metadata/runtime constants: **0**

## State / worker checks
- Study source switch detaches `package/current`, invalidates CPC binding cache, cancels Spectrum preload and Treatment Outcome Science, and clears old science results.
- Asynchronous result handlers reject callbacks whose workspace does not match the currently adopted Study.
- Spectrum Analyzer decode uses request IDs to reject obsolete decode results.

## Validation
- R0116 regression suite: **207 passed**
- Full non-PySide6-GUI suite: **513 passed**
- Known excluded test: `test_r0015_circular_roi_measurement.py` requires PySide6, unavailable in this container.
- `compileall src`: PASS
- ZIP integrity: checked at packaging time.
