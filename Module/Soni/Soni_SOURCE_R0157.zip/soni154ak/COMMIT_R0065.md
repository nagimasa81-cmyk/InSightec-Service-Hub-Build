# R0065 — Registration Geometry Recovery

Deep-dive finding and implementation:

- `CtImage.xml` in the validated export contains stored array dimensions, not patient-space CT geometry.
- `MriImageParams.xml` Field 16 is the preplanning CT (`BONE PLUS 1.25m`) and contains all 153 CT slices with TopLeftCoord R/A/S, row/column RAS direction cosines, 0.488281 mm pixel spacing, and 1.25 mm slice progression.
- `CtMr_mat.txt` maps the CT volume center close to the treatment planning BRAVO MR center, strongly supporting CT→treatment-MR matrix direction.
- `MrMr_mat.txt` inverse maps the earlier T2 planning/preplanning MR centers close to the treatment BRAVO MR centers, supporting the registration chain for preplanning MR review.
- RegistrationOverlayService now reads CT geometry from `MriImageParams.xml` before legacy CT-specific tables.
- No centered-pixel synthetic registration is introduced.
