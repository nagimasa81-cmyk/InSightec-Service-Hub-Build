# COMMIT R0083 — Multilingual Messages / RCA

## Languages
- English
- 日本語
- 한국어
- 繁體中文（台灣）
- Español

## UI policy
R0082 layout, controls, plots and scientific identifiers are preserved. A compact persistent language selector is added to the upper-right menu-bar corner.

## Localized content
- Cavitation Intelligence summary and explanatory note
- No-event / no-MR / skull classification messages
- Cavitation Root Cause Analysis summary
- RCA contributor names
- Evidence text where safely translatable
- Confidence levels
- Improvement-direction narratives
- Missing-evidence messages
- Key Replay cavitation availability/synchronization messages
- Hydrophone probable-region interpretation text

## Scientific naming
RCV, Band0–3, CPC, MR, Sonication, Power and numerical evidence remain unchanged where translation could reduce technical precision.

## Persistence
Selected language is stored through QSettings and restored on the next launch.
