# R0116f

- Increase events are OFF by default in CPC Spectrum / 8CH Hydrophone Analyzer.
- OFF now hides Increase events from both the control timeline chart and event table.
- Enabling Show Increase events restores both chart markers and table rows.
- Existing R0116e hover-preview changes are preserved.
