# RC7.10-R0154c

- Sonication Summary Movement Detection now appends `|RL|+|SI|+|AP|` and highlights the Movement Detection cell red at >= 2.0 mm.
- Sonication Elements Umbrella focus markers are independently toggleable: Reference focus, Authoritative steered target, and Phase-derived focus. Tooltips and inline help explain their different semantics.
- Sonication Elements table now lives in a vertical splitter so enabling Show element table gives the table real, resizable screen space on laptop displays.
- Preserves R0154a CPC wall-clock cycle mapping and R0154b unexplained zero-amplitude warning behavior.
