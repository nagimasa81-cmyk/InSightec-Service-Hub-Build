# R0116zb — Spectrum background preload + single-pass Acquisition_Brain cache

- Starts Spectrum/Cavitation preload immediately after the main Export is ready; opening Spectrum Dump Analyzer no longer initiates the expensive decode.
- If Analyzer is opened before preload finishes, it shows non-modal progress while the main Replay window remains usable.
- Relays real decode/validation progress instead of appearing frozen at a fixed 50%.
- Parses Acquisition_Brain once per file version and shares Increase, Display, Decrease, and power-control session products across validation calls.
- Cache is invalidated automatically when file size/mtime changes and is bounded to avoid unbounded memory growth.
