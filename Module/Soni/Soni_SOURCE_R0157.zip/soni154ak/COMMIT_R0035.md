# R0035 — SpectrumDumps-Only Cavitation Analysis

## Purpose
Cavitation analysis must remain useful when a complete treatment Export cannot be loaded and only `Spectrum_*.dmp` / `Spectrum_*.dmp_FFT` are available.

## Implemented
- Added explicit **Cavitation mode** selector:
  - Auto Evidence-First
  - SpectrumDumps Only
  - Vendor Rule + Dump
- Added **Cavitation Events** tab with a 32-row (8 hydrophones × 4 bands) activity heatmap and event table.
- Dump-only mode consumes the embedded 8CH × 4-band energy table directly.
- If `CavitationSafetyAndControl.ini` is absent, detections are labelled **Candidate** and no vendor power/stop action is invented.
- Added adjustable robust candidate threshold (default 6 sigma).
- Reconstructs Band0–Band3 frequency ranges directly from SpectrumDumps by finding FFT-bin intervals whose float32 sums reproduce the embedded energy table.
- If the raw companion is present, FFT snapshots are mapped to real 10-ms acquisition cycles using the full 8CH Band0 vector even without an INI file. This preserves real gaps/timing.
- If vendor INI rules are available, snapshot-level Decrease/Safety/Dynamic threshold events are additionally evaluated and clearly labelled as vendor-rule triggers.
- Band Energy defaults also use dump-reconstructed Band0–Band3 ranges when the INI is missing.

## Evidence policy
- Exact dump evidence: frequency axis, 8CH FFT, embedded Band0–Band3 energies, inferred band-bin ranges, and cycle mapping when the raw companion matches.
- Vendor behavior: only shown when matching vendor rule files are present.
- Dump-only statistical excursions are explicitly **candidates**, not claims that the workstation issued a cavitation-control action.

## Validation
- Focused R0033–R0035 tests pass.
- Real isolated Spectrum dump pair (no INI/log/Export) successfully decodes 34 FFT snapshots, reconstructs all 4 band ranges, and maps the first snapshots to cycles 20, 60, 100, 140, 180, 540 exactly.
