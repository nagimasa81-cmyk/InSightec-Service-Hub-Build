# R0116zy — Integrated Cavitation Science / UI / Metadata Repair

- Reconnected Cavitation Root Cause Analysis refresh to the live Cavitation Intelligence update path.
- Reconnected Event / Element list population from visible control events and sonication element snapshots.
- Evidence-chain panel refreshes with selected sonication evidence.
- MriImageParams row selection now prefers real treatment thermometry/MEMP rows with valid direction cosines/frequency direction over placeholder rows.
- Replay detailed sonication metadata refreshes after fast initial load.
- Temperature Trend and Power/Score share irradiation-relative time beginning at irradiation start.
- Spectrum Dump Analyzer defaults to no vertical scroll; Analysis Details enables vertical scrolling only while expanded.
- Replay speed is beside Show analysis details.
- Cavitation Events table keeps vertical scroll, removes horizontal scroll, and optimizes columns.
- Spectrogram fits the actual data interval, uses a color map, and provides hover interpretation.
- CGA threshold display adds threshold-relative guidance for sub-threshold curves.
- Probable-location central pattern is visually emphasized without changing evidence values.
- Treatment Outcome Science labels follow marker colors and improved placement.
- Replay section visibility controls are three horizontal checkboxes.
