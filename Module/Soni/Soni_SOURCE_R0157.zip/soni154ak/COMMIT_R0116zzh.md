# R0116zzh — Spectrum cumulative RMS / temporal noise analysis

## Spectrum Processing
- Current spectrum
- Current − accumulated mean (prior frames only)
- Accumulated RMS (frame 0 through current, calculated in linear amplitude then converted to dB)
- Temporal noise RMS (per-bin temporal residual RMS / standard deviation)
- Innovation |z-score| (absolute current deviation from prior-frame mean divided by prior temporal sigma; 3σ guide)

## Engineering
- Extended the single authoritative prefix cache with squared sums and counts; no duplicate calculation path.
- Fixed Y ranges across replay for all processing modes.
- Reference lines are added only once per plot in overlay mode.
- All new processing labels/tooltips are localized for the seven supported languages.
