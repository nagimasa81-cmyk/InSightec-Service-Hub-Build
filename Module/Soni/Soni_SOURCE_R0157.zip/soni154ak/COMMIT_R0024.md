# R0024 — Workstation Replay and Partial Export Intelligence

Base: R0023. All R0023 Spectrum Dump Import / CGA-style Analyzer changes are retained.

## Added
- Export / Replay Status workspace with per-capability AVAILABLE / DEGRADED / MISSING states.
- PARTIAL and INCOMPLETE sonications remain selectable; available streams are never rejected globally.
- Clear replay behavior for every missing capability.
- Exact-first SpectrumMsg structure diagnostics (frame count, frame size, channels, header size, confidence).
- Thermometry Data workspace for Fields 5/6/23/28/33/2/34 and TMAP vs TMAP-ME (Multi Echo).
- Elements & Skull workspace separating ACT, SkullMeasures, SkullHeating and mesh availability.
- Treatment-level Comparison table retaining partial sonications.
- Shared Sonication1 planning / registration / mesh inheritance remains supported by FUS Export Core.

## Compatibility
- R0023 standalone Spectrum Dump Analyzer preserved.
- Existing Replay and Analysis tabs preserved.
- Legacy SpectrumMsg layouts still fall back to heuristic decoding when exact size validation fails.
