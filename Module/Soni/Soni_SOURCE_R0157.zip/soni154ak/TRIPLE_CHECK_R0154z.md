# R0154z Triple Check

## Scope
Brain220/230 DQA focus alignment measurement/judgement separation.

## Checks
- Removed frequency-family blanket N/A gate for 150–350 kHz.
- Preserved same-raster first measurement priority.
- Preserved coordinate-frame compatibility gate before focalRAS/reference subtraction.
- Preserved non-local >25 mm coordinate mismatch rejection.
- Steering/multi-target/target-voxel now suppresses only centre-alignment judgement, not measured X/Y/Z/Tilt.
- Selected steered Sonication remains measurable; other excluded shots cannot redefine nominal cross-plane reference.
- DQA alert coloring is disabled for `Not judged` shots while numeric values remain visible.
- No changes to Spectrum, thermometry, power/energy, or 1024-channel element decoding in this commit.

## Validation
- verify_source.py: PASS
- Python compile: PASS
- Focused DQA regression set: 39 passed
- Added test_r0154z_dqa_measurement_judgement_split.py
- Updated stale R0154x contract test that required the removed Brain220 blanket N/A gate.
