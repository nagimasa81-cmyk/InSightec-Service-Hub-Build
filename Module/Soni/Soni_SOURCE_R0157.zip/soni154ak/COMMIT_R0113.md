# R0113 — Image-row cleanup, complete MR thumbnails, nonblocking Sonication Summary

## Image rows
- Removed Show Reference and Show Treatment MR checkboxes completely.
- Removed their visibility state/connection code so Reference, Treatment MR and Thermal rows cannot be hidden by stale state.
- Added Planning MR All and Preplanning MR All selectors.
- Planning MR All is the default Reference selector and includes Ax/Sag/Cor exported series.
- Every exported image creates a list slot immediately.
- Background thumbnail decode updates the matching item icon directly instead of rebuilding the entire strip.
- Final scrollbar ranges are resynchronized after background decode.

## Sonication Summary
- Cheap exported Power/Duration/Energy values are displayed immediately.
- Power/Energy charts can render immediately from the seeded rows.
- Expensive Thermal/CPC/RCA detail is moved to a QThread worker.
- The GUI no longer sequentially executes one full Sonication analysis per QTimer callback.

## Validated export
10-00-09_ANx(1).zip contains and decodes:
- Planning MR Ax: 52/52
- Planning MR Cor: 49/49
- Planning MR Sag: 49/49
- Preplanning MR Ax: 13/13
- Preplanning MR Cor: 15/15
- Preplanning MR Sag: 19/19
