# RC7.2-R0116y — Build Contract Metadata Repair

- Added mandatory `commit` to `version.json`.
- Synchronized VERSION, APP_VERSION and APP_COMMIT to R0116y.
- Updated InSightec build contract source_version/release_sequence.
- Updated CI/local Nuitka Windows metadata from the stale R0078 identity.
- Added regression tests preventing missing/unsynchronized build metadata.
- Kept the R0116x Spectrum loading, screen-fit and XD 3-D integration code intact.
