# R0116zh — Spectrum progress and final publish recovery

- Keep Spectrum progress popup visible when Analyzer opens with a completed background preload.
- Do not close the popup before decoded replay is published.
- Eliminate the remaining GUI-thread CPC chronological fallback decode.
- Standalone Open ZIP / mapped Sonication both use SpectrumDecodeWorker.
- Decoder stage mapping starts at 56% rather than rounding the first worker callback back to 55%.
- Add 1-second decode heartbeat with elapsed time so long operations visibly remain active.
- Publish primary FFT/Spectrum first at 90%; defer Spectrogram/Band/Vendor/Cavitation work to the next Qt event turn.
- Always terminate successful publish at 100% and close the popup after a short confirmation interval.
