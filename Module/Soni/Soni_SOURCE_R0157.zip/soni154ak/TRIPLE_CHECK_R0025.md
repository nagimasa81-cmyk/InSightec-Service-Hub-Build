# R0025 Triple Check Report

## Check 1 — Source / contract integrity
- `python -m compileall -q .`: PASS
- `python verify_source.py`: `VERIFY_SOURCE_OK`
- Build contract updated to release sequence 25 / RC7.2-R0025.
- R0024b Workstation frequency behavior retained: per-Sonication `SonicationSummary.frequency` is authoritative when present.
- Qt circular ROI implementation/test remains in source. It cannot be executed in this Linux validation runtime because PySide6 is not installed.

## Check 2 — Non-GUI regression and connection audit
- `pytest -q --ignore=tests/test_r0015_circular_roi_measurement.py`: **65 passed**.
- MainWindow wiring checked: Sonication selection -> Export workspaces -> EngineeringAnalysisService -> Metrics / Dependency / ACT / Skull / Spectrum / Thermometry tables.
- PARTIAL capability graph is independent by feature; missing Thermometry does not disable Spectrum, ACT, or Skull analysis.
- SpectrumMsg exact structure analysis uses the complete payload, not the former 8 MB truncation path.
- `channel_count=8` is reported strictly as container metadata. No unverified 8-way payload splitting is performed.

## Check 3 — Real Export evidence
### Sonication10 standalone sample
- Temperature / Magnitude: 11 / 12 frames.
- ACT: 1024 elements; active 938; disabled 86.
- SkullMeasures: 1024 rows; geometry-valid 1017.
- ACT <-> Skull phase: max delta 0.000499 rad; mean delta 0.000253 rad.
- SkullHeating: active 938; Algorithm off=7; NPR off=75; CPC off=4.
- Sum of element AvgPower: 847.014 W.
- SpectrumMsg: exact 67 frames; 200,640 B/frame; 8-channel container metadata; 272-B global header.
- PARTIAL standalone status is expected because Sonication1 shared Planning assets are not present in this isolated folder.

### Legacy MR / TMAP subset
- Workflow: 2D / Multi-plane.
- Thermometry: TMAP (Single Echo).
- SonicationSummary replay frequency read as 0.670 MHz.
- Field5 baseline detected as 37.00 C.
- Engineering metrics generate without requiring TMAP-ME.

## Result
PASS for source, non-GUI regression, Export Core connections, and real-data engineering analysis.
One environment limitation remains: the PySide6-dependent circular ROI GUI test requires Windows/GitHub or another runtime with PySide6 installed.
