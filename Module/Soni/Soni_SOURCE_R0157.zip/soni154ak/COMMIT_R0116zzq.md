# R0116zzq — Band Energy fit + Probable Location recovery

- Band Energy tab uses a viewport height budget so the pinned Replay controls remain accessible.
- Band Energy Y-axis is data-tight instead of the old fixed -60..0 dB range, removing excessive lower empty space while keeping all finite curves visible.
- Probable Location redraw now restores both image/overlay items after plot clear.
- RCV contribution/focus geometry is always visible even when evidence generation fails.
- Probable Location retries frame-only evidence when event-linked estimation fails and refreshes when the Cavitation Events tab is opened.
