# Regression R0116zzzc

## Red threshold contract
- Red overlay condition: temperature >= red threshold.
- Boundary is inclusive.
- Values below the threshold are not part of the red overlay.
- Existing focal connected-region filtering, smooth alpha, pure-red fill and replay refresh remain enabled.

## Verification
- `python verify_source.py`: PASS
- `python -m compileall -q src`: PASS
- `pytest -q --ignore=tests/test_r0015_circular_roi_measurement.py`: 688 PASS
- `test_r0015_circular_roi_measurement.py` is not collected in this Linux environment because PySide6 is unavailable.
