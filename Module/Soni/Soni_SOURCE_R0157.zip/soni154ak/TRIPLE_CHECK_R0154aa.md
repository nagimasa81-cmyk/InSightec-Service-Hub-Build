# R0154aa triple check

1. Semantic/data-owner check
- DQA production path cannot call phantom-relative numeric helpers.
- Legacy phantom-relative arithmetic tokens were removed from DQA source.
- Invalid Brain220 T2*/phase-like float32 RAW is rejected as thermometry.
- SpectrumMsg and physical CPC ownership remain separate and simultaneous.

2. Regression/ancestry check
- Updated historical tests that explicitly required the removed phantom-relative
  DQA algorithm.
- Preserved the 650-family R0130 Band0 contract while preventing its use for 230 kHz.
- ACT fallback is missing-only and does not overwrite existing phase evidence.
- 1043 non-GUI tests pass; one AES ZIP test is skipped only because pyzipper is
  not installed in the validation environment.

3. Packaging/identity check
- VERSION, constants.py, version.json, build contract and Nuitka BAT descriptions
  all identify RC7.10-R0154aa.
- verify_source.py passes.
- src/ has no duplicate class/function definitions.
- __pycache__, .pytest_cache, *.pyc and *.pyo are removed before packaging.
