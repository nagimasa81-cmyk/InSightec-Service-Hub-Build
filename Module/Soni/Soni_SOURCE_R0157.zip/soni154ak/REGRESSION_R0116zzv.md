# R0116zzv Regression Report

## Automated regression
- `pytest -q --ignore=tests/test_r0015_circular_roi_measurement.py`
- Result: **639 passed**
- R0116zzv async-lifecycle dedicated test file: **19 passed**

## Known environment-only exclusion
`tests/test_r0015_circular_roi_measurement.py` cannot be collected in this Linux validation container because `PySide6` is not installed. This is the same GUI-environment limitation as earlier releases; it is not an application regression discovered by the test suite.

## Source verification
- `python -m compileall -q .` — PASS
- `python verify_source.py` — `VERIFY_SOURCE_OK`

## Static lifecycle audit
`R0116zzv_STATIC_AUDIT.json`:
- duplicate class definitions: 0
- duplicate methods within classes: 0
- exact duplicate `.connect(signal->slot)` occurrences inside a method: 0
- runtime `QApplication.processEvents()`: 0
- production `.wait(` calls: 0
- production `.terminate(` calls: 0

## Regression locks added
The R0116zzv tests fail if any of the following return:
- runtime `QApplication.processEvents()` pumping
- direct Spectrum spectrogram/Band/cavitation computation from GUI draw methods
- stale Spectrum secondary worker publish
- hidden 1024-element table population
- non-batched visible element-table population
