# R0153 — Canonical Sonication timing unification

- Full-datetime WS power-window matching; historical logs from another date cannot win by time-of-day alone.
- Full-datetime MRServer interval matching, including Prepped/Prescanning/Idle -> Scanning transitions.
- Legacy undated MRServer compatibility is projected only onto an already-selected dated WS treatment window.
- Main Temperature, Power/Score, Cavitation, Waterfall, Cavitation Intelligence and Spectrum Dump Analyzer share MR acquisition start = 0 s.
- Chart click/cursor navigation uses the same absolute MR time and does not double-add Sonication start.
- Timing markers are removed before redraw; canonical timing objects are copied, not recomputed by subviews.
- Preserves R0150a find_log, R0151a exact-end/snapshot and R0152 focus separation.
