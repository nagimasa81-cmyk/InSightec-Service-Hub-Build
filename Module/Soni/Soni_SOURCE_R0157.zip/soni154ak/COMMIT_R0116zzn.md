# R0116zzn — Cavitation severity / delivered energy / resilient Sonication Summary

- Adds transparent 0–100 cavitation control-response severity.
- Decrease/modulation severity follows cumulative observed ExPowerRatio reduction; Safety halt = 100.
- Adds cavitation-related Energy delivered (%) from Actual/Target Energy, capped at 100; no intervention = 100, unavailable target = unavailable.
- Sonication Summary detail path skips expensive vendor history/control re-validation and uses primary CPC decode + observed control timeline.
- Adds non-modal Sonication Summary progress popup with per-Sonication progress.
- Prevents overlapping Summary workers; refresh requests queue until the running worker returns.
- Adds new metrics to Summary table and lower chart selector, with localization keys.
