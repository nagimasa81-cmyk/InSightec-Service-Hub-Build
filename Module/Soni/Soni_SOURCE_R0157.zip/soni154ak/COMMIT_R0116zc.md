# R0116zc — Spectrum preload connection recovery

- Fixes Analyzer opening with `No CPC source loaded` after Export adoption.
- If ReplayPackage CPC inventory yields no physical SpectrumDumps candidate, background worker performs one recovery discovery over the Export workspace.
- Releases completed/failed preload QThread references so failed preload can be retried instead of becoming permanently disconnected.
- Analyzer open restarts preload when no live worker/context exists.
- Spectrum preload status is shown in the source label while waiting.
- Background preload remains non-modal and Analyzer tabs/navigation remain usable.
- Existing cached/preloaded path remains preferred; recovery scan only runs when inventory is empty.
