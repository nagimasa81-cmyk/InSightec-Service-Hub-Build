# R0052 — Cavitation chart usability + Registration operation

- Registration ON is enabled only when a Preplanning/Planning MR is already displayed in the main Replay image.
- Treatment MR switching resets prior planning-image zoom so the acquired MR fills the main viewer.
- Application-level arrow navigation was hardened for child widgets.
- Vendor band energy is the full-width upper chart.
- Cavitation control response and CGA/Acquisition Display Rule share one lower chart with independent left/right Y axes and a Both/Control/Rule selector.
- Selected receiver mode has an explicit RCV0–RCV7 selector next to the view selector.
- Registration review now evaluates plausible CtMr matrix direction and, for preplanning MR, MrMr chain hypotheses against MR/CT edge agreement. Bone edges are thickened for visibility.
