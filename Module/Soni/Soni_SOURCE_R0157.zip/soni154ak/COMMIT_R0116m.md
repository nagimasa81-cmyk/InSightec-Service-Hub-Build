# R0116m — Replay flow repair

Observed regression in R0116l:
- Temperature graph stayed empty when Load images was OFF.
- Replay buttons/slider updated only part of the state because `set_frame()` returned early in no-image mode.
- Spectrum Dump Analyzer performed its expensive Export discovery/decode before showing the window, so the button appeared dead.

Fixes:
- Added cached thermometry-only replay trends. Temperature RAW is decoded numerically without loading magnitude MR, thumbnails, registration images, or display arrays.
- Temperature graph, current ROI Max/Avg, Sonication Summary, and Cavitation Intelligence now share the same thermometry cache.
- Metadata-only replay frames carry numerical temperature metrics while image arrays remain `None`.
- Removed the no-image early return from `set_frame()`. Only image rendering/registration is gated; Replay cursor, Temperature, Power/Score, Spectrum, Cavitation, CI, phase, and synchronized panels continue to update.
- Spectrum Dump Analyzer is shown first, then its Export context load is deferred to the next event-loop turn.
- Hidden Spectrum analyzer windows are no longer eagerly synchronized during study/Sonication loading.
- Existing strict `Load images OFF` thumbnail/image blocking remains intact.

Validation:
- 31 regression tests passed.
- Real export `10-00-09_ANx(1).zip`: 8 Sonications discovered; Sonication 1 temperature trend produced 11/11 finite replay points while both magnitude and temperature display arrays remained unloaded in metadata-only frame mode.
