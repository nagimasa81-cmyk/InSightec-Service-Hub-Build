# R0116j — Strict Load Images OFF

- Renamed `No image` to the unambiguous `Load images`.
- Default is OFF.
- OFF means no Planning/Reference/Treatment MR/Thermal thumbnail worker is scheduled.
- Both thumbnail worker entry points independently return immediately while OFF.
- Turning OFF increments both thumbnail generations before cancelling workers, so stale results are invalidated.
- All thumbnail ready/finished callbacks independently reject results while OFF.
- OFF clears thumbnail caches and visible strips and disables Registration/image selectors.
- Replay continues through the existing metadata-only `decode_images=False` path.
- ON explicitly enables staged image/thumbnail loading.
- R0116i Sonication Summary frequency/background behavior is preserved.
