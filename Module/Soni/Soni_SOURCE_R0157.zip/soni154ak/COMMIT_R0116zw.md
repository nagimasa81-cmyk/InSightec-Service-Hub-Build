# R0116zw — Replay chart cleanup and science label visibility

- Removed chart-local collapse/enlarge buttons from Replay Temperature/Spectrum/Power panels.
- Replay section-level collapsers remain the single layout control so plots use the full available viewport.
- Temperature Trend now uses one custom hover popup only; removed duplicate plot TextItem/native tooltip display.
- Temperature hover popup auto-hides after 1.5 seconds.
- Treatment Outcome Science plot adds visual margins around the 0..100 score domain.
- Sonication labels flip anchors near upper/right boundaries so Sxx labels remain fully visible.
- R0116 regression: 202/202 PASS.
- Full non-PySide6 regression: 508/508 PASS.
