# R0142 — Acquisition session start-token unification

## Real-device regression
R0141 still showed `0/5 mapped; 27 CPC candidate(s) discovered` and every Cavitation Summary row remained `Control evidence unavailable`. The Import audit itself showed the loaded package consistently had five numbered Sonications, so the remaining failure was downstream session binding rather than logical Sonication construction.

## Root cause
`CavitationControlTimelineService` accepted the generic workstation token `Got StartSpectrumMeasurement`, while `AcousticControlService` only accepted `Got StartSpectrumMeasurementA` or the newer `StartSpectrumMeasurement: SetInitial PowerRatios` form. On exports using the generic token, `AcousticControlService.parse_segments()` returned no treatment sessions. That simultaneously prevented CPC candidates from receiving Acquisition session indices and prevented Summary from selecting an authoritative control session.

## Fix
- Unified AcousticControl start recognition with the control timeline parser.
- Accept `Got StartSpectrumMeasurement`, `Got StartSpectrumMeasurementA`, and `StartSpectrumMeasurement: SetInitial PowerRatios`.
- Kept the existing <2 s debounce so multiple start-related lines for one physical sonication do not create duplicate sessions.
- Added regression coverage proving the generic token creates multiple Acquisition sessions and enables exact CPC filename-clock -> session binding.
- No latest-N / blind positional CPC mapping was introduced.

## Validation
- R0142 targeted regression: PASS.
- `verify_source.py`: PASS after release metadata synchronization.
- `compileall`: PASS.
