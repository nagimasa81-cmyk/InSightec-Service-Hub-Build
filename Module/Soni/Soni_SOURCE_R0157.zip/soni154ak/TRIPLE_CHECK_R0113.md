# R0113 Triple Check

## 1. Image-row visibility / stale connection audit
PASS
- Removed Show Reference and Show Treatment MR controls.
- Removed show_reference_images_check / show_treatment_mr_images_check.
- Removed _reference_nav_widgets / _treatment_mr_nav_widgets visibility state.
- Reference, Treatment MR and Treatment Thermal rows are permanent.

## 2. Planning / Preplanning MR thumbnail source audit
PASS on 10-00-09_ANx(1).zip
- Planning MR Ax: 52/52 decodable
- Planning MR Cor: 49/49 decodable
- Planning MR Sag: 49/49 decodable
- Preplanning MR Ax: 13/13 decodable
- Preplanning MR Cor: 15/15 decodable
- Preplanning MR Sag: 19/19 decodable
- Default Reference selector changed to Planning MR All (Ax + Sag + Cor).
- Every exported image is inserted as a list item before decoding.
- Background worker now updates the matching item icon directly; it no longer repeatedly rebuilds the whole list during thumbnail loading.

## 3. Sonication Summary freeze audit
PASS at code/regression level
- Exported Power / Duration / Energy seed immediately.
- Seeded rows are also used by the chart immediately.
- Thermal / CPC / RCA detail runs in SonicationSummaryDetailWorker on QThread.
- Main GUI thread no longer sequentially executes _build_one_sonication_summary for each row.

## Regression
- compileall: PASS
- non-GUI regression suite: 295 passed
- full GUI suite cannot be collected in this Linux validation environment because PySide6 is not installed.
