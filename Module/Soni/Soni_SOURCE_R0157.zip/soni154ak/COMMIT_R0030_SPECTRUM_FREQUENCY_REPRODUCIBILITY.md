# R0030 — Spectrum Frequency Reproducibility Deep Validation

## Objective
Increase reproducibility of the acoustic-spectrum frequency axis without inventing bins from sonication frequency or the Nyquist range.

## Evidence hierarchy
1. Embedded graph start/spacing stored beside each 256-bin spectrum record.
2. SpectrumMsg declared frame/channel counts used as a structural cross-check.
3. Acquisition.ini f1ForGraph/f2ForGraph used as a consistency check and fallback only.
4. SamplingFrequency / SizeOfOutputGraph used only for theoretical FFT-resolution comparison.

## Validated 6.33 export findings
- SpectrumMsg graph records: 256 bins, start 250000 Hz, stored spacing 1953 Hz.
- CPC Spectrum_*.dmp_FFT records: the same axis is stored as 0.25 MHz and 0.001953 MHz.
- Acquisition.ini window: 250000..750000 Hz.
- Sampling frequency: 2,000,000 Hz.
- Effective output graph configuration: 1024, giving theoretical FFT spacing 1953.125 Hz.
- The vendor-stored display spacing differs from the theoretical spacing by only -0.125 Hz/bin.
- A nominal 670 kHz main frequency maps to the stored-display bin at 669.895 kHz (error -105 Hz), well below one graph bin.

## R0030 changes
- Parse embedded graph-axis metadata in both SpectrumMsg and CPC FFT containers.
- Support both vendor unit representations: Hz and MHz.
- For SpectrumMsg, validate exact record count = declared frame_count × channel_count before accepting the explicit graph reconstruction.
- Preserve embedded vendor axis as the display/replay axis; do not silently replace it with the theoretical FFT axis.
- Expose frequency-axis provenance, start/end, bin spacing, nearest-f0-bin error, and theoretical-resolution delta.
- Added reusable `tools/validate_spectrum_frequency_reproduction.py` for export-level audits.

## Result
The validated export passed all 8 SpectrumMsg sonications and all 15 CPC FFT dumps with a stable 250.000–748.015 kHz vendor axis and ~1953 Hz spacing.
