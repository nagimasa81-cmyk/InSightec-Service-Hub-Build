# R0154k — ZIP-drop Summary completion gate + CPC pre-irradiation semantics

## Sonication Summary ancestor regression
- Authoritative Spectrum handoff no longer calls `_refresh_sonication_summary()` directly while a full-table Summary worker is active.
- All Summary starts/retries route through `_request_sonication_summary_detail()`, which now leaves an active all-Sonication pass running instead of cancelling/restarting it.
- This removes the queued-signal race seen after ZIP drop where Sonication 1 completed but rows 2..N stayed on `Analyzing…`.
- A completed row whose canonical control evidence is unavailable is now shown as terminal `Control evidence unavailable`, not as an apparently still-running `Evidence pending` row.

## CPC pre-irradiation display
- The Measurement Timeline title now explicitly says that the fallback trace is **processed CPC 8CH measurement history, not the Raw A/D waveform**.
- R0154 wall-clock positioning can legitimately change where this processed history appears relative to Sonication start, but this release does not reinterpret the history as acoustic waveform data.

## Brain220 follow-up
- R0154k deliberately does not fabricate CPC samples or stretch an 18-frame CPC replay to Sonication end. A CPC source that ends early must remain visibly incomplete until its source-candidate/session coverage is proven from the Export evidence.
