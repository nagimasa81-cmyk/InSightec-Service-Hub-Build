# Thermometry evidence deep audit — R0154ad

## Evidence contract
DQA numeric displacement requires **observed thermal focus − planned focus in the same registered MR raster**. A RAW field number or byte size is never enough.

A candidate is accepted only when:
1. the RAW filename binds to an exact `MriImageParams` row,
2. the MR protocol is not explicitly non-thermal (T2*/T2_Star/NFUSCAL),
3. the float raster has a plausible absolute-temperature or delta-temperature distribution, and
4. the planned focus projects into the same exported frame.

## Real 42110 Brain220 export
Deep inspection of `42110-2026-04-01-18-30-47.zip` found:
- Field 5 exists only for Sonications 4/5/7 and is labelled `T2_Star_ME_1SL`.
- Its float32 values are MR-signal/T2*-like, with medians around 9,681–14,229 and maxima around 32,767, not degrees C.
- Field 6 is matching MR magnitude.
- Fields 13/14/24 are `Brn-NFUSCAL1` image volumes (21 slices each); they are calibration/anatomical evidence, not temperature maps.
- Fields 2/23/28/34 are zero-byte placeholders in this export.
- Field 52 is a near-zero derived raster and is not accepted as thermometry.

Therefore this particular 220 export does **not** contain validated numerical thermometry suitable for manufacturing DQA X/Y/Z. It must remain fail-closed until a genuine observed-focus source is identified.

## Why this matters
Previous code treated field 5 as temperature by filename alone. In Brain220 this can turn T2* signal into a false hotspot. R0154ad prohibits that path structurally.
