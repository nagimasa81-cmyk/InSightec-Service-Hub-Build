# R0047

- Global arrow navigation via application event filters in Main Replay and Spectrum Dump Analyzer.
- Cavitation charts default to full-range All 8 receivers.
- Chart click and observed-event table click are synchronized with FFT snapshot selection.
- Reconstructed ExPowerRatio is aligned to the observed session's acquisition-cycle origin.
- User-facing hydrophone labels standardized to RCV0-RCV7, matching the supplied Cap/Tile receiver drawing.
- Registration view no longer fabricates CT/MR fusion by image resizing. Planning MR remains the reference until a registration transform is actually decoded.
- Right-side image navigator terminology changed to Reference / Anatomy / Thermal, with Registration as an explicit reference mode.
