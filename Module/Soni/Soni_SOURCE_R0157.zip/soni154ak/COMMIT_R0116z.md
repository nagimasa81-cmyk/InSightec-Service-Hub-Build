# R0116z — 91% loading stall repair

- Initial Sonication load no longer precomputes Sonication Elements, Cavitation Intelligence, Engineering Analysis, Export/Replay detail tables, or Diagnostics while the exclusive progress dialog is open.
- The 91% "Metadata and analysis panels" stage now performs only cheap selected-Sonication metadata work.
- Heavy panels refresh lazily when their tab is opened.
- Removed the duplicate full dependent-view refresh after Sonication combo changes.
- Removed Cavitation Intelligence / Sonication Elements from the generic eager dependent-view refresh path.
- Replay becomes available immediately after essential Spectrum, trend, cavitation-core, optional image, and metadata stages complete.
