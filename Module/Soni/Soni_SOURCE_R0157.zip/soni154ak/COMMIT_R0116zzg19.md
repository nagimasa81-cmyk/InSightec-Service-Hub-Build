# R0116zzg19 — Spectrum MR timeline ndarray truthiness regression fix

## Root cause
R0116zzg16 introduced MR Spectrum timeline helpers that used `getattr(replay, "mr_frame_times_s", []) or []`. `mr_frame_times_s` is a NumPy ndarray property. Evaluating an ndarray in boolean context raises `ValueError: The truth value of an array with more than one element is ambiguous`.

The exception occurs before `_draw_spectrum()` can bind any FFT curve. It also aborts `_set_frame_primary_only()` before primary materialization, explaining the observed sequence: source header says Decoded N frames, Measurement Timeline can later draw independently, Spectrum remains blank with the stale `waiting for decoded CPC frames` label, and visiting secondary tabs can populate unrelated products without fixing Spectrum.

## Fix
- Remove all boolean `or []` evaluation around `mr_frame_times_s`.
- Convert the ndarray directly with `np.asarray(...)` in Spectrum MR phase, timeline label, phase jump and irradiation-end frame selection.
- Preserve g18 pre-irradiation Spectrum Summary and all g17 primary-publish recovery logic.
- Add regression tests preventing NumPy truthiness from returning in these paths.
