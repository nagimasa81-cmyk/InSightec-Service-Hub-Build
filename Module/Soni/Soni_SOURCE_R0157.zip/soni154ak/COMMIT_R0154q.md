# RC7.10-R0154q

This revision consolidates the Brain220/DQA/Spectrum/Elements corrections after R0154o/p.

- Brain220 BBB 3x3 sub-sonications are not interpreted as target voxels.
- S5 in the 42110 DQA export is one executed SpotCue (single target); it is excluded from DQA numerics only because its workstation steering is off the default centre.
- Numeric DQA alignment is emitted only for a proven single treatment SpotCue at default-centre steering.
- For eligible DQA shots, the reported focus is the observed spatially-supported thermometry focus converted with that RAW frame's own MriImageParams row. Planned focalRAS is only search/validation evidence and a fail-closed fallback.
- Real 4267 690-kHz DQA verification changes the default-centre examples from planned-frame subtraction to observed per-shot values (about 1-3 mm lateral and 7-9 mm S/I in that export); steered S4 remains N/A.
- Replay target overlays use SpotSonicationData ownership plus SpotMesh physical geometry. Every export-proven target is drawn at its projected position and size; Target 1 is the default temperature ROI.
- Brain220 SpectrumMsg aggregate can populate Spectrum/Spectrogram when no physical RCV CPC pair exists, without inventing RCV0-RCV7 or raw A/D.
- The fast candidate universe now merges Sonication-owned SpectrumMsg with physical CPC, so a complete physical CPC mapping no longer hides embedded 220 SpectrumMsg sources from Spectrum Dump Analyzer.
- When an exact physical CPC treatment-block mapping proves an Acquisition_Brain session but Sonication_Brain evidence is absent, that exact session may backfill the canonical session for linked Spectrum/Cavitation timing.
- Sonication Elements umbrella front/side/perspective vertical display uses the corrected screen-Z sign; Top XY is unchanged.
- Repeated ZIP-load cancellation/progress hardening from R0154p is retained.
