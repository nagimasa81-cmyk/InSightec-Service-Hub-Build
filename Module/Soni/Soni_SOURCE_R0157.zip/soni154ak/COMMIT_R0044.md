# R0044

Fixes two issues visible in the latest validation screenshots:

1. The Control Timeline chart had no data because the observed timeline parser was not invoked after the R0043 layout refactor. R0044 restores parsing/drawing and nearest-cycle selection.
2. The cavitation likelihood geometry now follows the supplied receiver-location reference: Cap RCV CH0-3 and Tile RCV CH4-7.
