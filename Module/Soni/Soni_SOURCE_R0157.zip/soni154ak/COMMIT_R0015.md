# Commit R0015 - Circular ROI Measurement

- Added a movable and resizable circular ROI measurement tool to the main Sonication Analysis overlay viewer.
- Added Show ROI / Copy / Clear controls in the left information panel.
- Measurement uses the visible temperature map when thermal data is shown; otherwise it measures the displayed magnitude image.
- Live statistics: mean, standard deviation, median, min, max, pixel count, circular diameter, and circular area in pixels.
- Results can be copied to the clipboard as tab-separated values.
- Existing fixed treatment ROI and cursor behaviour are unchanged.
