# R0106 — Fast Load / Thermal Thumbnail Lazy Load

- Treatment Thermal image row is hidden by default.
- Adds `Show Thermal Images` checkbox; unchecked is the startup/default state.
- Thermal RAW thumbnails are decoded on a dedicated QThread after the normal Sonication navigator becomes usable.
- Thermal thumbnails are cached and never re-read during strip rebuilds or selector changes.
- Turning the checkbox on displays thumbnails already available in cache while remaining thumbnails continue loading.
- Thermal thumbnail work is cancelled/replaced when Sonication selection changes.
- Main treatment replay behavior is unchanged; this change targets thumbnail/navigation loading only.
