# R0054 — Cavitation MR / Registration evidence refinement

- Added explicit receiver-labelled log phase/channel extraction.
- Added WW/WL and zoom controls to MR signal-loss correlation.
- Event/list selection now recalculates probable location for that exact event.
- Registration requires patient/world geometry when available and avoids presenting a geometry-free overlay as treatment registration.
- Legends occupy reserved chart-header space.
