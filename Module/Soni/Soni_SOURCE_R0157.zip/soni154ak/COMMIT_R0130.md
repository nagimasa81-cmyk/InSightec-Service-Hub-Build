# R0130 — FFT Band0 contract + MR frequency-direction hat

- FFT-derived Band0 is fixed to 0.311–0.411 MHz.
- Raw A/D selected-range FFT highlights this exact interval and reports per-receiver Band0 FFT RMS.
- Main image annotation adds the workstation-style cyan lower-right hat marker using the resolved anatomical frequency axis; unknown direction is not guessed.
- R0129 FFT range dropdown/direct drag and Control Timeline layout hardening are preserved.
