# R0116zzg14 — Summary interruption provenance + deterministic tab materialization

- Cavitation-positive Sonication Summary rows are red/bold.
- Non-cavitation interrupted sonications preserve SonicationSummary.xml `panictype` in status, e.g. `Patient : No Power Decrease / Safety event`.
- Selected-Sonication trend/Spectrum preparation starts from Sonication selection itself, not a later tab visit.
- Spectrum Dump Analyzer replay adoption materializes Raw/Spectrum/Measure immediately and all secondary tabs from one payload without requiring cursor movement/tab clicks.
- Carries forward R0116zzg13 authoritative control-clock corrections.
