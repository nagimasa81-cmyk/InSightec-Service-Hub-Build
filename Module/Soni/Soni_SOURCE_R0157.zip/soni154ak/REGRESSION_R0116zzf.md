# R0116zzf Regression Report

## Fixes
- Replay right pane now uses tight / compact / normal height profiles based on the actual vertical splitter viewport.
- Thumbnail strip, thumbnail slider, Temperature/Spectrum minimum height, Power/Score/Cavitation minimum height, and cavitation subplots resize together.
- Splitter handle height is reserved before distributing visible section sizes.
- Replay right sections use vertical `QSizePolicy.Ignored` so stale/intrinsic size hints cannot push the bottom section outside the visible page.
- `resizeEvent` schedules a fresh replay-right rebalance after maximize, restore, and monitor/window-size changes.
- Finite spatially-uniform Treatment Thermal frames are valid. The first baseline Thermal frame is no longer discarded merely because `nanstd == 0`.
- Constant Treatment MR frames remain rejected as invalid anatomical images.
- Treatment Thermal thumbnail red mask remains `temperature >= red_threshold` and no longer applies the old two-pass mask blur.

## Verification
- Dedicated R0116zzf contract tests: 5 PASS.
- Full test suite excluding the known PySide6-only GUI collection test: 702 PASS.
- `verify_source.py`: VERIFY_SOURCE_OK.
- `compileall`: PASS.
- AST duplicate-method scan: PASS.
- Known environment limitation: `tests/test_r0015_circular_roi_measurement.py` cannot collect in this Linux validation runtime because PySide6 is not installed.
