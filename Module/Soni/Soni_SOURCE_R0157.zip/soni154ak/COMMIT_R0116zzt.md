# R0116zzt — cross-view synchronization / registration / thumbnail / CI repair

- Registration overlay now uses deterministic green RGBA rendering instead of sharing Thermal/ΔT LUT state.
- Temperature mode and red-threshold changes no longer repaint a selected Planning/Preplanning MR with live Thermal data.
- Planning MR thumbnails are restored with lazy, low-priority post-Replay decoding; selected on-demand images backfill the thumbnail cache immediately.
- Sonication Summary keeps fast/detail rows first, then runs a second low-priority thermometry enrichment worker so Start/Peak/ΔT are populated without blocking the GUI.
- Acoustic, Waterfall and Cavitation chart clicks use the common irradiation-start=0 convention and return a Planning reference view to synchronized Replay before moving the cursor.
- Probable cavitation region is suppressed unless a detected/synchronized cavitation event exists (explicit historical Event-list preview remains allowed).
- Spectrum Dump Analyzer always paints a progress popup when opened, including cached/preloaded handoff.
- An empty Cavitation Control timeline now states that no source control-action/power-response payload exists instead of appearing as a rendering failure.
