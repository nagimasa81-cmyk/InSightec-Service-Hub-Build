# R0131 — common X-axis drag zoom + double-click reset

- Drag directly on a chart's bottom X axis with the left mouse button to select an X interval.
- The selected X interval is zoomed with the current Y range preserved.
- Double-left-click anywhere in the plot viewport resets both axes to current data bounds.
- Plot-area drag remains normal pyqtgraph pan, avoiding conflict with Raw A/D FFT chart-area range selection.
- Spectrum Dump Analyzer manual-view preservation is updated on range zoom and cleared on reset.
