# R0116zzg23 — Band0 gap alignment + canonical CI time axis

- Band0 reconstructed metric now uses the same physical dB reference as measured FFT Band0.
- Reconstruction is shown only inside validated FFT gaps, never over measured regions.
- 10-ms history is aligned/validated against exact FFT snapshot history indices; unstable amplitude mapping is rejected.
- Cavitation Intelligence linked control/vendor plots now use MR acquisition start = 0 and the same MR duration as Spectrum Dump Analyzer.
- Controller validation event cycles are mapped by the shared physical sonication_cycle_zero instead of the legacy pre-roll offset.
- Sonication start/end markers are shown on the CI linked charts.
- Full Spectrum/Spectrogram gaps remain missing unless verified RAW A/D exists; Band0 metric reconstruction does not fabricate full spectra.
