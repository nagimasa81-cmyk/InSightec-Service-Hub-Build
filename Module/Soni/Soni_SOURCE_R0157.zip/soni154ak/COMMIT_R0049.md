# R0049

Image workflow now mirrors treatment semantics:

1. Preplanning CT
2. Preplanning MR Ax / Sag / Cor
3. Treatment-day Planning MR Ax / Sag / Cor (including reformatted 3-D planning series)
4. Treatment MR actual magnitude images
5. Treatment Thermal

Registration review is no longer a synthetic standalone image type. When a preplanning/planning MR is on the main replay viewer, Registration ON overlays CT skull edges using the treatment-adopted CtMr registration matrix for that sonication.
