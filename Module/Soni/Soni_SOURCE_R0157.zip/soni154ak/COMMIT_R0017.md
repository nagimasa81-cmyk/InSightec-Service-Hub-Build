# R0017 — Sonication Target and Actual Metrics

- Corrected the Sonication information-panel frequency from the Xd nominal 0.800 MHz value to the treatment transmit frequency 0.630 MHz.
- Added separate Target and Actual rows for Energy, Power, and Duration.
- Reads measured/actual power and energy fields from SonicationSummary.xml when present.
- Uses calculated values only as a fallback when an explicit target/actual energy is unavailable.
- Updated the detailed Info and Scan views to use the same labels.
