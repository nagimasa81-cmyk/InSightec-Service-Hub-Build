# R0116o — Dynamic Cavitation Sync / Source Reset

- Fixed missing Control Timeline mouse-click connection; event click now reaches selection/Why logic.
- Probable Location follows the live replay frame again after leaving an explicit event inspection.
- Added current-frame cursor and row synchronization to Hydrophone × Band.
- Added replay-safe display rebuild guard: changing Raw/Spectrum display pauses playback, rebuilds once, resumes at the same frame.
- Added hard Spectrum source-context reset.
- Main Open ZIP/folder/drop now uses latest-open-wins behavior; a new request is queued instead of being ignored while extraction is active.
- Stale package-load results are discarded when a newer source was requested.
- Registration display contour narrowed (display only); full CT skull remains unchanged for registration QA.
