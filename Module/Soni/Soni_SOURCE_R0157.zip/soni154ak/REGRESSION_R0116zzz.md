# R0116zzz Regression / Deep Validation

- Non-PySide6 suite: **670 passed**.
- Known environment exclusion: `tests/test_r0015_circular_roi_measurement.py` requires PySide6, unavailable in this Linux validation image.
- Real data: `10-00-09_ANx.zip` recomposed with the current source.
  - S1 429.8 W / 11.470 s / 4536.2 J / no confirmed cavitation / delivered 100.805%.
  - S2 429.8 W / 11.474 s / 4536.7 J / no confirmed cavitation / delivered 100.815%.
  - S3 962.2 W / 24.576 s / 21070.4 J / 966 vendor Rule Triggers / Peak 50.77 C / delivered 100.235%.
  - S4-S8 retain confirmed Vendor Rule Trigger evidence.
- Red threshold benchmark after hardening (synthetic focal region): 256² ~6 ms, 512² ~26 ms, 1024² ~104 ms in this container; previous audit measured ~66 / 364 / 1360 ms.
- `10-00-09_ANx.zip` extraction without pre-`testzip()`: ~3.68 s in this container.

- `verify_source.py`: **VERIFY_SOURCE_OK**.
- Python compileall: **PASS**.
- Static duplicate-method / processEvents / daemon-reader / terminate audit: **PASS**.
