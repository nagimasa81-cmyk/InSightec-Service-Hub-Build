# R0154f

- Harden canonical Sonication identity: ignore completely empty trailing Sonication folders.
- Collapse duplicate Type-6 Sonication_Brain setup writes only when near-adjacent and physically identical.
- Prefer Acquisition_Brain internal session evidence over filename clock assumptions.
- Add DQA-only focus alignment to Sonication Summary: X/Y vs phantom circle center, Z vs lower straight reference line, and phantom tilt.
- Highlight DQA focus alignment when |X| >= 15 mm, |Y| >= 15 mm, or |Z| >= 20 mm.
- Preserve R0154e canonical load / diagnostics behavior and prior R0154a-d fixes.
