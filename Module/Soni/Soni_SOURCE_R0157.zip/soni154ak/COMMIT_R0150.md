# R0150

- Movement Detection primary evidence now uses treatment-day WS `FinalMovementVector` (RAS).
- Each vector is bound to the next Sonication using `SonicationSummary.sontime` within 90 seconds.
- RAS is presented as RL=X, SI=Z, AP=Y; missing pre-Sonication measurements remain missing.
- Sonication Summary adds a dedicated **Movement Detection graph** button.
- The graph renders RL / SI / AP as three series and leaves unmeasured Sonications as gaps.
- R0149 canonical steering and data-loading behavior are preserved.
