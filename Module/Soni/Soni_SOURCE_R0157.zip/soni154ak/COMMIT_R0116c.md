# R0116c — Full-frame Thumbnail UI

- Thumbnail cells keep their compact footprint.
- Every thumbnail uses KeepAspectRatio with a black letterbox canvas.
- No crop and no aspect-ratio distortion.
- Hovering a thumbnail opens a larger full-frame preview without changing selection.
- Each Reference / Treatment MR / Treatment Thermal row has a compact ↗ gallery button.
- Gallery displays all images in a wrapping grid and reuses the same payload/navigation path.
- Existing image-index QSlider remains the primary compact-row navigator.
- No image re-decode is triggered by slider, hover preview, or gallery navigation.
- Registration visibility changes from R0116b are preserved.
