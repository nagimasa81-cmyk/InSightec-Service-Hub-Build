# COMMIT R0082 — Cavitation Intelligence Layout / Image Visibility Fix

## Summary
Improves the Cavitation Intelligence workspace usability on laptop displays.

## Changes
- Evidence Chain converted to collapsible section
- Cavitation Root Cause Analysis converted to collapsible section
- Added `Show images` checkbox to hide/show the image area
- Added `Fit all` and per-image `Fit` actions
- Likelihood and MR images now auto-fit after redraw
- Increased image minimum height to keep full content visible more often
- Keeps event / element lists optional via checkbox

## User impact
- Images are easier to see without being crushed by text sections
- Dense interpretation blocks no longer consume space unless needed
- Users can quickly focus on images or details as needed
