# R0031 — Vendor Cavitation Reproduction Deep Validation

For CPC 6.33 exports, `CavitationSafetyAndControl.ini` defines four harmonic bands as `f0 * ratio ± delta`. The saved CPC raw companion contains eight non-zero measurement histories. R0031 validates their semantics by applying the actual `INCREASE_POWER_RULE_0` weights and matching the result against `Acquisition_Brain` `Calculated Energy` cycle-by-cycle.

Validated real export `17-00-24_ANx`:
- 15/15 Spectrum dump pairs passed exact Band0 validation.
- First run: n=1160, r=0.999999, MAE≈2.46e-7, max error≈5e-7.
- Normalized Display Rule 1 (`Calculated Energy / 0.025`) independently matches the Acquisition log with r≈1.0 and MAE≈2.5e-5 (log output is rounded to four decimals).
- For f0=670 kHz the vendor bands are:
  - Band0: 311.130–411.130 kHz (`0.539*f0 ±50 kHz`)
  - Band1: 261.400–301.400 kHz (`0.42*f0 ±20 kHz`)
  - Band2: 330.000–340.000 kHz (`0.5*f0 ±5 kHz`)
  - Band3: 665.000–675.000 kHz (`1.0*f0 ±5 kHz`)

Bands 4/5 shown in the historical CGA UI are not assigned vendor semantics unless another configuration source proves them. R0031 deliberately leaves them as user-editable analysis bands rather than guessing.
