# R0116h — No image default / fast loading

- Added `No image` checkbox immediately below Registration.
- Default is OFF.
- OFF means no Reference / Treatment MR / Thermal image files are decoded.
- Thumbnail workers are not scheduled and stale delayed workers are hard-gated.
- Replay uses a metadata-only frame path with no magnitude RAW, temperature RAW or baseline reads.
- Image-derived temperature scans, cursor-temperature scans and RCA temperature scans are skipped while OFF.
- Registration is disabled while image loading is OFF.
- Turning the checkbox ON starts staged background image loading and displays the current replay frame.
- Turning it OFF cancels image workers, clears decoded image caches and removes the displayed image without affecting spectrum/cavitation/log analysis.
- R0116g MainWindow scope fix and R0116f Increase-default-hidden behavior are preserved.
