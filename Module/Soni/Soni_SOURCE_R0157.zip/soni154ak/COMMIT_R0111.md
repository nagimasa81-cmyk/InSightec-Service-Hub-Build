# R0111

- Sonication Summary Power/Energy now reads numeric SonicationSummary model values directly.
- Unit-bearing strings such as `429.8 W` and `4536.2 J` are also parsed correctly.
- Reference thumbnail preview budget restores visible thumbnails while preserving lazy loading.
- CT registration volume lazy-decodes the signed field-16 CT stack; R0110's lazy-image change no longer removes the bone overlay.
- Increase events are hidden by default from both Cavitation Control chart and event list.
- Umbrella is now a geometry-based interactive 3-D view using exported Element X/Y/Z.
  - left drag: rotate
  - wheel: zoom
  - Perspective / Top XY / Front XZ / Side YZ projections
  - Blade selection plus channel range/filter selection
- Phase-value interpretation remains separate. Selecting a phase parameter no longer forces `Phase dedicated`.
