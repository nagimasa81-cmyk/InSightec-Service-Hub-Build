# R0116zzt Regression Report

## User-visible repairs
- Red-threshold / Registration overlay state isolation: PASS (static regression + compile).
- Planning MR thumbnail lazy/background restoration: PASS.
- Sonication Summary background thermometry enrichment: PASS.
- Cross-chart click synchronization with irradiation-start=0: PASS.
- Probable cavitation region gated to qualifying Decrease/Safety cavitation events: PASS.
- Spectrum Dump Analyzer progress popup on open/cached handoff: PASS.
- Empty Cavitation Control timeline explicitly reports absent source payload instead of looking broken: PASS.

## Automated validation
- `python -m compileall -q src`: PASS.
- `python verify_source.py`: PASS.
- Focused R0116zzt regression tests: 10 PASS.
- Full non-GUI regression suite: 613 PASS.
- `tests/test_r0015_circular_roi_measurement.py`: not executable in this Linux validation container because PySide6 is not installed; unchanged from the prior environment limitation.

## Duplicate / signal audit
- Duplicate class methods in `main_window.py`: 0.
- Duplicate class methods in `hydrophone_window.py`: 0.
- Duplicate class methods in `image_panel.py`: 0.
- Temperature plot click connection: 1.
- Power/Score plot click connection: 1.
- Waterfall plot click connection: 1.
- Cavitation plot click connection: 1.
- Sonication Summary double-click connection: 1.
- Registration toggle connection: 1.

## Important behavior note
A Cavitation Control timeline with no qualifying events and no observed/reconstructed ExPowerRatio payload is legitimately data-empty. R0116zzt does not invent a curve; it shows an explicit in-chart message. Likewise, RCV monitoring evidence may exist without cavitation, but the Probable cavitation region is no longer displayed unless a qualifying cavitation event exists.
