# RC7.2-R0116x — Spectrum Load + Screen Fit + XD 3D Integration

- Spectrum Dump Analyzer resolves package-level CPCFiles to a concrete FFT/RAW pair before decode, so package-level Spectrum dumps do not depend on SonicationN directory placement.
- Source label is updated before decode, making source resolution visible during load.
- Spectrum Dump Analyzer automatically fits inside the available laptop desktop on first show; normal resize/maximize remains available.
- Replay XD button now opens the shared Sonication Elements 3-D umbrella instead of a disconnected 2-D XD dialog.
- Sonication Elements Display adds XD/SkullMeasures metrics including SDR, skull thickness, angles, distances, cortex/marrow intensities, phase correction and total phase shift.
- XD metrics use the same exported physical 1024-element XYZ geometry, channel-state layers, blade filters, projections, rotation and zoom as Sonication Phase/Amplitude.
