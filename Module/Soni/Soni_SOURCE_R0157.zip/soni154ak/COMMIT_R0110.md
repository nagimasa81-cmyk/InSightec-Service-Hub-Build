# R0110 — Thermal Default + Exported MR Reformat Adoption

## Main-view behavior
- Thermal remains the dominant/default main image.
- Thermal thumbnail row is visible by default and still fills from the background cache.
- Reference row is hidden by default; `Show Reference` displays it.
- Treatment MR row is hidden by default; `Show Treatment MR` displays it.
- Changing the Reference dropdown only filters the reference row; it never replaces the live Thermal main image.
- A reference image becomes the main image only after an explicit thumbnail click.

## Exported Preplanning / Planning MR
- `SeriesDataItem.xml` is now authoritative for study role:
  - studytype=0: treatment-day Planning MR
  - studytype=1: Preplanning MR
  - studytype=2: CT
- MriImageParams rows are matched to SeriesDataItem by series number + physical plane.
- This recovers saved low-series-number Planning reformats that the former `series >= 700` heuristic misclassified.
- Exported original and exported reformatted images are used directly.
- Synthetic Sag/Cor reformatting is not used when exported reformats exist.
- Planning/reference RAW decoding is lazy on explicit thumbnail click to reduce Sonication-selection latency.

## Validated export 10-00-09_ANx(1).zip
- Preplanning:
  - Ax field 7 / series 7 / 13 images
  - Cor field 8 / series 8 / 15 images
  - Sag field 12 / series 5 / 19 images
- Treatment-day Planning:
  - Ax field 19 / series 900 / 52 images / exported original 3D series
  - Cor field 20 / series 5 / 49 images / exported saved reformat
  - Sag field 21 / series 4 / 49 images / exported saved reformat
