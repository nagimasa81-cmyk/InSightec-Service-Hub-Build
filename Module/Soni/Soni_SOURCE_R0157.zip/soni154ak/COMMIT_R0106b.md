# R0106b — Planning MR Geometry Plane Resolver

- Fixes treatment-day planning MR series being classified as `PLANNING_MR_UNKNOWN` when the series description has no Ax/Sag/Cor token and the numeric plane code is not one of the legacy 18/20/24 values.
- Plane resolution priority:
  1. explicit series description,
  2. known legacy plane code,
  3. exported RAS row/column direction cosines.
- Direction-cosine fallback computes the image normal (`row × column`) and maps dominant R/A/S axis to Sag/Cor/Ax.
- Real-data validation on `10-00-09_ANx(1).zip`:
  - series 900 / field 19 / description `(Creator:10362)` / imgplane=2 / seriesplane=2
  - normal ≈ (-0.015649, 0.100158, -0.994849)
  - resolved plane: Ax
  - 52 images moved from `PLANNING_MR_UNKNOWN` to `PLANNING_MR_AX`
  - `PLANNING_MR_UNKNOWN`: 0
- R0106 fast/lazy Thermal thumbnail behavior and R0106a reference-display/1024-element fixes are preserved.
