# R0021 — Frequency Guard and Hover Popup Fix

- Reject sonication-frequency candidates outside 0.550–0.700 MHz.
- 0.800 MHz can no longer be adopted from unrelated settings.
- Fall back to a valid non-default Xd_####.ini, then 0.650 MHz.
- Show Spectrum, Acoustic Power/Score and Temperature hover values as cursor tooltips.
- Preserve the in-chart hover label as a secondary visual indicator.
