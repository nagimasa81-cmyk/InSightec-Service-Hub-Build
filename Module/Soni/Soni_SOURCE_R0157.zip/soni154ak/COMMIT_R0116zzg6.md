# R0116zzg6 — Selected Sonication publish + CPC handoff reliability

- Publish cache-backed Treatment MR/Thermal immediately while the image worker is still running.
- Repaint the current irradiation-end frame as soon as its source row reaches the RAM cache.
- Proactively retarget Spectrum/CPC preload on every Sonication selection instead of waiting for Analyzer open.
- Merge study-scoped preload contexts so previously decoded Sonications remain reusable.
- Refresh the selected Replay automatically when CPC preload completes.
- End the Spectrum Analyzer exclusive decode progress at the 72% metadata boundary and complete metadata/primary plot handoff on the next Qt event-loop turn.
