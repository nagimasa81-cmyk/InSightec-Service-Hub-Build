# R0116zzw — Auto Essential Images / Activity Monitor / Reset Safety

## User-visible changes

- `Load images` is ON by default, but no image I/O is started during widget construction.
- After package + current Sonication are authoritative, the existing single-owner image pipeline is requested once.
- Current Sonication Treatment MR is the first image stage; the first Treatment MR can be shown before the full cache completes.
- Remaining Treatment MR, Thermal and thumbnail preparation continue in the background.
- Reference/Planning bulk decode remains lazy/on-demand.
- Initial SpectrumDumps preload is automatically deferred briefly so essential current-Sonication images get first I/O opportunity.
- Image progress has its own non-modal `BackgroundProgressDialog`; the package-ready modal can close without hiding image activity.
- Added compact `Activity` and `Reset` controls inside the existing left scroll panel, preserving image width.
- Activity window reports running QThreads, pending requests, image/Spectrum progress, process RSS and major estimated cache sizes.
- Reset menu provides:
  - Restore previous view
  - Reset current study view
  - Unload study (before file load)
- Unload invalidates study workers and safely discards any in-flight package-load result.

## Lifecycle safeguards

- Auto-ON does not emit the checkbox signal during UI construction.
- Essential image worker remains single-owner and generation-scoped.
- During image loading, async Replay callbacks no longer clear the early Treatment MR preview as if images were OFF.
- No `QApplication.processEvents()`, `QThread.wait()` or `QThread.terminate()` calls exist in production `src/`.
- No duplicate class methods or duplicate same-method Signal→slot connections were found by the static audit.
