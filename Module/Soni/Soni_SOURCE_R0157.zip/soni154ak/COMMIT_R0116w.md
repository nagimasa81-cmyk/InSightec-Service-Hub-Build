# RC7.2-R0116w — Exclusive Progress Window

- Adds a non-cancelable application-modal progress window for source/package loading phases where the current study must not be operated.
- Main Replay load shows stage + percentage from Open/Extract/Discovery through first-Sonication/deferred study preparation, then closes before background summary work.
- Spectrum Dump Analyzer shows the same style progress window during source scan/decode/replay build/cavitation evaluation.
- Existing status-bar/subwindow progress remains as a secondary indicator.
- Background-only work that is safe to interact with does not keep the modal window open.
