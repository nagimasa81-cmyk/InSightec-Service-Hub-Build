# R0116zzp — image-load stall hardening

- RAW size preflight before Treatment MR/Thermal np.fromfile reads.
- Read only the exact expected number of elements after size validation.
- Skip malformed/oversized RAW immediately instead of reading the whole file.
- Remove synchronous set_frame() from Load images ON startup; Replay refresh remains deferred until image caches and thumbnail strips are ready.
- Preserve incremental thumbnail materialization and background cache behavior from R0116zzo.
