# R0148 — Directional Movement Detection Summary

- Replaced the incorrect scalar Movement Detection Summary value with explicit three-axis anatomical displacement.
- Summary format is RL → SI → AP using direction letters, e.g. `R0.1 S0.2 A0.0`.
- Positive/negative direction mapping: RL = R/L, SI = S/I, AP = A/P.
- A scalar `SpotDoseData.motionvalue` is never expanded into three axes.
- Only explicit three-axis evidence associated with `sonicationindex` is published; conflicting duplicate evidence fails closed.
- Removed Movement Detection from the scalar lower-chart metric list.
- Corrected the Summary thermometry background column indices after the Movement Detection column insertion.
