# R0116zd — Authoritative Study Source Binding / Golden Export Regression

## Why this revision exists
R0116v-zc accumulated two independent CPC Spectrum mapping rules. The real
`10-00-09_ANx(1).zip` contains 13 physical CPC Spectrum pairs but only 8
treatment Sonications. The new candidate mapper required equal cardinality and
therefore returned zero treatment bindings, while the legacy replay selector
correctly selected the latest 8 treatment pairs.

## Changes
- One deterministic CPC rule: explicit Sonication identity first, then treatment
  fallback to the latest N physical CPC pairs when extra early setup/calibration
  pairs exist.
- MainWindow summary, RCA, Cavitation Intelligence and CPC replay all route
  through `_resolve_cpc_pair()` / `_build_cpc_replay()`.
- Background preload rejects zero-frame results instead of publishing a false
  "Ready" context.
- Analyzer only accepts a cached preload when the requested Sonication is
  actually ready; otherwise it shows non-modal preload progress and starts the
  requested Sonication in the worker.
- Selecting the already-loaded Export ZIP in Spectrum Analyzer reuses the main
  workspace instead of extracting the ZIP again.
- Manual Spectrum decode now relays real `build_direct()` progress so the UI
  does not appear frozen at 55%.
- Loaded-workspace Spectrum discovery reuses package CPC inventory before any
  recursive recovery scan.
- Build metadata synchronized to R0116zd.

## Golden export contract
A checked-in metadata-only fixture captures the 13 CPC pair names from
`10-00-09_ANx(1).zip` and asserts that Sonication1-8 bind to the final 8 pairs.
The patient data itself is not packaged.
