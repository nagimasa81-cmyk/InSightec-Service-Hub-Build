# R0154ae triple check

- DQA series result is one fixed-XD result, not one value per Sonication.
- X/Y source is DQA-Axial phantom geometry only.
- Z/Tilt source is DQA-Sagittal phantom geometry only.
- Default-centre workstation steering is required to identify fixed natural focus.
- Steered focalRAS values are never averaged as mechanical XD motion.
- Thermometry is independent of mechanical DQA alignment.
- Named non-thermal MR protocols cannot pass temperature classification by value range alone.
- R0154ad umbrella orientation contract retained.
