# R0132

Triple-check hardening after R0131 horizontal-axis range zoom.

- X-axis drag zoom remains single shared implementation in `src/ui/chart_interaction.py`.
- Installation guard prevents duplicate handlers.
- Dynamic FFT result plots now receive the same interaction contract.
- Hidden-axis image/map panels are excluded to prevent unintended image reset/zoom semantics.
- Generated Python bytecode/cache removed from SOURCE.
- Version/build/package identity synchronized to RC7.9-R0132.
