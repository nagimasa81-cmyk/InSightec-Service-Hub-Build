# R0116b — Registration Visibility

- Registration geometry/CtMr transform unchanged.
- Bone overlay changed to higher-contrast lime green.
- Registration overlay opacity increased 0.64 -> 0.82.
- Display-only outer-skull contour dilation increased one -> two pixels.
- Registration QA still uses original skull mask.
