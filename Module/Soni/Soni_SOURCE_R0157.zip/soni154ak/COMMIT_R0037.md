# R0037

Focus: visualize the possible cavitation location range from hydrophone contributions.

Implemented:
- Cavitation Likelihood Service to convert hydrophone contribution patterns into a 2D probable-region map.
- UI panel in Cavitation Events tab for the probable region, dominant hydrophone, contributors, and centroid.
- Automatic updates from selected observed events or the current FFT snapshot.
