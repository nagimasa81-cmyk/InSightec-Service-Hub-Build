# R0034 — Cavitation Control Rule Reconstruction

This revision extends the vendor cavitation reconstruction from energy detection into treatment-control behavior.

## Decoded control model
- `CavitationControlStartingPowerRatio = 0.20`.
- Increase Rule 0: Band0 weighted CH1–CH4, lower limit 0.014, multiplicative +1%.
- Decrease Rules 0–5: thresholds and multiplicative reductions decoded directly from `CavitationSafetyAndControl.ini`.
- Safety Rules 0–4: weighted bands, maximum/critical thresholds, failure-count limits and failure-time windows decoded.
- Cavitation levels 1.0 and 1.5 decoded.
- Dynamic Rules 0–1 decoded from `CavitationDynamicRules_0.ini`: Band2-weighted trigger, 5 failures/50 ms, switch to sub-sonication 1.
- General policy flags including RTDCA stop and SW/HW error policy are exposed without inventing undocumented interaction semantics.

## Runtime validation
`Acquisition_Brain` Set records prove the power-control arithmetic. Across all 15 measurement sessions in the supplied export:
- 18,174 control events reproduced.
- 48 decrease events.
- 18,126 increase events.
- MAE in ExPowerRatio: ~5.66e-06.
- Maximum absolute error: 9.8e-05 (log rounding scale).
- 15/15 sessions PASS the <=5e-4 exact-reproduction criterion.

When multiple decrease rules fire in one cycle, the largest configured decrease fraction is applied; decreases are not summed. Increase Rule 0 multiplies the previous ratio by 1.01 and saturates at 1.0.

Safety-stop and dynamic sub-sonication switching are decoded from INI but are not labelled runtime-validated unless matching events are present in the log.
