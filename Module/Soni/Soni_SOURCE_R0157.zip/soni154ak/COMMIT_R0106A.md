# R0106a — R0105 real-export corrective update on R0106 base

Validated against `10-00-09_ANx(1).zip` and the supplied R0105 screenshots.

- Keeps R0106 fast-load / background Thermal thumbnail behavior.
- Reference selector now immediately displays the selected Ax/Sag/Cor series representative slice; selector text and actual main image can no longer silently disagree.
- Registration therefore evaluates the MR plane actually displayed on screen.
- Sonication Elements is refreshed automatically at the metadata stage for every Sonication.
- Existing export evidence (`ChannelMeasure.ini` + per-Sonication `SkullMeasures`) is consumed without requiring manual Rescan/Open Log.
- Release metadata synchronized.
