# R0116zzg4 — Non-modal long-operation hardening

## Purpose
Prevent any long-running load/analysis progress popup from making the Windows application appear frozen when a worker is slow or stalls.

## Changes
- `BusyProgressDialog` is now always `NonModal`.
- Main study package loading remains QThread-owned and protected by latest-open / generation guards, but no longer application-modally traps the UI.
- Spectrum source/decode progress never restores `ApplicationModal`, including after background preload handoff.
- Existing image, summary, selected-Sonication data, planning/reference I/O and deferred-panel progress remain `BackgroundProgressDialog` / non-modal.
- Added regression tests covering these contracts.

## Audit result
Long-running data families checked: package open/discovery, CPC Spectrum source discovery, FFT/raw decode, Spectrum secondary analysis, image cache/thumbnail build, Sonication summary, selected-Sonication data, planning/reference image I/O, deferred analysis panels, Spectrum preload. Their expensive I/O/compute owners are worker threads or incremental QTimer publishing; long-running progress is non-modal after this change.
