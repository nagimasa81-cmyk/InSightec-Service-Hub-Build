# R0116zq — Actual Power / Irradiation Alignment Fix

- Actual power in CGA Cavitation / Vendor Rules now uses the exported Workstation `spotsonicationdata.xml` PowerGraph.
- Acquisition_Brain `ExPowerRatio` is no longer labelled/drawn as emitted Actual power; it is a controller state and can change during pre-irradiation setup.
- Workstation PowerGraph is placed at `Irradiation start + PowerGraph elapsed time` and anchored with zero power exactly at irradiation start.
- INI-rule reconstructed response remains a diagnostic curve but is displayed only within the irradiation-active interval in the lower Vendor/Control chart.
- Real Export validation (4231): Sonication 1 Workstation irradiation start = 9.051 s; first exported PowerGraph sample = +0.362 s, therefore first actual-power sample = 9.413 s. The prior Acquisition controller ratio began changing around 4.765 s and was the source of the misleading display.
- R0116 regression: 182/182 PASS.
- Full non-PySide6 regression: 488/488 PASS. One known ROI GUI test requires PySide6 and cannot collect in this environment.
