# R0090 — Replay Power/Score Curve Persistence Fix

## Root cause
R0087 correctly renders the chart from the native `spotsonicationdata PowerGraph` timeline (`plot_time_s` / `plot_power_percent`) and aligned Score trace. During replay navigation, `_apply_workstation_replay_behavior()` overwrote those curves with frame-sampled `trend.time_s` / `trend.power_percent` / `trend.score_percent` and progressively masked them by replay-frame time. The two timelines have different origins, so Play/Next/slider operations could reduce the visible curve to NaN/empty points.

## Fix
- Power % / Score always render from the authoritative R0087 `plot_*` arrays when available.
- Replay Play/Next/Previous/slider actions no longer trim or replace the Power/Score history.
- Replay still moves the synchronized vertical cursor.
- Temperature progressive replay behavior is unchanged.
- R0088 Phase fix and R0089 visible multilingual selector are preserved.
