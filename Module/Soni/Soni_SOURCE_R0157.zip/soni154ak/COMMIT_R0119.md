# R0119 — Band0 status/markers attributed per receiver channel

## Problem
`_draw_band_energy` tracked Band0 gap-reconstruction success/rejection and
sub-harmonic evidence with variables shared across every visible receiver
channel (`reconstructed_any`, `rejected_reconstruction`, `rejection_detail`,
`subharmonic_total`). Two concrete problems fell out of this:

1. If RCV0's history validated (reconstruction succeeds) while RCV1's did
   not (rejected), the status line showed *both* messages concatenated with
   no indication of which receiver was which -- and `rejection_detail` only
   ever held the *last* channel to fail, silently dropping every other
   channel's own reason.
2. Sub-harmonic markers were plotted and counted inside the per-band loop.
   Selecting more than one band (e.g. Band0 + Band1) re-plotted and
   re-counted the *same* channel's sub-harmonic markers once per selected
   band, inflating the status count and duplicating on-screen markers.

## Fix
- Replaced the shared flags with per-channel structures:
  `band0_reconstructed_channels`, `band0_rejected_channels` (channel ->
  quantified reason), `subharmonic_by_channel` (channel -> count).
- Added `plotted_subharmonic_channels` so each channel's sub-harmonic
  markers/count are produced at most once regardless of how many bands are
  selected.
- Status line now enumerates receivers by name, e.g.:
  `Band0 history rejected (RCV1: max dev 12.4% over 8 sample(s), RCV3: only
  2 sample(s), need >= 5)` and `▲ f0/2 sub-harmonic evidence: RCV1 x6, RCV4
  x2 -- not a cavitation diagnosis`.

## Tests
- `tests/test_r0119_band0_per_channel_status_attribution.py` (new): checks
  the per-channel dicts exist and are used in the status line, the
  multi-band de-duplication guard is present, and none of the old shared
  flag names remain.
- `tests/test_r0116zzg23_band0_time_alignment.py` and
  `tests/test_r0117_band0_hardening_and_subharmonic_detection.py`: updated
  the two assertions that referenced the old flag names by literal string
  (`rejected_reconstruction=True` / `rejection_detail`) to check the new
  per-channel equivalents; the guarantees they were checking are unchanged.

All R0116zzg23 / R0117 / R0117b / R0118 assertions re-verified passing.
`verify_source.py` re-run against the packaged, re-extracted
`Soni_SOURCE_R0119.zip` -> `VERIFY_SOURCE_OK` (exit 0).
