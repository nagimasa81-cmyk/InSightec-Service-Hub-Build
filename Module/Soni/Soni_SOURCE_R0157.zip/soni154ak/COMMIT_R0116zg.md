# R0116zg — Spectrum No-Data Publish Path Fix

- Reproduced against real `17-00-24_ANx(4).zip` treatment Export.
- Confirmed 15 physical CPC Spectrum RAW+FFT pairs and 8 treatment Sonications.
- Authoritative mapping selects the latest 8 treatment pairs.
- Real decoder validation: all 8 mapped Sonications decode successfully (309 total FFT frames).
- Removed the remaining synchronous mapped-Sonication `build_direct()` call from the GUI thread.
- Mapped Sonication now uses `SpectrumDecodeWorker`, same as standalone SpectrumDumps.
- Successful worker result is cached by Sonication and immediately published to plots.
- Background preload failure now falls back to `load_package()` instead of leaving Analyzer in waiting/No-data state.
- Regression tests for the publish/fallback path added.
