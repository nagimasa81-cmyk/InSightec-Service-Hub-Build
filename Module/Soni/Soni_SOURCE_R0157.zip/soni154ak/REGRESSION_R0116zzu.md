# R0116zzu Regression Report

## Focused image re-entry tests

- 7 new R0116zzu race/lifecycle tests: PASS.
- R0116zzs essential image-loader regressions: PASS after updating the callback expectation to the cycle-scoped form.
- R0116zzt cross-view regressions: PASS.

## Full non-GUI suite

- **620 passed**.
- `test_r0015_circular_roi_measurement.py` remains excluded in this Linux validation environment because PySide6 is not installed; this is an environment limitation, not a newly observed application failure.

## Static/lifecycle assertions

- No `QThread.wait()` in `_cancel_essential_image_worker`.
- Old reader is retained until `thread.finished`.
- Same-cycle reader start is coalesced.
- Different-cycle reader restart is deferred until old QThread exit.
- Sonication change cancels the old essential reader before changing `self.current`.
- Stale OFF/ON callbacks are rejected by load-cycle generation.
- Initial Reference/Planning bulk decode remains disabled.
