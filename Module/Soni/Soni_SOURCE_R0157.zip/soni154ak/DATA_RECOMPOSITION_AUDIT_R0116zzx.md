# R0116zzx Cross-View Data Contract

1. Power / Duration / Energy originate from the per-sonication SonicationSummary export model.
2. Temperature Start / Peak / ΔT originate from the same ReplayService thermometry trend used by Replay.
3. Cavitation status is no longer inferred independently by each screen. Canonical confirmed evidence is the union of observed cavitation-control events and vendor INI Rule Triggers reproduced from the Spectrum dump.
4. Robust-z Candidates are diagnostic only and cannot independently label a Sonication as confirmed cavitation.
5. Cavitation severity combines observed control-response severity and vendor threshold-exceedance severity; it is explicitly an engineering score, not a clinical grade.
6. Probable cavitation region is gated by a confirmed canonical event near the replay cursor.
7. Energy delivered (%) requires measured/actual evidence and never uses planned Energy as its numerator fallback.
8. Summary RCA is recomputed after thermometry values arrive, preventing stale lightweight-row scores.
