# R0028

- Rebased on R0026 to restore previously working replay/image behavior.
- Fixed R0027 tuple-order regression in Planning image entries that could prevent the initial replay render after thumbnails were built.
- Fusion is additive: original Planning CT, Planning MR, Anatomy MR and Thermal entries are unchanged.
- Spectrum Dump Analyzer now keeps Sonication sources and adds loaded-Export SpectrumDumps in the same selector.
- Added cavitation visualization and orientation alignment labels.
- Direction-cosine orientation is preferred over ambiguous free text.
