# R0069 — Post-Sonication Replay Gating

- Power/Score curves now terminate when measured Acquisition acoustic-control telemetry ends; values are no longer forward-filled through post-sonication MR.
- Main Acoustic Spectrum no longer stretches the last sonication spectrum frame across later MR acquisition frames.
- Post-sonication MR is explicitly marked as cavitation-evaluation OFF. MR-gradient noise is excluded from cavitation scoring and RCV/Band evidence.
- Historical acoustic/cavitation data remains available for earlier replay times.
