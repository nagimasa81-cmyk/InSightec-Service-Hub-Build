# R0116s — Triple Check Runtime Connections

This release is a connection/runtime audit on top of R0116r.

## Fixed runtime failures

1. **Why/Event-list runtime NameError**
   - `_why_text_for_event()` referenced non-existent `HydrophoneWindow` instead of `EightHydrophoneWindow`.
   - This could allow Control Timeline curves/markers to render, then fail while populating Event list tooltips or opening Why.
   - Fixed the class reference.

2. **Latest-open source switch thread lifecycle**
   - Package-load QThread/worker references were never cleared after `thread.finished`.
   - A later Open ZIP/drop could inspect a deleted Qt object or remain queued at the wrong time.
   - Added `_package_load_thread_finished()` to clear references first, then run the newest queued source.
   - Removed the race that started the queued source before the previous QThread had actually finished.

3. **Replay-scoped stale state**
   - Added `_reset_replay_analysis_state()` and call it before switching SpectrumDump candidates or Sonications.
   - Clears old control timeline, event tables, probable-location state, Why highlight, likelihood, and band heatmap before adopting the next replay.

4. **Red event cursor vs white replay cursor**
   - Decoupled selected-event state from Probable Location pinning.
   - Explicit event selection pins Probable Location to that event.
   - Normal replay movement releases only the location pin; it does not erase the selected-event red cursor/highlight.
   - This prevents red and white cursors from being forced into the same state while keeping Probable Location dynamic during replay.

## Preserved behavior

- Control Timeline `Why popup` remains default OFF.
- When ON, marker click and Event-list row click open the exact selected-event Why.
- Increase events remain default hidden.
- Disabled RCV handling remains based on `Calibration.ini IsEnabled=0`.
