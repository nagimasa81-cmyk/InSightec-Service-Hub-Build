# R0111a — Build smoke fix

Build_Diagnostics_Soni_186 showed that Nuitka compilation/linking completed successfully,
but the generated EXE exited during smoke test:

`NameError: name 'XDWindow' is not defined`

R0111 had separated the old embedded XD dialog into `SkullElementWindow`, but one constructor
in `_build_replay_tab()` still referenced the obsolete `XDWindow` name.

Fix:
- `self.xd_window = XDWindow(self)`
+ `self.xd_window = SkullElementWindow(self)`

No functional rollback of the R0111 3-D Umbrella, Summary, Increase, thumbnail, or registration fixes.
