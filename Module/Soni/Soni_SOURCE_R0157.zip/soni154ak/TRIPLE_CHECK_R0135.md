# R0135 Triple Check

## Check 1 — source/data-chain audit
PASS after fixes.

Confirmed defects found during audit:
1. Slotted CPC replay lacked `sonication_index`, causing authoritative preload failure.
2. Acquisition fallback counted only top-level Sonication folders; wrapped exports bound Power/Score to DQA/calibration sessions.
3. Package-level control fallback could lose exact candidate session ownership when decode failed.
4. Package-root control timeline could not find a nested `CPCFiles/Acquisition_Brain_*.txt`.
5. Exact CPC source-mapping provenance was not copied onto the replay object.

All five are corrected in R0135.

## Check 2 — real treatment data
Dataset: `17-00-24_ANx(5).zip`.

- 8/8 Sonications have Exact CPC candidate mappings to Acquisition sessions 8–15.
- 8/8 CPC replays decode successfully.
- PowerGraph / Acquisition fallback selects segments 8–15 respectively.
- Sonication 5 reproduces CAVITATION HALT ×1 / 2 physical control responses.
- Sonication 6 reproduces CAVITATION HALT ×1 / 25 physical control responses.
- Sessions 1–4 and 7–8 contain no treatment cavitation responses in the authoritative Acquisition sessions.

## Check 3 — regression/static validation
- Focused preload/publish/summary/power/cavitation suite: 102 PASS + 1 pre-existing static string expectation failure; the same failure is present in R0134.
- Full non-GUI suite after adding R0135 tests: 860 PASS / 8 FAIL / 1 SKIP.
- The 8 failures are pre-existing legacy/static expectations (old RC7.2 release strings or superseded static implementation-string expectations), not new R0135 failures.
- PySide6-only circular ROI test cannot be collected in this Linux validation environment because PySide6 is not installed.
- Python compile and `verify_source.py` are required before packaging.
