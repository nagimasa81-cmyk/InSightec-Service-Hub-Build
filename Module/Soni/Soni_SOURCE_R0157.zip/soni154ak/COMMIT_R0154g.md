# R0154g

## Brain 220 / Brain 650 acoustic-family support

- Added evidence-first acoustic system classification. Actual SonicationSummary frequency is primary, followed by TransducerInfo.transtype and serial-specific Xd_####.ini evidence.
- Brain 220 family supports the observed 210-260 kHz operating band; Brain 650 family supports the observed 620-700 kHz band. The gap remains invalid to prevent unrelated frequencies being accepted.
- Package main frequency now follows the median actual SonicationSummary frequency when available.
- Export Status and diagnostics expose the acoustic family, actual frequency, transducer type, evidence and conflicts.
- Spectrum presentation honors Acquisition.ini f1ForGraph/f2ForGraph; low-frequency fallback is family-aware.
- Verified against real DQA exports: Tx41/230 kHz/serial XD 6314 and Tx42/670 kHz/serial XD 7491.
- DQA focus-alignment behavior from R0154f is retained for Brain220 DQA exports.

## DQA / no-CPC / zero-amplitude hardening
- DQA focus alignment no longer assumes S1/S2/S3 thermometry. It resolves dedicated `DQA-Axial` / `DQA-Sagittal` reference series from `MriImageParams.xml`, reconstructs phantom circle center and lower-line RAS, and reports each Sonication focal RAS offset independently.
- DQA exports with no CPC Spectrum files bypass authoritative CPC binding and use SpectrumMsg evidence directly, preventing the 74% loading stall path.
- Element zero-amplitude visual contract: explained zero = gray tile/element; unexplained zero = black tile/element. Warning/filter/details remain independent from DEFECT classification.
