# R0154ab — Spectrum eager materialization / Brain220 composite preload

## Field regression addressed
On the supplied Brain220 run, Spectrum/Spectrogram/Band Energy were not fully materialized after ZIP import. Opening Spectrogram was the event that started the missing SpectrumMsg/composite decode, so data were hidden/incomplete until the Analyzer tab was visited.

## Root cause
R0154aa had two different ownership moments:
- `SpectrumPreloadWorker` preloaded the authoritative physical CPC replay.
- Brain220 `SpectrumMsg` was attached as `spectral_replay` only inside the Analyzer decode path.

Therefore the Analyzer window/tab was still a data-loading trigger even though the UI claimed background preload ownership. Secondary products were also computed only after replay adoption inside the Analyzer.

## Fix
1. `SpectrumEvidenceRepository.replay()` now creates the Brain220/230 composite during study preload: physical CPC remains 8CH/control authority and exact Sonication-owned SpectrumMsg is attached as the spectral sidecar. SpectrumMsg candidates are consumed through `primary_path` (the importer stores these `.dmp` files in `raw_path`), fixing the hidden `fft_path is None` preload miss. SpectrumMsg-only exports are also materialized eagerly with explicit no-physical-CPC provenance.
2. `SpectrumEvidenceRepository.secondary_products()` is composite-aware. Spectrogram uses the SpectrumMsg sidecar, physical vendor Band Energy remains authoritative when embedded values exist, and aggregate fallback is never duplicated into fake 8 receiver channels.
3. `SpectrumPreloadWorker` now materializes every Sonication, not just the currently selected one, and precomputes the default Spectrogram/Band Energy/cavitation payload for each successful replay.
4. `EightHydrophoneWindow.load_sonication()` does not start a Brain220 SpectrumMsg decode when the repository already owns a complete composite replay. Opening Spectrogram/Band Energy is now a cached publish operation, not a file-read/decode trigger.
5. Per-Sonication preload failures are retained explicitly in `preload_errors`; the selected Sonication still fails closed rather than presenting partial evidence as complete.

## Invariant
A loaded Export must not require opening Spectrum Dump Analyzer, Spectrogram, Band Energy, or moving a cursor to cause acoustic evidence to be read. Those UI actions may only publish already-owned data or explicitly report unavailable evidence.
