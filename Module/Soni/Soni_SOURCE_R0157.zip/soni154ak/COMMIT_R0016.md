# Commit R0016 — Responsive Replay Information Panel

- Rebuilt the left replay information panel for laptop and High-DPI displays.
- Added a vertical scroll area so ROI, cursor, source and sonication information remain readable.
- Replaced the compressed Sonication form with a two-column responsive grid.
- Reformatted circular ROI results into Source, Diameter, Pixels, Mean and Maximum rows.
- Reformatted cursor values into Temperature, X and Y rows.
- Increased Show ROI / Copy / Clear and Info / MR / Scan / XD button heights.
- Increased the default left-panel width while preserving splitter resizing.
- Preserved circular ROI measurement, replay, chart and metadata behavior.
