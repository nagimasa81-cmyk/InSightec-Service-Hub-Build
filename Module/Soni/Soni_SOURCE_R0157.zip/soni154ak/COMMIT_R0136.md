# R0136 — Single-owner evidence pipeline hardening

- Loaded Export now has one authoritative CPC source universe owned by `SpectrumEvidenceRepository`.
- A partial `package.cpc_spectrum_files` inventory is accepted only when it maps every discovered Sonication; otherwise one worker-owned recursive scan expands and de-duplicates the candidate universe.
- `SpectrumPreloadWorker` receives the complete repository context, not `list(mapping.values())` (which previously hid unmapped candidates and produced `Mapped NO / Decoded 0`).
- Main preload failure no longer falls back to Analyzer-local package discovery. This removes the second, conflicting mapping universe that could overwrite Main/Summary/CI state.
- Analyzer `load_package()` routes a loaded Main-window Export back to Main's preload owner instead of independently rediscovering it.
- Selected Replay Power/Score now requests the same authoritative Acquisition session used by CPC/control evidence.
- New regression tests lock the single-owner contract and partial-inventory deep-discovery fallback.
