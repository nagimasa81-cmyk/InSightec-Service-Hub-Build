# COMMIT R0085 — RCV Curve Legend Toggles

## Changes
- Added RCV0–RCV7 curve entries to Vendor chart Legend
- Each RCV curve has an independent checkbox
- Legend colors exactly match plotted RCV curves
- Selected receiver mode honors the same RCV checkbox
- Visibility changes preserve zoom/pan state
- Expanded Legend area to fit RCV and exact FFT marker controls
