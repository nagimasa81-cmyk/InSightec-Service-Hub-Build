# R0137 — GUI Evidence Handoff Resilience

- SelectedReplayDataWorker now carries the repository-owned CPC/Spectrum context together with Power/temperature data.
- CPC evidence ingestion is no longer gated by the Main chart CPC ON/OFF display toggle.
- Added one `_adopt_authoritative_spectrum_context()` handoff used by both preload and selected-data workers.
- Cavitation Intelligence can recover directly from the repository cache even when the UI preload context missed a callback.
- Transient `Control evidence unavailable` Summary results are no longer cached permanently; authoritative handoff invalidates/retries pending/unavailable Summary evidence.
- Existing Analyzer-local Loaded Export fallback remains disabled; no ancestor source-discovery path is reintroduced.
