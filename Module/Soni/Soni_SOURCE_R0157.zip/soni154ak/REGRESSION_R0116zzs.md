# R0116zzs Regression / Stall Audit

## Primary symptom audited
Observed UI: `Load images` appears frozen around `treatment_mr 11/11` / total progress near the middle of the essential workload.

## Root cause found in R0116zzr
R0116zzr had moved Treatment MR and Thermal numeric RAW decoding to background QThreads, but still launched the two roles independently. Each worker performed a monolithic `np.fromfile()` per RAW and emitted progress only after that call returned. Therefore a blocked/very slow Thermal RAW read could leave the progress dialog showing the last Treatment-MR message even though Treatment MR itself was already complete. Parallel readers also made the displayed role/numerator nondeterministic.

## R0116zzs repair
- One deterministic `EssentialImageLoadWorker` owns initial current-Sonication image loading.
- Ordered decode: Treatment MR -> Thermal.
- Reference/Planning are excluded from the initial workload.
- Per-file trace: start -> stat/size preflight -> RAW read -> ready/SKIP.
- Trace output: `<workspace>/image_load_trace.log`.
- Exact RAW filename is shown in progress.
- Per-file 30 s circuit breaker prevents one blocked RAW from stranding the entire series.
- Numeric cache is filled off GUI thread; QPixmap/QIcon creation is deferred to incremental GUI batches.
- Initial hidden Planning strip is not materialized.

## Ancestor / duplicate / overwrite audit
- Duplicate class-method AST scan: PASS, zero duplicate methods.
- `Load images` toggle connection count: 1.
- Planning source combo connection count: 1.
- Anatomy source combo connection count: 1.
- Thermal source combo connection count: 1.
- Initial essential-worker scheduler count: 1.
- Legacy initial Treatment-MR worker scheduler count: 0.
- Legacy initial Thermal worker scheduler count: 0.
- Release metadata stale R0116zzr references (excluding historical commit notes): 0.

## Tests
- New R0116zzs focused image-loader tests: PASS.
- R0116zzr lazy-reference/non-blocking-summary tests: PASS.
- Rich i18n regression tests: PASS.
- Full non-GUI suite available in this container: **603 passed**.
- `tests/test_r0015_circular_roi_measurement.py` could not be collected in this Linux container because PySide6 is not installed. This is an environment limitation; Python source compile and static regression suite pass.

## Remaining Windows validation target
On the reported real dataset, confirm that progress changes from Treatment MR to an explicit Thermal RAW filename and inspect `image_load_trace.log`. If a RAW is malformed/blocked it must appear as `SKIP` and loading must continue to the next frame rather than remaining Not Responding.
