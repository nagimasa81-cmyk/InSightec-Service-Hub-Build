# R0022 — FUS Export Core / Best-effort Partial Replay

- Adds semantic FUS Export inspection shared model.
- COMPLETE/PARTIAL/INCOMPLETE is capability-based, not a load gate.
- PARTIAL/INCOMPLETE datasets load every available replay stream.
- Sonication Information shows missing full-replay and optional assets.
- Detects 3D / 2D multi-plane / Hybrid planning workflows.
- Detects TMAP vs TMAP-ME (Multi Echo).
- Adds size-validated SpectrumMsg structural parser.
