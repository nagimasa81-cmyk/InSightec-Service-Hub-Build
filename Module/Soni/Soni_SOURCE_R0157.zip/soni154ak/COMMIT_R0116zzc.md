# R0116zzc — Screen-fit / persistent Spectrogram help / ancestry hardening

## UI
- Spectrum Dump Analyzer normal view fits inside the available screen before enabling page scrolling.
- Main Spectrum Analyzer horizontal scrollbar remains disabled.
- Analysis Details is the only normal Spectrum path allowed to enable page vertical scrolling.
- Cavitation event tables retain vertical scrolling, disable horizontal scrolling, and optimize columns to the viewport.
- Replay/Cavitation Intelligence optional analysis sections use horizontal checkboxes instead of legacy arrow collapsibles.
- Cavitation Intelligence default view compresses linked plots/tables so lower controls remain reachable without a page vertical scrollbar; optional expanded material may scroll.

## Spectrogram
- X axis is explicitly fitted to the actual decoded spectrogram time interval.
- Hover explanation remains visible while the pointer stays on the plot and is dismissed on Leave/Hide.
- Hover explanation is localized through the seven-language UI text map.

## Ancestry / overwrite audit
- Removed unused legacy `_make_ci_collapsible_section` triangle-header factory.
- Removed legacy Vendor 280/245 px minimum-height overwrite.
- Reconfirmed no last-N CPC mapping fallback.
- Reconfirmed no duplicate Python method definitions in main_window, hydrophone_window, or i18n.
- Exact repeated QThread connection source lines were reviewed and belong to separate worker/thread instances, not duplicate connections on one instance.

## Validation
- R0116 tests: 238/238 PASS.
- Full suite excluding the known PySide6-dependent ROI GUI test: 544/544 PASS.
