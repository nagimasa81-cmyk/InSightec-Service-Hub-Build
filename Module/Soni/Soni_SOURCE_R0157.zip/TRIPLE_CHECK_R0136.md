# R0136 Triple Check — Single-owner evidence / blank-tab / Power stability

## Root causes confirmed
1. `SpectrumPreloadWorker` exported only `list(mapping.values())`, not the complete discovered candidate universe. Partial mapping therefore made Analyzer show a reduced `Discovered N` set and `Mapped NO` for an unmapped target.
2. `SpectrumEvidenceRepository.candidate_mapping()` trusted a partial `package.cpc_spectrum_files` inventory whenever any CPC candidate existed. It did not escalate to a recursive study scan when Sonication coverage was incomplete.
3. Main preload failure fell back to `EightHydrophoneWindow.load_package()`, creating a second Analyzer-local discovery/mapping universe. Main/Summary/CI and Analyzer could therefore disagree about the same Sonication.
4. Power/Score background decode selected its Acquisition session independently from CPC/control evidence.
5. Additional audit finding: `_apply_acoustic_trend()` mutated `trend.plot_time_s` from canonical MR time to irradiation-relative time. Every rematerialization could subtract the Sonication start again, moving or erasing Power curves.

## R0136 hardening
- One loaded Export -> one `SpectrumEvidenceRepository` source universe / mapping owner.
- Fast package inventory is used only when it covers every Sonication; otherwise recursive discovery expands + de-duplicates candidates.
- `authoritative_context()` supplies complete candidates, mapping, decoded replay and authoritative Acquisition session in one handoff.
- Loaded-Export Analyzer package load routes back to Main preload owner; preload failure never launches Analyzer-local discovery.
- Selected Power/Score requests `repository.authoritative_session()`.
- Acoustic trend timestamps remain canonical and immutable; irradiation-relative conversion is view-local only.

## Real-data validation — 17-00-24_ANx
- Sonications discovered: 8
- Complete CPC universe: 15 physical CPC candidates
- Mapping: 8/8 Exact
- Acquisition sessions (1-based): S1->8, S2->9, S3->10, S4->11, S5->12, S6->13, S7->14, S8->15
- S5: 11 decoded FFT frames; canonical result `CAVITATION HALT ×1 · control responses ×2`
- S6: 45 decoded FFT frames; canonical result `CAVITATION HALT ×1 · control responses ×25`
- Power relative end vs actual duration (s):
  - S1 11.494 / 11.573
  - S2 11.410 / 11.550
  - S3 11.592 / 11.652
  - S4 12.721 / 12.721
  - S5 1.990 / 1.990
  - S6 11.253 / 11.373
  - S7 19.054 / 19.054
  - S8 27.508 / 27.646

## Regression / integrity
- Full non-PySide6 suite: 875 passed, 1 skipped (`pyzipper` unavailable).
- PySide6 circular-ROI test not collected in this Linux environment because PySide6 is unavailable.
- Focused R0126-R0136 + async/CPC/control tests pass.
- AST duplicate-method audit: 0 duplicate methods in Main, Hydrophone Analyzer, Spectrum repository, Acoustic Control service.
- `verify_source.py`: PASS.
- Python compilation: PASS.
