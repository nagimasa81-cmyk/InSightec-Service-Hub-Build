# R0046

Focus: responsive loading, visible progress, reduced popup obstruction, and Fusion display correction.

Key behavior:
- package import/extraction/discovery is asynchronous; current UI stays usable;
- sonication data loads in visible stages and selection changes invalidate stale remaining stages;
- file/decode failures use inline status instead of modal dialogs;
- Fusion uses MR as the base image and CT bone-edge overlay chosen by structural similarity.
