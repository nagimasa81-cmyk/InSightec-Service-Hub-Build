# Sonication Replay Engine RC1 Commit0003

## Xd INI main frequency

The application searches for `Xd_*.ini` or `Xd*.ini`.

The main sonication frequency is read from the final non-empty data line.

Examples supported:

```text
650000
650000 Hz
650 kHz
0.650 MHz
MainFrequency=650000
```

The value is normalized internally to Hz and displayed in kHz.

## Spectrum integration

SpectrumMsg is now decoded through the shared SpectrumMsg Analyzer adapter.

The INI main frequency anchors candidate selection and adds markers for:

- Main
- Subharmonic
- 2nd Harmonic
- 3rd Harmonic

Spectrum replay uses normalized frame mapping until exact timestamps are
available.
