# Changelog

## RC1 Commit0003

- Added automatic discovery of `Xd_*.ini` / `Xd*.ini` files.
- Added main-frequency extraction from the final non-empty line of the INI file.
- Added unit inference for Hz, kHz and MHz values.
- Added metadata confidence and source-path display.
- Added shared spectrum decoder core adapted from SpectrumMsg Analyzer.
- Connected `SpectrumMsgAnalyzerAdapter` to the Replay Engine.
- Added automatic candidate search using the INI main frequency as the anchor.
- Added kHz spectrum display in Replay.
- Added Main, Subharmonic, 2nd Harmonic and 3rd Harmonic markers.
- Added normalized replay synchronization between MR, temperature and spectrum frames.
- Added provider caching so switching replay frames does not repeatedly decode files.
- Added verification for Xd INI parsing and anchored spectrum decoding.

## RC1 Commit0002

- Added shared core and replay-oriented layout.
