from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from src.domain.models import SonicationModel
from src.services.raw_service import RawService, RawDecodeError

@dataclass(slots=True)
class ReplayFrameData:
    replay_index:int
    magnitude_index:int|None
    temperature_index:int|None
    magnitude:np.ndarray|None
    temperature:np.ndarray|None
    hotspot_x:int|None=None
    hotspot_y:int|None=None
    maximum_temperature:float|None=None
    mean_temperature:float|None=None

class ReplayService:
    def __init__(self): self.raw=RawService()
    def frame(self,son:SonicationModel,index:int)->ReplayFrameData:
        count=son.replay_frame_count; index=max(0,min(index,count-1))
        mag=temp=None; mi=ti=None
        if son.magnitude_frames:
            mi=self.raw.normalize_index(index,count,len(son.magnitude_frames)); mag=self.raw.read_magnitude(son.magnitude_frames[mi].path)
        if son.temperature_frames:
            ti=self.raw.normalize_index(index,count,len(son.temperature_frames)); temp=self.raw.read_temperature(son.temperature_frames[ti].path)
        hx=hy=None; mx=mean=None
        if temp is not None and np.isfinite(temp).any():
            safe=np.nan_to_num(temp,nan=-np.inf); flat=int(np.argmax(safe)); hy,hx=np.unravel_index(flat,temp.shape)
            mx=float(np.nanmax(temp)); mean=float(np.nanmean(temp))
        return ReplayFrameData(index,mi,ti,mag,temp,hx,hy,mx,mean)
