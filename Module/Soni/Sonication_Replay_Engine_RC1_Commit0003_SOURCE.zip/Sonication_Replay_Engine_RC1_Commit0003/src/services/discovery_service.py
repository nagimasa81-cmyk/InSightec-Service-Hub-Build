from __future__ import annotations

import re
from pathlib import Path

from src.common.constants import MAGNITUDE_PREFIX, TEMPERATURE_PREFIX
from src.domain.models import RawFrame, ReplayPackage, SonicationModel
from src.services.xd_ini_service import XdIniService


SON_RE = re.compile(r"^sonication\s*[_-]?\s*(\d+)$", re.I)
RAW_RE = re.compile(r"^(\d+)-.*-(\d+)\.raw$", re.I)


def natural_key(text):
    return [
        int(x) if x.isdigit() else x.lower()
        for x in re.split(r"(\d+)", text)
    ]


class DiscoveryService:
    def __init__(self) -> None:
        self.xd_ini = XdIniService()

    def discover(self, source: Path, workspace: Path) -> ReplayPackage:
        dirs = []
        for path in workspace.rglob("*"):
            if path.is_dir() and SON_RE.match(path.name):
                dirs.append(path)

        if SON_RE.match(workspace.name):
            dirs.append(workspace)

        if (
            not dirs
            and any(
                path.is_file()
                and (
                    "spectrummsg" in path.name.lower()
                    or path.suffix.lower() == ".raw"
                )
                for path in workspace.iterdir()
            )
        ):
            dirs = [workspace]

        unique = {path.resolve(): path for path in dirs}
        dirs = sorted(
            unique.values(),
            key=lambda path: natural_key(path.name),
        )
        models = [
            self._build(path, index + 1)
            for index, path in enumerate(dirs)
        ]

        frequency = self.xd_ini.read_main_frequency(workspace)

        return ReplayPackage(
            source=source,
            workspace=workspace,
            sonications=models,
            main_frequency_hz=frequency.frequency_hz,
            main_frequency_source=frequency.source_path,
            main_frequency_raw_line=frequency.raw_line,
            main_frequency_confidence=frequency.confidence,
            main_frequency_interpretation=frequency.unit_interpretation,
        )

    def _build(
        self,
        folder: Path,
        fallback: int,
    ) -> SonicationModel:
        match = SON_RE.match(folder.name)
        name = (
            f"Sonication{int(match.group(1))}"
            if match
            else f"Sonication{fallback}"
        )

        model = SonicationModel(
            name=name,
            folder=folder,
        )

        for path in folder.rglob("*"):
            if not path.is_file():
                continue

            low = path.name.lower()
            raw_match = RAW_RE.match(path.name)

            if raw_match:
                frame = RawFrame(
                    path=path,
                    index=int(raw_match.group(2)),
                    prefix=raw_match.group(1),
                )
                if frame.prefix == TEMPERATURE_PREFIX:
                    model.temperature_frames.append(frame)
                elif frame.prefix == MAGNITUDE_PREFIX:
                    model.magnitude_frames.append(frame)
                else:
                    model.other_files.append(path)
            elif (
                "spectrummsg" in low
                and path.suffix.lower() == ".dmp"
            ):
                model.spectrum_files.append(path)
            elif path.suffix.lower() == ".act":
                model.act_files.append(path)
            else:
                model.other_files.append(path)

        model.temperature_frames.sort(key=lambda frame: frame.index)
        model.magnitude_frames.sort(key=lambda frame: frame.index)
        model.spectrum_files.sort(
            key=lambda path: natural_key(path.name)
        )
        model.act_files.sort(
            key=lambda path: natural_key(path.name)
        )
        return model
