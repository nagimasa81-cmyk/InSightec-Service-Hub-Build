from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import QByteArray, QSettings, Qt, QTimer
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QFileDialog,
    QGroupBox,
    QHeaderView,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSlider,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from src.common.constants import APP_NAME, APP_VERSION, ORGANIZATION
from src.domain.models import SonicationModel
from src.integration.spectrum_provider import SpectrumMsgAnalyzerAdapter
from src.services.discovery_service import DiscoveryService
from src.services.import_service import ImportService
from src.services.replay_service import ReplayService
from src.ui.image_panel import ImagePanel, OverlayPanel

LOG = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} - {APP_VERSION}")
        self.resize(1700, 1000)
        self.setAcceptDrops(True)

        self.settings = QSettings(ORGANIZATION, APP_NAME)
        self.importer = ImportService()
        self.discovery = DiscoveryService()
        self.replay = ReplayService()

        self.package = None
        self.current: SonicationModel | None = None
        self.frame_index = 0
        self.temperature_trend: list[float] = []
        self.spectrum_provider = SpectrumMsgAnalyzerAdapter()
        self.spectrum_frames = []

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.next_frame)

        self._build_actions()
        self._build_ui()
        self._restore()

    def _build_actions(self):
        menu = self.menuBar().addMenu("&File")

        open_zip = QAction("Open ZIP...", self)
        open_zip.triggered.connect(self.open_zip)
        menu.addAction(open_zip)

        open_folder = QAction("Open Folder...", self)
        open_folder.triggered.connect(self.open_folder)
        menu.addAction(open_folder)

        menu.addSeparator()
        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        menu.addAction(exit_action)

        toolbar = self.addToolBar("Main")
        toolbar.setObjectName("MainToolbar")
        toolbar.setMovable(False)
        toolbar.addAction(open_zip)
        toolbar.addAction(open_folder)

    def _build_ui(self):
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Sonication / Data", "Count"])
        self.tree.itemSelectionChanged.connect(self.select_sonication)

        left = QGroupBox("Sonications")
        left_layout = QVBoxLayout(left)
        left_layout.addWidget(self.tree)

        self.overlay = OverlayPanel()
        self.magnitude = ImagePanel("Magnitude")
        self.temperature = ImagePanel("Temperature")

        self.spectrum_plot = pg.PlotWidget(title="Spectrum")
        self.spectrum_plot.setLabel("left", "Amplitude")
        self.spectrum_plot.setLabel("bottom", "Frequency", units="kHz")
        self.spectrum_plot.showGrid(x=True, y=True, alpha=0.25)
        self.spectrum_placeholder = pg.TextItem(
            "SpectrumMsg Analyzer adapter not connected",
            anchor=(0.5, 0.5),
        )
        self.spectrum_plot.addItem(self.spectrum_placeholder)
        self.spectrum_placeholder.setPos(0.5, 0.5)

        right_split = QSplitter(Qt.Orientation.Vertical)
        right_split.addWidget(self.magnitude)
        right_split.addWidget(self.temperature)
        right_split.addWidget(self.spectrum_plot)
        right_split.setSizes([300, 300, 260])

        view_split = QSplitter(Qt.Orientation.Horizontal)
        view_split.addWidget(self.overlay)
        view_split.addWidget(right_split)
        view_split.setSizes([1100, 520])

        self.timeline = QSlider(Qt.Orientation.Horizontal)
        self.timeline.valueChanged.connect(self.slider_changed)

        first = QPushButton("|<")
        previous = QPushButton("<")
        self.play = QPushButton("Play")
        next_button = QPushButton(">")
        last = QPushButton(">|")

        first.clicked.connect(lambda: self.set_frame(0))
        previous.clicked.connect(self.previous_frame)
        self.play.clicked.connect(self.toggle_play)
        next_button.clicked.connect(self.next_frame)
        last.clicked.connect(
            lambda: self.set_frame(
                max(0, self.current.replay_frame_count - 1)
                if self.current
                else 0
            )
        )

        self.speed = QSpinBox()
        self.speed.setRange(1, 20)
        self.speed.setValue(5)
        self.speed.setSuffix(" fps")
        self.speed.valueChanged.connect(self.speed_changed)

        self.opacity = QSlider(Qt.Orientation.Horizontal)
        self.opacity.setRange(0, 100)
        self.opacity.setValue(55)
        self.opacity.setMaximumWidth(180)
        self.opacity.valueChanged.connect(
            lambda _value: self.set_frame(self.frame_index)
        )

        self.frame_label = QLabel("Frame -/-")
        controls = QHBoxLayout()
        for widget in (
            first,
            previous,
            self.play,
            next_button,
            last,
            self.frame_label,
            QLabel("Speed"),
            self.speed,
            QLabel("Overlay opacity"),
            self.opacity,
        ):
            controls.addWidget(widget)

        timeline_box = QGroupBox("Replay Timeline")
        timeline_layout = QVBoxLayout(timeline_box)
        timeline_layout.addLayout(controls)
        timeline_layout.addWidget(self.timeline)

        self.temperature_plot = pg.PlotWidget(title="Maximum Temperature Trend")
        self.temperature_plot.setLabel("left", "Temperature", units="°C")
        self.temperature_plot.setLabel("bottom", "Replay Frame")
        self.temperature_plot.showGrid(x=True, y=True, alpha=0.25)
        self.temperature_curve = self.temperature_plot.plot()
        self.temperature_cursor = pg.InfiniteLine(
            angle=90,
            movable=False,
        )
        self.temperature_plot.addItem(self.temperature_cursor)

        self.metrics = QTableWidget(0, 2)
        self.metrics.setHorizontalHeaderLabels(["Metric", "Value"])
        self.metrics.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.metrics.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)

        lower_split = QSplitter(Qt.Orientation.Horizontal)
        lower_split.addWidget(self.temperature_plot)
        lower_split.addWidget(self.metrics)
        lower_split.setSizes([1000, 600])

        center = QWidget()
        center_layout = QVBoxLayout(center)
        center_layout.addWidget(timeline_box)
        center_layout.addWidget(view_split, 1)
        center_layout.addWidget(lower_split)

        self.main_split = QSplitter(Qt.Orientation.Horizontal)
        self.main_split.addWidget(left)
        self.main_split.addWidget(center)
        self.main_split.setSizes([300, 1400])

        self.setCentralWidget(self.main_split)
        self.statusBar().showMessage("Ready")

    def open_zip(self):
        filename, _ = QFileDialog.getOpenFileName(
            self,
            "Open treatment or Sonication ZIP",
            "",
            "ZIP files (*.zip)",
        )
        if filename:
            self.load(Path(filename))

    def open_folder(self):
        folder = QFileDialog.getExistingDirectory(
            self,
            "Open treatment or Sonication folder",
        )
        if folder:
            self.load(Path(folder))

    def load(self, source: Path):
        try:
            workspace = self.importer.open(source)
            package = self.discovery.discover(source, workspace)
        except Exception as exc:
            LOG.exception("Import failed")
            QMessageBox.critical(self, APP_NAME, str(exc))
            return

        self.package = package
        self.spectrum_provider = SpectrumMsgAnalyzerAdapter(
            package.main_frequency_hz
        )
        self.tree.clear()

        if not package.sonications:
            QMessageBox.information(
                self,
                APP_NAME,
                "No Sonication folder or compatible Sonication files were found.",
            )
            return

        if package.main_frequency_hz is not None:
            frequency_item = QTreeWidgetItem(
                [
                    "Main Frequency",
                    f"{package.main_frequency_hz / 1000.0:.1f} kHz",
                ]
            )
            frequency_item.setToolTip(
                0,
                (
                    f"Source: {package.main_frequency_source}\n"
                    f"Last line: {package.main_frequency_raw_line}\n"
                    f"Interpretation: {package.main_frequency_interpretation}\n"
                    f"Confidence: {package.main_frequency_confidence:.1f}%"
                ),
            )
            self.tree.addTopLevelItem(frequency_item)

        for sonication in package.sonications:
            item = QTreeWidgetItem(
                [
                    sonication.name,
                    f"{sonication.replay_frame_count} replay frames",
                ]
            )
            item.setData(
                0,
                Qt.ItemDataRole.UserRole,
                sonication.name,
            )
            self.tree.addTopLevelItem(item)

            for name, count in (
                ("Temperature RAW", len(sonication.temperature_frames)),
                ("Magnitude RAW", len(sonication.magnitude_frames)),
                ("SpectrumMsg", len(sonication.spectrum_files)),
                ("ACT", len(sonication.act_files)),
                ("Other", len(sonication.other_files)),
            ):
                item.addChild(QTreeWidgetItem([name, str(count)]))
            item.setExpanded(True)

        self.tree.setCurrentItem(self.tree.topLevelItem(0))
        self.statusBar().showMessage(
            f"Loaded {len(package.sonications)} sonication(s)"
        )

    def select_sonication(self):
        items = self.tree.selectedItems()
        if not items or items[0].parent() is not None:
            return

        name = items[0].data(
            0,
            Qt.ItemDataRole.UserRole,
        )
        self.current = next(
            (
                sonication
                for sonication in self.package.sonications
                if sonication.name == name
            ),
            None,
        )
        self.spectrum_frames = self.spectrum_provider.load(
            self.current.spectrum_files
        )
        self._build_temperature_trend()
        self.set_frame(0)

    def _build_temperature_trend(self):
        self.temperature_trend = []
        if not self.current:
            return

        for index in range(self.current.replay_frame_count):
            try:
                frame = self.replay.frame(self.current, index)
                value = (
                    frame.maximum_temperature
                    if frame.maximum_temperature is not None
                    else np.nan
                )
            except Exception:
                value = np.nan
            self.temperature_trend.append(value)

        self.temperature_curve.setData(
            np.arange(len(self.temperature_trend)),
            np.asarray(self.temperature_trend, dtype=float),
        )

    def set_frame(self, index: int):
        if not self.current:
            return

        try:
            data = self.replay.frame(self.current, index)
        except Exception as exc:
            LOG.exception("Frame decode failed")
            QMessageBox.warning(
                self,
                APP_NAME,
                f"Unable to decode frame\n{exc}",
            )
            return

        self.frame_index = data.replay_index
        replay_count = self.current.replay_frame_count

        self.timeline.blockSignals(True)
        self.timeline.setRange(0, max(0, replay_count - 1))
        self.timeline.setValue(self.frame_index)
        self.timeline.blockSignals(False)

        self.frame_label.setText(
            f"Frame {self.frame_index + 1}/{replay_count}"
        )
        self.temperature_cursor.setPos(self.frame_index)

        magnitude = data.magnitude
        magnitude_levels = None
        if magnitude is not None:
            magnitude_levels = (
                float(np.percentile(magnitude, 1)),
                float(np.percentile(magnitude, 99)),
            )
            self.magnitude.set_image(
                magnitude,
                levels=magnitude_levels,
            )
        else:
            self.magnitude.set_image(None)

        temperature = data.temperature
        temperature_levels = None
        lut = pg.colormap.get("CET-L4").getLookupTable(0, 1, 256)
        hotspot = (
            (data.hotspot_x, data.hotspot_y)
            if data.hotspot_x is not None
            else None
        )
        hotspot_text = (
            f"{data.maximum_temperature:.2f} °C"
            if data.maximum_temperature is not None
            else None
        )

        if temperature is not None:
            finite = temperature[np.isfinite(temperature)]
            temperature_levels = (
                (
                    float(np.percentile(finite, 2)),
                    float(np.percentile(finite, 98)),
                )
                if finite.size
                else None
            )
            self.temperature.set_image(
                temperature,
                levels=temperature_levels,
                lut=lut,
                hotspot=hotspot,
                hotspot_text=hotspot_text,
            )
        else:
            self.temperature.set_image(None)

        self.overlay.set_overlay(
            magnitude=magnitude,
            temperature=temperature,
            magnitude_levels=magnitude_levels,
            temperature_levels=temperature_levels,
            temperature_lut=lut,
            opacity=self.opacity.value() / 100.0,
            hotspot=hotspot,
            hotspot_text=hotspot_text,
        )

        self.spectrum_plot.clear()
        spectrum_frame = None
        if self.spectrum_frames:
            spectrum_index = self.replay.raw.normalize_index(
                self.frame_index,
                replay_count,
                len(self.spectrum_frames),
            )
            spectrum_frame = self.spectrum_frames[spectrum_index]
            frequencies_khz = (
                np.asarray(spectrum_frame.frequency, dtype=float)
                / 1000.0
            )
            amplitudes = np.asarray(
                spectrum_frame.amplitude,
                dtype=float,
            )
            self.spectrum_plot.plot(
                frequencies_khz,
                amplitudes,
            )

            if self.package.main_frequency_hz is not None:
                main_khz = self.package.main_frequency_hz / 1000.0
                for frequency_khz, label in (
                    (main_khz, "Main"),
                    (main_khz / 2.0, "Subharmonic"),
                    (main_khz * 2.0, "2nd Harmonic"),
                    (main_khz * 3.0, "3rd Harmonic"),
                ):
                    self.spectrum_plot.addItem(
                        pg.InfiniteLine(
                            pos=frequency_khz,
                            angle=90,
                            movable=False,
                            label=label,
                        )
                    )
            spectrum_status = (
                f"Frame {spectrum_index + 1}/{len(self.spectrum_frames)}; "
                f"confidence {spectrum_frame.confidence:.1f}%"
            )
        elif self.current.spectrum_files:
            spectrum_status = (
                "SpectrumMsg found, but decoding requires valid Xd INI frequency"
            )
            self.spectrum_placeholder = pg.TextItem(
                spectrum_status,
                anchor=(0.5, 0.5),
            )
            self.spectrum_plot.addItem(self.spectrum_placeholder)
            self.spectrum_placeholder.setPos(0.5, 0.5)
        else:
            spectrum_status = "No SpectrumMsg"

        rows = [
            ("Sonication", self.current.name),
            (
                "Replay frame",
                f"{self.frame_index + 1}/{replay_count}",
            ),
            (
                "Magnitude frame",
                str(data.magnitude_index)
                if data.magnitude_index is not None
                else "Missing",
            ),
            (
                "Temperature frame",
                str(data.temperature_index)
                if data.temperature_index is not None
                else "Missing",
            ),
            (
                "Maximum temperature",
                f"{data.maximum_temperature:.2f} °C"
                if data.maximum_temperature is not None
                else "Unavailable",
            ),
            (
                "Mean temperature",
                f"{data.mean_temperature:.2f} °C"
                if data.mean_temperature is not None
                else "Unavailable",
            ),
            (
                "Hotspot",
                f"X={data.hotspot_x}, Y={data.hotspot_y}"
                if data.hotspot_x is not None
                else "Unavailable",
            ),
            ("ACT", f"{len(self.current.act_files)} file(s)"),
            (
                "Main frequency",
                (
                    f"{self.package.main_frequency_hz / 1000.0:.1f} kHz"
                    if self.package.main_frequency_hz is not None
                    else "Unavailable"
                ),
            ),
            (
                "Frequency source",
                (
                    self.package.main_frequency_source.name
                    if self.package.main_frequency_source is not None
                    else "Unavailable"
                ),
            ),
            ("Spectrum", spectrum_status),
            (
                "Spectrum main peak",
                (
                    f"{spectrum_frame.main_peak_hz / 1000.0:.1f} kHz"
                    if spectrum_frame is not None
                    and spectrum_frame.main_peak_hz is not None
                    else "Unavailable"
                ),
            ),
            (
                "Spectrum decoder offset",
                (
                    f"0x{spectrum_frame.decoder_offset:08X}"
                    if spectrum_frame is not None
                    and spectrum_frame.decoder_offset is not None
                    else "Unavailable"
                ),
            ),
            ("Sync mode", "Normalized MR / temperature / spectrum mapping"),
            ("Core API", "Image / Temperature / Replay / Spectrum ready"),
        ]

        self.metrics.setRowCount(len(rows))
        for row, (key, value) in enumerate(rows):
            self.metrics.setItem(row, 0, QTableWidgetItem(key))
            self.metrics.setItem(row, 1, QTableWidgetItem(value))

    def slider_changed(self, value: int):
        self.set_frame(value)

    def previous_frame(self):
        self.set_frame(max(0, self.frame_index - 1))

    def next_frame(self):
        if not self.current:
            return

        next_index = self.frame_index + 1
        if next_index >= self.current.replay_frame_count:
            next_index = (
                0
                if self.timer.isActive()
                else self.current.replay_frame_count - 1
            )
        self.set_frame(next_index)

    def toggle_play(self):
        if self.timer.isActive():
            self.timer.stop()
            self.play.setText("Play")
        else:
            self.timer.start(
                max(20, int(1000 / self.speed.value()))
            )
            self.play.setText("Pause")

    def speed_changed(self, value: int):
        if self.timer.isActive():
            self.timer.start(max(20, int(1000 / value)))

    def dragEnterEvent(self, event):
        if any(
            url.isLocalFile()
            for url in event.mimeData().urls()
        ):
            event.acceptProposedAction()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            if not url.isLocalFile():
                continue
            path = Path(url.toLocalFile())
            if path.is_dir() or path.suffix.lower() == ".zip":
                self.load(path)
                event.acceptProposedAction()
                return

    def _restore(self):
        geometry = self.settings.value("geometry")
        state = self.settings.value("state")
        splitter = self.settings.value("splitter")

        if isinstance(geometry, QByteArray):
            self.restoreGeometry(geometry)
        if isinstance(state, QByteArray):
            self.restoreState(state)
        if isinstance(splitter, QByteArray):
            self.main_split.restoreState(splitter)

    def closeEvent(self, event):
        self.timer.stop()
        self.settings.setValue(
            "geometry",
            self.saveGeometry(),
        )
        self.settings.setValue(
            "state",
            self.saveState(),
        )
        self.settings.setValue(
            "splitter",
            self.main_split.saveState(),
        )
        self.importer.cleanup()
        super().closeEvent(event)
