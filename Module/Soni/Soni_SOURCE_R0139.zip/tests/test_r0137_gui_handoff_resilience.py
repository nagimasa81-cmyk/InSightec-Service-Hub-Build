from pathlib import Path
from types import SimpleNamespace

from src.services.sonication_summary_cavitation_evidence_service import SonicationSummaryCavitationEvidenceService


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'src/ui/main_window.py').read_text(encoding='utf-8')
SUMMARY = (ROOT / 'src/services/sonication_summary_cavitation_evidence_service.py').read_text(encoding='utf-8')


def test_selected_data_worker_carries_repository_context_with_power():
    block = MAIN.split('class SelectedReplayDataWorker', 1)[1].split('class PlanningIoWorker', 1)[0]
    assert '"spectrum_context":None' in block
    assert 'self.repository.authoritative_context(' in block
    assert 'payload["spectrum_context"]' in block
    assert 'if self.cpc_enabled and self.repository is not None' not in block


def test_both_async_paths_use_one_gui_adoption_function():
    assert 'def _adopt_authoritative_spectrum_context' in MAIN
    preload = MAIN.split('def _spectrum_preload_ready', 1)[1].split('def _spectrum_preload_failed', 1)[0]
    selected = MAIN.split('def _selected_replay_data_ready', 1)[1].split('def _selected_replay_data_failed', 1)[0]
    assert '_adopt_authoritative_spectrum_context(' in preload
    assert '_adopt_authoritative_spectrum_context(' in selected


def test_ci_recovers_from_repository_cache_without_waiting_for_ui_context():
    block = MAIN.split('def _prepare_cavitation_on_demand', 1)[1].split('def _prepare_default_cavitation_intelligence', 1)[0]
    assert 'self.spectrum_evidence_repository.cached_replay' in block
    assert '_adopt_authoritative_spectrum_context' in block


def test_transient_unavailable_summary_evidence_is_not_cached():
    assert 'if replay is not None and getattr(replay, "frames", None) and timeline_available:' in SUMMARY
    assert 'self._evidence[key] = payload' in SUMMARY


def test_authoritative_handoff_retries_unavailable_or_pending_summary():
    block = MAIN.split('def _adopt_authoritative_spectrum_context', 1)[1].split('def _spectrum_preload_ready', 1)[0]
    assert 'summary_cavitation_evidence_service.clear_cache()' in block
    assert '"unavailable" in str(r.get("cavitation_status"' in block
    assert '"pending" in str(r.get("cavitation_status"' in block
