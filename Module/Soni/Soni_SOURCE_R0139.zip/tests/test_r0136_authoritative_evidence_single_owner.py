from pathlib import Path
from types import SimpleNamespace

import src.services.spectrum_evidence_repository as repo_mod
from src.services.spectrum_evidence_repository import SpectrumEvidenceRepository


def _candidate(name, family='CPC Spectrum'):
    p=Path('/tmp')/name
    return SimpleNamespace(
        family=family, fft_path=p.with_suffix('.fft'), raw_path=None, source=p,
        acquisition_session_index=None, mapping_confidence='Unknown', mapping_evidence='',
    )


def test_partial_package_inventory_expands_to_recursive_universe(monkeypatch, tmp_path):
    fast=[_candidate('cpc1'), _candidate('cpc2')]
    deep=[*fast, _candidate('cpc3'), _candidate('cpc4')]

    class FakeImporter:
        def discover_from_files(self, workspace, inventory):
            return list(fast)
        def discover(self, workspace):
            return list(deep)
        def map_candidates_to_sonications(self, candidates, sonications):
            # deterministic coverage proportional to available CPC candidates
            physical=[c for c in candidates if c.family == 'CPC Spectrum']
            return {i:c for i,c in enumerate(physical[:len(sonications)])}

    monkeypatch.setattr(repo_mod, 'SpectrumDumpImportService', FakeImporter)
    package=SimpleNamespace(workspace=tmp_path, cpc_spectrum_files=[Path('partial')], sonications=[object() for _ in range(4)])
    repo=SpectrumEvidenceRepository()
    universe=repo.candidate_universe(package)
    mapping=repo.candidate_mapping(package)
    assert len(universe) == 4
    assert len(mapping) == 4


def test_complete_fast_inventory_does_not_force_recursive_scan(monkeypatch, tmp_path):
    fast=[_candidate('cpc1'), _candidate('cpc2')]
    calls={'deep':0}
    class FakeImporter:
        def discover_from_files(self, workspace, inventory): return list(fast)
        def discover(self, workspace):
            calls['deep'] += 1
            return []
        def map_candidates_to_sonications(self, candidates, sonications):
            return {i:c for i,c in enumerate(candidates[:len(sonications)])}
    monkeypatch.setattr(repo_mod, 'SpectrumDumpImportService', FakeImporter)
    package=SimpleNamespace(workspace=tmp_path, cpc_spectrum_files=[Path('a'),Path('b')], sonications=[object(),object()])
    repo=SpectrumEvidenceRepository()
    assert len(repo.candidate_mapping(package)) == 2
    assert calls['deep'] == 0


def test_main_preload_uses_authoritative_context_and_never_mapping_values_subset():
    text=(Path(__file__).resolve().parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')
    worker=text.split('class SpectrumPreloadWorker',1)[1].split('class SelectedReplayDataWorker',1)[0]
    assert 'repository.authoritative_context(' in worker
    assert 'candidates = list(mapping.values())' not in worker


def test_preload_failure_does_not_fall_back_to_analyzer_local_package_discovery():
    text=(Path(__file__).resolve().parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')
    block=text.split('def _spectrum_preload_failed',1)[1].split('def _open_hydrophone_window',1)[0]
    assert 'hydrophone_window.load_package' not in block
    assert 'mark_authoritative_preload_failed' in block


def test_power_worker_uses_same_authoritative_acquisition_session_as_cpc_control():
    text=(Path(__file__).resolve().parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')
    block=text.split('class SelectedReplayDataWorker',1)[1].split('class PlanningIoWorker',1)[0]
    assert 'self.repository.authoritative_session(self.package,self.index,self.sonication)' in block
    assert 'preferred_session_index=preferred_session' in block


def test_loaded_export_analyzer_package_load_routes_back_to_main_single_owner():
    text=(Path(__file__).resolve().parents[1]/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    block=text.split('def load_package',1)[1].split('def _load_source_entry',1)[0]
    assert 'getattr(parent,"package",None) is package' in block
    assert 'parent._start_spectrum_preload(package,int(sonication_index))' in block

def test_power_chart_never_mutates_canonical_acoustic_time_axis():
    text=(Path(__file__).resolve().parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')
    apply_block=text.split('def _apply_acoustic_trend',1)[1].split('def _build_acoustic_trends',1)[0]
    assert 'trend.plot_time_s=plot_tx' not in apply_block
    assert 'plot_tx_abs' in apply_block
    update_block=text.split('def _update_acoustic_replay_view',1)[1].split('def _temperature_axis_end_s',1)[0]
    assert 'plot_tx = plot_tx_abs - irradiation_start' in update_block
