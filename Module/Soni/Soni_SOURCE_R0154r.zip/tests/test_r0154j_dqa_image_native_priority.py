from types import SimpleNamespace
from pathlib import Path

from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService


def test_image_native_alignment_aggregates_axial_and_sagittal_without_absolute_ras(tmp_path: Path, monkeypatch):
    pkg=SimpleNamespace(
        workspace=tmp_path,
        source=tmp_path/'case.zip',
        sonications=[
            SimpleNamespace(sonication_number=1, canonical_steering_xyz=None),
            SimpleNamespace(sonication_number=2, canonical_steering_xyz=None),
        ],
    )
    svc=DqaFocusAlignmentService()
    monkeypatch.setattr(svc, '_find_mri_params', lambda _w: tmp_path/'MriImageParams.xml')
    monkeypatch.setattr(svc, '_row_by_number', lambda _p: {1:{'id':1},2:{'id':2}})
    monkeypatch.setattr(svc, '_dqa_exclusion_reason', lambda _p,_n,_f: None)
    monkeypatch.setattr(svc, '_measure_one', lambda son,row: (
        {'orientation':'Axial','x_mm':1.2,'y_mm':-2.4} if son.sonication_number==1
        else {'orientation':'Sagittal','z_mm':3.1,'tilt_deg':0.7}
    ))
    out=svc._image_native_alignment(pkg,{1:(100,100,100),2:(100,100,100)},1)
    assert out is not None
    assert out.x_mm == 1.2 and out.y_mm == -2.4
    assert out.z_mm == 3.1 and out.tilt_deg == 0.7
    assert 'no absolute-RAS subtraction' in out.evidence[-1]


def test_analyze_prefers_image_native_result_over_plausible_but_wrong_focalras(tmp_path: Path, monkeypatch):
    (tmp_path/'SonicationSummary.xml').write_text(
        '<root xmlns:z="urn:schemas-microsoft-com:rowset"><z:row sonicationindex="1" treatprotocol="Low-Energy-DQA" focalrasx="112" focalrasy="81" focalrasz="-63.9" /></root>',
        encoding='utf-8')
    (tmp_path/'spotsonicationdata.xml').write_text('<root xmlns:z="urn:schemas-microsoft-com:rowset"><z:row sonicationindex="1" spotcue="1"/></root>',encoding='utf-8')
    pkg=SimpleNamespace(workspace=tmp_path,source=tmp_path/'case.zip',sonications=[SimpleNamespace(sonication_number=1,canonical_steering_xyz=(0.0,0.0,150.0))])
    svc=DqaFocusAlignmentService()
    native=SimpleNamespace(x_mm=1.0,y_mm=-1.5,z_mm=2.0,tilt_deg=0.2,confidence='High',evidence=['native'],excluded_reason=None,display='native',alert=False)
    monkeypatch.setattr(svc, '_dqa_reference_geometry', lambda _p: {'center_ras':(0.0,0.0,0.0),'validation_rows':[]})
    monkeypatch.setattr(svc, '_image_native_alignment', lambda _p,_f,_n: native)
    out=svc.analyze(pkg,0)
    assert out is native
