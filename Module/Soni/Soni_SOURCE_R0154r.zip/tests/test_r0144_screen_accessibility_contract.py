from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_application_installs_global_screen_safe_guard_before_main_window():
    text = (ROOT / 'src/app/application.py').read_text(encoding='utf-8')
    install_pos = text.index('install_screen_safe_guard(app)')
    window_pos = text.index('window = MainWindow()')
    assert install_pos < window_pos
    assert 'fit_top_level_to_screen(window)' in text


def test_screen_safe_guard_covers_all_qdialog_and_qmainwindow_top_levels():
    text = (ROOT / 'src/ui/screen_safe.py').read_text(encoding='utf-8')
    assert 'isinstance(obj, (QMainWindow, QDialog))' in text
    assert 'frameGeometry()' in text
    assert 'availableGeometry()' in text
    assert 'DEFAULT_BOTTOM_RESERVE' in text
    assert 'for delay in (0, 60, 180)' in text


def test_spectrum_analyzer_keeps_vertical_escape_path_in_every_state():
    text = (ROOT / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'self._main_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)' in text
    assert 'Qt.ScrollBarPolicy.ScrollBarAsNeeded if checked else Qt.ScrollBarPolicy.ScrollBarAlwaysOff' not in text
    # No main-scroll vertical AlwaysOff assignment may remain anywhere.
    for line in text.splitlines():
        if '_main_scroll.setVerticalScrollBarPolicy' in line:
            assert 'AlwaysOff' not in line


def test_r0144_version_identity():
    constants = (ROOT / 'src/common/constants.py').read_text(encoding='utf-8')
    assert 'APP_VERSION = "RC7.10-R0154r"' in constants
    assert 'APP_COMMIT = "R0154r"' in constants
