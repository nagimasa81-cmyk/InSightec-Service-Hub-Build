from pathlib import Path
from types import SimpleNamespace

from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService


def _spot_xml(root: Path, rows):
    body=''.join(f'<z:row sonicationindex="{n}" spotcue="{cue}" />' for n,cue in rows)
    (root/'spotsonicationdata.xml').write_text(
        f'<root xmlns:z="urn:schemas-microsoft-com:rowset">{body}</root>',encoding='utf-8')


def test_dqa_requires_single_spot_and_exact_xyz_default_center(tmp_path: Path):
    _spot_xml(tmp_path, [(1,'100'),(2,'200'),(3,'300'),(4,'400'),(5,'500')])
    sons=[
        SimpleNamespace(sonication_number=1,canonical_steering_xyz=(0.0,0.0,150.0),canonical_steering_source='WS'),
        SimpleNamespace(sonication_number=2,canonical_steering_xyz=(0.0,0.0,142.0),canonical_steering_source='WS'),
        SimpleNamespace(sonication_number=3,canonical_steering_xyz=(0.0,0.0,152.0),canonical_steering_source='WS'),
        SimpleNamespace(sonication_number=4,canonical_steering_xyz=(4.0,4.0,154.0),canonical_steering_source='WS'),
        SimpleNamespace(sonication_number=5,canonical_steering_xyz=None,canonical_steering_source=''),
    ]
    pkg=SimpleNamespace(workspace=tmp_path,sonications=sons)
    assert DqaFocusAlignmentService._dqa_exclusion_reason(pkg,1,{}) is None
    assert DqaFocusAlignmentService._dqa_exclusion_reason(pkg,2,{}) == 'electronic steering'
    assert DqaFocusAlignmentService._dqa_exclusion_reason(pkg,3,{}) == 'electronic steering'
    assert DqaFocusAlignmentService._dqa_exclusion_reason(pkg,4,{}) == 'electronic steering'
    assert DqaFocusAlignmentService._dqa_exclusion_reason(pkg,5,{}) == 'default centre steering not proven'


def test_bbb_subsonication_count_is_not_target_count_but_multiple_spotcues_are(tmp_path: Path):
    # One executed SpotCue remains single target regardless of internal BBB count.
    _spot_xml(tmp_path, [(1,'100'),(2,'200'),(2,'201')])
    sons=[
        SimpleNamespace(sonication_number=1,canonical_steering_xyz=(0.0,0.0,150.0),canonical_steering_source='WS'),
        SimpleNamespace(sonication_number=2,canonical_steering_xyz=(0.0,0.0,150.0),canonical_steering_source='WS'),
    ]
    pkg=SimpleNamespace(workspace=tmp_path,sonications=sons)
    assert DqaFocusAlignmentService._dqa_exclusion_reason(pkg,1,{}) is None
    assert DqaFocusAlignmentService._dqa_exclusion_reason(pkg,2,{}) == 'multi-target / 2 treatment spots'


def test_summary_has_explicit_steering_column_and_dqa_shifted_right():
    text=Path('src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'QTableWidget(0,18)' in text
    assert '"Steering","DQA focus alignment"' in text
    assert 'setItem(int(row),17,dqa_item)' in text
    assert 'default centre: X 0, Y 0, Z 150 mm' in text


def test_loaded_export_analyzer_does_not_hide_spectrummsg_when_cpc_exists():
    text=Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'if candidate.family=="SpectrumMsg":continue' not in text
    assert 'prefix="SpectrumMsg" if candidate.family=="SpectrumMsg" else "SpectrumDumps"' in text
    assert 'complete aggregate FFT/Spectrogram history' in text
