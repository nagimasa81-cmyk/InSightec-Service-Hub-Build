from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re
import struct
import xml.etree.ElementTree as ET

import numpy as np

_TIME_RE = re.compile(r"(?P<h>\d{2}):(?P<m>\d{2}):(?P<s>\d{2}):(?P<ms>\d{3})")
_START_RE = re.compile(
    r"(?:Got\s+StartSpectrumMeasurementA?|Got\s+StartSpectrumMeasurement|"
    r"StartSpectrumMeasurement:\s*SetInitial\s+PowerRatios)",
    re.I,
)
_SET_RE = re.compile(r"AblPowerRatio\s*=\s*(?P<ratio>[-+0-9.eE]+)", re.I)
_SCORE_RE = re.compile(
    r"Calculated Energy:\s*<(?P<energy>[-+0-9.eE]+)>.*?"
    r"(?:Bottom Limit Of Harmless Energy|Bottom Energy limit)\s*[:=]\s*<(?P<limit>[-+0-9.eE]+)>",
    re.I,
)
_STOP_RE = re.compile(r"StopSpectrumMeasurement|Spectrum Measurement.*(?:stop|finished)", re.I)


@dataclass(slots=True)
class AcousticControlSample:
    elapsed_s: float
    power_percent: float | None = None
    score_percent: float | None = None
    energy: float | None = None
    harmless_limit: float | None = None


@dataclass(slots=True)
class AcousticControlSegment:
    source: Path
    start_clock_s: float
    samples: list[AcousticControlSample] = field(default_factory=list)


@dataclass(slots=True)
class AcousticControlTrend:
    time_s: np.ndarray
    power_percent: np.ndarray
    score_percent: np.ndarray
    energy: np.ndarray
    harmless_limit: np.ndarray
    source: Path | None = None
    segment_index: int | None = None
    status: str = "Unavailable"
    acoustic_onset_raw_s: float | None = None
    control_pre_roll_s: float = 0.0
    cavitation_event_s: float | None = None
    modulation_event_s: tuple[float, ...] = ()
    acoustic_end_s: float | None = None
    plot_time_s: np.ndarray | None = None
    plot_power_percent: np.ndarray | None = None
    plot_score_percent: np.ndarray | None = None


class AcousticControlService:
    """Read the workstation cavitation-control telemetry from Acquisition logs.

    Verified from supplied ANx cases:
    * ``AblPowerRatio`` is the applied/requested power ratio (1.0 = 100%).
    * The displayed cavitation score follows the normalized control energy:
      ``Calculated Energy / Bottom Limit Of Harmless Energy * 100``.

    Values are paired by timestamp and are never synthesized from spectrum peaks.
    """

    _ACQ_LOG_STAMP_RE = re.compile(
        r"Acquisition_Brain_\d+_(?P<dow>Mon|Tue|Wed|Thu|Fri|Sat|Sun)_"
        r"(?P<mon>Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)_"
        r"(?P<day>\d{2})_(?P<h>\d{2})_(?P<m>\d{2})_(?P<s>\d{2})_(?P<year>\d{4})\.txt$",
        re.I,
    )
    _MONTHS = {
        "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
        "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
    }

    @classmethod
    def _log_stamp(cls, path: Path):
        match = cls._ACQ_LOG_STAMP_RE.search(Path(path).name)
        if not match:
            return None
        try:
            import datetime as _dt
            return _dt.datetime(
                int(match.group("year")),
                cls._MONTHS[match.group("mon").lower()],
                int(match.group("day")),
                int(match.group("h")),
                int(match.group("m")),
                int(match.group("s")),
            )
        except Exception:
            return None

    @staticmethod
    def _summary_first_sonication_stamp(workspace: Path):
        """Return first real Sonication timestamp from SonicationSummary.xml."""
        try:
            import datetime as _dt
            base = Path(workspace)
            if base.is_file():
                base = base.parent
            search_roots = [base, *base.parents[:2]]
            summaries = []
            for root in search_roots:
                summaries.extend(root.rglob("SonicationSummary.xml"))
                if summaries:
                    break
            stamps = []
            for path in summaries:
                try:
                    root = ET.parse(path).getroot()
                except Exception:
                    continue
                for row in root.iter():
                    raw = str(row.attrib.get("sontime", "")).strip()
                    if re.fullmatch(r"\d{14}", raw):
                        stamps.append(_dt.datetime.strptime(raw, "%Y%m%d%H%M%S"))
            return min(stamps) if stamps else None
        except Exception:
            return None

    def find_log(self, workspace: Path) -> Path | None:
        base = Path(workspace)
        # R0150a/R0151a: Spectrum/FFT callers may provide a logical file path
        # before that file is materialized. Its parent still identifies the
        # CPC workspace and must be searched for Acquisition_Brain evidence.
        if base.is_file() or (not base.exists() and bool(base.suffix)):
            base = base.parent
        candidates = sorted(base.rglob("Acquisition_Brain_*.txt"), key=lambda p: str(p).lower())
        if not candidates:
            return None

        treatment_stamp = self._summary_first_sonication_stamp(base)
        stamped = [(self._log_stamp(path), path) for path in candidates]
        stamped = [(stamp, path) for stamp, path in stamped if stamp is not None]

        if treatment_stamp is not None and stamped:
            before = [(stamp, path) for stamp, path in stamped if stamp <= treatment_stamp]
            if before:
                return max(before, key=lambda item: item[0])[1]
            return min(stamped, key=lambda item: abs((item[0] - treatment_stamp).total_seconds()))[1]

        if stamped:
            return max(stamped, key=lambda item: item[0])[1]

        return candidates[-1]

    @staticmethod
    def _clock_delta_seconds_compat(a: float, b: float) -> float:
        """Signed clock delta with midnight rollover, shared by evidence binders."""
        d = float(a) - float(b)
        if d > 43200.0:
            d -= 86400.0
        elif d < -43200.0:
            d += 86400.0
        return d

    @staticmethod
    def _clock_seconds(line: str) -> float | None:
        match = _TIME_RE.search(line)
        if not match:
            return None
        return (
            int(match.group("h")) * 3600
            + int(match.group("m")) * 60
            + int(match.group("s"))
            + int(match.group("ms")) / 1000.0
        )

    def parse_segments(self, path: Path) -> list[AcousticControlSegment]:
        segments: list[AcousticControlSegment] = []
        current: AcousticControlSegment | None = None
        latest_power: float | None = None
        latest_score: tuple[float, float, float] | None = None

        with path.open("r", encoding="utf-8", errors="replace") as stream:
            for line in stream:
                clock = self._clock_seconds(line)
                if _START_RE.search(line) and clock is not None:
                    # Workstation writes several start-related lines for one sonication.
                    # Debounce them so one physical sonication becomes one telemetry segment.
                    if current is not None and (clock - current.start_clock_s) < 2.0:
                        continue
                    current = AcousticControlSegment(path, clock)
                    segments.append(current)
                    latest_power = None
                    latest_score = None
                    continue
                if current is None or clock is None:
                    continue
                if _STOP_RE.search(line) and current.samples:
                    current = None
                    continue

                power_match = _SET_RE.search(line)
                score_match = _SCORE_RE.search(line)
                if power_match:
                    latest_power = float(power_match.group("ratio")) * 100.0
                if score_match:
                    energy = float(score_match.group("energy"))
                    limit = float(score_match.group("limit"))
                    score = energy / limit * 100.0 if limit > 0 else np.nan
                    latest_score = (score, energy, limit)

                if power_match or score_match:
                    elapsed = clock - current.start_clock_s
                    if elapsed < -12 * 3600:  # midnight rollover
                        elapsed += 24 * 3600
                    score, energy, limit = latest_score or (None, None, None)
                    current.samples.append(
                        AcousticControlSample(
                            elapsed_s=max(0.0, elapsed),
                            power_percent=latest_power,
                            score_percent=score,
                            energy=energy,
                            harmless_limit=limit,
                        )
                    )
        return [segment for segment in segments if segment.samples]

    @staticmethod
    def _collapse(samples: list[AcousticControlSample]) -> tuple[np.ndarray, ...]:
        # Logs often contain a power line and score line a few ms apart. Retain the
        # latest value and sort; interpolation then gives one coherent WS trace.
        ordered = sorted(samples, key=lambda sample: sample.elapsed_s)
        t = np.asarray([sample.elapsed_s for sample in ordered], dtype=float)
        power = np.asarray([
            sample.power_percent if sample.power_percent is not None else np.nan
            for sample in ordered
        ], dtype=float)
        score = np.asarray([
            sample.score_percent if sample.score_percent is not None else np.nan
            for sample in ordered
        ], dtype=float)
        energy = np.asarray([
            sample.energy if sample.energy is not None else np.nan
            for sample in ordered
        ], dtype=float)
        limit = np.asarray([
            sample.harmless_limit if sample.harmless_limit is not None else np.nan
            for sample in ordered
        ], dtype=float)
        return t, power, score, energy, limit

    @staticmethod
    def _fill_forward(values: np.ndarray) -> np.ndarray:
        result = values.copy()
        last = np.nan
        for index, value in enumerate(result):
            if np.isfinite(value):
                last = value
            elif np.isfinite(last):
                result[index] = last
        return result

    @staticmethod
    def _treatment_segment_index(workspace: Path, sonication_index: int, segment_count: int) -> int:
        """Map exported Sonication folders to the matching Acquisition segment.

        A treatment export can contain DQA/calibration spectrum measurements before
        the treatment Sonication folders.  The supplied treatment contains 15
        Acquisition segments but only 8 Sonication folders; the treatment replay is
        therefore the final eight segments, not the first eight.
        """
        # Export ZIPs normally unpack into a wrapper directory (for example
        # workspace/17-00-24_ANx/Sonication1). Counting only workspace.iterdir()
        # therefore returned zero and incorrectly bound treatment Sonications to
        # the early DQA/calibration Acquisition segments. Count recursively and
        # deduplicate resolved Sonication directories so fallback session mapping
        # is the final N treatment segments, matching CPC mapping.
        sonication_dirs = {
            path.resolve() for path in workspace.rglob("*")
            if path.is_dir() and re.fullmatch(r"Sonication\d+", path.name, re.I)
        }
        if re.fullmatch(r"Sonication\d+", workspace.name, re.I):
            sonication_dirs.add(workspace.resolve())
        sonication_count = len(sonication_dirs)
        if sonication_count <= 0 or segment_count <= sonication_count:
            return max(0, min(sonication_index, segment_count - 1))
        offset = segment_count - sonication_count
        return max(0, min(offset + sonication_index, segment_count - 1))


    @staticmethod
    def _find_spotsonication_xml(workspace: Path) -> Path | None:
        candidates = sorted(
            workspace.rglob("spotsonicationdata.xml"),
            key=lambda p: (len(p.parts), str(p).lower()),
        )
        return candidates[0] if candidates else None

    def power_graph_for_sonication(self, workspace: Path, sonication_index: int) -> tuple[np.ndarray, np.ndarray] | None:
        """Return the exported Workstation PowerGraph on the Sonication clock."""
        return self._vendor_power_graph(Path(workspace), int(sonication_index))

    def _vendor_power_graph(self, workspace: Path, sonication_index: int) -> tuple[np.ndarray, np.ndarray] | None:
        """Decode the workstation-exported PowerGraph for one Sonication.

        ``spotsonicationdata.xml`` stores PowerGraph as whitespace-split bin.hex.
        Every point is two little-endian float32 values: elapsed seconds and
        applied power ratio.  The ratio is converted to percent only after the
        complete hex payload has been joined and validated against powergraphsize.
        """
        path = self._find_spotsonication_xml(workspace)
        if path is None:
            return None
        try:
            root = ET.parse(path).getroot()
        except Exception:
            return None
        wanted = int(sonication_index) + 1
        for row in root.iter():
            attrs = row.attrib
            try:
                if int(attrs.get("sonicationindex", "-1")) != wanted:
                    continue
            except Exception:
                continue
            raw_hex = re.sub(r"\s+", "", attrs.get("powergraph", ""))
            if not raw_hex:
                return None
            try:
                payload = bytes.fromhex(raw_hex)
            except ValueError:
                return None
            if len(payload) < 8 or len(payload) % 8:
                return None
            try:
                values = np.asarray(struct.unpack("<" + "f" * (len(payload) // 4), payload), dtype=float)
            except Exception:
                return None
            t = values[0::2]
            power = values[1::2]
            try:
                expected = int(attrs.get("powergraphsize", "0") or 0)
            except Exception:
                expected = 0
            if expected > 0 and len(t) != expected:
                return None
            valid = np.isfinite(t) & np.isfinite(power) & (t >= 0)
            t = t[valid]; power = power[valid]
            if not t.size:
                return None
            # Exported values are ratios (about 0.2..1.0).  Keep compatibility
            # with any future export that already stores percent.
            finite_power = power[np.isfinite(power)]
            if finite_power.size and float(np.nanpercentile(np.abs(finite_power), 95)) <= 2.0:
                power = power * 100.0
            order = np.argsort(t, kind="stable")
            return t[order], power[order]
        return None

    @staticmethod
    def _align_control_to_vendor_power(
        control_t: np.ndarray, control_power: np.ndarray, vendor_t: np.ndarray, vendor_power: np.ndarray
    ) -> float:
        """Estimate Acquisition pre-roll before the exported PowerGraph starts.

        Acquisition_Brain starts cavitation control several seconds before the
        actual sonication.  PowerGraph time zero is the sonication timeline.
        Match the two measured power trajectories instead of assuming that the
        StartSpectrumMeasurement timestamp is acoustic t=0.
        """
        cv = np.isfinite(control_t) & np.isfinite(control_power)
        vv = np.isfinite(vendor_t) & np.isfinite(vendor_power)
        if cv.sum() < 2 or vv.sum() < 2:
            return 0.0
        ct = np.asarray(control_t[cv], float); cp = np.asarray(control_power[cv], float)
        vt = np.asarray(vendor_t[vv], float); vp = np.asarray(vendor_power[vv], float)
        # Ignore the terminal zero sentinel when fitting.
        keep = ~((vp <= 0.01) & (vt >= np.nanmax(vt) - 1e-4))
        vt = vt[keep]; vp = vp[keep]
        if vt.size < 2:
            return 0.0
        upper = max(0.0, float(np.nanmax(ct) - np.nanmax(vt) + 1.5))
        upper = min(30.0, max(upper, 2.0))
        candidates = np.linspace(0.0, upper, max(401, int(upper / 0.01) + 1))
        best_offset = 0.0; best_error = float("inf")
        for offset in candidates:
            q = vt + offset
            inside = (q >= ct[0]) & (q <= ct[-1])
            if inside.sum() < min(5, len(vt)):
                continue
            predicted = np.interp(q[inside], ct, cp)
            err = float(np.nanmedian(np.abs(predicted - vp[inside])))
            # The dynamic ramp is more discriminating than the long plateau.
            dyn = np.abs(np.gradient(vp[inside])) > 0.5 if inside.sum() >= 3 else np.zeros(inside.sum(), bool)
            if dyn.any():
                err += 0.5 * float(np.nanmedian(np.abs(predicted[dyn] - vp[inside][dyn])))
            if err < best_error:
                best_error = err; best_offset = float(offset)
        return best_offset

    def sonication_time_zero_offset(self, workspace: Path, sonication_index: int, preferred_session_index: int | None = None) -> float:
        """Return Acquisition-session seconds preceding Sonication PowerGraph t=0.

        The CPC/Acquisition stream starts before acoustic treatment.  This offset
        converts acquisition-clock timestamps to the canonical Sonication clock.
        """
        log = self.find_log(Path(workspace))
        if log is None:
            return 0.0
        segments = self.parse_segments(log)
        if not segments:
            return 0.0
        index = (int(preferred_session_index) if preferred_session_index is not None and 0 <= int(preferred_session_index) < len(segments)
                 else self._treatment_segment_index(Path(workspace), int(sonication_index), len(segments)))
        segment = segments[index]
        t, power, _score, _energy, _limit = self._collapse(segment.samples)
        if t.size < 2:
            return 0.0
        control_t = np.maximum(np.asarray(t, float) - float(np.nanmin(t)), 0.0)
        vendor = self._vendor_power_graph(Path(workspace), int(sonication_index))
        if vendor is None:
            return 0.0
        vendor_t, vendor_power = vendor
        return float(self._align_control_to_vendor_power(control_t, self._fill_forward(power), vendor_t, vendor_power))

    def measured_duration_for_sonication(self, workspace: Path, sonication_index: int, preferred_session_index: int | None = None) -> float | None:
        log = self.find_log(workspace)
        if log is None:
            return None
        segments = self.parse_segments(log)
        if not segments:
            return None
        index = (int(preferred_session_index) if preferred_session_index is not None and 0 <= int(preferred_session_index) < len(segments)
                 else self._treatment_segment_index(workspace, sonication_index, len(segments)))
        samples = segments[index].samples
        if not samples:
            return None
        values = [sample.elapsed_s for sample in samples]
        return max(0.0, float(max(values) - min(values)))

    @staticmethod
    def _detect_acoustic_onset(t: np.ndarray, power: np.ndarray) -> float:
        """Return the measured start of the acoustic power ramp.

        Acquisition telemetry begins several seconds before energy delivery.
        The old normalized mapping incorrectly stretched that pre-roll across the
        complete MR replay.  Onset is the first sustained departure from the
        initial power-ratio baseline.
        """
        valid = np.isfinite(t) & np.isfinite(power)
        if not valid.any():
            return float(np.nanmin(t)) if t.size else 0.0
        tv = t[valid]; pv = power[valid]
        baseline_count = max(3, min(len(pv), 50))
        baseline = float(np.nanmedian(pv[:baseline_count]))
        threshold = max(0.5, abs(baseline) * 0.02)
        changed = np.flatnonzero(np.abs(pv - baseline) >= threshold)
        if changed.size:
            return float(tv[int(changed[0])])
        return float(tv[0])

    @staticmethod
    def _event_times(t: np.ndarray, power: np.ndarray, score: np.ndarray) -> tuple[float | None, tuple[float, ...]]:
        cavitation = None
        valid_score = np.isfinite(score)
        if valid_score.any():
            indices = np.flatnonzero(valid_score & (score >= 40.0))
            if indices.size:
                cavitation = float(t[int(indices[0])])
        modulations: list[float] = []
        for i in range(1, len(power)):
            if np.isfinite(power[i-1]) and np.isfinite(power[i]) and power[i-1] - power[i] >= 8.0:
                candidate = float(t[i])
                if not modulations or candidate - modulations[-1] >= 0.10:
                    modulations.append(candidate)
        return cavitation, tuple(modulations)

    def trend_for_sonication(
        self,
        workspace: Path,
        sonication_index: int,
        replay_count: int,
        replay_duration_s: float,
        preferred_session_index: int | None = None,
        mr_sonication_start_s: float = 0.0,
        mr_sonication_end_s: float = 0.0,
    ) -> AcousticControlTrend:
        empty = np.full(max(replay_count, 1), np.nan, dtype=float)
        # R0138: target_t is the resampling grid used below to build
        # power_percent/score_percent (the series main_window.py's
        # _apply_acoustic_trend checks to decide whether *any* measured
        # Power % exists at all). vendor_t/source_t are shifted onto the
        # MR-acquisition-absolute clock via "+ mr_sonication_start_s" a few
        # lines down; target_t must live on that same absolute clock or the
        # two domains stop overlapping and every np.interp/resample() call
        # below silently returns all-NaN (interp's left=np.nan fires for
        # every point once mr_sonication_start_s exceeds replay_duration_s).
        # This was invisible while the R0116zzg23-era mr_sonication_start_s
        # bug (see COMMIT_R0123.md) made every Sonication resolve to 0.0 --
        # target_t and vendor_t/source_t coincidentally shared the same
        # [0, duration] domain by accident. Fixing that timeline bug exposed
        # this pre-existing, previously-dormant one: real measured Power/
        # Score data (visible via plot_power_percent/plot_score_percent,
        # which are NOT resampled onto target_t) got reported to the user as
        # "Measured Power % unavailable; planned power ... W" even though it
        # was actually present.
        mr_start_offset = float(mr_sonication_start_s or 0.0)
        target_t = np.linspace(mr_start_offset, mr_start_offset + max(replay_duration_s, 0.0), max(replay_count, 1))
        log = self.find_log(workspace)
        if log is None:
            return AcousticControlTrend(target_t, empty.copy(), empty.copy(), empty.copy(), empty.copy())
        segments = self.parse_segments(log)
        if not segments:
            return AcousticControlTrend(target_t, empty.copy(), empty.copy(), empty.copy(), empty.copy(), source=log)
        index = (int(preferred_session_index) if preferred_session_index is not None and 0 <= int(preferred_session_index) < len(segments)
                 else self._treatment_segment_index(workspace, sonication_index, len(segments)))
        segment = segments[index]
        t, power, score, energy, limit = self._collapse(segment.samples)
        if t.size == 0:
            return AcousticControlTrend(target_t, empty.copy(), empty.copy(), empty.copy(), empty.copy(), source=log, segment_index=index)

        onset_raw = self._detect_acoustic_onset(t, power)
        control_t = np.maximum(t - float(np.nanmin(t)), 0.0)
        vendor = self._vendor_power_graph(workspace, sonication_index)
        alignment_offset = 0.0
        if vendor is not None:
            vendor_t, vendor_power = vendor
            alignment_offset = self._align_control_to_vendor_power(control_t, self._fill_forward(power), vendor_t, vendor_power)
            source_t = control_t - alignment_offset + float(mr_sonication_start_s or 0.0)
            vendor_t = vendor_t + float(mr_sonication_start_s or 0.0)
            acoustic_end_s = float(np.nanmax(vendor_t)) if vendor_t.size else None
        else:
            vendor_t = np.asarray([], dtype=float); vendor_power = np.asarray([], dtype=float)
            source_t = control_t + float(mr_sonication_start_s or 0.0)
            acoustic_end_s = float(np.nanmax(source_t)) if source_t.size and np.isfinite(source_t).any() else None
        exact_end=float(mr_sonication_end_s or 0.0)
        if exact_end > float(mr_sonication_start_s or 0.0):
            acoustic_end_s=exact_end

        def resample(values: np.ndarray, time_axis: np.ndarray = source_t) -> np.ndarray:
            values = self._fill_forward(np.asarray(values, float))
            valid = np.isfinite(values) & np.isfinite(time_axis)
            if acoustic_end_s is not None:
                valid &= (time_axis >= 0.0) & (time_axis <= acoustic_end_s + 1e-6)
            if not valid.any():
                return empty.copy()
            if valid.sum() == 1:
                result = np.full(target_t.shape, np.nan, dtype=float)
                nearest = int(np.argmin(np.abs(target_t - time_axis[valid][0])))
                result[nearest] = values[valid][0]
                return result
            return np.interp(target_t, time_axis[valid], values[valid], left=np.nan, right=np.nan)

        if vendor is not None:
            vvalid = np.isfinite(vendor_t) & np.isfinite(vendor_power)
            sampled_power = np.interp(target_t, vendor_t[vvalid], vendor_power[vvalid], left=np.nan, right=np.nan) if vvalid.sum() >= 2 else empty.copy()
            if acoustic_end_s is not None:
                sampled_power[target_t > acoustic_end_s] = np.nan
        else:
            sampled_power = resample(power)
        sampled_score = resample(score)
        sampled_energy = resample(energy)
        sampled_limit = resample(limit)

        # Use the native PowerGraph points for chart rendering.  Score/energy stay
        # synchronized by shifting Acquisition pre-roll onto the same sonication clock.
        if vendor is not None and vendor_t.size:
            terminal_zero = (vendor_power <= 0.01) & (vendor_t >= float(np.nanmax(vendor_t)) - 1e-4)
            plot_keep = ~terminal_zero
            if not np.any(plot_keep):
                plot_keep = np.ones(vendor_t.shape, dtype=bool)
            plot_t = vendor_t[plot_keep].copy()
            plot_power = vendor_power[plot_keep].copy()
            svals = self._fill_forward(score)
            svalid = np.isfinite(svals) & np.isfinite(source_t) & (source_t >= 0.0)
            if acoustic_end_s is not None:
                svalid &= source_t <= acoustic_end_s + 1e-6
            plot_score = np.interp(plot_t, source_t[svalid], svals[svalid], left=np.nan, right=np.nan) if svalid.sum() >= 2 else np.full(plot_t.shape, np.nan)
        else:
            plot_t = target_t.copy(); plot_power = sampled_power.copy(); plot_score = sampled_score.copy()

        cavitation, modulations = self._event_times(target_t, sampled_power, sampled_score)
        source_name = "spotsonicationdata PowerGraph + Acquisition score" if vendor is not None else "Acquisition telemetry"
        status = (
            f"{source_name}; control pre-roll {alignment_offset:.3f} s; acoustic end +{acoustic_end_s:.3f} s; "
            f"Acquisition segment {index + 1}/{len(segments)}"
            if acoustic_end_s is not None else
            f"{source_name}; Acquisition segment {index + 1}/{len(segments)}"
        )
        return AcousticControlTrend(
            target_t, sampled_power, sampled_score, sampled_energy, sampled_limit,
            source=log, segment_index=index, status=status,
            acoustic_onset_raw_s=alignment_offset if vendor is not None else onset_raw,
            control_pre_roll_s=float(alignment_offset if vendor is not None else 0.0),
            cavitation_event_s=cavitation, modulation_event_s=modulations, acoustic_end_s=acoustic_end_s,
            plot_time_s=plot_t, plot_power_percent=plot_power, plot_score_percent=plot_score,
        )

