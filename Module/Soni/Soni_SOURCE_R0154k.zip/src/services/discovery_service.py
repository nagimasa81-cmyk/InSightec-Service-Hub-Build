from __future__ import annotations

import re
from pathlib import Path

from src.common.constants import MAGNITUDE_PREFIX, TEMPERATURE_PREFIX, DEFAULT_MAIN_FREQUENCY_HZ
from src.domain.models import RawFrame, ReplayPackage, SonicationModel
from src.services.xd_ini_service import XdIniService
from src.services.sonication_frequency_service import SonicationFrequencyService
from src.services.sonication_timing_service import SonicationTimingService
from src.services.planning_data_service import PlanningDataService
from src.services.sonication_evidence_service import SonicationEvidenceService
from src.services.mr_timeline_service import MRTimelineService
from src.core.fus_export_core import inspect_export
from src.services.import_completeness_service import ImportCompletenessService
from src.services.sonication_identity_service import SonicationIdentityService
from src.services.movement_detection_service import MovementDetectionService
from src.services.clock_domain_service import ClockDomainService
from src.services.acoustic_system_profile_service import AcousticSystemProfileService


SON_RE = re.compile(r"^sonication\s*[_-]?\s*(\d+)$", re.I)
RAW_RE = re.compile(r"^(\d+)-.*-(\d+)\.raw$", re.I)


def natural_key(text):
    return [
        int(x) if x.isdigit() else x.lower()
        for x in re.split(r"(\d+)", text)
    ]


class DiscoveryService:
    def __init__(self) -> None:
        self.xd_ini = XdIniService()
        self.sonication_frequency = SonicationFrequencyService()
        self.sonication_timing = SonicationTimingService()
        self.planning_data = PlanningDataService()
        self.sonication_evidence = SonicationEvidenceService()
        self.mr_timeline = MRTimelineService()
        self.import_completeness = ImportCompletenessService()
        self.sonication_identity = SonicationIdentityService()
        self.movement_detection = MovementDetectionService()
        self.clock_domain = ClockDomainService()
        self.acoustic_system_profile = AcousticSystemProfileService()

    def discover(self, source: Path, workspace: Path) -> ReplayPackage:
        # R0141: logical Sonication identity is no longer owned by physical
        # SonicationN folders.  Resolve it from the union of numbered evidence
        # first, then build exactly one model per logical Sonication number.
        identity = self.sonication_identity.resolve(workspace)
        numbers = list(identity.numbers)

        # Legacy single-Sonication exports may have local RAW/Spectrum evidence
        # without any numbered identity marker. Preserve that established path.
        if not numbers and any(
            path.is_file() and ("spectrummsg" in path.name.lower() or path.suffix.lower() == ".raw")
            for path in workspace.iterdir()
        ):
            numbers = [1]

        models = [
            self._build_logical(
                workspace=workspace,
                number=number,
                folders=identity.folders_by_number.get(number, []),
                identity_evidence=identity.evidence_by_number.get(number, []),
            )
            for number in numbers
        ]

        # Semantic Export inspection is intentionally independent from replay
        # decoding. PARTIAL sonications remain loadable; missing assets are
        # reported per capability rather than blocking the whole case.
        export_inspection = inspect_export(workspace)
        inspection_by_number = {item.number: item for item in export_inspection.sonications}
        for model in models:
            item = inspection_by_number.get(model.sonication_number)
            if item is not None:
                model.completeness_status = item.status
                model.completeness_score = item.score
                model.missing_required = list(item.missing_required)
                model.missing_optional = list(item.missing_optional)
                model.degraded_items = list(item.degraded_items)
                model.capabilities = {
                    key: {
                        "available": value.available,
                        "degraded": value.degraded,
                        "reason": value.reason,
                        "evidence": list(value.evidence),
                    }
                    for key, value in item.capabilities.items()
                }
                model.thermometry_mode = item.thermometry_mode
            elif model.synthetic_identity:
                model.completeness_status = "PARTIAL"
                model.missing_required = ["Physical Sonication folder"]
                model.degraded_items = ["Logical identity reconstructed from package-level evidence"]

        timings = self.sonication_timing.read_indexed(workspace)
        for model in models:
            timing = timings.get(model.sonication_number)
            if timing is None:
                continue
            model.planned_duration_s = timing.planned_duration_s
            model.actual_duration_s = timing.actual_duration_s
            model.planned_power_w = timing.planned_power_w
            model.actual_power_w = timing.actual_power_w
            model.planned_energy_j = timing.planned_energy_j
            model.actual_energy_j = timing.actual_energy_j
            # Authoritative Workstation Replay frequency: SonicationSummary.xml
            # per-sonication row. Do not replace this value with SkullHeating
            # or package/XD nominal frequency.
            if timing.frequency_hz is not None:
                model.main_frequency_hz = timing.frequency_hz
                model.main_frequency_source = timing.source
                model.main_frequency_raw_line = f"SonicationSummary.frequency={timing.frequency_hz:g}"
            model.timing_source = timing.source
            model.panic_type = timing.panic_type

        # R0148: Movement Detection is a three-axis anatomical displacement.
        # Never derive RL/SI/AP from the legacy scalar motionvalue.
        movement_rows = self.movement_detection.read_indexed(workspace)
        for model in models:
            movement = movement_rows.get(model.sonication_number)
            if movement is not None:
                model.movement_detection_rl = float(movement.rl)
                model.movement_detection_si = float(movement.si)
                model.movement_detection_ap = float(movement.ap)
                model.movement_detection_display = movement.display
                model.movement_detection_source = movement.source

        xd_references = self.xd_ini.discover_references(workspace)
        frequency = self.xd_ini.read_main_frequency(workspace)
        fallback_hz = frequency.frequency_hz if frequency.frequency_hz is not None else DEFAULT_MAIN_FREQUENCY_HZ
        for model in models:
            # SonicationSummary frequency is authoritative for Workstation Replay.
            # Legacy/local discovery is used only when the summary has no frequency.
            if model.main_frequency_hz is not None:
                continue
            local = self.sonication_frequency.read(model.folder) if model.folder.exists() else self.sonication_frequency.read(workspace)
            model.main_frequency_hz = local.frequency_hz if local.frequency_hz is not None else fallback_hz
            model.main_frequency_source = local.source if local.source is not None else frequency.source_path
            model.main_frequency_raw_line = local.raw_line if local.raw_line is not None else frequency.raw_line

        # R0116zm/R0141: bind evidence by explicit Sonication number, never by
        # list position. This is required for missing/gapped/duplicate folders.
        try:
            evidence_rows = self.sonication_evidence.read(workspace, models)
        except Exception:
            evidence_rows = []
        evidence_by_number = {row.sonication_index: row for row in evidence_rows}
        for model in models:
            evidence = evidence_by_number.get(model.sonication_number)
            if evidence is None:
                continue
            model.canonical_acquisition_session_index = evidence.acquisition_session_index
            model.canonical_setup_clock_s = evidence.setup_record.clock_s if evidence.setup_record is not None else None
            if evidence.setup_record is not None:
                model.canonical_steering_xyz = tuple(evidence.setup_record.steering_xyz)
                model.canonical_steering_source = evidence.setup_record.source
            model.canonical_mapping_confidence = evidence.confidence
            model.canonical_mapping_evidence = list(evidence.evidence)
            model.spectrummsg_frame_count = evidence.spectrummsg_frame_count
            model.powergraph_size = evidence.powergraph_size
            model.sonication_file_inventory = dict(evidence.file_inventory)

        # R0116zn/R0141: one authoritative clock for the whole application.
        # MRTimelineService also resolves Summary rows by Sonication number.
        try:
            mr_timelines = self.mr_timeline.resolve_all(workspace, models)
        except Exception:
            mr_timelines = []
        for model, timeline in zip(models, mr_timelines):
            model.mr_timeline_duration_s = float(timeline.duration_s)
            model.mr_sonication_start_s = float(timeline.sonication_start_s)
            model.mr_sonication_end_s = float(timeline.sonication_end_s)
            model.mr_frame_interval_s = timeline.frame_interval_s
            model.mr_timeline_source = str(timeline.source)
            model.mr_timeline_confidence = str(timeline.confidence)
            model.mr_timeline_evidence = list(timeline.evidence)

        # R0153 clock-domain hardening: Treatment WS and CPC Windows clocks are
        # not assumed synchronized.  Estimate a robust case-level offset from
        # shared acoustic-onset anchors.  This is diagnostic evidence first;
        # unstable/one-anchor estimates are never auto-corrected.
        try:
            clock_assessment = self.clock_domain.assess(workspace, models, mr_timelines)
        except Exception as exc:
            clock_assessment = None
            clock_error = f"Clock-domain assessment failed: {type(exc).__name__}: {exc}"
        else:
            clock_error = None
        for model in models:
            if clock_assessment is None:
                model.clock_sync_status = "Unavailable"
                model.clock_sync_evidence = [clock_error] if clock_error else []
                continue
            model.cpc_to_ws_clock_offset_s = (
                float(clock_assessment.cpc_to_ws_offset_s)
                if clock_assessment.cpc_to_ws_offset_s is not None else None
            )
            model.clock_sync_status = str(clock_assessment.status)
            model.clock_sync_anchor_count = int(clock_assessment.anchor_count)
            model.clock_sync_spread_s = (
                float(clock_assessment.spread_s) if clock_assessment.spread_s is not None else None
            )
            model.clock_sync_evidence = list(clock_assessment.evidence)

        cpc_files = []
        for path in workspace.rglob('*'):
            if not path.is_file():
                continue
            low = path.name.lower()
            if 'spectrummsg' in low:
                continue
            if low.startswith('spectrum_') and (low.endswith('.dmp') or low.endswith('.dmp_fft')):
                cpc_files.append(path)
        cpc_files = sorted(set(cpc_files), key=lambda path: natural_key(str(path)))

        planning = self.planning_data.discover(workspace)

        try:
            import_audit = self.import_completeness.audit(workspace, models).to_dict()
        except Exception as exc:
            import_audit = {
                "status": "WARN",
                "issues": [f"Import completeness audit failed: {type(exc).__name__}: {exc}"],
            }

        # R0154g: actual treatment frequency owns the package-level frequency.
        # A package may contain both Brain220 and Brain650 template INIs, so the
        # presence/name of a template is never enough to classify the system.
        actual_frequencies = [
            float(model.main_frequency_hz) for model in models
            if model.main_frequency_hz is not None
        ]
        acoustic_profile = self.acoustic_system_profile.classify(workspace, actual_frequencies)
        if acoustic_profile.actual_frequency_hz is not None:
            package_frequency_hz = float(acoustic_profile.actual_frequency_hz)
            package_frequency_source = next((m.main_frequency_source for m in models if m.main_frequency_source is not None), None)
            package_frequency_raw = f"SonicationSummary median={package_frequency_hz:g} Hz"
            package_frequency_confidence = 100.0 if not acoustic_profile.conflict else 40.0
            package_frequency_interpretation = f"Actual treatment frequency · {acoustic_profile.family}"
        elif frequency.frequency_hz is not None:
            package_frequency_hz = float(frequency.frequency_hz)
            package_frequency_source = frequency.source_path
            package_frequency_raw = frequency.raw_line
            package_frequency_confidence = frequency.confidence
            package_frequency_interpretation = f"Serial XD fallback · {acoustic_profile.family}"
        elif acoustic_profile.transducer_type == 41:
            package_frequency_hz = 230_000.0
            package_frequency_source = None
            package_frequency_raw = "TransducerInfo.transtype=41 nominal fallback"
            package_frequency_confidence = 50.0
            package_frequency_interpretation = "Tx41 nominal fallback (230 kHz)"
        elif acoustic_profile.transducer_type == 42:
            package_frequency_hz = 650_000.0
            package_frequency_source = None
            package_frequency_raw = "TransducerInfo.transtype=42 nominal fallback"
            package_frequency_confidence = 50.0
            package_frequency_interpretation = "Tx42 nominal fallback (650 kHz)"
        else:
            package_frequency_hz = DEFAULT_MAIN_FREQUENCY_HZ
            package_frequency_source = None
            package_frequency_raw = None
            package_frequency_confidence = 10.0
            package_frequency_interpretation = "Legacy fallback 650 kHz; acoustic system unresolved"

        return ReplayPackage(
            source=source,
            workspace=workspace,
            sonications=models,
            main_frequency_hz=package_frequency_hz,
            main_frequency_source=package_frequency_source,
            main_frequency_raw_line=package_frequency_raw,
            main_frequency_confidence=package_frequency_confidence,
            main_frequency_interpretation=package_frequency_interpretation,
            acoustic_system_family=acoustic_profile.family,
            acoustic_system_profile=acoustic_profile.display,
            acoustic_system_conflict=bool(acoustic_profile.conflict),
            acoustic_system_evidence=list(acoustic_profile.evidence),
            cpc_spectrum_files=cpc_files,
            planning_assets=planning.assets,
            xd_reference_files=xd_references.xd_files,
            xd_geometry_files=xd_references.geometry_files,
            workflow_mode=export_inspection.workflow_mode,
            thermometry_mode=export_inspection.thermometry_mode,
            import_audit=import_audit,
        )

    def _build_logical(
        self,
        workspace: Path,
        number: int,
        folders: list[Path],
        identity_evidence: list[str],
    ) -> SonicationModel:
        # Pick a stable primary path for APIs that still expect ``model.folder``.
        # All duplicate physical folders are merged into this one logical model.
        primary = folders[0] if folders else workspace / f"Sonication{number}"
        model = SonicationModel(
            name=f"Sonication{number}",
            folder=primary,
            sonication_number=int(number),
            evidence_folders=list(folders),
            synthetic_identity=not bool(folders),
            identity_evidence=list(identity_evidence),
        )

        scan_roots = list(folders)
        seen_file_keys: set[tuple[str, int]] = set()
        files: list[Path] = []
        for root in scan_roots:
            if not root.exists():
                continue
            for path in root.rglob("*"):
                if not path.is_file():
                    continue
                try:
                    size = path.stat().st_size
                except OSError:
                    size = -1
                # Nested ZIP expansion can materialize the same Sonication folder
                # twice. Merge duplicate copies by filename+size while retaining
                # distinct evidence with different names/sizes.
                key = (path.name.lower(), int(size))
                if key in seen_file_keys:
                    continue
                seen_file_keys.add(key)
                files.append(path)

        # A missing physical Sonication folder must not hide package-level
        # SpectrumMsg-N evidence. Also capture it if it lives outside the folder.
        spectrum_pattern = re.compile(rf"^spectrummsg[-_ ]?{int(number)}(?:\D|$)", re.I)
        for path in workspace.rglob("*"):
            if not path.is_file() or path.suffix.lower() != ".dmp":
                continue
            if not spectrum_pattern.match(path.name):
                continue
            try:
                size = path.stat().st_size
            except OSError:
                size = -1
            key = (path.name.lower(), int(size))
            if key not in seen_file_keys:
                seen_file_keys.add(key)
                files.append(path)

        for path in files:
            low = path.name.lower()
            raw_match = RAW_RE.match(path.name)
            if raw_match:
                frame = RawFrame(path=path, index=int(raw_match.group(2)), prefix=raw_match.group(1))
                if frame.prefix == TEMPERATURE_PREFIX:
                    model.temperature_frames.append(frame)
                elif frame.prefix == MAGNITUDE_PREFIX:
                    model.magnitude_frames.append(frame)
                else:
                    model.other_files.append(path)
            elif "spectrummsg" in low and path.suffix.lower() == ".dmp":
                model.spectrum_files.append(path)
            elif path.suffix.lower() == ".act":
                model.act_files.append(path)
            else:
                model.other_files.append(path)

        model.temperature_frames.sort(key=lambda frame: frame.index)
        model.magnitude_frames.sort(key=lambda frame: frame.index)
        model.spectrum_files.sort(key=lambda path: natural_key(path.name))
        model.act_files.sort(key=lambda path: natural_key(path.name))
        return model

    def _build(
        self,
        folder: Path,
        fallback: int,
    ) -> SonicationModel:
        match = SON_RE.match(folder.name)
        name = (
            f"Sonication{int(match.group(1))}"
            if match
            else f"Sonication{fallback}"
        )

        model = SonicationModel(
            name=name,
            folder=folder,
        )

        for path in folder.rglob("*"):
            if not path.is_file():
                continue

            low = path.name.lower()
            raw_match = RAW_RE.match(path.name)

            if raw_match:
                frame = RawFrame(
                    path=path,
                    index=int(raw_match.group(2)),
                    prefix=raw_match.group(1),
                )
                if frame.prefix == TEMPERATURE_PREFIX:
                    model.temperature_frames.append(frame)
                elif frame.prefix == MAGNITUDE_PREFIX:
                    model.magnitude_frames.append(frame)
                else:
                    model.other_files.append(path)
            elif (
                "spectrummsg" in low
                and path.suffix.lower() == ".dmp"
            ):
                model.spectrum_files.append(path)
            elif path.suffix.lower() == ".act":
                model.act_files.append(path)
            else:
                model.other_files.append(path)

        model.temperature_frames.sort(key=lambda frame: frame.index)
        model.magnitude_frames.sort(key=lambda frame: frame.index)
        model.spectrum_files.sort(
            key=lambda path: natural_key(path.name)
        )
        model.act_files.sort(
            key=lambda path: natural_key(path.name)
        )
        return model
