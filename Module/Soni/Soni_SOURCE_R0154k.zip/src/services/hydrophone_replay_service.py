from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re
import gzip
import struct
import numpy as np

from src.services.hydrophone_calibration_service import HydrophoneCalibrationService
from src.services.cpc_vendor_reproduction_service import CpcVendorReproductionService, VendorCavitationProfile, VendorHistoryValidation, VendorControlValidation
from src.services.cavitation_visualization_service import CavitationVisualizationService


@dataclass(slots=True)
class CpcHydrophoneFrame:
    index: int
    frequency_hz: np.ndarray
    channels: list[np.ndarray]
    uncalibrated_channels: list[np.ndarray] = field(default_factory=list)
    raw_channels: list[np.ndarray] = field(default_factory=list)
    duration_s: float = 0.010
    hw_status: int | None = None
    vendor_band_energies: np.ndarray = field(default_factory=lambda: np.empty((0, 0), dtype=float))
    acquisition_history_index: int | None = None
    acquisition_cycle: int | None = None
    acquisition_time_s: float | None = None


@dataclass(slots=True)
class SubharmonicEvent:
    """One frame whose f0/2 sub-harmonic band is comparably strong to the fundamental.

    R0118: ``fundamental_amplitude``/``subharmonic_amplitude`` are band-
    integrated energy (via ``CavitationVisualizationService.band_energy``),
    the same physical quantity plotted as ``CavitationTrend.subharmonic_db``
    -- not a single peak-bin amplitude. This is a passive acoustic
    *indicator*, not a cavitation diagnosis: broadband noise, a nearby
    resonance, or a decode artifact can also elevate the f0/2 band.
    Consumers should present this as evidence worth an operator's attention,
    consistent with the project's evidence-first policy (see
    CavitationLikelihoodService), never as a deterministic cavitation call.
    """
    frame_index: int
    time_s: float
    channel: int
    fundamental_hz: float
    subharmonic_hz: float
    fundamental_amplitude: float
    subharmonic_amplitude: float
    ratio_db: float
    confidence: str


@dataclass(slots=True)
class CpcHydrophoneReplay:
    source_fft: Path | None
    source_raw: Path | None
    # Stable treatment ownership. This must be a declared slots field because
    # repository/preload/UI handoffs assign it for semantic replay identity.
    sonication_index: int | None = None
    channel_count: int = 8
    sampling_frequency_hz: float = 0.0
    main_frequency_hz: float = 0.0
    declared_frame_count: int = 0
    declared_message_count: int = 0
    decoded_snapshot_count: int = 0
    messages_per_snapshot: int = 1
    final_snapshot_has_single_message: bool = False
    acquisition_interval_s: float = 0.010
    raw_adc_available: bool = False
    raw_adc_unavailable_reason: str = ""
    total_samples: int = 0
    frames: list[CpcHydrophoneFrame] = field(default_factory=list)
    channel_reference_levels: list[float] = field(default_factory=lambda: [1.0] * 8)
    display_db_min: float = -60.0
    display_db_max: float = 0.0
    note: str = ""
    decoder_confidence: str = "failed"
    raw_timeline_channels: list[np.ndarray] = field(default_factory=list)
    raw_history_pairs: list[tuple[np.ndarray, np.ndarray]] = field(default_factory=list)
    raw_timeline_time_s: np.ndarray = field(default_factory=lambda: np.array([], dtype=float))
    raw_container_total_measurements: int = 0
    raw_container_saved_measurements: int = 0
    raw_structure_note: str = ""
    calibration_available: bool = False
    calibration_ini: Path | None = None
    response_ini: Path | None = None
    spectrum_coef: float = 1.0
    spectrum_factors: tuple[float, ...] = (1.0,) * 8
    receiver_enabled: tuple[bool, ...] = (True,) * 8
    response_point_count: int = 0
    frequency_axis_source: str = "Unknown"
    frequency_start_hz: float | None = None
    frequency_spacing_hz: float | None = None
    frequency_end_hz: float | None = None
    frequency_axis_config_delta_hz: float | None = None
    main_frequency_bin_hz: float | None = None
    main_frequency_bin_error_hz: float | None = None
    theoretical_fft_spacing_hz: float | None = None
    embedded_vs_theoretical_spacing_delta_hz: float | None = None
    vendor_profile: VendorCavitationProfile | None = None
    vendor_history_validation: VendorHistoryValidation | None = None
    vendor_band0_exact: bool = False
    vendor_band0_weighted: np.ndarray = field(default_factory=lambda: np.array([], dtype=float))
    vendor_display_rule1: np.ndarray = field(default_factory=lambda: np.array([], dtype=float))
    vendor_display_rule2: np.ndarray = field(default_factory=lambda: np.array([], dtype=float))
    vendor_band1_log_exact: np.ndarray = field(default_factory=lambda: np.array([], dtype=float))
    vendor_band2_log_events: np.ndarray = field(default_factory=lambda: np.array([], dtype=float))
    vendor_embedded_band_energy_available: bool = False
    vendor_embedded_band_energy_validated: bool = False
    vendor_embedded_band_energy_max_error: float | None = None
    snapshot_cycle_mapping_validated: bool = False
    snapshot_cycle_mapping_max_error: float | None = None
    vendor_control_validation: VendorControlValidation | None = None
    acquisition_session_index: int | None = None
    sonication_time_zero_offset_s: float = 0.0
    # Acquisition_Brain controller cycle corresponding to Sonication power t=0.
    # CPC FFT frame acquisition_time_s is not in the same origin as the physical
    # control response timeline; when available this cycle anchor is authoritative.
    sonication_cycle_zero: int | None = None
    # Application-wide canonical timeline: MR scan start=0, MR scan end=end.
    mr_timeline_duration_s: float = 0.0
    mr_sonication_start_s: float = 0.0
    mr_sonication_end_s: float = 0.0
    mr_timeline_source: str = "Unavailable"
    mr_timeline_confidence: str = "Unknown"
    controller_cycle_numbers: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=int))
    controller_cycle_mr_times_s: np.ndarray = field(default_factory=lambda: np.asarray([], dtype=float))
    mapping_evidence: str = "Unresolved"
    mapping_confidence: str = "Unknown"
    _accumulated_prefix_cache: dict = field(default_factory=dict, repr=False, compare=False)

    @property
    def frame_interval_s(self) -> float:
        times = np.asarray([f.acquisition_time_s for f in self.frames if f.acquisition_time_s is not None and np.isfinite(f.acquisition_time_s)], dtype=float)
        if times.size > 1:
            diffs = np.diff(times)
            diffs = diffs[np.isfinite(diffs) & (diffs > 0)]
            if diffs.size:
                rounded=np.round(diffs, 6)
                unique, counts=np.unique(rounded, return_counts=True)
                max_count=int(np.max(counts))
                return float(np.min(unique[counts == max_count]))
        values = [f.duration_s for f in self.frames if np.isfinite(f.duration_s) and f.duration_s > 0]
        return float(np.median(values)) if values else 0.010

    @property
    def frame_times_s(self) -> np.ndarray:
        if self.frames and all(f.acquisition_time_s is not None and np.isfinite(f.acquisition_time_s) for f in self.frames):
            return np.asarray([float(f.acquisition_time_s) for f in self.frames], dtype=float)
        return np.arange(len(self.frames), dtype=float) * self.frame_interval_s

    def _cycles_to_mr(self, cycles) -> np.ndarray | None:
        values=np.asarray(cycles,dtype=float)
        x=np.asarray(self.controller_cycle_numbers,dtype=float)
        y=np.asarray(self.controller_cycle_mr_times_s,dtype=float)
        valid=np.isfinite(x) & np.isfinite(y)
        if np.count_nonzero(valid) < 2:
            return None
        x=x[valid]; y=y[valid]
        order=np.argsort(x,kind="stable"); x=x[order]; y=y[order]
        unique=np.r_[True,np.diff(x)>0]; x=x[unique]; y=y[unique]
        if x.size < 2:
            return None
        out=np.full(values.shape,np.nan,dtype=float)
        inside=np.isfinite(values) & (values >= x[0]) & (values <= x[-1])
        if np.any(inside):
            out[inside]=np.interp(values[inside],x,y)
        return out

    def cycles_to_mr_times(self, cycles) -> np.ndarray:
        """Map CPC controller cycle IDs onto the canonical MR axis.

        Prefer exact Acquisition_Brain wall-clock cycle timestamps.  Only when
        those timestamps are unavailable may callers fall back to the legacy
        fixed AcquireInterval model.  Keeping this conversion here prevents UI
        panels from reintroducing their own cycle*10ms clocks.
        """
        values=np.asarray(cycles,dtype=float)
        mapped=self._cycles_to_mr(values)
        if mapped is not None and np.all(np.isfinite(mapped)):
            return mapped
        if self.sonication_cycle_zero is not None:
            return (values-float(self.sonication_cycle_zero))*float(self.acquisition_interval_s or 0.010) + float(self.mr_sonication_start_s or 0.0)
        return np.asarray([self.acquisition_to_mr_time_s((float(c)-1.0)*float(self.acquisition_interval_s or 0.010)) for c in values],dtype=float)

    @property
    def sonication_frame_times_s(self) -> np.ndarray:
        # R0154: prefer exact Acquisition_Brain Cycle N Done wall-clock mapping.
        if self.frames and all(getattr(f, "acquisition_cycle", None) is not None for f in self.frames):
            mapped=self._cycles_to_mr([float(f.acquisition_cycle) for f in self.frames])
            if mapped is not None and np.all(np.isfinite(mapped)):
                return mapped - float(self.mr_sonication_start_s or 0.0)
        # R0116zzg13: CPC FFT frames carry Acquisition cycle IDs.  Their decoded
        # acquisition_time_s starts at the CPC history origin, whereas
        # Acquisition_Brain power/control rows start at physical Sonication t=0.
        # Applying sonication_time_zero_offset_s to FFT timestamps was wrong for
        # short/aborted Sonications (all frames could become negative).  Use the
        # shared controller cycle domain whenever it is available.
        if self.sonication_cycle_zero is not None and self.frames and all(getattr(f, "acquisition_cycle", None) is not None for f in self.frames):
            return np.asarray([
                (float(f.acquisition_cycle) - float(self.sonication_cycle_zero)) * float(self.acquisition_interval_s or 0.010)
                for f in self.frames
            ], dtype=float)
        return self.frame_times_s - float(self.sonication_time_zero_offset_s or 0.0)

    def _acquisition_times_to_sonication(self, values) -> np.ndarray:
        arr=np.asarray(values,dtype=float)
        frame_acq=np.asarray(self.frame_times_s,dtype=float)
        frame_son=np.asarray(self.sonication_frame_times_s,dtype=float)
        valid=np.isfinite(frame_acq) & np.isfinite(frame_son)
        if np.count_nonzero(valid) >= 2:
            x=frame_acq[valid]; y=frame_son[valid]
            order=np.argsort(x,kind="stable"); x=x[order]; y=y[order]
            # The decoded CPC acquisition clock and cycle clock are linear. Fit the
            # measured relationship so RAW/history timestamps share the same origin
            # as FFT frames without reusing the unrelated Acquisition pre-roll.
            try:
                slope, intercept=np.polyfit(x,y,1)
                if np.isfinite(slope) and np.isfinite(intercept):
                    return arr*float(slope)+float(intercept)
            except Exception:
                pass
        return arr - float(self.sonication_time_zero_offset_s or 0.0)

    @property
    def sonication_raw_timeline_time_s(self) -> np.ndarray:
        return self._acquisition_times_to_sonication(self.raw_timeline_time_s)

    @property
    def mr_frame_times_s(self) -> np.ndarray:
        if self.frames and all(getattr(f, "acquisition_cycle", None) is not None for f in self.frames):
            mapped=self._cycles_to_mr([float(f.acquisition_cycle) for f in self.frames])
            if mapped is not None and np.all(np.isfinite(mapped)):
                return mapped
        return self.sonication_frame_times_s + float(self.mr_sonication_start_s or 0.0)

    @property
    def mr_raw_timeline_time_s(self) -> np.ndarray:
        n=int(np.asarray(self.raw_timeline_time_s).size)
        if n > 0:
            mapped=self._cycles_to_mr(np.arange(1,n+1,dtype=float))
            if mapped is not None and np.all(np.isfinite(mapped)):
                return mapped
        return self.sonication_raw_timeline_time_s + float(self.mr_sonication_start_s or 0.0)

    def acquisition_to_mr_time_s(self, value: float) -> float:
        mapped=self._acquisition_times_to_sonication(np.asarray([float(value)],dtype=float))
        return float(mapped[0]) + float(self.mr_sonication_start_s or 0.0)

    def reconstruction_support(self, gap_factor: float = 3.0) -> dict[str, object]:
        """Describe measured FFT gaps and any validated alternate data usable inside them.

        This never invents a full spectrum.  The 10-ms CPC measurement-history
        arrays may be used as a Band0 metric only when the FFT-to-history
        fingerprint mapping was validated.  Per-record RAW A/D can support a
        true FFT reconstruction only when it is actually present.
        """
        measured=np.asarray(self.mr_frame_times_s,dtype=float)
        finite=measured[np.isfinite(measured)]
        gaps=[]
        nominal=float(self.frame_interval_s or self.acquisition_interval_s or 0.010)
        threshold=max(nominal*float(gap_factor), nominal+1e-6)
        if finite.size >= 2:
            order=np.argsort(finite,kind="stable"); values=finite[order]
            for a,b in zip(values[:-1],values[1:]):
                if float(b-a) > threshold:
                    gaps.append({"start_s":float(a),"end_s":float(b),"duration_s":float(b-a)})
        history_time=np.asarray(self.mr_raw_timeline_time_s,dtype=float)
        history=[]
        if self.snapshot_cycle_mapping_validated and self.raw_timeline_channels and history_time.size:
            n=min(history_time.size,min(len(np.asarray(ch)) for ch in self.raw_timeline_channels[:self.channel_count]))
            if n>0:
                matrix=np.vstack([np.asarray(ch,dtype=float)[:n] for ch in self.raw_timeline_channels[:self.channel_count]]).T
                history={"time_s":history_time[:n],"values":matrix,"source":"Validated CPC measurement history / Band0 fingerprint"}
        return {
            "gaps":gaps,
            "nominal_interval_s":nominal,
            "raw_adc_available":bool(self.raw_adc_available),
            "band0_history":history,
            "full_spectrum_reconstruction":bool(self.raw_adc_available),
            "note": (
                "Full-spectrum reconstruction is permitted only from verified RAW A/D. "
                "Validated CPC measurement history can reconstruct Band0 metric values, not the full spectrum."
            ),
        }

    # Minimum finite, above-noise amplitude samples required near f0/2 and f0
    # before a frame's ratio is trusted.  A single sample can look "prominent"
    # by chance; this does not change ratio math, only whether we report it.
    SUBHARMONIC_MIN_NOISE_MULTIPLE = 3.0

    def subharmonic_events(
        self,
        channel: int,
        prominence_db: float = -3.0,
        main_frequency_hz: float | None = None,
    ) -> list["SubharmonicEvent"]:
        """Flag frames whose f0/2 sub-harmonic is comparably strong to the fundamental.

        R0118: this used to compare raw peak-bin amplitudes with its own
        window width and a 20*log10 (amplitude-ratio) dB formula -- a second,
        silently different definition of "sub-harmonic energy" from the one
        Cavitation Intelligence already renders as ``CavitationTrend.
        subharmonic_db`` (band-integrated energy, 10*log10 power-style dB).
        Two independent definitions of the same physical quantity can drift
        apart and disagree about the same frame; this method now reuses
        ``CavitationVisualizationService.band_energy``/``energy_ratio_db``/
        the canonical window widths so both views are the same measurement,
        just aggregated differently (per-frame per-channel discrete events
        with a noise-floor gate here, vs. a channel-averaged continuous
        trend there).

        A prominent f0/2 component is the textbook acoustic signature of
        stable/inertial cavitation, but this method only reports the spectral
        ratio it measured; it is deliberately silent on *why* the ratio is
        elevated.  ``prominence_db`` is the minimum sub-harmonic-to-fundamental
        energy ratio (in dB, 10*log10 convention) required before a frame is
        reported; the default -3 dB means the sub-harmonic band reaches at
        least half the fundamental band's integrated energy.
        """
        events: list[SubharmonicEvent] = []
        f0 = float(main_frequency_hz if main_frequency_hz is not None else self.main_frequency_hz)
        if f0 <= 0 or not self.frames:
            return events
        times = np.asarray(self.mr_frame_times_s, dtype=float)
        fund_half_width = CavitationVisualizationService.fundamental_window_hz(f0)
        sub_half_width = CavitationVisualizationService.subharmonic_window_hz(f0)
        for i, frame in enumerate(self.frames):
            if channel < 0 or channel >= len(frame.channels):
                continue
            freq = np.asarray(frame.frequency_hz, dtype=float)
            amp = np.asarray(frame.channels[channel], dtype=float)
            if freq.size < 4 or amp.size != freq.size:
                continue
            fund_energy = CavitationVisualizationService.band_energy(freq, amp, f0 - fund_half_width, f0 + fund_half_width)
            sub_energy = CavitationVisualizationService.band_energy(freq, amp, f0 / 2.0 - sub_half_width, f0 / 2.0 + sub_half_width)
            if not (np.isfinite(fund_energy) and np.isfinite(sub_energy)):
                continue
            positive = amp[np.isfinite(amp) & (amp > 0)]
            noise = float(np.nanmedian(positive)) if positive.size else 0.0
            sub_mask = np.abs(freq - f0 / 2.0) <= sub_half_width
            sub_peak_amp = float(np.nanmax(amp[sub_mask])) if np.any(sub_mask) else 0.0
            if sub_energy <= 0.0 and fund_energy <= 0.0:
                continue
            ratio_db = CavitationVisualizationService.energy_ratio_db(sub_energy, fund_energy)
            if not np.isfinite(ratio_db) or ratio_db < float(prominence_db):
                continue
            if sub_peak_amp < noise * self.SUBHARMONIC_MIN_NOISE_MULTIPLE:
                continue
            confidence = "high" if sub_energy >= fund_energy and sub_peak_amp >= noise * 5.0 else "moderate"
            events.append(SubharmonicEvent(
                frame_index=i,
                time_s=float(times[i]) if i < times.size else float("nan"),
                channel=int(channel),
                fundamental_hz=f0,
                subharmonic_hz=f0 / 2.0,
                fundamental_amplitude=fund_energy,
                subharmonic_amplitude=sub_energy,
                ratio_db=float(ratio_db),
                confidence=confidence,
            ))
        return events


class HydrophoneReplayService:
    """Decode CPC Spectrum containers without mixing Sonication SpectrumMsg data.

    Header fields of the FFT container are stable in the supplied exports:
    saved-measure count, 8 channels, 16384 acquisition samples, FFT processing
    length, sample rate and sonication frequency.  The vendor record payload is
    not publicly documented, therefore record slicing is isolated and labelled
    diagnostic.  All analysis is calculated from decoded CPC payloads only.
    """

    def __init__(self) -> None:
        self.vendor_reproduction = CpcVendorReproductionService()
        # R0116zze: one authoritative cache for accumulated-spectrum baselines.
        # It is reset whenever a different replay object is analyzed so old-study
        # data can never leak into a newly loaded export.
        self._accumulated_prefix_replay_id: int | None = None
        self._accumulated_prefix_cache: dict[tuple[int, bool], tuple[np.ndarray, np.ndarray, np.ndarray, int]] = {}

    @staticmethod
    def _read_blob(path: Path | None) -> bytes:
        if path is None:
            return b""
        try:
            with gzip.open(path, "rb") as stream:
                return stream.read()
        except OSError:
            return path.read_bytes()

    @staticmethod
    def _pair_key(path: Path) -> tuple[str, str]:
        low=path.name.lower()
        base=path.name[:-4] if low.endswith(".dmp_fft") else path.name
        return str(path.parent.resolve()).lower(), base.lower()

    @staticmethod
    def _explicit_sonication_number(path: Path) -> int | None:
        for part in reversed(path.parts):
            compact=str(part).lower().replace("_","").replace("-","").replace(" ","")
            match=re.fullmatch(r"sonication(\d+)",compact)
            if match:
                return int(match.group(1))
        return None

    def select_files(self, cpc_files: list[Path], sonication_index: int, sonication_count: int) -> tuple[Path | None, Path | None]:
        groups: dict[tuple[str,str], dict[str,Path]]={}
        for p in sorted((Path(x) for x in cpc_files),key=lambda x:str(x).lower()):
            low=p.name.lower()
            if "spectrummsg" in low:
                continue
            if not (low.startswith("spectrum_") and (low.endswith(".dmp") or low.endswith(".dmp_fft"))):
                continue
            bucket=groups.setdefault(self._pair_key(p),{})
            if low.endswith(".dmp_fft"):
                bucket["fft"]=p
            else:
                bucket["raw"]=p

        pairs=[]
        for bucket in groups.values():
            primary=bucket.get("fft") or bucket.get("raw")
            if primary is not None:
                pairs.append((primary,bucket.get("fft"),bucket.get("raw")))
        pairs.sort(key=lambda item:str(item[0]).lower())
        if not pairs:
            return None,None

        target_number=int(sonication_index)+1
        explicit=[item for item in pairs if self._explicit_sonication_number(item[0])==target_number]
        if len(explicit) == 1:
            selected=explicit[0]
            return selected[1],selected[2]
        # R0116zx: never infer treatment identity from pair ordering.  The old
        # latest-N positional selector could silently bind calibration/pre-treatment
        # CPC measurements to a treatment Sonication.  Only an explicit
        # SonicationN path identity is accepted here.  A single-pair/single-
        # Sonication universe is also unambiguous and remains supported.
        if len(pairs) == 1 and int(sonication_count or 0) <= 1:
            selected=pairs[0]
            return selected[1],selected[2]
        return None,None

    def build(self, cpc_files: list[Path], sonication_index: int, sonication_count: int) -> CpcHydrophoneReplay:
        fft_path, raw_path = self.select_files(cpc_files, sonication_index, sonication_count)
        return self.build_direct(fft_path=fft_path, raw_path=raw_path)

    def build_direct(self, fft_path: Path | None, raw_path: Path | None, progress_callback=None, *, include_vendor_validation: bool = True) -> CpcHydrophoneReplay:
        """Decode an explicitly selected Spectrum dump pair.

        This is used by the standalone Spectrum Dump Analyzer so file/folder/ZIP
        selection does not depend on treatment-to-sonication positional mapping.
        """
        result = CpcHydrophoneReplay(source_fft=fft_path, source_raw=raw_path)
        def progress(value: int, message: str):
            if progress_callback is not None:
                try: progress_callback(int(value), str(message))
                except Exception: pass
        progress(3, "Reading CPC Spectrum headers…")
        calibration = None
        if fft_path is not None:
            calibration = HydrophoneCalibrationService().read(next((p for p in fft_path.parents if p.name.lower() == "cpcfiles"), fft_path.parent))
            result.calibration_available = bool(calibration.available)
            result.calibration_ini = calibration.calibration_ini
            result.response_ini = calibration.response_ini
            result.spectrum_coef = float(calibration.spectrum_coef)
            result.spectrum_factors = tuple(float(v) for v in calibration.spectrum_factors)
            result.receiver_enabled = tuple(bool(v) for v in calibration.is_enabled)
            result.response_point_count = int(calibration.response_frequency_hz.size)
        fft_blob = self._read_blob(fft_path)
        progress(10, "Reading FFT container…")
        if len(fft_blob) < 40:
            result.note = "No valid CPC Spectrum_*.dmp_FFT container was mapped."
            return result

        first, frame_count, channel_count, total_samples, processing, sample_rate = struct.unpack("<6I", fft_blob[:24])
        main_frequency = struct.unpack("<d", fft_blob[32:40])[0]
        result.channel_count = int(channel_count)
        result.sampling_frequency_hz = float(sample_rate)
        result.main_frequency_hz = float(main_frequency)
        result.declared_frame_count = int(frame_count)
        result.declared_message_count = int(frame_count)
        result.total_samples = int(total_samples)
        if channel_count != 8 or frame_count <= 0:
            result.note = f"Unsupported CPC FFT header: channels={channel_count}, measures={frame_count}."
            return result

        config = self._load_acquisition_config(raw_path or fft_path)
        graph_low_hz = float(config.get("graph_low_hz", 0.0))
        graph_high_hz = float(config.get("graph_high_hz", sample_rate / 2.0))
        progress(18, "Decoding 8-channel FFT snapshots…")
        fft_frames = self._decode_fft_payload(
            fft_blob[40:], frame_count, channel_count, sample_rate, graph_low_hz, graph_high_hz,
            vendor_bands=None, include_vendor_energy=True,
        )
        result.decoded_snapshot_count = len(fft_frames)
        if fft_frames:
            axis = np.asarray(fft_frames[0][0], float)
            if axis.size:
                result.frequency_start_hz = float(axis[0])
                result.frequency_end_hz = float(axis[-1])
                result.frequency_spacing_hz = float(np.median(np.diff(axis))) if axis.size > 1 else None
                # If the first record differs from the simple Acquisition.ini
                # linspace, it came from embedded vendor graph metadata.
                configured_spacing = ((graph_high_hz - graph_low_hz) / axis.size) if graph_high_hz > graph_low_hz else None
                if result.frequency_spacing_hz is not None and configured_spacing is not None:
                    result.frequency_axis_config_delta_hz = float(result.frequency_spacing_hz - configured_spacing)
                    result.frequency_axis_source = (
                        "Embedded CPC graph metadata" if abs(result.frequency_axis_config_delta_hz) > 1e-6
                        else "Embedded CPC graph metadata / Acquisition.ini consistent"
                    )
                else:
                    result.frequency_axis_source = "CPC graph axis"
                nearest = int(np.argmin(np.abs(axis - result.main_frequency_hz))) if result.main_frequency_hz > 0 else 0
                if result.main_frequency_hz > 0:
                    result.main_frequency_bin_hz = float(axis[nearest])
                    result.main_frequency_bin_error_hz = float(axis[nearest] - result.main_frequency_hz)
                fft_output_graph = config.get("fft_output_graph")
                if fft_output_graph and fft_output_graph > 0 and sample_rate > 0:
                    result.theoretical_fft_spacing_hz = float(sample_rate / fft_output_graph)
                    if result.frequency_spacing_hz is not None:
                        result.embedded_vs_theoretical_spacing_delta_hz = float(result.frequency_spacing_hz - result.theoretical_fft_spacing_hz)
        # All supplied CPC 6.33 exports show an exact 2:1 relation between the
        # header counter and validated 8CH spectrum snapshots. The header field
        # therefore represents paired message entries, not independent FFT frames.
        if fft_frames and len(fft_frames) == (frame_count + 1) // 2:
            result.messages_per_snapshot = 2
            result.final_snapshot_has_single_message = bool(frame_count % 2)
        elif fft_frames:
            result.messages_per_snapshot = max(1, round(frame_count / len(fft_frames)))
        progress(30, f"Decoded {len(fft_frames)} FFT snapshot(s); reading measurement history…")
        raw_blob = self._read_blob(raw_path)
        raw_frames = self._decode_raw_payload(raw_blob, len(fft_frames), channel_count, total_samples)
        result.acquisition_interval_s = float(config.get("acquire_interval_ms", 10.0)) / 1000.0
        timeline, timeline_info = self._decode_raw_timeline(raw_blob, int(first), channel_count)
        result.raw_timeline_channels = timeline
        if timeline:
            result.raw_timeline_time_s = np.arange(len(timeline[0]), dtype=float) * result.acquisition_interval_s
        result.raw_container_total_measurements = int(timeline_info.get("total_measurements", 0))
        result.raw_container_saved_measurements = int(timeline_info.get("saved_measurements", 0))
        result.raw_structure_note = str(timeline_info.get("note", ""))
        result.raw_history_pairs = list(timeline_info.get("pairs", []))
        progress(42, "Decoding CPC measurement history and vendor profile…")
        result.vendor_profile = self.vendor_reproduction.read_profile(fft_path or raw_path, result.main_frequency_hz)
        if include_vendor_validation:
            progress(52, "Validating vendor Band0 history against acquisition log…")
            result.vendor_history_validation = self.vendor_reproduction.validate_saved_band0_history(
                fft_path or raw_path, result.raw_timeline_channels, result.vendor_profile
            )
            preferred_session = result.vendor_history_validation.log_session_index if result.vendor_history_validation is not None else None
            progress(72, "Validating cavitation power-control events…")
            result.vendor_control_validation = self.vendor_reproduction.validate_power_control(
                fft_path or raw_path, result.vendor_profile, preferred_session_index=preferred_session
            )
            if result.vendor_history_validation is not None:
                result.vendor_band0_exact = result.vendor_history_validation.status.startswith("EXACT")
                result.vendor_band0_weighted = np.asarray(result.vendor_history_validation.weighted_history, float)
                result.vendor_display_rule1 = np.asarray(result.vendor_history_validation.normalized_display_rule1, float)
                display2 = result.vendor_history_validation.display_rule_histories.get(2, np.asarray([], dtype=float))
                result.vendor_display_rule2 = np.asarray(display2, float)
                band1 = result.vendor_history_validation.weighted_band_histories_from_log.get(1, np.asarray([], dtype=float))
                result.vendor_band1_log_exact = np.asarray(band1, float)
                band2 = result.vendor_history_validation.sparse_control_rule_histories.get(2, np.asarray([], dtype=float))
                result.vendor_band2_log_events = np.asarray(band2, float)
        else:
            progress(54, "Primary FFT data decoded; deferring Acquisition_Brain validation…")
        embedded_energy_errors = []
        for index, frame_payload in enumerate(fft_frames):
            freq, channels, embedded_band_energies = frame_payload
            raw = raw_frames[index] if index < len(raw_frames) else []
            calibrated_channels = [
                calibration.apply(freq, values, channel_index) if calibration is not None and calibration.available else np.asarray(values, dtype=float)
                for channel_index, values in enumerate(channels)
            ]
            original_channels = [np.asarray(values, dtype=float).copy() for values in channels]
            frame = CpcHydrophoneFrame(index, freq, calibrated_channels, uncalibrated_channels=original_channels, raw_channels=raw, vendor_band_energies=np.asarray(embedded_band_energies, dtype=float))
            result.frames.append(frame)
        result.vendor_embedded_band_energy_available = bool(result.frames) and all(np.asarray(f.vendor_band_energies).shape == (8, 4) for f in result.frames)

        # Validate the four per-channel vendor band energies embedded after each
        # 8CH FFT snapshot. The values must equal the sum of displayed FFT bins
        # inside HARMONICS_BANDWIDTHS to float precision. This proves that the
        # CGA energy calculation can be reproduced directly from the FFT graph.
        if result.vendor_profile is not None and result.frames:
            for frame in result.frames:
                if frame.vendor_band_energies.shape != (8, 4):
                    continue
                for band in result.vendor_profile.bands[:4]:
                    if not (0 <= band.index < 4):
                        continue
                    mask = (frame.frequency_hz >= band.low_hz) & (frame.frequency_hz <= band.high_hz)
                    if not np.any(mask):
                        continue
                    for ch in range(min(8, len(frame.uncalibrated_channels))):
                        calculated = float(np.sum(np.asarray(frame.uncalibrated_channels[ch], dtype=np.float32)[mask], dtype=np.float32))
                        embedded = float(frame.vendor_band_energies[ch, band.index])
                        if np.isfinite(calculated) and np.isfinite(embedded):
                            embedded_energy_errors.append(abs(calculated - embedded))
            if embedded_energy_errors:
                result.vendor_embedded_band_energy_max_error = float(max(embedded_energy_errors))
                result.vendor_embedded_band_energy_validated = result.vendor_embedded_band_energy_max_error <= 5e-8

        # Map FFT snapshots back to the 10-ms Band0 history.  Prefer the
        # vendor-weighted fingerprint when the INI is available, but do not
        # require it: SpectrumDumps-only mode can match the complete 8CH Band0
        # vector directly against the raw companion history.  This preserves
        # real timing/gaps without inventing a uniform FFT clock.
        if result.frames and result.raw_timeline_channels and len(result.raw_timeline_channels) >= 8:
            history_matrix=np.vstack([np.asarray(ch,float) for ch in result.raw_timeline_channels[:8]]).T
            history_len=history_matrix.shape[0]
            weighted_history=np.asarray(result.vendor_band0_weighted,float)
            weights=None
            if result.vendor_profile and result.vendor_profile.increase_rule0 is not None and weighted_history.size:
                weights=np.asarray(result.vendor_profile.increase_rule0.weights[:,0],float)
            last_index=-1; mapping_errors=[]; mapped=0
            for frame in result.frames:
                energies=np.asarray(frame.vendor_band_energies,float)
                if energies.shape != (8,4) or last_index+1 >= history_len:
                    continue
                candidates=np.arange(last_index+1,history_len,dtype=int)
                if weights is not None and weighted_history.size >= history_len:
                    fingerprint=float(np.dot(energies[:,0],weights))
                    errs=np.abs(weighted_history[candidates]-fingerprint)
                else:
                    fingerprint=np.asarray(energies[:,0],float)
                    values=history_matrix[candidates,:]
                    scale=np.maximum(np.nanmax(np.abs(fingerprint)),1e-12)
                    errs=np.nanmax(np.abs(values-fingerprint[None,:]),axis=1)/scale
                finite=np.isfinite(errs); candidates=candidates[finite]; errs=errs[finite]
                if candidates.size == 0:
                    continue
                pos=int(np.argmin(errs)); best_index=int(candidates[pos]); best_error=float(errs[pos])
                frame.acquisition_history_index=best_index
                frame.acquisition_cycle=best_index+1
                frame.acquisition_time_s=best_index*result.acquisition_interval_s
                last_index=best_index; mapping_errors.append(best_error); mapped+=1
            if mapping_errors:
                result.snapshot_cycle_mapping_max_error=float(max(mapping_errors))
                # weighted error is absolute energy; vector fallback is relative.
                tolerance=5e-8 if weights is not None else 1e-5
                result.snapshot_cycle_mapping_validated=mapped==len(result.frames) and result.snapshot_cycle_mapping_max_error <= tolerance

        progress(88, "Finalizing synchronized replay indices…")
        result.channel_reference_levels = self._references(result.frames)
        result.decoder_confidence = "validated_fft" if result.frames else "failed"
        result.raw_adc_available = any(f.raw_channels for f in result.frames)
        expected_adc_bytes = int(result.raw_container_saved_measurements or frame_count) * int(total_samples) * 2
        if not result.raw_adc_available:
            result.raw_adc_unavailable_reason = (
                f"The exported raw companion decompresses to {len(raw_blob):,} bytes, while even "
                f"{int(result.raw_container_saved_measurements or frame_count)} saved measurements × "
                f"{total_samples} int16 samples require at least {expected_adc_bytes:,} bytes before "
                "record envelopes. The 2048-sample/channel A/D payload is therefore not present in "
                "this export container; only measurement-history arrays are available."
            )
        if any(f.raw_channels for f in result.frames):
            result.decoder_confidence = "validated_fft_and_raw"
        raw_state = "validated raw waveform decoded" if any(f.raw_channels for f in result.frames) else ("validated 8CH measurement timeline decoded; per-measure waveform still under structural validation" if result.raw_timeline_channels else "raw waveform not verified; raw container not decoded")
        result.note = (
            f"Independent CPC 8CH analyzer: {len(result.frames)} validated 8CH FFT snapshots "
            f"from {frame_count} message entries (paired per snapshot; final entry may be unpaired), {raw_state}, "
            f"Fs={sample_rate/1e6:.3f} MHz, configured graph={graph_low_hz/1e6:.3f}–{graph_high_hz/1e6:.3f} MHz, sonication={main_frequency/1e6:.3f} MHz. "
            + (f"Frequency axis={result.frequency_axis_source}: {result.frequency_start_hz/1e3:.3f}–{result.frequency_end_hz/1e3:.3f} kHz, Δf={result.frequency_spacing_hz:.6f} Hz, nearest f0 bin error={result.main_frequency_bin_error_hz:+.3f} Hz. " if result.frequency_start_hz is not None and result.frequency_spacing_hz is not None and result.frequency_end_hz is not None and result.main_frequency_bin_error_hz is not None else "")
            + (f"FFT-theoretical Δf={result.theoretical_fft_spacing_hz:.6f} Hz; embedded-display delta={result.embedded_vs_theoretical_spacing_delta_hz:+.6f} Hz. " if result.theoretical_fft_spacing_hz is not None and result.embedded_vs_theoretical_spacing_delta_hz is not None else "")
            + (f"Vendor cavitation history={result.vendor_history_validation.status}: {result.vendor_history_validation.note} " if result.vendor_history_validation is not None else "")
            + (f"Embedded Band0-3 energies validated from FFT-bin sums (max error={result.vendor_embedded_band_energy_max_error:.3g}). " if result.vendor_embedded_band_energy_validated and result.vendor_embedded_band_energy_max_error is not None else "")
            + (f"FFT snapshots mapped exactly to 10-ms acquisition cycles by Band0 fingerprint (max error={result.snapshot_cycle_mapping_max_error:.3g}). " if result.snapshot_cycle_mapping_validated and result.snapshot_cycle_mapping_max_error is not None else "")
            + (f"Cavitation power-control rules={result.vendor_control_validation.status}: {result.vendor_control_validation.note} " if result.vendor_control_validation is not None else "")
            + ("Acquisition_Brain numerical validation deferred so primary Spectrum data can be displayed immediately. " if not include_vendor_validation else "")
            + "FFT blocks and the independent 8CH measurement-history arrays are structurally validated; spectrogram and editable band energy are calculated locally. "
            "The proprietary per-record envelope remains diagnostic; channel labels CH0–CH7 are preserved, physical positions are not inferred. "
            + (f"Calibration applied from {calibration.calibration_ini.name}; SpectrumFactor={calibration.spectrum_factors}." if calibration is not None and calibration.available and calibration.calibration_ini else "Calibration file not found; unity coefficients used.")
        )
        progress(100, "Spectrum replay ready")
        return result

    @staticmethod
    def _load_acquisition_config(raw_path: Path | None) -> dict[str, float]:
        """Read CPC Acquisition.ini values from the extracted package when present."""
        result: dict[str, float] = {}
        if raw_path is None:
            return result
        candidates = []
        for parent in [raw_path.parent, *raw_path.parents[:4]]:
            candidates.extend([parent / "App" / "Ini" / "Acquisition.ini", parent / "Acquisition.ini"])
        for ini in candidates:
            if not ini.exists():
                continue
            try:
                for raw_line in ini.read_text(encoding="utf-8", errors="ignore").splitlines():
                    line = raw_line.split(";", 1)[0].strip()
                    if "=" not in line:
                        continue
                    key, value = [x.strip() for x in line.split("=", 1)]
                    if key.lower() == "acquireinterval":
                        result["acquire_interval_ms"] = float(value)
                    elif key.lower() == "sizeofmeasurmentdata":
                        result["measurement_samples_total"] = float(value)
                    elif key.lower() == "sizeofoutputgraph":
                        result["fft_output_graph"] = float(value)
                    elif key.lower() == "f1forgraph":
                        result["graph_low_hz"] = float(value)
                    elif key.lower() == "f2forgraph":
                        result["graph_high_hz"] = float(value)
                return result
            except Exception:
                continue
        return result

    @staticmethod
    def _decode_fft_payload(payload: bytes, frame_count: int, channel_count: int, sample_rate: float, graph_low_hz: float = 0.0, graph_high_hz: float | None = None, vendor_bands=None, include_vendor_energy: bool = False):
        """Decode validated CPC FFT channel blocks.

        Real CPC exports store each channel spectrum as a 32-bit bin-count marker
        (normally 256), followed by that many float32 bins.  Channel blocks are
        separated by a fixed metadata envelope, and eight consecutive markers
        form one saved measure.  This parser intentionally rejects the old
        equal-slice heuristic.
        """
        if channel_count != 8 or len(payload) < 4096:
            return []
        blob = memoryview(payload)
        markers=[]

        # R0116zf: the original decoder walked the complete FFT container in a
        # Python loop, unpacking one uint32 every four bytes.  On large clinical
        # CPC dumps that means millions/tens-of-millions of Python iterations
        # before the first graph can be published.  Preserve the exact same
        # 4-byte-aligned marker contract, but locate candidate uint32 values in
        # one NumPy pass and only run the expensive float validation on those
        # candidates.  This is a performance change, not a format heuristic.
        aligned_size = (len(blob) // 4) * 4
        if aligned_size < 4:
            return []
        words = np.frombuffer(blob[:aligned_size], dtype='<u4')
        candidate_word_indices = np.flatnonzero((words >= 16) & (words <= 8192))
        for word_index in candidate_word_indices:
            off = int(word_index) * 4
            n = int(words[int(word_index)])
            end = off + 4 + n * 4
            if end > len(blob):
                continue
            vals=np.frombuffer(blob[off+4:end], dtype='<f4')
            finite=np.isfinite(vals)
            if finite.size and finite.mean() > .995 and np.nanmax(np.abs(vals[finite])) < 1e12:
                markers.append((off,n))
        groups=[]
        i=0
        while i+7 < len(markers):
            cand=markers[i:i+8]
            if len({n for _,n in cand})==1:
                gaps=np.diff([o for o,_ in cand])
                if np.all(gaps==gaps[0]) and gaps[0] >= 4+cand[0][1]*4:
                    groups.append(cand); i+=8; continue
            i+=1
        frames=[]
        for group_index, group in enumerate(groups[:frame_count]):
            bins=group[0][1]
            channels=[]
            valid=True
            embedded_starts=[]
            embedded_spacings=[]
            for off,n in group:
                arr=np.frombuffer(blob[off+4:off+4+n*4], dtype='<f4').astype(float)
                if len(arr)!=bins or not np.all(np.isfinite(arr)):
                    valid=False; break
                channels.append(np.abs(arr))
                if off >= 16:
                    try:
                        _yscale, spacing_raw, start_raw, _danger = struct.unpack_from('<4f', blob, off-16)
                        if 100.0 <= spacing_raw <= 20_000.0 and 50_000.0 <= start_raw <= 1_500_000.0:
                            embedded_spacings.append(float(spacing_raw)); embedded_starts.append(float(start_raw))
                        elif 0.0001 <= spacing_raw <= 0.020 and 0.05 <= start_raw <= 1.5:
                            embedded_spacings.append(float(spacing_raw)*1e6); embedded_starts.append(float(start_raw)*1e6)
                    except (struct.error, TypeError, ValueError):
                        pass
            if not valid: continue
            if len(embedded_starts) == channel_count and len(embedded_spacings) == channel_count:
                start_span=max(embedded_starts)-min(embedded_starts)
                spacing_span=max(embedded_spacings)-min(embedded_spacings)
                if start_span <= 1.0 and spacing_span <= 1.0:
                    low_hz=float(np.median(embedded_starts))
                    spacing_hz=float(np.median(embedded_spacings))
                    freq=low_hz + np.arange(bins,dtype=float)*spacing_hz
                    energies = HydrophoneReplayService._decode_embedded_band_energy_table(blob, group, groups[group_index + 1] if group_index + 1 < len(groups) else None)
                    frames.append((freq,channels,energies) if include_vendor_energy else (freq,channels))
                    continue
            high_hz = float(graph_high_hz if graph_high_hz is not None else sample_rate / 2.0)
            low_hz = float(graph_low_hz)
            if not np.isfinite(low_hz) or not np.isfinite(high_hz) or high_hz <= low_hz:
                low_hz, high_hz = 0.0, sample_rate / 2.0
            # Fallback only: use the configured GUI window when per-record axis
            # metadata is absent. Embedded metadata is the authoritative source.
            freq=np.linspace(low_hz, high_hz, bins, endpoint=False, dtype=float)
            energies = HydrophoneReplayService._decode_embedded_band_energy_table(blob, group, groups[group_index + 1] if group_index + 1 < len(groups) else None)
            frames.append((freq,channels,energies) if include_vendor_energy else (freq,channels))
        return frames

    @staticmethod
    def _decode_embedded_band_energy_table(blob: memoryview, group, next_group=None) -> np.ndarray:
        """Decode the vendor 8CH × 4-band energy table following one FFT group.

        CPC 6.33 stores eight 36-byte records after each 8-channel graph. Each
        record begins with uint32 band_count=4 followed by float32 Band0..Band3.
        We locate the table structurally rather than relying on a hard-coded
        absolute file offset.
        """
        if not group or len(group) != 8:
            return np.empty((0, 0), dtype=float)
        last_off, last_bins = group[-1]
        search_start = int(last_off + 4 + last_bins * 4)
        search_end = int(next_group[0][0]) if next_group else len(blob)
        record_size = 36
        table_size = record_size * 8
        if search_end - search_start < table_size:
            return np.empty((0, 0), dtype=float)
        # R0116zf: do not walk the envelope two bytes at a time in Python.
        # For the final FFT group ``search_end`` can be the end of a very large
        # decompressed CPC file, turning one missing table into tens of millions
        # of Python iterations. Locate the uint32 band_count=4 signature with
        # bytes.find() (C implementation), then structurally validate the eight
        # 36-byte rows exactly as before. Searching every byte is at least as
        # permissive as the former 2-byte stepping and does not impose a new
        # alignment heuristic.
        backing = blob.obj if isinstance(blob.obj, (bytes, bytearray)) else blob.tobytes()
        needle = struct.pack('<I', 4)
        last_start = search_end - table_size
        start = backing.find(needle, search_start, last_start + 4)
        while start >= 0 and start <= last_start:
            rows=[]; valid=True
            for ch in range(8):
                off=start + ch * record_size
                try:
                    count=struct.unpack_from('<I', blob, off)[0]
                    values=np.asarray(struct.unpack_from('<4f', blob, off+4), dtype=float)
                except struct.error:
                    valid=False; break
                if count != 4 or not np.all(np.isfinite(values)) or np.any(values < 0) or np.any(values > 1.0):
                    valid=False; break
                rows.append(values)
            if valid:
                return np.vstack(rows)
            start = backing.find(needle, start + 1, last_start + 4)
        return np.empty((0, 0), dtype=float)


    @staticmethod
    def _decode_raw_timeline(blob: bytes, expected_total_measurements: int, channel_count: int) -> tuple[list[np.ndarray], dict[str, object]]:
        """Decode the CPC .dmp measurement-history arrays without calling them ADC waveforms.

        In the supplied CPC 6.33 export the raw companion container begins with a
        compact header and then contains sixteen equally spaced arrays whose
        element count equals the FFT container's total-measurement counter.  The
        arrays occur as eight pairs: an all-zero optional spectrum-signal history
        followed by the calculated-energy history for CH0..CH7.  This matches the
        CPC screen's Energy-per-Band timeline and the Acquisition.ini setting that
        external modules receive periodic Spectrum messages.

        This parser validates count markers, equal spacing, finite float32 payloads,
        eight non-zero channel histories, and monotonic record geometry.  It does
        not mislabel these histories as a 2048-sample A/D waveform.
        """
        info: dict[str, object] = {"total_measurements": 0, "saved_measurements": 0, "note": ""}
        if len(blob) < 128 or channel_count != 8 or expected_total_measurements < 16:
            return [], info
        try:
            saved = int(struct.unpack_from("<I", blob, 0)[0])
        except struct.error:
            return [], info
        marker = struct.pack("<I", expected_total_measurements)
        offsets = []
        start = 0
        while True:
            pos = blob.find(marker, start)
            if pos < 0:
                break
            if pos % 4 == 0 and pos + 4 + expected_total_measurements * 4 <= len(blob):
                values = np.frombuffer(blob, dtype="<f4", count=expected_total_measurements, offset=pos + 4)
                if np.all(np.isfinite(values)) and float(np.max(np.abs(values))) < 1e6:
                    offsets.append(pos)
            start = pos + 1
        if len(offsets) < 16:
            info["note"] = f"Only {len(offsets)} validated history arrays found; 16 required."
            return [], info
        # Select a 16-array run with near-constant spacing.
        run = None
        for i in range(len(offsets) - 15):
            cand = offsets[i:i+16]
            gaps = np.diff(cand)
            if np.max(gaps) - np.min(gaps) <= 8 and np.median(gaps) >= 4 + expected_total_measurements * 4:
                run = cand
                break
        if run is None:
            info["note"] = "History markers exist but no stable 16-array CPC layout was found."
            return [], info
        arrays = [np.frombuffer(blob, dtype="<f4", count=expected_total_measurements, offset=o+4).astype(float, copy=True) for o in run]
        # The 16 arrays form eight stable pairs. Their semantic labels are not
        # stored in the export, so retain both arrays and expose the non-zero
        # member as a generic measurement-history series rather than calling it
        # calculated energy.
        pairs = [(arrays[2*ch], arrays[2*ch+1]) for ch in range(8)]
        history = [b if float(np.std(b)) >= float(np.std(a)) else a for a, b in pairs]
        if any(not np.all(np.isfinite(a)) for a in history):
            return [], info
        if sum(float(np.std(a)) > 0.0 for a in history) < 6:
            info["note"] = "CPC history arrays were found but too few channels carry signal."
            return [], info
        info.update({
            "total_measurements": expected_total_measurements,
            "saved_measurements": saved,
            "pairs": pairs,
            "note": (f"Validated CPC history layout: eight channel-pairs × {expected_total_measurements} measurements; "
                     f"container header saved-count={saved}; marker spacing≈{int(np.median(np.diff(run)))} bytes. "
                     "These are measurement histories, not the 2048-sample per-channel A/D waveform."),
        })
        return history, info

    @staticmethod
    def _decode_raw_payload(blob: bytes, expected_frames: int, channel_count: int, expected_samples: int = 16384) -> list[list[np.ndarray]]:
        """Decode raw samples only when a full, structurally valid 8CH payload exists.

        The supplied .dmp file is an energy/packet stream rather than a verified
        16384-sample waveform container.  Returning no data is safer than showing
        header bytes as ADC samples.  Future format-specific decoders can be added
        here without changing the UI/API.
        """
        if len(blob) < 40 or expected_frames <= 0 or channel_count != 8:
            return []
        required=expected_samples*channel_count*2
        payload=blob[40:]
        if len(payload) < required*expected_frames:
            return []
        # Accept only exact contiguous int16 frames; reject envelopes/remainders.
        if len(payload) != required*expected_frames:
            return []
        out=[]
        for i in range(expected_frames):
            chunk=payload[i*required:(i+1)*required]
            matrix=np.frombuffer(chunk,dtype='<i2').reshape(expected_samples,channel_count).T
            out.append([row.astype(float,copy=True) for row in matrix])
        return out

    @staticmethod
    def _references(frames: list[CpcHydrophoneFrame]) -> list[float]:
        refs: list[float] = []
        tiny = np.finfo(float).tiny
        for ch in range(8):
            levels = []
            for frame in frames:
                if ch >= len(frame.channels):
                    continue
                amp = np.asarray(frame.channels[ch], dtype=float)
                freq = np.asarray(frame.frequency_hz, dtype=float)
                mask = np.isfinite(amp) & (amp > 0) & np.isfinite(freq) & (freq >= 50_000) & (freq <= 1_000_000)
                if np.any(mask):
                    levels.append(float(np.percentile(amp[mask], 99.5)))
            refs.append(max(float(np.median(levels)) if levels else 1.0, tiny))
        return refs

    @staticmethod
    def spectrum_values(frame: CpcHydrophoneFrame, channel: int, calibrated: bool = True) -> np.ndarray:
        source = frame.channels if calibrated or not frame.uncalibrated_channels else frame.uncalibrated_channels
        return np.asarray(source[channel], dtype=float)

    @staticmethod
    def calibration_ratio(frame: CpcHydrophoneFrame, channel: int) -> np.ndarray:
        calibrated = HydrophoneReplayService.spectrum_values(frame, channel, True)
        raw = HydrophoneReplayService.spectrum_values(frame, channel, False)
        n = min(len(calibrated), len(raw))
        ratio = np.ones(n, dtype=float)
        valid = np.isfinite(raw[:n]) & (np.abs(raw[:n]) > np.finfo(float).tiny) & np.isfinite(calibrated[:n])
        ratio[valid] = calibrated[:n][valid] / raw[:n][valid]
        return ratio

    @staticmethod
    def absolute_db(frame: CpcHydrophoneFrame, channel: int, calibrated: bool = True) -> np.ndarray:
        amp = np.abs(HydrophoneReplayService.spectrum_values(frame, channel, calibrated))
        return 20.0 * np.log10(np.maximum(amp, np.finfo(float).tiny))

    @staticmethod
    def relative_db(replay: CpcHydrophoneReplay, frame: CpcHydrophoneFrame, channel: int) -> np.ndarray:
        amp = np.asarray(frame.channels[channel], dtype=float)
        ref = max(float(replay.channel_reference_levels[channel]), np.finfo(float).tiny)
        floor = ref * 10.0 ** (replay.display_db_min / 20.0)
        safe = np.maximum(np.where(np.isfinite(amp), np.abs(amp), 0.0), floor)
        return np.clip(20.0 * np.log10(safe / ref), replay.display_db_min, replay.display_db_max)

    def _accumulated_amplitude_stats(
        self, replay: CpcHydrophoneReplay, channel: int, calibrated: bool = True
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, int]:
        """Return prefix sum / squared-sum / finite-count for linear amplitude."""
        replay_id = id(replay)
        if self._accumulated_prefix_replay_id != replay_id:
            self._accumulated_prefix_cache.clear()
            self._accumulated_prefix_replay_id = replay_id
        ch = max(0, min(int(channel), replay.channel_count - 1))
        key = (ch, bool(calibrated))

        # R0116zzg5: prefix spectra can be expensive to construct (all FFT frames
        # x all bins).  Keep a replay-owned cache as well as the service-local
        # cache so a background worker can precompute it and the GUI service can
        # reuse the exact numpy arrays without rebuilding them on the Qt thread.
        shared = replay._accumulated_prefix_cache
        if not isinstance(shared, dict):
            shared = {}
            replay._accumulated_prefix_cache = shared
        cached = self._accumulated_prefix_cache.get(key)
        if cached is None:
            cached = shared.get(key)
            if cached is not None:
                self._accumulated_prefix_cache[key] = cached
        if cached is not None:
            return cached
        arrays = [
            np.abs(np.asarray(self.spectrum_values(frame, ch, calibrated), dtype=float))
            for frame in replay.frames
        ]
        min_bins = min((len(values) for values in arrays), default=0)
        if min_bins <= 0:
            empty = np.empty((0, 0), dtype=float)
            cached = (empty, empty, empty, 0)
            self._accumulated_prefix_cache[key] = cached
            return cached
        matrix = np.vstack([values[:min_bins] for values in arrays])
        finite = np.isfinite(matrix)
        clean = np.where(finite, matrix, 0.0)
        prefix_sum = np.cumsum(clean, axis=0)
        prefix_sq_sum = np.cumsum(clean * clean, axis=0)
        prefix_count = np.cumsum(finite.astype(np.int32), axis=0)
        cached = (prefix_sum, prefix_sq_sum, prefix_count, min_bins)
        self._accumulated_prefix_cache[key] = cached
        shared[key] = cached
        return cached

    @staticmethod
    def _prefix_mean_rms_std(
        prefix_sum: np.ndarray, prefix_sq_sum: np.ndarray, prefix_count: np.ndarray, row: int
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        tiny = np.finfo(float).tiny
        counts = prefix_count[row].astype(float)
        mean = np.divide(prefix_sum[row], counts, out=np.zeros(prefix_sum.shape[1], dtype=float), where=counts > 0)
        mean_sq = np.divide(prefix_sq_sum[row], counts, out=np.zeros(prefix_sum.shape[1], dtype=float), where=counts > 0)
        rms = np.sqrt(np.maximum(mean_sq, 0.0))
        variance = np.maximum(mean_sq - mean * mean, 0.0)
        std = np.sqrt(variance)
        return np.maximum(mean, tiny), np.maximum(rms, tiny), np.maximum(std, 0.0)

    def accumulated_average_delta_db(
        self,
        replay: CpcHydrophoneReplay,
        frame_index: int,
        channel: int,
        calibrated: bool = True,
    ) -> np.ndarray:
        """Current spectrum versus the accumulated mean of all PRIOR frames."""
        if not replay.frames:
            return np.array([], dtype=float)
        idx = max(0, min(int(frame_index), len(replay.frames) - 1))
        prefix_sum, prefix_sq_sum, prefix_count, min_bins = self._accumulated_amplitude_stats(replay, channel, calibrated)
        if min_bins <= 0:
            return np.array([], dtype=float)
        if idx == 0:
            return np.zeros(min_bins, dtype=float)
        baseline, _rms, _std = self._prefix_mean_rms_std(prefix_sum, prefix_sq_sum, prefix_count, idx - 1)
        tiny = np.finfo(float).tiny
        ch = max(0, min(int(channel), replay.channel_count - 1))
        current = np.abs(np.asarray(self.spectrum_values(replay.frames[idx], ch, calibrated), dtype=float))[:min_bins]
        current = np.maximum(np.where(np.isfinite(current), current, tiny), tiny)
        return 20.0 * np.log10(current / baseline)

    def accumulated_rms_db(
        self, replay: CpcHydrophoneReplay, frame_index: int, channel: int, calibrated: bool = True, relative: bool = False
    ) -> np.ndarray:
        """Cumulative RMS spectrum from frame 0 through the current frame."""
        if not replay.frames:
            return np.array([], dtype=float)
        idx = max(0, min(int(frame_index), len(replay.frames) - 1))
        prefix_sum, prefix_sq_sum, prefix_count, min_bins = self._accumulated_amplitude_stats(replay, channel, calibrated)
        if min_bins <= 0:
            return np.array([], dtype=float)
        _mean, rms, _std = self._prefix_mean_rms_std(prefix_sum, prefix_sq_sum, prefix_count, idx)
        if relative:
            ch = max(0, min(int(channel), replay.channel_count - 1))
            ref = max(float(replay.channel_reference_levels[ch]), np.finfo(float).tiny)
            return np.clip(20.0 * np.log10(rms / ref), replay.display_db_min, replay.display_db_max)
        return 20.0 * np.log10(rms)

    def temporal_noise_rms_db(
        self, replay: CpcHydrophoneReplay, frame_index: int, channel: int, calibrated: bool = True, relative: bool = False
    ) -> np.ndarray:
        """Temporal residual RMS (standard deviation) per frequency bin.

        Stable spectral lines stay low while bins that fluctuate over time rise,
        making incoherent/random components easier to see.
        """
        if not replay.frames:
            return np.array([], dtype=float)
        idx = max(0, min(int(frame_index), len(replay.frames) - 1))
        prefix_sum, prefix_sq_sum, prefix_count, min_bins = self._accumulated_amplitude_stats(replay, channel, calibrated)
        if min_bins <= 0:
            return np.array([], dtype=float)
        _mean, _rms, std = self._prefix_mean_rms_std(prefix_sum, prefix_sq_sum, prefix_count, idx)
        tiny = np.finfo(float).tiny
        std = np.maximum(std, tiny)
        if relative:
            ch = max(0, min(int(channel), replay.channel_count - 1))
            ref = max(float(replay.channel_reference_levels[ch]), tiny)
            return np.clip(20.0 * np.log10(std / ref), replay.display_db_min, replay.display_db_max)
        return 20.0 * np.log10(std)

    def innovation_abs_zscore(
        self, replay: CpcHydrophoneReplay, frame_index: int, channel: int, calibrated: bool = True
    ) -> np.ndarray:
        """Absolute current innovation relative to PRIOR-frame mean/std, in sigma.

        At least two prior frames are required. Values above ~3 indicate a
        frequency bin that changed well beyond its prior temporal variability.
        The display is capped to avoid a zero-variance baseline dominating the plot.
        """
        if not replay.frames:
            return np.array([], dtype=float)
        idx = max(0, min(int(frame_index), len(replay.frames) - 1))
        prefix_sum, prefix_sq_sum, prefix_count, min_bins = self._accumulated_amplitude_stats(replay, channel, calibrated)
        if min_bins <= 0:
            return np.array([], dtype=float)
        if idx < 2:
            return np.zeros(min_bins, dtype=float)
        mean, _rms, std = self._prefix_mean_rms_std(prefix_sum, prefix_sq_sum, prefix_count, idx - 1)
        ch = max(0, min(int(channel), replay.channel_count - 1))
        current = np.abs(np.asarray(self.spectrum_values(replay.frames[idx], ch, calibrated), dtype=float))[:min_bins]
        current = np.where(np.isfinite(current), current, mean)
        scale_floor = np.maximum(mean * 1e-6, np.finfo(float).tiny)
        sigma = np.maximum(std, scale_floor)
        return np.clip(np.abs(current - mean) / sigma, 0.0, 25.0)

    def spectrogram(self, replay: CpcHydrophoneReplay, channel: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        if not replay.frames:
            return np.array([]), np.array([]), np.empty((0, 0))
        min_bins = min(len(f.channels[channel]) for f in replay.frames)
        matrix = np.vstack([self.relative_db(replay, f, channel)[:min_bins] for f in replay.frames])
        freq = replay.frames[0].frequency_hz[:min_bins]
        time = replay.sonication_frame_times_s
        return time, freq, matrix

    @staticmethod
    def vendor_band_energy(replay: CpcHydrophoneReplay, band_index: int) -> np.ndarray:
        """Return exact embedded vendor per-channel energy for Band0..Band3."""
        if not replay.frames or not (0 <= int(band_index) <= 3):
            return np.empty((0, replay.channel_count), dtype=float)
        out=np.full((len(replay.frames), replay.channel_count), np.nan, dtype=float)
        for i, frame in enumerate(replay.frames):
            energies=np.asarray(frame.vendor_band_energies, float)
            if energies.shape == (8,4):
                out[i,:8]=energies[:,int(band_index)]
        return out

    def band_energy(self, replay: CpcHydrophoneReplay, low_hz: float, high_hz: float) -> np.ndarray:
        output = np.full((len(replay.frames), replay.channel_count), np.nan, dtype=float)
        for i, frame in enumerate(replay.frames):
            freq = np.asarray(frame.frequency_hz, dtype=float)
            mask = (freq >= low_hz) & (freq <= high_hz)
            if not np.any(mask):
                continue
            for ch in range(min(replay.channel_count, len(frame.channels))):
                amp = np.asarray(frame.channels[ch], dtype=float)
                n = min(len(amp), len(mask))
                local = mask[:n]
                if np.any(local):
                    output[i, ch] = float(np.trapezoid(np.square(np.abs(amp[:n][local])), freq[:n][local]))
        return output

    def frame_statistics(self, replay: CpcHydrophoneReplay, frame_index: int, low_hz: float, high_hz: float) -> list[dict[str, float]]:
        if not replay.frames:
            return []
        frame = replay.frames[min(max(frame_index, 0), len(replay.frames)-1)]
        rows = []
        for ch in range(replay.channel_count):
            amp = self.spectrum_values(frame, ch, True)
            uncal = self.spectrum_values(frame, ch, False)
            freq = np.asarray(frame.frequency_hz, dtype=float)
            n = min(len(amp), len(freq)); amp = amp[:n]; freq = freq[:n]
            valid = np.isfinite(amp) & np.isfinite(freq)
            peak_i = int(np.argmax(np.where(valid, amp, -np.inf))) if np.any(valid) else 0
            mask = valid & (freq >= low_hz) & (freq <= high_hz)
            energy = float(np.trapezoid(np.square(amp[mask]), freq[mask])) if np.count_nonzero(mask) > 1 else float("nan")
            raw = np.asarray(frame.raw_channels[ch], dtype=float) if ch < len(frame.raw_channels) else np.array([])
            rows.append({
                "channel": float(ch),
                "raw_peak": float(np.max(np.abs(raw))) if raw.size else float("nan"),
                "raw_rms": float(np.sqrt(np.mean(np.square(raw)))) if raw.size else float("nan"),
                "dominant_hz": float(freq[peak_i]) if n else float("nan"),
                "peak_db": float(self.relative_db(replay, frame, ch)[peak_i]) if n else float("nan"),
                "band_energy": energy,
                "raw_spectrum_peak": float(np.nanmax(np.abs(uncal))) if uncal.size else float("nan"),
                "calibrated_spectrum_peak": float(np.nanmax(np.abs(amp))) if amp.size else float("nan"),
                "main_frequency_coefficient": float(self.calibration_ratio(frame, ch)[int(np.argmin(np.abs(freq - replay.main_frequency_hz)))]) if n and self.calibration_ratio(frame, ch).size else 1.0,
            })
        return rows
