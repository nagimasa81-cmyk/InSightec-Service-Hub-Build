from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np

from src.services.hydrophone_replay_service import HydrophoneReplayService


def main() -> int:
    parser = argparse.ArgumentParser(description='Validate exact CPC FFT Band0-3 energy and snapshot-cycle mapping')
    parser.add_argument('root', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    service = HydrophoneReplayService()
    fft_files = sorted(args.root.rglob('Spectrum_*.dmp_FFT'))
    lines=[]; exact_energy=0; exact_mapping=0
    for fft in fft_files:
        raw=Path(str(fft)[:-4])
        replay=service.build_direct(fft, raw if raw.exists() else None)
        if replay.vendor_embedded_band_energy_validated: exact_energy += 1
        if replay.snapshot_cycle_mapping_validated: exact_mapping += 1
        cycles=[f.acquisition_cycle for f in replay.frames if f.acquisition_cycle is not None]
        gaps=np.diff(cycles) if len(cycles)>1 else np.asarray([])
        lines.append(
            f'{fft.name}: snapshots={len(replay.frames)}; '
            f'Band0-3 exact={replay.vendor_embedded_band_energy_validated}; max_energy_error={replay.vendor_embedded_band_energy_max_error}; '
            f'cycle_map={replay.snapshot_cycle_mapping_validated}; max_map_error={replay.snapshot_cycle_mapping_max_error}; '
            f'cycle_range={cycles[0] if cycles else "-"}..{cycles[-1] if cycles else "-"}; '
            f'median_cycle_step={float(np.median(gaps)) if gaps.size else "-"}'
        )
    lines.append(f'RESULT: embedded Band0-3 EXACT {exact_energy}/{len(fft_files)}; snapshot-to-cycle EXACT {exact_mapping}/{len(fft_files)}')
    text='\n'.join(lines)+'\n'
    print(text,end='')
    if args.output:
        args.output.write_text(text,encoding='utf-8')
    return 0 if fft_files and exact_energy == len(fft_files) and exact_mapping == len(fft_files) else 1

if __name__ == '__main__':
    raise SystemExit(main())
