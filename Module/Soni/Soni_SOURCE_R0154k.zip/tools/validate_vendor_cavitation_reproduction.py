from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.services.hydrophone_replay_service import HydrophoneReplayService


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate vendor CPC Band0 / Display Rule 1 reproduction")
    parser.add_argument("root", type=Path, help="Extracted treatment export or CPCFiles folder")
    args = parser.parse_args()
    candidates = sorted(args.root.rglob("Spectrum_*.dmp_FFT"))
    if not candidates:
        print("FAIL: no Spectrum_*.dmp_FFT files found")
        return 2
    service = HydrophoneReplayService()
    passed = 0
    for fft in candidates:
        raw = Path(str(fft)[:-4])
        replay = service.build_direct(fft, raw if raw.exists() else None)
        val = replay.vendor_history_validation
        status = val.status if val else "Not validated"
        print(
            f"{fft.name}: {status}; f0={replay.main_frequency_hz/1000:.3f} kHz; "
            f"n={val.matched_samples if val else 0}; "
            f"r={val.correlation if val and val.correlation is not None else float('nan'):.9f}; "
            f"MAE={val.mae if val and val.mae is not None else float('nan'):.3g}; "
            f"DisplayRule1 r={val.display_rule1_correlation if val and val.display_rule1_correlation is not None else float('nan'):.9f}"
        )
        passed += int(bool(val and val.status.startswith("EXACT")))
    print(f"RESULT: EXACT {passed}/{len(candidates)}")
    return 0 if passed == len(candidates) else 1


if __name__ == "__main__":
    raise SystemExit(main())
