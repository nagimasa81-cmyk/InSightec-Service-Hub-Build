from __future__ import annotations

import argparse
from pathlib import Path
import re
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.core.spectrum_decoder import SharedSpectrumDecoder
from src.services.hydrophone_replay_service import HydrophoneReplayService


def _main_frequency(root: Path) -> float:
    # Prefer CPC FFT header because it is stored in the same acoustic dataset.
    fft = next(iter(sorted(root.rglob('Spectrum_*.dmp_FFT'))), None)
    if fft:
        replay = HydrophoneReplayService().build_direct(fft, None)
        if replay.main_frequency_hz > 0:
            return replay.main_frequency_hz
    for ini in root.rglob('Xd_*.ini'):
        text = ini.read_text(encoding='utf-8', errors='ignore')
        matches = re.findall(r'(?:Preferred|Recommended).*?([0-9]+(?:\.[0-9]+)?)\s*(MHz|kHz|Hz)?', text, re.I)
        if matches:
            value, unit = matches[-1]
            factor = 1e6 if unit.lower() == 'mhz' else 1e3 if unit.lower() == 'khz' else 1.0
            return float(value) * factor
    return 650000.0


def audit(root: Path) -> int:
    f0 = _main_frequency(root)
    decoder = SharedSpectrumDecoder()
    print(f'Frequency reproduction audit: {root}')
    print(f'Nominal f0: {f0/1e3:.3f} kHz')
    failures = 0
    messages = sorted(root.rglob('SpectrumMsg-*.dmp'))
    for path in messages:
        frames = decoder.decode_frames(path, f0)
        if not frames:
            print(f'FAIL {path.name}: no frames decoded'); failures += 1; continue
        starts = np.asarray([f.frequency_start_hz for f in frames if f.frequency_start_hz is not None], float)
        spacings = np.asarray([f.frequency_spacing_hz for f in frames if f.frequency_spacing_hz is not None], float)
        ends = np.asarray([f.frequency_end_hz for f in frames if f.frequency_end_hz is not None], float)
        peak_errors = np.asarray([abs(f.main_peak_hz-f0) for f in frames if f.main_peak_hz is not None], float)
        stable = starts.size == len(frames) and spacings.size == len(frames) and np.ptp(starts) <= 1.0 and np.ptp(spacings) <= 1.0
        print(f'{"PASS" if stable else "FAIL"} {path.parent.name}/{path.name}: frames={len(frames)}, axis={np.median(starts)/1e3:.3f}..{np.median(ends)/1e3:.3f} kHz, df={np.median(spacings):.6f} Hz, median |peak-f0|={np.median(peak_errors)/1e3:.3f} kHz, source={frames[0].frequency_axis_source}')
        failures += 0 if stable else 1
    ffts = sorted(root.rglob('Spectrum_*.dmp_FFT'))
    for path in ffts:
        raw = Path(str(path)[:-4]) if str(path).lower().endswith('_fft') else None
        if raw is not None and not raw.exists(): raw = None
        replay = HydrophoneReplayService().build_direct(path, raw)
        ok = bool(replay.frames and replay.frequency_spacing_hz and replay.frequency_start_hz is not None)
        print(f'{"PASS" if ok else "FAIL"} {path.name}: snapshots={len(replay.frames)}, axis={replay.frequency_start_hz/1e3 if replay.frequency_start_hz is not None else float("nan"):.3f}..{replay.frequency_end_hz/1e3 if replay.frequency_end_hz is not None else float("nan"):.3f} kHz, df={replay.frequency_spacing_hz or float("nan"):.6f} Hz, f0-bin-error={replay.main_frequency_bin_error_hz if replay.main_frequency_bin_error_hz is not None else float("nan"):+.3f} Hz, source={replay.frequency_axis_source}')
        failures += 0 if ok else 1
    print(f'Result: {"PASS" if failures == 0 else "FAIL"} ({failures} failure(s))')
    return failures


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    args = parser.parse_args()
    raise SystemExit(1 if audit(args.root) else 0)
