from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np

from src.services.cpc_vendor_reproduction_service import CpcVendorReproductionService


def main() -> int:
    parser=argparse.ArgumentParser(description='Validate CPC cavitation power-control reproduction against Acquisition_Brain log')
    parser.add_argument('source', type=Path, help='CPCFiles folder or a Spectrum dump inside it')
    parser.add_argument('--frequency-hz', type=float, default=670000.0)
    args=parser.parse_args()

    svc=CpcVendorReproductionService()
    profile=svc.read_profile(args.source,args.frequency_hz)
    log=svc._find_upwards(args.source,(),('Acquisition_Brain_*.txt',))
    if log is None:
        print('FAIL: Acquisition_Brain log not found')
        return 2
    sessions=svc._parse_power_control_sessions(log)
    all_errors=[]; total_dec=0; total_inc=0; matched_sessions=0
    for si,session in enumerate(sessions):
        previous=None; errors=[]; dec=inc=0
        for row in session:
            actual=row.get('power_ratio')
            if actual is None:
                continue
            prediction=None
            dec_rules=[profile.decrease_rules[i] for i in row['decrease_rules'] if i in profile.decrease_rules and profile.decrease_rules[i].power_ratio is not None]
            if previous is not None and dec_rules:
                strongest=max(dec_rules,key=lambda r:float(r.power_ratio or 0.0))
                prediction=float(previous)*(1.0-float(strongest.power_ratio)); dec+=1
            elif previous is not None and row['increase_rules'] and profile.increase_power_ratio is not None:
                prediction=min(1.0,float(previous)*(1.0+float(profile.increase_power_ratio))); inc+=1
            if prediction is not None:
                errors.append(abs(float(actual)-prediction))
            previous=float(actual)
        if errors:
            matched_sessions+=1; total_dec+=dec; total_inc+=inc; all_errors.extend(errors)
            print(f'Session {si:02d}: events={len(errors):5d} decrease={dec:3d} increase={inc:5d} MAE={np.mean(errors):.8g} MAX={np.max(errors):.8g}')
    if not all_errors:
        print('FAIL: no runtime power-control events decoded')
        return 3
    maxerr=float(np.max(all_errors)); mae=float(np.mean(all_errors))
    status='EXACT' if maxerr <= 5e-4 else 'PARTIAL'
    print(f'OVERALL {status}: sessions={matched_sessions}/{len(sessions)} events={len(all_errors)} decrease={total_dec} increase={total_inc} MAE={mae:.8g} MAX={maxerr:.8g}')
    print('Rule semantics validated: strongest simultaneous decrease wins; decrease/increase ratios are multiplicative; increase saturates at 1.0.')
    return 0 if status == 'EXACT' else 1


if __name__ == '__main__':
    raise SystemExit(main())
