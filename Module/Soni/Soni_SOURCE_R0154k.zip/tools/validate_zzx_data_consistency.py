from __future__ import annotations
import json, shutil
from pathlib import Path
import numpy as np
from src.services.import_service import ImportService
from src.services.discovery_service import DiscoveryService
from src.services.hydrophone_replay_service import HydrophoneReplayService
from src.services.acoustic_control_service import AcousticControlService
from src.services.cavitation_control_timeline_service import CavitationControlTimelineService
from src.services.standalone_cavitation_service import StandaloneCavitationService
from src.services.canonical_cavitation_evidence_service import CanonicalCavitationEvidenceService
from src.services.cavitation_likelihood_service import CavitationLikelihoodService
from src.services.sonication_summary_cavitation_evidence_service import SonicationSummaryCavitationEvidenceService
from src.services.replay_service import ReplayService


def finite(v):
    try:
        x=float(v)
        return x if np.isfinite(x) else None
    except Exception:return None


def main(source: Path, out: Path):
    imp=ImportService(); workspace=imp.open(source)
    try:
        pkg=DiscoveryService().discover(source,workspace)
        hydro=HydrophoneReplayService(); acoustic=AcousticControlService(); ctl=CavitationControlTimelineService()
        standalone=StandaloneCavitationService(); canon=CanonicalCavitationEvidenceService(); like=CavitationLikelihoodService()
        evidence=SonicationSummaryCavitationEvidenceService(hydro,acoustic,standalone,canon,like)
        replay_service=ReplayService()
        rows=[]
        for i,son in enumerate(pkg.sonications):
            preferred=getattr(son,'canonical_acquisition_session_index',None)
            timeline=ctl.parse(Path(pkg.workspace),None,preferred,np.asarray([],dtype=int),np.asarray([],dtype=float),0.0,
                float(getattr(son,'mr_sonication_start_s',0.0) or 0.0),float(getattr(son,'mr_sonication_end_s',0.0) or 0.0),
                float(getattr(son,'mr_timeline_duration_s',0.0) or 0.0),None,None,0.010)
            payload=evidence.analyze(pkg,i,son,list(getattr(timeline,'events',[]) or []))
            c=payload['canonical']
            tm=dict(replay_service.temperature_metrics(son) or {})
            ap=finite(getattr(son,'actual_power_w',None)); ad=finite(getattr(son,'actual_duration_s',None)); ae=finite(getattr(son,'actual_energy_j',None))
            pp=finite(getattr(son,'planned_power_w',None)); pd=finite(getattr(son,'planned_duration_s',None)); pe=finite(getattr(son,'planned_energy_j',None))
            measured_energy=ae if ae is not None else (ap*ad if ap is not None and ad is not None else None)
            delivered=(100.0*measured_energy/pe if measured_energy is not None and pe and pe>0 else None)
            likelihood=payload.get('likelihood')
            centroid=getattr(likelihood,'centroid_xy',None) if likelihood is not None else None
            rows.append({
                'sonication':i+1,'name':son.name,
                'actual_power_w':ap,'planned_power_w':pp,'actual_duration_s':ad,'planned_duration_s':pd,
                'actual_energy_j':ae,'planned_energy_j':pe,'energy_delivered_pct_raw':delivered,
                'start_temp_c':finite(tm.get('start_temp')),'peak_temp_c':finite(tm.get('peak_temp')),'delta_t_c':finite(tm.get('delta_temp')),
                'observed_control_cavitation_events':len(c.observed_events),'vendor_rule_triggers':len(c.vendor_rule_events),
                'dump_candidates':len(c.candidate_events),'canonical_detected':bool(c.detected),'canonical_status':c.status,
                'vendor_exceedance_severity':finite(c.vendor_exceedance_severity),
                'probable_centroid_xy':list(centroid) if centroid is not None else None,
                'spectrum_frames':len(getattr(payload.get('replay'),'frames',[]) or []),
            })
        result={'source':str(source),'sonication_count':len(rows),'rows':rows}
        out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        print(json.dumps(result,indent=2,ensure_ascii=False))
    finally:
        try: imp.cleanup(workspace)
        except Exception: shutil.rmtree(workspace,ignore_errors=True)

if __name__=='__main__':
    import sys
    main(Path(sys.argv[1]),Path(sys.argv[2]))
