from __future__ import annotations
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.services.hydrophone_replay_service import HydrophoneReplayService


def validate(root: Path) -> list[str]:
    service = HydrophoneReplayService()
    lines: list[str] = []
    fft_files = sorted(root.rglob('Spectrum_*.dmp_FFT'))
    b0_exact = b1_exact = files_with_b2 = 0
    for fft in fft_files:
        raw = Path(str(fft)[:-4])
        replay = service.build_direct(fft, raw if raw.exists() else None)
        validation = replay.vendor_history_validation
        if validation is None:
            lines.append(f'{fft.name}: NO vendor validation')
            continue
        band1 = np.asarray(replay.vendor_band1_log_exact, float)
        band2 = np.asarray(replay.vendor_band2_log_events, float)
        b1n = int(np.count_nonzero(np.isfinite(band1)))
        b2n = int(np.count_nonzero(np.isfinite(band2)))
        if validation.status.startswith('EXACT'):
            b0_exact += 1
        if b1n:
            b1_exact += 1
        if b2n:
            files_with_b2 += 1
        lines.append(
            f'{fft.name}: Band0={validation.status}; session={validation.log_session_index}; '
            f'Band1 exact log-derived samples={b1n}; Band2 exact threshold events={b2n}'
        )
    lines.append(f'RESULT: Band0 EXACT {b0_exact}/{len(fft_files)}; Band1 continuous exact {b1_exact}/{len(fft_files)}; Band2 event evidence in {files_with_b2}/{len(fft_files)}')
    lines.append('Band3: definition confirmed by INI (1.0*f0 ± 5 kHz), but no active display/control rule supplies an exact energy history in this configuration.')
    return lines


if __name__ == '__main__':
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    print('\n'.join(validate(root)))
