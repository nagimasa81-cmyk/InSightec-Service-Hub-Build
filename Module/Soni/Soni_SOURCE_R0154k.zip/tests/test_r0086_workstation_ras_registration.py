from pathlib import Path
from types import SimpleNamespace
import numpy as np

from src.services.registration_overlay_service import RegistrationOverlayService, CtGeometry


def test_mr_pixel_x_uses_col_direction_and_y_uses_row_direction():
    svc=RegistrationOverlayService()
    asset=SimpleNamespace(
        top_left_r=10.0, top_left_a=20.0, top_left_s=30.0,
        pixel_size_x=2.0, pixel_size_y=3.0,
        row_direction=(0.0,1.0,0.0), col_direction=(1.0,0.0,0.0),
    )
    origin,xdir,ydir,px,py=svc._mr_geometry(asset)
    np.testing.assert_allclose(origin,[10,20,30])
    np.testing.assert_allclose(xdir,[1,0,0])
    np.testing.assert_allclose(ydir,[0,1,0])
    assert px==2.0 and py==3.0


def test_ct_voxel_basis_uses_col_for_x_row_for_y():
    svc=RegistrationOverlayService()
    vol=np.zeros((2,4,5),bool)
    # CT pixel x=2, y=1, z=0 corresponds to RAS (2,1,0) when
    # col=(1,0,0), row=(0,1,0).
    vol[0,0:4,0:5]=True
    geom=CtGeometry(np.array([0.,0.,0.]),np.array([0.,1.,0.]),np.array([1.,0.,0.]),np.array([0.,0.,1.]),1.,1.,1.,Path('MriImageParams.xml'))
    mr=SimpleNamespace(top_left_r=0.,top_left_a=0.,top_left_s=0.,pixel_size_x=1.,pixel_size_y=1.,row_direction=(0.,1.,0.),col_direction=(1.,0.,0.))
    out=svc._world_reslice_mask(vol,(4,5),mr,geom,np.eye(4),'CtMr')
    assert np.isfinite(out[1,2])
    assert np.isfinite(out).sum() >= 8


def test_preplanning_recipe_inverts_mrmr(tmp_path: Path):
    son=tmp_path/'Sonication1'; son.mkdir()
    ct=np.eye(4); ct[0,3]=5.0
    mm=np.eye(4); mm[1,3]=7.0
    np.savetxt(son/'CtMr_mat.txt',ct)
    np.savetxt(son/'MrMr_mat.txt',mm)
    (son/'CtMr.rgs').write_text('IsMatrixValid=True\nIsMatrixUpToDate=True\nMrOrientation=MrAxial\n',encoding='utf-8')
    (son/'MrMr.rgs').write_text('IsMatrixValid=True\nIsMatrixUpToDate=True\nMrOrientation=MrAxial\n',encoding='utf-8')
    recipe=RegistrationOverlayService()._registration_recipe(tmp_path,1,SimpleNamespace(category='PREPLANNING_MR_AX'))
    assert recipe is not None
    assert recipe.chain_name=='inv(MrMr) × CtMr'
    np.testing.assert_allclose(recipe.matrix,np.linalg.inv(mm)@ct)
