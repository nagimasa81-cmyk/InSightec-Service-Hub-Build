
from pathlib import Path
REG=(Path(__file__).parents[1]/"src/services/registration_overlay_service.py").read_text(encoding="utf-8")
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_current_slice_qa_exists():
    assert "def _current_slice_projection_qa" in REG
    b=REG.split("def _current_slice_projection_qa",1)[1].split("def diagnose_reference_candidates",1)[0]
    assert "slice_tolerance_mm" in b
    assert "applicable" in b
    assert "not_applicable_points" in b

def test_direct_projection_compares_with_renderer():
    b=REG.split("def _current_slice_projection_qa",1)[1].split("def diagnose_reference_candidates",1)[0]
    assert "raster_overlap_fraction" in b
    assert "overlay_agreement_fraction" in b
    assert "_project" not in ""  # source-contract placeholder keeps test deterministic

def test_display_hypotheses_are_diagnostic_only():
    assert "def _display_hypothesis_scores" in REG
    b=REG.split("def _display_hypothesis_scores",1)[1].split("def _current_slice_projection_qa",1)[0]
    for key in ['"identity"','"flip-x"','"flip-y"','"flip-xy"']:
        assert key in b
    assert "never changes production" in b

def test_image_qa_does_not_override_strong_geometry():
    b=REG.split("def render_volume",1)[1].split("def render(",1)[0]
    assert "geometry_coherent" in b
    assert "image_qa_mismatch and not geometry_coherent" in b
    assert "2D MR outer-head QA warning" in b

def test_trace_explains_not_applicable_slice_points():
    assert "NOT_APPLICABLE_TO_SLICE" in MAIN
    assert "high direct/render overlap" in MAIN
