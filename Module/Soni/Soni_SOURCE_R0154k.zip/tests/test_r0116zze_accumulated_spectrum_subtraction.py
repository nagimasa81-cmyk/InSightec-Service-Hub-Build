from pathlib import Path
import numpy as np

from src.services.hydrophone_replay_service import (
    CpcHydrophoneFrame,
    CpcHydrophoneReplay,
    HydrophoneReplayService,
)


def _frame(index: int, values: list[float]) -> CpcHydrophoneFrame:
    freq = np.array([100_000.0, 200_000.0, 300_000.0], dtype=float)
    channel = np.array(values, dtype=float)
    return CpcHydrophoneFrame(
        index=index,
        frequency_hz=freq,
        channels=[channel.copy() for _ in range(8)],
        uncalibrated_channels=[channel.copy() for _ in range(8)],
    )


def test_accumulated_mean_excludes_current_frame_and_is_binwise():
    replay = CpcHydrophoneReplay(source_fft=Path('dummy'), source_raw=None)
    replay.frames = [
        _frame(0, [1.0, 2.0, 4.0]),
        _frame(1, [3.0, 2.0, 8.0]),
        _frame(2, [4.0, 4.0, 6.0]),
    ]
    service = HydrophoneReplayService()

    first = service.accumulated_average_delta_db(replay, 0, 0, True)
    np.testing.assert_allclose(first, np.zeros(3))

    # frame 2 baseline = mean(frame0, frame1) = [2, 2, 6]
    delta = service.accumulated_average_delta_db(replay, 2, 0, True)
    expected = 20.0 * np.log10(np.array([4.0, 4.0, 6.0]) / np.array([2.0, 2.0, 6.0]))
    np.testing.assert_allclose(delta, expected, rtol=1e-12, atol=1e-12)


def test_accumulated_cache_resets_between_replays():
    service = HydrophoneReplayService()
    a = CpcHydrophoneReplay(source_fft=Path('a'), source_raw=None)
    a.frames = [_frame(0, [1, 1, 1]), _frame(1, [2, 2, 2])]
    b = CpcHydrophoneReplay(source_fft=Path('b'), source_raw=None)
    b.frames = [_frame(0, [10, 10, 10]), _frame(1, [10, 10, 10])]
    assert np.all(service.accumulated_average_delta_db(a, 1, 0) > 0)
    np.testing.assert_allclose(service.accumulated_average_delta_db(b, 1, 0), 0.0)


def test_spectrum_ui_exposes_processing_mode_and_zero_reference():
    src = Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'Current − accumulated mean' in src
    assert 'spectrum_processing_mode' in src
    assert 'accumulated_average_delta_db' in src
    assert 'InfiniteLine(pos=0.0' in src


def test_new_mode_is_localized_for_all_supported_languages():
    from src.ui.i18n import UI_TEXT
    for locale in ('ja', 'ko', 'zh_TW', 'es', 'th', 'hi'):
        assert UI_TEXT[locale].get('Current − accumulated mean')
        assert UI_TEXT[locale].get('Processing')
