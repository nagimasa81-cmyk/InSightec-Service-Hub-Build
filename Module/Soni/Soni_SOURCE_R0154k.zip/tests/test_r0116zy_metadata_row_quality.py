from pathlib import Path


def test_metadata_row_selector_prefers_real_treatment_row():
    text = Path('src/services/sonication_metadata_service.py').read_text(encoding='utf-8')
    assert 'Prefer the treatment thermometry/MEMP row' in text
    assert 'return max(matched, key=quality)' in text
    assert 'orientation_text if not mr_row else None' in text
    assert 'freq_text if not mr_row else None' in text
