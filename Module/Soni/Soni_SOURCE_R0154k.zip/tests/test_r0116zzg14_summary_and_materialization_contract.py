from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')

def test_summary_interrupt_reason_is_visible_without_manufacturing_cavitation():
    assert 'cav_status=f"{panic_type} : {cav_status}"' in MAIN
    assert 'if canonical.detected is not True and panic_type' in MAIN

def test_cavitation_summary_rows_are_red_and_bold():
    assert 'if data.get("cavitation") is True:' in MAIN
    assert 'QColor("#c62828")' in MAIN
    assert 'font.setBold(True)' in MAIN

def test_selected_sonication_owns_background_data_trigger():
    block=MAIN[MAIN.index('def _select_sonication_index'):MAIN.index('def _load_selected_stage')]
    assert 'self._start_selected_replay_data_background()' in block
    assert 'self._start_spectrum_preload(self.package,int(self.sonication_index))' in block

def test_analyzer_materializes_all_tabs_from_replay_adoption():
    assert 'def _materialize_all_tabs_for_replay' in HYDRO
    assert 'self._refresh_frame_views()' in HYDRO
    assert 'self._publish_secondary_payload()' in HYDRO
    assert 'self._queue_secondary_analysis()' in HYDRO
