from pathlib import Path
import numpy as np

from src.services.acoustic_control_service import AcousticControlService


def test_acoustic_trace_ends_instead_of_forward_filling_post_mr(tmp_path: Path):
    log=tmp_path/'Acquisition_Brain_650_test.txt'
    log.write_text(
        '12:00:00:000 Got StartSpectrumMeasurementA\n'
        '12:00:00:100 AblPowerRatio = 0.20\n'
        '12:00:01:000 AblPowerRatio = 1.00\n'
        '12:00:05:000 Calculated Energy: <0.010> Bottom Limit Of Harmless Energy: <0.020>\n'
        '12:00:06:000 AblPowerRatio = 0.80\n'
        '12:00:06:100 StopSpectrumMeasurement\n', encoding='utf-8')
    svc=AcousticControlService()
    trend=svc.trend_for_sonication(tmp_path,0,21,20.0)
    assert trend.acoustic_end_s is not None
    assert 5.9 <= trend.acoustic_end_s <= 6.1
    assert np.isfinite(trend.power_percent[5])
    assert np.isnan(trend.power_percent[-1])
    assert np.isnan(trend.score_percent[-1])
