from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]

def test_release_metadata_complete_and_synchronized():
    meta = json.loads((ROOT / "version.json").read_text(encoding="utf-8"))
    constants = (ROOT / "src/common/constants.py").read_text(encoding="utf-8")
    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    contract = json.loads((ROOT / "insightec_build_contract.json").read_text(encoding="utf-8"))
    assert meta["version"] == version
    assert meta["commit"] == version.split("-")[-1]
    assert version == meta["version"]
    assert f'APP_VERSION = "{version}"' in constants
    assert f'APP_COMMIT = "{meta["commit"]}"' in constants
    assert contract["source_version"] == version.lower()
    assert contract["release_sequence"] == 116

def test_build_scripts_embed_current_release_identity():
    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    meta = json.loads((ROOT / "version.json").read_text(encoding="utf-8"))
    file_version = str(meta.get("file_version", ""))
    for name in ("01_BUILD_EXE_NUITKA.bat", "01_BUILD_EXE_NUITKA_CI.bat"):
        text = (ROOT / name).read_text(encoding="utf-8")
        assert version in text
        if file_version:
            assert file_version in text
        assert "RC7.2-R0078" not in text
