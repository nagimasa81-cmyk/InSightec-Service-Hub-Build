from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HELPER = (ROOT / "src/ui/chart_interaction.py").read_text(encoding="utf-8")
HYD = (ROOT / "src/ui/hydrophone_window.py").read_text(encoding="utf-8")
PYPROJECT = (ROOT / "pyproject.toml").read_text(encoding="utf-8")

def test_shared_installer_has_duplicate_guard_and_hidden_axis_guard():
    assert "_soni_x_axis_range_zoom_installed" in HELPER
    assert 'not axis.isVisible()' in HELPER

def test_dynamic_fft_result_plots_receive_common_interaction():
    assert HYD.count("self._enable_plot_interaction(plot)") >= 3

def test_stale_pyproject_identity_removed():
    assert "RC7.2 Spectrum Dump Import and CGA-style Analysis" not in PYPROJECT
    assert "Sonication Replay Engine" in PYPROJECT
