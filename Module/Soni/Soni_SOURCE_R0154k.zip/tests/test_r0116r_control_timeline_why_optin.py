from pathlib import Path

H = (Path(__file__).resolve().parents[1] / "src" / "ui" / "hydrophone_window.py").read_text(encoding="utf-8")

def test_control_timeline_has_independent_why_checkbox_default_off():
    assert 'self.control_why_popup_check = QCheckBox("Why popup")' in H
    assert 'self.control_why_popup_check.setChecked(False)' in H

def test_control_marker_and_event_row_gate_popup_on_control_checkbox():
    assert H.count('control_why_popup_check.isChecked()') >= 2
    assert 'self._show_event_why_popup(event, force=True)' in H
    assert 'self._show_event_why_popup(ev, force=True)' in H

def test_off_state_preserves_selection_highlight_without_popup():
    assert 'self._highlight_why_event(event)' in H
    assert 'self._highlight_why_event(ev)' in H
