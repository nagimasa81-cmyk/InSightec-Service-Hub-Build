from pathlib import Path
from types import SimpleNamespace
import numpy as np

from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService


def test_dqa_reference_uses_named_axial_and_sagittal_series_not_fixed_sonication_order(tmp_path: Path):
    # Dedicated DQA reference anatomy exists in S1 even though treatment thermometry may be later.
    s1=tmp_path/'Sonication1'; s1.mkdir()
    yy,xx=np.indices((256,256)); cx,cy,r=128.0,105.0,48.0
    img=np.zeros((256,256),dtype=np.uint16)
    radial=np.hypot(xx-cx,yy-cy)
    img[np.abs(radial-r)<=2]=50000; img[radial<r-2]=12000
    img[145:148,45:211]=60000
    img.tofile(s1/'7-1-0-0.raw'); img.tofile(s1/'12-1-0-0.raw')
    (tmp_path/'MriImageParams.xml').write_text('''<root xmlns:z="urn:schemas-microsoft-com:rowset">
      <z:row fieldindex="7" sonicationindex="1" seriesdiscription="DQA-Axial" pixsizex="1" pixsizey="1"
        rowdirectcosrasx="0" rowdirectcosrasy="-1" rowdirectcosrasz="0" coldirectcosrasx="-1" coldirectcosrasy="0" coldirectcosrasz="0"
        topleftcoordr="128" topleftcoorda="128" topleftcoords="20" />
      <z:row fieldindex="12" sonicationindex="1" seriesdiscription="DQA-Sagittal" pixsizex="1" pixsizey="1"
        rowdirectcosrasx="0" rowdirectcosrasy="0" rowdirectcosrasz="-1" coldirectcosrasx="0" coldirectcosrasy="-1" coldirectcosrasz="0"
        topleftcoordr="0" topleftcoorda="128" topleftcoords="165" />
    </root>''',encoding='utf-8')
    (tmp_path/'SonicationSummary.xml').write_text('''<root xmlns:z="urn:schemas-microsoft-com:rowset">
      <z:row sonicationindex="1" treatprotocol="Low-Energy-DQA" focalrasx="-5" focalrasy="20" focalrasz="25" />
      <z:row sonicationindex="2" treatprotocol="Low-Energy-DQA" focalrasx="2" focalrasy="25" focalrasz="30" />
    </root>''',encoding='utf-8')
    package=SimpleNamespace(workspace=tmp_path,source=tmp_path/'case.zip',sonications=[SimpleNamespace(sonication_number=1),SimpleNamespace(sonication_number=2)])
    svc=DqaFocusAlignmentService()
    ref=svc._dqa_reference_geometry(package)
    assert ref['center_ras'] is not None and ref['baseline_s_mm'] is not None
    result=svc.analyze(package,1)
    assert result.confidence == 'High'
    assert result.x_mm is not None and result.y_mm is not None and result.z_mm is not None and result.tilt_deg is not None
    assert any('no fixed Sonication-order assumption' in x for x in result.evidence)


def test_selected_worker_has_explicit_no_cpc_dqa_spectrummsg_fallback():
    text=Path('src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'DQA Export has no CPC Spectrum files; using SpectrumMsg evidence' in text
    selected=text[text.index('class SelectedReplayDataWorker'):text.index('class DeferredPanelWorker')]
    assert 'repository.authoritative_context(' not in selected
    assert 'CPC preload is owned by the background Spectrum worker' in selected


def test_zero_amplitude_visual_contract_is_gray_explained_black_unexplained():
    text=Path('src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'gray=explained amplitude=0 · black=unexpected amplitude=0' in text
    assert 'QColor(155,155,155)' in text
    assert 'unexplained_zero' in text
    # Removed R0154f magenta warning-ring semantics.
    assert 'magenta ring=unexpected amplitude=0' not in text
