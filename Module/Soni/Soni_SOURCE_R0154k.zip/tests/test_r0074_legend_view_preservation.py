from pathlib import Path


def test_legend_checkbox_preserves_chart_view_state():
    text=(Path(__file__).parents[1]/"src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    assert "preserve_view=True" in text
    assert "saved_ranges" in text
    assert "Do not call autoRange for a visibility-only operation" in text
    assert "setRange(xRange=er[0], yRange=er[1], padding=0)" in text
