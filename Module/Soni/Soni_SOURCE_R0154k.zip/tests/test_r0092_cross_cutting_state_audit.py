
from pathlib import Path
import ast, collections, re

SRC=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def _method(name, next_name):
    return SRC.split(f"def {name}",1)[1].split(f"def {next_name}",1)[0]

def test_cavitation_stage_never_blocks_replay_ready_path():
    block=_method("_selected_stage_cavitation","_selected_stage_navigator")
    assert "_prepare_default_cavitation_intelligence()" not in block
    assert "_build_cpc_replay(" not in block
    assert "_spectrum_preload_context" in block
    lazy=_method("_main_tab_changed","_seed_sonication_summary_fast")
    assert "_prepare_cavitation_on_demand" in lazy

def test_clear_replay_clears_all_sonication_scoped_scientific_state():
    block=_method("_clear_replay_display","_decode_planning_image")
    for token in (
        "self.default_cpc_replay = None",
        "self.default_cavitation_timeline = None",
        "self.default_cavitation_likelihood = None",
        "self.default_cavitation_mr_correlation = None",
        "self.current_cavitation_root_cause = None",
        "self._ci_event_preview_result = None",
        "self._cavitation_trend = None",
    ):
        assert token in block

def test_no_unsafe_nearest_cpc_resolver_remains():
    assert "def _nearest_cpc_frame_index" not in SRC
    assert "_nearest_cpc_frame_index(" not in SRC

def test_event_table_has_single_authoritative_selection_connection():
    assert "cellClicked.connect(self._ci_event_selected)" in SRC
    assert "cellDoubleClicked.connect(self._ci_event_selected)" not in SRC

def test_thumbnail_mouse_action_is_not_double_connected():
    assert "strip.itemPressed.connect(" in SRC
    assert "strip.itemActivated.connect(" in SRC
    assert "strip.itemClicked.connect(" not in SRC

def test_localization_refresh_has_single_scientific_refresh_call():
    block=_method("_refresh_localized_messages","_localized_rca_summary")
    calls=re.findall(r"^\s*self\._update_default_cavitation_intelligence\(\)", block, re.M)
    assert len(calls) == 1
    assert not re.search(r"^\s*self\._update_ci_root_cause\(\)", block, re.M)

def test_no_duplicate_method_definitions_any_class():
    tree=ast.parse(SRC)
    for cls in (n for n in ast.walk(tree) if isinstance(n,ast.ClassDef)):
        counts=collections.Counter(n.name for n in cls.body if isinstance(n,ast.FunctionDef))
        assert not {k:v for k,v in counts.items() if v>1}
