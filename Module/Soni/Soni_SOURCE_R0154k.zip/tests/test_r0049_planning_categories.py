from src.services.planning_data_service import PlanningDataService


def test_plane_description_mapping():
    svc=PlanningDataService()
    assert svc._plane_from_description('BRAVO Ax',18,18)=='Ax'
    assert svc._plane_from_description('BRAVO Sag',20,20)=='Sag'
    assert svc._plane_from_description('BRAVO Cor',24,24)=='Cor'
