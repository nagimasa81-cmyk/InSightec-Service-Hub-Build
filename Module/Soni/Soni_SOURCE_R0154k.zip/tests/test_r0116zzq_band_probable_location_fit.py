from pathlib import Path

HYD = (Path(__file__).parents[1]/"src/ui/hydrophone_window.py").read_text(encoding="utf-8")

def test_band_energy_uses_data_tight_y_and_dynamic_height_budget():
    assert "plot_h = max(120, h - 86)" in HYD
    assert "self.band_plot.setMaximumHeight(plot_h)" in HYD
    assert "lo-0.06*span" in HYD
    assert "hi+0.04*span" in HYD
    assert "self.band_plot.setYRange(-60, 0" not in HYD

def test_probable_location_never_clears_to_blank_shell():
    assert "Always leave a visible geometry shell" in HYD
    assert "self.cavitation_likelihood_plot.addItem(self.cavitation_likelihood_overlay)" in HYD
    assert "Probable Location warning" in HYD
    assert "QTimer.singleShot(0, self._update_cavitation_likelihood)" in HYD
