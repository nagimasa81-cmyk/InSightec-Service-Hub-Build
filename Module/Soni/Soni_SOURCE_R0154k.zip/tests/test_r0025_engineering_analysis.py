from pathlib import Path
import numpy as np

from src.domain.models import SonicationModel, RawFrame
from src.services.engineering_analysis_service import EngineeringAnalysisService


def test_act_engineering_metrics(tmp_path: Path):
    act = tmp_path / 'Sonication1.act'
    act.write_text(
        '[Table Header]\nName=Sonication1\nNumberOfElements=4\n[Elements]\n'
        'Element1=1.0\t0.0\nElement2=0.5\t1.0\nElement3=0.0\t2.0\nElement4=1.0\t-1.0\n',
        encoding='utf-8'
    )
    son = SonicationModel('Sonication1', tmp_path, act_files=[act])
    metrics, rows = EngineeringAnalysisService()._act_analysis(son)
    values = {m.name: m.value for m in metrics}
    assert values['ACT elements'] == '4'
    assert values['Active elements'] == '3'
    assert values['Disabled elements'] == '1'
    assert rows[1][1] == '3 / 1'


def test_thermometry_masks_remove_invalid_peak(tmp_path: Path):
    son = SonicationModel('Sonication1', tmp_path)
    for i, peak in enumerate((37.0, 60.0)):
        arr = np.full((256,256), 37.0, dtype='<f4')
        if i:
            arr[128,128] = peak
            arr[0,0] = 300.0
        p = tmp_path / f'5-1-3-{i}.raw'; arr.tofile(p)
        son.temperature_frames.append(RawFrame(p, i, '5'))
    mag = np.zeros((256,256), dtype='<u2')
    for i in range(3):
        p=tmp_path/f'6-1-0-{i}.raw'; mag.tofile(p); son.magnitude_frames.append(RawFrame(p,i,'6'))
    mask33 = np.zeros((256,256), dtype=np.uint8); mask33[120:136,120:136]=255
    p33=tmp_path/'33-1-0-0.raw'; mask33.tofile(p33); son.other_files.append(p33)
    mask23 = np.ones((256,256), dtype='<f8'); mask23[0,0]=0
    p23=tmp_path/'23-1-3-0.raw'; mask23.tofile(p23); son.other_files.append(p23)
    metrics, _ = EngineeringAnalysisService()._thermometry_analysis(son)
    values={m.name:m.value for m in metrics}
    assert values['Global raw peak temperature'].startswith('300.00')
    assert values['Background-mask peak temperature'].startswith('60.00')
    assert values['Quality-mask peak temperature'].startswith('60.00')


def test_dependency_graph_keeps_partial_features_independent(tmp_path: Path):
    son=SonicationModel('Sonication1',tmp_path)
    son.capabilities={
        'thermometry': {'available': False, 'degraded': False},
        'spectrum': {'available': True, 'degraded': False},
        'elements': {'available': True, 'degraded': False},
        'skull': {'available': False, 'degraded': False},
        'motion': {'available': True, 'degraded': True},
        'dose': {'available': False, 'degraded': False},
        'registration': {'available': True, 'degraded': False},
        'planning': {'available': True, 'degraded': False},
    }
    deps=EngineeringAnalysisService()._dependencies(son)
    states={d.feature:d.state for d in deps}
    assert states['Temperature replay']=='MISSING'
    assert states['Spectrum analysis']=='AVAILABLE'
    assert states['Motion comparison']=='DEGRADED'
