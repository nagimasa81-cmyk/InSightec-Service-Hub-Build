from pathlib import Path


ROOT = Path(__file__).parents[1]
MAIN = (ROOT / "src/ui/main_window.py").read_text(encoding="utf-8")
REG = (ROOT / "src/services/registration_overlay_service.py").read_text(encoding="utf-8")
THEME = (ROOT / "src/common/theme.py").read_text(encoding="utf-8")


def test_thumbnail_scrollbar_has_grabbable_thumb_and_tracking():
    assert "QScrollBar::handle:horizontal" in THEME
    assert "min-width: 34px" in THEME
    assert "scroll.setTracking(True)" in MAIN
    assert "scroll.setPageStep(4)" in MAIN
    assert "slider.setRange(0,max(0,count-1))" in MAIN


def test_expensive_reference_diagnostic_is_trace_only():
    apply_block = MAIN.split("def _apply_registration_overlay", 1)[1].split(
        "def _activate_replay_mode_for_navigation", 1
    )[0]
    trace_block = MAIN.split("def _show_registration_trace", 1)[1].split(
        "def _registration_toggled", 1
    )[0]
    assert "_update_registration_reference_report" not in apply_block
    assert "_update_registration_reference_report" in trace_block


def test_ct_volume_skull_mask_and_slice_render_are_cached():
    assert "self._registration_ct_volume_cache" in MAIN
    assert "self._registration_overlay_cache.get(cache_key)" in MAIN
    assert "def _cached_vendor_skull_mask" in REG
    assert "self._skull_mask_cache" in REG


def test_study_reference_cache_survives_sonication_switch():
    clear_replay = MAIN.split("def _clear_replay_display", 1)[1].split(
        "def _clear_study_reference_cache", 1
    )[0]
    clear_study = MAIN.split("def _clear_study_reference_cache", 1)[1].split(
        "@staticmethod", 1
    )[0]
    assert "self._reference_thumbnail_cache = {}" not in clear_replay
    assert "self._planning_array_cache = {}" not in clear_replay
    assert "clear_runtime_cache()" not in clear_replay
    assert "self._reference_thumbnail_cache = {}" in clear_study
    assert "self._planning_array_cache = {}" in clear_study
    assert "clear_runtime_cache()" in clear_study


def test_complete_reference_thumbnails_are_not_redecoded():
    start = MAIN.split("def _start_image_thumbnail_background", 1)[1].split(
        "def _image_thumbnail_ready", 1
    )[0]
    assert "Do not bulk-decode Reference/Planning assets here" in start
    assert 'for role,sources in (("treatment_mr",treatment_frames),):' in start
