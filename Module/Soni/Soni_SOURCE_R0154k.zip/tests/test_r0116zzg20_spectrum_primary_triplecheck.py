from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / "src" / "ui" / "hydrophone_window.py"
TEXT = SRC.read_text(encoding="utf-8")


def test_loaded_export_handoff_uses_target_aware_primary_publish_and_retries():
    start = TEXT.index("def _finish_loaded_sonication_handoff")
    end = TEXT.index("def _set_secondary_product_state", start)
    block = TEXT[start:end]
    assert "_publish_primary_latest" in block
    assert "_ensure_primary_materialized" in block
    assert "QTimer.singleShot(80" in block
    assert "QTimer.singleShot(300" in block
    assert "_publish_primary_replay_after_decode(g, r" not in block


def test_primary_recovery_requires_visible_curve_not_only_signature():
    assert "def _spectrum_primary_visible" in TEXT
    start = TEXT.index("def _ensure_primary_materialized")
    end = TEXT.index("def _publish_primary_replay_after_decode", start)
    block = TEXT[start:end]
    assert "self._spectrum_primary_visible()" in block
    assert "signature if self._spectrum_primary_visible() else None" in block


def test_core_publisher_accepts_equivalent_repository_replay_by_signature():
    start = TEXT.index("def _publish_primary_replay_after_decode")
    end = TEXT.index("def _materialize_all_tabs_for_replay", start)
    block = TEXT[start:end]
    assert "expected=self._primary_replay_signature(replay)" in block
    assert "actual=self._primary_replay_signature(current)" in block
    assert "replay=current" in block
