from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
STANDALONE=(ROOT/'src/services/standalone_cavitation_service.py').read_text(encoding='utf-8')


def test_global_time_axis_controls_and_defaults_exist():
    assert 'addItem("MR acquisition start", "mr_start")' in HYDRO
    assert 'addItem("Sonication start", "sonication_start")' in HYDRO
    assert 'addItem("Sonication end", "sonication_end")' in HYDRO
    assert 'addItem("MR acquisition end", "mr_end")' in HYDRO
    assert 'self.time_axis_end_combo.setCurrentIndex(1)' in HYDRO


def test_all_time_domain_views_share_selected_mr_window():
    assert 'def _apply_selected_time_window' in HYDRO
    assert 'self._apply_selected_time_window(self.spectrogram_plot)' in HYDRO
    assert 'self._set_mr_xrange(self.band_plot)' in HYDRO
    assert 'self._apply_mr_timeline_window(self.vendor_energy_plot, self.vendor_power_plot)' in HYDRO
    assert 'self._apply_mr_timeline_window(self.cavitation_control_plot)' in HYDRO
    assert 'self._apply_selected_time_window(self.cavitation_heatmap_plot, add_irradiation_markers=False)' in HYDRO


def test_spectrum_timeline_no_longer_rezeros_at_first_cpc_snapshot():
    phase=HYDRO.split('def _spectrum_mr_phase',1)[1].split('def _update_spectrum_mr_timeline_label',1)[0]
    assert 'scan_t=aligned_t' in phase
    assert 'aligned_t-scan_origin' not in phase


def test_heatmap_and_raw_snapshot_are_mr_time_based():
    assert 'self.cavitation_heatmap_plot.setLabel("bottom", "MR acquisition time", units="s")' in HYDRO
    assert 'base_t+np.arange(len(y),dtype=float)*dt' in HYDRO


def test_fit_and_reset_do_not_restore_payload_specific_time_windows():
    fit=HYDRO.split('def _fit_all_data_views',1)[1].split('def _open_loaded_export',1)[0]
    assert 'self._apply_selected_time_window(*time_plots' in fit
    reset=HYDRO.split('def _reset_cavitation_views',1)[1].split('def _draw_observed_cavitation_timeline',1)[0]
    assert '_apply_selected_time_window' in reset


