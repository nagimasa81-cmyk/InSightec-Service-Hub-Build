from pathlib import Path


def test_direct_mouse_drag_selection_contract():
    src = Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    assert "_raw_fft_plot_for_viewport" in src
    assert "QEvent.Type.MouseButtonPress" in src
    assert "QEvent.Type.MouseMove" in src
    assert "QEvent.Type.MouseButtonRelease" in src
    assert "_set_raw_fft_drag_region" in src
    assert "CrossCursor" in src
    assert "FFT range selection (drag chart)" in src

def test_selection_mode_does_not_remove_r0126_history_analysis():
    src = Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    assert "_run_selected_history_fft_band0" in src
    assert "temporal modulation frequency" in src
