from types import SimpleNamespace
import numpy as np

from src.services.cavitation_likelihood_service import CavitationLikelihoodService


def test_event_cycle_maps_to_nearest_fft_snapshot_not_exact_only():
    svc=CavitationLikelihoodService()
    frames=[
        SimpleNamespace(acquisition_cycle=100, vendor_band_energies=np.ones((8,4))*1.0),
        SimpleNamespace(acquisition_cycle=140, vendor_band_energies=np.ones((8,4))*2.0),
    ]
    replay=SimpleNamespace(frames=frames, vendor_profile=None, receiver_enabled=(True,)*8)
    event=SimpleNamespace(cycle=133, family='Decrease', rule_index=0,
                          contributing_channels=(), contributing_bands=(), dominant_channel=None)
    scores,evidence=svc._scores_from_event(replay,event)
    assert np.allclose(scores, np.ones(8)*8.0)  # nearest cycle 140, summed 4 bands × 2
    assert 'nearest FFT snapshot 2' in evidence
    assert 'cycle 140' in evidence
    assert 'Δcycle +7' in evidence


def test_hydrophone_window_source_contains_direct_band_cube_contract():
    from pathlib import Path
    source=Path(__file__).parents[1]/'src'/'ui'/'hydrophone_window.py'
    text=source.read_text(encoding='utf-8')
    assert 'def _direct_replay_band_cube' in text
    assert 'valid 8×4 matrices' in text
    assert 'self._render_direct_band_heatmap()' in text
