from pathlib import Path
import ast

ROOT=Path(__file__).parents[1]
SRC=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
TREE=ast.parse(SRC)
MW=next(n for n in TREE.body if isinstance(n,ast.ClassDef) and n.name=='MainWindow')
METHODS={n.name for n in MW.body if isinstance(n,ast.FunctionDef)}

def test_navigation_methods_are_mainwindow_members():
    for name in ('set_frame','previous_frame','next_frame','toggle_play','speed_changed',
                 'slider_changed','keyPressEvent','wheelEvent'):
        assert name in METHODS

def test_thumbnail_helpers_are_mainwindow_members():
    assert '_array_preview_pixmap' in METHODS
    assert '_array_icon' in METHODS

def test_preview_helper_not_top_level():
    assert not any(isinstance(n,ast.FunctionDef) and n.name=='_array_preview_pixmap' for n in TREE.body)

def test_timer_callback_resolves():
    assert 'self.timer.timeout.connect(self.next_frame)' in SRC
    assert 'next_frame' in METHODS
