# R0154k — ZIP-drop Summary completion + Brain220 SpectrumMsg publication

- Sonication Summary background analysis is now study-scoped and survives Sonication selection changes.
- Summary detail no longer waits on selected-Replay/Spectrum preload threads; the shared SpectrumEvidenceRepository already serializes duplicate CPC decode safely.
- CPC context publication no longer cancels/restarts a running Summary pass; at most one retry is queued after completion.
- Selected Sonication SpectrumMsg is always published to Replay Acoustic Spectrum, even when CPC is enabled. CPC remains the independent source for the dedicated 8CH Hydrophone Analyzer.
- No change was made to CPC measurement-history decoding/rendering; pre-irradiation history is a processed CPC metric, not Raw A/D.
