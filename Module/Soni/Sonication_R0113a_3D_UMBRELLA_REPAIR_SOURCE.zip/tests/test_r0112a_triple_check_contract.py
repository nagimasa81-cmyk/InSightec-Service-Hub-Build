from pathlib import Path
import ast,json
ROOT=Path(__file__).parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYD=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
REG=(ROOT/'src/services/registration_overlay_service.py').read_text(encoding='utf-8')

def test_version_sources_agree():
    v=json.loads((ROOT/'version.json').read_text(encoding='utf-8'))['version']
    assert (ROOT/'VERSION').read_text().strip()==v

def test_no_backup_ancestor_source_in_ui_package():
    assert not (ROOT/'src/ui/main_window.py.bak').exists()

def test_reference_treatment_thermal_rows_start_visible():
    assert 'show_reference_images_check' not in MAIN
    assert 'show_treatment_mr_images_check' not in MAIN
    assert 'QCheckBox("Show Thermal Images")' not in MAIN

def test_full_series_slots_and_explicit_scrollbar():
    assert 'self._planning_assets_all.append((asset,None,label,category))' in MAIN
    assert 'entries.append(("treatment_mr",mr_cache.get(int(row))' in MAIN
    assert 'QScrollBar(Qt.Orientation.Horizontal)' in MAIN
    assert 'scroll.setVisible(True)' in MAIN

def test_registration_click_first_commits_selected_mr_then_overlay():
    b=MAIN.split('def _activate_image_payload',1)[1].split('def _show_registration_trace',1)[0]
    assert b.index('self.overlay.set_overlay(array,None') < b.index('self._apply_registration_overlay()')
    assert 'mr=np.asarray(mr,float)' in REG

def test_registration_ct_field16_lazy_path_present():
    b=MAIN.split('def _ct_volume_for_registration',1)[1].split('def _registration_reference_candidates',1)[0]
    assert 'getattr(a,"field_index",None)!=16' in b
    assert 'arr=self._planning_array_for_asset(a)' in b

def test_ci_increase_is_list_only_default_hidden():
    assert 'self.ci_show_increase_events_check.setChecked(False)' in MAIN
    b=MAIN.split('def _update_ci_linked_panel',1)[1].split('def _make_ci_collapsible_section',1)[0]
    assert '.lower()!="increase"' in b

def test_ci_rule_state_has_detail_and_full_text_access():
    b=MAIN.split('def _update_ci_linked_panel',1)[1].split('def _make_ci_collapsible_section',1)[0]
    assert 'severity=' in b and 'result_text=' in b
    assert 'item.setToolTip' in b
    assert 'cellDoubleClicked.connect(self._ci_linked_event_detail_popup)' in MAIN

def test_umbrella_connections_and_interaction_are_single():
    assert 'currentTextChanged.connect(self.element_map.set_umbrella_projection)' in MAIN
    assert 'def _umbrella_project' in MAIN
    assert 'self._umbrella_drag_last=event.position()' in MAIN
    assert 'self.umbrella_zoom=' in MAIN
    tree=ast.parse(MAIN)
    for node in ast.walk(tree):
        if isinstance(node,ast.ClassDef):
            seen=set()
            for item in node.body:
                if isinstance(item,ast.FunctionDef):
                    assert item.name not in seen, f'duplicate {node.name}.{item.name}'
                    seen.add(item.name)

def test_summary_power_energy_use_authoritative_numeric_model():
    assert 'getattr(son,"actual_power_w",None)' in MAIN
    assert 'getattr(son,"actual_energy_j",None)' in MAIN

def test_hydrophone_increase_chart_vs_list_semantics():
    b=HYD.split('def _draw_observed_cavitation_timeline',1)[1].split('def _selected_observed_cavitation_event',1)[0]
    assert 'Increase stays visible on the chart' in b
    assert 'str(getattr(ev, "family", "")) != "Increase"' in b

def test_hydrophone_long_text_readability():
    assert 'def _install_table_readability' in HYD
    assert 'cellDoubleClicked.connect' in HYD
    assert 'setHorizontalScrollBarPolicy' in HYD
