from pathlib import Path
from types import SimpleNamespace

from src.services.spectrum_dump_import_service import SpectrumDumpCandidate, SpectrumDumpImportService


def cand(rel: str):
    p = Path('/tmp/export') / rel
    return SpectrumDumpCandidate(
        label=p.name.replace('_FFT',''),
        raw_path=Path(str(p).replace('_FFT','')),
        fft_path=p,
        relative_path=rel,
        family='CPC Spectrum',
    )


def test_explicit_sonication_folder_mapping_wins():
    svc = SpectrumDumpImportService()
    candidates = [
        cand('Sonication/Sonication2/Spectrum_B.dmp_FFT'),
        cand('Sonication/Sonication1/Spectrum_A.dmp_FFT'),
    ]
    sons = [
        SimpleNamespace(name='Sonication1', folder=Path('/x/Sonication1')),
        SimpleNamespace(name='Sonication2', folder=Path('/x/Sonication2')),
    ]
    mapping = svc.map_candidates_to_sonications(candidates, sons)
    assert mapping[0].relative_path.endswith('Sonication1/Spectrum_A.dmp_FFT')
    assert mapping[1].relative_path.endswith('Sonication2/Spectrum_B.dmp_FFT')


def test_spectrummsg_is_not_used_as_physical_cpc_mapping():
    svc = SpectrumDumpImportService()
    msg = SpectrumDumpCandidate('SpectrumMsg-1.dmp', Path('/tmp/SpectrumMsg-1.dmp'), None, 'Sonication1/SpectrumMsg-1.dmp', 'SpectrumMsg')
    mapping = svc.map_candidates_to_sonications([msg], [SimpleNamespace(name='Sonication1', folder=Path('/x/Sonication1'))])
    assert mapping == {}


def test_window_uses_discovered_candidate_before_legacy_package_list():
    source = Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    fn = source.split('    def load_sonication(self, index: int):', 1)[1].split('\n    def ', 1)[0]
    assert '_sonication_dump_map' in fn
    assert 'self.service.build_direct(candidate.fft_path, candidate.raw_path)' in fn
    assert 'Discovered {discovered}' in fn
    assert 'Mapped' in fn and 'Decoded' in fn
