from pathlib import Path


def test_exclusive_progress_dialog_wired_to_main_and_hydrophone():
    main = Path('src/ui/main_window.py').read_text(encoding='utf-8')
    hydro = Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    dialog = Path('src/ui/progress_window.py').read_text(encoding='utf-8')
    assert 'ApplicationModal' in dialog
    assert 'WindowCloseButtonHint' in dialog
    assert 'def reject(self)' in dialog
    assert '_exclusive_progress = BusyProgressDialog(self)' in main
    assert '_exclusive_progress = BusyProgressDialog(self)' in hydro
    assert 'self._exclusive_progress.finish()' in main
    assert 'dlg.finish()' in hydro


def test_background_summary_does_not_open_exclusive_progress():
    main = Path('src/ui/main_window.py').read_text(encoding='utf-8')
    start = main.index('def _start_sonication_summary_background')
    body = main[start:start+1300]
    assert 'show_progress(' not in body
