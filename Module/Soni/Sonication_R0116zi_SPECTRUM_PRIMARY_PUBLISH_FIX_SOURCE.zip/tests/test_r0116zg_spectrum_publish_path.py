from pathlib import Path


def test_mapped_sonication_uses_background_decode_worker():
    text = Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    start = text.index("def load_sonication")
    end = text.index("def _sonication_changed", start)
    block = text[start:end]
    assert "self._start_dump_decode(candidate_index, candidate)" in block
    assert "self.service.build_direct(candidate.fft_path, candidate.raw_path)" not in block


def test_preload_failure_falls_back_to_package_loader():
    text = Path("src/ui/main_window.py").read_text(encoding="utf-8")
    start = text.index("def _spectrum_preload_failed")
    end = text.index("def _open_hydrophone_window", start)
    block = text[start:end]
    assert "self.hydrophone_window.load_package(self.package" in block
