
from pathlib import Path
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_thermal_row_visible_by_current_default_contract():
    assert 'self._main_image_mode = "thermal"' in MAIN
    assert 'QCheckBox("Show Thermal Images")' not in MAIN

def test_background_worker_is_used():
    assert 'class ThermalThumbnailWorker(QObject)' in MAIN
    assert 'worker.moveToThread(thread)' in MAIN
    assert 'thread.started.connect(worker.run)' in MAIN

def test_navigator_does_not_decode_all_thermal_synchronously():
    b=MAIN.split('def _build_frame_navigator',1)[1].split('def _rebuild_all_image_strips',1)[0]
    assert 'for row, frame in enumerate(self.current.temperature_frames)' not in b
    assert 'for row, frame in enumerate(self.current.temperature_frames)' not in b
    assert 'QTimer.singleShot(420,self._start_thermal_thumbnail_background)' in MAIN

def test_strip_rebuild_uses_cache_not_raw_io():
    b=MAIN.split('def _all_image_entries',1)[1].split('def _rebuild_all_image_strips',1)[0]
    assert 'read_temperature' not in b
    assert '_thermal_thumbnail_cache' in b
