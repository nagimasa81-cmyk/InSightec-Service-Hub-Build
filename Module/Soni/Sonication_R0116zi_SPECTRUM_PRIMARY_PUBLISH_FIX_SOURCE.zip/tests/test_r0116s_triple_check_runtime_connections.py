from pathlib import Path
import ast

ROOT=Path(__file__).parents[1]
H=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
M=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')


def test_why_runtime_class_reference_is_valid():
    assert 'event_time=HydrophoneWindow._event_time_for_text' not in H
    assert 'event_time=EightHydrophoneWindow._event_time_for_text' in H


def test_latest_open_waits_for_thread_finished():
    assert 'thread.finished.connect(self._package_load_thread_finished)' in M
    block=M.split('def _package_load_thread_finished',1)[1].split('\n    def ',1)[0]
    assert 'self._package_load_thread=None' in block
    assert 'self._package_load_worker=None' in block
    assert '_run_pending_source_load' in block
    stale=M.split('def _package_load_finished',1)[1].split('\n    def ',1)[0]
    first_branch=stale.split('previous_workspace',1)[0]
    assert '_run_pending_source_load' not in first_branch


def test_replay_scoped_state_is_reset_before_source_switches():
    assert 'def _reset_replay_analysis_state' in H
    dump=H.split('def load_dump_candidate',1)[1].split('\n    def ',1)[0]
    son=H.split('def load_sonication',1)[1].split('\n    def ',1)[0]
    assert 'self._reset_replay_analysis_state()' in dump
    assert 'self._reset_replay_analysis_state()' in son
    reset=H.split('def _reset_replay_analysis_state',1)[1].split('\n    def ',1)[0]
    for token in ('observed_cavitation_timeline=None','_selected_observed_event_index=None','_clear_why_event_highlight()'):
        assert token in reset


def test_red_event_cursor_is_independent_from_replay_cursor():
    selected=H.split('def _selected_observed_cavitation_event',1)[1].split('\n    def ',1)[0]
    assert '_probable_location_pinned_to_event' in selected
    setframe=H.split('def set_frame',1)[1].split('\n    @staticmethod',1)[0]
    assert 'self._probable_location_pinned_to_event=False' in setframe
    assert 'self._selected_observed_event_index=None' not in setframe
    row=H.split('def _observed_cavitation_event_selected',1)[1].split('\n    def ',1)[0]
    assert 'self._probable_location_pinned_to_event=True' in row


def test_control_why_is_opt_in_and_runtime_path_uses_force():
    assert 'self.control_why_popup_check.setChecked(False)' in H
    row=H.split('def _observed_cavitation_event_selected',1)[1].split('\n    def ',1)[0]
    graph=H.split('def _cavitation_control_plot_clicked',1)[1].split('\n    def ',1)[0]
    assert 'self.control_why_popup_check.isChecked()' in row
    assert 'self._show_event_why_popup(event, force=True)' in row
    assert 'self.control_why_popup_check.isChecked()' in graph
    assert 'self._show_event_why_popup(ev, force=True)' in graph


def test_no_duplicate_methods_and_ast_valid():
    for text in (H,M): ast.parse(text)
    import collections
    tree=ast.parse(H)
    for node in tree.body:
        if isinstance(node,ast.ClassDef):
            d=collections.Counter(x.name for x in node.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)))
            assert not [name for name,count in d.items() if count>1]
