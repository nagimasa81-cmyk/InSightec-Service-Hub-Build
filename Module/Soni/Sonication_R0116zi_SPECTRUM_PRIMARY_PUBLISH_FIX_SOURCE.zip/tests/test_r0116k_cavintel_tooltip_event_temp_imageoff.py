from pathlib import Path
import ast
ROOT=Path(__file__).parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
CTL=(ROOT/'src/services/cavitation_control_timeline_service.py').read_text(encoding='utf-8')

def test_image_stage_skipped_off():
    assert 'stages.append((78, "Image thumbnails", self._selected_stage_navigator))' in MAIN
    assert 'if not self._image_loading_enabled()' in MAIN.split('def _selected_stage_navigator',1)[1].split('\n    def ',1)[0]
    assert 'if not self._image_loading_enabled()' in MAIN.split('def _build_frame_navigator',1)[1].split('\n    def ',1)[0]

def test_ci_temperature_numbers():
    assert 'ci_temperature_summary' in MAIN
    assert '("Temperature", "Temperature")' in MAIN
    assert 'def _ci_temperature_values' in MAIN
    assert 'background Sonication Summary' in MAIN

def test_contributors_semantics():
    assert 'rule_channels:' in CTL and 'observed_channels:' in CTL
    assert '"Contributors"' in HYDRO and 'observed_channels' in HYDRO and 'rule_channels' in HYDRO
    assert 'Observed contributors:' in HYDRO
    assert 'Configured rule inputs:' in HYDRO

def test_hidden_increase_click_filter():
    assert HYDRO.count('getattr(self,"_visible_observed_events",[])') >= 2

def test_tooltips_and_source_message():
    assert 'source_message:' in CTL
    assert 'item.setToolTip(full_detail)' in HYDRO
    assert 'Source line:' in HYDRO

def test_no_duplicate_mainwindow_methods():
    tree=ast.parse(MAIN)
    mw=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='MainWindow')
    seen=set()
    for n in mw.body:
        if isinstance(n,ast.FunctionDef):
            assert n.name not in seen, n.name
            seen.add(n.name)
