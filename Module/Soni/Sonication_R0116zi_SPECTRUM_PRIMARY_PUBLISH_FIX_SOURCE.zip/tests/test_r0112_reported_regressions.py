from pathlib import Path

ROOT=Path(__file__).parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
REG=(ROOT/'src/services/registration_overlay_service.py').read_text(encoding='utf-8')


def test_reference_and_treatment_rows_visible_by_default():
    assert 'show_reference_images_check' not in MAIN
    assert 'show_treatment_mr_images_check' not in MAIN
    assert 'Reference, Treatment MR and Treatment Thermal rows are always visible' in MAIN


def test_reference_and_treatment_thumbnails_are_background_loaded():
    assert 'class ImageThumbnailWorker(QObject)' in MAIN
    assert 'self._start_image_thumbnail_background()' in MAIN
    build=MAIN.split('def _build_frame_navigator',1)[1].split('def _planning_array_for_asset',1)[0]
    assert 'read_magnitude(frame.path)' not in build
    assert 'preview=self._decode_planning_image(asset)' not in build


def test_thermal_cache_rebuild_has_no_obsolete_checkbox_gate():
    block=MAIN.split('def _thermal_thumbnail_ready',1)[1].split('def _thermal_thumbnail_finished',1)[0]
    assert 'show_thermal_images_check' not in block
    assert '_rebuild_all_image_strips()' in block


def test_registration_selected_mr_committed_before_overlay():
    block=MAIN.split('def _activate_image_payload',1)[1].split('def _registration_toggled',1)[0]
    base=block.index('self.overlay.set_overlay(array,None')
    reg=block.index('self._apply_registration_overlay()')
    assert base < reg


def test_registration_current_slice_qa_receives_mr():
    assert 'mr: np.ndarray | None = None' in REG
    assert 'mr=np.asarray(mr,float),slice_tolerance_mm=1.5' in REG
    assert 'if mr is not None else {}' in REG


def test_ci_increase_hidden_by_default():
    assert 'self.ci_show_increase_events_check.setChecked(False)' in MAIN
    block=MAIN.split('def _update_ci_linked_panel',1)[1].split('def _make_ci_collapsible_section',1)[0]
    assert '.lower()!="increase"' in block


def test_cavitation_state_is_detailed_and_increase_only_not_cavitation():
    block=MAIN.split('def _build_one_sonication_summary',1)[1].split('def _refresh_sonication_summary',1)[0]
    assert 'non_increase=' in block
    assert 'Increase only×' in block
    assert 'No cavitation-control event' in block
    assert 'cav_status="Cavitation"' not in block


def test_ci_table_full_text_access():
    assert 'setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)' in MAIN
    assert 'cellDoubleClicked.connect(self._ci_linked_event_detail_popup)' in MAIN
    assert 'Cavitation event detail' in MAIN


def test_umbrella_phase_does_not_bypass_3d_projection():
    paint=MAIN.split('class SonicationElementMapWidget',1)[1].split('class SkullElementWindow',1)[0]
    assert "phase_mode = self.layout_mode.startswith('Phase dedicated')" in paint
    assert "and self.layout_mode.startswith('Umbrella')" not in paint.split('def paintEvent',1)[1].split('def wheelEvent',1)[0]
    assert 'self._umbrella_drag_last=event.position()' in paint


def test_summary_heavy_analysis_deferred_until_tab_open():
    load=MAIN.split('def _package_load_finished',1)[1].split('def _deferred_study_load',1)[0]
    assert '_seed_sonication_summary_fast()' in load
    assert '_refresh_sonication_summary()' not in load
    assert '_sonication_summary_needs_detail=True' in load
