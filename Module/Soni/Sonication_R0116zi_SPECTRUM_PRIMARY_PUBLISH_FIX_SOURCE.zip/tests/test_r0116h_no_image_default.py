from pathlib import Path
ROOT=Path(__file__).parents[1]
MAIN=(ROOT/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_image_io_is_opt_in_and_default_off():
    assert 'self.load_images_toggle = QCheckBox("Load images")' in MAIN
    assert 'self.load_images_toggle.setChecked(False)' in MAIN
    assert 'OFF (default): do not load/decode images or thumbnails' in MAIN
