from pathlib import Path


def test_vendor_tab_protects_chart_visibility_and_usability():
    text = Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    assert 'self.vendor_energy_plot.setMinimumHeight(260)' in text
    assert 'self.vendor_power_plot.setMinimumHeight(290)' in text
    assert 'self.vendor_power_plot.showAxis("right")' in text
    assert 'self.vendor_legend_label' in text
    assert "Control overview" in text
    assert "Selected receiver" in text
    assert "All 8 receivers" in text
    assert "All 8 receivers" in text
    assert "Smooth 100 ms" in text
    assert "Sync cursor" in text
