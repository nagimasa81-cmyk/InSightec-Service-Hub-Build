from pathlib import Path
import gzip
import struct
import time
import numpy as np

from src.services.hydrophone_replay_service import HydrophoneReplayService


def _write_pair(root: Path, frames: int = 8, padding: int = 4096):
    channels, bins, fs = 8, 256, 2_000_000
    header = struct.pack('<6I', 100, frames, channels, 16384, bins, fs) + b'\0' * 8 + struct.pack('<d', 670_000.0)
    payload = bytearray()
    for frame_index in range(frames):
        for channel_index in range(channels):
            values = np.zeros(bins, dtype='<f4')
            values[80 + frame_index] = channel_index + 1
            payload += struct.pack('<I', bins) + values.tobytes() + b'\0' * 48
        payload += b'\0' * padding
    fft = root / 'Spectrum_perf.dmp_FFT'
    raw = root / 'Spectrum_perf.dmp'
    with gzip.open(fft, 'wb') as stream:
        stream.write(header + payload)
    with gzip.open(raw, 'wb') as stream:
        stream.write(struct.pack('<I', frames) + b'\0' * 128)
    return fft, raw


def test_vectorized_marker_scan_still_decodes_valid_8ch_frames(tmp_path):
    fft, raw = _write_pair(tmp_path)
    replay = HydrophoneReplayService().build_direct(fft, raw, include_vendor_validation=False)
    assert len(replay.frames) == 8
    assert all(len(frame.channels) == 8 for frame in replay.frames)
    assert replay.decoder_confidence == 'validated_fft'
    assert 'validation deferred' in replay.note


def test_fft_marker_scan_is_vectorized_not_python_full_file_loop():
    source = (Path(__file__).parents[1] / 'src/services/hydrophone_replay_service.py').read_text(encoding='utf-8')
    assert 'candidate_word_indices = np.flatnonzero' in source
    assert 'for off in range(0, len(blob)-4, 4)' not in source


def test_standalone_analyzer_decode_runs_off_gui_thread():
    source = (Path(__file__).parents[1] / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'class SpectrumDecodeWorker(QObject)' in source
    assert 'worker.moveToThread(thread)' in source
    assert 'thread.started.connect(worker.run)' in source
    assert 'include_vendor_validation=False' in source
    open_region = source[source.index('def open_loaded_workspace'):source.index('def load_dump_candidate')]
    assert 'QTimer.singleShot(1200' not in open_region


def test_final_frame_band_table_search_uses_c_level_signature_scan():
    source = (Path(__file__).parents[1] / 'src/services/hydrophone_replay_service.py').read_text(encoding='utf-8')
    assert "backing.find(needle" in source
    assert "for start in range(search_start, search_end - table_size + 1, 2)" not in source


def test_background_preload_uses_fast_primary_decode():
    source = (Path(__file__).parents[1] / 'src/ui/main_window.py').read_text(encoding='utf-8')
    worker = source[source.index('class SpectrumPreloadWorker'):source.index('class ImageThumbnailWorker')]
    assert worker.count('include_vendor_validation=False') == 2
