from __future__ import annotations

from dataclasses import dataclass, replace
import math
import numpy as np

from src.services.hydrophone_replay_service import CpcHydrophoneReplay


@dataclass(slots=True)
class CavitationLikelihoodResult:
    likelihood_map: np.ndarray
    x_coords: np.ndarray
    y_coords: np.ndarray
    hydrophone_positions: np.ndarray
    focus_xy: tuple[float, float]
    per_channel_scores: np.ndarray
    dominant_channel: int | None
    centroid_xy: tuple[float, float] | None
    summary: str
    evidence: str
    acoustic_centroid_xy: tuple[float, float] | None = None
    mr_centroid_xy: tuple[float, float] | None = None
    acoustic_weight: float = 1.0
    mr_weight: float = 0.0
    fusion_confidence: float | None = None


class CavitationLikelihoodService:
    """Estimate a probable cavitation region from hydrophone contributions.

    This is an evidence-first visualization aid, not a deterministic locator.
    It creates a 2D likelihood field from the dominant/contributing hydrophone
    pattern, biases the field toward the focus, and reports the probable region
    relative to the focus.
    """

    # Schematic 8CH receiver ring around the sonication focus.  The exact site
    # geometry can be swapped later without changing the UI contract.
    # Default physical RCV layout from the provided receiver-location reference.
    # RCV0-RCV3 are Cap receivers (inner square); RCV4-RCV7 are Tile receivers (outer square).
    # These are normalized reference-geometry coordinates, not anatomical patient coordinates.
    DEFAULT_POSITIONS = np.asarray([
        (-0.42,  0.32),  # RCV0 — Cap
        ( 0.42,  0.32),  # RCV1 — Cap
        ( 0.42, -0.32),  # RCV2 — Cap
        (-0.42, -0.32),  # RCV3 — Cap
        (-0.72,  0.72),  # RCV4 — Tile
        ( 0.72,  0.72),  # RCV5 — Tile
        ( 0.72, -0.72),  # RCV6 — Tile
        (-0.72, -0.72),  # RCV7 — Tile
    ], dtype=float)
    RECEIVER_FAMILY = ("Cap", "Cap", "Cap", "Cap", "Tile", "Tile", "Tile", "Tile")
    FOCUS_XY = (0.0, 0.0)

    def _rule_weights(self, replay: CpcHydrophoneReplay, family: str, rule_index: int) -> np.ndarray | None:
        profile = getattr(replay, 'vendor_profile', None)
        if profile is None:
            return None
        if family == 'Increase' and rule_index == 0 and profile.increase_rule0 is not None:
            return np.asarray(profile.increase_rule0.weights, float)
        if family == 'Decrease':
            rule = profile.decrease_rules.get(rule_index)
            return None if rule is None else np.asarray(rule.weights, float)
        if family == 'Safety':
            rule = profile.safety_rules.get(rule_index)
            return None if rule is None else np.asarray(rule.weights, float)
        if family == 'Dynamic':
            rule = profile.dynamic_rules.get(rule_index)
            return None if rule is None else np.asarray(rule.weights, float)
        return None

    def _frame_by_cycle(self, replay: CpcHydrophoneReplay, cycle: int | None):
        """Return the nearest real FFT snapshot for a control-log cycle.

        Control events and SpectrumDumps are sampled on different cycle grids, so
        exact cycle equality is not a valid synchronization requirement.
        """
        if cycle is None or not replay.frames:
            return None, None, None
        candidates=[]
        for index, frame in enumerate(replay.frames):
            fc=getattr(frame, 'acquisition_cycle', None)
            if fc is None:
                continue
            try: candidates.append((abs(int(fc)-int(cycle)), index, frame, int(fc)-int(cycle)))
            except Exception: continue
        if not candidates:
            return None, None, None
        _dist,index,frame,delta=min(candidates,key=lambda x:(x[0],x[1]))
        return frame,index,delta

    def _scores_from_event(self, replay: CpcHydrophoneReplay, event) -> tuple[np.ndarray, str]:
        event_cycle=getattr(event, 'cycle', None)
        frame, frame_index, delta_cycle = self._frame_by_cycle(replay, event_cycle)
        if frame is None or np.asarray(frame.vendor_band_energies).shape != (8, 4):
            return np.zeros(8, float), 'No usable FFT snapshot could be mapped to the observed control event.'
        frame_cycle=getattr(frame,'acquisition_cycle',None)
        link=(f"event cycle {event_cycle} → nearest FFT snapshot {frame_index+1}"
              + (f" / cycle {frame_cycle} / Δcycle {delta_cycle:+d}" if frame_cycle is not None and delta_cycle is not None else ""))
        energies = np.asarray(frame.vendor_band_energies, float)
        weights = self._rule_weights(replay, getattr(event, 'family', ''), int(getattr(event, 'rule_index', -1)))
        if weights is not None and weights.shape == (8, 4):
            scores = np.sum(energies * np.maximum(weights, 0.0), axis=1)
            evidence = f"Observed {event.family} rule {event.rule_index}; {link}; weighted by vendor rule coefficients."
            return scores, evidence
        channels = tuple(getattr(event, 'contributing_channels', ()) or ())
        bands = tuple(getattr(event, 'contributing_bands', ()) or ())
        if channels and bands:
            scores = np.zeros(8, float)
            for ch in channels:
                scores[ch] = float(np.sum(energies[ch, list(bands)]))
            evidence = f"Observed {event.family} rule {event.rule_index}; {link}; summed across contributing hydrophones/bands."
            return scores, evidence
        # fallback to dominant hydrophone only
        scores = np.zeros(8, float)
        dom = getattr(event, 'dominant_channel', None)
        if dom is not None:
            scores[int(dom)] = float(getattr(event, 'dominant_energy', 1.0) or 1.0)
            evidence = f"Observed {event.family} rule {event.rule_index}; {link}; dominant hydrophone emphasis fallback."
            return scores, evidence
        return np.sum(energies, axis=1), f'Observed {getattr(event, "family", "control")} rule {getattr(event, "rule_index", "?")}; {link}; event could not be matched to rule weights; using summed per-channel energy.'

    def _scores_from_frame(self, replay: CpcHydrophoneReplay, frame_index: int) -> tuple[np.ndarray, str]:
        if not replay.frames or not (0 <= frame_index < len(replay.frames)):
            return np.zeros(8, float), 'No current FFT snapshot.'
        frame = replay.frames[frame_index]
        if np.asarray(frame.vendor_band_energies).shape == (8, 4):
            scores = np.max(np.asarray(frame.vendor_band_energies, float), axis=1)
            cyc = getattr(frame, 'acquisition_cycle', None)
            cyc_txt = f' (cycle {cyc})' if cyc is not None else ''
            return scores, f'Dump-only estimate from FFT snapshot {frame_index+1}{cyc_txt}; per-channel maximum Band0–3 energy.'
        return np.zeros(8, float), 'Vendor Band0–3 energies are unavailable in this FFT snapshot.'

    @staticmethod
    def _normalize_scores(scores: np.ndarray) -> np.ndarray:
        scores = np.asarray(scores, float)
        scores = np.where(np.isfinite(scores) & (scores > 0), scores, 0.0)
        total = float(np.sum(scores))
        return (scores / total) if total > 0 else scores

    @staticmethod
    def _region_text(point: tuple[float, float] | None) -> str:
        if point is None:
            return 'undetermined'
        x, y = point
        horiz = 'right' if x > 0.12 else 'left' if x < -0.12 else 'central'
        vert = 'anterior' if y > 0.12 else 'posterior' if y < -0.12 else 'central'
        if horiz == 'central' and vert == 'central':
            return 'central near focus'
        if horiz == 'central':
            return vert
        if vert == 'central':
            return horiz
        return f'{vert}-{horiz}'

    def _build_map(self, norm_scores: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, tuple[float, float] | None]:
        n = 220
        xs = np.linspace(-1.05, 1.05, n)
        ys = np.linspace(-1.05, 1.05, n)
        xx, yy = np.meshgrid(xs, ys)
        field = np.zeros_like(xx, dtype=float)
        focus = np.asarray(self.FOCUS_XY, float)
        positions = np.asarray(self.DEFAULT_POSITIONS, float)
        for ch, weight in enumerate(norm_scores):
            if weight <= 0:
                continue
            p = positions[ch]
            v = focus - p
            length = float(np.linalg.norm(v))
            if length <= 1e-8:
                continue
            u = v / length
            dx = xx - p[0]
            dy = yy - p[1]
            proj = (dx * u[0] + dy * u[1]) / length
            perp = np.abs(dx * u[1] - dy * u[0])
            longitudinal = np.exp(-0.5 * ((proj - 0.72) / 0.26) ** 2)
            radial = np.exp(-0.5 * (perp / 0.12) ** 2)
            gate = (proj >= 0.0) & (proj <= 1.20)
            field += weight * longitudinal * radial * gate
        focus_prior = np.exp(-0.5 * (((xx - focus[0]) ** 2 + (yy - focus[1]) ** 2) / (0.18 ** 2)))
        field += 0.35 * focus_prior * float(np.sum(norm_scores > 0)) / max(1, len(norm_scores))
        maxv = float(np.max(field)) if field.size else 0.0
        if maxv > 0:
            field /= maxv
        total = float(np.sum(field))
        centroid = None
        if total > 0:
            centroid = (float(np.sum(field * xx) / total), float(np.sum(field * yy) / total))
        return field, xs, ys, centroid

    @staticmethod
    def _resize_bilinear(array: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
        src=np.asarray(array,float)
        h,w=map(int,shape)
        if src.shape==(h,w): return src.copy()
        if src.ndim!=2 or src.size==0: return np.zeros((h,w),float)
        sy=np.linspace(0,src.shape[0]-1,h); sx=np.linspace(0,src.shape[1]-1,w)
        y0=np.floor(sy).astype(int); x0=np.floor(sx).astype(int)
        y1=np.minimum(y0+1,src.shape[0]-1); x1=np.minimum(x0+1,src.shape[1]-1)
        wy=sy-y0; wx=sx-x0
        a=src[y0[:,None],x0[None,:]]; b=src[y0[:,None],x1[None,:]]
        c=src[y1[:,None],x0[None,:]]; d=src[y1[:,None],x1[None,:]]
        return ((1-wy)[:,None]*((1-wx)[None,:]*a+wx[None,:]*b)+wy[:,None]*((1-wx)[None,:]*c+wx[None,:]*d))

    def refine_with_mr(self, result: CavitationLikelihoodResult, mr_correlation) -> CavitationLikelihoodResult:
        """Fuse receiver evidence with MR magnitude loss without an intracranial prior.

        Acoustic evidence already contains measured RCV band strengths and the
        vendor/FUS receiver weighting for the active rule. MR evidence contributes
        only when a coherent magnitude-loss region is available. No skull circle
        clips the candidate field, so extracranial solutions remain possible.
        """
        if result is None or mr_correlation is None:
            return result
        acoustic=np.asarray(result.likelihood_map,float)
        loss=np.asarray(getattr(mr_correlation,'loss_map',[]),float)
        if acoustic.ndim!=2 or not acoustic.size or loss.ndim!=2 or not loss.size:
            return result
        mr=self._resize_bilinear(loss,acoustic.shape)
        mr=np.where(np.isfinite(mr)&(mr>0),mr,0.0)
        if np.max(mr)>0: mr/=float(np.max(mr))
        acoustic=np.where(np.isfinite(acoustic)&(acoustic>0),acoustic,0.0)
        if np.max(acoustic)>0: acoustic/=float(np.max(acoustic))
        # Receiver evidence remains primary. MR gets more influence only when the
        # signal-loss detector itself reports coherent loss.
        strong_frac=float(getattr(mr_correlation,'strong_loss_fraction_percent',0.0) or 0.0)
        corr=float(getattr(mr_correlation,'correlation_score',0.0) or 0.0)/100.0
        mr_strength=float(np.clip(max(corr, min(1.0,strong_frac/3.0)),0.0,1.0))
        mr_w=0.15+0.30*mr_strength if np.max(mr)>0 else 0.0
        ac_w=1.0-mr_w
        fused=ac_w*acoustic+mr_w*mr
        if np.max(fused)>0: fused/=float(np.max(fused))
        total=float(np.sum(fused)); centroid=None
        if total>0:
            yy,xx=np.mgrid[0:fused.shape[0],0:fused.shape[1]]
            # Map pixels back to the receiver-reference coordinates of the result.
            xvals=np.linspace(float(result.x_coords[0]),float(result.x_coords[-1]),fused.shape[1])
            yvals=np.linspace(float(result.y_coords[0]),float(result.y_coords[-1]),fused.shape[0])
            xgrid=np.broadcast_to(xvals,(fused.shape[0],fused.shape[1]))
            ygrid=np.broadcast_to(yvals[:,None],(fused.shape[0],fused.shape[1]))
            centroid=(float(np.sum(fused*xgrid)/total),float(np.sum(fused*ygrid)/total))
        confidence=float(np.clip(100.0*(0.60*np.max(acoustic)+0.40*mr_strength),0,100)) if fused.size else None
        evidence=(result.evidence+f" MR fusion: acoustic {ac_w:.2f}, MR {mr_w:.2f}; "
                  f"MR strong-loss {strong_frac:.2f}%, correlation {corr*100:.0f}/100. "
                  "No intracranial clipping applied.")
        summary=(result.summary+f" Integrated candidate: {self._region_text(centroid)}; "
                 f"fusion confidence {confidence:.0f}/100." if confidence is not None else result.summary)
        return replace(result, likelihood_map=fused, centroid_xy=centroid, summary=summary, evidence=evidence,
                       acoustic_centroid_xy=result.centroid_xy, mr_centroid_xy=getattr(mr_correlation,'loss_centroid_xy',None),
                       acoustic_weight=ac_w, mr_weight=mr_w, fusion_confidence=confidence)

    def estimate(self, replay: CpcHydrophoneReplay, frame_index: int, observed_event=None) -> CavitationLikelihoodResult:
        if observed_event is not None:
            scores, evidence = self._scores_from_event(replay, observed_event)
        else:
            scores, evidence = self._scores_from_frame(replay, frame_index)
        # calibration.ini IsEnabled is authoritative for RCV participation.
        enabled=np.asarray(getattr(replay,"receiver_enabled",(True,)*8),bool)
        if enabled.size < 8:
            enabled=np.pad(enabled,(0,8-enabled.size),constant_values=True)
        scores=np.asarray(scores,float).copy()
        scores[:8]=np.where(enabled[:8],scores[:8],0.0)
        disabled_txt=', '.join(f"RCV{i}" for i,v in enumerate(enabled[:8]) if not bool(v))
        if disabled_txt:
            evidence += f" calibration.ini disabled receivers excluded: {disabled_txt}."
        norm_scores = self._normalize_scores(scores)
        field, xs, ys, centroid = self._build_map(norm_scores)
        dominant = int(np.argmax(norm_scores)) if np.any(norm_scores > 0) else None
        contrib_txt = ', '.join(f"RCV{idx} {100*v:.1f}%" for idx, v in enumerate(norm_scores) if v > 0.01)
        dom_txt = f"RCV{dominant}" if dominant is not None else 'none'
        region = self._region_text(centroid)
        summary = f"Dominant receiver: {dom_txt}. Probable cavitation region: {region}. Contributors: {contrib_txt or 'none'}"
        return CavitationLikelihoodResult(
            likelihood_map=field,
            x_coords=xs,
            y_coords=ys,
            hydrophone_positions=np.asarray(self.DEFAULT_POSITIONS, float),
            focus_xy=self.FOCUS_XY,
            per_channel_scores=norm_scores,
            dominant_channel=dominant,
            centroid_xy=centroid,
            summary=summary,
            evidence=evidence,
        )
