from __future__ import annotations

from dataclasses import dataclass
import numpy as np


@dataclass(slots=True)
class CavitationMrCorrelationResult:
    loss_map: np.ndarray
    correlated_map: np.ndarray
    current_image: np.ndarray
    signal_loss_percent: float
    strong_loss_fraction_percent: float
    loss_centroid_xy: tuple[float, float] | None
    likelihood_centroid_xy: tuple[float, float] | None
    centroid_distance_norm: float | None
    overlap_score: float | None
    correlation_score: float | None
    confidence: str
    summary: str


class CavitationMrCorrelationService:
    """Compare magnitude signal loss with a hydrophone likelihood map.

    The service deliberately returns a *correlation* rather than a location
    assertion.  The hydrophone map is in normalized receiver-reference
    coordinates and is mapped to the displayed MR plane for visual comparison.
    This is suitable for screening and event review while a full 3-D patient
    coordinate transform remains under validation.
    """

    @staticmethod
    def _resize_bilinear(array: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
        src = np.asarray(array, float)
        h, w = int(shape[0]), int(shape[1])
        if src.shape == (h, w):
            return src.copy()
        if src.ndim != 2 or src.size == 0 or h <= 0 or w <= 0:
            return np.zeros((max(0, h), max(0, w)), float)
        sy = np.linspace(0, src.shape[0] - 1, h)
        sx = np.linspace(0, src.shape[1] - 1, w)
        y0 = np.floor(sy).astype(int); y1 = np.minimum(y0 + 1, src.shape[0] - 1)
        x0 = np.floor(sx).astype(int); x1 = np.minimum(x0 + 1, src.shape[1] - 1)
        wy = sy - y0; wx = sx - x0
        a = src[y0[:, None], x0[None, :]]
        b = src[y0[:, None], x1[None, :]]
        c = src[y1[:, None], x0[None, :]]
        d = src[y1[:, None], x1[None, :]]
        return ((1 - wy)[:, None] * ((1 - wx)[None, :] * a + wx[None, :] * b)
                + wy[:, None] * ((1 - wx)[None, :] * c + wx[None, :] * d))

    @staticmethod
    def _gain_normalize(reference: np.ndarray, current: np.ndarray) -> tuple[np.ndarray, float]:
        ref = np.asarray(reference, float)
        cur = np.asarray(current, float)
        valid = np.isfinite(ref) & np.isfinite(cur) & (ref > 0) & (cur > 0)
        if np.count_nonzero(valid) < 64:
            return cur, 1.0
        # Use the middle signal distribution, excluding very dark background
        # and the hottest/highest-intensity tail, to avoid a local void driving
        # the global receive-gain correction.
        refv = ref[valid]
        lo, hi = np.nanpercentile(refv, [20.0, 85.0])
        stable = valid & (ref >= lo) & (ref <= hi)
        if np.count_nonzero(stable) < 64:
            stable = valid
        ref_med = float(np.nanmedian(ref[stable]))
        cur_med = float(np.nanmedian(cur[stable]))
        gain = ref_med / max(cur_med, 1e-9)
        return cur * gain, gain

    @staticmethod
    def _centroid(weight: np.ndarray) -> tuple[float, float] | None:
        arr = np.asarray(weight, float)
        arr = np.where(np.isfinite(arr) & (arr > 0), arr, 0.0)
        total = float(np.sum(arr))
        if total <= 0:
            return None
        h, w = arr.shape
        yy, xx = np.mgrid[0:h, 0:w]
        cx = float(np.sum(arr * xx) / total)
        cy = float(np.sum(arr * yy) / total)
        # normalized display coordinates: x/y in [-1, 1]
        nx = 2.0 * cx / max(1.0, w - 1.0) - 1.0
        ny = 1.0 - 2.0 * cy / max(1.0, h - 1.0)
        return nx, ny

    def analyze(
        self,
        baseline_frames: list[np.ndarray],
        current: np.ndarray,
        hydrophone_likelihood: np.ndarray | None,
    ) -> CavitationMrCorrelationResult:
        cur = np.asarray(current, float)
        refs = [np.asarray(a, float) for a in baseline_frames if np.asarray(a).shape == cur.shape]
        if cur.ndim != 2 or not refs:
            empty = np.zeros(cur.shape if cur.ndim == 2 else (0, 0), float)
            return CavitationMrCorrelationResult(empty, empty, empty, 0.0, 0.0, None, None, None, None, None, "Unavailable", "MR magnitude baseline unavailable")
        reference = np.nanmedian(np.stack(refs, axis=0), axis=0)
        normalized, _gain = self._gain_normalize(reference, cur)
        valid = np.isfinite(reference) & np.isfinite(normalized) & (reference > 0)
        ratio = np.ones_like(reference, float)
        ratio[valid] = normalized[valid] / np.maximum(reference[valid], 1e-9)
        # Positive value means signal loss.  Suppress tiny frame-to-frame noise.
        loss = np.where(valid, np.clip(1.0 - ratio, 0.0, 0.75), 0.0)
        loss = np.where(loss >= 0.08, loss, 0.0)

        # Focus on connected-looking changes by a small local averaging kernel.
        p = np.pad(loss, 1, mode="edge")
        smooth = sum(p[dy:dy + loss.shape[0], dx:dx + loss.shape[1]] for dy in range(3) for dx in range(3)) / 9.0
        strong = smooth >= 0.20
        loss_pct = float(100.0 * np.nanmedian(np.clip(1.0 - ratio[valid], 0.0, 1.0))) if np.any(valid) else 0.0
        strong_fraction = float(100.0 * np.mean(strong[valid])) if np.any(valid) else 0.0
        loss_centroid = self._centroid(smooth)

        likelihood_centroid = None
        overlap = None
        corr_score = None
        correlated = smooth.copy()
        if hydrophone_likelihood is not None and np.asarray(hydrophone_likelihood).size:
            hp = self._resize_bilinear(np.asarray(hydrophone_likelihood, float), cur.shape)
            hp = np.where(np.isfinite(hp), np.clip(hp, 0.0, None), 0.0)
            if np.max(hp) > 0:
                hp = hp / float(np.max(hp))
            likelihood_centroid = self._centroid(hp)
            correlated = smooth * hp
            denom = float(np.sum(smooth))
            overlap = float(np.sum(correlated) / denom) if denom > 0 else 0.0
            # A correlation score combines overlap and amount of coherent loss.
            loss_strength = min(1.0, float(np.nanpercentile(smooth[valid], 98)) / 0.35) if np.any(valid) else 0.0
            corr_score = float(100.0 * np.clip(0.65 * overlap + 0.35 * loss_strength, 0.0, 1.0))

        distance = None
        if loss_centroid is not None and likelihood_centroid is not None:
            distance = float(np.hypot(loss_centroid[0] - likelihood_centroid[0], loss_centroid[1] - likelihood_centroid[1]))

        if corr_score is None:
            confidence = "MR-only"
        elif corr_score >= 65 and (distance is None or distance <= 0.45):
            confidence = "High candidate"
        elif corr_score >= 40:
            confidence = "Moderate candidate"
        else:
            confidence = "Low candidate"
        summary = (
            f"MR magnitude loss median={loss_pct:.1f}% · strong-loss pixels={strong_fraction:.2f}%"
            + (f" · hydrophone/MR overlap={overlap:.2f} · score={corr_score:.0f}/100" if overlap is not None and corr_score is not None else "")
            + (f" · centroid distance={distance:.2f}" if distance is not None else "")
            + f" · {confidence}"
        )
        return CavitationMrCorrelationResult(
            loss_map=smooth,
            correlated_map=correlated,
            current_image=cur.copy(),
            signal_loss_percent=loss_pct,
            strong_loss_fraction_percent=strong_fraction,
            loss_centroid_xy=loss_centroid,
            likelihood_centroid_xy=likelihood_centroid,
            centroid_distance_norm=distance,
            overlap_score=overlap,
            correlation_score=corr_score,
            confidence=confidence,
            summary=summary,
        )
