from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable
import math
import numpy as np


@dataclass(slots=True)
class RootCauseFactor:
    key: str
    label: str
    contribution: float
    confidence: str
    evidence: str
    improvement: str
    available: bool = True


@dataclass(slots=True)
class CavitationRootCauseResult:
    sonication_number: int
    cavitation_detected: bool
    severity: str
    confidence: str
    root_cause_score: float
    factors: list[RootCauseFactor] = field(default_factory=list)
    summary: str = ""
    warning: str = ""
    metrics: dict[str, float | str | None] = field(default_factory=dict)

    @property
    def ranked_factors(self) -> list[RootCauseFactor]:
        return sorted((f for f in self.factors if f.available), key=lambda f: f.contribution, reverse=True)


class CavitationRootCauseService:
    """Evidence-weighted explanation of why cavitation appeared in a Sonication.

    The service deliberately reports *contributing evidence*, not a proven biological
    cause.  A factor is scored only when its source data are available. Missing data
    never become an assumed risk factor.
    """

    @staticmethod
    def _finite(value):
        try:
            value = float(value)
        except (TypeError, ValueError):
            return None
        return value if math.isfinite(value) else None

    @staticmethod
    def _clip100(value: float) -> float:
        return float(np.clip(value, 0.0, 100.0))

    @staticmethod
    def _event_strength(events: Iterable) -> tuple[float, str, bool]:
        ratios=[]; families=[]; detected=False
        for ev in events or ():
            family=str(getattr(ev, 'family', '') or '')
            result=str(getattr(ev, 'result', '') or '')
            is_cav = family in {'Decrease','Safety','Dynamic'} or 'CAVITATION' in result.upper() or 'HALT' in result.upper()
            if not is_cav:
                # Increase rules are normal control behavior and must never be promoted
                # into root-cause evidence for cavitation merely because they contain
                # an energy/threshold pair.
                continue
            detected=True
            if family: families.append(family)
            e=CavitationRootCauseService._finite(getattr(ev,'weighted_energy',None))
            t=CavitationRootCauseService._finite(getattr(ev,'threshold',None))
            c=CavitationRootCauseService._finite(getattr(ev,'critical_threshold',None))
            denom=c if c and c > 0 else t
            if e is not None and denom is not None and denom > 0:
                ratios.append(e/denom)
        if ratios:
            peak=max(ratios)
            score=CavitationRootCauseService._clip100(35.0 + 65.0*min(1.35, peak)/1.35)
            detail=f"peak weighted-energy/limit={peak:.2f}; event families={','.join(sorted(set(families))) or '--'}"
            return score, detail, detected
        if detected:
            return 75.0, f"control event present; families={','.join(sorted(set(families))) or '--'}", True
        return 0.0, "no decrease/safety/dynamic cavitation event in the synchronized control timeline", False

    @staticmethod
    def _rcv_concentration(replay) -> tuple[float | None, str]:
        if replay is None or not getattr(replay, 'frames', None):
            return None, 'CPC/RCV frames unavailable'
        rows=[]
        for fr in replay.frames:
            en=np.asarray(getattr(fr,'vendor_band_energies',[]),float)
            if en.shape==(8,4) and np.isfinite(en).any():
                rows.append(np.nansum(np.clip(en,0,None),axis=1))
        if not rows:
            return None, 'vendor Band0–3 per-receiver energy unavailable'
        ch=np.nanmax(np.vstack(rows),axis=0)
        total=float(np.nansum(ch))
        if total <= 0:
            return 0.0, 'receiver energy is zero'
        share=float(np.nanmax(ch)/total)
        dominant=int(np.nanargmax(ch))
        score=CavitationRootCauseService._clip100((share-0.125)/0.50*100.0)
        return score, f"dominant RCV{dominant} share={share*100:.1f}% of peak per-receiver Band0–3 energy"

    @staticmethod
    def _multiband_escalation(replay) -> tuple[float | None, str]:
        if replay is None or not getattr(replay,'frames',None):
            return None, 'CPC spectrum unavailable'
        matrices=[]
        for fr in replay.frames:
            en=np.asarray(getattr(fr,'vendor_band_energies',[]),float)
            if en.shape==(8,4) and np.isfinite(en).any(): matrices.append(en)
        if len(matrices)<2:
            return None, 'not enough CPC snapshots for an escalation trend'
        arr=np.stack(matrices)
        trace=np.nansum(np.clip(arr,0,None),axis=(1,2))
        n=max(1,min(len(trace)//3,8))
        baseline=float(np.nanmedian(trace[:n]))
        peak=float(np.nanmax(trace))
        if baseline <= 0:
            return None, 'positive acoustic baseline unavailable'
        ratio=peak/baseline
        score=CavitationRootCauseService._clip100((ratio-1.0)/3.0*100.0)
        return score, f"peak total vendor-band energy / early baseline={ratio:.2f}×"

    @staticmethod
    def _drive_score(power, treatment_power_median, previous_power, energy, duration) -> tuple[float | None,str]:
        p=CavitationRootCauseService._finite(power)
        if p is None:
            return None,'measured/planned power unavailable'
        refs=[]
        m=CavitationRootCauseService._finite(treatment_power_median)
        pp=CavitationRootCauseService._finite(previous_power)
        if m and m>0: refs.append(('treatment median',p/m))
        if pp and pp>0: refs.append(('previous Sonication',p/pp))
        if refs:
            peak_ref=max(r for _,r in refs)
            score=CavitationRootCauseService._clip100(50.0+(peak_ref-1.0)*80.0)
            ref_text='; '.join(f"{name}={ratio:.2f}×" for name,ratio in refs)
        else:
            score=35.0; ref_text='no treatment/prior power reference'
        e=CavitationRootCauseService._finite(energy); d=CavitationRootCauseService._finite(duration)
        extra=(f"; energy={e:.0f} J" if e is not None else '')+(f"; duration={d:.2f} s" if d is not None else '')
        return score,f"power={p:.0f} W; {ref_text}{extra}"

    @staticmethod
    def _thermal_score(start_temp, peak_temp, delta_temp, previous_peak_temp) -> tuple[float | None,str]:
        st=CavitationRootCauseService._finite(start_temp); pk=CavitationRootCauseService._finite(peak_temp)
        dt=CavitationRootCauseService._finite(delta_temp); prev=CavitationRootCauseService._finite(previous_peak_temp)
        if all(v is None for v in (st,pk,dt,prev)):
            return None,'thermometry unavailable'
        components=[]
        if st is not None:
            components.append(np.clip((st-37.0)/8.0,0,1))
        if dt is not None:
            components.append(np.clip(dt/20.0,0,1))
        if pk is not None:
            components.append(np.clip((pk-50.0)/15.0,0,1))
        if prev is not None:
            components.append(0.6*np.clip((prev-50.0)/15.0,0,1))
        score=100.0*float(max(components)) if components else 0.0
        parts=[]
        if st is not None: parts.append(f"start={st:.1f}°C")
        if pk is not None: parts.append(f"peak={pk:.1f}°C")
        if dt is not None: parts.append(f"ΔT={dt:.1f}°C")
        if prev is not None: parts.append(f"previous peak={prev:.1f}°C")
        return CavitationRootCauseService._clip100(score),'; '.join(parts)

    def analyze(self, *, sonication_number:int, events, replay=None, power=None,
                treatment_power_median=None, previous_power=None, energy=None, duration=None,
                start_temp=None, peak_temp=None, delta_temp=None, previous_peak_temp=None,
                previous_cavitation:bool|None=None, mr_correlation_score=None) -> CavitationRootCauseResult:
        factors=[]
        event_score,event_evidence,detected=self._event_strength(events)
        factors.append(RootCauseFactor('event','Cavitation control threshold crossing',event_score,'High' if events is not None else 'Unavailable',event_evidence,
            'Reduce escalation before the same threshold region; verify which vendor rule/band/RCV triggered first.',events is not None))

        multi_score,multi_ev=self._multiband_escalation(replay)
        factors.append(RootCauseFactor('multiband','Rapid acoustic multi-band escalation',multi_score or 0.0,'High' if multi_score is not None else 'Unavailable',multi_ev,
            'Use the earliest rising acoustic signature as a pre-cavitation warning and limit further power escalation.',multi_score is not None))

        drive_score,drive_ev=self._drive_score(power,treatment_power_median,previous_power,energy,duration)
        factors.append(RootCauseFactor('drive','High acoustic drive / escalation',drive_score or 0.0,'Moderate' if drive_score is not None else 'Unavailable',drive_ev,
            'Use smaller power increments or a lower peak drive while confirming thermal response.',drive_score is not None))

        thermal_score,thermal_ev=self._thermal_score(start_temp,peak_temp,delta_temp,previous_peak_temp)
        factors.append(RootCauseFactor('thermal','Thermal preconditioning / accumulated heating',thermal_score or 0.0,'Moderate' if thermal_score is not None else 'Unavailable',thermal_ev,
            'Allow more cooling or avoid repeating high drive while the target remains thermally elevated.',thermal_score is not None))

        rcv_score,rcv_ev=self._rcv_concentration(replay)
        factors.append(RootCauseFactor('rcv','Localized RCV contribution concentration',rcv_score or 0.0,'Moderate' if rcv_score is not None else 'Unavailable',rcv_ev,
            'Review focus/phase/element loading and whether the same receiver dominance repeats across Sonications.',rcv_score is not None))

        if previous_cavitation is None:
            factors.append(RootCauseFactor('history','Prior-Sonication cavitation history',0.0,'Unavailable','previous Sonication cavitation evidence unavailable',
                'Compare with the immediately preceding Sonication when treatment history is available.',False))
        else:
            score=70.0 if previous_cavitation else 0.0
            ev='previous Sonication also had a cavitation-control event' if previous_cavitation else 'no cavitation-control event in previous Sonication'
            factors.append(RootCauseFactor('history','Prior-Sonication cavitation history',score,'Moderate',ev,
                'If recurrent, treat the event as history-dependent and reduce escalation / extend cooling before retry.',True))

        mrc=self._finite(mr_correlation_score)
        factors.append(RootCauseFactor('mr','MR change correlated with acoustic candidate',mrc or 0.0,'Moderate' if mrc is not None else 'Unavailable',
            f"hydrophone/MR correlation score={mrc:.0f}/100" if mrc is not None else 'MR correlation unavailable',
            'If acoustic and MR changes co-localize, review the registered location before further escalation.',mrc is not None))

        ranked=sorted((f for f in factors if f.available),key=lambda f:f.contribution,reverse=True)
        # The aggregate is deliberately dominated by the strongest evidence rather than by the number of available streams.
        top=[f.contribution for f in ranked[:3]]
        aggregate=float(np.average(top,weights=[0.55,0.30,0.15][:len(top)])) if top else 0.0
        if detected:
            aggregate=max(aggregate,55.0)
        severity='High' if aggregate>=75 else 'Moderate' if aggregate>=50 else 'Low'
        avail=sum(f.available for f in factors)
        confidence='High' if avail>=6 and events is not None and replay is not None else 'Moderate' if avail>=3 else 'Low'
        names=', '.join(f.label for f in ranked[:3]) if ranked else 'insufficient evidence'
        state='Cavitation detected' if detected else 'No confirmed cavitation-control event'
        summary=f"{state}. Most supported contributors: {names}. RCA score {aggregate:.0f}/100 ({confidence} evidence coverage)."
        warning=''
        if not detected and ranked and ranked[0].contribution>=65:
            warning=f"Pre-cavitation warning candidate: {ranked[0].label} is elevated despite no confirmed control event."
        return CavitationRootCauseResult(
            sonication_number=sonication_number,cavitation_detected=detected,severity=severity,
            confidence=confidence,root_cause_score=aggregate,factors=factors,summary=summary,warning=warning,
            metrics={'power_w':self._finite(power),'energy_j':self._finite(energy),'duration_s':self._finite(duration),
                     'start_temp_c':self._finite(start_temp),'peak_temp_c':self._finite(peak_temp),'delta_temp_c':self._finite(delta_temp)}
        )
