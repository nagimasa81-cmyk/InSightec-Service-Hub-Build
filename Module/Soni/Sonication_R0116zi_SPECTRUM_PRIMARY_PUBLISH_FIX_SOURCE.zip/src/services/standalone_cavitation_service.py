from __future__ import annotations

from dataclasses import dataclass, field
import math
import numpy as np


@dataclass(slots=True)
class CavitationEvent:
    snapshot_index: int
    acquisition_cycle: int | None
    time_s: float | None
    channel: int
    band: int
    energy: float
    baseline: float | None
    robust_z: float | None
    severity: str
    evidence: str
    rule: str = ""
    action: str = ""


@dataclass(slots=True)
class StandaloneCavitationAnalysis:
    mode: str
    timing_status: str
    band_status: str
    rule_status: str
    inferred_bands: dict[int, tuple[float, float, float]] = field(default_factory=dict)
    events: list[CavitationEvent] = field(default_factory=list)
    energy_cube: np.ndarray = field(default_factory=lambda: np.empty((0, 8, 4), dtype=float))
    robust_z_cube: np.ndarray = field(default_factory=lambda: np.empty((0, 8, 4), dtype=float))
    summary: str = ""


class StandaloneCavitationService:
    """Evidence-first cavitation analysis that can run from Spectrum dumps alone.

    The embedded 8 x 4 energy table is used directly.  When the vendor INI is
    unavailable, Band0..Band3 are intentionally not assigned a physical meaning
    or a control threshold.  Instead, robust within-dump outliers are surfaced
    as *cavitation candidates*, never as confirmed vendor-rule events.
    """

    @staticmethod
    def _robust_z(values: np.ndarray) -> np.ndarray:
        arr=np.asarray(values,float)
        out=np.full(arr.shape,np.nan,float)
        if arr.size == 0:
            return out
        finite=arr[np.isfinite(arr)]
        if finite.size < 3:
            return out
        med=float(np.nanmedian(finite))
        mad=float(np.nanmedian(np.abs(finite-med)))
        # IQR fallback is useful for very quiet bands whose median absolute
        # deviation can legitimately collapse to zero.
        scale=1.4826*mad
        if not np.isfinite(scale) or scale <= np.finfo(float).eps:
            q25,q75=np.nanpercentile(finite,[25,75]); scale=max(float((q75-q25)/1.349), np.finfo(float).eps)
        out[np.isfinite(arr)]=(arr[np.isfinite(arr)]-med)/scale
        return out

    @staticmethod
    def _rule_value(energies: np.ndarray, weights: np.ndarray) -> float:
        e=np.asarray(energies,float); w=np.asarray(weights,float)
        if e.shape != (8,4) or w.shape != (8,4):
            return float('nan')
        return float(np.nansum(e*w))

    def infer_band_ranges(self, replay) -> dict[int, tuple[float, float, float]]:
        """Recover Band0..Band3 bin ranges from FFT + embedded energy alone.

        For each band, search contiguous FFT-bin intervals and select the range
        whose float32 sum reproduces the embedded per-channel band energy across
        several snapshots.  The returned confidence value is the maximum
        relative reproduction error; exact vendor ranges are normally near
        floating-point noise.
        """
        frames=[f for f in (getattr(replay,'frames',[]) or []) if np.asarray(getattr(f,'vendor_band_energies',[])).shape==(8,4)]
        if not frames:
            return {}
        frames=frames[:min(8,len(frames))]
        freq=np.asarray(getattr(frames[0],'frequency_hz',[]),float)
        if freq.size < 2:
            return {}
        observations=[]; targets={b:[] for b in range(4)}
        for frame in frames:
            if len(getattr(frame,'uncalibrated_channels',[])) < 8:
                continue
            e=np.asarray(frame.vendor_band_energies,float)
            for ch in range(8):
                a=np.asarray(frame.uncalibrated_channels[ch],dtype=np.float32)
                if a.size != freq.size:
                    continue
                observations.append(a)
                for b in range(4): targets[b].append(float(e[ch,b]))
        if not observations:
            return {}
        obs=np.asarray(observations,dtype=np.float32)
        # Prefix sums with float64 accumulation do not reproduce float32 exactly,
        # but are sufficient to locate the interval; candidate is rechecked with
        # float32 sum below.
        csum=np.concatenate([np.zeros((obs.shape[0],1),dtype=np.float64),np.cumsum(obs.astype(np.float64),axis=1)],axis=1)
        result={}
        n=freq.size
        for band in range(4):
            target=np.asarray(targets[band],float)
            scale=max(float(np.nanmax(np.abs(target))),1e-12)
            best=None
            for i in range(n):
                # vectorize all end positions j > i
                pred=csum[:,i+1:]-csum[:,i,None]
                errors=np.nanmax(np.abs(pred-target[:,None]),axis=0)/scale
                jrel=int(np.nanargmin(errors)); err=float(errors[jrel]); j=i+jrel
                if best is None or err < best[0]: best=(err,i,j)
            if best is None:
                continue
            _err,i,j=best
            # Recheck using the same float32 summation semantics used by the
            # decoder's vendor-energy validation.
            exact_errors=[]
            for row,a in enumerate(obs):
                calc=float(np.sum(np.asarray(a[i:j+1],np.float32),dtype=np.float32))
                exact_errors.append(abs(calc-target[row]))
            max_abs=float(max(exact_errors)) if exact_errors else float('inf')
            relative=max_abs/scale
            # Bin centers define the vendor graph integration range. Store
            # inclusive low/high bin frequencies and relative error.
            if relative <= 1e-5:
                result[band]=(float(freq[i]),float(freq[j]),float(relative))
        return result

    def analyze(self, replay, requested_mode: str = "Auto Evidence-First", z_threshold: float = 6.0) -> StandaloneCavitationAnalysis:
        frames=list(getattr(replay,'frames',[]) or [])
        rows=[]
        for frame in frames:
            values=np.asarray(getattr(frame,'vendor_band_energies',[]),float)
            if values.shape == (8,4):
                rows.append(values)
        cube=np.asarray(rows,float) if rows else np.empty((0,8,4),float)
        enabled=np.asarray(getattr(replay,'receiver_enabled',(True,)*8),bool)
        if cube.size and enabled.size>=8:
            cube[:,~enabled[:8],:]=np.nan
        profile=getattr(replay,'vendor_profile',None)
        has_ini=bool(profile is not None and getattr(profile,'source_ini',None) is not None)
        exact_times=bool(frames and all(getattr(f,'acquisition_time_s',None) is not None and np.isfinite(float(f.acquisition_time_s)) for f in frames))
        timing_status="Exact acquisition-cycle mapping" if exact_times else "Snapshot order only — acquisition time unavailable"
        inferred=self.infer_band_ranges(replay) if not has_ini else {}
        if has_ini:
            band_status="Vendor Band0–Band3 definitions loaded from CavitationSafetyAndControl.ini"
        elif len(inferred)==4:
            ranges=", ".join(f"B{b} {lo/1e3:.1f}–{hi/1e3:.1f} kHz" for b,(lo,hi,_err) in sorted(inferred.items()))
            band_status=f"Band0–Band3 ranges reconstructed from FFT-to-embedded-energy equality: {ranges}"
        else:
            band_status="Embedded Band0–Band3 IDs decoded; complete physical band ranges could not be reconstructed"
        rule_status="Vendor control/safety rules available" if has_ini else "Vendor thresholds/actions unavailable — candidate detection only"
        mode=("Vendor Rule + Dump" if has_ini and requested_mode != "SpectrumDumps Only" else "SpectrumDumps Only")
        if cube.size == 0:
            return StandaloneCavitationAnalysis(mode,timing_status,band_status,rule_status,inferred,summary="No embedded 8CH × 4-band energy table was decoded from the selected Spectrum dump.")

        zcube=np.full(cube.shape,np.nan,float)
        for ch in range(8):
            for band in range(4):
                zcube[:,ch,band]=self._robust_z(cube[:,ch,band])
        events=[]

        # Always expose strong dump-local outliers.  With no INI these are the
        # only detection statements we make, and are explicitly labelled Candidate.
        for i in range(cube.shape[0]):
            frame=frames[i]
            for ch in range(8):
                if enabled.size>=8 and not bool(enabled[ch]):
                    continue
                for band in range(4):
                    energy=float(cube[i,ch,band]); z=float(zcube[i,ch,band]) if np.isfinite(zcube[i,ch,band]) else None
                    if z is None or z < float(z_threshold):
                        continue
                    baseline=float(np.nanmedian(cube[:,ch,band]))
                    events.append(CavitationEvent(
                        i, getattr(frame,'acquisition_cycle',None), getattr(frame,'acquisition_time_s',None), ch, band,
                        energy, baseline, z, "Candidate", "Dump-only robust energy excursion"
                    ))

        # If the exact vendor rule file is present, additionally evaluate every
        # decoded decrease/safety/dynamic rule at each FFT snapshot.  This is a
        # snapshot-level reproduction; continuous 10-ms behavior still requires
        # the raw history/log evidence and is not fabricated here.
        if has_ini:
            rule_sets=[("Decrease",getattr(profile,'decrease_rules',{})),("Safety",getattr(profile,'safety_rules',{})),("Dynamic",getattr(profile,'dynamic_rules',{}))]
            for i in range(cube.shape[0]):
                frame=frames[i]
                for family,rules in rule_sets:
                    for idx,rule in sorted(rules.items()):
                        threshold=getattr(rule,'threshold',None)
                        if threshold is None or not np.isfinite(float(threshold)):
                            continue
                        value=self._rule_value(cube[i],getattr(rule,'weights',np.empty((0,0))))
                        if not np.isfinite(value) or value <= float(threshold):
                            continue
                        active=np.argwhere(np.asarray(rule.weights,float)!=0)
                        channels=sorted({int(ch) for ch,_ in active}) if active.size else []
                        bands=sorted({int(b) for _,b in active}) if active.size else []
                        action="Threshold exceeded"
                        if family == "Decrease" and getattr(rule,'power_ratio',None) is not None:
                            action=f"Power decrease {100.0*float(rule.power_ratio):.1f}%"
                        elif family == "Safety":
                            action=f"Safety failure counter ({getattr(rule,'max_failures',None) or '-'} / {getattr(rule,'max_failure_window_ms',None) or '-'} ms)"
                        elif family == "Dynamic":
                            action=f"Dynamic counter / SubSonication {getattr(rule,'switch_to_subsonication',None) if getattr(rule,'switch_to_subsonication',None) is not None else '-'}"
                        # One event represents the rule.  Use channel=-1 when it
                        # combines multiple hydrophones; its exact CH set is kept in evidence.
                        events.append(CavitationEvent(
                            i,getattr(frame,'acquisition_cycle',None),getattr(frame,'acquisition_time_s',None),
                            channels[0] if len(channels)==1 else -1, bands[0] if len(bands)==1 else -1,
                            value,float(threshold),None,"Rule Trigger","Vendor INI snapshot evaluation",
                            f"{family} Rule {idx} (CH {','.join(map(str,channels))}; Band {','.join(map(str,bands))})",action
                        ))

        # deterministic ordering: time/snapshot then confirmed rule before candidates
        events.sort(key=lambda e:(e.snapshot_index, 0 if e.severity=="Rule Trigger" else 1, e.channel, e.band))
        confirmed=sum(e.severity=="Rule Trigger" for e in events)
        candidates=sum(e.severity=="Candidate" for e in events)
        summary=(f"{cube.shape[0]} FFT snapshots × 8 hydrophones × 4 embedded bands analyzed. "
                 f"Vendor-rule triggers={confirmed}; dump-only candidates={candidates}. "
                 f"{timing_status}. {band_status}. {rule_status}.")
        return StandaloneCavitationAnalysis(mode,timing_status,band_status,rule_status,inferred,events,cube,zcube,summary)
