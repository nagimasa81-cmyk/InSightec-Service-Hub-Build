from pathlib import Path


def test_main_window_same_frame_requests_refresh():
    text = Path("src/ui/main_window.py").read_text(encoding="utf-8")
    assert "if after == before:" in text
    assert "self.replay_context.refresh()" in text


def test_verify_bat_executes_pytest():
    text = Path("00_VERIFY_SOURCE.bat").read_text(encoding="utf-8").lower()
    assert "python -m pytest -q" in text


def test_snapshot_indices_are_consumed_by_spectrum_renderer():
    main = Path("src/ui/main_window.py").read_text(encoding="utf-8")
    renderer = Path("src/core/current_spectrum_renderer.py").read_text(encoding="utf-8")
    assert "frame_indices=dict(snapshot.spectrum_indices)" in main
    assert "frame_indices: dict[str, int] | None" in renderer
