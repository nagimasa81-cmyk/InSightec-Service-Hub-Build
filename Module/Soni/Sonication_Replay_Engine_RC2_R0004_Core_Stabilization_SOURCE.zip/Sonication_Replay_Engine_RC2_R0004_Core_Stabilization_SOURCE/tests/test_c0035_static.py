from pathlib import Path
TEXT=Path("src/ui/main_window.py").read_text(encoding="utf-8")

def test_initial_main_view_is_displayed():
    assert 'initial_mode = "thermal" if self.current.temperature_frames else "anatomy"' in TEXT
    assert 'self.replay_context.refresh()' in TEXT
    assert 'self._main_image_mode = initial_mode' in TEXT

def test_all_three_rows_have_identical_source_choices():
    for label in ("Planning CT", "Planning MR", "Anatomy MR", "Thermal", "All images"):
        assert label in TEXT
    assert 'image_row_options' in TEXT
    assert 'planning_ct' in TEXT and 'planning_mr' in TEXT

def test_temperature_spectrum_split_prioritizes_temperature():
    assert 'self.graph_split.setStretchFactor(0, 65)' in TEXT
    assert 'self.graph_split.setStretchFactor(1, 35)' in TEXT
    assert 'self.graph_split.setSizes([650, 350])' in TEXT

def test_acoustic_curves_are_not_recreated_per_frame():
    section=TEXT.split('def _update_acoustic_cards',1)[1].split('def ',1)[0]
    assert '_ensure_acoustic_curve_items()' not in section
    assert "enableAutoRange(axis='x', enable=False)" in TEXT

def test_xd_has_editable_continuous_scale():
    assert 'self.scale_max = QDoubleSpinBox()' in TEXT
    assert ('gradient_image = QImage(1, 256' in TEXT) and ('reversed(self._lut)' in TEXT)
    assert 'for i in range(5)' in TEXT
