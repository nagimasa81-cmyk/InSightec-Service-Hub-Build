# R0189 — DQA observed-focus geometry visibility and hard-gate removal

## Root cause fixed
R0188 removed planned focalRAS as the displacement zero point, but the observed thermometry hotspot search still effectively constrained candidate selection around the planned location. That can suppress the very large displacement DQA is intended to measure. In addition, Summary values could not be visually reconciled because the selected circle centre / lower line / +20 mm reference / observed focus pixels were not shown in Replay.

## R0189 contract
- Search the full validated thermometry interior for the strongest coherent 3x3 hotspot; no planned-position hard rejection.
- Planned SonicationSummary focalRAS is only a near-equal-peak tie-break seed, never a displacement zero point.
- Prefer the magnitude raster paired with the actual thermometry acquisition for phantom reference extraction when available.
- Axial: X/Y = observed focus minus phantom circle centre in the selected same raster.
- Sagittal: evaluate the lower phantom line at the observed focus X position; Z = observed focus minus lower-line +20 mm reference.
- Pixel-derived RAS delta and direct RAS delta must agree within 0.25 mm or the affected component fails closed.
- Cache-only Replay diagnostic overlay visualizes the exact selected geometry and does not trigger DQA analysis or workspace I/O.

## Replay diagnostics
- Observed focus
- Phantom circle centre
- Lower line at focus X
- Lower line +20 mm reference
- Measurement vectors and R0189 X/Y/Z annotation

## Validation
- DQA/focus regression tests: 68/68 PASS.
- compileall: PASS.
- verify_source.py: VERIFY_SOURCE_OK.
- Package audit performed after cache cleanup.
