# R0188 Triple Check

1. Coordinate semantics
   - No direct Locate-workstation XYZ minus MR-RAS subtraction.
   - No `registered_focal - phantom_reference` path in `analyze_series()`.
   - Planned `SonicationSummary.focalRAS` is search seed only.
   - Observed thermometry hotspot is converted with the exact owning MriImageParams row.

2. Same-raster geometry
   - Axial phantom circle stores per-slice pixel + RAS candidates.
   - Sagittal lower line stores per-slice pixel + RAS candidates.
   - Closest compatible slice is selected from actual focus RAS.
   - Focus is projected into that selected raster before subtraction.
   - Sagittal +20 mm reference is itself projected/back-projected in the selected raster.
   - Missing/invalid geometry fails closed.

3. UI / lifecycle / regression
   - Series result remains calculated once after Summary rows complete.
   - DQA service cache is cleared immediately before the authoritative series calculation.
   - Tooltip identifies R0188 contract and exact pixel/RAS evidence.
   - DQA regression suite: 57 PASS.
   - compileall PASS; VERIFY_SOURCE_OK.
   - R0187 baseline comparison performed to distinguish pre-existing test failures.
