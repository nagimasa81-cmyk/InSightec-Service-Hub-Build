# TRIPLE CHECK R0189

1. Measurement semantics
   - No planned focalRAS displacement zero point.
   - No planned-position hard gate for observed thermometry hotspot.
   - Planned focalRAS is only a near-equal-peak tie-break seed.
   - Sagittal baseline is evaluated at focus X before applying the +20 mm Z reference.

2. Coordinate / raster integrity
   - Selected reference and focus are carried as both pixel and RAS diagnostics.
   - Pixel-space delta transformed through exact row direction cosines / spacing is cross-checked against direct RAS delta.
   - >0.25 mm disagreement fails closed instead of emitting an alignment number.
   - Replay diagnostic overlay uses calculator cache only and never starts analysis or file loading.

3. Regression / packaging
   - DQA/focus tests: 68 PASS.
   - compileall PASS.
   - verify_source.py: VERIFY_SOURCE_OK.
   - Build identity / source_version updated to R0189.
   - Duplicate ZIP names, build-contract count, nested source trees, and pycache/pyc are audited before release.
