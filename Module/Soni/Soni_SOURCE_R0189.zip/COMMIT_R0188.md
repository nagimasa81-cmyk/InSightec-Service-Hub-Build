# R0188 — DQA same-raster observed-focus alignment

## Root cause fixed
R0187 series DQA used `SonicationSummary.focalRAS` as the numeric MR-RAS focus after only using Locate Transducer coordinates as evidence. That contradicted the existing contract that `focalRAS` is planned-focus evidence and caused Summary XYZ to disagree with the displayed phantom geometry.

## R0188 contract
- `SonicationSummary.focalRAS` is a local hotspot-search seed only; never a displacement zero point.
- Observed focus is recovered from validated thermometry with exact MriImageParams binding.
- Axial X/Y: observed focus is projected into the nearest compatible DQA-Axial phantom raster and compared with that raster's detected phantom-circle centre.
- Sagittal Z: observed focus is projected into the nearest compatible DQA-Sagittal phantom raster and compared with that raster's detected lower line +20.0 mm superior.
- If observed focus/reference cannot be established in a compatible raster, the component fails closed instead of manufacturing a number.
- Electronic steering remains a judgement exclusion; it is not folded into the physical reference.

## Diagnostics
Summary tooltip now reports exact selected reference frame, reference pixel, focus projection pixel, slice-plane distance, lower-line-to-focus S distance and final component values.

## Validation
- DQA tests: 57/57 PASS.
- Focused R0188/R0185-R0187 contract tests: 17/17 PASS.
- compileall: PASS.
- verify_source.py: VERIFY_SOURCE_OK.
- Broad historical R0154-R0188 run: 212 PASS / 6 legacy failures; same untouched R0187 baseline has 211 PASS / 8 failures. No new R0188 regression was identified; remaining six failures are pre-existing stale assertions in unrelated Spectrum preload / temperature / diagnostics areas or unused historical helper wording.
