# Hydrophone Reverse Engineering Lab (C0022)

This commit separates evidence collection from Replay rendering.

## Inputs

- `SpectrumMsg-*.dmp` in Sonication folders
- `Acquisition*.dmp`, Reflection and CavitationControl DMP candidates in CPCFiles
- `Acquisition_Brain*.txt` telemetry
- Sonication `.act` / local configuration for Main Frequency and configured CH

## Outputs

- `hydrophone_reverse_engineering_report.json`
- `binary_candidates.csv`
- `telemetry_summary.csv`

Every finding is labelled `Confirmed`, `Estimated`, or `Unknown`. Candidate arrays are not automatically promoted into Acoustic Spectrum rendering.

## Current confirmed mapping

- Power percent is parsed from `AblPowerRatio × 100`.
- Score percent is parsed from `Calculated Energy / Bottom Limit Of Harmless Energy × 100`.

## Questions intentionally left open

- Exact SpectrumMsg block header and channel field
- Whether Acquisition DMP contains raw hydrophone waveform, FFT, or DSP intermediate data
- Workstation FFT window, overlap, smoothing and amplitude scaling
- Baseline subtraction and Score integration window
- CH multiplexing order when no explicit channel field is found
