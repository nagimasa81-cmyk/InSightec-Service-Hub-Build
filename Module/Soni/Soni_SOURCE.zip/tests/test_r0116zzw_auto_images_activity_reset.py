from pathlib import Path
import ast

ROOT=Path(__file__).parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
PROGRESS=(ROOT/'src/ui/progress_window.py').read_text(encoding='utf-8')
TREE=ast.parse(MAIN)
MW=next(n for n in TREE.body if isinstance(n,ast.ClassDef) and n.name=='MainWindow')
METHODS={n.name:n for n in MW.body if isinstance(n,ast.FunctionDef)}

def body(name):
    n=METHODS[name]; lines=MAIN.splitlines(); return '\n'.join(lines[n.lineno-1:n.end_lineno])

def test_default_on_does_not_emit_during_widget_construction():
    assert 'self.load_images_toggle.setChecked(True)' in MAIN
    assert MAIN.index('self.load_images_toggle.setChecked(True)') < MAIN.index('self.load_images_toggle.toggled.connect(self._image_loading_toggled)')

def test_current_sonication_images_are_first_staged_operation():
    b=body('_load_selected_stage')
    assert '(14, "Current Sonication images", self._selected_stage_navigator)' in b
    assert b.index('Current Sonication images') < b.index('Spectrum and timing')

def test_initial_spectrum_preload_is_deferred_until_after_image_request():
    b=body('_package_load_finished')
    assert '_select_sonication_index(0)' in b
    assert '_start_initial_spectrum_preload_after_images' in b
    assert b.index('_select_sonication_index(0)') < b.index('_start_initial_spectrum_preload_after_images')

def test_first_treatment_mr_can_publish_before_full_image_cache():
    b=body('_essential_image_frame_ready')
    assert 'int(row) == 0' in b
    assert 'self.overlay.set_overlay(arr, None, fit=True)' in b

def test_image_progress_is_separate_nonmodal_owner():
    assert 'self._image_progress = BackgroundProgressDialog(self)' in MAIN
    assert '_image_progress' in body('_begin_image_load_progress')
    assert '_exclusive_progress' not in body('_begin_image_load_progress')
    assert 'WindowModality.NonModal' in PROGRESS

def test_activity_window_reports_threads_pending_rss_and_caches():
    assert 'class BackgroundActivityWindow(QDialog)' in MAIN
    b=body('_background_activity_snapshot')
    for token in ('QThread','_process_rss_bytes','cache_rows','_pending'):
        assert token in b

def test_activity_and_reset_controls_use_existing_scroll_panel():
    assert 'self.background_activity_btn = QPushButton("Activity")' in MAIN
    assert 'self.reset_menu_btn = QToolButton()' in MAIN
    assert 'Restore previous view' in MAIN
    assert 'Reset current study view' in MAIN
    assert 'Unload study (before file load)' in MAIN

def test_reset_paths_are_generation_safe_and_can_release_workspace():
    unload=body('_unload_current_study')
    assert '_prepare_source_switch' in unload
    assert 'self.importer.release(workspace)' in unload
    restore=body('_restore_view_state')
    assert '_restoring_view_state' in restore
    assert '_select_sonication_index' in restore

def test_inflight_package_result_can_be_discarded_after_unload():
    assert '_discard_package_load_result' in body('_package_load_finished')

def test_no_duplicate_mainwindow_methods():
    names=[n.name for n in MW.body if isinstance(n,ast.FunctionDef)]
    assert len(names)==len(set(names))
