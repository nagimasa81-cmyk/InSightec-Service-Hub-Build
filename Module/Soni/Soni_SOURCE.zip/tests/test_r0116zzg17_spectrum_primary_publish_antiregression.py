from pathlib import Path

SRC = Path(__file__).parents[1] / "src" / "ui" / "hydrophone_window.py"

def test_primary_publish_resolves_latest_replay_not_queued_identity():
    text = SRC.read_text(encoding="utf-8")
    assert "def _publish_primary_latest" in text
    assert "def _ensure_primary_materialized" in text
    assert "_primary_materialized_signature" in text
    assert "QTimer.singleShot(80" in text
    assert "QTimer.singleShot(300" in text

def test_spectrum_has_current_frame_visible_range_and_no_silent_empty_recovery():
    text = SRC.read_text(encoding="utf-8")
    assert "def _current_spectrum_y_range" in text
    assert "drawn_curve_count" in text
    assert "Decoded frames must never fail silently" in text

def test_preirradiation_is_not_lost_when_irradiation_start_is_zero():
    text = SRC.read_text(encoding="utf-8")
    assert 'if aligned_t < start-eps:' in text
    assert 'MR Spectrum timeline 0.000–' in text
