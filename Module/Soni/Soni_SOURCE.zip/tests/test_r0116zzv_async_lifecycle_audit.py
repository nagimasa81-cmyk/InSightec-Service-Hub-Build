from pathlib import Path
import ast

MAIN_PATH=Path('src/ui/main_window.py')
HYDRO_PATH=Path('src/ui/hydrophone_window.py')
MAIN=MAIN_PATH.read_text(encoding='utf-8')
HYDRO=HYDRO_PATH.read_text(encoding='utf-8')


def _class(path,name):
    tree=ast.parse(Path(path).read_text(encoding='utf-8'))
    return next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name)


def _method(path,clsname,name):
    src=Path(path).read_text(encoding='utf-8'); cls=_class(path,clsname)
    fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==name)
    return fn, ast.get_source_segment(src,fn) or ''


def _call_names(fn):
    out=[]
    for n in ast.walk(fn):
        if not isinstance(n,ast.Call): continue
        f=n.func
        out.append(f.attr if isinstance(f,ast.Attribute) else f.id if isinstance(f,ast.Name) else '')
    return out


def test_no_gui_thread_wait_calls():
    assert '.wait(' not in MAIN
    assert '.wait(' not in HYDRO


def test_mainwindow_direct_heavy_io_is_worker_callback_only():
    cls=_class(MAIN_PATH,'MainWindow')
    heavy={'rglob','glob','read_text','read_bytes','fromfile','open_source','discover','discover_from_files',
           'build_direct','read_snapshots','find_and_read','read_temperature','read_magnitude','temperature_metrics','temperature_trend'}
    allowed={'_build_one_sonication_temperature_summary','_decode_planning_image'}
    offenders={}
    for fn in [n for n in cls.body if isinstance(n,ast.FunctionDef)]:
        hits=heavy.intersection(_call_names(fn))
        if hits and fn.name not in allowed: offenders[fn.name]=sorted(hits)
    assert offenders=={}


def test_hydrophone_dialog_has_no_direct_source_or_decode_io():
    cls=_class(HYDRO_PATH,'EightHydrophoneWindow')
    heavy={'rglob','glob','read_text','read_bytes','fromfile','open_source','discover','discover_from_files','build_direct'}
    offenders={}
    for fn in [n for n in cls.body if isinstance(n,ast.FunctionDef)]:
        hits=heavy.intersection(_call_names(fn))
        if hits: offenders[fn.name]=sorted(hits)
    assert offenders=={}


def test_cursor_temperature_trend_is_cache_only():
    fn,body=_method(MAIN_PATH,'MainWindow','_rebuild_cursor_temperature_trend')
    calls=set(_call_names(fn))
    assert 'frame' not in calls
    assert 'read_temperature' not in calls
    assert '_thermal_thumbnail_cache' in body


def test_probable_location_mr_fallback_is_cache_only():
    fn,body=_method(MAIN_PATH,'MainWindow','_draw_ci_linked_rcv_probable')
    calls=set(_call_names(fn))
    assert 'read_magnitude' not in calls
    assert '_treatment_mr_thumbnail_cache' in body


def test_cpc_compatibility_path_cannot_decode_or_discover():
    fn,body=_method(MAIN_PATH,'MainWindow','_build_cpc_replay')
    calls=set(_call_names(fn))
    assert 'build_direct' not in calls
    assert 'discover' not in calls and 'discover_from_files' not in calls
    assert '_spectrum_preload_context' in body
    fn2,_=_method(MAIN_PATH,'MainWindow','_ensure_cpc_binding')
    calls2=set(_call_names(fn2))
    assert 'discover' not in calls2 and 'discover_from_files' not in calls2


def test_deferred_panel_is_single_owner_latest_request():
    _,queue=_method(MAIN_PATH,'MainWindow','_queue_deferred_panel')
    _,finish=_method(MAIN_PATH,'MainWindow','_deferred_panel_thread_finished')
    assert '_deferred_panel_pending' in queue
    assert 'thread.isRunning()' in queue
    assert 'worker.cancel()' in queue
    assert '_start_deferred_panel_request' in finish
    assert '.wait(' not in queue+finish


def test_source_and_sonication_switch_retire_secondary_workers():
    _,source=_method(MAIN_PATH,'MainWindow','_prepare_source_switch')
    _,select=_method(MAIN_PATH,'MainWindow','_select_sonication_index')
    assert '_cancel_deferred_panel_worker' in source
    assert '_cancel_selected_replay_data' in source
    assert '_cancel_spectrum_preload' in source
    assert '_cancel_deferred_panel_worker' in select
    assert '_cancel_selected_replay_data' in select
    assert '_cancel_essential_image_worker' in select


def test_secondary_tabs_only_queue_background_heavy_work():
    for name in ('_refresh_engineering_analysis','_refresh_export_workspaces'):
        fn,body=_method(MAIN_PATH,'MainWindow',name)
        calls=set(_call_names(fn))
        assert 'rglob' not in calls and 'decode_spectrum_structure' not in calls and 'analyze' not in calls
        assert '_queue_deferred_panel' in body
    fn,body=_method(MAIN_PATH,'MainWindow','_load_sonic_snapshots_if_needed')
    calls=set(_call_names(fn))
    assert 'read_snapshots' not in calls and 'find_and_read' not in calls
    assert '_queue_deferred_panel' in body


def test_spectrum_preload_superseded_result_is_not_published():
    _,start=_method(MAIN_PATH,'MainWindow','_start_spectrum_preload')
    _,ready=_method(MAIN_PATH,'MainWindow','_spectrum_preload_ready')
    _,progress=_method(MAIN_PATH,'MainWindow','_spectrum_preload_progressed')
    assert '_spectrum_preload_active_request' in start
    assert '_spectrum_preload_pending' in ready
    assert '_spectrum_preload_pending' in progress


def test_analyzer_source_discovery_is_background_owned():
    for name in ('open_loaded_workspace','open_dump_source','load_package'):
        fn,body=_method(HYDRO_PATH,'EightHydrophoneWindow',name)
        calls=set(_call_names(fn))
        assert 'discover' not in calls and 'discover_from_files' not in calls and 'open_source' not in calls
        assert '_queue_spectrum_source_task' in body
    assert 'class SpectrumSourceWorker' in HYDRO


def test_analyzer_source_switch_invalidates_old_discovery():
    _,body=_method(HYDRO_PATH,'EightHydrophoneWindow','reset_source_context')
    assert '_source_request_id += 1' in body
    assert '_source_pending = None' in body
    assert 'source_worker.cancel()' in body
    assert '.wait(' not in body


def test_no_duplicate_methods_in_primary_ui_classes():
    for path,name in ((MAIN_PATH,'MainWindow'),(HYDRO_PATH,'EightHydrophoneWindow')):
        cls=_class(path,name); names=[n.name for n in cls.body if isinstance(n,ast.FunctionDef)]
        dup=sorted({x for x in names if names.count(x)>1})
        assert dup==[]


def test_planning_selection_and_registration_accessors_are_cache_only():
    for name in ('_planning_array_for_asset','_ct_volume_for_registration'):
        fn,body=_method(MAIN_PATH,'MainWindow',name)
        calls=set(_call_names(fn))
        assert 'fromfile' not in calls and '_decode_planning_image' not in calls
        assert 'rglob' not in calls


def test_set_frame_disallows_disk_fallback():
    _,body=_method(MAIN_PATH,'MainWindow','set_frame')
    assert 'disk_fallback=False' in body


def test_no_runtime_process_events_pumping():
    for path in (MAIN_PATH, HYDRO_PATH, Path('src/ui/progress_window.py')):
        text=path.read_text(encoding='utf-8')
        assert 'QApplication.processEvents()' not in text


def test_spectrum_secondary_analysis_is_worker_owned_and_latest_request_only():
    assert 'class SpectrumSecondaryWorker' in HYDRO
    _,queue=_method(HYDRO_PATH,'EightHydrophoneWindow','_queue_secondary_analysis')
    _,start=_method(HYDRO_PATH,'EightHydrophoneWindow','_start_secondary_analysis')
    _,ready=_method(HYDRO_PATH,'EightHydrophoneWindow','_secondary_analysis_ready')
    assert '_secondary_pending' in queue
    assert 'thread.isRunning()' in queue
    assert 'worker.cancel()' in queue
    assert 'SpectrumSecondaryWorker' in start
    assert 'request_id != self._secondary_request_id' in ready
    assert 'replay is not self.replay' in ready


def test_spectrum_heavy_secondary_draws_are_cache_only():
    for name, forbidden in (
        ('_draw_spectrogram', {'spectrogram'}),
        ('_draw_band_energy', {'band_energy','vendor_band_energy'}),
        ('_refresh_cavitation_analysis', {'analyze'}),
    ):
        fn,body=_method(HYDRO_PATH,'EightHydrophoneWindow',name)
        calls=set(_call_names(fn))
        assert not forbidden.intersection(calls), (name, sorted(forbidden.intersection(calls)))
        assert '_secondary_cache' in body


def test_hidden_1024_element_table_is_lazy():
    _,changed=_method(MAIN_PATH,'MainWindow','_element_snapshot_changed')
    _,toggle=_method(MAIN_PATH,'MainWindow','_element_table_visibility_changed')
    _,populate=_method(MAIN_PATH,'MainWindow','_populate_element_table')
    assert 'self.element_table_toggle.isChecked()' in changed
    assert 'self._populate_element_table(snap)' in changed
    assert 'self.element_table.setRowCount(0)' in toggle
    assert 'self.element_table.setRowCount(len(values))' in populate
    assert 'QTimer.singleShot' in populate
    _,chunk=_method(MAIN_PATH,'MainWindow','_populate_element_table_chunk')
    assert 'batch = 96' in chunk
    assert '_element_table_generation' in chunk
    assert 'insertRow' not in changed
