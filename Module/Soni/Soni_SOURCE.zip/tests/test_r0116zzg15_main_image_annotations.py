from pathlib import Path

ROOT=Path(__file__).parents[1]
META=(ROOT/'src/services/sonication_metadata_service.py').read_text(encoding='utf-8')
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
PANEL=(ROOT/'src/ui/image_panel.py').read_text(encoding='utf-8')

def test_main_image_annotation_overlay_contract():
    for token in ['class MRAnnotationOverlay','def set_mr_annotation','annotation_center','MR acquisition:']:
        assert token in PANEL or token in MAIN

def test_mr_protocol_values_come_from_mri_image_params():
    for token in ['repetitiontimetr','echotimete','varbandwidth','seriesdiscription','Image Center RAS']:
        assert token in META

def test_annotation_uses_cached_metadata_and_updates_from_set_frame():
    block=MAIN.split('def set_frame',1)[1].split('def _workstation_replay_toggled',1)[0]
    assert '_update_main_image_annotation(seconds, data)' in block
    helper=MAIN.split('def _main_image_annotation_payload',1)[1].split('def _update_orientation_alignment_labels',1)[0]
    assert 'self.current_metadata.summary' in helper
    assert 'rglob(' not in helper and 'read_text(' not in helper
