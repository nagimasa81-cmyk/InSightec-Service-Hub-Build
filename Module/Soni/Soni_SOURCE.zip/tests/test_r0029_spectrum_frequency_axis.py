import gzip
import struct
from pathlib import Path

import numpy as np

from src.core.spectrum_decoder import SharedSpectrumDecoder
from src.services.hydrophone_replay_service import HydrophoneReplayService


def test_cpc_graph_axis_uses_acquisition_ini_window():
    payload = bytearray()
    for ch in range(8):
        values = np.zeros(256, dtype='<f4')
        values[215] = 1.0 + ch
        payload += struct.pack('<I', 256) + values.tobytes() + b'\0' * 16
    frames = HydrophoneReplayService._decode_fft_payload(bytes(payload), 1, 8, 2_000_000.0, 250_000.0, 750_000.0)
    assert len(frames) == 1
    freq, channels = frames[0]
    assert np.isclose(freq[0], 250_000.0)
    assert np.isclose(freq[1]-freq[0], 500_000.0/256.0)
    assert np.isclose(freq[215], 669_921.875)
    assert int(np.argmax(channels[0])) == 215


def test_spectrummsg_exact_graph_blocks_reproduce_main_and_half_frequency(tmp_path: Path):
    root = tmp_path / 'Export'
    son = root / 'Sonication1'; son.mkdir(parents=True)
    ini = root / 'CPCFiles' / 'App' / 'Ini' / 'Acquisition.ini'; ini.parent.mkdir(parents=True)
    ini.write_text('[SPECTRUM]\nf1ForGraph=250000\nf2ForGraph=750000\n', encoding='utf-8')
    frame = bytearray(b'\0' * 100)
    for ch in range(8):
        values = np.zeros(256, dtype='<f4')
        values[43] = 0.25
        values[215] = 1.0
        frame += struct.pack('<I', 256) + values.tobytes() + b'\0' * 32
    frame_size = len(frame)
    header = struct.pack('<iii', 1, frame_size, 8) + b'\0' * 180
    msg = son / 'SpectrumMsg-1.dmp'
    msg.write_bytes(gzip.compress(header + bytes(frame)))
    decoded = SharedSpectrumDecoder().decode_frames(msg, 670_000.0)
    assert len(decoded) == 1
    spectrum = decoded[0]
    assert np.isclose(spectrum.frequency_hz[43], 333_984.375)
    assert np.isclose(spectrum.main_peak_hz, 669_921.875)
