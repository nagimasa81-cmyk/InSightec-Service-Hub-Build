from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYD=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
SUM=(ROOT/'src/services/sonication_summary_cavitation_evidence_service.py').read_text(encoding='utf-8')

def test_summary_no_longer_preparses_unbound_workspace_timeline():
    block=MAIN.split('def _build_one_sonication_summary',1)[1].split('def _build_one_sonication_temperature_summary',1)[0]
    assert '_summary_canonical_cavitation_evidence(index,son,None)' in block
    assert 'Path(self.package.workspace), None, preferred' not in block

def test_summary_uses_replay_bound_log_session_vendor_profile_and_cycle_anchor():
    assert 'authoritative_timeline = CavitationControlTimelineService().parse' in SUM
    assert 'getattr(history, "log_session_index", None)' in SUM
    assert 'getattr(replay, "vendor_profile", None)' in SUM
    assert 'getattr(anchor, "acquisition_cycle", None)' in SUM
    assert 'authoritative_events = list(getattr(authoritative_timeline, "events", []) or [])' in SUM

def test_analyzer_selector_consults_shared_repository_before_decode():
    block=HYD.split('def load_sonication',1)[1].split('def _finish_loaded_sonication_handoff',1)[0]
    assert 'self.spectrum_evidence_repository.cached_replay(self.package, index)' in block
    assert 'self._preloaded_replays[index] = cached' in block

def test_loaded_export_decode_worker_uses_shared_repository_not_parallel_direct_decode():
    assert 'repository=(self.spectrum_evidence_repository if sonication_index is not None else None)' in HYD
    worker=HYD.split('class SpectrumDecodeWorker',1)[1].split('def _build_observed_cavitation_timeline_for_replay',1)[0]
    assert 'self.repository.replay(self.package, self.sonication_index, son, relay)' in worker
    assert 'Loaded-Export Sonications must use the same study-scoped repository' in worker
