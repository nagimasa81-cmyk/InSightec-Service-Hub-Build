from pathlib import Path

H=Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")

def test_control_timeline_has_independent_white_replay_cursor():
    assert "def _current_control_time" in H
    assert "def _install_control_replay_cursor" in H
    assert "def _update_control_replay_cursor" in H
    assert 'pg.mkPen("#ffffff",width=2.0' in H
    assert "self._update_control_replay_cursor()" in H

def test_event_rows_survive_why_formatting_error():
    assert "Never let tooltip/Why formatting abort the Event list population" in H
    assert "Event detail formatting warning" in H
    assert "<display error:" in H

def test_control_marker_hit_test_is_pixel_based():
    graph=H.split("def _cavitation_control_plot_clicked",1)[1].split("\n    def ",1)[0]
    assert "mapViewToScene" in graph
    assert "18.0*18.0" in graph
    assert "self._show_event_why_popup(ev, force=True)" in graph

def test_version_is_current_release():
    import json
    expected=json.loads(Path('version.json').read_text())['version']
    assert Path('VERSION').read_text().strip()==expected
