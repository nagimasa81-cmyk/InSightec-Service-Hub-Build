
from pathlib import Path
REG=(Path(__file__).parents[1]/"src/services/registration_overlay_service.py").read_text(encoding="utf-8")
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_forward_inverse_diagnostic_exists():
    assert "forward_pixel_xy" in REG
    assert "inverse_pixel_xy" in REG
    assert "likely_matrix_direction" in REG
    assert "def _matrix_direction_diagnostic" in REG

def test_overlay_matrix_is_not_auto_changed():
    block=REG.split("def _trace_ct_voxel_to_mr_pixel",1)[1].split("def _alignment_score",1)[0]
    assert "overlay itself remains forward/exported" in block

def test_reference_candidate_ranker_exists():
    assert "def diagnose_reference_candidates" in REG
    assert "Geometry-only candidate ranking" in REG

def test_mismatch_classifies_direction_vs_reference():
    block=REG.split("if gross_mismatch:",1)[1].split("return RegistrationOverlayResult",1)[0]
    assert "inverse hypothesis lands inside MR FOV" in block
    assert "both forward and inverse hypotheses miss displayed MR" in block

def test_ui_explains_diagnostic():
    assert "forward outside / inverse inside" in MAIN
    assert "forward outside / inverse outside" in MAIN
