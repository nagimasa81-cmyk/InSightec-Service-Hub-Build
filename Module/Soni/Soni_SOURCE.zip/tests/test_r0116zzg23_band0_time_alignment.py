from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')


def test_band0_reconstruction_is_gap_only_and_uses_shared_reference():
    block=HYDRO.split('def _draw_band_energy',1)[1].split('def _apply_vendor_band_defaults',1)[0]
    assert 'reconstructed gap' in block
    assert 'gap_mask' in block
    assert 'h_scaled[valid_h]/max(ref' in block
    assert 'href=float(np.nanmax' not in block


def test_band0_history_is_snapshot_aligned_before_use():
    block=HYDRO.split('def _draw_band_energy',1)[1].split('def _apply_vendor_band_defaults',1)[0]
    assert 'acquisition_history_index' in block
    assert 'np.median(ratios)' in block
    assert 'rejected_reconstruction=True' in block


def test_ci_linked_charts_use_canonical_mr_axis():
    assert 'def _apply_ci_canonical_mr_axis' in MAIN
    vendor=MAIN.split('def _draw_ci_linked_vendor_energy',1)[1].split('def _draw_ci_linked_control',1)[0]
    control=MAIN.split('def _draw_ci_linked_control',1)[1].split('def _update_ci_linked_panel',1)[0]
    assert '_apply_ci_canonical_mr_axis(plot, replay)' in vendor
    assert '_apply_ci_canonical_mr_axis(plot, replay)' in control
    assert 'sonication_cycle_zero' in control
    assert 'sonication_time_zero_offset_s' not in control
