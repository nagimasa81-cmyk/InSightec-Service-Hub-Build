
from pathlib import Path
REG=(Path(__file__).parents[1]/"src/services/registration_overlay_service.py").read_text(encoding="utf-8")
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")
def test_landmarks():
    b=REG.split("def _skull_landmarks_xyz",1)[1].split("def _series_slice_spacing_mm",1)[0]
    assert '("center"' in b and '("x",2)' in b and '("y",1)' in b and '("z",0)' in b
def test_correspondence():
    assert "def _nearest_slice_for_ras" in REG and "def _series_landmark_correspondence" in REG
def test_scoring():
    b=REG.split("def diagnose_reference_series",1)[1].split("def format_reference_diagnostic",1)[0]
    assert '120.0*forward["match_fraction"]' in b and '"forward_match_fraction"' in b
def test_detail():
    b=REG.split("def format_reference_diagnostic",1)[1].split("def _trace_ct_voxel_to_mr_pixel",1)[0]
    assert "LANDMARK DETAIL" in b and "nearest array=" in b and "sliceDist=" in b
def test_ui():
    assert "high landmark match with low 2D skull QA" in MAIN
