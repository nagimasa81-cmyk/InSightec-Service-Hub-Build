from pathlib import Path
ROOT=Path(__file__).parents[1]
MAIN=(ROOT/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_image_io_is_auto_enabled_only_after_ui_construction():
    assert 'self.load_images_toggle = QCheckBox("Load images")' in MAIN
    assert 'self.load_images_toggle.setChecked(True)' in MAIN
    assert 'ON (default): auto-load the current Sonication Treatment MR first' in MAIN
    assert MAIN.index('self.load_images_toggle.setChecked(True)') < MAIN.index('self.load_images_toggle.toggled.connect(self._image_loading_toggled)')
