from pathlib import Path

SRC = Path('src/ui/main_window.py').read_text(encoding='utf-8')


def block_after(signature: str, next_signature: str) -> str:
    return SRC.split(signature,1)[1].split(next_signature,1)[0]


def test_91_percent_stage_uses_fast_metadata_only():
    block = block_after('def _selected_stage_metadata(self):','def _highest_average_frame')
    assert '_update_sonication_metadata_fast()' in block
    assert '_update_sonication_metadata()' not in block
    assert 'skull_measures_service' not in block


def test_replay_ready_closes_exclusive_progress_without_waiting_for_deferred_panels():
    block = block_after('def _load_selected_stage(self, generation: int, stage: int):','def _selected_stage_spectrum')
    assert 'self._exclusive_progress.finish()' in block
    assert 'additional panels load only when opened' in block


def test_deferred_study_load_does_not_precompute_diagnostics_or_planning():
    block = block_after('def _deferred_study_load(self, workspace_token: Path):','def _start_sonication_summary_background')
    assert 'diagnostics_tab.load_study' not in block
    assert '_update_planning_view()' not in block
    assert '_set_load_progress(97' not in block


def test_sonication_select_does_not_run_legacy_full_refresh():
    block = block_after('def _select_sonication_index(self, index: int):','def _load_selected_stage')
    assert '_refresh_all_sonication_dependent_views()' not in block


def test_detailed_metadata_does_not_scan_skullmeasures():
    block = block_after('def _update_sonication_metadata(self):','def _update_info_window')
    assert 'skull_measures_service.find_and_read' not in block
