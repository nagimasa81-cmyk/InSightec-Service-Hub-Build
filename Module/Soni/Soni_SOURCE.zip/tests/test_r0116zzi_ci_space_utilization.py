from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_ci_uses_full_remaining_height_without_plot_cap():
    s=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'reserve = 215 if compact else 235' in s
    assert 'linked_h = max(220, viewport_h - reserve)' in s
    assert 'w.setMaximumHeight(16777215)' in s
    assert 'stack.setMinimumHeight(linked_h)' in s
    assert 'self.ci_summary.setWordWrap(False)' in s
    assert 'self.ci_temperature_summary.setWordWrap(False)' in s
    assert 'self.ci_explanatory_note.setMaximumHeight(30)' in s
