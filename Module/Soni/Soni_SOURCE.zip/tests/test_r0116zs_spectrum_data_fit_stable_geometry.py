from pathlib import Path


def _text():
    return Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")


def test_all_tabs_fit_plotted_payload_not_mr_duration():
    text=_text()
    block=text[text.index("def _fit_current_tab"):text.index("def _open_loaded_export", text.index("def _fit_current_tab"))]
    assert "_plot_data_x_range" in block
    assert "_mr_fit_range" not in block
    assert "mr_timeline_duration_s" not in block


def test_mr_window_compatibility_function_now_uses_payload_extent():
    text=_text()
    start=text.index("def _apply_mr_timeline_window")
    end=text.index("def _current_control_time", start)
    block=text[start:end]
    assert "_apply_selected_time_window" in block
    assert "setXRange(0.0, end" not in block


def test_analyzer_uses_scroll_shell_and_screen_clamp():
    text=_text()
    assert "self._main_scroll = QScrollArea(self)" in text
    assert "self._main_scroll.setWidgetResizable(True)" in text
    assert "def _clamp_window_to_screen" in text
    assert "self.setMinimumSize(560, 420)" in text
    assert "self.setMaximumSize(16777215, 16777215)" in text


def test_vendor_axes_keep_reserved_geometry():
    text=_text()
    assert 'getAxis("left").setWidth(52)' in text
    assert 'getAxis("right").setWidth(52)' in text
    assert 'getAxis("right").setVisible(show_rule)' not in text
    assert 'getAxis("left").setVisible(show_power)' not in text
