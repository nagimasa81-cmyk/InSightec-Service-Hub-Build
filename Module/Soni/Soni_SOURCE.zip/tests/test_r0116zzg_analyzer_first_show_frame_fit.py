from pathlib import Path

SRC = Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')


def test_first_show_refits_using_native_frame_geometry():
    assert 'def _settle_initial_screen_layout' in SRC
    assert 'frame = self.frameGeometry()' in SRC
    assert 'area = screen.availableGeometry()' in SRC
    assert 'over_h = max(0' in SRC
    assert 'self.width() - over_w' in SRC
    assert 'self.height() - over_h' in SRC


def test_first_show_settle_runs_after_event_loop_and_native_frame_creation():
    assert 'def _schedule_initial_screen_settle' in SRC
    assert 'for delay in (0, 60, 180)' in SRC
    assert 'self._schedule_initial_screen_settle()' in SRC


def test_settle_reuses_resize_fit_pipeline_and_pinned_controls_contract():
    block = SRC[SRC.index('def _settle_initial_screen_layout'):SRC.index('def _schedule_initial_screen_settle')]
    assert 'self._apply_compact_screen_layout()' in block
    assert 'self._fit_tab_vertical_budget()' in block
    assert 'self._fit_current_tab(force=True)' in block
    assert 'self._clamp_window_to_screen()' in block
    assert 'Replay/navigation is pinned outside the scroll area' in SRC


def test_main_content_reference_exists_for_layout_activation():
    assert 'self._main_content = content' in SRC
    assert 'widget.layout().activate()' in SRC
