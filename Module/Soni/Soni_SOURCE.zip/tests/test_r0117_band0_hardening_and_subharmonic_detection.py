from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HYDRO = (ROOT / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
MAIN = (ROOT / 'src/ui/main_window.py').read_text(encoding='utf-8')
REPLAY_SVC = (ROOT / 'src/services/hydrophone_replay_service.py').read_text(encoding='utf-8')
REPO = (ROOT / 'src/services/spectrum_evidence_repository.py').read_text(encoding='utf-8')


def test_band0_reconstruction_requires_minimum_validated_pairs():
    """A single matched FFT/history sample must never be enough to enable
    gap reconstruction: its ratio trivially equals itself (rel error 0),
    so without a floor a single lucky match could turn on reconstruction
    for an entire Sonication."""
    block = HYDRO.split('def _draw_band_energy', 1)[1].split('def _apply_vendor_band_defaults', 1)[0]
    assert 'MIN_VALIDATION_PAIRS' in block
    assert 'len(pairs) >= MIN_VALIDATION_PAIRS' in block
    assert 'ratios.size >= MIN_VALIDATION_PAIRS' in block


def test_band0_rejection_reports_quantified_deviation():
    block = HYDRO.split('def _draw_band_energy', 1)[1].split('def _apply_vendor_band_defaults', 1)[0]
    assert 'rejection_detail' in block
    assert 'max dev' in block
    assert 'rejected_reconstruction' in block


def test_band0_panel_surfaces_subharmonic_evidence_without_gating_reconstruction():
    block = HYDRO.split('def _draw_band_energy', 1)[1].split('def _apply_vendor_band_defaults', 1)[0]
    assert 'subharmonic_events' in block
    assert 'not a cavitation diagnosis' in block
    # Sub-harmonic markers must never replace or block the existing
    # measured/reconstructed Band0 curves -- only add to them.
    assert 'self.band_plot.plot(tx, yy' in block
    assert 'symbol="t"' in block


def test_ci_canonical_mr_axis_failure_is_logged_not_swallowed():
    block = MAIN.split('def _apply_ci_canonical_mr_axis', 1)[1].split('def _draw_ci_linked_vendor_energy', 1)[0]
    assert 'except Exception:' in block
    assert 'LOG.exception' in block
    assert 'except Exception:\n            pass' not in block


def test_subharmonic_event_dataclass_and_method_exist_and_are_evidence_only():
    assert 'class SubharmonicEvent' in REPLAY_SVC
    assert 'not a cavitation diagnosis' in REPLAY_SVC or 'not a cavitation diagnos' in REPLAY_SVC
    assert 'def subharmonic_events' in REPLAY_SVC
    # R0118: ratio math must delegate to the canonical CavitationVisualizationService
    # definition (band_energy / energy_ratio_db), not re-derive its own dB formula.
    func_block = REPLAY_SVC.split('def subharmonic_events', 1)[1].split('\n\n\n', 1)[0]
    assert 'CavitationVisualizationService.energy_ratio_db' in func_block
    assert 'CavitationVisualizationService.band_energy' in func_block
    # Other, unrelated 20*log10 amplitude->dB conversions exist elsewhere in this
    # file (spectrogram/waterfall display); scope the check to this function only.
    assert '20.0 * np.log10' not in func_block
    assert 'channel: int' in REPLAY_SVC.split('def subharmonic_events', 1)[1][:400]


def test_subharmonic_events_wired_into_both_secondary_product_pipelines():
    # Local/dev worker path (no shared repository).
    assert 'payload["subharmonic_events"]' in HYDRO
    # Shared study-scoped repository path (the production app flow).
    assert 'payload["subharmonic_events"]' in REPO
    # Must be computed per receiver channel, not a single global flag.
    assert 'for ch in range(int(getattr(self.replay' in HYDRO
    assert 'for ch in range(int(getattr(replay' in REPO
