from pathlib import Path

from src.services.sonication_frequency_service import SonicationFrequencyService
from src.services.xd_ini_service import XdIniService


def test_rejects_0800_and_accepts_0630(tmp_path: Path):
    (tmp_path / 'a.act').write_text('AcquisitionFrequency=0.800 MHz\n', encoding='utf-8')
    (tmp_path / 'b.ini').write_text('SonicationFrequency=0.630 MHz\n', encoding='utf-8')
    result = SonicationFrequencyService().read(tmp_path)
    assert result.frequency_hz == 630_000.0
    assert result.source.name == 'b.ini'


def test_invalid_local_falls_back_to_valid_xd(tmp_path: Path):
    son = tmp_path / 'Sonication1'; son.mkdir()
    (son / 'settings.act').write_text('Frequency=0.800 MHz\n', encoding='utf-8')
    (tmp_path / 'Xd_1234.ini').write_text('Frequency=0.630 MHz\n', encoding='utf-8')
    local = SonicationFrequencyService().read(son)
    xd = XdIniService().read_main_frequency(tmp_path)
    assert local.frequency_hz is None
    assert xd.frequency_hz == 630_000.0


def test_xd_rejects_0800(tmp_path: Path):
    (tmp_path / 'Xd_1234.ini').write_text('Frequency=0.800 MHz\n', encoding='utf-8')
    result = XdIniService().read_main_frequency(tmp_path)
    assert result.frequency_hz is None


def test_hover_tooltip_wiring_present():
    source = Path('src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'class ChartHoverPopup(QLabel)' in source
    assert 'popup.show_lines(lines)' in source
    assert 'QToolTip.showText(QCursor.pos(), text, widget, widget.rect(), 1200)' in source
    assert 'self._show_chart_tooltip(self.spectrum_plot, lines)' in source
    assert 'self._show_chart_tooltip(self.acoustic_control_plot, lines)' in source
    assert 'self._show_chart_tooltip(self.temperature_plot, lines)' in source
