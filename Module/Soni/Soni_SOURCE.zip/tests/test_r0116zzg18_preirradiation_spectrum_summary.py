from types import SimpleNamespace

import numpy as np

from src.services.standalone_cavitation_service import (
    CavitationEvent,
    StandaloneCavitationAnalysis,
    StandaloneCavitationService,
)


def replay(times=(-5.0, -2.0, 0.1), start=0.0):
    return SimpleNamespace(
        frames=[object() for _ in times],
        mr_frame_times_s=np.asarray(times, dtype=float),
        mr_sonication_start_s=float(start),
    )


def analysis(events):
    return StandaloneCavitationAnalysis("Auto", "Exact", "Bands", "Rules", events=list(events))


def test_preirradiation_summary_reports_no_when_analyzed_and_quiet():
    result = StandaloneCavitationService().summarize_preirradiation(replay(), analysis([]))
    assert result.status == "NO"
    assert result.snapshot_count == 2
    assert result.vendor_rule_triggers == 0
    assert result.dump_candidates == 0


def test_preirradiation_summary_reports_yes_for_decrease_or_safety_rule_evidence():
    event = CavitationEvent(1, 100, -2.0, -1, -1, 2.0, 1.0, None,
                            "Rule Trigger", "Vendor INI snapshot evaluation",
                            "Decrease Rule 1", "Power decrease 10%")
    result = StandaloneCavitationService().summarize_preirradiation(replay(), analysis([event]))
    assert result.status == "YES"
    assert result.vendor_rule_triggers == 1
    assert result.snapshot_count == 2


def test_preirradiation_summary_keeps_dump_only_outlier_as_candidate_not_confirmed_yes():
    event = CavitationEvent(0, 99, -5.0, 1, 0, 3.0, 1.0, 8.0,
                            "Candidate", "Dump-only robust energy excursion")
    result = StandaloneCavitationService().summarize_preirradiation(replay(), analysis([event]))
    assert result.status == "CANDIDATE"
    assert result.vendor_rule_triggers == 0
    assert result.dump_candidates == 1


def test_preirradiation_summary_ignores_dynamic_rule_as_confirmed_cavitation():
    event = CavitationEvent(0, 99, -5.0, -1, -1, 3.0, 1.0, None,
                            "Rule Trigger", "Vendor INI snapshot evaluation",
                            "Dynamic Rule 0", "Dynamic counter")
    result = StandaloneCavitationService().summarize_preirradiation(replay(), analysis([event]))
    assert result.status == "NO"
    assert result.vendor_rule_triggers == 0
