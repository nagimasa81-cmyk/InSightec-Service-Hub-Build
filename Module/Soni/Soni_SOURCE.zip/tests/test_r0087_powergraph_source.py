from pathlib import Path
import struct
import numpy as np

from src.services.acoustic_control_service import AcousticControlService


def _hex_graph(points):
    payload = b''.join(struct.pack('<ff', float(t), float(p)) for t, p in points)
    text = payload.hex()
    return text[:32] + ' ' + text[32:64] + '\n' + text[64:]


def test_vendor_powergraph_whitespace_decode_and_ratio_to_percent(tmp_path: Path):
    points = [(0.05, 0.20), (0.50, 0.25), (1.50, 0.58), (2.30, 0.946), (19.05, 0.946), (19.05, 0.0)]
    graph = _hex_graph(points)
    (tmp_path / 'spotsonicationdata.xml').write_text(
        f'<xml><row sonicationindex="7" powergraphsize="{len(points)}" powergraph="{graph}" /></xml>',
        encoding='utf-8',
    )
    svc = AcousticControlService()
    decoded = svc._vendor_power_graph(tmp_path, 6)
    assert decoded is not None
    t, p = decoded
    assert len(t) == len(points)
    assert np.allclose(t, [x[0] for x in points], atol=1e-5)
    assert np.allclose(p, np.asarray([x[1] for x in points]) * 100.0, atol=1e-4)


def test_vendor_powergraph_aligns_acquisition_preroll(tmp_path: Path):
    points = [(0.05, 0.20), (0.50, 0.25), (1.50, 0.58), (2.30, 0.946), (4.00, 0.946)]
    graph = _hex_graph(points)
    (tmp_path / 'spotsonicationdata.xml').write_text(
        f'<xml><row sonicationindex="7" powergraphsize="{len(points)}" powergraph="{graph}" /></xml>',
        encoding='utf-8',
    )
    for n in range(1, 8):
        (tmp_path / f'Sonication{n}').mkdir()
    # Control starts 7.5 s before the actual PowerGraph timeline.
    log = tmp_path / 'Acquisition_Brain_650_test.txt'
    lines = ['12:00:00:000 Got StartSpectrumMeasurementA', '12:00:00:100 Set: AblPowerRatio = 0.2000']
    for t, ratio in points:
        sec = 7.5 + t
        whole = int(sec); ms = int(round((sec - whole) * 1000))
        lines.append(f'12:00:{whole:02d}:{ms:03d} Set: AblPowerRatio = {ratio:.4f}')
        lines.append(f'12:00:{whole:02d}:{min(ms+1,999):03d} Calculated Energy: <0.005> Bottom Limit Of Harmless Energy: <0.014>')
    lines.append('12:00:12:000 StopSpectrumMeasurement')
    log.write_text('\n'.join(lines), encoding='utf-8')

    svc = AcousticControlService()
    trend = svc.trend_for_sonication(tmp_path, 6, 21, 20.0)
    assert trend.plot_time_s is not None and trend.plot_power_percent is not None
    assert np.allclose(trend.plot_time_s, [x[0] for x in points], atol=1e-4)
    assert np.allclose(trend.plot_power_percent, np.asarray([x[1] for x in points]) * 100.0, atol=0.05)
    assert 7.3 <= float(trend.acoustic_onset_raw_s) <= 7.7
    assert float(trend.acoustic_end_s) == np.max(trend.plot_time_s)
