from src.ui.i18n import LANGUAGES, ui_text


def test_seven_languages_available():
    assert list(LANGUAGES) == ['en','ja','ko','zh_TW','es','th','hi']


def test_major_spectrum_ui_localized_in_all_non_english_languages():
    labels = [
        'Open Export ZIP','Open Spectrum File','Cavitation Events',
        'Measure / Statistics','Show pre-irradiation control',
        'Control Timeline','Probable Location','Source details',
    ]
    for locale in ['ja','ko','zh_TW','es','th','hi']:
        for label in labels:
            assert ui_text(locale, label) != label, (locale, label)


def test_language_switch_is_reversible():
    source='Open Export ZIP'
    ja=ui_text('ja',source)
    ko=ui_text('ko',ja)
    en=ui_text('en',ko)
    assert ja != source
    assert ko != ja
    assert en == source


def test_scientific_identifiers_remain_stable():
    for locale in LANGUAGES:
        assert ui_text(locale,'RCV0') == 'RCV0'
        assert ui_text(locale,'FFT') == 'FFT'
        assert ui_text(locale,'CPC') == 'CPC'
