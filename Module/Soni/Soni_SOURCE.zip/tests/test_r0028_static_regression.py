from pathlib import Path


def test_planning_entries_keep_array_then_label_then_source_asset():
    text=Path('src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'entries.append((mode,array,label,asset))' in text
    assert 'entries.append((mode,asset,array,label))' not in text

def test_loaded_export_selector_is_additive():
    text=Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'Sonication / {son.name}' in text
    assert 'SpectrumDumps / {candidate.label}' in text
    assert 'additional selectable sources, never replacements' in text
