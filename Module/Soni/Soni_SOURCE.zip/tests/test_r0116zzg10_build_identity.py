from __future__ import annotations

import json
from pathlib import Path

from src.common.constants import APP_COMMIT, APP_VERSION


def test_release_identity_is_coherent_across_build_inputs():
    root = Path(__file__).resolve().parents[1]
    assert (root / "VERSION").read_text(encoding="utf-8").strip() == APP_VERSION
    version = json.loads((root / "version.json").read_text(encoding="utf-8"))
    assert version["version"] == APP_VERSION
    assert version["commit"] == APP_COMMIT
    contract = json.loads((root / "insightec_build_contract.json").read_text(encoding="utf-8"))
    assert contract["source_version"] == APP_VERSION.lower()
    for name in ("01_BUILD_EXE_NUITKA_CI.bat", "01_BUILD_EXE_NUITKA.bat"):
        assert APP_VERSION in (root / name).read_text(encoding="utf-8", errors="replace")
