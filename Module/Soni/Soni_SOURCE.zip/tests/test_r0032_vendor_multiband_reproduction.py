from pathlib import Path
import numpy as np

from src.services.cpc_vendor_reproduction_service import CpcVendorReproductionService, VendorCavitationProfile, VendorRule


def test_display_rule2_reconstructs_band1_and_decrease_rule4_marks_band2(tmp_path: Path):
    log = tmp_path / "Acquisition_Brain_test.txt"
    lines = ["Got StartSpectrumMeasurement"]
    band0_values = []
    for cycle in range(1, 26):
        band0 = 0.004 + cycle * 0.00001
        rule1 = band0 / 0.025
        rule2 = 0.05 + cycle * 0.0001
        band0_values.append(band0)
        lines.append(f"Increase Power Rule no. 0 : Calculated Energy: <{band0:.8f}>")
        if cycle == 1:
            lines.append("Decrease Power Rule no. 4 : Calculated Energy: <0.007000>")
        lines.append(f"Cycle {cycle} Done. Display: Rule <0>: -1.#IND Rule <1>: {rule1:.8f} Rule <2>: {rule2:.8f} Rule <3>: -1.#IND")
    lines.append("Got StopSpectrumMeasurement")
    log.write_text("\n".join(lines) + "\n", encoding="utf-8")
    service = CpcVendorReproductionService()
    profile = VendorCavitationProfile(
        increase_rule0=VendorRule("inc", np.array([[0,0,0,0],[.25,0,0,0],[.25,0,0,0],[.25,0,0,0],[.25,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]], float), 0.014),
        display_rules={
            1: VendorRule("d1", np.array([[0,0,0,0],[.25,0,0,0],[.25,0,0,0],[.25,0,0,0],[.25,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]], float), 0.025),
            2: VendorRule("d2", np.array([[0,0,0,0],[0,.25,0,0],[0,.25,0,0],[0,.25,0,0],[0,.25,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]], float), 0.018),
        },
    )
    # Make the weighted saved Band0 history exactly match the logged increase-rule values.
    histories = [np.zeros(25) for _ in range(8)]
    for ch in (1,2,3,4):
        histories[ch] = np.asarray(band0_values, float)
    # Force log discovery by placing the source next to the log.
    source = tmp_path / "Spectrum_test.dmp_FFT"
    source.write_bytes(b"x")
    result = service.validate_saved_band0_history(source, histories, profile)
    assert result.status.startswith("EXACT")
    assert 1 in result.weighted_band_histories_from_log
    np.testing.assert_allclose(result.weighted_band_histories_from_log[1][0], (0.0501)*0.018, rtol=0, atol=1e-12)
    assert 2 in result.sparse_control_rule_histories
    assert result.sparse_control_rule_histories[2][0] == 0.007
    assert np.isnan(result.sparse_control_rule_histories[2][1])
    # Disabled display rules must remain absent rather than being parsed as -1.0.
    assert 0 not in result.display_rule_histories
