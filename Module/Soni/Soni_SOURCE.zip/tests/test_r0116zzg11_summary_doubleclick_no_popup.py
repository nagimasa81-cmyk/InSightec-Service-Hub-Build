from pathlib import Path

MAIN = (Path(__file__).parents[1] / "src/ui/main_window.py").read_text(encoding="utf-8")

def test_summary_double_click_is_navigation_only():
    assert 'self.sonication_summary_table.cellDoubleClicked.connect(self._sonication_summary_jump)' in MAIN
    assert 'self.sonication_summary_table.setProperty("suppress_readability_double_click_popup", True)' in MAIN
    assert 'if not bool(table.property("suppress_readability_double_click_popup")):' in MAIN

def test_summary_jump_still_loads_and_goes_to_replay():
    start = MAIN.index('def _sonication_summary_jump')
    block = MAIN[start:start+700]
    assert 'self._select_sonication_index(int(row))' in block
    assert 'self.tabs.setCurrentWidget(self.replay_tab)' in block
