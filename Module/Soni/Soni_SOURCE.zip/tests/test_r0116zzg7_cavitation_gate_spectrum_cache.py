from pathlib import Path
from types import SimpleNamespace

from src.services.canonical_cavitation_evidence_service import CanonicalCavitationEvidenceService

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')


def _vendor_trigger():
    return SimpleNamespace(severity='Rule Trigger', energy=10.0, baseline=5.0, rule='Decrease Rule 4')


def test_vendor_rule_trigger_alone_does_not_create_cavitation_status_or_severity_gate():
    evidence=CanonicalCavitationEvidenceService.combine([], SimpleNamespace(events=[_vendor_trigger()]))
    assert evidence.detected is False
    assert evidence.observed_events == ()
    assert len(evidence.vendor_rule_events) == 1  # retained as supporting evidence
    assert evidence.status == 'No Power Decrease / Safety event'
    assert evidence.rca_events == ()


def test_only_decrease_or_safety_can_create_cavitation_event():
    events=[
        SimpleNamespace(family='Increase', counts_as_cavitation=True),
        SimpleNamespace(family='Dynamic', counts_as_cavitation=True),
        SimpleNamespace(family='Decrease', counts_as_cavitation=False),
        SimpleNamespace(family='Safety', counts_as_cavitation=False),
    ]
    evidence=CanonicalCavitationEvidenceService.combine(events, SimpleNamespace(events=[_vendor_trigger()]))
    assert evidence.detected is True
    assert [e.family for e in evidence.observed_events] == ['Decrease','Safety']
    assert evidence.status == 'Observed control cavitation ×2'
    assert [e.family for e in evidence.rca_events] == ['Decrease','Safety']


def test_summary_severity_never_uses_vendor_exceedance_as_cavitation_severity():
    assert 'cavitation_severity=response_severity if canonical.detected is True else None' in MAIN
    detail=MAIN.split('def _build_one_sonication_summary',1)[1].split('def _build_one_sonication_temperature_summary',1)[0]
    assert 'vendor_severity=' not in detail
    assert 'if canonical.detected is True:' in detail


def test_selected_sonication_analyzer_reuses_repository_cache_and_preserves_study_context():
    start=MAIN.split('def _start_spectrum_preload',1)[1].split('def _spectrum_preload_thread_finished',1)[0]
    assert 'self._spectrum_preload_context=None; self._spectrum_preload_progress' not in start
    assert 'existing=getattr(self,"_spectrum_preload_context",None)' in start
    opener=MAIN.split('def _open_hydrophone_window',1)[1].split('# --------------------------------------------------------------- Loading',1)[0]
    assert 'cached_replay(package,index)' in opener
    assert 'replays[index]=cached' in opener
    assert 'ready.add(index)' in opener
