from pathlib import Path
import numpy as np

from src.services.sonication_log_receiver_service import SonicationLogReceiverService
from src.services.registration_overlay_service import RegistrationOverlayService, CtGeometry


def test_sonication_log_parser_decodes_sonic_channel_block(tmp_path):
    p=tmp_path/'Sonication_Brain_650_test.txt'
    p.write_text('''12:00:00:100 Inf CLoadSonicationData fields:\n Number Of Channels <1024>\n12:00:00:100 Inf Channel <0>\n Logical Amplitude <1.000000>\n Logical Phase <425.260445>\n12:00:00:100 Inf Channel <3>\n Logical Amplitude <0.750000>\n Logical Phase <422.100000>\n''',encoding='utf-8')
    snaps=SonicationLogReceiverService().read_snapshots(tmp_path)
    assert len(snaps)==1 and snaps[0].declared_channels==1024
    assert [v.channel for v in snaps[0].values]==[0,3]
    assert snaps[0].values[0].logical_phase_rad==425.260445


def test_world_reslice_uses_patient_geometry():
    svc=RegistrationOverlayService()
    vol=np.zeros((8,32,32),float); vol[3,8:24,8:24]=1000.0
    class MR:
        top_left_r=0.0; top_left_a=0.0; top_left_s=3.0
        pixel_size_x=1.0; pixel_size_y=1.0
        row_direction=(1.0,0.0,0.0); col_direction=(0.0,1.0,0.0)
    geom=CtGeometry(np.array([0.,0.,0.]),np.array([1.,0.,0.]),np.array([0.,1.,0.]),np.array([0.,0.,1.]),1.,1.,1.,Path('CtImage.xml'))
    out=svc._world_reslice(vol,(32,32),MR(),geom,np.eye(4),'CtMr')
    assert out is not None and np.isfinite(out).sum() > 20


def test_r0054_ui_contract_present():
    text=Path('src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'Auto WW/WL' in text
    assert 'self.ci_event_table.cellClicked.connect(self._ci_event_selected)' in text
    assert 'sonic channel phase / amplitude (separate from RCV0–RCV7)' in text
    h=Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'self.cavitation_event_table.cellClicked.connect(self._cavitation_event_selected)' in h
