from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_preload_recovers_when_package_inventory_is_empty():
    s=(ROOT/'src/services/spectrum_evidence_repository.py').read_text(encoding='utf-8')
    assert 'if not any(getattr(c, "family", "") == "CPC Spectrum" for c in candidates):' in s
    assert 'candidates = importer.discover(workspace)' in s

def test_finished_preload_releases_thread_for_retry():
    s=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'def _spectrum_preload_thread_finished' in s
    assert 'self._spectrum_preload_thread = None' in s
    assert 'if thread is None or not thread.isRunning()' in s

def test_waiting_analyzer_shows_live_source_status_and_stays_usable():
    s=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'Spectrum preload:' in s
    assert 'self.tabs.setEnabled(True)' in s
    assert 'self.sonication_combo.setEnabled(True)' in s
