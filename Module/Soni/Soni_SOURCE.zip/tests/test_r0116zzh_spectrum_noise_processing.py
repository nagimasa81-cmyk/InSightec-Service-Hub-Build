from pathlib import Path
import numpy as np

from src.services.hydrophone_replay_service import CpcHydrophoneFrame, CpcHydrophoneReplay, HydrophoneReplayService


def _frame(index, values):
    freq=np.array([100_000.,200_000.,300_000.])
    arr=np.array(values,float)
    return CpcHydrophoneFrame(index=index, frequency_hz=freq,
        channels=[arr.copy() for _ in range(8)],
        uncalibrated_channels=[arr.copy() for _ in range(8)])


def _replay():
    r=CpcHydrophoneReplay(source_fft=Path('dummy'), source_raw=None)
    r.frames=[
        _frame(0,[1,2,4]),
        _frame(1,[3,2,8]),
        _frame(2,[5,2,4]),
    ]
    r.channel_reference_levels=tuple([10.0]*8)
    r.display_db_min=-100.0; r.display_db_max=0.0
    return r


def test_accumulated_rms_is_linear_amplitude_rms_then_db():
    s=HydrophoneReplayService(); r=_replay()
    got=s.accumulated_rms_db(r,2,0,True,False)
    expected=20*np.log10(np.sqrt(np.mean(np.array([[1,2,4],[3,2,8],[5,2,4]],float)**2,axis=0)))
    np.testing.assert_allclose(got,expected,rtol=1e-12,atol=1e-12)


def test_temporal_noise_rms_highlights_varying_bins_and_stable_bin_stays_low():
    s=HydrophoneReplayService(); r=_replay()
    got=s.temporal_noise_rms_db(r,2,0,True,False)
    # middle bin is perfectly stable at 2, so residual RMS is effectively floor.
    assert got[1] < -5000
    assert got[0] > got[1]
    assert got[2] > got[1]


def test_innovation_zscore_uses_prior_frames_only_and_is_nonnegative():
    s=HydrophoneReplayService(); r=_replay()
    got=s.innovation_abs_zscore(r,2,0,True)
    assert np.all(got >= 0)
    # bin 2 prior values [2,2] are stable and current remains 2 => zero novelty.
    assert got[1] == 0
    # bin 1 prior [1,3] => mean 2, std 1, current 5 => 3 sigma.
    np.testing.assert_allclose(got[0],3.0,rtol=1e-12,atol=1e-12)


def test_ui_exposes_all_noise_processing_modes_and_sigma_reference():
    src=Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    for label in ('Accumulated RMS','Temporal noise RMS','Innovation |z-score|'):
        assert label in src
    assert 'innovation_abs_zscore' in src
    assert 'pos=3.0' in src


def test_new_noise_modes_localized_for_all_languages():
    from src.ui.i18n import UI_TEXT
    for locale in ('en','ja','ko','zh_TW','es','th','hi'):
        for key in ('Accumulated RMS','Temporal noise RMS','Innovation |z-score|'):
            assert UI_TEXT[locale].get(key)
