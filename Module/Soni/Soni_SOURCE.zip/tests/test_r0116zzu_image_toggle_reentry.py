from pathlib import Path
import ast

SRC = Path(__file__).resolve().parents[1] / 'src' / 'ui' / 'main_window.py'
TEXT = SRC.read_text(encoding='utf-8')
TREE = ast.parse(TEXT)


def method_source(name: str) -> str:
    for node in ast.walk(TREE):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
            return ast.get_source_segment(TEXT, node) or ''
    raise AssertionError(f'method not found: {name}')


def test_toggle_on_uses_cycle_scoped_navigator_callback():
    body = method_source('_image_loading_toggled')
    assert '_image_load_cycle_generation' in body
    assert '_build_frame_navigator(c)' in body


def test_off_invalidates_cycle_and_essential_worker_generation():
    body = method_source('_clear_image_ui_for_load_images_off')
    assert '_image_load_cycle_generation' in body
    assert '_cancel_essential_image_worker(invalidate=True, restart_cycle=None)' in body


def test_navigator_rejects_stale_delayed_callbacks():
    body = method_source('_build_frame_navigator')
    assert 'load_cycle' in body
    assert '_image_load_cycle_generation' in body
    assert '_start_essential_image_background(c)' in body


def test_essential_reader_never_waits_on_gui_and_never_overlaps():
    cancel = method_source('_cancel_essential_image_worker')
    start = method_source('_start_essential_image_background')
    assert '.wait(' not in cancel
    assert 'active_thread.isRunning()' in start
    assert 'active_cycle == load_cycle' in start
    assert 'restart_cycle=load_cycle' in start
    assert 'Finishing previous image read' in start


def test_qthread_reference_is_kept_until_finished_signal():
    cancel = method_source('_cancel_essential_image_worker')
    finished = method_source('_essential_image_thread_finished')
    # Running branch returns before references are cleared.
    assert 'if thread is not None and thread.isRunning()' in cancel
    assert 'return' in cancel
    assert '_essential_image_thread=None' in finished
    assert '_essential_image_worker=None' in finished


def test_sonication_change_retires_old_image_reader_before_current_changes():
    body = method_source('_select_sonication_index')
    cancel_pos = body.index('_cancel_essential_image_worker')
    current_pos = body.index('self.current =')
    assert cancel_pos < current_pos


def test_staged_navigator_coalesces_existing_checkbox_load_cycle():
    body = method_source('_selected_stage_navigator')
    assert 'if not bool(getattr(self,"_image_load_in_progress",False))' in body
    assert 'cycle=int(getattr(self,"_image_load_cycle_generation",0))' in body
