from pathlib import Path

from src.services.sonication_frequency_service import SonicationFrequencyService
from src.services.xd_ini_service import XdIniService


def test_xd_discovery_accepts_only_four_digit_non_default_serial(tmp_path: Path):
    names = [
        "Xd_1234.ini",
        "Xd_0000.ini",
        "Xd_123.ini",
        "Xd_12345.ini",
        "Xd_ABC1.ini",
        "Xd_test.ini",
        "Xd.ini",
    ]
    for name in names:
        (tmp_path / name).write_text("Frequency=630 kHz\n")

    found = XdIniService().discover(tmp_path)
    assert [p.name for p in found] == ["Xd_1234.ini"]


def test_xd_geometry_discovery_excludes_0000_and_supports_field_spelling(tmp_path: Path):
    for name in (
        "XdGometry_2468.ini",
        "XdGeometry_1357.ini",
        "XdGometry_0000.ini",
        "XdGeometry_0000.ini",
        "XdGeometry_test.ini",
    ):
        (tmp_path / name).write_text("geometry\n")

    found = XdIniService().discover_geometry(tmp_path)
    assert [p.name for p in found] == ["XdGeometry_1357.ini", "XdGometry_2468.ini"]


def test_default_xd_does_not_supply_main_frequency(tmp_path: Path):
    (tmp_path / "Xd_0000.ini").write_text("Frequency=800 kHz\n")
    metadata = XdIniService().read_main_frequency(tmp_path)
    assert metadata.frequency_hz is None
    assert metadata.source_path is None


def test_sonication_local_scanner_ignores_xd_reference_files(tmp_path: Path):
    (tmp_path / "Xd_0000.ini").write_text("Frequency=800 kHz\n")
    (tmp_path / "Xd_1234.ini").write_text("Frequency=630 kHz\n")
    result = SonicationFrequencyService().read(tmp_path)
    assert result.frequency_hz is None
