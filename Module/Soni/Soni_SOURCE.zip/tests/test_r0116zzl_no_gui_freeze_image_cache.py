from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
REPLAY = (ROOT/'src/services/replay_service.py').read_text(encoding='utf-8')


def _body(name, text=MAIN):
    marker=f'    def {name}'
    start=text.index(marker)
    nxt=text.find('\n    def ', start+len(marker))
    return text[start:] if nxt < 0 else text[start:nxt]


def test_first_valid_frame_does_not_decode_raw_on_gui_thread():
    body=_body('_first_valid_replay_frame')
    assert 'self.replay.frame' not in body
    assert 'read_magnitude' not in body
    assert 'return 0' in body


def test_set_frame_uses_background_image_cache_without_disk_fallback():
    body=_body('set_frame')
    assert '_treatment_mr_thumbnail_cache' in body
    assert '_thermal_thumbnail_cache' in body
    assert 'disk_fallback=False' in body
    assert '_image_load_in_progress' in body


def test_mr_correlation_and_signal_loss_are_cache_only():
    for name in ('_current_magnitude_signal_loss','_current_magnitude_correlation'):
        body=_body(name)
        assert '_treatment_mr_thumbnail_cache' in body
        assert 'read_magnitude' not in body


def test_thermal_thumbnail_updates_do_not_rebuild_all_strips():
    body=_body('_thermal_thumbnail_ready')
    assert '_apply_ready_thumbnail_to_visible_items("treatment_thermal"' in body
    assert '_rebuild_all_image_strips' not in body


def test_image_loading_has_nonmodal_dedicated_progress_and_worker_progress_signals():
    assert 'progress = Signal(str, int, int, int)' in MAIN
    assert 'progress = Signal(int, int, int)' in MAIN
    body=_body('_begin_image_load_progress')
    assert 'Loading images' in body
    assert '_image_progress' in body
    assert '_exclusive_progress' not in body
    body2=_body('_image_load_role_finished')
    assert '_start_incremental_image_strip_build' in body2
    final=_body('_continue_incremental_image_strip_build')
    assert 'set_frame' in final
    assert '.finish()' in final


def test_replay_service_supports_cache_only_image_rendering():
    assert 'magnitude_override=None' in REPLAY
    assert 'temperature_override=None' in REPLAY
    assert 'disk_fallback: bool = True' in REPLAY
    assert 'elif disk_fallback' in REPLAY
