from pathlib import Path


def _hydro():
    return Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")

def test_open_zip_55_stage_defers_decode_to_next_event_turn():
    text=_hydro()
    assert text.count('Spectrum source selected; scheduling background decode') >= 2
    assert 'def _continue_dump_candidate' in text
    assert 'QTimer.singleShot(0, lambda src=source_token' in text

def test_standalone_candidate_does_not_full_reset_before_worker():
    text=_hydro(); a=text.index('def load_dump_candidate'); b=text.index('def dragEnterEvent',a); block=text[a:b]
    assert '_reset_replay_state_fast()' in block
    assert '_reset_replay_analysis_state()' not in block

def test_source_reset_invalidates_stale_decoder():
    text=_hydro(); a=text.index('def reset_source_context'); b=text.index('def _rebuild_raw_plots',a); block=text[a:b]
    assert 'self._decode_request_id += 1' in block
    assert 'self._decode_context = None' in block
    assert 'self._decode_heartbeat.stop()' in block

def test_standalone_mode_clears_package_source_entries():
    text=_hydro(); a=text.index('def open_dump_source'); b=text.index('def _continue_dump_candidate',a); block=text[a:b]
    assert 'self.source_entries = []' in block
    assert 'self._loaded_sonication_index = None' in block

def test_dump_ready_only_caches_mapped_sonication_decode():
    text=_hydro(); a=text.index('def _dump_decode_ready'); b=text.index('def _hide_decode_progress_if_current',a); block=text[a:b]
    assert 'context.get("kind") == "sonication"' in block
    assert 'sonication_cache_index' in block

def test_load_package_does_not_fake_100_before_async_completion():
    text=_hydro(); a=text.index('def load_package'); b=text.index('def _load_source_entry',a); block=text[a:b]
    assert '_load_source_entry(target_row)' in block
    assert '_set_subwindow_progress(100' not in block

def test_secondary_publish_is_event_loop_staged():
    text=_hydro()
    for name in ('_finish_secondary_replay_publish','_finish_secondary_spectrogram','_finish_secondary_vendor','_finish_secondary_cavitation'):
        assert f'def {name}' in text
    assert 'class SpectrumSecondaryWorker' in text
    assert 'worker.moveToThread(thread)' in text
    assert 'worker.ready.connect(self._secondary_analysis_ready)' in text
