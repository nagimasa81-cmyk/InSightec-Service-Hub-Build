from pathlib import Path

from src.services.cavitation_control_timeline_service import CavitationControlTimelineService
from src.services.cpc_vendor_reproduction_service import VendorCavitationProfile, VendorControlRule
import numpy as np


def test_parse_observed_halt_event(tmp_path):
    log = tmp_path / "Acquisition_Brain_test.txt"
    log.write_text("""12:00:00:000 Inf Got StartSpectrumMeasurement
12:00:00:010 Inf Set: SubSonic = 0, ExciterPower = 100 W, AblPower = 100 W, ExPowerRatio = 0.5 (0) AblPowerRatio = 0.5 (0)
12:00:00:020 Err Safety Rule no. 3: Calculated Energy from all hydrophones is more than a critical energy (Changing Frequency = 0 )
                        Calculated Energy: < 0.064407 >
                        Critical Energy:   < 0.060000 >
12:00:00:020 Wrn RuleNo. <3> Sonic with one frequency Cavitaion calculation  0.064407 =
Ch < 1 > band<0> 0.0376(Emax 1000.0000 ) * 0.2500( weight ) +band<1> 0.0032(Emax 1000.0000 ) * 0.0000( weight ) +
Ch < 2 > band<0> 0.0554(Emax 1000.0000 ) * 0.2500( weight ) +band<1> 0.0049(Emax 1000.0000 ) * 0.0000( weight ) +
Ch < 3 > band<0> 0.1039(Emax 1000.0000 ) * 0.2500( weight ) +band<1> 0.0077(Emax 1000.0000 ) * 0.0000( weight ) +
Ch < 4 > band<0> 0.0607(Emax 1000.0000 ) * 0.2500( weight ) +band<1> 0.0052(Emax 1000.0000 ) * 0.0000( weight ) +
Ch < 5 > band<0> 0.0607(Emax 1000.0000 ) * 0.0000( weight ) +band<1> 0.0052(Emax 1000.0000 ) * 0.0000( weight ) +
Ch < 6 > band<0> 0.0607(Emax 1000.0000 ) * 0.0000( weight ) +band<1> 0.0052(Emax 1000.0000 ) * 0.0000( weight ) +
Ch < 7 > band<0> 0.0607(Emax 1000.0000 ) * 0.0000( weight ) +band<1> 0.0052(Emax 1000.0000 ) * 0.0000( weight ) +
Ch < 0 > band<0> 0.0479(Emax 1000.0000 ) * 0.0000( weight ) +band<1> 0.0045(Emax 1000.0000 ) * 0.0000( weight ) +
12:00:00:020 Inf Status was changed to <HALTED BY CAVITATION> AddStatus<13>
12:00:00:020 Inf Set: SubSonic = 0, ExciterPower = NA, AblPower = NA, ExPowerRatio = 0 (0) AblPowerRatio = 0 (0)
""", encoding='utf-8')
    profile = VendorCavitationProfile(source_ini=tmp_path / 'dummy.ini')
    weights = np.zeros((8,4), float); weights[1:5,0] = 0.25
    profile.safety_rules[3] = VendorControlRule('Safety', 3, weights, threshold=0.025, critical_threshold=0.060)
    svc = CavitationControlTimelineService()
    tl = svc.parse(log, profile, 0, None, None)
    assert tl.events
    halt = [e for e in tl.events if 'HALTED' in e.result][0]
    assert halt.dominant_channel == 3
    assert halt.after_power_ratio == 0.0
