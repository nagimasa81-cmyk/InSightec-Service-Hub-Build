from pathlib import Path
import struct
import numpy as np

from src.services.hydrophone_replay_service import HydrophoneReplayService


def _synthetic_fft_payload():
    payload=bytearray()
    energy_rows=[]
    for ch in range(8):
        vals=np.zeros(256,dtype='<f4')
        vals[5:10]=0.001*(ch+1)
        payload += struct.pack('<I',256)+vals.tobytes()+b'\0'*48
    # Add vendor energy table: uint32 band count + 4 float energies + 16 byte tail, 8 rows.
    for ch in range(8):
        row=np.asarray([0.001*(ch+1),0.002*(ch+1),0.003*(ch+1),0.004*(ch+1)],dtype=np.float32)
        energy_rows.append(row)
        payload += struct.pack('<I4f',4,*row)+b'\0'*16
    return bytes(payload), np.vstack(energy_rows)


def test_embedded_vendor_energy_table_decodes_without_changing_legacy_interface():
    payload, expected=_synthetic_fft_payload()
    legacy=HydrophoneReplayService._decode_fft_payload(payload,1,8,2_000_000.0,250_000.0,750_000.0)
    assert len(legacy)==1
    freq,channels=legacy[0]
    assert len(channels)==8
    detailed=HydrophoneReplayService._decode_fft_payload(payload,1,8,2_000_000.0,250_000.0,750_000.0,include_vendor_energy=True)
    assert len(detailed)==1
    _freq,_channels,energies=detailed[0]
    assert energies.shape==(8,4)
    assert np.allclose(energies,expected)


def test_frame_times_prefers_exact_acquisition_times():
    from src.services.hydrophone_replay_service import CpcHydrophoneReplay, CpcHydrophoneFrame
    replay=CpcHydrophoneReplay(None,None)
    replay.frames=[
        CpcHydrophoneFrame(0,np.array([1.]),[np.array([1.])]*8,acquisition_time_s=0.19),
        CpcHydrophoneFrame(1,np.array([1.]),[np.array([1.])]*8,acquisition_time_s=0.59),
        CpcHydrophoneFrame(2,np.array([1.]),[np.array([1.])]*8,acquisition_time_s=5.39),
    ]
    assert np.allclose(replay.frame_times_s,[0.19,0.59,5.39])
    assert replay.frame_interval_s==0.4
