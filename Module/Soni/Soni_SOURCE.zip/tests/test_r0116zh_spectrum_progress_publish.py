from pathlib import Path


def _hydro():
    return Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")

def test_preload_handoff_keeps_progress_visible_until_publish():
    text=_hydro(); start=text.index("def accept_preloaded_context"); end=text.index("def reset_source_context",start); block=text[start:end]
    assert '_set_subwindow_progress(58, "Spectrum preload ready; scheduling decoded-data publish…", pump_events=False)' in block
    assert "QTimer.singleShot(0" in block
    assert "_continue_preloaded_publish" in block
    assert 'self._set_subwindow_progress(None)\n        # Do not leave' not in block

def test_decode_progress_does_not_round_back_to_55():
    text=_hydro(); start=text.index("def _dump_decode_progress"); end=text.index("def _update_decode_heartbeat",start); block=text[start:end]
    assert 'mapped = 56 +' in block
    assert 'elapsed' in block

def test_decode_heartbeat_is_visible():
    text=_hydro(); assert 'def _update_decode_heartbeat' in text; assert 'self._decode_heartbeat.start()' in text

def test_primary_spectrum_is_published_before_secondary_analysis():
    text=_hydro(); assert text.count('Spectrum displayed — {count} FFT frame(s); finishing secondary analysis…') >= 2
    # R0116zzv: secondary CPU work is no longer staged on the GUI event loop;
    # it is owned by SpectrumSecondaryWorker and only its lightweight publish
    # returns to the GUI thread.
    assert 'self._queue_secondary_analysis()' in text
    assert 'class SpectrumSecondaryWorker' in text
    assert 'self._set_secondary_progress(100, f"Ready — {len(self.replay.frames)} decoded FFT frame(s)")' in text

def test_no_mapped_or_chronological_gui_thread_direct_decode():
    text=_hydro(); start=text.index("def load_sonication"); end=text.index("def sync_sonication",start); block=text[start:end]
    assert 'self.service.build_direct(candidate.fft_path, candidate.raw_path)' not in block
    assert 'self.service.build_direct(fft_path, raw_path)' not in block
