from pathlib import Path
import numpy as np

from src.services.cpc_vendor_reproduction_service import CpcVendorReproductionService


def test_vendor_band_definition_and_rule_weighting(tmp_path: Path):
    root = tmp_path / "CPCFiles"
    (root / "Site" / "Ini").mkdir(parents=True)
    (root / "App" / "Ini").mkdir(parents=True)
    safety = root / "Site" / "Ini" / "CavitationSafetyAndControl.ini"
    safety.write_text(
        "[HARMONICS_BANDWIDTHS]\n"
        "NumOfHarmonicsBandwidths = 4\n"
        "Bandwidth_0 = 0.539 50.0\n"
        "Bandwidth_1 = 0.42 20.0\n"
        "Bandwidth_2 = 0.5 5.0\n"
        "Bandwidth_3 = 1.0 5.0\n"
        "[INCREASE_POWER_RULE_0]\n"
        "IncreaseRuleWeight = | 0 0 0 0 | .25 0 0 0 | .25 0 0 0 | .25 0 0 0 | .25 0 0 0 | 0 0 0 0 | 0 0 0 0 | 0 0 0 0 |\n"
        "BottomLimitOfHarmlessEnergy = 0.014\n"
        "[DISPLAY_RULE_1]\n"
        "DisplayRuleWeight = | 0 0 0 0 | .25 0 0 0 | .25 0 0 0 | .25 0 0 0 | .25 0 0 0 | 0 0 0 0 | 0 0 0 0 | 0 0 0 0 |\n"
        "MaximumEnergyForAllHydrophones = 0.025\n",
        encoding="utf-8",
    )
    (root / "App" / "Ini" / "Acquisition.ini").write_text(
        "[SPECTRUM]\nf1ForGraph=250000\nf2ForGraph=750000\nCalculatedE_Factor=200\n",
        encoding="utf-8",
    )
    source = root / "Spectrum_test.dmp_FFT"
    source.write_bytes(b"")
    service = CpcVendorReproductionService()
    profile = service.read_profile(source, 670000.0)
    assert [(round(b.low_hz), round(b.high_hz)) for b in profile.bands] == [
        (311130, 411130), (261400, 301400), (330000, 340000), (665000, 675000)
    ]
    history = [np.asarray([float(ch + 1), float(ch + 2)]) for ch in range(8)]
    weighted = service.weighted_band0(history, profile.increase_rule0.weights)
    np.testing.assert_allclose(weighted, np.asarray([3.5, 4.5]))
