from pathlib import Path
import numpy as np
from src.services.registration_overlay_service import RegistrationOverlayService


def test_signed_ct_hu_recovers_wrapped_air():
    src=np.array([[62512, 0, 500, 1500]],dtype=np.uint16)  # -3024 wrapped as uint16
    out=RegistrationOverlayService._signed_ct_hu(src)
    assert out[0,0] == -3024
    assert out[0,2] == 500
    assert out[0,3] == 1500


def test_vendor_profile_prefers_brainact(tmp_path: Path):
    p=tmp_path/'WSFiles'/'App'/'AppInifiles'/'AppClap'
    p.mkdir(parents=True)
    (p/'BrainApp.ini').write_text('[BrainACT]\nLowBoneThreshold = 500\n[BackgroundEliminationInit]\nLowBoneThreshold = 800\nHighBoneThreshold = 5000\n',encoding='utf-8')
    prof=RegistrationOverlayService.read_vendor_bone_profile(tmp_path)
    assert prof.low_hu == 500
    assert prof.high_hu == 5000
    assert prof.source is not None and prof.source.name == 'BrainApp.ini'


def test_native_ct_mask_does_not_turn_wrapped_air_into_bone():
    svc=RegistrationOverlayService()
    vol=np.full((2,64,64), np.uint16(62512), dtype=np.uint16)
    # skull-sized ring at real +1000 HU
    yy,xx=np.mgrid[:64,:64]
    rr=np.sqrt((xx-31.5)**2+(yy-31.5)**2)
    ring=(rr>22)&(rr<26)
    vol[:,ring]=1000
    prof=svc.read_vendor_bone_profile(Path('/path/that/does/not/exist'))
    mask=svc.build_vendor_skull_mask(vol,prof)
    assert mask[:,32,32].sum() == 0
    assert mask[:,6:59,6:59].sum() > 0
    assert mask.mean() < 0.25
