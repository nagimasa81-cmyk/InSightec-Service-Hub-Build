from pathlib import Path
import numpy as np

from src.core.image_orientation import (
    receiver_field_to_raster_rows,
    raster_rows_to_receiver_field,
    normalized_x_to_raster_col,
    normalized_y_to_raster_row,
)

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYDRO = (ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
IMG = (ROOT/'src/ui/image_panel.py').read_text(encoding='utf-8')
MR_CORR = (ROOT/'src/services/cavitation_mr_correlation_service.py').read_text(encoding='utf-8')
LIKELIHOOD = (ROOT/'src/services/cavitation_likelihood_service.py').read_text(encoding='utf-8')
REG = (ROOT/'src/services/registration_overlay_service.py').read_text(encoding='utf-8')


def test_receiver_field_raster_roundtrip_is_one_vertical_flip():
    a=np.arange(12).reshape(3,4)
    b=receiver_field_to_raster_rows(a)
    assert np.array_equal(b, a[::-1])
    assert np.array_equal(raster_rows_to_receiver_field(b), a)


def test_normalized_y_maps_positive_y_to_top_raster_rows():
    assert normalized_y_to_raster_row(1.0, 101) == 0.0
    assert normalized_y_to_raster_row(0.0, 101) == 50.0
    assert normalized_y_to_raster_row(-1.0, 101) == 100.0
    assert normalized_x_to_raster_col(-1.0, 101) == 0.0
    assert normalized_x_to_raster_col(1.0, 101) == 100.0


def test_main_anatomical_plot_routes_use_raster_y_down_viewbox():
    assert 'self.ci_linked_probable_plot.invertY(True)' in MAIN
    assert 'self.replay_mr_corr_plot.invertY(True)' in MAIN


def test_hydrophone_probable_location_switches_between_mr_and_xy_modes():
    assert 'def _set_probable_location_anatomical_mode' in HYDRO
    assert 'self._set_probable_location_anatomical_mode(True)' in HYDRO
    assert HYDRO.count('self._set_probable_location_anatomical_mode(False)') >= 2


def test_hydrophone_mr_projection_flips_receiver_field_exactly_once():
    assert 'projected = receiver_field_to_raster_rows(shown_display)' in HYDRO
    assert 'normalized_y_to_raster_row(float(result.centroid_xy[1]), h, extent=1.05)' in HYDRO


def test_mr_correlation_converts_receiver_field_before_pixelwise_fusion():
    assert 'receiver_field_to_raster_rows(np.asarray(hydrophone_likelihood, float))' in MR_CORR


def test_likelihood_mr_refinement_converts_raster_loss_to_receiver_field():
    assert 'raster_rows_to_receiver_field(loss)' in LIKELIHOOD


def test_registration_flip_hypotheses_are_registration_search_not_display_mutations():
    # These deliberate hypotheses must remain confined to registration matching;
    # display code must not acquire new np.flipud/fliplr operations.
    assert '"flip-y":np.flipud(arr)' in REG
    assert 'np.flipud' not in MAIN
    assert 'np.fliplr' not in MAIN
    assert 'np.flipud' not in HYDRO
    assert 'np.fliplr' not in HYDRO


def test_red_threshold_contract_is_values_at_or_above_threshold():
    assert 'raw=np.isfinite(arr) & (arr>=float(threshold))' in IMG
    assert 'np.where(temp>=temperature_threshold,temp,np.nan)' in IMG
    assert 'arr<=float(threshold)' not in IMG
