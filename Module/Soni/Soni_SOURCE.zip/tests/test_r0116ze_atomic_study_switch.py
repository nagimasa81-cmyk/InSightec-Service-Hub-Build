from pathlib import Path
import ast

ROOT = Path(__file__).parents[1]
M = (ROOT / 'src/ui/main_window.py').read_text(encoding='utf-8')


def _method(name: str) -> str:
    return M.split(f'def {name}', 1)[1].split('\n    def ', 1)[0]


def test_source_switch_detaches_authoritative_package_immediately():
    block = _method('_prepare_source_switch')
    assert 'self._cancel_spectrum_preload()' in block
    assert 'self._spectrum_preload_context = None' in block
    assert 'self._invalidate_cpc_binding_cache()' in block
    assert 'self.package = None' in block
    assert 'self.current = None' in block
    assert 'self.sonication_index = -1' in block
    assert 'self.hydrophone_window.reset_source_context()' in block


def test_previous_workspace_is_retained_only_for_cleanup():
    block = _method('_prepare_source_switch')
    assert 'self._source_switch_previous_workspace = Path(self.package.workspace)' in block
    finished = _method('_package_load_finished')
    assert 'previous_workspace = self._source_switch_previous_workspace' in finished
    assert 'self._source_switch_previous_workspace = None' in finished


def test_terminal_load_failure_cannot_leave_old_study_adopted():
    failed = _method('_package_load_failed')
    assert 'previous_workspace = self._source_switch_previous_workspace' in failed
    assert 'self.importer.release(previous_workspace)' in failed
    assert 'self._source_switch_previous_workspace = None' in failed
    prepare = _method('_prepare_source_switch')
    assert prepare.index('self.package = None') < prepare.index('self._inline_notice')


def test_ast_valid():
    ast.parse(M)
