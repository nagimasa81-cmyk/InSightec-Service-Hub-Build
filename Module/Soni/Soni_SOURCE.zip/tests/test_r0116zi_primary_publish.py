from pathlib import Path


def _window_text():
    return Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")

def test_primary_publish_does_not_call_full_set_frame():
    text=_window_text()
    assert "def _set_frame_primary_only" in text
    assert text.count("self._set_frame_primary_only(0)") >= 2

def test_primary_helper_avoids_secondary_cavitation_work():
    text=_window_text()
    start=text.index("def _set_frame_primary_only")
    end=text.index("def set_frame", start)
    block=text[start:end]
    assert "self._refresh_frame_views()" in block
    assert "_update_cavitation_likelihood" not in block
    assert "_sync_cavitation_dynamic_views" not in block
    assert "_update_vendor_sync_cursors" not in block

def test_cached_publish_reports_intermediate_progress():
    text=_window_text()
    start=text.index("def load_sonication")
    end=text.index("def _finish_secondary_replay_publish", start)
    block=text[start:end]
    for value in (64,72,82,90):
        assert f"_set_subwindow_progress({value}" in block
