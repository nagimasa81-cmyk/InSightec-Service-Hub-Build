from pathlib import Path

from src.services.sonication_timing_service import SonicationTimingService


def _summary_xml(freq='650000'):
    return f'''<xml xmlns:rs="urn:schemas-microsoft-com:rowset" xmlns:z="#RowsetSchema"><rs:data><z:row sonicationindex="1" duration="24" actualduration="25.774" power="904" measuredpower="841.8" energy="20792" measuredenergy="20823" frequency="{freq}"/></rs:data></xml>'''


def test_frequency_is_read_from_sonication_summary(tmp_path: Path):
    p = tmp_path / 'SonicationSummary.xml'
    p.write_text(_summary_xml(), encoding='utf-8')
    rows = SonicationTimingService().read_all(tmp_path)
    assert len(rows) == 1
    assert rows[0].frequency_hz == 650_000.0
    assert rows[0].planned_power_w == 904.0
    assert rows[0].actual_power_w == 841.8


def test_frequency_numeric_mhz_compatibility():
    assert SonicationTimingService._frequency_hz('0.650') == 650_000.0
    assert SonicationTimingService._frequency_hz('650') == 650_000.0
    assert SonicationTimingService._frequency_hz('650000') == 650_000.0
