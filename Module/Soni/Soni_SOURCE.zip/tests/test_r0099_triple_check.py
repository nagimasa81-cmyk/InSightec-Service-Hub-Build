
from pathlib import Path
import ast, collections
ROOT=Path(__file__).parents[1]
MAIN=(ROOT/"src/ui/main_window.py").read_text(encoding="utf-8")
HYD=(ROOT/"src/ui/hydrophone_window.py").read_text(encoding="utf-8")
HRS=(ROOT/"src/services/hydrophone_replay_service.py").read_text(encoding="utf-8")
DISC=(ROOT/"src/services/discovery_service.py").read_text(encoding="utf-8")
REG=(ROOT/"src/services/registration_overlay_service.py").read_text(encoding="utf-8")

def test_no_duplicate_method_definitions():
    for text in (MAIN,HYD,HRS,REG):
        tree=ast.parse(text)
        for cls in (n for n in ast.walk(tree) if isinstance(n,ast.ClassDef)):
            c=collections.Counter(n.name for n in cls.body if isinstance(n,ast.FunctionDef))
            assert not {k:v for k,v in c.items() if v>1}

def test_event_tables_have_single_selection_path():
    assert "cellDoubleClicked.connect(self._observed_cavitation_event_selected)" not in HYD
    assert "cellDoubleClicked.connect(self._cavitation_event_selected)" not in HYD

def test_analyzer_round_trip_does_not_redecode_same_sonication():
    block=HYD.split("def sync_sonication",1)[1].split("def _sonication_changed",1)[0]
    assert "_loaded_sonication_index != index" in block

def test_cpc_discovery_shared_source_universe():
    assert "for path in workspace.rglob('*')" in DISC
    assert "if 'spectrummsg' in low" in DISC

def test_raw_fft_pairing_is_logical_before_mapping():
    block=HRS.split("def select_files",1)[1].split("def build(",1)[0]
    assert "groups" in block
    assert 'bucket["fft"]=p' in block
    assert 'bucket["raw"]=p' in block
    assert "return selected[1],selected[2]" in block

def test_summary_jump_opens_replay():
    block=MAIN.split("def _sonication_summary_jump",1)[1].split("@staticmethod",1)[0]
    assert "_select_sonication_index" in block
    assert "setCurrentWidget(self.replay_tab)" in block

def test_registration_has_containment_guard():
    assert "def _head_containment_fraction" in REG
    block=REG.split("def render_volume",1)[1].split("def render(",1)[0]
    assert "containment=self._head_containment_fraction" in block
    assert "containment < 0.35" in block
