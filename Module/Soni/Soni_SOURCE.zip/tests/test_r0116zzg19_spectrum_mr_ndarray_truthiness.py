from pathlib import Path


def test_spectrum_mr_timeline_never_boolean_tests_numpy_array():
    text = Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    bad = (
        'getattr(replay,"mr_frame_times_s",[]) or []',
        'getattr(replay, "mr_frame_times_s", []) or []',
        'getattr(self.replay,"mr_frame_times_s",[]) or []',
        'getattr(self.replay, "mr_frame_times_s", []) or []',
    )
    for token in bad:
        assert token not in text


def test_g19_fix_covers_all_four_mr_spectrum_consumers():
    text = Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    for name in (
        "_default_irradiation_end_frame_index",
        "_spectrum_mr_phase",
        "_update_spectrum_mr_timeline_label",
        "_jump_spectrum_mr_phase",
    ):
        start = text.index(f"def {name}")
        block = text[start:start+2600]
        assert "mr_frame_times_s" in block
        assert 'mr_frame_times_s",[]) or []' not in block
        assert 'mr_frame_times_s", []) or []' not in block
