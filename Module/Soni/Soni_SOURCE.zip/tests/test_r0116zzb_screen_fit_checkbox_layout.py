from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def test_spectrum_analyzer_prefers_fit_over_main_scrollbars():
    s=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'def _apply_compact_screen_layout' in s
    assert 'self._main_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)' in s
    assert 'self._main_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)' in s
    assert 'Qt.ScrollBarPolicy.ScrollBarAsNeeded if checked else Qt.ScrollBarPolicy.ScrollBarAlwaysOff' in s
    assert 'self._apply_compact_screen_layout()' in s
    # Legacy Vendor defaults must not be allowed to re-expand the dialog after fitting.
    vendor=s[s.index('def _apply_vendor_tab_default_layout'):s.index('def _fit_plot', s.index('def _apply_vendor_tab_default_layout'))]
    assert 'self._apply_compact_screen_layout()' in vendor


def test_cavitation_event_tables_have_no_horizontal_scrollbar():
    s=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'getattr(self, "cavitation_event_table", None)' in s
    assert 'def _optimize_cavitation_table_columns' in s
    assert 'table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)' in s


def test_replay_visibility_is_three_horizontal_checkboxes():
    s=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'visibility = QHBoxLayout()' in s
    for name in ('right_images_check','right_trends_check','right_analysis_check'):
        assert f'self.{name} = QCheckBox' in s
    assert 'visibility.addWidget(cb)' in s
    assert 'self.right_images_check.toggled.connect' in s
    assert 'self.right_trends_check.toggled.connect' in s
    assert 'self.right_analysis_check.toggled.connect' in s


def test_ci_three_sections_use_one_horizontal_checkbox_row_not_arrow_headers():
    s=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
    for name in ('ci_chain_check','ci_rca_check','ci_science_check'):
        assert f'self.{name} = QCheckBox' in s
        assert f'self.{name}.toggled.connect' in s
    build=s[s.index('def _build_cavitation_intelligence_tab'):s.index('def _ci_increase_filter_changed')]
    assert '_make_ci_collapsible_section(chain_header.text()' not in build
    assert '"Cavitation Root Cause Analysis — why did this Sonication cavitate?", rca_host' not in build
    assert '"Treatment Outcome Science — all Sonications", science_host' not in build


def test_ci_default_view_fits_without_vertical_scroll_and_optional_content_can_enable_it():
    s=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'page.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)' in s
    assert 'def _apply_ci_screen_fit' in s
    assert 'def _ci_optional_section_visibility_changed' in s
    assert 'Qt.ScrollBarPolicy.ScrollBarAsNeeded if optional else Qt.ScrollBarPolicy.ScrollBarAlwaysOff' in s
    assert 'self.ci_linked_control_plot.setMinimumHeight(140)' in s
    assert 'root.addWidget(self.ci_linked_host, 1)' in s


def test_spectrogram_hover_persists_and_is_localized():
    h=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    i=(ROOT/'src/ui/i18n.py').read_text(encoding='utf-8')
    assert 'def _spectrogram_help_text' in h
    assert "ui_text(lang, 'Spectrogram hover explanation')" in h
    assert '600000' in h
    assert 'QEvent.Type.Leave' in h and 'QToolTip.hideText()' in h
    assert '_SPECTROGRAM_HELP_I18N' in i
    for locale in ('en','ja','ko','zh_TW','es','th','hi'):
        assert repr(locale) + ':' in i
