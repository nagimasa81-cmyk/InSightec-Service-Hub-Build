from pathlib import Path

HYD=Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
MAIN=Path("src/ui/main_window.py").read_text(encoding="utf-8")

def test_replay_controls_pinned_and_window_resizable():
    assert "outer.addLayout(controls)" in HYD
    assert "self.setMaximumSize(16777215, 16777215)" in HYD
    assert "self.isMaximized() or self.isFullScreen()" in HYD
    assert "self._fit_current_tab(force=True)" in HYD

def test_probable_location_has_two_views_and_fixed_receiver_order():
    assert "self.cavitation_contribution_plot = pg.PlotWidget(title=\"RCV contribution\")" in HYD
    assert "self.cavitation_likelihood_plot = pg.PlotWidget(title=\"Probable cavitation region\")" in HYD
    assert "filled = [ch for ch in range(8) if ch in visible]" in HYD

def test_summary_has_location_and_dqa_na():
    assert "Cavitation location" in MAIN
    assert "Extracranial" in MAIN
    assert "Intracranial — near skull" in MAIN
    assert "Intracranial — central" in MAIN
    assert "NA" in MAIN and "_summary_export_is_dqa" in MAIN
