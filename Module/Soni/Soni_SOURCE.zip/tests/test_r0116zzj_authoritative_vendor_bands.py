from pathlib import Path
from types import SimpleNamespace
from src.services.standalone_cavitation_service import StandaloneCavitationService
from src.services.cpc_vendor_reproduction_service import VendorBand
from src.services.hydrophone_replay_service import HydrophoneReplayService

def test_no_legacy_default(): assert not hasattr(HydrophoneReplayService, "DEFAULT_BANDS_MHZ")
def test_ini_is_authoritative(monkeypatch):
    svc=StandaloneCavitationService(); p=SimpleNamespace(bands=[VendorBand(0,.5,0,310000,411000)], source_ini=Path("CavitationSafetyAndControl.ini")); r=SimpleNamespace(vendor_profile=p)
    monkeypatch.setattr(svc,"infer_band_ranges",lambda _: (_ for _ in ()).throw(AssertionError()))
    x=svc.resolved_band_ranges(r); assert x[0][:2]==(310000.0,411000.0)
def test_fft_only_fallback(monkeypatch):
    svc=StandaloneCavitationService(); r=SimpleNamespace(vendor_profile=SimpleNamespace(bands=[])); monkeypatch.setattr(svc,"infer_band_ranges",lambda _:{2:(500000,550000,1e-7)}); x=svc.resolved_band_ranges(r); assert x[2][2]=="FFT / embedded Band energy"
def test_no_guess(monkeypatch):
    svc=StandaloneCavitationService(); r=SimpleNamespace(vendor_profile=None); monkeypatch.setattr(svc,"infer_band_ranges",lambda _:{}); assert svc.resolved_band_ranges(r)=={}
def test_ui_only_4_vendor_bands():
    s=Path("src/ui/hydrophone_window.py").read_text(); assert "for i in range(4):" in s; assert "DEFAULT_BANDS_MHZ" not in s
