import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import numpy as np
from PySide6.QtWidgets import QApplication

from src.ui.image_panel import OverlayPanel


def test_r0015_circular_roi_measurement():
    app = QApplication.instance() or QApplication([])
    panel = OverlayPanel()
    magnitude = np.arange(100, dtype=float).reshape(10, 10)
    temperature = magnitude + 40.0
    panel.set_overlay(magnitude, temperature, fit=False)
    panel.show_measure_roi()
    panel.measure_roi.setPos((2, 2), update=False)
    panel.measure_roi.setSize((4, 4), update=False)
    panel._update_measurement()
    result = panel._last_measurement
    assert result is not None
    assert result["source"] == "Temperature"
    assert result["pixels"] > 0
    assert result["max"] >= result["mean"] >= result["min"]
