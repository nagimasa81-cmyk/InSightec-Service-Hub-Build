from pathlib import Path
import numpy as np

from src.services.hydrophone_replay_service import CpcHydrophoneReplay, CpcHydrophoneFrame


def _frame(i,t):
    return CpcHydrophoneFrame(i,np.array([1.0,2.0]),[np.ones(2) for _ in range(8)],acquisition_time_s=t,acquisition_cycle=i+1)

def test_gap_report_keeps_full_spectrum_unreconstructed_without_raw_adc():
    r=CpcHydrophoneReplay(None,None,frames=[_frame(0,0.0),_frame(1,0.01),_frame(2,1.0)],acquisition_interval_s=0.01)
    r.mr_sonication_start_s=0.0
    out=r.reconstruction_support()
    assert out["gaps"] and out["gaps"][0]["duration_s"] > 0.9
    assert out["full_spectrum_reconstruction"] is False

def test_validated_measurement_history_is_retained_as_band0_metric():
    r=CpcHydrophoneReplay(None,None,frames=[_frame(0,0.0),_frame(1,0.01)],acquisition_interval_s=0.01)
    r.snapshot_cycle_mapping_validated=True
    r.raw_timeline_time_s=np.array([0.0,0.01,0.02])
    r.raw_timeline_channels=[np.array([1.0,2.0,3.0])+ch for ch in range(8)]
    out=r.reconstruction_support()
    hist=out["band0_history"]
    assert hist["values"].shape == (3,8)
    assert "Band0" in hist["source"]

def test_ui_does_not_interpolate_spectrogram_across_missing_time():
    text=Path("src/ui/hydrophone_window.py").read_text(encoding="utf-8")
    block=text[text.index("def _draw_spectrogram"):text.index("def _selected_bands") ]
    assert "np.interp(target_t" not in block
    assert "np.full((source_img.shape[0],count),np.nan" in block
    assert "reconstructed metric" in text
