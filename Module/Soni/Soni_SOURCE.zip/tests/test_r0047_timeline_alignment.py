from pathlib import Path
import numpy as np
from src.services.cavitation_control_timeline_service import CavitationControlTimelineService
from src.services.cpc_vendor_reproduction_service import VendorCavitationProfile


def test_predicted_power_uses_observed_cycle_origin(tmp_path: Path):
    log = tmp_path / "Acquisition_Brain_test.txt"
    log.write_text(
        "12:00:00:000 Inf Got StartSpectrumMeasurement\n"
        "12:00:00:010 Inf Cycle 99 Done.\n"
        "12:00:00:020 Inf Set: SubSonic = 0, ExciterPower = 100 W, AblPower = 100 W, ExPowerRatio = 0.5 (0) AblPowerRatio = 0.5 (0)\n"
        "12:00:00:030 Inf Cycle 100 Done.\n"
        "12:00:00:040 Inf Set: SubSonic = 0, ExciterPower = 101 W, AblPower = 101 W, ExPowerRatio = 0.51 (0) AblPowerRatio = 0.51 (0)\n",
        encoding="utf-8",
    )
    svc = CavitationControlTimelineService()
    tl = svc.parse(log, VendorCavitationProfile(), 0, np.asarray([100, 101]), np.asarray([0.5, 0.51]))
    assert np.allclose(tl.predicted_power_times_s, [0.0, 0.01])
