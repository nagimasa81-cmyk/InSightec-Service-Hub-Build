from pathlib import Path
from types import SimpleNamespace
import numpy as np
from src.services.registration_overlay_service import RegistrationOverlayService


def _write_matrix(path: Path, m):
    path.write_text('\n'.join(' '.join(str(float(v)) for v in row) for row in np.asarray(m)), encoding='utf-8')


def _write_rgs(path: Path, reg_type: str, orientation: str):
    path.write_text(f"[General]\nRegType={reg_type}\nIsMatrixValid=True\nIsMatrixUpToDate=True\n[AutoReg]\nInitialSolution=UseLastReg\nMrOrientation={orientation}\n", encoding='utf-8')


def test_planning_mr_replays_saved_ctmr_without_hypothesis_search(tmp_path: Path):
    son=tmp_path/'Sonication1'; son.mkdir()
    ct=np.eye(4); ct[:3,3]=[1,2,3]
    _write_matrix(son/'CtMr_mat.txt',ct); _write_rgs(son/'CtMr.rgs','CtMr','MrAxial')
    svc=RegistrationOverlayService()
    recipe=svc._registration_recipe(tmp_path,1,SimpleNamespace(category='PLANNING_MR_AX'))
    assert recipe is not None
    assert recipe.chain_name=='CtMr'
    assert np.allclose(recipe.matrix,ct)
    assert recipe.orientation=='MrAxial' and recipe.valid and recipe.up_to_date


def test_preplanning_mr_replays_saved_mrmr_times_ctmr(tmp_path: Path):
    son=tmp_path/'Sonication1'; son.mkdir()
    ct=np.eye(4); ct[0,3]=10
    mm=np.eye(4); mm[1,3]=-5
    _write_matrix(son/'CtMr_mat.txt',ct); _write_matrix(son/'MrMr_mat.txt',mm)
    _write_rgs(son/'CtMr.rgs','CtMr','MrAxial'); _write_rgs(son/'MrMr.rgs','MrMr','MrSagittal')
    svc=RegistrationOverlayService()
    recipe=svc._registration_recipe(tmp_path,1,SimpleNamespace(category='PREPLANNING_MR_SAG'))
    assert recipe is not None
    assert recipe.chain_name=='inv(MrMr) × CtMr'
    assert np.allclose(recipe.matrix,np.linalg.inv(mm)@ct)
    assert recipe.orientation=='MrSagittal'


def test_rgs_validity_is_not_replaced_by_image_score(tmp_path: Path):
    son=tmp_path/'Sonication1'; son.mkdir()
    _write_matrix(son/'CtMr_mat.txt',np.eye(4))
    (son/'CtMr.rgs').write_text('[General]\nRegType=CtMr\nIsMatrixValid=False\nIsMatrixUpToDate=True\n',encoding='utf-8')
    recipe=RegistrationOverlayService()._registration_recipe(tmp_path,1,SimpleNamespace(category='PLANNING_MR_AX'))
    assert recipe is not None and recipe.valid is False


def test_render_volume_does_not_use_hypothesis_selection_source():
    text=(Path(__file__).parents[1]/'src/services/registration_overlay_service.py').read_text(encoding='utf-8')
    start=text.index('    def render_volume(')
    end=text.index('\n    def render(',start)
    block=text[start:end]
    assert '_registration_hypotheses' not in block
    assert "_world_reslice_mask(skull_mask" in block
    assert "recipe.matrix,'CtMr'" in block
