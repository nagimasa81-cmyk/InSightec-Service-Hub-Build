
from pathlib import Path
MAIN=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")
HYD=(Path(__file__).parents[1]/"src/ui/hydrophone_window.py").read_text(encoding="utf-8")

def test_probable_region_uses_real_correlation_fields():
    block=MAIN.split("def _draw_ci_linked_rcv_probable",1)[1].split("def _draw_ci_linked_vendor_energy",1)[0]
    assert 'getattr(corr, "current_image", [])' in block
    assert 'getattr(corr, "likelihood_centroid_xy", None)' in block
    assert "centroid_col" not in block
    assert "radius_px" not in block

def test_probable_region_has_current_mr_fallback():
    block=MAIN.split("def _draw_ci_linked_rcv_probable",1)[1].split("def _draw_ci_linked_vendor_energy",1)[0]
    assert "read_magnitude(self.current.magnitude_frames[idx].path)" in block

def test_ci_has_explicit_sonication_summary():
    assert 'self.tabs.addTab(self.sonication_summary_tab, "Sonication Summary")' in MAIN


def test_stale_show_images_control_removed():
    build=MAIN.split("def _build_cavitation_intelligence_tab",1)[1].split("def _ci_linked_mode_changed",1)[0]
    assert 'QCheckBox("Show images")' not in build

def test_vendor_legend_has_all_on_and_clear():
    assert 'QPushButton("All ON")' in HYD
    assert 'QPushButton("All Clear")' in HYD
    assert "def _set_all_vendor_legend_series" in HYD
