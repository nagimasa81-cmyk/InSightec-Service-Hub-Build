import numpy as np
from src.services.cavitation_likelihood_service import CavitationLikelihoodService, CavitationLikelihoodResult
from src.services.cavitation_mr_correlation_service import CavitationMrCorrelationResult


def test_refine_with_mr_preserves_extracranial_candidate_space():
    svc=CavitationLikelihoodService()
    n=80
    xs=np.linspace(-1.05,1.05,n); ys=np.linspace(-1.05,1.05,n)
    xx,yy=np.meshgrid(xs,ys)
    acoustic=np.exp(-((xx-0.72)**2+(yy+0.02)**2)/0.04)
    base=CavitationLikelihoodResult(acoustic,xs,ys,svc.DEFAULT_POSITIONS,svc.FOCUS_XY,np.ones(8)/8,0,(0.72,-0.02),'s','e')
    mr=np.exp(-((xx-0.88)**2+(yy+0.02)**2)/0.02)
    corr=CavitationMrCorrelationResult(mr,mr,np.ones_like(mr),12.0,2.5,(0.88,-0.02),(0.72,-0.02),0.16,0.7,75.0,'High candidate','x')
    out=svc.refine_with_mr(base,corr)
    assert out.mr_weight>0
    assert out.fusion_confidence is not None
    assert out.centroid_xy[0]>0.70
    assert np.isfinite(out.likelihood_map).all()

