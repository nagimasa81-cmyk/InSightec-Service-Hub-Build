from pathlib import Path
from types import SimpleNamespace

from src.services.registration_overlay_service import RegistrationOverlayService


def test_ct_geometry_prefers_mri_image_params(tmp_path: Path):
    xml = '''<?xml version="1.0"?>
<xml xmlns:rs="urn:schemas-microsoft-com:rowset" xmlns:z="#RowsetSchema">
<rs:data>
<z:row fieldindex="16" sonicationindex="1" arrayindex="0" imgnum="1"
 topleftcoordr="125.244141" topleftcoorda="145.644135" topleftcoords="-40"
 rowdirectcosrasx="0" rowdirectcosrasy="-1" rowdirectcosrasz="0"
 coldirectcosrasx="-1" coldirectcosrasy="0" coldirectcosrasz="0"
 pixsizex="0.488281" pixsizey="0.488281" slicethick="1.25" />
<z:row fieldindex="16" sonicationindex="1" arrayindex="1" imgnum="2"
 topleftcoordr="125.244141" topleftcoorda="145.644135" topleftcoords="-38.75"
 rowdirectcosrasx="0" rowdirectcosrasy="-1" rowdirectcosrasz="0"
 coldirectcosrasx="-1" coldirectcosrasy="0" coldirectcosrasz="0"
 pixsizex="0.488281" pixsizey="0.488281" slicethick="1.25" />
</rs:data></xml>'''
    (tmp_path/'MriImageParams.xml').write_text(xml, encoding='utf-8')
    asset=SimpleNamespace(field_index=16, sonication_index=1)
    geom=RegistrationOverlayService.read_ct_geometry(tmp_path, asset)
    assert geom is not None
    assert geom.source.name == 'MriImageParams.xml'
    assert tuple(round(v,6) for v in geom.origin_ras) == (125.244141,145.644135,-40.0)
    assert tuple(round(v,6) for v in geom.row_direction) == (0.0,-1.0,0.0)
    assert tuple(round(v,6) for v in geom.col_direction) == (-1.0,0.0,0.0)
    assert tuple(round(v,6) for v in geom.slice_direction) == (0.0,0.0,1.0)
    assert round(geom.slice_spacing,6) == 1.25
