from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
HYD=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
REPO=(ROOT/'src/services/spectrum_evidence_repository.py').read_text(encoding='utf-8')
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')


def test_shared_repository_owns_all_secondary_products():
    assert 'def secondary_products(' in REPO
    for key in ('"spectrogram"', '"band_energy"', '"cavitation_analysis"', '"resolved_bands"'):
        assert key in REPO
    assert '_secondary_inflight' in REPO
    assert 'cached_secondary_products' in REPO


def test_analyzer_worker_uses_study_repository_when_loaded_export_exists():
    assert 'repository=self.spectrum_evidence_repository if self.package is not None else None' in HYD
    assert 'self.repository.secondary_products(' in HYD
    assert 'self.spectrum_evidence_repository = getattr(parent, "spectrum_evidence_repository", None)' in HYD


def test_each_secondary_tab_publishes_independently():
    assert 'def _publish_secondary_payload' in HYD
    assert 'def _publish_secondary_product' in HYD
    # One failing view must not gate the remaining views behind one monolithic try.
    body=HYD.split('def _publish_secondary_payload',1)[1].split('def _publish_current_secondary_tab_from_cache',1)[0]
    for product in ('spectrogram','band_energy','vendor','cavitation'):
        assert f'"{product}"' in body
    assert '_publish_secondary_product("spectrogram"' in body
    assert '_publish_secondary_product("band_energy"' in body
    assert '_publish_secondary_product("vendor"' in body
    assert '_publish_secondary_product("cavitation"' in body


def test_tabs_opened_after_worker_completion_republish_from_cache():
    assert 'self._publish_current_secondary_tab_from_cache' in HYD
    assert 'QTimer.singleShot(0, self._publish_current_secondary_tab_from_cache)' in HYD


def test_waiting_no_data_error_states_are_explicit():
    assert 'Spectrogram: Processing…' in HYD
    assert 'Spectrogram: No data' in HYD
    assert 'Spectrogram: Needs attention' in HYD
    assert 'Band Energy: No data' in HYD
    assert 'Band Energy: Needs attention' in HYD
    assert 'Evidence unavailable — Needs attention' in HYD


def test_band_default_application_no_longer_recursively_draws():
    body=HYD.split('def _apply_vendor_band_defaults',1)[1].split('def _sync_vendor_rule_view_geometry',1)[0]
    assert 'self._draw_band_energy()' not in body
