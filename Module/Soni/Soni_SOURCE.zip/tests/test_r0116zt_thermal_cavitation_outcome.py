from src.services.cavitation_root_cause_service import CavitationRootCauseService

class E:
    family='Decrease'; result='CAVITATION'; weighted_energy=2.; threshold=1.; critical_threshold=None

def test_strong_thermal_without_cavitation_is_favorable_reference():
    r=CavitationRootCauseService().analyze(sonication_number=1,events=[],start_temp=37,peak_temp=55,delta_temp=18,power=300)
    assert r.thermal_response_score > 50
    assert not r.cavitation_detected
    assert 'without confirmed cavitation' in r.outcome_zone
    assert 'reference' in r.what_if_priority.lower()

def test_cavitation_with_limited_heating_is_poor_tradeoff():
    r=CavitationRootCauseService().analyze(sonication_number=1,events=[E()],start_temp=37,peak_temp=41,delta_temp=4,power=300)
    assert r.cavitation_detected
    assert r.thermal_response_score < 50
    assert 'Limited thermal response + cavitation' == r.outcome_zone
    assert r.cavitation_burden_score > 0
