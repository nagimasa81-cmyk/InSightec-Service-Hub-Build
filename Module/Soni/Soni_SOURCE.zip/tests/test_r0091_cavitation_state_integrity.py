
from pathlib import Path
import ast, collections
SRC=(Path(__file__).parents[1]/"src/ui/main_window.py").read_text(encoding="utf-8")

def _method(name,next_name):
    return SRC.split(f"def {name}",1)[1].split(f"def {next_name}",1)[0]

def test_ci_uses_strict_synchronized_cpc_only():
    block=_method("_update_cavitation_intelligence_page","_build_replay_tab")
    assert "_synchronized_cpc_frame_index(replay_time)" in block
    assert "_nearest_cpc_frame_index(replay_time)" not in block

def test_no_sync_clears_authoritative_likelihood():
    block=_method("_update_default_cavitation_intelligence","_update_cavitation_visualization")
    assert "self.default_cavitation_likelihood = None" in block
    assert "stale CPC frames are not reused" in block

def test_event_selection_is_preview_only():
    block=_method("_ci_event_selected","_ci_sonic_snapshot_changed")
    assert "self._ci_event_preview_result=result" in block
    assert "self.default_cavitation_likelihood=result" not in block

def test_sonication_prepare_clears_mr_state():
    block=_method("_prepare_default_cavitation_intelligence","_synchronized_cpc_frame_index")
    assert "self.default_cavitation_mr_correlation = None" in block

def test_element_map_has_single_paint_event():
    tree=ast.parse(SRC)
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="SonicationElementMapWidget")
    counts=collections.Counter(n.name for n in cls.body if isinstance(n,ast.FunctionDef))
    assert counts["paintEvent"] == 1
