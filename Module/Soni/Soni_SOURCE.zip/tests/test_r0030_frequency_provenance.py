import gzip
import struct
from pathlib import Path
import numpy as np
from src.core.spectrum_decoder import SharedSpectrumDecoder
from src.services.hydrophone_replay_service import HydrophoneReplayService


def _record_hz(peak_bin=215):
    vals=np.zeros(256,dtype='<f4'); vals[peak_bin]=1.0
    return struct.pack('<4fI',0.003,1953.0,250000.0,0.001,256)+vals.tobytes()+b'\0'*32


def test_spectrummsg_uses_one_explicit_group_per_declared_frame(tmp_path: Path):
    frames=[]
    for _ in range(2):
        body=bytearray(b'\0'*100)
        for ch in range(8): body += _record_hz(215 if ch else 43)
        frames.append(bytes(body))
    frame_size=len(frames[0]); header=struct.pack('<iii',2,frame_size,8)+b'\0'*180
    path=tmp_path/'SpectrumMsg-1.dmp'; path.write_bytes(gzip.compress(header+b''.join(frames)))
    decoded=SharedSpectrumDecoder().decode_frames(path,670000.0,channel_index=1)
    assert len(decoded)==2
    assert all('Embedded SpectrumMsg graph metadata' in x.frequency_axis_source for x in decoded)
    assert all(np.isclose(x.frequency_spacing_hz,1953.0) for x in decoded)
    assert all(np.isclose(x.main_peak_hz,669895.0) for x in decoded)


def test_cpc_fft_prefers_embedded_axis_over_ini_window():
    payload=bytearray()
    for ch in range(8):
        vals=np.zeros(256,dtype='<f4'); vals[215]=1.0
        payload += struct.pack('<4fI',0.003,0.001953,0.25,0.001,256)+vals.tobytes()+b'\0'*32
    frames=HydrophoneReplayService._decode_fft_payload(bytes(payload),1,8,2_000_000.0,250_000.0,750_000.0)
    assert len(frames)==1
    freq,_=frames[0]
    assert np.isclose(freq[0],250000.0,atol=.1)
    assert np.isclose(freq[1]-freq[0],1953.0,atol=.1)
    assert np.isclose(freq[215],669895.0,atol=1.0)
