from pathlib import Path
ROOT=Path(__file__).parents[1]
MAIN=(ROOT/"src/ui/main_window.py").read_text(encoding="utf-8")

def test_hover_preview_large_and_bounded():
    assert "max_box=QSize(620,620)" in MAIN
    assert "min(760,area.width()//2)" in MAIN
    assert "min(760,area.height()//2)" in MAIN
