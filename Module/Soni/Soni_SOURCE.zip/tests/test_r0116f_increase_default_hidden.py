
from pathlib import Path
ROOT=Path(__file__).parents[1]
SRC=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')

def test_increase_checkbox_defaults_off():
    assert 'self.show_increase_events_check.setChecked(False)' in SRC

def test_increase_hidden_from_chart_when_off():
    assert 'lower() == "increase" and not show_increase' in SRC
    assert 'continue' in SRC

def test_increase_hidden_from_event_table_when_off():
    assert 'if show_increase or str(getattr(ev, "family", "")) != "Increase"' in SRC

def test_tooltip_matches_visibility_contract():
    assert 'hidden from both the chart and event list by default' in SRC
