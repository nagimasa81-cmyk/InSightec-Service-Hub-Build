from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class MainFrequencyMetadata:
    frequency_hz: float | None
    source_path: Path | None
    raw_line: str | None
    confidence: float
    unit_interpretation: str


@dataclass(slots=True)
class XdReferenceFiles:
    xd_files: list[Path]
    geometry_files: list[Path]


class XdIniService:
    """Discover and parse valid transducer XD configuration files.

    Only serial-specific files are valid references:
      * Xd_####.ini
      * XdGometry_####.ini (field spelling)
      * XdGeometry_####.ini (supported compatibility spelling)

    Serial 0000 is the vendor/default template and is deliberately ignored.
    Broad names such as Xd.ini, Xd_test.ini, or Xd_ABC123.ini are not accepted.
    """

    NUMBER_RE = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?")
    MIN_VALID_FREQUENCY_HZ = 550_000.0
    MAX_VALID_FREQUENCY_HZ = 700_000.0

    XD_RE = re.compile(r"^xd_(\d{4})\.ini$", re.IGNORECASE)
    XD_GEOMETRY_RE = re.compile(r"^xd(?:gometry|geometry)_(\d{4})\.ini$", re.IGNORECASE)

    @staticmethod
    def _non_default_serial(match: re.Match[str] | None) -> bool:
        return bool(match and match.group(1) != "0000")

    def discover_references(self, workspace: Path) -> XdReferenceFiles:
        xd_files: list[Path] = []
        geometry_files: list[Path] = []
        for path in workspace.rglob("*.ini"):
            xd_match = self.XD_RE.fullmatch(path.name)
            if self._non_default_serial(xd_match):
                xd_files.append(path)
                continue
            geometry_match = self.XD_GEOMETRY_RE.fullmatch(path.name)
            if self._non_default_serial(geometry_match):
                geometry_files.append(path)

        key = lambda p: str(p).lower()
        xd_files.sort(key=key)
        geometry_files.sort(key=key)
        return XdReferenceFiles(xd_files=xd_files, geometry_files=geometry_files)

    def discover(self, workspace: Path) -> list[Path]:
        """Return only valid Xd_####.ini files used for frequency parsing."""
        return self.discover_references(workspace).xd_files

    def discover_geometry(self, workspace: Path) -> list[Path]:
        """Return valid non-default XdGometry/XdGeometry files."""
        return self.discover_references(workspace).geometry_files

    def read_main_frequency(self, workspace: Path) -> MainFrequencyMetadata:
        files = self.discover(workspace)
        if not files:
            return MainFrequencyMetadata(
                frequency_hz=None,
                source_path=None,
                raw_line=None,
                confidence=0.0,
                unit_interpretation="Valid non-default Xd_####.ini not found",
            )

        best: MainFrequencyMetadata | None = None
        for path in files:
            metadata = self._parse_file(path)
            if metadata.frequency_hz is not None:
                if best is None or metadata.confidence > best.confidence:
                    best = metadata

        if best is not None:
            return best

        return MainFrequencyMetadata(
            frequency_hz=None,
            source_path=files[-1],
            raw_line=None,
            confidence=10.0,
            unit_interpretation="No numeric value found on final data line",
        )

    def _parse_file(self, path: Path) -> MainFrequencyMetadata:
        text = path.read_text(encoding="utf-8", errors="ignore")
        lines = [
            line.strip()
            for line in text.splitlines()
            if line.strip() and not line.lstrip().startswith(("#", ";", "//"))
        ]
        if not lines:
            return MainFrequencyMetadata(None, path, None, 5.0, "Empty INI")

        raw_line = lines[-1]
        numbers = self.NUMBER_RE.findall(raw_line)
        if not numbers:
            return MainFrequencyMetadata(None, path, raw_line, 10.0, "No numeric token")

        value = float(numbers[-1])
        lower = raw_line.lower()

        if "mhz" in lower:
            frequency_hz = value * 1_000_000.0
            interpretation = "Explicit MHz"
            confidence = 100.0
        elif "khz" in lower:
            frequency_hz = value * 1_000.0
            interpretation = "Explicit kHz"
            confidence = 100.0
        elif re.search(r"(?<![kKmM])\bhz\b", raw_line, re.IGNORECASE):
            frequency_hz = value
            interpretation = "Explicit Hz"
            confidence = 100.0
        elif abs(value) < 10.0:
            frequency_hz = value * 1_000_000.0
            interpretation = "Unit inferred as MHz"
            confidence = 80.0
        elif abs(value) < 10_000.0:
            frequency_hz = value * 1_000.0
            interpretation = "Unit inferred as kHz"
            confidence = 75.0
        else:
            frequency_hz = value
            interpretation = "Unit inferred as Hz"
            confidence = 75.0

        if not (self.MIN_VALID_FREQUENCY_HZ <= frequency_hz <= self.MAX_VALID_FREQUENCY_HZ):
            return MainFrequencyMetadata(
                frequency_hz=None,
                source_path=path,
                raw_line=raw_line,
                confidence=0.0,
                unit_interpretation=(
                    f"Rejected {frequency_hz/1_000_000.0:.3f} MHz: outside supported "
                    "sonication transmit band 0.550-0.700 MHz"
                ),
            )

        return MainFrequencyMetadata(
            frequency_hz=frequency_hz,
            source_path=path,
            raw_line=raw_line,
            confidence=confidence,
            unit_interpretation=interpretation,
        )
