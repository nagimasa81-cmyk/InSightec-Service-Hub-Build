from pathlib import Path
from types import SimpleNamespace
import numpy as np

from src.services.spectrum_dump_import_service import SpectrumDumpCandidate, SpectrumDumpImportService
from src.services.cavitation_control_timeline_service import CavitationControlTimelineService


def test_canonical_session_beats_positional_mapping(tmp_path, monkeypatch):
    imp = SpectrumDumpImportService()
    c1 = SpectrumDumpCandidate('a', tmp_path/'a.dmp', tmp_path/'a.dmp_FFT', 'a', 'CPC Spectrum')
    c2 = SpectrumDumpCandidate('b', tmp_path/'b.dmp', tmp_path/'b.dmp_FFT', 'b', 'CPC Spectrum')
    c1.acquisition_session_index = 8
    c2.acquisition_session_index = 7
    monkeypatch.setattr(imp, 'bind_candidates_to_acquisition_sessions', lambda candidates: None)
    sons = [
        SimpleNamespace(name='Sonication1', folder=tmp_path/'Sonication1', canonical_acquisition_session_index=7, canonical_mapping_evidence=['local exact']),
        SimpleNamespace(name='Sonication2', folder=tmp_path/'Sonication2', canonical_acquisition_session_index=8, canonical_mapping_evidence=['local exact']),
    ]
    mapping = imp.map_candidates_to_sonications([c1,c2], sons)
    assert mapping[0] is c2
    assert mapping[1] is c1
    assert mapping[0].mapping_confidence == 'Exact'


def test_replay_and_ui_use_sonication_clock():
    hydro = Path('src/services/hydrophone_replay_service.py').read_text(encoding='utf-8')
    main = Path('src/ui/main_window.py').read_text(encoding='utf-8')
    window = Path('src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'time = replay.sonication_frame_times_s' in hydro
    assert 'times = np.asarray(replay.sonication_frame_times_s, float)' in main
    assert 'timestamp_seconds=float(replay.sonication_frame_times_s[frame.index])' in main
    assert 'self.replay.sonication_frame_times_s' in window


def test_spectrummsg_uses_powergraph_clock_when_cardinality_matches():
    main = Path('src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'if len(pg_time) == len(son_frames):' in main
    assert 'frame.timestamp_seconds = float(pg_time[i])' in main


def test_control_timeline_has_canonical_offset_parameter():
    text = Path('src/services/cavitation_control_timeline_service.py').read_text(encoding='utf-8')
    assert 'sonication_time_zero_offset_s: float = 0.0' in text
    assert 'event.timestamp_s = (float(event.cycle) - float(base_cycle)) * 0.010 - float(sonication_time_zero_offset_s or 0.0)' in text


def test_discovery_populates_sonication_evidence_fields():
    text = Path('src/services/discovery_service.py').read_text(encoding='utf-8')
    assert 'self.sonication_evidence.read(workspace, models)' in text
    assert 'model.canonical_acquisition_session_index = evidence.acquisition_session_index' in text
    assert 'model.spectrummsg_frame_count = evidence.spectrummsg_frame_count' in text
