from __future__ import annotations

import re
from pathlib import Path

from src.common.constants import MAGNITUDE_PREFIX, TEMPERATURE_PREFIX, DEFAULT_MAIN_FREQUENCY_HZ
from src.domain.models import RawFrame, ReplayPackage, SonicationModel
from src.services.xd_ini_service import XdIniService
from src.services.sonication_frequency_service import SonicationFrequencyService
from src.services.sonication_timing_service import SonicationTimingService
from src.services.planning_data_service import PlanningDataService
from src.services.sonication_evidence_service import SonicationEvidenceService
from src.core.fus_export_core import inspect_export


SON_RE = re.compile(r"^sonication\s*[_-]?\s*(\d+)$", re.I)
RAW_RE = re.compile(r"^(\d+)-.*-(\d+)\.raw$", re.I)


def natural_key(text):
    return [
        int(x) if x.isdigit() else x.lower()
        for x in re.split(r"(\d+)", text)
    ]


class DiscoveryService:
    def __init__(self) -> None:
        self.xd_ini = XdIniService()
        self.sonication_frequency = SonicationFrequencyService()
        self.sonication_timing = SonicationTimingService()
        self.planning_data = PlanningDataService()
        self.sonication_evidence = SonicationEvidenceService()

    def discover(self, source: Path, workspace: Path) -> ReplayPackage:
        dirs = []
        for path in workspace.rglob("*"):
            if path.is_dir() and SON_RE.match(path.name):
                dirs.append(path)

        if SON_RE.match(workspace.name):
            dirs.append(workspace)

        if (
            not dirs
            and any(
                path.is_file()
                and (
                    "spectrummsg" in path.name.lower()
                    or path.suffix.lower() == ".raw"
                )
                for path in workspace.iterdir()
            )
        ):
            dirs = [workspace]

        unique = {path.resolve(): path for path in dirs}
        dirs = sorted(
            unique.values(),
            key=lambda path: natural_key(path.name),
        )
        models = [
            self._build(path, index + 1)
            for index, path in enumerate(dirs)
        ]

        # Semantic Export inspection is intentionally independent from replay
        # decoding. PARTIAL sonications remain loadable; missing assets are
        # reported per capability rather than blocking the whole case.
        export_inspection = inspect_export(workspace)
        inspection_by_number = {item.number: item for item in export_inspection.sonications}
        for index, model in enumerate(models):
            match = SON_RE.match(model.folder.name)
            number = int(match.group(1)) if match else index + 1
            item = inspection_by_number.get(number)
            if item is not None:
                model.completeness_status = item.status
                model.completeness_score = item.score
                model.missing_required = list(item.missing_required)
                model.missing_optional = list(item.missing_optional)
                model.degraded_items = list(item.degraded_items)
                model.capabilities = {
                    key: {
                        "available": value.available,
                        "degraded": value.degraded,
                        "reason": value.reason,
                        "evidence": list(value.evidence),
                    }
                    for key, value in item.capabilities.items()
                }
                model.thermometry_mode = item.thermometry_mode

        timings = self.sonication_timing.read_all(workspace)
        for index, model in enumerate(models):
            if index < len(timings):
                timing = timings[index]
                model.planned_duration_s = timing.planned_duration_s
                model.actual_duration_s = timing.actual_duration_s
                model.planned_power_w = timing.planned_power_w
                model.actual_power_w = timing.actual_power_w
                model.planned_energy_j = timing.planned_energy_j
                model.actual_energy_j = timing.actual_energy_j
                # Authoritative Workstation Replay frequency: SonicationSummary.xml
                # per-sonication row. Do not replace this value with SkullHeating
                # or package/XD nominal frequency.
                if timing.frequency_hz is not None:
                    model.main_frequency_hz = timing.frequency_hz
                    model.main_frequency_source = timing.source
                    model.main_frequency_raw_line = f"SonicationSummary.frequency={timing.frequency_hz:g}"
                model.timing_source = timing.source

        xd_references = self.xd_ini.discover_references(workspace)
        frequency = self.xd_ini.read_main_frequency(workspace)
        fallback_hz = frequency.frequency_hz if frequency.frequency_hz is not None else DEFAULT_MAIN_FREQUENCY_HZ
        for model in models:
            # SonicationSummary frequency is authoritative for Workstation Replay.
            # Legacy/local discovery is used only when the summary has no frequency.
            if model.main_frequency_hz is not None:
                continue
            local = self.sonication_frequency.read(model.folder)
            model.main_frequency_hz = local.frequency_hz if local.frequency_hz is not None else fallback_hz
            model.main_frequency_source = local.source if local.source is not None else frequency.source_path
            model.main_frequency_raw_line = local.raw_line if local.raw_line is not None else frequency.raw_line

        # R0116zm: establish a Sonication-local evidence chain before CPC mapping.
        # SonicationN/SpectrumMsg-N + PowerGraph + SonicationSummary + Sonication_Brain
        # gives an absolute Type6 setup clock and authoritative Acquisition session.
        try:
            evidence_rows = self.sonication_evidence.read(workspace, models)
        except Exception:
            evidence_rows = []
        for model, evidence in zip(models, evidence_rows):
            model.canonical_acquisition_session_index = evidence.acquisition_session_index
            model.canonical_setup_clock_s = evidence.setup_record.clock_s if evidence.setup_record is not None else None
            model.canonical_mapping_confidence = evidence.confidence
            model.canonical_mapping_evidence = list(evidence.evidence)
            model.spectrummsg_frame_count = evidence.spectrummsg_frame_count
            model.powergraph_size = evidence.powergraph_size
            model.sonication_file_inventory = dict(evidence.file_inventory)

        cpc_files = []
        for path in workspace.rglob('*'):
            if not path.is_file():
                continue
            low = path.name.lower()
            if 'spectrummsg' in low:
                continue
            if low.startswith('spectrum_') and (low.endswith('.dmp') or low.endswith('.dmp_fft')):
                cpc_files.append(path)
        cpc_files = sorted(set(cpc_files), key=lambda path: natural_key(str(path)))

        # One physical CPC source universe is shared by Replay Cavitation
        # Intelligence and Spectrum Dump Analyzer. SpectrumMsg stays separate.

        planning = self.planning_data.discover(workspace)

        return ReplayPackage(
            source=source,
            workspace=workspace,
            sonications=models,
            main_frequency_hz=frequency.frequency_hz if frequency.frequency_hz is not None else DEFAULT_MAIN_FREQUENCY_HZ,
            main_frequency_source=frequency.source_path,
            main_frequency_raw_line=frequency.raw_line,
            main_frequency_confidence=frequency.confidence,
            main_frequency_interpretation=frequency.unit_interpretation if frequency.frequency_hz is not None else "Default 650 kHz",
            cpc_spectrum_files=cpc_files,
            planning_assets=planning.assets,
            xd_reference_files=xd_references.xd_files,
            xd_geometry_files=xd_references.geometry_files,
            workflow_mode=export_inspection.workflow_mode,
            thermometry_mode=export_inspection.thermometry_mode,
        )

    def _build(
        self,
        folder: Path,
        fallback: int,
    ) -> SonicationModel:
        match = SON_RE.match(folder.name)
        name = (
            f"Sonication{int(match.group(1))}"
            if match
            else f"Sonication{fallback}"
        )

        model = SonicationModel(
            name=name,
            folder=folder,
        )

        for path in folder.rglob("*"):
            if not path.is_file():
                continue

            low = path.name.lower()
            raw_match = RAW_RE.match(path.name)

            if raw_match:
                frame = RawFrame(
                    path=path,
                    index=int(raw_match.group(2)),
                    prefix=raw_match.group(1),
                )
                if frame.prefix == TEMPERATURE_PREFIX:
                    model.temperature_frames.append(frame)
                elif frame.prefix == MAGNITUDE_PREFIX:
                    model.magnitude_frames.append(frame)
                else:
                    model.other_files.append(path)
            elif (
                "spectrummsg" in low
                and path.suffix.lower() == ".dmp"
            ):
                model.spectrum_files.append(path)
            elif path.suffix.lower() == ".act":
                model.act_files.append(path)
            else:
                model.other_files.append(path)

        model.temperature_frames.sort(key=lambda frame: frame.index)
        model.magnitude_frames.sort(key=lambda frame: frame.index)
        model.spectrum_files.sort(
            key=lambda path: natural_key(path.name)
        )
        model.act_files.sort(
            key=lambda path: natural_key(path.name)
        )
        return model
