# Architecture

## Main-frequency source

The main sonication frequency is read from the final non-empty line of an
`Xd_*.ini` or `Xd*.ini` file.

The parser accepts:

- `650000`
- `650000 Hz`
- `650 kHz`
- `0.650 MHz`
- `Frequency=650000`

The normalized value is stored internally in Hz.

## Spectrum integration

SpectrumMsg Analyzer logic is exposed through:

`src/integration/spectrum_provider.py`

Replay UI receives only common `SpectrumFrame` objects. It does not directly
depend on analyzer widgets.
