from __future__ import annotations

import math
import struct
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass(slots=True)
class DecodedSpectrum:
    offset: int
    frequency_hz: np.ndarray
    amplitude: np.ndarray
    confidence: float
    main_peak_hz: float | None
    source: Path


class SharedSpectrumDecoder:
    """
    Lightweight shared decoder for Replay integration.

    SpectrumMsg Analyzer remains the detailed reverse-engineering application.
    This decoder evaluates a bounded set of Float32/Little-Endian offsets and
    selects the candidate whose strongest peak is closest to the Xd INI main
    frequency.
    """

    SAMPLE_COUNT = 2048
    MAX_READ_BYTES = 8 * 1024 * 1024

    def decode_file(
        self,
        path: Path,
        main_frequency_hz: float,
    ) -> DecodedSpectrum | None:
        data = path.read_bytes()[: self.MAX_READ_BYTES]
        sample_bytes = self.SAMPLE_COUNT * 4
        if len(data) < 64:
            return None

        max_frequency_hz = max(
            main_frequency_hz * 2.2,
            main_frequency_hz + 200_000.0,
        )

        candidate_offsets = {0, 16, 32, 64, 128, 256, 512, 1024}
        for divisor in range(1, 17):
            candidate_offsets.add(
                max(0, (len(data) // divisor) // 4 * 4)
            )
        for offset in range(
            0,
            min(len(data), sample_bytes * 4),
            max(256, sample_bytes // 4),
        ):
            candidate_offsets.add(offset)

        best = None
        best_score = -1.0

        for offset in sorted(candidate_offsets):
            if offset + 16 > len(data):
                continue

            count = min(
                self.SAMPLE_COUNT,
                (len(data) - offset) // 4,
            )
            if count < 64:
                continue

            values = np.frombuffer(
                data,
                dtype="<f4",
                count=count,
                offset=offset,
            ).astype(np.float64)

            finite = np.isfinite(values)
            if float(np.mean(finite)) < 0.95:
                continue

            amplitude = np.abs(
                np.nan_to_num(
                    values,
                    nan=0.0,
                    posinf=0.0,
                    neginf=0.0,
                )
            )

            if not np.any(amplitude > 0):
                continue

            frequencies = np.linspace(
                0.0,
                max_frequency_hz,
                num=count,
                endpoint=False,
            )

            peak_index = int(np.argmax(amplitude))
            peak_frequency = float(frequencies[peak_index])
            distance = abs(
                peak_frequency - main_frequency_hz
            ) / max(main_frequency_hz, 1.0)

            non_negative = float(np.mean(values >= 0))
            dynamic = float(
                np.max(amplitude)
                / max(np.mean(amplitude), 1e-12)
            )
            continuity = 1.0 - min(
                1.0,
                float(np.std(np.diff(amplitude)))
                / max(float(np.std(amplitude)) * 2.0, 1e-12),
            )

            frequency_score = max(0.0, 1.0 - distance)
            dynamic_score = min(1.0, dynamic / 20.0)
            score = (
                frequency_score * 0.55
                + non_negative * 0.15
                + dynamic_score * 0.20
                + continuity * 0.10
            ) * 100.0

            if score > best_score:
                best_score = score
                best = DecodedSpectrum(
                    offset=offset,
                    frequency_hz=frequencies,
                    amplitude=amplitude,
                    confidence=round(score, 1),
                    main_peak_hz=peak_frequency,
                    source=path,
                )

        return best
