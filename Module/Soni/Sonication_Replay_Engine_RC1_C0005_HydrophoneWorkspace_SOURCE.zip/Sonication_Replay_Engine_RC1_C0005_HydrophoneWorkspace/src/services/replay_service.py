from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from src.domain.models import SonicationModel
from src.services.raw_service import RawService

@dataclass(slots=True)
class ReplayFrameData:
    replay_index: int
    magnitude_index: int | None
    temperature_index: int | None
    magnitude: np.ndarray | None
    temperature: np.ndarray | None
    temperature_delta: np.ndarray | None
    hotspot_x: int | None = None
    hotspot_y: int | None = None
    maximum_temperature: float | None = None
    mean_temperature: float | None = None
    maximum_delta_temperature: float | None = None
    mean_delta_temperature: float | None = None

class ReplayService:
    def __init__(self):
        self.raw = RawService()
        self._baseline_cache: dict[str, np.ndarray] = {}

    def _baseline(self, son: SonicationModel) -> np.ndarray | None:
        if not son.temperature_frames:
            return None
        key = str(son.folder.resolve())
        if key not in self._baseline_cache:
            self._baseline_cache[key] = self.raw.read_temperature(son.temperature_frames[0].path)
        return self._baseline_cache[key]

    def frame(self, son: SonicationModel, index: int) -> ReplayFrameData:
        count = son.replay_frame_count
        index = max(0, min(index, count - 1))
        mag = temp = delta = None
        mi = ti = None
        if son.magnitude_frames:
            mi = self.raw.normalize_index(index, count, len(son.magnitude_frames))
            mag = self.raw.read_magnitude(son.magnitude_frames[mi].path)
        if son.temperature_frames:
            ti = self.raw.normalize_index(index, count, len(son.temperature_frames))
            temp = self.raw.read_temperature(son.temperature_frames[ti].path)
            baseline = self._baseline(son)
            if baseline is not None and baseline.shape == temp.shape:
                delta = temp - baseline

        hx = hy = None
        mx = mean = md = meand = None
        hotspot_source = delta if delta is not None else temp
        if hotspot_source is not None and np.isfinite(hotspot_source).any():
            safe = np.nan_to_num(hotspot_source, nan=-np.inf)
            flat = int(np.argmax(safe))
            hy, hx = np.unravel_index(flat, hotspot_source.shape)
        if temp is not None and np.isfinite(temp).any():
            mx = float(np.nanmax(temp))
            mean = float(np.nanmean(temp))
        if delta is not None and np.isfinite(delta).any():
            md = float(np.nanmax(delta))
            meand = float(np.nanmean(delta))

        return ReplayFrameData(index, mi, ti, mag, temp, delta, hx, hy, mx, mean, md, meand)
