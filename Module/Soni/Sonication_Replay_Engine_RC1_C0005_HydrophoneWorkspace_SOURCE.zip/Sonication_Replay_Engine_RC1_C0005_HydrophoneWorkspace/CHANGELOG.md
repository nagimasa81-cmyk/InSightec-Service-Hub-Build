# Changelog

## RC1 C0005 HydrophoneWorkspace
- Added All / single / multiple Hydrophone channel selection.
- Added Spectrum, Waterfall, and Both display modes.
- Added Overlay and Stacked multi-channel spectrum layouts.
- Added replay-synchronized multi-channel waterfall rendering.
- Enlarged the primary Magnitude + ΔTemperature overlay by assigning more vertical layout space.
- Preserved Frame Navigator, replay controls, temperature trend, metadata, Xd.ini frequency lookup, and 650 kHz fallback.

## RC1 C0004 OverlayReplayUI
- Added the primary Magnitude + ΔTemperature overlay replay layout.
