# Sonication Replay Engine RC1 C0005

Treatment-first replay viewer with a large Magnitude + ΔTemperature overlay and an adaptive multi-channel Hydrophone Workspace.

## Hydrophone Workspace
- All, single, or multiple channel selection
- Spectrum, Waterfall, or Both display
- Overlay or Stacked multi-channel chart layout
- Replay-synchronized spectrum and waterfall
- Automatic fallback to CH1 when channel information is absent

Use the BAT files in `build` for verification, debug launch, and Nuitka builds.
