from __future__ import annotations

import math
import struct
import tempfile
from pathlib import Path

from src.integration.spectrum_provider import SpectrumMsgAnalyzerAdapter
from src.services.xd_ini_service import XdIniService


def main() -> int:
    with tempfile.TemporaryDirectory(
        prefix="SonicationReplayCommit5Verify_"
    ) as temp:
        root = Path(temp)

        ini = root / "Xd_ABC123.ini"
        ini.write_text(
            "[Transducer]\nSerial=ABC123\nMainFrequency=650 kHz\n",
            encoding="utf-8",
        )

        metadata = XdIniService().read_main_frequency(root)
        assert metadata.frequency_hz == 650000.0
        assert metadata.source_path == ini
        assert metadata.raw_line == "MainFrequency=650 kHz"

        son = root / "Sonication1"
        son.mkdir()

        values = []
        sample_count = 2048
        for index in range(sample_count):
            value = (
                math.exp(-((index - 930) / 20.0) ** 2) * 100.0
                + math.exp(-((index - 465) / 16.0) ** 2) * 25.0
                + math.exp(-((index - 1860) / 30.0) ** 2) * 40.0
            )
            values.append(struct.pack("<f", value))

        spectrum_file = son / "SpectrumMsg-1.dmp"
        spectrum_file.write_bytes(
            b"SPECTRUMMSG" + b"\x00" * 21 + b"".join(values)
        )

        adapter = SpectrumMsgAnalyzerAdapter(
            metadata.frequency_hz
        )
        frames = adapter.load([spectrum_file])

        assert len(frames) == 1
        assert frames[0].frequency
        assert frames[0].amplitude
        assert frames[0].main_peak_hz is not None
        assert abs(frames[0].main_peak_hz - 650000.0) < 100000.0

    print("VERIFY_SOURCE_OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
