from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
import numpy as np


@dataclass(slots=True)
class RegistrationOverlayResult:
    overlay: np.ndarray | None
    matrix: np.ndarray | None
    matrix_source: Path | None
    ct_source: Path | None
    status: str
    selected_slice_index: int | None = None
    alignment_score: float | None = None


class RegistrationOverlayService:
    """Render an evidence-preserving CT bone overlay on planning MR.

    The treatment export stores the adopted CT↔MR registration in CtMr_mat.txt.
    For the 2-D replay review we project the relevant in-plane rotation and
    translation from that 4x4 matrix onto the selected MR plane. This is not a
    replacement for a full 3-D reslice; it is deliberately labelled as a 2-D
    treatment-registration review overlay.
    """

    _FLOAT_RE = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?")

    @classmethod
    def read_matrix(cls, path: Path | None) -> np.ndarray | None:
        if path is None or not Path(path).is_file():
            return None
        try:
            vals = [float(x) for x in cls._FLOAT_RE.findall(Path(path).read_text(encoding='utf-8', errors='ignore'))]
        except (OSError, ValueError):
            return None
        if len(vals) < 16:
            return None
        return np.asarray(vals[:16], float).reshape(4, 4)

    @staticmethod
    def find_treatment_matrix(workspace: Path, sonication_index: int) -> Path | None:
        candidates = [
            workspace / f"Sonication{sonication_index}" / "CtMr_mat.txt",
            workspace / f"Sonication_{sonication_index}" / "CtMr_mat.txt",
            workspace / "WSFiles" / "lastCtMrRegistration_mat.txt",
        ]
        for p in candidates:
            if p.is_file():
                return p
        hits = sorted(workspace.rglob("CtMr_mat.txt"))
        return hits[0] if hits else None

    @staticmethod
    def _plane_axes(plane: str) -> tuple[int, int]:
        p = (plane or '').lower()
        if 'sag' in p:
            return (1, 2)  # A/S
        if 'cor' in p:
            return (0, 2)  # R/S
        return (0, 1)      # R/A (Axial default)

    @staticmethod
    def _bilinear_sample(image: np.ndarray, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        h, w = image.shape[:2]
        x0 = np.floor(x).astype(int); y0 = np.floor(y).astype(int)
        x1 = x0 + 1; y1 = y0 + 1
        valid = (x0 >= 0) & (y0 >= 0) & (x1 < w) & (y1 < h)
        out = np.full(x.shape, np.nan, float)
        if not np.any(valid):
            return out
        xv = x[valid]; yv = y[valid]
        x0v=x0[valid]; x1v=x1[valid]; y0v=y0[valid]; y1v=y1[valid]
        wx=xv-x0v; wy=yv-y0v
        a=image[y0v,x0v]; b=image[y0v,x1v]; c=image[y1v,x0v]; d=image[y1v,x1v]
        out[valid]=(1-wx)*(1-wy)*a + wx*(1-wy)*b + (1-wx)*wy*c + wx*wy*d
        return out

    @staticmethod
    def _bone_edges(ct: np.ndarray) -> np.ndarray:
        arr=np.asarray(ct,float)
        finite=arr[np.isfinite(arr)]
        if finite.size < 64:
            return np.full(arr.shape, np.nan, float)
        # Signed HU-like CT: isolate the high-density tail.  A pure percentile
        # can collapse to background when most voxels are zero, so combine it
        # with a fraction of the observed dynamic range.
        low=float(np.percentile(finite, 5)); high=float(np.percentile(finite, 99.5))
        if float(np.nanmax(finite)) - float(np.nanmin(finite)) <= np.finfo(float).eps:
            return np.full(arr.shape, np.nan, float)
        threshold=max(float(np.percentile(finite, 84)), low + 0.30*max(high-low, 0.0))
        if high <= low or threshold >= float(np.nanmax(finite)):
            threshold=low + 0.50*max(float(np.nanmax(finite))-low, 0.0)
        mask=(arr >= threshold).astype(float)
        gy,gx=np.gradient(mask)
        edge=np.hypot(gx,gy) > 0.05
        return np.where(edge, arr, np.nan)

    def project_2d(self, ct: np.ndarray, mr_shape: tuple[int,int], matrix: np.ndarray, plane: str,
                   ct_pixel_mm: float = 0.5, mr_pixel_mm: tuple[float,float] = (1.0,1.0)) -> np.ndarray:
        ct=np.asarray(ct,float)
        mh,mw=int(mr_shape[0]),int(mr_shape[1])
        ch,cw=ct.shape[:2]
        axes=self._plane_axes(plane)
        rot=matrix[np.ix_(axes, axes)]
        trans=matrix[list(axes), 3]
        # Mapping output MR pixel -> source CT pixel. Invert the treatment transform.
        try:
            inv=np.linalg.inv(rot)
        except np.linalg.LinAlgError:
            inv=np.eye(2)
        yy,xx=np.mgrid[0:mh,0:mw]
        mx=(xx-(mw-1)/2.0)*float(mr_pixel_mm[0])
        my=(yy-(mh-1)/2.0)*float(mr_pixel_mm[1])
        pts=np.stack([mx-trans[0], my-trans[1]],axis=0).reshape(2,-1)
        src=inv@pts
        sx=(src[0]/float(ct_pixel_mm)+(cw-1)/2.0).reshape(mh,mw)
        sy=(src[1]/float(ct_pixel_mm)+(ch-1)/2.0).reshape(mh,mw)
        warped=self._bilinear_sample(ct,sx,sy)
        return self._bone_edges(warped)


    @staticmethod
    def _mr_edge_strength(mr: np.ndarray) -> np.ndarray:
        arr=np.asarray(mr,float)
        finite=arr[np.isfinite(arr)]
        if finite.size < 64:
            return np.zeros(arr.shape,float)
        lo,hi=np.percentile(finite,[2,98.5])
        scaled=np.clip((arr-lo)/max(hi-lo,1e-9),0,1)
        gy,gx=np.gradient(scaled)
        return np.hypot(gx,gy)

    @classmethod
    def _alignment_score(cls, mr: np.ndarray, bone_overlay: np.ndarray) -> float:
        edge=np.isfinite(bone_overlay)
        if np.count_nonzero(edge) < 20:
            return float('-inf')
        mr_edge=cls._mr_edge_strength(mr)
        vals=mr_edge[edge]
        if vals.size < 20:
            return float('-inf')
        # Reward bone edges that land on strong MR anatomical boundaries while
        # mildly penalizing overlays that cover an excessive fraction of image.
        score=float(np.nanmean(vals))
        density=float(np.count_nonzero(edge))/float(edge.size)
        return score-0.12*max(0.0,density-0.12)

    @staticmethod
    def _volume_plane_slices(volume: np.ndarray, plane: str):
        vol=np.asarray(volume,float)
        p=(plane or '').lower()
        if vol.ndim != 3:
            return []
        if 'sag' in p:
            return [(i,vol[:,:,i]) for i in range(vol.shape[2])]
        if 'cor' in p:
            return [(i,vol[:,i,:]) for i in range(vol.shape[1])]
        return [(i,vol[i,:,:]) for i in range(vol.shape[0])]

    def render_volume(self, workspace: Path, sonication_index: int, mr: np.ndarray, plane: str,
                      ct_asset, ct_volume: np.ndarray, mr_asset=None) -> RegistrationOverlayResult:
        matrix_path=self.find_treatment_matrix(Path(workspace),sonication_index)
        matrix=self.read_matrix(matrix_path)
        if matrix is None:
            return RegistrationOverlayResult(None,None,matrix_path,getattr(ct_asset,'path',None),"Treatment CtMr registration matrix unavailable")
        mr_px=(float(getattr(mr_asset,'pixel_size_x',1.0) or 1.0),float(getattr(mr_asset,'pixel_size_y',1.0) or 1.0))
        candidates=self._volume_plane_slices(ct_volume,plane)
        if not candidates:
            return RegistrationOverlayResult(None,matrix,matrix_path,getattr(ct_asset,'path',None),"Preplanning CT volume unavailable")
        # Search the entire corresponding CT plane. The exported CtMr transform
        # controls in-plane mapping; the best slice is selected by MR/CT edge
        # agreement instead of assuming equal slice indices between acquisitions.
        best=None
        step=max(1,len(candidates)//96)
        for idx,ct2d in candidates[::step]:
            overlay=self.project_2d(ct2d,np.asarray(mr).shape[:2],matrix,plane,0.5,mr_px)
            score=self._alignment_score(mr,overlay)
            if best is None or score>best[0]:
                best=(score,idx,overlay)
        if best is None or not np.isfinite(best[0]):
            return RegistrationOverlayResult(None,matrix,matrix_path,getattr(ct_asset,'path',None),"CtMr matrix decoded, but no usable skull alignment was found")
        # refine around coarse best index
        coarse_idx=best[1]
        lo=max(0,coarse_idx-step); hi=min(len(candidates)-1,coarse_idx+step)
        for idx in range(lo,hi+1):
            ct2d=candidates[idx][1]
            overlay=self.project_2d(ct2d,np.asarray(mr).shape[:2],matrix,plane,0.5,mr_px)
            score=self._alignment_score(mr,overlay)
            if score>best[0]: best=(score,idx,overlay)
        score,idx,overlay=best
        status=(f"Registration ON · treatment CtMr matrix: {matrix_path.name} · {plane} CT slice {idx+1}/{len(candidates)} · "
                f"MR/CT edge agreement={score:.3f} · 2-D review of treatment-adopted registration")
        return RegistrationOverlayResult(overlay,matrix,matrix_path,getattr(ct_asset,'path',None),status,idx,float(score))

    def render(self, workspace: Path, sonication_index: int, mr: np.ndarray, plane: str,
               ct_asset, ct_array: np.ndarray, mr_asset=None) -> RegistrationOverlayResult:
        matrix_path=self.find_treatment_matrix(Path(workspace), sonication_index)
        matrix=self.read_matrix(matrix_path)
        if matrix is None:
            return RegistrationOverlayResult(None,None,matrix_path,getattr(ct_asset,'path',None),"Treatment CtMr registration matrix unavailable")
        mr_px=(float(getattr(mr_asset,'pixel_size_x',1.0) or 1.0), float(getattr(mr_asset,'pixel_size_y',1.0) or 1.0))
        overlay=self.project_2d(ct_array, np.asarray(mr).shape[:2], matrix, plane, 0.5, mr_px)
        finite=np.isfinite(overlay)
        status=(f"Registration ON · treatment CtMr matrix: {matrix_path.name} · "
                f"{plane} 2-D projection · bone edge pixels={int(np.count_nonzero(finite))}")
        return RegistrationOverlayResult(overlay,matrix,matrix_path,getattr(ct_asset,'path',None),status)
