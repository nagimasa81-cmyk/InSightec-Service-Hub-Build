from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEXT = (ROOT / 'src/ui/main_window.py').read_text(encoding='utf-8')


def test_three_image_rows_present():
    for token in ('planning_frame_list', 'anatomy_frame_list', 'thermal_frame_list'):
        assert token in TEXT


def test_relative_spectrum_not_added_to_replay_layout():
    assert 'self.lower_split.addWidget(self.waterfall_panel)' not in TEXT
    assert 'self.waterfall_panel.setVisible(False)' in TEXT


def test_initial_frame_is_forced_after_sonication_selection():
    assert 'QTimer.singleShot(0, lambda: self.set_frame(0, display_mode="thermal"))' in TEXT


def test_previous_sonication_state_is_cleared():
    assert 'def _clear_replay_display' in TEXT
    assert TEXT.count('self._clear_replay_display()') >= 2
