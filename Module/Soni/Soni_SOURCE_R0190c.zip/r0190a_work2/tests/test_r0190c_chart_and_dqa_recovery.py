from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CH=(ROOT/'src/ui/chart_interaction.py').read_text()
MAIN=(ROOT/'src/ui/main_window.py').read_text()
HYD=(ROOT/'src/ui/hydrophone_window.py').read_text()
DQA=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text()

def test_doubleclick_handler_can_be_upgraded_not_stuck_on_ancestor_reset():
    assert 'filt.double_click_callback = double_click_callback' in CH

def test_replay_keeps_domain_synchronized_popup_owner():
    assert 'if bool(getattr(plot, "_soni_x_axis_range_zoom_installed", False)):' in MAIN
    assert 'double_click_callback=lambda k=key: self._open_chart_popup(k)' in MAIN

def test_analyzer_doubleclick_enlarges_all_plotwidgets():
    assert 'open_enlarged_plot' in HYD
    assert 'double_click_callback=lambda p=_plot_widget: open_enlarged_plot' in HYD

def test_generic_analysis_charts_have_enlarge_fallback():
    assert 'open_enlarged_plot' in MAIN

def test_dqa_does_not_require_magnitude_pair_to_recover_observed_thermal_focus():
    assert 'validated same-raster thermal hotspot' in DQA
    assert "_planned_focus_native_measurement(son,rows,planned)" in DQA
    assert "'paired_reference':None" in DQA
