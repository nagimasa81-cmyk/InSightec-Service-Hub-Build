from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import math
import re

import numpy as np

from src.parsers.ado_rowset import parse_ado_rowset
from src.services.raw_service import RawService
from src.services.transducer_location_service import TransducerLocationService


@dataclass(slots=True)
class DqaFocusAlignment:
    x_mm: float | None = None
    y_mm: float | None = None
    z_mm: float | None = None
    tilt_deg: float | None = None
    confidence: str = "Unavailable"
    evidence: list[str] = field(default_factory=list)
    excluded_reason: str | None = None
    judgement_excluded_reason: str | None = None
    reference_xyz: tuple[float,float,float] | None = None
    registered_focal_ras: tuple[float,float,float] | None = None
    baseline_to_focal_mm: float | None = None
    calculator_contract: str = "R0190"
    diagnostic_overlays: dict[str, dict[str, object]] = field(default_factory=dict)

    @property
    def alert(self) -> bool:
        if self.excluded_reason or self.judgement_excluded_reason:
            return False
        return bool(
            (self.x_mm is not None and abs(float(self.x_mm)) >= 15.0)
            or (self.y_mm is not None and abs(float(self.y_mm)) >= 15.0)
            or (self.z_mm is not None and abs(float(self.z_mm)) >= 20.0)
        )

    @property
    def display(self) -> str:
        if self.excluded_reason:
            return f"N/A — {self.excluded_reason}"
        def f(name: str, value: float | None, unit: str = "mm") -> str:
            return f"{name} {value:+.1f} {unit}" if value is not None and np.isfinite(value) else f"{name} —"
        text="  ".join((f("X", self.x_mm), f("Y", self.y_mm), f("Z", self.z_mm), f("Tilt", self.tilt_deg, "°")))
        if self.judgement_excluded_reason:
            text += "  · Not judged"
        return text


class DqaFocusAlignmentService:
    """Recover DQA mechanical focus alignment and optional thermal focus evidence.

    The DQA *series* alignment follows the workstation/phantom geometry contract:
      * the XD is mechanically fixed for the DQA series;
      * X/Y are the fixed natural-focus position relative to the phantom centre
        measured from the DQA-Axial stack;
      * Z is the same fixed natural focus relative to the lower phantom baseline
        measured from the DQA-Sagittal stack;
      * Tilt is the sagittal phantom-baseline angle, image horizontal = 0 degrees.

    Individual thermal-focus evidence remains a separate contract: observed heated
    focus minus the planned focus of the same Sonication.  It must never be used to
    manufacture missing series geometry, and T2*/NFUSCAL anatomical data must never
    be relabelled as thermometry.
    """

    def __init__(self) -> None:
        self.raw = RawService()
        self._cache: dict[str, DqaFocusAlignment] = {}
        self._reference_cache: dict[str, dict[str, object]] = {}

    @staticmethod
    def is_dqa(package) -> bool:
        """Return True only from treatment-specific DQA evidence.

        Installed exports may contain generic Brain220/Brain650 DQA templates even
        during ordinary treatment, so template presence alone is not sufficient.
        Prefer the actual per-sonication protocol recorded by SonicationSummary or
        ProtocolData. This also works when the ZIP/folder name itself has no DQA
        token, as observed in real Brain220 DQA exports.
        """
        workspace = Path(getattr(package, "workspace", "") or ".")
        candidates = []
        for name in ("SonicationSummary.xml", "ProtocolData.xml"):
            try:
                candidates.extend(sorted(workspace.rglob(name), key=lambda p: (len(p.parts), str(p).lower()))[:2])
            except Exception:
                pass
        for path in candidates:
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            low = text.lower()
            if path.name.lower() == "sonicationsummary.xml":
                # Actual treatment protocol, not merely a protocol template.
                if re.search(r"treatprotocol\s*=\s*['\"][^'\"]*dqa", text, re.I):
                    return True
            else:
                if re.search(r"(?:name|predefinedspotspath)\s*=\s*['\"][^'\"]*dqa", text, re.I):
                    return True
        # Legacy fallback: an explicitly DQA-named source is useful only when
        # treatment protocol tables are absent. It must not override a normal
        # SonicationSummary such as treatprotocol='Brain-Treat'.
        has_summary = any(p.name.lower() == "sonicationsummary.xml" for p in candidates)
        if not has_summary:
            return "dqa" in str(getattr(package, "source", "")).lower()
        return False

    @staticmethod
    def _find_mri_params(workspace: Path) -> Path | None:
        for name in ("MriImageParams.xml", "MRIImageParams.xml"):
            items = sorted(Path(workspace).rglob(name), key=lambda p: (len(p.parts), str(p).lower()))
            if items:
                return items[0]
        return None

    @staticmethod
    def _row_by_number(path: Path | None) -> dict[int, dict[str, object]]:
        if path is None:
            return {}
        try:
            rows = parse_ado_rowset(path)
        except Exception:
            return {}
        out: dict[int, list[dict[str, object]]] = {}
        for row in rows:
            try:
                n = int(float(row.get("sonicationindex", "")))
            except (TypeError, ValueError):
                continue
            out.setdefault(n, []).append(row)
        best: dict[int, dict[str, object]] = {}
        for n, candidates in out.items():
            def quality(row):
                series = str(row.get("seriesdiscription") or row.get("seriesdescription") or "").upper()
                treatment = int(any(t in series for t in ("MEMP", "TMAP", "THERM")))
                try:
                    sx = float(row.get("pixsizex") or 0); sy = float(row.get("pixsizey") or 0)
                    pixels = int(sx > 0 and sy > 0)
                except Exception:
                    pixels = 0
                try:
                    rv = np.asarray([float(row.get(k, 0)) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")])
                    cv = np.asarray([float(row.get(k, 0)) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")])
                    cos = int(np.linalg.norm(rv) > .5 and np.linalg.norm(cv) > .5)
                except Exception:
                    cos = 0
                return treatment, pixels, cos
            best[n] = max(candidates, key=quality)
        return best

    @staticmethod
    def _orientation(row: dict[str, object]) -> str | None:
        try:
            rv = np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")], float)
            cv = np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")], float)
            normal = np.cross(rv, cv)
            axis = int(np.argmax(np.abs(normal)))
            return ("Sagittal", "Coronal", "Axial")[axis]
        except Exception:
            return None

    @staticmethod
    def _pixel_sizes(row: dict[str, object]) -> tuple[float, float] | None:
        try:
            sx = float(row.get("pixsizex")); sy = float(row.get("pixsizey"))
            if sx <= 0 or sy <= 0 or not np.isfinite([sx, sy]).all():
                return None
            return sx, sy
        except Exception:
            return None

    @staticmethod
    def _ras_delta(row: dict[str, object], dx: float, dy: float) -> np.ndarray | None:
        sizes = DqaFocusAlignmentService._pixel_sizes(row)
        if sizes is None:
            return None
        try:
            rv = np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")], float)
            cv = np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")], float)
        except Exception:
            return None
        # The displayed RAW raster uses exported COLUMN direction on screen X
        # and exported ROW direction on screen Y (same convention as metadata UI).
        sx, sy = sizes
        return cv * (float(dx) * sx) + rv * (float(dy) * sy)

    def _hotspot(self, son) -> tuple[float, float, int] | None:
        frames = list(getattr(son, "temperature_frames", []) or [])
        if not frames:
            return None
        try:
            baseline = self.raw.read_temperature(frames[0].path)
        except Exception:
            return None
        finite = baseline[np.isfinite(baseline)]
        absolute = bool(finite.size and 15.0 <= float(np.nanmedian(finite)) <= 80.0)
        best = None
        h, w = baseline.shape
        y0, y1 = int(.10*h), int(.90*h); x0, x1 = int(.10*w), int(.90*w)
        for i, frame in enumerate(frames):
            try:
                arr = self.raw.read_temperature(frame.path)
            except Exception:
                continue
            delta = arr - baseline if absolute else arr
            roi = np.asarray(delta[y0:y1, x0:x1], float)
            if not np.isfinite(roi).any():
                continue
            flat = int(np.nanargmax(roi)); yy, xx = np.unravel_index(flat, roi.shape)
            yy += y0; xx += x0
            peak = float(delta[yy, xx])
            if best is None or peak > best[0]:
                # Local weighted centroid reduces single-pixel noise without
                # changing the measured focus to a global threshold centroid.
                r = 6
                ya, yb = max(0, yy-r), min(h, yy+r+1); xa, xb = max(0, xx-r), min(w, xx+r+1)
                patch = np.asarray(delta[ya:yb, xa:xb], float)
                floor = float(np.nanpercentile(patch[np.isfinite(patch)], 50)) if np.isfinite(patch).any() else 0.0
                weights = np.maximum(patch - floor, 0.0)
                if np.isfinite(weights).all() and float(weights.sum()) > 0:
                    gy, gx = np.indices(weights.shape)
                    cx = xa + float((weights * gx).sum() / weights.sum())
                    cy = ya + float((weights * gy).sum() / weights.sum())
                else:
                    cx, cy = float(xx), float(yy)
                best = (peak, cx, cy, i)
        return (best[1], best[2], best[3]) if best is not None else None

    def _magnitude_for(self, son, temp_index: int) -> np.ndarray | None:
        """Deprecated: index-based thermal/magnitude pairing is forbidden in R0190."""
        return None

    @staticmethod
    def _norm(image: np.ndarray) -> np.ndarray:
        arr = np.asarray(image, float)
        finite = arr[np.isfinite(arr)]
        if not finite.size:
            return np.zeros_like(arr)
        lo, hi = np.nanpercentile(finite, [2, 98])
        if hi <= lo:
            return np.zeros_like(arr)
        return np.clip((arr-lo)/(hi-lo), 0.0, 1.0)

    @classmethod
    def _baseline_line(cls, image: np.ndarray) -> tuple[float, float, float] | None:
        """Return y = slope*x + intercept and a 0..1 support score."""
        a = cls._norm(image); h, w = a.shape
        # Strong horizontal structural boundary in the lower half of the DQA phantom.
        gy = np.abs(a[2:, :] - a[:-2, :])
        xa, xb = int(.18*w), int(.82*w); ya, yb = int(.48*h), int(.88*h)
        if xb-xa < 20 or yb-ya < 20:
            return None
        score = np.nanmean(gy[ya:yb, xa:xb], axis=1)
        if not np.isfinite(score).any():
            return None
        yc = ya + int(np.nanargmax(score)) + 1
        xs=[]; ys=[]; strengths=[]
        for x in range(xa, xb):
            ylo=max(1,yc-6); yhi=min(h-2,yc+7)
            col=gy[ylo-1:yhi-1,x]
            if not col.size or not np.isfinite(col).any():
                continue
            j=int(np.nanargmax(col)); y=ylo+j
            xs.append(float(x)); ys.append(float(y)); strengths.append(float(col[j]))
        if len(xs) < 24:
            return None
        x=np.asarray(xs); y=np.asarray(ys); st=np.asarray(strengths)
        keep=st >= np.nanpercentile(st,40)
        x=x[keep]; y=y[keep]
        if x.size < 20:
            return None
        for _ in range(3):
            slope, intercept=np.polyfit(x,y,1)
            resid=y-(slope*x+intercept); mad=float(np.nanmedian(np.abs(resid-np.nanmedian(resid))))
            tol=max(1.5,3.5*mad)
            keep=np.abs(resid)<=tol
            if keep.sum()<20: break
            x=x[keep]; y=y[keep]
        slope,intercept=np.polyfit(x,y,1)
        support=min(1.0,float(x.size)/max(1,(xb-xa)*.55))
        if abs(float(slope)) > .35:
            return None
        return float(slope),float(intercept),support

    @classmethod
    def _circle_center(cls, image: np.ndarray, baseline_y: float | None = None) -> tuple[float, float, float] | None:
        a=cls._norm(image); h,w=a.shape
        gx=np.zeros_like(a); gy=np.zeros_like(a)
        gx[:,1:-1]=a[:,2:]-a[:,:-2]; gy[1:-1,:]=a[2:,:]-a[:-2,:]
        g=np.hypot(gx,gy)
        cx0=w/2.0; cy0=min(h*.50,(baseline_y-h*.18) if baseline_y is not None else h*.50)
        yy,xx=np.indices(a.shape)
        radius=np.hypot(xx-cx0,yy-cy0)
        mask=(xx>.14*w)&(xx<.86*w)&(yy>.14*h)&(yy<(.76*h if baseline_y is None else baseline_y-3))
        mask &= (radius>.11*w)&(radius<.34*w)
        vals=g[mask]
        vals=vals[np.isfinite(vals) & (vals > 1e-6)]
        if vals.size < 80:
            return None
        # Percentiles over the whole mostly-zero search ROI would yield a zero
        # threshold and make every interior pixel a false circle edge. Rank only
        # real gradient pixels, then fit the strongest structural boundary points.
        thr=float(np.nanpercentile(vals,55))
        ys,xs=np.nonzero(mask & (g>=thr) & (g>1e-6))
        if xs.size < 60:
            return None
        x=xs.astype(float); y=ys.astype(float)
        # Robust algebraic circle fit with radial-residual trimming.
        for _ in range(4):
            A=np.column_stack((x,y,np.ones_like(x))); b=-(x*x+y*y)
            try:
                aa,bb,cc=np.linalg.lstsq(A,b,rcond=None)[0]
            except np.linalg.LinAlgError:
                return None
            cx=-aa/2.0; cy=-bb/2.0; r2=cx*cx+cy*cy-cc
            if r2<=0: return None
            r=math.sqrt(r2); resid=np.abs(np.hypot(x-cx,y-cy)-r)
            med=float(np.nanmedian(resid)); mad=float(np.nanmedian(np.abs(resid-med)))
            keep=resid<=max(2.0,med+2.5*mad)
            if keep.sum()<40: break
            x=x[keep]; y=y[keep]
        if not (.20*w < cx < .80*w and .15*h < cy < .70*h and .10*w < r < .36*w):
            return None
        support=min(1.0,float(x.size)/180.0)
        return float(cx),float(cy),support

    def _measure_one(self, son, row: dict[str, object]) -> dict[str, float | str | None]:
        """Deprecated phantom-relative helper; numeric output intentionally disabled.

        Old releases used hotspot-minus-phantom and baseline-line geometry here.
        Keeping a numeric implementation around made accidental regression too easy.
        """
        return {"orientation": self._orientation(row), "error": "legacy phantom-relative DQA measurement disabled"}

    @staticmethod
    def _frame_identity(path: Path) -> tuple[int, int, int, int] | None:
        m=re.match(r"^(\d+)-(\d+)-(\d+)-(\d+)\.raw$", Path(path).name, re.I)
        return tuple(int(v) for v in m.groups()) if m else None

    @classmethod
    def _row_for_raw_frame(cls, rows: list[dict[str, object]], path: Path) -> dict[str, object] | None:
        """Resolve the MriImageParams row that owns one exported RAW frame.

        A Sonication can contain several fields/slices.  Selecting one arbitrary
        row per Sonication made the thermal hotspot and phantom geometry live in
        different image frames and produced large but plausible DQA offsets.
        """
        ident=cls._frame_identity(path)
        if ident is None:
            return None
        field,son,zone,array_index=ident
        exact=[]
        for row in rows:
            try:
                rf=int(float(row.get("fieldindex")))
                rs=int(float(row.get("sonicationindex")))
                rz=int(float(row.get("zoneindex",0) or 0))
                # RAW final token is the exported zero-based array index.
                # MriImageParams commonly exposes both zero-based `arrayindex` and
                # one-based `imgnum`.  Treating both as interchangeable candidates
                # (and accepting +/-1) makes adjacent frames all look like matches
                # and causes exact Thermal->Magnitude pairing to fail closed.
                row_array=None
                try:
                    row_array=int(float(row.get("arrayindex")))
                except Exception:
                    try:
                        row_array=int(float(row.get("imgnum")))-1
                    except Exception:
                        row_array=None
                if rf==field and rs==son and rz==zone and row_array==array_index:
                    exact.append(row)
            except Exception:
                continue
        if not exact:
            return None
        # Prefer treatment thermometry/magnitude rows with complete physical geometry.
        def quality(row):
            series=str(row.get("seriesdiscription") or row.get("seriesdescription") or "").upper()
            treatment=int(any(t in series for t in ("MEMP","TMAP","THERM")))
            return treatment, int(cls._pixel_sizes(row) is not None)
        return max(exact,key=quality)

    @staticmethod
    def _row_acquisition_identity(row: dict[str, object]) -> tuple[int,int,int] | None:
        """Canonical acquisition identity excluding field number.

        The exported RAW suffix is zero-based.  `arrayindex` follows that convention
        while `imgnum` is normally one-based.  Canonicalising here is essential:
        accepting a +/-1 neighbourhood makes every interior acquisition ambiguous.
        """
        try:
            son=int(float(row.get("sonicationindex")))
            zone=int(float(row.get("zoneindex",0) or 0))
        except Exception:
            return None
        try:
            array_index=int(float(row.get("arrayindex")))
        except Exception:
            try:
                array_index=int(float(row.get("imgnum")))-1
            except Exception:
                return None
        return son,zone,array_index

    @classmethod
    def _geometry_compatible(cls, a: dict[str,object], b: dict[str,object], *, tolerance_mm: float=.75) -> bool:
        if cls._orientation(a) != cls._orientation(b) or cls._pixel_sizes(a) is None or cls._pixel_sizes(b) is None:
            return False
        try:
            if max(abs(x-y) for x,y in zip(cls._pixel_sizes(a),cls._pixel_sizes(b))) > 1e-3:
                return False
            for prefix in ("rowdirectcosras","coldirectcosras"):
                va=np.asarray([float(a[prefix+k]) for k in "xyz"],float)
                vb=np.asarray([float(b[prefix+k]) for k in "xyz"],float)
                if float(np.linalg.norm(va-vb)) > 1e-3:
                    return False
            oa=np.asarray([float(a[k]) for k in ("topleftcoordr","topleftcoorda","topleftcoords")],float)
            ob=np.asarray([float(b[k]) for k in ("topleftcoordr","topleftcoorda","topleftcoords")],float)
            normal=np.cross(
                np.asarray([float(a["rowdirectcosras"+k]) for k in "xyz"]),
                np.asarray([float(a["coldirectcosras"+k]) for k in "xyz"]),
            )
            normal=normal/max(float(np.linalg.norm(normal)),1e-12)
            return abs(float(np.dot(ob-oa,normal))) <= tolerance_mm and float(np.linalg.norm((ob-oa)-normal*np.dot(ob-oa,normal))) <= tolerance_mm
        except Exception:
            return False

    @classmethod
    def _exact_magnitude_pair(cls, rows, thermal_path: Path, magnitude_frames) -> tuple[object,dict[str,object]] | None:
        """Bind thermal RAW to one exact acquisition/geometry magnitude frame.

        No list-index or ratio mapping is permitted. Ambiguity fails closed.
        """
        trow=cls._row_for_raw_frame(rows,thermal_path)
        tid=cls._row_acquisition_identity(trow or {})
        if trow is None or tid is None:
            return None
        matches=[]
        for mf in list(magnitude_frames or []):
            mrow=cls._row_for_raw_frame(rows,mf.path)
            mid=cls._row_acquisition_identity(mrow or {})
            if mrow is None or mid is None:
                continue
            # Identities are already canonicalised to zero-based acquisition index.
            # Require exact S/Z/acquisition equality; never widen to adjacent frames.
            if tid != mid:
                continue
            if not cls._geometry_compatible(trow,mrow):
                continue
            matches.append((mf,mrow))
        if len(matches) != 1:
            return None
        return matches[0]

    @classmethod
    def _phantom_mask_from_magnitude(cls, orientation: str, mag: np.ndarray) -> tuple[np.ndarray,dict[str,object]] | None:
        """Return a phantom/body-derived search mask; never planned-focus centred."""
        a=np.asarray(mag,float)
        if a.ndim != 2 or min(a.shape) < 32:
            return None
        h,w=a.shape
        if orientation == "Axial":
            cc=cls._circle_center(a,None)
            if cc is None or cc[2] < .55:
                return None
            cx,cy,support=cc
            # Circle detector does not return radius. Derive a conservative body
            # radius from the structural extent around the detected centre.
            norm=cls._norm(a); yy,xx=np.indices(a.shape)
            dist=np.hypot(xx-cx,yy-cy)
            structural=(norm > float(np.nanpercentile(norm,55)))
            ds=dist[structural & (dist < .40*w)]
            if ds.size < 100:
                return None
            radius=float(np.nanpercentile(ds,82))
            radius=max(.12*w,min(.34*w,radius))
            mask=dist <= radius*.88
            return mask,{"kind":"axial-circle","circle_pixel":(float(cx),float(cy)),"radius_px":radius,"support":float(support)}
        if orientation == "Sagittal":
            ln=cls._baseline_line(a)
            if ln is None or ln[2] < .55:
                return None
            slope,intercept,support=ln; yy,xx=np.indices(a.shape)
            norm=cls._norm(a)
            body=norm > float(np.nanpercentile(norm,35))
            # Interior is above the detected lower baseline with a small inset,
            # excluding wrap/border regions and air below the phantom.
            mask=body & (yy < (slope*xx+intercept-3.0)) & (xx >= .08*w) & (xx <= .92*w) & (yy >= .08*h)
            if int(mask.sum()) < 200:
                return None
            return mask,{"kind":"sagittal-body-baseline","slope":float(slope),"intercept":float(intercept),"support":float(support)}
        return None

    def _native_measurement_for_sonication(self, son, rows: list[dict[str, object]]) -> dict[str, float | str | None]:
        """Legacy API retained only as a fail-closed compatibility shim.

        Historical releases measured hotspot-to-phantom-centre here. That
        quantity is not DQA focus displacement and must never re-enter the
        production path. Callers receive an explicit non-numeric result.
        """
        return {"orientation": None, "error": "legacy phantom-relative DQA measurement disabled"}

    def _thermal_focus_ras_alignment(self, package, reference: dict[str, object], focal_by_number: dict[int, tuple[float,float,float]], current_number: int | None = None) -> DqaFocusAlignment | None:
        """Deprecated phantom-relative 3-D alignment path; permanently disabled.

        Kept only so old plugins/tests fail safely instead of silently restoring
        the pre-R0154aa hotspot-minus-phantom algorithm.
        """
        return None

    @staticmethod
    def _thermometry_evidence(row: dict[str, object] | None, image: np.ndarray) -> dict[str, object]:
        """Classify whether one Field-5-like raster is valid temperature evidence.

        Field number and payload width are not sufficient.  Brain220 exports can
        store `T2_Star_ME_1SL` float32 rasters under field 5; their values are MR
        signal/T2* quantities in the thousands, not degrees C.  DQA must bind the
        RAW to MriImageParams and validate both protocol semantics and value range.
        """
        row = dict(row or {})
        series = str(row.get("seriesdiscription") or row.get("seriesdescription") or "").strip()
        upper = series.upper().replace("*", "_STAR_")
        arr = np.asarray(image, float)
        finite = arr[np.isfinite(arr)]
        evidence = []
        if series:
            evidence.append(f"MriImageParams series={series}")
        else:
            evidence.append("MriImageParams series unavailable")
        known_nonthermal = any(token in upper for token in (
            "T2_STAR", "T2STAR", "NFUSCAL", "DQA-AXIAL", "DQA-SAGITTAL", "DQA-CORONAL"
        ))
        protocol_thermal = any(token in upper for token in ("TMAP", "MEMP", "THERM", "TEMPERATURE"))
        if known_nonthermal:
            return {"valid": False, "mode": None, "reason": f"non-thermometry MR protocol {series or 'unknown'}", "evidence": evidence}
        if not finite.size:
            return {"valid": False, "mode": None, "reason": "temperature raster has no finite samples", "evidence": evidence}
        median = float(np.nanmedian(finite))
        p01, p99 = (float(v) for v in np.nanpercentile(finite, [1, 99]))
        evidence.append(f"value distribution median={median:.3f}, p01={p01:.3f}, p99={p99:.3f}")
        absolute = bool(15.0 <= median <= 80.0 and -10.0 <= p01 and p99 <= 120.0)
        delta_like = bool(-20.0 <= median <= 20.0 and -60.0 <= p01 and p99 <= 100.0)
        if not (absolute or delta_like):
            return {"valid": False, "mode": None, "reason": "temperature values outside validated absolute/delta range", "evidence": evidence}
        # A named MR series must positively identify thermometry.  Value range alone
        # is not sufficient because processed magnitude/phase products can overlap
        # temperature-like ranges.  Only truly blank legacy descriptions retain the
        # value-distribution fallback.
        if series and not protocol_thermal:
            return {"valid": False, "mode": None, "reason": f"named MR series is not a validated thermometry protocol: {series}", "evidence": evidence}
        mode = "absolute" if absolute else "delta"
        evidence.append(("thermal protocol marker present; " if protocol_thermal else "legacy blank protocol; ") + f"validated {mode} temperature distribution")
        return {"valid": True, "mode": mode, "reason": "validated thermometry", "evidence": evidence}

    def _planned_focus_native_measurement(self, son, rows: list[dict[str, object]], planned_ras: tuple[float,float,float]) -> dict[str, object]:
        """Measure observed thermal focus minus the planned focus in one MR raster.

        This is the only production numeric DQA displacement contract.  The planned
        Sonication focus is projected into the exact thermometry frame that owns the
        observed hotspot.  The displacement is then calculated in that frame's
        in-plane physical basis.  The through-plane component is left unavailable;
        it is never manufactured from phantom centre, image centre, another
        Sonication, steering amount or target-voxel coordinates.
        """
        temps=list(getattr(son,"temperature_frames",[]) or [])
        if not temps:
            return {"error":"thermometry unavailable"}
        # A float32-sized raster is not automatically thermometry. Brain220 DQA
        # exports contain T2*/phase-like field-5 RAW whose values are in the
        # thousands. Treating those as temperature produced false focus locations.
        try:
            baseline=np.asarray(self.raw.read_temperature(temps[0].path),float)
        except Exception:
            return {"error":"temperature baseline unavailable"}
        baseline_row=self._row_for_raw_frame(rows,temps[0].path)
        if baseline_row is None:
            return {"error":"temperature baseline has no exact MriImageParams binding"}
        thermo=self._thermometry_evidence(baseline_row,baseline)
        if not bool(thermo.get("valid")):
            return {"error":f"temperature RAW is not validated thermometry: {thermo.get('reason')}", "thermometry_evidence":list(thermo.get("evidence",[]) or [])}
        absolute=(thermo.get("mode") == "absolute")
        best=None
        for ti,tf in enumerate(temps):
            row=self._row_for_raw_frame(rows,tf.path)
            if row is None:
                continue
            ok,diag=self._point_in_exported_image_frame(
                row, planned_ras, in_plane_margin_fraction=.08, normal_tolerance_mm=10.0
            )
            if not ok or not diag:
                continue
            try:
                arr=np.asarray(self.raw.read_temperature(tf.path),float)
            except Exception:
                continue
            if arr.shape != baseline.shape:
                continue
            delta=arr-baseline if absolute else arr
            h,w=delta.shape
            px=float(diag["x_px"]); py=float(diag["y_px"])
            # A DQA focus cannot be accepted from an unrelated hot structure.  Use
            # a local physical search around the planned focus only.
            radius=14
            xa=max(1,int(round(px))-radius); xb=min(w-1,int(round(px))+radius+1)
            ya=max(1,int(round(py))-radius); yb=min(h-1,int(round(py))+radius+1)
            roi=np.asarray(delta[ya:yb,xa:xb],float)
            if roi.shape[0] < 3 or roi.shape[1] < 3 or not np.isfinite(roi).any():
                continue
            filled=np.nan_to_num(roi,nan=0.0)
            pad=np.pad(filled,1,mode="edge")
            sm=sum(pad[dy:dy+roi.shape[0],dx:dx+roi.shape[1]] for dy in range(3) for dx in range(3))/9.0
            flat=int(np.nanargmax(sm)); yy,xx=np.unravel_index(flat,sm.shape)
            score=float(sm[yy,xx]); hx=float(xx+xa); hy=float(yy+ya)
            pixel_distance=float(np.hypot(hx-px,hy-py))
            if pixel_distance > 10.0:
                continue
            ras_delta=self._ras_delta(row,hx-px,hy-py)
            if ras_delta is None or not np.isfinite(ras_delta).all():
                continue
            if best is None or score > best[0]:
                best=(score,ras_delta,row,hx,hy,px,py,Path(tf.path).name,ti)
        if best is None:
            return {"error":"observed focus vs planned focus not measurable in one MR raster"}
        _score,drow,row,hx,hy,px,py,name,ti=best
        orientation=self._orientation(row)
        values=[float(v) for v in drow]
        # Never report a through-plane zero from an in-plane measurement.
        if orientation == "Axial":
            values[2]=None
        elif orientation == "Sagittal":
            values[0]=None
        elif orientation == "Coronal":
            values[1]=None
        return {
            "x_mm":values[0], "y_mm":values[1], "z_mm":values[2],
            "orientation":orientation, "frame":name,
            "hotspot_x":hx, "hotspot_y":hy, "planned_x":px, "planned_y":py,
            "evidence":f"{name}: observed thermal hotspot ({hx:.2f},{hy:.2f}) px - planned focus ({px:.2f},{py:.2f}) px in same {orientation or 'MR'} raster; " + "; ".join(str(v) for v in list(thermo.get("evidence",[]) or [])),
        }

    def _image_native_alignment(self, package, focal_by_number: dict[int, tuple[float,float,float]], current_number: int | None = None) -> DqaFocusAlignment | None:
        """Return Sonication-local observed-minus-planned DQA displacement only."""
        if current_number is None or int(current_number) not in focal_by_number:
            return None
        params=self._find_mri_params(Path(getattr(package,"workspace",".")))
        try:
            rows=parse_ado_rowset(params) if params is not None and Path(params).exists() else []
        except Exception:
            rows=[]
        if not rows:
            return None
        son=None
        for pos,item in enumerate(list(getattr(package,"sonications",[]) or []),start=1):
            n=int(getattr(item,"sonication_number",0) or pos)
            if n == int(current_number):
                son=item; break
        if son is None:
            return None
        planned=focal_by_number[int(current_number)]
        m=self._planned_focus_native_measurement(son,rows,planned)
        if m.get("error"):
            return None
        x=m.get("x_mm"); y=m.get("y_mm"); z=m.get("z_mm")
        vals=[v for v in (x,y,z) if v is not None and np.isfinite(float(v))]
        if not vals:
            return None
        exclusion=self._dqa_exclusion_reason(package,int(current_number),focal_by_number)
        evidence=[
            f"S{int(current_number)} planned focus RAS=({planned[0]:.3f},{planned[1]:.3f},{planned[2]:.3f}) mm",
            str(m.get("evidence") or ""),
            "DQA numeric contract: observed heated focus minus planned focus of the same Sonication; phantom/image centre and steering coordinates are forbidden as displacement zero-points",
        ]
        if exclusion:
            evidence.append(f"Centre-alignment judgement excluded: {exclusion}; measurement retained")
        return DqaFocusAlignment(
            x_mm=None if x is None else float(x), y_mm=None if y is None else float(y), z_mm=None if z is None else float(z),
            tilt_deg=None, confidence="High" if len(vals)>=2 else "Partial", evidence=evidence,
            judgement_excluded_reason=exclusion,
        )

    @staticmethod
    def _absolute_ras(row: dict[str, object], x: float, y: float) -> np.ndarray | None:
        """Convert an exported image pixel coordinate to absolute RAS millimetres."""
        sizes = DqaFocusAlignmentService._pixel_sizes(row)
        if sizes is None:
            return None
        try:
            origin = np.asarray([float(row[k]) for k in ("topleftcoordr","topleftcoorda","topleftcoords")], float)
            rv = np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")], float)
            cv = np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")], float)
        except Exception:
            return None
        if not np.isfinite(origin).all() or np.linalg.norm(rv) < .5 or np.linalg.norm(cv) < .5:
            return None
        sx, sy = sizes
        return origin + cv * (float(x) * sx) + rv * (float(y) * sy)

    @staticmethod
    def _point_in_exported_image_frame(
        row: dict[str, object],
        point_ras: tuple[float, float, float] | np.ndarray,
        *,
        width: int = 256,
        height: int = 256,
        in_plane_margin_fraction: float = 0.20,
        normal_tolerance_mm: float = 18.0,
    ) -> tuple[bool, dict[str, float]]:
        """Validate that a RAS point belongs to the same exported MR frame.

        ``SonicationSummary.focalRAS`` and ``MriImageParams.TopLeftCoordRAS`` are
        not guaranteed to use the same coordinate frame in every workstation
        generation.  R0154g incorrectly assumed that they always did and directly
        subtracted the two.  The result can look like a 100+ mm phantom/focus
        displacement even while the displayed DQA anatomy is visually centered.

        A legitimate point in the same frame must project near the image field of
        view *and* near the image plane.  This is a coordinate-frame sanity gate,
        not a clinical alignment threshold.
        """
        sizes = DqaFocusAlignmentService._pixel_sizes(row)
        if sizes is None:
            return False, {}
        try:
            origin = np.asarray([float(row[k]) for k in ("topleftcoordr","topleftcoorda","topleftcoords")], float)
            rv = np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")], float)
            cv = np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")], float)
            point = np.asarray(point_ras, float)
        except Exception:
            return False, {}
        if point.size != 3 or not np.isfinite(point).all() or not np.isfinite(origin).all():
            return False, {}
        rn=float(np.linalg.norm(rv)); cn=float(np.linalg.norm(cv))
        if rn < .5 or cn < .5:
            return False, {}
        rv=rv/rn; cv=cv/cn
        normal=np.cross(cv,rv)
        nn=float(np.linalg.norm(normal))
        if nn < .5:
            return False, {}
        normal=normal/nn
        sx,sy=sizes
        delta=point-origin
        x_px=float(np.dot(delta,cv)/sx)
        y_px=float(np.dot(delta,rv)/sy)
        normal_mm=float(np.dot(delta,normal))
        mx=float(width)*float(in_plane_margin_fraction)
        my=float(height)*float(in_plane_margin_fraction)
        inside=(-mx <= x_px <= (width-1)+mx and -my <= y_px <= (height-1)+my)
        coplanar=abs(normal_mm) <= float(normal_tolerance_mm)
        return bool(inside and coplanar), {
            "x_px": x_px, "y_px": y_px, "normal_mm": normal_mm,
            "width": float(width), "height": float(height),
        }

    @classmethod
    def _focal_reference_frame_compatibility(cls, reference: dict[str, object], focal_ras) -> tuple[bool, list[str]]:
        """Validate focalRAS against the *DQA image stacks*, not one arbitrary slice.

        Brain220 DQA exports store one MriImageParams row per slice.  Earlier code
        kept only the first row of each field and then required the focus to be
        coplanar with that single slice.  A perfectly valid focus near another
        slice therefore looked like a coordinate-frame mismatch.  The correct
        test is volume-like: the focus must project inside the FOV of at least one
        axial slice and at least one sagittal slice, with a small plane-distance
        tolerance.  This proves common RAS geometry without assuming one fixed
        slice owns the whole series.
        """
        rows=list(reference.get("validation_rows",[]) or [])
        if not rows:
            return False, ["DQA coordinate-frame validation unavailable: no reference image geometry"]
        groups={"Axial":[],"Sagittal":[]}; evidence=[]
        for label,row in rows:
            orientation=cls._orientation(row)
            ok,diag=cls._point_in_exported_image_frame(
                row,focal_ras,in_plane_margin_fraction=0.08,normal_tolerance_mm=6.0
            )
            if orientation in groups:
                groups[orientation].append(bool(ok))
            if diag:
                evidence.append(
                    f"{label} focal projection: x={diag['x_px']:.1f}px, y={diag['y_px']:.1f}px, plane={diag['normal_mm']:+.1f}mm -> {'compatible' if ok else 'mismatch'}"
                )
        required=[name for name in ("Axial","Sagittal") if groups[name]]
        compatible=bool(len(required)>=2 and all(any(groups[name]) for name in required))
        return compatible,evidence

    @staticmethod
    def _read_u16_image(path: Path) -> np.ndarray | None:
        try:
            data = np.fromfile(path, dtype="<u2")
        except Exception:
            return None
        if data.size != 256 * 256:
            return None
        return data.reshape((256, 256))

    def _dqa_reference_geometry(self, package) -> dict[str, object]:
        """Recover DQA phantom geometry with one metadata row per RAW slice.

        A DQA field is a stack, not one image.  Each MriImageParams row carries a
        different slice RAS origin.  Reusing the first row for every RAW frame was
        the root cause of the large false X/Y/Z offsets seen in R0154m.
        """
        token = str(Path(getattr(package, "workspace", ".")).resolve())
        if token in self._reference_cache:
            return dict(self._reference_cache[token])
        workspace = Path(getattr(package, "workspace", "."))
        params = self._find_mri_params(workspace)
        try:
            rows = parse_ado_rowset(params) if params is not None else []
        except Exception:
            rows = []
        axial_rows=[]; sagittal_rows=[]
        for row in rows:
            series = str(row.get("seriesdiscription") or row.get("seriesdescription") or "").strip().lower()
            try:
                field = int(float(row.get("fieldindex", -1)))
                son = int(float(row.get("sonicationindex", -1)))
                imgnum = int(float(row.get("imgnum", 1) or 1))
                zone = int(float(row.get("zoneindex", 0) or 0))
            except Exception:
                continue
            if field < 0 or son < 1 or imgnum < 1 or self._pixel_sizes(row) is None:
                continue
            entry=(son,field,zone,imgnum,row)
            is_axial=("dqa-axial" in series or ("dqa" in series and "axial" in series)
                      or ("dqa" in series and ("_tra" in series or "trans" in series)))
            is_sagittal=("dqa-sagittal" in series or ("dqa" in series and "sagittal" in series)
                         or ("dqa" in series and "_sag" in series))
            if is_axial:
                axial_rows.append(entry)
            if is_sagittal:
                sagittal_rows.append(entry)

        folder_cache={}
        def raw_for(entry):
            son,field,zone,imgnum,_row=entry
            folder=folder_cache.get(son)
            if folder is None:
                folder=workspace / f"Sonication{son}"
                if not folder.exists():
                    matches=[p for p in workspace.rglob(f"Sonication{son}") if p.is_dir()]
                    folder=matches[0] if matches else folder
                folder_cache[son]=folder
            expected=folder / f"{field}-{son}-{zone}-{imgnum-1}.raw"
            if expected.exists():
                return expected
            # Some generations do not preserve zone/index naming exactly.  The
            # metadata row still owns the frame; use imgnum-1 as the final token.
            matches=sorted(folder.glob(f"{field}-{son}-*-{imgnum-1}.raw"))
            return matches[0] if matches else None

        evidence=[]; axial_centres=[]; baseline_s=[]; tilts=[]; validation_rows=[]
        axial_candidates=[]; sagittal_candidates=[]
        for entry in axial_rows:
            son,field,_zone,imgnum,row=entry
            raw=raw_for(entry)
            if raw is None: continue
            img=self._read_u16_image(raw)
            if img is None: continue
            circle=self._circle_center(img,None)
            if circle is None: continue
            cx,cy,support=circle
            if support < .55: continue
            ras=self._absolute_ras(row,cx,cy)
            if ras is None: continue
            ras_arr=np.asarray(ras,float)
            axial_centres.append(ras_arr)
            axial_candidates.append({
                "row": row, "raw": str(raw), "label": f"DQA-Axial S{son} field {field} image {imgnum}",
                "circle_pixel": (float(cx),float(cy)), "circle_ras": tuple(float(v) for v in ras_arr),
                "support": float(support),
            })
            validation_rows.append((f"DQA-Axial S{son} field {field} image {imgnum}",row))

        for entry in sagittal_rows:
            son,field,_zone,imgnum,row=entry
            raw=raw_for(entry)
            if raw is None: continue
            img=self._read_u16_image(raw)
            if img is None: continue
            line=self._baseline_line(img)
            sizes=self._pixel_sizes(row)
            if line is None or sizes is None: continue
            slope,intercept,support=line
            if support < .55: continue
            sx,sy=sizes; x=img.shape[1]/2.0; y=slope*x+intercept
            ras=self._absolute_ras(row,x,y)
            if ras is None: continue
            tilt_deg=float(math.degrees(math.atan2(slope*sy,sx)))
            baseline_s.append(float(ras[2]))
            tilts.append(tilt_deg)
            sagittal_candidates.append({
                "row": row, "raw": str(raw), "label": f"DQA-Sagittal S{son} field {field} image {imgnum}",
                "baseline_pixel": (float(x),float(y)), "baseline_ras": tuple(float(v) for v in np.asarray(ras,float)),
                "slope": float(slope), "intercept": float(intercept), "support": float(support), "tilt_deg": tilt_deg,
            })
            validation_rows.append((f"DQA-Sagittal S{son} field {field} image {imgnum}",row))

        center=None
        if axial_centres:
            arr=np.vstack(axial_centres)
            # The axial stack changes S by design.  Only R/A describe the phantom
            # cylinder centre.  Keep S as the stack median solely for diagnostics.
            center=np.asarray([
                float(np.nanmedian(arr[:,0])),
                float(np.nanmedian(arr[:,1])),
                float(np.nanmedian(arr[:,2])),
            ])
            evidence.append(
                f"Phantom axial centre from {len(arr)} slice-owned frame(s): R={center[0]:.2f} mm, A={center[1]:.2f} mm; slice S range {float(np.nanmin(arr[:,2])):.2f}..{float(np.nanmax(arr[:,2])):.2f} mm"
            )
        if baseline_s:
            evidence.append(
                f"Phantom sagittal lower line from {len(baseline_s)} slice-owned frame(s): S={float(np.nanmedian(baseline_s)):.2f} mm, tilt={float(np.nanmedian(tilts)):+.2f}°"
            )
        result={
            "center_ras": tuple(float(v) for v in center) if center is not None else None,
            "baseline_s_mm": float(np.nanmedian(baseline_s)) if baseline_s else None,
            "tilt_deg": float(np.nanmedian(tilts)) if tilts else None,
            "evidence": evidence,
            "validation_rows": validation_rows,
            "axial_candidates": axial_candidates,
            "sagittal_candidates": sagittal_candidates,
        }
        self._reference_cache[token]=dict(result)
        return result

    @staticmethod
    def _treatment_spot_count(package, number: int) -> tuple[int | None, str]:
        """Return the number of *executed treatment spots* for one Sonication.

        Brain220 ``bbbnumsubsonicuvw`` / workstation ``BBB spot subsonications``
        describe the internal 3x3 BBB firing pattern inside one treatment spot.
        They are deliberately NOT target-voxel counts.  A treatment target is
        counted only from explicit Sonication->SpotCue ownership rows.
        """
        workspace = Path(getattr(package, "workspace", "") or ".")
        path = next((q for q in workspace.rglob("*") if q.is_file() and q.name.lower()=="spotsonicationdata.xml"), None)
        if path is None:
            return None, "SpotSonicationData unavailable"
        try:
            rows = parse_ado_rowset(path)
        except Exception:
            return None, "SpotSonicationData unreadable"
        cues=[]
        for row in rows:
            try:
                if int(float(row.get("sonicationindex"))) != int(number):
                    continue
            except Exception:
                continue
            cue=str(row.get("spotcue") or "").strip()
            if cue and cue not in cues:
                cues.append(cue)
        if not cues:
            return None, "No explicit Sonication/SpotCue ownership"
        return len(cues), f"SpotSonicationData: {len(cues)} executed SpotCue(s)"

    @staticmethod
    def _dqa_exclusion_reason(package, number: int, focal_by_number: dict[int, tuple[float,float,float]]) -> str | None:
        """Exclude any DQA shot that is not a default-centre, single-target shot.

        This is intentionally strict.  BBB internal sub-sonications are never
        interpreted as target voxels.  Numeric focus/phantom alignment is valid
        only when the export proves one executed treatment spot and workstation
        steering is the default centre for the study.
        """
        # Single-target gate from explicit treatment ownership, never BBB count.
        spot_count, _spot_evidence = DqaFocusAlignmentService._treatment_spot_count(package, int(number))
        if spot_count is not None and int(spot_count) != 1:
            return f"multi-target / {int(spot_count)} treatment spots"

        sons=list(getattr(package,"sonications",[]) or [])
        target=next((s for s in sons if int(getattr(s,"sonication_number",0) or 0)==int(number)),None)
        setup_steering_resolved=False
        try:
            from src.services.sonication_evidence_service import SonicationEvidenceService
            workspace = Path(getattr(package, "workspace", "") or ".")
            setups = SonicationEvidenceService().parse_setup_records(workspace)
            setup = next((r for r in setups if r.sonication_counter is not None and int(r.sonication_counter)+1==int(number)), None)
            usable=[r for r in setups if all(v is not None for v in r.steering_xyz)]
            if setup is not None and all(v is not None for v in setup.steering_xyz) and usable:
                # Default centre is the most axis-centred workstation setup in the
                # same study.  Require that reference itself to be close to the
                # acoustic axis; otherwise fail closed rather than choosing an
                # arbitrary peer median as "centre".
                nominal_rec=min(usable,key=lambda r: float(r.steering_xyz[0])**2+float(r.steering_xyz[1])**2)
                arr=np.asarray(setup.steering_xyz,float)
                nominal=np.asarray(nominal_rec.steering_xyz,float)
                if np.isfinite(arr).all() and np.isfinite(nominal).all():
                    nominal_lateral=float(np.hypot(nominal[0],nominal[1]))
                    if nominal_lateral > 0.5:
                        return "default centre steering not proven"
                    if float(np.linalg.norm(arr-nominal)) > 0.5:
                        return "electronic steering"
                    setup_steering_resolved=True
        except Exception:
            setup_steering_resolved=False

        # Fallback only when workstation setup evidence is unavailable.  Do not
        # use BBB sub-sonication count, repeated focalRAS, or Sonication order as
        # target-voxel proxies.
        if target is not None and not setup_steering_resolved:
            steering=getattr(target,"canonical_steering_xyz",None)
            if steering is not None:
                try:
                    arr=np.asarray([float(v) for v in steering],float)
                    if np.isfinite(arr).all():
                        # If canonical steering is already expressed as offset,
                        # non-zero lateral steering proves non-centre.  For absolute
                        # XYZ forms, defer rather than manufacturing a reference.
                        if abs(float(arr[0])) <= 20.0 and abs(float(arr[1])) <= 20.0 and float(np.hypot(arr[0],arr[1])) > 0.5:
                            return "electronic steering"
                except Exception:
                    pass

        # If explicit ownership exists and is single, the target gate is proved.
        # If it is unavailable, retain historical compatibility for 650 exports;
        # the centre-steering gate above still prevents false DQA numerics.
        return None

    @staticmethod
    def _summary_focal_ras(package) -> dict[int, tuple[float,float,float]]:
        workspace=Path(getattr(package,"workspace","."))
        paths=sorted(workspace.rglob("SonicationSummary.xml"),key=lambda p:(len(p.parts),str(p).lower()))
        if not paths: return {}
        try: rows=parse_ado_rowset(paths[0])
        except Exception: return {}
        out={}
        for row in rows:
            try:
                n=int(float(row.get("sonicationindex")))
                xyz=tuple(float(row.get(k)) for k in ("focalrasx","focalrasy","focalrasz"))
            except Exception: continue
            if all(np.isfinite(v) for v in xyz): out[n]=xyz
        return out

    def analyze(self, package, sonication_index: int | None = None) -> DqaFocusAlignment:
        base_key=str(Path(getattr(package,"workspace",".")).resolve())
        key=f"{base_key}::S{sonication_index if sonication_index is not None else 'package'}"
        if key in self._cache:
            return self._cache[key]
        if not self.is_dqa(package):
            result=DqaFocusAlignment(confidence="Not DQA",evidence=["DQA-only analysis not applicable"])
            self._cache[key]=result; return result

        # Production DQA does not build or consult a phantom-centre reference.
        # SonicationSummary focalRAS is PLANNED focus evidence only; an observed
        # thermometry focus from the same Sonication is required for numerics.
        focal_by_number=self._summary_focal_ras(package)
        number=None
        if sonication_index is not None:
            sons=list(getattr(package,"sonications",[]) or [])
            if 0 <= int(sonication_index) < len(sons):
                number=int(getattr(sons[int(sonication_index)],"sonication_number",int(sonication_index)+1) or int(sonication_index)+1)
            else:
                number=int(sonication_index)+1
        elif focal_by_number:
            number=sorted(focal_by_number)[0]

        # R0154aa production contract: measurement and judgement are separate.
        # Numeric DQA displacement has exactly one zero-point:
        # observed heated focus minus planned focus of the SAME Sonication.
        # Phantom centre, image centre, steering amount, target voxel coordinates
        # and peer Sonications are prohibited as displacement references.
        judgement_exclusion=(self._dqa_exclusion_reason(package,int(number),focal_by_number)
                             if number is not None else None)
        native=self._image_native_alignment(package,focal_by_number,number)
        if native is not None and native.excluded_reason is None:
            if not any("same-raster authority" in str(v) for v in native.evidence):
                native.evidence.append("DQA same-raster authority: observed focus minus planned focus of the same Sonication")
            components=[native.x_mm,native.y_mm,native.z_mm]
            finite=[abs(float(v)) for v in components if v is not None and np.isfinite(float(v))]
            if finite and max(finite) <= 25.0:
                if judgement_exclusion and not native.judgement_excluded_reason:
                    native.judgement_excluded_reason=judgement_exclusion
                    native.evidence.append(f"Centre-alignment judgement excluded: {judgement_exclusion}; measurement retained")
                self._cache[key]=native; return native

        reason="observed focus vs planned focus unavailable"
        evidence=[
            "DQA numeric displacement was not emitted because a same-Sonication observed thermal focus could not be measured against its planned focus in one registered MR raster.",
            "Fail-closed contract: planned focalRAS, phantom centre, image centre, steering coordinates and target voxel coordinates are never subtracted from one another to manufacture DQA displacement.",
        ]
        if number is not None and number in focal_by_number:
            fx,fy,fz=focal_by_number[number]
            evidence.append(f"S{number} planned focalRAS=({fx:.3f},{fy:.3f},{fz:.3f}) mm is retained as planned-target evidence only")
        if judgement_exclusion:
            evidence.append(f"Judgement eligibility: {judgement_exclusion}")
        result=DqaFocusAlignment(confidence="Unavailable",evidence=evidence,excluded_reason=reason)
        self._cache[key]=result; return result


    def _series_fixed_focus_ras(self, package, focal_by_number: dict[int, tuple[float,float,float]]) -> tuple[tuple[float,float,float] | None, list[str]]:
        """Return the mechanically fixed DQA natural-focus RAS.

        Brain220 DQA may electronically steer individual shots while the XD itself
        stays fixed.  ``SonicationSummary.focalRAS`` therefore varies across the
        series and must not be averaged directly.  The default-centre workstation
        setup (smallest lateral steering magnitude) identifies the natural-focus
        shot.  If no unequivocal centre setup exists we fail closed.
        """
        evidence=[]
        try:
            from src.services.sonication_evidence_service import SonicationEvidenceService
            setups=SonicationEvidenceService().parse_setup_records(Path(getattr(package,'workspace','.') or '.'))
        except Exception as exc:
            return None,[f'Workstation steering setup unavailable: {exc}']
        numbered=[]
        for rec in setups:
            try:
                if rec.sonication_counter is None:
                    continue
                n=int(rec.sonication_counter)+1
                numbered.append((n,rec))
            except Exception:
                continue
        # Brain 220 logs often omit the Sonication counter in every setup row.
        # The final N setup sessions are nevertheless the exact treatment block,
        # already proven by SpectrumMsg/PowerGraph/CPC ordering. Bind that tail
        # one-to-one to the exported Sonication folders instead of declaring the
        # fixed DQA focus unavailable.
        if not numbered:
            sons=list(getattr(package,'sonications',[]) or [])
            if sons and len(setups) >= len(sons):
                tail=list(setups)[-len(sons):]
                numbered=[(int(getattr(son,'sonication_number',i+1) or i+1),rec)
                          for i,(son,rec) in enumerate(zip(sons,tail))]
                evidence.append(f'Brain220 counterless setup tail bound to {len(numbered)} treatment Sonication(s)')
        candidates=[]
        for n,rec in numbered:
            try:
                sx,sy,sz=(float(v) for v in rec.steering_xyz)
                if n not in focal_by_number or not np.isfinite([sx,sy,sz]).all():
                    continue
                candidates.append((n,(sx,sy,sz),focal_by_number[n]))
            except Exception:
                continue
        if not candidates:
            return None,['No Sonication has both workstation steering and planned focalRAS evidence']
        steering=np.asarray([v[1] for v in candidates],float)
        nominal=np.nanmedian(steering,axis=0)
        candidates.sort(key=lambda v:(float(np.linalg.norm(np.asarray(v[1],float)-nominal)),v[0]))
        best=candidates[0]
        # A DQA natural-focus shot is expected on/very near the acoustic axis.
        # Do not silently choose a steered treatment target as the mechanical focus.
        lateral=float(math.hypot(best[1][0],best[1][1]))
        if lateral > 0.5:
            return None,[*evidence,f'Default-centre DQA steering not proven: smallest lateral steering={lateral:.2f} mm']
        n,steer,focus=best
        evidence.append(
            f'Fixed XD natural focus from default-centre S{n}: workstation steering=({steer[0]:+.2f},{steer[1]:+.2f},{steer[2]:.2f}), series median=({nominal[0]:+.2f},{nominal[1]:+.2f},{nominal[2]:.2f}), planned focalRAS=({focus[0]:+.2f},{focus[1]:+.2f},{focus[2]:+.2f}) mm'
        )
        return tuple(float(v) for v in focus),evidence

    def _dqa_common_locate_focal_ras(self, package) -> tuple[tuple[float,float,float] | None, list[str], str | None]:
        """Return the common physical DQA focal point from Locate Transducer.

        For a DQA series the transducer is mechanically fixed after the setup Locate.
        We therefore use the last directly reported workstation ``focal position:``
        preceding the first DQA sonication.  Electronic steering is a separate
        domain; if the sonication steering target changes across the series the
        centre-alignment judgement is excluded rather than folding steering into
        the physical focal point.
        """
        workspace=Path(getattr(package,'workspace','.') or '.')
        svc=TransducerLocationService()
        history=[q for q in svc.locate_focal_history(workspace)
                 if q.focal_xyz is not None and (not q.protocol_name or 'dqa' in q.protocol_name.lower())]
        steering=list(svc._sonication_steering_events(workspace))
        evidence=[]
        first_sonic=min((float(q.clock_s) for q in steering),default=None)

        candidates=history
        if first_sonic is not None:
            pre=[q for q in history if float(q.clock_s) <= first_sonic + 1e-6]
            if pre:
                candidates=pre
        if not candidates:
            return None,['No DQA Locate Transducer focal-position record was found'],None

        chosen=max(candidates,key=lambda q:float(q.clock_s))
        focal=tuple(float(v) for v in chosen.focal_xyz)
        evidence.append(
            f'DQA common focal from last Locate before first sonication: '
            f'({focal[0]:+.1f},{focal[1]:+.1f},{focal[2]:+.1f}) mm at {chosen.clock_s:.3f}s'
        )

        steering_exclusion=None
        if len(steering) >= 2:
            vals=np.asarray([q.steering_xyz for q in steering],float)
            if vals.ndim == 2 and vals.shape[1] == 3 and np.all(np.isfinite(vals)):
                span=np.nanmax(vals,axis=0)-np.nanmin(vals,axis=0)
                if float(np.nanmax(np.abs(span))) > 0.5:
                    steering_exclusion=(
                        'electronic steering changes across the DQA series '
                        f'(XYZ span {span[0]:.2f}/{span[1]:.2f}/{span[2]:.2f} mm)'
                    )
                    evidence.append('DQA centre-alignment judgement excluded: '+steering_exclusion)
                else:
                    evidence.append(
                        f'No material electronic steering change across DQA sonications '
                        f'(XYZ span {span[0]:.2f}/{span[1]:.2f}/{span[2]:.2f} mm)'
                    )
        return focal,evidence,steering_exclusion

    def _observed_dqa_focus_by_orientation(self, package, focal_by_number: dict[int, tuple[float,float,float]]) -> tuple[dict[str,dict[str,object]], list[str]]:
        """R0190: exact-paired, phantom-masked observed DQA focus measurement."""
        params=self._find_mri_params(Path(getattr(package,'workspace','.') or '.'))
        try:
            rows=parse_ado_rowset(params) if params is not None and Path(params).exists() else []
        except Exception:
            rows=[]
        if not rows:
            return {},['Observed DQA focus unavailable: MriImageParams missing/unreadable']
        evidence=[]; shot_best={}
        for pos,son in enumerate(list(getattr(package,'sonications',[]) or []),start=1):
            number=int(getattr(son,'sonication_number',0) or pos)
            exclusion=self._dqa_exclusion_reason(package,number,focal_by_number)
            if exclusion:
                evidence.append(f'S{number} excluded from common-focus measurement: {exclusion}')
                continue
            temps=list(getattr(son,'temperature_frames',[]) or [])
            mags=list(getattr(son,'magnitude_frames',[]) or [])
            if not temps or not mags:
                continue
            # Establish validated baselines independently per physical orientation.
            baselines={}
            for tf in temps:
                row=self._row_for_raw_frame(rows,tf.path)
                orientation=self._orientation(row or {})
                if orientation not in ('Axial','Sagittal') or orientation in baselines:
                    continue
                try: arr=np.asarray(self.raw.read_temperature(tf.path),float)
                except Exception: continue
                thermo=self._thermometry_evidence(row,arr)
                if bool(thermo.get('valid')):
                    baselines[orientation]=(arr,thermo)
            for tf in temps:
                row=self._row_for_raw_frame(rows,tf.path)
                orientation=self._orientation(row or {})
                if orientation not in baselines:
                    continue
                pair=self._exact_magnitude_pair(rows,tf.path,mags)
                if pair is None:
                    evidence.append(f'S{number} {Path(tf.path).name}: no unique exact magnitude acquisition/geometry pair; fail closed')
                    continue
                mf,mrow=pair
                try:
                    arr=np.asarray(self.raw.read_temperature(tf.path),float)
                    mag=np.asarray(self.raw.read_magnitude(mf.path),float)
                except Exception:
                    continue
                baseline,thermo=baselines[orientation]
                if arr.shape != baseline.shape or mag.shape[:2] != arr.shape[:2]:
                    continue
                masked=self._phantom_mask_from_magnitude(orientation,mag)
                if masked is None:
                    evidence.append(f'S{number} {Path(tf.path).name}: phantom-derived {orientation} mask unavailable; fail closed')
                    continue
                mask,mask_diag=masked
                delta=arr-baseline if thermo.get('mode') == 'absolute' else arr
                valid=mask & np.isfinite(delta)
                if int(valid.sum()) < 25:
                    continue
                filled=np.where(valid,delta,np.nan)
                # Coherent 5x5 local statistic. Require enough valid neighbours so
                # a mask edge/single-pixel spike cannot win.
                values=np.nan_to_num(filled,nan=0.0); counts=valid.astype(float)
                pv=np.pad(values,2,mode='constant'); pc=np.pad(counts,2,mode='constant')
                sums=sum(pv[dy:dy+delta.shape[0],dx:dx+delta.shape[1]] for dy in range(5) for dx in range(5))
                nums=sum(pc[dy:dy+delta.shape[0],dx:dx+delta.shape[1]] for dy in range(5) for dx in range(5))
                sm=np.where(nums>=18.0,sums/np.maximum(nums,1.0),-np.inf)
                sm[~mask]=-np.inf
                if not np.isfinite(sm).any():
                    continue
                flat=int(np.nanargmax(sm)); hy,hx=np.unravel_index(flat,sm.shape); score=float(sm[hy,hx])
                # Weighted centroid in a local 5x5 patch, constrained by mask.
                ya,yb=max(0,hy-2),min(delta.shape[0],hy+3); xa,xb=max(0,hx-2),min(delta.shape[1],hx+3)
                patch=np.asarray(delta[ya:yb,xa:xb],float); pm=mask[ya:yb,xa:xb] & np.isfinite(patch)
                floor=float(np.nanmedian(patch[pm])) if pm.any() else score
                weights=np.where(pm,np.maximum(patch-floor,0.0),0.0)
                if float(weights.sum())>0:
                    gy,gx=np.indices(weights.shape); fx=xa+float((weights*gx).sum()/weights.sum()); fy=ya+float((weights*gy).sum()/weights.sum())
                else:
                    fx=float(hx); fy=float(hy)
                hotspot_ras=self._absolute_ras(row,fx,fy)
                if hotspot_ras is None or not np.isfinite(hotspot_ras).all():
                    continue
                paired={'row':mrow,'raw':str(mf.path),'label':f'Exact paired {orientation} magnitude S{number} {Path(mf.path).name}'}
                if orientation=='Axial':
                    cp=mask_diag['circle_pixel']; cr=self._absolute_ras(mrow,*cp)
                    if cr is None: continue
                    paired.update(circle_pixel=cp,circle_ras=tuple(float(v) for v in cr),support=float(mask_diag['support']))
                else:
                    ok,fdiag=self._point_in_exported_image_frame(mrow,hotspot_ras,in_plane_margin_fraction=.10,normal_tolerance_mm=2.0)
                    if not ok or not fdiag:
                        continue
                    bx=float(fdiag['x_px']); by=float(mask_diag['slope']*bx+mask_diag['intercept']); br=self._absolute_ras(mrow,bx,by)
                    sizes=self._pixel_sizes(mrow)
                    if br is None or sizes is None: continue
                    tilt=float(math.degrees(math.atan2(float(mask_diag['slope'])*sizes[1],sizes[0])))
                    paired.update(baseline_pixel=(bx,by),baseline_ras=tuple(float(v) for v in br),slope=float(mask_diag['slope']),intercept=float(mask_diag['intercept']),support=float(mask_diag['support']),tilt_deg=tilt)
                candidate={'sonication_number':number,'orientation':orientation,'row':row,'frame':Path(tf.path).name,
                    'magnitude_frame':Path(mf.path).name,'hotspot_pixel':(fx,fy),'hotspot_ras':tuple(float(v) for v in hotspot_ras),
                    'score':score,'mask_geometry':mask_diag,'paired_reference':paired,
                    'exact_identity':self._row_acquisition_identity(row),'thermometry_evidence':list(thermo.get('evidence',[]) or [])}
                key=(number,orientation); old=shot_best.get(key)
                if old is None or score>float(old['score']): shot_best[key]=candidate
        # R0190c recovery path: some valid MEMP DQA exports expose thermometry
        # perfectly (and Replay can display it) but do not provide a unique Field-6
        # magnitude partner for every Field-5 acquisition.  The old strict path then
        # discarded *all* observed focus evidence and Summary stayed N/A.
        #
        # Recover only the observed hotspot, never the DQA zero point: use the
        # already fail-closed same-raster planned-focus local search to identify a
        # coherent heated focus.  Series X/Y/Z are still measured later against the
        # independently detected DQA phantom circle/lower-line geometry.
        present_orientations={o for (_n,o) in shot_best}
        if len(present_orientations) < 2:
            for pos,son in enumerate(list(getattr(package,'sonications',[]) or []),start=1):
                number=int(getattr(son,'sonication_number',0) or pos)
                if self._dqa_exclusion_reason(package,number,focal_by_number):
                    continue
                planned=focal_by_number.get(number)
                if planned is None:
                    continue
                m=self._planned_focus_native_measurement(son,rows,planned)
                if m.get('error'):
                    evidence.append(f"S{number} thermal-focus fallback unavailable: {m.get('error')}")
                    continue
                orientation=str(m.get('orientation') or '')
                if orientation not in ('Axial','Sagittal') or orientation in present_orientations:
                    continue
                frame_name=str(m.get('frame') or '')
                tf=next((f for f in list(getattr(son,'temperature_frames',[]) or []) if Path(f.path).name==frame_name),None)
                row=self._row_for_raw_frame(rows,tf.path) if tf is not None else None
                if row is None:
                    continue
                fx=float(m.get('hotspot_x')); fy=float(m.get('hotspot_y')); ras=self._absolute_ras(row,fx,fy)
                if ras is None or not np.isfinite(ras).all():
                    continue
                candidate={'sonication_number':number,'orientation':orientation,'row':row,'frame':frame_name,
                    'magnitude_frame':'not required (validated thermal-focus fallback)',
                    'hotspot_pixel':(fx,fy),'hotspot_ras':tuple(float(v) for v in ras),
                    'score':0.0,'mask_geometry':{'kind':'validated-thermal-local-focus'},'paired_reference':None,
                    'exact_identity':self._row_acquisition_identity(row),'thermometry_evidence':[str(m.get('evidence') or '')]}
                shot_best[(number,orientation)]=candidate; present_orientations.add(orientation)
                evidence.append(f"Observed {orientation} DQA focus recovered from validated same-raster thermal hotspot in S{number} {frame_name}; magnitude pair was not used as the displacement zero-point")
                if len(present_orientations)>=2:
                    break

        # Select a DQA shot before selecting a frame: each S/orientation contributes
        # at most one exact-paired or validated thermal-focus candidate. Planned focus
        # is only a focus-identification aid/tie-break, never the series zero point.
        best={}
        for orientation in ('Axial','Sagittal'):
            candidates=[c for (n,o),c in shot_best.items() if o==orientation]
            if not candidates: continue
            top=max(float(c['score']) for c in candidates); near=[c for c in candidates if float(c['score'])>=top-max(abs(top)*.03,.15)]
            def tie(c):
                planned=focal_by_number.get(int(c['sonication_number']))
                if planned is None: return float('inf')
                ok,d=self._point_in_exported_image_frame(c['row'],planned,in_plane_margin_fraction=.25,normal_tolerance_mm=18.0)
                if not ok or not d: return float('inf')
                return float(np.hypot(float(c['hotspot_pixel'][0])-float(d['x_px']),float(c['hotspot_pixel'][1])-float(d['y_px'])))
            best[orientation]=min(near,key=lambda c:(tie(c),-float(c['score'])))
        for orientation,c in sorted(best.items()):
            h=c['hotspot_pixel']; r=c['hotspot_ras']; mg=c['mask_geometry']
            evidence.append(f"Observed {orientation} DQA focus: selected S{c['sonication_number']} thermal={c['frame']} magnitude={c['magnitude_frame']} exact_identity={c['exact_identity']}; hotspot=({h[0]:.2f},{h[1]:.2f}) px MR-RAS=({r[0]:+.2f},{r[1]:+.2f},{r[2]:+.2f}) mm; 5x5 coherent score={float(c['score']):.3f}; phantom mask={mg.get('kind')}")
        return best,evidence

    @classmethod
    def _nearest_reference_candidate(cls, candidates: list[dict[str,object]], focus_ras) -> tuple[dict[str,object] | None, dict[str,float] | None]:
        best=None; best_diag=None; best_cost=float('inf')
        for candidate in candidates:
            row=candidate.get('row')
            if not isinstance(row,dict):
                continue
            ok,diag=cls._point_in_exported_image_frame(row,focus_ras,in_plane_margin_fraction=.08,normal_tolerance_mm=10.0)
            if not ok or not diag:
                continue
            # Prefer the closest slice plane first; an in-FOV projection is required.
            x=float(diag.get('x_px',np.nan)); y=float(diag.get('y_px',np.nan))
            w=float(diag.get('width',256.0)); h=float(diag.get('height',256.0))
            inside=(0.0 <= x < w and 0.0 <= y < h)
            if not inside:
                continue
            cost=abs(float(diag.get('normal_mm',np.inf)))
            if cost < best_cost:
                best=candidate; best_diag=diag; best_cost=cost
        return best,best_diag

    def analyze_series(self, package) -> DqaFocusAlignment:
        """Series-common DQA alignment from observed focus and phantom geometry.

        R0190 contract:
          * Observed focus comes from validated thermometry, not planned focalRAS.
          * planned focalRAS may seed a local hotspot search but is never a zero-point.
          * X/Y are measured in one DQA-Axial raster: observed focus projection -
            detected phantom-circle centre.
          * Z is measured in one DQA-Sagittal raster: observed focus projection -
            (detected lower line + 20.0 mm superior in MR RAS).
          * Reference and focus must both project into the same selected raster.
            Otherwise the component is unavailable (fail closed).
        """
        key=f"r0190::series::{Path(getattr(package,'workspace','.') or '.').resolve()}"
        if key in self._cache:
            return self._cache[key]
        if not self.is_dqa(package):
            result=DqaFocusAlignment(confidence='Not DQA',evidence=['DQA-only analysis not applicable'],calculator_contract='R0190')
            self._cache[key]=result
            return result

        reference=self._dqa_reference_geometry(package)
        ref_evidence=list(reference.get('evidence',[]) or [])
        focal_by_number=self._summary_focal_ras(package)
        observed,observed_evidence=self._observed_dqa_focus_by_orientation(package,focal_by_number)
        _locate_focal,locate_evidence,steering_exclusion=self._dqa_common_locate_focal_ras(package)

        x=y=z=None; tilt=None; reference_xyz=None; registered_focal=None; baseline_to_focal=None
        geometry_evidence=[]; failures=[]; diagnostic_overlays={}

        axial=observed.get('Axial')
        if axial is None:
            failures.append('observed Axial thermal focus')
        else:
            focus_ras=np.asarray(axial['hotspot_ras'],float)
            candidate=axial.get('paired_reference') if isinstance(axial.get('paired_reference'),dict) and axial.get('paired_reference',{}).get('circle_ras') is not None else None
            diag=None
            if candidate is not None:
                _ok,diag=self._point_in_exported_image_frame(candidate['row'],focus_ras,in_plane_margin_fraction=.08,normal_tolerance_mm=10.0)
                if not _ok:
                    diag=None
            if candidate is None or diag is None:
                candidate,diag=self._nearest_reference_candidate(list(reference.get('axial_candidates',[]) or []),focus_ras)
            if candidate is None or diag is None:
                failures.append('same-raster Axial phantom reference')
            else:
                row=candidate['row']; circle=np.asarray(candidate['circle_ras'],float)
                focus_plane=self._absolute_ras(row,float(diag['x_px']),float(diag['y_px']))
                if focus_plane is None:
                    failures.append('Axial focus projection')
                else:
                    focus_plane=np.asarray(focus_plane,float)
                    cp=candidate['circle_pixel']
                    pixel_delta=self._ras_delta(row,float(diag['x_px'])-float(cp[0]),float(diag['y_px'])-float(cp[1]))
                    direct_delta=focus_plane-circle
                    if pixel_delta is None or float(np.linalg.norm(np.asarray(pixel_delta)-direct_delta)) > 0.25:
                        failures.append('Axial pixel/RAS geometry consistency')
                        x=y=None
                        geometry_evidence.append('R0190 fail-closed: Axial pixel-derived and direct RAS deltas disagree by >0.25 mm')
                    else:
                        x=float(direct_delta[0]); y=float(direct_delta[1])
                    geometry_evidence.append(
                        f"Axial same-raster: {candidate['label']}; circle=({cp[0]:.2f},{cp[1]:.2f}) px, "
                        f"focus projection=({float(diag['x_px']):.2f},{float(diag['y_px']):.2f}) px, plane distance={float(diag['normal_mm']):+.2f} mm; "
                        f"X/Y=({x:+.2f},{y:+.2f}) mm"
                    )
                    reference_xyz=(float(circle[0]),float(circle[1]),float(circle[2]))
                    registered_focal=tuple(float(v) for v in focus_plane)
                    diagnostic_overlays[str(axial.get('frame') or '')]={
                        'orientation':'Axial','source_frame':str(axial.get('frame') or ''),'reference_label':str(candidate.get('label') or ''),
                        'circle_pixel':(float(cp[0]),float(cp[1])),'focus_pixel':(float(diag['x_px']),float(diag['y_px'])),
                        'circle_ras':tuple(float(v) for v in circle),'focus_ras':tuple(float(v) for v in focus_plane),
                        'x_mm':x,'y_mm':y,'contract':'R0190',
                    }

        sagittal=observed.get('Sagittal')
        if sagittal is None:
            failures.append('observed Sagittal thermal focus')
        else:
            focus_ras=np.asarray(sagittal['hotspot_ras'],float)
            candidate=sagittal.get('paired_reference') if isinstance(sagittal.get('paired_reference'),dict) and sagittal.get('paired_reference',{}).get('baseline_ras') is not None else None
            diag=None
            if candidate is not None:
                _ok,diag=self._point_in_exported_image_frame(candidate['row'],focus_ras,in_plane_margin_fraction=.08,normal_tolerance_mm=10.0)
                if not _ok:
                    diag=None
            if candidate is None or diag is None:
                candidate,diag=self._nearest_reference_candidate(list(reference.get('sagittal_candidates',[]) or []),focus_ras)
            if candidate is None or diag is None:
                failures.append('same-raster Sagittal phantom reference')
            else:
                row=candidate['row']; baseline=np.asarray(candidate['baseline_ras'],float)
                focus_plane=self._absolute_ras(row,float(diag['x_px']),float(diag['y_px']))
                ref_ras=baseline.copy(); ref_ras[2]+=20.0
                ref_ok,ref_diag=self._point_in_exported_image_frame(row,ref_ras,in_plane_margin_fraction=.08,normal_tolerance_mm=2.0)
                if focus_plane is None or not ref_ok or not ref_diag:
                    failures.append('Sagittal +20 mm reference projection')
                else:
                    focus_plane=np.asarray(focus_plane,float)
                    ref_plane=self._absolute_ras(row,float(ref_diag['x_px']),float(ref_diag['y_px']))
                    if ref_plane is None:
                        failures.append('Sagittal reference back-projection')
                    else:
                        ref_plane=np.asarray(ref_plane,float)
                        bp=candidate['baseline_pixel']
                        pixel_delta=self._ras_delta(row,float(diag['x_px'])-float(ref_diag['x_px']),float(diag['y_px'])-float(ref_diag['y_px']))
                        direct_delta=focus_plane-ref_plane
                        if pixel_delta is None or float(np.linalg.norm(np.asarray(pixel_delta)-direct_delta)) > 0.25:
                            failures.append('Sagittal pixel/RAS geometry consistency')
                            z=None
                            geometry_evidence.append('R0190 fail-closed: Sagittal pixel-derived and direct RAS deltas disagree by >0.25 mm')
                        else:
                            z=float(direct_delta[2])
                        baseline_to_focal=float(focus_plane[2]-baseline[2])
                        tilt=float(candidate.get('tilt_deg')) if candidate.get('tilt_deg') is not None else None
                        geometry_evidence.append(
                            f"Sagittal same-raster: {candidate['label']}; lower line=({bp[0]:.2f},{bp[1]:.2f}) px, "
                            f"+20 mm reference=({float(ref_diag['x_px']):.2f},{float(ref_diag['y_px']):.2f}) px, "
                            f"focus projection=({float(diag['x_px']):.2f},{float(diag['y_px']):.2f}) px, plane distance={float(diag['normal_mm']):+.2f} mm; "
                            f"lower-line→focus S={baseline_to_focal:+.2f} mm, Z after +20 mm={z:+.2f} mm"
                        )
                        if reference_xyz is None:
                            reference_xyz=(float(ref_plane[0]),float(ref_plane[1]),float(ref_plane[2]))
                        else:
                            reference_xyz=(reference_xyz[0],reference_xyz[1],float(ref_plane[2]))
                        if registered_focal is None:
                            registered_focal=tuple(float(v) for v in focus_plane)
                        diagnostic_overlays[str(sagittal.get('frame') or '')]={
                            'orientation':'Sagittal','source_frame':str(sagittal.get('frame') or ''),'reference_label':str(candidate.get('label') or ''),
                            'baseline_pixel':(float(bp[0]),float(bp[1])),'reference_pixel':(float(ref_diag['x_px']),float(ref_diag['y_px'])),
                            'focus_pixel':(float(diag['x_px']),float(diag['y_px'])),'baseline_ras':tuple(float(v) for v in baseline),
                            'reference_ras':tuple(float(v) for v in ref_plane),'focus_ras':tuple(float(v) for v in focus_plane),
                            'baseline_to_focus_mm':baseline_to_focal,'z_mm':z,'tilt_deg':tilt,'contract':'R0190',
                        }

        if x is None and y is None and z is None:
            result=DqaFocusAlignment(
                tilt_deg=tilt, confidence='Unavailable', calculator_contract='R0190',
                judgement_excluded_reason=steering_exclusion,
                evidence=[
                    'R0190 fail-closed: DQA displacement requires observed thermometry focus and phantom reference in the same selected MR raster.',
                    'planned SonicationSummary focalRAS is a hotspot-search seed only and is never subtracted from phantom geometry.',
                    *observed_evidence,*geometry_evidence,*locate_evidence,*ref_evidence,
                ],
                excluded_reason='missing '+', '.join(failures) if failures else 'same-raster DQA geometry unavailable',
            )
            self._cache[key]=result
            return result

        confidence='High' if x is not None and y is not None and z is not None and tilt is not None else 'Partial'
        evidence=[
            'R0190 DQA contract: observed validated-thermometry focus vs phantom reference in selected same MR rasters.',
            'X/Y = Axial observed-focus projection - Axial phantom-circle centre.',
            'Z = Sagittal observed-focus projection - (Sagittal lower line +20.0 mm superior).',
            'SonicationSummary focalRAS is a hotspot-search seed only; it is never a displacement zero-point.',
            *observed_evidence,*geometry_evidence,*locate_evidence,*ref_evidence,
        ]
        if failures:
            evidence.append('Partial components unavailable: '+', '.join(failures))
        result=DqaFocusAlignment(
            x_mm=x,y_mm=y,z_mm=z,tilt_deg=tilt,confidence=confidence,
            judgement_excluded_reason=steering_exclusion,
            reference_xyz=reference_xyz,registered_focal_ras=registered_focal,
            baseline_to_focal_mm=baseline_to_focal,calculator_contract='R0190',diagnostic_overlays=diagnostic_overlays,evidence=evidence,
        )
        self._cache[key]=result
        return result

    def cached_series(self, package) -> DqaFocusAlignment | None:
        """Return the already-computed series result without triggering analysis or I/O."""
        key=f"r0189::series::{Path(getattr(package,'workspace','.') or '.').resolve()}"
        return self._cache.get(key)

    def clear_cache(self) -> None:
        self._cache.clear()
        self._reference_cache.clear()
