from __future__ import annotations

import types
from typing import Callable

import pyqtgraph as pg
from PySide6.QtCore import QObject, QEvent, Qt, QTimer
from PySide6.QtWidgets import QDialog, QVBoxLayout
from PySide6.QtGui import QColor


class _PlotDoubleClickResetFilter(QObject):
    def __init__(self, plot, reset_callback: Callable[[], None] | None = None, double_click_callback: Callable[[], None] | None = None):
        super().__init__(plot)
        self.plot = plot
        self.reset_callback = reset_callback
        self.double_click_callback = double_click_callback

    def eventFilter(self, obj, event):
        if event.type() == QEvent.Type.MouseButtonDblClick and event.button() == Qt.MouseButton.LeftButton:
            if self.double_click_callback is not None:
                try:
                    self.double_click_callback()
                except Exception:
                    return False
            else:
                reset_plot_zoom(self.plot, self.reset_callback)
            event.accept()
            return True
        return False


def reset_plot_zoom(plot, reset_callback: Callable[[], None] | None = None) -> None:
    """Reset both axes to the current data bounds with one double click."""
    if plot is None:
        return
    try:
        vb = plot.getViewBox()
        vb.autoRange(padding=0.02)
    except Exception:
        try:
            plot.autoRange(padding=0.02)
        except Exception:
            return
    try:
        if reset_callback is not None:
            reset_callback()
    except Exception:
        pass


def install_horizontal_axis_range_zoom(
    plot,
    *,
    manual_callback: Callable[[], None] | None = None,
    reset_callback: Callable[[], None] | None = None,
    double_click_callback: Callable[[], None] | None = None,
) -> None:
    """Add horizontal-axis drag-to-zoom and chart double-click reset.

    Contract:
    - Drag with the LEFT button directly on the bottom X axis to choose an X range.
    - Only X changes; the existing Y range is preserved exactly.
    - Normal dragging inside the plotting area remains pyqtgraph pan behavior.
    - Double-left-click invokes ``double_click_callback`` when supplied; otherwise it resets zoom.

    This deliberately keeps FFT/raw chart-area range selection independent: it owns
    the plotting area, while generic navigation owns only the bottom axis.
    """
    if plot is None:
        return
    # R0190c: installation is idempotent for axis drag, but the double-click
    # action is intentionally upgradeable.  Earlier code returned here and could
    # leave an older reset handler installed when a later owner requested enlarge.
    if bool(getattr(plot, "_soni_x_axis_range_zoom_installed", False)):
        filt = getattr(plot, "_soni_x_axis_zoom_filter", None)
        if filt is not None:
            if double_click_callback is not None:
                filt.double_click_callback = double_click_callback
            if reset_callback is not None:
                filt.reset_callback = reset_callback
        return
    try:
        axis = plot.getAxis("bottom")
        vb = plot.getViewBox()
        # Image/map panels deliberately hide their X axis.  They are not range charts,
        # so installing a viewport double-click reset there would change image framing.
        if hasattr(axis, "isVisible") and not axis.isVisible():
            return
        original_drag = axis.mouseDragEvent
    except Exception:
        return

    plot._soni_x_axis_range_zoom_installed = True
    state = {"active": False, "start": None, "region": None, "y": None}

    def _scene_x(ev):
        try:
            return float(vb.mapSceneToView(ev.scenePos()).x())
        except Exception:
            try:
                return float(vb.mapSceneToView(ev.pos()).x())
            except Exception:
                return None

    def _remove_region():
        region = state.get("region")
        state["region"] = None
        if region is not None:
            try:
                plot.removeItem(region)
            except Exception:
                pass

    def _axis_mouse_drag(axis_self, ev):
        try:
            if ev.button() != Qt.MouseButton.LeftButton:
                return original_drag(ev)
        except Exception:
            return original_drag(ev)

        x = _scene_x(ev)
        if x is None:
            return original_drag(ev)

        if ev.isStart():
            state["active"] = True
            state["start"] = x
            try:
                state["y"] = tuple(float(v) for v in vb.viewRange()[1])
            except Exception:
                state["y"] = None
            _remove_region()
            try:
                region = pg.LinearRegionItem(
                    values=(x, x),
                    orientation=pg.LinearRegionItem.Vertical,
                    movable=False,
                    brush=pg.mkBrush(QColor(90, 180, 255, 55)),
                    pen=pg.mkPen(QColor(130, 210, 255, 210), width=1),
                )
                region.setZValue(10_000)
                plot.addItem(region, ignoreBounds=True)
                state["region"] = region
            except Exception:
                state["region"] = None

        if state.get("active"):
            start = float(state.get("start", x))
            lo, hi = sorted((start, x))
            region = state.get("region")
            if region is not None:
                try:
                    region.setRegion((lo, hi))
                except Exception:
                    pass
            if ev.isFinish():
                state["active"] = False
                _remove_region()
                # Reject accidental clicks/tiny ranges in scene coordinates.
                try:
                    current_x = vb.viewRange()[0]
                    min_width = max(abs(float(current_x[1]) - float(current_x[0])) * 0.002, 1e-12)
                except Exception:
                    min_width = 1e-12
                if hi - lo >= min_width:
                    try:
                        vb.setXRange(lo, hi, padding=0.0)
                        y = state.get("y")
                        if y is not None and len(y) == 2:
                            vb.setYRange(float(y[0]), float(y[1]), padding=0.0)
                        if manual_callback is not None:
                            manual_callback()
                    except Exception:
                        pass
        ev.accept()

    axis.mouseDragEvent = types.MethodType(_axis_mouse_drag, axis)

    # The viewport sees double-clicks before GraphicsScene dispatch. This is more
    # reliable than depending on a particular pyqtgraph ViewBox version.
    try:
        filt = _PlotDoubleClickResetFilter(plot, reset_callback, double_click_callback)
        plot.viewport().installEventFilter(filt)
        plot._soni_x_axis_zoom_filter = filt
    except Exception:
        pass

    try:
        old_tip = str(plot.toolTip() or "").strip()
        dbl_hint = "Double-click the chart to enlarge it." if double_click_callback is not None else "Double-click the chart to reset zoom."
        hint = "Drag the bottom X axis to zoom a horizontal range. " + dbl_hint
        plot.setToolTip((old_tip + "\n" + hint).strip())
    except Exception:
        pass


def open_enlarged_plot(plot, title: str = "Chart", parent=None):
    """Open a non-modal enlarged copy of any pyqtgraph PlotWidget.

    This is the common fallback for analysis/analyzer charts that do not have a
    domain-specific synchronized popup.  Curves and vertical/horizontal markers
    are copied from the live plot at open time; the source plot is never mutated.
    """
    if plot is None:
        return None
    dlg = QDialog(parent)
    dlg.setWindowTitle(str(title or "Chart"))
    dlg.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowCloseButtonHint)
    dlg.resize(1100, 720)
    out = pg.PlotWidget(title=str(title or "Chart")); out.showGrid(x=True, y=True, alpha=.2)
    try:
        for axis_name in ("left", "bottom"):
            src_axis=plot.getAxis(axis_name); dst_axis=out.getAxis(axis_name)
            txt=getattr(src_axis, "labelText", "") or ""; units=getattr(src_axis, "labelUnits", "") or ""
            if txt: dst_axis.setLabel(text=txt, units=units)
    except Exception:
        pass
    for item in list(getattr(plot.getPlotItem(), "items", []) or []):
        try:
            if isinstance(item, pg.PlotDataItem):
                x,y=item.getData(); pen=item.opts.get("pen", None); symbol=item.opts.get("symbol", None)
                out.plot(x, y, pen=pen, symbol=symbol, connect=item.opts.get("connect", "auto"))
            elif isinstance(item, pg.InfiniteLine):
                angle=float(item.angle); value=float(item.value()); out.addLine(x=value if angle==90 else None, y=value if angle!=90 else None, pen=item.pen)
        except Exception:
            continue
    try:
        xr,yr=plot.getViewBox().viewRange(); out.setXRange(*xr,padding=0); out.setYRange(*yr,padding=0)
    except Exception:
        out.autoRange()
    install_horizontal_axis_range_zoom(out)
    lay=QVBoxLayout(dlg); lay.addWidget(out)
    # Keep dialog alive with its source widget; close cleanup removes the reference.
    refs=list(getattr(plot, "_soni_enlarged_dialogs", []) or []); refs.append(dlg); plot._soni_enlarged_dialogs=refs
    dlg.finished.connect(lambda *_: setattr(plot, "_soni_enlarged_dialogs", [d for d in getattr(plot,"_soni_enlarged_dialogs",[]) if d is not dlg]))
    dlg.show(); dlg.raise_(); dlg.activateWindow()
    return dlg
