from pathlib import Path
S=(Path(__file__).parents[1]/'src/services/dqa_focus_alignment_service.py').read_text(encoding='utf-8')
def block(a,b): return S[S.index(a):S.index(b,S.index(a)+1)]
def test_no_index_ratio_pairing_in_dqa_service():
    assert '(len(mags)-1)' not in S
    assert 'float(ti)*(len(mags)' not in S
def test_exact_pair_uses_acquisition_and_geometry_and_fails_ambiguity():
    b=block('    def _exact_magnitude_pair','    @classmethod\n    def _phantom_mask_from_magnitude')
    assert '_row_acquisition_identity' in b and '_geometry_compatible' in b
    assert 'if len(matches) != 1' in b
def test_observed_focus_is_phantom_masked_not_global_raster_or_planned_roi():
    b=block('    def _observed_dqa_focus_by_orientation','    @classmethod\n    def _nearest_reference_candidate')
    assert '_phantom_mask_from_magnitude' in b
    assert 'sm[~mask]=-np.inf' in b
    assert '5x5' in b
    assert '.05*w' not in b and '.95*w' not in b
    assert 'radius=14' not in b and 'pixel_distance > 10.0' not in b
def test_point_projection_ok_is_required_in_reference_paths():
    b=block('    def _nearest_reference_candidate','    def analyze_series')
    assert 'if not ok or not diag' in b
    a=S[S.index('    def analyze_series'):]
    assert 'if not _ok:' in a
    assert 'if focus_plane is None or not ref_ok or not ref_diag' in a
def test_mask_is_phantom_derived_for_both_orientations():
    b=block('    def _phantom_mask_from_magnitude','    def _native_measurement_for_sonication')
    assert '_circle_center' in b and '_baseline_line' in b
    assert 'focal_by_number' not in b and 'planned_ras' not in b
def test_r0190_contract_label():
    assert 'calculator_contract: str = "R0190e"' in S
    assert 'r0190y::series::' in S
