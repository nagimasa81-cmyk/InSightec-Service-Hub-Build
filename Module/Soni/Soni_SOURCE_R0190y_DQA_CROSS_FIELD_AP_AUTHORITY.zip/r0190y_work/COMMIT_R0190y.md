# R0190y — DQA cross-field pairing and AP authority hardening

- Thermal↔Magnitude pairing identity is now Sonication + canonical acquisition index.
  Field-local zone index is deliberately excluded; 4267 uses thermal zone 3 and magnitude zone 0 for the same MEMP acquisition.
- Sagittal AP zero point no longer comes from the sagittal body/baseline mask extent.
  Y/AP uses the physical A coordinate of the exact-paired Axial phantom circle.
- Observed thermal candidates more than 30 mm in-plane from the commanded DQA focus are rejected as unrelated artifacts.
  The measured centroid is not moved or fitted.
- Marker display continues to use the same physical reference used by the calculator.
- No fixture-name/SHA branching, expected-value fitting, numeric clipping, or 11 mm constant was added.
