from pathlib import Path
ROOT=Path(__file__).parents[1]
REPLAY=(ROOT/'src/services/replay_service.py').read_text(encoding='utf-8')
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')

def method_block(text, name):
    start=text.index(f'def {name}')
    tail=text[start:]
    marker='\n    def '
    end=tail.find(marker, 8)
    return tail if end < 0 else tail[:end]

def test_temperature_metrics_is_independent_of_load_images():
    assert 'def temperature_metrics(self, son: SonicationModel)' in REPLAY
    block=method_block(MAIN, '_build_one_sonication_summary')
    assert 'self.replay.temperature_metrics(son)' in block
    assert 'if self._image_loading_enabled()' not in block

def test_temperature_metrics_reads_no_magnitude():
    block=method_block(REPLAY, 'temperature_metrics')
    assert 'read_temperature' in block
    assert 'read_magnitude' not in block

def test_rca_temperature_uses_numeric_cache_path():
    block=method_block(MAIN, '_rca_temperature_metrics')
    assert 'temperature_metrics' in block
    assert '_image_loading_enabled' not in block

def test_why_popup_identifies_selected_point():
    assert 'Selected point:' in HYDRO
    assert 'Trigger check:' in HYDRO
    assert 'Graph link:' in HYDRO
    assert 'def _highlight_why_event' in HYDRO
    assert 'ScatterPlotItem([float(t)],[float(weighted)]' in HYDRO
    assert 'Selected rule threshold' in HYDRO

def test_popup_title_has_event_and_time():
    assert 'title=f"Why — {family}"' in HYDRO
    assert 'title+=f" @ {t:.3f} s"' in HYDRO
