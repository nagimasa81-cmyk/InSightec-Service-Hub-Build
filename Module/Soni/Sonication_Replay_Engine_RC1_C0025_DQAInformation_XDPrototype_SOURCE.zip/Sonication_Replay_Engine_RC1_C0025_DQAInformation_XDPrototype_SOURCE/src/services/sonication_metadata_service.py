from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re


@dataclass(slots=True)
class SonicationMetadata:
    summary: dict[str, str] = field(default_factory=dict)
    mr: list[tuple[str, str]] = field(default_factory=list)
    scan: list[tuple[str, str]] = field(default_factory=list)


class SonicationMetadataService:
    """Best-effort metadata resolver. Unknown values remain explicit rather than guessed."""

    DQA_FALLBACK = {
        1: ("Axial", "A/P", "R/L"),
        2: ("Sagittal", "A/P", "S/I"),
        3: ("Axial", "R/L", "A/P"),
    }

    def read(self, model, package, sonication_number: int) -> SonicationMetadata:
        orientation = self._find_value(model.folder, [r"(?:Orientation|Plane)\s*[:=]\s*([A-Za-z/]+)"])
        freq_dir = self._find_value(model.folder, [r"(?:Frequency\s*(?:Dir|Direction)|FreqDir)\s*[:=]\s*([A-Za-z/]+)"])
        hotspot = "Unavailable"
        if sonication_number in self.DQA_FALLBACK:
            fallback_orientation, fallback_dir, hotspot = self.DQA_FALLBACK[sonication_number]
            orientation = orientation or fallback_orientation
            freq_dir = freq_dir or fallback_dir

        power = model.planned_power_w
        duration = model.actual_duration_s or model.planned_duration_s
        energy = power * duration if power is not None and duration is not None else None
        frequency_hz = model.main_frequency_hz or getattr(package, "main_frequency_hz", None)

        summary = {
            "Orientation": orientation or "Unavailable",
            "Frequency Dir": freq_dir or "Unavailable",
            "Energy": f"{energy:.1f} J" if energy is not None else "Unavailable",
            "Power": f"{power:.1f} W" if power is not None else "Unavailable",
            "Duration": f"{duration:.3f} s" if duration is not None else "Unavailable",
            "Frequency": f"{frequency_hz/1e6:.3f} MHz" if frequency_hz else "Unavailable",
            "Hotspot Check": hotspot,
        }

        mr = [
            ("Orientation", summary["Orientation"]),
            ("Frequency Direction", summary["Frequency Dir"]),
            ("Temperature RAW Frames", str(len(model.temperature_frames))),
            ("Magnitude RAW Frames", str(len(model.magnitude_frames))),
            ("MR Data Source", str(model.folder)),
        ]
        scan = [
            ("Sonication", str(sonication_number)),
            ("Power", summary["Power"]),
            ("Duration", summary["Duration"]),
            ("Energy", summary["Energy"]),
            ("Transducer Frequency", summary["Frequency"]),
            ("Hotspot Check Direction", hotspot),
            ("ACT Files", str(len(model.act_files))),
            ("SpectrumMsg Files", str(len(model.spectrum_files))),
        ]
        return SonicationMetadata(summary=summary, mr=mr, scan=scan)

    def _find_value(self, folder: Path, patterns: list[str]) -> str | None:
        compiled = [re.compile(p, re.I) for p in patterns]
        for path in sorted(folder.rglob("*")):
            if not path.is_file() or path.suffix.lower() not in {".log", ".txt", ".act", ".ini"}:
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for pattern in compiled:
                match = pattern.search(text)
                if match:
                    return match.group(1).strip().upper().replace("SAGITAL", "SAGITTAL").title()
        return None
