from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import math
import re


@dataclass(slots=True)
class SkullElement:
    number: int
    enabled: bool
    failure_reason: int
    values: dict[str, float] = field(default_factory=dict)


@dataclass(slots=True)
class SkullMeasuresData:
    source: Path | None = None
    elements: list[SkullElement] = field(default_factory=list)
    header: dict[str, str] = field(default_factory=dict)


class SkullMeasuresService:
    PARAMETERS = {
        "Element On/Off": 1,
        "Failure Reason": 2,
        "Phase Correction": 4,
        "Total Phase Shift": 5,
        "Outer Angle": 6,
        "Inner Angle": 7,
        "Skull Thickness": 8,
        "Air in Skull": 9,
        "Average Skull Velocity": 10,
        "Average Shear Velocity": 11,
        "Ray Shift": 12,
        "Critical Angle": 13,
        "Element X": 14,
        "Element Y": 15,
        "Element Z": 16,
        "Element-to-Skull Distance": 41,
        "Skull-to-Focal Distance": 42,
        "First Cortex Intensity": 43,
        "Second Cortex Intensity": 44,
        "Marrow Intensity": 45,
        "Element SDR": 46,
    }

    def find_and_read(self, folder: Path) -> SkullMeasuresData:
        candidates = sorted(folder.rglob("SkullMeasures*.log"))
        return self.read(candidates[0]) if candidates else SkullMeasuresData()

    def read(self, path: Path) -> SkullMeasuresData:
        result = SkullMeasuresData(source=path)
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            return result
        for line in lines:
            stripped = line.strip()
            if stripped.startswith("%"):
                for key, value in re.findall(r"([A-Za-z][A-Za-z0-9_ ]*?)\s*=\s*([^\t%]+)", stripped[1:]):
                    result.header[key.strip()] = value.strip()
                continue
            if not stripped or not stripped[0].isdigit():
                continue
            parts = stripped.split()
            if len(parts) < 47:
                continue
            try:
                raw = [float(x) for x in parts[:47]]
            except ValueError:
                continue
            values = {name: raw[index] for name, index in self.PARAMETERS.items() if index < len(raw)}
            result.elements.append(SkullElement(
                number=int(raw[0]), enabled=bool(int(raw[1])), failure_reason=int(raw[2]), values=values
            ))
        return result
