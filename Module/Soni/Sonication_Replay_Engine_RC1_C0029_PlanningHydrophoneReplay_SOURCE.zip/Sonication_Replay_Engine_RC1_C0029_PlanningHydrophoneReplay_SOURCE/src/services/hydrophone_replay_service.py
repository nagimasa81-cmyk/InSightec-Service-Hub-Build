from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import numpy as np

from src.integration.spectrum_provider import SpectrumMsgAnalyzerAdapter, SpectrumFrame
from src.domain.models import SonicationModel


@dataclass(slots=True)
class HydrophoneChannel:
    channel: int
    frames: list[SpectrumFrame] = field(default_factory=list)

    @property
    def label(self) -> str:
        return f"H{self.channel + 1}"

    @property
    def peak_amplitude(self) -> float | None:
        values = [max(frame.amplitude) for frame in self.frames if frame.amplitude]
        return float(max(values)) if values else None


@dataclass(slots=True)
class HydrophoneReplaySet:
    channels: list[HydrophoneChannel]
    source_files: list[Path]
    decoder_note: str

    @property
    def available_channel_count(self) -> int:
        return sum(1 for channel in self.channels if channel.frames)


class HydrophoneReplayService:
    """Build an eight-channel replay view from decoded SpectrumMsg records.

    The export does not label records with a public hydrophone schema. RC1 maps
    ordered records cyclically to H1..H8 and clearly reports that interpretation.
    """

    def build(self, sonication: SonicationModel, main_frequency_hz: float) -> HydrophoneReplaySet:
        adapter = SpectrumMsgAnalyzerAdapter(main_frequency_hz)
        frames = adapter.load(sonication.spectrum_files, source_kind="Sonication")
        channels = [HydrophoneChannel(index) for index in range(8)]
        for index, frame in enumerate(frames):
            channel_index = frame.channel if frame.channel is not None else index % 8
            channels[int(channel_index) % 8].frames.append(frame)
        return HydrophoneReplaySet(
            channels=channels,
            source_files=list(sonication.spectrum_files),
            decoder_note=(
                "Eight-channel ordering is reconstructed from SpectrumMsg record order (H1..H8 cyclic mapping). "
                "Channel identity remains diagnostic until the proprietary record header is fully decoded."
            ),
        )
