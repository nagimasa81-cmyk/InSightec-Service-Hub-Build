from __future__ import annotations

from pathlib import Path
import numpy as np

from src.core.spectrum_decoder import SharedSpectrumDecoder
from src.services.hydrophone_replay_service import CpcHydrophoneReplay, CpcHydrophoneFrame


class SpectrumMsgAggregateService:
    """Expose SpectrumMsg as one aggregate acoustic spectrum stream.

    This is intentionally *not* an RCV0-RCV7 CPC decoder.  Brain220 exports may
    contain exact SpectrumMsg FFT records while carrying no physical CPC pair.
    The Analyzer should still show the available spectrum/spectrogram, but must
    never invent eight receiver identities or raw A/D samples.
    """

    def build(self, path: Path, main_frequency_hz: float) -> CpcHydrophoneReplay:
        path=Path(path)
        decoded=SharedSpectrumDecoder().decode_frames(path,float(main_frequency_hz),channel_index=None)
        replay=CpcHydrophoneReplay(source_fft=path,source_raw=None,channel_count=1)
        replay.main_frequency_hz=float(main_frequency_hz)
        replay.raw_adc_available=False
        replay.raw_adc_unavailable_reason="SpectrumMsg contains aggregate FFT/history only; physical RCV raw A/D is not exported"
        replay.note="Embedded SpectrumMsg aggregate · no physical RCV0–RCV7 channel identity"
        replay.decoder_confidence="exact SpectrumMsg aggregate" if decoded else "failed"
        replay.declared_frame_count=len(decoded); replay.decoded_snapshot_count=len(decoded)
        replay.receiver_enabled=(True,False,False,False,False,False,False,False)
        replay.channel_reference_levels=[1.0]*8
        if decoded:
            replay.frequency_axis_source=str(decoded[0].frequency_axis_source)
            replay.frequency_start_hz=decoded[0].frequency_start_hz
            replay.frequency_spacing_hz=decoded[0].frequency_spacing_hz
            replay.frequency_end_hz=decoded[0].frequency_end_hz
        times=[]
        for i,row in enumerate(decoded):
            freq=np.asarray(row.frequency_hz,float)
            amp=np.asarray(row.amplitude,float)
            t=float(row.timestamp_seconds) if row.timestamp_seconds is not None and np.isfinite(row.timestamp_seconds) else None
            if t is not None: times.append(t)
            replay.frames.append(CpcHydrophoneFrame(
                index=i,frequency_hz=freq,channels=[amp],uncalibrated_channels=[amp],raw_channels=[],
                duration_s=0.0,acquisition_time_s=t,
            ))
        if replay.frames:
            peaks=[float(np.nanmax(np.abs(f.channels[0]))) for f in replay.frames if f.channels and np.asarray(f.channels[0]).size and np.isfinite(f.channels[0]).any()]
            if peaks:
                replay.channel_reference_levels[0]=max(max(peaks),np.finfo(float).tiny)
        if len(times)>=2:
            diffs=np.diff(np.asarray(times,float)); diffs=diffs[np.isfinite(diffs)&(diffs>0)]
            if diffs.size: replay.acquisition_interval_s=float(np.nanmedian(diffs))
        return replay
