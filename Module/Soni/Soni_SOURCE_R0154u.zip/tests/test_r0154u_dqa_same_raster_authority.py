from pathlib import Path
from types import SimpleNamespace

from src.services.dqa_focus_alignment_service import DqaFocusAlignment, DqaFocusAlignmentService


def _package():
    return SimpleNamespace(workspace=Path('.'), sonications=[SimpleNamespace(sonication_number=1)])


def test_same_raster_native_precedes_cross_stack_observed(monkeypatch):
    svc=DqaFocusAlignmentService()
    monkeypatch.setattr(svc,'is_dqa',lambda package: True)
    monkeypatch.setattr(svc,'_dqa_reference_geometry',lambda package: {'center_ras':(0.0,0.0,0.0),'evidence':[]})
    monkeypatch.setattr(svc,'_summary_focal_ras',lambda package: {1:(0.0,0.0,0.0)})
    monkeypatch.setattr(svc,'_dqa_exclusion_reason',lambda package,number,focal: None)
    monkeypatch.setattr(svc,'_image_native_alignment',lambda package,focal,number: DqaFocusAlignment(x_mm=0.4,y_mm=-0.3,z_mm=0.2,confidence='High',evidence=[]))
    def bad_observed(*args,**kwargs):
        raise AssertionError('cross-stack observed route must not run when same-raster evidence is valid')
    monkeypatch.setattr(svc,'_thermal_focus_ras_alignment',bad_observed)
    out=svc.analyze(_package(),0)
    assert (out.x_mm,out.y_mm,out.z_mm)==(0.4,-0.3,0.2)
    assert any('same-raster authority' in x for x in out.evidence)


def test_nonlocal_observed_is_not_returned_as_dqa_offset(monkeypatch):
    svc=DqaFocusAlignmentService()
    monkeypatch.setattr(svc,'is_dqa',lambda package: True)
    monkeypatch.setattr(svc,'_dqa_reference_geometry',lambda package: {'center_ras':(0.0,0.0,0.0),'evidence':[]})
    monkeypatch.setattr(svc,'_summary_focal_ras',lambda package: {1:(100.0,100.0,100.0)})
    monkeypatch.setattr(svc,'_dqa_exclusion_reason',lambda package,number,focal: None)
    monkeypatch.setattr(svc,'_image_native_alignment',lambda package,focal,number: None)
    monkeypatch.setattr(svc,'_thermal_focus_ras_alignment',lambda *args,**kwargs: DqaFocusAlignment(x_mm=-2.2,y_mm=-34.7,z_mm=-83.5,confidence='High',evidence=[]))
    monkeypatch.setattr(svc,'_focal_reference_frame_compatibility',lambda reference,focal: (False,['not same frame']))
    out=svc.analyze(_package(),0)
    assert out.x_mm is None and out.y_mm is None and out.z_mm is None
    assert out.confidence == 'Coordinate mismatch'
