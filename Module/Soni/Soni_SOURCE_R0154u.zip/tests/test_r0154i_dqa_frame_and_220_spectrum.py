from pathlib import Path
from types import SimpleNamespace
import struct
import numpy as np

from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService
from src.core.spectrum_decoder import SharedSpectrumDecoder


def _row_axial():
    return {
        'pixsizex':'1','pixsizey':'1',
        'rowdirectcosrasx':'0','rowdirectcosrasy':'-1','rowdirectcosrasz':'0',
        'coldirectcosrasx':'-1','coldirectcosrasy':'0','coldirectcosrasz':'0',
        'topleftcoordr':'128','topleftcoorda':'128','topleftcoords':'20',
    }


def _row_sagittal():
    return {
        'pixsizex':'1','pixsizey':'1',
        'rowdirectcosrasx':'0','rowdirectcosrasy':'0','rowdirectcosrasz':'-1',
        'coldirectcosrasx':'0','coldirectcosrasy':'-1','coldirectcosrasz':'0',
        'topleftcoordr':'0','topleftcoorda':'128','topleftcoords':'165',
    }


def test_dqa_coordinate_frame_gate_accepts_same_frame_point():
    reference={'validation_rows':[('axial',_row_axial()),('sagittal',_row_sagittal())]}
    ok,evidence=DqaFocusAlignmentService._focal_reference_frame_compatibility(reference,(-5.0,20.0,25.0))
    assert ok
    assert len(evidence)==2 and all('compatible' in x for x in evidence)


def test_dqa_coordinate_frame_gate_rejects_direct_subtraction_across_frames():
    reference={'validation_rows':[('axial',_row_axial()),('sagittal',_row_sagittal())]}
    # Mirrors the failure shape seen in R0154h: a point can produce a plausible
    # numeric subtraction but is tens/hundreds of mm away from the exported MR planes.
    ok,evidence=DqaFocusAlignmentService._focal_reference_frame_compatibility(reference,(-111.6,140.0,-43.0))
    assert not ok
    assert any('mismatch' in x for x in evidence)


def test_brain220_display_range_is_family_aware_source_contract():
    text=Path('src/core/current_spectrum_renderer.py').read_text(encoding='utf-8')
    assert 'def frequency_display_range' in text
    assert '0.18 <= main <= 0.32' in text
    assert 'main/2.0' in text


def test_embedded_650_style_axis_is_rejected_for_brain220(tmp_path: Path):
    dmp=tmp_path/'SpectrumMsg-1.dmp'; dmp.write_bytes(b'x')
    embedded=250_000.0 + np.arange(256)*1953.0
    freq,source=SharedSpectrumDecoder._axis_for_graph_values(dmp,230_000.0,embedded)
    assert float(freq[0]) < 230_000.0 < float(freq[-1])
    assert 'fallback' in source.lower()


def test_selection_clear_contract_removes_stale_spectrum():
    text=Path('src/ui/main_window.py').read_text(encoding='utf-8')
    block=text[text.index('def _clear_replay_display'):text.index('def _clear_study_reference_cache')]
    assert 'self.spectrum_channels={f"CH{i}":[] for i in range(8)}' in block
    assert 'self.chart_state.x_ranges.pop("spectrum",None)' in block


def test_analyze_suppresses_cross_frame_dqa_numbers(tmp_path: Path):
    yy,xx=np.indices((256,256)); cx,cy,r=128.0,105.0,48.0
    img=np.zeros((256,256),dtype=np.uint16)
    radial=np.hypot(xx-cx,yy-cy)
    img[np.abs(radial-r)<=2]=50000; img[radial<r-2]=12000
    img[145:148,45:211]=60000
    s1=tmp_path/'Sonication1'; s1.mkdir()
    img.tofile(s1/'7-1-0-0.raw'); img.tofile(s1/'12-1-0-0.raw')
    (tmp_path/'MriImageParams.xml').write_text('''<root xmlns:z="urn:schemas-microsoft-com:rowset">
      <z:row fieldindex="7" sonicationindex="1" seriesdiscription="DQA-Axial" pixsizex="1" pixsizey="1"
        rowdirectcosrasx="0" rowdirectcosrasy="-1" rowdirectcosrasz="0" coldirectcosrasx="-1" coldirectcosrasy="0" coldirectcosrasz="0"
        topleftcoordr="128" topleftcoorda="128" topleftcoords="20" />
      <z:row fieldindex="12" sonicationindex="1" seriesdiscription="DQA-Sagittal" pixsizex="1" pixsizey="1"
        rowdirectcosrasx="0" rowdirectcosrasy="0" rowdirectcosrasz="-1" coldirectcosrasx="0" coldirectcosrasy="-1" coldirectcosrasz="0"
        topleftcoordr="0" topleftcoorda="128" topleftcoords="165" />
    </root>''',encoding='utf-8')
    (tmp_path/'SonicationSummary.xml').write_text('''<root xmlns:z="urn:schemas-microsoft-com:rowset">
      <z:row sonicationindex="1" treatprotocol="Low-Energy-DQA" focalrasx="-111.6" focalrasy="140" focalrasz="-43" />
    </root>''',encoding='utf-8')
    package=SimpleNamespace(workspace=tmp_path,source=tmp_path/'case.zip',sonications=[SimpleNamespace(sonication_number=1,canonical_steering_xyz=None)])
    result=DqaFocusAlignmentService().analyze(package,0)
    assert result.x_mm is None and result.y_mm is None and result.z_mm is None
    assert result.excluded_reason == 'focal/phantom coordinate frames not registered'
    assert not result.alert
