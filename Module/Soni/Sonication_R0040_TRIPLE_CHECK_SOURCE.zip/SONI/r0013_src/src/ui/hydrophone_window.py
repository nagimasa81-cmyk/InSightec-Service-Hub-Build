from __future__ import annotations

from pathlib import Path

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import Qt, Signal, QTimer, QRectF
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QGridLayout, QHBoxLayout,
    QHeaderView, QLabel, QPushButton, QSlider, QSpinBox, QTabWidget,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget, QFileDialog,
    QMessageBox, QAbstractItemView
)

from src.services.hydrophone_replay_service import HydrophoneReplayService, CpcHydrophoneReplay
from src.services.spectrum_dump_import_service import SpectrumDumpImportService, SpectrumDumpCandidate
from src.services.standalone_cavitation_service import StandaloneCavitationService
from src.services.cavitation_control_timeline_service import CavitationControlTimelineService
from src.services.cavitation_likelihood_service import CavitationLikelihoodService


class SpectrumDumpPickerDialog(QDialog):
    """Choose one logical Spectrum measurement after ZIP/folder discovery."""
    def __init__(self, candidates: list[SpectrumDumpCandidate], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Select Spectrum dump")
        self.resize(980, 520)
        self.candidates = candidates
        layout = QVBoxLayout(self)
        info = QLabel(
            "Compatible Spectrum dumps were found. Select one measurement. "
            "RAW and _FFT companions are paired automatically when both are present."
        )
        info.setWordWrap(True); layout.addWidget(info)
        self.table = QTableWidget(len(candidates), 5)
        self.table.setHorizontalHeaderLabels(["Type", "File / measurement", "Available", "Location", "Size"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        for row, candidate in enumerate(candidates):
            size = sum(p.stat().st_size for p in (candidate.raw_path, candidate.fft_path) if p is not None and p.exists())
            values = [candidate.family, candidate.label, candidate.completeness, candidate.relative_path, f"{size/1024:.1f} KB"]
            for col, value in enumerate(values): self.table.setItem(row, col, QTableWidgetItem(str(value)))
        if candidates: self.table.selectRow(0)
        self.table.doubleClicked.connect(lambda _: self.accept())
        layout.addWidget(self.table, 1)
        buttons = QHBoxLayout(); buttons.addStretch(1)
        cancel = QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        use = QPushButton("Open selected"); use.setDefault(True); use.clicked.connect(self.accept)
        buttons.addWidget(cancel); buttons.addWidget(use); layout.addLayout(buttons)

    def selected_candidate(self) -> SpectrumDumpCandidate | None:
        row = self.table.currentRow()
        return self.candidates[row] if 0 <= row < len(self.candidates) else None


class EightHydrophoneWindow(QDialog):
    sonicationRequested = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("CPC Spectrum / 8CH Hydrophone Analyzer — R0039")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinMaxButtonsHint)
        self.resize(1500, 930)
        self.service = HydrophoneReplayService()
        self.dump_importer = SpectrumDumpImportService()
        self.standalone_cavitation_service = StandaloneCavitationService()
        self.control_timeline_service = CavitationControlTimelineService()
        self.likelihood_service = CavitationLikelihoodService()
        self.dump_source = None
        self.package = None
        self.source_entries = []
        self.replay: CpcHydrophoneReplay | None = None
        self.frame_index = 0
        self.timer = QTimer(self)
        self.cavitation_analysis = None
        self.observed_cavitation_timeline = None
        self.cavitation_likelihood = None
        self.timer.timeout.connect(lambda: self.set_frame(self.frame_index + 1))

        import_row = QHBoxLayout()
        self.open_loaded_export_btn = QPushButton("Select From Loaded Export")
        self.open_export_zip_btn = QPushButton("Open Export ZIP")
        self.open_dump_folder_btn = QPushButton("Open Folder")
        self.open_dump_file_btn = QPushButton("Open Spectrum File")
        self.analysis_mode_combo = QComboBox()
        self.analysis_mode_combo.addItems(["Auto Evidence-First", "SpectrumDumps Only", "Vendor Rule + Dump"])
        self.analysis_mode_combo.setToolTip("SpectrumDumps Only never requires the treatment Export. Vendor actions are shown only when the matching INI is available.")
        self.candidate_z = QDoubleSpinBox(); self.candidate_z.setRange(2.0, 20.0); self.candidate_z.setDecimals(1); self.candidate_z.setValue(6.0); self.candidate_z.setSuffix(" σ")
        self.analysis_mode_combo.currentIndexChanged.connect(self._refresh_cavitation_analysis)
        self.candidate_z.valueChanged.connect(self._refresh_cavitation_analysis)
        self.open_loaded_export_btn.clicked.connect(self._open_loaded_export)
        self.open_export_zip_btn.clicked.connect(self._open_export_zip)
        self.open_dump_folder_btn.clicked.connect(self._open_dump_folder)
        self.open_dump_file_btn.clicked.connect(self._open_dump_file)
        self.open_loaded_export_btn.setEnabled(False)
        self.open_loaded_export_btn.setToolTip("Choose a Spectrum dump already extracted from the Export loaded in Sonication Analysis")
        import_row.addWidget(self.open_loaded_export_btn)
        import_row.addWidget(self.open_export_zip_btn); import_row.addWidget(self.open_dump_folder_btn); import_row.addWidget(self.open_dump_file_btn)
        import_row.addWidget(QLabel("Cavitation mode")); import_row.addWidget(self.analysis_mode_combo)
        import_row.addWidget(QLabel("Candidate threshold")); import_row.addWidget(self.candidate_z)
        import_row.addStretch(1)

        top = QHBoxLayout()
        self.sonication_combo = QComboBox()
        self.sonication_combo.currentIndexChanged.connect(self._sonication_changed)
        self.channel_spin = QSpinBox(); self.channel_spin.setRange(0, 7)
        self.channel_spin.valueChanged.connect(self._refresh_all)
        self.source_label = QLabel("No CPC source loaded")
        self.source_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        top.addWidget(QLabel("Sonication")); top.addWidget(self.sonication_combo)
        top.addWidget(QLabel("Analysis CH")); top.addWidget(self.channel_spin)
        top.addWidget(self.source_label, 1)

        self.note = QLabel("No data")
        self.note.setWordWrap(True)

        self.tabs = QTabWidget()
        self.raw_tab = self._build_raw_tab()
        self.spectrum_tab = self._build_spectrum_tab()
        self.spectrogram_tab = self._build_spectrogram_tab()
        self.band_tab = self._build_band_tab()
        self.vendor_cavitation_tab = self._build_vendor_cavitation_tab()
        self.cavitation_events_tab = self._build_cavitation_events_tab()
        self.navigator_tab = self._build_navigator_tab()
        self.tabs.addTab(self.raw_tab, "Measurement Timeline / Raw A/D")
        self.tabs.addTab(self.spectrum_tab, "Spectrum")
        self.tabs.addTab(self.spectrogram_tab, "Spectrogram")
        self.tabs.addTab(self.band_tab, "Band Energy")
        self.tabs.addTab(self.vendor_cavitation_tab, "CGA Cavitation / Vendor Rules")
        self.tabs.addTab(self.cavitation_events_tab, "Cavitation Events")
        self.tabs.addTab(self.navigator_tab, "Measure / Statistics")

        controls = QHBoxLayout()
        self.first_btn = QPushButton("|◀")
        self.prev_btn = QPushButton("◀")
        self.play_btn = QPushButton("▶")
        self.next_btn = QPushButton("▶")
        self.last_btn = QPushButton("▶|")
        self.first_btn.clicked.connect(lambda: self.set_frame(0))
        self.prev_btn.clicked.connect(lambda: self.set_frame(self.frame_index - 1))
        self.next_btn.clicked.connect(lambda: self.set_frame(self.frame_index + 1))
        self.last_btn.clicked.connect(lambda: self.set_frame(len(self.replay.frames)-1 if self.replay else 0))
        self.play_btn.clicked.connect(self._toggle_play)
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.valueChanged.connect(self.set_frame)
        self.measure_spin = QSpinBox(); self.measure_spin.setRange(1, 1)
        self.measure_spin.valueChanged.connect(lambda v: self.set_frame(v - 1))
        self.frame_label = QLabel("Measure - / - · Time -")
        controls.addWidget(self.first_btn); controls.addWidget(self.prev_btn)
        controls.addWidget(self.play_btn); controls.addWidget(self.next_btn); controls.addWidget(self.last_btn)
        controls.addWidget(self.slider, 1)
        controls.addWidget(QLabel("Measure #")); controls.addWidget(self.measure_spin)
        controls.addWidget(self.frame_label)

        layout = QVBoxLayout(self)
        layout.addLayout(import_row)
        layout.addLayout(top)
        layout.addWidget(self.note)
        layout.addWidget(self.tabs, 1)
        layout.addLayout(controls)
        self.setAcceptDrops(True)

    def _plot(self, bottom: str, left: str) -> pg.PlotWidget:
        plot = pg.PlotWidget()
        plot.showGrid(x=True, y=True, alpha=.25)
        plot.setLabel("bottom", bottom)
        plot.setLabel("left", left)
        return plot

    def _build_raw_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout()
        self.raw_mode = QComboBox(); self.raw_mode.addItems(["Overlay 8CH", "Single CH", "8 Panels"])
        self.raw_mode.currentIndexChanged.connect(self._rebuild_raw_plots)
        self.raw_scale = QComboBox(); self.raw_scale.addItems(["Auto", "Common symmetric"])
        self.raw_scale.currentIndexChanged.connect(self._draw_raw)
        row.addWidget(QLabel("Display")); row.addWidget(self.raw_mode)
        row.addWidget(QLabel("Y scale")); row.addWidget(self.raw_scale); row.addStretch(1)
        layout.addLayout(row)
        self.raw_host = QWidget(); self.raw_layout = QGridLayout(self.raw_host); self.raw_layout.setContentsMargins(0,0,0,0)
        layout.addWidget(self.raw_host, 1)
        self.raw_plots: list[pg.PlotWidget] = []
        self._rebuild_raw_plots()
        return page

    def _build_spectrum_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout()
        self.spectrum_mode = QComboBox(); self.spectrum_mode.addItems(["Overlay 8CH", "Single CH", "8 Panels"])
        self.spectrum_mode.currentIndexChanged.connect(self._rebuild_spectrum_plots)
        self.spectrum_value_mode = QComboBox()
        self.spectrum_value_mode.addItems(["Calibrated absolute", "Raw absolute", "Raw + calibrated", "Relative dB"])
        self.spectrum_value_mode.currentIndexChanged.connect(self._draw_spectrum)
        self.db_floor = QSpinBox(); self.db_floor.setRange(-180, -20); self.db_floor.setValue(-100)
        self.db_floor.valueChanged.connect(self._draw_spectrum)
        row.addWidget(QLabel("Display")); row.addWidget(self.spectrum_mode)
        row.addWidget(QLabel("Values")); row.addWidget(self.spectrum_value_mode)
        row.addWidget(QLabel("Floor")); row.addWidget(self.db_floor); row.addWidget(QLabel("dB")); row.addStretch(1)
        layout.addLayout(row)
        self.spectrum_host = QWidget(); self.spectrum_layout = QGridLayout(self.spectrum_host); self.spectrum_layout.setContentsMargins(0,0,0,0)
        layout.addWidget(self.spectrum_host, 1)
        self.spectrum_plots: list[pg.PlotWidget] = []
        self._rebuild_spectrum_plots()
        return page

    def _build_spectrogram_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout()
        self.spec_min = QDoubleSpinBox(); self.spec_min.setRange(0.0, 10.0); self.spec_min.setDecimals(3); self.spec_min.setValue(0.20); self.spec_min.setSuffix(" MHz")
        self.spec_max = QDoubleSpinBox(); self.spec_max.setRange(0.0, 10.0); self.spec_max.setDecimals(3); self.spec_max.setValue(1.00); self.spec_max.setSuffix(" MHz")
        self.spec_min.valueChanged.connect(self._draw_spectrogram); self.spec_max.valueChanged.connect(self._draw_spectrogram)
        row.addWidget(QLabel("Frequency range")); row.addWidget(self.spec_min); row.addWidget(QLabel("to")); row.addWidget(self.spec_max); row.addStretch(1)
        layout.addLayout(row)
        self.spectrogram_plot = pg.PlotWidget()
        self.spectrogram_plot.setLabel("bottom", "Time", "s")
        self.spectrogram_plot.setLabel("left", "Frequency", "MHz")
        self.spectrogram_image = pg.ImageItem(axisOrder="row-major")
        self.spectrogram_plot.addItem(self.spectrogram_image)
        self.spectrogram_plot.setMouseEnabled(x=True, y=True)
        layout.addWidget(self.spectrogram_plot, 1)
        return page

    def _build_band_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        controls = QGridLayout()
        self.band_enabled: list[QCheckBox] = []
        self.band_low: list[QDoubleSpinBox] = []
        self.band_high: list[QDoubleSpinBox] = []
        for i, (low, high) in enumerate(self.service.DEFAULT_BANDS_MHZ):
            enabled = QCheckBox(f"Band {i}"); enabled.setChecked(i == 0)
            lo = QDoubleSpinBox(); lo.setRange(0.0, 10.0); lo.setDecimals(3); lo.setValue(low); lo.setSuffix(" MHz")
            hi = QDoubleSpinBox(); hi.setRange(0.0, 10.0); hi.setDecimals(3); hi.setValue(high); hi.setSuffix(" MHz")
            enabled.toggled.connect(self._draw_band_energy); lo.valueChanged.connect(self._draw_band_energy); hi.valueChanged.connect(self._draw_band_energy)
            controls.addWidget(enabled, i//3, (i%3)*3)
            controls.addWidget(lo, i//3, (i%3)*3+1)
            controls.addWidget(hi, i//3, (i%3)*3+2)
            self.band_enabled.append(enabled); self.band_low.append(lo); self.band_high.append(hi)
        layout.addLayout(controls)
        self.band_plot = self._plot("Time (s)", "Relative band energy (dB)")
        layout.addWidget(self.band_plot, 1)
        return page

    def _build_vendor_cavitation_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        self.vendor_profile_label = QLabel("Vendor cavitation rules are not loaded")
        self.vendor_profile_label.setWordWrap(True)
        self.vendor_profile_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(self.vendor_profile_label)
        self.vendor_band_table = QTableWidget(4, 5)
        self.vendor_band_table.setHorizontalHeaderLabels(["Band", "Ratio × f0", "± Δ", "Frequency range", "Meaning / evidence"])
        self.vendor_band_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.vendor_band_table.verticalHeader().setVisible(False)
        self.vendor_band_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.vendor_band_table, 0)
        self.vendor_energy_plot = self._plot("Acquisition time (s)", "Vendor energy")
        self.vendor_energy_plot.setTitle("Vendor band energy reproduction: Band0 continuous, Band1 log-exact, Band2 threshold events")
        layout.addWidget(self.vendor_energy_plot, 1)
        self.vendor_rule_plot = self._plot("Acquisition time (s)", "CGA Display Rule")
        self.vendor_rule_plot.setTitle("CGA / Acquisition Display Rule 1 and Rule 2")
        layout.addWidget(self.vendor_rule_plot, 1)
        self.vendor_control_table = QTableWidget(0, 6)
        self.vendor_control_table.setHorizontalHeaderLabels(["Family", "Rule", "Weighted input", "Threshold", "Action / persistence", "Runtime evidence"])
        self.vendor_control_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.vendor_control_table.verticalHeader().setVisible(False)
        self.vendor_control_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.vendor_control_table, 0)
        self.vendor_power_plot = self._plot("Acquisition time (s)", "Power ratio")
        self.vendor_power_plot.setTitle("Cavitation control response — actual vs INI-rule reproduction")
        layout.addWidget(self.vendor_power_plot, 1)
        return page

    def _build_cavitation_events_tab(self) -> QWidget:
        page=QWidget(); layout=QVBoxLayout(page)
        self.cavitation_evidence_label=QLabel(
            "SpectrumDumps-only analysis uses the embedded 8CH × 4-band energy table. "
            "Without CavitationSafetyAndControl.ini, detections are labelled Candidate and no vendor power/stop action is inferred."
        )
        self.cavitation_evidence_label.setWordWrap(True); layout.addWidget(self.cavitation_evidence_label)
        self.cavitation_observed_label = QLabel("Observed cavitation-control timeline is not loaded yet.")
        self.cavitation_observed_label.setWordWrap(True)
        layout.addWidget(self.cavitation_observed_label)
        self.cavitation_control_plot = self._plot("Session time (s)", "Power ratio / event")
        self.cavitation_control_plot.setTitle("Cavitation control timeline — observed actions and power response")
        self.cavitation_control_plot.addLegend(offset=(8, 8))
        layout.addWidget(self.cavitation_control_plot, 1)
        self.cavitation_observed_table = QTableWidget(0, 11)
        self.cavitation_observed_table.setHorizontalHeaderLabels(["Time", "Cycle", "Rule", "State", "Weighted", "Threshold", "Dominant", "Contributors", "Power", "Result", "Evidence"])
        self.cavitation_observed_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.cavitation_observed_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.cavitation_observed_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.cavitation_observed_table.cellDoubleClicked.connect(self._observed_cavitation_event_selected)
        self.cavitation_observed_table.itemSelectionChanged.connect(self._update_cavitation_likelihood)
        layout.addWidget(self.cavitation_observed_table, 1)
        self.cavitation_likelihood_label = QLabel("Cavitation likelihood map not calculated yet.")
        self.cavitation_likelihood_label.setWordWrap(True)
        layout.addWidget(self.cavitation_likelihood_label)
        self.cavitation_likelihood_plot = pg.PlotWidget(title="Probable cavitation region from hydrophone contribution pattern")
        self.cavitation_likelihood_plot.setLabel("bottom", "Right  ← normalized geometry →  Left")
        self.cavitation_likelihood_plot.setLabel("left", "Posterior  ← normalized geometry →  Anterior")
        self.cavitation_likelihood_plot.setAspectLocked(True)
        self.cavitation_likelihood_image = pg.ImageItem(axisOrder="row-major")
        self.cavitation_likelihood_plot.addItem(self.cavitation_likelihood_image)
        self.cavitation_likelihood_plot.showGrid(x=True, y=True, alpha=0.25)
        layout.addWidget(self.cavitation_likelihood_plot, 1)
        self.cavitation_likelihood_table = QTableWidget(0, 3)
        self.cavitation_likelihood_table.setHorizontalHeaderLabels(["Hydrophone", "Contribution", "Role"])
        self.cavitation_likelihood_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.cavitation_likelihood_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.cavitation_likelihood_table, 1)
        self.cavitation_heatmap_plot=pg.PlotWidget(title="Cavitation activity — Hydrophone × Band over FFT snapshots")
        self.cavitation_heatmap_plot.setLabel("bottom","FFT snapshot")
        self.cavitation_heatmap_plot.setLabel("left","CH/Band row")
        self.cavitation_heatmap_image=pg.ImageItem(axisOrder="row-major")
        self.cavitation_heatmap_plot.addItem(self.cavitation_heatmap_image)
        layout.addWidget(self.cavitation_heatmap_plot,1)
        self.cavitation_event_table=QTableWidget(0,10)
        self.cavitation_event_table.setHorizontalHeaderLabels(["Snapshot","Cycle","Time","Hydrophone","Band","Energy","Baseline/Limit","Score","Detection","Processing / Result"])
        self.cavitation_event_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.cavitation_event_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.cavitation_event_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.cavitation_event_table.cellDoubleClicked.connect(self._cavitation_event_selected)
        self.cavitation_event_table.itemSelectionChanged.connect(self._update_cavitation_likelihood)
        layout.addWidget(self.cavitation_event_table,1)
        return page

    def _cavitation_event_selected(self,row:int,_column:int):
        item=self.cavitation_event_table.item(row,0)
        if item is None: return
        try: self.set_frame(max(0,int(item.text())-1))
        except ValueError: pass

    def _observed_cavitation_event_selected(self,row:int,_column:int):
        if self.observed_cavitation_timeline is None or not (0 <= row < len(self.observed_cavitation_timeline.events)) or not self.replay:
            return
        event = self.observed_cavitation_timeline.events[row]
        if event.cycle is not None:
            for idx, frame in enumerate(self.replay.frames):
                if getattr(frame, "acquisition_cycle", None) == event.cycle:
                    self.set_frame(idx)
                    return
        if event.timestamp_s is not None and self.replay.frames:
            times = np.asarray([float(getattr(f, "acquisition_time_s", np.nan)) for f in self.replay.frames], float)
            if np.isfinite(times).any():
                idx = int(np.nanargmin(np.abs(times - float(event.timestamp_s))))
                self.set_frame(idx)

    def _draw_observed_cavitation_timeline(self):
        if not hasattr(self, "cavitation_control_plot"):
            return
        self.cavitation_control_plot.clear()
        self.cavitation_control_plot.addLegend(offset=(8, 8))
        timeline = self.observed_cavitation_timeline
        self.cavitation_observed_table.setRowCount(0)
        if timeline is None:
            self.cavitation_observed_label.setText("Observed cavitation-control timeline is unavailable.")
            return
        self.cavitation_observed_label.setText(timeline.summary)
        if timeline.actual_power_times_s.size and timeline.actual_power_ratio.size:
            self.cavitation_control_plot.plot(timeline.actual_power_times_s, timeline.actual_power_ratio, pen=pg.mkPen("#ffffff", width=2.5), symbol="o", symbolSize=4, name="Observed ExPowerRatio")
        if timeline.predicted_power_times_s.size and timeline.predicted_power_ratio.size:
            self.cavitation_control_plot.plot(timeline.predicted_power_times_s, timeline.predicted_power_ratio, pen=pg.mkPen("#06d6a0", width=1.5, style=Qt.PenStyle.DashLine), name="Reconstructed ExPowerRatio")
        family_points = {}
        for ev in timeline.events:
            t = float(ev.timestamp_s) if ev.timestamp_s is not None else ((float(ev.cycle)-1.0)*0.010 if ev.cycle is not None else float('nan'))
            if not np.isfinite(t):
                continue
            family_points.setdefault(ev.family, [[], []])
            y = 1.0
            if ev.after_power_ratio is not None and np.isfinite(ev.after_power_ratio):
                y = float(ev.after_power_ratio)
            elif ev.before_power_ratio is not None and np.isfinite(ev.before_power_ratio):
                y = float(ev.before_power_ratio)
            family_points[ev.family][0].append(t); family_points[ev.family][1].append(y)
        style = {"Increase": ("t", "#06d6a0"), "Decrease": ("o", "#ffd166"), "Safety": ("s", "#f72585")}
        for family, (xs, ys) in family_points.items():
            symbol, color = style.get(family, ("d", "#4cc9f0"))
            self.cavitation_control_plot.plot(xs, ys, pen=None, symbol=symbol, symbolSize=9, symbolBrush=color, name=f"{family} event")
        self.cavitation_observed_table.setRowCount(len(timeline.events))
        for r, ev in enumerate(timeline.events):
            t = '-' if ev.timestamp_s is None else f"{ev.timestamp_s:.3f} s"
            cycle = '-' if ev.cycle is None else str(ev.cycle)
            rule = f"{ev.family} {ev.rule_index}"
            state = ev.severity
            weighted = '-' if ev.weighted_energy is None or not np.isfinite(ev.weighted_energy) else f"{ev.weighted_energy:.6g}"
            thr_parts = []
            if ev.threshold is not None and np.isfinite(ev.threshold): thr_parts.append(f"max {ev.threshold:.6g}")
            if ev.critical_threshold is not None and np.isfinite(ev.critical_threshold): thr_parts.append(f"critical {ev.critical_threshold:.6g}")
            threshold = ' / '.join(thr_parts) if thr_parts else '-'
            dominant = '-'
            if ev.dominant_channel is not None:
                band_txt = f"/B{ev.dominant_band}" if ev.dominant_band is not None else ''
                val_txt = '' if ev.dominant_energy is None or not np.isfinite(ev.dominant_energy) else f" ({ev.dominant_energy:.4g})"
                dominant = f"H{ev.dominant_channel+1}{band_txt}{val_txt}"
            contributors = '-'
            if ev.contributing_channels or ev.contributing_bands:
                contributors = f"H{','.join(str(ch+1) for ch in ev.contributing_channels) if ev.contributing_channels else '-'} / B{','.join(str(b) for b in ev.contributing_bands) if ev.contributing_bands else '-'}"
            power = '-'
            if ev.before_power_ratio is not None or ev.after_power_ratio is not None:
                before = '?' if ev.before_power_ratio is None or not np.isfinite(ev.before_power_ratio) else f"{ev.before_power_ratio:.3f}"
                after = '?' if ev.after_power_ratio is None or not np.isfinite(ev.after_power_ratio) else f"{ev.after_power_ratio:.3f}"
                power = f"{before} → {after}"
            result = ev.result or ev.action or '-'
            values = [t, cycle, rule, state, weighted, threshold, dominant, contributors, power, result, ev.evidence or '-']
            for c, value in enumerate(values):
                self.cavitation_observed_table.setItem(r, c, QTableWidgetItem(str(value)))

    def _selected_observed_cavitation_event(self):
        if self.observed_cavitation_timeline is None or not hasattr(self, "cavitation_observed_table"):
            return None
        row = self.cavitation_observed_table.currentRow()
        if 0 <= row < len(self.observed_cavitation_timeline.events):
            return self.observed_cavitation_timeline.events[row]
        return None

    def _draw_cavitation_likelihood(self):
        if not hasattr(self, "cavitation_likelihood_plot"):
            return
        self.cavitation_likelihood_plot.clear()
        self.cavitation_likelihood_plot.addItem(self.cavitation_likelihood_image)
        self.cavitation_likelihood_table.setRowCount(0)
        result = self.cavitation_likelihood
        if result is None or result.likelihood_map.size == 0:
            self.cavitation_likelihood_label.setText("Cavitation likelihood map is unavailable for the current evidence.")
            self.cavitation_likelihood_image.setImage(np.empty((0, 0)))
            return
        self.cavitation_likelihood_label.setText(
            result.summary + "\n" + result.evidence +
            "\nInterpretation: this is a probable region, not a single-point localization."
        )
        shown = np.asarray(result.likelihood_map, float)
        self.cavitation_likelihood_image.setImage(shown, autoLevels=False, levels=(0, 1))
        self.cavitation_likelihood_image.setRect(QRectF(float(result.x_coords[0]), float(result.y_coords[0]), float(result.x_coords[-1] - result.x_coords[0]), float(result.y_coords[-1] - result.y_coords[0])))
        # Outline schematic head/focus area
        theta = np.linspace(0, 2*np.pi, 240)
        self.cavitation_likelihood_plot.plot(np.cos(theta), np.sin(theta), pen=pg.mkPen("#aaaaaa", width=1.0), name="Receiver ring")
        fx, fy = result.focus_xy
        self.cavitation_likelihood_plot.plot([fx], [fy], pen=None, symbol="+", symbolSize=14, symbolPen=pg.mkPen("#ffffff", width=2), name="Focus")
        pos = np.asarray(result.hydrophone_positions, float)
        dom = result.dominant_channel
        for ch in range(pos.shape[0]):
            color = "#f72585" if dom is not None and ch == dom else "#ffd166" if result.per_channel_scores[ch] > 0 else "#4cc9f0"
            size = 12 if dom is not None and ch == dom else 9
            self.cavitation_likelihood_plot.plot([pos[ch,0]], [pos[ch,1]], pen=None, symbol="o", symbolSize=size, symbolBrush=color, symbolPen=pg.mkPen("#000000", width=1.0))
            txt = pg.TextItem(f"H{ch+1}", color="#ffffff", anchor=(0.5, 1.2))
            txt.setPos(float(pos[ch,0]), float(pos[ch,1]))
            self.cavitation_likelihood_plot.addItem(txt)
        if result.centroid_xy is not None:
            cx, cy = result.centroid_xy
            self.cavitation_likelihood_plot.plot([cx], [cy], pen=None, symbol="x", symbolSize=14, symbolPen=pg.mkPen("#06d6a0", width=3), name="Likelihood centroid")
        rows = np.argsort(-result.per_channel_scores)
        positive = [int(r) for r in rows if result.per_channel_scores[int(r)] > 0]
        self.cavitation_likelihood_table.setRowCount(max(len(positive), 8))
        filled = positive if positive else list(range(8))
        for r, ch in enumerate(filled):
            role = "Dominant" if dom is not None and ch == dom else "Contributing" if result.per_channel_scores[ch] > 0.01 else "Low"
            vals = [f"H{ch+1}", f"{100*result.per_channel_scores[ch]:.1f}%", role]
            for c, v in enumerate(vals):
                self.cavitation_likelihood_table.setItem(r, c, QTableWidgetItem(v))

    def _update_cavitation_likelihood(self):
        if not self.replay or not hasattr(self, "cavitation_likelihood_plot"):
            return
        observed_event = self._selected_observed_cavitation_event()
        self.cavitation_likelihood = self.likelihood_service.estimate(self.replay, self.frame_index, observed_event)
        self._draw_cavitation_likelihood()

    def _refresh_cavitation_analysis(self,*_):
        if not hasattr(self,"cavitation_event_table"):
            return
        self.cavitation_event_table.setRowCount(0)
        if hasattr(self, "cavitation_observed_table"):
            self.cavitation_observed_table.setRowCount(0)
        if not self.replay:
            self.cavitation_evidence_label.setText("No Spectrum dump loaded.")
            if hasattr(self, "cavitation_observed_label"):
                self.cavitation_observed_label.setText("Observed cavitation-control timeline is unavailable.")
            self.cavitation_heatmap_image.setImage(np.empty((0,0)))
            self.cavitation_likelihood = None
            self._draw_cavitation_likelihood()
            return
        requested=self.analysis_mode_combo.currentText() if hasattr(self,"analysis_mode_combo") else "Auto Evidence-First"
        analysis=self.standalone_cavitation_service.analyze(self.replay,requested,float(self.candidate_z.value()))
        self.cavitation_analysis=analysis
        self.cavitation_evidence_label.setText(
            f"Mode: {analysis.mode}\nTiming: {analysis.timing_status}\nBands: {analysis.band_status}\nRules: {analysis.rule_status}\n{analysis.summary}"
        )
        cube=np.asarray(analysis.robust_z_cube,float)
        if cube.size:
            # Flatten CH0/B0..B3, CH1/B0..B3 ... into 32 rows; positive robust
            # excursions are the useful dump-only activity visualization.
            img=np.transpose(cube,(1,2,0)).reshape(32,cube.shape[0])
            shown=np.where(np.isfinite(img),np.clip(img,0,12),0)
            self.cavitation_heatmap_image.setImage(shown,autoLevels=False,levels=(0,12))
            self.cavitation_heatmap_image.setRect(QRectF(0,0,max(cube.shape[0],1),32))
        else:
            self.cavitation_heatmap_image.setImage(np.empty((0,0)))
        self.cavitation_event_table.setRowCount(len(analysis.events))
        for r,event in enumerate(analysis.events):
            hydro="Combined" if event.channel < 0 else f"H{event.channel+1}"
            band="Combined" if event.band < 0 else f"Band{event.band}"
            time="-" if event.time_s is None else f"{event.time_s:.3f} s"
            cycle="-" if event.acquisition_cycle is None else str(event.acquisition_cycle)
            base="-" if event.baseline is None or not np.isfinite(event.baseline) else f"{event.baseline:.6g}"
            score="-" if event.robust_z is None or not np.isfinite(event.robust_z) else f"{event.robust_z:.1f} σ"
            detection=event.severity if not event.rule else f"{event.severity}: {event.rule}"
            result=event.evidence if not event.action else f"{event.evidence} → {event.action}"
            values=[str(event.snapshot_index+1),cycle,time,hydro,band,f"{event.energy:.6g}",base,score,detection,result]
            for c,value in enumerate(values): self.cavitation_event_table.setItem(r,c,QTableWidgetItem(value))

    def _build_navigator_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page)
        self.packet_label = QLabel("No measure selected")
        layout.addWidget(self.packet_label)
        self.stats_table = QTableWidget(8, 9)
        self.stats_table.setHorizontalHeaderLabels(["CH", "Raw A/D peak", "Raw A/D RMS", "Dominant MHz", "Peak dB", "Band energy", "Raw spectrum peak", "Cal spectrum peak", "Coef @ f0"])
        self.stats_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.stats_table.verticalHeader().setVisible(False)
        layout.addWidget(self.stats_table, 1)
        return page

    def _clear_layout(self, layout: QGridLayout) -> None:
        while layout.count():
            item = layout.takeAt(0); widget = item.widget()
            if widget: widget.deleteLater()

    def _rebuild_raw_plots(self) -> None:
        if not hasattr(self, "raw_layout"): return
        self._clear_layout(self.raw_layout); self.raw_plots = []
        mode = self.raw_mode.currentText()
        count = 8 if mode == "8 Panels" else 1
        for i in range(count):
            plot = self._plot("Measurement time (s)", "History value")
            if count == 8:
                plot.setTitle(f"CH{i}"); self.raw_layout.addWidget(plot, i//4, i%4)
            else:
                self.raw_layout.addWidget(plot, 0, 0)
            self.raw_plots.append(plot)
        self._draw_raw()

    def _rebuild_spectrum_plots(self) -> None:
        if not hasattr(self, "spectrum_layout"): return
        self._clear_layout(self.spectrum_layout); self.spectrum_plots = []
        mode = self.spectrum_mode.currentText()
        count = 8 if mode == "8 Panels" else 1
        for i in range(count):
            plot = self._plot("Frequency (MHz)", "Relative level (dB)")
            plot.setXRange(0.0, 1.0, padding=0.0)
            if count == 8:
                plot.setTitle(f"CH{i}"); self.spectrum_layout.addWidget(plot, i//4, i%4)
            else:
                self.spectrum_layout.addWidget(plot, 0, 0)
            self.spectrum_plots.append(plot)
        self._draw_spectrum()

    def _open_loaded_export(self):
        if self.package is None:
            QMessageBox.information(
                self, "Spectrum Dump Analyzer",
                "No Export is currently loaded in Sonication Analysis."
            )
            return
        self.open_loaded_workspace(self.package.workspace)

    def _open_export_zip(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "Open Export ZIP", "", "ZIP files (*.zip)")
        if file_name: self.open_dump_source(Path(file_name))

    def _open_dump_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Open folder containing Spectrum dumps")
        if folder: self.open_dump_source(Path(folder))

    def _open_dump_file(self):
        file_name, _ = QFileDialog.getOpenFileName(
            self, "Open Spectrum dump", "",
            "Spectrum dumps (*.dmp *.dmp_FFT);;All files (*.*)"
        )
        if file_name: self.open_dump_source(Path(file_name))

    def open_loaded_workspace(self, workspace: Path, *, auto_pick: bool = False) -> bool:
        """Use Spectrum files from the Export workspace already loaded by Sonication Analysis.

        No ZIP is extracted a second time.  The existing Replay workspace is scanned
        recursively, candidates are paired exactly as in standalone import, and the
        user can choose the logical Spectrum measurement to display.
        """
        workspace = Path(workspace).resolve()
        try:
            candidates = self.dump_importer.discover(workspace)
        except Exception as exc:
            QMessageBox.critical(self, "Spectrum Dump Analyzer", str(exc))
            return False
        if not candidates:
            QMessageBox.information(
                self, "Spectrum Dump Analyzer",
                "No compatible Spectrum*.dmp / Spectrum*.dmp_FFT file was found in the loaded Export."
            )
            return False

        candidate = candidates[0]
        if len(candidates) > 1 and not auto_pick:
            picker = SpectrumDumpPickerDialog(candidates, self)
            picker.setWindowTitle("Select Spectrum dump from loaded Export")
            if picker.exec() != QDialog.DialogCode.Accepted:
                return False
            candidate = picker.selected_candidate()
            if candidate is None:
                return False

        # This source only references the already-owned Sonication Analysis
        # workspace.  It must never be deleted by the Spectrum importer.
        from src.services.spectrum_dump_import_service import SpectrumDumpSource
        self.dump_source = SpectrumDumpSource(
            source=workspace, workspace=workspace, candidates=candidates, temporary=False
        )
        self.sonication_combo.blockSignals(True); self.sonication_combo.clear()
        for i, item in enumerate(candidates):
            self.sonication_combo.addItem(f"{item.family}: {item.label} [{item.completeness}]", i)
        selected_index = candidates.index(candidate)
        self.sonication_combo.setCurrentIndex(selected_index); self.sonication_combo.blockSignals(False)
        self.load_dump_candidate(selected_index)
        return True

    def open_dump_source(self, source: Path):
        try:
            result = self.dump_importer.open_source(source)
        except Exception as exc:
            QMessageBox.critical(self, "Spectrum Dump Analyzer", str(exc)); return
        if not result.candidates:
            QMessageBox.information(
                self, "Spectrum Dump Analyzer",
                "No compatible Spectrum*.dmp / Spectrum*.dmp_FFT file was found."
            ); return
        candidate = result.candidates[0]
        if len(result.candidates) > 1:
            picker = SpectrumDumpPickerDialog(result.candidates, self)
            if picker.exec() != QDialog.DialogCode.Accepted:
                return
            candidate = picker.selected_candidate()
            if candidate is None: return
        self.dump_source = result
        # Keep any loaded Sonication Analysis package as reusable context so
        # the user can return to "Select From Loaded Export" without loading
        # the treatment ZIP again.
        self.sonication_combo.blockSignals(True); self.sonication_combo.clear()
        for i, item in enumerate(result.candidates):
            self.sonication_combo.addItem(f"{item.family}: {item.label} [{item.completeness}]", i)
        selected_index = result.candidates.index(candidate)
        self.sonication_combo.setCurrentIndex(selected_index); self.sonication_combo.blockSignals(False)
        self.load_dump_candidate(selected_index)

    def load_dump_candidate(self, index: int):
        if self.dump_source is None or not (0 <= index < len(self.dump_source.candidates)): return
        candidate = self.dump_source.candidates[index]
        if candidate.family == "SpectrumMsg":
            self.replay = None
            self.source_label.setText(f"SpectrumMsg: {candidate.primary_path.name}")
            self.note.setText(
                "SpectrumMsg is a reduced workstation/message stream. It is detected and selectable, "
                "but this independent 8CH CPC view does not invent channel identities from it. "
                "Use the main Sonication Spectrum view for SpectrumMsg analysis."
            )
            self.slider.setRange(0, 0); self.measure_spin.setRange(1, 1); self.set_frame(0)
            return
        self.replay = self.service.build_direct(candidate.fft_path, candidate.raw_path)
        fft = self.replay.source_fft.name if self.replay.source_fft else "No FFT companion"
        raw = self.replay.source_raw.name if self.replay.source_raw else "No RAW companion"
        cal = self.replay.calibration_ini.name if self.replay.calibration_ini else "Not found"
        response = self.replay.response_ini.name if self.replay.response_ini else "Not found"
        self.source_label.setText(f"FFT: {fft} | RAW: {raw} | Calibration: {cal} | Response: {response}")
        factors = ", ".join(f"CH{i}={v:.6g}" for i, v in enumerate(self.replay.spectrum_factors))
        axis_audit = ""
        if self.replay.frequency_start_hz is not None and self.replay.frequency_spacing_hz is not None and self.replay.frequency_end_hz is not None:
            axis_audit = (f"\nFrequency axis audit: {self.replay.frequency_axis_source}; "
                          f"{self.replay.frequency_start_hz/1e3:.3f}–{self.replay.frequency_end_hz/1e3:.3f} kHz; "
                          f"Δf={self.replay.frequency_spacing_hz:.6f} Hz; "
                          f"f0 bin error={self.replay.main_frequency_bin_error_hz:+.3f} Hz." if self.replay.main_frequency_bin_error_hz is not None else "")
        self.note.setText(self.replay.note + axis_audit + f"\nApplied calibration audit: SpectrumCoef={self.replay.spectrum_coef:.6g}; {factors}; response points={self.replay.response_point_count}.")
        count = len(self.replay.frames)
        self.slider.setRange(0, max(0, count-1)); self.measure_spin.setRange(1, max(1, count))
        self.set_frame(0); self._draw_spectrogram(); self._draw_band_energy(); self._apply_vendor_band_defaults(); self._draw_vendor_cavitation(); self._refresh_cavitation_analysis()

    def dragEnterEvent(self, event):
        if any(url.isLocalFile() for url in event.mimeData().urls()):
            event.acceptProposedAction()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            if not url.isLocalFile(): continue
            path = Path(url.toLocalFile())
            if path.is_dir() or path.suffix.lower() == ".zip" or "spectrum" in path.name.lower():
                self.open_dump_source(path); event.acceptProposedAction(); return

    def load_package(self, package, sonication_index: int, *, select_from_loaded_export: bool = False):
        """Load Sonication sources and ADD SpectrumDumps from the loaded Export.

        The original Sonication choices are always preserved. SpectrumDumps are
        additional selectable sources, never replacements.
        """
        self.package = package
        self.open_loaded_export_btn.setEnabled(True)
        candidates = self.dump_importer.discover(Path(package.workspace))
        from src.services.spectrum_dump_import_service import SpectrumDumpSource
        self.dump_source = SpectrumDumpSource(source=Path(package.workspace), workspace=Path(package.workspace), candidates=candidates, temporary=False) if candidates else None
        self.source_entries = []
        self.sonication_combo.blockSignals(True); self.sonication_combo.clear()
        for i, son in enumerate(package.sonications):
            self.source_entries.append(("sonication", i))
            self.sonication_combo.addItem(f"Sonication / {son.name}")
        for i, candidate in enumerate(candidates):
            # Avoid duplicating Sonication-local SpectrumMsg entries as a second
            # physical 8CH source. CPC SpectrumDumps are the intended additions.
            if candidate.family == "SpectrumMsg":
                continue
            self.source_entries.append(("dump", i))
            self.sonication_combo.addItem(f"SpectrumDumps / {candidate.label} [{candidate.completeness}]")
        target_row = next((row for row, entry in enumerate(self.source_entries) if entry == ("sonication", max(0, sonication_index))), 0)
        self.sonication_combo.setCurrentIndex(target_row); self.sonication_combo.blockSignals(False)
        self._load_source_entry(target_row)

    def _load_source_entry(self, row: int):
        if not (0 <= row < len(self.source_entries)):
            return
        kind, index = self.source_entries[row]
        if kind == "dump":
            self.load_dump_candidate(index)
        else:
            self.load_sonication(index)

    def load_sonication(self, index: int):
        if self.package is None: return
        self.replay = self.service.build(self.package.cpc_spectrum_files, index, len(self.package.sonications))
        fft = self.replay.source_fft.name if self.replay.source_fft else "No FFT"
        raw = self.replay.source_raw.name if self.replay.source_raw else "No raw"
        cal = self.replay.calibration_ini.name if self.replay.calibration_ini else "Not found"
        response = self.replay.response_ini.name if self.replay.response_ini else "Not found"
        self.source_label.setText(f"FFT: {fft} | RAW: {raw} | Calibration: {cal} | Response: {response}")
        factors = ", ".join(f"CH{i}={v:.6g}" for i, v in enumerate(self.replay.spectrum_factors))
        axis_audit = ""
        if self.replay.frequency_start_hz is not None and self.replay.frequency_spacing_hz is not None and self.replay.frequency_end_hz is not None:
            axis_audit = (f"\nFrequency axis audit: {self.replay.frequency_axis_source}; "
                          f"{self.replay.frequency_start_hz/1e3:.3f}–{self.replay.frequency_end_hz/1e3:.3f} kHz; "
                          f"Δf={self.replay.frequency_spacing_hz:.6f} Hz; "
                          f"f0 bin error={self.replay.main_frequency_bin_error_hz:+.3f} Hz." if self.replay.main_frequency_bin_error_hz is not None else "")
        self.note.setText(self.replay.note + axis_audit + f"\nApplied calibration audit: SpectrumCoef={self.replay.spectrum_coef:.6g}; {factors}; response points={self.replay.response_point_count}.")
        count = len(self.replay.frames)
        self.slider.setRange(0, max(0, count-1))
        self.measure_spin.setRange(1, max(1, count))
        self.set_frame(0)
        self._draw_spectrogram(); self._draw_band_energy(); self._apply_vendor_band_defaults(); self._draw_vendor_cavitation(); self._refresh_cavitation_analysis()

    def sync_sonication(self, index: int):
        row = next((r for r, entry in enumerate(self.source_entries) if entry == ("sonication", index)), -1)
        if row >= 0:
            self.sonication_combo.blockSignals(True); self.sonication_combo.setCurrentIndex(row); self.sonication_combo.blockSignals(False)
            self.load_sonication(index)

    def _sonication_changed(self, index: int):
        if index < 0: return
        if self.source_entries:
            kind, source_index = self.source_entries[index]
            self._load_source_entry(index)
            if kind == "sonication": self.sonicationRequested.emit(source_index)
            return
        if self.dump_source is not None:
            self.load_dump_candidate(index); return
        self.load_sonication(index); self.sonicationRequested.emit(index)

    def set_frame(self, index: int):
        count = len(self.replay.frames) if self.replay else 0
        self.frame_index = max(0, min(int(index), max(0, count-1)))
        self.slider.blockSignals(True); self.slider.setValue(self.frame_index); self.slider.blockSignals(False)
        self.measure_spin.blockSignals(True); self.measure_spin.setValue(self.frame_index+1); self.measure_spin.blockSignals(False)
        interval = self.replay.frame_interval_s if self.replay else 0.010
        if self.replay and count and self.frame_index < len(self.replay.frames):
            frame = self.replay.frames[self.frame_index]
            actual_time = frame.acquisition_time_s if frame.acquisition_time_s is not None else self.frame_index * interval
            cycle_text = f" · Acquisition cycle {frame.acquisition_cycle}" if frame.acquisition_cycle is not None else ""
        else:
            actual_time = self.frame_index * interval
            cycle_text = ""
        self.frame_label.setText(f"FFT Snapshot {self.frame_index+1 if count else '-'} / {count or '-'} · Time {actual_time:.3f} s{cycle_text}")
        if self.timer.isActive() and count and self.frame_index >= count-1:
            self.timer.stop(); self.play_btn.setText("▶")
        self._refresh_frame_views()
        self._update_vendor_current_marker()
        self._update_cavitation_likelihood()

    def _toggle_play(self):
        if self.timer.isActive():
            self.timer.stop(); self.play_btn.setText("▶")
        else:
            if self.replay and self.replay.frames and self.frame_index >= len(self.replay.frames)-1: self.set_frame(0)
            interval = self.replay.frame_interval_s if self.replay else 0.010
            self.timer.start(max(10, int(interval*1000))); self.play_btn.setText("Ⅱ")

    def _refresh_all(self):
        self._refresh_frame_views(); self._draw_spectrogram(); self._draw_band_energy(); self._draw_vendor_cavitation()

    def _refresh_frame_views(self):
        self._draw_raw(); self._draw_spectrum(); self._draw_statistics()

    def _draw_raw(self):
        for plot in getattr(self, "raw_plots", []): plot.clear()
        if not self.replay or not self.replay.frames or not self.raw_plots: return
        frame = self.replay.frames[self.frame_index]
        if not frame.raw_channels:
            if self.replay.raw_timeline_channels:
                t = self.replay.raw_timeline_time_s
                mode = self.raw_mode.currentText()
                channels = range(8) if mode != "Single CH" else [self.channel_spin.value()]
                if mode == "8 Panels":
                    for ch, plot in enumerate(self.raw_plots):
                        y = self.replay.raw_timeline_channels[ch]
                        plot.plot(t[:len(y)], y, pen=pg.intColor(ch, 8))
                        plot.setLabel("bottom", "Measurement time", units="s")
                        plot.setLabel("left", "History value")
                        plot.setTitle(f"CH{ch} measurement history")
                else:
                    plot = self.raw_plots[0]
                    for ch in channels:
                        y = self.replay.raw_timeline_channels[ch]
                        plot.plot(t[:len(y)], y, pen=pg.intColor(ch, 8), name=f"CH{ch}")
                    plot.setLabel("bottom", "Measurement time", units="s")
                    plot.setLabel("left", "History value")
                    suffix = "Raw A/D payload is not present in this export"
                    plot.setTitle(f"Validated CPC 8CH measurement history — {suffix}")
            else:
                self.raw_plots[0].setTitle("CPC raw companion container not decoded")
            return
        mode = self.raw_mode.currentText()
        channels = range(8) if mode != "Single CH" else [self.channel_spin.value()]
        common = max((float(np.max(np.abs(frame.raw_channels[ch]))) for ch in channels if len(frame.raw_channels[ch])), default=1.0)
        if mode == "8 Panels":
            for ch, plot in enumerate(self.raw_plots):
                y = frame.raw_channels[ch]; plot.plot(np.arange(len(y)), y, pen=pg.intColor(ch, 8))
                if self.raw_scale.currentText() == "Common symmetric": plot.setYRange(-common, common, padding=.02)
        else:
            plot = self.raw_plots[0]
            for ch in channels:
                y = frame.raw_channels[ch]; plot.plot(np.arange(len(y)), y, pen=pg.intColor(ch, 8), name=f"CH{ch}")
            plot.setTitle("CH0–CH7 raw overlay" if mode == "Overlay 8CH" else f"CH{self.channel_spin.value()} raw")
            if self.raw_scale.currentText() == "Common symmetric": plot.setYRange(-common, common, padding=.02)

    def _draw_spectrum(self):
        for plot in getattr(self, "spectrum_plots", []): plot.clear()
        if not self.replay or not self.replay.frames or not self.spectrum_plots: return
        frame = self.replay.frames[self.frame_index]; x = frame.frequency_hz / 1e6
        floor = float(self.db_floor.value())
        layout_mode = self.spectrum_mode.currentText()
        value_mode = self.spectrum_value_mode.currentText()
        channels = range(8) if layout_mode != "Single CH" else [self.channel_spin.value()]

        def curves(ch: int):
            if value_mode == "Relative dB":
                return [(self.service.relative_db(self.replay, frame, ch), "calibrated")]
            if value_mode == "Raw absolute":
                return [(self.service.absolute_db(frame, ch, False), "raw")]
            if value_mode == "Raw + calibrated":
                return [(self.service.absolute_db(frame, ch, False), "raw"), (self.service.absolute_db(frame, ch, True), "calibrated")]
            return [(self.service.absolute_db(frame, ch, True), "calibrated")]

        def draw(plot, ch):
            items = curves(ch)
            for idx, (y, label) in enumerate(items):
                pen = pg.mkPen(pg.intColor(ch, 8), width=2 if label == "calibrated" else 1, style=Qt.PenStyle.SolidLine if label == "calibrated" else Qt.PenStyle.DashLine)
                plot.plot(x[:len(y)], np.maximum(y, floor), pen=pen, name=f"CH{ch} {label}")
            plot.setLabel("left", "Relative level" if value_mode == "Relative dB" else "Absolute amplitude", units="dB")
            if value_mode == "Relative dB": plot.setYRange(max(floor, -120), 0.0, padding=0.0)

        if layout_mode == "8 Panels":
            for ch, plot in enumerate(self.spectrum_plots):
                draw(plot, ch)
                factor = self.replay.spectrum_factors[ch] * self.replay.spectrum_coef
                plot.setTitle(f"CH{ch} · static coef {factor:.6g}")
        else:
            plot = self.spectrum_plots[0]
            for ch in channels: draw(plot, ch)
            plot.setTitle("CH0–CH7 spectrum overlay" if layout_mode == "Overlay 8CH" else f"CH{self.channel_spin.value()} spectrum")

    def _draw_spectrogram(self):
        if not hasattr(self, "spectrogram_image") or not self.replay or not self.replay.frames: return
        time, freq, matrix = self.service.spectrogram(self.replay, self.channel_spin.value())
        low = self.spec_min.value()*1e6; high = self.spec_max.value()*1e6
        mask = (freq >= low) & (freq <= high)
        if not np.any(mask): return
        image = matrix[:, mask].T
        self.spectrogram_image.setImage(image, autoLevels=False, levels=(self.replay.display_db_min, self.replay.display_db_max))
        f_values = freq[mask]/1e6
        diffs = np.diff(time) if len(time) > 1 else np.asarray([], dtype=float)
        uniform = bool(diffs.size == 0 or (np.all(np.isfinite(diffs)) and np.nanmax(np.abs(diffs - np.nanmedian(diffs))) <= 1e-6))
        if uniform:
            x_max = max(float(time[-1]) if len(time) else 0.0, self.replay.frame_interval_s)
            self.spectrogram_plot.setLabel("bottom", "Acquisition time", units="s")
            title = f"CH{self.channel_spin.value()} · time-frequency relative level"
        else:
            # ImageItem pixels are uniformly spaced. Do not stretch rows across
            # non-uniform real acquisition gaps and call that a time axis.
            x_max = max(float(len(self.replay.frames)), 1.0)
            self.spectrogram_plot.setLabel("bottom", "FFT snapshot sequence")
            title = f"CH{self.channel_spin.value()} · spectrum snapshots (non-uniform timing; navigator shows exact cycle/time)"
        self.spectrogram_image.setRect(QRectF(0.0, float(f_values[0]), x_max, float(f_values[-1]-f_values[0] if len(f_values)>1 else .001)))
        self.spectrogram_plot.setTitle(title)

    def _selected_bands(self):
        return [(i, self.band_low[i].value()*1e6, self.band_high[i].value()*1e6) for i, enabled in enumerate(self.band_enabled) if enabled.isChecked() and self.band_high[i].value() > self.band_low[i].value()]

    def _draw_band_energy(self):
        if not hasattr(self, "band_plot"): return
        self.band_plot.clear()
        if not self.replay or not self.replay.frames: return
        time = self.replay.frame_times_s
        vendor_bands = {int(b.index): b for b in (getattr(self.replay.vendor_profile, "bands", []) if getattr(self.replay, "vendor_profile", None) else [])}
        inferred_bands = self.standalone_cavitation_service.infer_band_ranges(self.replay) if not vendor_bands else {}
        for band_index, low, high in self._selected_bands():
            vendor = vendor_bands.get(int(band_index))
            if vendor is not None:
                exact_vendor = bool(abs(low-vendor.low_hz) <= 1.0 and abs(high-vendor.high_hz) <= 1.0 and getattr(self.replay, "vendor_embedded_band_energy_available", False))
            elif int(band_index) in inferred_bands:
                ilo,ihi,_err=inferred_bands[int(band_index)]
                exact_vendor = bool(abs(low-ilo) <= 1.0 and abs(high-ihi) <= 1.0 and getattr(self.replay, "vendor_embedded_band_energy_available", False))
            else:
                exact_vendor = False
            energy = self.service.vendor_band_energy(self.replay, band_index) if exact_vendor else self.service.band_energy(self.replay, low, high)
            for ch in range(8):
                y = energy[:, ch]
                valid = np.isfinite(y) & (y > 0)
                if not np.any(valid): continue
                ref = float(np.nanmax(y[valid])); db = np.full_like(y, -120.0)
                db[valid] = 10.0*np.log10(y[valid]/max(ref, np.finfo(float).tiny))
                pen = pg.mkPen(pg.intColor(ch, 8), width=2 if band_index == 0 else 1)
                suffix = " exact" if exact_vendor else " local"
                self.band_plot.plot(time[:len(db)], db, pen=pen, name=f"B{band_index} CH{ch}{suffix}")
        self.band_plot.setYRange(-60, 0, padding=.03)

    def _apply_vendor_band_defaults(self):
        if not self.replay:
            return
        profile=getattr(self.replay, "vendor_profile", None)
        bands=list(profile.bands or []) if profile is not None else []
        if bands:
            ranges={int(b.index):(float(b.low_hz),float(b.high_hz)) for b in bands[:4]}
        else:
            ranges={i:(lo,hi) for i,(lo,hi,_err) in self.standalone_cavitation_service.infer_band_ranges(self.replay).items()}
        for i in range(min(4,len(self.band_low))):
            if i not in ranges: continue
            low,high=ranges[i]
            self.band_low[i].blockSignals(True); self.band_high[i].blockSignals(True)
            self.band_low[i].setValue(float(low)/1e6); self.band_high[i].setValue(float(high)/1e6)
            self.band_low[i].blockSignals(False); self.band_high[i].blockSignals(False)
        self._draw_band_energy()

    def _draw_vendor_cavitation(self):
        if not hasattr(self, "vendor_energy_plot"):
            return
        self.vendor_energy_plot.clear(); self.vendor_rule_plot.clear()
        if hasattr(self, "vendor_power_plot"): self.vendor_power_plot.clear()
        if hasattr(self, "vendor_control_table"): self.vendor_control_table.setRowCount(0)
        if not self.replay:
            self.vendor_profile_label.setText("Vendor cavitation rules are not loaded")
            return
        profile = getattr(self.replay, "vendor_profile", None)
        validation = getattr(self.replay, "vendor_history_validation", None)
        if profile is None:
            self.vendor_profile_label.setText("Cavitation profile object is unavailable")
            return
        inferred = self.standalone_cavitation_service.infer_band_ranges(self.replay) if not profile.bands else {}
        for row in range(4):
            band = next((b for b in profile.bands if b.index == row), None)
            if band is None and row in inferred:
                low,high,error=inferred[row]
                values = [f"Band{row}", "Recovered", "-", f"{low/1000:.3f} – {high/1000:.3f} kHz", f"SpectrumDumps-only: FFT-bin range reproduces embedded energy; relative error {error:.3g}"]
            elif band is None:
                values = [f"Band{row}", "-", "-", "Unavailable", "Not decoded"]
            else:
                evidence = "Vendor HARMONICS_BANDWIDTHS"
                if row == 0:
                    evidence += "; exact FFT-snapshot energy + exact continuous 8CH saved history + Display Rule 1 validation"
                elif row == 1:
                    evidence += "; exact FFT-snapshot energy; continuous combined energy reconstructed from Display Rule 2 × 0.018"
                elif row == 2:
                    evidence += "; exact FFT-snapshot energy; sparse threshold events from Decrease Power Rule 4/5"
                elif row == 3:
                    evidence += "; exact FFT-snapshot energy; no active combined display/control rule in this configuration"
                values = [f"Band{row}", f"{band.ratio:.3f} × f0", f"± {band.delta_hz/1000:.1f} kHz", f"{band.low_hz/1000:.3f} – {band.high_hz/1000:.3f} kHz", evidence]
            for col, value in enumerate(values): self.vendor_band_table.setItem(row, col, QTableWidgetItem(str(value)))
        validation_text = validation.note if validation is not None else "No saved-history validation"
        self.vendor_profile_label.setText(
            f"f0={self.replay.main_frequency_hz/1e6:.6f} MHz | Rules: {profile.source_ini.name if profile.source_ini else 'SpectrumDumps-only / no INI'} | "
            f"Acquisition: {profile.acquisition_ini.name if profile.acquisition_ini else 'not found'}\n"
            f"History semantic: {validation.status if validation else 'Not validated'}\n"
            f"FFT Band0-3 table: {'EXACT' if getattr(self.replay, 'vendor_embedded_band_energy_validated', False) else 'Not validated'}"
            f" | Snapshot→cycle map: {'EXACT' if getattr(self.replay, 'snapshot_cycle_mapping_validated', False) else 'Not validated'}\n"
            f"Control: {getattr(getattr(self.replay, 'vendor_control_validation', None), 'status', 'Not validated')} | "
            f"start ratio={profile.starting_power_ratio if profile.starting_power_ratio is not None else '-'} | levels={profile.cavitation_levels or '-'} | "
            f"RTDCA stop={profile.stop_on_rtdca} | SW/HW policy={profile.error_policy_sw}/{profile.error_policy_hw}\n"
            f"{validation_text}\n{getattr(getattr(self.replay, 'vendor_control_validation', None), 'note', '')}"
        )
        if not self.replay.raw_timeline_channels:
            return
        time = np.asarray(self.replay.raw_timeline_time_s, float)
        for ch, values in enumerate(self.replay.raw_timeline_channels[:8]):
            y=np.asarray(values,float); self.vendor_energy_plot.plot(time[:len(y)], y, pen=pg.mkPen(pg.intColor(ch,8), width=1), name=f"CH{ch} Band0")
        weighted=np.asarray(getattr(self.replay, "vendor_band0_weighted", []), float)
        if weighted.size:
            self.vendor_energy_plot.plot(time[:len(weighted)], weighted, pen=pg.mkPen("w", width=2.5), name="Band0 combined (saved history)")
        band1=np.asarray(getattr(self.replay, "vendor_band1_log_exact", []), float)
        if band1.size and np.isfinite(band1).any():
            self.vendor_energy_plot.plot(time[:len(band1)], band1, pen=pg.mkPen("#4cc9f0", width=2.2), name="Band1 combined (Display Rule 2 exact)")
        band2=np.asarray(getattr(self.replay, "vendor_band2_log_events", []), float)
        if band2.size and np.isfinite(band2).any():
            mask=np.isfinite(band2); self.vendor_energy_plot.plot(time[:len(band2)][mask], band2[mask], pen=None, symbol="o", symbolSize=7, symbolBrush="#f72585", name="Band2 exact threshold events")
        # R0033: the FFT container itself stores exact Band0..Band3 energy for
        # every hydrophone and snapshot. Plot the selected channel at its true
        # acquisition-cycle timestamps; no log is required for these points.
        if getattr(self.replay, "vendor_embedded_band_energy_validated", False):
            snapshot_time = self.replay.frame_times_s
            ch = int(self.channel_spin.value())
            symbols = ["o", "t", "s", "d"]
            brushes = ["#ffffff", "#4cc9f0", "#f72585", "#ffd166"]
            for band_index in range(4):
                exact = self.service.vendor_band_energy(self.replay, band_index)
                if exact.shape[0] and ch < exact.shape[1]:
                    y = exact[:, ch]
                    self.vendor_energy_plot.plot(snapshot_time[:len(y)], y, pen=None, symbol=symbols[band_index], symbolSize=6, symbolBrush=brushes[band_index], name=f"Band{band_index} CH{ch} exact FFT snapshots")
        inc = profile.increase_rule0
        if inc is not None and inc.limit is not None:
            self.vendor_energy_plot.addItem(pg.InfiniteLine(pos=float(inc.limit), angle=0, movable=False, pen=pg.mkPen("#ffd166", width=2, style=Qt.PenStyle.DashLine), label=f"Increase limit {inc.limit:g}"))
        display1=profile.display_rules.get(1)
        normalized=np.asarray(getattr(self.replay, "vendor_display_rule1", []), float)
        if normalized.size:
            self.vendor_rule_plot.plot(time[:len(normalized)], normalized, pen=pg.mkPen("#06d6a0", width=2.5), name="Display Rule 1 / Band0")
        display2=np.asarray(getattr(self.replay, "vendor_display_rule2", []), float)
        if display2.size and np.isfinite(display2).any():
            self.vendor_rule_plot.plot(time[:len(display2)], display2, pen=pg.mkPen("#4cc9f0", width=2.2), name="Display Rule 2 / Band1")
        if normalized.size or (display2.size and np.isfinite(display2).any()):
            self.vendor_rule_plot.addItem(pg.InfiniteLine(pos=1.0, angle=0, movable=False, pen=pg.mkPen("#ffd166", width=2, style=Qt.PenStyle.DashLine), label="MaximumEnergy normalized = 1.0"))

        # R0034: Decode the actual cavitation-control state machine from the INI.
        control_rows=[]
        def weighted_input(rule):
            active=np.argwhere(np.asarray(rule.weights, float) != 0)
            if active.size == 0: return "Disabled"
            bands=sorted({int(b) for _ch,b in active}); channels=sorted({int(ch) for ch,_b in active})
            return f"Band{','.join(str(b) for b in bands)} / CH{','.join(str(c) for c in channels)}"
        validation=getattr(self.replay, "vendor_control_validation", None)
        runtime_status=validation.status if validation is not None else "Not validated"
        for idx,rule in sorted(profile.decrease_rules.items()):
            if not np.any(np.asarray(rule.weights,float)): continue
            threshold="-" if rule.threshold is None else f"> {rule.threshold:g}"
            action="-" if rule.power_ratio is None else f"Power × {1.0-float(rule.power_ratio):.3f} ({100*float(rule.power_ratio):.1f}% decrease)"
            control_rows.append(("Decrease",idx,weighted_input(rule),threshold,action,runtime_status))
        if profile.increase_rule0 is not None:
            inc_ratio = getattr(profile, "increase_power_ratio", None)
            action = "-" if inc_ratio is None else f"Power × {1.0+float(inc_ratio):.3f} (until 1.0)"
            threshold = "-" if profile.increase_rule0.limit is None else f"< {profile.increase_rule0.limit:g}"
            control_rows.append(("Increase",0,weighted_input(profile.increase_rule0),threshold,action,runtime_status))
        for idx,rule in sorted(profile.safety_rules.items()):
            if not np.any(np.asarray(rule.weights,float)): continue
            threshold=f"Max>{rule.threshold:g}" if rule.threshold is not None else "-"
            if rule.critical_threshold is not None: threshold += f" / Critical>{rule.critical_threshold:g}"
            persistence=f"Max {rule.max_failures if rule.max_failures is not None else '-'} in {rule.max_failure_window_ms if rule.max_failure_window_ms is not None else '-'} ms; Critical {rule.critical_failures if rule.critical_failures is not None else '-'} in {rule.critical_failure_window_ms if rule.critical_failure_window_ms is not None else '-'} ms"
            control_rows.append(("Safety",idx,weighted_input(rule),threshold,persistence,"INI decoded; no safety-stop event required for validation"))
        for idx,rule in sorted(profile.dynamic_rules.items()):
            if not np.any(np.asarray(rule.weights,float)): continue
            threshold="-" if rule.threshold is None else f"> {rule.threshold:g}"
            action=f"Switch to SubSonication {rule.switch_to_subsonication if rule.switch_to_subsonication is not None else '-'}; {rule.max_failures if rule.max_failures is not None else '-'} failures / {rule.max_failure_window_ms if rule.max_failure_window_ms is not None else '-'} ms"
            control_rows.append(("Dynamic",idx,weighted_input(rule),threshold,action,"CavitationDynamicRules_0.ini"))
        self.vendor_control_table.setRowCount(len(control_rows))
        for r,row in enumerate(control_rows):
            for c,value in enumerate(row): self.vendor_control_table.setItem(r,c,QTableWidgetItem(str(value)))

        if validation is not None and validation.event_cycles.size:
            tx=(np.asarray(validation.event_cycles,float)-1.0)*float(self.replay.acquisition_interval_s)
            actual=np.asarray(validation.actual_power_ratio,float); predicted=np.asarray(validation.predicted_power_ratio,float)
            self.vendor_power_plot.plot(tx,actual,pen=pg.mkPen("#ffffff",width=2.5),symbol="o",symbolSize=4,name="Actual ExPowerRatio")
            self.vendor_power_plot.plot(tx,predicted,pen=pg.mkPen("#06d6a0",width=1.8,style=Qt.PenStyle.DashLine),name="INI-rule prediction")
            self.vendor_power_plot.setYRange(0.0,1.02,padding=0.0)
        self._update_vendor_current_marker()

    def _update_vendor_current_marker(self):
        if not self.replay or not hasattr(self, "vendor_profile_label"):
            return
        validation = getattr(self.replay, "vendor_history_validation", None)
        if validation is None or not self.replay.raw_timeline_channels:
            return
        # Use the exact R0033 Band0-fingerprint mapping when available. It
        # recovers real 10-ms acquisition cycle/time and preserves gaps.
        frame = self.replay.frames[self.frame_index] if self.replay.frames and self.frame_index < len(self.replay.frames) else None
        if frame is not None and frame.acquisition_history_index is not None:
            raw_index = int(frame.acquisition_history_index)
        else:
            t = float(self.frame_index) * float(self.replay.frame_interval_s)
            raw_index = min(max(int(round(t / max(self.replay.acquisition_interval_s, 1e-9))), 0), len(self.replay.raw_timeline_channels[0])-1)
        weighted=np.asarray(getattr(self.replay, "vendor_band0_weighted", []),float)
        normalized=np.asarray(getattr(self.replay, "vendor_display_rule1", []),float)
        display2=np.asarray(getattr(self.replay, "vendor_display_rule2", []),float)
        band1=np.asarray(getattr(self.replay, "vendor_band1_log_exact", []),float)
        band2=np.asarray(getattr(self.replay, "vendor_band2_log_events", []),float)
        current_energy = weighted[raw_index] if raw_index < weighted.size else np.nan
        current_rule = normalized[raw_index] if raw_index < normalized.size else np.nan
        current_rule2 = display2[raw_index] if raw_index < display2.size else np.nan
        current_band1 = band1[raw_index] if raw_index < band1.size else np.nan
        current_band2 = band2[raw_index] if raw_index < band2.size else np.nan
        base = self.vendor_profile_label.text().split("\nCurrent:",1)[0]
        f6=lambda v: "N/A" if not np.isfinite(v) else f"{v:.6f}"
        f4=lambda v: "N/A" if not np.isfinite(v) else f"{v:.4f}"
        band2_text = f6(current_band2) if np.isfinite(current_band2) else "no threshold event"
        snapshot_text = ""
        if frame is not None and np.asarray(frame.vendor_band_energies).shape == (8,4):
            ch=int(self.channel_spin.value()); ev=np.asarray(frame.vendor_band_energies,float)[ch]
            snapshot_text = " | FFT exact " + ", ".join(f"B{i}={f6(ev[i])}" for i in range(4))
        self.vendor_profile_label.setText(base + f"\nCurrent: acquisition #{raw_index+1} | Band0={f6(current_energy)} (Rule1={f4(current_rule)}) | Band1={f6(current_band1)} (Rule2={f4(current_rule2)}) | Band2={band2_text}{snapshot_text}")

    def _draw_statistics(self):
        if not hasattr(self, "stats_table") or not self.replay or not self.replay.frames: return
        bands = self._selected_bands()
        low, high = (bands[0][1], bands[0][2]) if bands else (0.25e6, 0.30e6)
        rows = self.service.frame_statistics(self.replay, self.frame_index, low, high)
        self.packet_label.setText(
            f"Measure #{self.frame_index+1} of {len(self.replay.frames)} · "
            f"Sonication frequency {self.replay.main_frequency_hz/1e6:.6f} MHz · "
            f"Band {low/1e6:.3f}–{high/1e6:.3f} MHz"
        )
        for r, data in enumerate(rows):
            values = [
                f"CH{int(data['channel'])}", self._fmt(data['raw_peak']), self._fmt(data['raw_rms']),
                self._fmt(data['dominant_hz']/1e6, 6), self._fmt(data['peak_db'], 2), self._fmt(data['band_energy'], 5),
                self._fmt(data['raw_spectrum_peak'], 5), self._fmt(data['calibrated_spectrum_peak'], 5), self._fmt(data['main_frequency_coefficient'], 6),
            ]
            for c, value in enumerate(values): self.stats_table.setItem(r, c, QTableWidgetItem(value))

    def closeEvent(self, event):
        self.timer.stop()
        self.dump_importer.cleanup()
        super().closeEvent(event)

    @staticmethod
    def _fmt(value: float, digits: int = 3) -> str:
        return "N/A" if not np.isfinite(value) else f"{value:.{digits}g}"
