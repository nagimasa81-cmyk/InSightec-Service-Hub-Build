from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
import numpy as np


@dataclass(slots=True)
class RegistrationOverlayResult:
    overlay: np.ndarray | None
    matrix: np.ndarray | None
    matrix_source: Path | None
    ct_source: Path | None
    status: str
    selected_slice_index: int | None = None
    alignment_score: float | None = None


@dataclass(slots=True)
class RegistrationTrace:
    ct_voxel_xyz: tuple[float, float, float] | None
    ct_ras_xyz: tuple[float, float, float] | None
    mr_ras_xyz: tuple[float, float, float] | None
    mr_pixel_xy: tuple[float, float] | None
    mr_shape: tuple[int, int]
    inside_display: bool | None
    matrix_source: str
    chain_name: str
    note: str
    forward_pixel_xy: tuple[float, float] | None = None
    inverse_pixel_xy: tuple[float, float] | None = None
    forward_inside: bool | None = None
    inverse_inside: bool | None = None
    likely_matrix_direction: str = "undetermined"


@dataclass(slots=True)
class VendorBoneProfile:
    low_hu: float = 500.0
    high_hu: float = 5000.0
    source: Path | None = None
    source_section: str = "BrainACT/BackgroundEliminationInit"


@dataclass(slots=True)
class CtGeometry:
    origin_ras: np.ndarray
    row_direction: np.ndarray
    col_direction: np.ndarray
    slice_direction: np.ndarray
    pixel_size_x: float
    pixel_size_y: float
    slice_spacing: float
    source: Path


@dataclass(slots=True)
class RegistrationRecipe:
    reg_type: str
    matrix: np.ndarray
    matrix_source: Path
    rgs_source: Path | None
    orientation: str | None
    valid: bool
    up_to_date: bool
    initial_solution: str | None
    chain_name: str


class RegistrationOverlayService:
    """Render an evidence-preserving CT bone overlay on planning MR.

    The treatment export stores the adopted CT↔MR registration in CtMr_mat.txt.
    For the 2-D replay review we project the relevant in-plane rotation and
    translation from that 4x4 matrix onto the selected MR plane. This is not a
    replacement for a full 3-D reslice; it is deliberately labelled as a 2-D
    treatment-registration review overlay.
    """

    _FLOAT_RE = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?")

    @classmethod
    def read_matrix(cls, path: Path | None) -> np.ndarray | None:
        if path is None or not Path(path).is_file():
            return None
        try:
            vals = [float(x) for x in cls._FLOAT_RE.findall(Path(path).read_text(encoding='utf-8', errors='ignore'))]
        except (OSError, ValueError):
            return None
        if len(vals) < 16:
            return None
        return np.asarray(vals[:16], float).reshape(4, 4)

    @staticmethod
    def find_treatment_matrix(workspace: Path, sonication_index: int) -> Path | None:
        candidates = [
            workspace / f"Sonication{sonication_index}" / "CtMr_mat.txt",
            workspace / f"Sonication_{sonication_index}" / "CtMr_mat.txt",
            workspace / "WSFiles" / "lastCtMrRegistration_mat.txt",
        ]
        for p in candidates:
            if p.is_file():
                return p
        hits = sorted(workspace.rglob("CtMr_mat.txt"))
        return hits[0] if hits else None

    @staticmethod
    def find_treatment_mrmr_matrix(workspace: Path, sonication_index: int) -> Path | None:
        candidates = [
            workspace / f"Sonication{sonication_index}" / "MrMr_mat.txt",
            workspace / f"Sonication_{sonication_index}" / "MrMr_mat.txt",
            workspace / "WSFiles" / "lastMrMrRegistration_mat.txt",
        ]
        for p in candidates:
            if p.is_file():
                return p
        hits = sorted(workspace.rglob("MrMr_mat.txt"))
        return hits[0] if hits else None

    @staticmethod
    def find_registration_rgs(workspace: Path, sonication_index: int, reg_type: str) -> Path | None:
        name=f"{reg_type}.rgs"
        candidates=[
            workspace / f"Sonication{sonication_index}" / name,
            workspace / f"Sonication_{sonication_index}" / name,
            workspace / "WSFiles" / f"last{reg_type}Registration.rgs",
        ]
        for path in candidates:
            if path.is_file():
                return path
        hits=sorted(workspace.rglob(name))
        return hits[0] if hits else None

    @staticmethod
    def read_rgs(path: Path | None) -> dict[str,str]:
        if path is None or not Path(path).is_file():
            return {}
        values={}
        section=''
        try:
            lines=Path(path).read_text(encoding='utf-8',errors='ignore').splitlines()
        except OSError:
            return {}
        for raw in lines:
            line=raw.strip()
            if not line or line.startswith((';','#')):
                continue
            if line.startswith('[') and line.endswith(']'):
                section=line[1:-1].strip()
                continue
            if '=' not in line:
                continue
            key,value=line.split('=',1)
            key=key.strip(); value=value.strip()
            values[key]=value
            if section:
                values[f'{section}.{key}']=value
        return values

    @staticmethod
    def _rgs_bool(values: dict[str,str], key: str, default: bool=False) -> bool:
        value=str(values.get(key,values.get(f'General.{key}',''))).strip().lower()
        if value in {'true','1','yes','on'}: return True
        if value in {'false','0','no','off'}: return False
        return bool(default)

    def _registration_recipe(self, workspace: Path, sonication_index: int, mr_asset) -> RegistrationRecipe | None:
        """Return the exact treatment-export registration chain.

        The exported matrices are not candidate transforms. CtMr is the accepted
        CT→treatment-MR registration. Workstation registration logs show MrMr is
        stored as preplanning-MR→treatment-MR (the second/source volume is the
        preplanning MR), so a preplanning display must use inv(MrMr) × CtMr.
        RGS metadata is used only to verify that the saved registration was
        valid/up-to-date; image similarity never selects or alters the transform.
        """
        workspace=Path(workspace)
        ct_path=self.find_treatment_matrix(workspace,sonication_index)
        ct=self.read_matrix(ct_path)
        if ct_path is None or ct is None:
            return None
        ct_rgs_path=self.find_registration_rgs(workspace,sonication_index,'CtMr')
        ct_rgs=self.read_rgs(ct_rgs_path)
        ct_valid=self._rgs_bool(ct_rgs,'IsMatrixValid',True)
        ct_current=self._rgs_bool(ct_rgs,'IsMatrixUpToDate',True)
        category=str(getattr(mr_asset,'category','') or '').upper()
        if category.startswith('PREPLANNING_MR'):
            mm_path=self.find_treatment_mrmr_matrix(workspace,sonication_index)
            mm=self.read_matrix(mm_path)
            if mm_path is None or mm is None:
                return None
            mm_rgs_path=self.find_registration_rgs(workspace,sonication_index,'MrMr')
            mm_rgs=self.read_rgs(mm_rgs_path)
            valid=ct_valid and self._rgs_bool(mm_rgs,'IsMatrixValid',True)
            current=ct_current and self._rgs_bool(mm_rgs,'IsMatrixUpToDate',True)
            orientation=mm_rgs.get('MrOrientation',mm_rgs.get('AutoReg.MrOrientation'))
            initial=mm_rgs.get('InitialSolution',mm_rgs.get('AutoReg.InitialSolution'))
            try:
                chain=np.linalg.inv(mm)@ct
            except np.linalg.LinAlgError:
                return None
            return RegistrationRecipe('CtMr+MrMr',chain,ct_path,mm_rgs_path,orientation,valid,current,initial,'inv(MrMr) × CtMr')
        orientation=ct_rgs.get('MrOrientation',ct_rgs.get('AutoReg.MrOrientation'))
        initial=ct_rgs.get('InitialSolution',ct_rgs.get('AutoReg.InitialSolution'))
        return RegistrationRecipe('CtMr',ct,ct_path,ct_rgs_path,orientation,ct_valid,ct_current,initial,'CtMr')

    @staticmethod
    def _row_float(row, *names):
        low={str(k).lower():v for k,v in row.items()}
        for name in names:
            if name.lower() in low:
                try: return float(low[name.lower()])
                except (TypeError,ValueError): pass
        return None

    @classmethod
    def _vec_from_row(cls,row,prefixes):
        for px,py,pz in prefixes:
            vals=[cls._row_float(row,px),cls._row_float(row,py),cls._row_float(row,pz)]
            if all(v is not None for v in vals):
                a=np.asarray(vals,float); n=float(np.linalg.norm(a))
                if n>1e-6: return a/n
        return None

    @classmethod
    def read_ct_geometry(cls, workspace: Path, ct_asset=None) -> CtGeometry | None:
        """Recover CT voxel→RAS geometry from exported image metadata.

        The planning CT geometry is not stored in ``CtImage.xml`` in the examined
        Brain export.  ``CtImage.xml`` only describes the stored raw-array size.
        The authoritative CT DICOM-derived geometry is in ``MriImageParams.xml``
        (Field 16 / BONE PLUS in the validated export): TopLeftCoord R/A/S,
        Row/Col direction cosines, pixel spacing, slice thickness and one row per
        CT slice.  Prefer that source, then fall back to legacy CtImage/
        CtVolumeData metadata if a different export generation contains it.
        """
        try:
            from src.parsers.ado_rowset import parse_ado_rowset
        except Exception:
            return None
        workspace=Path(workspace)
        target_field=getattr(ct_asset,'field_index',16) if ct_asset is not None else 16
        target_son=getattr(ct_asset,'sonication_index',None) if ct_asset is not None else None

        def geometry_from_rows(path, rows, require_field=True):
            candidates=[]
            for row in rows:
                low={str(k).lower():v for k,v in row.items()}
                try: field=int(low.get('fieldindex',target_field))
                except (TypeError,ValueError): field=target_field
                if require_field and field != target_field:
                    continue
                # Planning CT is typically owner Sonication 1 even when reviewing a
                # later sonication, so do not reject MriImageParams rows solely on
                # target_son.  Field index + CT series metadata is the stronger key.
                ox=cls._row_float(row,'topleftcoordr','originr','origin_r','voloriginr','ctoriginr')
                oy=cls._row_float(row,'topleftcoorda','origina','origin_a','volorigina','ctorigina')
                oz=cls._row_float(row,'topleftcoords','origins','origin_s','volorigins','ctorigins')
                if None in (ox,oy,oz):
                    continue
                rd=cls._vec_from_row(row,[( 'rowdirectcosrasx','rowdirectcosrasy','rowdirectcosrasz'),('rowdirectionx','rowdirectiony','rowdirectionz')])
                cd=cls._vec_from_row(row,[( 'coldirectcosrasx','coldirectcosrasy','coldirectcosrasz'),('coldirectionx','coldirectiony','coldirectionz')])
                if rd is None or cd is None:
                    continue
                px=cls._row_float(row,'pixsizex','pixelsizex','voxsizex','voxelsizex')
                py=cls._row_float(row,'pixsizey','pixelsizey','voxsizey','voxelsizey')
                if not px or not py:
                    continue
                try: order=int(low.get('arrayindex',low.get('imgnum',low.get('sliceindex',len(candidates)))))
                except (TypeError,ValueError): order=len(candidates)
                candidates.append((order,np.asarray([ox,oy,oz],float),rd,cd,float(px),float(py),row))
            if not candidates:
                return None
            # imgnum is often the true slice ordering for MriImageParams while
            # arrayindex can be reused by derived fields.  Sort geometrically if
            # necessary after collecting all rows.
            candidates.sort(key=lambda x:x[0])
            _,origin,rd,cd,px,py,_=candidates[0]
            normal=np.cross(rd,cd); nn=float(np.linalg.norm(normal))
            if nn<1e-6:
                return None
            normal/=nn
            spacing=None; sdir=normal
            if len(candidates)>=2:
                diffs=[]
                for a,b in zip(candidates[:-1],candidates[1:]):
                    d=b[1]-a[1]; n=float(np.linalg.norm(d))
                    if n>1e-5:
                        diffs.append(d)
                if diffs:
                    d=np.median(np.asarray(diffs),axis=0)
                    spacing=float(np.linalg.norm(d))
                    sdir=d/max(spacing,1e-9)
            if not spacing:
                row0=candidates[0][6]
                spacing=cls._row_float(row0,'slicespacing','slicethickness','slicethick','pixsizez','voxsizez','voxelsizez')
            if not spacing or spacing<=0:
                return None
            return CtGeometry(origin,rd,cd,sdir,px,py,float(spacing),path)

        # R0065: authoritative source first.  This is where Field 16 BONE PLUS
        # carries the complete 153-slice CT patient geometry in the validated export.
        for path in sorted(workspace.rglob('MriImageParams.xml')):
            try: rows=parse_ado_rowset(path)
            except Exception: continue
            geom=geometry_from_rows(path,rows,True)
            if geom is not None:
                return geom

        # Legacy/fallback generations may expose geometry in CT-specific tables.
        paths=[p for p in workspace.rglob('*') if p.is_file() and p.name.lower() in {'ctimage.xml','ctvolumedata.xml'}]
        for path in paths:
            try: rows=parse_ado_rowset(path)
            except Exception: continue
            geom=geometry_from_rows(path,rows,path.name.lower()=='ctimage.xml')
            if geom is not None:
                return geom
        return None

    @staticmethod
    def _mr_geometry(mr_asset):
        if mr_asset is None: return None
        vals=[getattr(mr_asset,k,None) for k in ('top_left_r','top_left_a','top_left_s','pixel_size_x','pixel_size_y')]
        if any(v is None for v in vals): return None
        rd=np.asarray(getattr(mr_asset,'row_direction',None),float); cd=np.asarray(getattr(mr_asset,'col_direction',None),float)
        if rd.size!=3 or cd.size!=3 or np.linalg.norm(rd)<1e-6 or np.linalg.norm(cd)<1e-6: return None
        # Workstation/DICOM image-index convention: image X (column index)
        # advances along ColDirectCosRAS and image Y (row index) advances along
        # RowDirectCosRAS. Earlier builds swapped these two axes.
        return np.asarray(vals[:3],float),cd/np.linalg.norm(cd),rd/np.linalg.norm(rd),float(vals[3]),float(vals[4])

    @staticmethod
    def _signed_ct_hu(volume: np.ndarray) -> np.ndarray:
        """Return CT as signed HU-like values even if an upstream path used uint16.

        Field 16 in the real Brain export is 512x512 little-endian int16. Air is
        around -3024 HU. Interpreting those bytes as uint16 turns air into ~62512,
        which falsely classifies non-bone/background as the brightest structure.
        """
        arr=np.asarray(volume)
        out=arr.astype(float,copy=True)
        finite=out[np.isfinite(out)]
        if finite.size and float(np.nanmin(finite)) >= 0.0 and float(np.nanpercentile(finite,95)) > 30000.0:
            out=np.where(out > 32767.0, out - 65536.0, out)
        return out

    @classmethod
    def read_vendor_bone_profile(cls, workspace: Path) -> VendorBoneProfile:
        """Recover the workstation's exported skull/bone HU thresholds.

        BrainACT is preferred for skull geometry (LowBoneThreshold=500 in the
        supplied Brain export). BackgroundEliminationInit/SinusesSegmentation
        provide the exported high-bone guard (5000 HU) and fallback low value.
        """
        workspace=Path(workspace)
        candidates=[]
        for p in workspace.rglob('*.ini'):
            if p.name.lower()=='brainapp.ini':
                candidates.insert(0,p)
            elif p.name.lower()=='fusapp.ini':
                candidates.append(p)
        low=None; high=None; source=None; section=''
        for path in candidates:
            try: lines=path.read_text(encoding='utf-8',errors='ignore').splitlines()
            except OSError: continue
            current=''
            values={}
            for line in lines:
                stripped=line.strip()
                if stripped.startswith('[') and stripped.endswith(']'):
                    current=stripped[1:-1].strip()
                    continue
                if '=' not in stripped or stripped.startswith(';'):
                    continue
                k,v=[x.strip() for x in stripped.split('=',1)]
                try: fv=float(v.split(';',1)[0].strip())
                except ValueError: continue
                values[(current.lower(),k.lower())]=fv
            for sec in ('brainact','backgroundeliminationinit','sinusessegmentation'):
                v=values.get((sec,'lowbonethreshold'))
                if v is not None and low is None:
                    low=float(v); source=path; section=sec
                    break
            for sec in ('brainact','backgroundeliminationinit','sinusessegmentation'):
                v=values.get((sec,'highbonethreshold'))
                if v is not None:
                    high=float(v); source=source or path
                    break
            if low is not None and high is not None: break
        return VendorBoneProfile(
            low_hu=float(low if low is not None else 500.0),
            high_hu=float(high if high is not None else 5000.0),
            source=source,
            source_section=section or 'default',
        )

    @staticmethod
    def _keep_large_2d_components(mask: np.ndarray) -> np.ndarray:
        """Retain skull-sized 8-connected components, rejecting calcification/noise."""
        bone=np.asarray(mask,bool); h,w=bone.shape
        seen=np.zeros((h,w),bool); keep=np.zeros((h,w),bool)
        # Skull ring is thousands of pixels at 512^2. This threshold rejects tiny
        # intracranial calcifications while allowing superior/inferior fragmented skull.
        min_component=max(24,int(round(h*w*0.00045)))
        components=[]
        for yy in range(h):
            for xx in range(w):
                if not bone[yy,xx] or seen[yy,xx]: continue
                stack=[(yy,xx)]; seen[yy,xx]=True; comp=[]
                while stack:
                    cy,cx=stack.pop(); comp.append((cy,cx))
                    for dy in (-1,0,1):
                        for dx in (-1,0,1):
                            if dx==0 and dy==0: continue
                            ny,nx=cy+dy,cx+dx
                            if 0<=ny<h and 0<=nx<w and bone[ny,nx] and not seen[ny,nx]:
                                seen[ny,nx]=True; stack.append((ny,nx))
                components.append(comp)
        if not components: return keep
        large=[c for c in components if len(c)>=min_component]
        if not large:
            large=[max(components,key=len)]
        # Keep all large skull plates/ring fragments, not only one component.
        for comp in large:
            for cy,cx in comp: keep[cy,cx]=True
        return keep

    @classmethod
    def build_vendor_skull_mask(cls, volume: np.ndarray, profile: VendorBoneProfile) -> np.ndarray:
        """Build skull mask in native CT space before registration interpolation."""
        hu=cls._signed_ct_hu(volume)
        mask=np.isfinite(hu) & (hu >= float(profile.low_hu)) & (hu <= float(profile.high_hu))
        if mask.ndim!=3: return mask.astype(bool)
        cleaned=np.zeros(mask.shape,bool)
        for z in range(mask.shape[0]):
            cleaned[z]=cls._keep_large_2d_components(mask[z])
        return cleaned

    def _world_reslice_mask(self, mask_volume, mr_shape, mr_asset, ct_geom: CtGeometry, matrix, matrix_direction: str):
        """Nearest-neighbour patient-coordinate reslice of a native CT skull mask."""
        mg=self._mr_geometry(mr_asset)
        if mg is None: return None
        origin,xdir,ydir,px,py=mg; h,w=map(int,mr_shape[:2]); yy,xx=np.mgrid[0:h,0:w]
        world=origin[:,None,None] + xdir[:,None,None]*(xx*px) + ydir[:,None,None]*(yy*py)
        pts=np.vstack([world.reshape(3,-1),np.ones((1,h*w))])
        try:
            ct_world=(np.linalg.inv(matrix)@pts) if matrix_direction=='CtMr' else (matrix@pts)
        except np.linalg.LinAlgError: return None
        basis=np.column_stack([ct_geom.col_direction*ct_geom.pixel_size_x,ct_geom.row_direction*ct_geom.pixel_size_y,ct_geom.slice_direction*ct_geom.slice_spacing])
        try: inv_basis=np.linalg.inv(basis)
        except np.linalg.LinAlgError: return None
        ijk=inv_basis@(ct_world[:3]-ct_geom.origin_ras[:,None])
        xi=np.rint(ijk[0]).astype(int).reshape(h,w)
        yi=np.rint(ijk[1]).astype(int).reshape(h,w)
        zi=np.rint(ijk[2]).astype(int).reshape(h,w)
        vol=np.asarray(mask_volume,bool); d,hh,ww=vol.shape
        valid=(xi>=0)&(yi>=0)&(zi>=0)&(xi<ww)&(yi<hh)&(zi<d)
        hit=np.zeros((h,w),bool)
        hit[valid]=vol[zi[valid],yi[valid],xi[valid]]
        if np.count_nonzero(hit)<8:
            return np.full((h,w),np.nan,float)
        # Display body + one-pixel border, all non-bone remains NaN/transparent.
        edge=np.zeros_like(hit)
        for dy in (-1,0,1):
            for dx in (-1,0,1):
                if dx==0 and dy==0: continue
                shifted=np.roll(np.roll(hit,dy,axis=0),dx,axis=1)
                edge |= hit ^ shifted
        visible=hit | edge
        visible[[0,-1],:]=False; visible[:,[0,-1]]=False
        out=np.full((h,w),np.nan,float)
        out[hit]=0.72
        out[edge & visible]=1.0
        return out

    def _world_reslice(self, volume, mr_shape, mr_asset, ct_geom: CtGeometry, matrix, matrix_direction: str):
        mg=self._mr_geometry(mr_asset)
        if mg is None: return None
        origin,xdir,ydir,px,py=mg; h,w=map(int,mr_shape[:2]); yy,xx=np.mgrid[0:h,0:w]
        world=origin[:,None,None] + xdir[:,None,None]*(xx*px) + ydir[:,None,None]*(yy*py)
        pts=np.vstack([world.reshape(3,-1),np.ones((1,h*w))])
        try:
            if matrix_direction=='CtMr': ct_world=np.linalg.inv(matrix)@pts
            else: ct_world=matrix@pts
        except np.linalg.LinAlgError: return None
        basis=np.column_stack([ct_geom.col_direction*ct_geom.pixel_size_x,ct_geom.row_direction*ct_geom.pixel_size_y,ct_geom.slice_direction*ct_geom.slice_spacing])
        try: inv_basis=np.linalg.inv(basis)
        except np.linalg.LinAlgError: return None
        ijk=inv_basis@(ct_world[:3]-ct_geom.origin_ras[:,None])
        x=ijk[0].reshape(h,w); y=ijk[1].reshape(h,w); z=ijk[2].reshape(h,w)
        vol=np.asarray(volume,float); d,hh,ww=vol.shape
        x0=np.floor(x).astype(int); y0=np.floor(y).astype(int); z0=np.floor(z).astype(int)
        x1=x0+1; y1=y0+1; z1=z0+1
        valid=(x0>=0)&(y0>=0)&(z0>=0)&(x1<ww)&(y1<hh)&(z1<d)
        out=np.full((h,w),np.nan,float)
        if not np.any(valid): return out
        xv=x[valid]; yv=y[valid]; zv=z[valid]; xa=x0[valid]; xb=x1[valid]; ya=y0[valid]; yb=y1[valid]; za=z0[valid]; zb=z1[valid]
        wx=xv-xa; wy=yv-ya; wz=zv-za
        c000=vol[za,ya,xa]; c100=vol[za,ya,xb]; c010=vol[za,yb,xa]; c110=vol[za,yb,xb]
        c001=vol[zb,ya,xa]; c101=vol[zb,ya,xb]; c011=vol[zb,yb,xa]; c111=vol[zb,yb,xb]
        c00=c000*(1-wx)+c100*wx; c10=c010*(1-wx)+c110*wx; c01=c001*(1-wx)+c101*wx; c11=c011*(1-wx)+c111*wx
        c0=c00*(1-wy)+c10*wy; c1=c01*(1-wy)+c11*wy; out[valid]=c0*(1-wz)+c1*wz
        return self._bone_edges(out)

    @staticmethod
    def _plane_axes(plane: str) -> tuple[int, int]:
        p = (plane or '').lower()
        if 'sag' in p:
            return (1, 2)  # A/S
        if 'cor' in p:
            return (0, 2)  # R/S
        return (0, 1)      # R/A (Axial default)

    @staticmethod
    def _bilinear_sample(image: np.ndarray, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        h, w = image.shape[:2]
        x0 = np.floor(x).astype(int); y0 = np.floor(y).astype(int)
        x1 = x0 + 1; y1 = y0 + 1
        valid = (x0 >= 0) & (y0 >= 0) & (x1 < w) & (y1 < h)
        out = np.full(x.shape, np.nan, float)
        if not np.any(valid):
            return out
        xv = x[valid]; yv = y[valid]
        x0v=x0[valid]; x1v=x1[valid]; y0v=y0[valid]; y1v=y1[valid]
        wx=xv-x0v; wy=yv-y0v
        a=image[y0v,x0v]; b=image[y0v,x1v]; c=image[y1v,x0v]; d=image[y1v,x1v]
        out[valid]=(1-wx)*(1-wy)*a + wx*(1-wy)*b + (1-wx)*wy*c + wx*wy*d
        return out

    @staticmethod
    def _bone_edges(ct: np.ndarray) -> np.ndarray:
        """Extract a skull-selective overlay from the registered CT reslice.

        R0066 intentionally tightens the R0064 mask.  The previous 72nd-percentile
        threshold could admit scalp/soft tissue and tint most of the MR green.
        This version uses a high-density upper-tail threshold and removes tiny
        isolated components before adding a narrow visibility rim.  Only selected
        bone pixels are returned; every other pixel is NaN/transparent.
        """
        arr=np.asarray(ct,float)
        valid=np.isfinite(arr)
        finite=arr[valid]
        if finite.size < 64:
            return np.full(arr.shape, np.nan, float)
        vmin=float(np.nanmin(finite)); vmax=float(np.nanmax(finite))
        if vmax-vmin <= np.finfo(float).eps:
            return np.full(arr.shape, np.nan, float)

        p50,p85,p90,p95,p995=map(float,np.percentile(finite,[50,85,90,95,99.5]))
        # If the export is HU-like, prefer an actual osseous threshold. Otherwise
        # use the upper intensity tail.  This avoids treating scalp/brain as bone.
        hu_like=(vmin < -250.0 and vmax > 500.0)
        if hu_like:
            threshold=max(250.0, p85)
        else:
            upper_span=max(p995-p90, 0.0)
            threshold=max(p90, p90 + 0.18*upper_span)
            threshold=min(threshold, p995)
        bone=valid & (arr >= threshold)

        # 8-neighbour connected components.  Reject tiny isolated bright points
        # (noise/calcification) while retaining fragmented skull plates/rings.
        h,w=bone.shape[:2]
        seen=np.zeros((h,w),dtype=bool)
        keep=np.zeros((h,w),dtype=bool)
        min_component=max(10, int(round(h*w*0.00012)))
        for yy in range(h):
            for xx in range(w):
                if not bone[yy,xx] or seen[yy,xx]:
                    continue
                stack=[(yy,xx)]; seen[yy,xx]=True; comp=[]
                while stack:
                    cy,cx=stack.pop(); comp.append((cy,cx))
                    for dy in (-1,0,1):
                        for dx in (-1,0,1):
                            if dx==0 and dy==0: continue
                            ny,nx=cy+dy,cx+dx
                            if 0<=ny<h and 0<=nx<w and bone[ny,nx] and not seen[ny,nx]:
                                seen[ny,nx]=True; stack.append((ny,nx))
                if len(comp) >= min_component:
                    for cy,cx in comp: keep[cy,cx]=True
        if np.count_nonzero(keep) < 20:
            keep=bone

        # One-pixel rim only.  R0064 used a two-pixel dilation, which could make
        # the green overlay appear to bleed into adjacent non-bone structures.
        mask=keep.astype(float)
        gy,gx=np.gradient(mask)
        edge=np.hypot(gx,gy) > 0.05
        rim=edge.copy()
        for dy in (-1,0,1):
            for dx in (-1,0,1):
                if dx==0 and dy==0: continue
                rim |= np.roll(np.roll(edge,dy,axis=0),dx,axis=1)
        visible=keep | rim
        visible[[0,-1],:]=False; visible[:,[0,-1]]=False

        out=np.full(arr.shape, np.nan, float)
        if np.any(visible):
            scaled=np.clip((arr-threshold)/max(vmax-threshold,np.finfo(float).eps),0.0,1.0)
            dense=np.where(keep,0.58+0.32*scaled,np.nan)
            dense=np.where(rim,0.88+0.12*scaled,dense)
            out[visible]=dense[visible]
        return out

    def project_2d(self, ct: np.ndarray, mr_shape: tuple[int,int], matrix: np.ndarray, plane: str,
                   ct_pixel_mm: float = 0.5, mr_pixel_mm: tuple[float,float] = (1.0,1.0)) -> np.ndarray:
        ct=np.asarray(ct,float)
        mh,mw=int(mr_shape[0]),int(mr_shape[1])
        ch,cw=ct.shape[:2]
        axes=self._plane_axes(plane)
        rot=matrix[np.ix_(axes, axes)]
        trans=matrix[list(axes), 3]
        # Mapping output MR pixel -> source CT pixel. Invert the treatment transform.
        try:
            inv=np.linalg.inv(rot)
        except np.linalg.LinAlgError:
            inv=np.eye(2)
        yy,xx=np.mgrid[0:mh,0:mw]
        mx=(xx-(mw-1)/2.0)*float(mr_pixel_mm[0])
        my=(yy-(mh-1)/2.0)*float(mr_pixel_mm[1])
        pts=np.stack([mx-trans[0], my-trans[1]],axis=0).reshape(2,-1)
        src=inv@pts
        sx=(src[0]/float(ct_pixel_mm)+(cw-1)/2.0).reshape(mh,mw)
        sy=(src[1]/float(ct_pixel_mm)+(ch-1)/2.0).reshape(mh,mw)
        warped=self._bilinear_sample(ct,sx,sy)
        return self._bone_edges(warped)


    @staticmethod
    def _mr_edge_strength(mr: np.ndarray) -> np.ndarray:
        arr=np.asarray(mr,float)
        finite=arr[np.isfinite(arr)]
        if finite.size < 64:
            return np.zeros(arr.shape,float)
        lo,hi=np.percentile(finite,[2,98.5])
        scaled=np.clip((arr-lo)/max(hi-lo,1e-9),0,1)
        gy,gx=np.gradient(scaled)
        return np.hypot(gx,gy)


    @staticmethod
    def _largest_component(mask: np.ndarray) -> np.ndarray:
        mask=np.asarray(mask,bool)
        h,w=mask.shape[:2]
        seen=np.zeros((h,w),bool); best=[]
        for y in range(h):
            for x in range(w):
                if not mask[y,x] or seen[y,x]:
                    continue
                stack=[(y,x)]; seen[y,x]=True; comp=[]
                while stack:
                    cy,cx=stack.pop(); comp.append((cy,cx))
                    for dy in (-1,0,1):
                        for dx in (-1,0,1):
                            if dx==0 and dy==0: continue
                            ny,nx=cy+dy,cx+dx
                            if 0<=ny<h and 0<=nx<w and mask[ny,nx] and not seen[ny,nx]:
                                seen[ny,nx]=True; stack.append((ny,nx))
                if len(comp)>len(best): best=comp
        out=np.zeros((h,w),bool)
        for y,x in best: out[y,x]=True
        return out

    @classmethod
    def _outer_shell_metrics(cls, mr: np.ndarray, bone_overlay: np.ndarray) -> tuple[float,float,float]:
        """Return (median_abs_residual_px, signed_bias_px, coverage).

        The old registration selector rewarded any strong MR edge, which could
        incorrectly favor the inner brain/skull boundary.  This metric compares
        the outer radial envelope of the registered CT skull to the outer head
        silhouette on MR, making global scale/origin errors visible.
        """
        arr=np.asarray(mr,float); finite=np.isfinite(arr)
        vals=arr[finite]
        if vals.size<128: return float('inf'),float('nan'),0.0
        lo,hi=np.percentile(vals,[3,97])
        threshold=lo+0.08*max(hi-lo,1e-9)
        head=cls._largest_component(finite & (arr>threshold))
        skull=np.isfinite(bone_overlay)
        if np.count_nonzero(head)<100 or np.count_nonzero(skull)<20:
            return float('inf'),float('nan'),0.0
        yy,xx=np.nonzero(head); cy=float(np.mean(yy)); cx=float(np.mean(xx))
        def radial(mask):
            y,x=np.nonzero(mask)
            ang=np.mod(np.arctan2(y-cy,x-cx),2*np.pi)
            rad=np.hypot(x-cx,y-cy)
            bins=np.floor(ang/(2*np.pi)*180).astype(int)
            out=np.full(180,np.nan,float)
            for b in range(180):
                rv=rad[bins==b]
                if rv.size: out[b]=float(np.max(rv))
            return out
        rh=radial(head); rs=radial(skull); ok=np.isfinite(rh)&np.isfinite(rs)
        if np.count_nonzero(ok)<45: return float('inf'),float('nan'),float(np.mean(ok))
        diff=rs[ok]-rh[ok]
        return float(np.median(np.abs(diff))),float(np.median(diff)),float(np.mean(ok))

    @classmethod
    def _head_containment_fraction(cls, mr: np.ndarray, bone_overlay: np.ndarray) -> float:
        arr=np.asarray(mr,float); finite=np.isfinite(arr); vals=arr[finite]
        skull=np.isfinite(bone_overlay)
        if vals.size<128 or np.count_nonzero(skull)<20:
            return 0.0
        lo,hi=np.percentile(vals,[3,97])
        head=cls._largest_component(finite & (arr > lo+0.08*max(hi-lo,1e-9)))
        near=head.copy()
        for _ in range(5):
            expanded=near.copy()
            for dy in (-1,0,1):
                for dx in (-1,0,1):
                    expanded |= np.roll(np.roll(near,dy,axis=0),dx,axis=1)
            near=expanded
        return float(np.count_nonzero(skull & near))/float(max(1,np.count_nonzero(skull)))

    @staticmethod
    def _project_ras_to_pixel(mr_asset, mr_shape, mr_ras: np.ndarray) -> tuple[tuple[float, float] | None, bool | None]:
        mg = RegistrationOverlayService._mr_geometry(mr_asset)
        if mg is None:
            return None, None
        origin, xdir, ydir, px, py = mg
        delta = np.asarray(mr_ras, float) - origin
        pixel_x = float(np.dot(delta, xdir) / px)
        pixel_y = float(np.dot(delta, ydir) / py)
        h, w = tuple(map(int, np.asarray(mr_shape)[:2]))
        inside = 0.0 <= pixel_x < float(w) and 0.0 <= pixel_y < float(h)
        return (pixel_x, pixel_y), bool(inside)

    @staticmethod
    def _apply_matrix_hypothesis(matrix: np.ndarray, ras_xyz: np.ndarray, *, inverse: bool = False) -> np.ndarray | None:
        try:
            mat = np.asarray(matrix, float)
            if inverse:
                mat = np.linalg.inv(mat)
            vec = np.asarray([ras_xyz[0], ras_xyz[1], ras_xyz[2], 1.0], float)
            out = mat @ vec
            if abs(float(out[3])) > 1e-12:
                out = out / out[3]
            return np.asarray(out[:3], float)
        except Exception:
            return None

    @classmethod
    def _matrix_direction_diagnostic(cls, ct_ras: np.ndarray, mr_asset, mr_shape, matrix: np.ndarray) -> dict:
        result = {
            "forward_ras": None, "inverse_ras": None,
            "forward_pixel": None, "inverse_pixel": None,
            "forward_inside": None, "inverse_inside": None,
            "likely": "undetermined",
        }
        fwd = cls._apply_matrix_hypothesis(matrix, ct_ras, inverse=False)
        inv = cls._apply_matrix_hypothesis(matrix, ct_ras, inverse=True)
        if fwd is not None:
            result["forward_ras"] = tuple(map(float, fwd))
            result["forward_pixel"], result["forward_inside"] = cls._project_ras_to_pixel(mr_asset, mr_shape, fwd)
        if inv is not None:
            result["inverse_ras"] = tuple(map(float, inv))
            result["inverse_pixel"], result["inverse_inside"] = cls._project_ras_to_pixel(mr_asset, mr_shape, inv)
        if result["forward_inside"] is True and result["inverse_inside"] is not True:
            result["likely"] = "forward"
        elif result["inverse_inside"] is True and result["forward_inside"] is not True:
            result["likely"] = "inverse"
        elif result["forward_inside"] is True and result["inverse_inside"] is True:
            result["likely"] = "both-inside"
        elif result["forward_inside"] is False and result["inverse_inside"] is False:
            result["likely"] = "neither-inside"
        return result

    @classmethod
    def diagnose_reference_candidates(cls, ct_ras: np.ndarray, matrix: np.ndarray, mr_candidates: list) -> list[dict]:
        """Geometry-only candidate ranking; never modifies treatment registration."""
        rows = []
        for asset in mr_candidates:
            shape = getattr(asset, "shape", None)
            if shape is None or len(shape) < 2:
                continue
            diag = cls._matrix_direction_diagnostic(ct_ras, asset, shape, matrix)
            score = (2 if diag["forward_inside"] is True else 0) + (1 if diag["inverse_inside"] is True else 0)
            rows.append({
                "name": str(getattr(asset, "name", "") or getattr(asset, "path", "") or ""),
                "plane": str(getattr(asset, "plane", "") or ""),
                "score": score,
                **diag,
            })
        rows.sort(key=lambda row: (-int(row["score"]), row["name"].lower()))
        return rows

    @staticmethod
    def _trace_ct_voxel_to_mr_pixel(
        skull_mask: np.ndarray,
        ct_geom: CtGeometry,
        mr_asset,
        mr_shape,
        recipe: RegistrationRecipe,
    ) -> RegistrationTrace:
        """Trace representative skull voxel through forward and inverse hypotheses."""
        shape = tuple(map(int, np.asarray(mr_shape)[:2]))
        coords = np.argwhere(np.asarray(skull_mask, bool))
        if coords.size == 0:
            return RegistrationTrace(
                None, None, None, None, shape, None,
                str(recipe.matrix_source), recipe.chain_name,
                "No skull voxel available for coordinate trace",
            )

        # Explicitly validate MR geometry at trace entry.
        if RegistrationOverlayService._mr_geometry(mr_asset) is None:
            return RegistrationTrace(
                None, None, None, None, shape, None,
                str(recipe.matrix_source), recipe.chain_name,
                "MR RAS geometry unavailable",
            )

        centroid = np.mean(coords, axis=0)
        row = coords[int(np.argmin(np.sum((coords - centroid) ** 2, axis=1)))]
        z, y, x = [float(v) for v in row]
        ct_ras = (
            ct_geom.origin_ras
            + ct_geom.col_direction * (x * ct_geom.pixel_size_x)
            + ct_geom.row_direction * (y * ct_geom.pixel_size_y)
            + ct_geom.slice_direction * (z * ct_geom.slice_spacing)
        )

        diag = RegistrationOverlayService._matrix_direction_diagnostic(
            np.asarray(ct_ras, float), mr_asset, shape, recipe.matrix
        )
        return RegistrationTrace(
            (x, y, z),
            tuple(map(float, ct_ras)),
            diag["forward_ras"],
            diag["forward_pixel"],
            shape,
            diag["forward_inside"],
            str(recipe.matrix_source),
            recipe.chain_name,
            "Forward and inverse matrix directions compared geometrically; overlay itself remains forward/exported",
            forward_pixel_xy=diag["forward_pixel"],
            inverse_pixel_xy=diag["inverse_pixel"],
            forward_inside=diag["forward_inside"],
            inverse_inside=diag["inverse_inside"],
            likely_matrix_direction=str(diag["likely"]),
        )

    @classmethod
    def _alignment_score(cls, mr: np.ndarray, bone_overlay: np.ndarray) -> float:
        edge=np.isfinite(bone_overlay)
        if np.count_nonzero(edge) < 20:
            return float('-inf')
        mr_edge=cls._mr_edge_strength(mr)
        vals=mr_edge[edge]
        if vals.size < 20:
            return float('-inf')
        # Reward bone edges that land on strong MR anatomical boundaries while
        # mildly penalizing overlays that cover an excessive fraction of image.
        score=float(np.nanmean(vals))
        density=float(np.count_nonzero(edge))/float(edge.size)
        return score-0.12*max(0.0,density-0.12)

    @staticmethod
    def _volume_plane_slices(volume: np.ndarray, plane: str):
        vol=np.asarray(volume,float)
        p=(plane or '').lower()
        if vol.ndim != 3:
            return []
        if 'sag' in p:
            return [(i,vol[:,:,i]) for i in range(vol.shape[2])]
        if 'cor' in p:
            return [(i,vol[:,i,:]) for i in range(vol.shape[1])]
        return [(i,vol[i,:,:]) for i in range(vol.shape[0])]

    def _registration_hypotheses(self, workspace: Path, sonication_index: int, mr_asset, ctmr: np.ndarray):
        """Return evidence-preserving transform hypotheses.

        Legacy diagnostic helper only. Production render_volume does not use hypotheses;
        it replays the accepted export registration deterministically. This helper
        is retained for engineering comparison and must not select production data.
        """
        out=[("CtMr",ctmr)]
        try: out.append(("inv(CtMr)",np.linalg.inv(ctmr)))
        except np.linalg.LinAlgError: pass
        category=str(getattr(mr_asset,'category','') or '').upper()
        if category.startswith('PREPLANNING_MR'):
            mp=self.find_treatment_mrmr_matrix(Path(workspace),sonication_index)
            mm=self.read_matrix(mp)
            if mm is not None:
                combos=[]
                try: combos.append(("inv(MrMr) × CtMr",np.linalg.inv(mm)@ctmr))
                except np.linalg.LinAlgError: pass
                combos.append(("MrMr × CtMr",mm@ctmr))
                try: combos.append(("CtMr × inv(MrMr)",ctmr@np.linalg.inv(mm)))
                except np.linalg.LinAlgError: pass
                combos.append(("CtMr × MrMr",ctmr@mm))
                out=combos+out
        # de-duplicate numerically equivalent candidates
        unique=[]
        for name,m in out:
            if not any(np.allclose(m,u[1],rtol=1e-7,atol=1e-7) for u in unique): unique.append((name,m))
        return unique

    def render_volume(self, workspace: Path, sonication_index: int, mr: np.ndarray, plane: str,
                      ct_asset, ct_volume: np.ndarray, mr_asset=None) -> RegistrationOverlayResult:
        workspace=Path(workspace)
        recipe=self._registration_recipe(workspace,sonication_index,mr_asset)
        matrix_path=self.find_treatment_matrix(workspace,sonication_index)
        if recipe is None:
            return RegistrationOverlayResult(None,None,matrix_path,getattr(ct_asset,'path',None),
                "Accepted treatment registration chain is incomplete (CtMr/MrMr matrix unavailable)")
        if not recipe.valid or not recipe.up_to_date:
            rgs_name=recipe.rgs_source.name if recipe.rgs_source is not None else 'RGS unavailable'
            return RegistrationOverlayResult(None,recipe.matrix,recipe.matrix_source,getattr(ct_asset,'path',None),
                f"Saved registration rejected by export metadata: {rgs_name} · valid={recipe.valid} · up-to-date={recipe.up_to_date}")
        ct_geom=self.read_ct_geometry(workspace,ct_asset)
        mr_geom=self._mr_geometry(mr_asset)
        if ct_geom is None or mr_geom is None:
            missing=[]
            if ct_geom is None: missing.append("CT voxel/RAS geometry")
            if mr_geom is None: missing.append("MR RAS geometry")
            return RegistrationOverlayResult(None,recipe.matrix,recipe.matrix_source,getattr(ct_asset,'path',None),
                "Saved registration decoded, but " + " + ".join(missing) + " is unavailable; overlay suppressed")
        profile=self.read_vendor_bone_profile(workspace)
        skull_mask=self.build_vendor_skull_mask(ct_volume,profile)
        # Deterministic replay: recipe.matrix is always CT RAS -> displayed MR RAS.
        # Therefore target-MR patient coordinates are mapped back to CT with inverse(matrix).
        overlay=self._world_reslice_mask(skull_mask,np.asarray(mr).shape[:2],mr_asset,ct_geom,recipe.matrix,'CtMr')
        if overlay is None or not np.isfinite(overlay).any():
            return RegistrationOverlayResult(None,recipe.matrix,recipe.matrix_source,getattr(ct_asset,'path',None),
                f"Saved registration {recipe.chain_name} produced no CT skull intersection with the displayed MR plane")
        # QA is diagnostic only. It never selects, changes, flips or optimizes the saved matrix.
        edge_score=self._alignment_score(mr,overlay)
        residual,bias,coverage=self._outer_shell_metrics(mr,overlay)
        containment=self._head_containment_fraction(mr,overlay)
        trace=self._trace_ct_voxel_to_mr_pixel(skull_mask,ct_geom,mr_asset,np.asarray(mr).shape[:2],recipe)
        profile_src=profile.source.name if profile.source is not None else 'built-in fallback'
        rgs_name=recipe.rgs_source.name if recipe.rgs_source is not None else 'RGS unavailable'
        gross_mismatch = (
            (np.isfinite(residual) and residual > max(18.0, 0.06 * min(np.asarray(mr).shape[:2])))
            or (np.isfinite(coverage) and coverage < 0.20)
            or (np.isfinite(containment) and containment < 0.35)
        )
        if gross_mismatch:
            if trace.forward_inside is False and trace.inverse_inside is True:
                likely="exported matrix direction is inconsistent with displayed MR; inverse hypothesis lands inside MR FOV"
            elif trace.forward_inside is False and trace.inverse_inside is False:
                likely="both forward and inverse hypotheses miss displayed MR: matrix direction / MR geometry / reference-plane mismatch"
            elif trace.inside_display is False:
                likely="representative CT skull point transforms outside displayed MR"
            elif containment < 0.35:
                likely="transformed skull intersects MR frame but lies mostly outside the MR head: geometry/reference mismatch"
            else:
                likely="outer-skull geometry disagreement"
            status=(f"Registration suppressed · {likely} · exported {recipe.chain_name} does not geometrically agree with displayed MR · "
                    f"outer residual={residual:.1f}px, bias={bias:+.1f}px, coverage={coverage:.2f}, containment={containment:.2f} · "
                    f"TRACE: CT voxel={trace.ct_voxel_xyz} → CT RAS={trace.ct_ras_xyz} → "
                    f"forward MR RAS={trace.mr_ras_xyz}, forward MR pixel={trace.forward_pixel_xy} (inside={trace.forward_inside}) / "
                    f"inverse MR pixel={trace.inverse_pixel_xy} (inside={trace.inverse_inside}) · "
                    f"direction diagnostic={trace.likely_matrix_direction}, MR shape={trace.mr_shape} · "
                    f"matrix={trace.matrix_source} · check CtMr/MrMr direction, displayed MR geometry/plane, and CT geometry; "
                    f"no automatic image-similarity correction applied")
            return RegistrationOverlayResult(None,recipe.matrix,recipe.matrix_source,getattr(ct_asset,'path',None),
                                             status,None,float(edge_score) if np.isfinite(edge_score) else None)
        orientation=recipe.orientation or 'unspecified'
        initial=recipe.initial_solution or 'unspecified'
        status=(f"Registration ON · export-replay deterministic · {recipe.chain_name} · matrix {recipe.matrix_source.name} · "
                f"RGS {rgs_name}: valid/up-to-date · registration MR={orientation} · initial={initial} · "
                f"CT geometry {ct_geom.source.name} · signed HU · bone {profile.low_hu:g}..{profile.high_hu:g} HU "
                f"({profile_src}/{profile.source_section}) · QA only: edge={edge_score:.3f}, outer residual={residual:.1f}px, bias={bias:+.1f}px, coverage={coverage:.2f}, containment={containment:.2f} · "
                f"TRACE CT voxel={trace.ct_voxel_xyz} → forward MR pixel={trace.forward_pixel_xy}, inverse MR pixel={trace.inverse_pixel_xy}, "
                f"direction={trace.likely_matrix_direction}")
        return RegistrationOverlayResult(overlay,recipe.matrix,recipe.matrix_source,getattr(ct_asset,'path',None),status,None,float(edge_score) if np.isfinite(edge_score) else None)

    def render(self, workspace: Path, sonication_index: int, mr: np.ndarray, plane: str,
               ct_asset, ct_array: np.ndarray, mr_asset=None) -> RegistrationOverlayResult:
        matrix_path=self.find_treatment_matrix(Path(workspace), sonication_index)
        matrix=self.read_matrix(matrix_path)
        if matrix is None:
            return RegistrationOverlayResult(None,None,matrix_path,getattr(ct_asset,'path',None),"Treatment CtMr registration matrix unavailable")
        mr_px=(float(getattr(mr_asset,'pixel_size_x',1.0) or 1.0), float(getattr(mr_asset,'pixel_size_y',1.0) or 1.0))
        overlay=self.project_2d(ct_array, np.asarray(mr).shape[:2], matrix, plane, 0.5, mr_px)
        finite=np.isfinite(overlay)
        status=(f"Registration ON · treatment CtMr matrix: {matrix_path.name} · "
                f"{plane} 2-D projection · bone edge pixels={int(np.count_nonzero(finite))}")
        return RegistrationOverlayResult(overlay,matrix,matrix_path,getattr(ct_asset,'path',None),status)
