from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path, PurePosixPath
import shutil
import tempfile
import zipfile


@dataclass(slots=True)
class SpectrumDumpCandidate:
    label: str
    raw_path: Path | None
    fft_path: Path | None
    relative_path: str
    family: str

    @property
    def primary_path(self) -> Path:
        return self.fft_path or self.raw_path  # type: ignore[return-value]

    @property
    def completeness(self) -> str:
        if self.raw_path is not None and self.fft_path is not None:
            return "RAW + FFT"
        if self.fft_path is not None:
            return "FFT only"
        return "RAW only"


@dataclass(slots=True)
class SpectrumDumpSource:
    source: Path
    workspace: Path
    candidates: list[SpectrumDumpCandidate]
    temporary: bool = False


class SpectrumDumpImportService:
    """Discover CPC/Spectrum dump pairs from a ZIP, folder, or one file.

    The browser deliberately stays file-family based.  A candidate is a logical
    measurement containing Spectrum_*.dmp and, when present, its matching
    Spectrum_*.dmp_FFT companion.  SpectrumMsg*.dmp is also surfaced as a
    distinct message-stream family but is never relabelled as physical 8CH CPC.
    """

    def __init__(self) -> None:
        self._temp_dirs: list[Path] = []

    @staticmethod
    def _validate_zip_member(name: str) -> None:
        normalized = name.replace("\\", "/")
        member = PurePosixPath(normalized)
        if member.is_absolute() or ".." in member.parts:
            raise ValueError(f"Unsafe ZIP entry rejected: {name}")
        if member.parts and ":" in member.parts[0]:
            raise ValueError(f"Unsafe ZIP entry rejected: {name}")

    def open_source(self, source: Path) -> SpectrumDumpSource:
        source = source.expanduser().resolve()
        temporary = False
        if source.is_dir():
            workspace = source
        elif source.is_file() and source.suffix.lower() == ".zip":
            workspace = Path(tempfile.mkdtemp(prefix="SpectrumDump_"))
            temporary = True
            try:
                with zipfile.ZipFile(source) as archive:
                    bad = archive.testzip()
                    if bad:
                        raise ValueError(f"Corrupted ZIP member: {bad}")
                    for info in archive.infolist():
                        self._validate_zip_member(info.filename)
                    archive.extractall(workspace)
            except Exception:
                shutil.rmtree(workspace, ignore_errors=True)
                raise
            self._temp_dirs.append(workspace)
        elif source.is_file():
            workspace = source.parent
        else:
            raise FileNotFoundError(f"Source not found: {source}")

        candidates = self.discover(workspace, selected_file=source if source.is_file() and source.suffix.lower() != ".zip" else None)
        return SpectrumDumpSource(source=source, workspace=workspace, candidates=candidates, temporary=temporary)

    @staticmethod
    def _is_spectrum_file(path: Path) -> bool:
        low = path.name.lower()
        return (
            (low.endswith(".dmp") or low.endswith(".dmp_fft"))
            and "spectrum" in low
        )

    @staticmethod
    def _key_for(path: Path) -> str:
        low = path.name.lower()
        if low.endswith(".dmp_fft"):
            return path.name[:-4]  # remove _FFT, keep .dmp stem identity
        return path.name

    def discover(self, workspace: Path, selected_file: Path | None = None) -> list[SpectrumDumpCandidate]:
        if selected_file is not None:
            if not self._is_spectrum_file(selected_file):
                raise ValueError("Selected file is not a Spectrum dump (*.dmp / *.dmp_FFT).")
            files = [selected_file]
            # A single-file selection is deterministic, but still bring in the
            # exact same-directory companion automatically when it exists.
            low = selected_file.name.lower()
            if low.endswith(".dmp_fft"):
                companion = selected_file.with_name(selected_file.name[:-4])
            else:
                companion = selected_file.with_name(selected_file.name + "_FFT")
            if companion.exists():
                files.append(companion)
        else:
            files = sorted(
                (p for p in workspace.rglob("*") if p.is_file() and self._is_spectrum_file(p)),
                key=lambda p: str(p).lower(),
            )

        groups: dict[tuple[str, str], dict[str, Path]] = {}
        for path in files:
            low = path.name.lower()
            family = "SpectrumMsg" if "spectrummsg" in low else "CPC Spectrum"
            key_name = self._key_for(path).lower()
            group_key = (str(path.parent.resolve()).lower() + "::" + key_name, family)
            bucket = groups.setdefault(group_key, {})
            if low.endswith(".dmp_fft"):
                bucket["fft"] = path
            else:
                bucket["raw"] = path

        out: list[SpectrumDumpCandidate] = []
        for (_, family), bucket in groups.items():
            raw = bucket.get("raw")
            fft = bucket.get("fft")
            primary = fft or raw
            if primary is None:
                continue
            try:
                rel = str(primary.relative_to(workspace))
            except ValueError:
                rel = primary.name
            base = (raw or fft).name if (raw or fft) is not None else primary.name
            if base.lower().endswith(".dmp_fft"):
                base = base[:-4]
            out.append(SpectrumDumpCandidate(
                label=base,
                raw_path=raw,
                fft_path=fft,
                relative_path=rel,
                family=family,
            ))
        out.sort(key=lambda c: (0 if c.family == "CPC Spectrum" else 1, c.relative_path.lower()))
        return out


    @staticmethod
    def _explicit_sonication_number(candidate: SpectrumDumpCandidate) -> int | None:
        """Return SonicationN encoded in the candidate path, if present."""
        for part in reversed(Path(candidate.relative_path).parts):
            compact = str(part).lower().replace("_", "").replace("-", "").replace(" ", "")
            if compact.startswith("sonication"):
                suffix = compact[len("sonication"): ]
                if suffix.isdigit():
                    return int(suffix)
        return None

    def map_candidates_to_sonications(self, candidates: list[SpectrumDumpCandidate], sonications: list[object]) -> dict[int, SpectrumDumpCandidate]:
        """Build one deterministic Sonication -> physical CPC SpectrumDumps mapping.

        Explicit ``SonicationN`` directory identity wins.  Remaining CPC
        candidates are assigned positionally only when that mapping is
        unambiguous.  SpectrumMsg entries are intentionally excluded because
        they are not the physical 8-channel CPC source used by this analyzer.
        """
        physical = [c for c in candidates if c.family == "CPC Spectrum"]
        mapping: dict[int, SpectrumDumpCandidate] = {}
        used: set[int] = set()

        # 1) Explicit treatment-export folder identity is authoritative.
        for ci, candidate in enumerate(physical):
            number = self._explicit_sonication_number(candidate)
            if number is None:
                continue
            index = number - 1
            if 0 <= index < len(sonications) and index not in mapping:
                mapping[index] = candidate
                used.add(ci)

        # 2) Match the actual Sonication folder/name when it appears in path.
        for si, son in enumerate(sonications):
            if si in mapping:
                continue
            tokens = []
            name = getattr(son, "name", "")
            folder = getattr(son, "folder", None)
            if name:
                tokens.append(str(name).lower().replace(" ", ""))
            if folder is not None:
                tokens.append(Path(folder).name.lower().replace(" ", ""))
            matches = []
            for ci, candidate in enumerate(physical):
                if ci in used:
                    continue
                rel = candidate.relative_path.lower().replace(" ", "")
                if any(token and token in rel for token in tokens):
                    matches.append((ci, candidate))
            if len(matches) == 1:
                ci, candidate = matches[0]
                mapping[si] = candidate
                used.add(ci)

        # 3) Positional fallback only when the remaining cardinality matches.
        remaining_s = [i for i in range(len(sonications)) if i not in mapping]
        remaining_c = [(ci, c) for ci, c in enumerate(physical) if ci not in used]
        if remaining_s and len(remaining_s) == len(remaining_c):
            remaining_c.sort(key=lambda item: item[1].relative_path.lower())
            for si, (ci, candidate) in zip(remaining_s, remaining_c):
                mapping[si] = candidate
                used.add(ci)

        return mapping

    def cleanup(self) -> None:
        for path in self._temp_dirs:
            shutil.rmtree(path, ignore_errors=True)
        self._temp_dirs.clear()
