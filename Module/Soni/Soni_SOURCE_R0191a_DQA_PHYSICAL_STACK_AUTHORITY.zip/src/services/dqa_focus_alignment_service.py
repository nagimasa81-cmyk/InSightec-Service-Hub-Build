from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import math
import re

import numpy as np

from src.parsers.ado_rowset import parse_ado_rowset
from src.services.raw_service import RawService
from src.services.transducer_location_service import TransducerLocationService


@dataclass(slots=True)
class DqaFocusAlignment:
    x_mm: float | None = None
    y_mm: float | None = None
    z_mm: float | None = None
    tilt_deg: float | None = None
    confidence: str = "Unavailable"
    evidence: list[str] = field(default_factory=list)
    excluded_reason: str | None = None
    judgement_excluded_reason: str | None = None
    reference_xyz: tuple[float,float,float] | None = None
    registered_focal_ras: tuple[float,float,float] | None = None
    baseline_to_focal_mm: float | None = None
    calculator_contract: str = "R0190e"
    diagnostic_overlays: dict[str, dict[str, object]] = field(default_factory=dict)
    observed_target_x_mm: float | None = None
    observed_target_y_mm: float | None = None
    observed_target_z_mm: float | None = None
    observed_target_phase_axis: str | None = None

    @property
    def alert(self) -> bool:
        if self.excluded_reason or self.judgement_excluded_reason:
            return False
        return bool(
            (self.x_mm is not None and abs(float(self.x_mm)) >= 15.0)
            or (self.y_mm is not None and abs(float(self.y_mm)) >= 15.0)
            or (self.z_mm is not None and abs(float(self.z_mm)) >= 20.0)
        )

    @property
    def display(self) -> str:
        if self.excluded_reason:
            return f"N/A — {self.excluded_reason}"
        def f(name: str, value: float | None, unit: str = "mm") -> str:
            return f"{name} {value:+.1f} {unit}" if value is not None and np.isfinite(value) else f"{name} —"
        text="  ".join((f("X", self.x_mm), f("Y", self.y_mm), f("Z", self.z_mm), f("Tilt", self.tilt_deg, "°")))
        if self.judgement_excluded_reason:
            text += "  · Not judged"
        return text


class DqaFocusAlignmentService:
    """Recover DQA mechanical focus alignment and optional thermal focus evidence.

    The DQA *series* alignment follows the workstation/phantom geometry contract:
      * the XD is mechanically fixed for the DQA series;
      * X is the fixed natural-focus left/right offset from the phantom centre
        measured from the DQA-Axial stack;
      * Y is the fixed natural-focus anterior/posterior offset from the phantom
        centre measured from the DQA-Sagittal stack;
      * Z is the same fixed natural focus relative to the lower phantom baseline
        measured from the DQA-Sagittal stack;
      * Tilt is the sagittal phantom-baseline angle, image horizontal = 0 degrees.

    Individual thermal-focus evidence remains a separate contract: observed heated
    focus minus the planned focus of the same Sonication.  It must never be used to
    manufacture missing series geometry, and T2*/NFUSCAL anatomical data must never
    be relabelled as thermometry.
    """

    def __init__(self) -> None:
        self.raw = RawService()
        self._cache: dict[str, DqaFocusAlignment] = {}
        self._reference_cache: dict[str, dict[str, object]] = {}

    @staticmethod
    def is_dqa(package) -> bool:
        """Return True only from treatment-specific DQA evidence.

        Installed exports may contain generic Brain220/Brain650 DQA templates even
        during ordinary treatment, so template presence alone is not sufficient.
        Prefer the actual per-sonication protocol recorded by SonicationSummary or
        ProtocolData. This also works when the ZIP/folder name itself has no DQA
        token, as observed in real Brain220 DQA exports.
        """
        workspace = Path(getattr(package, "workspace", "") or ".")
        candidates = []
        for name in ("SonicationSummary.xml", "ProtocolData.xml"):
            try:
                candidates.extend(sorted(workspace.rglob(name), key=lambda p: (len(p.parts), str(p).lower()))[:2])
            except Exception:
                pass
        for path in candidates:
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            low = text.lower()
            if path.name.lower() == "sonicationsummary.xml":
                # Actual treatment protocol, not merely a protocol template.
                if re.search(r"treatprotocol\s*=\s*['\"][^'\"]*dqa", text, re.I):
                    return True
            else:
                if re.search(r"(?:name|predefinedspotspath)\s*=\s*['\"][^'\"]*dqa", text, re.I):
                    return True
        # Legacy fallback: an explicitly DQA-named source is useful only when
        # treatment protocol tables are absent. It must not override a normal
        # SonicationSummary such as treatprotocol='Brain-Treat'.
        has_summary = any(p.name.lower() == "sonicationsummary.xml" for p in candidates)
        if not has_summary:
            return "dqa" in str(getattr(package, "source", "")).lower()
        return False

    @staticmethod
    def _find_mri_params(workspace: Path) -> Path | None:
        for name in ("MriImageParams.xml", "MRIImageParams.xml"):
            items = sorted(Path(workspace).rglob(name), key=lambda p: (len(p.parts), str(p).lower()))
            if items:
                return items[0]
        return None

    @staticmethod
    def _row_by_number(path: Path | None) -> dict[int, dict[str, object]]:
        if path is None:
            return {}
        try:
            rows = parse_ado_rowset(path)
        except Exception:
            return {}
        out: dict[int, list[dict[str, object]]] = {}
        for row in rows:
            try:
                n = int(float(row.get("sonicationindex", "")))
            except (TypeError, ValueError):
                continue
            out.setdefault(n, []).append(row)
        best: dict[int, dict[str, object]] = {}
        for n, candidates in out.items():
            def quality(row):
                series = str(row.get("seriesdiscription") or row.get("seriesdescription") or "").upper()
                treatment = int(any(t in series for t in ("MEMP", "TMAP", "THERM")))
                try:
                    sx = float(row.get("pixsizex") or 0); sy = float(row.get("pixsizey") or 0)
                    pixels = int(sx > 0 and sy > 0)
                except Exception:
                    pixels = 0
                try:
                    rv = np.asarray([float(row.get(k, 0)) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")])
                    cv = np.asarray([float(row.get(k, 0)) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")])
                    cos = int(np.linalg.norm(rv) > .5 and np.linalg.norm(cv) > .5)
                except Exception:
                    cos = 0
                return treatment, pixels, cos
            best[n] = max(candidates, key=quality)
        return best

    @staticmethod
    def _orientation(row: dict[str, object]) -> str | None:
        try:
            rv = np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")], float)
            cv = np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")], float)
            normal = np.cross(rv, cv)
            axis = int(np.argmax(np.abs(normal)))
            return ("Sagittal", "Coronal", "Axial")[axis]
        except Exception:
            return None

    @staticmethod
    def _pixel_sizes(row: dict[str, object]) -> tuple[float, float] | None:
        try:
            sx = float(row.get("pixsizex")); sy = float(row.get("pixsizey"))
            if sx <= 0 or sy <= 0 or not np.isfinite([sx, sy]).all():
                return None
            return sx, sy
        except Exception:
            return None

    @staticmethod
    def _ras_delta(row: dict[str, object], dx: float, dy: float) -> np.ndarray | None:
        sizes = DqaFocusAlignmentService._pixel_sizes(row)
        if sizes is None:
            return None
        try:
            rv = np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")], float)
            cv = np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")], float)
        except Exception:
            return None
        # The displayed RAW raster uses exported COLUMN direction on screen X
        # and exported ROW direction on screen Y (same convention as metadata UI).
        sx, sy = sizes
        return cv * (float(dx) * sx) + rv * (float(dy) * sy)

    @staticmethod
    def _phase_axis(row: dict[str, object]) -> str | None:
        """Resolve phase-encoding anatomical axis from THIS raster only.

        freqdirection names the exported frequency-encoding image dimension.
        Screen X follows exported COLUMN cosine and screen Y follows ROW cosine in
        this reader, therefore the orthogonal in-plane direction is phase.
        Never inherit a phase axis from another Sonication/raster.
        """
        try:
            rv=np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")],float)
            cv=np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")],float)
            def axis(v):
                i=int(np.argmax(np.abs(v)))
                return ("RL","AP","SI")[i] if abs(float(v[i])) >= 0.85 else None
            fd=str(row.get("freqdirection") or "").strip().upper()
            if fd == "ROW": return axis(cv)
            if fd in ("COL","COLUMN"): return axis(rv)
        except Exception:
            return None
        return None

    @staticmethod
    def _coherent_hotspot_centroid(delta: np.ndarray, hx: float, hy: float, radius: int = 5) -> tuple[float,float]:
        """Sub-pixel centre of the coherent thermal blob around a detected peak.

        The peak detector chooses the correct local blob; this step centres the
        marker on that blob instead of leaving it on the hottest/smoothed pixel.
        Weights are local temperature rise above the patch median, so no planned
        target or expected DQA displacement can pull the centroid.
        """
        a=np.asarray(delta,float); h,w=a.shape
        ix=int(round(hx)); iy=int(round(hy)); r=max(2,int(radius))
        xa=max(0,ix-r); xb=min(w,ix+r+1); ya=max(0,iy-r); yb=min(h,iy+r+1)
        patch=np.asarray(a[ya:yb,xa:xb],float)
        finite=patch[np.isfinite(patch)]
        if finite.size < 4: return float(hx),float(hy)
        floor=float(np.nanmedian(finite))
        weights=np.where(np.isfinite(patch),np.maximum(patch-floor,0.0),0.0)
        if float(weights.sum()) <= 0: return float(hx),float(hy)
        gy,gx=np.indices(weights.shape)
        return xa+float((weights*gx).sum()/weights.sum()), ya+float((weights*gy).sum()/weights.sum())

    def _hotspot(self, son) -> tuple[float, float, int] | None:
        frames = list(getattr(son, "temperature_frames", []) or [])
        if not frames:
            return None
        try:
            baseline = self.raw.read_temperature(frames[0].path)
        except Exception:
            return None
        finite = baseline[np.isfinite(baseline)]
        absolute = bool(finite.size and 15.0 <= float(np.nanmedian(finite)) <= 80.0)
        best = None
        h, w = baseline.shape
        y0, y1 = int(.10*h), int(.90*h); x0, x1 = int(.10*w), int(.90*w)
        for i, frame in enumerate(frames):
            try:
                arr = self.raw.read_temperature(frame.path)
            except Exception:
                continue
            delta = arr - baseline if absolute else arr
            roi = np.asarray(delta[y0:y1, x0:x1], float)
            if not np.isfinite(roi).any():
                continue
            flat = int(np.nanargmax(roi)); yy, xx = np.unravel_index(flat, roi.shape)
            yy += y0; xx += x0
            peak = float(delta[yy, xx])
            if best is None or peak > best[0]:
                # Local weighted centroid reduces single-pixel noise without
                # changing the measured focus to a global threshold centroid.
                r = 6
                ya, yb = max(0, yy-r), min(h, yy+r+1); xa, xb = max(0, xx-r), min(w, xx+r+1)
                patch = np.asarray(delta[ya:yb, xa:xb], float)
                floor = float(np.nanpercentile(patch[np.isfinite(patch)], 50)) if np.isfinite(patch).any() else 0.0
                weights = np.maximum(patch - floor, 0.0)
                if np.isfinite(weights).all() and float(weights.sum()) > 0:
                    gy, gx = np.indices(weights.shape)
                    cx = xa + float((weights * gx).sum() / weights.sum())
                    cy = ya + float((weights * gy).sum() / weights.sum())
                else:
                    cx, cy = float(xx), float(yy)
                best = (peak, cx, cy, i)
        return (best[1], best[2], best[3]) if best is not None else None

    def _magnitude_for(self, son, temp_index: int) -> np.ndarray | None:
        """Deprecated: index-based thermal/magnitude pairing is forbidden in R0190."""
        return None

    @staticmethod
    def _norm(image: np.ndarray) -> np.ndarray:
        arr = np.asarray(image, float)
        finite = arr[np.isfinite(arr)]
        if not finite.size:
            return np.zeros_like(arr)
        lo, hi = np.nanpercentile(finite, [2, 98])
        if hi <= lo:
            lo=float(np.nanmin(finite)); hi=float(np.nanmax(finite))
            if hi <= lo:
                return np.zeros_like(arr)
        return np.clip((arr-lo)/(hi-lo), 0.0, 1.0)

    @classmethod
    def _baseline_line(cls, image: np.ndarray) -> tuple[float, float, float] | None:
        """Detect the *upper* edge of the DQA sagittal lower reference bar.

        The physical DQA lower reference is a finite-thickness horizontal bar.  The
        old implementation simply selected the strongest gradient in the lower
        half; on real 4267 data that locks to the bar's lower edge (~y=144) instead
        of its upper/reference edge (~y=138), creating an artificial ~12 mm SI
        error.  Rank horizontal bands by cross-column support, then prefer the
        upper member of a close parallel-edge pair.  No expected displacement is
        used by this detector.
        """
        a=cls._norm(image); h,w=a.shape
        gy=np.abs(a[2:,:]-a[:-2,:])
        xa,xb=int(.28*w),int(.72*w); ya,yb=int(.48*h),int(.82*h)
        if xb-xa<20 or yb-ya<12: return None
        band=np.nanmedian(gy[ya-1:yb-1,xa:xb],axis=1)
        if not np.isfinite(band).any(): return None
        # Local maxima with meaningful support.
        finite=band[np.isfinite(band)]
        floor=max(float(np.nanpercentile(finite,65)),1e-4)
        peaks=[]
        for i in range(1,len(band)-1):
            if np.isfinite(band[i]) and band[i]>=band[i-1] and band[i]>=band[i+1] and band[i]>=floor:
                peaks.append((float(band[i]),ya+i+1))
        if not peaks: return None
        peaks=sorted(peaks,reverse=True)[:10]
        # A real lower-reference bar has two strong, nearly parallel edges.  Use
        # its upper edge.  This rejects the old strongest-edge/lower-edge bias.
        yc=None
        by_y=sorted(peaks,key=lambda z:z[1])
        pair_scores=[]
        for i,(si,yi) in enumerate(by_y):
            for sj,yj in by_y[i+1:]:
                gap=yj-yi
                if 3<=gap<=10:
                    pair_scores.append((min(si,sj),si+sj,-gap,yi))
        if pair_scores:
            yc=max(pair_scores)[3]-1  # central-difference peak -> physical upper edge
        else:
            yc=max(peaks)[1]
        xs=[];ys=[];strengths=[]
        for x in range(xa,xb):
            ylo=max(1,int(yc)-1); yhi=min(h-2,int(yc)+2)
            col=gy[ylo-1:yhi-1,x]
            if not col.size or not np.isfinite(col).any(): continue
            vmax=float(np.nanmax(col))
            eligible=np.flatnonzero(col >= max(.30*vmax,.015))
            if not eligible.size: continue
            j=int(eligible[0]); y=ylo+j
            xs.append(float(x));ys.append(float(y));strengths.append(vmax)
        if len(xs)<24: return None
        x=np.asarray(xs);y=np.asarray(ys);st=np.asarray(strengths)
        keep=st>=np.nanpercentile(st,35);x=x[keep];y=y[keep]
        if x.size<20:return None
        for _ in range(3):
            slope,intercept=np.polyfit(x,y,1)
            resid=y-(slope*x+intercept); med=float(np.nanmedian(resid)); mad=float(np.nanmedian(np.abs(resid-med)))
            keep=np.abs(resid-med)<=max(1.25,3.0*mad)
            if keep.sum()<20: break
            x=x[keep];y=y[keep]
        slope,intercept=np.polyfit(x,y,1)
        support=min(1.0,float(x.size)/max(1,(xb-xa)*.55))
        if abs(float(slope))>.20:return None
        return float(slope),float(intercept),support


    @classmethod
    def _baseline_edge_pair(cls, image: np.ndarray) -> list[tuple[float,float,float]]:
        """Return both supported edges of the finite-thickness sagittal DQA bar.

        Pixel top/bottom is not anatomical S/I: some exports reverse the sagittal
        column direction.  Callers must transform both edges to MR-RAS and choose
        the physically superior edge.  This prevents SI sign/edge regressions
        across differently oriented exports.
        """
        a=cls._norm(image); h,w=a.shape
        gy=np.abs(a[2:,:]-a[:-2,:])
        xa,xb=int(.28*w),int(.72*w); ya,yb=int(.45*h),int(.86*h)
        if xb-xa<20 or yb-ya<12: return []
        band=np.nanmedian(gy[ya-1:yb-1,xa:xb],axis=1)
        finite=band[np.isfinite(band)]
        if not finite.size: return []
        floor=max(float(np.nanpercentile(finite,62)),1e-4)
        peaks=[]
        for i in range(1,len(band)-1):
            if np.isfinite(band[i]) and band[i]>=band[i-1] and band[i]>=band[i+1] and band[i]>=floor:
                peaks.append((float(band[i]),ya+i+1))
        if len(peaks)<2: return []
        peaks=sorted(peaks,reverse=True)[:14]
        pairs=[]
        by_y=sorted(peaks,key=lambda z:z[1])
        for i,(si,yi) in enumerate(by_y):
            for sj,yj in by_y[i+1:]:
                gap=yj-yi
                if 3<=gap<=12:
                    pairs.append((min(si,sj),si+sj,-abs(gap-6),yi,yj))
        if not pairs: return []
        _,_,_,yu,yl=max(pairs)

        def fit_near(yc):
            xs=[]; ys=[]; strengths=[]
            for x in range(xa,xb):
                ylo=max(1,int(yc)-2); yhi=min(h-2,int(yc)+3)
                col=gy[ylo-1:yhi-1,x]
                if not col.size or not np.isfinite(col).any(): continue
                j=int(np.nanargmax(col)); vmax=float(col[j])
                if vmax < max(.012,.25*float(np.nanmax(gy[:,x]))): continue
                # sub-pixel parabolic interpolation in y
                yy=float(ylo+j)
                gi=ylo-1+j
                if 0 < gi < gy.shape[0]-1:
                    a0,a1,a2=float(gy[gi-1,x]),float(gy[gi,x]),float(gy[gi+1,x])
                    den=a0-2*a1+a2
                    if abs(den)>1e-12:
                        yy += float(np.clip(.5*(a0-a2)/den,-.5,.5))
                xs.append(float(x)); ys.append(yy); strengths.append(vmax)
            if len(xs)<24: return None
            x=np.asarray(xs); y=np.asarray(ys); st=np.asarray(strengths)
            keep=st>=np.nanpercentile(st,30); x=x[keep]; y=y[keep]
            if x.size<20:return None
            for _ in range(3):
                slope,intercept=np.polyfit(x,y,1)
                resid=y-(slope*x+intercept); med=float(np.nanmedian(resid)); mad=float(np.nanmedian(np.abs(resid-med)))
                keep=np.abs(resid-med)<=max(1.0,3.0*mad)
                if keep.sum()<20: break
                x=x[keep]; y=y[keep]
            slope,intercept=np.polyfit(x,y,1)
            support=min(1.0,float(x.size)/max(1,(xb-xa)*.55))
            if abs(float(slope))>.20:return None
            return float(slope),float(intercept),support
        out=[]
        for yc in (yu-1,yl-1):
            v=fit_near(yc)
            if v is not None: out.append(v)
        return out

    @classmethod
    def _geometric_lr_center(cls, image: np.ndarray) -> tuple[float,float,float] | None:
        """Centre from opposing phantom edges, not an all-gradient circle fit.

        DQA HASTE images contain bright internal structures that bias a least-
        squares circle.  For RL/AP alignment only the left/right midpoint is
        required.  Pair the dominant opposing edges on many central rows and use
        their robust median midpoint.
        """
        a=cls._norm(image);h,w=a.shape
        gx=np.abs(a[:,2:]-a[:,:-2])
        mids=[]; widths=[]; strengths=[]
        for yy in range(int(.40*h),int(.55*h)):
            g=gx[yy]
            l0,l1=int(.34*w),int(.49*w); r0,r1=int(.51*w),int(.66*w)
            if l1<=l0 or r1<=r0: continue
            li=l0+int(np.nanargmax(g[l0:l1])); ri=r0+int(np.nanargmax(g[r0:r1]))
            ls=float(g[li]);rs=float(g[ri]); width=float(ri-li)
            if min(ls,rs)<.06 or not (.10*w<=width<=.28*w): continue
            # R0190k: retain sub-pixel edge position.  Integer argmax quantised the
            # opposing-edge midpoint by almost one physical millimetre on 4267.
            # A local parabolic peak interpolation is data-driven (gradient only)
            # and does not use an expected DQA displacement.
            def subpeak(idx):
                if idx <= 0 or idx >= g.size-1:
                    return float(idx)
                a0,a1,a2=float(g[idx-1]),float(g[idx]),float(g[idx+1])
                den=a0-2.0*a1+a2
                off=0.0 if abs(den)<1e-12 else 0.5*(a0-a2)/den
                return float(idx)+float(np.clip(off,-0.5,0.5))
            lp=subpeak(li); rp=subpeak(ri)
            # central-difference gx index is one pixel left of the physical
            # transition. The common +1 is restored after midpointing.
            mids.append(.5*(lp+rp)+1.0); widths.append(rp-lp); strengths.append(min(ls,rs))
        if len(mids)<8:return None
        m=np.asarray(mids); med=float(np.nanmedian(m)); mad=float(np.nanmedian(np.abs(m-med)))
        keep=np.abs(m-med)<=max(.8,3.0*mad)
        if keep.sum()<6:return None
        center=float(np.nanmedian(m[keep])); support=min(1.0,float(keep.sum())/20.0)
        # y is display-only; use robust vertical structural centre rather than
        # letting it affect the RL/AP coordinate.
        return center,float(h*.5),support

    @classmethod
    def _circle_center(cls, image: np.ndarray, baseline_y: float | None = None) -> tuple[float, float, float] | None:
        # DQA alignment needs the LR midpoint.  Keep the historical method name
        # for callers/overlays, but make the measured quantity explicit.
        return cls._geometric_lr_center(image)

    def _measure_one(self, son, row: dict[str, object]) -> dict[str, float | str | None]:
        """Deprecated phantom-relative helper; numeric output intentionally disabled.

        Old releases used hotspot-minus-phantom and baseline-line geometry here.
        Keeping a numeric implementation around made accidental regression too easy.
        """
        return {"orientation": self._orientation(row), "error": "legacy phantom-relative DQA measurement disabled"}

    @staticmethod
    def _frame_identity(path: Path) -> tuple[int, int, int, int] | None:
        m=re.match(r"^(\d+)-(\d+)-(\d+)-(\d+)\.raw$", Path(path).name, re.I)
        return tuple(int(v) for v in m.groups()) if m else None

    @classmethod
    def _row_for_raw_frame(cls, rows: list[dict[str, object]], path: Path) -> dict[str, object] | None:
        """Resolve the MriImageParams row that owns one exported RAW frame.

        A Sonication can contain several fields/slices.  Selecting one arbitrary
        row per Sonication made the thermal hotspot and phantom geometry live in
        different image frames and produced large but plausible DQA offsets.
        """
        ident=cls._frame_identity(path)
        if ident is None:
            return None
        field,son,zone,array_index=ident
        exact=[]
        for row in rows:
            try:
                rf=int(float(row.get("fieldindex")))
                rs=int(float(row.get("sonicationindex")))
                rz=int(float(row.get("zoneindex",0) or 0))
                # RAW final token is the exported zero-based array index.
                # MriImageParams commonly exposes both zero-based `arrayindex` and
                # one-based `imgnum`.  Treating both as interchangeable candidates
                # (and accepting +/-1) makes adjacent frames all look like matches
                # and causes exact Thermal->Magnitude pairing to fail closed.
                row_array=None
                try:
                    row_array=int(float(row.get("arrayindex")))
                except Exception:
                    try:
                        row_array=int(float(row.get("imgnum")))-1
                    except Exception:
                        row_array=None
                if rf==field and rs==son and rz==zone and row_array==array_index:
                    exact.append(row)
            except Exception:
                continue
        if not exact:
            return None
        # Prefer treatment thermometry/magnitude rows with complete physical geometry.
        def quality(row):
            series=str(row.get("seriesdiscription") or row.get("seriesdescription") or "").upper()
            treatment=int(any(t in series for t in ("MEMP","TMAP","THERM")))
            return treatment, int(cls._pixel_sizes(row) is not None)
        return max(exact,key=quality)

    @staticmethod
    def _row_acquisition_identity(row: dict[str, object]) -> tuple[int,int] | None:
        """Canonical acquisition identity excluding field number.

        The exported RAW suffix is zero-based.  `arrayindex` follows that convention
        while `imgnum` is normally one-based.  Canonicalising here is essential:
        accepting a +/-1 neighbourhood makes every interior acquisition ambiguous.
        """
        try:
            son=int(float(row.get("sonicationindex")))
        except Exception:
            return None
        try:
            array_index=int(float(row.get("arrayindex")))
        except Exception:
            try:
                array_index=int(float(row.get("imgnum")))-1
            except Exception:
                return None
        # Field-5 thermometry and Field-6 magnitude can intentionally use
        # different zone indices for the same MEMP acquisition (4267: 3 vs 0).
        # Zone is therefore field-local metadata, not a cross-field pairing key.
        return son,array_index

    @classmethod
    def _geometry_compatible(cls, a: dict[str,object], b: dict[str,object], *, tolerance_mm: float=.75) -> bool:
        if cls._orientation(a) != cls._orientation(b) or cls._pixel_sizes(a) is None or cls._pixel_sizes(b) is None:
            return False
        try:
            if max(abs(x-y) for x,y in zip(cls._pixel_sizes(a),cls._pixel_sizes(b))) > 1e-3:
                return False
            for prefix in ("rowdirectcosras","coldirectcosras"):
                va=np.asarray([float(a[prefix+k]) for k in "xyz"],float)
                vb=np.asarray([float(b[prefix+k]) for k in "xyz"],float)
                if float(np.linalg.norm(va-vb)) > 1e-3:
                    return False
            oa=np.asarray([float(a[k]) for k in ("topleftcoordr","topleftcoorda","topleftcoords")],float)
            ob=np.asarray([float(b[k]) for k in ("topleftcoordr","topleftcoorda","topleftcoords")],float)
            normal=np.cross(
                np.asarray([float(a["rowdirectcosras"+k]) for k in "xyz"]),
                np.asarray([float(a["coldirectcosras"+k]) for k in "xyz"]),
            )
            normal=normal/max(float(np.linalg.norm(normal)),1e-12)
            return abs(float(np.dot(ob-oa,normal))) <= tolerance_mm and float(np.linalg.norm((ob-oa)-normal*np.dot(ob-oa,normal))) <= tolerance_mm
        except Exception:
            return False

    @classmethod
    def _exact_magnitude_pair(cls, rows, thermal_path: Path, magnitude_frames) -> tuple[object,dict[str,object]] | None:
        """Bind thermal RAW to one exact acquisition/geometry magnitude frame.

        No list-index or ratio mapping is permitted. Ambiguity fails closed.
        """
        trow=cls._row_for_raw_frame(rows,thermal_path)
        tid=cls._row_acquisition_identity(trow or {})
        if trow is None or tid is None:
            return None
        matches=[]
        for mf in list(magnitude_frames or []):
            mrow=cls._row_for_raw_frame(rows,mf.path)
            mid=cls._row_acquisition_identity(mrow or {})
            if mrow is None or mid is None:
                continue
            # Identities are already canonicalised to zero-based acquisition index.
            # Require exact Sonication/acquisition equality.  Zone is deliberately
            # excluded because it is field-local (e.g. thermal zone 3 vs magnitude
            # zone 0 in the same physical MEMP acquisition).
            if tid != mid:
                continue
            if not cls._geometry_compatible(trow,mrow):
                continue
            matches.append((mf,mrow))
        if len(matches) != 1:
            return None
        return matches[0]

    @classmethod
    def _phantom_mask_from_magnitude(cls, orientation: str, mag: np.ndarray) -> tuple[np.ndarray,dict[str,object]] | None:
        """Return a phantom/body-derived search mask; never planned-focus centred."""
        a=np.asarray(mag,float)
        if a.ndim != 2 or min(a.shape) < 32:
            return None
        h,w=a.shape
        if orientation == "Axial":
            cc=cls._circle_center(a,None)
            if cc is None or cc[2] < .55:
                return None
            cx,cy,support=cc
            # Circle detector does not return radius. Derive a conservative body
            # radius from the structural extent around the detected centre.
            norm=cls._norm(a); yy,xx=np.indices(a.shape)
            dist=np.hypot(xx-cx,yy-cy)
            structural=(norm > float(np.nanpercentile(norm,55)))
            ds=dist[structural & (dist < .40*w)]
            if ds.size < 100:
                return None
            radius=float(np.nanpercentile(ds,82))
            radius=max(.12*w,min(.34*w,radius))
            mask=dist <= radius*.88
            return mask,{"kind":"axial-circle","circle_pixel":(float(cx),float(cy)),"radius_px":radius,"support":float(support)}
        if orientation == "Sagittal":
            ln=cls._baseline_line(a)
            if ln is None or ln[2] < .55:
                return None
            slope,intercept,support=ln; yy,xx=np.indices(a.shape)
            norm=cls._norm(a)
            body=norm > float(np.nanpercentile(norm,35))
            # Interior is above the detected lower baseline with a small inset,
            # excluding wrap/border regions and air below the phantom.
            mask=body & (yy < (slope*xx+intercept-3.0)) & (xx >= .08*w) & (xx <= .92*w) & (yy >= .08*h)
            if int(mask.sum()) < 200:
                return None
            return mask,{"kind":"sagittal-body-baseline","slope":float(slope),"intercept":float(intercept),"support":float(support)}
        return None


    @classmethod
    def _sagittal_ap_center_from_mask(cls, row: dict[str,object], mask: np.ndarray) -> tuple[float,tuple[float,float]] | None:
        """Physical A/P midpoint of the detected sagittal phantom portion."""
        yy,xx=np.nonzero(np.asarray(mask,bool))
        if xx.size < 200:
            return None
        step=max(1,int(xx.size//4000)); pts=[]
        for px,py in zip(xx[::step],yy[::step]):
            rr=cls._absolute_ras(row,float(px),float(py))
            if rr is not None and np.isfinite(rr).all():
                pts.append((float(rr[1]),float(px),float(py)))
        if not pts:
            return None
        ac=.5*(min(v[0] for v in pts)+max(v[0] for v in pts))
        q=min(pts,key=lambda v:abs(v[0]-ac))
        return float(ac),(float(q[1]),float(q[2]))

    @classmethod
    def _sagittal_ap_center_from_image(cls, row: dict[str,object], image: np.ndarray) -> tuple[float,tuple[float,float]] | None:
        """Sagittal DQA AP centre from the prescribed phantom-centred raster.

        The HASTE DQA sagittal acquisition is prescribed through the phantom AP
        axis. Internal bright bands are asymmetric and are not a valid AP edge.
        Use the physical centre between the two central raster columns; this is
        metadata geometry, not an expected-offset fit.
        """
        a=np.asarray(image)
        if a.ndim!=2:return None
        masked=cls._phantom_mask_from_magnitude("Sagittal",a)
        if masked is None:
            return None
        mask,_diag=masked
        # Authoritative AP reference is the midpoint of the *detected phantom*
        # physical AP extent.  The image/raster centre is deliberately forbidden:
        # a prescribed sagittal raster can be centred differently from the actual
        # phantom and silently biases the DQA AP displacement.
        return cls._sagittal_ap_center_from_mask(row,mask)

    def _native_measurement_for_sonication(self, son, rows: list[dict[str, object]]) -> dict[str, float | str | None]:
        """Legacy API retained only as a fail-closed compatibility shim.

        Historical releases measured hotspot-to-phantom-centre here. That
        quantity is not DQA focus displacement and must never re-enter the
        production path. Callers receive an explicit non-numeric result.
        """
        return {"orientation": None, "error": "legacy phantom-relative DQA measurement disabled"}

    def _thermal_focus_ras_alignment(self, package, reference: dict[str, object], focal_by_number: dict[int, tuple[float,float,float]], current_number: int | None = None) -> DqaFocusAlignment | None:
        """Deprecated phantom-relative 3-D alignment path; permanently disabled.

        Kept only so old plugins/tests fail safely instead of silently restoring
        the pre-R0154aa hotspot-minus-phantom algorithm.
        """
        return None

    @staticmethod
    def _thermometry_evidence(row: dict[str, object] | None, image: np.ndarray) -> dict[str, object]:
        """Classify whether one Field-5-like raster is valid temperature evidence.

        Field number and payload width are not sufficient.  Brain220 exports can
        store `T2_Star_ME_1SL` float32 rasters under field 5; their values are MR
        signal/T2* quantities in the thousands, not degrees C.  DQA must bind the
        RAW to MriImageParams and validate both protocol semantics and value range.
        """
        row = dict(row or {})
        series = str(row.get("seriesdiscription") or row.get("seriesdescription") or "").strip()
        upper = series.upper().replace("*", "_STAR_")
        arr = np.asarray(image, float)
        finite = arr[np.isfinite(arr)]
        evidence = []
        if series:
            evidence.append(f"MriImageParams series={series}")
        else:
            evidence.append("MriImageParams series unavailable")
        known_nonthermal = any(token in upper for token in (
            "T2_STAR", "T2STAR", "NFUSCAL", "DQA-AXIAL", "DQA-SAGITTAL", "DQA-CORONAL"
        ))
        protocol_thermal = any(token in upper for token in ("TMAP", "MEMP", "THERM", "TEMPERATURE"))
        if known_nonthermal:
            return {"valid": False, "mode": None, "reason": f"non-thermometry MR protocol {series or 'unknown'}", "evidence": evidence}
        if not finite.size:
            return {"valid": False, "mode": None, "reason": "temperature raster has no finite samples", "evidence": evidence}
        median = float(np.nanmedian(finite))
        p01, p99 = (float(v) for v in np.nanpercentile(finite, [1, 99]))
        evidence.append(f"value distribution median={median:.3f}, p01={p01:.3f}, p99={p99:.3f}")
        absolute = bool(15.0 <= median <= 80.0 and -10.0 <= p01 and p99 <= 120.0)
        delta_like = bool(-20.0 <= median <= 20.0 and -60.0 <= p01 and p99 <= 100.0)
        if not (absolute or delta_like):
            return {"valid": False, "mode": None, "reason": "temperature values outside validated absolute/delta range", "evidence": evidence}
        # A named MR series must positively identify thermometry.  Value range alone
        # is not sufficient because processed magnitude/phase products can overlap
        # temperature-like ranges.  Only truly blank legacy descriptions retain the
        # value-distribution fallback.
        if series and not protocol_thermal:
            return {"valid": False, "mode": None, "reason": f"named MR series is not a validated thermometry protocol: {series}", "evidence": evidence}
        mode = "absolute" if absolute else "delta"
        evidence.append(("thermal protocol marker present; " if protocol_thermal else "legacy blank protocol; ") + f"validated {mode} temperature distribution")
        return {"valid": True, "mode": mode, "reason": "validated thermometry", "evidence": evidence}

    def _planned_focus_native_measurement(self, son, rows: list[dict[str, object]], planned_ras: tuple[float,float,float]) -> dict[str, object]:
        """Measure observed thermal focus minus the planned focus in one MR raster.

        This is the only production numeric DQA displacement contract.  The planned
        Sonication focus is projected into the exact thermometry frame that owns the
        observed hotspot.  The displacement is then calculated in that frame's
        in-plane physical basis.  The through-plane component is left unavailable;
        it is never manufactured from phantom centre, image centre, another
        Sonication, steering amount or target-voxel coordinates.
        """
        temps=list(getattr(son,"temperature_frames",[]) or [])
        if not temps:
            return {"error":"thermometry unavailable"}
        # A float32-sized raster is not automatically thermometry. Brain220 DQA
        # exports contain T2*/phase-like field-5 RAW whose values are in the
        # thousands. Treating those as temperature produced false focus locations.
        try:
            baseline=np.asarray(self.raw.read_temperature(temps[0].path),float)
        except Exception:
            return {"error":"temperature baseline unavailable"}
        baseline_row=self._row_for_raw_frame(rows,temps[0].path)
        if baseline_row is None:
            return {"error":"temperature baseline has no exact MriImageParams binding"}
        thermo=self._thermometry_evidence(baseline_row,baseline)
        if not bool(thermo.get("valid")):
            return {"error":f"temperature RAW is not validated thermometry: {thermo.get('reason')}", "thermometry_evidence":list(thermo.get("evidence",[]) or [])}
        absolute=(thermo.get("mode") == "absolute")
        best=None
        for ti,tf in enumerate(temps):
            row=self._row_for_raw_frame(rows,tf.path)
            if row is None:
                continue
            ok,diag=self._point_in_exported_image_frame(
                row, planned_ras, in_plane_margin_fraction=.08, normal_tolerance_mm=10.0
            )
            if not ok or not diag:
                continue
            try:
                arr=np.asarray(self.raw.read_temperature(tf.path),float)
            except Exception:
                continue
            if arr.shape != baseline.shape:
                continue
            delta=arr-baseline if absolute else arr
            h,w=delta.shape
            px=float(diag["x_px"]); py=float(diag["y_px"])
            # A DQA focus cannot be accepted from an unrelated hot structure.  Use
            # a local physical search around the planned focus only.
            radius=14
            xa=max(1,int(round(px))-radius); xb=min(w-1,int(round(px))+radius+1)
            ya=max(1,int(round(py))-radius); yb=min(h-1,int(round(py))+radius+1)
            roi=np.asarray(delta[ya:yb,xa:xb],float)
            if roi.shape[0] < 3 or roi.shape[1] < 3 or not np.isfinite(roi).any():
                continue
            filled=np.nan_to_num(roi,nan=0.0)
            pad=np.pad(filled,1,mode="edge")
            sm=sum(pad[dy:dy+roi.shape[0],dx:dx+roi.shape[1]] for dy in range(3) for dx in range(3))/9.0
            flat=int(np.nanargmax(sm)); yy,xx=np.unravel_index(flat,sm.shape)
            score=float(sm[yy,xx]); peak_hx=float(xx+xa); peak_hy=float(yy+ya)
            # R0190v: the smoothed argmax identifies the coherent blob, but is not
            # its centre.  Centre the observed-focus marker/numerics on the local
            # thermal-rise centroid.  This is image-derived only (no target pull).
            hx,hy=self._coherent_hotspot_centroid(delta,peak_hx,peak_hy,radius=5)
            pixel_distance=float(np.hypot(hx-px,hy-py))
            if pixel_distance > 10.0:
                continue
            ras_delta=self._ras_delta(row,hx-px,hy-py)
            if ras_delta is None or not np.isfinite(ras_delta).all():
                continue
            if best is None or score > best[0]:
                best=(score,ras_delta,row,hx,hy,px,py,Path(tf.path).name,ti)
        if best is None:
            return {"error":"observed focus vs planned focus not measurable in one MR raster"}
        _score,drow,row,hx,hy,px,py,name,ti=best
        orientation=self._orientation(row)
        values=[float(v) for v in drow]
        # Never report a through-plane zero from an in-plane measurement.
        if orientation == "Axial":
            values[2]=None
        elif orientation == "Sagittal":
            values[0]=None
        elif orientation == "Coronal":
            values[1]=None
        return {
            "x_mm":values[0], "y_mm":values[1], "z_mm":values[2],
            "orientation":orientation, "frame":name,
            "hotspot_x":hx, "hotspot_y":hy, "planned_x":px, "planned_y":py,
            "hotspot_score_c":float(_score), "phase_axis":self._phase_axis(row),
            "evidence":f"{name}: observed thermal hotspot centroid ({hx:.2f},{hy:.2f}) px - planned focus ({px:.2f},{py:.2f}) px in same {orientation or 'MR'} raster; phase={self._phase_axis(row) or 'Unavailable'}; " + "; ".join(str(v) for v in list(thermo.get("evidence",[]) or [])),
        }

    def _image_native_alignment(self, package, focal_by_number: dict[int, tuple[float,float,float]], current_number: int | None = None) -> DqaFocusAlignment | None:
        """Return Sonication-local observed-minus-planned DQA displacement only."""
        if current_number is None or int(current_number) not in focal_by_number:
            return None
        params=self._find_mri_params(Path(getattr(package,"workspace",".")))
        try:
            rows=parse_ado_rowset(params) if params is not None and Path(params).exists() else []
        except Exception:
            rows=[]
        if not rows:
            return None
        son=None
        for pos,item in enumerate(list(getattr(package,"sonications",[]) or []),start=1):
            n=int(getattr(item,"sonication_number",0) or pos)
            if n == int(current_number):
                son=item; break
        if son is None:
            return None
        planned=focal_by_number[int(current_number)]
        m=self._planned_focus_native_measurement(son,rows,planned)
        if m.get("error"):
            return None
        x=m.get("x_mm"); y=m.get("y_mm"); z=m.get("z_mm")
        vals=[v for v in (x,y,z) if v is not None and np.isfinite(float(v))]
        if not vals:
            return None
        exclusion=self._dqa_exclusion_reason(package,int(current_number),focal_by_number)
        evidence=[
            f"S{int(current_number)} planned focus RAS=({planned[0]:.3f},{planned[1]:.3f},{planned[2]:.3f}) mm",
            str(m.get("evidence") or ""),
            "DQA numeric contract: observed heated focus minus planned focus of the same Sonication; phantom/image centre and steering coordinates are forbidden as displacement zero-points",
        ]
        if exclusion:
            evidence.append(f"Centre-alignment judgement excluded: {exclusion}; measurement retained")
        return DqaFocusAlignment(
            x_mm=None if x is None else float(x), y_mm=None if y is None else float(y), z_mm=None if z is None else float(z),
            tilt_deg=None, confidence="High" if len(vals)>=2 else "Partial", evidence=evidence,
            judgement_excluded_reason=exclusion, observed_target_phase_axis=m.get("phase_axis"),
        )

    @staticmethod
    def _absolute_ras(row: dict[str, object], x: float, y: float) -> np.ndarray | None:
        """Convert an exported image pixel coordinate to absolute RAS millimetres."""
        sizes = DqaFocusAlignmentService._pixel_sizes(row)
        if sizes is None:
            return None
        try:
            origin = np.asarray([float(row[k]) for k in ("topleftcoordr","topleftcoorda","topleftcoords")], float)
            rv = np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")], float)
            cv = np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")], float)
        except Exception:
            return None
        if not np.isfinite(origin).all() or np.linalg.norm(rv) < .5 or np.linalg.norm(cv) < .5:
            return None
        sx, sy = sizes
        return origin + cv * (float(x) * sx) + rv * (float(y) * sy)

    @staticmethod
    def _point_in_exported_image_frame(
        row: dict[str, object],
        point_ras: tuple[float, float, float] | np.ndarray,
        *,
        width: int = 256,
        height: int = 256,
        in_plane_margin_fraction: float = 0.20,
        normal_tolerance_mm: float = 18.0,
    ) -> tuple[bool, dict[str, float]]:
        """Validate that a RAS point belongs to the same exported MR frame.

        ``SonicationSummary.focalRAS`` and ``MriImageParams.TopLeftCoordRAS`` are
        not guaranteed to use the same coordinate frame in every workstation
        generation.  R0154g incorrectly assumed that they always did and directly
        subtracted the two.  The result can look like a 100+ mm phantom/focus
        displacement even while the displayed DQA anatomy is visually centered.

        A legitimate point in the same frame must project near the image field of
        view *and* near the image plane.  This is a coordinate-frame sanity gate,
        not a clinical alignment threshold.
        """
        sizes = DqaFocusAlignmentService._pixel_sizes(row)
        if sizes is None:
            return False, {}
        try:
            origin = np.asarray([float(row[k]) for k in ("topleftcoordr","topleftcoorda","topleftcoords")], float)
            rv = np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")], float)
            cv = np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")], float)
            point = np.asarray(point_ras, float)
        except Exception:
            return False, {}
        if point.size != 3 or not np.isfinite(point).all() or not np.isfinite(origin).all():
            return False, {}
        rn=float(np.linalg.norm(rv)); cn=float(np.linalg.norm(cv))
        if rn < .5 or cn < .5:
            return False, {}
        rv=rv/rn; cv=cv/cn
        normal=np.cross(cv,rv)
        nn=float(np.linalg.norm(normal))
        if nn < .5:
            return False, {}
        normal=normal/nn
        sx,sy=sizes
        delta=point-origin
        x_px=float(np.dot(delta,cv)/sx)
        y_px=float(np.dot(delta,rv)/sy)
        normal_mm=float(np.dot(delta,normal))
        mx=float(width)*float(in_plane_margin_fraction)
        my=float(height)*float(in_plane_margin_fraction)
        inside=(-mx <= x_px <= (width-1)+mx and -my <= y_px <= (height-1)+my)
        coplanar=abs(normal_mm) <= float(normal_tolerance_mm)
        return bool(inside and coplanar), {
            "x_px": x_px, "y_px": y_px, "normal_mm": normal_mm,
            "width": float(width), "height": float(height),
        }

    @classmethod
    def _project_ras_to_exact_row_pixel(cls, row: dict[str, object], point_ras) -> tuple[float, float] | None:
        """Project a physical RAS point into *this exact displayed raster*.

        Unlike ``_point_in_exported_image_frame`` this helper does not select or
        substitute a nearby reference slice.  It is display geometry only.  The
        caller already owns the exact thermal row, so returning coordinates from
        any other row would be a coordinate-space bug.
        """
        sizes=cls._pixel_sizes(row)
        if sizes is None:
            return None
        try:
            origin=np.asarray([float(row[k]) for k in ("topleftcoordr","topleftcoorda","topleftcoords")],float)
            rv=np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")],float)
            cv=np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")],float)
            point=np.asarray(point_ras,float)
        except Exception:
            return None
        rn=float(np.linalg.norm(rv)); cn=float(np.linalg.norm(cv))
        if point.size != 3 or not np.isfinite(point).all() or not np.isfinite(origin).all() or rn < .5 or cn < .5:
            return None
        rv=rv/rn; cv=cv/cn; sx,sy=sizes; delta=point-origin
        x=float(np.dot(delta,cv)/sx); y=float(np.dot(delta,rv)/sy)
        return (x,y) if np.isfinite(x) and np.isfinite(y) else None

    @classmethod
    def _focal_reference_frame_compatibility(cls, reference: dict[str, object], focal_ras) -> tuple[bool, list[str]]:
        """Validate focalRAS against the *DQA image stacks*, not one arbitrary slice.

        Brain220 DQA exports store one MriImageParams row per slice.  Earlier code
        kept only the first row of each field and then required the focus to be
        coplanar with that single slice.  A perfectly valid focus near another
        slice therefore looked like a coordinate-frame mismatch.  The correct
        test is volume-like: the focus must project inside the FOV of at least one
        axial slice and at least one sagittal slice, with a small plane-distance
        tolerance.  This proves common RAS geometry without assuming one fixed
        slice owns the whole series.
        """
        rows=list(reference.get("validation_rows",[]) or [])
        if not rows:
            return False, ["DQA coordinate-frame validation unavailable: no reference image geometry"]
        groups={"Axial":[],"Sagittal":[]}; evidence=[]
        for label,row in rows:
            orientation=cls._orientation(row)
            ok,diag=cls._point_in_exported_image_frame(
                row,focal_ras,in_plane_margin_fraction=0.08,normal_tolerance_mm=6.0
            )
            if orientation in groups:
                groups[orientation].append(bool(ok))
            if diag:
                evidence.append(
                    f"{label} focal projection: x={diag['x_px']:.1f}px, y={diag['y_px']:.1f}px, plane={diag['normal_mm']:+.1f}mm -> {'compatible' if ok else 'mismatch'}"
                )
        required=[name for name in ("Axial","Sagittal") if groups[name]]
        compatible=bool(len(required)>=2 and all(any(groups[name]) for name in required))
        return compatible,evidence

    @staticmethod
    def _read_u16_image(path: Path) -> np.ndarray | None:
        try:
            data = np.fromfile(path, dtype="<u2")
        except Exception:
            return None
        if data.size != 256 * 256:
            return None
        return data.reshape((256, 256))

    def _dqa_reference_geometry(self, package) -> dict[str, object]:
        """Recover DQA phantom geometry with one metadata row per RAW slice.

        A DQA field is a stack, not one image.  Each MriImageParams row carries a
        different slice RAS origin.  Reusing the first row for every RAW frame was
        the root cause of the large false X/Y/Z offsets seen in R0154m.
        """
        token = str(Path(getattr(package, "workspace", ".")).resolve())
        if token in self._reference_cache:
            return dict(self._reference_cache[token])
        workspace = Path(getattr(package, "workspace", "."))
        params = self._find_mri_params(workspace)
        try:
            rows = parse_ado_rowset(params) if params is not None else []
        except Exception:
            rows = []
        axial_rows=[]; sagittal_rows=[]
        for row in rows:
            series = str(row.get("seriesdiscription") or row.get("seriesdescription") or "").strip().lower()
            try:
                field = int(float(row.get("fieldindex", -1)))
                son = int(float(row.get("sonicationindex", -1)))
                imgnum = int(float(row.get("imgnum", 1) or 1))
                zone = int(float(row.get("zoneindex", 0) or 0))
            except Exception:
                continue
            if field < 0 or son < 1 or imgnum < 1 or self._pixel_sizes(row) is None:
                continue
            entry=(son,field,zone,imgnum,row)
            is_axial=("dqa-axial" in series or ("dqa" in series and "axial" in series)
                      or ("dqa" in series and ("_tra" in series or "trans" in series)))
            is_sagittal=("dqa-sagittal" in series or ("dqa" in series and "sagittal" in series)
                         or ("dqa" in series and "_sag" in series))
            if is_axial:
                axial_rows.append(entry)
            if is_sagittal:
                sagittal_rows.append(entry)

        folder_cache={}
        def raw_for(entry):
            son,field,zone,imgnum,_row=entry
            folder=folder_cache.get(son)
            if folder is None:
                folder=workspace / f"Sonication{son}"
                if not folder.exists():
                    matches=[p for p in workspace.rglob(f"Sonication{son}") if p.is_dir()]
                    folder=matches[0] if matches else folder
                folder_cache[son]=folder
            expected=folder / f"{field}-{son}-{zone}-{imgnum-1}.raw"
            if expected.exists():
                return expected
            # Some generations do not preserve zone/index naming exactly.  The
            # metadata row still owns the frame; use imgnum-1 as the final token.
            matches=sorted(folder.glob(f"{field}-{son}-*-{imgnum-1}.raw"))
            return matches[0] if matches else None

        evidence=[]; axial_centres=[]; baseline_s=[]; tilts=[]; validation_rows=[]
        axial_candidates=[]; sagittal_candidates=[]
        for entry in axial_rows:
            son,field,_zone,imgnum,row=entry
            raw=raw_for(entry)
            if raw is None: continue
            img=self._read_u16_image(raw)
            if img is None: continue
            circle=self._circle_center(img,None)
            if circle is None: continue
            cx,cy,support=circle
            if support < .55: continue
            ras=self._absolute_ras(row,cx,cy)
            if ras is None: continue
            ras_arr=np.asarray(ras,float)
            axial_centres.append(ras_arr)
            axial_candidates.append({
                "row": row, "raw": str(raw), "label": f"DQA-Axial S{son} field {field} image {imgnum}",
                "circle_pixel": (float(cx),float(cy)), "circle_ras": tuple(float(v) for v in ras_arr),
                "support": float(support),
            })
            validation_rows.append((f"DQA-Axial S{son} field {field} image {imgnum}",row))

        for entry in sagittal_rows:
            son,field,_zone,imgnum,row=entry
            raw=raw_for(entry)
            if raw is None: continue
            img=self._read_u16_image(raw)
            if img is None: continue
            # R0190r: detect both finite-bar edges, transform both to MR-RAS,
            # then select the physically SUPERIOR edge. Pixel-up is not reliably
            # superior across exports because sagittal column direction can flip.
            edges=self._baseline_edge_pair(img)
            sizes=self._pixel_sizes(row)
            if not edges or sizes is None: continue
            sx,sy=sizes; x=img.shape[1]/2.0
            edge_phys=[]
            for eslope,eintercept,esupport in edges:
                ey=eslope*x+eintercept
                eras=self._absolute_ras(row,x,ey)
                if eras is not None and esupport>=.55:
                    edge_phys.append((float(np.asarray(eras,float)[2]),eslope,eintercept,esupport,ey,eras))
            if not edge_phys: continue
            # Anatomical superior is +S in RAS, independent of raster orientation.
            _sphys,slope,intercept,support,y,ras=max(edge_phys,key=lambda q:q[0])
            tilt_deg=float(math.degrees(math.atan2(slope*sy,sx)))
            baseline_s.append(float(ras[2]))
            tilts.append(tilt_deg)
            # Simple sagittal AP centre: use the centre of the phantom/body AP
            # extent above the validated lower baseline.  Convert mask pixels to
            # MR-RAS and take the midpoint of the physical A extent; this avoids
            # coupling Y to the axial image or to the lower-line Z reference.
            sag_mask_info=self._phantom_mask_from_magnitude("Sagittal",img)
            ap_center_ras=None; ap_center_pixel=None
            if sag_mask_info is not None:
                ap=self._sagittal_ap_center_from_image(row,img)
                if ap is not None:
                    ap_center_ras,ap_center_pixel=ap
            sagittal_candidates.append({
                "row": row, "raw": str(raw), "label": f"DQA-Sagittal S{son} field {field} image {imgnum}",
                "baseline_pixel": (float(x),float(y)), "baseline_ras": tuple(float(v) for v in np.asarray(ras,float)),
                "phantom_ap_center_ras": ap_center_ras, "phantom_ap_center_pixel": ap_center_pixel,
                "slope": float(slope), "intercept": float(intercept), "support": float(support), "tilt_deg": tilt_deg,
                "baseline_edge_contract": "physically superior (+S RAS) edge of finite-thickness sagittal lower reference bar",
                "baseline_edge_candidates_s_mm": [float(q[0]) for q in edge_phys],
            })
            validation_rows.append((f"DQA-Sagittal S{son} field {field} image {imgnum}",row))

        # R0190l: cross-slice LR consensus prevents an internal concentric edge
        # on one slice from becoming the phantom reference solely because its
        # slice plane is nearest to the observed focus.
        if axial_candidates:
            rr=np.asarray([float(c["circle_ras"][0]) for c in axial_candidates],float)
            rmed=float(np.nanmedian(rr)); rmad=float(np.nanmedian(np.abs(rr-rmed))); rtol=max(1.25,3.5*rmad)
            for c in axial_candidates:
                resid=abs(float(c["circle_ras"][0])-rmed)
                c["stack_consensus_r_mm"]=rmed; c["stack_residual_mm"]=resid; c["stack_consistent"]=bool(resid<=rtol)
            rejected=[c for c in axial_candidates if not c["stack_consistent"]]
            if rejected: evidence.append(f"Axial phantom consensus rejected {len(rejected)}/{len(axial_candidates)} slice(s) with LR residual > {rtol:.2f} mm")

        # R0190n: the SI/AP reference is also a stack measurement.  A single
        # sagittal slice must not win merely because it is nearest to the thermal
        # focus when its lower-bar edge is an outlier.  Consensus is computed in
        # physical S (not pixels), so slice origin/spacing are respected.
        if sagittal_candidates:
            ss=np.asarray([float(c["baseline_ras"][2]) for c in sagittal_candidates],float)
            smed=float(np.nanmedian(ss)); smad=float(np.nanmedian(np.abs(ss-smed)))
            # 1.0 mm is only a detector-stability floor, not a DQA expected shift.
            stol=max(1.0,3.5*smad)
            for c in sagittal_candidates:
                resid=abs(float(c["baseline_ras"][2])-smed)
                c["stack_consensus_s_mm"]=smed; c["stack_residual_mm"]=resid
                c["stack_consistent"]=bool(resid<=stol)
            rejected=[c for c in sagittal_candidates if not c["stack_consistent"]]
            if rejected:
                evidence.append(f"Sagittal lower-reference consensus rejected {len(rejected)}/{len(sagittal_candidates)} slice(s) with S residual > {stol:.2f} mm")

        center=None
        if axial_centres:
            good=[np.asarray(c["circle_ras"],float) for c in axial_candidates if c.get("stack_consistent",True)]
            arr=np.vstack(good if good else axial_centres)
            # The axial stack changes S by design.  Only R/A describe the phantom
            # cylinder centre.  Keep S as the stack median solely for diagnostics.
            center=np.asarray([
                float(np.nanmedian(arr[:,0])),
                float(np.nanmedian(arr[:,1])),
                float(np.nanmedian(arr[:,2])),
            ])
            evidence.append(
                f"Phantom axial centre from {len(arr)} slice-owned frame(s): R={center[0]:.2f} mm, A={center[1]:.2f} mm; slice S range {float(np.nanmin(arr[:,2])):.2f}..{float(np.nanmax(arr[:,2])):.2f} mm"
            )
        good_sag=[c for c in sagittal_candidates if c.get("stack_consistent",True)]
        good_baseline_s=[float(c["baseline_ras"][2]) for c in good_sag]
        good_tilts=[float(c["tilt_deg"]) for c in good_sag if c.get("tilt_deg") is not None]
        if good_baseline_s:
            evidence.append(
                f"Phantom sagittal lower reference (physical upper bar edge) from {len(good_baseline_s)} consensus frame(s): S={float(np.nanmedian(good_baseline_s)):.2f} mm, tilt={float(np.nanmedian(good_tilts)):+.2f}°"
            )
        result={
            "center_ras": tuple(float(v) for v in center) if center is not None else None,
            "baseline_s_mm": float(np.nanmedian(good_baseline_s)) if good_baseline_s else None,
            "sagittal_ap_center_mm": float(np.nanmedian([float(c["phantom_ap_center_ras"]) for c in good_sag if c.get("phantom_ap_center_ras") is not None and np.isfinite(float(c["phantom_ap_center_ras"]))])) if any(c.get("phantom_ap_center_ras") is not None and np.isfinite(float(c["phantom_ap_center_ras"])) for c in good_sag) else None,
            "tilt_deg": float(np.nanmedian(good_tilts)) if good_tilts else None,
            "evidence": evidence,
            "validation_rows": validation_rows,
            "axial_candidates": axial_candidates,
            "sagittal_candidates": sagittal_candidates,
        }
        self._reference_cache[token]=dict(result)
        return result

    @staticmethod
    def _treatment_spot_count(package, number: int) -> tuple[int | None, str]:
        """Return the number of *executed treatment spots* for one Sonication.

        Brain220 ``bbbnumsubsonicuvw`` / workstation ``BBB spot subsonications``
        describe the internal 3x3 BBB firing pattern inside one treatment spot.
        They are deliberately NOT target-voxel counts.  A treatment target is
        counted only from explicit Sonication->SpotCue ownership rows.
        """
        workspace = Path(getattr(package, "workspace", "") or ".")
        path = next((q for q in workspace.rglob("*") if q.is_file() and q.name.lower()=="spotsonicationdata.xml"), None)
        if path is None:
            return None, "SpotSonicationData unavailable"
        try:
            rows = parse_ado_rowset(path)
        except Exception:
            return None, "SpotSonicationData unreadable"
        cues=[]
        for row in rows:
            try:
                if int(float(row.get("sonicationindex"))) != int(number):
                    continue
            except Exception:
                continue
            cue=str(row.get("spotcue") or "").strip()
            if cue and cue not in cues:
                cues.append(cue)
        if not cues:
            return None, "No explicit Sonication/SpotCue ownership"
        return len(cues), f"SpotSonicationData: {len(cues)} executed SpotCue(s)"

    @staticmethod
    def _dqa_exclusion_reason(package, number: int, focal_by_number: dict[int, tuple[float,float,float]]) -> str | None:
        """Exclude any DQA shot that is not a default-centre, single-target shot.

        This is intentionally strict.  BBB internal sub-sonications are never
        interpreted as target voxels.  Numeric focus/phantom alignment is valid
        only when the export proves one executed treatment spot and workstation
        steering is the default centre for the study.
        """
        # Single-target gate from explicit treatment ownership, never BBB count.
        spot_count, _spot_evidence = DqaFocusAlignmentService._treatment_spot_count(package, int(number))
        if spot_count is not None and int(spot_count) != 1:
            return f"multi-target / {int(spot_count)} treatment spots"

        sons=list(getattr(package,"sonications",[]) or [])
        target=next((s for s in sons if int(getattr(s,"sonication_number",0) or 0)==int(number)),None)
        setup_steering_resolved=False
        try:
            from src.services.sonication_evidence_service import SonicationEvidenceService
            workspace = Path(getattr(package, "workspace", "") or ".")
            setups = SonicationEvidenceService().parse_setup_records(workspace)
            setup = next((r for r in setups if r.sonication_counter is not None and int(r.sonication_counter)+1==int(number)), None)
            usable=[r for r in setups if all(v is not None for v in r.steering_xyz)]
            if setup is not None and all(v is not None for v in setup.steering_xyz) and usable:
                # Default centre is the most axis-centred workstation setup in the
                # same study.  Require that reference itself to be close to the
                # acoustic axis; otherwise fail closed rather than choosing an
                # arbitrary peer median as "centre".
                nominal_rec=min(usable,key=lambda r: float(r.steering_xyz[0])**2+float(r.steering_xyz[1])**2)
                arr=np.asarray(setup.steering_xyz,float)
                nominal=np.asarray(nominal_rec.steering_xyz,float)
                if np.isfinite(arr).all() and np.isfinite(nominal).all():
                    nominal_lateral=float(np.hypot(nominal[0],nominal[1]))
                    if nominal_lateral > 0.5:
                        return "default centre steering not proven"
                    if float(np.linalg.norm(arr-nominal)) > 0.5:
                        return "electronic steering"
                    setup_steering_resolved=True
        except Exception:
            setup_steering_resolved=False

        # Fallback only when workstation setup evidence is unavailable.  Do not
        # use BBB sub-sonication count, repeated focalRAS, or Sonication order as
        # target-voxel proxies.
        if target is not None and not setup_steering_resolved:
            steering=getattr(target,"canonical_steering_xyz",None)
            if steering is not None:
                try:
                    arr=np.asarray([float(v) for v in steering],float)
                    if np.isfinite(arr).all():
                        # If canonical steering is already expressed as offset,
                        # non-zero lateral steering proves non-centre.  For absolute
                        # XYZ forms, defer rather than manufacturing a reference.
                        if abs(float(arr[0])) <= 20.0 and abs(float(arr[1])) <= 20.0 and float(np.hypot(arr[0],arr[1])) > 0.5:
                            return "electronic steering"
                except Exception:
                    pass

        # If explicit ownership exists and is single, the target gate is proved.
        # If it is unavailable, retain historical compatibility for 650 exports;
        # the centre-steering gate above still prevents false DQA numerics.
        return None

    @staticmethod
    def _summary_focal_ras(package) -> dict[int, tuple[float,float,float]]:
        workspace=Path(getattr(package,"workspace","."))
        paths=sorted(workspace.rglob("SonicationSummary.xml"),key=lambda p:(len(p.parts),str(p).lower()))
        if not paths: return {}
        try: rows=parse_ado_rowset(paths[0])
        except Exception: return {}
        out={}
        for row in rows:
            try:
                n=int(float(row.get("sonicationindex")))
                xyz=tuple(float(row.get(k)) for k in ("focalrasx","focalrasy","focalrasz"))
            except Exception: continue
            if all(np.isfinite(v) for v in xyz): out[n]=xyz
        return out

    def analyze(self, package, sonication_index: int | None = None) -> DqaFocusAlignment:
        base_key=str(Path(getattr(package,"workspace",".")).resolve())
        key=f"{base_key}::S{sonication_index if sonication_index is not None else 'package'}"
        if key in self._cache:
            return self._cache[key]
        if not self.is_dqa(package):
            result=DqaFocusAlignment(confidence="Not DQA",evidence=["DQA-only analysis not applicable"])
            self._cache[key]=result; return result

        # Production DQA does not build or consult a phantom-centre reference.
        # SonicationSummary focalRAS is PLANNED focus evidence only; an observed
        # thermometry focus from the same Sonication is required for numerics.
        focal_by_number=self._summary_focal_ras(package)
        number=None
        if sonication_index is not None:
            sons=list(getattr(package,"sonications",[]) or [])
            if 0 <= int(sonication_index) < len(sons):
                number=int(getattr(sons[int(sonication_index)],"sonication_number",int(sonication_index)+1) or int(sonication_index)+1)
            else:
                number=int(sonication_index)+1
        elif focal_by_number:
            number=sorted(focal_by_number)[0]

        # R0154aa production contract: measurement and judgement are separate.
        # Numeric DQA displacement has exactly one zero-point:
        # observed heated focus minus planned focus of the SAME Sonication.
        # Phantom centre, image centre, steering amount, target voxel coordinates
        # and peer Sonications are prohibited as displacement references.
        judgement_exclusion=(self._dqa_exclusion_reason(package,int(number),focal_by_number)
                             if number is not None else None)
        native=self._image_native_alignment(package,focal_by_number,number)
        if native is not None and native.excluded_reason is None:
            if not any("same-raster authority" in str(v) for v in native.evidence):
                native.evidence.append("DQA same-raster authority: observed focus minus planned focus of the same Sonication")
            components=[native.x_mm,native.y_mm,native.z_mm]
            finite=[abs(float(v)) for v in components if v is not None and np.isfinite(float(v))]
            if finite and max(finite) <= 25.0:
                if judgement_exclusion and not native.judgement_excluded_reason:
                    native.judgement_excluded_reason=judgement_exclusion
                    native.evidence.append(f"Centre-alignment judgement excluded: {judgement_exclusion}; measurement retained")
                self._cache[key]=native; return native

        reason="observed focus vs planned focus unavailable"
        evidence=[
            "DQA numeric displacement was not emitted because a same-Sonication observed thermal focus could not be measured against its planned focus in one registered MR raster.",
            "Fail-closed contract: planned focalRAS, phantom centre, image centre, steering coordinates and target voxel coordinates are never subtracted from one another to manufacture DQA displacement.",
        ]
        if number is not None and number in focal_by_number:
            fx,fy,fz=focal_by_number[number]
            evidence.append(f"S{number} planned focalRAS=({fx:.3f},{fy:.3f},{fz:.3f}) mm is retained as planned-target evidence only")
        if judgement_exclusion:
            evidence.append(f"Judgement eligibility: {judgement_exclusion}")
        result=DqaFocusAlignment(confidence="Unavailable",evidence=evidence,excluded_reason=reason)
        self._cache[key]=result; return result


    def _series_fixed_focus_ras(self, package, focal_by_number: dict[int, tuple[float,float,float]]) -> tuple[tuple[float,float,float] | None, list[str]]:
        """Return the mechanically fixed DQA natural-focus RAS.

        Brain220 DQA may electronically steer individual shots while the XD itself
        stays fixed.  ``SonicationSummary.focalRAS`` therefore varies across the
        series and must not be averaged directly.  The default-centre workstation
        setup (smallest lateral steering magnitude) identifies the natural-focus
        shot.  If no unequivocal centre setup exists we fail closed.
        """
        evidence=[]
        try:
            from src.services.sonication_evidence_service import SonicationEvidenceService
            setups=SonicationEvidenceService().parse_setup_records(Path(getattr(package,'workspace','.') or '.'))
        except Exception as exc:
            return None,[f'Workstation steering setup unavailable: {exc}']
        numbered=[]
        for rec in setups:
            try:
                if rec.sonication_counter is None:
                    continue
                n=int(rec.sonication_counter)+1
                numbered.append((n,rec))
            except Exception:
                continue
        # Brain 220 logs often omit the Sonication counter in every setup row.
        # The final N setup sessions are nevertheless the exact treatment block,
        # already proven by SpectrumMsg/PowerGraph/CPC ordering. Bind that tail
        # one-to-one to the exported Sonication folders instead of declaring the
        # fixed DQA focus unavailable.
        if not numbered:
            sons=list(getattr(package,'sonications',[]) or [])
            if sons and len(setups) >= len(sons):
                tail=list(setups)[-len(sons):]
                numbered=[(int(getattr(son,'sonication_number',i+1) or i+1),rec)
                          for i,(son,rec) in enumerate(zip(sons,tail))]
                evidence.append(f'Brain220 counterless setup tail bound to {len(numbered)} treatment Sonication(s)')
        candidates=[]
        for n,rec in numbered:
            try:
                sx,sy,sz=(float(v) for v in rec.steering_xyz)
                if n not in focal_by_number or not np.isfinite([sx,sy,sz]).all():
                    continue
                candidates.append((n,(sx,sy,sz),focal_by_number[n]))
            except Exception:
                continue
        if not candidates:
            return None,['No Sonication has both workstation steering and planned focalRAS evidence']
        steering=np.asarray([v[1] for v in candidates],float)
        nominal=np.nanmedian(steering,axis=0)
        candidates.sort(key=lambda v:(float(np.linalg.norm(np.asarray(v[1],float)-nominal)),v[0]))
        best=candidates[0]
        # A DQA natural-focus shot is expected on/very near the acoustic axis.
        # Do not silently choose a steered treatment target as the mechanical focus.
        lateral=float(math.hypot(best[1][0],best[1][1]))
        if lateral > 0.5:
            return None,[*evidence,f'Default-centre DQA steering not proven: smallest lateral steering={lateral:.2f} mm']
        n,steer,focus=best
        evidence.append(
            f'Fixed XD natural focus from default-centre S{n}: workstation steering=({steer[0]:+.2f},{steer[1]:+.2f},{steer[2]:.2f}), series median=({nominal[0]:+.2f},{nominal[1]:+.2f},{nominal[2]:.2f}), planned focalRAS=({focus[0]:+.2f},{focus[1]:+.2f},{focus[2]:+.2f}) mm'
        )
        return tuple(float(v) for v in focus),evidence

    def _dqa_common_locate_focal_ras(self, package) -> tuple[tuple[float,float,float] | None, list[str], str | None]:
        """Return the common physical DQA focal point from Locate Transducer.

        For a DQA series the transducer is mechanically fixed after the setup Locate.
        We therefore use the last directly reported workstation ``focal position:``
        preceding the first DQA sonication.  Electronic steering is a separate
        domain; if the sonication steering target changes across the series the
        centre-alignment judgement is excluded rather than folding steering into
        the physical focal point.
        """
        workspace=Path(getattr(package,'workspace','.') or '.')
        svc=TransducerLocationService()
        history=[q for q in svc.locate_focal_history(workspace)
                 if q.focal_xyz is not None and (not q.protocol_name or 'dqa' in q.protocol_name.lower())]
        steering=list(svc._sonication_steering_events(workspace))
        evidence=[]
        first_sonic=min((float(q.clock_s) for q in steering),default=None)

        candidates=history
        if first_sonic is not None:
            pre=[q for q in history if float(q.clock_s) <= first_sonic + 1e-6]
            if pre:
                candidates=pre
        if not candidates:
            return None,['No DQA Locate Transducer focal-position record was found'],None

        chosen=max(candidates,key=lambda q:float(q.clock_s))
        focal=tuple(float(v) for v in chosen.focal_xyz)
        evidence.append(
            f'DQA common focal from last Locate before first sonication: '
            f'({focal[0]:+.1f},{focal[1]:+.1f},{focal[2]:+.1f}) mm at {chosen.clock_s:.3f}s'
        )

        steering_exclusion=None
        if len(steering) >= 2:
            vals=np.asarray([q.steering_xyz for q in steering],float)
            if vals.ndim == 2 and vals.shape[1] == 3 and np.all(np.isfinite(vals)):
                # R0190d: a single electronically-steered DQA shot must not suppress
                # judgement of the physical/default-centre DQA shots.  Determine the
                # study default from the most axis-centred steering state, exclude
                # non-centre shots individually (the measurement path already does
                # this), and assess stability only among centre shots.
                centre_i=int(np.argmin(np.hypot(vals[:,0], vals[:,1])))
                nominal=vals[centre_i]
                centre_mask=np.linalg.norm(vals-nominal,axis=1) <= 0.5
                centre_vals=vals[centre_mask]
                steered=[int(q.sonication_number) for q,keep in zip(steering,centre_mask) if not bool(keep)]
                if steered:
                    evidence.append('Electronic-steering DQA shot(s) excluded individually: '+', '.join(f'S{n}' for n in sorted(set(steered))))
                if len(centre_vals) >= 2:
                    span=np.nanmax(centre_vals,axis=0)-np.nanmin(centre_vals,axis=0)
                    if float(np.nanmax(np.abs(span))) > 0.5:
                        steering_exclusion=(
                            'default-centre steering is internally inconsistent '
                            f'(XYZ span {span[0]:.2f}/{span[1]:.2f}/{span[2]:.2f} mm)'
                        )
                        evidence.append('DQA centre-alignment judgement excluded: '+steering_exclusion)
                    else:
                        evidence.append(
                            f'Default-centre DQA steering stable after per-shot exclusions '
                            f'(XYZ span {span[0]:.2f}/{span[1]:.2f}/{span[2]:.2f} mm)'
                        )
        return focal,evidence,steering_exclusion

    def _observed_dqa_focus_by_orientation(self, package, focal_by_number: dict[int, tuple[float,float,float]]) -> tuple[dict[str,dict[str,object]], list[str]]:
        """R0190: exact-paired, phantom-masked observed DQA focus measurement."""
        params=self._find_mri_params(Path(getattr(package,'workspace','.') or '.'))
        try:
            rows=parse_ado_rowset(params) if params is not None and Path(params).exists() else []
        except Exception:
            rows=[]
        if not rows:
            return {},['Observed DQA focus unavailable: MriImageParams missing/unreadable']
        evidence=[]; shot_best={}
        for pos,son in enumerate(list(getattr(package,'sonications',[]) or []),start=1):
            number=int(getattr(son,'sonication_number',0) or pos)
            exclusion=self._dqa_exclusion_reason(package,number,focal_by_number)
            if exclusion:
                evidence.append(f'S{number} excluded from common-focus measurement: {exclusion}')
                continue
            temps=list(getattr(son,'temperature_frames',[]) or [])
            mags=list(getattr(son,'magnitude_frames',[]) or [])
            if not temps or not mags:
                continue
            # Establish validated baselines independently per physical orientation.
            baselines={}
            for tf in temps:
                row=self._row_for_raw_frame(rows,tf.path)
                orientation=self._orientation(row or {})
                if orientation not in ('Axial','Sagittal') or orientation in baselines:
                    continue
                try: arr=np.asarray(self.raw.read_temperature(tf.path),float)
                except Exception: continue
                thermo=self._thermometry_evidence(row,arr)
                if bool(thermo.get('valid')):
                    baselines[orientation]=(arr,thermo)
            for tf in temps:
                row=self._row_for_raw_frame(rows,tf.path)
                orientation=self._orientation(row or {})
                if orientation not in baselines:
                    continue
                pair=self._exact_magnitude_pair(rows,tf.path,mags)
                if pair is None:
                    evidence.append(f'S{number} {Path(tf.path).name}: no unique exact magnitude acquisition/geometry pair; fail closed')
                    continue
                mf,mrow=pair
                try:
                    arr=np.asarray(self.raw.read_temperature(tf.path),float)
                    mag=np.asarray(self.raw.read_magnitude(mf.path),float)
                except Exception:
                    continue
                baseline,thermo=baselines[orientation]
                if arr.shape != baseline.shape or mag.shape[:2] != arr.shape[:2]:
                    continue
                masked=self._phantom_mask_from_magnitude(orientation,mag)
                if masked is None:
                    evidence.append(f'S{number} {Path(tf.path).name}: phantom-derived {orientation} mask unavailable; fail closed')
                    continue
                mask,mask_diag=masked
                delta=arr-baseline if thermo.get('mode') == 'absolute' else arr
                valid=mask & np.isfinite(delta)
                if int(valid.sum()) < 25:
                    continue
                filled=np.where(valid,delta,np.nan)
                # Coherent 5x5 local statistic. Require enough valid neighbours so
                # a mask edge/single-pixel spike cannot win.
                values=np.nan_to_num(filled,nan=0.0); counts=valid.astype(float)
                pv=np.pad(values,2,mode='constant'); pc=np.pad(counts,2,mode='constant')
                sums=sum(pv[dy:dy+delta.shape[0],dx:dx+delta.shape[1]] for dy in range(5) for dx in range(5))
                nums=sum(pc[dy:dy+delta.shape[0],dx:dx+delta.shape[1]] for dy in range(5) for dx in range(5))
                sm=np.where(nums>=18.0,sums/np.maximum(nums,1.0),-np.inf)
                sm[~mask]=-np.inf
                if not np.isfinite(sm).any():
                    continue
                flat=int(np.nanargmax(sm)); hy,hx=np.unravel_index(flat,sm.shape); score=float(sm[hy,hx])
                # Weighted centroid in a local 5x5 patch, constrained by mask.
                ya,yb=max(0,hy-2),min(delta.shape[0],hy+3); xa,xb=max(0,hx-2),min(delta.shape[1],hx+3)
                patch=np.asarray(delta[ya:yb,xa:xb],float); pm=mask[ya:yb,xa:xb] & np.isfinite(patch)
                floor=float(np.nanmedian(patch[pm])) if pm.any() else score
                weights=np.where(pm,np.maximum(patch-floor,0.0),0.0)
                if float(weights.sum())>0:
                    gy,gx=np.indices(weights.shape); fx=xa+float((weights*gx).sum()/weights.sum()); fy=ya+float((weights*gy).sum()/weights.sum())
                else:
                    fx=float(hx); fy=float(hy)
                # R0190p focus-estimator audit.  Keep the thermometry centroid as
                # the authoritative observed focus, but independently estimate the
                # local smooth-map maximum with a sub-pixel parabola.  Recording
                # both prevents phantom geometry from being moved to compensate for
                # an observed-focus estimator bias.
                qx=float(hx); qy=float(hy)
                if 0 < hx < sm.shape[1]-1 and np.isfinite(sm[hy,hx-1:hx+2]).all():
                    a,b,c=(float(v) for v in sm[hy,hx-1:hx+2]); den=a-2.0*b+c
                    if abs(den)>1e-12:
                        qx=float(hx)+float(np.clip(0.5*(a-c)/den,-0.5,0.5))
                if 0 < hy < sm.shape[0]-1 and np.isfinite(sm[hy-1:hy+2,hx]).all():
                    a,b,c=(float(v) for v in sm[hy-1:hy+2,hx]); den=a-2.0*b+c
                    if abs(den)>1e-12:
                        qy=float(hy)+float(np.clip(0.5*(a-c)/den,-0.5,0.5))
                hotspot_ras=self._absolute_ras(row,fx,fy)
                quadratic_ras=self._absolute_ras(row,qx,qy)
                if hotspot_ras is None or not np.isfinite(hotspot_ras).all():
                    continue
                # Reject unrelated hot structures/artifacts far from the commanded
                # DQA focus.  This is a plausibility gate only; it does not move or
                # fit the measured centroid.  The 30 mm radius comfortably includes
                # clinically meaningful DQA offsets while excluding the >100 mm
                # sagittal artifact seen in the 4267 export.
                planned=focal_by_number.get(number)
                if planned is not None:
                    planned_arr=np.asarray(planned,float)
                    inplane=np.asarray(hotspot_ras,float)-planned_arr
                    if orientation == 'Axial':
                        dist_mm=float(np.hypot(inplane[0],inplane[1]))
                    else:
                        dist_mm=float(np.hypot(inplane[1],inplane[2]))
                    if not np.isfinite(dist_mm) or dist_mm > 30.0:
                        evidence.append(f'S{number} {Path(tf.path).name}: thermal candidate {dist_mm:.1f} mm from planned focus rejected as unrelated artifact')
                        continue
                paired={'row':mrow,'raw':str(mf.path),'label':f'Exact paired {orientation} magnitude S{number} {Path(mf.path).name}'}
                if orientation=='Axial':
                    cp=mask_diag['circle_pixel']; cr=self._absolute_ras(mrow,*cp)
                    if cr is None: continue
                    paired.update(circle_pixel=cp,circle_ras=tuple(float(v) for v in cr),support=float(mask_diag['support']))
                else:
                    ok,fdiag=self._point_in_exported_image_frame(mrow,hotspot_ras,in_plane_margin_fraction=.10,normal_tolerance_mm=2.0)
                    if not ok or not fdiag:
                        continue
                    bx=float(fdiag['x_px']); by=float(mask_diag['slope']*bx+mask_diag['intercept']); br=self._absolute_ras(mrow,bx,by)
                    sizes=self._pixel_sizes(mrow)
                    if br is None or sizes is None: continue
                    tilt=float(math.degrees(math.atan2(float(mask_diag['slope'])*sizes[1],sizes[0])))
                    ap=self._sagittal_ap_center_from_image(mrow,mag)
                    paired.update(baseline_pixel=(bx,by),baseline_ras=tuple(float(v) for v in br),slope=float(mask_diag['slope']),intercept=float(mask_diag['intercept']),support=float(mask_diag['support']),tilt_deg=tilt,phantom_ap_center_ras=(ap[0] if ap else None),phantom_ap_center_pixel=(ap[1] if ap else None))
                candidate={'sonication_number':number,'orientation':orientation,'row':row,'frame':Path(tf.path).name,
                    'magnitude_frame':Path(mf.path).name,'hotspot_pixel':(fx,fy),'hotspot_ras':tuple(float(v) for v in hotspot_ras),
                    'score':score,'mask_geometry':mask_diag,'paired_reference':paired,
                    'focus_estimator_audit':{
                        'centroid_pixel':(float(fx),float(fy)),'quadratic_peak_pixel':(float(qx),float(qy)),
                        'centroid_ras':tuple(float(v) for v in hotspot_ras),
                        'quadratic_peak_ras':None if quadratic_ras is None else tuple(float(v) for v in quadratic_ras),
                        'pixel_separation':float(np.hypot(fx-qx,fy-qy)),
                    },
                    'exact_identity':self._row_acquisition_identity(row),'thermometry_evidence':list(thermo.get('evidence',[]) or [])}
                key=(number,orientation); old=shot_best.get(key)
                if old is None or score>float(old['score']): shot_best[key]=candidate
        # R0190c recovery path: some valid MEMP DQA exports expose thermometry
        # perfectly (and Replay can display it) but do not provide a unique Field-6
        # magnitude partner for every Field-5 acquisition.  The old strict path then
        # discarded *all* observed focus evidence and Summary stayed N/A.
        #
        # Recover only the observed hotspot, never the DQA zero point: use the
        # already fail-closed same-raster planned-focus local search to identify a
        # coherent heated focus.  Series X/Y/Z are still measured later against the
        # independently detected DQA phantom circle/lower-line geometry.
        present_orientations={o for (_n,o) in shot_best}
        if len(present_orientations) < 2:
            for pos,son in enumerate(list(getattr(package,'sonications',[]) or []),start=1):
                number=int(getattr(son,'sonication_number',0) or pos)
                if self._dqa_exclusion_reason(package,number,focal_by_number):
                    continue
                planned=focal_by_number.get(number)
                if planned is None:
                    continue
                m=self._planned_focus_native_measurement(son,rows,planned)
                if m.get('error'):
                    evidence.append(f"S{number} thermal-focus fallback unavailable: {m.get('error')}")
                    continue
                orientation=str(m.get('orientation') or '')
                if orientation not in ('Axial','Sagittal') or orientation in present_orientations:
                    continue
                frame_name=str(m.get('frame') or '')
                tf=next((f for f in list(getattr(son,'temperature_frames',[]) or []) if Path(f.path).name==frame_name),None)
                row=self._row_for_raw_frame(rows,tf.path) if tf is not None else None
                if row is None:
                    continue
                fx=float(m.get('hotspot_x')); fy=float(m.get('hotspot_y')); ras=self._absolute_ras(row,fx,fy)
                if ras is None or not np.isfinite(ras).all():
                    continue
                candidate={'sonication_number':number,'orientation':orientation,'row':row,'frame':frame_name,
                    'magnitude_frame':'not required (validated thermal-focus fallback)',
                    'hotspot_pixel':(fx,fy),'hotspot_ras':tuple(float(v) for v in ras),
                    'score':float(m.get('hotspot_score_c',0.0) or 0.0),'mask_geometry':{'kind':'validated-thermal-local-focus'},'paired_reference':None,
                    'exact_identity':self._row_acquisition_identity(row),'thermometry_evidence':[str(m.get('evidence') or '')]}
                shot_best[(number,orientation)]=candidate; present_orientations.add(orientation)
                evidence.append(f"Observed {orientation} DQA focus recovered from validated same-raster thermal hotspot in S{number} {frame_name}; magnitude pair was not used as the displacement zero-point")
                if len(present_orientations)>=2:
                    break

        # Select a DQA shot before selecting a frame: each S/orientation contributes
        # at most one exact-paired or validated thermal-focus candidate. Planned focus
        # is only a focus-identification aid/tie-break, never the series zero point.
        best={}
        for orientation in ('Axial','Sagittal'):
            candidates=[c for (n,o),c in shot_best.items() if o==orientation]
            if not candidates: continue
            top=max(float(c['score']) for c in candidates); near=[c for c in candidates if float(c['score'])>=top-max(abs(top)*.03,.15)]
            def tie(c):
                planned=focal_by_number.get(int(c['sonication_number']))
                if planned is None: return float('inf')
                ok,d=self._point_in_exported_image_frame(c['row'],planned,in_plane_margin_fraction=.25,normal_tolerance_mm=18.0)
                if not ok or not d: return float('inf')
                return float(np.hypot(float(c['hotspot_pixel'][0])-float(d['x_px']),float(c['hotspot_pixel'][1])-float(d['y_px'])))
            best[orientation]=min(near,key=lambda c:(tie(c),-float(c['score'])))
        for orientation,c in sorted(best.items()):
            h=c['hotspot_pixel']; r=c['hotspot_ras']; mg=c['mask_geometry']
            evidence.append(f"Observed {orientation} DQA focus: selected S{c['sonication_number']} thermal={c['frame']} magnitude={c['magnitude_frame']} exact_identity={c['exact_identity']}; hotspot=({h[0]:.2f},{h[1]:.2f}) px MR-RAS=({r[0]:+.2f},{r[1]:+.2f},{r[2]:+.2f}) mm; 5x5 coherent score={float(c['score']):.3f}; phantom mask={mg.get('kind')}")
        return best,evidence

    @classmethod
    def _nearest_reference_candidate(cls, candidates: list[dict[str,object]], focus_ras) -> tuple[dict[str,object] | None, dict[str,float] | None]:
        best=None; best_diag=None; best_cost=float('inf')
        for candidate in candidates:
            if candidate.get('stack_consistent') is False:
                continue
            row=candidate.get('row')
            if not isinstance(row,dict):
                continue
            ok,diag=cls._point_in_exported_image_frame(row,focus_ras,in_plane_margin_fraction=.08,normal_tolerance_mm=10.0)
            if not ok or not diag:
                continue
            # Prefer the closest slice plane first; an in-FOV projection is required.
            x=float(diag.get('x_px',np.nan)); y=float(diag.get('y_px',np.nan))
            w=float(diag.get('width',256.0)); h=float(diag.get('height',256.0))
            inside=(0.0 <= x < w and 0.0 <= y < h)
            if not inside:
                continue
            cost=abs(float(diag.get('normal_mm',np.inf)))
            if cost < best_cost:
                best=candidate; best_diag=diag; best_cost=cost
        return best,best_diag

    def analyze_series(self, package) -> DqaFocusAlignment:
        """Series-common DQA alignment from observed focus and phantom geometry.

        R0190 contract:
          * Observed focus comes from validated thermometry, not planned focalRAS.
          * planned focalRAS may seed a local hotspot search but is never a zero-point.
          * X is measured in one DQA-Axial raster: observed focus LR projection -
            detected phantom-circle LR centre.
          * Y is measured in one DQA-Sagittal raster: observed focus AP projection -
            detected sagittal phantom/body AP centre.
          * Z is measured in one DQA-Sagittal raster: observed focus projection -
            (detected lower line + 20.0 mm superior in MR RAS).
          * Reference and focus must both project into the same selected raster.
            Otherwise the component is unavailable (fail closed).
        """
        key=f"r0191a::series::{Path(getattr(package,'workspace','.') or '.').resolve()}"
        if key in self._cache:
            return self._cache[key]
        if not self.is_dqa(package):
            result=DqaFocusAlignment(confidence='Not DQA',evidence=['DQA-only analysis not applicable'],calculator_contract='R0191a')
            self._cache[key]=result
            return result

        reference=self._dqa_reference_geometry(package)
        ref_evidence=list(reference.get('evidence',[]) or [])
        focal_by_number=self._summary_focal_ras(package)
        observed,observed_evidence=self._observed_dqa_focus_by_orientation(package,focal_by_number)
        _locate_focal,locate_evidence,steering_exclusion=self._dqa_common_locate_focal_ras(package)

        x=y=z=None; tilt=None; reference_xyz=None; registered_focal=None; baseline_to_focal=None
        ot_x=ot_y=ot_z=None; ot_phase_axis=None
        geometry_evidence=[]; failures=[]; diagnostic_overlays={}

        axial=observed.get('Axial')
        if axial is None:
            failures.append('observed Axial thermal focus')
        else:
            focus_ras=np.asarray(axial['hotspot_ras'],float)
            candidate=axial.get('paired_reference') if isinstance(axial.get('paired_reference'),dict) and axial.get('paired_reference',{}).get('circle_ras') is not None else None
            # R0190m: an exact slice pairing is not allowed to override the
            # cross-slice phantom consensus when that slice locked onto an
            # internal concentric edge.  Prefer another registered phantom slice.
            if candidate is not None and candidate.get('stack_consistent') is False:
                candidate=None
            diag=None
            if candidate is not None:
                _ok,diag=self._point_in_exported_image_frame(candidate['row'],focus_ras,in_plane_margin_fraction=.08,normal_tolerance_mm=10.0)
                if not _ok:
                    diag=None
            # R0190x: NEVER substitute a phantom point from another DQA stack/slice.
            # The workstation overlay and the numeric X must be owned by the same
            # acquisition geometry as the observed thermal focus.  Cross-series RAS
            # projection can be mathematically valid yet measure a different physical
            # phantom section; that produced the false ~5 mm result while the visible
            # focus/reference separation was ~11 mm.
            if candidate is None or diag is None:
                candidate=None; diag=None
                failures.append('exact-paired Axial phantom reference')
            else:
                row=candidate['row']; circle=np.asarray(candidate['circle_ras'],float)
                focus_plane=self._absolute_ras(row,float(diag['x_px']),float(diag['y_px']))
                if focus_plane is None:
                    failures.append('Axial focus projection')
                else:
                    focus_plane=np.asarray(focus_plane,float)
                    # Independent observed-vs-Sonication-target measurement.  This
                    # is NOT the phantom alignment zero-point.  Project the planned
                    # focalRAS of the same observed Sonication into this exact raster.
                    planned=focal_by_number.get(int(axial.get('sonication_number') or 0))
                    planned_diag=None
                    if planned is not None:
                        pok,planned_diag=self._point_in_exported_image_frame(row,planned,in_plane_margin_fraction=.08,normal_tolerance_mm=10.0)
                        if pok and planned_diag:
                            planned_plane=self._absolute_ras(row,float(planned_diag['x_px']),float(planned_diag['y_px']))
                            if planned_plane is not None:
                                pd=focus_plane-np.asarray(planned_plane,float)
                                ot_x=float(pd[0]); ot_y=float(pd[1])
                    cp=candidate['circle_pixel']
                    pixel_delta=self._ras_delta(row,float(diag['x_px'])-float(cp[0]),float(diag['y_px'])-float(cp[1]))
                    direct_delta=focus_plane-circle
                    if pixel_delta is None or float(np.linalg.norm(np.asarray(pixel_delta)-direct_delta)) > 0.25:
                        failures.append('Axial pixel/RAS geometry consistency')
                        x=None
                        geometry_evidence.append('R0190 fail-closed: Axial pixel-derived and direct RAS deltas disagree by >0.25 mm')
                    else:
                        x=float(direct_delta[0])
                    geometry_evidence.append(
                        f"Axial same-raster: {candidate['label']}; circle=({cp[0]:.2f},{cp[1]:.2f}) px, "
                        f"focus projection=({float(diag['x_px']):.2f},{float(diag['y_px']):.2f}) px, plane distance={float(diag['normal_mm']):+.2f} mm; "
                        f"RL={x:+.2f} mm (focus R={float(focus_plane[0]):+.3f} - phantom R={float(circle[0]):+.3f}); "
                        f"pixel dx={float(diag['x_px'])-float(cp[0]):+.3f} px; Y/AP comes only from Sagittal"
                    )
                    reference_xyz=(float(circle[0]),float(circle[1]),float(circle[2]))
                    registered_focal=tuple(float(v) for v in focus_plane)
                    # R0190u: calculator pixels above belong to the selected phantom
                    # reference raster.  The overlay, however, is drawn on the exact
                    # thermal RAW named by the key.  Reusing reference-raster pixels
                    # on that thermal image caused the visibly displaced markers.
                    # Keep calculator geometry intact, but reproject every physical
                    # point into the exact thermal row for display.
                    display_focus=(float(axial['hotspot_pixel'][0]),float(axial['hotspot_pixel'][1]))
                    # R0190w display contract: X is an RL-only measurement.  A full 3-D
                    # phantom circle centre from another registered slice carries an AP/SI
                    # coordinate that is irrelevant to X and made the green marker appear
                    # ~10 mm away from the visible phantom centre.  Display the physical RL
                    # zero-point at the observed focus's AP/SI coordinates.  Calculator X
                    # remains focus_R - phantom_R and is unchanged.
                    display_lr_ras=np.asarray(focus_ras,float).copy()
                    display_lr_ras[0]=float(circle[0])
                    display_circle=self._project_ras_to_exact_row_pixel(axial['row'],display_lr_ras)
                    display_planned=None if planned is None else self._project_ras_to_exact_row_pixel(axial['row'],planned)
                    diagnostic_overlays[f"S{int(axial.get('sonication_number') or 0)}::{str(axial.get('frame') or '')}"]={
                        'orientation':'Axial','source_sonication_number':int(axial.get('sonication_number') or 0),'source_frame':str(axial.get('frame') or ''),'reference_label':str(candidate.get('label') or ''),
                        'circle_pixel':display_circle,'focus_pixel':display_focus,
                        'calculator_circle_pixel':(float(cp[0]),float(cp[1])),'calculator_focus_pixel':(float(diag['x_px']),float(diag['y_px'])),
                        'circle_ras':tuple(float(v) for v in circle),'display_lr_reference_ras':tuple(float(v) for v in display_lr_ras),'focus_ras':tuple(float(v) for v in focus_ras),
                        'planned_pixel':display_planned,
                        'planned_ras': None if planned is None else tuple(float(v) for v in planned),
                        'x_mm':x,'focus_rl_ras_mm':float(focus_plane[0]),'phantom_rl_ras_mm':float(circle[0]),
                        'rl_pixel_delta_px':float(diag['x_px'])-float(cp[0]),'circle_support':candidate.get('support'),
                        'circle_stack_residual_mm':candidate.get('stack_residual_mm'),
                        'focus_estimator_audit':axial.get('focus_estimator_audit'),'contract':'R0191a',
                    }

        sagittal=observed.get('Sagittal')
        if sagittal is None:
            failures.append('observed Sagittal thermal focus')
        else:
            focus_ras=np.asarray(sagittal['hotspot_ras'],float)
            # AP centre from exact-paired Axial phantom circle.
            # R0191a: AP is an independent cross-field physical measurement.
            # It must not disappear merely because the Sagittal lower-line/SI
            # reference is unavailable.  The exact-paired Axial circle owns the
            # phantom A coordinate; the observed Sagittal thermal focus owns the
            # focus A coordinate.  Both are absolute RAS scalars.
            ap_center=None
            if axial is not None:
                axref=axial.get('paired_reference') if isinstance(axial.get('paired_reference'),dict) else None
                if axref is not None and axref.get('circle_ras') is not None:
                    try:
                        ap_center=float(axref['circle_ras'][1])
                    except Exception:
                        ap_center=None
            if ap_center is not None and np.isfinite(float(ap_center)):
                y=float(focus_ras[1]-float(ap_center))
                geometry_evidence.append(
                    f"AP cross-field authority: exact-paired Axial phantom A={float(ap_center):+.2f} mm, "
                    f"Sagittal observed focus A={float(focus_ras[1]):+.2f} mm; Y={y:+.2f} mm"
                )
            else:
                failures.append('Axial phantom AP centre')
                y=None
            candidate=sagittal.get('paired_reference') if isinstance(sagittal.get('paired_reference'),dict) and sagittal.get('paired_reference',{}).get('baseline_ras') is not None else None
            if candidate is not None and candidate.get('stack_consistent') is False:
                candidate=None
            diag=None
            if candidate is not None:
                _ok,diag=self._point_in_exported_image_frame(candidate['row'],focus_ras,in_plane_margin_fraction=.08,normal_tolerance_mm=10.0)
                if not _ok:
                    diag=None
            # R0190x: Y/Z must use the phantom geometry paired to THIS thermal
            # acquisition.  Do not borrow the nearest registered DQA-Sagittal slice.
            # In the 4267 diagnostics the borrowed slice was +8.39 mm out of plane,
            # so its AP centre was not a same-raster measurement.
            if candidate is None or diag is None:
                candidate=None; diag=None
                failures.append('exact-paired Sagittal phantom reference')
            else:
                row=candidate['row']
                focus_plane=self._absolute_ras(row,float(diag['x_px']),float(diag['y_px']))
                # Evaluate the lower reference line at the observed focus X.
                # The previous centre-column baseline made the 'Lower line @ focus X'
                # overlay diagonal and was geometrically inconsistent.
                bx=float(diag['x_px']); by=float(candidate['slope']*bx+candidate['intercept'])
                baseline_abs=self._absolute_ras(row,bx,by)
                baseline=np.asarray(baseline_abs,float) if baseline_abs is not None else np.asarray(candidate['baseline_ras'],float)
                ref_ras=baseline.copy(); ref_ras[2]+=20.0
                ref_ok,ref_diag=self._point_in_exported_image_frame(row,ref_ras,in_plane_margin_fraction=.08,normal_tolerance_mm=2.0)
                if focus_plane is None or not ref_ok or not ref_diag:
                    failures.append('Sagittal +20 mm reference projection')
                else:
                    focus_plane=np.asarray(focus_plane,float)
                    # Phase encoding is the in-plane axis perpendicular to the exported
                    # frequency-encoding ROW/COL direction. Resolve only when the
                    # direction cosines are cardinal enough; otherwise leave it unknown.
                    try:
                        rv=np.asarray([float(row[k]) for k in ('rowdirectcosrasx','rowdirectcosrasy','rowdirectcosrasz')])
                        cv=np.asarray([float(row[k]) for k in ('coldirectcosrasx','coldirectcosrasy','coldirectcosrasz')])
                        def _axis(v):
                            i=int(np.argmax(np.abs(v)))
                            return ('RL','AP','SI')[i] if abs(float(v[i])) >= 0.85 else None
                        rawfd=str(row.get('freqdirection') or '').strip().upper()
                        if rawfd == 'ROW': ot_phase_axis=_axis(cv)
                        elif rawfd in ('COL','COLUMN'): ot_phase_axis=_axis(rv)
                    except Exception:
                        pass
                    planned=focal_by_number.get(int(sagittal.get('sonication_number') or 0))
                    planned_diag=None
                    if planned is not None:
                        pok,planned_diag=self._point_in_exported_image_frame(row,planned,in_plane_margin_fraction=.08,normal_tolerance_mm=10.0)
                        if pok and planned_diag:
                            planned_plane=self._absolute_ras(row,float(planned_diag['x_px']),float(planned_diag['y_px']))
                            if planned_plane is not None:
                                pd=focus_plane-np.asarray(planned_plane,float)
                                ot_y=float(pd[1]); ot_z=float(pd[2])
                    # R0191a: AP/Y was already resolved independently above.
                    # Do not couple it to Sagittal lower-line/SI availability.
                    # This block intentionally performs no Y reassignment.
                    ref_plane=self._absolute_ras(row,float(ref_diag['x_px']),float(ref_diag['y_px']))
                    if ref_plane is None:
                        failures.append('Sagittal reference back-projection')
                    else:
                        ref_plane=np.asarray(ref_plane,float)
                        bp=(float(diag['x_px']),float(candidate['slope']*float(diag['x_px'])+candidate['intercept']))
                        pixel_delta=self._ras_delta(row,float(diag['x_px'])-float(ref_diag['x_px']),float(diag['y_px'])-float(ref_diag['y_px']))
                        direct_delta=focus_plane-ref_plane
                        if pixel_delta is None or float(np.linalg.norm(np.asarray(pixel_delta)-direct_delta)) > 0.25:
                            failures.append('Sagittal pixel/RAS geometry consistency')
                            z=None
                            geometry_evidence.append('R0190 fail-closed: Sagittal pixel-derived and direct RAS deltas disagree by >0.25 mm')
                        else:
                            z=float(direct_delta[2])
                        baseline_to_focal=float(focus_plane[2]-baseline[2])
                        tilt=float(candidate.get('tilt_deg')) if candidate.get('tilt_deg') is not None else None
                        geometry_evidence.append(
                            f"Sagittal same-raster: {candidate['label']}; lower line=({bp[0]:.2f},{bp[1]:.2f}) px, "
                            f"+20 mm reference=({float(ref_diag['x_px']):.2f},{float(ref_diag['y_px']):.2f}) px, "
                            f"focus projection=({float(diag['x_px']):.2f},{float(diag['y_px']):.2f}) px, plane distance={float(diag['normal_mm']):+.2f} mm; "
                            f"lower-line→focus S={baseline_to_focal:+.2f} mm, Z after +20 mm={z:+.2f} mm"
                        )
                        if reference_xyz is None:
                            reference_xyz=(float(ref_plane[0]),float(ref_plane[1]),float(ref_plane[2]))
                        else:
                            reference_xyz=(reference_xyz[0],reference_xyz[1],float(ref_plane[2]))
                        if registered_focal is None:
                            registered_focal=tuple(float(v) for v in focus_plane)
                        # R0190u display contract: all pixels below are in the exact
                        # thermal source raster, never the phantom-reference raster.
                        display_focus=(float(sagittal['hotspot_pixel'][0]),float(sagittal['hotspot_pixel'][1]))
                        # R0190w display contract: decompose Sagittal phantom references by
                        # anatomical component.  Y uses only phantom AP centre; Z uses only
                        # lower-line/+20 mm SI.  Reusing the full 3-D coordinates of a
                        # reference slice visually introduced unrelated AP/SI/RL offsets.
                        display_base_ras=np.asarray(focus_ras,float).copy(); display_base_ras[2]=float(baseline[2])
                        display_ref_ras=np.asarray(focus_ras,float).copy(); display_ref_ras[2]=float(ref_plane[2])
                        display_ap_ras=None
                        if ap_center is not None and np.isfinite(float(ap_center)):
                            display_ap_ras=np.asarray(focus_ras,float).copy(); display_ap_ras[1]=float(ap_center)
                        display_baseline=self._project_ras_to_exact_row_pixel(sagittal['row'],display_base_ras)
                        display_reference=self._project_ras_to_exact_row_pixel(sagittal['row'],display_ref_ras)
                        display_ap_reference=None if display_ap_ras is None else self._project_ras_to_exact_row_pixel(sagittal['row'],display_ap_ras)
                        display_planned=None if planned is None else self._project_ras_to_exact_row_pixel(sagittal['row'],planned)
                        diagnostic_overlays[f"S{int(sagittal.get('sonication_number') or 0)}::{str(sagittal.get('frame') or '')}"]={
                            'orientation':'Sagittal','source_sonication_number':int(sagittal.get('sonication_number') or 0),'source_frame':str(sagittal.get('frame') or ''),'reference_label':str(candidate.get('label') or ''),
                            'baseline_pixel':display_baseline,'reference_pixel':display_reference,'ap_reference_pixel':display_ap_reference,
                            'focus_pixel':display_focus,'calculator_baseline_pixel':(float(bp[0]),float(bp[1])),'calculator_reference_pixel':(float(ref_diag['x_px']),float(ref_diag['y_px'])),'calculator_focus_pixel':(float(diag['x_px']),float(diag['y_px'])),'baseline_ras':tuple(float(v) for v in baseline),
                            'reference_ras':tuple(float(v) for v in ref_plane),'display_si_reference_ras':tuple(float(v) for v in display_ref_ras),'display_ap_reference_ras':None if display_ap_ras is None else tuple(float(v) for v in display_ap_ras),'focus_ras':tuple(float(v) for v in focus_ras),
                            'planned_pixel':display_planned,
                            'planned_ras': None if planned is None else tuple(float(v) for v in planned),
                            'phantom_ap_center_ras':candidate.get('phantom_ap_center_ras'),'y_mm':y,'baseline_to_focus_mm':baseline_to_focal,'z_mm':z,'tilt_deg':tilt,
                            'baseline_edge_contract':candidate.get('baseline_edge_contract'),'baseline_support':candidate.get('support'),
                            'baseline_stack_residual_mm':candidate.get('stack_residual_mm'),'contract':'R0191a',
                        }

        # R0190x: registered-stack numeric fallback is intentionally forbidden.
        # A missing exact magnitude/geometry pair is an unavailable measurement,
        # not permission to subtract a phantom centre from another acquisition.
        # This keeps calculator points, overlay points, and reported millimetres on
        # one physical raster.  Never fit to a screenshot/expected value.
        geometry_evidence.append(
            'R0190x exact-raster authority: no registered-stack fallback; each DQA component requires the phantom reference paired to the observed thermal acquisition.'
        )

        # R0191a physical-reference authority.  The DQA phantom zero-points are
        # properties of the phantom stack, not of one Field-6 slice.  R0190x/z
        # over-constrained the calculator to an exact thermal/magnitude raster;
        # this hid the valid SI reference and made the displayed phantom marker
        # disagree with the series-common physical reference.  Keep observed focus
        # Sonication-local, but take R/A and lower-S from the independently detected
        # phantom stack consensus.
        _center=reference.get('center_ras')
        if _center is not None and len(_center) >= 2:
            _cr=float(_center[0]); _ca=float(_center[1])
            if axial is not None:
                _afr=np.asarray(axial['hotspot_ras'],float)
                x=float(_afr[0]-_cr)
                geometry_evidence.append(f"R0191a phantom-stack RL authority: focus R={_afr[0]:+.3f}, phantom R={_cr:+.3f}; X={x:+.2f} mm")
            if sagittal is not None:
                _sfr=np.asarray(sagittal['hotspot_ras'],float)
                y=float(_sfr[1]-_ca)
                geometry_evidence.append(f"R0191a phantom-stack AP authority: focus A={_sfr[1]:+.3f}, phantom A={_ca:+.3f}; Y={y:+.2f} mm")
        _bs=reference.get('baseline_s_mm')
        if sagittal is not None and _bs is not None and np.isfinite(float(_bs)):
            _sfr=np.asarray(sagittal['hotspot_ras'],float)
            _ref_s=float(_bs)+20.0
            z=float(_sfr[2]-_ref_s)
            baseline_to_focal=float(_sfr[2]-float(_bs))
            _td=reference.get('tilt_deg')
            tilt=float(_td) if _td is not None and np.isfinite(float(_td)) else tilt
            geometry_evidence.append(f"R0191a phantom-stack SI authority: focus S={_sfr[2]:+.3f}, lower edge S={float(_bs):+.3f}, +20 mm reference S={_ref_s:+.3f}; Z={z:+.2f} mm")

        # Display the same physical zero-points used by the calculator.  On Axial,
        # the green phantom marker carries BOTH R and A phantom-centre components;
        # this makes the visible focus-to-phantom separation agree with X/Y instead
        # of collapsing AP onto the focus.
        if axial is not None and _center is not None:
            _afr=np.asarray(axial['hotspot_ras'],float)
            _pr=_afr.copy(); _pr[0]=float(_center[0]); _pr[1]=float(_center[1])
            _pix=self._project_ras_to_exact_row_pixel(axial['row'],_pr)
            _k=f"S{int(axial.get('sonication_number') or 0)}::{str(axial.get('frame') or '')}"
            _ov=diagnostic_overlays.setdefault(_k,{'orientation':'Axial','source_sonication_number':int(axial.get('sonication_number') or 0),'source_frame':str(axial.get('frame') or ''),'focus_pixel':tuple(axial['hotspot_pixel'])})
            _ov['circle_pixel']=_pix; _ov['circle_ras']=(float(_pr[0]),float(_pr[1]),float(_pr[2])); _ov['reference_label']='Phantom R/A stack consensus'
        if sagittal is not None:
            _sfr=np.asarray(sagittal['hotspot_ras'],float); _k=f"S{int(sagittal.get('sonication_number') or 0)}::{str(sagittal.get('frame') or '')}"
            _ov=diagnostic_overlays.setdefault(_k,{'orientation':'Sagittal','source_sonication_number':int(sagittal.get('sonication_number') or 0),'source_frame':str(sagittal.get('frame') or ''),'focus_pixel':tuple(sagittal['hotspot_pixel'])})
            if _center is not None:
                _ap=_sfr.copy(); _ap[1]=float(_center[1]); _ov['ap_reference_pixel']=self._project_ras_to_exact_row_pixel(sagittal['row'],_ap); _ov['display_ap_reference_ras']=tuple(float(v) for v in _ap)
            if _bs is not None and np.isfinite(float(_bs)):
                _si=_sfr.copy(); _si[2]=float(_bs)+20.0; _base=_sfr.copy(); _base[2]=float(_bs)
                _ov['reference_pixel']=self._project_ras_to_exact_row_pixel(sagittal['row'],_si); _ov['baseline_pixel']=self._project_ras_to_exact_row_pixel(sagittal['row'],_base); _ov['display_si_reference_ras']=tuple(float(v) for v in _si); _ov['baseline_ras']=tuple(float(v) for v in _base); _ov['reference_label']='Phantom AP / SI stack consensus'

        if x is None and y is None and z is None:
            result=DqaFocusAlignment(
                tilt_deg=tilt, confidence='Unavailable', calculator_contract='R0191a',
                judgement_excluded_reason=steering_exclusion,
                evidence=[
                    'R0190 fail-closed: DQA displacement requires observed thermometry focus and phantom reference in the same selected MR raster.',
                    'planned SonicationSummary focalRAS is a hotspot-search seed only and is never subtracted from phantom geometry.',
                    *observed_evidence,*geometry_evidence,*locate_evidence,*ref_evidence,
                ],
                excluded_reason='missing '+', '.join(failures) if failures else 'same-raster DQA geometry unavailable',
            )
            self._cache[key]=result
            return result

        confidence='High' if x is not None and y is not None and z is not None and tilt is not None else 'Partial'
        evidence=[
            'R0191a DQA contract: observed thermal focus is Sonication-local; phantom R/A and lower-S zero-points come from independently detected physical phantom-stack consensus.',
            'X = Axial observed-focus LR position - Axial phantom LR centre.',
            'Y = Sagittal observed-focus AP position - Sagittal phantom AP centre.',
            'Z = Sagittal observed-focus projection - (Sagittal lower line +20.0 mm superior).',
            'SonicationSummary focalRAS is a hotspot-search seed only; it is never a displacement zero-point.',
            *observed_evidence,*geometry_evidence,*locate_evidence,*ref_evidence,
        ]
        if failures:
            evidence.append('Partial components unavailable: '+', '.join(failures))
        # R0190u: overlay labels are display evidence for the final series result.
        # Populate them only after all axis components/fallbacks have resolved so
        # an Axial overlay cannot show stale/NaN Y and a Sagittal overlay cannot
        # disagree with Summary.  This does not alter the calculator inputs.
        for _overlay in diagnostic_overlays.values():
            _overlay['x_mm']=x; _overlay['y_mm']=y; _overlay['z_mm']=z; _overlay['tilt_deg']=tilt
            _overlay['contract']='R0191a'
        result=DqaFocusAlignment(
            x_mm=x,y_mm=y,z_mm=z,tilt_deg=tilt,confidence=confidence,
            judgement_excluded_reason=steering_exclusion,
            reference_xyz=reference_xyz,registered_focal_ras=registered_focal,
            baseline_to_focal_mm=baseline_to_focal,calculator_contract='R0191a',diagnostic_overlays=diagnostic_overlays,evidence=evidence,
            observed_target_x_mm=ot_x, observed_target_y_mm=ot_y, observed_target_z_mm=ot_z, observed_target_phase_axis=ot_phase_axis,
        )
        self._cache[key]=result
        return result

    def cached_series(self, package) -> DqaFocusAlignment | None:
        """Return the already-computed series result without triggering analysis or I/O."""
        key=f"r0191a::series::{Path(getattr(package,'workspace','.') or '.').resolve()}"
        return self._cache.get(key)

    def clear_cache(self) -> None:
        self._cache.clear()
        self._reference_cache.clear()
