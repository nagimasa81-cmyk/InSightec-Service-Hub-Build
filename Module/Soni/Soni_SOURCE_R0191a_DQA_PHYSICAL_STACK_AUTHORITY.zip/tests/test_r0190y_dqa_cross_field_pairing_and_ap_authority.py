from pathlib import Path
import ast

SRC=Path(__file__).parents[1]/"src/services/dqa_focus_alignment_service.py"

def _load_class():
    tree=ast.parse(SRC.read_text(encoding="utf-8"))
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="DqaFocusAlignmentService")
    mod=ast.Module(body=[cls],type_ignores=[])
    ns={}
    # This test is source-contract focused because the full service imports Qt/project runtime.
    return ast.unparse(cls)

def test_pairing_identity_explicitly_excludes_zone():
    src=_load_class()
    block=src[src.index("def _row_acquisition_identity"):src.index("def _geometry_compatible")]
    assert "return (son, array_index)" in block or "return son, array_index" in block
    assert "zone" not in block.split("return son, array_index")[0].split("def _row_acquisition_identity",1)[1]

def test_ap_uses_axial_phantom_circle_not_sagittal_body_midpoint():
    src=SRC.read_text(encoding="utf-8")
    assert "AP centre from exact-paired Axial phantom circle" in src
    calc=src[src.index("ap_center=None",src.index("def analyze_series")):]
    calc=calc[:calc.index("ref_plane=")]
    assert "axref['circle_ras'][1]" in calc
    assert "candidate.get('phantom_ap_center_ras')" not in calc

def test_far_thermal_artifact_is_rejected():
    src=SRC.read_text(encoding="utf-8")
    assert "dist_mm > 30.0" in src
    assert "rejected as unrelated artifact" in src
