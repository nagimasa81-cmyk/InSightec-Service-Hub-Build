from pathlib import Path
S=Path("src/services/dqa_focus_alignment_service.py").read_text(encoding="utf-8")
I=Path("src/ui/image_panel.py").read_text(encoding="utf-8")

def test_axial_display_reference_is_rl_only():
    assert "display_lr_ras[0]=float(circle[0])" in S
    assert "Phantom LR reference" in I

def test_sagittal_display_references_are_component_decomposed():
    assert "display_base_ras[2]=float(baseline[2])" in S
    assert "display_ref_ras[2]=float(ref_plane[2])" in S
    assert "display_ap_ras[1]=float(ap_center)" in S
    assert "Phantom AP reference" in I
    assert "Phantom SI reference (+20 mm)" in I
