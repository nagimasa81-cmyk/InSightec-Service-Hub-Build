import ast
from pathlib import Path
import numpy as np
P=Path(__file__).parents[1]
S=P/'src/services/dqa_focus_alignment_service.py'
M=P/'src/ui/main_window.py'

def test_sources_parse():
    ast.parse(S.read_text()); ast.parse(M.read_text())

def test_phase_is_not_inherited_in_summary():
    text=M.read_text()
    assert 'local_phase=phase' not in text
    assert "observed_target_phase_axis" in text

def test_phase_axis_is_raster_local():
    text=S.read_text()
    assert 'def _phase_axis' in text
    assert '"phase_axis":self._phase_axis(row)' in text

def test_centroid_helper_centres_asymmetric_blob_without_target():
    # execute only the static helper body via importing is avoided (PySide independent service may import deps)
    tree=ast.parse(S.read_text())
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='DqaFocusAlignmentService')
    fn=next(n for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name=='_coherent_hotspot_centroid')
    mod=ast.Module(body=[fn],type_ignores=[]); ast.fix_missing_locations(mod)
    ns={'np':np}; exec(compile(mod,'<centroid>','exec'),ns)
    a=np.zeros((31,31),float)
    yy,xx=np.indices(a.shape); a += 10*np.exp(-((xx-16.4)**2+(yy-14.7)**2)/(2*2.0**2))
    x,y=ns['_coherent_hotspot_centroid'](a,16,15,5)
    assert abs(x-16.4)<0.35 and abs(y-14.7)<0.35
