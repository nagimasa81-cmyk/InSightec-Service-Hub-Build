from pathlib import Path
SRC=Path(__file__).parents[1]/"src/services/dqa_focus_alignment_service.py"

def test_ap_resolves_before_sagittal_lower_line_gate():
    src=SRC.read_text(encoding="utf-8")
    a=src.index("# R0191a: AP is an independent cross-field physical measurement.")
    b=src.index("if candidate is None or diag is None:", a)
    block=src[a:b]
    assert "y=float(focus_ras[1]-float(ap_center))" in block
    assert "axref['circle_ras'][1]" in block

def test_missing_si_reference_does_not_clear_y():
    src=SRC.read_text(encoding="utf-8")
    a=src.index("if candidate is None or diag is None:", src.index("# R0191a: AP is an independent"))
    b=src.index("# R0190x: registered-stack numeric fallback", a)
    block=src[a:b]
    assert "y=None" not in block
