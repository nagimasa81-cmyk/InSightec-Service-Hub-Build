from pathlib import Path

SRC = (Path(__file__).parents[1] / "src/services/dqa_focus_alignment_service.py").read_text(encoding="utf-8")

def test_cross_stack_numeric_fallback_is_removed():
    assert "X aggregate Axial" not in SRC
    assert "Y aggregate Sagittal" not in SRC
    assert "registered-stack fallback used" not in SRC
    assert "R0190x exact-raster authority" in SRC

def test_nearest_reference_is_not_used_by_series_calculator():
    body = SRC[SRC.index("def analyze_series"): ]
    assert "candidate,diag=self._nearest_reference_candidate" not in body
    assert "exact-paired Axial phantom reference" in body
    assert "exact-paired Sagittal phantom reference" in body

def test_4267_bad_sagittal_cross_plane_path_is_documented():
    assert "+8.39 mm out of plane" in SRC
