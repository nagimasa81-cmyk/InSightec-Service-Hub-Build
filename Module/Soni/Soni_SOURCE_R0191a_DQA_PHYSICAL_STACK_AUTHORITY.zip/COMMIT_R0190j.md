# R0190j

- DQA Focus alignment remains Observed focus minus Phantom reference only.
- Adds independent Observed focus minus Sonication target center evidence.
- Adds dedicated bold Phase-direction delta cell; phase axis is emitted only when MR freqdirection + direction cosines resolve it safely.
- Adds independent display-only toggles for Observed focus, Sonication target center, and Phantom reference; toggles never alter calculations.
- Preserves R0190i uniform chart double-click reset hardening.
