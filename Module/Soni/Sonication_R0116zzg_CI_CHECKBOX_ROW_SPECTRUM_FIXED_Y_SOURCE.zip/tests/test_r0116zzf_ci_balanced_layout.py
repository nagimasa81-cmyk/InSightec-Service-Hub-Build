from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def test_ci_primary_visualization_gets_stretch_and_optional_sections_follow_it():
    s=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
    main=s.index('root.addWidget(self.ci_linked_host, 1)')
    chain=s.index('root.addWidget(self.ci_chain_container, 0)')
    rca=s.index('root.addWidget(self.ci_rca_container, 0)')
    science=s.index('root.addWidget(self.ci_science_container, 0)')
    details=s.index('root.addWidget(self.ci_details_host, 0)')
    assert main < chain < rca < science < details
    assert 'self.ci_linked_host.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)' in s
    assert 'self.ci_linked_stack.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)' in s

def test_ci_screen_fit_donates_more_height_to_main_plot_than_event_table():
    s=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'linked_h = max(145, min(390 if not compact else 310, viewport_h - reserve))' in s
    assert 'table.setMaximumHeight(70 if compact else 88)' in s
    assert 'self.ci_explanatory_note.setMaximumHeight(58)' in s

def test_treatment_science_has_single_compact_access_path():
    s=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'self.ci_science_check = QCheckBox("Treatment Outcome Science")' in s
    assert 'self.ci_science_open_button = None' in s
    assert 'QPushButton("Treatment Outcome Science")' not in s
