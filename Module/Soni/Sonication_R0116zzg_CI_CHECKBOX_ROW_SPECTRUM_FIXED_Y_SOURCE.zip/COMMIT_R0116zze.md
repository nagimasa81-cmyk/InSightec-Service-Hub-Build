# R0116zze — Accumulated-average Spectrum subtraction

- Added Spectrum Processing mode: Current spectrum / Current − accumulated mean.
- Baseline is the bin-by-bin arithmetic mean in linear amplitude from frame 0 through the frame immediately before the current frame.
- Current frame is excluded from its own baseline.
- Output is signed delta dB = 20*log10(current / accumulated_mean).
- 0 dB reference line added; positive values indicate newly elevated frequency components.
- Prefix-sum cache keeps replay updates efficient and is invalidated whenever the replay object changes.
- New controls/tooltips localized across all seven supported languages.
- No duplicate implementation path added; calculation is centralized in HydrophoneReplayService.

Validation before packaging: dedicated 4/4, R0116 245/245, full non-PySide6 ROI 551/551.
