# R0116zzg — CI checkbox row + spectrum fixed Y scale

- Cavitation Intelligence: unify the four optional section checkboxes into one horizontal row.
- Cavitation Intelligence: donate more viewport height to Linked Cavitation Analysis and reduce footer note height for better balance on laptop screens.
- Spectrum tab: keep the frequency-axis behaviour unchanged, but compute a fixed Y range from the full replay so the whole waveform is visible and replay-to-replay changes are visually comparable.
- Spectrum tab accumulated-delta mode: use a symmetric fixed Y range around 0 dB across the full replay.
