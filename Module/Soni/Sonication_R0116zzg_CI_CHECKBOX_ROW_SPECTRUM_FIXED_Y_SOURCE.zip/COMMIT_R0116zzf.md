# R0116zzf — Cavitation Intelligence balanced layout

- Rebalanced Cavitation Intelligence into compact summary/controls, dominant primary linked visualization, and optional detail sections below.
- Primary Linked Cavitation Analysis receives layout stretch and responsive height instead of remaining a thin lower strip.
- Evidence Chain, Root Cause Analysis, Treatment Outcome Science, and Event/Element details are placed below the main visualization and remain optional.
- Removed duplicate Treatment Outcome Science header button; the horizontal checkbox is the single compact access path.
- Reduced explanatory-note and event-table height so plots receive the available screen space.
- Updated screen-fit sizing to donate substantially more viewport height to the main plots while retaining laptop fit.
- Updated stale regression tests that encoded the older fixed-height/header-button layout so they cannot force a layout regression later.
- Duplicate method audit: 0 in main_window.py and hydrophone_window.py.

Validation before packaging: R0116 248/248 PASS; full suite excluding known PySide6 ROI GUI test 554/554 PASS.
