from __future__ import annotations

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import Signal, QPointF
from PySide6.QtWidgets import QGroupBox, QVBoxLayout


class ImagePanel(QGroupBox):
    def __init__(self, title, parent=None):
        super().__init__(title, parent)
        self.view = pg.PlotWidget()
        self.view.setAspectLocked(True)
        self.view.invertY(True)
        self.view.hideAxis("left")
        self.view.hideAxis("bottom")
        self.image = pg.ImageItem(axisOrder="row-major")
        self.view.addItem(self.image)
        self.hotspot = pg.ScatterPlotItem(size=18, symbol="+", pen=pg.mkPen(width=3))
        self.view.addItem(self.hotspot)
        self.hotspot_label = pg.TextItem(anchor=(0, 1))
        self.hotspot_label.setVisible(False)
        self.view.addItem(self.hotspot_label)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(2, 4, 2, 2)
        layout.addWidget(self.view)

    def set_image(self, array, levels=None, lut=None, hotspot=None, hotspot_text=None):
        if array is None:
            self.image.clear(); self.hotspot.setData([]); self.hotspot_label.setVisible(False); return
        self.image.setImage(np.asarray(array), autoLevels=levels is None, levels=levels)
        self.image.setLookupTable(lut)
        self.view.autoRange(padding=0.01)
        if hotspot is not None:
            self.hotspot.setData([hotspot[0]], [hotspot[1]])
            if hotspot_text:
                self.hotspot_label.setText(hotspot_text)
                self.hotspot_label.setPos(hotspot[0] + 4, hotspot[1] - 4)
                self.hotspot_label.setVisible(True)
        else:
            self.hotspot.setData([]); self.hotspot_label.setVisible(False)


class OverlayPanel(QGroupBox):
    cursorMoved = Signal(float, float)

    def __init__(self, title="Magnitude + Temperature Overlay", parent=None):
        super().__init__(title, parent)
        self.view = pg.PlotWidget()
        self.view.setAspectLocked(True)
        self.view.invertY(True)
        self.view.hideAxis("left")
        self.view.hideAxis("bottom")
        self.view.setMouseEnabled(x=True, y=True)
        self.magnitude_item = pg.ImageItem(axisOrder="row-major")
        self.temperature_item = pg.ImageItem(axisOrder="row-major")
        self.view.addItem(self.magnitude_item)
        self.view.addItem(self.temperature_item)

        self.hotspot = pg.ScatterPlotItem(size=20, symbol="+", pen=pg.mkPen("r", width=3))
        self.view.addItem(self.hotspot)
        self.hotspot_label = pg.TextItem(anchor=(0, 1))
        self.hotspot_label.setVisible(False)
        self.view.addItem(self.hotspot_label)

        # Compact movable cursor. The workstation-style full-screen yellow
        # crosshair was intentionally removed; only a small target remains.
        self.cursor_target = pg.TargetItem(
            movable=True,
            size=18,
            symbol="+",
            pen=pg.mkPen("#00d9ff", width=2),
            hoverPen=pg.mkPen("#ffffff", width=2),
        )
        self.cursor_target.setVisible(False)
        self.cursor_label = pg.TextItem(anchor=(0, 1), color="#f5f5f5", fill=pg.mkBrush(0, 0, 0, 160))
        self.cursor_label.setVisible(False)
        self.view.addItem(self.cursor_target)
        self.view.addItem(self.cursor_label)
        self.cursor_target.sigPositionChanged.connect(self._target_dragged)

        # Blue ROI circle used for Max/Average temperature calculation.
        self.roi_circle = pg.CircleROI((0, 0), (10, 10), movable=False, pen=pg.mkPen("#00a8ff", width=2))
        self.roi_circle.setAcceptedMouseButtons(0)
        self.roi_circle.setVisible(False)
        self.view.addItem(self.roi_circle)

        self._shape = None
        self._updating_target = False
        self.view.scene().sigMouseClicked.connect(self._clicked)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(2, 4, 2, 2)
        layout.addWidget(self.view)

    def _clicked(self, event):
        if self._shape is None or event.button() != __import__("PySide6.QtCore", fromlist=["Qt"]).Qt.MouseButton.LeftButton:
            return
        point = self.view.plotItem.vb.mapSceneToView(event.scenePos())
        x = float(np.clip(point.x(), 0, self._shape[1] - 1))
        y = float(np.clip(point.y(), 0, self._shape[0] - 1))
        self.cursorMoved.emit(x, y)

    def _target_dragged(self):
        if self._updating_target or self._shape is None:
            return
        pos = self.cursor_target.pos()
        x = float(np.clip(pos.x(), 0, self._shape[1] - 1))
        y = float(np.clip(pos.y(), 0, self._shape[0] - 1))
        self.cursorMoved.emit(x, y)

    def set_cursor(self, x: float, y: float, text: str = ""):
        self._updating_target = True
        self.cursor_target.setPos(QPointF(x, y))
        self._updating_target = False
        self.cursor_label.setPos(x + 4, y - 4)
        self.cursor_label.setText(text)
        self.cursor_target.setVisible(True)
        self.cursor_label.setVisible(bool(text))

    def set_roi(self, center_x: float | None, center_y: float | None, radius: float | None):
        if center_x is None or center_y is None or radius is None:
            self.roi_circle.setVisible(False)
            return
        diameter = radius * 2.0
        self.roi_circle.setPos((center_x - radius, center_y - radius), update=False)
        self.roi_circle.setSize((diameter, diameter), update=False)
        self.roi_circle.setVisible(True)

    def fit_image(self):
        self.view.autoRange(padding=0.01)

    def set_overlay(self, magnitude, temperature, magnitude_levels=None, temperature_levels=None,
                    temperature_lut=None, opacity=0.55, hotspot=None, hotspot_text=None,
                    temperature_threshold=None, fit=False):
        if magnitude is None:
            self.magnitude_item.clear()
        else:
            mag = np.asarray(magnitude)
            self._shape = mag.shape[:2]
            self.magnitude_item.setLookupTable(None)
            self.magnitude_item.setImage(mag, autoLevels=magnitude_levels is None, levels=magnitude_levels)
        if temperature is None:
            self.temperature_item.clear()
        else:
            temp = np.asarray(temperature)
            self._shape = temp.shape[:2]
            shown = temp if temperature_threshold is None else np.where(temp >= temperature_threshold, temp, np.nan)
            self.temperature_item.setImage(shown, autoLevels=temperature_levels is None, levels=temperature_levels)
            self.temperature_item.setLookupTable(temperature_lut)
            self.temperature_item.setOpacity(max(0.0, min(1.0, opacity)))
        if hotspot is not None:
            self.hotspot.setData([hotspot[0]], [hotspot[1]])
            if hotspot_text:
                self.hotspot_label.setText(hotspot_text)
                self.hotspot_label.setPos(hotspot[0] + 4, hotspot[1] - 4)
                self.hotspot_label.setVisible(True)
        else:
            self.hotspot.setData([]); self.hotspot_label.setVisible(False)
        if fit:
            self.fit_image()
