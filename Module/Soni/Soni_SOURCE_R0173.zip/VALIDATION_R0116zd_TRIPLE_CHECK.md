# R0116zd Final Triple Check

## Pass 1 — data binding / real Export
- Golden Export: `10-00-09_ANx(1).zip`.
- 13 physical CPC Spectrum pairs are present while treatment has 8 Sonications.
- Authoritative binding uses explicit Sonication identity first; when extra early setup/calibration pairs exist, final N physical CPC pairs bind to N treatment Sonications.
- Real Export validation: Sonication1-8 mapped 8/8 and decoded 8/8.
- All eight mapped sources reproduced `EXACT vendor Band0 history` and `EXACT control reproduction`.
- Main Replay summary/RCA/Cavitation/CPC replay and Spectrum Analyzer use the same resolver path rather than independent cardinality assumptions.

## Pass 2 — ancestor / duplicate / stale path audit
- MainWindow duplicate method definitions: 0.
- HydrophoneWindow duplicate method definitions: 0.
- Zero-frame background Spectrum result is not published as Ready.
- Cached preload is accepted only for the requested Sonication.
- Already-loaded Export ZIP is reused by Spectrum Analyzer instead of being extracted again.
- Manual Spectrum decode propagates real internal progress instead of appearing fixed at 55%.
- Registration suppression logic was not weakened in this revision; exported CT/MR registration remains deterministic and geometry-QA protected.

## Pass 3 — package / regression
- `verify_source.py`: PASS.
- `compileall`: PASS.
- Non-GUI regression suite: PASS (PySide6-only circular ROI GUI test excluded because PySide6 is unavailable in this audit environment).
- Build metadata synchronized: version.json / VERSION / build contract / build scripts = R0116zd.
- Source ZIP created from this exact validated tree with caches/build artefacts excluded.
