# R0116zzf — Replay height fit + Thermal frame-1 thumbnail repair

- Treat finite constant treatment-thermal frames as valid baseline images; do not discard Thermal 1 merely because its spatial standard deviation is zero.
- Keep the stricter constant-image rejection for Treatment MR only.
- Make the thumbnail red threshold match the sharp main overlay (`temperature >= threshold`) without alpha-mask blur.
- Add tight/compact/normal Replay-right height profiles driven by the actual splitter viewport.
- Resize thumbnail strips/sliders and chart minimum heights as available vertical space changes.
- Ignore intrinsic vertical size hints for the three Replay-right splitter sections and reserve splitter-handle height before allocating panes.
- Rebalance after maximize/restore/monitor resize via `resizeEvent`.
