# R0116zzw Regression Report

## Automated tests

- Non-GUI pytest suite: **649 passed**
- Known PySide6-dependent `test_r0015_circular_roi_measurement.py` remains excluded in this Linux validation environment because PySide6 is unavailable there.
- `python verify_source.py`: **VERIFY_SOURCE_OK**
- `python -m compileall -q .`: **PASS**

## Dedicated R0116zzw guards

`tests/test_r0116zzw_auto_images_activity_reset.py` verifies:

1. Load images defaults ON without emitting during widget construction.
2. Current-Sonication image stage precedes Spectrum/timing stage.
3. Initial Spectrum preload is deferred until after image request scheduling.
4. First Treatment MR may publish before the complete image cache.
5. Image progress has a dedicated non-modal owner.
6. Activity monitor exposes worker/pending/RSS/cache state.
7. Activity/Reset controls live in the existing scroll panel.
8. Reset/unload routes reuse generation-safe source/selection paths.
9. In-flight package results can be discarded after unload.
10. No duplicate MainWindow methods.

## Static lifecycle audit

- Duplicate class methods: **0**
- Duplicate same-method Signal→slot connections: **0**
- `QApplication.processEvents(`: **0**
- `.wait(`: **0**
- `.terminate(`: **0**

See `R0116zzw_STATIC_AUDIT.json`.
