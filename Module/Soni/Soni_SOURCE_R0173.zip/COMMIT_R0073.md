# R0073 — Direct Sonication Selector

- Added a Sonication drop-down list to the main Replay header.
- Kept previous/next Sonication buttons.
- Direct selection and arrow navigation both use the same authoritative selection path.
- The selector is populated from every Sonication discovered in the loaded Export.
- Replay, Cavitation Intelligence, Sonication Elements, diagnostics and Hydrophone views remain synchronized to the selected Sonication.
