# R0167 — Fix stale CI-linked axis on None replay + add missing Workstation power series

## Part 1: stale/extreme X-axis range on a blank CI-linked panel

### Evidence
Live screenshots of RC7.10-R0166: the MainWindow's "Cavitation Intelligence"
-> "Linked Cavitation Analysis" panel occasionally rendered completely
blank while showing a leftover, nonsensical X-axis range (e.g. -150..100 s,
or -800..600 s in an earlier screenshot) that didn't correspond to the
currently selected Sonication.

### Root cause
`_ci_linked_mode_changed()` (the "Lower display" combo's handler) is
deliberately cheap by design (R0095: "dropdown interaction must stay
instant") -- it only switches the `QStackedWidget` page and never redraws.
Actual redrawing happens inside `_update_ci_linked_panel()`, gated by a
`key` identity check (`id(replay), id(timeline), ...`) so heavy curve
rebuilding only happens when the underlying data actually changes.

`_draw_ci_linked_vendor_energy(replay)` / `_draw_ci_linked_control(replay)`
both start with `plot.clear()` and, when `replay is None` (which happens
whenever `self.default_cpc_replay` is momentarily `None` -- e.g. while a
Sonication switch's background preload is still in flight and this panel
is asked to redraw in the meantime), returned immediately **without
touching the ViewBox's range**. `plot.clear()` only removes plotted
curves; it does not reset the view range. So whatever axis a *previous*,
unrelated draw call had set (a different Sonication's range, or even a
pre-R0166 stale extrapolated range that happened to still be sitting in
the ViewBox from much earlier) stayed visible underneath the now-empty
chart.

### Fix
Both `None`-replay early-exits now call
`plot.enableAutoRange(axis=pg.ViewBox.XAxis/YAxis, enable=True)` before
returning, so an empty chart auto-ranges to something sane (effectively
"nothing to show") instead of keeping a stale, unrelated range.

### Tests
`tests/test_r0167_ci_linked_panel_stale_axis_on_none_replay.py`: static
checks that both `None`-replay branches call `enableAutoRange` on both
axes.

## Part 2: CI-linked control panel was missing the Workstation power series

### Investigation
Compared the MainWindow's `_draw_ci_linked_control` chart against the
Analyzer's own equivalent view (`hydrophone_window.py`'s
`_draw_vendor_cavitation`) for the same Sonication. Confirmed directly:
`vendor_display_rule1` (plotted as "CGA Rule 1 / Band0") is `0.0` for
every one of Sonication1's 698 samples -- this is a real, correctly
computed value (the CGA controller genuinely never intervened), not a
bug. But the Analyzer's chart additionally plots
`_workstation_actual_power_series()` -- the applied-power trace from
`spotsonicationdata.xml`'s PowerGraph, which is a completely different
signal from the Acquisition_Brain ExPowerRatio *controller state* -- and
that series does rise meaningfully. The CI-linked panel had no equivalent
series at all, so it could look flat/near-empty even when the Analyzer's
own chart plainly showed delivered power.

### Fix
`_draw_ci_linked_control()` now additionally calls
`AcousticControlService().power_graph_for_sonication(workspace,
sonication_index)` and plots the result as "Actual power ratio
(Workstation PowerGraph)", mirroring the Analyzer's series exactly
(same source, same `mr_sonication_start_s` offset, same leading-zero-pad
behavior). Failures are logged via `LOG.exception(...)`, not swallowed.

### Verified against the real Brain220 export
```
power_graph_for_sonication(Sonication1): 75 samples, range 5.28-8.80 (%)
```
This matches the "Power ratio (x0.001)" axis reading of roughly 20-80 seen
in the Analyzer's own chart for the same Sonication (the axis label's
"x0.001" scaling means a displayed "80" is the real value 0.080 --
consistent with 8.0%).

### Tests
`tests/test_r0167b_ci_linked_control_workstation_power.py`: static checks
that the new series is added, uses `self.sonication_index`, and that a
lookup failure is logged rather than silently swallowed.

## Verification
Full test sweep: 1109 passed (up from 1107 at the R0166 baseline,
reflecting the 4 new test functions here), same 11 pre-existing/unrelated
failures. `verify_source.py` re-run against the packaged, re-extracted
`Soni_SOURCE_R0167.zip` -> `VERIFY_SOURCE_OK`. No repeat of the R0158
duplicate-tree packaging mistake: exactly one
`insightec_build_contract.json` inside the extracted package.

## Still open
The root *timing* question -- exactly which live-session event sequence
makes `self.default_cpc_replay` transiently `None` while this panel is
asked to redraw -- was not traced further in this session (it is a Qt
event-ordering question that this sandbox, without PySide6, cannot
exercise). Part 1's fix makes the *symptom* (a stale, misleading axis
range) impossible regardless of that timing, which is the practically
important guarantee, but the underlying "why does this panel sometimes
get asked to redraw with no replay yet" question remains unconfirmed.
