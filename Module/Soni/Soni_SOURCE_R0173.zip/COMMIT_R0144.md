# R0144 — Screen-accessibility hardening

## Scope
Eliminate remaining routes where bottom controls can fall below the usable Windows desktop, especially CPC Spectrum / 8CH Hydrophone Analyzer on laptop displays and display scaling.

## Changes
- Added an application-wide `ScreenSafeTopLevelFilter` covering every `QMainWindow` and `QDialog` created by Soni.
- Geometry fitting uses native `frameGeometry()` plus `availableGeometry()`, not client size alone.
- Added a conservative bottom safety reserve to tolerate Windows taskbar/native-frame timing and DPI rounding.
- Re-runs fitting at 0/60/180 ms after show/window-state changes so native frame metrics and late layout hints are accounted for.
- If an existing hard minimum is larger than the current usable screen, only the offending minimum dimension is reduced.
- Spectrum Dump Analyzer main scroll shell now keeps vertical `ScrollBarAsNeeded` as a permanent escape path. No collapsed/detail-toggle path may turn vertical scrolling off.
- Existing compact plot/table budgeting and pinned Replay row remain; scrolling is only a fallback when content still exceeds the viewport.

## Regression intent
This is a geometry/accessibility change only. Spectrum decoding, CPC mapping, cavitation calculations, replay timing and evidence selection are unchanged from R0143.
