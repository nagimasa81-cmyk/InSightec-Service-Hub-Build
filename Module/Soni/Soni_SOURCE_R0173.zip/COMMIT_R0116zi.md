# R0116zi — Spectrum 58% primary-publish deadlock split

- Initial Spectrum publish no longer calls full set_frame(0).
- Added lightweight first-frame publisher: frame controls + Raw + Spectrum + Statistics only.
- Vendor cursors, control replay, band heatmap and Probable Location/cavitation likelihood are deferred.
- Cached preload handoff now exposes 58 -> 64 -> 72 -> 82 -> 90 progress stages.
- Standalone Open ZIP worker publish uses the same lightweight first-frame path.
