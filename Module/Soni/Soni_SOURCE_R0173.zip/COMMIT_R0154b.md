# R0154b — unexplained zero-amplitude channel reporting

- Adds a separate `Unexpected amplitude=0` warning state for channels that have zero ACT and/or measured amplitude without an exported exclusion explanation.
- Explicit INI disabled, disconnected/defect, and SkullHeating OffReason channels are excluded from this warning.
- Keeps the existing `ACT amplitude=0` fact layer unchanged; the new state is diagnostic and does not reclassify a channel as defect.
- Adds a dedicated warning banner, channel list/count, channel filter, selected-channel detail, tooltip detail, and magenta map ring.
- Adds pure service tests to prevent false positives and regression into INI defect semantics.
