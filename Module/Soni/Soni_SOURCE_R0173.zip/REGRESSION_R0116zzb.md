# R0116zzb regression

- Dedicated R0116zzb tests: 6 passed.
- Full non-PySide6 suite: 685 passed.
- Existing PySide6 circular ROI test cannot collect in this Linux environment because PySide6 is unavailable.
- Real-data validation: 4231-2026-08-13-11-17-24, Sonication 2 -> 170 FFT frames; spectrogram 170x256 spanning about 250-748 kHz; Vendor Band0-3 each 170x8; 37 cavitation events.
- This proves the formerly empty Spectrogram/Band Energy tabs had source data; the fault was publish/state binding, not missing payload.
