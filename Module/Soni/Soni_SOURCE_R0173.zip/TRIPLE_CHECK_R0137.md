# R0137 Triple Check

Regression target: real Windows symptom where Power/thermometry display but Summary reports Control evidence unavailable and CI/Analyzer remain on background Spectrum loading.

Key architectural checks:
1. Selected-data worker and dedicated Spectrum preload both publish through one MainWindow adoption function.
2. CPC evidence ingestion is independent of the chart CPC display toggle (default OFF must not disable Spectrum/Cavitation data).
3. Repository cached replay can self-heal CI if a Qt preload callback was missed/discarded.
4. Unavailable Summary evidence is retryable and not frozen in service cache.
5. No Analyzer-local package discovery fallback is restored.

Real-data service-chain validation on 17-00-24_ANx wrapper workspace:
- 8 Sonications discovered.
- 15 CPC Spectrum candidates; 8/8 Exact mappings.
- Sonication 5: 11 decoded FFT frames, acquisition session index 11 (session 12), Exact mapping.
- Sonication 5 canonical status: CAVITATION HALT ×1 · control responses ×2.
- Sonication 5 Power uses the same authoritative acquisition session.

Additional anti-regression finding:
- `ChartState.cpc_enabled` defaults OFF and settings currently force it OFF. In R0136 the selected-data worker would therefore have skipped CPC handoff if it had been used as the fallback owner. R0137 explicitly decouples evidence ingestion from that display toggle.

Validation:
- R0137 + R0136/R0135 + Spectrum/summary/orientation/zoom focused regressions: 54 passed.
- Full non-PySide6 suite: 880 passed, 1 skipped (`pyzipper` unavailable).
- PySide6-only circular ROI collection cannot run in this Linux test environment because PySide6 is not installed.
- `verify_source.py`: PASS.
- Python compile: PASS.
- AST duplicate-method audit on Main/Analyzer/Repository/Summary/Acoustic services: 0 duplicates.
