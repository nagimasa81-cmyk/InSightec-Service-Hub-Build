# R0122 — AES (WinZip AE-x) encrypted ZIP support

## What changed
`ImportService` previously only supported traditional ZipCrypto password
protection (stdlib `zipfile`'s only supported decryption). AES-encrypted
ZIPs (WinZip AES / 7-Zip "AES-256" mode) raised `NotImplementedError` and
stopped with a "cannot decrypt" message.

- Added `ImportService._is_aes_encrypted()`: detects WinZip AE-x entries by
  `compress_type == 99` (the real method + AES key size live in the 0x9901
  extra field per the APPNOTE spec) -- a different signal from the general
  "is this entry encrypted at all" flag-bit check.
- Added `ImportService._extract_aes_password_protected()`, a fully separate
  code path using the optional `pyzipper` package (`pyzipper.AESZipFile`),
  which both decrypts AES and can also read plain ZipCrypto entries -- so a
  mixed archive is handled correctly too. Tries every configured password
  in order (same clean-temp-between-attempts discipline as the existing
  ZipCrypto path), and stops with a clear `PermissionError` if none work.
- If `pyzipper` is not installed, AES archives now fail with an actionable
  message ("... requires the optional 'pyzipper' package ... pip install
  pyzipper ...") instead of the previous generic "cannot decrypt" message.
  Unencrypted and ZipCrypto-protected ZIPs are completely unaffected --
  `pyzipper` is only imported lazily, inside this one AES-specific method.
- Added `pyzipper>=0.3.6,<1` to `requirements.txt`.

## Why this is a separate path, not a rewrite of the existing one
The already-verified ZipCrypto flow (`_extract_password_protected`, tested
against real Info-ZIP-encrypted fixtures in R0120) is untouched. Routing
*only* AE-x-flagged archives through `pyzipper` keeps the AES addition from
being able to regress the already-working, already-tested behavior.

## Tests
`tests/test_r0122_aes_zip_support.py`:
- AES detection is based on `compress_type == 99`
- the seeded default password opens an AES-flagged archive (via a small
  fake `pyzipper` module installed into `sys.modules`, since the real
  package cannot be installed in this environment to verify against)
- wrong/unconfigured password stops cleanly, no leaked temp workspace
- adding the right password afterward opens the same archive
- missing `pyzipper` raises a clear, actionable message
- no configured passwords -> clear error (AES case)
- the AES and ZipCrypto branches are wired as genuinely separate code paths
- `pyzipper` is declared in `requirements.txt`
- `test_real_pyzipper_end_to_end_if_installed`: skipped in this sandbox
  (`pyzipper` unavailable here), but will run for real and encrypt/decrypt
  a genuine AES archive wherever the real package is installed (e.g. once
  CI installs `requirements.txt`).

All prior tests (R0116zzg23 through R0121) re-verified passing. `verify_source.py`
re-run against the packaged, re-extracted `Soni_SOURCE_R0122.zip` ->
`VERIFY_SOURCE_OK` (exit 0).

## Known limitation
Real AES encrypt/decrypt could not be exercised end-to-end in this sandbox
(no network access to install `pyzipper`). `test_real_pyzipper_end_to_end_if_installed`
will do so automatically the first time this suite runs somewhere `pyzipper`
is present -- worth watching that specific test on the first real CI run.
