# R0116zzy Regression

- Approved ruler contract: right-side, vertically centered, transparent background, pale cyan, 1 mm interval ticks only.
- Physical span remains 5 mm and follows pixel spacing / zoom.
- Tick direction: leftward from the right-side spine.
- No numeric labels, `5 mm` label, or `1 mm ticks` helper text.

## Validation
- Related ruler/UI tests: 20 passed.
- Full non-PySide6 regression suite: 662 passed.
- `test_r0015_circular_roi_measurement.py` cannot be collected in this Linux validation environment because PySide6 is unavailable.
- `verify_source.py`: PASS (`VERIFY_SOURCE_OK`).
- `python -m compileall -q .`: PASS.
- Static audit: duplicate methods 0; `QApplication.processEvents(` 0; `.wait(` 0; `.terminate(` 0.
