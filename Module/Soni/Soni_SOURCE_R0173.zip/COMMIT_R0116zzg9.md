# R0116zzg9 — Analyzer materialization / replay-identity cache repair

Deep root cause repair for Analyzer tabs that remained empty until Replay navigation, with Spectrogram/Band Energy permanently empty.

- SpectrumEvidenceRepository secondary cache is now replay-identity aware. A derived payload from an older replay object can no longer be returned under the same Sonication/channel key and then silently rejected by the UI.
- Loaded-Export Analyzer now always prefers the authoritative study repository replay over its local preload cache, so Summary/CI/Analyzer cannot diverge onto different replay objects.
- Analyzer tab activation is self-healing: primary tabs redraw immediately; secondary tabs publish a valid cache or queue the single shared secondary worker.
- First primary publication materializes the visible tab without requiring Replay cursor movement.
- Spectrogram/Band Energy use a robust one-time-per-frame display time axis with MR-time preference and safe acquisition-time fallback.
- Spectrogram auto-fits the actual decoded frequency axis when a remembered frequency range has no overlap instead of displaying a silent blank chart.
- Band Energy plots clamp x/y lengths before pyqtgraph binding so partial time metadata cannot blank the whole tab.
