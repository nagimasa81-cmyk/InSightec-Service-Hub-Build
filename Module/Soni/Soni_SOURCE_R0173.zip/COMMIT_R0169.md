# R0169 — Merge R0168 linked-CI fixes with on-demand replay recovery

## Combined fixes
- Retains R0168 Sonication-scoped linked-CI X axis (MR acquisition start -> Sonication end).
- Retains R0168 payload fingerprint so repository secondary-product readiness can invalidate an earlier blank paint on the same replay object.
- Retains R0168 authoritative Spectrum handoff invalidation of the linked-CI paint cache.
- Retains R0168 per-source-frame thermometry diagnostics; no value fitting or Sonication-specific temperature correction.
- Adds the alternate R0168 on-demand recovery wiring: opening Cavitation Intelligence calls `_prepare_cavitation_on_demand()`, and per-frame CI updates retry it only while `default_cpc_replay` is still None.
- The recovery path remains single-owner: `_start_spectrum_preload()` rejects in-flight/completed study duplicates.

## Why both are needed
The on-demand wiring fixes a missed adoption/start path. The readiness fingerprint fixes the different case where a replay object was already adopted but secondary products became ready later. Either fix alone can still leave a blank Main linked panel in one of those states.
