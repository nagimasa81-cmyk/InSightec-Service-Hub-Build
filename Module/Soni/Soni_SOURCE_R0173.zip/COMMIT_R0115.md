# R0115

- RCV disable criterion is calibration.ini `[SPECTRUM] IsEnabled`.
- `IsEnabled=0` receivers are hidden by default in hydrophone/spectrum/cavitation views.
- Compact `Show disabled RCV` control opts them back in.
- CavitationSafetyAndControl.ini is not used to decide whether a receiver channel is disabled.
- Keeps R0115 thumbnail image-index slider, Registration QA-warning overlay retention, and 3-D focus/camera linkage.
