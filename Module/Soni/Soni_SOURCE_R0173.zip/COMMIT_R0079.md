# R0079 — Phase / Replay View / Registration QA

- Sonication Elements phase display split into Sonication Phase (1024 reconstructed), Logical Phase (observed log), and Channel Calibration Phase.
- Reconstructed phase uses SkullMeasures Total Phase Shift for all available transmit channels, with a common circular phase anchor from observed Logical Phase channels when present.
- Phase Dedicated defaults to reconstructed Sonication Phase instead of ChannelMeasure residual phase.
- Planning/Registration ViewBox state is stored separately from live Anatomy/Thermal Replay view state; returning to Thermal no longer inherits planning zoom/pan.
- Registration candidate selection now combines MR edge agreement with an outer-skull/head-envelope residual, preventing an inward skull contour from winning simply because it overlaps strong intracranial edges.
- R0078 conservative standalone Windows build strategy is preserved.
