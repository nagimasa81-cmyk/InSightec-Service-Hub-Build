# R0116zzg16 — Spectrum pre-irradiation MR-timeline navigation

- Carries forward all R0116zzg15 functionality.
- Spectrum tab now explicitly exposes decoded CPC FFT snapshots from the full MR acquisition timeline, including MR-start to pre-irradiation frames.
- Adds MR start, Last pre-irradiation, and Irradiation start navigation controls.
- Spectrum titles and the shared frame label show canonical MR acquisition time and phase (Pre-irradiation / Irradiation / Post-irradiation).
- No data are re-decoded or synthetically generated; controls navigate already decoded CPC frames using `mr_frame_times_s`.
