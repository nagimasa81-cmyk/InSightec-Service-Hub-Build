# R0171 — Per-frame thermometry semantic binding

- Field-prefix discovery remains a candidate step only.
- Every candidate thermal RAW is now exact-bound to MriImageParams by field/sonication/zone/array index before its pixels are accepted into the temperature trend.
- Named non-thermometry or unbound frames fail closed when exact MriImageParams metadata exists.
- Import Diagnostics records per-frame Series Description, Series UID, echo number/time, scan time and projected treatment ROI geometry.
- No coefficient fitting, clipping or cross-Sonication temperature normalization is performed.
