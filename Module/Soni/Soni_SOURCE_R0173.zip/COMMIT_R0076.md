# R0076 — SpectrumDumps progress, phase phasor, probable-location replay speed

- Added visible staged processing progress for SpectrumDumps decode/replay/chart/cavitation work.
- Added 0.25x/0.5x/1x/2x/4x/8x replay speed control directly on Probable Location.
- Reworked Phase dedicated view to a physical phasor projection: angle from wrapped relative phase, radius from normalized amplitude, red positive / blue negative phase.
- Phase summary reports 1024 measured-phase coverage and phase span so calibration-residual data is not confused with full logical sonication phase.
- Exact proprietary workstation calibration arcs are not fabricated when the required full phase-scan dataset is absent.
