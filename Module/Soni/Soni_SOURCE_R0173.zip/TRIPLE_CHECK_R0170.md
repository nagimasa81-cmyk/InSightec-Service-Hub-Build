# R0170 triple check

Diagnostics 2026-09-04 03:30:13:
- S1-S4 SpectrumMsg: 75 frames covering about 20 s Sonication-relative; Sonication start is 7.6 s and end about 27.65 s.
- S6-S7 SpectrumMsg: 192 frames covering about 49.77 s; Sonication end about 50.0 s.
- Physical CPC has only 18 FFT frames per Sonication and saved measurement history is shorter. It must not be extrapolated or relabelled as full 8CH coverage.
- S1 thermometry remains genuinely high in decoded thermal RAW: coherent 3x3 peak 67.07 C; the source-frame audit shows a sustained high region, not merely three isolated hot pixels. No value-fitting correction was applied.

Checks:
- compileall PASS
- verify_source.py VERIFY_SOURCE_OK
- focused R0154aj/R0160/R0164/R0166/R0168/R0169/R0170 regression set PASS
