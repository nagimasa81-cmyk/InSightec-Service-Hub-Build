# R0036

Focus: visualization-first cavitation control analysis.

Implemented:
- Acquisition_Brain parsing for observed Increase / Decrease / Safety events.
- Event-chain visualization: observed power timeline + event markers.
- Event detail table with dominant hydrophone and weighted contributors.
- Preserved SpectrumDumps-only candidate mode and combined it with observed evidence when logs exist.
