# R0116zzr — essential-first image loading + non-blocking Sonication Summary

- Initial `Load images` blocking phase now decodes only the current Sonication's Treatment MR and Thermal frames.
- Reference/Planning series are excluded from the initial workload and decoded only when selected; the progress denominator matches the actual essential workload.
- Hidden planning thumbnail strips are not materialized during the blocking phase; visible strips are built incrementally in small GUI batches.
- Sonication Summary seeds cheap exported values immediately.
- Summary detail no longer decodes CPC FFT, MR metadata, or thermometry RAW per Sonication. It uses Acquisition_Brain control evidence plus already-cached temperature values when available.
- Acquisition_Brain text is cached by file mtime/size so all Sonication session lookups do not reread the same large log from disk.
- Legacy regression requiring Summary thermometry RAW decode was updated to the new cache-only non-blocking contract.
