# R0169 Triple Check

1. Main linked axis remains Sonication-scoped.
2. Linked-CI cache key includes secondary-product readiness, not replay identity alone.
3. Cavitation tab and None-replay frame updates route through `_prepare_cavitation_on_demand()`.
4. Spectrum preload remains one study-owned worker and refuses completed/in-flight duplicate starts.
5. R0168 thermometry source-frame diagnostics remain present.
6. Brain220/650 parser, session selection, non-extrapolated history time mapping, workstation actual-power overlay and prior cursor guards remain unchanged.
