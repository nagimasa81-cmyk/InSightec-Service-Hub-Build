# R0109 — Phase-Derived Electronic Steering Focus

- Physical 1024-channel element coordinates remain fixed from SkullMeasures Element X/Y/Z.
- Sonication phase never changes element position.
- Estimates the geometric focus from a robust sphere fit to the physical transducer bowl.
- Uses 1024-channel Sonication Phase + ACT commanded amplitude + actual frequency to search
  for the maximum homogeneous-medium phase coherence near the geometric focus.
- Excludes ACT amplitude=0, INI disabled, and INI defect/disconnected channels.
- Evaluates both propagation phase-sign conventions.
- If an unambiguous exported SpotValidation X/Y/Z steering vector exists, it is used only
  to select the phase convention and to report consistency; it never forces the answer.
- Phase dedicated X-Z view overlays:
  - cyan cross = geometric focus
  - red dot = phase-derived focus
  - red line = derived steering vector
- Displays ΔX / ΔY / ΔZ / |Δr|, coherence, sign convention, optional exported request/error.
- Important limitation is visible in the UI:
  Sonication phase can contain both electronic steering and skull-aberration correction.
  Therefore this estimate is not labeled as pure steering without corroborating export data.


## Actual export validation: 10-00-09_ANx(1).zip / Sonication1
- Wrapped Total Phase Shift matches ACT phase: circular concentration 0.999999957.
- Total Phase Shift is treated as unwrapped radians, not degrees.
- Steering residual RMS = 0.000475 rad.
- SkullMeasures FocalPointPos = (-16.464, -4.98388, -117.305).
- Geometry-fitted natural focus = (-16.176518004058746, -5.38875376612495, -117.12167415084429).
- Focal minus natural focus = (-0.2874819959412527, 0.4048737661249495, -0.1833258491557217) mm.
- This Sonication is consistent with essentially no electronic steering; applied phase is dominated by skull correction.
