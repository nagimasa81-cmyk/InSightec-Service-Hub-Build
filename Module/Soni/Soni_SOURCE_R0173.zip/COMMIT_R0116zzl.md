# R0116zzl — Responsive Image Loading / No-GUI-I/O Hardening

## Fixes
- Load images now opens a visible modal progress dialog and builds image caches in background workers.
- Replay frame navigation reuses cached Treatment MR/Thermal arrays and forbids synchronous disk fallback on the GUI thread.
- Thermal thumbnails update one item in place; the old repeated full-strip rebuild was removed.
- Thumbnail updates use O(1) item lookup instead of scanning hundreds/thousands of items for each decoded frame.
- `_first_valid_replay_frame()` no longer probes RAW images synchronously.
- MR signal-loss and MR/cavitation correlation consume the Treatment MR cache instead of rereading RAW files on every Replay interaction.
- Cavitation trend computation is cached per Sonication/channel configuration.

## Real export validation
- 4231-2026-08-13-11-17-24(1).zip: 3084 ZIP entries, 1589 RAW files.
- Discovery: 13 Sonications, 2308 planning assets.
- Planning CT: 1175 assets; Planning/Preplanning MR exceeds 1000 assets.
- Cache-only ReplayService frame verified with filesystem image reads deliberately disabled.

## Regression
- New anti-freeze tests: 6/6 PASS.
- R0116 tests: 268/268 PASS.
- Full non-PySide6 suite after updating obsolete sync-decode/rebuild expectations: 574/574 PASS.
