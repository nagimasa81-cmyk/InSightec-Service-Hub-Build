# R0166 — Fix: Vendor/Raw-history timelines stretched to ~130-400s

## Evidence
User supplied 5 live screenshots of RC7.10-R0165 against the real
7-Sonication Brain220 export. Every "CGA Cavitation / Vendor Rules" and
"Measurement Timeline / Raw A/D" chart showed the Vendor/history curves
extending far past the "Time axis: ... -> Sonication end" value stated at
the top of the window:

| Sonication | stated Sonication end | actual visible chart extent |
|---|---|---|
| 5 | 10.617 s | ~130 s |
| 6 | 50.079 s | ~400 s |
| 2 | 27.638 s | ~350 s |

The "Cavitation Intelligence" tab's "Vendor band energy reproduction"
panel (screenshot 5) was, separately, still completely blank for
Sonication2.

## Root cause
`CpcHydrophoneReplay.mr_raw_timeline_time_s` passed `np.arange(1, n+1)` --
plain 1-based sample *indices* into the 10-ms measurement history -- into
`_cycles_to_mr()` as if they were real absolute CPC controller cycle
numbers. `raw_timeline_time_s` itself (`np.arange(len(timeline[0])) *
acquisition_interval_s`) carries no real per-sample cycle number at all.
Confirmed directly: `frame_times_s` (the physical FFT frames' own domain)
spans only ~0.17 s on a composite 220 kHz Sonication (18 frames, limited
by the CPC's ~15 s dump-rollover cadence -- see COMMIT_R0156.md), while
`sonication_frame_times_s` (its real, wall-clock-anchored MR-time
counterpart) spans ~9 s. Fitting a line across that tiny domain and
extrapolating it across the ~7 s / ~700-sample history array amplified the
slope by ~53x, stretching the mapped range out to ~380 s -- this study's
overall multi-Sonication session span, not this Sonication's own duration.

A second, related issue in `_acquisition_times_to_sonication()` (used by
`sonication_raw_timeline_time_s`) had the same underlying problem: its
`np.polyfit` line, learned over the FFT frames' own tiny domain, was
applied without any bound to a much larger input range.

## Fix
1. `mr_raw_timeline_time_s` no longer attempts the index-as-cycle-number
   mapping at all; it always uses the interval-based, Sonication-relative
   fallback (`sonication_raw_timeline_time_s + mr_sonication_start_s`).
2. `_acquisition_times_to_sonication()` now guards the polyfit-derived
   mapping against extrapolation: it is only trusted when the values being
   mapped span no more than 5x the domain the fit was actually learned
   over (or 1.0 s, whichever is larger); otherwise it falls back to a
   plain offset (no invented scale) rather than fabricate an amplified
   time base.

## Verified against the real 7-Sonication Brain220 export
| Sonication | raw-timeline range (before) | raw-timeline range (after) | Sonication end |
|---|---|---|---|
| 1 | 9.41 - 380.39 s | 9.07 - 16.04 s | 29.15 s |
| 2 | 10.44 - 383.52 s | 10.10 - 17.09 s | 30.14 s |
| 5 | 10.04 - 136.64 s | 10.05 - 17.04 s | 13.07 s |
| 6 | 4.83 - 377.96 s | 4.49 - 11.48 s | 54.57 s |

Every Sonication's Vendor/Raw-history timeline now starts at its own
Sonication start and covers a physically reasonable ~7 s window (matching
the ~700-sample, 10-ms-interval history array), instead of stretching into
the hundreds of seconds.

## Tests
`tests/test_r0166_raw_timeline_extrapolation_fix.py`:
- `mr_raw_timeline_time_s` no longer calls `_cycles_to_mr` or constructs
  the `np.arange(1, n+1)` index-as-cycle-number sequence.
- `_acquisition_times_to_sonication` contains the span-bounded
  extrapolation guard and still reaches the plain-offset fallback.

`tests/test_r0154_cpc_wallclock_cycle_mapping.py` (updated): the previous
`test_replay_fft_and_history_use_exact_cycle_wallclock_mapping` test
specifically validated the now-removed index-as-cycle-number mechanism by
construction (a synthetic case where history sample indices 1..5
happened to coincide with real absolute cycle numbers 1..5) -- exactly
the coincidence this fix proves does not hold in general. Replaced with
`test_replay_history_uses_fft_frame_anchored_fit_not_index_as_cycle_number`
(validates the corrected, FFT-frame-anchored fit's exact output) and
`test_extrapolation_guard_falls_back_to_plain_offset_when_domains_mismatch`
(directly reproduces the real amplification scenario and asserts the
guard now prevents it).

Full test sweep re-run: 1107 passed (up from 1102 at the R0164/R0165
baseline, reflecting the 5 new/updated test functions here), the same 11
pre-existing, unrelated failures remain. `verify_source.py` re-run against
the packaged, re-extracted `Soni_SOURCE_R0166.zip` -> `VERIFY_SOURCE_OK`.
No repeat of the R0158 duplicate-tree packaging mistake: exactly one
`insightec_build_contract.json` inside the extracted package.

## Still open
The blank "Vendor band energy reproduction" panel for Sonication2 in the
Cavitation Intelligence tab (screenshot 5) was not reproduced or diagnosed
in this session -- it may be related to this same fix (worth re-checking
against a rebuilt executable) or may be a separate, live-session-only
issue (e.g. preload timing) that this sandbox cannot exercise without
PySide6.
