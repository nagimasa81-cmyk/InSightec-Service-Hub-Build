# R0100 — Registration Coordinate Chain Trace

- Adds exact diagnostic tracing using the same coordinate convention as the world-reslice path:
  CT skull voxel -> CT RAS -> exported CtMr / inv(MrMr)×CtMr -> MR RAS -> displayed MR pixel.
- Representative skull point is selected deterministically from the native vendor skull mask.
- Registration is never automatically optimized or visually re-aligned.
- Gross mismatch status now distinguishes:
  - transformed skull point outside displayed MR,
  - transformed skull inside frame but mostly outside MR head,
  - outer-shell geometry disagreement.
- Adds a visible `Registration Trace` button beside Registration to inspect the full diagnostic status.
