# R0154aa — Brain220 deep ownership / DQA fail-closed hardening

## Purpose
R0154aa is a code-structure hardening release after repeated Brain220 regressions.
It does not accept a visually plausible value unless the data path proves the
quantity being displayed.

## DQA focus-alignment contract
Production numeric displacement now has exactly one allowed definition:

    observed focus - planned focus of the same Sonication

The following are forbidden as numeric zero-points:
- phantom centre
- image centre
- planned focalRAS by itself
- another Sonication's focus
- electronic-steering amount
- target-voxel coordinates

Legacy hotspot-minus-phantom implementations remain only as non-numeric
compatibility shims. Their arithmetic has been removed from the source so an old
caller cannot silently resurrect the former values.

Brain220 field-5 float32 RAW is additionally required to pass the same
thermometry-distribution sanity contract used by replay. T2*/phase-like rasters
with values in the thousands are rejected as thermometry. This specifically
prevents the false R0154z S5 result that came from treating T2* as a heat map.

If observed focus cannot be proven, the result is N/A. This is intentional and
is preferable to the former false X/Y/Z values.

## Brain220 Spectrum ownership
A loaded Sonication is dual-source:
- Sonication-owned SpectrumMsg: spectral FFT/Spectrogram stream
- exact-mapped physical CPC: 8CH history, vendor Band energy, CGA/control/event evidence

All package-backed source-worker branches merge `package.cpc_spectrum_files` and
each Sonication's `spectrum_files`, preventing a late asynchronous callback from
restoring a CPC-only candidate universe.

## Band contracts
The historical R0130 fixed Band0 0.311–0.411 MHz is limited to the 650-family
(or the historical unknown-frequency default). Brain220/230 keeps vendor INI
band definitions and is not overwritten by the 650-family contract.

## 1024-channel phase
ACT explicit phase fills only missing phase channels and never overwrites a
phase already recovered from stronger evidence. The real 42110 fixture recovers
1024/1024 phase channels for Sonications 1–7.

## Validation
- non-GUI pytest: 1043 passed, 1 skipped (pyzipper unavailable)
- GUI-only collection not run in this Linux environment because PySide6 is absent
- source verification: PASS
- Python compile: PASS
- duplicate class/function definitions in src/: 0
- real 42110 audit written to VALIDATION_R0154aa_REAL_42110.json
