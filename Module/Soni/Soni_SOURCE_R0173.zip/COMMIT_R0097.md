# R0097
- Fixed blank probable-region MR image by using actual `current_image` and normalized centroid fields.
- Added current Treatment MR fallback before MR-correlation baseline is available.
- Added explicit Sonication Summary inside Cavitation Intelligence.
- Removed obsolete Show images checkbox.
- Added Spectrum Dump Analyzer Legend `All ON` / `All Clear` with one redraw per batch.
