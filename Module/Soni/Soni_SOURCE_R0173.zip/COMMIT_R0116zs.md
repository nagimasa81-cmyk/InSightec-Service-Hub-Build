# R0116zs — Spectrum Data-Extent Fit / Stable Analyzer Geometry

- Measurement Timeline negative time is retained only when CPC/Acquisition payload truly exists before MR time zero.
- Every Spectrum Dump Analyzer tab now fits to the finite X extent of its plotted payload instead of forcing the MR acquisition duration.
- Empty pre/post-data regions are not displayed by default.
- Analyzer content is hosted inside a scroll shell so child minimum-size hints cannot enlarge the top-level window.
- Opening is clamped to the available desktop and subsequent tab/visibility changes preserve top-level geometry.
- Vendor left/right axis widths are reserved so checkbox/list toggles do not resize the plot area.
- Sonication source popup width is capped for laptop displays.
