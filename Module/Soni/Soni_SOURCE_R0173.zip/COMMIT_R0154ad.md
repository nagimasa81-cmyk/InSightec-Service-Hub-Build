# R0154ad

- Corrects Umbrella vertical orientation by removing the second Z inversion from named and perspective projections.
- Establishes one screen-axis inversion only: native transducer +Z is mapped upward on screen by `_umbrella_project`.
- Deepens DQA thermometry evidence binding: a Field-5 filename/float32 payload is no longer sufficient.
- Each DQA temperature candidate must bind to its exact `MriImageParams` row and pass protocol/value-distribution validation.
- Explicit T2*/NFUSCAL series are rejected as non-thermometry even if the payload shape matches float32 temperature maps.
- Keeps the R0154ac series-common DQA contract: X/Y from Axial, Z from Sagittal, Tilt from Sagittal phantom baseline.
