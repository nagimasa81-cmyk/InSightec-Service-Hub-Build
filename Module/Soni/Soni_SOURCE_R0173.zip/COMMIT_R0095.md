# R0095

## Cavitation Intelligence
- Removed permanent side-by-side upper RCV + MR image layout.
- One image viewport with dropdown:
  - Treatment MR · integrated cavitation location (default)
  - RCV contribution → probable cavitation region
- Removed duplicated RCV page from the linked lower display.
- Linked lower dropdown now contains only:
  - Vendor band energy reproduction
  - Cavitation control response + CGA / Acquisition Display Rule
- Dropdown switching is display-only and no longer rebuilds plots/tables.
- Vendor/CGA plots and event rows are cached by underlying replay/timeline identity.
- Event timing marker remains persistent and visible.

## Spectrum Dump Analyzer
- Why popup control moved to the always-visible top row.
- Default remains OFF.
- ON state explicitly shows “click an event point”.
- Event time can be resolved from timestamp_s or acquisition cycle.
- Click hit tolerance increased from 100 ms to at least 350 ms.
- Vendor and control chart clicks use the same robust event-time resolver.
