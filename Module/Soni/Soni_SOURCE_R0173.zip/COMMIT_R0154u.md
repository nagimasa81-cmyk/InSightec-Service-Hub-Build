# R0154u — strict build identity + DQA same-raster authority

- DQA numeric alignment now prefers same-raster thermal-hotspot to phantom-landmark geometry before any cross-stack absolute RAS path.
- The 3-D thermal/reference RAS path is no longer returned unconditionally; non-local values are rejected and cannot become a focus-offset alarm.
- Version/build identity is RC7.10-R0154u throughout the SOURCE package.
- Use the dedicated no-cache Soni workflow for first validation to eliminate mixed q/s/t cache artifacts.
