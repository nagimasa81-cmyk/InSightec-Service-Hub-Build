# R0116l

## Thermometry numeric path separated from image UI
- Sonication Summary temperature no longer depends on `Load images`.
- Added `ReplayService.temperature_metrics()` that reads only temperature RAW frames.
- It does not read magnitude data, build thumbnails, run registration, or create UI image objects.
- Start / Peak / ΔT are cached and reused by Cavitation Intelligence/RCA.

## Why popup event-to-graph linkage
- Popup title identifies event family/rule and exact session time.
- Popup text includes selected time/cycle and an explicit threshold comparison.
- Selecting an event draws a red vertical cursor on related graphs.
- The exact Acquisition_Brain weighted-energy value is drawn as a large highlighted point on the upper vendor-energy graph.
- The selected rule threshold is drawn as a red dotted horizontal line.
- Popup explains that continuous curves can be a different receiver/band/rule weighting than the sparse exact log event.

## Important interpretation
For a Decrease event, the trigger condition is `Calculated Energy > Calculated Top Energy limit`.
The highlighted exact log point is therefore the authoritative event-value/threshold comparison even when a continuously plotted diagnostic series does not visibly cross that rule's threshold.
