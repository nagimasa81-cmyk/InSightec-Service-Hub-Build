# R0116zr — Replay Right Pane Compact / Linked Time Axis

- Power % / Score X axis is linked to Temperature Trend and always uses the same full Replay-time viewport.
- Progressive replay clips curve data only; it no longer changes the Power/Score horizontal range.
- Registration, Registration Trace, and Load images are stacked vertically to save thumbnail width.
- Right-side Images, Temperature/Spectrum, and Power/Score/Cavitation blocks are independently collapsible.
- Individual chart panels also support collapse/show while preserving enlarged-chart access.
