# R0157 — Fix: _probable_reference_image() domain mismatch for composite Sonications

## Context
Continuing the audit of `self.replay.frames` references flagged as "needs
a closer look" in `COMMIT_R0156.md`. `_probable_reference_image()` (finds
the Treatment MR image nearest the strongest/selected cavitation evidence)
picks `target_frame` from up to three different sources, each indexed
against a *different* replay:

1. Default: `self.frame_index` -- a cursor/composite-domain index
   (`_cursor_frame_count()` prefers `_spectral_replay()`, per R0156).
2. "Observed cavitation event" branch: `_frame_by_cycle(self.replay, ...)`
   -- this explicitly scans `self.replay.frames` (physical CPC), so it
   returns a **physical**-domain index.
3. "cavitation_analysis.events" branch: `snapshot_index` is indexed against
   `analysis_replay = spectral or replay` inside
   `SpectrumEvidenceRepository` ("cavitation spectral evidence must follow
   the full SpectrumMsg stream" for a composite Brain220 replay) -- i.e.
   the **spectral/aggregate**-domain, same as case 1.

The old code always looked up `self.replay.mr_frame_times_s` (physical)
regardless of which domain `target_frame` actually came from, and the
ratio-based fallback denominator was always `len(self.replay.frames)-1`
(physical) too.

## Bug found
On a 220/230 kHz composite Sonication, case 3 (a cavitation event, which
can legitimately occur anywhere across the *full* Sonication) produces a
`target_frame` in the spectral domain (e.g. up to 74 for a 75-frame
spectral replay), but got looked up against the physical replay's much
shorter `mr_frame_times_s` (e.g. size 18). Any event past index 17 missed
the `0 <= target_frame < times.size` check entirely and fell into the
ratio-based fallback, which -- still dividing by the physical frame count
-- produced a wildly out-of-range index instead of a usable one (see
verification below: index 349 instead of ~25 in a size-100 MR image
sequence).

## Fix
Track which replay `target_frame` is actually indexed against
(`target_domain_replay`), defaulting to `self._spectral_replay()` and
switching to `self.replay` only in the one branch (`_frame_by_cycle`) that
genuinely produces a physical-domain index. Both the `times` lookup and the
fallback denominator now use `target_domain_replay` consistently.

## Verified
Simulated the exact failure shape (a cavitation event at spectral index 60,
spectral replay covering the full Sonication, physical replay only 18
frames):
- Old code: fell through to the fallback, produced index **349.4** (nonsense).
- New code: correctly resolved via `times[60]` to **25.26 s** into a real
  spectral timeline covering 9.08-29.04 s.

## Tests
`tests/test_r0157_probable_reference_image_domain_fix.py`:
- static check that `target_domain_replay` is set to the spectral/
  aggregate replay by default and to `self.replay` only inside the
  `_frame_by_cycle` branch.
- static check that both the `times` lookup and the fallback denominator
  use `target_domain_replay`, and the old domain-blind lookups are gone.

Existing `tests/test_r0156_last_frame_navigation_uses_composite_count.py`
re-verified passing (this change does not touch the navigation sites fixed
there). `verify_source.py`: VERIFY_SOURCE_OK.
