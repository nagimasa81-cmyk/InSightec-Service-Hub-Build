# R0026 — Loaded Export Spectrum Selection

## Goal
Keep the standalone Spectrum Dump Analyzer input flow unchanged before any treatment/export is loaded, while eliminating duplicate ZIP/folder browsing after Sonication Analysis already has an Export open.

## Implemented
- `Spectrum Dump Analyzer` now detects the current Sonication Analysis package/workspace.
- When launched after an Export ZIP/folder is loaded, it scans the **already extracted workspace** recursively.
- If multiple logical Spectrum measurements exist, `Select Spectrum dump from loaded Export` is shown before rendering.
- `Spectrum_*.dmp` + matching `_FFT` companions remain paired as one candidate.
- A single candidate opens directly.
- `SpectrumMsg*.dmp` remains a separate family and is not fabricated into physical CPC 8CH data.
- Added `Select From Loaded Export` inside the analyzer so the user can return to the loaded Export after opening another Spectrum source.
- The loaded treatment workspace is referenced only; Spectrum Dump Analyzer does **not** extract or own/delete it.
- Before any treatment/export is loaded, the existing `Open Export ZIP`, `Open Folder`, `Open Spectrum File`, and drag/drop workflow remains unchanged.
