# Full Async Lifecycle Audit — R0116zzv

## Audit scope
The review covered loading, switching, reloading and UI publication paths for:
- Treatment MR / Thermal images
- Planning / Reference images and registration
- Sonication selection and repeated Sonication changes
- Export ZIP/folder/source changes
- CPC/Spectrum preload, Analyzer discovery and decode
- Spectrum secondary products
- Temperature/replay-derived data
- Sonication Summary and deferred analysis panels
- Engineering / Export / Sonication Elements views
- charts, lists and table refresh paths
- QThread/QTimer ownership, cancellation, stale callbacks and cache-only UI paths
- duplicate methods and duplicate Signal connection patterns

## Failure patterns explicitly audited
1. old worker still running when a new request starts
2. two UI entry points launching the same heavy task
3. stale worker callback overwriting the new Sonication/source
4. heavy RAW/FFT/file work returning to the GUI thread through a fallback
5. hidden UI widgets performing expensive population
6. nested event-loop pumping re-entering signals during progress updates
7. worker ownership references being dropped before the thread actually exits
8. cache miss causing synchronous disk decode

## R0116zzv final hardening
### Spectrum secondary analysis
The previous deferred `QTimer.singleShot` chain still executed spectrogram/Band/cavitation calculations on the GUI event loop. R0116zzv moves those calculations to `SpectrumSecondaryWorker`. GUI methods consume the precomputed cache and only publish Qt/pyqtgraph objects.

### Spectrum secondary lifecycle
Only one secondary worker is active. A newer request becomes the single pending latest request. Old results are rejected using both request id and replay identity. Thread teardown remains asynchronous; the GUI never waits.

### 1024-element table
When hidden, the table contains zero rows/items. When shown, rows are created in bounded 96-row event-loop batches. Each batch carries a generation token, so hiding the table or selecting a newer snapshot invalidates unfinished batches.

### Nested event loops
All production `QApplication.processEvents()` calls were removed. Progress dialogs now update normally through Qt's event loop while background workers continue independently.

## Final static result
No duplicate class/method definitions, exact duplicate connection statements, `processEvents()`, thread waits or forced thread termination calls were found in `src/`.
