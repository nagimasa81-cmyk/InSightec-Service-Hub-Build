# R0048

- 100 ms smoothing: default ON.
- Main Sonication Replay: default 1× Actual timing, user-selectable speed multiplier.
- Clarified receiver naming policy: internal zero-based channel indices remain implementation details; user UI uses RCV0–RCV7.
