# Auto Image / Background Activity / Reset Design — R0116zzw

## Startup sequence

1. Build/show UI.
2. Open/discover package in PackageLoadWorker.
3. Adopt package and select current Sonication.
4. Because Load images defaults ON, queue current-Sonication essential image load through the existing single-owner path.
5. Treatment MR is decoded before Thermal; the first Treatment MR can be painted immediately.
6. Remaining image cache + thumbnails continue in background.
7. SpectrumDumps preload starts automatically after a short delay; Reference/Planning stay lazy.

The checkbox is set ON before its `toggled` signal is connected, preventing startup I/O during UI construction.

## Background Activity window

The Activity button opens a live diagnostic window refreshed every 750 ms. It reports:

- running QThreads discovered from MainWindow and Spectrum Dump Analyzer ownership,
- queued/pending work,
- essential image progress,
- Spectrum preload progress/message,
- current Sonication,
- process resident working set (RSS),
- estimated memory held by major in-process caches containing NumPy arrays/byte buffers.

No new `psutil` dependency is required. On Windows RSS uses `GetProcessMemoryInfo`; non-Windows validation uses `/proc/self/statm` when present.

## Reset semantics

### Restore previous view

Restores the previous same-study checkpoint: Sonication, Replay frame, main image mode, image-load state, temperature display/range, threshold, opacity and Registration state when available. A different study workspace is never restored accidentally.

### Reset current study view

Restores the view state captured immediately after the current package's first Sonication is selected, without re-importing the source.

### Unload study (before file load)

Returns to a no-study state, retires study workers using existing non-blocking generation-safe paths, releases the extracted workspace/cache, and discards an in-flight package result if one finishes after the reset.
