# R0078 Windows Defender build notes

R0078 intentionally uses a normal Nuitka **standalone directory** rather than `--onefile`.

## Distribution
GitHub Actions produces `Sonication_R0078_Windows_Standalone.zip`. Extract the entire ZIP before running. Do not copy only the EXE out of the folder; the DLLs and Qt runtime beside it are required.

## Security
This build does not change or weaken Windows Defender settings. If Defender still reports a threat, record the threat name/path through your IT/security team and do not add an exclusion merely to make the program run.

## Why standalone
Onefile executables unpack a large embedded payload at runtime. That behavior can attract heuristic antivirus detections. Standalone avoids that self-extraction path and makes individual runtime files visible for security scanning. This reduces one class of false-positive trigger but is not a guarantee against antivirus detection.
