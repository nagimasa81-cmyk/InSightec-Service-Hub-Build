# R0129 Triple Check

## Check 1 — FFT/Band0 range selection
- Direct mouse drag path remains active only while the selection toggle is checked.
- Range preset drop-down is restored.
- R0128 defect found: choosing a non-mouse preset created `_raw_fft_region_values`, but `_update_raw_fft_controls()` still required the mouse-selection toggle to be checked, so the Run button could remain disabled.
- R0129 automatically activates the selection overlay for non-mouse presets and treats a preset-defined region as a valid selection state.
- Clear Range returns to Mouse drag and restores the normal cursor.
- Raw A/D remains preferred; validated CPC history remains the fallback for temporal FFT + Band0 statistics.

## Check 2 — Control Timeline first-open layout / bottom access
- Plot and event table remain inside one vertical `QSplitter`.
- R0128 generic delayed refit could still miss the first nested-tab native layout because the splitter could already report a non-zero but stale size.
- R0129 adds a dedicated nested Control Timeline first-visible settle using `cavitation_visual_tabs.contentsRect().height()`.
- Splitter ratio is seeded once after the nested viewport is valid, then user-adjusted splitter sizes are preserved.
- Splitter children remain non-collapsible and handle width is explicit.
- Replay/navigation controls remain pinned outside the Analyzer scroll shell.

## Check 3 — Regression / build identity
- Targeted R0124-R0129 interaction, CPC-history FFT/Band0, and Band0-time-alignment tests: 24 PASS.
- `tools/verify_source.py`: PASS.
- Python compileall: PASS.
- Full non-GUI suite (excluding PySide6-only GUI collection test): 833 PASS, 8 FAIL, 1 SKIP.
- The same 8 failures already exist in the unmodified R0128 baseline and are legacy/static expectation mismatches (old RC7.2 strings, an old CI helper assertion, and an old exact-string time-axis assertion). R0129 introduces no additional full-suite failures.
