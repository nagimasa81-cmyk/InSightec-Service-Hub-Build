# R0093 — Readability + Power/Score Replay Axis

- All QTableWidget screens use horizontal scrolling as needed.
- Hover exposes full cell text; double-click opens a resizable full-text popup.
- Wrapped/current-value labels expose full text by tooltip.
- Power/Score curves stop at measured acoustic exposure; no post-exposure hold/extension.
- Terminal PowerGraph zero sentinel is treated as an end marker, not a plotted data point.
- Replay/MR X axis continues to the current replay time after exposure ends.
