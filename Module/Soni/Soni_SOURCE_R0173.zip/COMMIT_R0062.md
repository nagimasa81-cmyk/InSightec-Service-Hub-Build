# R0062 — Registration Persistence + Full Image Selector

- Registration ON is retained while the user browses another image.
- The registration overlay is re-applied automatically when a Preplanning/Planning MR reference is selected again.
- Registration is not silently reset by CT, Treatment MR, or Thermal image selection.
- Added a full-series image selector for each Reference / Treatment MR / Treatment Thermal row.
- The selector exposes every decoded image in the selected category even when only a few thumbnails fit in the right-side navigator.
- Thumbnail strips retain horizontal scrolling and direct click selection.
