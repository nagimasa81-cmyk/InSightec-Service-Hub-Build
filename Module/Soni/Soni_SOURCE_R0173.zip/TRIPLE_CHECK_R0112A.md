# R0112a Triple Check

Three passes were performed against current user requirements and historical commits.

## Pass 1 — connection/state integrity
- Reference, Treatment MR and Thermal rows start visible.
- Thumbnail slots exist for the full series; image bytes arrive asynchronously.
- Registration commits the selected MR before overlay work begins.
- Registration CT stack is reconstructed from field-16 CT assets.
- CI Increase filtering is independent from Spectrum Dump Analyzer filtering.
- Umbrella projection combo, mouse drag and wheel zoom target the same ElementMap widget.

## Pass 2 — ancestor-regression review
- Restored R0068 semantics: Spectrum Dump Analyzer keeps Increase markers on the chart but hides Increase list rows by default.
- Preserved R0075 explicit horizontal thumbnail scrollbar rather than reviving the less reliable native QListWidget scrollbar.
- R0106 hidden-Thermal default is intentionally superseded by the later Thermal-visible requirement.
- R0079/R0088 phase-anchor/phasor tests are intentionally superseded by R0109 real-export phase semantics.

## Pass 3 — packaging / duplicate / stale source review
- VERSION and version.json synchronized to RC7.2-R0112a.
- Removed src/ui/main_window.py.bak so stale UI source cannot be confused with production code.
- Duplicate-method AST guard retained.
- Added one consolidated R0112a behavior-contract regression test.

## Additional fixes from the audit
- CI Rule/state now includes family/rule plus severity/result when present.
- Hydrophone analysis tables now support horizontal scrolling, full-cell hover tooltip and double-click full-text popup.
