# R0058 — Sonication Elements Phase Dedicated Display

- Added a dedicated phase display mode inspired by the workstation UI.
- Phase views now auto-switch to the dedicated layout from umbrella view and render positive/negative relative phase on separate arcs.
- Preserved tile and umbrella views for amplitude and manual layout selection.
