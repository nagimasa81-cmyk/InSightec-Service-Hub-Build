# R0116zzm — Replay synchronization + image presentation + Analyzer fit

- Analyzer Control Timeline/Band Energy dynamically fit the tab viewport; bottom Replay controls remain pinned and accessible.
- Probable Location projects the likelihood field on the Treatment MR nearest selected/strongest cavitation evidence when the parent image cache is available.
- Replay Temperature Trend progressive updates keep irradiation-relative time instead of being overwritten by the old MR-absolute axis.
- Temperature and Power/Score cursors use the same irradiation-relative axis.
- SpectrumMsg and CPC synchronization use their correct time origins; restores main Acoustic Spectrum curves when SpectrumMsg is irradiation-relative.
- Waterfall and Cavitation Visualization charts click back to Replay time.
- Right image navigator uses two visible rows: Thermal + red region, then Selected image (default Treatment MR).
- Main thermal overlay uses smooth solid-red threshold fill, full-resolution cached arrays, a 5 mm ruler with 1 mm ticks when Pixel Size is known, and a 4 mm green target circle.
- Red-threshold changes refresh both main overlay and thermal thumbnails.
