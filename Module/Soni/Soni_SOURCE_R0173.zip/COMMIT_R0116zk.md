# R0116zk — Spectrum asynchronous handoff and race hardening

This revision follows repeated real-machine stalls at 55% and 58%.

## Root causes fixed
- Preload-ready handoff no longer calls `load_sonication()` inline from the Qt signal slot; it returns to the event loop first.
- Open ZIP / Open Folder 55% stage no longer runs the full Cavitation UI reset before starting the decoder.
- Candidate decode starts on the next Qt event turn with a source-identity guard.
- `load_package()` no longer reports 100% before asynchronous decode/publish actually finishes.
- Standalone candidate mode clears package `source_entries`, preventing combo rows from being misrouted as Sonication rows.
- Source reset invalidates old decoder request IDs so a stale worker cannot repopulate a new study.
- Standalone decode results are no longer cached under a stale Sonication index.
- Secondary Spectrogram/Band/Vendor/Cavitation publish is split into separate event-loop stages.

## Validation
- R0116 regression suite: 153 passed.
- Broad non-GUI suite: 459 passed.
- Real 17-00-24_ANx(4).zip: 15 physical CPC pairs, 8/8 treatment mappings, 309 total FFT frames decoded.
- Python compileall and AST duplicate-method audit passed.
