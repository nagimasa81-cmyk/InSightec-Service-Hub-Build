# R0116zzk — Analyzer accessibility + probable-location dual view + location summary

- Spectrum Dump Analyzer replay controls are pinned outside the scroll viewport so late tab/layout updates cannot hide them.
- Removed hard maximum-size clamping after initial fit; normal resize and maximize are supported. Resize triggers tab/content refit.
- Probable Location now shows RCV contribution and probable cavitation region side-by-side.
- Probable Location receiver table is fixed RCV0→RCV7 order (subject only to calibration.ini disabled-channel visibility).
- Sonication/Cavitation Summary adds Cavitation location: Extracranial / Intracranial — near skull / Intracranial — central / Undetermined; DQA exports report NA when identified from export content.
