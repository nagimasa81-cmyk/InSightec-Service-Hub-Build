# R0116t — Control Timeline Runtime Repair

## Field symptoms addressed
- Control Timeline graph populated but Event list rows visually empty.
- Control Timeline Why popup does not open.
- White replay cursor is missing.
- Probable Location updates, proving FFT/Band data is present.

## Root-cause hardening
1. Event-table population no longer aborts when optional tooltip/evidence formatting raises. Every row/cell gets a fallback item.
2. Control Timeline now owns an independent white replay cursor. It is mapped by acquisition cycle to Acquisition_Brain control-session time, rather than incorrectly assuming FFT time zero equals control time zero.
3. Marker selection uses screen-space distance (18 px hit radius), avoiding missed clicks caused by a fixed time-domain tolerance.
4. Why popup formatting is exception-safe; an evidence formatting issue can no longer suppress the popup itself.
5. Red selected-event cursor and white replay cursor remain separate state.

## Expected behavior
- Event list is populated whenever visible control events are reported.
- Why popup remains default OFF; when ON, marker or row click opens exact event evidence.
- White cursor follows replay; red cursor stays on the selected event.
- Probable Location continues to update from current FFT snapshot when not pinned to a selected event.
