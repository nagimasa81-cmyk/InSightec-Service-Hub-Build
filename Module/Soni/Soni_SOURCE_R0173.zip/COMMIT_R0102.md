# R0102 — Registration Reference Series Diagnostic

- Geometry-only comparison across every decoded Preplanning MR and Planning MR series.
- Candidate-specific chain: Planning MR = CtMr; Preplanning MR = inv(MrMr) × CtMr.
- Reports forward/inverse MR pixel, FOV inclusion, center distance, chain, plane, series, active marker, and LEADING REFERENCE.
- Production registration is not changed automatically.
