# R0156 — Fix: "Last"/End navigation stranded inside a composite 220/230 kHz Sonication

## Context
Continuing the 220 kHz (Brain220 DQA) investigation: confirmed that
`SpectrumEvidenceRepository.replay()` already builds a *composite* replay
for 150-350 kHz Sonications (`replay.spectral_replay`, the Sonication-owned
SpectrumMsg stream) alongside the short physical CPC replay (`replay`
itself, limited to whatever one ~15 s CPC dump-rollover window happened to
overlap Sonication start). `_draw_band_energy` and friends already
correctly prefer the full-coverage spectral/aggregate data via
`_spectral_replay()`/`aggregate_band_energy` -- that part needed no fix.

## Bug found
The frame cursor/slider itself is correctly sized by `_cursor_frame_count()`
(which also prefers `_spectral_replay()`), so scrubbing the slider or
stepping frame-by-frame already covers the full Sonication. But three
navigation entry points jumped straight to `len(self.replay.frames)-1` --
the *physical* replay's short frame count -- instead of asking
`_cursor_frame_count()`:
- the "Last" toolbar button
- the `End` key `QShortcut`
- the `End` key handled inside the window's `eventFilter`

`set_frame()` clamps whatever index it's given to `_cursor_frame_count()-1`,
so on 650 kHz data (no `spectral_replay`; physical *is* the cursor source)
this was harmless -- clamping to the physical count and clamping to the
cursor count are the same operation. On a real 220 kHz composite Sonication
(physical=18 frames / ~0.17 s, spectral=75-192 frames / full duration),
"Last" and `End` could only ever reach frame 17, permanently stranding the
user near the very start of a Sonication that might run 20-54+ seconds,
with no way to jump to its actual end.

## Fix
All three sites now call `self.set_frame(self._cursor_frame_count()-1)`.

## Verified
Simulated both cases directly:
- 650 kHz (no spectral_replay): `cursor_frame_count=18`, Last still lands
  on frame 17 -- unchanged, no regression.
- 220 kHz composite (physical=18, spectral=75): old code landed on frame
  17/74; fixed code correctly reaches frame 74/74.

## Tests
`tests/test_r0156_last_frame_navigation_uses_composite_count.py`:
- static check that all three navigation sites use
  `self._cursor_frame_count()-1` and the old physical-only pattern is gone
  everywhere.
- static check that `_cursor_frame_count()`/`_spectral_replay()` still
  prefer the spectral/aggregate replay.

`verify_source.py`: VERIFY_SOURCE_OK.

## Still open
This was found by manually auditing 34 direct `self.replay.frames`
references in `hydrophone_window.py` after the Band0/aggregate check. Most
are legitimate (physical CPC 8CH history/raw-ADC views, which only exist
in the physical replay by nature, and already have their own
physical-vs-spectral index conversion via `_physical_frame_index()`). One
additional site (line ~3105, a fallback ratio-based frame mapping used
only when `self.replay.mr_frame_times_s` doesn't cover the requested
cavitation-event snapshot index) was inspected but not changed -- it is a
rare fallback path inside a more complex function and needs a closer,
dedicated look rather than a quick fix alongside this change.
