# R0154ad triple check

- Umbrella named projections use native +Z and screen conversion occurs once in `_umbrella_project`.
- Perspective projection also uses native +Z; no second Z negation remains.
- DQA thermometry candidates require exact MriImageParams binding plus protocol/value validation.
- Explicit T2*/T2_Star/NFUSCAL Field-5 data are rejected as thermometry.
- Real 42110 audit: Field 5 = T2_Star_ME_1SL with MR-signal-scale values, not temperature; Fields 13/14/24 = Brn-NFUSCAL1; zero-byte placeholders 2/23/28/34; Field 52 not thermometry.
- Series-common DQA contract from R0154ac retained.
- Focused tests: 22 passed.
- Full non-PySide6 regression: 1054 passed, 1 skipped (pyzipper unavailable).
- compileall PASS; verify_source PASS.
