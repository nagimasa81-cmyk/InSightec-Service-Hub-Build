# R0163

Integrated the R0162 comparison findings without regressing the single-owner Spectrum architecture.

- Accept Brain220 `ExciterElectricalPower` in cavitation-control `Set:` records while retaining Brain650 `ExciterPower` support.
- Retain repository-owned `aggregate_time_s` / `aggregate_band_energy` for CI-linked SpectrumMsg Band0/Band1 rendering; MainWindow does not recompute band energy.
- Retain physical/spectral cursor-domain runtime guards from R0160.
- Retain tab-change behavior as cache-publish/paint only for Loaded Export.
- Normalize Windows/Nuitka and source metadata to RC7.10-R0163 / 7.10.0.163.
