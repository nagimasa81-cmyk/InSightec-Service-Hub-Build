# R0159 — Fix: vendor/control cursor features misaligned on 220/230 kHz composite Sonications

## Reported concern
User asked directly: on 220 kHz data, given the physical/spectral
structural difference already investigated (R0156/R0157), is Spectrum
Dump Analyzer only showing "part of the data" for a Sonication?

## Bug found
Beyond the "Last"/End navigation (R0156) and `_probable_reference_image`
(R0157) already fixed, five more sites indexed
`self.replay.frames[self.frame_index]` (clamped to the physical array's
bounds) directly:
- `_current_control_time()`
- the observed-cavitation-event table auto-highlight
- `_render_direct_band_heatmap()`'s current-value readout
- `_current_vendor_time()` (drives the Vendor energy/power plot cursor
  lines)
- `_update_vendor_current_marker()`

`self.frame_index` is a cursor/spectral-domain index (R0156/R0157: it's
sized by `_cursor_frame_count()`, which prefers `_spectral_replay()`).
For a 220/230 kHz composite Sonication the spectral replay is sampled at
its own interval (e.g. ~266 ms across a 75-frame, ~20 s SpectrumMsg
stream) while the physical CPC replay is sampled at ~10 ms and typically
covers only a short window near Sonication start (limited by the CPC's
own ~15 s dump-rollover cadence, see R0156). Treating "spectral sample
number N" as if it were "physical sample number N" is wrong even for
in-range indices, not only once the cursor exceeds the physical array's
short length.

## Verified with a direct simulation
Using the real numbers from this investigation (physical: 18 samples over
9.07-9.24 s; spectral: 75 samples over 9.08-29.04 s):

| cursor (spectral index) | spectral time | OLD physical frame's real time | time error |
|---|---|---|---|
| 0 | 9.080 s | 9.070 s | 10 ms |
| 3 | 9.889 s | 9.100 s | **789 ms** |
| 8 | 11.238 s | 9.150 s | **2088 ms** |
| 15 | 13.126 s | 9.220 s | **3906 ms** |

The old code was already wrong by up to ~4 seconds well before the cursor
ever left the physical array's bounds -- these vendor/control cursor
markers and readouts did not track the scrubbed position correctly across
most of a 220/230 kHz Sonication.

## Fix
All five sites now call the existing `self._physical_frame_index()` helper
(already used correctly by `set_frame()` since R0156) instead of clamping
`self.frame_index` directly. This helper maps the cursor's actual MR time
to the nearest real physical CPC frame.

One further site (`_direct_replay_band_cube()` / the Band0/RCV FFT-Band
link cube used inside `_render_direct_band_heatmap()`) was inspected and
left unchanged: it intentionally iterates the physical replay only,
because `vendor_band_energies` (exact CGA-provided 8-channel x 4-band
values) exists only on physical CPC frames by nature -- this is a genuine
data-availability limit of that specific vendor-exact view, not a domain
mismatch bug.

## Tests
`tests/test_r0159_vendor_control_cursor_domain_fix.py`:
- static check that none of the five stale clamp/index patterns remain.
- static check that all five sites now call `self._physical_frame_index()`.
- static check that the helper is genuinely time-based (`mr_frame_times_s`
  + `np.argmin`), not a linear clamp.

Existing R0155/R0156/R0157 tests re-verified passing. `verify_source.py`
re-run against the packaged, re-extracted `Soni_SOURCE_R0159.zip` ->
`VERIFY_SOURCE_OK`. Confirmed no repeat of the R0158 duplicate-tree
packaging mistake: exactly one `insightec_build_contract.json` inside the
extracted package.
