# R0129 — FFT preset activation + Control Timeline first-open hardening

- Triple-checked R0128 range selection and found a functional regression: selecting a non-mouse Range preset populated the interval but the Run button still depended on the separate mouse-selection toggle.
- Non-mouse presets now automatically activate the selection overlay, display the selected interval, and enable analysis when validated Raw A/D or CPC history exists.
- Clear range returns the selector to Mouse drag and restores the normal cursor.
- Control Timeline nested-tab opening now uses a dedicated first-visible settle based on the nested viewport, not only the outer Analyzer tab height.
- The Control Timeline splitter is seeded once to a usable plot/table ratio, then preserves user adjustments.
- Added splitter handle/opaque-resize hardening and zero-minimum page sizing to prevent lower-table clipping on first open.
