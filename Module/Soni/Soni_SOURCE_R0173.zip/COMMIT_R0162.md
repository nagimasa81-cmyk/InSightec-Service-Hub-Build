# R0162 — R0160/R0161 consolidation

- Keep R0161 full-timeline SpectrumMsg aggregate Band0/Band1 visibility in the CI-linked vendor panel.
- Keep R0161 removal of `_ensure_current_tab_materialized()` from tab navigation. The call was redundant for valid cache and does not start authoritative work on cache miss; Loaded Export tab navigation remains paint/cache-only.
- Eliminate duplicate aggregate-band derivation in MainWindow. CI now consumes `aggregate_band_energy` and `aggregate_time_s` from `SpectrumEvidenceRepository.cached_secondary_products`, the same preload-owned product used by Spectrum Dump Analyzer.
- Preserve the R0161 cycle/cycles restoration and regression guards.
