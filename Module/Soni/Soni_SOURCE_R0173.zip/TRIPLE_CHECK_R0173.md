# Triple Check R0173

1. Semantic separation: Xd loc XYZ is physical transducer location; Steering XYZ remains electronic steering.
2. Evidence provenance: every row preserves source file + line; no interpolation of XYZ.
3. Baseline motion: delta XYZ and 3D displacement are calculated only from observed location rows, relative to the first valid row.
4. Sonication association is context only and does not alter location values.
5. CSV export mirrors the UI evidence and includes source provenance.
6. Diagnostics parity: the same physical-location records shown/exported by the UI are available in Import Diagnostics metadata, including source line provenance and separate Steering XYZ.
