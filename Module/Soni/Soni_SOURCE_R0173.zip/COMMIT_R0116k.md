# R0116k

- Load images OFF now skips the Image thumbnails stage itself, not only the worker.
- Cavitation event cells show full details on mouse hover.
- Parser preserves the matched Acquisition_Brain source line.
- Contributors are split into configured Rule inputs and actually observed contributors.
- Hidden Increase events are excluded from chart click hit-testing, so non-Increase points no longer open Increase popups.
- Why popup explicitly shows Event type, dominant RCV/band, configured inputs, observed contributors, power response and source line.
- Cavitation Intelligence adds numerical Temperature (Start / Peak / ΔT and current Max/Avg when already decoded).
- Temperature display does not force image decoding while Load images is OFF.
