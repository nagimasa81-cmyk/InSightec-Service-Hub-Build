# R0116zl — Authoritative Sonication / CPC / Acquisition Session Alignment

- Replaces blind latest-N treatment CPC mapping with evidence-based Acquisition_Brain session binding.
- Spectrum filename end clock is matched to Acquisition session end clock; treatment block boundary must be evidenced.
- Full vendor Band0 validation now runs in background decode and independently confirms the same Acquisition session.
- Main Replay acoustic-control trend, Cavitation Intelligence, RCA, and Spectrum Analyzer use the same session identity.
- If physical CPC pairs exist but a Sonication binding cannot be proven, no positional substitute is displayed.
- Real 4231 Export: 13/13 treatment Sonications map to Acquisition sessions 7..19 with <1 s end-clock error.
- Real 4231 Sonication 3: CPC 12:38:36 -> session 9 by filename clock, vendor Band0 -> session 9 EXACT, control timeline -> session 9.
- Real June 11 Export: 8/8 treatment Sonications map to Acquisition sessions 8..15 with <1 s end-clock error.
