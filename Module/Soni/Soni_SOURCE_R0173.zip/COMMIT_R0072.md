# R0072 — Full Planning MR Thumbnail Scroll

- Planning MR Ax remains the default Reference series.
- The thumbnail strip contains every decoded image in the selected series.
- Horizontal scrollbar is always visible and uses per-pixel scrolling.
- Removed redundant per-image drop-down selectors from all three navigator rows.
- Category/series drop-downs remain for switching Preplanning/Planning/Treatment image classes.
- Registration checkbox remains at the upper right and preserves the existing behavior.
