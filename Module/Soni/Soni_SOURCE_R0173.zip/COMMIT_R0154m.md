# R0154m — Brain220 SpectrumMsg exact container support

Deep analysis of the supplied `42110-2026-04-01-18-30-47.zip` showed that Brain220 `SpectrumMsg-N.dmp` is structurally different from the Brain650 container handled by the historical decoder.

## Exact format evidence

The Brain220 files use a variable record table:

- `uint32 record_count`
- `uint32 record_size[record_count]`
- exactly concatenated variable-size records

The complete file size equation closes exactly for every Sonication1–7 SpectrumMsg in the supplied export.

Inside each record:

- the first uint32 encodes `48 + 8 * FFT_bin_count`
- FFT values are IEEE754 Float64 with 32-bit words stored high-word then low-word
- embedded bin spacing is 250 Hz for 1000-bin records or 625 Hz for 400-bin records
- embedded upper frequency is approximately 250000 Hz
- the FFT therefore spans 0–250 kHz and contains the physically expected 115 kHz subharmonic and 230 kHz main-frequency bins
- after the FFT is a measurement-history count, 20-byte history entries, and a fixed 12-byte trailer
- the fourth float32 of each history entry is monotonic elapsed acquisition time and is now used as the Spectrum frame timestamp

This format is detected only by structural invariants and exact byte-count equations. No filename, serial number, fixture name/hash, expected frame count, numeric clipping, or expected-value fitting is used.

## Implementation

- Add exact size-table SpectrumMsg parser before Brain650/legacy heuristics.
- Decode every record instead of returning one heuristic frame.
- Preserve embedded 0–250 kHz FFT bins and 250/625 Hz spacing.
- Propagate record timestamps into `SpectrumFrame` for evidence-based Replay synchronization.
- Make both current-spectrum and spectrogram display ranges Brain220 aware; show 50–250 kHz while retaining all decoded bins internally.
- Preserve Brain650 decoder paths unchanged.

## Real-export validation

For supplied Brain220 export:

- S1: 161/161 records, 1000 bins, 250 Hz, time 0.219–41.891 s
- S2: 6/6 records, 400 bins, 625 Hz, time 0.398–1.637 s
- S3: 347/347 records, 1000 bins, 250 Hz, time 0.000–89.909 s
- S4: 153/153 records, 400 bins, 625 Hz, time 0.505–40.005 s
- S5: 346/346 records, 1000 bins, 250 Hz, time 0.217–89.796 s
- S6: 348/348 records, 1000 bins, 250 Hz, time 0.000–89.907 s
- S7: 346/346 records, 1000 bins, 250 Hz, time 0.109–89.909 s

S1/S2/S6/S7 directly show strong 115 kHz bins; S6/S7 also contain 230 kHz strongest-peak frames. This is direct binary evidence that the previous 200–800 kHz/heuristic display was not a faithful Brain220 decode.
