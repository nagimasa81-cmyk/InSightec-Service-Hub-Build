# R0172 — Confirm R0171's ChatGPT changes, remove packaging artifact, fix two regressed tests

## Evaluation of R0171 ("Per-frame thermometry semantic binding")

R0171's actual feature (factoring the T2_STAR/NFUSCAL/TMAP token
classification out of `_thermometry_protocol` into a shared
`_classify_thermometry_series()` helper, reused per-frame by a new
`thermometry_frame_semantics()`, and checking *every* source frame in
`temperature_trend` rather than only the first candidate) is a sound,
well-motivated improvement: a single Sonication can legitimately contain
multiple MR series under the same numeric field family (confirmed by the
new test's own construction: array index 0 = TMAP-ME thermometry, array
index 10 = T2_Star_ME_1SL non-thermometry, same field/sonication/zone).
The old first-frame-only check could not distinguish this. Diagnostics
now also exports per-frame semantic decision, series description/UID,
echo number/time, and ROI binding. Verified: all 3 new R0171 tests pass.

## Packaging mistake found and removed

`src/ui/hydrophone_window.py.tmp` was present in the delivered ZIP -- a
leftover draft of an earlier, unused approach (a "SpectrumMsg full
timeline" Vendor-view combo option with its own dB-relative plotting
path) that was superseded by the simpler, actually-shipped R0170 approach
(default the initial Measurement tab to Band Energy on a composite
replay, and report both physical/SpectrumMsg counts in the source-details
line) -- confirmed by running the new
`test_r0170_brain220_dual_domain_presentation.py` against the *shipped*
`hydrophone_window.py`, which passes. The `.tmp` draft was never wired
into anything and only bloated the package (same class of mistake as the
R0158 `soni154ak/` duplicate tree). Deleted.

## Two regressed tests found and fixed

1. `tests/test_r0116z_loading_stall_lazy_panels.py`'s
   `test_heavy_panels_are_lazy_tab_refreshes`: this session's own R0170
   fix (widening the assertion to accept either
   `_update_cavitation_intelligence_page()` or
   `_prepare_cavitation_on_demand()`) was reverted back to the stricter,
   single-string form somewhere in R0171's merge, while the actual
   `_main_tab_changed()` implementation still calls
   `_prepare_cavitation_on_demand()` -- so the test was failing again.
   Re-widened the assertion (third time fixing this exact regression
   pattern in this session).

2. `tests/test_r0154ak_common_data_lifecycle.py`'s
   `test_named_nonthermal_mr_protocol_cannot_become_celsius`: expected
   the literal tokens `T2_STAR`/`NFUSCAL`/`TMAP` inside
   `_thermometry_protocol` itself, but R0171's refactor moved them into
   the new shared `_classify_thermometry_series()` helper;
   `_thermometry_protocol` now delegates to
   `thermometry_frame_semantics()` instead of inlining the checks. Updated
   the test to look for the tokens in the classifier they now actually
   live in, and to confirm `_thermometry_protocol` delegates to it.

## Verification
Full test sweep: 1127 passed, 9 pre-existing/unrelated failures remain
(same set as R0170's baseline). `verify_source.py` re-run against the
packaged, re-extracted `Soni_SOURCE_R0172.zip` -> `VERIFY_SOURCE_OK`.
Confirmed no `.tmp` files and no `soni154ak`-style duplicate directories
in the final package.
