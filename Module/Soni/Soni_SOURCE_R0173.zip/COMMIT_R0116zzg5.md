# R0116zzg5 — Spectrum fixed-scale background hardening

## Problem
The Spectrum tab intentionally keeps a fixed Y axis across the complete replay. The previous implementation computed that range from `_draw_spectrum()` by scanning every FFT frame and receiver. On large CPC/SpectrumDumps this could block the Qt GUI thread when opening or switching Spectrum display modes, reproducing the same "stuck" appearance already removed from the load pipeline.

Accumulated delta/RMS/noise/innovation modes also build prefix statistics over the full replay on first use, so switching to those modes near the sonication end could perform another full replay calculation from the GUI paint path.

## Change
- Added `SpectrumYRangeWorker` on a low-priority QThread.
- `_spectrum_fixed_y_range()` is now cache lookup + background request only; it never scans all FFT frames.
- A conservative temporary axis is published immediately while the stable full-replay range is prepared.
- Accumulated modes show a short "Preparing fixed Spectrum scale in background…" state instead of constructing prefix matrices on the GUI thread.
- Prefix-statistics cache is now replay-owned as well as service-local, allowing the worker to prewarm the exact numpy arrays reused by the GUI service.
- Replay reset and window close cancel stale scale jobs; generation/request guards prevent an old Sonication from repainting a new one.

## Behavioral contract preserved
- Spectrum Y range remains fixed across playback once computed.
- The fixed range still considers all selected receivers/all frames.
- calibration.ini receiver enable/disable behavior is unchanged.
- No change to FFT frequency axis, cavitation thresholds, vendor band energy, or event semantics.
