# R0116zzg17 — Spectrum primary publish anti-regression

- Fixes a primary publish race where an equivalent repository replay object could replace the queued replay before the Qt timer painted Raw/Spectrum/Statistics. Decoded CPC frames no longer remain behind an empty Spectrum tab.
- Primary publication is now owned by selected Sonication + source signature, not transient Python object identity.
- Adds 80 ms / 300 ms no-I/O self-healing primary materialization retries.
- Adds a decoded-current-frame Y-range fallback while the global fixed-scale worker is pending, preventing valid current spectra from being clipped by a generic placeholder range.
- Adds no-silent-empty Spectrum redraw recovery when enabled receivers contain decoded FFT bins.
- Corrects MR Spectrum navigation labels: pre-irradiation CPC snapshots are displayed from MR/CPC acquisition start as 0 s, while irradiation start is shown explicitly later on the same timeline.
- Carries forward all R0116zzg14–g16 cavitation, tab materialization, and MR annotation changes.
