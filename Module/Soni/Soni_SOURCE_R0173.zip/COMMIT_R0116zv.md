# R0116zv — Replay space reallocation + analyzer fit + science access

- Replay right-side collapsible sections now donate freed vertical space to remaining visible sections.
- Temperature/Spectrum and Power/Score/Cavitation horizontal split columns are synchronized.
- Power/Score explicitly shares Temperature Trend X range after every replay refresh.
- Treatment Outcome Science is directly accessible from the Cavitation Intelligence header.
- Spectrum Dump Analyzer main workspace has no horizontal scrollbar; vertical scroll only when required.
- Analyzer opens/clamps to usable screen geometry and allows children to shrink horizontally.
