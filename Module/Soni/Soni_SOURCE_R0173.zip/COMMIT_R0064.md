# R0064 — Registration Light-Green Skull Overlay

- Registration skull/bone overlay changed to semi-transparent light green.
- Increased visible bone body and expanded boundary rim so the overlay is usable on laptop displays.
- Reduced registration overlay opacity so MR remains visible while skull stays readable.
- Preserved evidence-first behavior: no synthetic centered overlay is drawn when CT/MR geometry is missing.
