# R0116zzza — Canonical Image Orientation Unification

This release repairs the reintroduced vertical inversion in anatomical image routes and prevents the same failure from surviving in alternate views.

## Implemented
- Added one explicit receiver-field ↔ raster-row orientation conversion contract in `src/core/image_orientation.py`.
- Main Replay anatomical views (`Linked Probable Region`, `MR Correlation`) use a row-0-at-top ViewBox exactly once; arrays are not pre-flipped.
- Spectrum Dump Analyzer / Hydrophone probable-location view switches orientation by mode: Treatment MR mode is raster row-0-at-top, receiver schematic mode remains Cartesian Y-up.
- Receiver likelihood projected onto Treatment MR is converted to raster rows before overlay.
- Cavitation MR correlation now converts receiver likelihood before pixelwise MR fusion.
- MR evidence fused back into receiver-reference likelihood is converted in the inverse direction.
- Normalized probable-location markers now use shared normalized-coordinate-to-raster helpers.
- Registration `flip-x/flip-y/transpose` hypotheses remain confined to registration candidate search and are not display transforms.
- Preserved canonical Replay/Planning/Reference/Registration display route using `ViewBox.invertY(True)` with unflipped arrays.
- Applied the pending Red-threshold contract: values `<= threshold` are the solid red threshold region.

## Regression protection
New tests fail if display-level `np.flipud/fliplr` is reintroduced in Main/Hydrophone UI, if anatomical probable-location plots lose the raster orientation, or if MR/receiver evidence fusion omits the coordinate conversion.
