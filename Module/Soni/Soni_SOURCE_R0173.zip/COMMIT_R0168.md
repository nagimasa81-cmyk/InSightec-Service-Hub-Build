# R0168 — Linked CI refresh ownership + Sonication-scoped axis + thermometry audit

## Fixes
- Main Linked Cavitation Analysis now uses MR acquisition start -> Sonication end as its canonical initial X range, matching Spectrum Analyzer.
- Linked CI redraw cache now fingerprints repository secondary-product readiness, not only replay object identity. A panel first painted while secondary cache is incomplete can repaint when Band/Control products become ready.
- Authoritative Spectrum context handoff explicitly invalidates the linked CI paint cache.
- Import Diagnostics now distinguishes source RAW frame count from replay-aligned finite sample count and records per-source-frame robust peak/mean/robust delta metadata for thermometry root-cause analysis.

## Intentionally unchanged
- No arbitrary thermometry coefficient, clipping, or Sonication1-specific correction was introduced.
- R0164 spatially coherent 3x3 peak logic remains authoritative pending per-source-frame evidence.
- R0165-R0167 Acquisition_Brain session selection, non-extrapolated history timing, stale-axis reset, and workstation actual-power overlay are retained.
