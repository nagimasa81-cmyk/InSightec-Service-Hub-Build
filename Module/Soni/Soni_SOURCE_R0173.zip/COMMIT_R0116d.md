# R0116d
- Hover image enlarged to diagnostic-size preview.
- Registration routine overlay emphasizes external skull envelope; QA/matrix unchanged.
- Consolidated Sonication-dependent refresh path added.
- Sonication handlers patched: ['_sonication_combo_changed', '_select_sonication_index']
- 3-D defect/disconnected markers project through the same active camera as element XYZ.
- R0116c thumbnail gallery/QSlider and prior registration improvements preserved.
