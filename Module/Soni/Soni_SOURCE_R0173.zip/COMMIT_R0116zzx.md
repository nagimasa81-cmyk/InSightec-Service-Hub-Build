# R0116zzx — Visual Thermometry / Canonical Cavitation / Data Recomposition Repair

- Red threshold overlay now uses a focal connected threshold region with a soft alpha boundary and pure red RGBA.
- MR/Thermal zoom rendering requests SmoothPixmapTransform.
- 5 mm / 1 mm-tick ruler is a screen-edge overlay; physical line length is recomputed from pixel spacing and ViewBox zoom.
- Added one CanonicalCavitationEvidence contract shared by Cavitation Intelligence, Probable Location, Sonication Summary and RCA.
- Confirmed cavitation = observed cavitation-control event OR Spectrum Dump Analyzer vendor INI Rule Trigger. Robust-z Candidate alone remains unconfirmed.
- Sonication Summary Spectrum evidence discovery/decode remains background-only through SonicationSummaryCavitationEvidenceService.
- Energy delivered (%) no longer becomes artificial 100% from a planned-energy fallback.
- RCA score is recomposed after thermometry enrichment.
- Added explicit top-toolbar Activity / Memory button with a distinct signal from Spectrum Dump Analyzer.
- Added R0116zzx regression guards and real-export revalidation.
