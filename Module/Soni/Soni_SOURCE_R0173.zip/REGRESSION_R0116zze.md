# R0116zze Regression Report

## Fixes
- Red threshold alarm remains temperature >= threshold.
- Removed multi-pass alpha blur from the red threshold mask; binary threshold edges are preserved.
- Secondary Spectrum publishing no longer reuses the exclusive/modal progress dialog.
- Worker completion at 96% performs no full stale-view clear or chart/table binding before returning to Qt.
- Fresh and cached secondary payloads both enter the same staged QTimer publish path.
- Publish stages remain independently identifiable at 97/98/99/100%.
- Slow UI bind stages (>0.75 s) append a diagnostic duration to the Analyzer note.

## Regression
- pytest excluding the known PySide6-only GUI collection test: 697 passed.
- verify_source.py: VERIFY_SOURCE_OK.
- compileall: PASS.
- duplicate methods in MainWindow/HydrophoneWindow/ImagePanel: 0.
- QApplication.processEvents in those production modules: 0.
- QThread terminate calls in those production modules: 0.

## Environment limitation
- tests/test_r0015_circular_roi_measurement.py cannot be collected in this Linux validation environment because PySide6 is not installed.
