# R0043

Cavitation Events layout fix.

The previous tab stacked control plot, event table, likelihood text, likelihood plot, contribution table, activity heatmap, and candidate table in one vertical column. On laptop-height displays this reduced charts to only a few pixels.

R0043 separates the visual tasks into three inner tabs and collapses explanatory text by default.
