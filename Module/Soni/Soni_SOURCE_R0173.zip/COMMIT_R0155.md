# R0155 — Fix: uncaught IndexError for Sonication-less (DQA/phantom) Exports

## Reported context
User supplied a real 220 kHz Brain220 Export (17-45-37, `Frequency[Hz]`
230000 in the CPC Spectrum dumps) for analysis, noting the data structure
differs from the 650 kHz Brain650 Exports used throughout this
investigation. Structural check confirmed: `SonicationSummary.xml` and
`TreatSummary.csv` contain zero data rows (schema only) -- this specific
Export recorded no completed treatment Sonications, only raw CPC Spectrum
candidates (20 discovered) and controller/log files. `DiscoveryService`
correctly reports `sonication_count=0` for this Export; that much is
already correct.

## Bug found
Any caller that asks for the default Sonication index (0) against such a
package -- which is exactly what `_open_hydrophone_window`/
`prepare_for_background_preload`-style flows do reflexively when a package
loads -- hit an uncaught `IndexError: list index out of range` with no
explanation, from two separate unguarded direct-list-index sites:

1. `SpectrumEvidenceRepository.replay()`: `son =
   list(getattr(package,"sonications",[]) or [])[index]` when `son` is not
   supplied.
2. `SpectrumDecodeWorker.run()` (`src/ui/hydrophone_window.py`), in both
   the dual-source (SpectrumMsg + physical CPC) and CPC-only branches:
   `son = self.package.sonications[self.sonication_index]`, one line
   *before* it would even reach the repository's own check.

Reproduced directly against the real 220 kHz Export:
```
repo.replay(package, 0) -> IndexError: list index out of range
```
`SpectrumDecodeWorker.run()` does catch `Exception` broadly and emit a
`.failed` signal rather than crashing the whole app, but the message
shown to the user would have been the bare, unhelpful `IndexError: list
index out of range` with no indication that the real cause is simply "this
Export has zero completed Sonications."

## Fix
Both sites now bounds-check before indexing and raise the same clear,
descriptive `IndexError` (same exception type, so existing callers that
already catch/handle `IndexError`-class failures are unaffected) instead
of a bare one:
```
Sonication index {index} is out of range: this package has {n} completed
Sonication(s). A DQA/phantom Export or a Loaded Export with no recorded
treatment Sonications can legitimately have zero; a clinical treatment
Export should not.
```
`SpectrumDecodeWorker.run()` gained a local `_resolve_sonication(index)`
helper so both branches share one guarded lookup instead of two separate
unguarded ones.

## Verified
- Real 220 kHz Export (0 Sonications): `repo.replay(package, 0)` now
  raises the clear, descriptive `IndexError` instead of the bare one.
- Real 650 kHz Export (5 Sonications, used throughout this investigation):
  `repo.replay(package, i)` for i in 0..4 still returns fully decoded
  replays (34/33/34/34/12 frames respectively) -- unaffected.
- CPC Spectrum FFT decode itself was checked directly against this 220 kHz
  data and works correctly: `main_frequency_hz=230000.0`, 8 channels,
  frequency axis 50 kHz-250 kHz over 1601 bins, 250 frames per dump file --
  no frequency-specific decode issue found; the crash was purely the
  zero-Sonications indexing bug above, unrelated to the 220 vs 650 kHz
  frequency difference itself.
- Full non-PySide6 test sweep: 1078 passed. The 10 failures / 4 errors
  present are pre-existing and confirmed (by grep) to have zero reference
  to `replay(`, `_resolve_sonication`, or `SpectrumDecodeWorker` -- they
  are limitations of this sandbox's minimal test-shim (missing
  `pytest.approx`, complex fixture signatures), not regressions from this
  change. 2 files fail to import for pre-existing, unrelated reasons
  (`PySide6`/`pyqtgraph` not installed in this environment).
- `verify_source.py`: VERIFY_SOURCE_OK.

## Tests
`tests/test_r0155_sonicationless_package_no_crash.py`:
- `replay()` raises the clear IndexError for an empty `sonications` list.
- `replay()` still raises IndexError (with the correct count) when the
  index exceeds a non-empty list.
- Static check that `SpectrumDecodeWorker` uses the shared
  `_resolve_sonication` helper in both branches and the old unguarded
  direct-index pattern is gone.
