# R0134 Triple Check — Blank Main/Spectrum Tabs

## Root causes confirmed
1. Spectrum secondary products still used Python object identity (`id(replay)` / `replay is self.replay`) in several async completion and publish paths. Equivalent replay instances for the same selected Sonication could therefore decode successfully but have their publish callbacks discarded.
2. Main heavy tabs could be opened before selected-data/Spectrum preload workers finished. The first lazy paint could be empty, and worker completion did not always re-materialize the currently visible tab.

## R0134 changes
- Stable semantic replay ownership key: selected Sonication index + resolved Spectrum/Raw source path + decoded FFT frame count.
- Repository secondary cache stores `replay_key` and validates against it; legacy `replay_id` is retained only for compatibility with pre-existing payloads.
- Secondary ready, staged publish, cache publish, tab self-heal, materialize-all, Spectrum Y-range callbacks and delayed view-fit recovery use semantic ownership.
- Selected-data completion and Spectrum preload completion schedule a refresh of the currently visible main tab.
- Equivalent decoded replay instances are accepted; stale/different Sonication/source/frame-count callbacks are rejected.

## Verification
- Async/Spectrum targeted regressions: 74 passed.
- R0133 orientation + R0130 Band0/hat + R0131/R0132 zoom regressions: 36 passed.
- Full non-GUI suite (excluding PySide6-only ROI collection test): 855 passed, 8 failed, 1 skipped. The 8 failures are pre-existing legacy/static expectations (old RC7.2 version strings, old CI fit helper/time-window static assertions) and are unrelated to R0134 blank-tab changes.
- Python compileall: PASS.
- verify_source.py: PASS.
- Duplicate-method AST scan for main_window.py, hydrophone_window.py and spectrum_evidence_repository.py: no duplicate methods.
