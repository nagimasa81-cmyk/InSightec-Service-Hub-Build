# R0055 — Transmit Element Blade Mapping + Legend Toggle

- Treat Sonication_Brain Channel 0..1023 as ultrasound transmit elements, not hydrophone receivers.
- Map each element to Blade 1..16 and Blade-local CH 0..63 using 64 channels per Blade.
- Cavitation Intelligence table now shows Element CH / Blade / Blade CH / amplitude / phase.
- Keeps transmit-element namespace separate from RCV0..RCV7 cavitation receivers.
- Adds a checked-by-default Legend checkbox to show/hide the vendor cavitation chart legend strip.
