# R0116zzg3 — Spectrum decode/display handoff freeze guard

- Preserve irradiation-end default snapshot.
- End the exclusive Spectrum data-processing dialog as soon as decode/calibration ownership is complete.
- Yield to the Qt event loop before binding Raw/Spectrum/Statistics widgets.
- Publish primary data with stale-generation/replay guards.
- Keep secondary Spectrogram/Band Energy/Cavitation processing non-modal and worker-owned.
