# R0120 — Configurable password support for opening protected export ZIPs

## Feature
Dropped/selected ZIP exports that are password-protected are now handled
automatically instead of failing with a raw zipfile error:

1. `ImportService.open()` detects encrypted entries (general-purpose flag
   bit 0, per ZIP APPNOTE 4.4.4) before extracting anything.
2. If encrypted, it tries every password from `ZipPasswordService`, in
   order, starting from a freshly-cleared temp directory each attempt so a
   wrong password's partial/garbage output never contaminates the next try.
3. The built-in default candidate is `"clinicalopt"` -- but it is **not**
   hardcoded as the only option. It is written once into a plain, editable
   JSON config file (`~/SonicationReplayEngine/config/zip_passwords.json`)
   the first time the service runs; every read/write after that goes
   through the same file. A site can add, remove, or replace passwords at
   any time with zero code changes and zero rebuild.
4. If no configured password opens the archive, extraction stops cleanly
   with a clear `PermissionError` (no partial workspace left behind) --
   exactly the "give up and stop" behavior requested, not a silent
   fallback or a crash.
5. Archives using an encryption method Python's stdlib `zipfile` cannot
   decrypt at all (e.g. WinZip AES) get a distinct message explaining that,
   instead of being misreported as "wrong password".

## In-app settings (not just hand-editing JSON)
Added `ZipPasswordSettingsDialog` (`src/ui/zip_password_dialog.py`) and a
"File -> ZIP Password Settings..." menu action in `main_window.py`. The
dialog is a thin view over `ZipPasswordService` (add/remove/list) -- it is
not a second store of the password list.

## Bug found and fixed while testing this
`NotImplementedError` is a subclass of `RuntimeError` in Python. The first
implementation wrote `except RuntimeError` before `except
NotImplementedError`, so the wider `RuntimeError` clause caught AES-style
"unsupported encryption" failures first and (since their message doesn't
contain "password") re-raised them raw instead of ever reaching the
intended `NotImplementedError` branch. Fixed by reordering the except
clauses (narrower/subclass exception first) and added
`test_not_implemented_error_is_checked_before_the_wider_runtime_error_branch`
as a permanent regression guard, plus a passing behavioral test for the
now-correct AES-rejection message.

## Tests
`tests/test_r0120_zip_password_support.py` -- behavioral (pytest-style,
using `tmp_path`/`monkeypatch`), verified locally against this sandbox's
`zip` CLI for the real-encryption cases and via targeted monkeypatching for
the two edge cases that are impractical to reproduce with a real AES ZIP
in a sandbox:
- default password is seeded into a plain editable config file
- passwords can be added/removed/replaced without code changes
- unencrypted ZIPs are unaffected
- the seeded default password opens a matching ZIP with no manual setup
- a wrong/unconfigured password stops cleanly, no leaked temp workspace
- adding the right password afterward makes the same ZIP open (the actual
  "configurable, not hardcoded" guarantee)
- no configured passwords -> clear error
- unsupported (AES-class) encryption -> distinct message
- except-clause ordering regression guard (see bug above)
- File menu action and dialog are wired to the same service, no second
  source of truth

All R0116zzg23 / R0117 / R0117b / R0118 / R0119 assertions re-verified
passing. `verify_source.py` re-run against the packaged, re-extracted
`Soni_SOURCE_R0120.zip` -> `VERIFY_SOURCE_OK` (exit 0). No new third-party
dependency: only `zipfile`/`json`/`pathlib` (stdlib) and existing
PySide6 widgets are used.
