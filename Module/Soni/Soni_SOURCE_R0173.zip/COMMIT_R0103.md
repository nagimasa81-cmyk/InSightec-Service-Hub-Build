# R0103 — Plane-Aware Series Registration QA

- Groups MR candidates by category + series number + plane.
- Eliminates per-array/slice spam in Registration Trace.
- Evaluates all slices in each series and selects the representative slice by minimum patient-coordinate through-plane distance.
- Ax/Sag/Cor are compared independently.
- Active plane and active series are explicitly marked and weighted.
- Uses CtMr for Planning MR and inv(MrMr)×CtMr for Preplanning MR.
- Production overlay remains export-deterministic; no image-similarity or visual auto-registration.
