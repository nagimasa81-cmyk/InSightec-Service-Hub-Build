# RC7.10-R0154af

## Purpose

Deepen Sonication data completeness and add a per-Sonication MRI RAW protocol inventory.

## Changes

- Spectrum preload now materializes secondary Spectrum/CGA/Band/Cavitation products for every physically decoded receiver channel (up to RCV0-RCV7), rather than preloading only RCV0 and allowing later tab selection to become a hidden data-load trigger.
- Added `MrRawProtocolService`.
  - RAW filename field + Sonication ownership is authoritative.
  - Each RAW-backed field is bound to the exact `MriImageParams.xml` rows for that Sonication.
  - No protocol is inferred from field number.
  - RAW files without a matching MriImageParams row remain visible as `Metadata unavailable`; they are not silently dropped.
- Added top-level **MR Protocol / RAW** tab.
  - One row per RAW-backed MR field/series for the selected Sonication.
  - Shows Series/Protocol, plane, RAW count, matrix, pixel size, slice thickness, TR, TE, flip angle, bandwidth, frequency direction, acquisition matrix, center frequency, transmit gain, and Series UID.
  - Selecting a series exposes the full exported representative MriImageParams parameter set plus the exact RAW filenames.
- The MR protocol inventory is prepared by the existing deferred Export/Data worker; opening the tab itself does not start a new filesystem scan.

## Regression contract

- `SpectrumPreloadWorker` must preload every available physical receiver channel's secondary products.
- `MR Protocol / RAW` must use Sonication-local RAW ownership plus exact MriImageParams binding.
- Missing metadata must remain explicit, never be substituted from another Sonication or field.
