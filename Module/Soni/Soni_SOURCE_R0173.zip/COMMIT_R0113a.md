# R0113a — Interactive 3-D Umbrella Repair

The R0111/R0113 3-D controls were present but did not provide a usable 3-D interaction.

Root causes fixed:
- left-click on one of 1024 dense points selected the element and returned before drag rotation could start;
- named projection matrices did not match their labels (Top XY / Front XZ / Side YZ);
- dots were auto-scaled without wire/depth cues, making camera changes visually ambiguous;
- free rotation switched the internal mode to Perspective but the combo box remained on the old named view;
- Reset view reset the renderer but did not synchronize the UI selector.

R0113a:
- drag starts everywhere in the Umbrella map; a short click selects, movement rotates;
- exact orthographic XY/XZ/YZ projections;
- perspective camera with yaw/pitch;
- wheel zoom 0.20x–6.0x;
- physical blade wireframe + depth-order + depth-dependent marker size/alpha;
- projection combo synchronizes when drag changes to Perspective;
- Reset view synchronizes renderer and combo.
