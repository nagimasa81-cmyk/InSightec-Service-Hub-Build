# R0033 — Exact FFT Vendor Band Energy / Cycle Mapping

Deep reverse engineering of real CPC Spectrum dump data found a stable post-FFT structure:

- Every 8-channel FFT snapshot is followed by eight 36-byte records.
- Each record starts with `uint32 4` and then four `float32` values.
- Those four values are exactly vendor Band0, Band1, Band2, Band3 energies for that hydrophone.
- Re-summing the displayed FFT bins inside `HARMONICS_BANDWIDTHS` reproduces those embedded values to float32 precision.
- The Band0 vector across 8 hydrophones acts as a unique fingerprint. Matching the weighted Band0 fingerprint to the saved 10-ms Band0 history recovers the real acquisition cycle of each FFT snapshot exactly.

This removes two prior approximations: local band-energy inference and uniform FFT snapshot timing.
