# R0112a Triple Check — connection / overwrite / ancestor-regression audit

## Scope
Re-audited RC7.2-R0112 against historical regression tests, current R0112 fixes, source-level signal/state connections, release metadata, and the real export `10-00-09_ANx(1).zip`.

## Check 1 — Source / state / connection audit
PASS after repairs.

Findings repaired:
- Release identity had reverted: `VERSION` and `src/common/constants.py` still reported R0106b while `version.json` reported R0112. All three now report R0112a.
- R0054 MR signal-loss WW/WL handlers survived, but their UI controls had disappeared. Restored WW, WL, `Auto WW/WL`, `Fit MR`, and value-change connections.
- R0068 Increase behavior had drifted from list-only filtering to chart+list filtering. Restored Increase markers on the chart; the checkbox controls event-list visibility only. Cavitation Intelligence retains its independent default-OFF Increase list filter.
- R0072 full-series access used an external scrollbar but depended only on Qt `rangeChanged`. Added explicit range/page-step synchronization after every strip rebuild to prevent an external scrollbar remaining at 0..0 while off-screen thumbnails exist.
- Removed `src/ui/main_window.py.bak`, which contained obsolete Show-Thermal logic and could cause human/tool ancestor confusion.
- Legacy `_planning_type_changed()` no longer routes to the old planning-only strip builder; it delegates to the unified navigator.
- Restored explicit RCV → probable-region wording and probable-region/non-point-localization semantics.

Already correct and rechecked:
- Reference and Treatment MR rows default visible.
- Thermal remains the default main replay image.
- Reference/Treatment thumbnail decoding stays off the UI thread.
- Selected MR is committed to the main image before Registration overlay evaluation.
- Registration CT stack accepts only verified field-16 CT when present.
- CI Increase list is default OFF.
- Summary status distinguishes Decrease/Safety from Increase-only and no-event states.
- Umbrella projection controls are connected to one Element X/Y/Z renderer; drag rotates and wheel zooms.
- No duplicate method definitions in audited Python classes.
- No stale `XDWindow` constructor or removed `show_thermal_images_check` reference remains in active source.

## Check 2 — Historical regression reconciliation
Initial non-GUI historical suite exposed 15 failures. They were classified rather than blindly forcing old behavior back.

Real regressions fixed:
- stale release metadata/version constants
- missing Auto WW/WL UI despite surviving handlers
- lost RCV/probable-region explanatory contract
- Increase chart behavior changed beyond the original list-filter request
- external thumbnail scrollbar range could remain stale

Superseded tests reconciled to later confirmed requirements:
- old R0079 degree/common-phase-anchor model was superseded by R0109 real-export validation: Total Phase Shift is unwrapped radians and steering residual is `wrap(Total - Phase Correction)`
- old R0088 phasor-position layout was superseded by the requirement that physical Element X/Y/Z position stays fixed and phase controls color/focus analysis
- old R0106 Show-Thermal-default-OFF behavior was superseded by the later requirement that Thermal is the default visible image
- old `itemClicked` test was updated because packaged Qt now intentionally uses `itemPressed + itemActivated` to avoid double execution
- old replay-wheel test was selecting the Sonication Element widget's wheel handler instead of `MainWindow.wheelEvent`
- old native-scrollbar test was reconciled with the explicit external horizontal scrollbar design

Result: **291 non-GUI tests passed**.
Full test collection cannot run in this Linux validation environment because PySide6 is not installed; source compilation and AST checks pass.

## Check 3 — Real export validation
`10-00-09_ANx(1).zip` was reopened with R0112a services.

Non-UI load timing on this environment:
- ZIP open/extract: ~5.96 s
- Discovery: ~0.48 s
- Total non-UI import/discovery: ~6.44 s

Detected:
- 8 Sonications
- 26 CPC spectrum files
- 640 planning/reference assets

Exported MR classification remains correct:
- Planning Ax: 52 — field 19 / series 900 — exported original 3-D series
- Planning Cor: 49 — field 20 / series 5 — exported saved reformat
- Planning Sag: 49 — field 21 / series 4 — exported saved reformat
- Preplanning Ax: 13 — field 7 / series 7
- Preplanning Cor: 15 — field 8 / series 8
- Preplanning Sag: 19 — field 12 / series 5

Power / duration / energy are present for all eight Sonications, including:
- S1: 429.8 W / 11.47 s / 4536.2 J
- S7: 885.1 W / 30.94 s / 20869.7 J
- S8: 875.0 W / 52.00 s / 32126.0 J

## Remaining runtime verification
The following still require Windows/PySide6 EXE verification because they depend on real Qt rendering/event delivery:
- final visual confirmation that every progressively decoded thumbnail icon appears in the existing slot
- visual CT bone overlay on the actual selected MR slices
- mouse drag/wheel feel of the 3-D Umbrella in the packaged EXE
- actual wall-clock UI-ready time after ZIP load

These are not marked complete solely from source inspection.
