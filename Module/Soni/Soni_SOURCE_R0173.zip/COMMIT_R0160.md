# R0160 — Fix: CI-linked vendor panel showed nothing past physical CPC coverage

## Reported concern + evidence
User asked directly whether Spectrum Dump Analyzer only shows partial data
for a 220 kHz Sonication despite R0156/R0157/R0159, and provided three
live screenshots of the actual running RC7.10-R0159 build against real
220 kHz data:
1. Spectrum Dump Analyzer, "Measurement Timeline / Raw A/D" tab: data only
   ~11-14.5 s, flat/empty the rest of the way to Sonication end (~27 s).
2. Spectrum Dump Analyzer, "CGA Cavitation / Vendor Rules" tab: same
   ~11-14.5 s window only, empty afterward.
3. MainWindow's Cavitation Intelligence tab, "Combined Band0 / control
   input" chart: **completely blank**, no data at all.

## Investigation
(1) and (2) are the physical CPC vendor/8CH measurement history itself
(`raw_timeline_channels`, `vendor_band0_weighted`, etc.) -- this is
data genuinely limited to whatever one ~15 s CPC dump-rollover window
overlapped Sonication start (see COMMIT_R0156.md); the chart titles
("Validated CPC 8CH measurement history -- processed history (not Raw A/D
waveform)") already say so. The Spectrum Dump Analyzer's Vendor tab
already has code to overlay the Sonication-owned SpectrumMsg aggregate as
a separately-named curve reaching the true Sonication end
(`hydrophone_window.py`, `_vendor_series_enabled("weighted_b0")`) -- this
mechanism was verified working correctly against the real data (see
below), so (1)/(2) not showing the overlay in the screenshot is most
likely a live-session timing/cache-population question that could not be
reproduced in this sandbox (no PySide6). No source bug was found there.

(3) was a real, confirmed bug. `_draw_ci_linked_vendor_energy()` in
`main_window.py` plotted only `replay.vendor_band0_weighted` /
`vendor_band1_log_exact` -- the physical-only vendor history -- with **no
equivalent aggregate overlay at all**, unlike the Analyzer's own Vendor
tab. On a composite 220/230 kHz Sonication where the physical vendor
history is short or the CI-linked replay object doesn't carry it, this
panel had nothing else to fall back to and rendered completely blank,
matching screenshot 3 exactly.

## Fix
Added the same aggregate-overlay pattern already used in the Analyzer's
Vendor tab to `_draw_ci_linked_vendor_energy()`: when `replay.spectral_replay`
is present, compute Band0/Band1 energy directly from it
(`self.spectrum_evidence_repository.hydrophone.band_energy(spectral, low,
high)`, band ranges from `.standalone.resolved_band_ranges(...)`) and plot
each as a separately-named curve ("SpectrumMsg aggregate Band0/Band1 (full
timeline; no RCV identity)"), additive to the existing physical curves.

## Verified against the real 220 kHz export
```
Band0: points=75/75  time_range=(9.078, 29.040)  sonication_end=29.149
Band1: points=75/75  time_range=(9.078, 29.040)  sonication_end=29.149
```
Both bands now cover essentially the full Sonication (within ~0.1 s of its
end), matching the same near-complete coverage already confirmed for the
Analyzer's own aggregate overlay in earlier commits.

650 kHz data (no `spectral_replay`) confirmed unaffected: the new overlay
code is skipped entirely (`spectral is None`), so the pre-existing
physical-only curves render exactly as before
(`vendor_band0_weighted`: 1721/1721 finite samples, unchanged).

## Tests
`tests/test_r0160_ci_linked_vendor_aggregate_overlay.py`:
- static check that the aggregate overlay block is present, sources
  `spectral_replay`/`resolved_band_ranges`/`band_energy` correctly, and
  both new curves are named distinctly from the physical ones.
- static check that the original physical-only curves are still drawn
  (additive, not a replacement).
- static check that a failure in the overlay is logged, not swallowed.

Existing R0155/R0156/R0157/R0159 tests re-verified passing.
`verify_source.py` re-run against the packaged, re-extracted
`Soni_SOURCE_R0160.zip` -> `VERIFY_SOURCE_OK`. Confirmed no repeat of the
R0158 duplicate-tree packaging mistake: exactly one
`insightec_build_contract.json` inside the extracted package.
