# R0063 — Persistent Registration Checkbox + Dense Bone Overlay

- Registration control moved to a persistent top-right checkbox in the image navigator.
- Checked state remains retained while browsing non-reference images and resumes on planning/preplanning MR.
- Registered CT rendering now preserves the high-density skull/bone body plus an emphasized rim instead of reducing the CT to a thin contour only.
- Registration still suppresses the overlay when patient-coordinate CT/MR geometry is unavailable; no fabricated alignment is introduced.
