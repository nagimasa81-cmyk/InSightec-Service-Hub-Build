# Triple Check R0163

1. Parser compatibility: Brain650 `ExciterPower` and Brain220 `ExciterElectricalPower` are both accepted by `_SET_RE`.
2. Architecture regression: CI aggregate Band0/Band1 remains sourced from repository cached secondary products; no MainWindow `band_energy()` recomputation was reintroduced.
3. Cursor regression: R0159/R0160 vendor/control physical-frame mapping guards remain present.

Validation:
- `python -m compileall -q main.py src tools tests` PASS
- `python verify_source.py` -> VERIFY_SOURCE_OK
- focused integration suite -> 17 passed
