# Sonication Replay Engine R0024a — Triple Check Report

## Result
PASS with one environment limitation: PySide6 is not installed in this Linux validation runtime, so the Qt GUI test cannot execute here. Static Qt wiring, source compilation, non-GUI regression, real Export inspection, and source verification passed.

## Check 1 — Source / Build / Metadata
- Python compileall: PASS
- verify_source.py: PASS
- Build contract updated to release_sequence 24 / source rc7.2-r0024a
- VERSION / version.json / APP_VERSION / APP_COMMIT synchronized
- Existing R0023 Spectrum Dump Import retained
- ZIP path traversal protections retained

## Check 2 — Internal Connections
- Importer -> DiscoveryService -> FUS Export Core -> SonicationModel: connected
- Sonication selection -> Export/Replay Status refresh: connected
- Thermometry fields -> Thermometry Data workspace: connected
- ACT / Skull logs / Mesh -> Elements & Skull workspace: connected
- All sonications including PARTIAL -> Comparison workspace: connected
- PARTIAL does not block Replay: confirmed by control flow
- Sonication1 planning/reference inheritance supports `Sonication1` and `Sonication 1` naming
- Spectrum Dump Analyzer action remains connected
- CPC 8CH decoder remains separate from Sonication SpectrumMsg

## Check 3 — Regression / Real Data
- Non-GUI pytest: 60 passed
- Old TMAP Export: 6/6 COMPLETE; Hybrid; TMAP (Single Echo)
- Partial Export: Sonication8 = PARTIAL 72%; usable streams retained; missing Thermometry and Dose reported; Reference motion inherited
- Sonication10 SpectrumMsg structure: Exact=True, Frames=67, FrameSize=200640, ContainerChannels=8, Header=272
- Sonication10 Replay decoder: 67 frame-bounded spectra returned even though expanded payload > 8 MB

## Spectrum accuracy clarification
The SpectrumMsg container header reliably reports 8 channels. Current evidence does NOT prove that each frame payload can be split into eight equal contiguous FFT blocks. R0024a therefore does not fabricate 8 individual SpectrumMsg channels. Exact frame boundaries are honored; detailed channel payload mapping stays unresolved until validated. CPCFiles 8CH decoding remains the independent validated 8-channel path.

## Environment limitation
`tests/test_r0015_circular_roi_measurement.py` requires PySide6. It cannot be collected in this Linux runtime because PySide6 is absent. The test remains in the source and should run on the Windows/GitHub build environment where application dependencies are installed.
