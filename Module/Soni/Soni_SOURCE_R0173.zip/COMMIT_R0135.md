# R0135 — CPC preload / Power / Cavitation data-chain hardening

## Fixed
- Declared `sonication_index` on slotted `CpcHydrophoneReplay`; repository preload can now assign stable semantic ownership without `AttributeError`.
- Wrapped-export Acquisition fallback now recursively counts `SonicationN` folders, binding 8 treatment Sonications to Acquisition sessions 8–15 in the 15-session real export instead of early DQA/calibration sessions.
- Treatment Outcome / Summary fallback uses the already-resolved CPC candidate Acquisition session if Spectrum decode is unavailable; it no longer lets the timeline parser choose the event-richest session arbitrarily.
- Package-root control-timeline lookup now recursively finds `Acquisition_Brain_*.txt` inside wrapper/CPCFiles layouts.
- Exact candidate `mapping_confidence` / `mapping_evidence` is copied to decoded replay objects.
- A missing authoritative timeline is no longer silently converted into a negative cavitation finding.

## Real-data verification
Dataset: `17-00-24_ANx(5).zip`
- Spectrum candidate mapping: Sonication 1–8 -> Acquisition sessions 8–15, all Exact.
- Full CPC replay decode succeeded for all 8 Sonications.
- Decoded FFT frame counts: 33, 34, 34, 37, 11, 45, 48, 67.
- Sonication 5: `CAVITATION HALT ×1 · control responses ×2`.
- Sonication 6: `CAVITATION HALT ×1 · control responses ×25`.
- PowerGraph native endpoints follow each Sonication duration, including Sonication 5 ending at 1.989864 s.
