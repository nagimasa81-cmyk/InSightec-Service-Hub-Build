# R0154ak — Summary/data-domain lifecycle repair

- Separates the SpectrumMsg hydrophone timeline from the physical CPC control-history timeline throughout loading and presentation.
- Publishes one Sonication at a time from the study-owned repository, so Summary can begin deterministically without waiting for unrelated rows or another tab.
- Starts Summary detail and thermometry as independent background owners; opening Summary itself initiates visible progress and complete-data enrichment.
- Makes secondary visualization failures non-fatal to valid decoded Spectrum evidence.
- Uses the complete aggregate SpectrumMsg frame count for Spectrum sliders/spinners in composite replay.
- Rejects named, exactly bound nonthermal MR series before RAW decoding and Celsius classification.
- Merges CPC Rule 1 into only missing Acquisition Score samples and keeps the fallback inside measured CPC coverage.
- Extends Import Diagnostics v2 with per-Sonication thermometry decisions and separate acoustic/control coverage.

The supplied `18-30-47` Export was used as a regression fixture. It is a different study instance from the photographed/diagnostic `20-25-58` Export, so exact reproduction of the photographed Sonication 1 temperature remains contingent on that original Export.
