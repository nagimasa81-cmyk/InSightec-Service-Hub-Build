# R0154aj — single-owner data lifecycle repair

- Removes Analyzer tab navigation as a secondary-analysis trigger. Loaded Exports are computed only by the automatic study preload; tabs bind immutable cached arrays.
- Prevents Sonication selection from cancelling and restarting the already-running all-Sonication preload for the same Export.
- Keeps SpectrumMsg as an aggregate source instead of placing it in a fake RCV0 column. Aggregate Band Energy is carried separately and plotted regardless of the selected physical RCV.
- Uses the complete SpectrumMsg/PowerGraph time series for Brain220 Band Energy and spectral cavitation analysis while preserving CPC for physical 8CH and controller evidence.
- Adds product-level failure containment so one Spectrogram/Cavitation failure does not discard valid Band Energy or control products.
- Fills a missing Brain220 Score percent from the validated saved CPC Display Rule 1 response; explicit Acquisition Score remains authoritative when present.
- Fixes Import Diagnostics ZIP completion so all dialogs and controls are updated on the GUI thread after the worker thread exits.
- Makes Spectrogram publication depend on decoded data, not the previous Sonication's remembered frequency-range controls.
- Locks the Power/Score viewport to the canonical MR acquisition duration so thermometry pre-roll cannot shift or truncate it.
- Verified the supplied diagnostics contract: seven mapped Sonications, with treatment windows 7.6–~27.65 s (1–4), 7.6–10.62 s (5), and ~50 s acquisition timelines (6–7).
