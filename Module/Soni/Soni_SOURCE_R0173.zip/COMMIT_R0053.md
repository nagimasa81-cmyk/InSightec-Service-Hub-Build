# R0053 — Replay Cavitation Intelligence Workspace

- Adds a top-level **Cavitation Intelligence** tab directly beside Replay.
- Adds a toolbar entry for one-click access without changing Replay frame/sonication state.
- Makes the analysis chain explicit: Event → RCV → Band/Energy → MR Signal → Probable Location → Skull Class → Power Response.
- Adds large RCV likelihood and MR magnitude correlation panels.
- Adds a synchronized nearby-event evidence table.
- Keeps Observed vs Reconstructed provenance explicit and does not claim skull classification until registered CT geometry is available.
- Reuses the existing Replay cavitation services so the dedicated page remains synchronized to the current Sonication/frame.
