# R0126 — Selected CPC measurement-history FFT + Band0 analysis

## Scope
Extends Spectrum Dump Analyzer > Measurement Timeline / Raw A/D selected-range analysis to processed CPC measurement history when per-measure Raw A/D is absent.

## Behavior
- `FFT range selection` is available for either validated Raw A/D or validated CPC 8CH measurement/Band0 history.
- If Raw A/D exists, the R0125 acoustic Raw FFT path remains preferred and unchanged.
- If Raw A/D is absent but validated CPC history exists, `FFT + Band0 selected range` computes a temporal FFT of the selected history interval.
- The history FFT x-axis is temporal modulation frequency in Hz; it is never presented as acoustic frequency in MHz.
- The same selected interval produces per-RCV Band0 statistics: mean, RMS, median, standard deviation, min, max, peak-to-peak, P95, and dominant temporal FFT frequency.
- Missing values or large time gaps are rejected rather than interpolated.
- Existing R0124 pan/zoom and R0125 Raw FFT behavior remain intact.
