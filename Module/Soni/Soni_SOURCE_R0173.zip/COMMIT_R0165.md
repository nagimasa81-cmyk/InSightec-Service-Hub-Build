# R0165 — Fix: every Sonication's observed Control Timeline collapsed onto one session

## Evaluation that found this
Asked to evaluate whether Spectrum Dump Analyzer correctly displays each of
Sonication1-7 (real 7-Sonication Brain220 export). Ran every Sonication
through the full pipeline (replay build, spectral aggregate coverage,
thermometry, observed Control Timeline) and compared results side by side.

`aggregate_band_energy`/`aggregate_time_s` (R0160/R0162/R0163/R0164 work)
were all correct and distinct per Sonication. But the observed Control
Timeline's sample **count** was suspiciously identical across all 7
Sonications (701 points each) despite each Sonication legitimately having
a different physical CPC recording window and duration.

## Root cause
Three call sites resolve which Acquisition_Brain session to parse:
```python
preferred_session = history_validation.log_session_index if history_validation is not None else getattr(replay, "acquisition_session_index", None)
```
`history_validation` (`vendor_history_validation`) is a real, non-None
object for essentially every Sonication -- even when its own
cross-validation against the log didn't reach "EXACT" (status=
"INI-derived", the same validation-status distinction already understood
from R0162). The condition only tested whether the *object* existed, not
whether its `log_session_index` was usable. So `history_validation is not
None` was `True` for all 7 Sonications, `history_validation.log_session_index`
was `None` in every case, and the correct fallback
(`replay.acquisition_session_index`, which genuinely differs -- confirmed
32, 33, 34, 35, 36, 37, 38 for the 7 real Sonications) was **never**
reached. `CavitationControlTimelineService.parse()` then auto-selected
"whichever session has the most events" for every Sonication -- silently
showing the *same* one Sonication's observed ExPowerRatio timeline (and
any Decrease/Safety events) on all seven, and on `_current_control_time()`'s
cursor mapping / the observed-cavitation-event highlight that consume the
same timeline.

## Fix
All three sites (`hydrophone_window.py`'s
`_build_observed_cavitation_timeline_for_replay`,
`spectrum_evidence_repository.py`'s `_observed_control_timeline`,
`sonication_summary_cavitation_evidence_service.py`'s inline construction)
now check the *value*, not just object existence:
```python
preferred_session = getattr(history_validation, "log_session_index", None) if history_validation is not None else None
if preferred_session is None:
    preferred_session = getattr(replay, "acquisition_session_index", None)
```

## Verified against the real 7-Sonication Brain220 export
| Sonication | session (before) | session (after) | points (before) | points (after) |
|---|---|---|---|---|
| 1 | None -> auto | **32** | 701 | 698 |
| 2 | None -> auto | **33** | 701 | 700 |
| 3 | None -> auto | **34** | 701 | 701 |
| 4 | None -> auto | **35** | 701 | 698 |
| 5 | None -> auto | **36** | 701 | 700 |
| 6 | None -> auto | **37** | 701 | 700 |
| 7 | None -> auto | **38** | 701 | 700 |

Each Sonication now resolves its own distinct Acquisition_Brain session
(matching the diagnostics-reported `canonical_acquisition_session_index`
values from the earlier investigation) and its own distinct point count,
instead of all seven collapsing onto whichever single session happened to
have the most events.

## Tests
`tests/test_r0165_session_index_fallback_reaches_acquisition_index.py`:
- the stale "object exists implies value is usable" pattern is gone from
  all three sites.
- all three sites now contain the corrected two-step fallback
  (`if preferred_session is None: preferred_session =
  replay.acquisition_session_index`).

Full test sweep re-run: 1102 passed (unchanged from the R0164 baseline);
the same 11 pre-existing, unrelated failures remain (confirmed by earlier
grep to reference none of this session's changed files).
`verify_source.py` re-run against the packaged, re-extracted
`Soni_SOURCE_R0165.zip` -> `VERIFY_SOURCE_OK`. No repeat of the R0158
duplicate-tree packaging mistake: exactly one
`insightec_build_contract.json` inside the extracted package.
