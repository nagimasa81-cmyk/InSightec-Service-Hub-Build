# R0071 — Vendor Skull Mask Registration

- Deep-dived the complete treatment export for the workstation bone overlay pipeline.
- Confirmed Field 16 CT RAW is signed little-endian int16 HU (real data: air around -3024 HU).
- Fixed the core Field 16 semantic label from uint16 to int16 HU.
- Reads exported `BrainApp.ini` bone thresholds, preferring `[BrainACT] LowBoneThreshold` and exported high-bone threshold.
- Builds the skull mask in native CT space before any registration interpolation.
- Rejects small isolated high-density components so intracranial calcification/noise is not treated as skull.
- Reslices the binary skull mask into MR patient coordinates using the exported `CtMr_mat.txt` and `MriImageParams.xml` geometry.
- Removes the previous failure mode where negative CT HU interpreted as uint16 could become ~62k and paint non-bone regions green.
- Increased overlay visibility with a brighter light-green body and rim.
- Evidence found in the full export: `RegistOverlays#OvrBone=ON`, `ReplayOverlays#OvrBone=ON`, `BrainACT#SlicesDir=local\log\SkullSlices`, `BrainACT#LowBoneThreshold=500`, `BackgroundEliminationInit#HighBoneThreshold=5000`, and 8192 `actelement.xml` rows (1024 elements × 8 sonications) containing skull thickness/intensity/SDR data.
