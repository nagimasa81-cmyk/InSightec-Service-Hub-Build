# R0139 — Import completeness contract and nested ZIP evidence preservation

## Root cause addressed
R0138 could discover many CPC Spectrum candidates while producing a ReplayPackage with fewer Sonications and no authoritative CPC mapping. The failure surfaced late in Spectrum preload as `0/N mapped`, which hid whether the root problem was mapping itself or evidence loss during ZIP import/package construction.

## Changes
- Recursively expands nested ZIP evidence while preserving each original nested archive.
- Uses the same path-safety and password/AES extraction rules for nested packages.
- Fails explicitly if a real nested ZIP cannot be completely materialized instead of silently dropping its contents.
- Adds `ImportCompletenessService`, auditing:
  - numbered Sonication folders
  - ReplayPackage Sonication count
  - SonicationSummary indices
  - spotsonicationdata indices
  - SpectrumMsg count/identity
  - physical CPC candidate count
  - Acquisition_Brain session count
  - Sonication_Brain setup count
  - canonical Acquisition session resolution count
  - authoritative CPC mapping count
- Stores the audit on `ReplayPackage.import_audit`.
- Spectrum preload mapping errors now include the upstream audit summary and first concrete causes.
- Package loading progress displays the audit result before the UI is published.
- Spectrum / 8CH Hydrophone Analyzer title now follows the common application version rather than hard-coded R0133.

## Principle
No positional or latest-N CPC fallback was added. R0139 makes missing evidence visible; it does not manufacture an authoritative mapping when canonical evidence is absent.
