# R0116zd Triple Check / Regression Gate

## Pass 1 — source-binding integrity
- Real Golden Export has 13 physical CPC Spectrum pairs and 8 treatment Sonications.
- R0116zc candidate mapping returned zero when counts differed; R0116zd maps the latest 8 treatment pairs, matching the established legacy selector.
- MainWindow CPC consumers no longer call `build(package.cpc_spectrum_files, ...)` directly. Summary, RCA, Cavitation Intelligence and CPC replay use one `_resolve_cpc_pair()` / `_build_cpc_replay()` path.
- SpectrumMsg is excluded from the physical 8CH treatment mapping.
- Background preload publishes Ready only when decoded frames are non-zero.
- Cached preload is accepted only for the requested Sonication index; otherwise a worker preload is started and Analyzer stays navigable.
- Selecting the already-loaded Export ZIP in Spectrum Analyzer reuses Main Replay workspace rather than extracting it again.

## Pass 2 — ancestor/regression integrity
- Full non-GUI regression suite: 431 PASS.
- Focused registration/loading/spectrum/control suite: 36 PASS.
- MainWindow and EightHydrophoneWindow duplicate-method AST audit: zero duplicates.
- `verify_source.py`: PASS.
- Python compileall: PASS.
- Registration code was not relaxed or replaced in this revision. Exported CtMr/MrMr chain and current-slice QA remain deterministic. A bone overlay suppressed as `outer-skull geometry disagreement` is therefore a QA rejection, not silently treated as a successful registration.

## Pass 3 — real Export execution
Validated against the already-extracted `10-00-09_ANx(1).zip` workspace.
- 13 physical CPC pairs discovered.
- 8/8 treatment Sonications mapped.
- 8/8 mapped FFT pairs decode non-zero frames.
- 8/8 report `EXACT vendor Band0 history`.
- 8/8 report `EXACT control reproduction`.
See `VALIDATION_R0116zd_REAL_EXPORT.txt` for exact file names and frame counts.

## Known validation boundary
The Linux audit environment does not have PySide6, so the one PySide6 circular-ROI GUI test cannot be collected here. This revision therefore does not claim a live Qt screenshot test. The source-level progress-window wiring is preserved, and all non-GUI behavior contracts pass.
