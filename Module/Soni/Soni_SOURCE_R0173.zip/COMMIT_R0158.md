# R0158 — Fix: packaging bug, duplicate `soni154ak/` source tree removed

## Root cause (identified by the user, not by me)
The GitHub Actions "Repository contract audit" step kept failing with
`"Expected exactly one contract, found 2"` against `Soni_SOURCE_R0157.zip`
even after removing an unrelated stray `build_work/` leftover from the
repository. The actual cause was in **my own packaging process**, not the
repository:

The original `Soni_SOURCE_R0154al.zip` (the source ZIP first provided at
the start of this investigation) already contained a full, duplicate copy
of an older source tree nested at `soni154ak/` -- complete with its own
`src/`, `tests/`, `tools/`, `build/`, `docs/`, and (critically) its own
`insightec_build_contract.json`. All of my edits since then (R0155 through
R0157) correctly targeted the top-level source tree via relative paths
(e.g. `src/services/mr_timeline_service.py`), and every `verify_source.py`
run passed because it only checks the top-level files. But the nested
`soni154ak/` directory was never touched, and every subsequent package
(`zip -r ... .` run from the same working directory) silently swept it
back in -- giving every R0155/R0156/R0157 deliverable two complete,
independent source trees (and two `insightec_build_contract.json` files)
in one ZIP.

## Fix
Deleted `soni154ak/` entirely from the working tree. Verified directly
inside the rebuilt ZIP (not just the working directory) that exactly one
`insightec_build_contract.json` remains:
```
entries matching *insightec_build_contract.json*: 1
total ZIP entries: 875 (down from 1756 in R0157 -- roughly half, consistent
with removing one full duplicate tree)
```
Also re-extracted the rebuilt ZIP into a clean directory and re-ran
`verify_source.py` there (not just in the already-cleaned working
directory) to make sure the packaged artifact itself is clean, not just my
local state: `VERIFY_SOURCE_OK`.

## Tests
No new test added for this specific packaging mistake (it was a build/
delivery-process bug, not a source-code bug -- there is nothing in the
Python source itself to regression-test). All prior R0155/R0156/R0157
tests re-verified passing against the cleaned tree.

## Note on naming
`Soni_SOURCE_R0158.zip` uses this conversation's version-bump convention
(no source-code change this time, only the duplicate-tree removal) so the
GitHub `Module/Soni/` upload gets a distinct, non-colliding filename per
the earlier "always change the filename" request.
