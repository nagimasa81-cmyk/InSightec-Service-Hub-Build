# R0032 — Vendor Multi-Band Cavitation Reconstruction

- Preserves R0031 exact Band0 reconstruction from saved 8CH CPC history.
- Parses all numeric Acquisition Display Rules without treating `-1.#IND` as a valid value.
- Reconstructs combined Band1 energy exactly from `Display Rule 2 × MaximumEnergyForAllHydrophones (0.018)` for the matched acquisition session.
- Reconstructs exact sparse Band2 energy events from `Decrease Power Rule 4/5` Calculated Energy on threshold-crossing cycles.
- Adds explicit evidence classification in the CGA Cavitation tab:
  - Band0: exact continuous saved history + independent log validation.
  - Band1: exact continuous combined energy from vendor Display Rule 2 log output.
  - Band2: exact sparse event values from vendor control-rule logs.
  - Band3: frequency definition confirmed; no active rule provides an exact energy history in this configuration.
- CGA Cavitation UI now overlays Band0/Band1/Band2 evidence and Display Rule 1/2 on acquisition time.
- Adds `validate_vendor_multiband_reproduction.py` and focused regression tests.
