# R0074 — Legend View-State Preservation

- Individual Cavitation Control legend checkboxes now change only series visibility.
- Current X/Y zoom ranges are captured before redraw and restored afterwards.
- Legend toggles no longer invoke autoRange, preserving zoom/pan during inspection.
- Other view/mode changes retain their existing auto-range behavior.
