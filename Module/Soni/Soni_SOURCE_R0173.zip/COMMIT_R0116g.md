# R0116g — Build Smoke / Navigation Scope Fix

Build_Diagnostics_Soni_16.zip showed startup failure:
`AttributeError: 'MainWindow' object has no attribute 'next_frame'`.

Root cause:
R0116e added `_array_preview_pixmap` at module scope instead of MainWindow class scope.
That unintentionally ended the `MainWindow` class at `_frame_time_axis`.
All methods following it — including `_array_icon`, `previous_frame`, `next_frame`,
`toggle_play`, speed/navigation handlers, keyboard/wheel handlers and later UI methods —
became nested inside `_array_preview_pixmap` and were not members of MainWindow.

Fix:
- Restored `_array_preview_pixmap` to MainWindow class scope.
- Restored every following method to MainWindow scope without changing its behavior.
- Preserved R0116f Increase-default-hidden behavior and earlier thumbnail/registration/3-D fixes.
- Added AST regression tests for class-scope integrity.
- compileall PASS.
- navigation scope tests PASS.
- duplicate MainWindow method audit PASS.
