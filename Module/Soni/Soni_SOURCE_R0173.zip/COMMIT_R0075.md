# R0075 — Thumbnail Scrollbar + Preplanning Registration Chain

- Adds an explicit horizontal scrollbar below each thumbnail row so all series images can be browsed even when QListWidget hides its native scrollbar.
- Keeps image-number drop-downs removed.
- Fixes a registration-path bug: Preplanning MR now evaluates CtMr + MrMr matrix chains rather than applying CtMr directly to a preplanning target.
- Keeps direct CtMr hypotheses for treatment-day Planning MR.
- Registration status reports the selected matrix chain and direction.
