# R0116zzg1 — Cavitation response semantics / irradiation-end default

- Treat every observed `Decrease` and `Safety` control response assigned to a Sonication as a cavitation event. `Increase` remains non-cavitation.
- Make the shared canonical Cavitation Status include Decrease/Safety even when older timing/threshold classification left `counts_as_cavitation=False`.
- Default a newly selected Sonication to the replay frame nearest the irradiation-end marker instead of frame 1.
- Keep Thermal/MR, Spectrum, Power/Score and cavitation-linked displays on that single synchronized end-of-irradiation cursor.
- Prevent the lazy image navigator from resetting the cursor to the first available MR frame.
- When Spectrum Dump Analyzer is bound to a loaded Sonication, publish the FFT snapshot nearest irradiation end; standalone SpectrumDumps without treatment timing retain the first-frame default.
- Added regression coverage for the cavitation contract and initial replay/Spectrum cursor behavior.
