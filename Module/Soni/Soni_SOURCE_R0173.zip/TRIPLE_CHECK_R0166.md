# TRIPLE_CHECK_R0166

## Pass 1 — Static re-read of the fix itself
- Re-read `mr_raw_timeline_time_s` and `_acquisition_times_to_sonication`
  in full: both match the intended fix exactly (index-as-cycle-number
  mapping removed entirely from the first; the second now guards
  extrapolation to <= 5x the fitted domain, falling back to a plain
  offset otherwise).
- Searched the whole codebase for every other call site of `_cycles_to_mr`
  and `cycles_to_mr_times` to rule out the same anti-pattern (fabricated
  index passed off as a real absolute cycle number) existing elsewhere:
  - `mr_frame_times_s` / `sonication_frame_times_s`: use
    `f.acquisition_cycle` -- a real, decoded per-frame cycle number. Safe.
  - `hydrophone_window.py:2876` (observed-event highlight) and
    `main_window.py:3927` (CI-linked control plot): both pass
    `ev.cycle` / `validation.event_cycles` -- real event cycle numbers
    from vendor/control validation, not fabricated indices. Safe.
  - No other site does what the removed code did. This was an isolated
    defect, not a systemic pattern.

## Pass 2 — Behavioral re-verification against the real 7-Sonication Brain220 export
Re-ran the full pipeline for all 7 Sonications and checked, per Sonication:
monotonicity of `mr_raw_timeline_time_s`, physically reasonable bounds
relative to that Sonication's own start/end, and that
`vendor_band0_weighted` (the actual plotted series) is fully finite and
sized to match.

```
Son          raw_t_min raw_t_max son_start   son_end vb0_size vb0_finite  monotonic
Sonication1       9.07     16.04      9.07     29.15      698        698       True  OK
Sonication2      10.10     17.09     10.10     30.14      700        700       True  OK
Sonication3       9.66     16.66      9.66     29.73      701        701       True  OK
Sonication4      10.07     17.04     10.07     30.12      698        698       True  OK
Sonication5      10.05     17.04     10.05     13.07      700        700       True  OK
Sonication6       4.49     11.48      4.49     54.57      700        700       True  OK
Sonication7       3.52     10.51      3.52     53.55      700        700       True  OK

ALL SONICATIONS WITHIN PHYSICALLY REASONABLE BOUNDS: True
```
All 7/7 pass. No Sonication's Vendor/Raw-history timeline extends past a
small, physically sane margin beyond its own reported end.

## Pass 3 — Full regression sweep + packaged-artifact re-check
- Full test sweep (cache cleared first): **1107 passed**, same 11
  pre-existing/unrelated failures as the R0164/R0165 baseline (all
  confirmed to reference none of the files touched by R0166), same 4
  environment-limited errors (missing `pyzipper`/`pytest.approx`/shim
  gaps), same 2 PySide6/pyqtgraph import-skips. No new failures introduced.
- Re-extracted the delivered `Soni_SOURCE_R0166.zip` into a clean
  directory: exactly **one** `insightec_build_contract.json` (no repeat of
  the R0158 duplicate-tree mistake), `verify_source.py` -> `VERIFY_SOURCE_OK`.

## Investigated but not resolved in this session
Traced the still-blank "Vendor band energy reproduction" panel
(screenshot 5, MainWindow's Cavitation Intelligence tab) to its actual
source: `_update_ci_linked_panel()` reads `replay =
self.default_cpc_replay`, a separate cached replay reference that is
supposed to be kept in sync with the selected Sonication by
`_prepare_default_cavitation_intelligence()` whenever the Spectrum for
that Sonication is ready. The wiring that keeps it in sync looks correct
by inspection, but confirming whether it was actually refreshed for
Sonication2 at the moment that screenshot was taken is a live Qt
event-timing question (e.g. preload-in-progress vs. already-ready) that
this sandbox cannot exercise without PySide6. This is a known limitation
of this triple-check, not a confirmed defect -- worth re-checking directly
against a rebuilt executable.

## Verdict
R0166's fix is confirmed correct and complete for the defect it targets
(Vendor/Raw-history timeline stretching to ~130-400 s) across all three
independent verification passes, with no regressions and no repeat of the
prior packaging mistake. The one remaining open item (blank Vendor panel
for a specific Sonication) is explicitly flagged as unverified rather than
claimed fixed.
