# R0041

UI regression fix for CGA Cavitation / Vendor Rules. The previous all-vertical layout allowed descriptive content and tables to squeeze the lower graphs until they were effectively invisible. R0041 compacts non-chart content, places the two upper charts horizontally, and reserves visible height for the control-response chart.
