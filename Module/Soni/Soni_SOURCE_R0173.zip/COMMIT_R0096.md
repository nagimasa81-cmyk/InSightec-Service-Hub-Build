# R0096 — Unified Three-Way Cavitation Display

- Removed the entire upper Cavitation Intelligence image/graph area.
- All visual evidence is now in the lower Linked Cavitation Analysis selector.
- Three lower choices:
  1. RCV Contribution + probable cavitation region
  2. Vendor band energy reproduction
  3. Cavitation control response + CGA / Acquisition Display Rule
- Default selection is option 3 (CGA/control).
- RCV contribution and probable cavitation region are shown side-by-side in one view.
- Existing event list, persistent event-time marker, cached dropdown switching, Why popup, R0093 Power/Score behavior, and R0091/R0092 state-integrity fixes are preserved.
