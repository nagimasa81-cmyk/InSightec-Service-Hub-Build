# R0116zzg2 — post-100% load freeze fix

- Preserve the R0116zzg1 irradiation-end default cursor.
- Programmatic startup/frame-cache callbacks use `defer_heavy=True`.
- `set_frame()` no longer rebuilds hidden Analysis or Cavitation Intelligence panels.
- Analysis plots refresh when Analysis is opened; Cavitation Intelligence remains on-demand.
- This removes the GUI-thread workload that could start immediately after the load progress reached 100%.
