# R0019 — Hydrophone Spectrum Calibration Audit

- Preserves raw CPC FFT amplitudes and calibrated amplitudes independently.
- Adds Raw / Calibrated / Overlay / Relative dB spectrum modes.
- Displays SpectrumCoef, CH0–CH7 SpectrumFactor, response-point count, and coefficient at sonication frequency.
- Removes unsupported SpectrumMsg `frame_index % 8` channel mapping.
- Applies SpectrumMsg channel calibration only when an explicit channel is found in Sonication configuration files.
- Marks unknown mappings as calibration-not-applied.
