# Triple check R0164

1. Brain220 and Brain650 Acquisition_Brain Set-line parser parity.
2. Selected-Sonication X-axis default vs explicit full-MR inspection.
3. Preload lifecycle: one study owner, no post-completion GUI restart loop.
4. Thermometry: no cross-Sonication coefficient fitting; spatial coherence only.
5. R0162 single-owner aggregate and R0160 cursor guards retained.
