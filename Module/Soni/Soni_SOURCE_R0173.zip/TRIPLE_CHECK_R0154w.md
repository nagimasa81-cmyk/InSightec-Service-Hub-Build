# R0154w Triple Check

## Check 1 — ancestry / overwrite
- SOURCE identity synchronized across VERSION, constants.py, version.json, build contract and Nuitka build scripts.
- Python bytecode, pytest cache and other generated cache directories removed from the SOURCE package.
- No duplicate function/class definitions exist inside the same module/class scope in `src/`.
- Functional delta from R0154u is restricted to the intended DQA and CPC timing paths plus the hydrophone timing provenance UI.

## Check 2 — timing / cavitation contamination
- R0154v was found to rewrite `frame.acquisition_cycle` while claiming to repair display timing only.
- This could contaminate cavitation/rule correlation because acquisition_cycle is consumed outside the Spectrum display.
- R0154w removes that overwrite. Original decoder cycle evidence is preserved.
- Only `frame_mr_time_override_s` changes the repaired MR display axis.
- Added regression: collapsed timing repair must not alter original acquisition_cycle values.

## Check 3 — regression / stale tests
- Updated two stale historical assertions that were testing obsolete hard-coded release/orientation values rather than the current contract.
- Non-GUI suite: 1027 passed, 1 skipped (`pyzipper` unavailable).
- Focused Brain220/DQA/Spectrum suite: 24 passed.
- Full GUI collection is not runnable in this Linux environment because PySide6 is not installed; this is an environment limitation, not a discovered test failure.
- `verify_source.py`: PASS.

## Result
R0154v is superseded by R0154w for validation/build. Do not build R0154v.
