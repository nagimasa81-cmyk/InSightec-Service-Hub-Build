# R0168 Triple Check

1. Main/Analyzer time-domain check: Linked CI prefers `mr_sonication_end_s`; Analyzer R0164 default remains Sonication end.
2. Data readiness check: Linked CI cache fingerprint includes repository aggregate time/band readiness and is invalidated on authoritative handoff.
3. Regression check: R0164-R0167 focused suite plus R0168 tests passes; no tab-owned decode path was added.

Thermometry: this revision adds source-frame diagnostics only. It does not force Sonication1 temperature toward neighboring Sonications without raw-frame evidence.
