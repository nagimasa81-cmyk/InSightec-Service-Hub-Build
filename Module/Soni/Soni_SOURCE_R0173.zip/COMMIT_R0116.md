# R0116 — RCV Disable / Image Slider / Focus / Registration Integration

- Calibration.ini `IsEnabled=0` is the authoritative RCV disable mask.
- Disabled RCVs are hidden by default from Raw, Spectrum, Band Energy, Vendor/CGA receiver curves, exact snapshot receiver points, receiver selectors and standalone cavitation candidate analysis.
- `Show disabled RCV` is the only opt-in that exposes them.
- Vendor legend RCV cells are hidden with their disabled curves.
- Thumbnail navigation is a real image-index QSlider (0..N-1), independent of QListWidget pixel-layout range.
- Reference thumbnails reuse cache and background workers start after the UI becomes interactive at LowPriority.
- 3-D reference/phase focus markers use the exact same camera/projection as Element XYZ.
- Exported SkullMeasures FocalPointPos is the primary reference focus; sphere-fit center is fallback/QA only.
- Registration QA still evaluates the complete CT skull, while the user-facing green overlay displays the outer skull envelope to avoid confusing internal skull-base bone with brain-parenchyma overlay.
