# R0170

- Diagnose the apparent early hydrophone cutoff as two different exported domains, not one missing stream.
- Physical CPC 8CH saved history is explicitly labelled partial when appropriate.
- Brain220 composite Analyzer initially opens Band Energy (full Sonication-owned SpectrumMsg timeline) only when the untouched default Measurement tab is still selected.
- Source handoff displays both physical CPC history sample count and SpectrumMsg full-stream frame count.
- No physical RCV identity, Raw A/D, Rule/Score, or amplitude scale is synthesized for SpectrumMsg.
- R0169 on-demand CI recovery, Sonication-end axis, repository single-owner behavior, and thermometry diagnostics are retained.
