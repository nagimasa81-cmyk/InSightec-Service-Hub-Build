# R0101 — Registration Matrix Direction Diagnostic

- Compares exported forward matrix and inverse matrix geometrically on the same CT skull point.
- Actual overlay is unchanged and still uses the exported treatment matrix.
- Reports forward/inverse MR pixels and inside/outside FOV.
- Distinguishes matrix-direction suspicion from MR geometry/reference-plane mismatch.
- Adds geometry-only MR reference-candidate ranking helper for subsequent multi-series diagnosis.
- No image-similarity optimization or automatic registration correction.
