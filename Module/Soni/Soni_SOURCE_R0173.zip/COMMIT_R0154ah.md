# R0154ah — Brain 220 geometry, full timeline, DQA and thermometry repair

- Converts native transducer Z to the workstation umbrella basis once for both
  elements and all focus markers.
- Binds exact-count SpectrumMsg FFT records to authoritative Workstation
  PowerGraph timestamps, preserving the complete irradiation interval.
- Resolves counterless Brain 220 setup logs by binding the final treatment setup
  block one-to-one to exported Sonications before series-common DQA analysis.
- Keeps Replay's diagnostic single-pixel Max curve, but derives Summary Peak/ΔT
  from the median of the hottest three target-ROI pixels to reject isolated
  thermometry outliers.
- Preserves R0154ag Brain 220 Power/Score parsing and sparse-score hold behavior.
