# R0024b — Workstation Replay Frequency Source Fix

- Replay frequency is now read from the per-sonication `frequency` field in `SonicationSummary.xml`.
- This is the same sonication information source that supplies target/actual power, duration, and energy.
- `SkullHeating` frequency is retained only as skull-model information and never overrides Replay frequency.
- `Xd_*.ini` is retained as transducer/reference information and only legacy-fallback discovery when SonicationSummary has no usable frequency.
- Added numeric compatibility for summary values stored as Hz, kHz-like, or MHz-like numbers.
- Validated against a real export: all six SonicationSummary rows decoded with 670000 Hz.
