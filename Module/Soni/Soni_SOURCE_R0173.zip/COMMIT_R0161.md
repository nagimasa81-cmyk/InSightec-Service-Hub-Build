# R0161 — Integrate independent triple-check: restore cycle/cycles deleted by R0159

## Source of this fix
User uploaded a copy of `Soni_SOURCE_R0160.zip` back for comparison. Diffing
it against this session's own R0160 working tree showed it was not
identical: it additionally contained `TRIPLE_CHECK_R0160.md` and a
different regression test (`test_r0160_cursor_mapping_runtime_guards.py`),
neither authored in this session. That triple-check documents a real bug:

> "Runtime-regression audit: restored `cycle` / `cycles` definitions
> accidentally deleted in R0159; added dedicated guards so a future
> textual replacement cannot silently recreate the NameError."

## Verified against this session's own R0159/R0160 source
Confirmed directly: R0159's edit to replace the old physical-frame clamp
with `self._physical_frame_index()` in two places
(`_current_control_time()` and the observed-cavitation-event highlight
inside the timeline loader) accidentally deleted the
`cycle=getattr(frame,"acquisition_cycle",None)` /
`cycles=np.asarray(...)` assignment lines that used to sit immediately
after the frame lookup -- while the very next line in both functions still
reads `cycle`/`cycles`. This is a real, self-introduced regression in this
session's own R0159 delivery (`COMMIT_R0159.md` claimed both sites were
"fixed"; the *domain* fix was correct, but the accompanying edit silently
dropped two required variable definitions), producing an uncaught
`NameError` the first time either function actually ran, not merely a
domain mismatch.

## Fix
Restored both assignment lines exactly where they belong, immediately
after `frame = self.replay.frames[self._physical_frame_index()]` and
before their first use:
- `_current_control_time()`: `cycle=getattr(frame,"acquisition_cycle",None)`
  and `cycles=np.asarray(getattr(timeline,"actual_power_cycles",...))`.
- the observed-cavitation-event highlight:
  `cycle = getattr(frame, "acquisition_cycle", None)`.

## Also integrated
This session's own `main_window.py` R0160 fix (CI-linked vendor panel
Band0/Band1 aggregate overlay) was **not** present in the user's uploaded
copy -- it predates that upload. Kept as-is; nothing to merge there.

## Tests
`tests/test_r0161_restore_cycle_variables_deleted_by_r0159.py`:
- both `cycle`/`cycles` assignments are present and appear (by source
  position) before their first use in each function.
- `_physical_frame_index()` itself remains a genuine nearest-time lookup
  (`st[self.frame_index]` against the spectral/aggregate time axis via
  `np.argmin`), not a regression back to a linear clamp -- this specific
  assertion mirrors the independently-authored triple-check's own test for
  extra cross-validation.

Existing R0155/R0156/R0157/R0159/R0160 tests re-verified passing.
`verify_source.py` re-run against the packaged, re-extracted
`Soni_SOURCE_R0161.zip` -> `VERIFY_SOURCE_OK`. Confirmed no repeat of the
R0158 duplicate-tree packaging mistake: exactly one
`insightec_build_contract.json` inside the extracted package.
