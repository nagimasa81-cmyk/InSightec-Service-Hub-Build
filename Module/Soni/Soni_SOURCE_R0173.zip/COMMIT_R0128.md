# R0128 — FFT range preset restore + Control Timeline layout repair

- Restored an explicit FFT/Band0 analysis Range drop-down while retaining direct mouse-drag selection.
- Range presets: Mouse drag, Visible chart range, MR start→Sonication start, Sonication start→Sonication end, MR start→MR end.
- Rebuilt Control Timeline plot/table area with a vertical QSplitter so lower content cannot be pushed outside the tab viewport.
- Removed conflicting plot/table maximum-height caps from the active Control Timeline path.
- Added delayed nested-tab layout settling on open/switch to prevent the first-open malformed layout regression on Windows laptops.
- Bottom replay/navigation remains pinned outside the main scroll shell.
