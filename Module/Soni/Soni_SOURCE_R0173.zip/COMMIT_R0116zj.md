# R0116zj — 58% pre-publish reset fix

The 58% stall was traced to `_reset_replay_analysis_state()` executing before the first cached FFT frame was published. That reset synchronously cleared Cavitation tables, heatmaps, and Why-highlight graphics on the Qt GUI thread.

R0116zj splits reset into a fast ownership reset and a deferred secondary-view clear. The first Spectrum frame is now allowed to publish before heavy secondary Qt widget cleanup. Visible stages advance through 60/64/68/74/84/90 before secondary analysis.
