# R0152

- Separates Reference focus, authoritative Sonication_Brain steered target, and phase-derived focus in Sonication Elements.
- Authoritative target is drawn at reference focus + canonical treatment-relative steering delta.
- Keeps R0150a find_log handling and R0151/R0151a snapshot/end-timing fixes.
