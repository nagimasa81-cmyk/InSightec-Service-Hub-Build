# R0151a

Merge correction over R0151.

- Preserves R0151 snapshot-selection callback fix.
- Preserves R0151 exact Sonication-end / WS power-window resolution fix.
- Restores R0150a AcousticControlService.find_log behavior for non-existing file-like Spectrum/FFT locator paths by searching from the locator parent.
- No cavitation rule semantics changed.
