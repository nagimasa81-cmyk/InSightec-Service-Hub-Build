# R0154l — ancestry regression audit: Summary lifecycle + Brain220 structural decode

## Deep code audit findings

R0154k still contained two concrete lifecycle regressions even though its targeted tests passed.

1. **Scheduled-preload race on ZIP drop**
   - Package adoption schedules detailed Summary work before the intentionally delayed Spectrum preload thread is created.
   - `_sonication_summary_initial_data_busy()` only inspected live/pending QThreads.
   - During the delay window Summary could therefore start before the canonical CPC/Spectrum handoff, making behavior depend on timing and active tab.
   - R0154l adds an explicit initial-handoff state that covers the scheduled-but-not-yet-started period and is released on both preload success and terminal preload failure.

2. **R0137 retry request was lost by R0154k**
   - `_adopt_authoritative_spectrum_context()` correctly marked pending/unavailable Summary rows for retry.
   - R0154k's `_request_sonication_summary_detail()` then cleared `_sonication_summary_needs_detail` when a full-table worker was already running.
   - Result: the active pass was preserved, but the required post-handoff retry vanished.
   - R0154l preserves the retry flag and launches a clean second pass only after the current pass finishes. No mid-table cancellation/restart is reintroduced.

3. **Terminal worker errors could leave DQA `Analyzing…`**
   - A detail-worker exception updated only the cavitation-status column.
   - The seeded DQA cell remained `Analyzing…`, falsely resembling an unfinished import.
   - R0154l terminalizes that cell as `Unavailable` with the underlying error tooltip.

## Brain220 Spectrum decoder audit

- A structurally valid SpectrumMsg header could fail the strict global record-count check and then fall through to the legacy global `8-record` grouper.
- That fallback can silently return fewer groups than the declared frame count and therefore make a partial decode look complete.
- R0154l forbids that fallback whenever the vendor frame header is valid; recovery stays within declared frame boundaries.
- Legacy Float32 heuristic search is now family-aware. Brain220 includes the low/subharmonic region instead of inheriting the historical 200–800 kHz Brain650 band.
- No samples are fabricated, stretched, or numerically clipped.

## Anti-regression contract

A new R0154l test module locks:
- scheduled-preload gating,
- retained authoritative retry while Summary is running,
- release/resume on preload success and failure,
- no permanent DQA `Analyzing…` after a row error,
- Brain220 low-frequency heuristic coverage,
- no structural-header fallback to global hard-coded 8-record grouping.
