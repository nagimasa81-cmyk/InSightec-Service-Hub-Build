# R0171 Triple Check

1. Discovery may still collect prefix-5 candidates, but ReplayService independently validates every source frame.
2. Temperature values are never adjusted to resemble neighboring Sonications; invalid semantic frames are excluded rather than numerically corrected.
3. Diagnostics expose exact per-frame metadata/ROI evidence so a remaining Sonication1 high temperature can be traced to source semantics or spatial targeting.
