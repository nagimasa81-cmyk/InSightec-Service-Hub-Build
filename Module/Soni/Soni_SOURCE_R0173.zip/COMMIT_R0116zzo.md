# R0116zzo — Summary schema self-heal + responsive image loading

- Force the Sonication Summary table back to the current 15-column schema on build, seed, refresh and detail row updates.
- Explicitly unhide Cavitation severity and Energy delivered (%) columns.
- Show image-loading progress before image-browser preparation starts.
- Remove synchronous 1000+ thumbnail-item construction from Load Images ON.
- Cache the reference asset row map once instead of recreating it on every frameReady signal.
- Do not construct QPixmap/QIcon objects for thumbnail frames when no visible list item exists yet.
- After background decode completes, build image strips in small GUI batches while progress remains visible, preventing event-loop starvation at 1%.
