# R0116zzzc — Red Threshold Direction Fix

- Corrected the thermal red threshold contract to render temperatures **at or above** the selected threshold in red.
- Inclusive boundary: `temperature >= red_threshold`.
- Temperatures below the threshold are excluded from the red overlay.
- Preserved focal connected-region filtering, smooth alpha fill, pure-red color, replay refresh, and the existing `Red starts at XX °C` UI wording.
- Added regression protection against reintroducing the inverted `<=` contract.
