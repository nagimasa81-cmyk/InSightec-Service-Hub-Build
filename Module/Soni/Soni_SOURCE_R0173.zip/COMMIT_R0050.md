# R0050 — Cavitation MR Correlation + Registration

This release connects two previously separate analysis branches:

1. RCV/Band cavitation evidence → probable-region map → treatment MR magnitude signal-loss correlation.
2. Preplanning CT → treatment-adopted CtMr matrix → planning/preplanning MR registration review.

The MR correlation is explicitly a screening/correlation result, not a definitive 3-D cavitation localization. Registration uses the real treatment CtMr matrix and searches the CT volume for the strongest MR/CT edge agreement; full patient-coordinate 3-D reslicing remains a future geometry refinement.
