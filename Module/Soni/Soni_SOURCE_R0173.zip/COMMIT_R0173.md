# R0173 — Transducer Location History

- Added independent parsing of workstation `Xd loc XYZ` records.
- Physical transducer XYZ is kept separate from electronic `Steering` XYZ.
- Added chronological Transducer History UI with date/time, X/Y/Z, roll/pitch, baseline deltas and 3D displacement.
- Added contextual nearest Sonication association without using it to manufacture location values.
- Added CSV export including source path and line provenance.
- Explicit Locate Transducer text near a location record is classified as such; otherwise the record remains an `XD location report` rather than being over-claimed.
- Import Diagnostics now includes `transducer_location_history` with record count, physical XYZ, separate Steering XYZ, baseline deltas/displacement, related Sonication context and source/line provenance.
