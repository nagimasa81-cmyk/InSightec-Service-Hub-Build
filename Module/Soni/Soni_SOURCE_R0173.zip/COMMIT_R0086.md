# R0086 — Workstation RAS Registration Replay Fix

- Corrected native image pixel-axis mapping: X/column index follows `ColDirectCosRAS`; Y/row index follows `RowDirectCosRAS`.
- Corrected CT voxel-to-RAS basis with the same Workstation/DICOM convention.
- Corrected Preplanning MR chain to `inv(MrMr) × CtMr`, based on Workstation registration source/destination evidence.
- Kept saved CtMr/MrMr deterministic; no image-fit transform selection or optimization is used.
- Planning orientation labels now come from the displayed planning asset geometry instead of stale thermal/replay metadata.
- Added R0086 regression tests covering pixel axes, CT voxel basis and the preplanning matrix chain.
