# Triple Check R0040

## Check 1 — Build/source integrity
- `python -m compileall -q src`: PASS
- `python verify_source.py`: PASS (`VERIFY_SOURCE_OK`)
- AST parse: PASS for 70 Python files
- No `PLACEHOLDER` remains in `src`

## Check 2 — Regression tests
- Full non-Qt suite: 86 PASS
- R0036 cavitation timeline, R0037 likelihood, R0039 launch guard, and R0040 geometry tests included.
- One PySide6 GUI test cannot execute in this Linux checker because PySide6 is not installed; its source is present and compilation/static checks pass.

## Check 3 — Manual/static launch and cavitation audit
- Spectrum Dump Analyzer button/action still targets `EightHydrophoneWindow`.
- R0039 launch NameError fix retained.
- Release metadata mismatch discovered and fixed (`APP_VERSION`/`APP_COMMIT`).
- Stale tests that hard-coded R0025 metadata and pre-fusion navigation mode updated.
- Cavitation likelihood default geometry corrected to the previously supplied XD 7029 angular mapping:
  - CH0/H1 1:00
  - CH1/H2 4:00
  - CH2/H3 7:00
  - CH3/H4 11:00
  - CH4/H5 2:00
  - CH5/H6 3:30
  - CH6/H7 8:00
  - CH7/H8 10:00

## Result
R0040 is the corrected triple-checked successor to R0039.
