# R0164

- Unified Brain220 Acquisition_Brain ExciterElectricalPower parsing across control-timeline and vendor reproduction paths.
- Default Analyzer time window now ends at the selected Sonication end; full MR acquisition remains explicitly selectable.
- Added terminal study-preload ownership so GUI cache misses cannot restart a completed/failed whole-study Spectrum preload.
- Replaced unordered top-3 thermometry peak with a spatially coherent local 3x3 median peak to reject scattered hot-pixel artifacts.
