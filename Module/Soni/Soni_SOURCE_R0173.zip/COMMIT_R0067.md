# R0067 — 1024 Channel Elements / Phase / Legend Controls

- Added CPCFiles/Site/Ini/ChannelMeasure.ini decoding for all 1024 transmit channels.
- Selects the ChannelMeasure frequency nearest the current Sonication frequency.
- Keeps measured calibration amplitude/phase separate from sparse Logical sonication-log values.
- Connects the 1024-channel measured phase array to Tile, Umbrella, and Phase Dedicated rendering.
- Fixed Phase Dedicated methods being defined on the wrong widget class; they now exist on SonicationElementMapWidget.
- Element tables now expose measured and logical values side-by-side.
- Existing cavitation legend layout is retained and each item now has a checkbox controlling its corresponding graph series.
