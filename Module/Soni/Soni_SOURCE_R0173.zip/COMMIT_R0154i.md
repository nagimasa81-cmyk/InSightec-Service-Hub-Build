# R0154i — DQA coordinate-frame gate + Brain220 Spectrum handoff repair

## DQA focus / phantom alignment
- Removed the unsafe assumption that `SonicationSummary.focalRAS` and DQA `MriImageParams` image RAS are always directly subtractable.
- Before any DQA X/Y/Z value is calculated, the focal point is projected into both the exported DQA-Axial and DQA-Sagittal frames.
- A focal point must be inside the image FOV (with metadata tolerance) and close to both image planes. If that common-coordinate-frame test fails, alignment is reported as `N/A — focal/phantom coordinate frames not registered` and cannot trigger an orange DQA alert.
- Evidence records the projected pixel coordinates and plane distance, so a future export-specific registration transform can be implemented from evidence rather than guessed.
- Existing electronic-steering and repeated target-voxel exclusions remain in force after the coordinate-frame gate.

## Brain220 / Spectrum data binding
- Sonication switching now clears Sonication-scoped Spectrum payload immediately. A Brain220 selection can no longer display the previous Brain650 Spectrum while its own worker is loading, nor can stale non-empty channels suppress loading.
- Spectrum X range is now family/data aware instead of fixed to 0.20–0.80 MHz. Brain220 displays include the low-frequency region and subharmonic band.
- Embedded SpectrumMsg graph axes are checked against the actual Sonication main frequency. If the embedded axis excludes the actual main frequency, only the presentation axis is rebuilt from `Acquisition.ini` / the existing family-aware fallback; stored amplitudes are not altered.
- Post-sonication Spectrum state and reference markers now use the selected Sonication frequency rather than a stale/package-only display assumption.
