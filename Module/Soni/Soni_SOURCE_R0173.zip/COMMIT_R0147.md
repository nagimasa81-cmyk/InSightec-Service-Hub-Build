# R0147 — CI vertical allocation repair + Movement Detection in Sonication Summary

- Removed the viewport-derived minimum height that could create a large blank band inside Cavitation Intelligence and squeeze the lower graph/table region.
- Kept the R0146 passive ScrollBarAsNeeded escape path; no import/replay/data callback was added.
- Explicitly gives the vendor-band and control-response plots layout stretch so remaining vertical space goes to the actual graph.
- Added authoritative per-Sonication Movement Detection extraction from `SpotDoseData.xml` `motionvalue`.
- Negative values (notably `-1`) remain unavailable; non-negative measured values are displayed. Conflicting duplicate exports fail closed rather than being guessed.
- Added a `Movement detection` column and chart metric to Sonication Summary.
