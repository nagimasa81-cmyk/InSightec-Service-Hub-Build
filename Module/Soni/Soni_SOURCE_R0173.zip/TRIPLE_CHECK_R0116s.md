# R0116s Triple Check

## Check 1 — Static / connection audit
PASS

- AST parse across `src/`: PASS
- Duplicate method names within classes: none detected
- Workflow YAML parse: PASS
- Version consistency: `RC7.2-R0116s`
- Reconfirmed signal wiring for Control Timeline click, Event-list click, replay timer, source open/drop, and Sonication synchronization.

Critical runtime issue found and fixed:
- non-existent `HydrophoneWindow._event_time_for_text()` reference caused a runtime NameError in Why/Event-list population.

## Check 2 — Runtime-flow regression audit
PASS

- New R0116s runtime-connection tests: PASS
- R0116r Why opt-in regression: PASS
- R0116q dynamic-state sync regression: PASS
- R0116p FFT-link regression: PASS
- R0116o dynamic sync/source-reset regression: PASS
- Focused set: 23/23 PASS

All non-PySide6 tests:
- 399/399 PASS

The single PySide6 GUI test cannot be collected in this Linux validation container because PySide6 is not installed; this is an environment limitation, not a detected source failure.

## Check 3 — Source-switch / stale-state audit
PASS after fixes

Verified/fixed:
- New Open/Drop request clears stale visible state.
- If another package load is still running, only the latest source remains queued.
- Queued source starts only after the old QThread has actually finished and references are cleared.
- Switching SpectrumDump candidate or Sonication clears replay-scoped cavitation state before loading the next replay.
- Old Event list / selected event / probable location / band heatmap cannot intentionally survive into the new replay state.
- Red selected-event cursor and white replay cursor now use independent state semantics.
