# R0154n — Brain220 deep export binding

## Scope
Deep structural analysis of the supplied Brain220 / 230 kHz export `42110-2026-04-01-18-30-47.zip` and evidence-driven hardening of Spectrum / Sonication identity / DQA handling.

## Confirmed export facts

1. Brain220 `SpectrumMsg-N.dmp` is a variable-record size-table stream, not the legacy fixed-frame/channel header assumed by `decode_spectrum_structure`.
2. For all Sonications 1–7, the first uint32 record count is exactly equal to `spotsonicationdata.PowerGraphSize`.
3. The last embedded SpectrumMsg history time is exactly equal (Float32 identity) to the last PowerGraph time and agrees with `actualsonicduration` to XML rounding precision.
4. Two exact FFT layouts coexist in the same export: 1000 bins @ 250 Hz and 400 bins @ 625 Hz. Both cover ~0–250 kHz.
5. The main workstation `.Log` contains zero-based `StartSonicate Sonication Counter` identity, programmed power, duration, actual frequency (230000 Hz), steering, and for multi-target cases the full sub-sonication geometry.
6. Sonications 1,3,5,6,7 contain nine sub-sonications. Their nine RAS coordinates form a 3x3 grid and their arithmetic centre agrees with `SonicationSummary.focalRAS` within <0.001 mm in the supplied export.
7. Sonications 6 and 7 have identical 9-point RAS geometry and identical steering, confirming repeated multi-target target-voxel behavior from independent workstation evidence.
8. The 20-byte history entries contain structured state beyond timestamps. A recurring marker entry carries 0.096 / 0.84 / 0.7. Other entries include a small integer field and cumulative/aggregate-like floating values. The exact semantic name of that small integer is not yet promoted to Receiver because values 0–8 occur while the product exposes eight RCV channels; R0154n deliberately leaves this field unlabeled rather than guessing.

## Code changes

- `decode_spectrum_structure()` now recognizes the variable size-table FFT/history layout before interpreting words 2/3 as fixed frame-size/channel-count.
- Exact structure reporting now carries layout, FFT-bin count, embedded spacing, history sample count, and last embedded timestamp.
- `SonicationEvidenceService` falls back to authoritative workstation `StartSonicate` blocks when `Sonication_Brain_*.txt` is absent.
- Zero-based workstation Sonication Counter is used as an explicit identity key instead of positional guessing.
- Full multi-target RAS geometry and per-sub-sonication steering table are retained in setup evidence.
- Spectrum evidence now validates both `record_count == PowerGraphSize` and `SpectrumMsg last embedded time == PowerGraph end`.
- DQA exclusion recognizes exact multi-target geometry (>1 sub-sonication with complete RAS list) and reports it as a multi-target voxel rather than evaluating it as a single centre focus.
- For single-focus DQA steering, the most axis-centred single-focus workstation setup is used as the nominal reference so multi-target Sonications cannot distort the old all-peer median.

## No unsupported assumptions added

- No fixture-name/SHA/serial branching.
- No expected-value coefficient fitting.
- No numeric clipping.
- The unresolved history integer 0–8 is not labeled as RCV/channel/sub-sonication until independent evidence resolves it.
- Legacy Brain650 fixed-frame decode remains available and is not replaced by the Brain220 variable-record path.
