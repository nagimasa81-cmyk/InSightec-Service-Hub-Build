# R0154s — Tool ruler / DQA fail-closed / Spectrum handoff

## User-visible changes
- Renamed the left `Temperature ROI` group to `Tool`.
- Added `ROI`, `Distance`, `Copy`, and `Clear` actions. Distance uses the displayed MR pixel spacing and reports mm plus pixel length.
- DQA focus alignment now prefers same-raster thermal-hotspot/phantom landmark geometry when 3-D observed alignment is unavailable.
- Large absolute focalRAS-to-reference deltas (>25 mm) are rejected as coordinate-frame mismatch instead of being displayed as a DQA focus displacement. This specifically blocks repeated translation-like values such as the reported ~Y -35 / Z -84 mm pattern.
- Spectrum Dump Analyzer receives authoritative CPC/SpectrumMsg candidate/mapping context immediately when opened, before background decode finishes, so the loaded Export is no longer shown as disconnected while Main/CI/Summary already have mapped acoustic evidence.

## Re-checks
- 4258 diagnostic: Brain 650 family, actual 690 kHz, 5/5 Sonications, 5 SpectrumMsg, 5 physical CPC mappings; discovery/mapping is present, so an Analyzer blank/disconnected state is a UI handoff defect rather than missing data.
- 42110 diagnostic: Brain 220 family, actual 230 kHz, 7/7 Sonications, 7 SpectrumMsg, 65 physical CPC candidates, all 7 treatment Sonications mapped Exact to CPC. 220 data therefore must stay connected to the authoritative mapping; there is no basis to synthesize DQA focus-shift values unless DQA protocol + eligible center-shot evidence is explicitly present.

## Validation
- `python -m py_compile` PASS for changed modules.
- Focused regression suite: 51 passed.
- Full pytest collection is not runnable in this Linux container because PySide6 is not installed; failure occurs at GUI-test collection before tests execute.
