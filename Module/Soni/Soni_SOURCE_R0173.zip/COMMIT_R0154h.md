# R0154h

Hardening release for CPC single-owner loading, DQA temperature fail-closed behavior, DQA target/steering exclusion, and serial XD Umbrella geometry fallback.

Validation includes real 42110 Brain220 DQA and 4267 Brain650 CPC/Spectrum exports plus regression and static ownership checks.
