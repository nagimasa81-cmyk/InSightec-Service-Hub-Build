# R0116zz — Anatomical Direction Traceability + Rich i18n Expansion

## MRI direction display
- Basic direction display now uses patient anatomical axes first and preserves DICOM ROW/COL in parentheses for traceability.
- Examples: `RL (ROW)`, `AP (COL)`, `SI (ROW)`.
- ROW/COL anatomical mapping is derived from the actual row/column direction cosines; it is never assumed from plane alone.
- If direction cosines are unavailable, the software keeps raw `ROW`/`COL` rather than inventing an anatomical axis.
- Legacy anatomical values such as R/L, A/P and S/I are normalized to RL, AP and SI without fabricating ROW/COL.
- MR detail rows and Replay summary use the same canonical direction representation.

## Plane / anatomical-axis convention
- Axial physical plane: RL + AP
- Sagittal physical plane: AP + SI
- Coronal physical plane: RL + SI
- Image row/column orientation can rotate within a plane, so ROW/COL is resolved from direction cosines.

## Language coverage
- Retains 7 languages: English, Japanese, Korean, Traditional Chinese (Taiwan), Spanish, Thai, Hindi.
- Expanded localization to MRI metadata labels, Treatment Outcome Science, Root Cause Analysis, Event/Element lists, evidence-chain UI, treatment-map controls, table headers, combo-box choices, and analysis-detail controls.
- `localize_qt_tree()` now localizes exact known QTableWidget headers, static QComboBox items, and exact known tooltips in addition to buttons/labels/tabs/group titles.
- Scientific identifiers and anatomical/engineering codes (MR/CPC/RCV/CGA/FFT, RL/AP/SI, ROW/COL) remain unchanged for cross-site traceability.

## Validation
- Dedicated R0116zz direction/i18n tests: 6/6 PASS.
- R0116 regression suite: 222/222 PASS.
- Full suite excluding the known PySide6-only ROI GUI test: 528/528 PASS.
