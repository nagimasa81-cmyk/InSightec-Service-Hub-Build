# R0059 — Sonication Element Smart Discovery and Icon Legend

- Sonication Elements searches the selected Sonication context first and the full Export workspace second.
- Added direct **Open Sonication Log** and **Rescan** controls.
- Added fallback parsing for Number Of Channels / Channel / Logical Amplitude / Logical Phase blocks even when the known CLoadSonicationData marker is absent.
- Directly selected .txt/.log files are accepted even with nonstandard names.
- Cavitation chart legend uses compact line/point icons with short labels instead of a long prose legend.
