# R0081 — Cavitation Root Cause Analysis

Adds a first-class, evidence-weighted root-cause layer to Cavitation Intelligence.

## Root-cause contributors
- Cavitation control threshold crossing / event severity
- CPC vendor Band0–3 multi-band escalation versus early baseline
- Acoustic drive relative to treatment median and previous Sonication
- Thermal preconditioning (start, peak, delta-T, previous peak)
- Localized RCV contribution concentration
- Previous-Sonication cavitation history
- Hydrophone/MR correlation score

## Safety of interpretation
The analysis ranks supporting evidence. It does not claim biological causality, and missing streams remain explicitly unavailable rather than being imputed.

## UI
Cavitation Intelligence now shows ranked contributors, 0–100 contribution, evidence, confidence and an improvement direction for each selected Sonication.
