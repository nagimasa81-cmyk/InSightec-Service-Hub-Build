# R0116e

- Fixed thumbnail hover preview so the popup uses the underlying image array instead of the small letterboxed thumbnail icon.
- The preview image now fills the popup area much more effectively.
- Reduced popup padding and made popup size follow the actual scaled image size.
- Screen-aware maximum preview size retained.
- R0116d fixes preserved.
