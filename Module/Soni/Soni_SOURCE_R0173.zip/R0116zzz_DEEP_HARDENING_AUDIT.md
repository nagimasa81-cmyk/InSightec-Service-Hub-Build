# R0116zzz Deep Architecture Hardening Audit

## Fixed high-risk findings
1. **Cavitation truth split** — Treatment Outcome Science now consumes `CanonicalCavitationEvidenceService`, including observed control events and vendor INI Rule Triggers, exactly like Replay/CI/Summary.
2. **False normal from missing data** — canonical detection is tri-state: `True`, `False`, or `None` for incomplete evidence. Missing Spectrum/control evidence reports `Evidence incomplete — Needs attention`; Treatment Outcome suppresses cavitation burden/RCA outcome inference when evidence is unknown.
3. **Leaked timeout readers** — Essential RAW loading no longer spawns daemon decode threads. Cooperative chunk reads check cancel/deadline between chunks and cannot continue invisibly after a skip.
4. **Red-threshold GUI cost** — threshold masking now vector-selects the focal seed and floods only the selected component. Synthetic benchmark improved from prior audit ~66/364/1360 ms (256/512/1024) to ~6/26/104 ms in this container.
5. **Repeated Spectrum decode** — `SpectrumEvidenceRepository` shares candidate mapping, replay decode and standalone vendor evidence across preload, Summary and Treatment Outcome. Per-Sonication in-flight ownership prevents concurrent duplicate decode.
6. **ZIP double decompression** — full `testzip()` pre-pass removed from treatment and Spectrum ZIP import. Extraction remains CRC-validating. `10-00-09_ANx.zip` extraction measured ~3.68 s in this container.
7. **Ancestor/dead synchronous paths** — synchronous metadata compatibility entry now hard-fails rather than performing GUI-thread I/O; legacy staged Spectrum secondary methods redirect to the current background queue.

## Data fidelity changes
- Energy delivered (%) no longer clips at 100%. Real measured/planned ratios above 100% remain visible.
- 10-00-09 real recomposition: S1 100.805%, S2 100.815%, S3 100.235%.
- S3: 962.2 W / 24.576 s / 21070.4 J / Peak 50.77 C / 966 Vendor Rule Triggers / canonical cavitation=True.
- S1/S2 canonical=False; S3-S8 canonical=True from vendor-rule evidence.

## Static / regression status
- 670 non-PySide6 tests passed.
- PySide6-only circular ROI test cannot collect in this Linux image.
- `verify_source.py`: PASS.
- `compileall`: PASS.
- duplicate methods: 0 in MainWindow/HydrophoneWindow/ImagePanel.
- `QApplication.processEvents()`: 0.
- `QThread.terminate()`: 0.
- daemon reader threads: 0.
- `archive.testzip()`: 0.

## Remaining runtime-only caveat
A blocking OS/filesystem read cannot be forcibly interrupted inside one `readinto()` call. R0116zzz limits RAW reads to small chunks and removes leaked reader threads, but a pathological filesystem driver can still delay one chunk. Windows EXE runtime validation remains required for that OS-level behavior and final Qt rendering/event delivery.
