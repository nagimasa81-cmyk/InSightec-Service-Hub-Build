# R0025 — FUS Engineering Analysis Phase 1

## Goal
Move Sonication Analysis beyond Workstation replay into an evidence-first FUS engineering analyzer while preserving R0024b Workstation-frequency behavior and PARTIAL best-effort replay.

## Added
- New **Engineering Analysis** workspace.
- Metrics table with explicit Source / Confidence / Note columns.
- **Dependency Graph** showing AVAILABLE / DEGRADED / MISSING by feature and functional fallback.
- ACT element analytics: active/off count, aperture %, amplitude statistics, phase range/RMS.
- ACT ↔ SkullMeasures phase cross-validation and skull-valid → ACT-active filtering analysis.
- SkullMeasures engineering statistics: SDR, thickness, skull velocity, outer/inner angle, ray shift.
- SkullHeating analytics: active elements, OffReason breakdown (Algorithm/NPR/Manual/Apodization/CPC), element AvgPower sum, predicted internal/external temperatures, bath/model parameters.
- Thermometry engineering diagnostics: raw peak, Field33 background-mask peak, Field33+Field23 quality-mask peak, Field2/34 local derived-map occupancy.
- Spectrum structure reporting: exact frame count/frame size/container-channel/header validation; no fabricated channel-payload splitting.

## Safety / accuracy rules retained
- Replay frequency comes from per-Sonication SonicationSummary information when available.
- SkullHeating frequency is shown separately as a model/reference value and never overrides Replay frequency.
- PARTIAL/INCOMPLETE data are never silently dropped; independent capabilities remain usable.
- Field23 interpretation remains evidence-based and is labelled as such.
