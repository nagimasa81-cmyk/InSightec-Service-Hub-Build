# R0066 — Skull-selective bright-green registration overlay

- Tightened bone extraction after R0064 soft-tissue green spill.
- Uses HU-aware/high-density upper-tail threshold.
- Rejects small isolated components before rendering.
- Reduced boundary dilation from two pixels to one pixel.
- Non-bone pixels remain NaN/transparent.
- Changed overlay to a brighter light yellow-green and slightly reduced opacity.
- Keeps R0065 patient-coordinate CT geometry recovery unchanged.
