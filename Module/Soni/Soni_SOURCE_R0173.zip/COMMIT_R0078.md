# R0078 — Defender-Conservative Standalone Build

- Preserves all R0077 application functionality.
- Removes Nuitka `--onefile` from local and GitHub Actions builds.
- Ships the complete Nuitka `.dist` runtime as a ZIP instead of a self-extracting executable.
- Adds Windows product/file version resources.
- Adds SHA256 manifests for the distribution ZIP and executable.
- Does not disable Defender, add exclusions, restore quarantined files, or attempt to bypass security controls.
- A standalone build can reduce heuristic false positives caused by self-extraction, but it cannot guarantee Defender acceptance.
