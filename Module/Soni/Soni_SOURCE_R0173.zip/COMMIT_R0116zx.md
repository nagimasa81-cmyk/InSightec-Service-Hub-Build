# R0116zx — Cross-cutting ancestry / connection audit hardening

- Removed surviving latest-N CPC positional selector from HydrophoneReplayService.select_files().
- Spectrum preload refuses positional substitution when physical CPC pairs exist but authoritative mapping is unresolved.
- Converted legacy `_set_mr_xrange()` into payload-data-fit compatibility shim, preventing Raw/Spectrogram/Band Energy from reverting to 0..MR-end.
- Cavitation Intelligence linked control plot labels Acquisition_Brain state as `Controller ExPowerRatio`, not Actual Power.
- CI linked Vendor/Control plots fit to their finite payload intervals.
- Added anti-regression tests for ancestry and connection leaks.
