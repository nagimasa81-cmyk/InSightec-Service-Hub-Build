# R0088 — Sonication Phase Absolute Phasor Fix
- Removed the second circular-mean subtraction from Sonication Phase display.
- Preserves SkullMeasures Total Phase Shift + Logical common-phase anchor.
- Displays wrapped sonication phase directly (-180°..+180°).
- Phasor angle = phase; radius = normalized channel amplitude.
- Calibration and observed-log phase remain relative diagnostic views.
