# R0116zzz — Architecture Hardening and Evidence Integrity

This release hardens the post-R0116zzy architecture without adding a new analysis mode.

- Treatment Outcome Science now uses the same Canonical Cavitation Evidence contract as Replay/CI/Summary.
- Missing Spectrum/control evidence is `Evidence incomplete — Needs attention`, never silently `No cavitation`.
- Essential RAW reads no longer spawn daemon timeout threads; cooperative chunked reads own cancellation/deadlines.
- Focal red-threshold mask extraction was reduced from all-component Python enumeration to vector seed + one-component flood fill.
- A study-scoped `SpectrumEvidenceRepository` shares candidate mapping, decoded replay and standalone evidence across preload, Summary and Treatment Outcome.
- ZIP import no longer performs a full `testzip()` decompression before extraction; extraction CRC remains authoritative.
- Legacy synchronous metadata loading is explicitly blocked; legacy Spectrum staged GUI-computation entries redirect to the background owner.
- Energy delivered (%) is not clipped at 100; measured/planned values above 100% remain visible.

Validation: 670+ non-GUI regressions plus R0116zzz hardening tests, real 10-00-09_ANx recomposition, compile and source verification.
