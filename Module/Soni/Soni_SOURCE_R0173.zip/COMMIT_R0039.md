# R0039 — Spectrum Dump Analyzer launch fix

Root cause: R0037/R0038 packaging retained a bare `PLACEHOLDER` statement inside `_draw_cavitation_likelihood()`. Opening the analyzer from the default replay immediately called `load_package()` -> cavitation refresh -> likelihood draw, which raised `NameError` before the dialog was shown.

Fix: replace the placeholder with the intended likelihood summary/evidence text update and add regression guards.
