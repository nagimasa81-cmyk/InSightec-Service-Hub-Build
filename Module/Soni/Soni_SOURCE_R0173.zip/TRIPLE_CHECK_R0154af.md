# Triple check — RC7.10-R0154af

1. **Data ownership**
   - SpectrumMsg and physical CPC remain separate composite sources.
   - Receiver secondary products are preloaded for all decoded RCV channels.
   - MR protocol rows are bound by exact Sonication number + RAW field ID.

2. **No silent substitution / overwrite**
   - A RAW field with no matching MriImageParams row remains visible as Metadata unavailable.
   - No field-number-to-protocol guess is used.
   - Existing DQA/Umbrella contracts from R0154ae are untouched by this feature.

3. **Regression / packaging**
   - Focused R0154 tests pass.
   - Non-GUI regression suite passes apart from the documented optional AES dependency skip.
   - Source compile and release identity verification pass.
   - Generated caches are removed before ZIP creation.
