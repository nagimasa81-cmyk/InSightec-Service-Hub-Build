from pathlib import Path

ROOT = Path(__file__).parents[1]
IMG = (ROOT / "src/ui/image_panel.py").read_text(encoding="utf-8")
MAIN = (ROOT / "src/ui/main_window.py").read_text(encoding="utf-8")


def test_red_threshold_is_inclusive_upper_temperature_alarm():
    assert "raw=np.isfinite(arr) & (arr>=float(threshold))" in IMG
    assert "np.where(temp>=temperature_threshold,temp,np.nan)" in IMG
    assert "arr<=float(threshold)" not in IMG
    assert "temp<=temperature_threshold" not in IMG


def test_red_threshold_label_matches_rendering_direction():
    assert 'Red starts at {value} °C' in MAIN
    assert 'Red starts at 48 °C' in MAIN


def test_solid_red_fill_still_uses_focal_connected_region_and_pure_red():
    assert "mask=self._focused_threshold_mask(temp,float(temperature_threshold),hotspot=hotspot)" in IMG
    assert "rgba[...,0]=255; rgba[...,1]=0; rgba[...,2]=0" in IMG
    assert "passes=6" in IMG
