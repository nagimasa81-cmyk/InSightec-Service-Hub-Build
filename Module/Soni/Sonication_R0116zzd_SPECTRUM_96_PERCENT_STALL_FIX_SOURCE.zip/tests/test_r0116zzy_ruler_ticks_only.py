from pathlib import Path

ROOT=Path(__file__).parents[1]
IMG=(ROOT/'src/ui/image_panel.py').read_text(encoding='utf-8')

def test_ruler_ticks_only_contract():
    block=IMG.split('class PhysicalRulerOverlay',1)[1].split('class ImagePanel',1)[0]
    assert 'QColor(74, 226, 235)' in block
    assert 'for mm in range(6)' in block
    assert 'x - 12.0' in block
    assert 'drawRoundedRect' not in block
    assert 'drawText(' not in block

def test_ruler_right_center_and_zoom_physical_length():
    block=IMG.split('class PhysicalRulerOverlay',1)[1].split('class ImagePanel',1)[0]
    assert 'parent.width()) - width - 8' in block
    assert '(int(parent.height()) - height) // 2' in block
    assert '_length_px' in block

def test_version_bumped_to_zzy():
    constants=(ROOT/'src/common/constants.py').read_text(encoding='utf-8')
    assert 'RC7.2-R0116zzd' in constants
