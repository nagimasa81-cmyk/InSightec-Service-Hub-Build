from pathlib import Path
import ast
import numpy as np

ROOT=Path(__file__).parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
IMG=(ROOT/'src/ui/image_panel.py').read_text(encoding='utf-8')
CANON=(ROOT/'src/services/canonical_cavitation_evidence_service.py').read_text(encoding='utf-8')


def test_red_threshold_is_focal_smooth_pure_red_not_all_hot_pixels():
    assert '_focused_threshold_mask' in IMG
    assert 'passes=6' in IMG
    assert 'rgba[...,0]=255; rgba[...,1]=0; rgba[...,2]=0' in IMG
    assert 'hotspot=hotspot' in IMG


def test_image_zoom_requests_smooth_pixmap_rendering():
    assert IMG.count('QPainter.RenderHint.SmoothPixmapTransform') >= 2


def test_ruler_is_screen_edge_widget_with_true_5mm_zoom_scale():
    assert 'class PhysicalRulerOverlay(QWidget)' in IMG
    assert 'sigRangeChanged.connect(self._view_range_changed)' in IMG
    assert 'viewPixelSize()[1]' in IMG
    assert 'image_pixels_for_5mm=5.0/float(self._mm_per_pixel)' in IMG
    assert 'place_at_right' in IMG
    assert 'for mm in range(6)' in IMG
    assert 'QColor(74, 226, 235)' in IMG
    block=IMG.split('class PhysicalRulerOverlay',1)[1].split('class ImagePanel',1)[0]
    assert 'drawRoundedRect' not in block
    assert 'drawText(' not in block
    assert '(int(parent.height()) - height) // 2' in block
    assert 'x - 12.0' in block


def test_cavitation_contract_has_only_confirmed_observed_or_vendor_rules():
    assert 'counts_as_cavitation' in CANON
    assert 'severity=="Rule Trigger"' in CANON
    assert 'dump candidate' in CANON
    assert 'confirmed=bool(observed or rule)' in CANON
    assert 'Evidence incomplete — Needs attention' in CANON


def test_summary_and_ci_share_canonical_cavitation_contract():
    assert '_summary_canonical_cavitation_evidence' in MAIN
    assert 'self.canonical_cavitation_evidence_service.combine' in MAIN
    assert 'default_canonical_cavitation_evidence' in MAIN
    assert 'CAVITATION DETECTED' in MAIN


def test_summary_runs_spectrum_cavitation_enrichment_in_background_worker_path():
    tree=ast.parse(MAIN)
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='MainWindow')
    fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_build_one_sonication_summary')
    text='\n'.join(MAIN.splitlines()[fn.lineno-1:fn.end_lineno])
    assert '_summary_canonical_cavitation_evidence' in text
    assert 'canonical.rca_events' in text


def test_background_memory_toolbar_button_is_not_analyzer_action():
    assert 'QAction("Activity / Memory", self)' in MAIN
    assert 'self.background_activity_toolbar_btn = QToolButton(self)' in MAIN
    assert 'self.background_activity_toolbar_btn.clicked.connect(self._show_background_activity_window)' in MAIN
    assert 'self.open_hydrophone_action.triggered.connect(self._open_hydrophone_window)' in MAIN


def test_energy_delivered_requires_actual_or_measured_evidence_not_planned_fallback():
    body=MAIN[MAIN.index('def _build_one_sonication_summary'):MAIN.index('def _build_one_sonication_temperature_summary')]
    assert 'actual_energy=self._summary_finite' in body
    assert 'measured_energy=actual_energy' in body
    assert 'actual_power is not None and actual_duration is not None' in body
    assert '100.0*float(measured_energy)/float(target_energy)' in body


def test_summary_rca_is_recomposed_after_thermometry_enrichment():
    body=MAIN[MAIN.index('def _sonication_summary_temperature_row_ready'):MAIN.index('def _sonication_summary_temperature_finished')]
    assert 'target["rca_score"]' in body
    assert 'events=target.get("_rca_events",())' in body
    assert 'replay=target.get("_rca_replay")' in body


def test_probable_region_uses_canonical_confirmed_events_not_only_control_log():
    assert 'def _nearest_canonical_cavitation_event' in MAIN
    probable=MAIN[MAIN.index('def _draw_ci_linked_rcv_probable'):MAIN.index('def _fit_plot_x_to_payload')]
    assert '_nearest_canonical_cavitation_event' in probable
    helper=MAIN[MAIN.index('def _nearest_canonical_cavitation_event'):MAIN.index('def _nearest_observed_cavitation_event')]
    assert 'Rule Trigger' in helper
    assert 'Candidate' not in helper
