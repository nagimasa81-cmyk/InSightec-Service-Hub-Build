from __future__ import annotations

from collections import Counter
from dataclasses import asdict
from pathlib import Path
from typing import Any
import numpy as np

from src.common.constants import APP_VERSION, APP_COMMIT
from src.services.acoustic_control_service import AcousticControlService
from src.services.sonication_evidence_service import SonicationEvidenceService
from src.services.spectrum_dump_import_service import SpectrumDumpImportService
from src.services.hydrophone_replay_service import HydrophoneReplayService
from src.services.replay_service import ReplayService
from src.services.spectrummsg_aggregate_service import SpectrumMsgAggregateService
from src.services.transducer_location_service import TransducerLocationService


class ImportDiagnosticsService:
    """Build a compact, content-free report for import/binding failures.

    The report deliberately contains metadata only: relative file names, sizes,
    counts, parsed clocks/session identities and mapping evidence.  It never
    copies treatment payload bytes, MR images, Spectrum samples or log text.
    """

    _RELEVANT_NAMES = (
        "sonicationsummary", "spotsonicationdata", "acquisition_brain",
        "sonication_brain", "spectrummsg", "spectrum_", "skullmeasures",
        "channelmeasure", "calibration", "cavitation", "powergraph",
    )

    @staticmethod
    def _rel(path: Path | None, root: Path) -> str | None:
        if path is None:
            return None
        try:
            return Path(path).resolve().relative_to(root.resolve()).as_posix()
        except Exception:
            return Path(path).name

    @staticmethod
    def _safe_size(path: Path | None) -> int | None:
        if path is None:
            return None
        try:
            return int(Path(path).stat().st_size)
        except Exception:
            return None

    @classmethod
    def _is_relevant(cls, path: Path) -> bool:
        low = path.name.lower()
        if path.suffix.lower() == ".zip":
            return True
        return any(token in low for token in cls._RELEVANT_NAMES)

    @staticmethod
    def _thermometry_source_frame_audit(replay_service, son) -> dict[str, Any]:
        """Metadata-only per-source-frame thermometry audit."""
        try:
            trend=replay_service.temperature_trend(son)
            src_count=len(getattr(son,"temperature_frames",[]) or [])
            replay_count=max(1,int(getattr(son,"replay_frame_count",0) or 1))
            robust=np.asarray(trend.get("robust_max",[]),float).reshape(-1)
            mean=np.asarray(trend.get("mean",[]),float).reshape(-1)
            delta=np.asarray(trend.get("robust_delta",[]),float).reshape(-1)
            samples=[]
            frames=list(getattr(son,"temperature_frames",[]) or [])
            semantics=list(trend.get("source_frame_semantics",[]) or [])
            for src_i,frame in enumerate(frames):
                mapped=[]
                for ri in range(replay_count):
                    try:
                        if replay_service.raw.normalize_index(ri,replay_count,src_count)==src_i:
                            mapped.append(ri)
                    except Exception:
                        pass
                def first(arr):
                    for ri in mapped:
                        if ri < arr.size and np.isfinite(arr[ri]):
                            return float(arr[ri])
                    return None
                sem=semantics[src_i] if src_i < len(semantics) and isinstance(semantics[src_i],dict) else {}
                samples.append({
                    "raw_index": int(getattr(frame,"index",src_i)),
                    "raw_name": Path(getattr(frame,"path","")).name,
                    "robust_peak_c": first(robust),
                    "mean_c": first(mean),
                    "robust_delta_c": first(delta),
                    "mapped_replay_samples": len(mapped),
                    "accepted_as_thermometry": sem.get("accepted"),
                    "semantic_decision": sem.get("decision"),
                    "semantic_reason": sem.get("reason"),
                    "exact_mri_binding_count": sem.get("exact_match_count"),
                    "series_description": sem.get("series_description"),
                    "series_uid": sem.get("series_uid"),
                    "echo_number": sem.get("echo_number"),
                    "echo_time": sem.get("echo_time"),
                    "scan_time": sem.get("scan_time"),
                    "roi_center_x": sem.get("roi_center_x"),
                    "roi_center_y": sem.get("roi_center_y"),
                    "roi_width_px": sem.get("roi_width_px"),
                    "roi_height_px": sem.get("roi_height_px"),
                    "decode_error": sem.get("decode_error"),
                })
            return {"source_raw_frame_count":src_count,"samples":samples}
        except Exception as exc:
            return {"error":f"{type(exc).__name__}: {exc}"}

    def build(self, package) -> dict[str, Any]:
        root = Path(package.workspace)
        errors: list[str] = []
        files: list[Path] = []
        try:
            files = [p for p in root.rglob("*") if p.is_file()]
        except Exception as exc:
            errors.append(f"workspace inventory failed: {type(exc).__name__}: {exc}")

        suffix_counts = Counter((p.suffix.lower() or "<none>") for p in files)
        relevant_files = [p for p in files if self._is_relevant(p)]
        relevant_inventory = [
            {
                "path": self._rel(p, root),
                "size": self._safe_size(p),
            }
            for p in sorted(relevant_files, key=lambda x: str(x).lower())
        ]

        acoustic = AcousticControlService()
        acq_candidates = sorted(root.rglob("Acquisition_Brain_*.txt"), key=lambda p: str(p).lower())
        selected_acq = None
        sessions = []
        try:
            selected_acq = acoustic.find_log(root)
            sessions = acoustic.parse_segments(selected_acq) if selected_acq is not None else []
        except Exception as exc:
            errors.append(f"Acquisition_Brain selection/parse failed: {type(exc).__name__}: {exc}")

        acq_rows = []
        for p in acq_candidates:
            stamp = acoustic._log_stamp(p)
            acq_rows.append({
                "path": self._rel(p, root),
                "size": self._safe_size(p),
                "filename_timestamp": stamp.isoformat(sep=" ") if stamp is not None else None,
                "selected": bool(selected_acq is not None and p.resolve() == selected_acq.resolve()),
            })

        session_rows = []
        for idx, segment in enumerate(sessions):
            vals = [float(s.elapsed_s) for s in segment.samples]
            session_rows.append({
                "index": idx,
                "start_clock_s": float(segment.start_clock_s),
                "sample_count": len(segment.samples),
                "last_elapsed_s": max(vals) if vals else None,
            })

        dump_service = SpectrumDumpImportService()
        candidates = []
        mapping = {}
        try:
            candidates = dump_service.discover(root)
            mapping = dump_service.map_candidates_to_sonications(candidates, list(package.sonications), workspace=root)
        except Exception as exc:
            errors.append(f"CPC discovery/mapping failed: {type(exc).__name__}: {exc}")

        candidate_rows = []
        for c in candidates:
            candidate_rows.append({
                "family": c.family,
                "relative_path": c.relative_path,
                "completeness": c.completeness,
                "raw_size": self._safe_size(c.raw_path),
                "fft_size": self._safe_size(c.fft_path),
                "filename_clock_s": dump_service._candidate_clock_s(c),
                "acquisition_session_index": c.acquisition_session_index,
                "acquisition_session_end_error_s": c.acquisition_session_end_error_s,
                "mapping_confidence": c.mapping_confidence,
                "mapping_evidence": c.mapping_evidence,
            })

        setup_records = []
        try:
            records = SonicationEvidenceService().parse_setup_records(root)
            for row in records:
                setup_records.append({
                    "sonication_index": getattr(row, "sonication_index", None),
                    "clock_s": getattr(row, "clock_s", None),
                    "source": self._rel(getattr(row, "source", None), root),
                    "steering_xyz": list(getattr(row, "steering_xyz", ()) or ()),
                })
        except Exception as exc:
            errors.append(f"Sonication_Brain setup parse failed: {type(exc).__name__}: {exc}")

        transducer_location_rows = []
        transducer_raw_report_count = 0
        transducer_raw_zero_xyz_count = 0
        transducer_locate_evidence = []
        transducer_discovery_evidence = []
        transducer_xd_context_samples = []
        try:
            transducer_service=TransducerLocationService()
            raw_reports=transducer_service.raw_xd_reports(root)
            transducer_raw_report_count=len(raw_reports)
            transducer_raw_zero_xyz_count=sum(1 for row in raw_reports if abs(row.x) <= 1e-9 and abs(row.y) <= 1e-9 and abs(row.z) <= 1e-9)
            for ev in transducer_service.locate_evidence(root):
                transducer_locate_evidence.append({
                    "clock_s": ev.clock_s,
                    "source": self._rel(ev.source, root),
                    "line_number": int(ev.line_number),
                    "text": ev.text,
                    "context": list(ev.context),
                    "evidence_kind": getattr(ev, "evidence_kind", "explicit-locate"),
                })
            for ev in transducer_service.discovery_evidence(root):
                transducer_discovery_evidence.append({
                    "clock_s": ev.clock_s,
                    "source": self._rel(ev.source, root),
                    "line_number": int(ev.line_number),
                    "text": ev.text,
                    "context": list(ev.context),
                    "evidence_kind": getattr(ev, "evidence_kind", "broad-workflow-candidate"),
                })
            for ev in transducer_service.raw_xd_context_samples(root):
                transducer_xd_context_samples.append({
                    "clock_s": ev.clock_s,
                    "source": self._rel(ev.source, root),
                    "line_number": int(ev.line_number),
                    "text": ev.text,
                    "context": list(ev.context),
                    "evidence_kind": "xd-context-sample",
                })
            for row in transducer_service.parse(root):
                transducer_location_rows.append({
                    "timestamp": row.timestamp.isoformat(timespec="milliseconds") if row.timestamp is not None else None,
                    "clock_s": float(row.clock_s),
                    "trigger": str(row.trigger),
                    "x": float(row.x),
                    "y": float(row.y),
                    "z": float(row.z),
                    "roll": row.roll,
                    "pitch": row.pitch,
                    "delta_x": float(row.delta_x),
                    "delta_y": float(row.delta_y),
                    "delta_z": float(row.delta_z),
                    "displacement": float(row.displacement),
                    "steering_xyz": [row.steering_x, row.steering_y, row.steering_z],
                    "related_sonication": row.related_sonication,
                    "related_startsonicate_delta_s": row.related_delta_s,
                    "locate_event_line": row.locate_event_line,
                    "locate_event_clock_s": row.locate_event_clock_s,
                    "locate_event_text": row.locate_event_text,
                    "source": self._rel(row.source, root),
                    "line_number": int(row.line_number),
                })
        except Exception as exc:
            errors.append(f"Transducer location history parse failed: {type(exc).__name__}: {exc}")

        sonications = []
        replay_service=ReplayService()
        hydrophone_service=HydrophoneReplayService()
        for pos, son in enumerate(package.sonications, start=1):
            number = int(getattr(son, "sonication_number", 0) or pos)
            # SpectrumDumpImportService mapping keys are zero-based package
            # indices. Diagnostics previously looked them up by Sonication number,
            # which could make a healthy mapping look shifted or absent.
            mapped = mapping.get(pos - 1)
            protocol_decision=None; protocol_reason="Unavailable"; temperature={}
            try:
                protocol_decision,protocol_reason=replay_service._thermometry_protocol(son)
                if getattr(son,"temperature_frames",[]) or []:
                    temperature=replay_service.temperature_metrics(son)
                else:
                    temperature={"source":"Unavailable","frames":0,"start_temp":None,"peak_temp":None,"delta_temp":None}
            except Exception as exc:
                errors.append(f"Sonication {number} thermometry audit failed: {type(exc).__name__}: {exc}")
            spectrummsg_frames=0; spectrummsg_start=None; spectrummsg_end=None
            try:
                msg=next((Path(p) for p in getattr(son,"spectrum_files",[]) or [] if "spectrummsg" in Path(p).name.lower()),None)
                hz=float(getattr(son,"main_frequency_hz",None) or getattr(package,"main_frequency_hz",None) or 0.0)
                if msg is not None and hz>0:
                    aggregate=SpectrumMsgAggregateService().build(msg,hz)
                    at=np.asarray(getattr(aggregate,"mr_frame_times_s",[]),float).reshape(-1)
                    at=at[np.isfinite(at)]
                    spectrummsg_frames=len(getattr(aggregate,"frames",[]) or [])
                    if at.size: spectrummsg_start=float(at[0]); spectrummsg_end=float(at[-1])
            except Exception as exc:
                errors.append(f"Sonication {number} SpectrumMsg coverage audit failed: {type(exc).__name__}: {exc}")
            physical_frames=0; rule_samples=0; rule_start=None; rule_end=None
            try:
                if mapped is not None and mapped.family=="CPC Spectrum":
                    physical=hydrophone_service.build_direct(mapped.fft_path,mapped.raw_path,include_vendor_validation=False)
                    physical_frames=len(getattr(physical,"frames",[]) or [])
                    pt=np.asarray(getattr(physical,"mr_raw_timeline_time_s",[]),float).reshape(-1)
                    rule=np.asarray(getattr(physical,"vendor_display_rule1",[]),float).reshape(-1)
                    n=min(pt.size,rule.size); valid=np.isfinite(pt[:n])&np.isfinite(rule[:n])
                    rule_samples=int(np.count_nonzero(valid))
                    if rule_samples: rule_start=float(pt[:n][valid][0]); rule_end=float(pt[:n][valid][-1])
            except Exception as exc:
                errors.append(f"Sonication {number} CPC coverage audit failed: {type(exc).__name__}: {exc}")
            sonications.append({
                "number": number,
                "synthetic_identity": bool(getattr(son, "synthetic_identity", False)),
                "physical_folder_count": len(getattr(son, "evidence_folders", []) or []),
                "identity_evidence": list(getattr(son, "identity_evidence", []) or []),
                "spectrummsg_files": len(getattr(son, "spectrum_files", []) or []),
                "act_files": len(getattr(son, "act_files", []) or []),
                "canonical_acquisition_session_index": getattr(son, "canonical_acquisition_session_index", None),
                "canonical_mapping_confidence": getattr(son, "canonical_mapping_confidence", None),
                "canonical_mapping_evidence": list(getattr(son, "canonical_mapping_evidence", []) or []),
                "mapped_cpc": mapped.relative_path if mapped is not None else None,
                "mapped_cpc_confidence": mapped.mapping_confidence if mapped is not None else None,
                "mapped_cpc_evidence": mapped.mapping_evidence if mapped is not None else None,
                "mr_timeline_source": getattr(son, "mr_timeline_source", None),
                "mr_timeline_confidence": getattr(son, "mr_timeline_confidence", None),
                "mr_sonication_start_s": getattr(son, "mr_sonication_start_s", None),
                "mr_sonication_end_s": getattr(son, "mr_sonication_end_s", None),
                "clock_sync_status": getattr(son, "clock_sync_status", None),
                "cpc_to_ws_clock_offset_s": getattr(son, "cpc_to_ws_clock_offset_s", None),
                "clock_sync_anchor_count": getattr(son, "clock_sync_anchor_count", None),
                "clock_sync_spread_s": getattr(son, "clock_sync_spread_s", None),
                "thermometry": {
                    "candidate_raw_frames": len(getattr(son,"temperature_frames",[]) or []),
                    "protocol_decision": protocol_decision,
                    "protocol_evidence": protocol_reason,
                    "source": temperature.get("source"),
                    "replay_aligned_finite_samples": temperature.get("frames",0),
                    "start_temp_c": temperature.get("start_temp"),
                    "peak_temp_c": temperature.get("peak_temp"),
                    "delta_temp_c": temperature.get("delta_temp"),
                    "source_frame_audit": self._thermometry_source_frame_audit(replay_service, son),
                },
                "acoustic_coverage": {
                    "spectrummsg_frames": spectrummsg_frames,
                    "spectrummsg_start_s": spectrummsg_start,
                    "spectrummsg_end_s": spectrummsg_end,
                    "physical_cpc_frames": physical_frames,
                    "cpc_rule1_samples": rule_samples,
                    "cpc_rule1_start_s": rule_start,
                    "cpc_rule1_end_s": rule_end,
                    "sonication_end_s": getattr(son,"mr_sonication_end_s",None),
                    "interpretation": "SpectrumMsg hydrophone coverage and physical CPC Rule/Score coverage are independent; no control values are extrapolated.",
                },
            })

        empty_sonication_folders=[]
        try:
            import re as _re
            for folder in root.rglob("*"):
                if not folder.is_dir() or not _re.fullmatch(r"Sonication\d+", folder.name, _re.I):
                    continue
                if not any(p.is_file() for p in folder.rglob("*")):
                    empty_sonication_folders.append(self._rel(folder, root))
        except Exception as exc:
            errors.append(f"empty Sonication-folder inventory failed: {type(exc).__name__}: {exc}")

        return {
            "schema": "Soni import diagnostics v2",
            "app_version": APP_VERSION,
            "app_commit": APP_COMMIT,
            "privacy": "Metadata plus small bounded transducer/localization log snippets for diagnostics. No treatment payload bytes, MR images, or Spectrum samples are included.",
            "source": {
                "kind": "zip" if Path(package.source).suffix.lower() == ".zip" else "folder",
                "name": Path(package.source).name,
                "workspace_file_count": len(files),
                "suffix_counts": dict(sorted(suffix_counts.items())),
                "nested_zip_count": sum(1 for p in files if p.suffix.lower() == ".zip"),
            },
            "import_audit": dict(getattr(package, "import_audit", {}) or {}),
            "acoustic_system": {
                "family": getattr(package, "acoustic_system_family", "Unknown"),
                "profile": getattr(package, "acoustic_system_profile", "Unknown"),
                "conflict": bool(getattr(package, "acoustic_system_conflict", False)),
                "main_frequency_hz": getattr(package, "main_frequency_hz", None),
                "main_frequency_interpretation": getattr(package, "main_frequency_interpretation", None),
                "evidence": list(getattr(package, "acoustic_system_evidence", []) or []),
            },
            "ignored_empty_sonication_folders": sorted(v for v in empty_sonication_folders if v),
            "acquisition_brain": {
                "candidate_count": len(acq_candidates),
                "selected": self._rel(selected_acq, root),
                "candidates": acq_rows,
                "parsed_sessions": session_rows,
            },
            "sonication_brain": {
                "setup_record_count": len(setup_records),
                "setup_records": setup_records,
            },
            "transducer_location_history": {
                "record_count": len(transducer_location_rows),
                "confirmed_locate_result_count": len(transducer_location_rows),
                "raw_xd_report_count": int(transducer_raw_report_count),
                "raw_zero_xyz_count": int(transducer_raw_zero_xyz_count),
                "locate_workflow_evidence_count": len(transducer_locate_evidence),
                "broad_discovery_evidence_count": len(transducer_discovery_evidence),
                "xd_context_sample_count": len(transducer_xd_context_samples),
                "max_displacement_from_first_confirmed": max((float(row.get("displacement", 0.0) or 0.0) for row in transducer_location_rows), default=0.0),
                "records": transducer_location_rows,
                "locate_workflow_evidence": transducer_locate_evidence,
                "broad_discovery_evidence": transducer_discovery_evidence,
                "xd_context_samples": transducer_xd_context_samples,
                "interpretation": "R0175 still publishes only non-zero Xd location reports causally associated with an explicit Locate Transducer workflow event. Broad transducer/localization evidence and bounded Xd contexts are diagnostics-only and never promote a result. Steering XYZ is electronic steering and is never substituted for physical X/Y/Z.",
            },
            "cpc": {
                "candidate_count": len(candidates),
                "physical_candidate_count": sum(c.family == "CPC Spectrum" for c in candidates),
                "spectrummsg_candidate_count": sum(c.family == "SpectrumMsg" for c in candidates),
                "mapped_count": len(mapping),
                "candidates": candidate_rows,
            },
            "sonications": sonications,
            "relevant_file_inventory": relevant_inventory,
            "diagnostic_errors": errors,
        }
