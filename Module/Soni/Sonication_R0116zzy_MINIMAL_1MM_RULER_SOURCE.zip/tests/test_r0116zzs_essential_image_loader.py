from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
TEXT=(ROOT/"src/ui/main_window.py").read_text(encoding="utf-8")

def _body(start,end):
    return TEXT[TEXT.index(start):TEXT.index(end)]

def test_initial_image_load_uses_one_deterministic_essential_worker():
    body=_body("def _build_frame_navigator", "def _cancel_essential_image_worker")
    assert "QTimer.singleShot(40" in body
    assert "_start_essential_image_background" in body
    assert "QTimer.singleShot(90,self._start_thermal_thumbnail_background)" not in body
    assert "QTimer.singleShot(40,self._start_image_thumbnail_background)" not in body

def test_essential_worker_excludes_reference_planning_and_orders_live_roles():
    body=_body("class EssentialImageLoadWorker", "class SonicationSummaryDetailWorker")
    assert "self._run_role('treatment_mr',self.magnitude_frames)" in body
    assert "self._run_role('thermal',self.temperature_frames)" in body
    assert "self.reference" not in body.lower()
    assert "planning_assets" not in body.lower()

def test_each_raw_has_trace_and_circuit_breaker():
    body=_body("class EssentialImageLoadWorker", "class SonicationSummaryDetailWorker")
    assert "path.stat().st_size" in body
    assert "thread.join(self.per_file_timeout_s)" in body
    assert "RAW read exceeded" in body
    assert "SKIP" in body
    assert "image_load_trace.log" in TEXT

def test_reference_not_in_blocking_progress_denominator():
    assert 'self._image_load_expected = {"reference":0, "treatment_mr":mr_count, "thermal":thermal_count}' in TEXT

def test_no_icon_generation_in_essential_frame_ready():
    body=_body("def _essential_image_frame_ready", "def _essential_image_role_finished")
    assert "_array_icon" not in body
    assert "_thermal_red_overlay_icon" not in body
