from pathlib import Path
from types import SimpleNamespace

from src.services.cavitation_control_timeline_service import CavitationControlTimelineService

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
PROGRESS=(ROOT/'src/ui/progress_window.py').read_text(encoding='utf-8')


def event(family,before,after,result='',active=True):
    return SimpleNamespace(
        family=family,before_power_ratio=before,after_power_ratio=after,result=result,
        irradiation_state='Irradiation active' if active else 'Pre-irradiation',counts_as_cavitation=active,
    )


def test_modulation_severity_tracks_cumulative_observed_power_reduction():
    m=CavitationControlTimelineService.control_response_severity([
        event('Decrease',1.0,0.8), event('Decrease',0.8,0.6),
    ])
    assert round(m['severity'],6)==40.0
    assert m['modulation_count']==2
    assert m['safety_stop_count']==0


def test_safety_halt_is_maximum_control_response_severity():
    m=CavitationControlTimelineService.control_response_severity([
        event('Decrease',1.0,0.9), event('Safety',0.9,0.0,'HALTED BY CAVITATION'),
    ])
    assert m['severity']==100.0
    assert m['safety_stop_count']==1


def test_pre_irradiation_events_do_not_inflate_severity():
    m=CavitationControlTimelineService.control_response_severity([
        event('Decrease',1.0,0.5,active=False),
    ])
    assert m['event_count']==0
    assert m['severity'] is None


def test_summary_has_new_columns_and_lightweight_cpc_path():
    assert '"Cavitation severity","Energy delivered (%)"' in MAIN
    body=MAIN[MAIN.index('def _build_one_sonication_summary'):MAIN.index('def _cancel_sonication_summary_worker')]
    assert '_build_cpc_replay' not in body
    assert 'cavitation_control_timeline_service.parse' in body
    assert 'measured_energy=actual_energy' in body
    assert 'energy_delivered_pct=float(np.clip(100.0*float(measured_energy)/float(target_energy),0.0,100.0))' in body
    assert 'canonical.detected' in body and 'canonical.status' in body


def test_summary_background_progress_is_visible_and_non_modal():
    assert 'progress = Signal(int, int, int, str)' in MAIN
    assert 'self._summary_progress.show_progress' in MAIN
    assert 'class BackgroundProgressDialog' in PROGRESS
    assert 'Qt.WindowModality.NonModal' in PROGRESS

def test_summary_refresh_does_not_overlap_workers():
    assert 'if not self._cancel_sonication_summary_worker()' in MAIN
    assert 'self._sonication_summary_pending_refresh=True' in MAIN
    assert 'thread.quit(); thread.wait(120)' not in MAIN
