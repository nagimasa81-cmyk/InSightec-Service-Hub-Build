from __future__ import annotations

import logging
from pathlib import Path

from src.services.spectrum_dump_import_service import SpectrumDumpImportService
from src.services.hydrophone_replay_service import HydrophoneReplayService
from src.services.standalone_cavitation_service import StandaloneCavitationService
from src.services.canonical_cavitation_evidence_service import CanonicalCavitationEvidenceService

LOG = logging.getLogger(__name__)


class SonicationSummaryCavitationEvidenceService:
    """Background-only cavitation evidence builder for Sonication Summary.

    The MainWindow must not perform Spectrum discovery/decode itself.  This service
    owns those expensive operations and caches both workspace candidate mappings and
    per-Sonication canonical evidence.  It is intentionally called only by the
    existing SonicationSummaryDetailWorker callback.
    """

    def __init__(
        self,
        hydrophone_replay_service: HydrophoneReplayService,
        acoustic_control_service,
        standalone_cavitation_service: StandaloneCavitationService | None = None,
        canonical_service: CanonicalCavitationEvidenceService | None = None,
        likelihood_service=None,
    ) -> None:
        self.hydrophone_replay_service = hydrophone_replay_service
        self.acoustic_control_service = acoustic_control_service
        self.standalone_cavitation_service = standalone_cavitation_service or StandaloneCavitationService()
        self.canonical_service = canonical_service or CanonicalCavitationEvidenceService()
        self.likelihood_service = likelihood_service
        self._mapping_token = None
        self._mapping = {}
        self._evidence_token = None
        self._evidence = {}

    @staticmethod
    def _workspace_token(package) -> str:
        try:
            return str(Path(package.workspace).resolve())
        except Exception:
            return str(getattr(package, "workspace", ""))

    def clear_cache(self) -> None:
        self._mapping_token = None
        self._mapping = {}
        self._evidence_token = None
        self._evidence = {}

    def candidate_mapping(self, package):
        token = self._workspace_token(package)
        if self._mapping_token == token:
            return self._mapping
        importer = SpectrumDumpImportService()
        workspace = Path(package.workspace)
        inventory = list(getattr(package, "cpc_spectrum_files", []) or [])
        candidates = importer.discover_from_files(workspace, inventory)
        if not any(getattr(c, "family", "") == "CPC Spectrum" for c in candidates):
            candidates = importer.discover(workspace)
        mapping = importer.map_candidates_to_sonications(
            candidates, list(getattr(package, "sonications", []) or [])
        )
        self._mapping_token = token
        self._mapping = mapping
        self._evidence_token = token
        self._evidence = {}
        return mapping

    def analyze(self, package, index: int, son, timeline_events):
        token = self._workspace_token(package)
        if self._evidence_token != token:
            self._evidence_token = token
            self._evidence = {}
        key = int(index)
        cached = self._evidence.get(key)
        if cached is not None:
            return cached

        replay = None
        standalone = None
        try:
            candidate = self.candidate_mapping(package).get(key)
            if candidate is not None:
                replay = self.hydrophone_replay_service.build_direct(
                    candidate.fft_path, candidate.raw_path, include_vendor_validation=True
                )
                if replay is not None and getattr(replay, "frames", None):
                    preferred = getattr(
                        getattr(replay, "vendor_history_validation", None),
                        "log_session_index",
                        None,
                    )
                    if preferred is None:
                        preferred = getattr(candidate, "acquisition_session_index", None)
                    if preferred is None:
                        preferred = getattr(son, "canonical_acquisition_session_index", None)
                    replay.acquisition_session_index = (
                        int(preferred) if preferred is not None else None
                    )
                    replay.sonication_time_zero_offset_s = self.acoustic_control_service.sonication_time_zero_offset(
                        Path(package.workspace), key, replay.acquisition_session_index
                    )
                    replay.mr_timeline_duration_s = float(
                        getattr(son, "mr_timeline_duration_s", 0.0) or 0.0
                    )
                    replay.mr_sonication_start_s = float(
                        getattr(son, "mr_sonication_start_s", 0.0) or 0.0
                    )
                    replay.mr_sonication_end_s = float(
                        getattr(son, "mr_sonication_end_s", 0.0) or 0.0
                    )
                    standalone = self.standalone_cavitation_service.analyze(
                        replay, "Auto Evidence-First", 6.0
                    )
        except Exception as exc:
            LOG.debug(
                "Summary Spectrum cavitation evidence unavailable for Sonication %s: %s",
                key + 1,
                exc,
            )

        canonical = self.canonical_service.combine(timeline_events, standalone)
        likelihood = None
        if canonical.detected and replay is not None and getattr(replay, "frames", None) and self.likelihood_service is not None:
            try:
                if canonical.observed_events:
                    ev=canonical.observed_events[0]
                    cycle=getattr(ev,"cycle",None)
                    frame_index=0
                    if cycle is not None:
                        choices=[]
                        for i,fr in enumerate(replay.frames):
                            fc=getattr(fr,"acquisition_cycle",None)
                            if fc is not None:
                                choices.append((abs(int(fc)-int(cycle)),i))
                        if choices: frame_index=min(choices)[1]
                    likelihood=self.likelihood_service.estimate(replay,int(frame_index),ev)
                elif canonical.vendor_rule_events:
                    ev=canonical.vendor_rule_events[0]
                    frame_index=int(getattr(ev,"snapshot_index",0) or 0)
                    frame_index=max(0,min(frame_index,len(replay.frames)-1))
                    likelihood=self.likelihood_service.estimate(replay,frame_index,None)
            except Exception as exc:
                LOG.debug("Summary probable-location evidence unavailable for Sonication %s: %s", key+1, exc)
        payload = {"canonical": canonical, "replay": replay, "standalone": standalone, "likelihood": likelihood}
        self._evidence[key] = payload
        return payload
