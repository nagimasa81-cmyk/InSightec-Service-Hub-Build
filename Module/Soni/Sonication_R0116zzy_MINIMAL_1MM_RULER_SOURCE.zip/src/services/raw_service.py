from __future__ import annotations
from pathlib import Path
import numpy as np
from src.common.constants import IMAGE_SHAPE

class RawDecodeError(RuntimeError): pass

class RawService:
    @staticmethod
    def _validate_exact_raw_size(path: Path, dtype, expected_values: int, label: str) -> None:
        dt=np.dtype(dtype)
        expected_bytes=int(expected_values)*int(dt.itemsize)
        try:
            actual_bytes=int(Path(path).stat().st_size)
        except Exception as exc:
            raise RawDecodeError(f'{label} RAW size could not be read: {exc}') from exc
        if actual_bytes != expected_bytes:
            actual_values = actual_bytes / max(1, dt.itemsize)
            raise RawDecodeError(
                f'{label} RAW has {actual_bytes} bytes ({actual_values:g} values); '
                f'expected exactly {expected_bytes} bytes ({expected_values} values).'
            )

    def read_temperature(self,path:Path)->np.ndarray:
        expected=IMAGE_SHAPE[0]*IMAGE_SHAPE[1]
        self._validate_exact_raw_size(path,'<f4',expected,'Temperature')
        data=np.fromfile(path,dtype='<f4',count=expected)
        if data.size!=expected: raise RawDecodeError(f'Temperature RAW read returned {data.size} values; expected {expected}.')
        return data.reshape(IMAGE_SHAPE)
    def read_magnitude(self,path:Path)->np.ndarray:
        expected=IMAGE_SHAPE[0]*IMAGE_SHAPE[1]
        self._validate_exact_raw_size(path,'<u2',expected,'Magnitude')
        data=np.fromfile(path,dtype='<u2',count=expected)
        if data.size!=expected: raise RawDecodeError(f'Magnitude RAW read returned {data.size} values; expected {expected}.')
        return data.reshape(IMAGE_SHAPE).astype(np.float32)
    @staticmethod
    def normalize_index(replay_index:int,replay_count:int,series_count:int)->int:
        if series_count<=1 or replay_count<=1: return 0
        return min(series_count-1,round(replay_index*(series_count-1)/(replay_count-1)))
