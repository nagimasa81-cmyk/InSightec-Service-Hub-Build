from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
import math
import re


_CLOCK_RE = re.compile(r"(?P<h>\d{2}):(?P<m>\d{2}):(?P<s>\d{2}):(?P<ms>\d{3})")
_FLOAT = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"
_XD_RE = re.compile(
    rf"Xd\s*loc\s*XYZ\s*:\s*\(?\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*\)?"
    rf"(?:\s*,?\s*roll\s*:\s*({_FLOAT}))?"
    rf"(?:\s*,?\s*pitch\s*:\s*({_FLOAT}))?"
    rf"(?:\s*,?\s*Steering\s*:\s*\(?\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*\)?)?",
    re.I,
)
_TRACKER_XD_CSA_RE = re.compile(
    rf"New\s+XD\s+pos\.\s+in\s+CSA\s+coords\.\s+according\s+to\s+trackers\s*-\s*"
    rf"X\s*:\s*({_FLOAT})\s*,\s*Y\s*:\s*({_FLOAT})\s*,\s*Z\s*:\s*({_FLOAT})"
    rf"(?:\s*,\s*Roll\s*:\s*({_FLOAT}))?(?:\s*,\s*Pitch\s*:\s*({_FLOAT}))?", re.I)
_TRACKER_TILT_RE = re.compile(rf"Transducer\s+tilt\s*:\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)", re.I)
_TRACKER_RELIABILITY_RE = re.compile(r"TRACKERS\s+SELECTION\s*:\s*Xd\s+location\s+was\s+decoded\s+from\s+the\s+trackers\s+with\s+([^\r\n]+?)(?:\s*\(|$)", re.I)
_TRACKER_RETURN_RE = re.compile(r"CalculateXdPosition\s+return\s+([A-Z0-9_]+)", re.I)
_TRACKER_PQR_RE = re.compile(rf"tracker\s+([0-3])\s+coordinates\s*:\s*PQR\s*:\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)", re.I)
_TRACKER_FOUND_UVW_RE = re.compile(rf"Found\s+TrackerPos\s+([0-3])\s*is\s*:\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)", re.I)
_HOME_UVW_RE = re.compile(rf"(?:Home\s+position\s+read.*?UVW\s*=\s*\(|Set\s+new\s+home\s+position\s*:\s*orig\s*:\s*)({_FLOAT})[ ,]+({_FLOAT})[ ,]+({_FLOAT})", re.I)
_START_RE = re.compile(r"\[CGeneralSonicationLogic::StartSonicate\]\s*Sonication Counter\s*:\s*(\d+)", re.I)
# R0174: an ordinary 'Xd loc XYZ' state report is NOT itself a Locate Transducer
# event.  Only explicit operator/workflow phrases may open an association window.
_LOCATE_EVENT_RE = re.compile(
    r"(?:\blocate\s+transducer\b|\btransducer\s+locat(?:e|ion|ing)\b|"
    r"\blocat(?:e|ing)\s+(?:the\s+)?xd\b|\bxd\s+transducer\s+locat(?:e|ion|ing)\b)",
    re.I,
)
# R0175 diagnostics-only discovery signature.  This deliberately does NOT
# promote a row to a confirmed location result.  It exists solely to reveal
# the workstation's real vendor wording in the next diagnostic package.
_LOCATE_DISCOVERY_RE = re.compile(
    r"(?:\btransducer\b|\blocali[sz](?:e|ed|ing|ation)\b|\blocat(?:e|ed|ing|ion)\b|"
    r"\bregistration\b|\bposition(?:ing)?\b|\bpose\b|\bdetector\b|\bxd\s*loc\b)",
    re.I,
)
_FILE_DATE_RE = re.compile(r"(?P<year>20\d{2})[_-](?P<mon>[A-Za-z]{3}|\d{1,2})[_-](?P<day>\d{1,2})", re.I)
_MONTHS = {m.lower(): i for i, m in enumerate(("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"), 1)}


@dataclass(slots=True)
class TransducerLocationRecord:
    timestamp: datetime | None
    clock_s: float
    x: float
    y: float
    z: float
    roll: float | None
    pitch: float | None
    steering_x: float | None
    steering_y: float | None
    steering_z: float | None
    source: Path
    line_number: int
    trigger: str = "Locate Transducer"
    related_sonication: int | None = None
    related_delta_s: float | None = None
    delta_x: float = 0.0
    delta_y: float = 0.0
    delta_z: float = 0.0
    displacement: float = 0.0
    coordinate_frame: str = "CSA"
    reliability: str | None = None
    reliability_code: str | None = None
    tilt_x: float | None = None
    tilt_y: float | None = None
    tilt_z: float | None = None
    tracker_pqr: tuple[tuple[float, float, float] | None, ...] = (None, None, None, None)
    tracker_uvw: tuple[tuple[float, float, float] | None, ...] = (None, None, None, None)
    home_uvw: tuple[float, float, float] | None = None
    locate_event_line: int | None = None
    locate_event_clock_s: float | None = None
    locate_event_text: str | None = None


@dataclass(slots=True)
class LocateTransducerEvidence:
    source: Path
    line_number: int
    clock_s: float | None
    text: str
    context: tuple[str, ...]
    evidence_kind: str = "explicit-locate"


class TransducerLocationService:
    """Extract *confirmed/associated* Locate Transducer position results.

    Workstation logs also emit recurring ``Xd loc XYZ`` state lines during normal
    operation.  R0173 incorrectly presented every one of those rows as a physical
    location history.  R0174 keeps those raw reports as diagnostic evidence only
    and publishes a location record only when an explicit Locate Transducer
    workflow/event precedes the report inside a bounded time window.

    ``Steering XYZ`` remains a separate electronic-steering field; it is never
    substituted for physical X/Y/Z.
    """

    LOCATE_ASSOCIATION_WINDOW_S = 30.0
    LOCATE_ASSOCIATION_MAX_LINES = 120

    @staticmethod
    def _clock_s(line: str) -> float | None:
        m = _CLOCK_RE.search(line)
        if not m:
            return None
        return (int(m.group("h"))*3600.0 + int(m.group("m"))*60.0 + int(m.group("s")) + int(m.group("ms"))/1000.0)

    @staticmethod
    def _date_from_name(path: Path) -> datetime | None:
        m = _FILE_DATE_RE.search(path.name)
        if not m:
            return None
        mon_raw=m.group("mon")
        try:
            mon=int(mon_raw) if mon_raw.isdigit() else _MONTHS[mon_raw.lower()]
            return datetime(int(m.group("year")), mon, int(m.group("day")))
        except Exception:
            return None

    @staticmethod
    def _candidate_logs(workspace: Path) -> list[Path]:
        logs=[]
        for pattern in ("*.Log", "*.log"):
            logs.extend(Path(workspace).rglob(pattern))
        return sorted(set(logs), key=lambda p: (0 if "wsfiles" in str(p.parent).lower() else 1, len(p.parts), str(p).lower()))

    @staticmethod
    def _is_nonzero_location(x: float, y: float, z: float) -> bool:
        # (0,0,0) is common as an unpopulated/default state in real exports.  It
        # must never become the displacement baseline without an independently
        # confirmed Locate workflow result.
        return bool(abs(float(x)) > 1e-9 or abs(float(y)) > 1e-9 or abs(float(z)) > 1e-9)

    def locate_evidence(self, workspace: Path, context_radius: int = 5) -> list[LocateTransducerEvidence]:
        """Return explicit Locate/Transducer workflow lines plus nearby raw context.

        This is intentionally diagnostic evidence, not a location parser.  It lets
        the next real export reveal the workstation's exact success/result wording
        without hard-coding an unobserved vendor signature.
        """
        out=[]
        seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            for i,line in enumerate(lines):
                if not _LOCATE_EVENT_RE.search(line):
                    continue
                key=(str(path.resolve()), i)
                if key in seen:
                    continue
                seen.add(key)
                lo=max(0,i-int(context_radius)); hi=min(len(lines),i+int(context_radius)+1)
                out.append(LocateTransducerEvidence(
                    source=path, line_number=i+1, clock_s=self._clock_s(line), text=line.strip(),
                    context=tuple(lines[lo:hi]),
                ))
        return out


    def discovery_evidence(self, workspace: Path, context_radius: int = 5, max_rows: int = 300) -> list[LocateTransducerEvidence]:
        """Return broad transducer/localization workflow evidence for diagnostics only.

        R0174 proved that the real workstation export does not necessarily spell
        the operation ``Locate Transducer``.  This intentionally broad scan is
        never used by :meth:`parse`; it only serializes small, bounded snippets
        so the vendor's actual success/result wording can be learned from a real
        export without guessing.
        """
        out=[]; seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            for i,line in enumerate(lines):
                if not _LOCATE_DISCOVERY_RE.search(line):
                    continue
                key=(str(path.resolve()),i)
                if key in seen:
                    continue
                seen.add(key)
                lo=max(0,i-int(context_radius)); hi=min(len(lines),i+int(context_radius)+1)
                kind=("explicit-locate" if _LOCATE_EVENT_RE.search(line) else
                      "xd-state-report" if _XD_RE.search(line) else "broad-workflow-candidate")
                out.append(LocateTransducerEvidence(
                    source=path,line_number=i+1,clock_s=self._clock_s(line),text=line.strip(),
                    context=tuple(lines[lo:hi]),evidence_kind=kind,
                ))
                if len(out) >= int(max_rows):
                    return out
        return out

    def raw_xd_context_samples(self, workspace: Path, context_radius: int = 4, max_rows: int = 24) -> list[LocateTransducerEvidence]:
        """Return bounded first/middle/last Xd-report contexts for diagnostics."""
        candidates=[]
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            hits=[i for i,line in enumerate(lines) if _XD_RE.search(line)]
            if not hits:
                continue
            # Preserve boundary and evenly-spaced evidence without dumping the log.
            if len(hits) <= max_rows:
                chosen=hits
            else:
                step=(len(hits)-1)/float(max_rows-1)
                chosen=sorted({hits[int(round(k*step))] for k in range(max_rows)})
            for i in chosen:
                lo=max(0,i-int(context_radius)); hi=min(len(lines),i+int(context_radius)+1)
                candidates.append(LocateTransducerEvidence(
                    source=path,line_number=i+1,clock_s=self._clock_s(lines[i]),text=lines[i].strip(),
                    context=tuple(lines[lo:hi]),evidence_kind="xd-context-sample",
                ))
                if len(candidates) >= int(max_rows):
                    return candidates
        return candidates

    def raw_xd_reports(self, workspace: Path) -> list[TransducerLocationRecord]:
        """Return all recurring Xd state reports for diagnostics only."""
        records=[]; seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            base_date=self._date_from_name(path)
            starts=[]
            for i,line in enumerate(lines):
                sm=_START_RE.search(line); cs=self._clock_s(line)
                if sm and cs is not None:
                    starts.append((cs, int(sm.group(1))+1, i))
            locate_events=[]
            for i,line in enumerate(lines):
                if _LOCATE_EVENT_RE.search(line):
                    locate_events.append((self._clock_s(line), i, line.strip()))
            for i,line in enumerate(lines):
                m=_XD_RE.search(line)
                if not m:
                    continue
                cs=self._clock_s(line)
                if cs is None:
                    continue
                vals=[float(m.group(j)) if m.group(j) is not None else None for j in range(1,9)]
                x,y,z=vals[:3]
                key=(round(cs,3), round(x,6), round(y,6), round(z,6), str(path.resolve()), i)
                if key in seen:
                    continue
                seen.add(key)
                timestamp=(base_date + timedelta(seconds=cs)) if base_date is not None else None
                assoc=None
                # Causal association only: an explicit Locate event must precede
                # the Xd report.  A later event cannot retroactively label it.
                candidates=[]
                for ev_cs, ev_i, ev_text in locate_events:
                    if ev_i >= i or i-ev_i > self.LOCATE_ASSOCIATION_MAX_LINES:
                        continue
                    if ev_cs is not None:
                        dt=cs-ev_cs
                        if dt < 0 or dt > self.LOCATE_ASSOCIATION_WINDOW_S:
                            continue
                    else:
                        dt=None
                    candidates.append((ev_i, ev_cs, ev_text, dt))
                if candidates:
                    assoc=max(candidates,key=lambda q:q[0])
                related=None; related_delta=None
                if starts:
                    best=min(starts, key=lambda row: abs(row[0]-cs)); delta=best[0]-cs
                    if abs(delta) <= 180.0:
                        related=best[1]; related_delta=float(delta)
                records.append(TransducerLocationRecord(
                    timestamp=timestamp, clock_s=float(cs), x=float(x), y=float(y), z=float(z),
                    roll=vals[3], pitch=vals[4], steering_x=vals[5], steering_y=vals[6], steering_z=vals[7],
                    source=path, line_number=i+1,
                    trigger="Locate Transducer" if assoc is not None else "XD state report",
                    related_sonication=related, related_delta_s=related_delta,
                    locate_event_line=(assoc[0]+1 if assoc is not None else None),
                    locate_event_clock_s=(assoc[1] if assoc is not None else None),
                    locate_event_text=(assoc[2] if assoc is not None else None),
                ))
        records.sort(key=lambda r: ((r.timestamp or datetime.min), r.clock_s, str(r.source).lower(), r.line_number))
        return records

    def tracker_localizations(self, workspace: Path) -> list[TransducerLocationRecord]:
        """Return tracker-derived XD localization results in the workstation CSA frame.

        R0176 is grounded in the real vendor sequence observed in diagnostics:
        tracker coordinates -> Transducer tilt -> TRACKERS SELECTION reliability ->
        ``New XD pos. in CSA coords. according to trackers``.  The latter line is
        the authoritative XYZ result.  Recurring ``Xd loc XYZ`` state reports and
        ``Location sent on MoveTo`` are deliberately ignored.
        """
        records=[]; seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            base_date=self._date_from_name(path)
            starts=[]
            home_updates=[]
            for i,line in enumerate(lines):
                cs=self._clock_s(line)
                sm=_START_RE.search(line)
                if sm and cs is not None:
                    starts.append((cs,int(sm.group(1))+1,i))
                hm=_HOME_UVW_RE.search(line)
                if hm and cs is not None:
                    home_updates.append((cs,i,(float(hm.group(1)),float(hm.group(2)),float(hm.group(3)))))
            for i,line in enumerate(lines):
                m=_TRACKER_XD_CSA_RE.search(line)
                if not m:
                    continue
                cs=self._clock_s(line)
                if cs is None:
                    continue
                x,y,z=float(m.group(1)),float(m.group(2)),float(m.group(3))
                roll=float(m.group(4)) if m.group(4) is not None else None
                pitch=float(m.group(5)) if m.group(5) is not None else None
                key=(str(path.resolve()),i,round(x,6),round(y,6),round(z,6))
                if key in seen: continue
                seen.add(key)
                lo=max(0,i-90); block=lines[lo:i+1]
                reliability=None; reliability_code=None; tilt=(None,None,None)
                pqr=[None]*4; uvw=[None]*4
                for b in block:
                    rm=_TRACKER_RELIABILITY_RE.search(b)
                    if rm: reliability=rm.group(1).strip()
                    rc=_TRACKER_RETURN_RE.search(b)
                    if rc: reliability_code=rc.group(1).strip()
                    tm=_TRACKER_TILT_RE.search(b)
                    if tm: tilt=(float(tm.group(1)),float(tm.group(2)),float(tm.group(3)))
                    pm=_TRACKER_PQR_RE.search(b)
                    if pm: pqr[int(pm.group(1))]=(float(pm.group(2)),float(pm.group(3)),float(pm.group(4)))
                    um=_TRACKER_FOUND_UVW_RE.search(b)
                    if um: uvw[int(um.group(1))]=(float(um.group(2)),float(um.group(3)),float(um.group(4)))
                home=None
                prior_home=[h for h in home_updates if h[1] <= i]
                if prior_home: home=max(prior_home,key=lambda h:h[1])[2]
                related=None; related_delta=None
                if starts:
                    best=min(starts,key=lambda row:abs(row[0]-cs)); delta=best[0]-cs
                    if abs(delta)<=180.0: related=best[1]; related_delta=float(delta)
                timestamp=(base_date+timedelta(seconds=cs)) if base_date is not None else None
                records.append(TransducerLocationRecord(
                    timestamp=timestamp,clock_s=float(cs),x=x,y=y,z=z,roll=roll,pitch=pitch,
                    steering_x=None,steering_y=None,steering_z=None,source=path,line_number=i+1,
                    trigger="Tracker localization",related_sonication=related,related_delta_s=related_delta,
                    coordinate_frame="CSA",reliability=reliability,reliability_code=reliability_code,
                    tilt_x=tilt[0],tilt_y=tilt[1],tilt_z=tilt[2],tracker_pqr=tuple(pqr),tracker_uvw=tuple(uvw),home_uvw=home,
                    locate_event_line=i+1,locate_event_clock_s=float(cs),locate_event_text=line.strip(),
                ))
        records.sort(key=lambda r:((r.timestamp or datetime.min),r.clock_s,str(r.source).lower(),r.line_number))
        if records:
            bx,by,bz=records[0].x,records[0].y,records[0].z
            for r in records:
                r.delta_x=r.x-bx; r.delta_y=r.y-by; r.delta_z=r.z-bz
                r.displacement=math.sqrt(r.delta_x*r.delta_x+r.delta_y*r.delta_y+r.delta_z*r.delta_z)
        return records

    def parse(self, workspace: Path) -> list[TransducerLocationRecord]:
        """Return transducer localization history with tracker evidence first.

        Real R0175 diagnostics established tracker-derived CSA XYZ as the stronger
        source.  Older exports may lack that vendor signature but contain an
        explicit Locate Transducer workflow followed by a non-zero Xd report; keep
        that prior R0174 contract only as a fallback.  Ordinary unassociated state
        reports are never promoted.
        """
        tracker=self.tracker_localizations(workspace)
        if tracker:
            return tracker
        raw=self.raw_xd_reports(workspace)
        records=[r for r in raw if r.trigger=="Locate Transducer" and self._is_nonzero_location(r.x,r.y,r.z)]
        if records:
            bx,by,bz=records[0].x,records[0].y,records[0].z
            for r in records:
                r.coordinate_frame="XD state / explicit Locate fallback"
                r.delta_x=r.x-bx; r.delta_y=r.y-by; r.delta_z=r.z-bz
                r.displacement=math.sqrt(r.delta_x*r.delta_x+r.delta_y*r.delta_y+r.delta_z*r.delta_z)
        return records
