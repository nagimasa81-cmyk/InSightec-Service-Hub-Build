# R0176 — Tracker-derived Transducer Localization History

- Uses the observed vendor result line `New XD pos. in CSA coords. according to trackers` as the authoritative transducer XYZ.
- Attaches tracker PQR/UVW, Transducer tilt, TRACKERS SELECTION reliability and CalculateXdPosition return code from the same localization block.
- Keeps recurring `Xd loc XYZ` and `Location sent on MoveTo` zero-state rows diagnostic-only.
- Lists CSA XYZ over time with delta X/Y/Z and 3D displacement from the first tracker localization.
- Diagnostics and CSV include coordinate frame, reliability, tilt, tracker coordinates and nearest home UVW.
