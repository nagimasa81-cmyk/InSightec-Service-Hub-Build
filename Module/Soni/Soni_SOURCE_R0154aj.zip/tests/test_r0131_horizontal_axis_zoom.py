from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HELPER = (ROOT / "src/ui/chart_interaction.py").read_text(encoding="utf-8")
HYD = (ROOT / "src/ui/hydrophone_window.py").read_text(encoding="utf-8")
MAIN = (ROOT / "src/ui/main_window.py").read_text(encoding="utf-8")


def test_axis_drag_is_x_only_and_preserves_y():
    assert 'axis = plot.getAxis("bottom")' in HELPER
    assert 'vb.setXRange(lo, hi, padding=0.0)' in HELPER
    assert 'vb.setYRange(float(y[0]), float(y[1]), padding=0.0)' in HELPER


def test_double_click_resets_zoom():
    assert 'QEvent.Type.MouseButtonDblClick' in HELPER
    assert 'vb.autoRange(padding=0.02)' in HELPER


def test_plot_area_pan_contract_is_not_replaced():
    assert 'axis.mouseDragEvent = types.MethodType' in HELPER
    assert 'Drag the bottom X axis' in HELPER
    assert 'vb.setMouseMode(pg.ViewBox.PanMode)' in HYD


def test_analyzer_and_main_window_install_common_interaction():
    assert 'install_horizontal_axis_range_zoom' in HYD
    assert 'self.findChildren(pg.PlotWidget)' in HYD
    assert 'self._install_horizontal_chart_zoom()' in MAIN
    assert 'self.findChildren(pg.PlotWidget)' in MAIN


def test_fft_chart_area_selection_remains_present():
    assert '_raw_fft_dragging' in HYD
    assert '_set_raw_fft_selection_cursor' in HYD
