from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pytest

from src.services.canonical_cavitation_evidence_service import CanonicalCavitationEvidenceService
from src.services.raw_service import RawService, RawDecodeError

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
IMPORT=(ROOT/'src/services/import_service.py').read_text(encoding='utf-8')
SDI=(ROOT/'src/services/spectrum_dump_import_service.py').read_text(encoding='utf-8')
REPO=(ROOT/'src/services/spectrum_evidence_repository.py').read_text(encoding='utf-8')


def test_missing_spectrum_does_not_turn_absent_control_event_into_unknown():
    ev=CanonicalCavitationEvidenceService.combine([], None, timeline_available=True, spectrum_available=False, unavailable_reason='missing spectrum')
    assert ev.detected is False
    assert ev.evidence_complete is False
    assert ev.status == 'No Power Decrease / Safety event'


def test_confirmed_observed_event_wins_even_if_spectrum_unavailable():
    observed=SimpleNamespace(family='Decrease', counts_as_cavitation=True)
    ev=CanonicalCavitationEvidenceService.combine([observed], None, spectrum_available=False)
    assert ev.detected is True
    assert len(ev.observed_events)==1


def test_raw_cooperative_cancel_has_no_daemon_reader(tmp_path):
    p=tmp_path/'m.raw'; p.write_bytes(np.zeros((256,256),dtype='<u2').tobytes())
    with pytest.raises(RawDecodeError, match='cancelled'):
        RawService().read_magnitude_cooperative(p, cancel_check=lambda: True)
    block=MAIN[MAIN.index('class EssentialImageLoadWorker'):MAIN.index('class SonicationSummaryDetailWorker')]
    assert 'daemon=True' not in block
    assert 'threading.Thread' not in block


def test_zip_open_avoids_double_decompression_testzip():
    assert 'archive.testzip(' not in IMPORT
    assert 'archive.testzip(' not in SDI


def test_treatment_outcome_uses_canonical_contract():
    block=MAIN[MAIN.index('class TreatmentOutcomeScienceWorker'):MAIN.index('class PackageLoadWorker') if MAIN.find('class PackageLoadWorker', MAIN.index('class TreatmentOutcomeScienceWorker')+1)>0 else MAIN.index('class SpectrumPreloadWorker')]
    assert 'self.canonical_service.combine' in block
    assert 'events=canonical.rca_events' in block
    assert 'previous_cavitation = canonical.detected' in block


def test_shared_spectrum_repository_is_used_by_background_consumers():
    assert 'class SpectrumEvidenceRepository' in REPO
    assert 'self._inflight' in REPO and 'self._condition.wait' in REPO
    assert 'repository.authoritative_context(' in MAIN
    assert 'repository.replay(package, index, son)' in MAIN


def test_legacy_sync_metadata_path_is_hard_blocked():
    a=MAIN.index('def _update_sonication_metadata(self):'); b=MAIN.index('def _update_info_window',a)
    block=MAIN[a:b]
    assert 'metadata_service.read' not in block
    assert 'Synchronous Sonication metadata loading is disabled' in block


def test_legacy_secondary_stages_cannot_compute_on_gui_thread():
    a=HYDRO.index('def _finish_secondary_replay_publish'); b=HYDRO.index('def _hide_publish_progress_if_current',a)
    block=HYDRO[a:b]
    assert '_draw_spectrogram()' not in block
    assert '_draw_band_energy()' not in block
    assert '_queue_secondary_analysis()' in block
