from pathlib import Path

from src.services.acoustic_control_service import AcousticControlService
from src.services.spectrum_dump_import_service import SpectrumDumpCandidate, SpectrumDumpImportService


def _write_log(path: Path, starts_and_dumps: list[tuple[str, str]]) -> None:
    lines = []
    for start, end in starts_and_dumps:
        lines += [
            f"{start}:000 Inf 1 CAcquisitionObject Got StartSpectrumMeasurementA\n",
            f"{start}:010 Inf 1 AblPowerRatio = 1.0\n",
            f"{end}:000 Inf 1 AblPowerRatio = 1.0\n",
            f"{end}:100 Inf 1 CAcquisitionObject Got StopSpectrumMeasurementS\n",
        ]
    path.write_text(''.join(lines), encoding='utf-8')


def test_selects_current_smaller_log_and_maps_only_bound_treatment_block(tmp_path: Path):
    # Older stale log is intentionally larger.
    old = tmp_path / 'CPCFiles' / 'Acquisition_Brain_650_Sun_Aug_23_16_30_13_2026.txt'
    cur = tmp_path / 'CPCFiles' / 'Acquisition_Brain_650_Sun_Aug_23_18_27_32_2026.txt'
    old.parent.mkdir(parents=True)
    _write_log(old, [('17:09:00', '17:09:12')] * 12)
    _write_log(cur, [
        ('18:34:09', '18:34:29'), ('18:35:59', '18:36:19'),
        ('18:37:43', '18:38:03'), ('18:39:14', '18:39:34'),
        ('18:40:46', '18:40:56'),
    ])
    assert old.stat().st_size > cur.stat().st_size

    (tmp_path / 'SonicationSummary.xml').write_text(
        '<xml><row sonicationindex="1" sontime="20260823183358 "/></xml>', encoding='utf-8'
    )

    service = AcousticControlService()
    assert service.find_log(tmp_path) == cur

    importer = SpectrumDumpImportService()
    candidates = []
    # Historical CPC dumps remain present but do not bind to the current log.
    for hhmmss in ['17_09_13', '17_14_06', '18_34_29', '18_36_19', '18_38_03', '18_39_34', '18_40_56']:
        raw = tmp_path / 'CPCFiles' / f'Spectrum_Sun_Aug_23_{hhmmss}_2026.dmp'
        raw.write_bytes(hhmmss.encode())
        candidates.append(SpectrumDumpCandidate(raw.name, raw, None, str(raw.relative_to(tmp_path)), 'CPC Spectrum'))

    selected = importer._validated_treatment_suffix(candidates, 5, tmp_path)
    assert selected is not None
    assert [c.primary_path.name for c in selected] == [
        'Spectrum_Sun_Aug_23_18_34_29_2026.dmp',
        'Spectrum_Sun_Aug_23_18_36_19_2026.dmp',
        'Spectrum_Sun_Aug_23_18_38_03_2026.dmp',
        'Spectrum_Sun_Aug_23_18_39_34_2026.dmp',
        'Spectrum_Sun_Aug_23_18_40_56_2026.dmp',
    ]
