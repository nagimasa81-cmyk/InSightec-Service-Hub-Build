from pathlib import Path

SRC = (Path(__file__).resolve().parents[1] / 'src' / 'ui' / 'main_window.py').read_text(encoding='utf-8')


def test_right_controls_are_scrolled_not_height_forcing():
    assert 'self.element_side_scroll = QScrollArea()' in SRC
    assert 'self.element_side_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)' in SRC
    assert 'self.element_side_scroll.setWidget(side)' in SRC


def test_umbrella_keeps_minimum_viewport_and_compact_table_share():
    assert 'self.element_map.setMinimumHeight(280)' in SRC
    assert 'middle.setMinimumHeight(320)' in SRC
    assert 'table_h=max(150,min(220,int(total*0.25)))' in SRC
    assert 'upper=max(320,total-table_h)' in SRC


def test_layout_refit_preserves_camera_state():
    body = SRC.split('def _refit_element_umbrella_after_layout', 1)[1].split('def _populate_element_table', 1)[0]
    assert 'element_map.updateGeometry()' in body
    assert 'element_map.update()' in body
    assert 'reset_umbrella_view' not in body
    assert 'umbrella_zoom=' not in body
