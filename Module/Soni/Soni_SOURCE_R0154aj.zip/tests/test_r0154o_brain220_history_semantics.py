import struct
from pathlib import Path

import numpy as np
import pytest

from src.core.spectrum_decoder import SharedSpectrumDecoder
from src.integration.spectrum_provider import SpectrumMsgAnalyzerAdapter


def _ws64(value: float) -> bytes:
    low, high = struct.unpack('<II', struct.pack('<d', float(value)))
    return struct.pack('<II', high, low)


def _record(state: int, timestamp: float, bins: int = 1000, spacing_hz: float = 250.0) -> bytes:
    spectral_extent = 48 + bins * 8
    buf = bytearray(56 + bins * 8)
    struct.pack_into('<I', buf, 0, spectral_extent)
    struct.pack_into('<f', buf, 12, 2.0)
    buf[16:24] = _ws64(0.005)
    buf[24:32] = _ws64(spacing_hz)
    buf[32:40] = _ws64(0.0)
    buf[40:48] = _ws64(bins * spacing_hz)
    buf[48:56] = _ws64(0.7)
    amp = np.full(bins, 1e-6, dtype=float)
    amp[int(round(115000.0 / spacing_hz))] = 2e-4
    for i, value in enumerate(amp):
        buf[56+i*8:64+i*8] = _ws64(value)
    # First row reproduces the recurring 0.096/0.84/0.7 metadata word seen in
    # the real export.  The second row carries an integer state/index and time.
    history = bytearray()
    history += struct.pack('<ffIff', 0.096, 0.84, 0x3F333333, max(-1.0, timestamp-0.1), 0.0)
    history += struct.pack('<ffIff', 0.001, 0.0001, state, timestamp, 0.00001)
    return bytes(buf) + struct.pack('<I', 2) + bytes(history) + struct.pack('<2fI', 0.0, 0.0, state)


def _container(records):
    return struct.pack('<I', len(records)) + struct.pack(f'<{len(records)}I', *[len(r) for r in records]) + b''.join(records)


def test_decoder_retains_latest_history_integer_without_naming_it(tmp_path: Path):
    p = tmp_path / 'SpectrumMsg-1.dmp'
    p.write_bytes(_container([_record(3, 0.44)]))
    frame = SharedSpectrumDecoder().decode_frames(p, 230000.0)[0]
    assert frame.timestamp_seconds == pytest.approx(0.44, abs=1e-6)
    assert frame.history_state_index == 3
    assert frame.history_state_semantics == 'Unresolved'
    assert frame.history_sample_count == 2
    assert frame.timestamp_source == 'Embedded SpectrumMsg 20-byte history'


def test_provider_promotes_state_only_with_independent_multi_target_count(tmp_path: Path):
    p = tmp_path / 'SpectrumMsg-1.dmp'
    p.write_bytes(_container([_record(i, 0.11*(i+1)) for i in range(9)]))
    ras = tuple((float(i), float(i+1), float(i+2)) for i in range(9))
    frames = SpectrumMsgAnalyzerAdapter(
        230000.0,
        subsonication_count_hint=9,
        subsonication_ras_hint=ras,
    ).load([p])
    assert len(frames) == 9
    assert all(f.history_state_semantics == 'WS-validated BBB sub-sonication index' for f in frames)
    assert frames[3].history_state_index == 3
    assert frames[3].active_target_ras == ras[3]


def test_provider_does_not_call_zero_to_seven_states_receivers_or_targets_without_ws_evidence(tmp_path: Path):
    p = tmp_path / 'SpectrumMsg-2.dmp'
    p.write_bytes(_container([_record(i, 0.2*(i+1), bins=400, spacing_hz=625.0) for i in range(8)]))
    frames = SpectrumMsgAnalyzerAdapter(230000.0).load([p])
    assert {f.history_state_index for f in frames} == set(range(8))
    assert all(f.history_state_semantics == 'Unresolved' for f in frames)
    assert all(f.active_target_ras is None for f in frames)
