from pathlib import Path


ROOT=Path(__file__).resolve().parents[1]


def test_spectrum_handoff_identity_includes_attached_full_stream():
    repo=(ROOT/'src/services/spectrum_evidence_repository.py').read_text()
    ui=(ROOT/'src/ui/hydrophone_window.py').read_text()
    assert 'spectral_count' in repo and 'spectral_key' in repo
    assert ui.count('spectral_count') >= 2
    assert 'SpectrumMsg aggregate Band0 (full timeline; no RCV identity)' in ui


def test_split_line_score_and_robust_temperature_contracts():
    acoustic=(ROOT/'src/services/acoustic_control_service.py').read_text()
    main=(ROOT/'src/ui/main_window.py').read_text()
    assert '_ENERGY_RE' in acoustic and '_LIMIT_RE' in acoustic
    assert 'robust_max_temperature_trend' in main


def test_dqa_series_never_uses_phantom_position_as_focus_zero():
    text=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text()
    block=text.split('def analyze_series',1)[1].split('def clear_cache',1)[0]
    assert 'self.analyze(package,index)' in block
    assert 'baseline_s_mm' not in block
    assert 'observed focus - same-Sonication planned focus' in block


def test_import_diagnostics_export_is_background_owned():
    text=(ROOT/'src/ui/diagnostics.py').read_text()
    assert 'class ImportDiagnosticsExportWorker(QObject)' in text
    assert 'thread.started.connect(worker.run)' in text
    assert 'setText("Exporting…")' in text
