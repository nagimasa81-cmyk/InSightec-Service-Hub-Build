from pathlib import Path
from types import SimpleNamespace

from src.services.acoustic_system_profile_service import AcousticSystemProfileService, frequency_family
from src.services.sonication_frequency_service import SonicationFrequencyService
from src.services.xd_ini_service import XdIniService
from src.core.spectrum_decoder import SharedSpectrumDecoder
from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService


def _write_profile(tmp_path: Path, frequency: int, tx: int, xd_values: list[int]):
    (tmp_path / "SonicationSummary.xml").write_text(
        "<root>" + "".join(f"<row frequency='{frequency}'/>" for _ in range(3)) + "</root>",
        encoding="utf-8",
    )
    (tmp_path / "TransducerInfo.xml").write_text(
        f"<root><row transtype='{tx}'/></root>", encoding="utf-8"
    )
    ini = tmp_path / "CPCFiles" / "Site" / "Ini"
    ini.mkdir(parents=True)
    (ini / "Xd_6314.ini").write_text(
        "[AVAILABLE_FREQUENCIES]\n" + "\n".join(f"FREQ{i}={v}" for i, v in enumerate(xd_values)),
        encoding="utf-8",
    )


def test_frequency_family_is_disjoint_and_supports_220_and_650():
    assert frequency_family(230_000) == "Brain 220 family"
    assert frequency_family(670_000) == "Brain 650 family"
    assert frequency_family(400_000) is None


def test_profile_classifies_realistic_brain220_evidence(tmp_path: Path):
    _write_profile(tmp_path, 230_000, 41, [210_000, 220_000, 230_000, 240_000, 250_000, 260_000, 270_000])
    p = AcousticSystemProfileService().classify(tmp_path)
    assert p.family == "Brain 220 family"
    assert p.actual_frequency_hz == 230_000
    assert p.transducer_type == 41
    assert p.confidence == "High"
    assert not p.conflict
    assert "actual 230 kHz" in p.display


def test_profile_classifies_realistic_brain650_evidence(tmp_path: Path):
    _write_profile(tmp_path, 670_000, 42, [630_000, 640_000, 650_000, 660_000, 670_000, 680_000, 690_000, 700_000])
    p = AcousticSystemProfileService().classify(tmp_path)
    assert p.family == "Brain 650 family"
    assert p.actual_frequency_hz == 670_000
    assert p.transducer_type == 42
    assert p.confidence == "High"
    assert not p.conflict


def test_profile_fails_closed_on_frequency_transducer_conflict(tmp_path: Path):
    _write_profile(tmp_path, 230_000, 42, [630_000, 640_000, 650_000, 670_000])
    p = AcousticSystemProfileService().classify(tmp_path)
    assert p.family == "Brain 220 family"  # actual treatment frequency remains primary
    assert p.conflict
    assert p.confidence == "Conflict"


def test_sonication_local_frequency_accepts_230k_and_rejects_gap(tmp_path: Path):
    (tmp_path / "a.act").write_text("Frequency=230000\n", encoding="utf-8")
    assert SonicationFrequencyService().read(tmp_path).frequency_hz == 230_000
    (tmp_path / "a.act").write_text("Frequency=400000\n", encoding="utf-8")
    assert SonicationFrequencyService().read(tmp_path).frequency_hz is None


def test_serial_xd_accepts_230k_final_value(tmp_path: Path):
    p = tmp_path / "Xd_6314.ini"
    p.write_text("[x]\nSomeValue=1\nPreferredFrequency=230000\n", encoding="utf-8")
    m = XdIniService().read_main_frequency(tmp_path)
    assert m.frequency_hz == 230_000


def test_brain220_acquisition_graph_window_is_used(tmp_path: Path):
    son = tmp_path / "Sonication1"; son.mkdir()
    dmp = son / "SpectrumMsg-1.dmp"; dmp.write_bytes(b"x")
    ini = tmp_path / "CPCFiles" / "App" / "Ini"; ini.mkdir(parents=True)
    (ini / "Acquisition.ini").write_text("f1ForGraph = 50000\nf2ForGraph = 250000\n", encoding="utf-8")
    assert SharedSpectrumDecoder._graph_frequency_range(dmp, 230_000) == (50_000.0, 250_000.0)


def test_dqa_detection_uses_actual_brain220_dqa_protocol(tmp_path: Path):
    (tmp_path / "SonicationSummary.xml").write_text(
        "<root><row sonicationindex='1' treatprotocol='Low-Energy-DQA '/></root>", encoding="utf-8"
    )
    package = SimpleNamespace(workspace=tmp_path, source=tmp_path / "case.zip")
    assert DqaFocusAlignmentService.is_dqa(package)


def test_generic_dqa_templates_do_not_reclassify_normal_treatment(tmp_path: Path):
    (tmp_path / "SonicationSummary.xml").write_text(
        "<root><row sonicationindex='1' treatprotocol='Brain-Treat'/></root>", encoding="utf-8"
    )
    p = tmp_path / "WSFiles"; p.mkdir()
    (p / "Brain220DQAProtocols.ini").write_text("[Low-Energy-DQA]\n", encoding="utf-8")
    package = SimpleNamespace(workspace=tmp_path, source=tmp_path / "DQA_case.zip")
    assert not DqaFocusAlignmentService.is_dqa(package)
