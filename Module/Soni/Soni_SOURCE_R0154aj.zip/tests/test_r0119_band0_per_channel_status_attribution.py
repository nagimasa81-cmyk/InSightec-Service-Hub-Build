from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HYDRO = (ROOT / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')


def _band_energy_block() -> str:
    return HYDRO.split('def _draw_band_energy', 1)[1].split('def _apply_vendor_band_defaults', 1)[0]


def test_band0_reconstruction_and_rejection_are_attributed_per_channel():
    """One receiver succeeding and another failing must be distinguishable
    in the status line -- a shared boolean flag can't say *which* RCV is
    which, and a shared 'last failing channel' detail string silently drops
    every other channel's own reason."""
    block = _band_energy_block()
    assert 'band0_reconstructed_channels' in block
    assert 'band0_rejected_channels' in block
    # The status line must enumerate receivers by name (RCV{ch}), not just a
    # single aggregate count/flag.
    assert 'f"RCV{ch}: {reason}"' in block
    assert 'f"RCV{ch}"' in block or "f'RCV{ch}'" in block


def test_subharmonic_markers_are_plotted_at_most_once_per_channel():
    """Selecting multiple bands must not re-plot (and re-count) the same
    channel's sub-harmonic markers once per selected band."""
    block = _band_energy_block()
    assert 'plotted_subharmonic_channels' in block
    assert 'int(ch) not in plotted_subharmonic_channels' in block
    assert 'plotted_subharmonic_channels.add(int(ch))' in block
    # subharmonic_by_channel replaces the old single running total so the
    # status line can name which receivers actually had evidence.
    assert 'subharmonic_by_channel' in block


def test_no_leftover_shared_flags_from_before_the_per_channel_rewrite():
    block = _band_energy_block()
    for stale_name in ('reconstructed_any', 'rejected_reconstruction', 'rejection_detail', 'subharmonic_total'):
        assert stale_name not in block, f"stale shared flag {stale_name!r} should have been replaced"
