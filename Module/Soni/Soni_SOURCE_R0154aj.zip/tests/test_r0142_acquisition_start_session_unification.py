from pathlib import Path
from types import SimpleNamespace

from src.services.acoustic_control_service import AcousticControlService
from src.services.cavitation_control_timeline_service import CavitationControlTimelineService
from src.services.spectrum_dump_import_service import SpectrumDumpCandidate, SpectrumDumpImportService


def _write_log(path: Path):
    path.write_text("\n".join([
        "08:00:00:000 Got StartSpectrumMeasurement",
        "08:00:00:100 Telemetry AblPowerRatio = 1.0",
        "08:00:01:000 Decrease Power Rule no. 1 : Calculated Energy: < 2.0 > Calculated Top Energy limit: < 1.0 >",
        "08:00:01:100 Telemetry AblPowerRatio = 0.9",
        "08:00:02:000 StopSpectrumMeasurement",
        "08:10:00:000 Got StartSpectrumMeasurement",
        "08:10:00:100 Telemetry AblPowerRatio = 1.0",
        "08:10:01:000 Safety Rule no. 2 : critical",
        "08:10:01:020 Calculated Energy: < 5.0 >",
        "08:10:01:030 Critical Energy: < 4.0 >",
        "08:10:01:100 Telemetry AblPowerRatio = 0.0",
        "08:10:02:000 HALTED BY CAVITATION",
        "08:10:03:000 StopSpectrumMeasurement",
    ]), encoding="utf-8")


def test_generic_got_start_is_shared_by_acoustic_and_control_parsers(tmp_path):
    log = tmp_path / "Acquisition_Brain_test.txt"
    _write_log(log)
    acoustic = AcousticControlService()
    segments = acoustic.parse_segments(log)
    assert len(segments) == 2
    timeline = CavitationControlTimelineService().parse(tmp_path, None, preferred_session_index=1)
    assert timeline.session_index == 1
    assert any(getattr(e, "family", "") == "Safety" for e in timeline.events)


def test_generic_got_start_enables_cpc_session_mapping(tmp_path):
    log = tmp_path / "Acquisition_Brain_test.txt"
    _write_log(log)
    # Candidate filenames encode clocks near acquisition-session end.
    c1p = tmp_path / "CPCFiles" / "Spectrum_Mon_Aug_26_08_00_01_2026.dmp"
    c2p = tmp_path / "CPCFiles" / "Spectrum_Mon_Aug_26_08_10_01_2026.dmp"
    c1p.parent.mkdir(parents=True)
    c1p.write_bytes(b"a")
    c2p.write_bytes(b"b")
    cands = [
        SpectrumDumpCandidate(c1p.name, c1p, None, str(c1p.relative_to(tmp_path)), "CPC Spectrum"),
        SpectrumDumpCandidate(c2p.name, c2p, None, str(c2p.relative_to(tmp_path)), "CPC Spectrum"),
    ]
    sons = [
        SimpleNamespace(name="Sonication1", sonication_number=1, folder=tmp_path/"Sonication1", canonical_acquisition_session_index=None),
        SimpleNamespace(name="Sonication2", sonication_number=2, folder=tmp_path/"Sonication2", canonical_acquisition_session_index=None),
    ]
    mapping = SpectrumDumpImportService().map_candidates_to_sonications(cands, sons, tmp_path)
    assert sorted(mapping) == [0, 1]
    assert mapping[0].acquisition_session_index == 0
    assert mapping[1].acquisition_session_index == 1
