from pathlib import Path
import numpy as np

from src.services.sonication_identity_service import SonicationIdentityService
from src.services.sonication_evidence_service import SonicationEvidenceService, SonicationEvidence, SonicationSetupRecord
from src.services.dqa_focus_alignment_service import DqaFocusAlignment, DqaFocusAlignmentService


def test_empty_trailing_sonication_folder_is_not_identity(tmp_path: Path):
    (tmp_path / "Sonication1").mkdir()
    (tmp_path / "Sonication1" / "6-a-1.raw").write_bytes(b"x")
    (tmp_path / "Sonication6").mkdir()
    inv = SonicationIdentityService().resolve(tmp_path)
    assert 1 in inv.numbers
    assert 6 not in inv.numbers


def test_nonempty_folder_only_legacy_identity_is_preserved(tmp_path: Path):
    f = tmp_path / "Sonication6"; f.mkdir()
    (f / "legacy.raw").write_bytes(b"x")
    inv = SonicationIdentityService().resolve(tmp_path)
    assert inv.numbers == [6]


def _rec(clock, power=200.0, duration=13.0, freq=650000.0, steering=(0.0,0.0,150.0)):
    return SonicationSetupRecord(clock_s=clock,power_w=power,duration_s=duration,frequency_hz=freq,
                                 sonication_type=6,cpc_mode=1,steering_xyz=steering)


def test_duplicate_type6_setup_writes_collapse_to_one_physical_sonication():
    records=[]
    for base,power in [(100.0,100.0),(190.0,110.0),(280.0,120.0),(370.0,130.0),(460.0,140.0)]:
        records += [_rec(base,power=power), _rec(base+2.0,power=power)]
    collapsed=SonicationEvidenceService._collapse_duplicate_setup_records(records)
    assert len(collapsed)==5
    assert [r.clock_s for r in collapsed]==[102.0,192.0,282.0,372.0,462.0]


def test_setup_window_matches_after_duplicate_collapse():
    svc=SonicationEvidenceService()
    evidence=[]; records=[]
    for i,(base,power) in enumerate([(100.0,100.0),(190.0,110.0),(280.0,120.0),(370.0,130.0),(460.0,140.0)],start=1):
        evidence.append(SonicationEvidence(sonication_index=i,displayed_power_w=power,summary_duration_s=13.0,frequency_hz=650000.0))
        records += [_rec(base,power=power), _rec(base+2.0,power=power)]
    matched=svc._match_regular_setup_window(evidence,records)
    assert matched is not None
    assert len(matched)==5
    assert [r.power_w for r in matched]==[100.0,110.0,120.0,130.0,140.0]


def test_dqa_alert_thresholds_are_absolute():
    assert not DqaFocusAlignment(x_mm=14.9,y_mm=-14.9,z_mm=19.9).alert
    assert DqaFocusAlignment(x_mm=-15.0).alert
    assert DqaFocusAlignment(y_mm=15.0).alert
    assert DqaFocusAlignment(z_mm=-20.0).alert


def test_dqa_display_contains_xyz_and_tilt():
    d=DqaFocusAlignment(x_mm=1.25,y_mm=-2.25,z_mm=3.5,tilt_deg=-1.25)
    text=d.display
    assert "X +1.2 mm" in text
    assert "Y -2.2 mm" in text
    assert "Z +3.5 mm" in text
    assert "Tilt -1.2 °" in text


def test_dqa_baseline_horizontal_is_zero_degree_geometry():
    # Synthetic bright horizontal phantom base on a quiet image.
    a=np.zeros((256,256),float)
    a[179:182,45:211]=1.0
    line=DqaFocusAlignmentService._baseline_line(a)
    assert line is not None
    slope, _intercept, support=line
    assert abs(slope) < 0.01


def test_dqa_ras_delta_maps_screen_x_and_y_to_exported_column_and_row():
    row={
        "pixsizex":"2.0","pixsizey":"3.0",
        "rowdirectcosrasx":"0","rowdirectcosrasy":"1","rowdirectcosrasz":"0",
        "coldirectcosrasx":"1","coldirectcosrasy":"0","coldirectcosrasz":"0",
    }
    d=DqaFocusAlignmentService._ras_delta(row,4,-2)
    assert np.allclose(d,[8,-6,0])


def test_dqa_full_synthetic_package_recovers_composite_alignment(tmp_path: Path):
    from types import SimpleNamespace
    from src.domain.models import RawFrame

    yy,xx=np.indices((256,256))
    cx,cy,r=128.0,110.0,50.0
    radial=np.hypot(xx-cx,yy-cy)
    mag=np.zeros((256,256),dtype=np.uint16)
    mag[np.abs(radial-r)<=2]=50000
    mag[(radial<r-2)]=14000
    mag[179:182,45:211]=60000

    def make_son(n,hx,hy):
        folder=tmp_path/f"Sonication{n}"; folder.mkdir()
        m=folder/f"6-test-{n}.raw"; mag.astype('<u2').tofile(m)
        t0=folder/f"5-base-{n}.raw"; np.zeros((256,256),np.float32).astype('<f4').tofile(t0)
        g=np.exp(-((xx-hx)**2+(yy-hy)**2)/(2*3.0**2)).astype(np.float32)*20.0
        t1=folder/f"5-hot-{n}.raw"; g.astype('<f4').tofile(t1)
        return SimpleNamespace(
            sonication_number=n,folder=folder,other_files=[],
            magnitude_frames=[RawFrame(m,0,'6')],
            temperature_frames=[RawFrame(t0,0,'5'),RawFrame(t1,1,'5')],
        )

    sons=[make_son(1,133,110),make_son(2,128,160),make_son(3,128,106)]
    xml=tmp_path/'MriImageParams.xml'
    xml.write_text('''<root xmlns:z="urn:schemas-microsoft-com:rowset">
      <z:row sonicationindex="1" seriesdiscription="MEMP" pixsizex="1" pixsizey="1" rowdirectcosrasx="0" rowdirectcosrasy="1" rowdirectcosrasz="0" coldirectcosrasx="1" coldirectcosrasy="0" coldirectcosrasz="0" />
      <z:row sonicationindex="2" seriesdiscription="MEMP" pixsizex="1" pixsizey="1" rowdirectcosrasx="0" rowdirectcosrasy="0" rowdirectcosrasz="1" coldirectcosrasx="0" coldirectcosrasy="1" coldirectcosrasz="0" />
      <z:row sonicationindex="3" seriesdiscription="MEMP" pixsizex="1" pixsizey="1" rowdirectcosrasx="0" rowdirectcosrasy="1" rowdirectcosrasz="0" coldirectcosrasx="1" coldirectcosrasy="0" coldirectcosrasz="0" />
    </root>''',encoding='utf-8')
    package=SimpleNamespace(workspace=tmp_path,source=tmp_path/'DQA_case.zip',sonications=sons)
    result=DqaFocusAlignmentService().analyze(package)
    # R0154aa: this historical synthetic fixture has no SonicationSummary planned
    # focus and was validating the removed hotspot-minus-phantom composite.  It
    # must now fail closed rather than manufacture DQA displacement.
    assert result.confidence == 'Unavailable'
    assert result.x_mm is None and result.y_mm is None and result.z_mm is None
    assert 'observed focus vs planned focus unavailable' in result.display
