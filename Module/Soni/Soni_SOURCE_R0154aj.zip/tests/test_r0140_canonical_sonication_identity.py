from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
import zipfile

from src.domain.models import SonicationModel
from src.services.discovery_service import DiscoveryService
from src.services.import_service import ImportService
from src.services.sonication_identity_service import SonicationIdentityService
from src.services.sonication_timing_service import SonicationTimingService
from src.services.spectrum_dump_import_service import SpectrumDumpImportService, SpectrumDumpCandidate


def _summary_xml(numbers: list[int]) -> str:
    rows = ''.join(
        f'<z:row sonicationindex="{n}" duration="4" actualduration="4" power="100" energy="400" frequency="650000"/>'
        for n in numbers
    )
    return f'<xml xmlns:rs="urn:schemas-microsoft-com:rowset" xmlns:z="#RowsetSchema"><rs:data>{rows}</rs:data></xml>'


def test_identity_union_restores_summary_sonications_missing_physical_folders(tmp_path: Path):
    for n in range(1, 6):
        (tmp_path / f'Sonication{n}').mkdir()
    (tmp_path / 'SonicationSummary.xml').write_text(_summary_xml(list(range(1, 9))), encoding='utf-8')

    inv = SonicationIdentityService().resolve(tmp_path)
    assert inv.numbers == list(range(1, 9))
    assert set(inv.folders_by_number) == set(range(1, 6))
    assert inv.summary_numbers == list(range(1, 9))


def test_discovery_builds_eight_logical_models_from_five_folders_and_eight_summary_rows(tmp_path: Path, monkeypatch):
    for n in range(1, 6):
        folder = tmp_path / f'Sonication{n}'
        folder.mkdir()
        (folder / f'local{n}.txt').write_text('x', encoding='utf-8')
    (tmp_path / 'SonicationSummary.xml').write_text(_summary_xml(list(range(1, 9))), encoding='utf-8')

    service = DiscoveryService()
    monkeypatch.setattr('src.services.discovery_service.inspect_export', lambda workspace: SimpleNamespace(
        sonications=[], workflow_mode='Unknown', thermometry_mode='Unknown'))
    monkeypatch.setattr(service.xd_ini, 'discover_references', lambda workspace: SimpleNamespace(xd_files=[], geometry_files=[]))
    monkeypatch.setattr(service.xd_ini, 'read_main_frequency', lambda workspace: SimpleNamespace(
        frequency_hz=650000.0, source_path=None, raw_line=None, confidence=1.0, unit_interpretation='Hz'))
    monkeypatch.setattr(service.sonication_frequency, 'read', lambda folder: SimpleNamespace(frequency_hz=None, source=None, raw_line=None))
    monkeypatch.setattr(service.sonication_evidence, 'read', lambda workspace, models: [])
    monkeypatch.setattr(service.mr_timeline, 'resolve_all', lambda workspace, models: [])
    monkeypatch.setattr(service.planning_data, 'discover', lambda workspace: SimpleNamespace(assets=[]))
    monkeypatch.setattr(service.import_completeness, 'audit', lambda workspace, models: SimpleNamespace(to_dict=lambda: {'status':'PASS'}))

    package = service.discover(tmp_path, tmp_path)
    assert [m.sonication_number for m in package.sonications] == list(range(1, 9))
    assert [m.name for m in package.sonications] == [f'Sonication{n}' for n in range(1, 9)]
    assert all(not m.synthetic_identity for m in package.sonications[:5])
    assert all(m.synthetic_identity for m in package.sonications[5:])


def test_duplicate_physical_folders_merge_into_one_logical_model(tmp_path: Path):
    a = tmp_path / 'outer' / 'Sonication1'; a.mkdir(parents=True)
    b = tmp_path / 'nested' / 'Sonication1'; b.mkdir(parents=True)
    (a / 'same.txt').write_text('same', encoding='utf-8')
    (b / 'same.txt').write_text('same', encoding='utf-8')
    (b / 'extra.txt').write_text('extra', encoding='utf-8')

    service = DiscoveryService()
    inv = service.sonication_identity.resolve(tmp_path)
    model = service._build_logical(tmp_path, 1, inv.folders_by_number[1], inv.evidence_by_number[1])
    assert model.sonication_number == 1
    assert len(model.evidence_folders) == 2
    names = [p.name for p in model.other_files]
    assert names.count('same.txt') == 1
    assert 'extra.txt' in names


def test_timing_is_keyed_by_explicit_sonication_index_not_row_position(tmp_path: Path):
    (tmp_path / 'SonicationSummary.xml').write_text(_summary_xml([1, 2, 4, 8]), encoding='utf-8')
    indexed = SonicationTimingService().read_indexed(tmp_path)
    assert sorted(indexed) == [1, 2, 4, 8]
    assert indexed[8].sonication_index == 8


def test_folder_input_with_nested_zip_uses_isolated_overlay_and_expands(tmp_path: Path):
    source = tmp_path / 'export_folder'; source.mkdir()
    nested = source / 'payload.zip'
    with zipfile.ZipFile(nested, 'w') as z:
        z.writestr('Sonication6/SpectrumMsg-6.dmp', b'evidence')

    service = ImportService()
    workspace = service.open(source)
    assert workspace != source
    assert service.last_import_report['folder_overlay'] is True
    assert (workspace / 'payload__expanded' / 'Sonication6' / 'SpectrumMsg-6.dmp').is_file()
    assert not (source / 'payload__expanded').exists()
    service.cleanup()


def test_explicit_cpc_folder_identity_maps_to_logical_model_number_not_list_offset(monkeypatch, tmp_path: Path):
    service = SpectrumDumpImportService()
    # Sparse logical package: list index 2 is Sonication4, not Sonication3.
    sons = [
        SonicationModel('Sonication1', tmp_path / 'Sonication1', sonication_number=1),
        SonicationModel('Sonication2', tmp_path / 'Sonication2', sonication_number=2),
        SonicationModel('Sonication4', tmp_path / 'Sonication4', sonication_number=4),
    ]
    candidate = SpectrumDumpCandidate(
        label='Spectrum_foo.dmp',
        raw_path=tmp_path / 'Sonication4' / 'Spectrum_foo.dmp',
        fft_path=None,
        relative_path='Sonication4/Spectrum_foo.dmp',
        family='CPC Spectrum',
    )
    monkeypatch.setattr(service, 'bind_candidates_to_acquisition_sessions', lambda physical: None)
    monkeypatch.setattr(service, '_validated_treatment_suffix', lambda physical, needed: None)
    mapping = service.map_candidates_to_sonications([candidate], sons)
    assert mapping == {2: candidate}


def test_sonication_evidence_uses_model_number_for_summary_and_powergraph(tmp_path: Path, monkeypatch):
    from src.services.sonication_evidence_service import SonicationEvidenceService

    service = SonicationEvidenceService()
    monkeypatch.setattr(service, '_find_first', lambda workspace, pattern: tmp_path / pattern)
    monkeypatch.setattr(service, '_rows_by_index', lambda path: {
        1: {'power': '101'},
        4: {'power': '404'},
    } if path.name == 'SonicationSummary.xml' else {})
    called = []
    monkeypatch.setattr(service, '_power_graph', lambda workspace, index0: (called.append(index0) or None))
    monkeypatch.setattr(service, 'parse_setup_records', lambda workspace: [])
    monkeypatch.setattr(service.acoustic, 'find_log', lambda workspace: None)

    sons = [
        SonicationModel('Sonication1', tmp_path / 'Sonication1', sonication_number=1),
        SonicationModel('Sonication4', tmp_path / 'Sonication4', sonication_number=4),
    ]
    rows = service.read(tmp_path, sons)
    assert [row.sonication_index for row in rows] == [1, 4]
    assert [row.summary_power_w for row in rows] == [101.0, 404.0]
    assert called == [0, 3]
