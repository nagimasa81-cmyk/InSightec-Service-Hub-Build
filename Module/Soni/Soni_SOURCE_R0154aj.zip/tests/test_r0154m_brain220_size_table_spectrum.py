import struct
from pathlib import Path

import numpy as np

from src.core.spectrum_decoder import SharedSpectrumDecoder


def _ws64(value: float) -> bytes:
    low, high = struct.unpack('<II', struct.pack('<d', float(value)))
    return struct.pack('<II', high, low)


def _record(bins: int, spacing_hz: float, peak_bin: int, t0: float) -> bytes:
    spectral_extent = 48 + bins * 8
    buf = bytearray(56 + bins * 8)
    struct.pack_into('<I', buf, 0, spectral_extent)
    struct.pack_into('<f', buf, 12, 2.0)
    buf[16:24] = _ws64(0.005)
    buf[24:32] = _ws64(spacing_hz)
    buf[32:40] = _ws64(0.0)
    buf[40:48] = _ws64(bins * spacing_hz)
    buf[48:56] = _ws64(0.7)
    amp = np.full(bins, 1e-6, dtype=float)
    amp[peak_bin] = 2e-4
    for i, value in enumerate(amp):
        buf[56 + i * 8:64 + i * 8] = _ws64(float(value))
    history = bytearray()
    for j in range(2):
        history += struct.pack('<5f', 0.096, 0.84, 0.7, t0 + j * 0.11, 0.0)
    return bytes(buf) + struct.pack('<I', 2) + bytes(history) + struct.pack('<2fI', 0.0, 0.0, 0)


def _container(records: list[bytes]) -> bytes:
    return struct.pack('<I', len(records)) + struct.pack(f'<{len(records)}I', *[len(r) for r in records]) + b''.join(records)


def test_brain220_size_table_container_decodes_all_records_and_exact_axis(tmp_path: Path):
    # 230 kHz family with exact 115 kHz subharmonic bin.
    records = [_record(1000, 250.0, 460, i * 0.22) for i in range(4)]
    p = tmp_path / 'SpectrumMsg-1.dmp'
    p.write_bytes(_container(records))
    frames = SharedSpectrumDecoder().decode_frames(p, 230_000.0)
    assert len(frames) == 4
    assert all(f.frequency_axis_source == 'Embedded SpectrumMsg size-table FFT metadata' for f in frames)
    assert all(f.frequency_start_hz == 0.0 for f in frames)
    assert all(f.frequency_spacing_hz == 250.0 for f in frames)
    assert all(abs(f.frequency_end_hz - 249_750.0) < 1e-6 for f in frames)
    assert all(abs(f.main_peak_hz - 115_000.0) < 1e-6 for f in frames)
    assert [round(f.timestamp_seconds, 2) for f in frames] == [0.11, 0.33, 0.55, 0.77]


def test_brain220_size_table_supports_400_bin_625hz_variant(tmp_path: Path):
    p = tmp_path / 'SpectrumMsg-2.dmp'
    p.write_bytes(_container([_record(400, 625.0, 184, 0.0)]))
    frames = SharedSpectrumDecoder().decode_frames(p, 230_000.0)
    assert len(frames) == 1
    assert len(frames[0].frequency_hz) == 400
    assert frames[0].frequency_spacing_hz == 625.0
    assert frames[0].main_peak_hz == 115_000.0


def test_size_table_detection_fails_closed_when_size_equation_is_broken(tmp_path: Path):
    p = tmp_path / 'SpectrumMsg-bad.dmp'
    blob = bytearray(_container([_record(400, 625.0, 184, 0.0)]))
    struct.pack_into('<I', blob, 4, 999999)
    p.write_bytes(blob)
    assert SharedSpectrumDecoder._size_table_records(bytes(blob)) == []
