from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
H = (ROOT / "src/ui/hydrophone_window.py").read_text(encoding="utf-8")
M = (ROOT / "src/ui/main_window.py").read_text(encoding="utf-8")


def test_cavitation_lock_is_opt_in_not_default():
    assert 'self.cavitation_lock_view_check.setChecked(False)' in H
    assert 'setMouseEnabled(x=not locked,y=not locked)' in H


def test_all_standard_hydrophone_plots_restore_mouse_contract():
    assert 'def _enable_plot_interaction(self, plot)' in H
    assert 'vb.setMouseEnabled(x=True, y=True)' in H
    assert 'plot.setMenuEnabled(True)' in H
    assert 'self._enable_plot_interaction(plot)' in H
    assert 'self._enable_plot_interaction(self.spectrogram_plot)' in H


def test_vendor_secondary_viewbox_cannot_swallow_drag_zoom():
    assert 'self.vendor_rule_view.setMouseEnabled(x=False, y=False)' in H


def test_replay_primary_charts_are_explicitly_interactive():
    for name in ('temperature_plot', 'spectrum_plot', 'acoustic_control_plot'):
        assert f'self.{name}.setMouseEnabled(x=True, y=True)' in M
        assert f'self.{name}.setMenuEnabled(True)' in M


def test_manual_pan_zoom_is_not_overwritten_by_ordinary_redraws():
    assert 'sigRangeChangedManually.connect' in H
    assert '_manual_view_override_ids' in H
    assert 'if force or id(plot) not in getattr(self,"_manual_view_override_ids",set())' in H
    assert 'self._clear_manual_view_overrides()' in H

def test_fit_helpers_honor_manual_override_until_forced_reset():
    assert 'def _fit_plot(self, plot, *, x_range=None, force: bool = False)' in H
    assert 'if not force and id(plot) in getattr(self, "_manual_view_override_ids", set())' in H
    assert 'self._apply_selected_time_window(*time_plots, force=force)' in H
