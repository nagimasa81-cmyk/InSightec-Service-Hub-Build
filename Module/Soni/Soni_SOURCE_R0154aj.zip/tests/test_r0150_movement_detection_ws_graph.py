from pathlib import Path
import xml.etree.ElementTree as ET

from src.services.movement_detection_service import MovementDetectionService


def _summary(path: Path):
    root=ET.Element('xml'); data=ET.SubElement(root,'data')
    for n,t in [(1,'20260826174203'),(2,'20260826174614'),(3,'20260826174943')]:
        ET.SubElement(data,'row',{'sonicationindex':str(n),'sontime':t})
    ET.ElementTree(root).write(path,encoding='utf-8')


def test_ws_final_movement_vector_binds_to_next_sonication(tmp_path):
    _summary(tmp_path/'SonicationSummary.xml')
    log=tmp_path/'2026_Aug_26_16_57_46.Log'
    log.write_text(
        '17:41:42:720 Inf Dbg FinalMovementVector = (-0.00543213, -0.0648041, 0.0466881)\n'
        '17:45:53:505 Inf Dbg FinalMovementVector = (0.021946, -0.182888, 0.0665436)\n'
        # More than 90 seconds before Sonication 3: must not be re-used or stretched forward.
        '17:47:00:000 Inf Dbg FinalMovementVector = (9, 9, 9)\n',
        encoding='utf-8'
    )
    rows=MovementDetectionService().read_indexed(tmp_path)
    assert rows[1].display == 'L0.0 S0.0 P0.1'
    assert rows[2].display == 'R0.0 S0.1 P0.2'
    assert 3 not in rows
    assert rows[1].rl == -0.00543213
    assert rows[1].si == 0.0466881
    assert rows[1].ap == -0.0648041


def test_summary_has_dedicated_movement_detection_graph_button():
    text=(Path(__file__).parents[1]/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'QPushButton("Movement Detection graph")' in text
    assert '_sonication_summary_movement_graph_toggled' in text
    assert 'movement_detection_rl' in text
    assert 'movement_detection_si' in text
    assert 'movement_detection_ap' in text
    assert 'Movement Detection (mm)' in text
    assert 'connect="finite"' in text
