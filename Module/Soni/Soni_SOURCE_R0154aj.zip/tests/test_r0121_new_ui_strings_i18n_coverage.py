from pathlib import Path

from src.ui.i18n import LANGUAGES, ui_text

ROOT = Path(__file__).resolve().parents[1]
LOCALES = ['ja', 'ko', 'zh_TW', 'es', 'th', 'hi']

R0117B_R0120_LABELS = [
    'Chart time axis', 'Start', 'End',
    'MR acquisition start', 'Sonication start', 'Sonication end', 'MR acquisition end',
    'Earliest decoded Spectrum (pre-irradiation)',
    'ZIP Password Settings...', 'ZIP Password Settings',
    'Manage the password(s) tried automatically when opening a password-protected export ZIP.',
    'Add', 'Remove selected',
    'Passwords tried, in order, when opening a password-protected ZIP.\n'
    'A built-in default is pre-filled on first use; add or remove any '
    'site-specific password here at any time -- no restart required.',
]


def test_r0117b_and_r0120_ui_strings_are_localized_in_every_language():
    """These labels were added to hydrophone_window.py (time-axis window
    selection) and main_window.py/zip_password_dialog.py (ZIP password
    settings) as plain English literals; they must resolve through the same
    ui_text()/localize_qt_tree() mechanism as the rest of the app's chrome."""
    for locale in LOCALES:
        for label in R0117B_R0120_LABELS:
            assert ui_text(locale, label) != label, (locale, label)


def test_new_strings_round_trip_back_to_canonical_english():
    for label in R0117B_R0120_LABELS:
        for locale in LOCALES:
            localized = ui_text(locale, label)
            assert ui_text('en', localized) == label, (locale, label)


def test_zip_password_dialog_localizes_itself_on_open():
    """The dialog is constructed fresh each time it is opened (not a
    permanent child present when the language was last switched), so it
    must localize itself instead of relying on MainWindow's sweep."""
    src = (ROOT / 'src/ui/zip_password_dialog.py').read_text(encoding='utf-8')
    assert 'from src.ui.i18n import localize_qt_tree, ui_text' in src
    assert 'localize_qt_tree(self, self._locale)' in src
    # The window title is not covered by localize_qt_tree() (it only handles
    # widget .text()/.title(), not QDialog.windowTitle()), so it must be set
    # through ui_text() explicitly rather than left as a raw literal.
    assert 'self.setWindowTitle(ui_text(self._locale, "ZIP Password Settings"))' in src


def test_zip_password_settings_menu_action_is_localizable():
    src = (ROOT / 'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'QAction("ZIP Password Settings...", self)' in src
