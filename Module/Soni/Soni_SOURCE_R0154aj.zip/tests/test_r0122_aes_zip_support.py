from __future__ import annotations

"""Tests for AES (WinZip AE-x) ZIP support.

The 'pyzipper' package (see requirements.txt) provides real AES decryption.
It is not always available in every environment this test suite runs in,
so most tests here install a minimal fake 'pyzipper' module into
sys.modules -- enough to exercise ImportService's branching, password-retry
loop, and error messages deterministically. Where the real package *is*
installed, test_real_pyzipper_end_to_end_if_installed additionally proves
the same code path against genuine AES-encrypted bytes.
"""

import json
import shutil
import sys
import types
import zipfile
from pathlib import Path

import pytest

from src.services.import_service import ImportService
from src.services.zip_password_service import ZipPasswordService


class _FakeAESZipFile:
    """Stand-in for pyzipper.AESZipFile: wraps a real (non-AES) zip and
    simulates password gating, so the integration around it can be tested
    without genuine AES crypto or the real dependency installed."""

    def __init__(self, source, correct_password: bytes = b"clinicalopt"):
        self._real = zipfile.ZipFile(source)
        self._pwd = None
        self._correct = correct_password

    def setpassword(self, pwd):
        self._pwd = pwd

    def infolist(self):
        return self._real.infolist()

    def extract(self, info, path):
        if self._pwd != self._correct:
            raise RuntimeError(f"Bad password for file {info.filename!r}")
        return self._real.extract(info, path)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self._real.close()
        return False


def _install_fake_pyzipper(monkeypatch, correct_password: bytes = b"clinicalopt"):
    fake_module = types.ModuleType("pyzipper")
    fake_module.AESZipFile = lambda source: _FakeAESZipFile(source, correct_password)
    monkeypatch.setitem(sys.modules, "pyzipper", fake_module)


def _make_zip_flagged_as_aes(tmp_path: Path, monkeypatch, name: str = "aes.zip") -> Path:
    """A real AE-x header requires bytes stdlib zipfile cannot write, so
    force detection via monkeypatch instead -- this isolates "did we route
    to the AES branch correctly" from "can we write real AE-x bytes"."""
    zpath = tmp_path / name
    with zipfile.ZipFile(zpath, "w") as z:
        z.writestr("a.txt", "hello world")
    monkeypatch.setattr(ImportService, "_is_encrypted", staticmethod(lambda infos: True))
    monkeypatch.setattr(ImportService, "_is_aes_encrypted", staticmethod(lambda infos: True))
    return zpath


def test_aes_detection_checks_compress_type_99():
    src = Path(__file__).resolve().parents[1].joinpath(
        "src", "services", "import_service.py"
    ).read_text(encoding="utf-8")
    block = src.split("def _is_aes_encrypted", 1)[1].split("def ", 1)[0]
    assert "compress_type" in block
    assert "99" in block


def test_correct_seeded_default_password_opens_an_aes_flagged_zip(tmp_path, monkeypatch):
    _install_fake_pyzipper(monkeypatch)
    zpath = _make_zip_flagged_as_aes(tmp_path, monkeypatch)
    svc = ImportService(zip_password_service=ZipPasswordService(config_path=tmp_path / "pw.json"))
    ws = svc.open(zpath)
    assert (ws / "a.txt").read_text() == "hello world"
    svc.cleanup()


def test_wrong_password_against_aes_zip_stops_cleanly(tmp_path, monkeypatch):
    _install_fake_pyzipper(monkeypatch)
    zpath = _make_zip_flagged_as_aes(tmp_path, monkeypatch)
    cfg = tmp_path / "pw.json"
    cfg.write_text(json.dumps({"passwords": ["not-the-right-one"]}), encoding="utf-8")
    svc = ImportService(zip_password_service=ZipPasswordService(config_path=cfg))
    with pytest.raises(PermissionError, match="AES"):
        svc.open(zpath)
    assert svc.temp_dirs == []


def test_adding_the_right_password_afterward_opens_the_same_aes_zip(tmp_path, monkeypatch):
    _install_fake_pyzipper(monkeypatch, correct_password=b"a-site-aes-password")
    zpath = _make_zip_flagged_as_aes(tmp_path, monkeypatch)
    pw_svc = ZipPasswordService(config_path=tmp_path / "pw.json")
    svc = ImportService(zip_password_service=pw_svc)
    with pytest.raises(PermissionError):
        svc.open(zpath)
    pw_svc.add_password("a-site-aes-password")
    ws = svc.open(zpath)
    assert (ws / "a.txt").read_text() == "hello world"
    svc.cleanup()


def test_missing_pyzipper_raises_a_clear_actionable_message(tmp_path, monkeypatch):
    monkeypatch.setitem(sys.modules, "pyzipper", None)  # forces ImportError on `import pyzipper`
    zpath = _make_zip_flagged_as_aes(tmp_path, monkeypatch)
    svc = ImportService(zip_password_service=ZipPasswordService(config_path=tmp_path / "pw.json"))
    with pytest.raises(PermissionError, match="pyzipper"):
        svc.open(zpath)


def test_no_configured_passwords_raises_a_clear_error_for_aes_too(tmp_path, monkeypatch):
    _install_fake_pyzipper(monkeypatch)
    zpath = _make_zip_flagged_as_aes(tmp_path, monkeypatch)
    cfg = tmp_path / "pw.json"
    cfg.write_text(json.dumps({"passwords": []}), encoding="utf-8")
    svc = ImportService(zip_password_service=ZipPasswordService(config_path=cfg))
    with pytest.raises(PermissionError, match="no ZIP password is configured"):
        svc.open(zpath)


def test_aes_branch_is_a_separate_code_path_from_zipcrypto(tmp_path, monkeypatch):
    """A genuinely non-AES ZipCrypto-protected archive must never be routed
    through the AES/pyzipper branch, and vice versa -- _is_aes_encrypted
    must gate which extractor runs."""
    src = Path(__file__).resolve().parents[1].joinpath(
        "src", "services", "import_service.py"
    ).read_text(encoding="utf-8")
    open_block = src.split("def open(self", 1)[1]
    assert "if self._is_aes_encrypted(infos):" in open_block
    assert "self._extract_aes_password_protected(source, infos, temp, progress_callback)" in open_block
    assert "self._extract_password_protected(archive, infos, temp, progress_callback)" in open_block


def test_pyzipper_is_declared_as_a_dependency():
    requirements = Path(__file__).resolve().parents[1].joinpath("requirements.txt").read_text(encoding="utf-8")
    assert "pyzipper" in requirements


def test_real_pyzipper_end_to_end_if_installed(tmp_path):
    """If the real 'pyzipper' package happens to be installed in whatever
    environment runs this test, additionally prove the code path against a
    genuinely AES-encrypted archive (not the fake stand-in above)."""
    pyzipper = pytest.importorskip("pyzipper")

    src_dir = tmp_path / "src"
    src_dir.mkdir()
    (src_dir / "a.txt").write_text("hello world", encoding="utf-8")
    zpath = tmp_path / "real_aes.zip"
    with pyzipper.AESZipFile(
        zpath, "w", compression=pyzipper.ZIP_DEFLATED, encryption=pyzipper.WZ_AES
    ) as z:
        z.setpassword(b"clinicalopt")
        z.write(src_dir / "a.txt", "a.txt")

    svc = ImportService(zip_password_service=ZipPasswordService(config_path=tmp_path / "pw.json"))
    ws = svc.open(zpath)
    assert (ws / "a.txt").read_text() == "hello world"
    svc.cleanup()
