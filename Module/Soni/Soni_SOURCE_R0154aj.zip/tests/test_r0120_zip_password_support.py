from __future__ import annotations

import json
import shutil
import subprocess
import zipfile
from pathlib import Path

import pytest

from src.services.import_service import ImportService
from src.services.zip_password_service import ZipPasswordService, DEFAULT_SEED_PASSWORDS

HAS_ZIP_CLI = shutil.which("zip") is not None
requires_zip_cli = pytest.mark.skipif(
    not HAS_ZIP_CLI,
    reason="Building a real ZipCrypto-encrypted fixture needs the 'zip' CLI; "
           "skipped where it is not on PATH.",
)


def _make_password_zip(tmp_path: Path, name: str, password: str | None) -> Path:
    src_dir = tmp_path / f"src_{name}"
    src_dir.mkdir()
    (src_dir / "a.txt").write_text("hello world", encoding="utf-8")
    (src_dir / "sub").mkdir()
    (src_dir / "sub" / "b.txt").write_text("nested", encoding="utf-8")
    out = tmp_path / f"{name}.zip"
    cmd = ["zip", "-q"]
    if password is not None:
        cmd += ["-P", password]
    cmd += ["-r", str(out), "a.txt", "sub"]
    subprocess.run(cmd, cwd=src_dir, check=True)
    return out


def test_default_password_is_seeded_into_a_plain_editable_config_file(tmp_path):
    """The built-in default must land in a normal, user-editable file --
    not stay a fixed value only the source code can change."""
    cfg_path = tmp_path / "zip_passwords.json"
    svc = ZipPasswordService(config_path=cfg_path)
    assert not cfg_path.exists()
    passwords = svc.get_passwords()
    assert passwords == list(DEFAULT_SEED_PASSWORDS)
    assert cfg_path.exists()
    on_disk = json.loads(cfg_path.read_text(encoding="utf-8"))
    assert on_disk["passwords"] == list(DEFAULT_SEED_PASSWORDS)


def test_passwords_can_be_added_removed_and_replaced_without_code_changes(tmp_path):
    cfg_path = tmp_path / "zip_passwords.json"
    svc = ZipPasswordService(config_path=cfg_path)
    svc.get_passwords()  # seed the file
    svc.add_password("site-b-password")
    assert svc.get_passwords() == ["clinicalopt", "site-b-password"]
    svc.remove_password("clinicalopt")
    assert svc.get_passwords() == ["site-b-password"]
    svc.set_passwords(["only-this-one"])
    assert svc.get_passwords() == ["only-this-one"]


@requires_zip_cli
def test_unencrypted_zip_is_unaffected(tmp_path):
    zpath = _make_password_zip(tmp_path, "plain", password=None)
    svc = ImportService(zip_password_service=ZipPasswordService(config_path=tmp_path / "pw.json"))
    ws = svc.open(zpath)
    assert (ws / "a.txt").read_text() == "hello world"
    svc.cleanup()


@requires_zip_cli
def test_default_password_opens_a_matching_zip_without_any_manual_setup(tmp_path):
    zpath = _make_password_zip(tmp_path, "clinicalopt_protected", password="clinicalopt")
    svc = ImportService(zip_password_service=ZipPasswordService(config_path=tmp_path / "pw.json"))
    ws = svc.open(zpath)
    assert (ws / "a.txt").read_text() == "hello world"
    assert (ws / "sub" / "b.txt").read_text() == "nested"
    svc.cleanup()


@requires_zip_cli
def test_wrong_password_stops_cleanly_with_no_partial_output(tmp_path):
    zpath = _make_password_zip(tmp_path, "other_password", password="not-configured-anywhere")
    svc = ImportService(zip_password_service=ZipPasswordService(config_path=tmp_path / "pw.json"))
    with pytest.raises(PermissionError):
        svc.open(zpath)
    # No leaked/half-extracted temp workspace after a failed attempt.
    assert svc.temp_dirs == []


@requires_zip_cli
def test_adding_the_right_password_afterward_makes_the_same_zip_open(tmp_path):
    """This is the actual 'configurable, not hardcoded' guarantee: a zip
    that fails against the default list succeeds once the site adds its
    own password -- no code change, no rebuild."""
    zpath = _make_password_zip(tmp_path, "site_specific", password="a-site-specific-password")
    pw_svc = ZipPasswordService(config_path=tmp_path / "pw.json")
    svc = ImportService(zip_password_service=pw_svc)
    with pytest.raises(PermissionError):
        svc.open(zpath)

    pw_svc.add_password("a-site-specific-password")
    ws = svc.open(zpath)
    assert (ws / "a.txt").read_text() == "hello world"
    svc.cleanup()


def test_no_configured_passwords_raises_a_clear_error(tmp_path, monkeypatch):
    cfg_path = tmp_path / "pw.json"
    cfg_path.write_text(json.dumps({"passwords": []}), encoding="utf-8")
    svc = ImportService(zip_password_service=ZipPasswordService(config_path=cfg_path))

    # Force the "this archive needs a password" branch directly rather than
    # fighting zipfile's writer (ZipFile.writestr recomputes flag_bits, so a
    # manually-set encryption bit does not survive a round trip). The real
    # flag-bit detection itself is already covered by
    # test_default_password_opens_a_matching_zip_without_any_manual_setup
    # using a genuinely Info-ZIP-encrypted fixture.
    monkeypatch.setattr(ImportService, "_is_encrypted", staticmethod(lambda infos: True))
    zpath = tmp_path / "unreachable.zip"
    with zipfile.ZipFile(zpath, "w") as z:
        z.writestr("a.txt", "irrelevant")

    with pytest.raises(PermissionError, match="no ZIP password is configured"):
        svc.open(zpath)


def test_unsupported_encryption_raises_a_distinct_message(tmp_path, monkeypatch):
    """AES-encrypted ZIPs raise NotImplementedError from stdlib zipfile
    regardless of password; no candidate password will ever help, so the
    message must say so distinctly instead of "wrong password"."""
    cfg_path = tmp_path / "pw.json"
    svc = ImportService(zip_password_service=ZipPasswordService(config_path=cfg_path))

    zpath = tmp_path / "aes.zip"
    with zipfile.ZipFile(zpath, "w") as z:
        z.writestr("a.txt", "irrelevant")

    monkeypatch.setattr(ImportService, "_is_encrypted", staticmethod(lambda infos: True))

    def fake_extract_all(self, archive, infos, temp, progress_callback, pwd):
        raise NotImplementedError("That compression method is not supported")

    monkeypatch.setattr(ImportService, "_extract_all", fake_extract_all)
    with pytest.raises(PermissionError, match="cannot decrypt"):
        svc.open(zpath)


def test_not_implemented_error_is_checked_before_the_wider_runtime_error_branch():
    """NotImplementedError is a RuntimeError subclass. Python tries except
    clauses in source order, so a plain 'except RuntimeError' written before
    'except NotImplementedError' would silently swallow it as a "wrong
    password" case instead. Pin the required order as a regression guard --
    this exact bug shipped once already."""
    import_service_src = Path(__file__).resolve().parents[1].joinpath(
        "src", "services", "import_service.py"
    ).read_text(encoding="utf-8")
    block = import_service_src.split("def _extract_password_protected", 1)[1].split(
        "self._clear_dir(temp)\n        if unsupported_encryption", 1
    )[0]
    not_impl_pos = block.find("except NotImplementedError")
    runtime_pos = block.find("except RuntimeError")
    assert not_impl_pos != -1 and runtime_pos != -1
    assert not_impl_pos < runtime_pos, (
        "except NotImplementedError must appear before except RuntimeError "
        "in source order, since NotImplementedError IS a RuntimeError"
    )


def test_menu_action_and_dialog_are_wired_without_hardcoding_a_second_source_of_truth():
    root = Path(__file__).resolve().parents[1]
    main_window_src = root.joinpath("src", "ui", "main_window.py").read_text(encoding="utf-8")
    dialog_src = root.joinpath("src", "ui", "zip_password_dialog.py").read_text(encoding="utf-8")
    assert "ZIP Password Settings" in main_window_src
    assert "_open_zip_password_settings" in main_window_src
    assert "ZipPasswordSettingsDialog" in dialog_src
    # The dialog must read/write through the same service, not its own file.
    assert "from src.services.zip_password_service import ZipPasswordService" in dialog_src
    assert "self.service.add_password" in dialog_src
    assert "self.service.remove_password" in dialog_src
