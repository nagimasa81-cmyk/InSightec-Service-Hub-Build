from pathlib import Path
from types import SimpleNamespace

from src.services.import_diagnostics_service import ImportDiagnosticsService

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "src" / "ui" / "main_window.py").read_text(encoding="utf-8")
DIAG = (ROOT / "src" / "ui" / "diagnostics.py").read_text(encoding="utf-8")


def test_summary_detail_is_gated_on_initial_binding_not_active_tab_order():
    assert "def _sonication_summary_initial_data_busy" in MAIN
    assert "_selected_data_thread" in MAIN
    assert "_spectrum_preload_thread" in MAIN
    assert "waiting for canonical CPC/Replay binding" in MAIN
    assert "_resume_sonication_summary_after_initial_data" in MAIN


def test_source_switch_invalidates_old_summary_generation():
    body = MAIN.split("def _prepare_source_switch", 1)[1].split("def _run_pending_source_load", 1)[0]
    assert "_sonication_summary_generation" in body
    assert "_cancel_sonication_summary_worker()" in body
    assert "_sonication_summary_waiting_for_initial_data=False" in body


def test_diagnostics_tab_lazily_binds_exact_current_package():
    body = MAIN.split("def _main_tab_changed", 1)[1].split("def _sonication_summary_initial_data_busy", 1)[0]
    assert 'getattr(self.diagnostics_tab, "package", None) is not self.package' in body
    assert "self.diagnostics_tab.load_study(self.package.workspace, self.package)" in body
    assert 'self.diagnostics_tab.clear()' in MAIN


def test_metadata_only_import_diagnostics_export_is_exposed():
    assert 'QPushButton("Export Import Diagnostics ZIP")' in DIAG
    assert "ImportDiagnosticsService().build(self.package)" in DIAG
    assert '"import_diagnostics.json"' in DIAG
    assert 'archive.writestr("README.txt", readme)' in DIAG
    assert "No MR images, Spectrum samples, or log text" in DIAG


def test_import_diagnostics_builds_without_treatment_payload_copy(tmp_path):
    (tmp_path / "SonicationSummary.xml").write_text("<root/>", encoding="utf-8")
    (tmp_path / "Spectrum_12_00_00_0000.dmp").write_bytes(b"1234")
    (tmp_path / "Spectrum_12_00_00_0000.dmp_FFT").write_bytes(b"5678")
    son = SimpleNamespace(
        sonication_number=1, synthetic_identity=True, evidence_folders=[], identity_evidence=["summary"],
        spectrum_files=[], act_files=[], canonical_acquisition_session_index=None,
        canonical_mapping_confidence="Unknown", canonical_mapping_evidence=[],
        mr_timeline_source="Unavailable", mr_timeline_confidence="Unknown",
        mr_sonication_start_s=None, mr_sonication_end_s=None,
        clock_sync_status="Unavailable", cpc_to_ws_clock_offset_s=None,
        clock_sync_anchor_count=0, clock_sync_spread_s=None,
    )
    package = SimpleNamespace(
        workspace=tmp_path, source=tmp_path / "case.zip", sonications=[son], import_audit={"status":"WARN"}
    )
    payload = ImportDiagnosticsService().build(package)
    assert payload["schema"] == "Soni import diagnostics v1"
    assert payload["source"]["workspace_file_count"] == 3
    assert payload["cpc"]["physical_candidate_count"] == 1
    assert "payload bytes" in payload["privacy"]
    # The report stores metadata/paths, never source file contents.
    text = repr(payload)
    assert "12345678" not in text
