from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
UI=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
REPO=(ROOT/'src/services/spectrum_evidence_repository.py').read_text(encoding='utf-8')

def test_repository_secondary_cache_is_replay_identity_aware():
    assert '_payload_matches_replay' in REPO
    assert 'replay_key' in REPO
    assert 'self._secondary.pop(key, None)' in REPO
    assert 'cached_secondary_products(self, package, index: int, channel: int, analysis_mode: str, candidate_z: float, replay=None)' in REPO

def test_analyzer_prefers_authoritative_repository_replay():
    block=UI.split('    def load_sonication(self, index: int):',1)[1].split('    def _finish_loaded_sonication_handoff',1)[0]
    assert 'cached = self.spectrum_evidence_repository.cached_replay(self.package, index)' in block
    assert block.index('cached = self.spectrum_evidence_repository.cached_replay') < block.index('local_cached = self._preloaded_replays.get(index)')

def test_visible_tab_self_heals_without_replay_navigation():
    assert 'def _ensure_current_tab_materialized' in UI
    assert 'QTimer.singleShot(0, self._ensure_current_tab_materialized)' in UI
    body=UI.split('def _ensure_current_tab_materialized',1)[1].split('def _apply_vendor_tab_default_layout',1)[0]
    assert 'self._queue_secondary_analysis()' in body
    assert 'self._draw_raw()' in body and 'self._draw_spectrum()' in body and 'self._draw_statistics()' in body

def test_spectrogram_and_band_have_robust_axis_fallbacks():
    assert 'def _spectrum_display_times' in UI
    assert 'Fit to finite data' in UI
    assert 'n=min(len(time),len(db))' in UI
