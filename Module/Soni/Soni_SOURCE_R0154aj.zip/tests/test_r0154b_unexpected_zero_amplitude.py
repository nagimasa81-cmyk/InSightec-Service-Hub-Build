from types import SimpleNamespace

from src.services.element_amplitude_anomaly_service import ElementAmplitudeAnomalyService


def _snapshot(values):
    return SimpleNamespace(values=[SimpleNamespace(channel=ch, measured_amplitude=amp) for ch, amp in values])


def test_reports_active_act_zero_without_exclusion_reason():
    out = ElementAmplitudeAnomalyService.detect(
        _snapshot([(10, 1.0)]), act_zero={10}, act_reasons={}, disabled=set(), defect=set()
    )
    assert set(out) == {10}
    assert "ACT amplitude=0" in out[10].reason


def test_does_not_report_ini_disabled_or_defect_or_explicit_off():
    out = ElementAmplitudeAnomalyService.detect(
        _snapshot([(1, 0.0), (2, 0.0), (3, 0.0)]),
        act_zero={1, 2, 3},
        act_reasons={3: "OffByApod · SkullHeating.log"},
        disabled={1},
        defect={2},
    )
    assert out == {}


def test_reports_measured_zero_even_when_act_value_is_not_zero():
    out = ElementAmplitudeAnomalyService.detect(
        _snapshot([(22, 0.0), (23, 1e-4)]),
        act_zero=set(), act_reasons={}, disabled=set(), defect=set(),
    )
    assert set(out) == {22}
    assert out[22].reason == "Measured amplitude=0"


def test_combines_act_and_measured_zero_evidence_once_per_channel():
    out = ElementAmplitudeAnomalyService.detect(
        _snapshot([(42, 0.0)]), act_zero={42}, act_reasons={}, disabled=set(), defect=set()
    )
    assert set(out) == {42}
    assert out[42].sources == ("ACT amplitude=0 without OFF reason", "Measured amplitude=0")
