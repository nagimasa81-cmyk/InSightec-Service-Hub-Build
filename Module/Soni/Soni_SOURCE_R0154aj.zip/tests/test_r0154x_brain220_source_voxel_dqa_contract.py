from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
DQA=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text(encoding='utf-8')


def test_brain220_sonication_prefers_exact_spectrummsg_for_spectral_view():
    assert 'spectrummsg_candidate = self._exact_spectrummsg_candidate(index)' in HYDRO
    assert 'if self._is_brain220_family(index) and spectrummsg_candidate is not None:' in HYDRO
    assert 'physical CPC remains available as SpectrumDumps' in HYDRO


def test_brain220_dqa_has_no_frequency_family_blanket_na_gate():
    assert 'if 150000.0 <= f0 <= 350000.0:' not in DQA
    assert 'Brain220 focus displacement not proven' not in DQA
    assert 'judgement_exclusion=' in DQA
    assert 'measurement retained' in DQA


def test_summary_has_target_voxel_count_and_size_column():
    assert '"Target voxel(s)"' in MAIN
    assert 'def _summary_target_voxel_text' in MAIN
    assert 'spots_for_sonication' in MAIN
    assert 'BBB internal sub-sonications are excluded from this count' in MAIN
