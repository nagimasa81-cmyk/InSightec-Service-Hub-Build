from pathlib import Path

import numpy as np

from src.services.hydrophone_replay_service import CpcHydrophoneFrame, CpcHydrophoneReplay


ROOT=Path(__file__).resolve().parents[1]


def test_spectrummsg_relative_clock_reaches_mr_sonication_end_once():
    replay=CpcHydrophoneReplay(source_fft=Path('SpectrumMsg-1.dmp'),source_raw=None,channel_count=1)
    replay.mr_sonication_start_s=7.6
    replay.mr_sonication_end_s=27.6
    replay.frames=[CpcHydrophoneFrame(i,np.array([1.0]),[np.array([1.0])],acquisition_time_s=float(i)) for i in range(21)]
    assert np.isclose(replay.mr_frame_times_s[0],7.6)
    assert np.isclose(replay.mr_frame_times_s[-1],27.6)


def test_loaded_export_tab_navigation_cannot_start_secondary_worker():
    text=(ROOT/'src/ui/hydrophone_window.py').read_text()
    tab=text.split('def _analyzer_tab_changed',1)[1].split('def _apply_vendor_tab_default_layout',1)[0]
    assert '_queue_secondary_analysis' not in tab
    queue=text.split('def _queue_secondary_analysis',1)[1].split('def _start_secondary_analysis',1)[0]
    assert 'if not allow_compute:' in queue
    assert 'tab navigation performs no data I/O' in queue


def test_same_study_selection_does_not_restart_full_preload():
    text=(ROOT/'src/ui/main_window.py').read_text()
    block=text.split('def _start_spectrum_preload',1)[1].split('def _spectrum_preload_thread_finished',1)[0]
    assert '_spectrum_preload_active_request' in block
    assert 'Path(package.workspace)' in block
    assert 'return' in block


def test_aggregate_band_energy_is_not_encoded_as_rcv0():
    repo=(ROOT/'src/services/spectrum_evidence_repository.py').read_text()
    ui=(ROOT/'src/ui/hydrophone_window.py').read_text()
    assert 'payload["aggregate_band_energy"]' in repo
    assert 'aggregate_band_energy' in ui
    assert 'SpectrumMsg aggregate (no RCV identity)' in ui


def test_diagnostics_dialogs_are_qobject_slots_on_gui_owner():
    text=(ROOT/'src/ui/diagnostics.py').read_text()
    assert 'worker.finished.connect(self._import_diagnostics_export_done)' in text
    assert 'worker.failed.connect(self._import_diagnostics_export_failed)' in text
    assert 'def done(path)' not in text


def test_brain220_score_has_validated_cpc_fallback():
    text=(ROOT/'src/ui/main_window.py').read_text()
    assert 'def _merge_replay_score_into_acoustic' in text
    assert 'vendor_display_rule1' in text
    assert 'Existing Acquisition Score samples always take precedence' in text


def test_spectrogram_publication_is_independent_of_stale_frequency_controls():
    text=(ROOT/'src/ui/hydrophone_window.py').read_text()
    start=text.index('def _publish_secondary_payload')
    end=text.index('\n    def ',start+4)
    block=text[start:end]
    assert 'self.spec_min.value()' not in block
    assert 'self.spec_max.value()' not in block


def test_power_score_view_uses_canonical_mr_duration():
    text=(ROOT/'src/ui/main_window.py').read_text()
    block=text.split('def _update_acoustic_replay_view',1)[1].split('def _ensure_acoustic_curve_items',1)[0]
    assert 'mr_timeline_duration_s' in block
