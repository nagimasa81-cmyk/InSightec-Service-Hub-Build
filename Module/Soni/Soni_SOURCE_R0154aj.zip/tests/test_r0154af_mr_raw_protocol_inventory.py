from pathlib import Path

from src.services.mr_raw_protocol_service import MrRawProtocolService


def test_raw_series_is_bound_to_exact_mri_params_and_keeps_full_details(tmp_path: Path):
    (tmp_path / "Sonication2").mkdir()
    for name in ("7-2-0-0.raw", "7-2-0-1.raw"):
        (tmp_path / "Sonication2" / name).write_bytes(b"\0" * 16)
    (tmp_path / "MriImageParams.xml").write_text(
        """<xml xmlns:z='#RowsetSchema'><rs:data xmlns:rs='urn:schemas-microsoft-com:rowset'>
        <z:row sonicationindex='2' fieldindex='7' zoneindex='0' arrayindex='0' imgnum='1'
          seriesdiscription='TMAP-ME Axial' imgmatrixx='256' imgmatrixy='128' pixsizex='1.5' pixsizey='1.6'
          slicethick='3' repetitiontimetr='28000' echotimete='3128' mrflipangle='30' varbandwidth='35.71'
          freqdirection='ROW' acquisitionmatrix='256\\0\\0\\128' centerfreq='1277000000'
          actualtransmitgain='17' autotransmitgain='18' prescanr1='7' prescanr2='8' shimx='1' shimy='2' shimz='3'
          rowdirectcosrasx='0' rowdirectcosrasy='1' rowdirectcosrasz='0'
          coldirectcosrasx='1' coldirectcosrasy='0' coldirectcosrasz='0'
          manufacturer='GE MEDICAL SYSTEMS' seriesuid='1.2.3'/>
        <z:row sonicationindex='2' fieldindex='7' zoneindex='0' arrayindex='1' imgnum='2'
          seriesdiscription='TMAP-ME Axial' imgmatrixx='256' imgmatrixy='128' pixsizex='1.5' pixsizey='1.6'
          slicethick='3' repetitiontimetr='28000' echotimete='3128' mrflipangle='30' varbandwidth='35.71'
          freqdirection='ROW' acquisitionmatrix='256\\0\\0\\128' centerfreq='1277000000'
          actualtransmitgain='17' autotransmitgain='18' prescanr1='7' prescanr2='8' shimx='1' shimy='2' shimz='3'
          rowdirectcosrasx='0' rowdirectcosrasy='1' rowdirectcosrasz='0'
          coldirectcosrasx='1' coldirectcosrasy='0' coldirectcosrasz='0'
          manufacturer='GE MEDICAL SYSTEMS' seriesuid='1.2.3'/>
        </rs:data></xml>""",
        encoding="utf-8",
    )
    rows = MrRawProtocolService().read(tmp_path, tmp_path / "Sonication2", 2)
    assert len(rows) == 1
    row = rows[0]
    assert row.field_index == 7
    assert row.raw_files == 2
    assert row.metadata_rows == 2
    assert row.series_description == "TMAP-ME Axial"
    assert row.plane == "Axial"
    assert row.matrix == "256×128"
    assert row.tr_ms == "28"
    assert row.te_ms == "3.128"
    assert row.frequency_direction == "ROW"
    assert row.series_uid == "1.2.3"
    assert {k for k, _ in row.details} >= {"centerfreq", "actualtransmitgain", "shimx", "seriesuid"}


def test_raw_without_mri_params_is_visible_not_silently_dropped(tmp_path: Path):
    folder = tmp_path / "Sonication1"
    folder.mkdir()
    (folder / "23-1-3-0.raw").write_bytes(b"\0" * 16)
    rows = MrRawProtocolService().read(tmp_path, folder, 1)
    assert len(rows) == 1
    assert rows[0].field_index == 23
    assert rows[0].series_description == "Metadata unavailable"
    assert "no matching MriImageParams" in rows[0].details[0][1]
