from types import SimpleNamespace
from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService


def _pkg(tmp_path):
    return SimpleNamespace(workspace=tmp_path, sonications=[])


def test_series_common_uses_axial_phantom_xy_sagittal_baseline_z_and_tilt(monkeypatch, tmp_path):
    svc=DqaFocusAlignmentService(); pkg=_pkg(tmp_path)
    monkeypatch.setattr(svc,'is_dqa',lambda _p: True)
    monkeypatch.setattr(svc,'_summary_focal_ras',lambda _p:{2:(-3.30,97.00,22.37)})
    monkeypatch.setattr(svc,'_series_fixed_focus_ras',lambda _p,_f:((-3.30,97.00,22.37),['centre S2']))
    monkeypatch.setattr(svc,'_dqa_reference_geometry',lambda _p:{
        'center_ras':(-0.98,98.07,40.0),'baseline_s_mm':18.57,'tilt_deg':-0.7,'evidence':['phantom']})
    r=svc.analyze_series(pkg)
    assert round(r.x_mm,2) == -2.32
    assert round(r.y_mm,2) == -1.07
    assert round(r.z_mm,2) == 3.80
    assert r.tilt_deg == -0.7
    assert r.confidence == 'High'


def test_series_common_fails_closed_without_natural_focus(monkeypatch, tmp_path):
    svc=DqaFocusAlignmentService(); pkg=_pkg(tmp_path)
    monkeypatch.setattr(svc,'is_dqa',lambda _p: True)
    monkeypatch.setattr(svc,'_summary_focal_ras',lambda _p:{1:(0.,0.,0.)})
    monkeypatch.setattr(svc,'_series_fixed_focus_ras',lambda _p,_f:(None,['no centre']))
    monkeypatch.setattr(svc,'_dqa_reference_geometry',lambda _p:{'center_ras':(0.,0.,0.),'baseline_s_mm':0.,'tilt_deg':0.,'evidence':[]})
    r=svc.analyze_series(pkg)
    assert r.excluded_reason == 'fixed DQA natural focus unavailable'


def test_series_common_does_not_depend_on_thermal_measurement(monkeypatch, tmp_path):
    svc=DqaFocusAlignmentService(); pkg=_pkg(tmp_path)
    monkeypatch.setattr(svc,'is_dqa',lambda _p: True)
    monkeypatch.setattr(svc,'_summary_focal_ras',lambda _p:{1:(1.,2.,3.)})
    monkeypatch.setattr(svc,'_series_fixed_focus_ras',lambda _p,_f:((1.,2.,3.),[]))
    monkeypatch.setattr(svc,'_dqa_reference_geometry',lambda _p:{'center_ras':(0.,0.,9.),'baseline_s_mm':1.,'tilt_deg':0.2,'evidence':[]})
    monkeypatch.setattr(svc,'_planned_focus_native_measurement',lambda *_a,**_k: (_ for _ in ()).throw(AssertionError('thermal path must not be used')))
    r=svc.analyze_series(pkg)
    assert (r.x_mm,r.y_mm,r.z_mm,r.tilt_deg)==(1.,2.,2.,0.2)
