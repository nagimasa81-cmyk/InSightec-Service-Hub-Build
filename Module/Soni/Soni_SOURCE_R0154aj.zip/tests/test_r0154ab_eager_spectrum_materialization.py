from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REPO=(ROOT/'src/services/spectrum_evidence_repository.py').read_text(encoding='utf-8')
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')


def test_repository_owns_brain220_spectrummsg_sidecar_before_analyzer_exists():
    block=REPO[REPO.index('    def replay('):REPO.index('    def standalone_analysis(')]
    assert 'SpectrumMsgAggregateService().build' in block
    assert 'replay.spectral_replay=spectral' in block
    assert 'replay.spectral_source_kind="Sonication-owned SpectrumMsg"' in block


def test_preload_materializes_every_sonication_and_secondary_products():
    block=MAIN[MAIN.index('class SpectrumPreloadWorker'):MAIN.index('class SonicationMetadataWorker')]
    assert 'order=[target] + [i for i in range(len(sons)) if i != target]' in block
    assert 'repository.authoritative_context(self.package,index,sons[index],_relay)' in block
    assert 'repository.secondary_products(' in block
    assert '"preload_errors":{}' in block


def test_repository_secondary_products_are_composite_aware():
    block=REPO[REPO.index('    def secondary_products('):REPO.index('    def cached_secondary_products(')]
    assert 'spectral=getattr(replay, "spectral_replay", None)' in block
    assert 'spectrum_replay=spectral or replay' in block
    assert 'out=np.full((one.shape[0],8),np.nan,dtype=float)' in block
    assert 'out[:,0]=one[:,0]' in block


def test_opening_brain220_analyzer_does_not_decode_when_composite_is_cached():
    block=HYDRO[HYDRO.index('    def load_sonication('):HYDRO.index('    def _finish_loaded_sonication_handoff', HYDRO.index('    def load_sonication('))]
    assert 'cached_composite = self.spectrum_evidence_repository.cached_replay' in block
    assert 'getattr(getattr(cached_composite, "spectral_replay", None), "frames", None)' in block
    assert 'and not (cached_composite is not None' in block


def test_spectrummsg_preload_uses_candidate_primary_path_not_fft_only_field():
    # SpectrumMsg candidates are represented as raw_path/primary_path by the
    # importer; requiring fft_path would silently disable eager composite preload.
    block=REPO[REPO.index('    def replay('):REPO.index('    def standalone_analysis(')]
    assert 'SpectrumMsgAggregateService().build(spectrummsg.primary_path,hz)' in block
    assert 'SpectrumMsgAggregateService().build(msg_candidates[0].primary_path, hz)' in block
    assert 'getattr(spectrummsg,"fft_path",None) is None' not in block
