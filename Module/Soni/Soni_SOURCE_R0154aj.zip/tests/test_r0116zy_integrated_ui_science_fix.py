from pathlib import Path


def src(name): return Path(name).read_text(encoding="utf-8")

def test_ci_root_cause_and_lists_are_actually_connected():
    s=src("src/ui/main_window.py")
    block=s[s.index("def _update_cavitation_intelligence_page"):s.index("def _build_export_status_tab")]
    assert "self._update_ci_event_element_lists()" in block
    assert "self._update_ci_root_cause()" in block
    assert "self._update_ci_evidence_chain" in block

def test_replay_temperature_and_power_use_canonical_mr_acquisition_time():
    s=src("src/ui/main_window.py")
    assert 'self.temperature_plot.setLabel("bottom", "MR acquisition time", units="s")' in s
    assert 'self.acoustic_control_plot.setLabel("bottom", "MR acquisition time", units="s")' in s
    assert 'plot_tx=plot_tx_abs-irradiation_start' not in s.replace(" ","")
    assert 'x=x_abs-irradiation_start' not in s.replace(" ","")

def test_analyzer_details_only_enables_main_vertical_scroll_when_expanded():
    s=src("src/ui/hydrophone_window.py")
    assert 'self._main_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)' in s
    assert 'def _cavitation_details_toggled' in s
    assert 'Qt.ScrollBarPolicy.ScrollBarAsNeeded if checked else Qt.ScrollBarPolicy.ScrollBarAlwaysOff' not in s

def test_cavitation_event_table_has_no_horizontal_scroll():
    s=src("src/ui/hydrophone_window.py")
    assert 'self.cavitation_observed_table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)' in s
    assert 'QHeaderView.ResizeMode.ResizeToContents if col < 8 else QHeaderView.ResizeMode.Stretch' in s

def test_spectrogram_is_colored_hover_explained_and_data_fitted():
    s=src("src/ui/hydrophone_window.py")
    block=s[s.index("def _draw_spectrogram"):s.index("def _selected_bands")]
    assert 'x_min=float(source_t[0]); x_max=float(source_t[-1])' in block
    assert 'self._apply_selected_time_window(self.spectrogram_plot)' in block
    assert 'pg.ColorMap' in s
    assert 'def _spectrogram_hovered' in s

def test_three_replay_sections_are_horizontal_checkboxes():
    s=src("src/ui/main_window.py")
    for label in ("Images / Registration","Temperature / Spectrum","Power / Score / Cavitation"):
        assert f'QCheckBox("{label}")' in s

def test_treatment_science_labels_reuse_marker_color():
    s=src("src/ui/main_window.py")
    assert 'label_colors[int(row["index"])]=color' in s
    assert 'color=label_colors.get(int(row["index"])' in s

def test_detailed_metadata_is_reconnected_after_fast_replay_load():
    s=src("src/ui/main_window.py")
    assert ('QTimer.singleShot(0, self._update_sonication_metadata)' in s or '_start_sonication_metadata_background()' in s)
