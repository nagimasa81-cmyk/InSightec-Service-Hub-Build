from pathlib import Path


def test_summary_uses_robust_roi_peak_not_single_pixel_maximum():
    src=Path('src/services/replay_service.py').read_text()
    assert '"robust_max"' in src
    assert 'finite_roi[-min(3,finite_roi.size):]' in src
    metrics=src.split('def temperature_metrics',1)[1].split('@staticmethod',1)[0]
    assert 'trend.get("robust_max",trend.get("max",[]))' in metrics
    assert 'trend.get("robust_delta",trend.get("delta",[]))' in metrics
