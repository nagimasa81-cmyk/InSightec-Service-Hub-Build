from types import SimpleNamespace
import numpy as np
from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService


def test_named_nonthermal_series_cannot_become_temperature_from_value_range():
    image=np.full((32,32),37.0,dtype=float)
    for series in ('DQA-Axial','DQA-Sagittal','Brn-NFUSCAL1','T2_Star_ME_1SL','SomeMagnitudeSeries'):
        ev=DqaFocusAlignmentService._thermometry_evidence({'seriesdiscription':series},image)
        assert ev['valid'] is False, series


def test_tmap_series_with_temperature_range_is_valid():
    image=np.full((32,32),37.0,dtype=float)
    ev=DqaFocusAlignmentService._thermometry_evidence({'seriesdiscription':'TMAP3'},image)
    assert ev['valid'] is True and ev['mode']=='absolute'


def test_blank_legacy_series_retains_fail_safe_value_classification():
    image=np.full((32,32),3.0,dtype=float)
    ev=DqaFocusAlignmentService._thermometry_evidence({'seriesdiscription':''},image)
    assert ev['valid'] is True and ev['mode']=='delta'


def test_default_center_setup_selects_fixed_xd_focus(monkeypatch,tmp_path):
    svc=DqaFocusAlignmentService()
    pkg=SimpleNamespace(workspace=tmp_path)
    rows=[
        SimpleNamespace(sonication_counter=0,steering_xyz=(1.0,0.0,150.0)),
        SimpleNamespace(sonication_counter=1,steering_xyz=(0.0,0.0,150.0)),
        SimpleNamespace(sonication_counter=2,steering_xyz=(-2.0,2.0,150.0)),
    ]
    import src.services.sonication_evidence_service as mod
    monkeypatch.setattr(mod.SonicationEvidenceService,'parse_setup_records',lambda self,_w:rows)
    focus,ev=svc._series_fixed_focus_ras(pkg,{1:(8.,9.,10.),2:(1.,2.,3.),3:(4.,5.,6.)})
    assert focus==(1.,2.,3.)
    assert any('default-centre S2' in x for x in ev)
