from pathlib import Path


def test_spectrum_preload_materializes_all_receiver_secondary_products():
    text = Path('src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'channel_count=max(1,min(8,int(getattr(replay,"channel_count",0) or 1)))' in text
    assert 'for channel in range(channel_count):' in text
    assert 'secondary_ready_channels' in text


def test_mr_raw_protocol_tab_is_not_a_hidden_filesystem_trigger():
    text = Path('src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'self.mr_raw_protocol_tab = self._build_mr_raw_protocol_tab()' in text
    assert 'MrRawProtocolService().read(workspace, folder, self.index + 1)' in text
    assert 'elif widget is getattr(self, "mr_raw_protocol_tab", None):' in text
