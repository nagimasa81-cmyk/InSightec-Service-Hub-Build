from pathlib import Path
from src.services.cpc_vendor_reproduction_service import CpcVendorReproductionService

ROOT = Path(__file__).parents[1]
MAIN = (ROOT / "src/ui/main_window.py").read_text(encoding="utf-8")


def _sample_log(tmp_path: Path) -> Path:
    p = tmp_path / "Acquisition_Brain_test.txt"
    p.write_text("""Got StartSpectrumMeasurement\nIncrease Power Rule no. 0 Calculated Energy: <0.25>\nDecrease Power Rule no. 4 Calculated Energy: <0.50>\nSet: ExciterPower = 10 W ExPowerRatio = 0.8\nCycle 1 Done Rule <1>: 0.33 Rule <2>: 0.44\nGot StopSpectrumMeasurement\n""", encoding="utf-8")
    return p


def test_acquisition_brain_single_pass_cache(tmp_path):
    p = _sample_log(tmp_path)
    svc = CpcVendorReproductionService()
    first = svc._parse_acquisition_brain(p)
    second = svc._parse_acquisition_brain(p)
    assert first is second
    assert first.increase0_sessions[0] == [(1, 0.25)]
    assert first.display_rule_sessions[0][1] == [(1, 0.33)]
    assert first.decrease_rule_sessions[0][4] == [(1, 0.50)]
    assert first.power_control_sessions[0][0]["power_ratio"] == 0.8


def test_compatibility_parsers_share_cache(tmp_path):
    p = _sample_log(tmp_path)
    svc = CpcVendorReproductionService()
    assert svc._parse_sessions(p)[0][0] == (1, 0.25)
    assert svc._parse_display_rule1_sessions(p)[0][0] == (1, 0.33)
    assert svc._parse_control_rule_sessions(p)[0][4][0] == (1, 0.50)
    assert svc._parse_power_control_sessions(p)[0][0]["cycle"] == 1


def test_spectrum_preload_worker_relays_real_build_progress():
    assert "repository.authoritative_context(" in MAIN
    assert "_relay" in MAIN
    repo=(ROOT / "src/services/spectrum_evidence_repository.py").read_text(encoding="utf-8")
    assert "progress_callback=progress_callback" in repo


def test_analyzer_open_does_not_start_sync_decode():
    start = MAIN.index("    def _open_hydrophone_window")
    end = MAIN.index("    # --------------------------------------------------------------- Loading", start)
    src = MAIN[start:end]
    assert "accept_preloaded_context" in src
    assert "prepare_for_background_preload" in src
    assert "build_direct(" not in src
