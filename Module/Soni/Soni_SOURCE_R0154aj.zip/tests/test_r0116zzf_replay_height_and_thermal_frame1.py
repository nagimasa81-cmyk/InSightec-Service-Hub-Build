from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'src' / 'ui' / 'main_window.py').read_text(encoding='utf-8')
CONSTANTS = (ROOT / 'src' / 'common' / 'constants.py').read_text(encoding='utf-8')


def test_uniform_thermal_baseline_is_not_rejected():
    # Both the legacy thermal-thumbnail worker and the essential image worker
    # must accept a finite constant temperature frame (valid baseline frame 1).
    thermal_worker = MAIN[MAIN.index('class ThermalThumbnailWorker'):MAIN.index('class EssentialImageLoadWorker')]
    assert 'if not finite.size:' in thermal_worker
    assert 'np.nanstd(finite)' not in thermal_worker

    essential = MAIN[MAIN.index('class EssentialImageLoadWorker'):MAIN.index('class SonicationSummaryDetailWorker')]
    assert "if role=='treatment_mr' and float(np.nanstd(finite))<=1e-8" in essential
    assert "decoded magnitude image is constant" in essential


def test_thumbnail_red_threshold_is_sharp_and_high_side():
    block = MAIN[MAIN.index('def _thermal_red_overlay_icon'):MAIN.index('def _current_pixel_spacing_mm')]
    assert 'temp>=threshold' in block
    assert 'for _ in range(2)' not in block
    assert 'np.pad(mask' not in block


def test_replay_right_pane_has_height_profiles_and_resize_rebalance():
    block = MAIN[MAIN.index('def _rebalance_replay_right_sections'):MAIN.index('def _sync_replay_chart_columns')]
    for profile in ('tight', 'compact', 'normal'):
        assert f'"{profile}"' in block
    assert 'handle_budget' in block
    assert 'setIconSize(icon_size)' in block
    assert 'setMinimumHeight(acoustic_h)' in block
    assert 'def resizeEvent' in MAIN
    assert 'QTimer.singleShot(0,self._rebalance_replay_right_sections)' in MAIN


def test_right_sections_ignore_intrinsic_vertical_size_hints():
    assert 'section.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Ignored)' in MAIN
    assert 'navigator_box.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Ignored)' in MAIN


def test_version_is_zzf():
    version=(ROOT/'VERSION').read_text(encoding='utf-8').strip()
    assert f'APP_VERSION = "{version}"' in CONSTANTS
    assert 'APP_COMMIT = "R0116zzg"' in CONSTANTS
