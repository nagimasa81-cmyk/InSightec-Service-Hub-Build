from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HYDRO = (ROOT / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
REPO = (ROOT / 'src/services/spectrum_evidence_repository.py').read_text(encoding='utf-8')


def _method(text: str, name: str) -> str:
    marker = f'    def {name}('
    start = text.index(marker)
    next_pos = text.find('\n    def ', start + len(marker))
    return text[start:] if next_pos < 0 else text[start:next_pos]


def test_gui_control_timeline_binding_does_not_parse_files():
    body = _method(HYDRO, '_load_observed_cavitation_timeline')
    assert '.parse(' not in body
    assert 'observed_cavitation_timeline' in body
    assert '_secondary_cache' in body


def test_secondary_worker_payload_owns_observed_control_timeline():
    assert 'payload["observed_cavitation_timeline"] = _build_observed_cavitation_timeline_for_replay' in HYDRO
    assert 'payload["observed_cavitation_timeline"] = self._observed_control_timeline(replay)' in REPO


def test_96_percent_publish_is_event_loop_staged_and_nonmodal():
    ready = _method(HYDRO, '_secondary_analysis_ready')
    staged = _method(HYDRO, '_publish_secondary_stage')
    assert '_publish_secondary_payload()' not in ready
    assert '_schedule_secondary_publish(current, payload)' in ready
    assert '_semantic_replay_key(replay) != self._semantic_replay_key(self.replay)' in ready
    scheduler = _method(HYDRO, '_schedule_secondary_publish')
    assert 'QTimer.singleShot(1' in scheduler
    assert '_clear_secondary_analysis_views()' not in scheduler
    assert '_secondary_progress' in HYDRO
    assert 'BackgroundProgressDialog' in HYDRO
    for label in ('Publishing Spectrogram', 'Publishing Vendor Band Energy', 'Publishing Vendor control views', 'Publishing cavitation evidence / control timeline'):
        assert label in staged
    assert 'QTimer.singleShot(0' in staged


def test_cavitation_publish_consumes_cached_timeline():
    refresh = _method(HYDRO, '_refresh_cavitation_analysis')
    load = _method(HYDRO, '_load_observed_cavitation_timeline')
    assert 'self._load_observed_cavitation_timeline()' in refresh
    assert 'cache.get("observed_cavitation_timeline")' in load
