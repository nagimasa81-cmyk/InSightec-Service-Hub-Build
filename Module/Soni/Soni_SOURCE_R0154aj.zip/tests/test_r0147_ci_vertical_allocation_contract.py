from pathlib import Path


def test_ci_fit_does_not_force_viewport_sized_stack_minimum():
    text = Path("src/ui/main_window.py").read_text(encoding="utf-8")
    start = text.index("    def _apply_ci_screen_fit(self) -> None:")
    end = text.index("    def _ci_optional_section_visibility_changed", start)
    block = text[start:end]
    assert "viewport_h - reserve" not in block
    assert "stack_min = 130 if compact else 155" in block
    assert "setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)" in text


def test_linked_vendor_and_control_plots_receive_layout_stretch():
    text = Path("src/ui/main_window.py").read_text(encoding="utf-8")
    assert "vendor_l.addWidget(self.ci_linked_vendor_plot, 1)" in text
    assert "control_l.addWidget(self.ci_linked_control_plot, 1)" in text
