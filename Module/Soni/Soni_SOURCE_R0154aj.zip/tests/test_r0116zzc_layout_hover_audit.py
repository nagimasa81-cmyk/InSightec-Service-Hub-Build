from pathlib import Path
import ast

ROOT=Path(__file__).resolve().parents[1]


def test_no_legacy_ci_triangle_collapsible_factory_remains():
    s=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'def _make_ci_collapsible_section' not in s
    assert 'self.ci_chain_check = QCheckBox("Evidence chain")' in s
    assert 'self.ci_rca_check = QCheckBox("Root Cause Analysis")' in s
    assert 'self.ci_science_check = QCheckBox("Treatment Outcome Science")' in s
    assert 'section_row = QHBoxLayout()' in s


def test_spectrum_fit_is_single_compact_path_without_legacy_vendor_height_override():
    s=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'def _apply_compact_screen_layout' in s
    assert 'vendor_energy_plot.setMinimumHeight(280)' not in s
    assert 'vendor_power_plot.setMinimumHeight(245)' not in s
    assert 'self._main_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)' in s


def test_spectrogram_hover_persists_until_pointer_leaves_and_is_localized():
    s=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
    assert 'def _spectrogram_help_text' in s
    assert "ui_text(lang, 'Spectrogram hover explanation')" in s
    assert '600000' in s
    assert 'event.type() in (QEvent.Type.Leave, QEvent.Type.Hide)' in s
    assert 'QToolTip.hideText()' in s


def test_ci_default_view_uses_passive_scroll_and_no_viewport_sized_stack_minimum():
    s=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
    assert 'def _apply_ci_screen_fit' in s
    assert 'page.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)' in s
    assert 'self.ci_linked_event_table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)' in s
    assert 'viewport_h - reserve' not in s[s.index('def _apply_ci_screen_fit'):s.index('def _ci_optional_section_visibility_changed')]
    assert 'w.setMaximumHeight(16777215)' in s
    assert 'stack.setMinimumHeight(stack_min)' in s


def test_no_duplicate_python_definitions_in_ui_sources():
    for name in ('main_window.py','hydrophone_window.py','i18n.py'):
        path=ROOT/'src/ui'/name
        tree=ast.parse(path.read_text(encoding='utf-8'))
        def check(body):
            seen={}
            for node in body:
                if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
                    seen.setdefault(node.name,[]).append(node.lineno)
                    if isinstance(node,ast.ClassDef):
                        check(node.body)
            dup={k:v for k,v in seen.items() if len(v)>1}
            assert not dup, f'{path.name}: {dup}'
        check(tree.body)
