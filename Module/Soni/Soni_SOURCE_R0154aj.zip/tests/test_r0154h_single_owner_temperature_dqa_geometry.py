from pathlib import Path
from types import SimpleNamespace
import numpy as np

from src.services.replay_service import ReplayService
from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService
from src.services.xd_ini_service import XdIniService


def test_selected_replay_worker_no_longer_owns_authoritative_cpc_decode():
    text=Path('src/ui/main_window.py').read_text(encoding='utf-8')
    # Only SpectrumPreloadWorker may call authoritative_context in GUI worker code.
    assert text.count('repository.authoritative_context(') == 1
    selected=text[text.index('class SelectedReplayDataWorker'):text.index('class DeferredPanelWorker')]
    assert 'repository.authoritative_context(' not in selected
    assert 'CPC preload is owned by the background Spectrum worker' in selected


def test_non_temperature_float32_raw_fails_closed(tmp_path: Path):
    from src.domain.models import SonicationModel, RawFrame
    folder=tmp_path/'Sonication1'; folder.mkdir()
    p=folder/'5-1-0-0.raw'
    # DQA/T2*-like numeric range: valid float32 container, not Celsius/delta-C.
    np.full((256,256),11205.0,dtype='<f4').tofile(p)
    son=SonicationModel('Sonication1',folder,sonication_number=1,temperature_frames=[RawFrame(p,0,'5')])
    svc=ReplayService()
    trend=svc.temperature_trend(son)
    assert trend['source'] == 'Unavailable'
    assert not np.isfinite(np.asarray(trend['max'],float)).any()
    frame=svc.frame(son,0,decode_images=True)
    assert frame.temperature is None
    assert frame.maximum_temperature is None


def test_valid_delta_temperature_still_supported(tmp_path: Path):
    from src.domain.models import SonicationModel, RawFrame
    folder=tmp_path/'Sonication1'; folder.mkdir()
    p=folder/'5-1-0-0.raw'
    np.full((256,256),2.0,dtype='<f4').tofile(p)
    son=SonicationModel('Sonication1',folder,sonication_number=1,temperature_frames=[RawFrame(p,0,'5')])
    frame=ReplayService().frame(son,0,decode_images=True)
    assert frame.temperature_source.startswith('Delta RAW')
    assert abs(float(frame.maximum_temperature)-39.0) < 1e-6


def test_serial_xd_geometry_parser_recovers_1024_and_ignores_0000(tmp_path: Path):
    ini=tmp_path/'Ini'; ini.mkdir()
    (ini/'XdGeometry_0000.ini').write_text('\n'.join(f'XCH{i}= 1 2 3 4' for i in range(1024)),encoding='utf-8')
    real=ini/'XdGeometry_6314.ini'
    real.write_text('\n'.join(f'XCH{i}= {i}.0 {i+1}.0 {i+2}.0 124' for i in range(1024)),encoding='utf-8')
    geo,src=XdIniService().read_channel_geometry(tmp_path)
    assert src == real
    assert len(geo)==1024
    assert geo[0] == (0.0,1.0,2.0)
    assert geo[1023] == (1023.0,1024.0,1025.0)


def test_dqa_repeated_focal_is_not_a_target_voxel_proxy():
    # R0154q correction: repeated focalRAS and BBB internal sub-sonications are
    # not sufficient evidence of multiple treatment targets.
    sons=[SimpleNamespace(sonication_number=6,canonical_steering_xyz=None),SimpleNamespace(sonication_number=7,canonical_steering_xyz=None)]
    package=SimpleNamespace(sonications=sons,workspace='.')
    focal={6:(1.0,2.0,3.0),7:(1.05,2.02,2.99)}
    reason=DqaFocusAlignmentService._dqa_exclusion_reason(package,6,focal)
    assert reason is None


def test_dqa_electronic_steering_is_excluded_from_threshold():
    sons=[
        SimpleNamespace(sonication_number=1,canonical_steering_xyz=(0.0,0.0,150.0)),
        SimpleNamespace(sonication_number=2,canonical_steering_xyz=(0.0,0.0,150.0)),
        SimpleNamespace(sonication_number=3,canonical_steering_xyz=(4.0,4.0,154.0)),
    ]
    package=SimpleNamespace(sonications=sons)
    reason=DqaFocusAlignmentService._dqa_exclusion_reason(package,3,{3:(0,0,0)})
    assert reason == 'electronic steering'


def test_elements_geometry_fallback_is_background_owned_and_cache_only_in_gui():
    text=Path('src/ui/main_window.py').read_text(encoding='utf-8')
    worker=text[text.index('class DeferredPanelWorker'):text.index('class MainWindow') if 'class MainWindow' in text else len(text)]
    assert 'read_channel_geometry(workspace)' in worker
    geom=text[text.index('def _sonication_element_geometry'):text.index('def _sonication_element_channel_states')]
    assert 'fallback_geometry' in geom
    assert 'read_channel_geometry(' not in geom
