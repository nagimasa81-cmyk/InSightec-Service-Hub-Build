from pathlib import Path
import ast

from src.services.mr_timeline_service import MRTimelineService

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
TIMING=(ROOT/'src/services/mr_timeline_service.py').read_text(encoding='utf-8')


def _method_source(source: str, cls: str, method: str) -> str:
    tree=ast.parse(source)
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == cls:
            for child in node.body:
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)) and child.name == method:
                    return ast.get_source_segment(source, child) or ''
    raise AssertionError(f'{cls}.{method} not found')


def test_snapshot_selection_uses_published_element_cache_not_undefined_payload():
    body=_method_source(MAIN,'MainWindow','_element_snapshot_changed')
    assert 'payload = getattr(self, "_element_evidence_cache", None) or {}' in body
    # The former regression read payload without ever binding it locally.
    tree=ast.parse(body)
    assigned={n.id for n in ast.walk(tree) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Store)}
    loaded={n.id for n in ast.walk(tree) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Load)}
    assert 'payload' in assigned and 'payload' in loaded


def test_power_window_discovery_keeps_multiple_ws_logs(tmp_path: Path):
    a=tmp_path/'2026_Aug_23_17_00_00.Log'
    b=tmp_path/'2026_Aug_23_18_00_00.Log'
    a.write_text(
        '17:10:00:000 Main status changed from: Sonication to Sonication power on\n'
        '17:10:13:000 Main status changed from: Sonication power on to Post sonication\n', encoding='utf-8')
    b.write_text(
        '18:20:00:000 Main status changed from: Sonication to Sonication power on\n'
        '18:20:03:000 Main status changed from: Sonication power on to Post sonication\n', encoding='utf-8')
    windows=MRTimelineService()._power_windows(tmp_path)
    assert len(windows) == 2
    assert [round(b-a,3) for a,b in windows] == [13.0,3.0]
    assert [__import__("datetime").datetime.fromtimestamp(a).date().isoformat() for a,_ in windows] == ["2026-08-23","2026-08-23"]
    assert len(windows)==2


def test_reconstructed_timeline_prefers_exact_ws_duration_when_available():
    assert 'exact_power_duration' in TIMING
    assert 'chosen_duration = exact_power_duration if exact_power_duration is not None' in TIMING
    assert 'WS exact acoustic duration + SVAT protocol + MR RAW count' in TIMING

def test_ws_power_window_is_not_indexed_by_acquisition_session_ordinal():
    resolve=_method_source(TIMING,'MRTimelineService','resolve_all')
    assert 'power_windows[session_index]' not in resolve
    assert 'power = self._select_power_window' in resolve
