from pathlib import Path
from types import SimpleNamespace

import numpy as np

from src.services.dqa_focus_alignment_service import DqaFocusAlignmentService
from src.services.hydrophone_replay_service import CpcHydrophoneReplay
from src.services.sonication_log_receiver_service import (
    SonicationLogReceiverService, SonicChannelSnapshot, SonicChannelValue,
)
from src.services.standalone_cavitation_service import StandaloneCavitationService


ROOT=Path(__file__).resolve().parents[1]
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')
DQA=(ROOT/'src/services/dqa_focus_alignment_service.py').read_text(encoding='utf-8')


def test_dqa_analyze_has_no_planned_minus_phantom_fallback():
    analyze=DQA[DQA.index('    def analyze('):DQA.index('    def clear_cache(')]
    assert '_image_native_alignment(package,focal_by_number,number)' in analyze
    assert '_thermal_focus_ras_alignment(' not in analyze
    assert '_focal_reference_frame_compatibility(' not in analyze
    assert 'reference.get("center_ras")' not in analyze
    assert 'focal_by_number[number]' not in analyze.replace(
        'if number is not None and number in focal_by_number:', ''
    ) or 'planned-target evidence only' in analyze


def test_dqa_axial_measurement_never_invents_through_plane_z(monkeypatch):
    svc=DqaFocusAlignmentService()
    son=SimpleNamespace(temperature_frames=[SimpleNamespace(path=Path('t0.raw')),SimpleNamespace(path=Path('t1.raw'))])
    rows=[{'dummy':1}]
    arrays={
        't0.raw':np.full((32,32),37.0,float),
        't1.raw':np.full((32,32),37.0,float),
    }
    arrays['t1.raw'][16,18]=42.0
    monkeypatch.setattr(svc.raw,'read_temperature',lambda path: arrays[Path(path).name])
    monkeypatch.setattr(svc,'_row_for_raw_frame',lambda rows,path: {'orientation':'Axial'})
    monkeypatch.setattr(svc,'_point_in_exported_image_frame',lambda row,ras,**kw:(True,{'x_px':16.0,'y_px':16.0}))
    monkeypatch.setattr(svc,'_ras_delta',lambda row,dx,dy: np.asarray([dx,dy,99.0],float))
    monkeypatch.setattr(svc,'_orientation',lambda row:'Axial')
    out=svc._planned_focus_native_measurement(son,rows,(1.0,2.0,3.0))
    assert out.get('error') is None
    assert out['x_mm'] is not None and out['y_mm'] is not None
    assert out['z_mm'] is None


def test_230_vendor_bands_are_not_overwritten_by_650_r0130_band0():
    profile=SimpleNamespace(bands=[
        SimpleNamespace(index=0,low_hz=75_000.0,high_hz=155_000.0),
        SimpleNamespace(index=1,low_hz=110_000.0,high_hz=120_000.0),
        SimpleNamespace(index=2,low_hz=119_500.0,high_hz=179_500.0),
        SimpleNamespace(index=3,low_hz=225_000.0,high_hz=235_000.0),
    ])
    replay=SimpleNamespace(vendor_profile=profile,main_frequency_hz=230_000.0,frames=[object()])
    out=StandaloneCavitationService().resolved_band_ranges(replay)
    assert out[0][:2] == (75_000.0,155_000.0)
    assert out[3][:2] == (225_000.0,235_000.0)
    assert out[0][2] == 'CavitationSafetyAndControl.ini'


def test_650_family_retains_r0130_fixed_band0_contract():
    profile=SimpleNamespace(bands=[SimpleNamespace(index=0,low_hz=285_000.0,high_hz=365_000.0)])
    replay=SimpleNamespace(vendor_profile=profile,main_frequency_hz=650_000.0,frames=[object()])
    out=StandaloneCavitationService().resolved_band_ranges(replay)
    assert out[0][:2] == (311_000.0,411_000.0)
    assert '650-family' in out[0][2]


def test_act_phase_fills_only_missing_channels_and_never_overwrites_existing(tmp_path: Path):
    act=tmp_path/'Sonication2.act'
    lines=['[Elements]']+[f'Element{i+1}=0.5 {0.01*i}' for i in range(128)]
    act.write_text('\n'.join(lines),encoding='utf-8')
    existing=SonicChannelValue(0,sonication_phase_rad=1.234,sonication_phase_method='SkullMeasures')
    missing=SonicChannelValue(1)
    snap=SonicChannelSnapshot(None,128,tmp_path/'log.txt',[existing,missing])
    out=SonicationLogReceiverService._merge_act_phase(snap,tmp_path,2)
    by={v.channel:v for v in out.values}
    assert by[0].sonication_phase_rad == 1.234
    assert by[0].sonication_phase_method == 'SkullMeasures'
    assert by[1].sonication_phase_rad is not None
    assert 'ACT explicit' in by[1].sonication_phase_method


def test_hydrophone_replay_keeps_separate_spectral_sidecar():
    physical=CpcHydrophoneReplay(source_fft=None,source_raw=None)
    spectral=CpcHydrophoneReplay(source_fft=None,source_raw=None)
    physical.spectral_replay=spectral
    physical.spectral_source_kind='Sonication-owned SpectrumMsg'
    assert physical.spectral_replay is spectral
    assert physical.spectral_source_kind == 'Sonication-owned SpectrumMsg'


def test_loaded_source_worker_merges_physical_cpc_and_sonication_spectrum_files():
    # Structural anti-regression: every package-backed source-worker branch must
    # explicitly merge per-Sonication spectrum_files with cpc_spectrum_files.
    worker=HYDRO[HYDRO.index('class SpectrumSourceWorker'):HYDRO.index('class SpectrumSecondaryWorker')]
    assert worker.count('inventory=list(getattr(package,"cpc_spectrum_files",[]) or [])') >= 3
    assert worker.count('inventory.extend(list(getattr(son,"spectrum_files",[]) or []))') >= 3


def test_composite_decode_attaches_spectrummsg_to_physical_not_replaces_it():
    worker=HYDRO[HYDRO.index('class SpectrumDecodeWorker'):HYDRO.index('def _build_observed_cavitation_timeline_for_replay')]
    assert 'physical.spectral_replay=spectral' in worker
    assert 'replay=physical' in worker
    assert 'Composite ready:' in worker


def test_aggregate_spectrum_energy_is_never_duplicated_into_fake_8_rcv_channels():
    worker=HYDRO[HYDRO.index('class SpectrumSecondaryWorker'):HYDRO.index('class SpectrumSourceWorker') if 'class SpectrumSourceWorker' in HYDRO[HYDRO.index('class SpectrumSecondaryWorker'):] else len(HYDRO)]
    # The class ordering is SourceWorker before SecondaryWorker; slice directly to next known class.
    start=HYDRO.index('class SpectrumSecondaryWorker')
    end=HYDRO.find('\nclass ',start+10)
    block=HYDRO[start:end if end!=-1 else len(HYDRO)]
    assert 'out=np.full((arr.shape[0],8),np.nan,dtype=float)' in block
    assert 'out[:,0]=arr[:,0]' in block


def test_dqa_rejects_float32_t2star_like_raster_as_thermometry(monkeypatch):
    svc=DqaFocusAlignmentService()
    son=SimpleNamespace(
        folder=Path('/tmp/Sonication5'),
        temperature_frames=[SimpleNamespace(path=Path('t0.raw')),SimpleNamespace(path=Path('t1.raw'))],
    )
    # Brain220 DQA field-5 RAW observed in the real export is float32-sized but
    # carries values in the thousands.  It must never be used as a heat map.
    fake=np.full((32,32),12000.0,float)
    monkeypatch.setattr(svc.raw,'read_temperature',lambda path: fake)
    monkeypatch.setattr(svc,'_row_for_raw_frame',lambda rows,path: {'seriesdiscription':'T2_Star_ME_1SL'})
    out=svc._planned_focus_native_measurement(son,[{'dummy':1}],(1.0,2.0,3.0))
    assert str(out.get('error')).startswith('temperature RAW is not validated thermometry')


def test_dqa_source_contains_no_legacy_phantom_relative_numeric_arithmetic():
    # Keep the compatibility method names if old plugins reference them, but the
    # actual hotspot-minus-phantom arithmetic must be absent from the source.
    forbidden=(
        'hx-cx', 'hy-cy', 'phantom delta=',
        'observed thermal focus minus dedicated phantom 3-D centre',
    )
    for token in forbidden:
        assert token not in DQA
