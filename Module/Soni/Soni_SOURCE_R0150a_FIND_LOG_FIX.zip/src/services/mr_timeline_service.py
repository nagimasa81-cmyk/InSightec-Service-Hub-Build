from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import configparser
import re

from src.parsers.ado_rowset import parse_ado_rowset


_CLOCK_RE = re.compile(r"^(\d{2}):(\d{2}):(\d{2}):(\d{3})")


@dataclass(slots=True)
class MRTimeline:
    mr_start_s: float = 0.0
    mr_end_s: float = 0.0
    sonication_start_s: float = 0.0
    sonication_end_s: float = 0.0
    frame_interval_s: float | None = None
    source: str = "Unavailable"
    confidence: str = "Unknown"
    evidence: list[str] = field(default_factory=list)

    @property
    def duration_s(self) -> float:
        return max(0.0, float(self.mr_end_s) - float(self.mr_start_s))


class MRTimelineService:
    """Build one canonical per-Sonication time base owned by the treatment MR scan.

    Canonical clock:
      MR scanning start = 0 s
      MR scanning end   = timeline end
      acoustic power-on/off are events *inside* that window.

    Preferred evidence is workstation-local logs because MR status and FUS power
    state then share one clock.  CPC clocks are deliberately not used to define
    MR zero; they are mapped later through the Sonication power trajectory.
    """

    def resolve_all(self, workspace: Path, sonications: list[object]) -> list[MRTimeline]:
        workspace = Path(workspace)
        summary_rows = self._summary_rows(workspace)
        summary_by_number: dict[int, dict] = {}
        for fallback, row in enumerate(summary_rows, start=1):
            try:
                number = int(float(row.get("sonicationindex", fallback)))
            except (TypeError, ValueError):
                number = fallback
            summary_by_number[number] = row
        power_windows = self._power_windows(workspace)
        scan_intervals = self._scan_intervals(workspace)
        protocol = self._protocol_parameters(workspace)
        out: list[MRTimeline] = []

        for index, son in enumerate(sonications):
            try:
                sonication_number = int(getattr(son, "sonication_number", 0) or 0)
            except (TypeError, ValueError):
                sonication_number = 0
            if sonication_number <= 0:
                sonication_number = index + 1
            row = summary_by_number.get(sonication_number, {})
            hint = self._summary_clock(row)
            # The Sonication evidence binder already resolves the authoritative
            # Acquisition_Brain session.  Use the same ordinal Workstation power
            # window whenever available so MR, CPC and treatment identity cannot
            # drift independently.
            session_index=getattr(son, "canonical_acquisition_session_index", None)
            try: session_index=int(session_index) if session_index is not None else None
            except (TypeError, ValueError): session_index=None
            if session_index is not None and 0 <= session_index < len(power_windows):
                power=power_windows[session_index]
            else:
                power = self._select_power_window(power_windows, hint, max(0, sonication_number - 1), len(sonications))
            if power is not None:
                on_s, off_s = power
                scan = self._select_scan_interval(scan_intervals, on_s, off_s)
                if scan is not None:
                    scan_start, scan_end = scan
                    start = max(0.0, on_s - scan_start)
                    end = max(start, off_s - scan_start)
                    duration = max(end, scan_end - scan_start)
                    out.append(MRTimeline(
                        0.0, duration, start, min(end, duration),
                        self._protocol_scan_time(row, protocol),
                        "WS + MRServer exact status clocks", "Exact",
                        [
                            f"MR Scanning {self._clock(scan_start)} -> {self._clock(scan_end)}",
                            f"Acoustic power {self._clock(on_s)} -> {self._clock(off_s)}",
                            f"MR-relative acoustic window {start:.3f} -> {end:.3f} s",
                        ],
                    ))
                    continue

            # Conservative fallback: protocol timing + exported MR frame count.
            scan_time = self._protocol_scan_time(row, protocol)
            pre = self._protocol_pre_frames(row, protocol)
            count = max(1, int(getattr(son, "replay_frame_count", 1) or 1))
            actual = self._number(row.get("actualduration"))
            if scan_time is not None and scan_time > 0:
                # First exported replay position owns t=0.  The complete scanner
                # window spans one acquisition period per replay frame.
                duration = max(float(count) * scan_time, float(max(0, count - 1)) * scan_time)
                acoustic_start = max(0.0, float(pre) * scan_time)
                acoustic_end = acoustic_start + max(0.0, float(actual or 0.0))
                duration = max(duration, acoustic_end)
                out.append(MRTimeline(
                    0.0, duration, acoustic_start, min(acoustic_end, duration), scan_time,
                    "SVAT protocol + SonicationSummary + MR RAW count", "Reconstructed",
                    [f"ScanTime={scan_time:.3f}s", f"PreSonicateNum={pre}", f"ReplayFrames={count}", f"ActualDuration={float(actual or 0.0):.3f}s"],
                ))
            else:
                duration = float(max(0, count - 1))
                acoustic_end = min(duration, max(0.0, float(actual or 0.0)))
                out.append(MRTimeline(0.0, duration, 0.0, acoustic_end, None, "Replay frame order only", "Low", ["MR clock unavailable"]))
        return out

    @staticmethod
    def _seconds(match: re.Match) -> float:
        return int(match.group(1))*3600.0 + int(match.group(2))*60.0 + int(match.group(3)) + int(match.group(4))/1000.0

    @staticmethod
    def _clock(value: float) -> str:
        value = float(value) % 86400.0
        h = int(value // 3600); value -= h*3600
        m = int(value // 60); value -= m*60
        return f"{h:02d}:{m:02d}:{value:06.3f}"

    @staticmethod
    def _number(value):
        try:
            return float(str(value).strip()) if value is not None else None
        except (TypeError, ValueError):
            return None

    def _summary_rows(self, workspace: Path) -> list[dict]:
        path = next(iter(sorted(workspace.rglob("SonicationSummary.xml"), key=lambda p: len(p.parts))), None)
        if path is None:
            return []
        try:
            rows = list(parse_ado_rowset(path))
        except Exception:
            return []
        def idx(row):
            try: return int(row.get("sonicationindex", 10**9))
            except Exception: return 10**9
        return sorted(rows, key=idx)

    def _summary_clock(self, row: dict) -> float | None:
        raw = str(row.get("sontime", "") or "").strip()
        m = re.search(r"(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})", raw)
        if not m:
            return None
        return int(m.group(4))*3600.0 + int(m.group(5))*60.0 + int(m.group(6))

    def _ws_logs(self, workspace: Path) -> list[Path]:
        candidates=[]
        for p in workspace.rglob("*"):
            if not p.is_file() or p.suffix.lower() != ".log":
                continue
            low=p.name.lower()
            if "mrserver" in low or "service" in low or "dcm" in low or "src_" in low:
                continue
            # Main workstation logs are normally YYYY_Mmm_DD_HH_MM_SS.Log.
            if re.search(r"\d{4}_[a-z]{3}_\d{2}_\d{2}_\d{2}_\d{2}", low):
                candidates.append(p)
        return sorted(candidates, key=lambda p: p.stat().st_size if p.exists() else 0, reverse=True)

    def _power_windows(self, workspace: Path) -> list[tuple[float,float]]:
        on=[]; off=[]
        for path in self._ws_logs(workspace):
            try:
                with path.open("r", errors="ignore") as f:
                    for line in f:
                        m=_CLOCK_RE.match(line)
                        if not m: continue
                        t=self._seconds(m)
                        if "Main status changed from: Sonication to Sonication power on" in line:
                            on.append(t)
                        elif "Main status changed from: Sonication power on to Post sonication" in line:
                            off.append(t)
            except OSError:
                continue
            if on:
                break
        out=[]; j=0
        for start in sorted(on):
            while j < len(off) and off[j] < start:
                j += 1
            if j < len(off):
                out.append((start, off[j])); j += 1
        return out

    def _mrserver_logs(self, workspace: Path) -> list[Path]:
        return sorted([p for p in workspace.rglob("*") if p.is_file() and "mrserver" in p.name.lower() and p.suffix.lower() in (".log", ".txt")], key=lambda p: p.stat().st_size if p.exists() else 0, reverse=True)

    def _scan_intervals(self, workspace: Path) -> list[tuple[float,float]]:
        starts=[]; ends=[]
        for path in self._mrserver_logs(workspace):
            try:
                with path.open("r", errors="ignore") as f:
                    for line in f:
                        m=_CLOCK_RE.match(line)
                        if not m: continue
                        t=self._seconds(m)
                        if "Status changed from Preparing to Scanning." in line:
                            starts.append(t)
                        elif ("Status changed from Scanning to Idle." in line or
                              "Status changed from Scanning to Step is open." in line):
                            ends.append(t)
            except OSError:
                continue
            if starts and ends:
                break
        # Do not consume end markers globally; duplicate/nested state messages
        # exist.  Each start owns the nearest following end within 10 minutes.
        out=[]
        for start in starts:
            following=[e for e in ends if start <= e <= start + 600.0]
            if following:
                out.append((start, min(following)))
        return out

    @staticmethod
    def _select_power_window(windows: list[tuple[float,float]], hint: float | None, index: int, count: int):
        if hint is not None and windows:
            # SonicationSummary.sontime is workflow-start-ish and precedes the
            # exact power-on by seconds. Prefer the first power window shortly
            # after it, but tolerate small clock ordering differences.
            ranked=sorted(windows, key=lambda w: (0 if -5.0 <= w[0]-hint <= 120.0 else 1, abs(w[0]-hint)))
            if ranked and abs(ranked[0][0]-hint) <= 180.0:
                return ranked[0]
        # Never use a latest-N guess when pre-treatment/calibration power windows
        # coexist with treatment Sonications.  Positional fallback is allowed only
        # when the counts prove a one-to-one universe.
        if len(windows) == count > 0 and 0 <= index < len(windows):
            return windows[index]
        return None

    @staticmethod
    def _select_scan_interval(intervals: list[tuple[float,float]], on_s: float, off_s: float):
        containing=[x for x in intervals if x[0] <= on_s <= x[1] and off_s <= x[1] + 2.0]
        if containing:
            return min(containing, key=lambda x: (x[1]-x[0], abs(on_s-x[0])))
        before=[x for x in intervals if 0 <= on_s-x[0] <= 120.0 and x[1] >= off_s]
        return min(before, key=lambda x: abs(on_s-x[0])) if before else None

    def _protocol_parameters(self, workspace: Path):
        configs=[]
        for p in workspace.rglob("*.ini"):
            low=p.name.lower()
            if "brainsvatprotocol" in low and "siemens" in low:
                configs.append(p)
        for path in sorted(configs, key=lambda p: ("nomultislice" not in p.name.lower(), len(p.parts))):
            cp=configparser.ConfigParser(interpolation=None, strict=False)
            cp.optionxform=str
            try:
                cp.read(path, encoding="utf-8-sig")
                if cp.sections(): return cp
            except Exception:
                continue
        return None

    def _protocol_scan_time(self, row: dict, cp) -> float | None:
        if cp is None: return None
        name=str(row.get("protocol", "") or "").strip()
        if not name or not cp.has_section(name): return None
        for key in ("ScanTime", "scantime"):
            if cp.has_option(name,key):
                return self._number(cp.get(name,key))
        return None

    @staticmethod
    def _resolve_alternative_section(cp, name: str, template: str) -> str:
        """Substitute ``$KeyName`` placeholders in an AlternativeSection
        template with that key's own value from the same section.

        e.g. ``AlternativeSection = PSD@$PSDType`` together with
        ``PSDType = SingleEcho`` in section ``name`` resolves to
        ``"PSD@SingleEcho"``. Without this substitution the literal,
        unresolved template string (containing a bare ``$PSDType``) never
        matches any real section name, so the lookup silently falls through
        to the base section -- which typically doesn't carry
        ``PreSonicateNum`` at all -- and the pre-sonication frame count
        defaults to 0. That made every Sonication start line up with MR
        acquisition start (t=0) instead of the true several-second
        pre-sonication scan delay.
        """
        def replace(match: re.Match) -> str:
            key = match.group(1)
            value = cp.get(name, key, fallback=None)
            return value if value is not None else match.group(0)
        return re.sub(r"\$(\w+)", replace, template)

    def _protocol_pre_frames(self, row: dict, cp) -> int:
        if cp is None: return 0
        name=str(row.get("protocol", "") or "").strip()
        if not name or not cp.has_section(name): return 0
        alt_template=cp.get(name,"AlternativeSection",fallback="").strip()
        alt=self._resolve_alternative_section(cp, name, alt_template) if alt_template else ""
        for section in (alt,name):
            if section and cp.has_section(section):
                raw=cp.get(section,"PreSonicateNum",fallback="")
                try: return max(0,int(float(raw)))
                except Exception: pass
        return 0
