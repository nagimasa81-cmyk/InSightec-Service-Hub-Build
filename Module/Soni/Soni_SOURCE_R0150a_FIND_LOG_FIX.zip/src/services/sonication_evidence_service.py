from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import datetime as _dt
import re

import numpy as np

from src.core.fus_export_core import decode_spectrum_structure
from src.parsers.ado_rowset import parse_ado_rowset
from src.services.acoustic_control_service import AcousticControlService


_TIME_RE = re.compile(r"(?P<h>\d{2}):(?P<m>\d{2}):(?P<s>\d{2}):(?P<ms>\d{3})")
_ANGLE_RE = re.compile(r"SkullAttenuationFactorsForEachReceiver:\s*([^\r\n]+)", re.I)
_SONICATION_LOG_RE = re.compile(
    r"Sonication_Brain_\d+_(?P<dow>Mon|Tue|Wed|Thu|Fri|Sat|Sun)_"
    r"(?P<mon>Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)_"
    r"(?P<day>\d{1,2})_(?P<h>\d{2})_(?P<m>\d{2})_(?P<s>\d{2})_(?P<y>\d{4})\.txt$", re.I)


@dataclass(slots=True)
class SonicationSetupRecord:
    clock_s: float
    power_w: float | None = None
    duration_s: float | None = None
    frequency_hz: float | None = None
    sonication_type: int | None = None
    cpc_mode: int | None = None
    cavitation_mode: int | None = None
    cavitation_level: float | None = None
    steering_xyz: tuple[float | None, float | None, float | None] = (None, None, None)
    channel_count: int | None = None
    subsonication_count: int | None = None
    receiver_skull_attenuation: tuple[float, ...] = ()
    source: Path | None = None


@dataclass(slots=True)
class SonicationEvidence:
    sonication_index: int
    spectrummsg_path: Path | None = None
    spectrummsg_frame_count: int | None = None
    spectrummsg_channel_count: int | None = None
    powergraph_size: int | None = None
    powergraph_time_s: np.ndarray = field(default_factory=lambda: np.array([], dtype=float))
    powergraph_power_percent: np.ndarray = field(default_factory=lambda: np.array([], dtype=float))
    actual_duration_s: float | None = None
    displayed_power_w: float | None = None
    summary_power_w: float | None = None
    summary_duration_s: float | None = None
    summary_energy_j: float | None = None
    frequency_hz: float | None = None
    focal_ras: tuple[float | None, float | None, float | None] = (None, None, None)
    cavitation_safety_mode: int | None = None
    acoustic_threshold: float | None = None
    setup_record: SonicationSetupRecord | None = None
    acquisition_session_index: int | None = None
    acquisition_session_start_error_s: float | None = None
    evidence: list[str] = field(default_factory=list)
    file_inventory: dict[str, int] = field(default_factory=dict)
    confidence: str = "Unknown"

    @property
    def spectrum_powergraph_exact(self) -> bool:
        return (
            self.spectrummsg_frame_count is not None
            and self.powergraph_size is not None
            and int(self.spectrummsg_frame_count) == int(self.powergraph_size)
        )


class SonicationEvidenceService:
    """Cross-link Sonication-local and package-level treatment evidence.

    This service intentionally starts from the numbered ``SonicationN`` folder.
    The exported ``SpectrumMsg-N.dmp`` is the local identity anchor.  Its validated
    frame count is compared with ``spotsonicationdata.xml/PowerGraphSize``.  The
    workstation summary supplies the per-sonication power/duration/frequency, and
    the matching regular Type-6 setup block in ``Sonication_Brain`` supplies an
    absolute clock.  That clock is then matched to the Acquisition_Brain session.

    The result is a defensible chain:
      SonicationN -> SpectrumMsg-N -> PowerGraph row -> Sonication_Brain setup
      -> Acquisition_Brain session.
    No latest-N positional assumption is required when this evidence is present.
    """

    def __init__(self) -> None:
        self.acoustic = AcousticControlService()

    @staticmethod
    def _f(row: dict[str, object], key: str) -> float | None:
        try:
            value = row.get(key)
            if value in (None, ""):
                return None
            return float(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _i(row: dict[str, object], key: str) -> int | None:
        try:
            value = row.get(key)
            if value in (None, ""):
                return None
            return int(float(value))
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _clock_s(line: str) -> float | None:
        m = _TIME_RE.search(line)
        if not m:
            return None
        return (
            int(m.group("h")) * 3600.0
            + int(m.group("m")) * 60.0
            + int(m.group("s"))
            + int(m.group("ms")) / 1000.0
        )

    @staticmethod
    def _clock_delta_s(a: float, b: float) -> float:
        d = float(a) - float(b)
        if d > 43200:
            d -= 86400
        elif d < -43200:
            d += 86400
        return d

    @staticmethod
    def _find_first(workspace: Path, pattern: str) -> Path | None:
        items = sorted(workspace.rglob(pattern), key=lambda p: (len(p.parts), str(p).lower()))
        return items[0] if items else None

    @staticmethod
    def _rows_by_index(path: Path | None) -> dict[int, dict[str, object]]:
        if path is None or not path.exists():
            return {}
        try:
            rows = parse_ado_rowset(path)
        except Exception:
            return {}
        out: dict[int, dict[str, object]] = {}
        for row in rows:
            try:
                idx = int(float(row.get("sonicationindex", "")))
            except (TypeError, ValueError):
                continue
            out[idx] = row
        return out

    def _power_graph(self, workspace: Path, index0: int) -> tuple[np.ndarray, np.ndarray] | None:
        # One authoritative decoder is retained in AcousticControlService.
        try:
            return self.acoustic.power_graph_for_sonication(workspace, index0)
        except AttributeError:
            # Backward-compatible fallback while older sources are inspected.
            return self.acoustic._vendor_power_graph(workspace, index0)

    @staticmethod
    def _field(text: str, name: str) -> str | None:
        m = re.search(re.escape(name) + r"\s*<([^>]+)>", text, re.I)
        return m.group(1).strip() if m else None

    @classmethod
    def _float_field(cls, text: str, name: str, scale: float = 1.0) -> float | None:
        value = cls._field(text, name)
        try:
            return float(value) * scale if value is not None else None
        except (TypeError, ValueError):
            return None

    @classmethod
    def _int_field(cls, text: str, name: str) -> int | None:
        value = cls._field(text, name)
        try:
            return int(float(value)) if value is not None else None
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _sonication_log_stamp(path: Path) -> _dt.datetime | None:
        m = _SONICATION_LOG_RE.search(path.name)
        if not m:
            return None
        try:
            return _dt.datetime.strptime(
                f"{m.group('mon')} {m.group('day')} {m.group('y')} {m.group('h')}:{m.group('m')}:{m.group('s')}",
                "%b %d %Y %H:%M:%S",
            )
        except ValueError:
            return None

    def _find_treatment_sonication_log(self, workspace: Path) -> Path | None:
        base = Path(workspace)
        candidates = sorted(base.rglob("Sonication_Brain_*.txt"), key=lambda p: str(p).lower())
        if not candidates:
            return None
        treatment_stamp = self.acoustic._summary_first_sonication_stamp(base)
        stamped = [(self._sonication_log_stamp(path), path) for path in candidates]
        stamped = [(stamp, path) for stamp, path in stamped if stamp is not None]
        if treatment_stamp is not None and stamped:
            before = [(stamp, path) for stamp, path in stamped if stamp <= treatment_stamp]
            if before:
                return max(before, key=lambda item: item[0])[1]
            return min(stamped, key=lambda item: abs((item[0] - treatment_stamp).total_seconds()))[1]
        if stamped:
            return max(stamped, key=lambda item: item[0])[1]
        return candidates[-1]

    def parse_setup_records(self, workspace: Path) -> list[SonicationSetupRecord]:
        path = self._find_treatment_sonication_log(workspace)
        if path is None:
            return []
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            return []
        records: list[SonicationSetupRecord] = []
        i = 0
        while i < len(lines):
            if "CPC Burn Spot fields:" not in lines[i]:
                i += 1
                continue
            clock_s = self._clock_s(lines[i])
            block = [lines[i]]
            i += 1
            # Include CLoadSonicationData metadata and stop at the HW load completion.
            while i < len(lines):
                if "CPC Burn Spot fields:" in lines[i]:
                    break
                block.append(lines[i])
                if "CHwServerThread: LoadSonicationA: done" in lines[i]:
                    i += 1
                    break
                i += 1
            if clock_s is None:
                continue
            text = "\n".join(block)
            attenuation: tuple[float, ...] = ()
            am = _ANGLE_RE.search(text)
            if am:
                try:
                    attenuation = tuple(float(v) for v in re.findall(r"[-+]?\d+(?:\.\d+)?", am.group(1)))
                except ValueError:
                    attenuation = ()
            records.append(SonicationSetupRecord(
                clock_s=float(clock_s),
                power_w=self._float_field(text, "Acoustic Power"),
                duration_s=self._float_field(text, "Duration"),
                frequency_hz=self._float_field(text, "Frequency", 1e6),
                sonication_type=self._int_field(text, "Sonication Type"),
                cpc_mode=self._int_field(text, "CPC Sonication Mode"),
                cavitation_mode=self._int_field(text, "Cavitation Mode"),
                cavitation_level=self._float_field(text, "Cavitation Level"),
                steering_xyz=(
                    self._float_field(text, "Steering X"),
                    self._float_field(text, "Steering Y"),
                    self._float_field(text, "Steering Z"),
                ),
                channel_count=self._int_field(text, "Number Of Channels"),
                subsonication_count=self._int_field(text, "Number Of SubSonications"),
                receiver_skull_attenuation=attenuation,
                source=path,
            ))
        return records

    @staticmethod
    def _setup_match_cost(ev: SonicationEvidence, setup: SonicationSetupRecord) -> float:
        """Zero means the setup signature exactly matches the exported row."""
        cost = 0.0
        if ev.displayed_power_w is not None and setup.power_w is not None:
            cost += abs(ev.displayed_power_w - setup.power_w) / max(abs(ev.displayed_power_w), 1.0) * 100.0
        elif ev.summary_power_w is not None and setup.power_w is not None:
            cost += abs(ev.summary_power_w - setup.power_w) / max(abs(ev.summary_power_w), 1.0) * 100.0
        else:
            cost += 50.0
        if ev.frequency_hz is not None and setup.frequency_hz is not None:
            cost += abs(ev.frequency_hz - setup.frequency_hz) / 1000.0
        else:
            cost += 20.0
        # Workstation revisions differ: some Sonication_Brain setup durations
        # equal SonicationSummary directly, while older exports wrap the acoustic
        # duration in a 3 s setup envelope. Accept whichever documented relation
        # is closer; duration remains corroborating evidence, never the identity
        # key by itself.
        if ev.summary_duration_s is not None and setup.duration_s is not None:
            direct = abs(ev.summary_duration_s - setup.duration_s)
            envelope = abs((ev.summary_duration_s + 3.0) - setup.duration_s)
            cost += min(direct, envelope) * 10.0
        return float(cost)

    def _match_regular_setup_window(self, evidence: list[SonicationEvidence], records: list[SonicationSetupRecord]) -> list[SonicationSetupRecord] | None:
        regular = [r for r in records if r.sonication_type == 6]
        n = len(evidence)
        if n == 0 or len(regular) < n:
            return None
        windows: list[tuple[float, float, int]] = []
        for start in range(len(regular) - n + 1):
            costs = [self._setup_match_cost(ev, rec) for ev, rec in zip(evidence, regular[start:start+n])]
            windows.append((float(sum(costs)), float(max(costs) if costs else 0.0), start))
        windows.sort()
        best_total, best_max, start = windows[0]
        second_total = windows[1][0] if len(windows) > 1 else float("inf")
        # Require every row to agree closely and the chosen window to be unique.
        if best_max > 2.5 or best_total > max(5.0, 0.5 * n):
            return None
        if np.isfinite(second_total) and second_total - best_total < max(5.0, 0.25 * n):
            return None
        return regular[start:start+n]

    def read(self, workspace: Path, sonications: list[object]) -> list[SonicationEvidence]:
        workspace = Path(workspace)
        summary_path = self._find_first(workspace, "SonicationSummary.xml")
        spot_path = self._find_first(workspace, "spotsonicationdata.xml")
        summary = self._rows_by_index(summary_path)
        spot = self._rows_by_index(spot_path)
        result: list[SonicationEvidence] = []

        for index0, model in enumerate(sonications):
            try:
                n = int(getattr(model, "sonication_number", 0) or 0)
            except (TypeError, ValueError):
                n = 0
            if n <= 0:
                name = str(getattr(model, "name", ""))
                m = re.search(r"(\d+)$", name)
                n = int(m.group(1)) if m else index0 + 1
            sr = summary.get(n, {})
            pr = spot.get(n, {})
            folder = Path(getattr(model, "folder", workspace / f"Sonication{n}"))
            spectrum_files = list(getattr(model, "spectrum_files", []) or [])
            spectrum_path = next((Path(p) for p in spectrum_files if "spectrummsg" in Path(p).name.lower()), None)
            if spectrum_path is None:
                direct = folder / f"SpectrumMsg-{n}.dmp"
                spectrum_path = direct if direct.exists() else None
            frame_count = channel_count = None
            if spectrum_path is not None and spectrum_path.exists():
                try:
                    st = decode_spectrum_structure(spectrum_path)
                    frame_count = st.frame_count
                    channel_count = st.channel_count
                except Exception:
                    pass
            # PowerGraph rows are indexed by treatment Sonication number, not by
            # the current ReplayPackage list position.
            pg = self._power_graph(workspace, max(0, n - 1))
            pt = np.asarray(pg[0], float) if pg is not None else np.array([], dtype=float)
            pp = np.asarray(pg[1], float) if pg is not None else np.array([], dtype=float)
            evidence_folders = list(getattr(model, "evidence_folders", []) or [])
            if not evidence_folders and folder.exists():
                evidence_folders = [folder]
            all_local = []
            seen_local: set[Path] = set()
            for evidence_folder in evidence_folders:
                if not Path(evidence_folder).exists():
                    continue
                for p in Path(evidence_folder).rglob("*"):
                    if p.is_file() and p.resolve() not in seen_local:
                        seen_local.add(p.resolve())
                        all_local.append(p)
            inventory = {
                "total": len(all_local),
                "spectrummsg": sum("spectrummsg" in p.name.lower() for p in all_local),
                "act": sum(p.suffix.lower() == ".act" for p in all_local),
                "raw": sum(p.suffix.lower() == ".raw" for p in all_local),
                "ini": sum(p.suffix.lower() == ".ini" for p in all_local),
                "log_or_text": sum(p.suffix.lower() in (".txt", ".log", ".out") for p in all_local),
            }
            ev = SonicationEvidence(
                sonication_index=n,
                file_inventory=inventory,
                spectrummsg_path=spectrum_path,
                spectrummsg_frame_count=frame_count,
                spectrummsg_channel_count=channel_count,
                powergraph_size=self._i(pr, "powergraphsize"),
                powergraph_time_s=pt,
                powergraph_power_percent=pp,
                actual_duration_s=self._f(pr, "actualsonicduration"),
                displayed_power_w=self._f(pr, "displayedpower"),
                summary_power_w=self._f(sr, "power"),
                summary_duration_s=self._f(sr, "duration"),
                summary_energy_j=self._f(sr, "energy"),
                frequency_hz=self._f(sr, "frequency"),
                focal_ras=(self._f(sr, "focalrasx"), self._f(sr, "focalrasy"), self._f(sr, "focalrasz")),
                cavitation_safety_mode=self._i(pr, "cavitationsafetymode"),
                acoustic_threshold=self._f(pr, "acousticthreshold"),
            )
            ev.evidence.append("Sonication folder inventory: " + ", ".join(f"{k}={v}" for k, v in inventory.items()))
            if ev.spectrum_powergraph_exact:
                ev.evidence.append(f"SpectrumMsg frame count {frame_count} == PowerGraphSize {ev.powergraph_size}")
            elif frame_count is not None and ev.powergraph_size is not None:
                ev.evidence.append(f"SpectrumMsg/PowerGraphSize mismatch {frame_count}!={ev.powergraph_size}")
            if ev.actual_duration_s is not None and pt.size:
                delta = abs(float(pt[-1]) - float(ev.actual_duration_s))
                if delta <= 0.01:
                    ev.evidence.append(f"PowerGraph end {pt[-1]:.6f}s == actualsonicduration")
                else:
                    ev.evidence.append(f"PowerGraph/actual duration delta {delta:.3f}s")
            result.append(ev)

        setup_records = self.parse_setup_records(workspace)
        numbers = [ev.sonication_index for ev in result]
        # Positional Type-6 setup windows are defensible only when logical
        # Sonication identity itself is contiguous. For sparse identity sets,
        # leave setup/session unresolved rather than silently shifting rows.
        contiguous = numbers == list(range(numbers[0], numbers[0] + len(numbers))) if numbers else True
        matched = self._match_regular_setup_window(result, setup_records) if contiguous else None
        if matched is not None:
            for ev, rec in zip(result, matched):
                ev.setup_record = rec
                ev.evidence.append(
                    f"Sonication_Brain Type6 setup exact signature: power={rec.power_w:g}W, "
                    f"duration={rec.duration_s:g}s, frequency={rec.frequency_hz/1e3:g}kHz"
                )

        # Bind setup clock to Acquisition_Brain session start. This is independent
        # evidence from the CPC filename/session-end binding used by SpectrumDumps.
        log = self.acoustic.find_log(workspace)
        sessions = self.acoustic.parse_segments(log) if log is not None else []
        used_sessions: set[int] = set()
        for ev in result:
            rec = ev.setup_record
            if rec is None or not sessions:
                continue
            choices = []
            for si, session in enumerate(sessions):
                if si in used_sessions:
                    continue
                delta = self._clock_delta_s(float(session.start_clock_s), rec.clock_s)
                if -0.25 <= delta <= 6.0:
                    choices.append((abs(delta), si, delta))
            if not choices:
                continue
            err, si, delta = min(choices)
            if err <= 3.0:
                ev.acquisition_session_index = int(si)
                ev.acquisition_session_start_error_s = float(err)
                used_sessions.add(si)
                ev.evidence.append(
                    f"Acquisition_Brain session {si+1} starts {delta:.3f}s after Type6 setup"
                )

        for ev in result:
            strong = bool(ev.spectrum_powergraph_exact and ev.setup_record is not None and ev.acquisition_session_index is not None)
            ev.confidence = "Exact" if strong else ("High" if ev.setup_record is not None or ev.acquisition_session_index is not None else "Unknown")
        return result
