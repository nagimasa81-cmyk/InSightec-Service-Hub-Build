# R0150a — Acoustic log locator regression fix

`AcousticControlService.find_log()` now treats a non-existing file-like
Spectrum/FFT path as a locator whose parent is the CPC workspace.

This restores R0034 exact cavitation-control reproduction validation without
changing the power-control rule semantics or release metadata.
