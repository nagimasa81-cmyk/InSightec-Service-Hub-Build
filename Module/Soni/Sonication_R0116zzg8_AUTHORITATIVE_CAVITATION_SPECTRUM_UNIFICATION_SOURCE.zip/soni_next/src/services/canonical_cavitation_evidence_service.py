from __future__ import annotations

from dataclasses import dataclass
from types import SimpleNamespace
from typing import Iterable


@dataclass(frozen=True)
class CanonicalCavitationEvidence:
    detected: bool | None
    observed_events: tuple
    vendor_rule_events: tuple
    candidate_events: tuple
    status: str
    evidence_complete: bool = True
    unavailable_reason: str | None = None

    @property
    def vendor_exceedance_severity(self) -> float | None:
        """Transparent 0–100 threshold-exceedance score for vendor Rule Triggers.

        score = 100 * (1 - threshold / measured), so a just-crossed threshold is
        near 0, 2× threshold is 50, and stronger exceedance approaches 100.
        This is an engineering evidence score, not a clinical cavitation grade.
        """
        scores=[]
        for ev in self.vendor_rule_events:
            try:
                measured=float(getattr(ev,"energy",float("nan")))
                threshold=float(getattr(ev,"baseline",float("nan")))
                if measured>threshold>0:
                    scores.append(max(0.0,min(100.0,100.0*(1.0-threshold/measured))))
            except Exception:
                continue
        return max(scores) if scores else None

    @property
    def rca_events(self) -> tuple:
        """Events admitted to cavitation RCA under the authoritative event gate.

        Cavitation Summary is event-driven: only an observed Decrease or Safety
        control response establishes that a cavitation event occurred. Reproduced
        vendor-rule threshold crossings remain supporting acoustic evidence and must
        never create an RCA event on their own. Once a control event is confirmed,
        vendor-rule rows may still be used by dedicated evidence views, but the
        Summary RCA input itself stays anchored to the observed control response.
        """
        return tuple(self.observed_events)


class CanonicalCavitationEvidenceService:
    """One event contract shared by Replay, CI and Sonication Summary.

    A Cavitation Event/Status exists only when the treatment control path records an
    observed Power Decrease or Safety response. Spectrum/vendor-rule threshold
    crossings and dump-only candidates remain acoustic evidence; they never promote
    Cavitation Status or Cavitation Severity by themselves. Increase is not a
    cavitation event.
    """

    @staticmethod
    def combine(
        timeline_events: Iterable | None = None,
        standalone_analysis=None,
        *,
        timeline_available: bool = True,
        spectrum_available: bool = True,
        unavailable_reason: str | None = None,
    ) -> CanonicalCavitationEvidence:
        observed=[]
        for ev in list(timeline_events or []):
            family=str(getattr(ev,"family","") or "").strip().lower()
            # Authoritative application contract: only an observed Power Decrease
            # or Safety response is a Cavitation Event. Parser flags and acoustic
            # threshold evidence cannot widen this gate.
            if family in {"decrease","safety"}:
                observed.append(ev)

        rule=[]; candidates=[]
        for ev in list(getattr(standalone_analysis,"events",[]) or []):
            severity=str(getattr(ev,"severity","") or "")
            if severity=="Rule Trigger": rule.append(ev)
            elif severity=="Candidate": candidates.append(ev)

        confirmed=bool(observed)
        # Timeline/control evidence is sufficient to decide event status. Spectrum
        # availability only affects supporting evidence completeness, not whether a
        # Decrease/Safety event happened.
        detected = True if confirmed else (False if timeline_available else None)
        complete=bool(timeline_available and spectrum_available)
        if confirmed:
            status=f"Observed control cavitation ×{len(observed)}"
        elif timeline_available:
            status="No Power Decrease / Safety event"
        else:
            status="Control evidence unavailable — Needs attention"
        return CanonicalCavitationEvidence(
            detected=detected,
            observed_events=tuple(observed),
            vendor_rule_events=tuple(rule),
            candidate_events=tuple(candidates),
            status=status,
            evidence_complete=complete,
            unavailable_reason=(None if complete else (unavailable_reason or "One or more cavitation evidence sources were unavailable")),
        )
