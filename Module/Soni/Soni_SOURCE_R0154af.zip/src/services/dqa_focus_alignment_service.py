from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import math
import re

import numpy as np

from src.parsers.ado_rowset import parse_ado_rowset
from src.services.raw_service import RawService


@dataclass(slots=True)
class DqaFocusAlignment:
    x_mm: float | None = None
    y_mm: float | None = None
    z_mm: float | None = None
    tilt_deg: float | None = None
    confidence: str = "Unavailable"
    evidence: list[str] = field(default_factory=list)
    excluded_reason: str | None = None
    judgement_excluded_reason: str | None = None

    @property
    def alert(self) -> bool:
        if self.excluded_reason or self.judgement_excluded_reason:
            return False
        return bool(
            (self.x_mm is not None and abs(float(self.x_mm)) >= 15.0)
            or (self.y_mm is not None and abs(float(self.y_mm)) >= 15.0)
            or (self.z_mm is not None and abs(float(self.z_mm)) >= 20.0)
        )

    @property
    def display(self) -> str:
        if self.excluded_reason:
            return f"N/A — {self.excluded_reason}"
        def f(name: str, value: float | None, unit: str = "mm") -> str:
            return f"{name} {value:+.1f} {unit}" if value is not None and np.isfinite(value) else f"{name} —"
        text="  ".join((f("X", self.x_mm), f("Y", self.y_mm), f("Z", self.z_mm), f("Tilt", self.tilt_deg, "°")))
        if self.judgement_excluded_reason:
            text += "  · Not judged"
        return text


class DqaFocusAlignmentService:
    """Recover DQA mechanical focus alignment and optional thermal focus evidence.

    The DQA *series* alignment follows the workstation/phantom geometry contract:
      * the XD is mechanically fixed for the DQA series;
      * X/Y are the fixed natural-focus position relative to the phantom centre
        measured from the DQA-Axial stack;
      * Z is the same fixed natural focus relative to the lower phantom baseline
        measured from the DQA-Sagittal stack;
      * Tilt is the sagittal phantom-baseline angle, image horizontal = 0 degrees.

    Individual thermal-focus evidence remains a separate contract: observed heated
    focus minus the planned focus of the same Sonication.  It must never be used to
    manufacture missing series geometry, and T2*/NFUSCAL anatomical data must never
    be relabelled as thermometry.
    """

    def __init__(self) -> None:
        self.raw = RawService()
        self._cache: dict[str, DqaFocusAlignment] = {}
        self._reference_cache: dict[str, dict[str, object]] = {}

    @staticmethod
    def is_dqa(package) -> bool:
        """Return True only from treatment-specific DQA evidence.

        Installed exports may contain generic Brain220/Brain650 DQA templates even
        during ordinary treatment, so template presence alone is not sufficient.
        Prefer the actual per-sonication protocol recorded by SonicationSummary or
        ProtocolData. This also works when the ZIP/folder name itself has no DQA
        token, as observed in real Brain220 DQA exports.
        """
        workspace = Path(getattr(package, "workspace", "") or ".")
        candidates = []
        for name in ("SonicationSummary.xml", "ProtocolData.xml"):
            try:
                candidates.extend(sorted(workspace.rglob(name), key=lambda p: (len(p.parts), str(p).lower()))[:2])
            except Exception:
                pass
        for path in candidates:
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            low = text.lower()
            if path.name.lower() == "sonicationsummary.xml":
                # Actual treatment protocol, not merely a protocol template.
                if re.search(r"treatprotocol\s*=\s*['\"][^'\"]*dqa", text, re.I):
                    return True
            else:
                if re.search(r"(?:name|predefinedspotspath)\s*=\s*['\"][^'\"]*dqa", text, re.I):
                    return True
        # Legacy fallback: an explicitly DQA-named source is useful only when
        # treatment protocol tables are absent. It must not override a normal
        # SonicationSummary such as treatprotocol='Brain-Treat'.
        has_summary = any(p.name.lower() == "sonicationsummary.xml" for p in candidates)
        if not has_summary:
            return "dqa" in str(getattr(package, "source", "")).lower()
        return False

    @staticmethod
    def _find_mri_params(workspace: Path) -> Path | None:
        for name in ("MriImageParams.xml", "MRIImageParams.xml"):
            items = sorted(Path(workspace).rglob(name), key=lambda p: (len(p.parts), str(p).lower()))
            if items:
                return items[0]
        return None

    @staticmethod
    def _row_by_number(path: Path | None) -> dict[int, dict[str, object]]:
        if path is None:
            return {}
        try:
            rows = parse_ado_rowset(path)
        except Exception:
            return {}
        out: dict[int, list[dict[str, object]]] = {}
        for row in rows:
            try:
                n = int(float(row.get("sonicationindex", "")))
            except (TypeError, ValueError):
                continue
            out.setdefault(n, []).append(row)
        best: dict[int, dict[str, object]] = {}
        for n, candidates in out.items():
            def quality(row):
                series = str(row.get("seriesdiscription") or row.get("seriesdescription") or "").upper()
                treatment = int(any(t in series for t in ("MEMP", "TMAP", "THERM")))
                try:
                    sx = float(row.get("pixsizex") or 0); sy = float(row.get("pixsizey") or 0)
                    pixels = int(sx > 0 and sy > 0)
                except Exception:
                    pixels = 0
                try:
                    rv = np.asarray([float(row.get(k, 0)) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")])
                    cv = np.asarray([float(row.get(k, 0)) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")])
                    cos = int(np.linalg.norm(rv) > .5 and np.linalg.norm(cv) > .5)
                except Exception:
                    cos = 0
                return treatment, pixels, cos
            best[n] = max(candidates, key=quality)
        return best

    @staticmethod
    def _orientation(row: dict[str, object]) -> str | None:
        try:
            rv = np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")], float)
            cv = np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")], float)
            normal = np.cross(rv, cv)
            axis = int(np.argmax(np.abs(normal)))
            return ("Sagittal", "Coronal", "Axial")[axis]
        except Exception:
            return None

    @staticmethod
    def _pixel_sizes(row: dict[str, object]) -> tuple[float, float] | None:
        try:
            sx = float(row.get("pixsizex")); sy = float(row.get("pixsizey"))
            if sx <= 0 or sy <= 0 or not np.isfinite([sx, sy]).all():
                return None
            return sx, sy
        except Exception:
            return None

    @staticmethod
    def _ras_delta(row: dict[str, object], dx: float, dy: float) -> np.ndarray | None:
        sizes = DqaFocusAlignmentService._pixel_sizes(row)
        if sizes is None:
            return None
        try:
            rv = np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")], float)
            cv = np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")], float)
        except Exception:
            return None
        # The displayed RAW raster uses exported COLUMN direction on screen X
        # and exported ROW direction on screen Y (same convention as metadata UI).
        sx, sy = sizes
        return cv * (float(dx) * sx) + rv * (float(dy) * sy)

    def _hotspot(self, son) -> tuple[float, float, int] | None:
        frames = list(getattr(son, "temperature_frames", []) or [])
        if not frames:
            return None
        try:
            baseline = self.raw.read_temperature(frames[0].path)
        except Exception:
            return None
        finite = baseline[np.isfinite(baseline)]
        absolute = bool(finite.size and 15.0 <= float(np.nanmedian(finite)) <= 80.0)
        best = None
        h, w = baseline.shape
        y0, y1 = int(.10*h), int(.90*h); x0, x1 = int(.10*w), int(.90*w)
        for i, frame in enumerate(frames):
            try:
                arr = self.raw.read_temperature(frame.path)
            except Exception:
                continue
            delta = arr - baseline if absolute else arr
            roi = np.asarray(delta[y0:y1, x0:x1], float)
            if not np.isfinite(roi).any():
                continue
            flat = int(np.nanargmax(roi)); yy, xx = np.unravel_index(flat, roi.shape)
            yy += y0; xx += x0
            peak = float(delta[yy, xx])
            if best is None or peak > best[0]:
                # Local weighted centroid reduces single-pixel noise without
                # changing the measured focus to a global threshold centroid.
                r = 6
                ya, yb = max(0, yy-r), min(h, yy+r+1); xa, xb = max(0, xx-r), min(w, xx+r+1)
                patch = np.asarray(delta[ya:yb, xa:xb], float)
                floor = float(np.nanpercentile(patch[np.isfinite(patch)], 50)) if np.isfinite(patch).any() else 0.0
                weights = np.maximum(patch - floor, 0.0)
                if np.isfinite(weights).all() and float(weights.sum()) > 0:
                    gy, gx = np.indices(weights.shape)
                    cx = xa + float((weights * gx).sum() / weights.sum())
                    cy = ya + float((weights * gy).sum() / weights.sum())
                else:
                    cx, cy = float(xx), float(yy)
                best = (peak, cx, cy, i)
        return (best[1], best[2], best[3]) if best is not None else None

    def _magnitude_for(self, son, temp_index: int) -> np.ndarray | None:
        mags = list(getattr(son, "magnitude_frames", []) or [])
        temps = list(getattr(son, "temperature_frames", []) or [])
        if not mags:
            return None
        if len(mags) <= 1 or len(temps) <= 1:
            mi = 0
        else:
            mi = min(len(mags)-1, round(float(temp_index) * (len(mags)-1) / max(1, len(temps)-1)))
        try:
            return self.raw.read_magnitude(mags[mi].path)
        except Exception:
            return None

    @staticmethod
    def _norm(image: np.ndarray) -> np.ndarray:
        arr = np.asarray(image, float)
        finite = arr[np.isfinite(arr)]
        if not finite.size:
            return np.zeros_like(arr)
        lo, hi = np.nanpercentile(finite, [2, 98])
        if hi <= lo:
            return np.zeros_like(arr)
        return np.clip((arr-lo)/(hi-lo), 0.0, 1.0)

    @classmethod
    def _baseline_line(cls, image: np.ndarray) -> tuple[float, float, float] | None:
        """Return y = slope*x + intercept and a 0..1 support score."""
        a = cls._norm(image); h, w = a.shape
        # Strong horizontal structural boundary in the lower half of the DQA phantom.
        gy = np.abs(a[2:, :] - a[:-2, :])
        xa, xb = int(.18*w), int(.82*w); ya, yb = int(.48*h), int(.88*h)
        if xb-xa < 20 or yb-ya < 20:
            return None
        score = np.nanmean(gy[ya:yb, xa:xb], axis=1)
        if not np.isfinite(score).any():
            return None
        yc = ya + int(np.nanargmax(score)) + 1
        xs=[]; ys=[]; strengths=[]
        for x in range(xa, xb):
            ylo=max(1,yc-6); yhi=min(h-2,yc+7)
            col=gy[ylo-1:yhi-1,x]
            if not col.size or not np.isfinite(col).any():
                continue
            j=int(np.nanargmax(col)); y=ylo+j
            xs.append(float(x)); ys.append(float(y)); strengths.append(float(col[j]))
        if len(xs) < 24:
            return None
        x=np.asarray(xs); y=np.asarray(ys); st=np.asarray(strengths)
        keep=st >= np.nanpercentile(st,40)
        x=x[keep]; y=y[keep]
        if x.size < 20:
            return None
        for _ in range(3):
            slope, intercept=np.polyfit(x,y,1)
            resid=y-(slope*x+intercept); mad=float(np.nanmedian(np.abs(resid-np.nanmedian(resid))))
            tol=max(1.5,3.5*mad)
            keep=np.abs(resid)<=tol
            if keep.sum()<20: break
            x=x[keep]; y=y[keep]
        slope,intercept=np.polyfit(x,y,1)
        support=min(1.0,float(x.size)/max(1,(xb-xa)*.55))
        if abs(float(slope)) > .35:
            return None
        return float(slope),float(intercept),support

    @classmethod
    def _circle_center(cls, image: np.ndarray, baseline_y: float | None = None) -> tuple[float, float, float] | None:
        a=cls._norm(image); h,w=a.shape
        gx=np.zeros_like(a); gy=np.zeros_like(a)
        gx[:,1:-1]=a[:,2:]-a[:,:-2]; gy[1:-1,:]=a[2:,:]-a[:-2,:]
        g=np.hypot(gx,gy)
        cx0=w/2.0; cy0=min(h*.50,(baseline_y-h*.18) if baseline_y is not None else h*.50)
        yy,xx=np.indices(a.shape)
        radius=np.hypot(xx-cx0,yy-cy0)
        mask=(xx>.14*w)&(xx<.86*w)&(yy>.14*h)&(yy<(.76*h if baseline_y is None else baseline_y-3))
        mask &= (radius>.11*w)&(radius<.34*w)
        vals=g[mask]
        vals=vals[np.isfinite(vals) & (vals > 1e-6)]
        if vals.size < 80:
            return None
        # Percentiles over the whole mostly-zero search ROI would yield a zero
        # threshold and make every interior pixel a false circle edge. Rank only
        # real gradient pixels, then fit the strongest structural boundary points.
        thr=float(np.nanpercentile(vals,55))
        ys,xs=np.nonzero(mask & (g>=thr) & (g>1e-6))
        if xs.size < 60:
            return None
        x=xs.astype(float); y=ys.astype(float)
        # Robust algebraic circle fit with radial-residual trimming.
        for _ in range(4):
            A=np.column_stack((x,y,np.ones_like(x))); b=-(x*x+y*y)
            try:
                aa,bb,cc=np.linalg.lstsq(A,b,rcond=None)[0]
            except np.linalg.LinAlgError:
                return None
            cx=-aa/2.0; cy=-bb/2.0; r2=cx*cx+cy*cy-cc
            if r2<=0: return None
            r=math.sqrt(r2); resid=np.abs(np.hypot(x-cx,y-cy)-r)
            med=float(np.nanmedian(resid)); mad=float(np.nanmedian(np.abs(resid-med)))
            keep=resid<=max(2.0,med+2.5*mad)
            if keep.sum()<40: break
            x=x[keep]; y=y[keep]
        if not (.20*w < cx < .80*w and .15*h < cy < .70*h and .10*w < r < .36*w):
            return None
        support=min(1.0,float(x.size)/180.0)
        return float(cx),float(cy),support

    def _measure_one(self, son, row: dict[str, object]) -> dict[str, float | str | None]:
        """Deprecated phantom-relative helper; numeric output intentionally disabled.

        Old releases used hotspot-minus-phantom and baseline-line geometry here.
        Keeping a numeric implementation around made accidental regression too easy.
        """
        return {"orientation": self._orientation(row), "error": "legacy phantom-relative DQA measurement disabled"}

    @staticmethod
    def _frame_identity(path: Path) -> tuple[int, int, int, int] | None:
        m=re.match(r"^(\d+)-(\d+)-(\d+)-(\d+)\.raw$", Path(path).name, re.I)
        return tuple(int(v) for v in m.groups()) if m else None

    @classmethod
    def _row_for_raw_frame(cls, rows: list[dict[str, object]], path: Path) -> dict[str, object] | None:
        """Resolve the MriImageParams row that owns one exported RAW frame.

        A Sonication can contain several fields/slices.  Selecting one arbitrary
        row per Sonication made the thermal hotspot and phantom geometry live in
        different image frames and produced large but plausible DQA offsets.
        """
        ident=cls._frame_identity(path)
        if ident is None:
            return None
        field,son,zone,array_index=ident
        exact=[]
        for row in rows:
            try:
                rf=int(float(row.get("fieldindex")))
                rs=int(float(row.get("sonicationindex")))
                rz=int(float(row.get("zoneindex",0) or 0))
                # RAW final token is exported array index in treatment folders.
                candidates=[]
                for key in ("arrayindex","imgnum"):
                    try: candidates.append(int(float(row.get(key))))
                    except Exception: pass
                if rf==field and rs==son and rz==zone and (array_index in candidates or array_index+1 in candidates):
                    exact.append(row)
            except Exception:
                continue
        if not exact:
            return None
        # Prefer treatment thermometry/magnitude rows with complete physical geometry.
        def quality(row):
            series=str(row.get("seriesdiscription") or row.get("seriesdescription") or "").upper()
            treatment=int(any(t in series for t in ("MEMP","TMAP","THERM")))
            return treatment, int(cls._pixel_sizes(row) is not None)
        return max(exact,key=quality)

    def _native_measurement_for_sonication(self, son, rows: list[dict[str, object]]) -> dict[str, float | str | None]:
        """Legacy API retained only as a fail-closed compatibility shim.

        Historical releases measured hotspot-to-phantom-centre here. That
        quantity is not DQA focus displacement and must never re-enter the
        production path. Callers receive an explicit non-numeric result.
        """
        return {"orientation": None, "error": "legacy phantom-relative DQA measurement disabled"}

    def _thermal_focus_ras_alignment(self, package, reference: dict[str, object], focal_by_number: dict[int, tuple[float,float,float]], current_number: int | None = None) -> DqaFocusAlignment | None:
        """Deprecated phantom-relative 3-D alignment path; permanently disabled.

        Kept only so old plugins/tests fail safely instead of silently restoring
        the pre-R0154aa hotspot-minus-phantom algorithm.
        """
        return None

    @staticmethod
    def _thermometry_evidence(row: dict[str, object] | None, image: np.ndarray) -> dict[str, object]:
        """Classify whether one Field-5-like raster is valid temperature evidence.

        Field number and payload width are not sufficient.  Brain220 exports can
        store `T2_Star_ME_1SL` float32 rasters under field 5; their values are MR
        signal/T2* quantities in the thousands, not degrees C.  DQA must bind the
        RAW to MriImageParams and validate both protocol semantics and value range.
        """
        row = dict(row or {})
        series = str(row.get("seriesdiscription") or row.get("seriesdescription") or "").strip()
        upper = series.upper().replace("*", "_STAR_")
        arr = np.asarray(image, float)
        finite = arr[np.isfinite(arr)]
        evidence = []
        if series:
            evidence.append(f"MriImageParams series={series}")
        else:
            evidence.append("MriImageParams series unavailable")
        known_nonthermal = any(token in upper for token in (
            "T2_STAR", "T2STAR", "NFUSCAL", "DQA-AXIAL", "DQA-SAGITTAL", "DQA-CORONAL"
        ))
        protocol_thermal = any(token in upper for token in ("TMAP", "MEMP", "THERM", "TEMPERATURE"))
        if known_nonthermal:
            return {"valid": False, "mode": None, "reason": f"non-thermometry MR protocol {series or 'unknown'}", "evidence": evidence}
        if not finite.size:
            return {"valid": False, "mode": None, "reason": "temperature raster has no finite samples", "evidence": evidence}
        median = float(np.nanmedian(finite))
        p01, p99 = (float(v) for v in np.nanpercentile(finite, [1, 99]))
        evidence.append(f"value distribution median={median:.3f}, p01={p01:.3f}, p99={p99:.3f}")
        absolute = bool(15.0 <= median <= 80.0 and -10.0 <= p01 and p99 <= 120.0)
        delta_like = bool(-20.0 <= median <= 20.0 and -60.0 <= p01 and p99 <= 100.0)
        if not (absolute or delta_like):
            return {"valid": False, "mode": None, "reason": "temperature values outside validated absolute/delta range", "evidence": evidence}
        # A named MR series must positively identify thermometry.  Value range alone
        # is not sufficient because processed magnitude/phase products can overlap
        # temperature-like ranges.  Only truly blank legacy descriptions retain the
        # value-distribution fallback.
        if series and not protocol_thermal:
            return {"valid": False, "mode": None, "reason": f"named MR series is not a validated thermometry protocol: {series}", "evidence": evidence}
        mode = "absolute" if absolute else "delta"
        evidence.append(("thermal protocol marker present; " if protocol_thermal else "legacy blank protocol; ") + f"validated {mode} temperature distribution")
        return {"valid": True, "mode": mode, "reason": "validated thermometry", "evidence": evidence}

    def _planned_focus_native_measurement(self, son, rows: list[dict[str, object]], planned_ras: tuple[float,float,float]) -> dict[str, object]:
        """Measure observed thermal focus minus the planned focus in one MR raster.

        This is the only production numeric DQA displacement contract.  The planned
        Sonication focus is projected into the exact thermometry frame that owns the
        observed hotspot.  The displacement is then calculated in that frame's
        in-plane physical basis.  The through-plane component is left unavailable;
        it is never manufactured from phantom centre, image centre, another
        Sonication, steering amount or target-voxel coordinates.
        """
        temps=list(getattr(son,"temperature_frames",[]) or [])
        if not temps:
            return {"error":"thermometry unavailable"}
        # A float32-sized raster is not automatically thermometry. Brain220 DQA
        # exports contain T2*/phase-like field-5 RAW whose values are in the
        # thousands. Treating those as temperature produced false focus locations.
        try:
            baseline=np.asarray(self.raw.read_temperature(temps[0].path),float)
        except Exception:
            return {"error":"temperature baseline unavailable"}
        baseline_row=self._row_for_raw_frame(rows,temps[0].path)
        if baseline_row is None:
            return {"error":"temperature baseline has no exact MriImageParams binding"}
        thermo=self._thermometry_evidence(baseline_row,baseline)
        if not bool(thermo.get("valid")):
            return {"error":f"temperature RAW is not validated thermometry: {thermo.get('reason')}", "thermometry_evidence":list(thermo.get("evidence",[]) or [])}
        absolute=(thermo.get("mode") == "absolute")
        best=None
        for ti,tf in enumerate(temps):
            row=self._row_for_raw_frame(rows,tf.path)
            if row is None:
                continue
            ok,diag=self._point_in_exported_image_frame(
                row, planned_ras, in_plane_margin_fraction=.08, normal_tolerance_mm=10.0
            )
            if not ok or not diag:
                continue
            try:
                arr=np.asarray(self.raw.read_temperature(tf.path),float)
            except Exception:
                continue
            if arr.shape != baseline.shape:
                continue
            delta=arr-baseline if absolute else arr
            h,w=delta.shape
            px=float(diag["x_px"]); py=float(diag["y_px"])
            # A DQA focus cannot be accepted from an unrelated hot structure.  Use
            # a local physical search around the planned focus only.
            radius=14
            xa=max(1,int(round(px))-radius); xb=min(w-1,int(round(px))+radius+1)
            ya=max(1,int(round(py))-radius); yb=min(h-1,int(round(py))+radius+1)
            roi=np.asarray(delta[ya:yb,xa:xb],float)
            if roi.shape[0] < 3 or roi.shape[1] < 3 or not np.isfinite(roi).any():
                continue
            filled=np.nan_to_num(roi,nan=0.0)
            pad=np.pad(filled,1,mode="edge")
            sm=sum(pad[dy:dy+roi.shape[0],dx:dx+roi.shape[1]] for dy in range(3) for dx in range(3))/9.0
            flat=int(np.nanargmax(sm)); yy,xx=np.unravel_index(flat,sm.shape)
            score=float(sm[yy,xx]); hx=float(xx+xa); hy=float(yy+ya)
            pixel_distance=float(np.hypot(hx-px,hy-py))
            if pixel_distance > 10.0:
                continue
            ras_delta=self._ras_delta(row,hx-px,hy-py)
            if ras_delta is None or not np.isfinite(ras_delta).all():
                continue
            if best is None or score > best[0]:
                best=(score,ras_delta,row,hx,hy,px,py,Path(tf.path).name,ti)
        if best is None:
            return {"error":"observed focus vs planned focus not measurable in one MR raster"}
        _score,drow,row,hx,hy,px,py,name,ti=best
        orientation=self._orientation(row)
        values=[float(v) for v in drow]
        # Never report a through-plane zero from an in-plane measurement.
        if orientation == "Axial":
            values[2]=None
        elif orientation == "Sagittal":
            values[0]=None
        elif orientation == "Coronal":
            values[1]=None
        return {
            "x_mm":values[0], "y_mm":values[1], "z_mm":values[2],
            "orientation":orientation, "frame":name,
            "hotspot_x":hx, "hotspot_y":hy, "planned_x":px, "planned_y":py,
            "evidence":f"{name}: observed thermal hotspot ({hx:.2f},{hy:.2f}) px - planned focus ({px:.2f},{py:.2f}) px in same {orientation or 'MR'} raster; " + "; ".join(str(v) for v in list(thermo.get("evidence",[]) or [])),
        }

    def _image_native_alignment(self, package, focal_by_number: dict[int, tuple[float,float,float]], current_number: int | None = None) -> DqaFocusAlignment | None:
        """Return Sonication-local observed-minus-planned DQA displacement only."""
        if current_number is None or int(current_number) not in focal_by_number:
            return None
        params=self._find_mri_params(Path(getattr(package,"workspace",".")))
        try:
            rows=parse_ado_rowset(params) if params is not None and Path(params).exists() else []
        except Exception:
            rows=[]
        if not rows:
            return None
        son=None
        for pos,item in enumerate(list(getattr(package,"sonications",[]) or []),start=1):
            n=int(getattr(item,"sonication_number",0) or pos)
            if n == int(current_number):
                son=item; break
        if son is None:
            return None
        planned=focal_by_number[int(current_number)]
        m=self._planned_focus_native_measurement(son,rows,planned)
        if m.get("error"):
            return None
        x=m.get("x_mm"); y=m.get("y_mm"); z=m.get("z_mm")
        vals=[v for v in (x,y,z) if v is not None and np.isfinite(float(v))]
        if not vals:
            return None
        exclusion=self._dqa_exclusion_reason(package,int(current_number),focal_by_number)
        evidence=[
            f"S{int(current_number)} planned focus RAS=({planned[0]:.3f},{planned[1]:.3f},{planned[2]:.3f}) mm",
            str(m.get("evidence") or ""),
            "DQA numeric contract: observed heated focus minus planned focus of the same Sonication; phantom/image centre and steering coordinates are forbidden as displacement zero-points",
        ]
        if exclusion:
            evidence.append(f"Centre-alignment judgement excluded: {exclusion}; measurement retained")
        return DqaFocusAlignment(
            x_mm=None if x is None else float(x), y_mm=None if y is None else float(y), z_mm=None if z is None else float(z),
            tilt_deg=None, confidence="High" if len(vals)>=2 else "Partial", evidence=evidence,
            judgement_excluded_reason=exclusion,
        )

    @staticmethod
    def _absolute_ras(row: dict[str, object], x: float, y: float) -> np.ndarray | None:
        """Convert an exported image pixel coordinate to absolute RAS millimetres."""
        sizes = DqaFocusAlignmentService._pixel_sizes(row)
        if sizes is None:
            return None
        try:
            origin = np.asarray([float(row[k]) for k in ("topleftcoordr","topleftcoorda","topleftcoords")], float)
            rv = np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")], float)
            cv = np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")], float)
        except Exception:
            return None
        if not np.isfinite(origin).all() or np.linalg.norm(rv) < .5 or np.linalg.norm(cv) < .5:
            return None
        sx, sy = sizes
        return origin + cv * (float(x) * sx) + rv * (float(y) * sy)

    @staticmethod
    def _point_in_exported_image_frame(
        row: dict[str, object],
        point_ras: tuple[float, float, float] | np.ndarray,
        *,
        width: int = 256,
        height: int = 256,
        in_plane_margin_fraction: float = 0.20,
        normal_tolerance_mm: float = 18.0,
    ) -> tuple[bool, dict[str, float]]:
        """Validate that a RAS point belongs to the same exported MR frame.

        ``SonicationSummary.focalRAS`` and ``MriImageParams.TopLeftCoordRAS`` are
        not guaranteed to use the same coordinate frame in every workstation
        generation.  R0154g incorrectly assumed that they always did and directly
        subtracted the two.  The result can look like a 100+ mm phantom/focus
        displacement even while the displayed DQA anatomy is visually centered.

        A legitimate point in the same frame must project near the image field of
        view *and* near the image plane.  This is a coordinate-frame sanity gate,
        not a clinical alignment threshold.
        """
        sizes = DqaFocusAlignmentService._pixel_sizes(row)
        if sizes is None:
            return False, {}
        try:
            origin = np.asarray([float(row[k]) for k in ("topleftcoordr","topleftcoorda","topleftcoords")], float)
            rv = np.asarray([float(row[k]) for k in ("rowdirectcosrasx","rowdirectcosrasy","rowdirectcosrasz")], float)
            cv = np.asarray([float(row[k]) for k in ("coldirectcosrasx","coldirectcosrasy","coldirectcosrasz")], float)
            point = np.asarray(point_ras, float)
        except Exception:
            return False, {}
        if point.size != 3 or not np.isfinite(point).all() or not np.isfinite(origin).all():
            return False, {}
        rn=float(np.linalg.norm(rv)); cn=float(np.linalg.norm(cv))
        if rn < .5 or cn < .5:
            return False, {}
        rv=rv/rn; cv=cv/cn
        normal=np.cross(cv,rv)
        nn=float(np.linalg.norm(normal))
        if nn < .5:
            return False, {}
        normal=normal/nn
        sx,sy=sizes
        delta=point-origin
        x_px=float(np.dot(delta,cv)/sx)
        y_px=float(np.dot(delta,rv)/sy)
        normal_mm=float(np.dot(delta,normal))
        mx=float(width)*float(in_plane_margin_fraction)
        my=float(height)*float(in_plane_margin_fraction)
        inside=(-mx <= x_px <= (width-1)+mx and -my <= y_px <= (height-1)+my)
        coplanar=abs(normal_mm) <= float(normal_tolerance_mm)
        return bool(inside and coplanar), {
            "x_px": x_px, "y_px": y_px, "normal_mm": normal_mm,
            "width": float(width), "height": float(height),
        }

    @classmethod
    def _focal_reference_frame_compatibility(cls, reference: dict[str, object], focal_ras) -> tuple[bool, list[str]]:
        """Validate focalRAS against the *DQA image stacks*, not one arbitrary slice.

        Brain220 DQA exports store one MriImageParams row per slice.  Earlier code
        kept only the first row of each field and then required the focus to be
        coplanar with that single slice.  A perfectly valid focus near another
        slice therefore looked like a coordinate-frame mismatch.  The correct
        test is volume-like: the focus must project inside the FOV of at least one
        axial slice and at least one sagittal slice, with a small plane-distance
        tolerance.  This proves common RAS geometry without assuming one fixed
        slice owns the whole series.
        """
        rows=list(reference.get("validation_rows",[]) or [])
        if not rows:
            return False, ["DQA coordinate-frame validation unavailable: no reference image geometry"]
        groups={"Axial":[],"Sagittal":[]}; evidence=[]
        for label,row in rows:
            orientation=cls._orientation(row)
            ok,diag=cls._point_in_exported_image_frame(
                row,focal_ras,in_plane_margin_fraction=0.08,normal_tolerance_mm=6.0
            )
            if orientation in groups:
                groups[orientation].append(bool(ok))
            if diag:
                evidence.append(
                    f"{label} focal projection: x={diag['x_px']:.1f}px, y={diag['y_px']:.1f}px, plane={diag['normal_mm']:+.1f}mm -> {'compatible' if ok else 'mismatch'}"
                )
        required=[name for name in ("Axial","Sagittal") if groups[name]]
        compatible=bool(len(required)>=2 and all(any(groups[name]) for name in required))
        return compatible,evidence

    @staticmethod
    def _read_u16_image(path: Path) -> np.ndarray | None:
        try:
            data = np.fromfile(path, dtype="<u2")
        except Exception:
            return None
        if data.size != 256 * 256:
            return None
        return data.reshape((256, 256))

    def _dqa_reference_geometry(self, package) -> dict[str, object]:
        """Recover DQA phantom geometry with one metadata row per RAW slice.

        A DQA field is a stack, not one image.  Each MriImageParams row carries a
        different slice RAS origin.  Reusing the first row for every RAW frame was
        the root cause of the large false X/Y/Z offsets seen in R0154m.
        """
        token = str(Path(getattr(package, "workspace", ".")).resolve())
        if token in self._reference_cache:
            return dict(self._reference_cache[token])
        workspace = Path(getattr(package, "workspace", "."))
        params = self._find_mri_params(workspace)
        try:
            rows = parse_ado_rowset(params) if params is not None else []
        except Exception:
            rows = []
        axial_rows=[]; sagittal_rows=[]
        for row in rows:
            series = str(row.get("seriesdiscription") or row.get("seriesdescription") or "").strip().lower()
            try:
                field = int(float(row.get("fieldindex", -1)))
                son = int(float(row.get("sonicationindex", -1)))
                imgnum = int(float(row.get("imgnum", 1) or 1))
                zone = int(float(row.get("zoneindex", 0) or 0))
            except Exception:
                continue
            if field < 0 or son < 1 or imgnum < 1 or self._pixel_sizes(row) is None:
                continue
            entry=(son,field,zone,imgnum,row)
            is_axial=("dqa-axial" in series or ("dqa" in series and "axial" in series)
                      or ("dqa" in series and ("_tra" in series or "trans" in series)))
            is_sagittal=("dqa-sagittal" in series or ("dqa" in series and "sagittal" in series)
                         or ("dqa" in series and "_sag" in series))
            if is_axial:
                axial_rows.append(entry)
            if is_sagittal:
                sagittal_rows.append(entry)

        folder_cache={}
        def raw_for(entry):
            son,field,zone,imgnum,_row=entry
            folder=folder_cache.get(son)
            if folder is None:
                folder=workspace / f"Sonication{son}"
                if not folder.exists():
                    matches=[p for p in workspace.rglob(f"Sonication{son}") if p.is_dir()]
                    folder=matches[0] if matches else folder
                folder_cache[son]=folder
            expected=folder / f"{field}-{son}-{zone}-{imgnum-1}.raw"
            if expected.exists():
                return expected
            # Some generations do not preserve zone/index naming exactly.  The
            # metadata row still owns the frame; use imgnum-1 as the final token.
            matches=sorted(folder.glob(f"{field}-{son}-*-{imgnum-1}.raw"))
            return matches[0] if matches else None

        evidence=[]; axial_centres=[]; baseline_s=[]; tilts=[]; validation_rows=[]
        for entry in axial_rows:
            son,field,_zone,imgnum,row=entry
            raw=raw_for(entry)
            if raw is None: continue
            img=self._read_u16_image(raw)
            if img is None: continue
            circle=self._circle_center(img,None)
            if circle is None: continue
            cx,cy,support=circle
            if support < .55: continue
            ras=self._absolute_ras(row,cx,cy)
            if ras is None: continue
            axial_centres.append(np.asarray(ras,float))
            validation_rows.append((f"DQA-Axial S{son} field {field} image {imgnum}",row))

        for entry in sagittal_rows:
            son,field,_zone,imgnum,row=entry
            raw=raw_for(entry)
            if raw is None: continue
            img=self._read_u16_image(raw)
            if img is None: continue
            line=self._baseline_line(img)
            sizes=self._pixel_sizes(row)
            if line is None or sizes is None: continue
            slope,intercept,support=line
            if support < .55: continue
            sx,sy=sizes; x=img.shape[1]/2.0; y=slope*x+intercept
            ras=self._absolute_ras(row,x,y)
            if ras is None: continue
            baseline_s.append(float(ras[2]))
            tilts.append(float(math.degrees(math.atan2(slope*sy,sx))))
            validation_rows.append((f"DQA-Sagittal S{son} field {field} image {imgnum}",row))

        center=None
        if axial_centres:
            arr=np.vstack(axial_centres)
            # The axial stack changes S by design.  Only R/A describe the phantom
            # cylinder centre.  Keep S as the stack median solely for diagnostics.
            center=np.asarray([
                float(np.nanmedian(arr[:,0])),
                float(np.nanmedian(arr[:,1])),
                float(np.nanmedian(arr[:,2])),
            ])
            evidence.append(
                f"Phantom axial centre from {len(arr)} slice-owned frame(s): R={center[0]:.2f} mm, A={center[1]:.2f} mm; slice S range {float(np.nanmin(arr[:,2])):.2f}..{float(np.nanmax(arr[:,2])):.2f} mm"
            )
        if baseline_s:
            evidence.append(
                f"Phantom sagittal lower line from {len(baseline_s)} slice-owned frame(s): S={float(np.nanmedian(baseline_s)):.2f} mm, tilt={float(np.nanmedian(tilts)):+.2f}°"
            )
        result={
            "center_ras": tuple(float(v) for v in center) if center is not None else None,
            "baseline_s_mm": float(np.nanmedian(baseline_s)) if baseline_s else None,
            "tilt_deg": float(np.nanmedian(tilts)) if tilts else None,
            "evidence": evidence,
            "validation_rows": validation_rows,
        }
        self._reference_cache[token]=dict(result)
        return result

    @staticmethod
    def _treatment_spot_count(package, number: int) -> tuple[int | None, str]:
        """Return the number of *executed treatment spots* for one Sonication.

        Brain220 ``bbbnumsubsonicuvw`` / workstation ``BBB spot subsonications``
        describe the internal 3x3 BBB firing pattern inside one treatment spot.
        They are deliberately NOT target-voxel counts.  A treatment target is
        counted only from explicit Sonication->SpotCue ownership rows.
        """
        workspace = Path(getattr(package, "workspace", "") or ".")
        path = next((q for q in workspace.rglob("*") if q.is_file() and q.name.lower()=="spotsonicationdata.xml"), None)
        if path is None:
            return None, "SpotSonicationData unavailable"
        try:
            rows = parse_ado_rowset(path)
        except Exception:
            return None, "SpotSonicationData unreadable"
        cues=[]
        for row in rows:
            try:
                if int(float(row.get("sonicationindex"))) != int(number):
                    continue
            except Exception:
                continue
            cue=str(row.get("spotcue") or "").strip()
            if cue and cue not in cues:
                cues.append(cue)
        if not cues:
            return None, "No explicit Sonication/SpotCue ownership"
        return len(cues), f"SpotSonicationData: {len(cues)} executed SpotCue(s)"

    @staticmethod
    def _dqa_exclusion_reason(package, number: int, focal_by_number: dict[int, tuple[float,float,float]]) -> str | None:
        """Exclude any DQA shot that is not a default-centre, single-target shot.

        This is intentionally strict.  BBB internal sub-sonications are never
        interpreted as target voxels.  Numeric focus/phantom alignment is valid
        only when the export proves one executed treatment spot and workstation
        steering is the default centre for the study.
        """
        # Single-target gate from explicit treatment ownership, never BBB count.
        spot_count, _spot_evidence = DqaFocusAlignmentService._treatment_spot_count(package, int(number))
        if spot_count is not None and int(spot_count) != 1:
            return f"multi-target / {int(spot_count)} treatment spots"

        sons=list(getattr(package,"sonications",[]) or [])
        target=next((s for s in sons if int(getattr(s,"sonication_number",0) or 0)==int(number)),None)
        setup_steering_resolved=False
        try:
            from src.services.sonication_evidence_service import SonicationEvidenceService
            workspace = Path(getattr(package, "workspace", "") or ".")
            setups = SonicationEvidenceService().parse_setup_records(workspace)
            setup = next((r for r in setups if r.sonication_counter is not None and int(r.sonication_counter)+1==int(number)), None)
            usable=[r for r in setups if all(v is not None for v in r.steering_xyz)]
            if setup is not None and all(v is not None for v in setup.steering_xyz) and usable:
                # Default centre is the most axis-centred workstation setup in the
                # same study.  Require that reference itself to be close to the
                # acoustic axis; otherwise fail closed rather than choosing an
                # arbitrary peer median as "centre".
                nominal_rec=min(usable,key=lambda r: float(r.steering_xyz[0])**2+float(r.steering_xyz[1])**2)
                arr=np.asarray(setup.steering_xyz,float)
                nominal=np.asarray(nominal_rec.steering_xyz,float)
                if np.isfinite(arr).all() and np.isfinite(nominal).all():
                    nominal_lateral=float(np.hypot(nominal[0],nominal[1]))
                    if nominal_lateral > 0.5:
                        return "default centre steering not proven"
                    if float(np.linalg.norm(arr-nominal)) > 0.5:
                        return "electronic steering"
                    setup_steering_resolved=True
        except Exception:
            setup_steering_resolved=False

        # Fallback only when workstation setup evidence is unavailable.  Do not
        # use BBB sub-sonication count, repeated focalRAS, or Sonication order as
        # target-voxel proxies.
        if target is not None and not setup_steering_resolved:
            steering=getattr(target,"canonical_steering_xyz",None)
            if steering is not None:
                try:
                    arr=np.asarray([float(v) for v in steering],float)
                    if np.isfinite(arr).all():
                        # If canonical steering is already expressed as offset,
                        # non-zero lateral steering proves non-centre.  For absolute
                        # XYZ forms, defer rather than manufacturing a reference.
                        if abs(float(arr[0])) <= 20.0 and abs(float(arr[1])) <= 20.0 and float(np.hypot(arr[0],arr[1])) > 0.5:
                            return "electronic steering"
                except Exception:
                    pass

        # If explicit ownership exists and is single, the target gate is proved.
        # If it is unavailable, retain historical compatibility for 650 exports;
        # the centre-steering gate above still prevents false DQA numerics.
        return None

    @staticmethod
    def _summary_focal_ras(package) -> dict[int, tuple[float,float,float]]:
        workspace=Path(getattr(package,"workspace","."))
        paths=sorted(workspace.rglob("SonicationSummary.xml"),key=lambda p:(len(p.parts),str(p).lower()))
        if not paths: return {}
        try: rows=parse_ado_rowset(paths[0])
        except Exception: return {}
        out={}
        for row in rows:
            try:
                n=int(float(row.get("sonicationindex")))
                xyz=tuple(float(row.get(k)) for k in ("focalrasx","focalrasy","focalrasz"))
            except Exception: continue
            if all(np.isfinite(v) for v in xyz): out[n]=xyz
        return out

    def analyze(self, package, sonication_index: int | None = None) -> DqaFocusAlignment:
        base_key=str(Path(getattr(package,"workspace",".")).resolve())
        key=f"{base_key}::S{sonication_index if sonication_index is not None else 'package'}"
        if key in self._cache:
            return self._cache[key]
        if not self.is_dqa(package):
            result=DqaFocusAlignment(confidence="Not DQA",evidence=["DQA-only analysis not applicable"])
            self._cache[key]=result; return result

        # Production DQA does not build or consult a phantom-centre reference.
        # SonicationSummary focalRAS is PLANNED focus evidence only; an observed
        # thermometry focus from the same Sonication is required for numerics.
        focal_by_number=self._summary_focal_ras(package)
        number=None
        if sonication_index is not None:
            sons=list(getattr(package,"sonications",[]) or [])
            if 0 <= int(sonication_index) < len(sons):
                number=int(getattr(sons[int(sonication_index)],"sonication_number",int(sonication_index)+1) or int(sonication_index)+1)
            else:
                number=int(sonication_index)+1
        elif focal_by_number:
            number=sorted(focal_by_number)[0]

        # R0154aa production contract: measurement and judgement are separate.
        # Numeric DQA displacement has exactly one zero-point:
        # observed heated focus minus planned focus of the SAME Sonication.
        # Phantom centre, image centre, steering amount, target voxel coordinates
        # and peer Sonications are prohibited as displacement references.
        judgement_exclusion=(self._dqa_exclusion_reason(package,int(number),focal_by_number)
                             if number is not None else None)
        native=self._image_native_alignment(package,focal_by_number,number)
        if native is not None and native.excluded_reason is None:
            if not any("same-raster authority" in str(v) for v in native.evidence):
                native.evidence.append("DQA same-raster authority: observed focus minus planned focus of the same Sonication")
            components=[native.x_mm,native.y_mm,native.z_mm]
            finite=[abs(float(v)) for v in components if v is not None and np.isfinite(float(v))]
            if finite and max(finite) <= 25.0:
                if judgement_exclusion and not native.judgement_excluded_reason:
                    native.judgement_excluded_reason=judgement_exclusion
                    native.evidence.append(f"Centre-alignment judgement excluded: {judgement_exclusion}; measurement retained")
                self._cache[key]=native; return native

        reason="observed focus vs planned focus unavailable"
        evidence=[
            "DQA numeric displacement was not emitted because a same-Sonication observed thermal focus could not be measured against its planned focus in one registered MR raster.",
            "Fail-closed contract: planned focalRAS, phantom centre, image centre, steering coordinates and target voxel coordinates are never subtracted from one another to manufacture DQA displacement.",
        ]
        if number is not None and number in focal_by_number:
            fx,fy,fz=focal_by_number[number]
            evidence.append(f"S{number} planned focalRAS=({fx:.3f},{fy:.3f},{fz:.3f}) mm is retained as planned-target evidence only")
        if judgement_exclusion:
            evidence.append(f"Judgement eligibility: {judgement_exclusion}")
        result=DqaFocusAlignment(confidence="Unavailable",evidence=evidence,excluded_reason=reason)
        self._cache[key]=result; return result


    def _series_fixed_focus_ras(self, package, focal_by_number: dict[int, tuple[float,float,float]]) -> tuple[tuple[float,float,float] | None, list[str]]:
        """Return the mechanically fixed DQA natural-focus RAS.

        Brain220 DQA may electronically steer individual shots while the XD itself
        stays fixed.  ``SonicationSummary.focalRAS`` therefore varies across the
        series and must not be averaged directly.  The default-centre workstation
        setup (smallest lateral steering magnitude) identifies the natural-focus
        shot.  If no unequivocal centre setup exists we fail closed.
        """
        evidence=[]
        try:
            from src.services.sonication_evidence_service import SonicationEvidenceService
            setups=SonicationEvidenceService().parse_setup_records(Path(getattr(package,'workspace','.') or '.'))
        except Exception as exc:
            return None,[f'Workstation steering setup unavailable: {exc}']
        candidates=[]
        for rec in setups:
            try:
                n=int(rec.sonication_counter)+1
                sx,sy,sz=(float(v) for v in rec.steering_xyz)
                if n not in focal_by_number or not np.isfinite([sx,sy,sz]).all():
                    continue
                candidates.append((float(math.hypot(sx,sy)),n,(sx,sy,sz),focal_by_number[n]))
            except Exception:
                continue
        if not candidates:
            return None,['No Sonication has both workstation steering and planned focalRAS evidence']
        candidates.sort(key=lambda v:(v[0],abs(v[2][2]),v[1]))
        best=candidates[0]
        # A DQA natural-focus shot is expected on/very near the acoustic axis.
        # Do not silently choose a steered treatment target as the mechanical focus.
        if best[0] > 0.5:
            return None,[f'Default-centre DQA steering not proven: smallest lateral steering={best[0]:.2f} mm']
        _lat,n,steer,focus=best
        evidence.append(
            f'Fixed XD natural focus from default-centre S{n}: workstation steering=({steer[0]:+.2f},{steer[1]:+.2f},{steer[2]:.2f}), planned focalRAS=({focus[0]:+.2f},{focus[1]:+.2f},{focus[2]:+.2f}) mm'
        )
        return tuple(float(v) for v in focus),evidence

    def analyze_series(self, package) -> DqaFocusAlignment:
        """Return one mechanical DQA alignment shared by the complete series.

        X/Y are derived only from the DQA-Axial phantom centre, Z and Tilt only
        from the DQA-Sagittal phantom baseline.  Individual thermal-map results are
        deliberately not mixed into this series-common mechanical alignment.
        """
        key=f"series::{Path(getattr(package,'workspace','.') or '.').resolve()}"
        if key in self._cache:
            return self._cache[key]
        if not self.is_dqa(package):
            result=DqaFocusAlignment(confidence='Not DQA',evidence=['DQA-only analysis not applicable'])
            self._cache[key]=result; return result

        focal_by_number=self._summary_focal_ras(package)
        reference=self._dqa_reference_geometry(package)
        focus,focus_evidence=self._series_fixed_focus_ras(package,focal_by_number)
        ref_evidence=list(reference.get('evidence',[]) or [])
        if focus is None:
            result=DqaFocusAlignment(
                confidence='Unavailable',
                evidence=[
                    'Series DQA contract: fixed XD natural focus versus DQA phantom geometry; X/Y from Axial, Z/Tilt from Sagittal.',
                    *focus_evidence,*ref_evidence,
                ],
                excluded_reason='fixed DQA natural focus unavailable',
            )
            self._cache[key]=result; return result

        center=reference.get('center_ras')
        baseline=reference.get('baseline_s_mm')
        tilt=reference.get('tilt_deg')
        x=y=z=None
        if center is not None:
            try:
                cr,ca,_cs=(float(v) for v in center)
                if np.isfinite([cr,ca]).all():
                    x=float(focus[0]-cr)
                    y=float(focus[1]-ca)
            except Exception:
                pass
        try:
            if baseline is not None and np.isfinite(float(baseline)):
                z=float(focus[2]-float(baseline))
        except Exception:
            z=None
        try:
            tilt=float(tilt) if tilt is not None and np.isfinite(float(tilt)) else None
        except Exception:
            tilt=None

        finite=[v for v in (x,y,z) if v is not None and np.isfinite(float(v))]
        if not finite and tilt is None:
            result=DqaFocusAlignment(
                confidence='Unavailable',
                evidence=[
                    'Series DQA contract: fixed XD natural focus versus DQA phantom geometry; X/Y from Axial, Z/Tilt from Sagittal.',
                    *focus_evidence,*ref_evidence,
                ],
                excluded_reason='DQA phantom geometry unavailable',
            )
            self._cache[key]=result; return result
        confidence='High' if x is not None and y is not None and z is not None and tilt is not None else 'Partial'
        result=DqaFocusAlignment(
            x_mm=x,y_mm=y,z_mm=z,tilt_deg=tilt,confidence=confidence,
            evidence=[
                'Series-common mechanical DQA alignment: XD fixed; X/Y = natural focus - DQA-Axial phantom centre; Z = natural focus - DQA-Sagittal lower baseline; Tilt = sagittal baseline angle.',
                *focus_evidence,*ref_evidence,
                'Thermometry is audited separately and is not substituted for missing phantom geometry.',
            ],
        )
        self._cache[key]=result; return result

    def clear_cache(self) -> None:
        self._cache.clear()
        self._reference_cache.clear()
