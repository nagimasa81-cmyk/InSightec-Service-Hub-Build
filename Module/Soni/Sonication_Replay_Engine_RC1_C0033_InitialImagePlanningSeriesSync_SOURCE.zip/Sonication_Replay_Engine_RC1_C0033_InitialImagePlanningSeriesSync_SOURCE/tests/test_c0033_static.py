from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEXT = (ROOT / "src/ui/main_window.py").read_text(encoding="utf-8")

def test_initial_frame_is_validated():
    assert "_first_valid_replay_frame" in TEXT
    assert "self.set_frame(self._first_valid_replay_frame()" in TEXT

def test_planning_series_selector_present():
    assert "planning_type_combo" in TEXT
    assert "Planning MR" in TEXT and "Planning CT" in TEXT

def test_empty_thermal_frames_filtered():
    assert "acquisition placeholders" in TEXT
    assert "_thermal_row_map" in TEXT

def test_chart_ratio_is_three_to_four():
    assert "setStretchFactor(0,3)" in TEXT
    assert "setStretchFactor(1,4)" in TEXT
