from pathlib import Path

SRC = (Path(__file__).parents[1] / 'src/ui/hydrophone_window.py').read_text(encoding='utf-8')


def test_physical_history_is_explicitly_labeled_partial():
    assert 'Physical CPC 8CH saved history (may be partial)' in SRC
    assert 'full Sonication-owned hydrophone coverage is SpectrumMsg aggregate' in SRC


def test_composite_brain220_initial_view_prefers_full_spectrummsg_band_energy():
    assert 'getattr(self.replay,"spectral_replay",None) is not None' in SRC
    assert 'self.tabs.currentIndex() == 0' in SRC
    assert 'self.tabs.setCurrentWidget(self.band_tab)' in SRC


def test_source_handoff_exposes_both_physical_and_spectrummsg_counts():
    assert 'Physical CPC history=' in SRC
    assert 'SpectrumMsg full stream=' in SRC
