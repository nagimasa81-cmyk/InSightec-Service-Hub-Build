from pathlib import Path

MAIN = Path(__file__).resolve().parents[1] / 'src' / 'ui' / 'main_window.py'
TEXT = MAIN.read_text(encoding='utf-8')


def block(name, next_name):
    return TEXT.split(f'def {name}',1)[1].split(f'def {next_name}',1)[0]


def test_ci_linked_axis_prefers_sonication_end_over_full_mr_duration():
    b = block('_apply_ci_canonical_mr_axis', '_draw_ci_linked_vendor_energy')
    assert 'mr_sonication_end_s' in b
    assert b.index('mr_sonication_end_s') < b.index('mr_timeline_duration_s')


def test_ci_linked_cache_key_includes_secondary_product_readiness():
    b = block('_ci_linked_payload_fingerprint', '_update_ci_linked_panel')
    assert 'cached_secondary_products' in b
    assert 'aggregate_band_energy' in b
    assert 'aggregate_time_s' in b
    assert 'cavitation_analysis' in b


def test_authoritative_spectrum_handoff_invalidates_linked_panel_cache():
    b = block('_adopt_authoritative_spectrum_context', '_spectrum_preload_ready')
    assert 'self._ci_linked_data_key=None' in b


def test_linked_panel_key_is_not_only_replay_object_identity():
    b = block('_update_ci_linked_panel', '_make_ci_collapsible_section')
    assert '_ci_linked_payload_fingerprint(replay,timeline)' in b
