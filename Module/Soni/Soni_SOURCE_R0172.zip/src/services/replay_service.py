from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import re
import numpy as np
from src.domain.models import SonicationModel
from src.parsers.ado_rowset import parse_ado_rowset
from src.services.raw_service import RawService
from src.services.treatment_spot_geometry_service import TreatmentSpotGeometryService

@dataclass(slots=True)
class ReplayFrameData:
    replay_index: int
    magnitude_index: int | None
    temperature_index: int | None
    magnitude: np.ndarray | None
    temperature: np.ndarray | None
    temperature_delta: np.ndarray | None
    hotspot_x: int | None = None
    hotspot_y: int | None = None
    maximum_temperature: float | None = None
    mean_temperature: float | None = None
    maximum_delta_temperature: float | None = None
    mean_delta_temperature: float | None = None
    temperature_source: str = "Unavailable"
    reference_temperature: float | None = None
    roi_source: str = "Default center ROI"
    roi_center_x: float | None = None
    roi_center_y: float | None = None
    roi_radius: float | None = None
    roi_width: float | None = None
    roi_height: float | None = None
    target_voxels: list[dict] = None

class ReplayService:
    """Decode thermometry into workstation-style absolute-temperature data.

    The RAW format is inferred conservatively:
    * plausible 15..100 C values => absolute temperature
    * values centered near zero => delta-temperature, converted with a 37 C
      reference until an ACT/protocol-derived reference becomes available.
    """
    def __init__(self):
        self.raw = RawService()
        self._baseline_cache: dict[str, np.ndarray] = {}
        self._mode_cache: dict[str, tuple[str, float]] = {}
        self._temperature_trend_cache: dict[str, dict] = {}
        self._mr_parameter_cache: dict[str, list[dict]] = {}
        self._thermometry_protocol_cache: dict[str, tuple[bool | None, str]] = {}
        self.spot_geometry = TreatmentSpotGeometryService()

    @staticmethod
    def _raw_identity(path: Path) -> tuple[int, int, int, int] | None:
        match=re.match(r"^(\d+)-(\d+)-(\d+)-(\d+)\.raw$",Path(path).name,re.I)
        return tuple(int(match.group(i)) for i in range(1,5)) if match else None

    def _mr_parameter_rows(self, son: SonicationModel) -> list[dict]:
        """Read the immutable study MriImageParams table once per workspace."""
        workspace=Path(son.folder).parent
        key=str(workspace.resolve())
        if key in self._mr_parameter_cache:
            return self._mr_parameter_cache[key]
        paths=[]
        for name in ("MriImageParams.xml","MRIImageParams.xml"):
            paths.extend(workspace.rglob(name))
        rows=[]
        if paths:
            try: rows=list(parse_ado_rowset(sorted(paths,key=lambda p:(len(p.parts),str(p).lower()))[0]))
            except Exception: rows=[]
        self._mr_parameter_cache[key]=rows
        return rows

    @staticmethod
    def _classify_thermometry_series(series: str) -> tuple[bool | None, str]:
        series=str(series or '').strip()
        upper=series.upper().replace('*','_STAR_')
        nonthermal=any(token in upper for token in (
            'T2_STAR','T2STAR','NFUSCAL','DQA-AXIAL','DQA-SAGITTAL','DQA-CORONAL',
            'MAGNITUDE','ANATOMY','SCOUT',
        ))
        thermal=any(token in upper for token in ('TMAP','MEMP','THERM','TEMPERATURE'))
        if nonthermal:
            return False,f'non-thermometry MR protocol {series}'
        if series and not thermal:
            return False,f'named MR series is not validated thermometry: {series}'
        if thermal:
            return True,f'validated thermometry protocol {series}'
        return None,'blank legacy MR protocol'

    def _mr_rows_for_raw_frame(self, son: SonicationModel, frame_path: Path) -> list[dict]:
        ident=self._raw_identity(frame_path)
        if ident is None:
            return []
        field,sonication,zone,array_index=ident
        matches=[]
        for row in self._mr_parameter_rows(son):
            try:
                if int(float(row.get('fieldindex',-1))) != field: continue
                if int(float(row.get('sonicationindex',-1))) != sonication: continue
                if row.get('zoneindex') not in (None,'') and int(float(row.get('zoneindex'))) != zone: continue
                if row.get('arrayindex') not in (None,'') and int(float(row.get('arrayindex'))) != array_index: continue
            except (TypeError,ValueError):
                continue
            matches.append(row)
        return matches

    def thermometry_frame_semantics(self, son: SonicationModel, frame_path: Path) -> dict:
        """Return exact per-RAW thermometry semantics without decoding pixel data.

        R0171: field prefix 5 is only a discovery candidate.  A Sonication may
        contain multiple MR semantics under the same numeric field family, so a
        first-frame-only protocol decision is not allowed to authorize every
        later array index.
        """
        ident=self._raw_identity(frame_path)
        matches=self._mr_rows_for_raw_frame(son,frame_path)
        if ident is None:
            decision,reason=None,'RAW identity unavailable'
        elif not matches:
            decision,reason=None,'no exact MriImageParams binding'
        else:
            names={str(r.get('seriesdiscription') or r.get('seriesdescription') or '').strip() for r in matches}
            names.discard('')
            series=' / '.join(sorted(names))
            decision,reason=self._classify_thermometry_series(series)
        row=matches[0] if len(matches)==1 else (matches[0] if matches else {})
        def sval(name):
            v=row.get(name) if isinstance(row,dict) else None
            return None if v in (None,'') else str(v)
        return {
            'identity': ident,
            'decision': decision,
            'reason': reason,
            'exact_match_count': len(matches),
            'series_description': sval('seriesdiscription') or sval('seriesdescription'),
            'series_uid': sval('seriesuid'),
            'echo_number': sval('echonum'),
            'echo_time': sval('echotimete'),
            'scan_time': sval('scantime'),
        }

    def _thermometry_protocol(self, son: SonicationModel) -> tuple[bool | None, str]:
        """Return protocol authority for the first candidate temperature RAW.

        Overall source-mode classification still uses the first candidate, but
        R0171 performs a second exact semantic check for *every* source frame in
        ``temperature_trend`` before accepting its pixels.
        """
        if not son.temperature_frames:
            return None,'no candidate temperature RAW'
        frame=son.temperature_frames[0]
        key=str(Path(frame.path).resolve())
        cached=self._thermometry_protocol_cache.get(key)
        if cached is not None:
            return cached
        sem=self.thermometry_frame_semantics(son,frame.path)
        result=(sem.get('decision'),str(sem.get('reason') or 'Unavailable'))
        self._thermometry_protocol_cache[key]=result
        return result

    def _baseline(self, son: SonicationModel) -> np.ndarray | None:
        if not son.temperature_frames:
            return None
        key = str(son.folder.resolve())
        if key not in self._baseline_cache:
            self._baseline_cache[key] = self.raw.read_temperature(son.temperature_frames[0].path)
        return self._baseline_cache[key]

    def _temperature_mode(self, son: SonicationModel) -> tuple[str, float]:
        key = str(son.folder.resolve())
        if key in self._mode_cache:
            return self._mode_cache[key]
        protocol_ok,_protocol_reason=self._thermometry_protocol(son)
        if protocol_ok is False:
            # Exact nonthermal metadata is authoritative; do not even decode the
            # raster as a temperature candidate.
            result=("Unavailable",37.0)
            self._mode_cache[key]=result
            return result
        baseline = self._baseline(son)
        if baseline is None:
            result = ("Unavailable", 37.0)
        else:
            finite = baseline[np.isfinite(baseline)]
            if not finite.size:
                result = ("Unavailable", 37.0)
            else:
                median = float(np.nanmedian(finite))
                p01, p99 = np.nanpercentile(finite, [1, 99])
                # FUS workstation thermometry typically starts around body temp.
                if 15.0 <= median <= 80.0 and -10.0 <= p01 and p99 <= 120.0:
                    result = ("Absolute RAW", median)
                # Delta thermometry must itself be temperature-like.  Real DQA
                # T2*/magnitude-like RAW can be float32-sized yet contain values
                # in the thousands; treating every non-absolute raster as delta C
                # produced impossible 11,000+ C displays.  Fail closed unless the
                # distribution is compatible with a temperature delta map.
                elif -20.0 <= median <= 20.0 and -60.0 <= p01 and p99 <= 100.0:
                    result = ("Delta RAW + 37.0 C reference", 37.0)
                else:
                    result = ("Unavailable", 37.0)
        self._mode_cache[key] = result
        return result

    def clear_cache(self) -> None:
        self._baseline_cache.clear()
        self._mode_cache.clear()
        self._temperature_trend_cache.clear()
        self._mr_parameter_cache.clear()
        self._thermometry_protocol_cache.clear()

    @staticmethod
    def _spatial_robust_peak(values: np.ndarray, roi: np.ndarray) -> float | None:
        """Return the hottest spatially coherent 3x3 median inside ``roi``.

        The former "median of hottest 3 pixels" could promote three unrelated
        hot/noisy pixels into a treatment peak.  Thermometry is spatial evidence:
        require a local neighbourhood instead of an unordered top-N statistic.
        Border neighbourhoods are clipped; at least four finite ROI samples are
        required so one isolated pixel cannot dominate the result.
        """
        arr=np.asarray(values,dtype=float)
        mask=np.asarray(roi,dtype=bool)
        if arr.ndim != 2 or mask.shape != arr.shape:
            return None
        finite=mask & np.isfinite(arr)
        if not np.any(finite):
            return None
        ys,xs=np.nonzero(finite)
        best=None
        for y,x in zip(ys.tolist(),xs.tolist()):
            y0=max(0,y-1); y1=min(arr.shape[0],y+2)
            x0=max(0,x-1); x1=min(arr.shape[1],x+2)
            local=arr[y0:y1,x0:x1]
            local_mask=finite[y0:y1,x0:x1]
            vals=local[local_mask]
            vals=vals[np.isfinite(vals)]
            if vals.size < 4:
                continue
            med=float(np.nanmedian(vals))
            if best is None or med > best:
                best=med
        if best is not None:
            return float(best)
        vals=arr[finite]
        return float(np.nanmedian(vals)) if vals.size else None

    def temperature_trend(self, son: SonicationModel) -> dict:
        """Decode only thermometry RAW and cache replay-aligned numerical trends.

        This path never reads magnitude MR and never creates UI images/thumbnails.
        It is therefore valid while the UI `Load images` switch is OFF.
        """
        key=str(son.folder.resolve())
        cached=self._temperature_trend_cache.get(key)
        if cached is not None:
            return cached
        count=max(1,int(getattr(son,"replay_frame_count",0) or 1))
        out={
            "max":np.full(count,np.nan,dtype=float),
            "robust_max":np.full(count,np.nan,dtype=float),
            "mean":np.full(count,np.nan,dtype=float),
            "delta":np.full(count,np.nan,dtype=float),
            "robust_delta":np.full(count,np.nan,dtype=float),
            "source":"Unavailable","reference_temp":None,"decoded_source_frames":0,
            "source_frame_semantics":[],
        }
        if not son.temperature_frames:
            self._temperature_trend_cache[key]=out
            return out
        try:
            source, reference_temp = self._temperature_mode(son)
            baseline = self._baseline(son)
        except Exception:
            self._temperature_trend_cache[key]=out
            return out
        if source == "Unavailable":
            out["source"]="Unavailable"; out["reference_temp"]=None
            self._temperature_trend_cache[key]=out
            return out
        source_max=[]; source_robust_max=[]; source_mean=[]; source_delta=[]; source_robust_delta=[]
        workspace=Path(son.folder).parent
        son_number=int(getattr(son,"sonication_number",0) or 0)
        exact_metadata_present=bool(self._mr_parameter_rows(son))
        for frame in son.temperature_frames:
            mx=rmx=mn=dmx=rdmx=np.nan
            sem=self.thermometry_frame_semantics(son,frame.path)
            frame_audit=dict(sem)
            frame_audit["raw_name"]=Path(frame.path).name
            frame_audit["accepted"]=False
            try:
                # When MriImageParams is present, each candidate RAW must bind
                # positively to a thermometry series.  Do not let the first TMAP
                # frame authorize a later nonthermal/unknown array index.
                if exact_metadata_present and sem.get("decision") is not True:
                    out["source_frame_semantics"].append(frame_audit)
                    source_max.append(mx); source_robust_max.append(rmx); source_mean.append(mn)
                    source_delta.append(dmx); source_robust_delta.append(rdmx)
                    continue
                raw_temp=self.raw.read_temperature(frame.path)
                if source == "Absolute RAW":
                    abs_temp=raw_temp
                    delta=(raw_temp-baseline) if baseline is not None and baseline.shape==raw_temp.shape else None
                elif source.startswith("Delta RAW"):
                    delta=raw_temp
                    abs_temp=raw_temp+reference_temp
                else:
                    abs_temp=None; delta=None
                projected=self.spot_geometry.projected_spots(workspace,son_number,frame.path,abs_temp.shape if abs_temp is not None else (delta.shape if delta is not None else (256,256)))
                primary=projected[0] if projected else None
                if primary is not None:
                    frame_audit["roi_center_x"]=float(primary.center_x)
                    frame_audit["roi_center_y"]=float(primary.center_y)
                    frame_audit["roi_width_px"]=float(primary.width_px)
                    frame_audit["roi_height_px"]=float(primary.height_px)
                else:
                    frame_audit["roi_center_x"]=None; frame_audit["roi_center_y"]=None
                if abs_temp is not None and np.isfinite(abs_temp).any():
                    roi=self.spot_geometry.mask_for_projected_spot(abs_temp.shape,primary)
                    vals=np.where(roi,abs_temp,np.nan)
                    if np.isfinite(vals).any():
                        finite_roi=np.sort(vals[np.isfinite(vals)])
                        mx=float(finite_roi[-1]); mn=float(np.nanmean(finite_roi))
                        robust=self._spatial_robust_peak(abs_temp,roi)
                        rmx=float(robust) if robust is not None else float(np.nanmedian(finite_roi))
                if delta is not None and np.isfinite(delta).any():
                    roi=self.spot_geometry.mask_for_projected_spot(delta.shape,primary)
                    vals=np.where(roi,delta,np.nan)
                    if np.isfinite(vals).any():
                        finite_delta=np.sort(vals[np.isfinite(vals)])
                        dmx=float(finite_delta[-1])
                        robust_delta=self._spatial_robust_peak(delta,roi)
                        rdmx=float(robust_delta) if robust_delta is not None else float(np.nanmedian(finite_delta))
                frame_audit["accepted"]=bool(np.isfinite(rmx) or np.isfinite(mn))
            except Exception as exc:
                frame_audit["decode_error"]=f"{type(exc).__name__}: {exc}"
            out["source_frame_semantics"].append(frame_audit)
            source_max.append(mx); source_robust_max.append(rmx); source_mean.append(mn)
            source_delta.append(dmx); source_robust_delta.append(rdmx)
        src_count=len(source_max)
        for replay_index in range(count):
            src_index=self.raw.normalize_index(replay_index,count,src_count)
            out["max"][replay_index]=source_max[src_index]
            out["robust_max"][replay_index]=source_robust_max[src_index]
            out["mean"][replay_index]=source_mean[src_index]
            out["delta"][replay_index]=source_delta[src_index]
            out["robust_delta"][replay_index]=source_robust_delta[src_index]
        out["source"]=source
        out["reference_temp"]=float(reference_temp)
        out["decoded_source_frames"]=int(sum(np.isfinite(source_max)))
        self._temperature_trend_cache[key]=out
        return out

    def temperature_frame_metrics(self, son: SonicationModel, index: int) -> dict:
        trend=self.temperature_trend(son)
        count=max(1,int(getattr(son,"replay_frame_count",0) or 1))
        i=max(0,min(int(index),count-1))
        def val(name):
            arr=np.asarray(trend.get(name,[]),float)
            return float(arr[i]) if i < arr.size and np.isfinite(arr[i]) else None
        return {
            "maximum_temperature":val("max"),
            "mean_temperature":val("mean"),
            "maximum_delta_temperature":val("delta"),
            "temperature_source":trend.get("source","Unavailable"),
            "reference_temperature":trend.get("reference_temp"),
        }

    def temperature_metrics(self, son: SonicationModel) -> dict:
        """Study-summary values from the cached thermometry-only trend."""
        trend=self.temperature_trend(son)
        maxima=np.asarray(trend.get("robust_max",trend.get("max",[])),float)
        means=np.asarray(trend.get("mean",[]),float)
        deltas=np.asarray(trend.get("robust_delta",trend.get("delta",[])),float)
        finite=maxima[np.isfinite(maxima)] if maxima.size else np.asarray([],float)
        out={"start_temp":None,"peak_temp":None,"delta_temp":None,
             "current_max":None,"current_avg":None,"frames":0,
             "source":str(trend.get("source","Unavailable"))+" · spatially coherent 3x3 median peak"}
        if finite.size:
            first_i=int(np.flatnonzero(np.isfinite(maxima))[0])
            last_i=int(np.flatnonzero(np.isfinite(maxima))[-1])
            out["start_temp"]=float(maxima[first_i])
            out["peak_temp"]=float(np.nanmax(maxima))
            finite_delta=deltas[np.isfinite(deltas)] if deltas.size else np.asarray([],float)
            out["delta_temp"]=float(np.nanmax(finite_delta)) if finite_delta.size else float(out["peak_temp"]-out["start_temp"])
            out["current_max"]=float(maxima[last_i])
            out["current_avg"]=float(means[last_i]) if last_i < means.size and np.isfinite(means[last_i]) else None
            out["frames"]=int(np.isfinite(maxima).sum())
        return out

    @staticmethod
    def _roi_geometry(shape: tuple[int, int]) -> tuple[float, float, float, float]:
        """Return the requested target-centred 3 x 3 pixel voxel.

        This ROI is deliberately expressed in pixels.  It does not pretend that
        pixel spacing has been decoded from the export metadata.
        """
        h, w = shape
        # Use a real pixel centre, not a half-pixel coordinate on even matrices.
        # This guarantees that the inclusive mask contains exactly 3 x 3 pixels.
        cy, cx = float(h // 2), float(w // 2)
        return cx, cy, 3.0, 3.0

    @classmethod
    def _roi_mask(cls, shape: tuple[int, int]) -> np.ndarray:
        h, w = shape
        cx, cy, width, height = cls._roi_geometry(shape)
        yy, xx = np.ogrid[:h, :w]
        half_w=max((width-1.0)/2.0,0.0); half_h=max((height-1.0)/2.0,0.0)
        return (np.abs(xx-cx)<=half_w) & (np.abs(yy-cy)<=half_h)

    def frame(self, son: SonicationModel, index: int, decode_images: bool = True, *,
              magnitude_override=None, temperature_override=None, disk_fallback: bool = True) -> ReplayFrameData:
        count = son.replay_frame_count
        index = max(0, min(index, count - 1))
        mag = raw_temp = abs_temp = delta = None
        mi = ti = None

        # R0116h: metadata-only replay path.  It intentionally performs no
        # magnitude/temperature RAW reads and does not probe the temperature
        # baseline.  Timeline, spectrum and non-image controls can therefore
        # remain responsive while image loading is disabled.
        if son.magnitude_frames:
            mi = self.raw.normalize_index(index, count, len(son.magnitude_frames))
        if son.temperature_frames:
            ti = self.raw.normalize_index(index, count, len(son.temperature_frames))
        if not decode_images:
            metrics=self.temperature_frame_metrics(son,index) if ti is not None else {}
            return ReplayFrameData(
                index, mi, ti, None, None, None, None, None,
                metrics.get("maximum_temperature"), metrics.get("mean_temperature"),
                metrics.get("maximum_delta_temperature"), None,
                metrics.get("temperature_source","Unavailable"), metrics.get("reference_temperature"),
                "Target center voxel, 3 x 3 pixels (numerical thermometry only; images disabled)"
            )

        source, reference_temp = self._temperature_mode(son)
        baseline = self._baseline(son)

        if mi is not None:
            if magnitude_override is not None:
                mag = np.asarray(magnitude_override, np.float32)
            elif disk_fallback:
                mag = self.raw.read_magnitude(son.magnitude_frames[mi].path)
        if ti is not None:
            if temperature_override is not None:
                raw_temp = np.asarray(temperature_override, np.float32)
            elif disk_fallback:
                raw_temp = self.raw.read_temperature(son.temperature_frames[ti].path)
            if raw_temp is not None and source == "Absolute RAW":
                abs_temp = raw_temp
                if baseline is not None and baseline.shape == raw_temp.shape:
                    delta = raw_temp - baseline
            elif raw_temp is not None and source.startswith("Delta RAW"):
                # A validated delta RAW is already relative to the scanner reference.
                delta = raw_temp
                abs_temp = raw_temp + reference_temp
            else:
                # Non-temperature DQA/T2* rasters are intentionally not coerced
                # into Celsius merely because they share the float32 container.
                abs_temp = None; delta = None

        hx = hy = None
        mx = mean = md = meand = None
        projected_targets=[]
        if ti is not None and (abs_temp is not None or delta is not None):
            try:
                shape=(abs_temp.shape if abs_temp is not None else delta.shape)
                projected_targets=self.spot_geometry.projected_spots(Path(son.folder).parent,int(getattr(son,"sonication_number",0) or 0),son.temperature_frames[ti].path,shape)
            except Exception:
                projected_targets=[]
        primary_target=projected_targets[0] if projected_targets else None
        if abs_temp is not None and np.isfinite(abs_temp).any():
            roi = self.spot_geometry.mask_for_projected_spot(abs_temp.shape,primary_target)
            roi_values = np.where(roi, abs_temp, np.nan)
            safe = np.nan_to_num(roi_values, nan=-np.inf)
            flat = int(np.argmax(safe))
            hy, hx = np.unravel_index(flat, abs_temp.shape)
            mx = float(np.nanmax(roi_values))
            mean = float(np.nanmean(roi_values))
        if delta is not None and np.isfinite(delta).any():
            roi = self.spot_geometry.mask_for_projected_spot(delta.shape,primary_target)
            roi_delta = np.where(roi, delta, np.nan)
            md = float(np.nanmax(roi_delta))
            meand = float(np.nanmean(roi_delta))

        roi_x = roi_y = roi_radius = roi_width = roi_height = None
        roi_shape = abs_temp.shape if abs_temp is not None else (delta.shape if delta is not None else None)
        if roi_shape is not None:
            if primary_target is not None:
                roi_x=float(primary_target.center_x); roi_y=float(primary_target.center_y)
                roi_width=float(primary_target.width_px); roi_height=float(primary_target.height_px)
            else:
                roi_x, roi_y, roi_width, roi_height = self._roi_geometry(roi_shape)
            roi_radius = max(roi_width, roi_height) / 2.0

        if ti is not None and abs_temp is None:
            metrics = self.temperature_frame_metrics(son, index)
            mx = metrics.get("maximum_temperature")
            mean = metrics.get("mean_temperature")
            md = metrics.get("maximum_delta_temperature")
            source = metrics.get("temperature_source", source)
            reference_temp = metrics.get("reference_temperature", reference_temp)

        return ReplayFrameData(
            index, mi, ti, mag, abs_temp, delta, hx, hy, mx, mean, md, meand,
            source, reference_temp, ("Target 1 physical SpotMesh footprint" if primary_target is not None else "Target center voxel, 3 x 3 pixels"),
            roi_x, roi_y, roi_radius, roi_width, roi_height,
            [dict(center_x=float(v.center_x),center_y=float(v.center_y),width_px=float(v.width_px),height_px=float(v.height_px),width_mm=float(v.width_mm),height_mm=float(v.height_mm),label=v.label,spotcue=v.spotcue) for v in projected_targets]
        )
