import sys,json,time
from pathlib import Path
sys.path.insert(0,'/mnt/data/zzy_audit')
from src.services.import_service import ImportService
from src.services.discovery_service import DiscoveryService
from src.services.replay_service import ReplayService
from src.services.hydrophone_replay_service import HydrophoneReplayService
from src.services.acoustic_control_service import AcousticControlService
from src.services.standalone_cavitation_service import StandaloneCavitationService
from src.services.canonical_cavitation_evidence_service import CanonicalCavitationEvidenceService
from src.services.sonication_summary_cavitation_evidence_service import SonicationSummaryCavitationEvidenceService
from src.services.cavitation_control_timeline_service import CavitationControlTimelineService
from src.services.cavitation_likelihood_service import CavitationLikelihoodService

src=Path(sys.argv[1]); out=Path(sys.argv[2])
t0=time.time(); imp=ImportService(); ws=imp.open(src); print('EXTRACT',time.time()-t0,ws,flush=True)
try:
    pkg=DiscoveryService().discover(src,ws); print('DISCOVERY',time.time()-t0,'sons',len(pkg.sonications),'cpc',len(pkg.cpc_spectrum_files),flush=True)
    replay_svc=ReplayService(); hydro=HydrophoneReplayService(); acoustic=AcousticControlService(); standalone=StandaloneCavitationService(); canon=CanonicalCavitationEvidenceService(); likelihood=CavitationLikelihoodService()
    evidence=SonicationSummaryCavitationEvidenceService(hydro,acoustic,standalone,canon,likelihood)
    ctl=CavitationControlTimelineService(); rows=[]
    for i,son in enumerate(pkg.sonications):
        s=time.time(); preferred=getattr(son,'canonical_acquisition_session_index',None)
        timeline=ctl.parse(Path(pkg.workspace),None,preferred,[],[],0.0,float(getattr(son,'mr_sonication_start_s',0.0) or 0),float(getattr(son,'mr_sonication_end_s',0.0) or 0),float(getattr(son,'mr_timeline_duration_s',0.0) or 0),None,None,0.010)
        payload=evidence.analyze(pkg,i,son,list(timeline.events or [])); c=payload['canonical']; tm=replay_svc.temperature_metrics(son)
        actual_e=getattr(son,'actual_energy_j',None); actual_p=getattr(son,'actual_power_w',None); actual_d=getattr(son,'actual_duration_s',None); planned_e=getattr(son,'planned_energy_j',None)
        measured=actual_e if actual_e is not None else ((actual_p*actual_d) if actual_p is not None and actual_d is not None else None)
        delivered=(100*measured/planned_e if measured is not None and planned_e and planned_e>0 else None)
        row=dict(sonication=i+1,name=getattr(son,'name',f'Sonication{i+1}'),actual_power_w=actual_p,planned_power_w=getattr(son,'planned_power_w',None),actual_duration_s=actual_d,planned_duration_s=getattr(son,'planned_duration_s',None),actual_energy_j=actual_e,planned_energy_j=planned_e,energy_delivered_pct_raw=delivered,start_temp_c=tm.get('start_temp'),peak_temp_c=tm.get('peak_temp'),delta_t_c=tm.get('delta_temp'),observed_control_cavitation_events=len(c.observed_events),vendor_rule_triggers=len(c.vendor_rule_events),dump_candidates=len(c.candidate_events),canonical_detected=c.detected,canonical_status=c.status,vendor_exceedance_severity=c.vendor_exceedance_severity,probable_centroid_xy=(list(payload['likelihood'].centroid_xy) if payload.get('likelihood') is not None and getattr(payload['likelihood'],'centroid_xy',None) is not None else None),spectrum_frames=(len(payload['replay'].frames) if payload.get('replay') is not None else 0),elapsed_s=time.time()-s)
        rows.append(row); print(json.dumps(row,ensure_ascii=False),flush=True)
        out.write_text(json.dumps({'source':str(src),'sonication_count':len(pkg.sonications),'rows':rows,'elapsed_s':time.time()-t0},indent=2,ensure_ascii=False),encoding='utf-8')
    print('DONE',time.time()-t0,flush=True)
finally:
    imp.release(ws)
