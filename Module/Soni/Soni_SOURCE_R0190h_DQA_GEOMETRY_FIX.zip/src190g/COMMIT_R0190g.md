# R0190g
- DQA: when exact same-raster magnitude pairing is absent but registered DQA phantom geometry and validated thermal focus exist, calculate X/Y/Z in common MR-RAS using robust reference-stack medians instead of returning N/A.
- X = Axial focus R - Axial phantom R centre.
- Y = Sagittal focus A - Sagittal phantom A centre.
- Z = Sagittal focus S - (Sagittal lower line S + 20 mm).
- Chart double-click is hard reset-only: removed callback API, overrides ViewBox double-click, viewport/scene routes reset only, dormant replay chart popup opener removed.
