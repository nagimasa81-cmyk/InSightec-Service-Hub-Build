# TRIPLE CHECK R0190a

1. Compile: `python -m compileall -q src tests` PASS.
2. Focused DQA canonical-pair + R0190 exact-pair/mask + R0188 same-raster tests: 13/13 PASS, repeated 5 consecutive runs.
3. Static semantic audit: DQA production pairing requires exact canonical acquisition identity and geometry; adjacent-frame +/-1 matching removed.
4. Real diagnostic evidence reviewed: app RC7.10-R0190, 5 sonications, valid MEMP thermometry present; diagnostic ZIP intentionally contains no MR payload, so pixel-level DQA recomputation cannot be executed from diagnostics alone.
5. PySide6 is unavailable in this Linux validation environment; Qt collection remains environment-limited rather than treated as a product failure.
