# R0190f

## Chart double-click contract correction
- Restored the intended global chart interaction: **double-left-click resets the chart display/zoom**.
- Removed R0190b-R0190d double-click popup/enlarge wiring from Replay, generic analysis charts, and CPC Spectrum / 8CH Hydrophone Analyzer charts.
- Removed the generic `open_enlarged_plot` fallback so it cannot be accidentally rebound to double-click.
- Kept bottom-X-axis drag range zoom unchanged.
- Hydrophone/analyzer reset continues to clear manual-view overrides after auto-ranging.
- Reinstalling the common chart interaction now actively clears any stale double-click callback by assigning `None`; this closes the ancestor-handler retention path introduced by the prior idempotence guard.

## DQA
- R0190e simple-axis DQA contract is unchanged: X from Axial phantom LR center, Y from Sagittal phantom AP center, Z/Tilt unchanged.

## Release identity
- Corrected all build/release identity surfaces to RC7.10-R0190f (VERSION, version.json, constants, build contract, Nuitka BAT descriptions). This also prevents the earlier source/build letter mismatch.
