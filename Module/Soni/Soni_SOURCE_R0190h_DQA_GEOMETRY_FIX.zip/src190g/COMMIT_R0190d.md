# R0190d

- DQA: R0190c diagnostics proved the observed-focus fallback was active for this 4267 export. Preserve the actual thermal hotspot score instead of hard-coding 0.0.
- DQA: electronically steered shots are excluded per-sonication; one steered DQA shot no longer suppresses judgement of otherwise stable default-centre DQA shots.
- Chart double click: install both viewport and pyqtgraph scene double-click routes behind one 300 ms debounced dispatcher. This fixes Windows/pyqtgraph paths where the viewport event is consumed before the prior handler sees it.
- Existing X-axis drag zoom and synchronized Replay chart popup paths are preserved.
