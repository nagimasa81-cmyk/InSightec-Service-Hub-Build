# R0190e

DQA axis contract simplification requested from field validation.

- X: Axial image only; observed focus LR position minus phantom LR centre.
- Y: Sagittal image only; observed focus AP position minus sagittal phantom AP centre.
- Z: unchanged; sagittal lower phantom line +20 mm reference.
- Tilt: unchanged.
- Y is no longer inherited from the Axial circle-centre calculation.
- Sagittal AP centre is the midpoint of the detected phantom/body physical A/P extent in MR-RAS.
