# TRIPLE CHECK R0190g
1. Source compile: PASS (chart_interaction.py, main_window.py, dqa_focus_alignment_service.py).
2. New regression contract: 2/2 PASS.
3. Diagnostic root cause: R0190f diagnostics contained valid observed Axial/Sagittal thermal focus and valid phantom reference-stack geometry, but exact-pair gating forced DQA display to N/A. R0190g resolves this with registered-stack median geometry fallback.
4. Chart root cause hardening: callback-capable double-click API removed; ViewBox owns reset; viewport and scene routes also reset; dormant replay chart popup opener removed.
5. Version/build metadata: RC7.10-R0190g.
