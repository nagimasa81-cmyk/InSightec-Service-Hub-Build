# TRIPLE CHECK R0190b

- Replay chart double-click contract restored to synchronized enlarged ChartPopup.
- Temperature / Spectrum / Power-Score / Waterfall all enter through `_chart_panel`, so the behavior is common rather than four duplicated handlers.
- Generic non-Replay charts retain R0131 double-click reset behavior.
- Bottom-X-axis drag range zoom remains intact.
- Installation guard prevents both handlers being installed on one Replay plot.
- Focused R0190/R0190a/R0190b + R0131 suite: 25/25 PASS, repeated 3 times.
- `compileall`: PASS.
- `verify_source.py`: VERIFY_SOURCE_OK.
