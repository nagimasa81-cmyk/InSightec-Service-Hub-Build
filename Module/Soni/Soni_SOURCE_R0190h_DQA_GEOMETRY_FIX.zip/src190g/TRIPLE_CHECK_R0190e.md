# R0190e focused verification

1. Static contract test confirms X is assigned only from Axial and Y only from Sagittal AP centre. PASS.
2. Static contract test confirms Z remains lower-line +20.0 mm and direct RAS Z delta. PASS.
3. Focused DQA regression suite: 16 passed.
4. Python compileall: PASS.
5. Full pytest collection cannot complete in this Linux validation container because PySide6 is not installed; failure occurs during GUI-test collection, not in R0190e code.
