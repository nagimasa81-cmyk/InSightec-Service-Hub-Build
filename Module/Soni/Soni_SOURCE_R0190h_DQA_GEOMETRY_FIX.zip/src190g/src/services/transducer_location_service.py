from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
import math
import re


_CLOCK_RE = re.compile(r"(?P<h>\d{2}):(?P<m>\d{2}):(?P<s>\d{2}):(?P<ms>\d{3})")
_FLOAT = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"
_XD_RE = re.compile(
    rf"Xd\s*loc\s*XYZ\s*:\s*\(?\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*\)?"
    rf"(?:\s*,?\s*roll\s*:\s*({_FLOAT}))?"
    rf"(?:\s*,?\s*pitch\s*:\s*({_FLOAT}))?"
    rf"(?:\s*,?\s*Steering\s*:\s*\(?\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*[, ]+\s*({_FLOAT})\s*\)?)?",
    re.I,
)
_TRACKER_XD_RE = re.compile(
    rf"New\s+XD\s+pos\.\s+in\s+CSA\s+coords\.\s+according\s+to\s+trackers\s*-\s*"
    rf"X\s*:\s*({_FLOAT})\s*,\s*Y\s*:\s*({_FLOAT})\s*,\s*Z\s*:\s*({_FLOAT})"
    rf"(?:\s*,\s*Roll\s*:\s*({_FLOAT}))?(?:\s*,\s*Pitch\s*:\s*({_FLOAT}))?",
    re.I,
)
_TRACKER_PQR_RE = re.compile(
    rf"tracker\s+(\d+)\s+coordinates\s*:\s*PQR\s*:\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)"
    rf"(?:\s*-\s*iniPQR\s*:\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\))?",
    re.I,
)
_TRACKER_POS_RE = re.compile(
    rf"Found\s+TrackerPos\s+(\d+)\s*is\s*:\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)", re.I
)
_TILT_RE = re.compile(rf"Transducer\s+tilt\s*:\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)", re.I)
_RELIABILITY_RE = re.compile(r"TRACKERS\s+SELECTION\s*:\s*Xd\s+location\s+was\s+decoded\s+from\s+the\s+trackers\s+with\s+([^\r\n(]+)", re.I)
_RELIABILITY_CODE_RE = re.compile(r"CalculateXdPosition\s+return\s+([A-Z0-9_]+)", re.I)
_HOME_RE = re.compile(
    rf"Home\s+position\s+read.*?UVW\s*=\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)", re.I
)
_HOME_POSE_RE = re.compile(
    rf"Home\s+position\s+read.*?UVW\s*=\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)"
    rf".*?Transducer\s+Direction\s*:\s*UVW\s*=\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)", re.I
)
_NEW_HOME_POSE_RE = re.compile(
    rf"New\s+home\s+position\s*:\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)"
    rf".*?New\s+XD\s+tilt\s*:\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)", re.I
)
_FOCAL_DISPLAY_RE = re.compile(
    rf"focal\s+position\s*:\s*([LR])\s*({_FLOAT})\s+([AP])\s*({_FLOAT})\s+([SI])\s*({_FLOAT})", re.I
)
_SET_HOME_RE = re.compile(
    rf"Set\s+new\s+home\s+position\s*:\s*orig\s*:\s*({_FLOAT})\s+({_FLOAT})\s+({_FLOAT})", re.I
)
_PROTOCOL_RE = re.compile(r"protocol\s+data\s*-\s*name\s*:\s*([^,\r\n]+)", re.I)
_START_RE = re.compile(r"\[CGeneralSonicationLogic::StartSonicate\]\s*Sonication Counter\s*:\s*(\d+)", re.I)
_START_STEERING_RE = re.compile(rf"Steering\s*:\s*({_FLOAT})\s+({_FLOAT})\s+({_FLOAT})", re.I)
_POS_RE = re.compile(rf"\bPos\s*=\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})", re.I)
_CP_FOCAL_RE = re.compile(rf"cpFocalPointUVW\s*:\s*\(\s*({_FLOAT})\s*,\s*({_FLOAT})\s*,\s*({_FLOAT})\s*\)", re.I)
# R0174: an ordinary 'Xd loc XYZ' state report is NOT itself a Locate Transducer
# event.  Only explicit operator/workflow phrases may open an association window.
_LOCATE_EVENT_RE = re.compile(
    r"(?:\blocate\s+transducer\b|\btransducer\s+locat(?:e|ion|ing)\b|"
    r"\blocat(?:e|ing)\s+(?:the\s+)?xd\b|\bxd\s+transducer\s+locat(?:e|ion|ing)\b)",
    re.I,
)
# R0175 diagnostics-only discovery signature.  This deliberately does NOT
# promote a row to a confirmed location result.  It exists solely to reveal
# the workstation's real vendor wording in the next diagnostic package.
_LOCATE_DISCOVERY_RE = re.compile(
    r"(?:\btransducer\b|\blocali[sz](?:e|ed|ing|ation)\b|\blocat(?:e|ed|ing|ion)\b|"
    r"\bregistration\b|\bposition(?:ing)?\b|\bpose\b|\bdetector\b|\bxd\s*loc\b)",
    re.I,
)
_FILE_DATE_RE = re.compile(r"(?P<year>20\d{2})[_-](?P<mon>[A-Za-z]{3}|\d{1,2})[_-](?P<day>\d{1,2})", re.I)
_MONTHS = {m.lower(): i for i, m in enumerate(("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"), 1)}


@dataclass(slots=True)
class TransducerLocationRecord:
    timestamp: datetime | None
    clock_s: float
    x: float
    y: float
    z: float
    roll: float | None
    pitch: float | None
    steering_x: float | None
    steering_y: float | None
    steering_z: float | None
    source: Path
    line_number: int
    trigger: str = "Locate Transducer"
    related_sonication: int | None = None
    related_delta_s: float | None = None
    delta_x: float = 0.0
    delta_y: float = 0.0
    delta_z: float = 0.0
    displacement: float = 0.0
    locate_event_line: int | None = None
    locate_event_clock_s: float | None = None
    locate_event_text: str | None = None
    coordinate_frame: str = "CSA"
    reliability: str | None = None
    reliability_code: str | None = None
    tilt_xyz: tuple[float, float, float] | None = None
    tracker_pqr: dict[int, tuple[float, float, float]] | None = None
    tracker_ini_pqr: dict[int, tuple[float, float, float]] | None = None
    tracker_uvw: dict[int, tuple[float, float, float]] | None = None
    home_uvw: tuple[float, float, float] | None = None
    protocol_name: str | None = None
    patient_target_xyz: tuple[float, float, float] | None = None
    patient_transducer_xyz: tuple[float, float, float] | None = None
    patient_delta_xyz: tuple[float, float, float] | None = None
    patient_axis_pass: tuple[bool, bool, bool] | None = None
    patient_alignment_pass: bool | None = None
    patient_alignment_threshold_mm: float = 1.0
    localization_kind: str = "unclassified"
    startsonicate_delta_s: float | None = None




@dataclass(slots=True)
class PhysicalTransducerPoseRecord:
    timestamp: datetime | None
    clock_s: float
    home_xyz: tuple[float, float, float]
    direction_xyz: tuple[float, float, float]
    natural_focus_xyz: tuple[float, float, float] | None
    direct_focal_xyz: tuple[float, float, float] | None
    focal_distance_mm: float | None
    source: Path
    line_number: int
    event_kind: str
    reliability: str | None = None
    delta_home_xyz: tuple[float, float, float] | None = None
    home_displacement_mm: float | None = None
    delta_focus_xyz: tuple[float, float, float] | None = None
    focus_displacement_mm: float | None = None
    focal_validation_error_mm: float | None = None


@dataclass(slots=True)
class PatientAlignmentWorkflowRow:
    """Clinical Patient-treatment alignment timeline.

    A comparison row may reuse the most recent Locate Transducer result: entering
    the target does not itself re-run localization.
    """
    stage: str
    sequence: int
    timestamp: datetime | None
    clock_s: float | None
    target_xyz: tuple[float, float, float] | None
    transducer_xyz: tuple[float, float, float] | None
    delta_xyz: tuple[float, float, float] | None
    axis_pass: tuple[bool, bool, bool] | None
    overall_pass: bool | None
    source_record: TransducerLocationRecord | None
    note: str
    target_epoch: int | None = None
    change_mode: str = "Physical alignment"
    steering_xyz: tuple[float, float, float] | None = None
    steering_delta_xyz: tuple[float, float, float] | None = None
    effective_target_xyz: tuple[float, float, float] | None = None
    sonication_number: int | None = None
    protocol_name: str | None = None
    source_path: Path | None = None
    source_line: int | None = None


@dataclass(slots=True)
class LocateFocalRecord:
    timestamp: datetime | None
    clock_s: float
    focal_xyz: tuple[float,float,float]
    target_xyz: tuple[float,float,float] | None
    protocol_name: str | None
    source: Path
    line_number: int
    event_kind: str = "Locate Transducer"


@dataclass(slots=True)
class SonicationSteeringEvent:
    timestamp: datetime | None
    clock_s: float
    sonication_number: int
    steering_xyz: tuple[float, float, float]
    source: Path
    line_number: int


@dataclass(slots=True)
class LocateTransducerEvidence:
    source: Path
    line_number: int
    clock_s: float | None
    text: str
    context: tuple[str, ...]
    evidence_kind: str = "explicit-locate"


class TransducerLocationService:
    """Extract *confirmed/associated* Locate Transducer position results.

    Workstation logs also emit recurring ``Xd loc XYZ`` state lines during normal
    operation.  R0173 incorrectly presented every one of those rows as a physical
    location history.  R0174 keeps those raw reports as diagnostic evidence only
    and publishes a location record only when an explicit Locate Transducer
    workflow/event precedes the report inside a bounded time window.

    ``Steering XYZ`` remains a separate electronic-steering field; it is never
    substituted for physical X/Y/Z.
    """

    LOCATE_ASSOCIATION_WINDOW_S = 30.0
    LOCATE_ASSOCIATION_MAX_LINES = 120

    @staticmethod
    def _clock_s(line: str) -> float | None:
        m = _CLOCK_RE.search(line)
        if not m:
            return None
        return (int(m.group("h"))*3600.0 + int(m.group("m"))*60.0 + int(m.group("s")) + int(m.group("ms"))/1000.0)

    @staticmethod
    def _date_from_name(path: Path) -> datetime | None:
        m = _FILE_DATE_RE.search(path.name)
        if not m:
            return None
        mon_raw=m.group("mon")
        try:
            mon=int(mon_raw) if mon_raw.isdigit() else _MONTHS[mon_raw.lower()]
            return datetime(int(m.group("year")), mon, int(m.group("day")))
        except Exception:
            return None

    @staticmethod
    def _candidate_logs(workspace: Path) -> list[Path]:
        logs=[]
        for pattern in ("*.Log", "*.log"):
            logs.extend(Path(workspace).rglob(pattern))
        return sorted(set(logs), key=lambda p: (0 if "wsfiles" in str(p.parent).lower() else 1, len(p.parts), str(p).lower()))

    @staticmethod
    def _is_nonzero_location(x: float, y: float, z: float) -> bool:
        # (0,0,0) is common as an unpopulated/default state in real exports.  It
        # must never become the displacement baseline without an independently
        # confirmed Locate workflow result.
        return bool(abs(float(x)) > 1e-9 or abs(float(y)) > 1e-9 or abs(float(z)) > 1e-9)

    def locate_evidence(self, workspace: Path, context_radius: int = 5) -> list[LocateTransducerEvidence]:
        """Return explicit Locate/Transducer workflow lines plus nearby raw context.

        This is intentionally diagnostic evidence, not a location parser.  It lets
        the next real export reveal the workstation's exact success/result wording
        without hard-coding an unobserved vendor signature.
        """
        out=[]
        seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            for i,line in enumerate(lines):
                if not _LOCATE_EVENT_RE.search(line):
                    continue
                key=(str(path.resolve()), i)
                if key in seen:
                    continue
                seen.add(key)
                lo=max(0,i-int(context_radius)); hi=min(len(lines),i+int(context_radius)+1)
                out.append(LocateTransducerEvidence(
                    source=path, line_number=i+1, clock_s=self._clock_s(line), text=line.strip(),
                    context=tuple(lines[lo:hi]),
                ))
        return out


    def discovery_evidence(self, workspace: Path, context_radius: int = 5, max_rows: int = 300) -> list[LocateTransducerEvidence]:
        """Return broad transducer/localization workflow evidence for diagnostics only.

        R0174 proved that the real workstation export does not necessarily spell
        the operation ``Locate Transducer``.  This intentionally broad scan is
        never used by :meth:`parse`; it only serializes small, bounded snippets
        so the vendor's actual success/result wording can be learned from a real
        export without guessing.
        """
        out=[]; seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            for i,line in enumerate(lines):
                if not _LOCATE_DISCOVERY_RE.search(line):
                    continue
                key=(str(path.resolve()),i)
                if key in seen:
                    continue
                seen.add(key)
                lo=max(0,i-int(context_radius)); hi=min(len(lines),i+int(context_radius)+1)
                kind=("explicit-locate" if _LOCATE_EVENT_RE.search(line) else
                      "xd-state-report" if _XD_RE.search(line) else "broad-workflow-candidate")
                out.append(LocateTransducerEvidence(
                    source=path,line_number=i+1,clock_s=self._clock_s(line),text=line.strip(),
                    context=tuple(lines[lo:hi]),evidence_kind=kind,
                ))
                if len(out) >= int(max_rows):
                    return out
        return out

    def raw_xd_context_samples(self, workspace: Path, context_radius: int = 4, max_rows: int = 24) -> list[LocateTransducerEvidence]:
        """Return bounded first/middle/last Xd-report contexts for diagnostics."""
        candidates=[]
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            hits=[i for i,line in enumerate(lines) if _XD_RE.search(line)]
            if not hits:
                continue
            # Preserve boundary and evenly-spaced evidence without dumping the log.
            if len(hits) <= max_rows:
                chosen=hits
            else:
                step=(len(hits)-1)/float(max_rows-1)
                chosen=sorted({hits[int(round(k*step))] for k in range(max_rows)})
            for i in chosen:
                lo=max(0,i-int(context_radius)); hi=min(len(lines),i+int(context_radius)+1)
                candidates.append(LocateTransducerEvidence(
                    source=path,line_number=i+1,clock_s=self._clock_s(lines[i]),text=lines[i].strip(),
                    context=tuple(lines[lo:hi]),evidence_kind="xd-context-sample",
                ))
                if len(candidates) >= int(max_rows):
                    return candidates
        return candidates

    def raw_xd_reports(self, workspace: Path) -> list[TransducerLocationRecord]:
        """Return all recurring Xd state reports for diagnostics only."""
        records=[]; seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            base_date=self._date_from_name(path)
            starts=[]
            for i,line in enumerate(lines):
                sm=_START_RE.search(line); cs=self._clock_s(line)
                if sm and cs is not None:
                    starts.append((cs, int(sm.group(1))+1, i))
            locate_events=[]
            for i,line in enumerate(lines):
                if _LOCATE_EVENT_RE.search(line):
                    locate_events.append((self._clock_s(line), i, line.strip()))
            for i,line in enumerate(lines):
                m=_XD_RE.search(line)
                if not m:
                    continue
                cs=self._clock_s(line)
                if cs is None:
                    continue
                vals=[float(m.group(j)) if m.group(j) is not None else None for j in range(1,9)]
                x,y,z=vals[:3]
                key=(round(cs,3), round(x,6), round(y,6), round(z,6), str(path.resolve()), i)
                if key in seen:
                    continue
                seen.add(key)
                timestamp=(base_date + timedelta(seconds=cs)) if base_date is not None else None
                assoc=None
                # Causal association only: an explicit Locate event must precede
                # the Xd report.  A later event cannot retroactively label it.
                candidates=[]
                for ev_cs, ev_i, ev_text in locate_events:
                    if ev_i >= i or i-ev_i > self.LOCATE_ASSOCIATION_MAX_LINES:
                        continue
                    if ev_cs is not None:
                        dt=cs-ev_cs
                        if dt < 0 or dt > self.LOCATE_ASSOCIATION_WINDOW_S:
                            continue
                    else:
                        dt=None
                    candidates.append((ev_i, ev_cs, ev_text, dt))
                if candidates:
                    assoc=max(candidates,key=lambda q:q[0])
                related=None; related_delta=None
                if starts:
                    best=min(starts, key=lambda row: abs(row[0]-cs)); delta=best[0]-cs
                    if abs(delta) <= 180.0:
                        related=best[1]; related_delta=float(delta)
                records.append(TransducerLocationRecord(
                    timestamp=timestamp, clock_s=float(cs), x=float(x), y=float(y), z=float(z),
                    roll=vals[3], pitch=vals[4], steering_x=vals[5], steering_y=vals[6], steering_z=vals[7],
                    source=path, line_number=i+1,
                    trigger="Locate Transducer" if assoc is not None else "XD state report",
                    related_sonication=related, related_delta_s=related_delta,
                    locate_event_line=(assoc[0]+1 if assoc is not None else None),
                    locate_event_clock_s=(assoc[1] if assoc is not None else None),
                    locate_event_text=(assoc[2] if assoc is not None else None),
                ))
        records.sort(key=lambda r: ((r.timestamp or datetime.min), r.clock_s, str(r.source).lower(), r.line_number))
        return records

    @staticmethod
    def _display_focal_to_uvw(groups) -> tuple[float,float,float] | None:
        """Convert workstation anatomical labels to the same UVW sign convention
        observed for Home position display: +U=L, -U=R, -V=A, +V=P, +W=S, -W=I.
        """
        try:
            lr,x,ap,y,si,z=groups
            xv=float(x) * (1.0 if str(lr).upper()=="L" else -1.0)
            yv=float(y) * (-1.0 if str(ap).upper()=="A" else 1.0)
            zv=float(z) * (1.0 if str(si).upper()=="S" else -1.0)
            return (xv,yv,zv)
        except Exception:
            return None

    def physical_pose_history(self, workspace: Path) -> list[PhysicalTransducerPoseRecord]:
        """Authoritative physical transducer-pose history.

        Unlike ``New XD pos...`` residuals, the vendor lines
        ``Home position read ... Transducer Direction`` and
        ``New home position ... New XD tilt`` carry absolute pose evidence.

        Natural focus is reconstructed along the unit transducer direction.  The
        focal distance is inferred from a nearby direct ``focal position`` display
        when available.  If one pose in the workspace proves the distance, its
        robust median is reused for other poses.  Only when no direct focus exists
        do we fall back to 150 mm, and that fallback is explicitly tagged by a
        missing validation error rather than pretending it was measured.
        """
        raw=[]
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8",errors="replace").splitlines()
            except OSError:
                continue
            base_date=self._date_from_name(path)
            focals=[]
            for i,line in enumerate(lines):
                fm=_FOCAL_DISPLAY_RE.search(line)
                if fm:
                    xyz=self._display_focal_to_uvw(fm.groups())
                    cs=self._clock_s(line)
                    if xyz is not None and cs is not None:
                        focals.append((i,cs,xyz))
            # Reliability is useful evidence for tracker-updated poses.
            reliability_rows=[]
            for i,line in enumerate(lines):
                rm=_RELIABILITY_RE.search(line)
                if rm:
                    reliability_rows.append((i,rm.group(1).strip().rstrip(" .")))
            for i,line in enumerate(lines):
                kind=None; home=None; direction=None
                hm=_HOME_POSE_RE.search(line)
                if hm:
                    home=tuple(float(hm.group(k)) for k in range(1,4))
                    direction=tuple(float(hm.group(k)) for k in range(4,7))
                    kind="initial-home"
                nm=_NEW_HOME_POSE_RE.search(line)
                if nm:
                    home=tuple(float(nm.group(k)) for k in range(1,4))
                    direction=tuple(float(nm.group(k)) for k in range(4,7))
                    kind="tracker-updated-home"
                if kind is None or home is None or direction is None:
                    continue
                cs=self._clock_s(line)
                if cs is None:
                    continue
                norm=math.sqrt(sum(v*v for v in direction))
                if norm <= 0:
                    continue
                unit=tuple(v/norm for v in direction)
                # nearby focal display, preferentially after the pose update
                near=[q for q in focals if abs(q[1]-cs) <= 2.0]
                direct=None; inferred_dist=None; validation_error=None
                if near:
                    q=min(near,key=lambda q:(0 if q[1]>=cs else 1,abs(q[1]-cs)))
                    direct=q[2]
                    vec=tuple(direct[k]-home[k] for k in range(3))
                    inferred_dist=sum(vec[k]*unit[k] for k in range(3))
                    proj=tuple(home[k]+inferred_dist*unit[k] for k in range(3))
                    validation_error=math.sqrt(sum((direct[k]-proj[k])**2 for k in range(3)))
                    if not (50.0 <= inferred_dist <= 250.0):
                        inferred_dist=None
                rel=None
                prev_rel=[r for r in reliability_rows if r[0] <= i]
                if prev_rel and i-prev_rel[-1][0] <= 80:
                    rel=prev_rel[-1][1]
                ts=(base_date+timedelta(seconds=cs)) if base_date is not None else None
                raw.append({
                    "timestamp":ts,"clock_s":float(cs),"home":home,"direction":unit,
                    "direct":direct,"inferred":inferred_dist,"validation":validation_error,
                    "source":path,"line":i+1,"kind":kind,"reliability":rel,
                })
        raw.sort(key=lambda q:((q["timestamp"] or datetime.min),q["clock_s"],str(q["source"]).lower(),q["line"]))
        proven=[float(q["inferred"]) for q in raw if q["inferred"] is not None and (q["validation"] is None or q["validation"] <= 1.0)]
        focal_distance=(sorted(proven)[len(proven)//2] if proven else 150.0)
        out=[]
        prev=None
        for q in raw:
            dist=float(q["inferred"]) if q["inferred"] is not None else float(focal_distance)
            focus=tuple(q["home"][k]+dist*q["direction"][k] for k in range(3))
            rec=PhysicalTransducerPoseRecord(
                timestamp=q["timestamp"],clock_s=q["clock_s"],home_xyz=q["home"],
                direction_xyz=q["direction"],natural_focus_xyz=focus,direct_focal_xyz=q["direct"],
                focal_distance_mm=dist,source=q["source"],line_number=q["line"],event_kind=q["kind"],
                reliability=q["reliability"],focal_validation_error_mm=q["validation"],
            )
            if prev is not None:
                dh=tuple(rec.home_xyz[k]-prev.home_xyz[k] for k in range(3))
                rec.delta_home_xyz=dh
                rec.home_displacement_mm=math.sqrt(sum(v*v for v in dh))
                if rec.natural_focus_xyz is not None and prev.natural_focus_xyz is not None:
                    df=tuple(rec.natural_focus_xyz[k]-prev.natural_focus_xyz[k] for k in range(3))
                    rec.delta_focus_xyz=df
                    rec.focus_displacement_mm=math.sqrt(sum(v*v for v in df))
            out.append(rec); prev=rec
        return out

    def _tracker_localizations(self, workspace: Path) -> list[TransducerLocationRecord]:
        """Parse authoritative tracker-derived transducer positions.

        The real workstation export emits recurring ``Xd loc XYZ`` rows that can
        remain (0,0,0).  The vendor result line below is semantically different:
        ``New XD pos. in CSA coords. according to trackers`` is emitted by the
        tracker localization path after TRACKERS SELECTION / CalculateXdPosition.
        R0177 treats that result as the tracker-vs-calibrated-XD residual in CSA. For Patient treatment, the latest preceding calibrated/home target is combined with this residual to reconstruct the tracker-derived transducer XYZ. DQA remains excluded from this Patient alignment judgement.
        """
        records=[]; seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            base_date=self._date_from_name(path)
            starts=[]
            for i,line in enumerate(lines):
                sm=_START_RE.search(line); cs=self._clock_s(line)
                if sm and cs is not None:
                    starts.append((cs, int(sm.group(1))+1, i))
            # Home UVW is state that can be updated. Bind each localization to
            # the latest preceding value rather than one global first value.
            homes=[]
            for i,line in enumerate(lines):
                hm=_HOME_RE.search(line)
                if hm:
                    homes.append((i,(float(hm.group(1)),float(hm.group(2)),float(hm.group(3)))))
            target_refs=[]
            for i,line in enumerate(lines):
                hm2=_HOME_RE.search(line)
                if hm2:
                    target_refs.append((i,self._clock_s(line),(float(hm2.group(1)),float(hm2.group(2)),float(hm2.group(3))),"home-read"))
                tm=_SET_HOME_RE.search(line)
                if tm:
                    target_refs.append((i,self._clock_s(line),(float(tm.group(1)),float(tm.group(2)),float(tm.group(3))),"set-home"))
            protocols=[]
            for i,line in enumerate(lines):
                pm=_PROTOCOL_RE.search(line)
                if pm:
                    protocols.append((i, pm.group(1).strip()))
            for i,line in enumerate(lines):
                m=_TRACKER_XD_RE.search(line)
                if not m:
                    continue
                cs=self._clock_s(line)
                if cs is None:
                    continue
                x,y,z=(float(m.group(1)),float(m.group(2)),float(m.group(3)))
                roll=float(m.group(4)) if m.group(4) is not None else None
                pitch=float(m.group(5)) if m.group(5) is not None else None
                key=(str(path.resolve()),i,round(x,9),round(y,9),round(z,9))
                if key in seen:
                    continue
                seen.add(key)

                # Same localization block is compact in observed WS logs. Use a
                # bounded causal look-back and never cross the previous authoritative
                # tracker-localization result, otherwise tracker/reliability evidence
                # from two consecutive localizations could be merged.
                previous_result=-1
                for j in range(i-1, max(-1,i-400), -1):
                    if _TRACKER_XD_RE.search(lines[j]):
                        previous_result=j
                        break
                lo=max(previous_result+1, i-160, 0)
                block=lines[lo:i+1]
                pqr={}; ini_pqr={}; uvw={}; tilt=None; reliability=None; reliability_code=None
                for rel,ctx in enumerate(block):
                    pm=_TRACKER_PQR_RE.search(ctx)
                    if pm:
                        idx=int(pm.group(1)); pqr[idx]=(float(pm.group(2)),float(pm.group(3)),float(pm.group(4)))
                        if pm.group(5) is not None:
                            ini_pqr[idx]=(float(pm.group(5)),float(pm.group(6)),float(pm.group(7)))
                    fm=_TRACKER_POS_RE.search(ctx)
                    if fm:
                        uvw[int(fm.group(1))]=(float(fm.group(2)),float(fm.group(3)),float(fm.group(4)))
                    tm=_TILT_RE.search(ctx)
                    if tm:
                        tilt=(float(tm.group(1)),float(tm.group(2)),float(tm.group(3)))
                    rm=_RELIABILITY_RE.search(ctx)
                    if rm:
                        reliability=rm.group(1).strip().rstrip(' .')
                    cm=_RELIABILITY_CODE_RE.search(ctx)
                    if cm:
                        reliability_code=cm.group(1).strip()

                home=None
                preceding=[row for row in homes if row[0] < i]
                if preceding:
                    home=max(preceding,key=lambda row:row[0])[1]
                protocol_name=None
                pprev=[row for row in protocols if row[0] < i]
                if pprev:
                    protocol_name=max(pprev,key=lambda row:row[0])[1]
                is_dqa=bool(protocol_name and "dqa" in protocol_name.lower())
                patient_target=None; patient_transducer=None; patient_delta=None; patient_axis_pass=None; patient_pass=None
                preceding_targets=[row for row in target_refs if row[0] < i]
                target_ref=max(preceding_targets,key=lambda row:row[0]) if preceding_targets else None
                if target_ref is not None and protocol_name and not is_dqa:
                    patient_target=tuple(float(v) for v in target_ref[2])
                    # Keep the vendor tracker result as residual evidence. Absolute
                    # localized focal/transducer position is only materialized for
                    # a confirmed physical/manual Locate in the workflow layer.
                    patient_delta=(float(x),float(y),float(z))
                    patient_axis_pass=tuple(abs(v) < 1.0 for v in patient_delta)
                    patient_pass=all(patient_axis_pass)
                related=None; related_delta=None
                if starts:
                    best=min(starts,key=lambda row:abs(row[0]-cs)); delta=best[0]-cs
                    if abs(delta) <= 180.0:
                        related=best[1]; related_delta=float(delta)

                # R0180: distinguish operator/physical Locate from the automatic
                # tracker verification that can run immediately before every
                # Sonication.  A tracker localization is NOT automatically a
                # physical re-Locate.
                explicit_locate=False
                for j in range(max(0, i-self.LOCATE_ASSOCIATION_MAX_LINES), i):
                    if _LOCATE_EVENT_RE.search(lines[j]):
                        ev_cs=self._clock_s(lines[j])
                        if ev_cs is None or (0.0 <= cs-ev_cs <= self.LOCATE_ASSOCIATION_WINDOW_S):
                            explicit_locate=True
                pre_sonication=False
                if related_delta is not None:
                    # delta = StartSonicate - localization. Automatic verification
                    # is causal and close to the upcoming sonication.
                    pre_sonication=(0.0 <= float(related_delta) <= 30.0)
                target_changed_before=False
                if target_ref is not None:
                    prev_result_line=max((j for j in range(0,i) if _TRACKER_XD_RE.search(lines[j])), default=-1)
                    # A changed Set-new-home target/reference after the preceding
                    # tracker result opens a physical realignment cycle.
                    refs_since=[row for row in target_refs if prev_result_line < row[0] < i]
                    if refs_since:
                        latest=refs_since[-1][2]
                        earlier=[row[2] for row in target_refs if row[0] <= prev_result_line]
                        target_changed_before=(not earlier or self._xyz_changed(latest, earlier[-1]))
                if explicit_locate:
                    localization_kind="manual-locate"
                elif target_changed_before and not pre_sonication:
                    localization_kind="physical-realignment-locate"
                elif pre_sonication:
                    localization_kind="pre-sonication-verification"
                else:
                    localization_kind="unclassified"
                timestamp=(base_date+timedelta(seconds=cs)) if base_date is not None else None
                records.append(TransducerLocationRecord(
                    timestamp=timestamp,clock_s=float(cs),x=x,y=y,z=z,roll=roll,pitch=pitch,
                    steering_x=None,steering_y=None,steering_z=None,source=path,line_number=i+1,
                    trigger="Tracker localization",related_sonication=related,related_delta_s=related_delta,
                    locate_event_line=i+1,locate_event_clock_s=float(cs),locate_event_text=line.strip(),
                    coordinate_frame="CSA residual",reliability=reliability,reliability_code=reliability_code,
                    tilt_xyz=tilt,tracker_pqr=pqr,tracker_ini_pqr=ini_pqr,tracker_uvw=uvw,home_uvw=home,
                    protocol_name=protocol_name,patient_target_xyz=patient_target,patient_transducer_xyz=patient_transducer,
                    patient_delta_xyz=patient_delta,patient_axis_pass=patient_axis_pass,patient_alignment_pass=patient_pass,
                    localization_kind=localization_kind,startsonicate_delta_s=related_delta,
                ))
        records.sort(key=lambda r:((r.timestamp or datetime.min),r.clock_s,str(r.source).lower(),r.line_number))
        if records:
            bx,by,bz=records[0].x,records[0].y,records[0].z
            for r in records:
                r.delta_x=r.x-bx; r.delta_y=r.y-by; r.delta_z=r.z-bz
                r.displacement=math.sqrt(r.delta_x*r.delta_x+r.delta_y*r.delta_y+r.delta_z*r.delta_z)
        return records

    @staticmethod
    def _xyz_changed(a: tuple[float, float, float] | None, b: tuple[float, float, float] | None, tol: float = 1e-6) -> bool:
        if a is None or b is None:
            return a != b
        return any(abs(float(a[i]) - float(b[i])) > float(tol) for i in range(3))

    @staticmethod
    def _uvw_to_ras(xyz: tuple[float,float,float] | None) -> tuple[float,float,float] | None:
        if xyz is None:
            return None
        return (-float(xyz[0]), -float(xyz[1]), float(xyz[2]))

    def _export_treatment_context(self, workspace: Path) -> tuple[str | None, float | None]:
        """Return (mode, session-start clock) from SonicationSummary export rows.

        ``treatprotocol`` is more authoritative for the exported treatment session
        than a stale GUI protocol name that may still say Brain-DQA during the
        patient's initial pre-target Locate.
        """
        path=Path(workspace)/"SonicationSummary.xml"
        if not path.exists():
            return None,None
        try:
            text=path.read_text(encoding="utf-8",errors="replace")
        except OSError:
            return None,None
        rows=re.findall(r"<z:row\b([^>]*)/>",text,re.I)
        protocols=[]; clocks=[]
        for raw in rows:
            attrs=dict(re.findall(r'(\w+)="([^"]*)"',raw))
            tp=(attrs.get("treatprotocol") or "").strip()
            if tp:
                protocols.append(tp)
            tt=(attrs.get("treattime") or "").strip()
            m=re.fullmatch(r"(\d{2}):(\d{2}):(\d{2})",tt)
            if m:
                clocks.append(int(m.group(1))*3600+int(m.group(2))*60+int(m.group(3)))
        mode=None
        if protocols:
            mode=("dqa" if all("dqa" in q.lower() for q in protocols) else "treatment")
        return mode,(min(clocks) if clocks else None)

    def locate_focal_history(self, workspace: Path) -> list[LocateFocalRecord]:
        """Parse one authoritative focal record per physical Locate block.

        Real Brain treatment logs emit, in the same tracker localization block::

            New home position: (...) New XD tilt: (...)
            Pos = 11.1,7.5,14
            focal position: R11.3 A7.3 S13.1

        ``Pos`` is the treatment target in RAS-style XYZ and the displayed focal
        position is converted from its L/R A/P S/I labels into the same RAS-style
        XYZ.  DQA keeps focal only; target/delta interpretation is intentionally
        suppressed there.
        """
        out=[]
        export_mode,session_start=self._export_treatment_context(Path(workspace))
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8",errors="replace").splitlines()
            except OSError:
                continue
            base_date=self._date_from_name(path)
            protocols=[]
            for i,line in enumerate(lines):
                pm=_PROTOCOL_RE.search(line)
                if pm:
                    protocols.append((i,pm.group(1).strip()))
            for i,line in enumerate(lines):
                if not _NEW_HOME_POSE_RE.search(line):
                    continue
                cs=self._clock_s(line)
                if cs is None:
                    continue
                # A workstation log can contain earlier calibration/DQA activity
                # from before the exported treatment session.  When the export
                # declares a session start, only Locate blocks from that session
                # belong in this export's Focal/Target history.
                if session_start is not None and cs < float(session_start):
                    continue
                protocol=None
                prev=[q for q in protocols if q[0] <= i]
                if prev:
                    protocol=prev[-1][1]
                focal=None; target=None; focal_line=i+1
                # The paired GUI output is compact in observed Brain logs.  Stop
                # before another New-home event so two Locate blocks cannot merge.
                for j in range(i+1,min(len(lines),i+140)):
                    if j>i+1 and _NEW_HOME_POSE_RE.search(lines[j]):
                        break
                    if target is None:
                        pm=_POS_RE.search(lines[j])
                        if pm:
                            target=tuple(float(pm.group(k)) for k in range(1,4))
                    if focal is None:
                        fm=_FOCAL_DISPLAY_RE.search(lines[j])
                        if fm:
                            uvw=self._display_focal_to_uvw(fm.groups())
                            focal=self._uvw_to_ras(uvw)
                            focal_line=j+1
                    if focal is not None and (target is not None or (protocol and "dqa" in protocol.lower())):
                        break
                if focal is None:
                    continue
                # Session-level export semantics override stale GUI protocol state.
                # In the anonymized Patient export the first pre-target Locate at
                # 10:14 still carries Brain-DQA in the GUI state, while the export
                # session itself starts at 10:10:48 as Brain-Treat.
                if session_start is not None and cs >= float(session_start):
                    if export_mode == "treatment":
                        protocol="Brain-Treat"
                    elif export_mode == "dqa":
                        protocol="Brain-DQA"
                if protocol and "dqa" in protocol.lower():
                    target=None
                ts=(base_date+timedelta(seconds=cs)) if base_date is not None else None
                out.append(LocateFocalRecord(ts,float(cs),focal,target,protocol,path,focal_line))
        out.sort(key=lambda q:((q.timestamp or datetime.min),q.clock_s,str(q.source).lower(),q.line_number))
        return out

    def _sonication_steering_events(self, workspace: Path) -> list[SonicationSteeringEvent]:
        """Parse per-Sonication authoritative Steering XYZ from StartSonicate blocks.

        These coordinates describe the software-selected sonication target. They
        are intentionally kept separate from tracker-derived physical alignment.
        """
        out=[]; seen=set()
        for path in self._candidate_logs(Path(workspace)):
            try:
                lines=path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            base_date=self._date_from_name(path)
            starts=[i for i,line in enumerate(lines) if _START_RE.search(line)]
            for pos,i in enumerate(starts):
                sm0=_START_RE.search(lines[i]); cs=self._clock_s(lines[i])
                if sm0 is None or cs is None:
                    continue
                end=starts[pos+1] if pos+1 < len(starts) else min(len(lines),i+700)
                steering=None; steering_line=i
                for j in range(i,min(end,i+700)):
                    cm=_CP_FOCAL_RE.search(lines[j])
                    if cm:
                        uvw=tuple(float(cm.group(k)) for k in range(1,4))
                        steering=self._uvw_to_ras(uvw); steering_line=j; break
                    sm=_START_STEERING_RE.search(lines[j])
                    if sm:
                        steering=tuple(float(sm.group(k)) for k in range(1,4)); steering_line=j; break
                if steering is None:
                    continue
                son=int(sm0.group(1))+1
                key=(str(path.resolve()),i,son,tuple(round(v,9) for v in steering))
                if key in seen:
                    continue
                seen.add(key)
                ts=(base_date+timedelta(seconds=cs)) if base_date is not None else None
                out.append(SonicationSteeringEvent(ts,float(cs),son,steering,path,steering_line+1))
        out.sort(key=lambda e:((e.timestamp or datetime.min),e.clock_s,str(e.source).lower(),e.line_number))
        return out

    def _focus_for_clock(self, workspace: Path, clock_s: float | None) -> tuple[float,float,float] | None:
        poses=self.physical_pose_history(workspace)
        if not poses:
            return None

        def usable(q):
            if q.direct_focal_xyz is not None:
                return q.direct_focal_xyz
            # Do not expose a focal-target delta from an unvalidated 150 mm fallback.
            if q.natural_focus_xyz is not None and q.focal_validation_error_mm is not None and q.focal_validation_error_mm <= 1.0:
                return q.natural_focus_xyz
            return None

        if clock_s is None:
            for q in poses:
                u=usable(q)
                if u is not None:
                    return u
            return None
        preceding=[q for q in poses if q.clock_s <= float(clock_s)+1e-6 and usable(q) is not None]
        if preceding:
            q=max(preceding,key=lambda q:q.clock_s)
            return usable(q)
        following=[q for q in poses if usable(q) is not None]
        if following:
            q=min(following,key=lambda q:abs(q.clock_s-float(clock_s)))
            return usable(q)
        return None

    def patient_alignment_workflow(self, workspace: Path) -> list[PatientAlignmentWorkflowRow]:
        """Build Locate/Focal history for both Patient treatment and DQA.

        R0184 uses the vendor's *paired display values* instead of deriving the
        treatment target from Home/Set-home or the focal from tracker residuals.
        Treatment: Target=``Pos``; Focal=``focal position``; Delta=Focal-Target.
        DQA: every physical Locate focal point is listed, with Target/Delta N/A.
        """
        root=Path(workspace)
        locs=self.locate_focal_history(root)
        if not locs:
            return []
        rows=[]; epoch=0; last_target=None; locate_by_epoch={}
        first_treatment_target=next(
            (q.target_xyz for q in locs
             if q.target_xyz is not None and not (q.protocol_name and "dqa" in q.protocol_name.lower())),
            None,
        )
        initial_treatment_target_applied=False
        for q in locs:
            is_dqa=bool(q.protocol_name and "dqa" in q.protocol_name.lower())
            if is_dqa:
                idx=sum(1 for r in rows if r.change_mode=="DQA Locate")+1
                rows.append(PatientAlignmentWorkflowRow(
                    stage=f"DQA Locate #{idx} — Focal point",sequence=0,timestamp=q.timestamp,clock_s=q.clock_s,
                    target_xyz=None,transducer_xyz=q.focal_xyz,delta_xyz=None,axis_pass=None,overall_pass=None,
                    source_record=None,note="DQA Locate Transducer focal point. Target comparison is not applied.",
                    target_epoch=None,change_mode="DQA Locate",protocol_name=q.protocol_name,source_path=q.source,source_line=q.line_number))
                continue

            # Patient treatment. The first physical Locate may precede Target entry.
            # Clinically, once the first treatment target is entered it is compared
            # against that initial Locate result. Therefore back-bind the first
            # authoritative treatment Target to the first pre-target Locate only.
            target=q.target_xyz
            borrowed_initial_target=False
            if target is None and not initial_treatment_target_applied and first_treatment_target is not None:
                target=first_treatment_target
                borrowed_initial_target=True
                initial_treatment_target_applied=True
            elif target is not None and not initial_treatment_target_applied:
                initial_treatment_target_applied=True
            if target is not None and (last_target is None or self._xyz_changed(target,last_target,1e-6)):
                epoch+=1; last_target=target
            ep=epoch if epoch else None
            locate_by_epoch[ep]=locate_by_epoch.get(ep,0)+1
            d=(tuple(float(q.focal_xyz[k])-float(target[k]) for k in range(3)) if target is not None else None)
            axis=tuple(abs(v)<1.0 for v in d) if d is not None else None
            if borrowed_initial_target:
                stage="Initial Locate — first Target comparison"
                note=("Initial Treatment Locate Transducer: the first authoritative treatment Target is "
                      "back-bound to this earlier Locate result; ΔXYZ = Focal - first Target.")
                change_mode="Initial physical Locate"
            else:
                stage=(f"Target #{ep} — Locate #{locate_by_epoch[ep]}" if ep is not None else "Initial Locate — Focal point")
                note=("Treatment Locate Transducer: Target and Focal are read directly from the same workstation tracker block; ΔXYZ = Focal - Target."
                      if target is not None else "Initial Treatment Locate before a Target is present; Focal only.")
                change_mode=("Physical re-Locate" if target is not None else "Initial physical Locate")
            rows.append(PatientAlignmentWorkflowRow(
                stage=stage,sequence=0,timestamp=q.timestamp,clock_s=q.clock_s,target_xyz=target,
                transducer_xyz=q.focal_xyz,delta_xyz=d,axis_pass=axis,overall_pass=(all(axis) if axis is not None else None),
                source_record=None,note=note,
                target_epoch=ep,change_mode=change_mode,
                protocol_name=q.protocol_name,source_path=q.source,source_line=q.line_number))

        # Sonication target changes without a new physical Locate are electronic
        # steering/effective-target changes. Bind each event to the latest physical
        # Target that already existed at that clock; never borrow a future Target.
        export_mode,session_start=self._export_treatment_context(root)
        treatment_targets=sorted(
            [r for r in rows if r.change_mode=="Physical re-Locate" and r.target_xyz is not None and r.clock_s is not None],
            key=lambda r:float(r.clock_s),
        )
        prev_effective_by_epoch={}
        for ev in self._sonication_steering_events(root):
            if session_start is not None and ev.clock_s < float(session_start):
                continue
            if export_mode == "dqa":
                continue
            prior=[r for r in treatment_targets if float(r.clock_s) <= ev.clock_s]
            if not prior:
                continue
            base=prior[-1]
            base_target=base.target_xyz
            base_epoch=base.target_epoch
            if base_target is None:
                continue
            prev_effective=prev_effective_by_epoch.get(base_epoch)
            changed_from_base=self._xyz_changed(ev.steering_xyz,base_target,1e-6)
            changed_from_prev=(prev_effective is not None and self._xyz_changed(ev.steering_xyz,prev_effective,1e-6))
            if changed_from_base and (prev_effective is None or changed_from_prev):
                delta=tuple(ev.steering_xyz[k]-base_target[k] for k in range(3))
                rows.append(PatientAlignmentWorkflowRow(
                    stage=f"Target #{base_epoch or 1} — Electronic steering / effective target",sequence=0,
                    timestamp=ev.timestamp,clock_s=ev.clock_s,target_xyz=base_target,transducer_xyz=None,delta_xyz=None,
                    axis_pass=None,overall_pass=None,source_record=None,target_epoch=base_epoch,change_mode="Electronic steering",
                    steering_xyz=ev.steering_xyz,steering_delta_xyz=delta,effective_target_xyz=ev.steering_xyz,
                    sonication_number=ev.sonication_number,note="Effective sonication target changed electronically; physical Focal-vs-Target alignment is not reinterpreted.",
                    protocol_name="Brain-Treat",source_path=ev.source,source_line=ev.line_number))
            prev_effective_by_epoch[base_epoch]=ev.steering_xyz

        rows.sort(key=lambda w:((float(w.clock_s) if w.clock_s is not None else -1.0),0 if w.change_mode!="Electronic steering" else 1))
        for i,w in enumerate(rows,1): w.sequence=i
        return rows

    def parse(self, workspace: Path) -> list[TransducerLocationRecord]:
        """Return tracker-derived localization residuals plus Patient-treatment alignment when a target reference is available."""
        return self._tracker_localizations(workspace)
