from __future__ import annotations

import types
import time
from typing import Callable

import pyqtgraph as pg
from PySide6.QtCore import QObject, QEvent, Qt, QTimer
from PySide6.QtGui import QColor


class _PlotDoubleClickResetFilter(QObject):
    def __init__(self, plot, reset_callback: Callable[[], None] | None = None):
        super().__init__(plot)
        self.plot = plot
        self.reset_callback = reset_callback

    def eventFilter(self, obj, event):
        if event.type() == QEvent.Type.MouseButtonDblClick and event.button() == Qt.MouseButton.LeftButton:
            reset_plot_zoom(self.plot, self.reset_callback)
            event.accept()
            return True
        return False


def reset_plot_zoom(plot, reset_callback: Callable[[], None] | None = None) -> None:
    """Reset both axes to the current data bounds with one double click."""
    if plot is None:
        return
    try:
        vb = plot.getViewBox()
        vb.autoRange(padding=0.02)
    except Exception:
        try:
            plot.autoRange(padding=0.02)
        except Exception:
            return
    try:
        if reset_callback is not None:
            reset_callback()
    except Exception:
        pass


def install_horizontal_axis_range_zoom(
    plot,
    *,
    manual_callback: Callable[[], None] | None = None,
    reset_callback: Callable[[], None] | None = None,
) -> None:
    """Add horizontal-axis drag-to-zoom and chart double-click reset.

    Contract:
    - Drag with the LEFT button directly on the bottom X axis to choose an X range.
    - Only X changes; the existing Y range is preserved exactly.
    - Normal dragging inside the plotting area remains pyqtgraph pan behavior.
    - Double-left-click is reset-only. No popup/enlarge callback is accepted by this helper.

    This deliberately keeps FFT/raw chart-area range selection independent: it owns
    the plotting area, while generic navigation owns only the bottom axis.
    """
    if plot is None:
        return
    # R0190c: installation is idempotent for axis drag, but the double-click
    # action is intentionally upgradeable.  Earlier code returned here and could
    # leave an older reset handler installed when a later owner requested enlarge.
    if bool(getattr(plot, "_soni_x_axis_range_zoom_installed", False)):
        filt = getattr(plot, "_soni_x_axis_zoom_filter", None)
        if filt is not None:
            # R0190f: double-click is globally RESET-only.  Assign None as well so
            # a plot previously wired by R0190b-d to an enlarge callback is actively
            # downgraded back to reset instead of retaining the stale popup owner.
            if reset_callback is not None:
                filt.reset_callback = reset_callback
        return
    try:
        axis = plot.getAxis("bottom")
        vb = plot.getViewBox()
        # Image/map panels deliberately hide their X axis.  They are not range charts,
        # so installing a viewport double-click reset there would change image framing.
        if hasattr(axis, "isVisible") and not axis.isVisible():
            return
        original_drag = axis.mouseDragEvent
    except Exception:
        return

    plot._soni_x_axis_range_zoom_installed = True
    state = {"active": False, "start": None, "region": None, "y": None}

    def _scene_x(ev):
        try:
            return float(vb.mapSceneToView(ev.scenePos()).x())
        except Exception:
            try:
                return float(vb.mapSceneToView(ev.pos()).x())
            except Exception:
                return None

    def _remove_region():
        region = state.get("region")
        state["region"] = None
        if region is not None:
            try:
                plot.removeItem(region)
            except Exception:
                pass

    def _axis_mouse_drag(axis_self, ev):
        try:
            if ev.button() != Qt.MouseButton.LeftButton:
                return original_drag(ev)
        except Exception:
            return original_drag(ev)

        x = _scene_x(ev)
        if x is None:
            return original_drag(ev)

        if ev.isStart():
            state["active"] = True
            state["start"] = x
            try:
                state["y"] = tuple(float(v) for v in vb.viewRange()[1])
            except Exception:
                state["y"] = None
            _remove_region()
            try:
                region = pg.LinearRegionItem(
                    values=(x, x),
                    orientation=pg.LinearRegionItem.Vertical,
                    movable=False,
                    brush=pg.mkBrush(QColor(90, 180, 255, 55)),
                    pen=pg.mkPen(QColor(130, 210, 255, 210), width=1),
                )
                region.setZValue(10_000)
                plot.addItem(region, ignoreBounds=True)
                state["region"] = region
            except Exception:
                state["region"] = None

        if state.get("active"):
            start = float(state.get("start", x))
            lo, hi = sorted((start, x))
            region = state.get("region")
            if region is not None:
                try:
                    region.setRegion((lo, hi))
                except Exception:
                    pass
            if ev.isFinish():
                state["active"] = False
                _remove_region()
                # Reject accidental clicks/tiny ranges in scene coordinates.
                try:
                    current_x = vb.viewRange()[0]
                    min_width = max(abs(float(current_x[1]) - float(current_x[0])) * 0.002, 1e-12)
                except Exception:
                    min_width = 1e-12
                if hi - lo >= min_width:
                    try:
                        vb.setXRange(lo, hi, padding=0.0)
                        y = state.get("y")
                        if y is not None and len(y) == 2:
                            vb.setYRange(float(y[0]), float(y[1]), padding=0.0)
                        if manual_callback is not None:
                            manual_callback()
                    except Exception:
                        pass
        ev.accept()

    axis.mouseDragEvent = types.MethodType(_axis_mouse_drag, axis)

    # R0190d: pyqtgraph/Qt delivery differs between PlotWidget versions.  Some
    # Windows builds consume the viewport MouseButtonDblClick in GraphicsScene,
    # so a viewport-only eventFilter can silently miss the gesture.  Install two
    # routes to ONE debounced dispatcher: native viewport eventFilter plus the
    # pyqtgraph scene click signal.  The debounce prevents one physical double
    # click from opening two dialogs when both routes fire.
    # R0190g: own the pyqtgraph ViewBox double-click path itself. On Windows,
    # GraphicsView can consume the Qt viewport event before the viewport filter,
    # while ViewBox still receives the graphics-scene double-click. Reset here and
    # accept it so no legacy/default popup/enlarge owner can run afterward.
    try:
        original_vb_double = getattr(vb, "mouseDoubleClickEvent", None)
        def _viewbox_double(vb_self, ev):
            try:
                is_left = (ev.button() == Qt.MouseButton.LeftButton)
            except Exception:
                is_left = True
            if is_left:
                reset_plot_zoom(plot, reset_callback)
                try: ev.accept()
                except Exception: pass
                return
            if original_vb_double is not None:
                return original_vb_double(ev)
        vb.mouseDoubleClickEvent = types.MethodType(_viewbox_double, vb)
        plot._soni_viewbox_double_handler = _viewbox_double
    except Exception:
        pass

    try:
        filt = _PlotDoubleClickResetFilter(plot, reset_callback)
        plot.viewport().installEventFilter(filt)
        plot._soni_x_axis_zoom_filter = filt
        plot._soni_last_double_dispatch = 0.0
        original_dispatch = filt.eventFilter
        def _debounced_filter(obj, event):
            if event.type() == QEvent.Type.MouseButtonDblClick and event.button() == Qt.MouseButton.LeftButton:
                now=time.monotonic()
                if now-float(getattr(plot, '_soni_last_double_dispatch', 0.0)) < 0.30:
                    event.accept(); return True
                plot._soni_last_double_dispatch=now
            return original_dispatch(obj,event)
        filt.eventFilter=_debounced_filter

        def _scene_double(ev, owner=plot, f=filt):
            try:
                is_double=bool(ev.double())
                is_left=(ev.button() == Qt.MouseButton.LeftButton)
            except Exception:
                return
            if not (is_double and is_left):
                return
            now=time.monotonic()
            if now-float(getattr(owner, '_soni_last_double_dispatch', 0.0)) < 0.30:
                return
            owner._soni_last_double_dispatch=now
            reset_plot_zoom(owner, f.reset_callback)
            try: ev.accept()
            except Exception: pass
        plot.scene().sigMouseClicked.connect(_scene_double)
        plot._soni_scene_double_handler=_scene_double
    except Exception:
        pass

    try:
        old_tip = str(plot.toolTip() or "").strip()
        dbl_hint = "Double-click the chart to reset zoom."
        hint = "Drag the bottom X axis to zoom a horizontal range. " + dbl_hint
        plot.setToolTip((old_tip + "\n" + hint).strip())
    except Exception:
        pass
