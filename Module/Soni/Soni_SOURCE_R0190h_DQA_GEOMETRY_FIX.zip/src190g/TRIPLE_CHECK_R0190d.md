# R0190d triple check

Input evidence: 4267...Import_Diagnostics(3) from R0190c.

Key finding: R0190c recovered Axial/Sagittal focus, but diagnostics showed both fallback candidates with an artificial coherent score of 0.000 and excluded the entire judgement because S4 used electronic steering. The export itself shows default-centre setup records at (0,0,150) and a minority steered state at (4,4,154).

Validation:
- focused R0190d + R0190c/R0190a/R0190 tests: 18/18 PASS
- broader DQA regression selection: 22/22 PASS
- compileall: PASS
- verify_source.py: VERIFY_SOURCE_OK

Qt runtime cannot be executed in this Linux validation environment; Windows behavior must be confirmed in the built EXE.
