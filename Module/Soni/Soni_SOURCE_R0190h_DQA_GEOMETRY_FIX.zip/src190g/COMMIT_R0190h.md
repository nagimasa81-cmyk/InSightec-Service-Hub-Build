# R0190h
DQA phantom geometry correction.
- Axial RL reference no longer uses the biased all-gradient inner-circle fit.
- Sagittal AP reference no longer uses an asymmetric intensity-mask midpoint.
- Sagittal lower-line detector selects the physical upper edge of the finite-thickness DQA reference bar instead of its strongest/lower edge.
- Lower line and +20 mm SI reference are evaluated at observed-focus X; overlay and calculation now use the same geometry.
- No expected displacement values are used by the detectors.
- 4267 regression: previous X +1.3 / Y -2.5 / Z +18.6 changed to X -5.2 / Y -11.3 / Z +6.4 mm; SI/AP are now consistent with the supplied workstation visual evidence (~6.9/~12.4 mm), while RL remains image-derived rather than fitted to the supplied ~3.8 mm estimate.
