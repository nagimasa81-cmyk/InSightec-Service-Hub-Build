# COMMIT R0190

Base: Soni_SOURCE_R0189.zip (SHA256 0c3801576cfa0e3bb762551c094befe1f36e0865b43045fc065946a904e8d3d5)

## Summary lifecycle
- Full Sonication Summary detail is released only after whole-study Spectrum preload reaches terminal ready (`preload_complete=True`) or terminal failure.
- Per-Sonication `sonicationReady` adopts partial context for consumers only; it never dirties/restarts the Summary table.
- Added workspace + source-switch-generation once token. One full-detail worker is allowed per adopted study generation.
- Completed/running tokens reset only on source switch. Finish-time retry/pending auto-reanalysis path was removed from the normal R0190 lifecycle.

## DQA focus alignment
- Contract advanced to R0190.
- Removed thermal/magnitude list-index ratio pairing from the DQA service. `_magnitude_for` is fail-closed/deprecated.
- Thermal RAW is bound through `_row_for_raw_frame`; magnitude pairing requires acquisition identity plus compatible physical geometry and must resolve uniquely.
- Observed focus search is constrained by a magnitude-derived phantom/body mask: Axial circle interior; Sagittal body above the detected lower baseline.
- Hotspot uses coherent 5x5 local statistics plus local weighted centroid; global 5–95% raster maximum is removed.
- Planned focalRAS is not a displacement zero point or hard spatial gate; it is only a near-equal shot-selection tie-break.
- `_point_in_exported_image_frame` `ok` is required in paired/reference projection paths. Ambiguous pairing/mask/geometry fails closed.
- Diagnostics now record selected Sonication, thermal RAW, magnitude RAW, acquisition identity, mask kind, coherent score, hotspot pixel/RAS.

## Release metadata
- VERSION/version.json/constants/build descriptions/build contract updated to RC7.10-R0190a / R0190.
- Build contract release_sequence: 190.

No expected-value coefficient fitting, fixture/SHA branching, numeric clipping, planned-focus hard ROI, or Umbrella orientation logic changes were introduced.
