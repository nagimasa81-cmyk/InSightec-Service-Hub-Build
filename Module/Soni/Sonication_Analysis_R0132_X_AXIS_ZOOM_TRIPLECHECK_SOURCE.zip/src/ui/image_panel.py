from __future__ import annotations

import numpy as np
import pyqtgraph as pg
from PySide6.QtCore import Signal, QPointF, Qt, QTimer, QRectF, QEvent
from PySide6.QtGui import QPainter, QColor, QPen, QFont
from PySide6.QtWidgets import QApplication, QGroupBox, QVBoxLayout, QWidget


class InteractivePlotWidget(pg.PlotWidget):
    wlwwDragged = Signal(float, float)
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._right_start = None

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.RightButton:
            self._right_start = event.position()
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._right_start is not None:
            delta = event.position() - self._right_start
            self._right_start = event.position()
            self.wlwwDragged.emit(float(delta.x()), float(delta.y()))
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.RightButton and self._right_start is not None:
            self._right_start = None
            event.accept()
            return
        super().mouseReleaseEvent(event)


class MRAnnotationOverlay(QWidget):
    """Screen-fixed workstation-style MR annotation overlay.

    Orientation letters and acquisition/protocol text are painted independently
    from the image LUT/thermal layers so WW/WL, threshold and registration refreshes
    cannot erase them.  The overlay is display-only and never captures mouse input.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self._data = {}
        self.hide()

    def set_data(self, data: dict | None) -> None:
        self._data = dict(data or {})
        visible = bool(self._data)
        self.setVisible(visible)
        if visible:
            self.setGeometry(self.parentWidget().rect())
            self.raise_()
        self.update()

    def sync_geometry(self) -> None:
        parent = self.parentWidget()
        if parent is not None and self.isVisible():
            self.setGeometry(parent.rect())
            self.raise_()

    def _draw_text(self, painter, x, y, text, *, align=Qt.AlignmentFlag.AlignLeft, bold=False, size=10):
        if not text:
            return
        font = QFont()
        font.setPointSize(size)
        font.setBold(bool(bold))
        painter.setFont(font)
        metrics = painter.fontMetrics()
        rect = metrics.boundingRect(str(text))
        w = rect.width() + 10
        h = rect.height() + 6
        if align & Qt.AlignmentFlag.AlignHCenter:
            x -= w / 2
        elif align & Qt.AlignmentFlag.AlignRight:
            x -= w
        if align & Qt.AlignmentFlag.AlignVCenter:
            y -= h / 2
        # Black outline/shadow keeps text legible on both bright and dark MR pixels.
        painter.setPen(QPen(QColor(0, 0, 0, 230), 3.0))
        painter.drawText(QPointF(float(x + 5), float(y + h - 6)), str(text))
        painter.setPen(QPen(QColor(80, 235, 240), 1.0))
        painter.drawText(QPointF(float(x + 5), float(y + h - 6)), str(text))

    def paintEvent(self, event):
        if not self._data:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        w, h = float(self.width()), float(self.height())
        margin = 10.0
        # Anatomical edge direction labels.
        self._draw_text(painter, margin, h / 2, self._data.get('left'), align=Qt.AlignmentFlag.AlignVCenter, bold=True, size=12)
        self._draw_text(painter, w - margin, h / 2, self._data.get('right'), align=Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, bold=True, size=12)
        self._draw_text(painter, w / 2, margin, self._data.get('top'), align=Qt.AlignmentFlag.AlignHCenter, bold=True, size=12)
        self._draw_text(painter, w / 2, h - 36, self._data.get('bottom'), align=Qt.AlignmentFlag.AlignHCenter, bold=True, size=12)

        center = self._data.get('center_text')
        if center:
            self._draw_text(painter, w / 2, 34, center, align=Qt.AlignmentFlag.AlignHCenter, size=9)

        protocol_lines = [x for x in self._data.get('protocol_lines', []) if x]
        if protocol_lines:
            y = max(50.0, h - 24.0 - 22.0 * len(protocol_lines))
            for line in protocol_lines:
                self._draw_text(painter, margin, y, line, size=9)
                y += 22.0

        acq = self._data.get('acquisition_text')
        if acq:
            self._draw_text(painter, w / 2, h - 12, acq, align=Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignBottom, bold=True, size=9)

        # R0130: workstation-style frequency-encoding "hat" marker.
        # Keep the vendor-like cyan outline and lower-right placement from the
        # treatment workstation.  The caret is rotated only when the resolved
        # frequency axis maps to the displayed left/right anatomical axis.
        # Unknown direction is intentionally not guessed.
        freq_axis = str(self._data.get('frequency_axis') or '').upper()
        left = str(self._data.get('left') or '').upper()
        right = str(self._data.get('right') or '').upper()
        top = str(self._data.get('top') or '').upper()
        bottom = str(self._data.get('bottom') or '').upper()
        lr_axis = ''.join(sorted({left, right}))
        tb_axis = ''.join(sorted({top, bottom}))
        axis_pair = {
            'LR': 'RL', 'RL': 'RL', 'AP': 'AP', 'PA': 'AP', 'IS': 'SI', 'SI': 'SI'
        }
        lr_axis = axis_pair.get(lr_axis, '')
        tb_axis = axis_pair.get(tb_axis, '')
        freq_axis = axis_pair.get(freq_axis, freq_axis)
        if freq_axis in {'RL', 'AP', 'SI'}:
            cx, cy = w - 18.0, h - 18.0
            arm = 7.0
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            painter.setPen(QPen(QColor(80, 235, 240), 2.0))
            if freq_axis == lr_axis:
                # Same small hat shape as the workstation, rotated 90 degrees.
                painter.drawLine(QPointF(cx - arm, cy - arm), QPointF(cx, cy))
                painter.drawLine(QPointF(cx - arm, cy + arm), QPointF(cx, cy))
            elif freq_axis == tb_axis:
                painter.drawLine(QPointF(cx - arm, cy), QPointF(cx, cy - arm))
                painter.drawLine(QPointF(cx + arm, cy), QPointF(cx, cy - arm))
        painter.end()


class PhysicalRulerOverlay(QWidget):
    """Screen-fixed 5 mm physical ruler rendered as cyan 1 mm ticks only.

    The overlay is pinned to the right edge and vertically centered. Its total
    5 mm on-screen length is recomputed from ViewBox.viewPixelSize(), so zoom
    changes the physical scale length without moving the ruler away from the
    center-right of the viewport. The overlay has no background and no text;
    it only draws the cyan spine and six 1 mm boundary ticks (0..5 mm).
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self._length_px = 0.0
        self._visible_scale = False
        self.resize(42, 180)
        self.hide()

    def update_scale(self, length_px: float | None) -> None:
        try:
            value = float(length_px) if length_px is not None else 0.0
        except Exception:
            value = 0.0
        self._length_px = value if np.isfinite(value) and value > 1.0 else 0.0
        self._visible_scale = self._length_px > 1.0
        self.setVisible(self._visible_scale)
        self.update()

    def place_at_right(self) -> None:
        parent = self.parentWidget()
        if parent is None or not self._visible_scale:
            return
        width = 42
        available = max(32, int(parent.height()) - 16)
        desired = int(round(self._length_px)) + 18
        height = max(32, min(available, desired))
        x = max(0, int(parent.width()) - width - 8)
        y = max(8, (int(parent.height()) - height) // 2)
        self.setGeometry(x, y, width, height)
        self.raise_()

    def paintEvent(self, event):
        if not self._visible_scale:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        cyan = QColor(74, 226, 235)
        painter.setPen(QPen(cyan, 2.0))
        length = float(self._length_px)
        top = (float(self.height()) - length) / 2.0
        x = float(self.width() - 8)
        painter.drawLine(QPointF(x, top), QPointF(x, top + length))
        for mm in range(6):
            yy = top + length * float(mm) / 5.0
            painter.drawLine(QPointF(x - 12.0, yy), QPointF(x, yy))
        painter.end()



class ImagePanel(QGroupBox):
    def __init__(self, title, parent=None):
        super().__init__(title, parent)
        self.view = InteractivePlotWidget(); self.view.setAspectLocked(True); self.view.invertY(True)
        self.view.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        self.view.hideAxis("left"); self.view.hideAxis("bottom")
        self.image = pg.ImageItem(axisOrder="row-major"); self.view.addItem(self.image)
        layout = QVBoxLayout(self); layout.setContentsMargins(2,4,2,2); layout.addWidget(self.view)

    def set_image(self, array, levels=None, lut=None, hotspot=None, hotspot_text=None):
        if array is None: self.image.clear(); return
        self.image.setImage(np.asarray(array), autoLevels=levels is None, levels=levels)
        self.image.setLookupTable(lut); self.view.autoRange(padding=0.01)


class OverlayPanel(QGroupBox):
    cursorMoved = Signal(float, float)
    viewStateChanged = Signal()
    levelsChanged = Signal(float, float)
    measurementChanged = Signal(dict)

    def __init__(self, title="Magnitude + Temperature Overlay", parent=None):
        super().__init__(title, parent)
        self.view = InteractivePlotWidget(); self.view.setAspectLocked(True); self.view.invertY(True)
        self.view.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        self.view.hideAxis("left"); self.view.hideAxis("bottom"); self.view.setMouseEnabled(x=True,y=True)
        self.magnitude_item = pg.ImageItem(axisOrder="row-major")
        self.temperature_item = pg.ImageItem(axisOrder="row-major")
        try:
            self.magnitude_item.setOpts(autoDownsample=False)
            self.temperature_item.setOpts(autoDownsample=False)
        except Exception:
            pass
        self.view.addItem(self.magnitude_item); self.view.addItem(self.temperature_item)
        self.cursor_target = pg.TargetItem(movable=True,size=18,symbol="+",pen=pg.mkPen("#00d9ff",width=2),hoverPen=pg.mkPen("#ffffff",width=2))
        self.cursor_target.setVisible(False); self.view.addItem(self.cursor_target)
        self.cursor_target.sigPositionChanged.connect(self._target_dragged)
        self.cursor_label = pg.TextItem(anchor=(0,0),color="#f5f5f5",fill=pg.mkBrush(0,0,0,185)); self.cursor_label.setVisible(False); self.view.addItem(self.cursor_label)
        self.hover_label = pg.TextItem(anchor=(0.5,0), color="#ffffff", fill=pg.mkBrush(0,0,0,205)); self.hover_label.setZValue(80); self.hover_label.hide(); self.view.addItem(self.hover_label)
        self._hover_temperature = None
        self._hover_proxy = pg.SignalProxy(self.view.scene().sigMouseMoved, rateLimit=45, slot=self._hover_moved)
        # The 20-pixel target circle is display-only.  The 3 x 3 pixel square
        # is the actual temperature calculation voxel/ROI.
        self.target_circle = pg.EllipseROI((0,0),(20,20),movable=False,pen=pg.mkPen("#7CFC00",width=2.8))
        self.target_circle.setAcceptedMouseButtons(Qt.MouseButton.NoButton); self.target_circle.setVisible(False); self.view.addItem(self.target_circle)
        self.roi_box = pg.RectROI((0,0),(3,3),movable=False,pen=pg.mkPen("#00e5ff",width=2.0))
        self.roi_box.setAcceptedMouseButtons(Qt.MouseButton.NoButton); self.roi_box.setVisible(False); self.view.addItem(self.roi_box)
        measure_roi_cls = getattr(pg, "CircleROI", None)
        if measure_roi_cls is not None:
            self.measure_roi = measure_roi_cls((0,0),(20,20),movable=True,pen=pg.mkPen("#ffe45c",width=2.2))
        else:
            self.measure_roi = pg.EllipseROI((0,0),(20,20),movable=True,pen=pg.mkPen("#ffe45c",width=2.2))
        self.measure_roi.addScaleHandle([1, 1], [0, 0])
        self.measure_roi.addScaleHandle([0, 0], [1, 1])
        self.measure_roi.addScaleHandle([1, 0], [0, 1])
        self.measure_roi.addScaleHandle([0, 1], [1, 0])
        self.measure_roi.setZValue(75)
        self.measure_roi.hide(); self.view.addItem(self.measure_roi)
        self.measure_roi.sigRegionChanged.connect(self._update_measurement)
        self.measure_roi.sigRegionChangeFinished.connect(self._update_measurement)
        self.measure_label = pg.TextItem(anchor=(0,0), color="#fff9c4", fill=pg.mkBrush(0,0,0,205))
        self.measure_label.setZValue(85); self.measure_label.hide(); self.view.addItem(self.measure_label)
        self._measurement_array = None; self._measurement_name = "Image"; self._last_measurement = None
        self._shape=None; self._updating_target=False
        self._mm_per_pixel = None
        self._ruler_items = []
        self.ruler_overlay = PhysicalRulerOverlay(self.view)
        self.annotation_overlay = MRAnnotationOverlay(self.view)
        self.annotation_center = pg.TargetItem(movable=False, size=13, symbol="+", pen=pg.mkPen("#50ebf0", width=1.8))
        self.annotation_center.setZValue(72); self.annotation_center.hide(); self.view.addItem(self.annotation_center)
        self.view.installEventFilter(self)
        self._wlww_drag_start=None; self._wlww_start_levels=None
        self.view.scene().sigMouseClicked.connect(self._clicked)
        self.view.wlwwDragged.connect(self._wlww_dragged)
        self.view.plotItem.vb.sigRangeChanged.connect(self._view_range_changed)
        layout=QVBoxLayout(self); layout.setContentsMargins(2,4,2,2); layout.addWidget(self.view)

    def _display_to_data_y(self, y):
        # ViewBox.invertY(True) gives conventional raster display: row 0 at top.
        return float(y)
    def _data_to_display_y(self, y):
        return float(y)


    def eventFilter(self, obj, event):
        if obj is self.view and event.type() in (QEvent.Type.Resize, QEvent.Type.Show):
            QTimer.singleShot(0, self._draw_ruler)
            QTimer.singleShot(0, self.annotation_overlay.sync_geometry)
        return super().eventFilter(obj,event)

    def _view_range_changed(self, *_):
        self.viewStateChanged.emit()
        # Keep the physical ruler pinned to the visible right edge while its
        # on-screen length continues to represent a true 5 mm in image space.
        if not getattr(self, "_ruler_redraw_pending", False):
            self._ruler_redraw_pending = True
            QTimer.singleShot(0, self._redraw_ruler_after_range_change)

    def _redraw_ruler_after_range_change(self):
        self._ruler_redraw_pending = False
        self._draw_ruler()

    def _wlww_dragged(self, dx, dy):
        levels = self.magnitude_item.getLevels()
        if levels is None:
            return
        low, high = map(float, levels)
        width = max(1e-6, high-low)
        center = (high+low)/2.0
        width = max(1e-6, width * (1.0 + dx/250.0))
        center = center - dy * width/300.0
        new_levels=(center-width/2.0, center+width/2.0)
        self.magnitude_item.setLevels(new_levels)
        self.levelsChanged.emit(float(new_levels[0]), float(new_levels[1]))

    def view_range(self):
        return self.view.plotItem.vb.viewRange()

    def set_view_range(self, ranges):
        try:
            self.view.setXRange(*ranges[0], padding=0)
            self.view.setYRange(*ranges[1], padding=0)
        except Exception:
            pass

    def _clicked(self,event):
        if self._shape is None or event.button()!=Qt.MouseButton.LeftButton: return
        point=self.view.plotItem.vb.mapSceneToView(event.scenePos())
        x=float(np.clip(point.x(),0,self._shape[1]-1)); yd=float(np.clip(point.y(),0,self._shape[0]-1))
        self.cursorMoved.emit(x,self._display_to_data_y(yd))

    def _target_dragged(self):
        if self._updating_target or self._shape is None: return
        pos=self.cursor_target.pos(); x=float(np.clip(pos.x(),0,self._shape[1]-1)); yd=float(np.clip(pos.y(),0,self._shape[0]-1))
        self.cursorMoved.emit(x,self._display_to_data_y(yd))

    def set_cursor(self,x,y,text=""):
        yd=self._data_to_display_y(y); self._updating_target=True; self.cursor_target.setPos(QPointF(x,yd)); self._updating_target=False
        self.cursor_label.setPos(x+4,yd+5); self.cursor_label.setText(text); self.cursor_target.setVisible(True); self.cursor_label.setVisible(bool(text))

    def set_hover_temperature(self, array):
        self._hover_temperature = None if array is None else np.asarray(array, float)
        if self._hover_temperature is None:
            self.hover_label.hide()

    def _hover_moved(self, event):
        scene_pos = event[0] if isinstance(event, (tuple, list)) else event
        arr = self._hover_temperature
        if arr is None or self._shape is None or not self.view.sceneBoundingRect().contains(scene_pos):
            self.hover_label.hide(); return
        point = self.view.plotItem.vb.mapSceneToView(scene_pos)
        x = int(round(point.x())); y = int(round(self._display_to_data_y(point.y())))
        if x < 0 or y < 0 or y >= arr.shape[0] or x >= arr.shape[1]:
            self.hover_label.hide(); return
        value = arr[y, x]
        if not np.isfinite(value):
            self.hover_label.hide(); return
        # Place below the pointer; clamp near image borders so the label remains visible.
        px = float(np.clip(point.x(), 8, max(8, arr.shape[1]-8)))
        py = float(np.clip(point.y()+8, 0, max(0, arr.shape[0]-4)))
        self.hover_label.setText(f"{value:.1f} °C")
        self.hover_label.setPos(px, py)
        self.hover_label.show()

    @staticmethod
    def _smooth_binary_mask(mask: np.ndarray, passes: int = 2) -> np.ndarray:
        out=np.asarray(mask,float)
        for _ in range(max(1,int(passes))):
            p=np.pad(out,1,mode="edge")
            out=(p[:-2,:-2]+p[:-2,1:-1]+p[:-2,2:]+p[1:-1,:-2]+p[1:-1,1:-1]+p[1:-1,2:]+p[2:,:-2]+p[2:,1:-1]+p[2:,2:])/9.0
        return np.clip(out,0.0,1.0)

    @staticmethod
    def _focused_threshold_mask(temp: np.ndarray, threshold: float, hotspot=None) -> np.ndarray:
        """Return only the focal connected threshold region.

        R0116zzz: choose the seed vectorially, then flood only that component.  The
        previous implementation enumerated *every* component in Python, making a
        1024² overlay take >1 s on the GUI thread.
        """
        from collections import deque
        arr=np.asarray(temp,float)
        # User contract: the red threshold is a lower-bound alarm mask; values at or
        # above the selected threshold are the red-filled region.
        raw=np.isfinite(arr) & (arr>=float(threshold))
        if not raw.any():
            return raw
        h,w=raw.shape
        if hotspot is not None:
            try: sx=int(round(float(hotspot[0]))); sy=int(round(float(hotspot[1])))
            except Exception: sx=w//2; sy=h//2
        else:
            sx=w//2; sy=h//2
        sx=int(np.clip(sx,0,w-1)); sy=int(np.clip(sy,0,h-1))
        if raw[sy,sx]:
            seed_y,seed_x=sy,sx
        else:
            coords=np.argwhere(raw)
            d2=(coords[:,1].astype(np.int64)-sx)**2 + (coords[:,0].astype(np.int64)-sy)**2
            seed_y,seed_x=(int(v) for v in coords[int(np.argmin(d2))])
        keep=np.zeros_like(raw,bool)
        keep[seed_y,seed_x]=True
        q=deque([(seed_y,seed_x)])
        while q:
            cy,cx=q.popleft()
            y0=max(0,cy-1); y1=min(h,cy+2); x0=max(0,cx-1); x1=min(w,cx+2)
            local=np.argwhere(raw[y0:y1,x0:x1] & ~keep[y0:y1,x0:x1])
            for ly,lx in local:
                ny,nx=y0+int(ly),x0+int(lx)
                keep[ny,nx]=True; q.append((ny,nx))
        # Small vectorized close fills one-pixel holes without attaching distant
        # threshold islands.  Alpha smoothing happens separately.
        for _ in range(2):
            p=np.pad(keep.astype(np.uint8),1,mode="constant")
            n=sum(p[1+dy:h+1+dy,1+dx:w+1+dx] for dy in (-1,0,1) for dx in (-1,0,1))
            keep = keep | ((n>=5) & raw)
        return keep

    def set_mm_per_pixel(self, value):
        try:
            v=float(value)
            self._mm_per_pixel=v if np.isfinite(v) and v>0 else None
        except Exception:
            self._mm_per_pixel=None
        self._draw_ruler()

    def _clear_ruler(self):
        for item in self._ruler_items:
            try: self.view.removeItem(item)
            except Exception: pass
        self._ruler_items=[]

    def _draw_ruler(self):
        # Legacy GraphicsItems are removed; the real ruler is a screen-fixed
        # QWidget overlay so it cannot drift with image coordinates on zoom.
        self._clear_ruler()
        if self._shape is None or self._mm_per_pixel is None:
            self.ruler_overlay.update_scale(None)
            return
        try:
            data_units_per_screen_px=abs(float(self.view.plotItem.vb.viewPixelSize()[1]))
            if not np.isfinite(data_units_per_screen_px) or data_units_per_screen_px<=0:
                raise ValueError
            image_pixels_for_5mm=5.0/float(self._mm_per_pixel)
            screen_length_px=image_pixels_for_5mm/data_units_per_screen_px
        except Exception:
            self.ruler_overlay.update_scale(None)
            return
        self.ruler_overlay.update_scale(screen_length_px)
        self.ruler_overlay.place_at_right()

    def set_roi(self,center_x,center_y,radius=None,width=None,height=None):
        if center_x is None or center_y is None:
            self.target_circle.setVisible(False); self.roi_box.setVisible(False); return
        # Display ROI is a 4 mm diameter circle whenever pixel spacing is known.
        # If spacing is unavailable, keep the legacy 20 px fallback rather than
        # inventing a physical scale.
        circle_w=(4.0/self._mm_per_pixel) if self._mm_per_pixel else 20.0
        circle_h=circle_w
        yd=self._data_to_display_y(center_y)
        self.target_circle.setPos((center_x-circle_w/2.0,yd-circle_h/2.0),update=False)
        self.target_circle.setSize((circle_w,circle_h),update=False); self.target_circle.setVisible(True)
        square_w=max(1.0,float(width or 3.0)); square_h=max(1.0,float(height or 3.0))
        self.roi_box.setPos((center_x-square_w/2.0,yd-square_h/2.0),update=False)
        self.roi_box.setSize((square_w,square_h),update=False); self.roi_box.setVisible(True)

    def show_measure_roi(self):
        if self._shape is None:
            return
        diameter = max(8.0, float(min(self._shape[0], self._shape[1])) / 4.0)
        center_x = float(self._shape[1]) / 2.0
        center_y = float(self._shape[0]) / 2.0
        self.measure_roi.setPos((center_x - diameter / 2.0, self._data_to_display_y(center_y) - diameter / 2.0), update=False)
        self.measure_roi.setSize((diameter, diameter), update=False)
        self.measure_roi.show()
        self._update_measurement()

    def hide_measure_roi(self):
        self.measure_roi.hide(); self.measure_label.hide(); self._last_measurement = None

    def _measurement_bounds(self):
        pos = self.measure_roi.pos(); size = self.measure_roi.size()
        x0 = max(0, min(int(np.floor(pos.x())), self._shape[1]-1))
        y0 = max(0, min(int(np.floor(self._display_to_data_y(pos.y()))), self._shape[0]-1))
        x1 = max(x0+1, min(int(np.ceil(pos.x()+size.x())), self._shape[1]))
        y1 = max(y0+1, min(int(np.ceil(self._display_to_data_y(pos.y())+size.y())), self._shape[0]))
        return y0, y1, x0, x1

    def _measurement_mask(self, y0, y1, x0, x1):
        pos = self.measure_roi.pos(); size = self.measure_roi.size()
        radius_x = max(float(size.x()) / 2.0, 0.5)
        radius_y = max(float(size.y()) / 2.0, 0.5)
        center_x = float(pos.x()) + radius_x
        center_y = float(self._display_to_data_y(pos.y())) + radius_y
        yy, xx = np.mgrid[y0:y1, x0:x1]
        mask = ((xx + 0.5 - center_x) / radius_x) ** 2 + ((yy + 0.5 - center_y) / radius_y) ** 2 <= 1.0
        return mask, center_x, center_y, radius_x, radius_y

    def _update_measurement(self):
        if not self.measure_roi.isVisible() or self._measurement_array is None or self._shape is None:
            return
        array = np.asarray(self._measurement_array, float)
        y0, y1, x0, x1 = self._measurement_bounds()
        values = np.asarray(array[y0:y1, x0:x1], float)
        mask, center_x, center_y, radius_x, radius_y = self._measurement_mask(y0, y1, x0, x1)
        if values.shape != mask.shape:
            mask = np.ones(values.shape, dtype=bool)
        finite = values[mask]
        finite = finite[np.isfinite(finite)]
        if finite.size == 0:
            self.measure_label.setText("ROI: no finite values")
            self.measure_label.setPos(x0+2, self._data_to_display_y(y0)+2)
            self.measure_label.show()
            return
        diameter_px = float((radius_x*2.0 + radius_y*2.0) / 2.0)
        result = {
            "source": self._measurement_name,
            "x": x0, "y": y0,
            "center_x": float(center_x), "center_y": float(center_y),
            "width_px": int(x1-x0), "height_px": int(y1-y0),
            "diameter_px": diameter_px, "area_px": int(mask.sum()), "pixels": int(finite.size),
            "mean": float(np.mean(finite)), "std": float(np.std(finite)),
            "median": float(np.median(finite)), "min": float(np.min(finite)), "max": float(np.max(finite)),
        }
        unit = "°C" if self._measurement_name.lower().startswith("temperature") else "a.u."
        text = (
            f"{self._measurement_name} Circle ROI\n"
            f"Cx:{center_x:.1f}  Cy:{center_y:.1f}  Ø {diameter_px:.1f} px  N={finite.size}\n"
            f"Mean {result['mean']:.3f} {unit}   SD {result['std']:.3f}   Median {result['median']:.3f}\n"
            f"Min {result['min']:.3f}   Max {result['max']:.3f}"
        )
        self._last_measurement = result
        self.measure_label.setText(text); self.measure_label.setPos(x0+2, self._data_to_display_y(y0)+2); self.measure_label.show()
        self.measurementChanged.emit(result)

    def copy_measurement(self):
        if self._last_measurement is None:
            self._update_measurement()
        if self._last_measurement is None:
            return
        r = self._last_measurement
        fields = [
            f"Source={r['source']}", f"X={r['x']}", f"Y={r['y']}",
            f"CenterX={r['center_x']:.6g}", f"CenterY={r['center_y']:.6g}",
            f"Width(px)={r['width_px']}", f"Height(px)={r['height_px']}",
            f"Diameter(px)={r['diameter_px']:.6g}", f"Area(px)={r['area_px']}", f"Pixels={r['pixels']}",
            f"Mean={r['mean']:.8g}", f"SD={r['std']:.8g}", f"Median={r['median']:.8g}",
            f"Min={r['min']:.8g}", f"Max={r['max']:.8g}",
        ]
        QApplication.clipboard().setText("	".join(fields))

    def fit_image(self): self.view.autoRange(padding=0.01)

    def magnitude_levels(self):
        levels=self.magnitude_item.getLevels()
        return tuple(map(float,levels)) if levels is not None else None

    def set_magnitude_levels(self, levels):
        if levels is not None:
            try:
                self.magnitude_item.setLevels(tuple(map(float, levels)))
            except Exception:
                pass

    def set_overlay(self,magnitude,temperature,magnitude_levels=None,temperature_levels=None,temperature_lut=None,opacity=0.55,hotspot=None,hotspot_text=None,temperature_threshold=None,fit=False,solid_red_fill=False):
        if magnitude is None:
            self.magnitude_item.clear(); self._measurement_array = None
        else:
            mag=np.asarray(magnitude); self._shape=mag.shape[:2]; self.magnitude_item.setLookupTable(None)
            self.magnitude_item.setImage(mag,autoLevels=magnitude_levels is None,levels=magnitude_levels)
            self._measurement_array = np.asarray(mag, float); self._measurement_name = "Magnitude"
        if temperature is None:
            self.temperature_item.clear()
        else:
            temp=np.asarray(temperature,float); self._shape=temp.shape[:2]; shown=temp if temperature_threshold is None else np.where(temp>=temperature_threshold,temp,np.nan)
            if solid_red_fill and temperature_threshold is not None:
                mask=self._focused_threshold_mask(temp,float(temperature_threshold),hotspot=hotspot)
                # Threshold classification is intentionally binary. Do not blur the
                # temperature mask itself: pixels >= threshold are red and pixels
                # below threshold remain untouched. SmoothPixmapTransform on the
                # image view supplies only the final display-pixel antialiasing.
                alpha=mask.astype(float)
                rgba=np.zeros((temp.shape[0],temp.shape[1],4),dtype=np.ubyte)
                rgba[...,0]=255; rgba[...,1]=0; rgba[...,2]=0
                rgba[...,3]=(alpha*255.0*max(0.0,min(1.0,opacity))).astype(np.ubyte)
                self.temperature_item.setLookupTable(None)
                self.temperature_item.setImage(rgba,autoLevels=False)
                self.temperature_item.setOpacity(1.0)
            else:
                self.temperature_item.setImage(shown,autoLevels=temperature_levels is None,levels=temperature_levels)
                self.temperature_item.setLookupTable(temperature_lut); self.temperature_item.setOpacity(max(0.0,min(1.0,opacity)))
            self._measurement_array = np.asarray(shown, float); self._measurement_name = "Temperature"
        self._draw_ruler()
        if self.measure_roi.isVisible():
            self._update_measurement()
        if fit: self.fit_image()

    def set_mr_annotation(self, data: dict | None):
        """Update display-only MR annotations without touching image decoding/LUT state."""
        payload = dict(data or {})
        self.annotation_overlay.set_data(payload)
        shape = payload.get("shape") or self._shape
        try:
            if shape is not None and len(shape) >= 2:
                rows, cols = int(shape[0]), int(shape[1])
                if rows > 0 and cols > 0:
                    self.annotation_center.setPos(QPointF((cols - 1) / 2.0, (rows - 1) / 2.0))
                    self.annotation_center.show()
                    return
        except Exception:
            pass
        self.annotation_center.hide()

    def set_colored_mask_overlay(self, magnitude, mask, color=(120,255,90), opacity=0.72, magnitude_levels=None, fit=False):
        """Render a scalar registration mask as deterministic RGBA.

        This bypasses ImageItem LUT state left by Thermal/ΔT modes.  Reusing the
        same secondary ImageItem with a scalar LUT allowed a previous temperature
        LUT to leak into Registration, producing white/orange block artifacts.
        """
        if magnitude is None:
            self.magnitude_item.clear(); self._measurement_array=None
        else:
            mag=np.asarray(magnitude); self._shape=mag.shape[:2]; self.magnitude_item.setLookupTable(None)
            self.magnitude_item.setImage(mag,autoLevels=magnitude_levels is None,levels=magnitude_levels)
            self._measurement_array=np.asarray(mag,float); self._measurement_name="Magnitude"
        if mask is None:
            self.temperature_item.clear()
        else:
            arr=np.asarray(mask,float)
            finite=np.isfinite(arr)
            vals=arr[finite]
            if not vals.size:
                self.temperature_item.clear()
            else:
                lo,hi=np.percentile(vals,[5,99])
                if hi<=lo: hi=lo+1.0
                norm=np.zeros_like(arr,float)
                norm[finite]=np.clip((arr[finite]-lo)/(hi-lo),0.0,1.0)
                alpha=self._smooth_binary_mask(norm,passes=2)
                rgba=np.zeros((arr.shape[0],arr.shape[1],4),dtype=np.ubyte)
                rgba[...,0]=int(color[0]); rgba[...,1]=int(color[1]); rgba[...,2]=int(color[2])
                rgba[...,3]=(alpha*255.0*max(0.0,min(1.0,float(opacity)))).astype(np.ubyte)
                self.temperature_item.setLookupTable(None)
                self.temperature_item.setImage(rgba,autoLevels=False)
                self.temperature_item.setOpacity(1.0)
        self._draw_ruler()
        if fit: self.fit_image()
