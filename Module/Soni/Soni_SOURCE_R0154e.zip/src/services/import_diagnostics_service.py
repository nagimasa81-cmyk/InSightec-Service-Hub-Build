from __future__ import annotations

from collections import Counter
from dataclasses import asdict
from pathlib import Path
from typing import Any

from src.common.constants import APP_VERSION, APP_COMMIT
from src.services.acoustic_control_service import AcousticControlService
from src.services.sonication_evidence_service import SonicationEvidenceService
from src.services.spectrum_dump_import_service import SpectrumDumpImportService


class ImportDiagnosticsService:
    """Build a compact, content-free report for import/binding failures.

    The report deliberately contains metadata only: relative file names, sizes,
    counts, parsed clocks/session identities and mapping evidence.  It never
    copies treatment payload bytes, MR images, Spectrum samples or log text.
    """

    _RELEVANT_NAMES = (
        "sonicationsummary", "spotsonicationdata", "acquisition_brain",
        "sonication_brain", "spectrummsg", "spectrum_", "skullmeasures",
        "channelmeasure", "calibration", "cavitation", "powergraph",
    )

    @staticmethod
    def _rel(path: Path | None, root: Path) -> str | None:
        if path is None:
            return None
        try:
            return Path(path).resolve().relative_to(root.resolve()).as_posix()
        except Exception:
            return Path(path).name

    @staticmethod
    def _safe_size(path: Path | None) -> int | None:
        if path is None:
            return None
        try:
            return int(Path(path).stat().st_size)
        except Exception:
            return None

    @classmethod
    def _is_relevant(cls, path: Path) -> bool:
        low = path.name.lower()
        if path.suffix.lower() == ".zip":
            return True
        return any(token in low for token in cls._RELEVANT_NAMES)

    def build(self, package) -> dict[str, Any]:
        root = Path(package.workspace)
        errors: list[str] = []
        files: list[Path] = []
        try:
            files = [p for p in root.rglob("*") if p.is_file()]
        except Exception as exc:
            errors.append(f"workspace inventory failed: {type(exc).__name__}: {exc}")

        suffix_counts = Counter((p.suffix.lower() or "<none>") for p in files)
        relevant_files = [p for p in files if self._is_relevant(p)]
        relevant_inventory = [
            {
                "path": self._rel(p, root),
                "size": self._safe_size(p),
            }
            for p in sorted(relevant_files, key=lambda x: str(x).lower())
        ]

        acoustic = AcousticControlService()
        acq_candidates = sorted(root.rglob("Acquisition_Brain_*.txt"), key=lambda p: str(p).lower())
        selected_acq = None
        sessions = []
        try:
            selected_acq = acoustic.find_log(root)
            sessions = acoustic.parse_segments(selected_acq) if selected_acq is not None else []
        except Exception as exc:
            errors.append(f"Acquisition_Brain selection/parse failed: {type(exc).__name__}: {exc}")

        acq_rows = []
        for p in acq_candidates:
            stamp = acoustic._log_stamp(p)
            acq_rows.append({
                "path": self._rel(p, root),
                "size": self._safe_size(p),
                "filename_timestamp": stamp.isoformat(sep=" ") if stamp is not None else None,
                "selected": bool(selected_acq is not None and p.resolve() == selected_acq.resolve()),
            })

        session_rows = []
        for idx, segment in enumerate(sessions):
            vals = [float(s.elapsed_s) for s in segment.samples]
            session_rows.append({
                "index": idx,
                "start_clock_s": float(segment.start_clock_s),
                "sample_count": len(segment.samples),
                "last_elapsed_s": max(vals) if vals else None,
            })

        dump_service = SpectrumDumpImportService()
        candidates = []
        mapping = {}
        try:
            candidates = dump_service.discover(root)
            mapping = dump_service.map_candidates_to_sonications(candidates, list(package.sonications), workspace=root)
        except Exception as exc:
            errors.append(f"CPC discovery/mapping failed: {type(exc).__name__}: {exc}")

        candidate_rows = []
        for c in candidates:
            candidate_rows.append({
                "family": c.family,
                "relative_path": c.relative_path,
                "completeness": c.completeness,
                "raw_size": self._safe_size(c.raw_path),
                "fft_size": self._safe_size(c.fft_path),
                "filename_clock_s": dump_service._candidate_clock_s(c),
                "acquisition_session_index": c.acquisition_session_index,
                "acquisition_session_end_error_s": c.acquisition_session_end_error_s,
                "mapping_confidence": c.mapping_confidence,
                "mapping_evidence": c.mapping_evidence,
            })

        setup_records = []
        try:
            records = SonicationEvidenceService().parse_setup_records(root)
            for row in records:
                setup_records.append({
                    "sonication_index": getattr(row, "sonication_index", None),
                    "clock_s": getattr(row, "clock_s", None),
                    "source": self._rel(getattr(row, "source", None), root),
                    "steering_xyz": list(getattr(row, "steering_xyz", ()) or ()),
                })
        except Exception as exc:
            errors.append(f"Sonication_Brain setup parse failed: {type(exc).__name__}: {exc}")

        sonications = []
        for pos, son in enumerate(package.sonications, start=1):
            number = int(getattr(son, "sonication_number", 0) or pos)
            mapped = mapping.get(number)
            sonications.append({
                "number": number,
                "synthetic_identity": bool(getattr(son, "synthetic_identity", False)),
                "physical_folder_count": len(getattr(son, "evidence_folders", []) or []),
                "identity_evidence": list(getattr(son, "identity_evidence", []) or []),
                "spectrummsg_files": len(getattr(son, "spectrum_files", []) or []),
                "act_files": len(getattr(son, "act_files", []) or []),
                "canonical_acquisition_session_index": getattr(son, "canonical_acquisition_session_index", None),
                "canonical_mapping_confidence": getattr(son, "canonical_mapping_confidence", None),
                "canonical_mapping_evidence": list(getattr(son, "canonical_mapping_evidence", []) or []),
                "mapped_cpc": mapped.relative_path if mapped is not None else None,
                "mapped_cpc_confidence": mapped.mapping_confidence if mapped is not None else None,
                "mapped_cpc_evidence": mapped.mapping_evidence if mapped is not None else None,
                "mr_timeline_source": getattr(son, "mr_timeline_source", None),
                "mr_timeline_confidence": getattr(son, "mr_timeline_confidence", None),
                "mr_sonication_start_s": getattr(son, "mr_sonication_start_s", None),
                "mr_sonication_end_s": getattr(son, "mr_sonication_end_s", None),
                "clock_sync_status": getattr(son, "clock_sync_status", None),
                "cpc_to_ws_clock_offset_s": getattr(son, "cpc_to_ws_clock_offset_s", None),
                "clock_sync_anchor_count": getattr(son, "clock_sync_anchor_count", None),
                "clock_sync_spread_s": getattr(son, "clock_sync_spread_s", None),
            })

        return {
            "schema": "Soni import diagnostics v1",
            "app_version": APP_VERSION,
            "app_commit": APP_COMMIT,
            "privacy": "Metadata only. No treatment payload bytes, MR images, Spectrum samples, or log text are included.",
            "source": {
                "kind": "zip" if Path(package.source).suffix.lower() == ".zip" else "folder",
                "name": Path(package.source).name,
                "workspace_file_count": len(files),
                "suffix_counts": dict(sorted(suffix_counts.items())),
                "nested_zip_count": sum(1 for p in files if p.suffix.lower() == ".zip"),
            },
            "import_audit": dict(getattr(package, "import_audit", {}) or {}),
            "acquisition_brain": {
                "candidate_count": len(acq_candidates),
                "selected": self._rel(selected_acq, root),
                "candidates": acq_rows,
                "parsed_sessions": session_rows,
            },
            "sonication_brain": {
                "setup_record_count": len(setup_records),
                "setup_records": setup_records,
            },
            "cpc": {
                "candidate_count": len(candidates),
                "physical_candidate_count": sum(c.family == "CPC Spectrum" for c in candidates),
                "spectrummsg_candidate_count": sum(c.family == "SpectrumMsg" for c in candidates),
                "mapped_count": len(mapping),
                "candidates": candidate_rows,
            },
            "sonications": sonications,
            "relevant_file_inventory": relevant_inventory,
            "diagnostic_errors": errors,
        }
