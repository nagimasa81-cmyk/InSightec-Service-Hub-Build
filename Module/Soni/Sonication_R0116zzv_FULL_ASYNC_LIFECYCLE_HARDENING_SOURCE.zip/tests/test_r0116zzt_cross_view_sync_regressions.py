from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MAIN=(ROOT/'src/ui/main_window.py').read_text(encoding='utf-8')
PANEL=(ROOT/'src/ui/image_panel.py').read_text(encoding='utf-8')
HYDRO=(ROOT/'src/ui/hydrophone_window.py').read_text(encoding='utf-8')


def block(text, name):
    start=text.index(f'def {name}')
    tail=text[start+4:]
    nxt=tail.find('\n    def ')
    return text[start:] if nxt<0 else text[start:start+4+nxt]


def test_registration_uses_deterministic_rgba_mask_not_thermal_lut():
    assert 'def set_colored_mask_overlay' in PANEL
    assert 'self.overlay.set_colored_mask_overlay' in block(MAIN,'_apply_registration_overlay')


def test_temperature_controls_do_not_repaint_planning_reference_as_thermal():
    for name in ('_temperature_mode_changed','_threshold_changed'):
        b=block(MAIN,name)
        assert '_is_registration_reference_mode()' in b
        assert '_apply_registration_overlay()' in b


def test_planning_mr_thumbnails_are_lazy_low_priority_after_replay_ready():
    assert 'def _start_visible_reference_thumbnail_background' in MAIN
    b=block(MAIN,'_start_visible_reference_thumbnail_background')
    assert 'QThread.Priority.LowPriority' in b
    assert '_reference_thumbnail_cache' in b


def test_on_demand_planning_decode_backfills_thumbnail_cache():
    b=block(MAIN,'_planning_array_for_asset')
    assert '_reference_thumbnail_cache[key]' in b
    assert '_apply_ready_thumbnail_to_visible_items("reference"' in b


def test_summary_thermometry_is_second_background_pass():
    detail=block(MAIN,'_build_one_sonication_summary')
    assert 'self.replay.temperature_metrics(son)' not in detail
    assert 'class SonicationSummaryTemperatureWorker' in MAIN
    temp=block(MAIN,'_build_one_sonication_temperature_summary')
    assert 'self.replay.temperature_metrics(son)' in temp


def test_relative_time_chart_clicks_return_to_replay_and_add_irradiation_start():
    for name in ('_acoustic_plot_clicked','_waterfall_plot_clicked','_cavitation_plot_clicked'):
        b=block(MAIN,name)
        assert '_activate_replay_mode_for_navigation()' in b
        assert 'irradiation_start' in b


def test_probable_region_is_gated_by_detected_event():
    b=block(MAIN,'_draw_ci_linked_rcv_probable')
    assert '_nearest_observed_cavitation_event' in b
    assert 'no detected event' in b
    assert 'return' in b


def test_spectrum_analyzer_always_acknowledges_open_with_progress():
    b=block(MAIN,'_open_hydrophone_window')
    assert '_set_subwindow_progress(2,"Opening Spectrum Dump Analyzer…")' in b


def test_empty_control_timeline_explains_missing_source_data_without_faking_curve():
    b=block(HYDRO,'_draw_observed_cavitation_timeline')
    assert 'No observed cavitation-control action / power-response data' in b


def test_nearest_cavitation_event_excludes_increase_and_non_cavitation_events():
    b=block(MAIN,'_nearest_observed_cavitation_event')
    assert 'family=="increase"' in b
    assert 'counts is False' in b
