# Commit 0017d

## Hybrid build failure fix

GitHub Hybrid build reached the integrated FUS Image Explore Nuitka stage and failed with:

`FATAL: Error, failed to locate package 'pylibjpeg_libjpeg' you asked to include.`

The installed PyPI distributions are named `pylibjpeg-libjpeg` and
`pylibjpeg-openjpeg`, but their importable Python packages are `libjpeg`
and `openjpeg`.

### Changes

- `integrated_sources/FUSImageExplore/03_BUILD_NUITKA_STANDALONE.bat`
  - changed `--include-package=pylibjpeg_libjpeg` to `--include-package=libjpeg`
  - changed `--include-package=pylibjpeg_openjpeg` to `--include-package=openjpeg`
  - added a pre-build import probe for `pylibjpeg`, `libjpeg`, and `openjpeg`
- Kept `--include-package=pylibjpeg`
- No Hybrid UI behavior or tool routing was changed.
- No decoder runtime behavior was changed.

### Evidence

The source decoder manager already checks the correct import names
`libjpeg` and `openjpeg`; only the Nuitka build command used the wrong
distribution-derived names.
