\
from pathlib import Path

root = Path(__file__).resolve().parent
bat = root / "integrated_sources" / "FUSImageExplore" / "03_BUILD_NUITKA_STANDALONE.bat"
decoder = root / "integrated_sources" / "FUSImageExplore" / "decoder_manager.py"

build_text = bat.read_text(encoding="utf-8-sig", errors="replace")
decoder_text = decoder.read_text(encoding="utf-8-sig", errors="replace")

required_build = (
    "--include-package=pylibjpeg",
    "--include-package=libjpeg",
    "--include-package=openjpeg",
)
for token in required_build:
    if token not in build_text:
        raise SystemExit(f"FAIL: missing build token: {token}")

for forbidden in ("--include-package=pylibjpeg_libjpeg", "--include-package=pylibjpeg_openjpeg"):
    if forbidden in build_text:
        raise SystemExit(f"FAIL: obsolete invalid Nuitka package token remains: {forbidden}")

for module in ('_has_module("pylibjpeg")', '_has_module("libjpeg")', '_has_module("openjpeg")'):
    if module not in decoder_text:
        raise SystemExit(f"FAIL: decoder contract token missing: {module}")

print("PASS: FUS Image Explore decoder/Nuitka package contract is consistent.")
