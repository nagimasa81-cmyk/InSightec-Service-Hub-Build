# Commit 0017j — Repository Preflight Compatibility

The repository preflight currently requires exactly one root `main.py` for
`InSightec_Service_hub`, while Contract Audit requires the explicit
`InSightecServiceHub.py` Service Hub entry.

This commit keeps the actual build path canonical:

`Build_Hub_EXE_PyInstaller.bat / 01_BUILD_EXE.bat`
→ `Build_Hub_EXE.py`
→ `InSightecServiceHub.py`

A root `main.py` is restored only as a thin compatibility shim for the
repository preflight. `Build_Hub_EXE.py` does not select or reference it.
