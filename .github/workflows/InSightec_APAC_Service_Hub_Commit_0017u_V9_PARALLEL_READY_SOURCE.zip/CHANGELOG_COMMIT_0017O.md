# Commit 0017o — Simple Unified Tools UI

Primary Tools screen is reduced to the essentials:
- Drop/select ZIP or folder
- Select All / Clear All
- Tool checkbox
- Direct Launch
- Vertical scrolling

Removed from the primary Tools screen:
- Tool Validation
- Open Hub Folder
- Open Logs Folder
- Refresh
- Recommended selector

Existing ZIP handoff, direct launch, runtime callback fixes and build contracts are unchanged.
