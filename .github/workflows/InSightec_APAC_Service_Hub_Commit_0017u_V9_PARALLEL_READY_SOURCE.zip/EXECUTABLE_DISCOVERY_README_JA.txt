Commit 0010 - Resilient Executable Discovery

ツール起動EXEは単一の固定ファイル名だけに依存しません。
各 tools/<Tool>/manifest.json の以下を利用します。

- exe: 推奨名（互換用）
- executable_candidates: 優先候補名
- executable_patterns: 名前の正規表現
- executable_exclude: Debug、Console、Updaterなどの除外語

解決順序:
1. Toolフォルダ直下の候補名
2. サブフォルダ内の候補名
3. 全EXEをスコアリングして最適な起動対象を選択

Sonication Analysis:
- Sonication Replay Engine RC2-R0014 sourceを integrated_sources/SonicationAnalysis に統合
- main.py / src/app/application.py は --handoff JSONに対応
- workspace_pathを優先して自動ロード
- GitHub Actions用 build_config.json / version.json metadataを追加

YML:
R5_RESILIENT_EXECUTABLE_DISCOVERY.yml は、ビルド成果物EXEを固定名だけでなく
候補・除外・サイズ・出力フォルダから選択します。
