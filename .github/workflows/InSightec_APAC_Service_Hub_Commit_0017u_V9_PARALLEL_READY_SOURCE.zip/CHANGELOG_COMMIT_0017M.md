# Commit 0017m — Runtime Callback Integrity Fix

The built Hub crashed at startup because `_audit_geometry_managers` was still
scheduled from `HubApp.__init__()` after its method definition had been removed
during UI cleanup.

A class-wide callback audit found four additional missing callable helpers:
`choose_auto_dataset`, `choose_auto_folder`, `on_auto_dataset_drop`, and
`release_notes_text`.

All five are restored. Dashboard is not restored; Tools remains the single UI.
