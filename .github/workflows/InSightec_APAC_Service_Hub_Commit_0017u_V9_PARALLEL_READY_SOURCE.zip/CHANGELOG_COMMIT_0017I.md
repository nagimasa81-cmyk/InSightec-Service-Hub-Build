# Commit 0017i — Canonical Hub Entry Contract

- Canonical Hub application entry point is `InSightecServiceHub.py`.
- `Build_Hub_EXE.py` explicitly references `InSightecServiceHub.py`.
- Removed redundant root `main.py` wrapper.
- Both `01_BUILD_EXE.bat` and `Build_Hub_EXE_PyInstaller.bat` delegate to the same `Build_Hub_EXE.py`.
- Unified Tools UI and Hybrid checkbox ZIP routing are unchanged.
