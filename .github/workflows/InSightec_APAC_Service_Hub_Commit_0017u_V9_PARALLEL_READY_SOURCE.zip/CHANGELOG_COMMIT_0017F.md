# Commit 0017f — Unified Tools UI

## UI contract

- Dashboard is removed from navigation and normal operation.
- Hybrid Home is removed as a separate page.
- Auto Dataset Analyzer is removed as a separate navigation page.
- **Tools** is the single operational UI.

The Tools page contains:

- ZIP/folder drop zone
- Select ZIP / Select Folder
- tool checkboxes for dataset routing
- Select All / Clear All / Recommended
- per-tool status
- per-tool direct **Launch**
- per-tool **Information**
- Tool Validation
- Open Hub Folder
- Open Logs Folder
- Refresh

## Behavior

- Direct card Launch opens only that tool.
- ZIP/folder routing launches every checked tool with the same prepared dataset.
- Detection is advisory only.
- Legacy requests for Dashboard/Hybrid/Auto Analyzer are redirected to Tools.
