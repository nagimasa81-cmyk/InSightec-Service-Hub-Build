# Commit 0013

## VIMeasure source integration

- Integrated VIMeasure Analyzer Ver7 source under `integrated_sources/VIMeasure`.
- Added native Hub handoff v1 receiver through command line and environment variable.
- Added automatic multi-file loading and immediate chart analysis.
- Replaced filename-dependent discovery with content inspection of the data header, timestamp rows, and V/I labels.
- Preserved manual file and folder import.
- Guide and tour functionality remains removed.

## Validation

- Python source compilation check.
- JSON and YAML parse check.
- Synthetic handoff and content-detection test.
- Manifest/executable-discovery consistency check.
- Final ZIP integrity and clean extraction check.
