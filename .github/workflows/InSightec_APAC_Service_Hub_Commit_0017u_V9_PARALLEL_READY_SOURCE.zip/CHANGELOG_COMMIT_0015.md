# Commit 0015

- Build all six integrated tool EXEs during Hub build.
- Package outputs under tools/<tool>.
- Fail incomplete Hub builds.
- Show Installed / Missing EXE status in Auto Dataset Analyzer.
