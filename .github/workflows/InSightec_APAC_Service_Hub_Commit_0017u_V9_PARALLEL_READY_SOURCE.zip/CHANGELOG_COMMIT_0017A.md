# Commit 0017a — Canonical Build Entry Point

- Adds an exact root-level `main.py` required by the repository preflight/build contract.
- `main.py` is a thin launcher only; the application implementation remains in `InSightecServiceHub.py`.
- Preserves legacy launchers and Hybrid Main UI behavior from Commit 0017.
- Intended to fix preflight failure: `Entry point exact: Expected exactly 1 'main.py', found 0`.
