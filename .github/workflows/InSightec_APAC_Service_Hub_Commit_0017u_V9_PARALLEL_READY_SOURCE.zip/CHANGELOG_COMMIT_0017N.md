# Commit 0017n — Scrollable Unified Tools UI

- Entire Tools surface is wrapped in one Canvas + vertical Scrollbar.
- ZIP drop, management buttons, all tool cards and lower status sections scroll together.
- Mouse wheel/touchpad scrolling works while hovering the page.
- Linux Button-4/Button-5 wheel events are also supported.
- Inner content width follows the visible viewport.
- Scroll bindings are removed when switching pages.
- Tools opens at the top each time.
