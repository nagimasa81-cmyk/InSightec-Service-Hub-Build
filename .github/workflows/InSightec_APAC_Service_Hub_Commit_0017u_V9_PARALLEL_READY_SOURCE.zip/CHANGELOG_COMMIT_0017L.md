# Commit 0017l — Windows CMD Integration Fix

The Hub executable itself built successfully on GitHub Windows.

The integrated tool stage failed before DO Analysis executed because the
command was constructed as a nested quoted `/s /c` string and Windows `cmd`
treated escaped quotes as part of the command name.

The launcher now passes `call` and the BAT path as separate argv items:

`cmd.exe /d /c call <BAT_PATH>`

This applies to all six integrated tools.
