# Commit 0017q — Integrated Tool Selection Contract Fix

Observed GitHub failure:
- top-level build reported `include_sonication=false`
- external Sonication stages were correctly skipped
- Hub internal `Build_Integrated_Tools.py` still built Sonication Analysis
- Sonication `.venv` then failed with `No module named pytest`

Fixes:
- `Build_Integrated_Tools.py` honors `INPUT_INCLUDE_SONICATION`,
  `INSIGHTEC_INCLUDE_SONICATION`, and `INSIGHTEC_EXCLUDE_SONICATION`.
- Disabled Sonication is recorded as `skipped`, not as a missing/failed tool.
- `all_ready` is evaluated only against enabled tools.
- When Sonication is included, its verify/build BAT installs pytest explicitly.
