# Commit 0017s — FUS Runtime Copy Integrity Fix

Run 15 proved:
- PySide6 / QtOpenGL / pyqtgraph build-environment imports PASS.
- Nuitka standalone compilation PASS.
- Nuitka created MRI_Raw_FFT_Explorer.exe.
- Immediately afterward Windows printed `Insufficient memory`.
- Packaged EXE smoke then timed out.

The old BAT used `xcopy` to duplicate the entire Nuitka standalone directory
and did not check the xcopy return code. A partial runtime could therefore be
accepted and smoke-tested.

Fix:
- Remove xcopy completely.
- Copy with Python `shutil.copytree`.
- Verify source/destination file count and total bytes are identical.
- Verify EXE and required Qt6 DLLs / pyqtgraph resources exist.
- Fail before smoke/cache if packaging is incomplete.
- Disable startup guide dialogs during smoke.
- Allow 90 seconds for full MainWindow construction on GitHub Windows runners.
