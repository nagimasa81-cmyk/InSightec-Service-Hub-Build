# Commit 0017t — Headless-Safe Two-Stage FUS Smoke

Run 17 proved the packaged directory is byte-identical and contains all required
Qt/OpenGL/pyqtgraph runtime files, but the full MainWindow constructor did not
complete within 90 seconds on the GitHub offscreen runner.

The previous quit timer was scheduled only *after* `MainWindow()` returned, so
it could never stop a slow constructor.

New validation:
1. REQUIRED frozen runtime probe
   - imports the full frozen `app` module
   - therefore imports PySide6, QtOpenGL and pyqtgraph
   - creates QApplication
   - loads the Qt platform plugin
   - creates/shows a basic QWidget
   - enters the Qt event loop
   - exits cleanly
   - failure blocks build/cache
2. OPTIONAL full MainWindow diagnostic
   - still attempts real MainWindow startup
   - timeout is recorded as WARN on headless CI, not as a packaging failure

This preserves protection against the original pyqtgraph/PySide6 runtime error
without rejecting a valid package solely because the full UI is slow under
GitHub's headless/offscreen environment.
