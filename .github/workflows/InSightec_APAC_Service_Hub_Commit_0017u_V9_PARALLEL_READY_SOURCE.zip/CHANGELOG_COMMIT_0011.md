# Commit 0011

- Preserves user tool checkbox selections.
- Drop analysis no longer overwrites selections.
- Auto launch runs only selected tools with detected data.
- Added Auto launch after drop and Open Selected Tools.
- Added handoff loading to DO Analysis, TrackerSNR, Log Explore and FUS Image Explore.
- Retained Sonication Analysis handoff support.
- Added environment-variable fallback for VIMeasure and all tools.
- Removed Hub common guide/tour package and startup guide UI from integrated sources.
