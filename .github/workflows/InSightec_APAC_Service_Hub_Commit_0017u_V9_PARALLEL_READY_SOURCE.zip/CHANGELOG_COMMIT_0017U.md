# Commit 0017u — V9 Parallel Build Ready

- Adds `Fast_Preflight_All_Tools.py` to catch high-value contract/syntax failures before any heavy EXE build.
- `INSIGHTEC_ONLY_TOOL=<tool_id>` restricts integrated build to one matrix tool.
- `INSIGHTEC_PREBUILT_TOOLS_ROOT` lets the Hub overlay validated tool runtimes built by parallel jobs.
- `INSIGHTEC_EXTERNAL_TOOL_ASSEMBLY=1` makes the final Hub assembly preserve those runtimes instead of rebuilding them.
- Existing per-module cache, FUS frozen-runtime probe, Sonication include/exclude contract and true completed-Hub reuse are retained.
