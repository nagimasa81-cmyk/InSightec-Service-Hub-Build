# Commit 0014

- Fixed Auto Dataset Analyzer startup crash caused by mixing `pack` and `grid` under the same card frame.
- Added a dedicated grid-only child frame for detected-tool rows.
- Added a startup geometry-manager audit that logs any future mixed `pack`/`grid` parent.
- Updated `version.json` to Commit 0014.
