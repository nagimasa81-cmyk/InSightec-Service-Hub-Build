\
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path


def startup_log() -> Path:
    return Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "MR_Image_Explorer" / "startup_error.log"


def run_process(exe: Path, env: dict[str, str], timeout: int, label: str) -> tuple[bool, str]:
    print(f"[{label}] starting packaged EXE: {exe}")
    try:
        proc = subprocess.Popen([str(exe)], cwd=str(exe.parent), env=env)
        rc = proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)
        return False, f"timeout after {timeout}s"
    except Exception as exc:
        return False, f"could not start: {type(exc).__name__}: {exc}"

    if rc != 0:
        log = startup_log()
        details = f"exit code {rc}"
        if log.is_file():
            try:
                details += "\n----- startup_error.log -----\n" + log.read_text(encoding="utf-8", errors="replace")
            except Exception:
                pass
        return False, details
    return True, "exit code 0"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("exe", type=Path)
    ap.add_argument("--full-window", action="store_true")
    ns = ap.parse_args()

    exe = ns.exe.resolve()
    if not exe.is_file():
        print(f"[FAIL] packaged EXE missing: {exe}", file=sys.stderr)
        return 3
    if exe.stat().st_size < 100_000:
        print(f"[FAIL] packaged EXE unexpectedly small: {exe.stat().st_size}", file=sys.stderr)
        return 4

    env = os.environ.copy()
    env["QT_QPA_PLATFORM"] = "offscreen"
    env["PYTHONNOUSERSITE"] = "1"

    if ns.full_window:
        env["MRIE_STARTUP_SMOKE_TEST"] = "1"
        ok, detail = run_process(exe, env, 45, "FULL WINDOW DIAGNOSTIC")
        if ok:
            print("[PASS] Full MainWindow smoke completed")
            return 0
        # This diagnostic is intentionally non-fatal for CI. Headless/offscreen
        # runners can make the full MainWindow constructor extremely slow even
        # when the packaged Qt runtime is healthy.
        print(f"[WARN] Full MainWindow smoke did not complete: {detail}")
        return 0

    # Mandatory build gate: prove that the actual frozen EXE can import the
    # application, load PySide6 + pyqtgraph, initialize Qt, show a basic widget,
    # enter the event loop, and exit cleanly.
    env["MRIE_FROZEN_RUNTIME_PROBE"] = "1"
    ok, detail = run_process(exe, env, 30, "REQUIRED FROZEN RUNTIME PROBE")
    if not ok:
        print(f"[FAIL] Packaged runtime probe failed: {detail}", file=sys.stderr)
        return 7

    print("[PASS] Frozen EXE loaded app/PySide6/pyqtgraph, initialized Qt, showed a widget, and exited cleanly")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
