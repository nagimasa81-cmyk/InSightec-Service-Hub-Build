\
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path


def tree_stats(root: Path) -> tuple[int, int]:
    count = 0
    size = 0
    for path in root.rglob("*"):
        if path.is_file():
            count += 1
            size += path.stat().st_size
    return count, size


def require_any(root: Path, patterns: list[str], label: str) -> None:
    for pattern in patterns:
        if any(root.rglob(pattern)):
            print(f"[PASS] {label}: {pattern}")
            return
    raise RuntimeError(f"Required packaged runtime component missing: {label}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("destination", type=Path)
    ns = ap.parse_args()

    source = ns.source.resolve()
    dest = ns.destination.resolve()

    if not source.is_dir():
        raise FileNotFoundError(f"Nuitka standalone directory missing: {source}")

    if dest.exists():
        shutil.rmtree(dest)

    print(f"[COPY] {source}")
    print(f"    -> {dest}")
    shutil.copytree(source, dest, copy_function=shutil.copy2)

    src_count, src_size = tree_stats(source)
    dst_count, dst_size = tree_stats(dest)
    print(f"[COPY VERIFY] source files={src_count:,} bytes={src_size:,}")
    print(f"[COPY VERIFY] target files={dst_count:,} bytes={dst_size:,}")

    if src_count != dst_count:
        raise RuntimeError(
            f"Runtime copy file-count mismatch: source={src_count}, target={dst_count}"
        )
    if src_size != dst_size:
        raise RuntimeError(
            f"Runtime copy byte-count mismatch: source={src_size}, target={dst_size}"
        )

    exe = dest / "MRI_Raw_FFT_Explorer.exe"
    if not exe.is_file() or exe.stat().st_size < 100_000:
        raise RuntimeError(f"Packaged EXE missing or too small: {exe}")

    # Verify components implicated in the prior pyqtgraph/PySide6 startup failure.
    require_any(dest, ["PySide6*.pyd", "PySide6*.dll"], "PySide6 runtime")
    require_any(dest, ["Qt6Core.dll"], "Qt Core")
    require_any(dest, ["Qt6Gui.dll"], "Qt Gui")
    require_any(dest, ["Qt6Widgets.dll"], "Qt Widgets")
    require_any(dest, ["Qt6OpenGL.dll"], "Qt OpenGL")
    require_any(dest, ["Qt6OpenGLWidgets.dll"], "Qt OpenGL Widgets")

    # pyqtgraph is compiled/frozen, but its packaged data resources must exist.
    color_files = list(dest.rglob("*CET*")) + list(dest.rglob("*viridis*"))
    if not color_files:
        # Nuitka layout can preserve package data without those exact filenames.
        pg_dirs = [p for p in dest.rglob("pyqtgraph") if p.is_dir()]
        colors = [p for p in dest.rglob("colors") if p.is_dir()]
        if not pg_dirs and not colors:
            raise RuntimeError("pyqtgraph packaged data directory was not found")
    print("[PASS] pyqtgraph packaged resources detected")

    print("[PASS] Standalone runtime copy is complete and byte-identical")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"[FAIL] {type(exc).__name__}: {exc}", file=sys.stderr)
        raise
