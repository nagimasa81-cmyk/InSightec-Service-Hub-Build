from __future__ import annotations
import argparse, json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def load():
    meta=json.loads((ROOT/'version.json').read_text(encoding='utf-8-sig'))
    version=str(meta['version']).strip(); commit=str(meta['commit']).strip(); artifact=str(meta['artifact_base_name']).strip()
    if not version or not commit or not artifact: raise SystemExit('version.json missing version/commit/artifact_base_name')
    m=re.search(r'(\d+)$',commit)
    build=int(m.group(1)) if m else 0
    return meta, version, commit, artifact, build

def main():
    p=argparse.ArgumentParser(); p.add_argument('--write-bat',type=Path); a=p.parse_args()
    meta,version,commit,artifact,build=load()
    if a.write_bat:
        lines=[
            f'set "APP_NAME={artifact}"',
            f'set "APP_VERSION={version}"',
            f'set "APP_COMMIT={commit}"',
            f'set "BUILD_DIR=build_{commit.lower()}"',
            f'set "FILE_VERSION=2.0.0.{build}"',
            f'set "FILE_DESCRIPTION=Log Merge Tool RC1 {commit}"',
        ]
        a.write_bat.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    else:
        print(json.dumps(meta,ensure_ascii=False))
if __name__=='__main__': main()
