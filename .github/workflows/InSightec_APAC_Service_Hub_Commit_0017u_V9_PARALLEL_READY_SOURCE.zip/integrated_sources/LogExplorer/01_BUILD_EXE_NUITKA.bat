@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "MAIN_PY=LogMergeTool_NoExcel_Main.py"
set "PY=python"
%PY% build_metadata.py --write-bat .build_version_env.bat
if errorlevel 1 exit /b 1
call .build_version_env.bat
if errorlevel 1 exit /b 1
%PY% -m pip install --upgrade pip setuptools wheel
if errorlevel 1 exit /b 1
%PY% -m pip install --upgrade PySide6 openpyxl nuitka ordered-set zstandard
if errorlevel 1 exit /b 1
%PY% -m py_compile "%MAIN_PY%" build_metadata.py
if errorlevel 1 exit /b 1
%PY% tests\test_current_version_contract.py
if errorlevel 1 exit /b 1
%PY% tests\test_current_feature_contract.py
if errorlevel 1 exit /b 1
if exist "%BUILD_DIR%" rmdir /s /q "%BUILD_DIR%"
if not exist dist mkdir dist
%PY% -m nuitka ^
  --standalone ^
  --onefile ^
  --enable-plugin=pyside6 ^
  --windows-console-mode=disable ^
  --assume-yes-for-downloads ^
  --output-dir="%BUILD_DIR%" ^
  --output-filename="%APP_NAME%.exe" ^
  --company-name="InSightec" ^
  --product-name="Log Merge Tool - No Excel" ^
  --file-description="%FILE_DESCRIPTION%" ^
  --file-version=%FILE_VERSION% ^
  --product-version=%FILE_VERSION% ^
  --include-data-file=version.json=version.json ^
  --include-data-file=csa_error_rules.json=csa_error_rules.json ^
  --include-data-file=site_serial_map.json=site_serial_map.json ^
  "%MAIN_PY%"
if errorlevel 1 exit /b 1
copy /y "%BUILD_DIR%\%APP_NAME%.exe" "dist\%APP_NAME%.exe" >nul
if errorlevel 1 exit /b 1
del /q .build_version_env.bat >nul 2>nul
echo [OK] dist\%APP_NAME%.exe
endlocal
