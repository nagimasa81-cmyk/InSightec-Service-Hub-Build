# Commit 0017 - Hybrid Card Launcher + ZIP Drop Main UI

- Added a Hybrid Home page combining direct tool cards and dataset ZIP/folder/file drop.
- Hybrid Home is now the default startup page.
- Reuses the existing Auto Dataset Analyzer and tool launcher instead of duplicating routing logic.
- Dataset detection status is shown directly on each matching tool card.
- Direct card launching remains available before, during, and after dataset inspection.
- Added navigation-safe auto-analysis completion handling so a background scan cannot update destroyed widgets.
- Detailed Auto Dataset Analyzer and full Tools pages remain available for advanced use.
