# Commit 0017b — Help Runtime Build Contract Fix

- Added persistent `help/README.txt` so the required `help/` runtime directory survives ZIP/GitHub packaging.
- Preserved Commit 0017a canonical root `main.py` entry point.
- No Hybrid Main UI behavior changes.
- Aligns `validate_source.py` and `Build_Hub_EXE.py` runtime directory contract.
