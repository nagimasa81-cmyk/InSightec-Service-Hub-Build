# Commit 0017h — Service Hub Contract Compatibility Restore

- Restored `Build_Hub_EXE_PyInstaller.bat` because repository `contract_audit.py` uses it as part of the Service Hub explicit-layout contract.
- The BAT contains no independent build logic; it delegates to the same canonical `Build_Hub_EXE.py` used by `01_BUILD_EXE.bat`.
- No Dashboard, Hybrid duplicate page, Auto Dataset Analyzer page, prebuilt EXE, or Python cache was restored.
- Unified Tools UI remains the only operational launcher/dataset-routing page.
