# Commit 0017e — True Hybrid Home

## Required Hybrid behavior

The Home page has both workflows at the same time:

1. **ZIP Drop / dataset routing**
   - Check the tools to open.
   - Drop/select a ZIP.
   - Hub safely extracts the ZIP.
   - Every checked and packaged tool receives the same extracted dataset roots.
   - Every checked tool launches automatically.
   - Hub detection is advisory only and cannot veto a checked tool.

2. **Direct card launcher**
   - Click a tool card's Launch button.
   - Only that tool launches.
   - No dataset handoff is required.

## Compatibility

All six integrated tools retain the existing `--handoff` contract.
The handoff v2 payload keeps `matched_files` for compatibility, but in Hybrid
it contains the complete prepared dataset roots. Detection-specific files are
stored separately as `detected_files`.
