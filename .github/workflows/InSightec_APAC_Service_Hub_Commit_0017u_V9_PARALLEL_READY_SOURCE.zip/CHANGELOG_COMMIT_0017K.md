# Commit 0017k — End-to-End Build Pipeline Hardening

- Keeps the canonical Hub path: BAT -> Build_Hub_EXE.py -> InSightecServiceHub.py.
- Keeps root main.py only as the repository preflight compatibility shim.
- Removes interactive `pause` behavior during CI for DO Analysis, FUS Image Explore and VIMeasure.
- Makes VIMeasure install and probe its own PySide6/Nuitka dependencies instead of relying on a previous tool build.
- Quotes integrated tool BAT invocation explicitly for paths that may contain spaces.
