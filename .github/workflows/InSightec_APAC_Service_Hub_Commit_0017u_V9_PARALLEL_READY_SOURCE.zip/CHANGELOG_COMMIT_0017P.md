# Commit 0017p — True Reuse / Incremental Integrated Tool Cache

## Complete Hub reuse
Handled by the paired V8 workflow. An exact completed-Hub cache hit skips:
SOURCE reassembly, contract audit, preflight, pip setup, dependency checks,
Hub compilation, and all integrated tool builds.

## Per-module cache
If the complete Hub signature changed, each of the six integrated tools now
gets its own deterministic source signature. An unchanged tool runtime is
restored from `.module-cache/integrated-tools/...` and its BAT is not executed.

Changing only Hub UI therefore rebuilds the Hub shell while reusing unchanged
DO Analysis, TrackerSNR, Log Explorer, Sonication Analysis, FUS Image Explore,
and VIMeasure runtimes.
