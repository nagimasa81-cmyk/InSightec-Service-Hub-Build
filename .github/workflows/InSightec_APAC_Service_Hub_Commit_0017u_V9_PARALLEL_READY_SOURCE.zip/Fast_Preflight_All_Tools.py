\
from __future__ import annotations

import ast
import json
import os
import sys
from pathlib import Path

from Build_Integrated_Tools import TOOLS, tool_is_enabled, validate_tool_source_contract


def parse_python_tree(root: Path) -> int:
    count = 0
    for path in root.rglob("*.py"):
        parts = {p.lower() for p in path.parts}
        if "__pycache__" in parts or ".venv" in parts or "build" in parts or "dist" in parts:
            continue
        ast.parse(path.read_text(encoding="utf-8-sig", errors="replace"), filename=str(path))
        count += 1
    return count


def require_text(path: Path, required: list[str], label: str) -> None:
    text = path.read_text(encoding="utf-8", errors="ignore")
    missing = [item for item in required if item not in text]
    if missing:
        raise RuntimeError(f"{label}: missing required contract markers: {missing}")


def main() -> int:
    root = Path(__file__).resolve().parent
    results = []

    parsed = parse_python_tree(root)
    print(f"[PASS] Python AST parse: {parsed} files")

    for spec in TOOLS:
        if not tool_is_enabled(spec):
            print(f"[SKIP] {spec.tool_id}: disabled by build selection")
            continue
        source = root / "integrated_sources" / spec.source_dir
        contract = validate_tool_source_contract(spec, source)

        # High-value static checks that previously caused late failures.
        if spec.tool_id == "fus_image_explore":
            require_text(
                source / "03_BUILD_NUITKA_STANDALONE.bat",
                [
                    "--include-package=pyqtgraph",
                    "--include-module=PySide6.QtOpenGL",
                    "--include-module=PySide6.QtOpenGLWidgets",
                    "05_PREPARE_PACKAGED_RUNTIME.py",
                    "05_SMOKE_TEST_PACKAGED_EXE.py",
                ],
                "FUS frozen-runtime build",
            )
            require_text(
                source / "app.py",
                ["MRIE_FROZEN_RUNTIME_PROBE", "import pyqtgraph as pg", "QtOpenGLWidgets"],
                "FUS runtime probe",
            )
        elif spec.tool_id == "sonication_analysis":
            require_text(
                source / "01_BUILD_EXE_NUITKA.bat",
                ['pytest>=8,<9', "nuitka"],
                "Sonication verification/build",
            )

        print(f"[PASS] {spec.tool_id}: build contract + fast static preflight")
        results.append({"tool_id": spec.tool_id, "status": "pass", "contract": contract})

    report = {
        "schema": "insightec.fast-preflight.v1",
        "python_files_parsed": parsed,
        "enabled_tools": len(results),
        "tools": results,
    }
    out = root / "fast_preflight_report.json"
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[PASS] Fast preflight complete: {len(results)} enabled tool(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
