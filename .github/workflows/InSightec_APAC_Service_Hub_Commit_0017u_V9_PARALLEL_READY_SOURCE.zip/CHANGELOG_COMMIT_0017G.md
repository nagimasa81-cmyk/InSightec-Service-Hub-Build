# Commit 0017g — Clean Unified Tools

- Removed Dashboard route and UI code.
- Removed duplicate Auto Dataset Analyzer page UI; retained the shared dataset routing engine used by Tools.
- Removed startup-page Dashboard option; startup is always Tools.
- Canonicalized Hub build/run entry point to `main.py`.
- Removed stale embedded GitHub workflows and legacy build YML files from the SOURCE payload.
- Removed `__pycache__` / `.pyc` files.
- Removed stale prebuilt VIMeasure EXE that the integrated build always deletes/rebuilds.
- Removed one duplicate `_patient_axis_label` method definition that was being silently overwritten in FUS Image Explore.
- Updated release-mode metadata from `hybrid` to `tools` while retaining direct card launch + ZIP drop routing capabilities.
