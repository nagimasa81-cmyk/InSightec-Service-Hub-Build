# Commit 0017r — FUS Image Explore Frozen Runtime Smoke Hardening

Observed runtime failure:
`ImportError: PyQtGraph requires one of PyQt5, PyQt6, PySide2 or PySide6; none ... could be imported.`

Changes:
- Import PySide6 before pyqtgraph in `app.py`.
- Explicitly include pyqtgraph and QtCore/QtGui/QtWidgets/QtOpenGL/QtOpenGLWidgets in the Nuitka build.
- Probe these imports in the build venv before compilation.
- Launch the actual packaged EXE with `MRIE_STARTUP_SMOKE_TEST=1` and `QT_QPA_PLATFORM=offscreen`.
- Fail the FUS build if the packaged EXE does not create the Qt application/window and exit cleanly within 30 seconds.
- Because Build_Integrated_Tools caches only after the BAT returns success, a broken FUS executable is no longer saved as a reusable module runtime.
