from pathlib import Path
from feedback_engine import FeedbackEngine, FeedbackRequest, build_runtime_context
APP_DIR=Path(__file__).resolve().parent
engine=FeedbackEngine(APP_DIR, feedback_to="service@example.com")
context=build_runtime_context(application="My PySide6 Tool", application_version="1.0", build="001", current_page="Analysis", related_tool="My Tool", extra={"selected_file":"sample.log"})
request=FeedbackRequest(category="Bug Report", priority="High", comment="Describe the issue", context=context)
body, outputs=engine.prepare(request)
print(outputs)
