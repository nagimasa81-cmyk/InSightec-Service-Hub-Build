from pathlib import Path
from feedback_engine import FeedbackEngine, FeedbackRequest, build_runtime_context
APP_DIR=Path(__file__).resolve().parent
engine=FeedbackEngine(APP_DIR, feedback_to="service@example.com")
context=build_runtime_context(application="My Tkinter Tool", current_page="Dashboard", related_tool="My Tool")
request=FeedbackRequest(category="Improvement Request", comment="Describe the request", context=context)
body, outputs=engine.prepare(request)
print(outputs["template"])
