Read docs/INTEGRATION_GUIDE.md. Copy feedback_engine into each tool source.
